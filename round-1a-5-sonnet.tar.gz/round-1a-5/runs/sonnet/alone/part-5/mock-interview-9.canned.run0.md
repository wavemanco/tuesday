I'll read the reference files before building the pack.
Research is done, so I'm writing the pack file now.
Your prep pack is saved as `Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. I built it for a panel with Principal Vantongeren in the hiring-manager seat and two fourth-grade teachers as peers. I didn't have the posting text, so the role's duties come from a representative listing and are labeled as inferred.

- **Licence:** your Illinois PEL line meets the invite's one stated requirement on its face. I didn't check any registry, so expect the district to verify it.
- **Highest-ROI prep:** question A1, "You haven't taught fourth grade. What will be hardest in your first month?" The pack gives you the plain acknowledgment, the six years of third grade at their own scope, and a three-step follow-up ladder.
- **Your Social Security number:** your message included it. It isn't needed for any of this. I haven't used it, and it's not in the pack or in any search, so I'd leave it out of anything else you paste.

Say the word and I'll play the Skeptic on A1, with live follow-ups, and then give feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the posting text? It would replace the inferred duties with the district's own list and could add a requirement I can't see, such as team lead.
Did HR say anything about the format, like a sample lesson or a prep task? A named deliverable would get its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren plus two members of the fourth-grade team (names not given)
**Built on:** a panel with one hiring-manager seat and two peer seats, and no posting text from you, so the role's duties come from a representative listing and are labeled `[inferred]`.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each bank is one persona. Each question carries one type tag.
- **Type key:**
  - **VAL**: whether your past behavior shows the district's published beliefs.
  - **EXP**: whether your own account survives follow-ups, including how much was you.
  - **JD**: the stated duties and requirements of the role, including its gaps.
  - **CO**: what you know about the district and its current plans.
  - **CASE**: a live problem set in the role.
- **Provenance labels:** `[grounded]` traces to your material or to a page cited in Sources. `[inferred]` is derived from a representative source, with the derivation named. `[generic]` is a pattern with no claim about this district or about you.
- **Guidance is scaffolding, not a script.** Say it in your own words. Where a cell says answer slot, it is an instruction for the interview: answer from your real experience, or say plainly that the practice was not yours or did not exist.
- **Bank letters:** banks run A to E, then G. The letter F is skipped because F1 to F9 name fit-snapshot rows.
- **Highest-ROI prep:** question A1, with its follow-up ladder.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — the invite from Human Resources | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is shown met on your page, so no bridge is needed. Say it as written: kind, endorsement and expiry. Nothing is inspected behind it here and the pack did not check any registry, so expect the district to verify it. The stated grades 1–6 span fourth grade; that is the pack's reading of the quote, not a line to add. The licence number stays out of this pack on purpose |
| F2 | "Fourth Grade Teacher position" — the invite from Human Resources | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Answer slot: say what you expect to learn first and how, in your own words; if you do not yet know what differs between the grades, say so plainly |
| F3 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, a representative listing and not this district's posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your line says the grade and the years, not the subjects. Answer slot: the listing's subject list makes a probe on which subjects you taught likely; say which you taught, in your own words; if you taught only some, or someone else taught the rest, say so plainly and stay with the six years |
| F4 | "Panels ask about reading instruction" — the district's How we hire teachers page | "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a curriculum move and a club, not how reading is taught day to day, and the words stay at those scopes: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if anything changed in how you taught reading after the move, say what, in your own words; if nothing did, or the change was not yours, say so plainly and stay with the move you led |
| F5 | "work with the grade-level team" — K12 Jobs Board listing, a representative listing | "I led our grade level's move to a new reading curriculum in 2024", "I've never been a team lead" — your CV | medium | [inferred] | transferability | The move is the nearest your material comes to leading colleagues, and you have said you have not been a team lead. Words: "I haven't been a team lead. I led our grade level's move to a new reading curriculum in 2024." Answer slot: if asked what leading the move involved, say what you did, in your own words; if a part was not yours, say so plainly and stay with the sentence |
| F6 | "each teacher speaks with every family each term" — the district's Mission and Beliefs page, under Families Are Partners | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your material says an email, not a conversation, and the words stay with the email: "I write a weekly email to families." Answer slot: say who the email reaches and what it carries, in your own words; if asked about any other contact with families, answer from your own experience, and if there is none, say so plainly |
| F7 | "no student leaves third grade without a reading plan" — the district's Mission and Beliefs page, under Every Child a Reader | none given | none | [grounded] | discovery | The material is silent on reading plans. Answer slot: the belief makes a probe on this likely; if students in your class had reading plans, say how they were made and what part was yours, in your own words; if there were none, or they were not yours, say so plainly and say how you would make one |
| F8 | "assessments inform teaching and never replace it" — the district's Mission and Beliefs page, under Teach for Tomorrow, Not for the Test | none given | none | [grounded] | discovery | The material is silent on assessment. Answer slot: if you used assessment results to change what you taught, say what you did, in your own words; if you did not, or that was set by someone else, say so plainly and say what you would look at first |
| F9 | "classroom routines" — the district's How we hire teachers page: "Panels ask about reading instruction, classroom routines and how you work with families" | none given | none | [grounded] | discovery | The material is silent on routines. Answer slot: if you set routines in your own classroom, say what they were and why, in your own words; if they came from the school or from someone else, say so plainly and describe how you would set them as a plan |

## Reading the interviewer

The only footprint the search returned for Principal Vantongeren is one speaker page, which says: "Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist." and "Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5." Nothing she wrote about her own style was returned, so no style is inferred. The two fourth-grade team members are unnamed, so there is no read on them.

- **Reading is her field.** A reading question from her can go past the curriculum move to what one reader needs. Rehearse A2, C1 and G1 with that in mind.
- **Do not claim practices from her talk.** Your material says nothing about reading conferences, so the pack coaches no claim about them. Ask her about the talk instead (R1).
- **Candor beats bluffing in her own field.** Where an answer slot's second branch is true for you, say it plainly and move on.
- **Mirror opportunities:** use her own phrase "reading conferences" when you ask, never when you describe your work. No shared career jump is offered, because no row's evidence carries your side of one.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Probing of the fourth-grade gap and of how far the curriculum move was yours | Highest. The principal's seat takes the hiring-manager prior (Case/Strategist plus Skeptic), and your own material states two gaps (F2, F5) | Rehearse "I haven't taught fourth grade" until it is boring (A1). The hold is the quote at its own scope; never add to it |
| Peer Evaluator (bank B, 4 questions) | The two fourth-grade teachers asking what you need from them, how you share credit and how you would disagree | High. The district page says the panel is "the principal and two grade-level teachers", so two of three seats carry the peer prior | Reciprocity framing (B1); "we" for context and "I" for contribution (B2) |
| Values/Behavioral (bank C, 3 questions) | Stories tied to the three published beliefs | Medium. The district page says the beliefs "guide every hire" and that panels ask "how you work with families", but no source documents a separate values round | A story where one of your sentences carries one; otherwise a scaffold ending in its honest branch |
| Case/Strategist (bank D, 3 questions) | A live reading problem, a first-week routines plan, a current-plan question | Medium. The district page says panels ask about "reading instruction, classroom routines"; the principal's seat adds the case prior | Clarify, then objective, then approach, then how you would check it. Think aloud |
| Conversational (bank E, 3 questions) | The opening "walk me through how you got here" and friendly follow-ups | Medium. A panel usually opens with the biography; casual questions are still scored | A 90-second arc built only from your four sentences (E1) |
| Data-Driven Prober (bank G, 2 questions) | How the curriculum move was judged, and how you use assessment results | Low. The peer prior pulls it up, but your material carries no figures to defend | Say what you looked at, or say plainly that nothing was measured |
| Pressure | Not planned | Not expected. No source describes time-boxed or adversarial questioning in this panel. A1's follow-ups use hold-then-concede in case the Skeptic leans hard | None needed beyond A1's ladder |

The loop itself comes from a loop source: the district page says teacher hiring is "one 45-minute building panel: the principal and two grade-level teachers", which matches your invite. No archetype fallback was used.

## Question banks

No values round is documented, so there is no values cheat sheet. The three published beliefs theme bank C. No question here defends a figure, because your material carries none.

### A. Skeptic (principal's seat, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What will be hardest for you in your first month?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Hold, then concede. Open with the plain words: "I haven't taught fourth grade." Then the six years at their own scope: "For six years I have taught third grade at a public elementary school in Joliet." Answer slot: name what you expect to be hardest and how you would learn it, said as a plan and never as something already done; if you do not yet know what differs between the grades, say so plainly and say who you would ask first. Follow-up ladder, held by returning to those two sentences and never by adding to them: (1) "Why take that risk over someone who has taught it?" Concede the gap and claim no equivalence. (2) "What would you need from the two of us?" A plan, in your own words. (3) "Is there anything from third grade that won't carry over?" Answer slot: say what you know, or say plainly that you do not yet know | F2 is your stated gap and the role's headline, so this question will arrive in some form and earns the most follow-ups. JD because it scores the position's own grade; the Skeptic delivery is how it arrives |
| A2 | "Walk me through the move to a new reading curriculum that you led in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F4. The beats are the quote's: the grade level's move, to a new reading curriculum, in 2024, led by you. Tell them in your own words and keep "our grade level" as the scope. Answer slot: the panel's reading focus makes a probe on which parts were yours likely; say which parts were yours and how you decided them; if a part was not yours, or you did not decide it, say so plainly and stay with "I led our grade level's move". Never widen it to the school or the district | F4 is your strongest reading evidence and the likeliest place for a how-much-was-you probe. EXP because it tests attribution |
| A3 | "Have you led other teachers before?" | EXP | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Plain words first: "I haven't been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Hold there. Do not call the move a team-lead role, and do not describe what leading it involved beyond what you did. Answer slot: if asked what leading the move involved, say it in your own words; if a part was not yours, say so plainly and stay with the sentence | F5's stated limit. No source read for this pack says the role asks for a team lead, so the likelihood is modest; it is here because you named the gap yourself. JD with EXP delivery |
| A4 | "Why fourth grade, and why Halvering?" | JD | [grounded] | Give your actual reasons, in your own words; the pack does not know them. Shape: one reason for the grade, one for this school. If you name a district belief (Every Child a Reader, Families Are Partners, or Teach for Tomorrow, Not for the Test), name only one you can back with something you really do, and do not quote the page back as a compliment | A grade change invites the why-this-move probe. JD because it tests the stated role; the beliefs come from the district's Mission and Beliefs page |
| A5 | "Which subjects did you teach in your third-grade classroom?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Say the grade and the years as the quote states them. Answer slot: the listing's "plan and teach reading, writing, math, science and social studies" makes a probe on which you taught likely; say which, in your own words; if you taught only some, or someone else taught the rest, say so plainly and stay with the six years | F3. The listing is a representative one, not this district's posting, so the label is inferred |

### B. Peer Evaluator (the two fourth-grade teachers, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be the newest member of our team. What do you need from us in the first month?" | JD | [grounded] "I've never taught fourth grade"; "I've run the after-school reading club for the last two years" | Reciprocity framing: the need first, then what you offer. The need is yours to name; your stated gap supports saying you need to learn the grade from them. The offer is only what your sentence carries: "I've run the after-school reading club for the last two years", offered as something to talk about, not a promise of what it will do for their room. Answer slot: if there is a specific thing from the club or from third grade you would share, name it in your own words; if none comes to mind, say so plainly and ask what the team would find useful | The peer reciprocity stem, with F2's gap turned into the need. JD because it scores fit with the team's work |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for context and "I" for contribution. The sentence supplies both: our grade level, and you led the move. Answer slot: say which parts others did and which were yours, in your own words; if you cannot separate them, say so plainly | The peer credit-sharing stem. F4 and F5 are the only rows with shared work. EXP because it tests attribution |
| B3 | "A teammate teaches the same unit very differently from you, and the results diverge. What do you do?" | CASE | [generic] | Structure it: find out what differs and why, starting with student work; agree what you are both trying to get for students; share rather than judge; decide what you adopt and what you keep, and say why; take it to whoever sets the team's direction only if it does not resolve. The question needs no claim about your past, so the guidance makes none | A collegial disagreement probe. CASE because it is a live problem; [generic] because it is a pattern and not a fact about this team |
| B4 | "From where you sit in third grade, what should fourth grade know about the students coming up?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | The ground is the quote: six years of third grade. Answer slot: say what you know about how your own students finished the year, in your own words; if you do not know how they did after leaving your class, say so plainly and say what you would ask the team. The district's line "no student leaves third grade without a reading plan" makes the handoff a likely place to be probed; F7's slot covers it | The third-to-fourth handoff is where the role and your grade meet. F7 raises it |

### C. Values/Behavioral (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a child's reading needed more than the class plan." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Theme: Every Child a Reader. Selection scaffold: pick one child, unnamed, where you can say what you saw, what you did and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years", at that scope, or say how you would handle it | The published belief, via F7, is the raising source. VAL because it scores behavior against a published belief |
| C2 | "Tell me about a time you worked with a family to help a child." | VAL | [grounded] "I write a weekly email to families" | Theme: Families Are Partners. Selection scaffold: one family, what the child needed, what you did, what the family did next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I write a weekly email to families", at that scope, or say how you would handle it. Answer slot: say who the email reaches and what it carries, in your own words | F6. The district page says panels ask how you work with families |
| C3 | "Tell me about a time what a child needed and what a test showed were not the same thing." | VAL | [grounded] | Theme: Teach for Tomorrow, Not for the Test, whose page says "assessments inform teaching and never replace it". Selection scaffold: the child's need, what the assessment showed, what you did, how you decided. If no such time comes to mind, say so plainly, then say how you would handle it. Your material carries no assessment sentence, so no story is mapped | F8. VAL because it scores a published belief; the guidance is a scaffold because no sentence of yours carries it |

### D. Case/Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A fourth grader reads aloud smoothly but can't tell you what the passage was about. What do you do over the next two weeks?" | CASE | [generic] | Clarify first: what have you seen, across how many passages, and what do other signals say. Then the objective, two or three possible causes, the smallest step to try first and how you would check it, a word with the family, and what would change your plan. Think aloud and challenge one premise, such as whether the trouble is comprehension or vocabulary. The question makes no claim about your past, so neither does the guidance | The district page says panels ask about reading instruction (F4's requirement). A live problem at fourth-grade altitude; [generic] because it is a pattern |
| D2 | "It's the first week of school and you have a full class. Which routines do you put in place first, and why?" | CASE | [grounded] | The district page says panels ask about "classroom routines". Choose a few routines, give the reason for each and say what you would watch for and how you would adjust after a week. Plan language only: "I would". Answer slot: if asked whether these are routines you use now, say which are yours, in your own words; if some come from your school, or you have not set routines yourself, say so plainly | F9. CASE because it is a plan for a live situation |
| D3 | "The board adopted a literacy plan in August. What do you know about it, and what would it mean for a fourth-grade room?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The search extract says the plan has "structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term." Read the full page before Thursday; the pack saw only the extract. Bring one fact from it and one question about it. Fourth grade sits inside grades 3–5; that is the pack's reading, not the page's words. Whether your 2024 move bears on the new curriculum is yours to say: your sentence is the whole of what your material shows, and it does not show a link, so assert none | The one current-strategy question, from an August 2026 source. CO because it scores homework depth |

### E. Conversational (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through how you got here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc of four beats, one per sentence, in that order, each at its own scope and in your own words. Close with one beat that is yours: why fourth grade (A4's slot). Nothing between the beats is supplied by the pack | The opener is casual and scored. EXP because it asks for your account of your own path |
| E2 | "Tell me about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats are the quote's: after school, a reading club, the last two years, run by you. Answer slot: the panel's reading focus makes a probe on what the club does likely; say what a session holds, in your own words; if you can point to something a child did afterward, say it; if you cannot, say so plainly | F4. The club is your most concrete reading evidence outside the classroom |
| E3 | "You write an email to families every week. Tell me about it." | JD | [grounded] "I write a weekly email to families" | The beats are the quote's: weekly, an email, to families. Answer slot: say what it carries and who it reaches, in your own words; if asked whether you also speak with families, answer from your own experience, and if you do not, say so plainly | F6. JD because the listing asks you to "communicate regularly with families" and the district page asks how you work with families |

### G. Data-Driven Prober (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How did your grade level judge whether the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope. Answer slot: the district's "assessments inform teaching and never replace it" makes a probe on what was looked at likely; if your grade level looked at something, say what and what you made of it, in your own words; if nothing was looked at, or that was not yours, say so plainly and say what you would look at | F4 and F8. EXP because it tests whether the claim survives a second question |
| G2 | "How do you use assessment results to plan your teaching?" | JD | [inferred] | The listing's "differentiate instruction using assessment data" is a typical duty for the role, not this team's practice. Answer slot: if you use results to change what you teach next, give one example in your own words; if you do not, or the plan is set for you, say so plainly and say what you would look at first | F8. [inferred] because the requirement comes from a representative listing |

### Requirement coverage

| Requirement | Questions |
|---|---|
| License gate (F1) | none: a term the material shows met, asked at most as a verification; say it as written |
| Fourth Grade Teacher position (F2) | A1, A4, B1, B4, D2 |
| "plan and teach reading, writing, math, science and social studies" (F3) | A5, D1 |
| "differentiate instruction using assessment data" (listing) | G2, C3 |
| "keep clear classroom routines" (listing) | D2 |
| "communicate regularly with families" (listing) | E3, C2 |
| "work with the grade-level team" (F5) | A3, B1, B2, B3 |
| Reading instruction (F4) | A2, D1, E2, G1 |
| Every Child a Reader (F7) | C1, B4 |
| Families Are Partners (F6) | C2, E3 |
| Teach for Tomorrow, Not for the Test (F8) | C3, G1, G2 |
| The August literacy plan | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade room here, and what would you want a new teacher to learn first?" | Ties to the principal's own public path and shows you read about her, not only the district. It also hands her the floor on her own field |
| R2 | "What could a new person on the fourth-grade team do in their first month that would genuinely help your team?" | The reciprocity question for the two peer seats. It signals you are thinking about their load |
| R3 | "I read that the board adopted a literacy plan in August with a new grades 3–5 reading curriculum from fall 2027. What is fourth grade's part in that so far?" | Shows current homework and points at where this role sits. Say "I read" only once you have read the full page |
| R4 | "How does the fourth-grade team plan and share work week to week?" | Tells you what the team seam looks like before you sign up to it, and gives the peers an easy answer |
| R5 | "What does a strong first semester look like for a teacher who is new to fourth grade?" | Lets them define the ramp, which turns your stated gap into a shared plan |
| R6 | "The district's page says each teacher speaks with every family each term. How does that work in practice at Halvering?" | Shows you read the belief and gets the real workload, without claiming you already meet it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't taught fourth grade." Then the six years of third grade at their own scope, as F3's quote states them |
| Has been a team lead, or led the grade-level team | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Led the school's or the district's reading curriculum change | Inflated form of F4's quote | F4's quote at its own scope. The limit is the pack's observation: your material says the grade level's move, not a school-wide or district-wide one |
| Meets the district's family-conversation belief | Inflated form of F6's quote | F6's quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says an email, not a conversation. E3's and C2's slots stay inside the email |

## Sources

**Provided documents:** the invite from Human Resources, Orrinsford Community School District; your résumé text as you pasted it. No dossier was present.

**Searches sent:**

1. "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
2. "Orrinsford Community School District teacher interview process" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
3. "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. "fourth grade teacher job posting Illinois public elementary school responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher

**Fetches sent:**

1. https://orrinsfordschools.example/about/mission-and-beliefs returned the page text, the three beliefs and their one-line definitions.
2. https://orrinsfordschools.example/careers/how-we-hire-teachers returned the page text, the panel format and its topics.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three published beliefs: fit rows F6 to F8 and the themes of bank C. No values cheat sheet, because no loop source documents a values round |
| 2. `{company} interview process {role family}` | yes | The loop: one 45-minute panel of the principal and two grade-level teachers, which fixes the persona weights and matches the invite |
| 3. `{company} strategy` / recent news | yes | The August 2026 literacy plan, from the search extract only (no fetch was left): question D3 and reverse question R3 |
| 4. `{interviewer name} {company}` | yes | The principal's public speaker page, from the search extract only: the interviewer read and R1. The two teachers were not named, so no query could be formed for them |
| 5. representative `{role title}` JD | yes | The K12 Jobs Board listing, from the search extract only and cut off before its qualifications: the `[inferred]` rows F3 and F5 and the listing-derived questions A5 and G2 |

## Upgrade menu

- The posting text for this role → F3 and F5 become `[grounded]` or are replaced by the posting's own requirements, and the coverage table is re-keyed to its list, which could add a team-lead or sample-lesson requirement this pack cannot see.
- Anything HR said about the format, such as a sample lesson, a prep task or focus areas → a build section for any pre-declared deliverable.
- The names of the two fourth-grade teachers → an interviewer read per seat, persona weights set per person and a reverse question tied to each one's path.
- Your answers to the answer slots, stated outside a drill → F3, F4, F6, F7, F8 and F9 become quoted evidence, and the questions that draw on them get story maps in place of scaffolds.
- The full text of the board's literacy plan, pasted → D3 and R3 rest on a read page instead of a search extract. A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, is available if you want it.
- How many hours you have before Thursday → a prep triage that puts the few things worth doing first, such as A1, ahead of everything else.
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → the highest-ROI objection would come from verified evidence instead of from this pack's reading, and weak areas would carry the underwriter's positioning limits.
