# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner. Round: recruiter screen, a 30-minute phone call on Thursday at 2pm. She will ring the mobile number on your application. Her stated agenda, in her words: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.

## How to use this pack

- Personas are how a question arrives. Types are what it scores. Every question carries both.
- Type tags: VAL = values and behaviour (none of the questions here is VAL, because no published values were in hand); EXP = what you actually did; JD = the advert's stated duties and terms; CO = knowledge of the company; CASE = a live problem from the role.
- Guidance is scaffolding, not a script. Where it quotes you, those are your own sentences from your message, and they are the whole of what the pack knows about your past.
- An "answer slot" is an instruction for the call, not a question for you here: answer it from your own experience, in either branch.

## Prep triage

1. Say A1 to A4 aloud once each. They are the four topics Hannah named, and your own words already answer them.
2. Rehearse B1 until it is boring. It is the highest-ROI prep in this pack: the advert lists "ERP experience (SAP or similar) a plus" and your material says you have never used SAP.
3. Run C1 once, so you can say how your stock-discrepancy figure was counted, or plainly that you don't know.
4. Say the A5 arc aloud once, under 90 seconds.
5. Everything else is insurance for later rounds.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: four years, logistics coordinator, a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling and not work with a planning team or QA, and the words stay at the depots. Answer slot: the advert's planning, warehouse and QA line makes a probe on cross-team work likely. If you worked alongside any of those teams, say who and what you did; if you did not, say so plainly and stay with the three depots' delivery schedules |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap on the chasing half: you chase suppliers when orders slip, and that is the phrase to use. Expect a probe on how, which is C3 |
| F4 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The sentence touches the requirement without showing whether you track supplier deliveries, and the pack does not assume it. Answer slot: if you tracked supplier deliveries, say where and how, in your own words; if there was no tracking step, or it was not yours, say so plainly and stay with chasing suppliers when orders slip |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Quote it at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The figure invites a defend-the-number probe, which is C1 |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet, and the material does not say which tool. Answer slot: if it was Excel, say what you used it for in that rebuild, in your own words; if it was another tool, or you used little of Excel, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | The words are your own: "I haven't used SAP", from your stated negative, and "we run our own in-house stock system", at that scope. The pack's observation is that your material says an in-house stock system, nothing more. Answer slot, if asked about the in-house system: say what you use it for in your own words; if the honest answer is not much, say so |
| F8 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you produced any regular report on deliveries, say what it showed and how often, in your own words; if there was none, say so plainly and stay with the spreadsheet rebuild |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your own constraint, stated specifically. Use your sentence as it stands; nothing is added to it |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your own figure, stated specifically, and it sits inside the advert's band. Use your sentence as it stands; nothing is added to it |

Requirement coverage:

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A5, E1 |
| Coordinate production schedules between planning, the warehouse and QA | B3, D1, F1, F2 |
| Track supplier deliveries and chase late orders | C3, D1 |
| Keep stock records accurate | C1, D2 |
| Report weekly on on-time dispatch | B4 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar), a plus | B1, E2 |
| £38,000–£44,000 | A1 |
| Hybrid, two days a week at Avonmouth | A3 |
| Notice period (Hannah's topic, not an advert requirement) | A2 |
| What's prompting a move (Hannah's topic) | A4, B2 |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, structured phone call; casual questions that are still scored | Highest. A recruiter screen leans conversational, and Hannah has listed her four topics in a friendly register | Your own words for A1 to A4 are the answer; a 90-second arc for A5 |
| B. Skeptic | Quiet probing of the gaps: ERP, production scheduling, why this sector | High, second. Recruiter screens carry knockout checks, and F7 and F2 are where the advert and your material differ | B1 rehearsed until boring; bridges only from what your quotes say |
| C. Data-Driven Prober | Asks how the figure was counted | Medium-low. She may touch the figure briefly; a later round is likelier to press it | Say how it was counted, or plainly that you don't know |
| D. Case / Strategist | Live problems from the role | Low for this call. The loop beyond it is not established, so this is insurance, flat-weighted | Clarify first, then structure |
| E. Pressure | Time-boxed "why you" | Low. A recruiter rarely stress-tests, but the sixty-second pitch does come up | Hold, then concede the SAP gap in one clause |
| F. Peer Evaluator | Seam and collaboration questions | Low. A later round with the team is possible, not documented | Principles for the seam, not claims about a past |

Loop note: only this screen is established, by Hannah's own words. Rounds after it are unknown, so the weights beyond A and B rest on the generic pattern of screen, hiring manager, panel, and are said to be flat.

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled by your own words: "I'm hoping for £42,000." Say it and stop; nothing is added, and the pack gives no reasoning for the number. If asked what you earn now, you can redirect: "I'd rather focus on the range for this role" | Hannah named salary expectations first, and F10 is your own figure; JD because it scores the advert's terms |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period. If any part of it is uncertain, say which part you would need to check rather than guessing | Hannah named notice period; your material states none, so the slot is an instruction and the pack supplies no figure; JD because it is a term of the hire |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled by your own sentence, in your own words. If asked a follow-up on the commute or the pattern, your own words again, nothing added | F9 is the advert's hybrid term met in your own words; JD because it scores a stated term |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, filled by your own sentence, said plainly and in your own words. If pressed on it, return to those words rather than adding reasons. The pack's observation is that your material gives a reason for leaving, not a reason for Quillmoor; B2 covers that | A recruiter always asks it, and motive consistency is scored in a friendly register; EXP because it is about your actual circumstances |
| A5 | "So — walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." and "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with four beats, each one a clause your quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words and in your own order | The biography opener is almost certain on a screen; F1, F3 and F5 are the evidence it draws on; EXP because it scores what you actually did |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "ERP experience, SAP or similar, is a plus for this role. Where are you on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The highest-ROI rehearsal in this pack. Level 1: say what the sentence carries, in your own words: you have never used SAP, and you run your own in-house stock system. Level 2, if pressed on that system: answer slot, say what you use it for in your own words; if the honest answer is not much, say so plainly and return to the sentence. Level 3, if pressed on learning an ERP: say how you would go about learning one, as a plan, never as a past. Hold the sentence through all three levels and concede the SAP gap in one clause | F7 is the likeliest knockout-style objection to you in a screen that reads the advert line by line; JD because it scores a stated requirement, Skeptic because it presses the gap |
| B2 | "What's drawing you to a diagnostics manufacturer, and to Quillmoor?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | A selection scaffold. If something specific in the advert draws you, name it in your own words. If the honest answer is that the search started with the office closing, say so plainly; that quote is the whole of what your material says on motive. Do not borrow claims about Quillmoor's products or standing from memory, because the pack has not verified any | A move prompted by a closure invites "why us"; Hannah's own "what's prompting a move" raises it. EXP because it tests whether your story holds under follow-up |
| B3 | "The role coordinates production schedules between planning, the warehouse and QA. How does that compare with what you do now?" | JD | [grounded] "I schedule deliveries for our three depots" | The hold is only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if you have worked alongside a planning team, a warehouse or a QA function, say who and what you did; if not, say so plainly and stay with the three depots' delivery schedules | F2 is where the advert's duty and your material differ most; JD because it scores the duty |
| B4 | "The role reports weekly on on-time dispatch. What reporting have you done?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if you produced any regular report on deliveries, say what it showed and how often, in your own words; if there was none, say so plainly and stay with the spreadsheet rebuild, at its own scope | F8 is silent in your material, and the advert names the report, so a probe is likely; JD because it scores a stated duty |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know exactly how it was counted" is an honest branch. Keep the sentence's own scope: "about a third", "over a year", "I rebuilt" | F5's figure is the one number on your side, and probers go to numbers first; EXP because it scores attribution |
| C2 | "The role needs someone confident with Excel. How confident are you, and where have you used it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the spreadsheet was in Excel, say what you used it for in the rebuild, in your own words; if it was another tool, or you used little of Excel, say so plainly and stay with the rebuild | F6 is open: the quote says spreadsheet, not Excel, and the advert names Excel; JD because it scores a stated requirement |
| C3 | "You chase suppliers when orders slip. How do you keep track of what is late?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you tracked orders in a particular place or way, say where and how, in your own words; if there was no tracking step, or it was not yours, say so plainly and stay with chasing suppliers when orders slip | F3 and F4: the chasing is yours, the tracking is open; JD because the advert pairs them |

### D. Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery that QA needs is a week late, and production is scheduled for Friday. What do you do?" | CASE | [generic] | Structure it: what you ask first (what exactly is late, what depends on it, how firm the new date is), who needs to hear (planning, the warehouse, QA), the options, and what you record. The question needs no claim about your past, so the guidance makes none | The advert's coordination and chasing lines, set as a decision; `generic` because it is a role-family pattern, not a fact about Quillmoor |
| D2 | "The stock record says there is more on hand than the shelf holds. How do you handle it?" | CASE | [generic] | Structure it: confirm the count first, look for the cause before adjusting the record, say who needs to know, and say what you would put in place so it is caught sooner. No claim about your past | F5's requirement ("keep stock records accurate") as a live problem; generic for the same reason |
| D3 | "What do you know about Quillmoor?" | CO | [generic] | Use only what the advert says: a diagnostic-test manufacturer, about 400 staff, a site at Avonmouth. Say that is what you have seen. Before the call, read their careers page; the pack could not verify strategy or recent news | Recruiters often ask it casually; CO because it scores homework. Generic, because the research searches were not permitted |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we put you forward?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." | Three beats from your quotes, in your own words: the four years, the three depots, chasing suppliers when orders slip. Stop at sixty seconds; do not add a claim to fill the time | F1 and F3 are the evidence; the pitch is the likeliest time-boxed question in a screen |
| E2 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold-then-concede. Name the weakest part your material shows, in your own words: you have never used SAP. Concede it in one clause and stop. If another area is honestly weaker, such as the production side, say so plainly rather than hiding it | F7 and F2 are where the material is thinnest; JD, because it scores honest self-assessment against the advert |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Planning, the warehouse and QA sit side by side and will sometimes want different things from you in the same week. What do you do?" | CASE | [generic] | Offer principles for the seam rather than claims: find out what each team actually needs and by when, make the trade-off visible to all three, and agree one source of truth. No claim about your past | The advert's coordination line, asked collegially; generic because it is a pattern, not a fact about this team |
| F2 | "Tell me about a time you had to rebalance a schedule because different people needed different things." | EXP | [generic] | Selection scaffold: pick a time the schedule was yours to change, with a named competing need and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The advert's coordination line raises it; the pack holds no quote that carries this story, so it is a scaffold, not a story map |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do the next stages look like, and who would I meet?" | Hannah has said she will cover next steps; this gets the loop structure, which the pack could not establish |
| 2 | "Who would I work with most day to day across planning, the warehouse and QA?" | It mirrors the advert's coordination line and shows you read it |
| 3 | "What would good look like in the first few months, particularly on the weekly dispatch report?" | It ties to a stated duty and shows you think about what you would be measured on |
| 4 | "Which ERP does the team use, and is training part of getting started?" | It turns the SAP gap into a forward question about learning, without claiming any past |
| 5 | "For the two days at Avonmouth, are they fixed days or agreed with the team?" | A practical question that signals you are planning to be there |
| 6 | "Is this a new role or a replacement, and what prompted the opening?" | It gives context on the team and shows interest in the role's history |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has SAP or ERP experience | Negative you stated, F7 | Your own sentence: "Never used SAP — we run our own in-house stock system." The plain acknowledgment, from that quote: "I haven't used SAP". No slot |
| Your in-house stock system is an ERP | Inflated form of F7 | The quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material says an in-house stock system, nothing more |
| Coordinated production schedules across planning, the warehouse and QA | Inflated form of F2 | The quote at its own scope: "I schedule deliveries for our three depots". The limit is the pack's observation: your material says delivery scheduling, not production scheduling |
| Cut stock discrepancies by a third | Inflated form of F5 | The quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the material says "about", "fell" and "over a year" |
| Flexible on salary or on the number of office days | Inflated form of F9 and F10 | Your own sentences, quoted whole, with nothing added: "I'm hoping for £42,000." and "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

## Sources

Provided documents: Hannah Lowther's LinkedIn message, the advert text, and your notes about your background and what you would say. Nothing else was read.

Searches sent (all refused, none returned a result):

- "Quillmoor Diagnostics company values" — refused
- "Quillmoor Diagnostics Avonmouth news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have named the company's published values for B2; no values-style round is detected, so no values cheat sheet was due |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Hannah's own message fixes this session (one 30-minute recruiter call), so persona weights were already set; rounds after it stay unknown |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have grounded D3, which is generic as a result |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have supplied an interviewer read and a reverse question tied to her path |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search, or a pasted careers or values page for Quillmoor → D3 and B2 gain company-specific grounding instead of `[generic]`, and the loop for later rounds could be documented
- Hannah's public professional profile (or a go-ahead to search it) → an interviewer read, and a reverse question tied to her own career path
- A fuller CV → F4, F6 and F8 could move from open rows to `[grounded]` rows if it carries the evidence, and F1's dates and title could be quoted
- Your answers to the slots in F2, F4, F6, F7 and F8 (cross-team work, tracking, Excel use, the in-house system, regular reports) → those rows and B1 to B4 and C2 and C3 regenerate with your words quoted in
- The recruiter's description of later rounds (ask Hannah in the call) → persona weights for D, E and F stop being flat
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a company strategy brief and sharper CO questions, if search is permitted
- A `tuesday-dossier.md` from an earlier evidence check → verified evidence and prohibited claims would replace the locally built list above, and B1's objection would be evidence-derived instead of inferred
