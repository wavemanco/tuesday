# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Relationship: principal as the hiring-side lead, two grade-level peers.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for your own words, not a script, and every statement about your past in it is one of your own sentences, quoted. Where your material is silent, the guidance is an answer slot: answer it truthfully from your own experience, or say plainly that the practice was not yours.

Letter F is skipped in the question IDs so they never collide with the fit rows (F1 to F9).

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether what is on your CV survives a follow-up: what was actually you |
| JD | The role's stated requirements, gaps included |
| CO | Knowledge of the district's current direction |
| CASE | A live problem from the actual job |

Highest-ROI prep in this pack: **A1**, with **A3** close behind. Both are aimed at the two things your own CV says you have not done, and both will be asked in some form. Rehearse them until they are boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met by stated status: kind, endorsement and expiry, as written. Nothing here has been inspected, and checking the record is yours. Say it in the quote's own terms and no wider |
| F2 | "Fourth Grade Teacher position" — your invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've never taught fourth grade" — your CV | medium | [grounded] | transferability | Third grade is adjacent work at its own scope: "Six years teaching third grade at a public elementary school in Joliet." The limit is yours to state plainly: "I've never taught fourth grade." Any wider step is an answer slot: say what you already know about the step up, in your own words; if nothing yet, say so plainly and say what you would ask the team first |
| F3 | "reading instruction" — Orrinsford "How we hire teachers" page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your material says a curriculum move and a club, not the instruction itself, and the words stay there. Answer slot: expect a probe on how much of the move was yours; say what "led" covered, in your own words, and if it covered less than the word suggests, say so plainly and stay with the move |
| F4 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I've run the after-school reading club for the last two years." — your CV | low | [grounded] | discovery | The club touches reading, and the quote does not show reading plans. Answer slot: the belief names reading plans, so expect a probe; if you wrote or kept plans for students, say how, in your own words; if plans were not part of your practice, or not yours, say so plainly and stay with the club |
| F5 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | An email is not a conversation, so the words stay at the email: "I write a weekly email to families." Answer slot: if you also speak with families, say how and when; if the email is the whole of it, say so plainly and stay with it |
| F6 | "assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if assessment results ever changed what you taught, say what and how, in your own words; if they did not, or that was not yours to decide, say so plainly and say how you would use them |
| F7 | "classroom routines" — Orrinsford "How we hire teachers" page | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you set routines for your class, say which and why, in your own words; if they were set elsewhere, or you had none of your own, say so plainly and answer B3 as a plan |
| F8 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing for a fourth-grade teacher (a representative posting, not this district's) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The quote says third grade, not which subjects. Answer slot: say which of those subjects you taught, in your own words; if some were not yours to teach, say so plainly and stay with the ones you did |
| F9 | "work with the grade-level team" — K12 Jobs Board listing for a fourth-grade teacher (a representative posting, not this district's) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your CV | medium | [inferred] | transferability | Your move was a grade-level move, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." And plainly: "I've never been a team lead." Nothing wider than those two sentences |

## Reading the interviewer

Public professional footprint only. The two team members are unnamed, so this section covers the principal.

| Public fact | Source | What it means for the room | Mirror opportunity | Provenance |
|---|---|---|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Illinois principals forum speaker page (search result) | Expect her to listen closely on reading. Reading instruction is also the first topic the district's hiring page lists | Shared territory is reading. Pair it with your own words only: "I led our grade level's move to a new reading curriculum in 2024" (F3) | [grounded] |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | Illinois principals forum speaker page (search result) | Her talk spans your current grade and the one you are applying for. Know what small-group reading work you have actually done before you are asked, and say only that | The club: "I've run the after-school reading club for the last two years." (F3), told at its own scope | [grounded] |

## Persona table

The loop is one 45-minute building panel of the principal and two grade-level teachers, per the district's own hiring page. That page also lists what panels ask about: reading instruction, classroom routines and how you work with families. It names no values round, so no values cheat sheet is built; the district's three published beliefs still theme the D bank.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the two things your CV states you have not done | High. Your CV states both limits (F2, F9) and a panel of the grade's own teachers is the group that will test them | Rehearse A1 and A3 until they are boring: state the limit in your own plain words, hold what your sentences carry, add nothing |
| B. Case / Strategist | Live problems from the job: first weeks of reading, a family concern, routines | High. The hiring page names reading instruction and classroom routines, and the principal's published background is reading | Clarify, then structure, then answer; think aloud; challenge one premise politely |
| C. Peer Evaluator | The two fourth-grade teachers asking what you need and what you add | High. They are the people you would work beside, and F9 is the row they price | Reciprocity: what you bring their team, not only what you need |
| D. Values / Behavioral | Questions on the three published beliefs | Medium. The mission page says the beliefs guide every hire, but no source names a scored values round | Where a quoted sentence of yours carries a story, tell it at its scope; where none does, use the selection scaffold and its honest branch |
| E. Conversational | Opening biography and the closing "any questions for us" | Medium. Every panel opens somewhere, and the hiring page lists families as a topic | A 90-second arc built only from your own sentences; treat casual questions as scored |
| G. Data-Driven Prober | Line-by-line reading of the CV, asking what "led" covered | Low to medium. The CV has no figures to defend, so the probe lands on wording instead (F3) | Know exactly what each sentence of yours covers, and say plainly where it stops |
| Pressure | Interruptions and time-boxed challenges | Low. No source points to a stress format. No bank; A1 and A3 carry the hold-then-concede structure | Pause, restate the question, hold your position through two follow-ups, concede specifically |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I see six years in third grade and no fourth. What do you expect to be hardest in your first month with fourth graders?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Hold-then-concede: open with the plain limit, "I've never taught fourth grade," then the ground you stand on, "Six years teaching third grade at a public elementary school in Joliet." Hold both through two follow-ups; never add to either. Answer slot: say what you already know about the step up from third to fourth, in your own words; if you do not know yet, say so plainly and say what you would ask the team first | F2 is the largest gap the panel can see, so this objection arrives in some form. JD because it scores the stated role; the Skeptic delivery is why it sits here |
| A2 | "Why fourth grade, why here, and why now?" | EXP | [generic] | Give your actual reasons in your own words; this pack has none from you and will not supply them. Keep it to what is true, in an order you can say in under a minute: why fourth, why this school, why this year. If one of the three has no real answer yet, say so plainly and answer the other two | Motivation consistency is the standard Skeptic probe, and F2 is why it will be pointed. EXP because it tests whether your story holds together |
| A3 | "You say you led your grade level's move to a new reading curriculum, and you've never been a team lead. How do those fit together?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead." | Hold-then-concede again. Give each sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024," and, plainly, "I've never been a team lead." Do not reconcile them with a story your material does not carry. Answer slot: say what "led" covered, in your own words; if it covered less than the question assumes, say so plainly and stay with the move | The two quotes sit side by side on your CV, so a careful reader will ask. F9 is the row; this is the second-highest-ROI rehearsal, and it shares its answer with G1, so prepare them once |
| A4 | "The post asks for a valid Illinois Professional Educator License with an elementary endorsement. Where does yours stand?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as written: the license, the elementary endorsement for grades 1–6, and the stated expiry. Add nothing about other endorsements or levels. Check the record yourself before Thursday so the words match it | The invite states this as a condition, so a knockout check is likely. F1 is the row, and it is a gate your material shows met by stated status |
| A5 | "Which of reading, writing, math, science and social studies would you want the most support with in fourth grade?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: say which of those subjects you taught in third grade, in your own words; if some were not yours to teach, say so plainly and stay with the ones you did. Then name, from your own judgment, where you would want support, and say it as a request for the team's help | The subject list comes from a representative posting, not this district's, so it is framed as typical for the role (F8). JD because it probes a stated duty |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It is the first week of school and your fourth-grade class reads at a wide range of levels. Walk us through your first two weeks of reading instruction. What do you need to know first?" | CASE | [generic] | Structure it aloud: what you would ask first, your objective for the two weeks, how you would group students, what you would do in the room, how you would check it is working, what could go wrong. Challenge one premise politely, such as how the range is known. It asks nothing about your past, so the guidance makes none | Reading instruction is the first topic the district's page lists and the principal's published background is reading (F3). CASE because it is a live problem; generic because it is a pattern, not a fact about this school |
| B2 | "A parent writes that their child says reading is boring and refuses to read at home. What do you do?" | CASE | [generic] | Structure it: what you would ask the child and the parent first, what you would try in class, what you would suggest at home, how you would follow up with the family, and when you would involve others. No past claim is needed | Families are a listed topic and a published belief (F5). CASE with a VAL flavor; generic because it is a pattern |
| B3 | "Describe the classroom routine you would set for how students arrive and begin their day, and what you would do the first time it breaks down." | CASE | [generic] | Think aloud: your goals for the routine, how you would teach it, how you would notice it breaking, and how you would reset without blame. If you have routines of your own, say so in your own words; if not, answer as a plan | Classroom routines are a listed topic (F7). CASE because it is a live design problem |
| B4 | "The board adopted a three-year literacy plan with a new grades 3 to 5 reading curriculum from fall 2027. How would you want to be involved in getting ready for it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you have read the plan: three years, a new grades 3 to 5 curriculum from fall 2027, and a family reading night each term. Then answer as a plan for how you would help. Your own sentence is "I led our grade level's move to a new reading curriculum in 2024"; say it at that scope. Answer slot: say what the move involved, in your own words; if it involved less than a full rollout, say so plainly | The plan is the district's newest published move and bears directly on your grade (F3). CO because it tests current knowledge; the source is a news item, so read it before Thursday |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about a time you disagreed with a colleague about how to teach something. How did it end?" | EXP | [generic] | Selection scaffold: pick a real disagreement that had a named subject, your own position and a working relationship afterward. Say "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | Disagreement style with equals is what peers price (F9). EXP because it asks for a real instance; generic because your material carries none |
| C2 | "You would be new to our grade. What do you need from us in the first month, and what do you bring to the team?" | JD | [grounded] "I've never taught fourth grade" "I've run the after-school reading club for the last two years." | Reciprocity: ask for specific help in your own words, and offer what you can honestly stand behind. Your sentences are "I've never taught fourth grade" and "I've run the after-school reading club for the last two years."; the club is what you can name. Answer slot: say what you would bring from the club, in your own words; if nothing from it carries over, say so plainly and offer what you would actually do | Peers decide whether a hire adds to or lightens their load (F2, F9). JD because it scores the team requirement |
| C3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for context, "I" for contribution. The sentence you can stand on is "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say which part of that was yours and which was shared, in your own words; if you cannot separate them, say so plainly and describe what you can | A standard peer probe on shared work; your CV's one team-scale story is the likeliest anchor (F9) |
| C4 | "Tell us about the after-school reading club. How does it connect to what happens in your classroom?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Tell the club at its scope: "I've run the after-school reading club for the last two years." Answer slot: if the club and your classroom were connected, say how, in your own words; if they were separate, say so plainly and stay with the club | The club is the second reading item on your CV, and peers will ask about the part nearest their own work (F3) |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader is one of our beliefs: no student leaves third grade without a reading plan. Tell us about a time a student was not becoming a reader and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Selection scaffold: pick one real student situation with a named stake, a decision of yours, and what happened next. Your club sentence, "I've run the after-school reading club for the last two years.", can frame it only if the story truly came from the club. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | The belief is the district's own wording, and F4 shows your material touches it without reaching it. VAL because it scores a published belief |
| D2 | "Families Are Partners is another of our beliefs. How do you work with families?" | VAL | [grounded] "I write a weekly email to families." | Tell it at its scope: "I write a weekly email to families." Answer slot: the belief says each teacher speaks with every family each term; if you also speak with families, say how and when, in your own words; if the email is the whole of it, say so plainly and stay with it | F5 is the row. Families are a listed panel topic as well as a belief, so this one is close to certain |
| D3 | "Teach for Tomorrow, Not for the Test: tell us about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: pick a real moment where results led you to change course, with what you saw, what you changed and what followed. Your material has no sentence for this, so none is supplied. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would use assessment to inform teaching | The belief is published and F6 is silent, so this is the most exposed of the three. VAL because it scores a published belief |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about yourself and what brought you to this job." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc in your own words, built only from those sentences in order: the license, the six years in Joliet, the curriculum move, the club, the email. Then one sentence of your own on why this job, which this pack cannot supply | The opener is always asked, and the arc is what A2 and D2 later lean on (F1 to F5). EXP because it asks you to account for your career |
| E2 | "What are you reading with your students these days, or reading yourself?" | JD | [generic] | Name a real book you actually read recently, and say in a sentence why it stayed with you. Do not name one you have not read. If nothing comes to mind, say so plainly and name the last one that did | A casual question on the district's lead topic still counts (F3). Generic because it asks for your own current reading |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You led your grade level's move to a new reading curriculum. Which decisions were yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold what the sentence carries: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if particular decisions were yours, say which and how you made them; if the curriculum was chosen by others, or "led" covered less, say so plainly and stay with the move. Same answer as A3 | The CV has no figures to defend, so the probe lands on what "led" covers (F3) |
| G2 | "How do you decide whether a reading curriculum is serving your students?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer in your own judgment first: what you would look at and why. Then, at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you checked anything after the move, say what, in your own words; if nothing was checked, or that was not yours, say so plainly and say what you would look at | Ties F3 to the published belief on assessment (F6); JD because it scores the role's reading work |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license | A4, E1 |
| F2 fourth-grade role | A1, A2, C2 |
| F3 reading instruction | B1, B4, C4, G1, G2, E2 |
| F4 reading plans | D1 |
| F5 family partnership | D2, B2 |
| F6 assessment informs teaching | D3, G2 |
| F7 classroom routines | B3 |
| F8 subjects | A5 |
| F9 grade-level team | A3, C1, C2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You were a reading specialist before becoming principal, and your 2025 talk covered weekly reading conferences in grades 3 to 5. What does a strong fourth-grade reading conference look like at Halvering?" | Tied to the principal's own path (public footprint), and it turns a probe on your reading work into a conversation in her field |
| R2 | "The board's literacy plan brings a new grades 3 to 5 curriculum in fall 2027. What would the fourth-grade team most want from a new teacher as that comes in?" | Shows you read the district's current direction, and it asks the team what they need rather than telling them |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two peers; it asks about their load, not yours |
| R4 | "What does support look like for a teacher who is new to a grade?" | Meets the gap in your own material openly and asks how the school handles it |
| R5 | "Families Are Partners says each teacher speaks with every family each term. What does that look like in a fourth-grade year?" | Uses the district's own wording and shows you read it |
| R6 | "What would a strong first term look like to you?" | Gives the panel a chance to name what they will measure, and gives you something to aim at |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | The plain acknowledgment F2 gives: "I've never taught fourth grade." |
| Has been a team lead | A negative you stated, F9 | The plain acknowledgment F9 gives: "I've never been a team lead." |
| Led the school's or the district's reading curriculum | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says a grade level's move. The slot in A3 and G1 stays inside the move |
| Speaks with every family each term | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says an email. D2's slot asks only what else you did |

## Sources

Provided: the invite from Orrinsford Community School District Human Resources, and your résumé text. Nothing else was provided. The résumé's government-issued identifiers were not used in any search or in this pack.

Searches sent:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford fourth grade teacher interview" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Dolores Vantongeren principal Halvering Elementary" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Orrinsford Community School District strategic plan 2026 news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "fourth grade teacher job description elementary school Illinois responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: the mission and beliefs page, and the "How we hire teachers" page.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three published beliefs by name; the D bank and rows F4 to F6 |
| 2. `{company} interview process {role family}` | yes | Loop structure: one 45-minute panel, the topics it covers; persona weights and rows F3, F7 |
| 3. `{company} strategy` / recent news | yes | The 2026–2029 literacy plan, read from the search result only; question B4 and R2 |
| 4. `{interviewer name} {company}` | yes | The principal's public footprint, read from the search result only; the interviewer read and R1. The two team members are unnamed, so no query could be formed for them |
| 5. representative `{role title}` JD | yes | Rows F8 and F9, both `[inferred]`; the posting text came from a search result snippet and may be cut short |

## Upgrade menu

- The posting's own text → F8 and F9 become `[grounded]`, and any requirement the representative posting missed gets a JD-tagged question
- Anything HR said about preparing, such as a demo lesson or a writing sample → a build section for each declared deliverable
- The names of the two fourth-grade teachers → a public-footprint read for each, and persona weights per panel member
- The state's record of your license, as the licensing office shows it → F1 can move from `medium` to `high`
- Your own answers to the slots in F4, F5, F6, F7 and F8 → those rows and the questions on them upgrade from slots to story-mapped answers
- Deeper research (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the district's literacy plan and recent context, plus loop reports for teacher panels; offered once
- A `tuesday-dossier.md` → verified evidence and strategy limits per weak area, so the next pack is built on confirmed claims
