# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

- **Role:** Remote Administrative Assistant
- **Company:** Brennock Facilities Ltd
- **Interviewer:** the office manager, name not given. The invite's own words: "a 30-minute video call with our office manager". Your relationship to them was not stated, so this pack assumes the office manager is the person you would work to day to day, which weights it as a hiring-manager round
- **Loop:** one session. Your invite describes a single 30-minute video call, so persona weights rest on that and not on an archetype

## 1. How to use this pack

- **Personas are how a question arrives; types are what it scores.** Each bank is one persona's style. Each question carries one type tag.
- **Type key:**
  - EXP: your own experience, and whether it survives follow-up questions
  - JD: a duty or requirement the ad states
  - CO: what you know about the company
  - CASE: a live problem from the role, answered by structuring it
  - VAL: past behaviour against published company values. This pack has no VAL questions, because no values round was documented and no company values page could be read
- **Guidance is scaffolding, not a script.** Say it in your own words. Wherever the guidance says answer slot, it is an instruction for the interview and not a question to me: answer from what you actually did, or say plainly that the thing was not yours or never existed.
- **Provenance:** `[grounded]` rests on what you or the ad told me, `[inferred]` is my derivation, named, and `[generic]` is a pattern for the role with no claim about this employer or about you.
- **The deepest rehearsal in this pack is B1**, the supplier-invoice question. It is the likeliest objection to your background and the highest-return prep.

## 2. Requirement coverage

| Requirement (source) | Questions that cover it |
|---|---|
| "managing calendars" — the ad, as you described it | A1, D2, D3, E2 |
| "booking travel" — the ad, as you described it | A3, A4 |
| "preparing documents in Word and Excel" — the ad, as you described it | A5, B2, B4, C3 |
| "processing supplier invoices" — the ad, as you described it | A2, B1, D1 |

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your sentence reaches the calendars duty in other terms, and its words stay as they are: "I ran the appointment book for four physios." Lead with the book, named as you named it, because a named record beats an adjective. It is a self-reported line with nothing inspected behind it, so expect a probe on it |
| F2 | "booking travel" — the ad, as you described it in your message | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the ad's booking-travel line makes a probe likely. If you have booked travel for anyone, at the clinic or anywhere else, say what and for whom, in your own words; if you have not, say so plainly and say how you would learn it |
| F3 | "preparing documents in Word and Excel" (the Word half) — the ad, as you described it in your message | "I'm good with Word" — your message | low | [inferred] | discovery | A self-rating, and the bridge is my derivation from it. Your words: "I'm good with Word." Answer slot: the ad's preparing-documents line makes a probe on what you have prepared likely. Name what, in your own words; if the answer is little or none, say so plainly |
| F4 | "preparing documents in Word and Excel" (the Excel half) — the ad, as you described it in your message | "okay with Excel" — your message | low | [inferred] | discovery | Your own rating is the limit, and it stays at its own scope: "I'm okay with Excel." Answer slot: if asked what you can do in it, say what you can do and nothing wider; if there are things you cannot do yet, name one and say how you would learn it |
| F5 | "processing supplier invoices" — the ad, as you described it in your message | "chased unpaid invoices" — your message; "two years as a receptionist at a physiotherapy clinic" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices at a clinic, not processing supplier invoices, and the words stay at the first: "At the physiotherapy clinic I chased unpaid invoices." Answer slot: if you did invoice work beyond chasing, say what it was, in your own words; if you did not, say so plainly and stay with the chasing |

## 4. Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | Small live problems taken from the ad's four duties: clashing calendar requests, a trip to book, a document to produce, an invoice that looks wrong | High. A manager-type interviewer is priced on whether you can do the listed job, and the invite and ad give four concrete duties to build problems from | Ask what you need to know first, then structure aloud: who it is for, what is fixed, what can move, who decides, what you record |
| Skeptic (bank B) | Quiet probing of where the ad's duties go past your material: invoices, Excel, booking travel, and why a remote role | High. F2, F4 and F5 are the rows where the ad asks for more than your material shows | Rehearse B1 until it is boring: hold what your sentence says, name the limit in the words your material gives you, add a plan and no claim |
| Conversational (bank C) | An easy opening about your journey, plus a casual question about what you know of the company | Medium. A 30-minute call usually opens with your background, and casual questions are still scored | A 90-second arc built only from your own sentences, and a short, true answer on what you found out about the company |
| Data-Driven Prober (bank D) | Line-by-line questions on the appointment book, the invoices and the figure four | Medium. Your background gives the interviewer few lines to work with, so each line gets pressed | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure (bank E) | A time-boxed challenge on why you, and how much of the book was you | Low. Nothing in the invite signals a stress style, and it is kept because a first challenge can come in any register | Pause, restate the question, hold what your sentence says through two follow-ups |

## 5. Question banks

### Bank A: Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three people each ask you for the same hour in their calendars on the same morning. What do you do?" | CASE | [generic] | Structure it aloud: what each meeting is for and who must be there, whether any of them can move, who decides if none can, how you tell all three what was decided, and what you update afterwards. The question needs no claim about your past, so the guidance makes none | The ad's calendars duty, set as a decision (F1's requirement). CASE because it scores structure, not history; `[generic]` because it is a pattern for the problem and not a fact about this employer |
| A2 | "A supplier invoice arrives for a different amount from what the office manager expected. What do you do?" | CASE | [generic] | Structure it: hold off processing it, find out what was agreed and who ordered it, say what the difference is, ask the office manager how it should be handled, and record what happened. Say you would ask how this firm does it before assuming. No claim about your past | The ad's supplier-invoices duty, set as a decision (F5's requirement). It lets you show judgement on the duty without claiming experience of it |
| A3 | "The office manager needs a trip booked at short notice and has not told you the budget. What do you do first?" | CASE | [generic] | Clarify before you structure: who is travelling, dates, any fixed times, the budget or who approves it. Then options, a recommendation, and confirming before you book. No claim about your past | The ad's booking-travel duty (F2's requirement). Asking before acting is what this question scores |
| A4 | "Tell me about a time you arranged a trip, an event or a journey for someone else." | JD | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick any occasion, at work or not, where you arranged something for another person. It needs who it was for, what had to fit together, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or how you would set about booking a trip you had never booked | F2 has no evidence, so this is a scaffold and not a story map. JD because it scores the stated duty |
| A5 | "We would hand you rough notes and ask for a clean one-page document in Word. How would you set about it?" | CASE | [generic] | Say it as a plan: ask who it is for and what it is for, confirm what must be in it, draft, check against the notes, and send it with a line saying what you assumed. No claim about your past | The ad's documents duty as a live task (F3's requirement). It tests process without resting on a self-rating |

### Bank B: Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "At the clinic you chased unpaid invoices. This role is processing supplier invoices. How much of that have you done?" | JD | [grounded] "chased unpaid invoices" | **Highest-ROI rehearsal in this pack.** Hold only what the sentence carries: "At the physiotherapy clinic I chased unpaid invoices." Answer slot: if you did invoice work beyond chasing, say what it was, in your own words; if you did not, say so plainly and stay with the chasing. Follow-up 1 is likely "What did chasing involve?": answer from what you did, in your words, and nothing wider. Follow-up 2 is likely "What would you need to learn here?": answer as a plan, asking how this firm handles supplier invoices and what you would learn first, and describe no process as something you did. Hold through both, and concede the limit once, plainly, without apologising | F5 is the widest gap between what the ad asks and what your sentence carries, so this objection arrives in some form. JD because it scores a stated duty; the Skeptic delivery is why it sits here |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Pick the part you are honestly weakest at and say it in your own words, in under a minute. Your own rating of Excel is "okay with Excel", so if Excel is it, say that, then give a plan: what you would ask for and practise first. The plan is what you would do, said as a plan, and never as something already done | F4 is a low-confidence self-rating, and this question exists to find it. JD because it tests the requirement list against you |
| B3 | "Why a remote admin role after reception work at a clinic?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Start from the sentence: "I've spent two years as a receptionist at a physiotherapy clinic." Answer slot: your reasons for this move are yours, and this pack supplies none. Give them in your own words, in two or three sentences | A motivation-consistency probe is the Skeptic's standard opening. EXP because it tests whether your story holds together. F5's context is where it starts |
| B4 | "You say you are okay with Excel. Where does that stop, and what can you do in it today?" | JD | [grounded] "okay with Excel" | Say what you can do in it, small and true, in your own words. Answer slot: if there are things you cannot do yet, name one and say how you would learn it; if asked about a specific feature, say plainly whether you have used it. Never describe a skill you have not used | F4 is a self-rating the interviewer can test in one question. JD because Excel is in the stated duty |
| B5 | "This job is remote. Tell me about a time you worked on your own without someone checking in." | JD | [grounded] | Selection scaffold: pick a stretch at work where nobody was watching, with a named piece of work, what you did when you were unsure, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set up a remote working day | The title says Remote, and nothing in your material speaks to working alone, so the guidance rests on no sentence of yours. JD because it scores a condition of the stated role |

### Bank C: Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" | A 90-second arc in this order: the two years as a receptionist at a physiotherapy clinic, then running the appointment book for four physios, then chasing unpaid invoices, each in the sentence's own scope. Answer slot: why this role, now, is yours to say, in one or two sentences | The biography question is nearly certain in a short call, and a casual register is still scored. EXP because it checks your history holds together; the beats are F1 and F5 |
| C2 | "What do you know about what we do?" | CO | [generic] | Say only what you actually found out, from the company's own website or pages. If you found little, say so plainly and ask what the company would most like you to know. Do not fill the gap with a guess | Company research could not run for this pack, so this is a pattern and not a claim about the employer. CO because it scores homework |
| C3 | "Tell me about a document or spreadsheet you have put together that you were pleased with." | JD | [grounded] "I'm good with Word"; "okay with Excel" | Selection scaffold: pick one real thing you made, with who it was for, what it had to do, and what you would change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: your own ratings, "I'm good with Word" and "okay with Excel", or how you would set about one | F3 and F4 are thin, and a casual question is an easy way for the interviewer to reach them. JD because the ad names the duty |

### Bank D: Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you chased an unpaid invoice from start to finish." | EXP | [grounded] "chased unpaid invoices" | Say what you chased and for whom, in the sentence's terms. Answer slot: if there were steps you followed, say them in your own words; if there was no set process, or it was not yours, say so plainly and describe how you went about it. Never describe a step you did not take | F5's quote is the only invoice evidence, so the prober presses on it. EXP because it checks what was actually yours |
| D2 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Tell it in your own words with the beats the sentence states: the book, and the four physios. Answer slot: if asked how it was kept, or what happened when something changed, answer from what you did; if a part of it was not yours, say so plainly and return to the book you ran | F1 is the likeliest line to be pressed on a CV-style claim. EXP because it tests attribution |
| D3 | "When you say four physios, how many were you covering at any one time, and for how long?" | EXP | [grounded] "I ran the appointment book for four physios" | Defend the number in your own words: how the four was counted, what it depends on, which part of it was yours, and the assumption behind it you would defend least. If you do not know how it was counted, say so plainly. Name no method you did not use | The figure four is the one number in your material, and probers go to numbers. EXP because it tests the claim in F1 |

### Bank E: Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone with more office experience?" | EXP | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices" | Pause, restate it, then hold on what the sentences carry: you ran the appointment book for four physios, and you chased unpaid invoices. Concede once, plainly, that others may have more office experience. Answer slot: what else you bring is yours to say in your own words; this pack supplies none | The Pressure stem. EXP because it tests whether you can hold a position on what you actually did. F1 and F5 are the two rows it draws on |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold on the sentence: "I ran the appointment book for four physios." Answer slot: if anyone else shared it or covered it, say so plainly and say which part was yours; if it was all yours, say that and stop. Hold through two follow-ups by returning to the book, never by adding to it | Attribution is what the Pressure stem probes. EXP because it scores honesty about your own share; F1 is the line |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you are thinking about delivering, and the answer tells you what to practise before you start |
| R2 | "Of the four duties in the ad, calendars, travel, documents and invoices, which takes most of the week?" | It tells you where to focus your preparation, and it shows you read the ad closely |
| R3 | "Whose calendars would I be managing, and how many people is that?" | It scopes the duty F1 speaks to, and it lets you size it against the four physios you have run a book for |
| R4 | "Which tools would I use day to day for email, calendars, documents and invoices?" | It lets you plan what to practise, and it is an honest way to bring up the Excel level you have named |
| R5 | "How does the team stay in touch day to day when the role is remote?" | A remote role is judged on how well you work without being watched, and this shows you have thought about that |
| R6 | "What does handling a supplier invoice involve here, from arrival to being filed?" | It shows you want to learn the firm's way and not assume yours, which answers the gap F5 shows |
| R7 | "What are the next steps after this call, and when should I expect to hear?" | It is a practical close, and it lets you plan your time around the process |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices, or ran accounts payable | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation and not words for you: your material says chasing unpaid invoices at a clinic, not processing supplier invoices. B1's slot stays inside the chasing |
| Managed calendars for a team, or managed executives' diaries | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios". D2's slot stays inside the book |
| Advanced or expert Excel | Contradicted by F4's own quote | "okay with Excel" |
| Expert or advanced Word | Inflated form of F3 | "I'm good with Word", at its own scope. B2 and C3 stay inside that rating |

## 8. Sources

- **Provided documents:** your message, which held the invite's text, your account of the ad's duties, and your background. Nothing else was provided.
- **Searches sent, all refused:** "Brennock Facilities Ltd values", "Brennock Facilities Ltd interview process administrative assistant", "Brennock Facilities Ltd Ireland company news". The host did not grant search permission, so no result came back and nothing from the web is used anywhere in this pack. Every company-facing question is therefore `[generic]`.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Search refused. It would have given the published value names for VAL questions and the values cheat sheet, if a values round was documented |
| 2. Company interview process | unavailable | Search refused. Your invite's own words already fix the loop as one 30-minute video call with the office manager, so the persona weights stand, but the company's own loop description could have confirmed or changed them |
| 3. Company strategy and recent news | unavailable | Search refused. It would have grounded C2 in current facts about the company; as it is, C2 is `[generic]` |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative role JD | skipped | Your account of the ad's four duties fixes the fit snapshot rows and the JD-tagged questions |

## 9. Upgrade menu

- The full text of the ad → the four requirement rows now rest on your description of it, and the ad's own wording would make them `[grounded]` on its exact lines and may surface requirements your summary left out, such as hours or location terms
- Your CV, or a few more lines on your Word and Excel use and on any travel or invoice work → F2, F3 and F4 could move from `none` or `low`, and F5 from `transferability`, where your own sentences support it
- Who the office manager is to you, a line manager or a peer → persona weights are recomputed and the banks reweighted
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- The company's own pages pasted in, or search permission granted → C2 becomes grounded in what the company says about itself and the company-facing questions stop being `[generic]`
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, needs search permission and is run only if you say so
- A `tuesday-dossier.md` → verified evidence, strategy limits for each weak area and a ready-made prohibited-claims list would arrive instead of being inferred here; the pack does not need one
