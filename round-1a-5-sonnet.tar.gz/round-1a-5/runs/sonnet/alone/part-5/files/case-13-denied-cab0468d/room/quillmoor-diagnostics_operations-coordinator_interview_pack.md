# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, a 30-minute phone call with Hannah Lowther (Talent Partner), who will ring the mobile number on your application.
**Her agenda, in her words:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."
**Candidate:** Sam.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Every question carries both.
- **Types:** VAL is behaviour against the company's published values. EXP is work-experience deep-dive. JD is a stated advert requirement. CO is company and strategy knowledge. CASE is a live problem.
- This pack has no VAL or CO questions. Research on Quillmoor's values and strategy did not run (see Sources), and a recruiter screen rarely scores either.
- **Guidance is scaffolding, not a script.** Where a cell says "answer slot", it is an instruction for the interview: answer from what actually happened, or say plainly that it did not happen or was not yours.
- **Highest-ROI prep: B2** (the SAP question). It is the likeliest probe aimed at where your material is thinnest, and it is the one you have already told me about. Rehearse it until it is boring.
- A recruiter screen is scored even when it feels casual. Rows A1 to A4 are the four items Hannah named.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | transferability | Delivery scheduling across three depots is adjacent work, and the words stay at that scope: "I schedule deliveries for our three depots." Your material says delivery scheduling, not production scheduling, and does not say whether any of it involved planning, warehouse or QA teams. Answer slot: if it did, say who and what you did; if there was no such step, or it was not yours, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | presentation | The chasing half is already in your sentence; use its own terms: you chase suppliers when orders slip. Your material does not say how deliveries are tracked. Answer slot: if you track them, say how, in your own words; if there is no such tracking, or it is not yours, say so plainly and stay with the chasing |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | transferability | Your sentence is a rebuilt stock-count spreadsheet and a fall in discrepancies, and the words stay there: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Your material does not say the stock records themselves were yours to keep. The figure invites a probe (C1 and C2) |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you report on deliveries, say what, to whom and how often; if there is no such report, or it is not yours, say so plainly and say how you would approach building one |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap on length. Say it in those words. It is a stated figure with nothing inspected behind it, so expect a probe on the role |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says spreadsheet and does not say which program. Answer slot: say which tool it is built in; if it is Excel, say what you did in it, naming only what you actually used; if it is something else, say so plainly and say what you have worked in |
| F7 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. Never a claim to SAP work, and nothing added to make the gap feel smaller |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your sentence says your company runs its own in-house stock system. It does not say what you do in it or whether it counts as similar. Answer slot: if you work in it, say what you do there, in your own words; if you do not, or it is not something you can compare, say so plainly and stay with "I haven't used SAP." |
| F9 | "£38,000–£44,000" — advert; "your salary expectations" — Hannah's message | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advert's band. Say it as you gave it: "I'm hoping for £42,000." Nothing is added to it |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Say it as you gave it. The advert says two days; your words are fine with two and put a limit at three as a preference ("wouldn't want more than three"). Keep that wording, neither hardening it into a rule nor softening it |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Your material does not carry your notice period. Answer slot: give your actual notice period, in your own words; the pack supplies none |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it as you gave it. It is your own account of your circumstances, so expect it to be taken at face value and not probed further. Keep to those facts each time it comes up |

## Persona table

The loop is one session, established by Hannah's own message: a 30-minute phone call with her.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly agenda of pay, notice, hybrid and reasons for moving, then a background walk-through | Highest. A recruiter screen's prior is conversational with light skeptic, and Hannah listed four logistics items herself | Know your own words for each item so a casual question gets a settled answer; give a 90-second arc for the biography question |
| B. Skeptic | Quiet box-checking against the advert: production scheduling, SAP, Excel, weekly reporting | High. The advert names ERP and Excel, and F7 is a stated gap. A screen is where gaps are probed cheaply | Rehearse B2 until boring; give the plain words for a stated gap, and a slot answer where the material is silent |
| C. Data-Driven Prober | Asks how the one-third figure was counted | Medium. Recruiters seldom dig into a figure, but it is the one number on your page | Know what you can and cannot say about how it was counted, and say plainly where you do not know |
| D. Case / Strategist | A quick scenario on a late supplier or stock mismatch | Low. A recruiter screen rarely runs cases, but the advert's lines make them cheap to ask | Clarify, then structure, then say what you would report; claim nothing about the past |
| E. Pressure | "Sixty seconds: why you?" or a challenge on the wholesale-to-manufacturing step | Low to medium. A time-boxed ask is common in screens; sustained pressure is not | Pause, restate, hold on your quoted words through two follow-ups, concede specifically |
| F. Values / Behavioral | "Tell me about a time" prompts themed on the advert | Low. No published values were read, so any behavioral prompt would be themed on the advert only | Pick a real instance; if none comes to mind, say so |

Peer Evaluator is left out: this is a one-person screen with no peer in the room.

## Question banks

### A. Conversational / Rapport Builder (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot: say your figure in your own words, as you gave it: "I'm hoping for £42,000." Then stop. If asked what you earn now, you can decline with no figure: "I'd rather focus on the range for this role." | F9 is the row. Hannah named salary first; JD because it scores the advert's stated band |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. This pack does not know it and supplies none | F11. Hannah named it second; JD because it scores the job's terms |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot: say it as you gave it: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If asked about the commute or the pattern again, your own words were that sentence, so return to it | F10. Hannah named the hybrid pattern third; JD because the advert states two days at Avonmouth |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot: say it in your own words, keeping to those facts: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If it comes up again, return to the same words | F12. Hannah named it fourth. EXP because it tests whether your reason holds together across the call |
| A5 | "So, walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped in three beats, each one a clause of those sentences: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling about a third over a year. Tell it in your own words in about 90 seconds and add no beat beyond these | F5, F2 and F3 are the evidence. EXP because the casual opener still tests what you actually did |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. How does your background fit that?" | JD | [inferred] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold at the sentence's scope: "I schedule deliveries for our three depots." Your material says delivery scheduling, not production scheduling, so do not describe production work. Answer slot: if any of that scheduling involved other teams, say which and what you did; if there was no such step, or it was not yours, say so plainly and stay with the depots. Then say, as a plan, what you would ask first about how those three teams work together | F1 is the adjacent-but-not-matching row. JD because it scores the advert's first responsibility |
| B2 | "Have you worked with SAP or a similar ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **The highest-ROI rehearsal in this pack.** Start with the plain words your own sentence supports: "I haven't used SAP." Answer slot: if you work in your company's in-house stock system, say what you do there, in your own words; if you do not, or it is not something you can compare, say so plainly. Hold through two follow-ups by returning to those words, never adding to them. Then say, as a plan and not a past, how you would learn the system | F7 and F8. The advert marks ERP as "a plus", but you have said you have not used SAP, so a recruiter checking boxes is likely to ask. JD because it scores a stated requirement |
| B3 | "The role reports weekly on on-time dispatch. Is that something you've done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you report on deliveries, say what, to whom and how often; if there is no such report, or it was not yours, say so plainly. Your sentence carries scheduling and chasing, not reporting, so do not stretch it | F4 is silent in your material. JD because it scores a listed duty |
| B4 | "How confident are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Your sentence says spreadsheet and not which program. Answer slot: say which tool it is built in; if it is Excel, say what you did in it, naming only what you actually used; if it is something else, say so plainly and say what you have worked in | F6. JD because the advert lists it as a requirement |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that one-third drop in discrepancies was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep your own "about a third over a year." Answer slots, in your own words: how it was counted, what it is sensitive to, and the assumption behind it you would defend least. If you do not know how it was counted, say so plainly | F3 is your one headline figure and the likeliest target. EXP because it tests whether the number survives |
| C2 | "How much of that was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold on the verb you used: "I rebuilt our stock-count spreadsheet." Answer slot: say which part of the fall was yours; if part of it was not, or you cannot separate it, say so plainly | F3. EXP because it tests attribution |
| C3 | "What did you change when you rebuilt it?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say what you changed, in your own words; if you cannot recall some of it, or it was not all yours, say so plainly and stay with "I rebuilt our stock-count spreadsheet." Name nothing you did not change | F3 and F6. EXP because it checks the claim against detail |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery is four days late, and production is scheduled around it. What do you do first?" | CASE | [generic] | Structure it: what you would ask first (which orders and schedules are hit, how firm the new date is); who needs to know and when; what options you would put forward; what you would record. The question needs no claim about your past, so the guidance makes none | The advert's "track supplier deliveries and chase late orders" line (F2's requirement), asked as a decision. [generic] because it is a pattern, not a fact about Quillmoor |
| D2 | "The stock record says 120 units but QA says the warehouse holds fewer. How do you find out why?" | CASE | [generic] | Structure it: what you would ask first (who counted, when, what moved since); how you would reconcile; how you would correct the record and note the change; what you would check so it does not recur. No claim about your past | From the advert's "keep stock records accurate" (F3's requirement) |
| D3 | "Last week's on-time dispatch figure fell. What do you look at?" | CASE | [generic] | Structure it: how the measure is defined, what period and which orders, where the drop sits, what you would report and to whom. No claim about your past | From the advert's weekly reporting line (F4's requirement) |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we take you forward?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. Use only those two sentences' beats: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip. Hold through two follow-ups; if SAP comes up, concede specifically with "I haven't used SAP" and do not fold on the rest | F5 and F2. JD because it scores fit against the advert; Pressure delivery is a time-box |
| E2 | "You'd be moving from wholesale to manufacturing. Isn't that a big step?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Concede what is true: the advert is for a diagnostic-test manufacturer and your sentence is a building-supplies wholesaler. Hold on that sentence. Answer slot: if you have worked alongside any manufacturing or QA, say what; if not, say so plainly and stay with the wholesaler role | F5 and F1. JD because the premise comes from the advert |

### F. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time an order ran late and you had to chase it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on one beat the sentence states: you chase suppliers when orders slip. Choose one real instance yourself, saying what was late, who you chased and what happened, in your own words; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2. EXP because it asks for an instance. The theme is the advert's "chase late orders" |
| F2 | "Tell me about a time you worked with a team outside logistics." | EXP | [generic] | Selection scaffold: pick a time with a named team, a specific request or disagreement, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is the advert's "between planning, the warehouse and QA" line (F1's requirement) |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B1, D1, E2, F2 |
| "track supplier deliveries and chase late orders" | D1, F1 |
| "keep stock records accurate" | C1, C2, C3, D2 |
| "report weekly on on-time dispatch" | B3, D3 |
| "2+ years in operations or logistics coordination" | A5, E1 |
| "confident with Excel" | B4, C3 |
| "ERP experience (SAP or similar) a plus" | B2 |
| "£38,000–£44,000" | A1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A3 |
| "your notice period" (Hannah) | A2 |
| "what's prompting a move" (Hannah) | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first three months look like for the person in this role?" | Turns the call toward the job and gives you something concrete to hold against the advert |
| R2 | "Which systems does the team use day to day for stock and supplier tracking, and is training given on them?" | Ties to the advert's ERP line (F7 and F8) and puts the SAP gap into a practical conversation |
| R3 | "How is on-time dispatch reported today, and who reads the weekly report?" | Comes from the advert's reporting line (F4) and shows you read the duties, not just the title |
| R4 | "How do planning, the warehouse and QA work together on schedules now, and where does it get tight?" | Comes from the advert's first responsibility (F1) and shows interest in the job's hardest part |
| R5 | "Are the two Avonmouth days fixed days, and who sets them?" | Follows the advert's hybrid line (F10), so you can tell whether the pattern fits what you told Hannah |
| R6 | "Who would I report to, and how big is the team?" | A standard screen question that gives you facts to weigh against the advert |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F7 | The plain acknowledgment your sentence gives: "I haven't used SAP." No slot on SAP itself |
| Has ERP experience from the in-house stock system | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material says the company runs one, not what you do in it. B2's slot stays inside that |
| Coordinated production schedules | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." Your material says delivery scheduling, not production scheduling |
| Confident with Excel | Inflated form of F6 | F6's quote at its own scope: a stock-count spreadsheet. Your material does not say which program |
| Kept the stock records accurate | Inflated form of F3 | F3's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Your material does not say the stock records were yours to keep |
| Cut discrepancies by a third as a result of the rebuild | Inflated form of F3 | F3's quote, including "about a third over a year" |

## Sources

**Provided documents:** Hannah Lowther's LinkedIn message as you pasted it; the advert as you pasted it; your own description of your background and what you would tell her.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Search refused. Would have moved: a values cheat sheet and VAL questions, if a values-style round existed |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Search refused. Would have moved: later-round structure and persona weights beyond this screen. This session's loop is fixed by Hannah's own message, so the persona weights stand |
| 3. `Quillmoor Diagnostics Avonmouth Bristol news` | unavailable | Search refused. Would have moved: a CO question grounded in recent company news |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Search refused. Would have moved: an interviewer read and a reverse question tied to her path |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

Searches sent, by query:

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics Avonmouth Bristol news` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

No dossier was consumed.

## Upgrade menu

- Your actual notice period → F11, and A2 becomes your own words instead of an instruction
- Whether you work in your company's in-house stock system day to day, and what you do there → F8 and B2's slot become a quoted row
- Which program the stock-count spreadsheet is built in → F6 and B4 become a quoted row
- Whether you report on deliveries now, and how often → F4 and B3 become a quoted row
- How the one-third figure was counted → C1 and C2's slots become your own quoted words
- Search access for Quillmoor's values, news and process → a values cheat sheet if a values-style round is documented, a CO question, and a persona re-read
- Hannah's LinkedIn profile text, pasted → an interviewer read and a reverse question tied to her own path
- A fuller job description from Hannah → more `[grounded]` requirement rows than the advert gives
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) once search access is granted → a grounding brief on Quillmoor's strategy and recent moves
- A `tuesday-dossier.md` from job-underwriter → verified evidence, allowed strategies per weak area and a ready list of risks, so the SAP and production-scheduling rows start from graded evidence
