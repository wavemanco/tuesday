# Interview prep pack: Customer Support Specialist, Lumenvale Software

Role: Customer Support Specialist (remote). Company: Lumenvale Software. Interviewer: the support team lead (no name given). Relationship: treated as a hiring-manager round, built on your description of one text-chat interview with the support team lead. Persona weights rest on relationship priors, because no loop source beyond your own description was available.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for your own words, not a script: say only what you actually did, and where a cell says "answer slot", answer from your own experience or say plainly that it was not yours.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims in your background survive questions |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its strategy |
| CASE | A live problem from the role, reasoned out loud |

This pack has no CO questions and no values cheat sheet: company research was refused in this session (see Sources), and nothing in your message names a values round.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you listed it in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a sentence from your message with nothing inspected behind it, so expect a probe on it. Say the title as you gave it and let the interviewer judge how it maps to the ad's wording; do not relabel your job in the ad's vocabulary |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you listed it in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap, but name the tool you use: "I use Freshdesk every day." The quote says Freshdesk, so the words stay with Freshdesk |
| F3 | "clear written communication" — the job ad, as you listed it in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written, and the quote does not show how your replies were received. Answer slot: the ad's written-communication line makes a probe on your emails likely, and this interview is itself a text sample. If anything showed how your written replies were received, say what it was, in your own words; if nothing did, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — the job ad, as you listed it in your message | none given | none | [grounded] | discovery | Your material does not show whether escalations were part of your work, and silence is not absence. Answer slot: the ad's escalations line makes a probe likely. If calls or emails were ever passed on by you or to you, say what happened and what part was yours, in your own words; if that was not part of your work, say so plainly and stay with the calls and emails you answered |
| F5 | Working for a software company, role-family context from no line of the ad, so plain prose | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. "I use Freshdesk every day" stays at its own scope, a tool you use |
| F6 | Helping colleagues learn a process, role-family context from no line of the ad, so plain prose | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap against this context. Use the quote's own verb, trained, and keep the number attached to the new starters |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 2+ years | D1, D3, E1 |
| F2 ticketing tool | B4, D1 |
| F3 clear written communication | A1, A3, D2 |
| F4 escalations | A2, A4, B3, E2 |
| F5 no software-company background | B1, B2, B5, E1 |
| F6 training | C2, C3, D1 |
| The 60 a day figure | C1, D3 |
| Company and strategy (CO) | none, because company research was refused |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case / Strategist (5 questions) | Live support scenarios you answer by typing | Highest: the hiring-manager prior is Case plus Skeptic, and your invite describes a text chat, so a typed reply to a scenario is a natural test | Clarify first, then structure, then type the reply; see A1 to A5 |
| B Skeptic (5 questions) | Quiet probing of the gaps | Highest: the prior above, and F5 is a gap you stated yourself | Rehearse B1 until it is boring; hold the quotes, concede the limit |
| C Data-Driven Prober (3) | Asks how the numbers were counted | Medium: your message holds two figures, F3's and F6's | Know what you can and cannot say about each figure; say plainly if you do not know |
| D Conversational (3) | Friendly openers that are still scored | Medium: chat interviews usually open with a biography question, so D1 is worth a 90-second arc | Rehearse D1; treat casual questions as scored |
| E Pressure (2) | Time-boxed challenges | Low to medium: no interviewer profile, so no signal either way | Pause, restate the question, hold through two follow-ups |
| F Values / Behavioural (1) | Behavioural prompts | Low: nothing names a values round | One scaffold is enough |

A Peer persona is dropped: a team lead is not a peer relationship.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in to say they were charged twice this month and that they will cancel unless it is sorted today. Talk me through your first reply." | CASE | [generic] | Say it aloud in order: say sorry once and plainly, say what you need from them to look into the charge, say what you will do next and when you will come back, and do not promise a refund before it is checked. Then type the first message in full, in your own words. The question needs no claim about your past, so the guidance makes none | A live problem built from F3's requirement, asked as a draft rather than a record. CASE because it asks for a decision and a reply; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "Lots of customers write in at once about the same thing and you do not yet know the cause. What do you do first?" | CASE | [generic] | Clarify before structuring: ask where you would flag it and who owns updates, rather than assuming a channel. Then: check the messages really are the same issue, tell customers honestly that it is being looked at without guessing a cause or a fix time, and keep notes tidy so the next person can see the pattern. No claim about your past | Tests the judgement F4's requirement points at, as a decision. CASE because it is live; generic for the reason in A1 |
| A3 | "Here is a message from a customer: 'Your app is useless, nothing works, fix it now.' Write me your reply." | JD | [generic] | Acknowledge the frustration in one sentence, ask the one or two things you need to look into it, say what happens next. Type it in your own words, short, and read it back before sending, because this reply is also a sample of your written communication. No claim about your past | Scores F3's requirement directly. JD content with CASE delivery |
| A4 | "When would you pass a ticket to someone else, and what would you write so they do not have to ask the customer everything again?" | JD | [generic] | Give your own criteria aloud, and ask what this team's handover looks like rather than assuming it. A handover note covers what the customer asked, what you already checked and what you told them. Answer slot: the ad's escalations line makes a probe on your own handovers likely. If calls or emails were ever passed on by you, say how, in your own words; if that was not part of your work, say so plainly and answer as how you would do it | F4's requirement; a slot because the material is silent on it |
| A5 | "A customer asks something you do not know the answer to. What do you tell them?" | CASE | [generic] | Say what you do know, say what you are checking and with whom, say when you will come back, and come back then. Do not guess to fill the gap. No claim about your past | Honesty under not-knowing, which B1's gap (F5) makes likely. CASE because it is a live problem |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company before. How would you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company" and "I use Freshdesk every day" | The highest-ROI prep in this pack: it is the one objection you stated yourself, and it will arrive in some form. Hold only what the quotes carry: "I haven't worked for a software company." Then "I use Freshdesk every day" at its own scope, a tool you use. Then the plan, said as a plan: how you would learn the product in your first weeks, in your own words, with steps you would actually take. Follow-up 1, "How would you explain technical things to customers?": hold by returning to the two quotes, and concede specifically, "I don't know your product yet." Follow-up 2, "What if a customer knows more about the product than you?": say so plainly, say you would find out and come back, as in A5. Never present a plan as something already done | F5 is the largest stated gap and the likeliest place to be probed. JD because it scores the role's fit including its gap |
| B2 | "What would be hardest for you in your first month?" | JD | [grounded] "I've never worked for a software company" | Name the limit in the quote's own words, "I haven't worked for a software company," then the first thing you would do about it, as a plan. Pick one real difficulty; do not invent one to sound modest | Calibrated candour, F5. JD because it asks about fit to the job |
| B3 | "The ad asks for confidence handling escalations. Tell me about a time you handled one." | JD | [generic] | An open prompt, and no quoted sentence of yours carries it, so this is a selection scaffold: pick a time a customer wanted someone more senior, or something had to be passed on. It needs a named stake, what you did and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is silent in your material, so the story has to be chosen by you. JD with EXP delivery |
| B4 | "Which ticketing tools have you used?" | JD | [grounded] "I use Freshdesk every day" | Say it as it stands: "I use Freshdesk every day." Answer slot: the ad's ticketing line makes a probe on other tools likely. If you have used any other ticketing tool, name it and say how much; if you have not, say so plainly and stay with Freshdesk | F2's requirement; the slot leaves room for there being no other tool |
| B5 | "What draws you to this role?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Answer slot: the reason is yours and this pack has none to give. Say your actual reason in your own words; if it is practical, say so plainly. Do not criticise your current or past employer, and do not claim an interest in the product that you do not have | Motivation consistency, from F1 and F5. EXP because it tests whether your story holds together |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around 60 calls and emails a day. How was that number counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say it as the quote has it. Answer slot, the four a figure raises: say how it was counted if you know, and if you do not know, say that plainly; say what it is sensitive to; name the assumption you would defend least, "around" being the obvious one, in your own words; and say which part of it was yours | A figure on the page is a prober's first target, F3. EXP because it tests attribution |
| C2 | "Tell me about the four people you trained." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Beats the quote states: four new starters, your refunds process, last year, told in your own words with the verb you used, trained. Answer slot: if you checked afterwards how they got on, say what you looked at; if nothing was checked, or checking was not yours, say so plainly and stay with the training | F6 is your one training sentence and a prober will want what is behind it. EXP |
| C3 | "Which part of that training was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence: "I trained four new starters on our refunds process last year." Answer slot: if anyone shared the training, say who and which part; if it was all yours, say so plainly. Do not widen it beyond what you said | Attribution probe on F6. EXP |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | A 90-second arc using only those three beats, in your own words and in that order. Answer slot: why this role is yours to give, and the pack has none; if the move was not planned, say so plainly. Do not fill the gaps between the beats with detail you could not repeat under a second question | A biography opener is near-certain in a chat interview; F1, F2 and F6 are its beats |
| D2 | "What does a good reply to a customer look like to you?" | JD | [generic] | Your own criteria, said in your own words and kept short. A shape to start from: the customer can see you understood the problem, knows what happens next, and does not have to write back to ask. The pack supplies the shape, not your content | Casual questions on hot JD topics are scored; F3's requirement. JD |
| D3 | "Talk me through a typical day on the desk." | EXP | [grounded] "answering around 60 calls and emails a day" | The beats the quote states: calls and emails, around 60 a day. Answer slot: anything else about the day is yours to say or to leave out; say only what happened, and if the day was mostly answering, say that | Easy to answer loosely; F1 and F3. EXP |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" and "I've never worked for a software company" | Pause and restate the question. Hold the first two quotes without comparing yourself to anyone. Through two follow-ups, return to them. Concede specifically: "I haven't worked for a software company." Do not fold on what you have, and do not invent an advantage | F1, F2 and F5 together are the pressure point. JD with a pressure delivery |
| E2 | "Tell me about a time a customer was angry with you." | JD | [generic] | An open prompt, and no quoted sentence of yours carries it, so a selection scaffold: pick a time with a named stake, what you said, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Pause before you answer | F4's requirement and the pressure persona's stem. JD |

### F. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | An open prompt from the persona's stem, so a selection scaffold: pick a decision with a named stake, what you chose, and what it cost or saved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values were published in the material, so this is a pattern question only. VAL |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first month look like for someone who has not worked at a software company before?" | It turns B1's gap into a plan you are already thinking about |
| R2 | "How does the team decide when something should be handed on, and to whom?" | It shows you take escalation seriously and tells you the real process, F4 |
| R3 | "What do the tickets that take longest to solve usually look like?" | It shows interest in the hard part of the job rather than the easy part |
| R4 | "How does the team keep written replies consistent and clear?" | It shows you care about F3's requirement from the team's side |
| R5 | "Which ticketing tool does the team use, and how is product knowledge shared?" | It tells you what to learn first and signals F2's tool question was not a surprise |
| R6 | "After this chat, is there a further step, such as a call or video?" | It tells you what else to prepare for |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having worked for a software company, or knowing the product | Negative you stated, F5 | "I've never worked for a software company" — your message. The plain acknowledgment: "I haven't worked for a software company." No slot |
| Having used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material says Freshdesk, not Zendesk. B4's slot stays with ticketing tools in general |
| Having resolved 60 tickets a day | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says answering, not resolving, and calls and emails, not tickets. C1's slot asks only how the figure was counted |
| Having led, managed or onboarded new starters | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says trained, on the refunds process, not that you ran a programme. C2 and C3 stay inside the training |

## Sources

Provided documents: your message, containing the invite text, the ad's requirements as you listed them, and your background. No job ad file and no CV were provided; no dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2. Every search was refused by the host, so nothing came back.

| # | Search | Outcome |
|---|---|---|
| 1 | Lumenvale Software company values | refused |
| 2 | Lumenvale Software Customer Support Specialist interview process | refused |
| 3 | Reports of recruitment scams run wholly through a chat app | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have fed a values cheat sheet and VAL questions; search was refused |
| 2. Interview process for the role family | unavailable | Would have fixed the loop; persona weights instead rest on your own description of one text chat with the support team lead |
| 3. Strategy and recent news | unavailable | Would have fed CO questions; not sent after the first two calls were refused |
| 4. Interviewer name | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative JD | skipped | The requirements you listed fix the fit snapshot and the JD questions |
| Un-numbered | unavailable | Search 3 was outside the declared targets and moved nothing |

## Upgrade menu

- The full text of the job ad: the four requirement rows F1 to F4 move from your summary of the ad to its own words, and any mid-list item the ad has gets a question
- Your CV: the evidence cells quote it, F3 and F4 may move off discovery, and D1 gets more beats
- Your own words on the slots in F3 (how your written replies were received) and F4 (escalations): those rows, A4 and B3 become story-mapped instead of scaffolds
- The support team lead's name, from a source you find yourself: an interviewer read from their public professional footprint, and a reverse question tied to their path
- Permission for web search: company values and process would feed VAL and CO questions, and a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available once if you want it
- A tuesday-dossier.md from an earlier engagement, if you have one: verified evidence and allowed strategies for the weak areas, never required
