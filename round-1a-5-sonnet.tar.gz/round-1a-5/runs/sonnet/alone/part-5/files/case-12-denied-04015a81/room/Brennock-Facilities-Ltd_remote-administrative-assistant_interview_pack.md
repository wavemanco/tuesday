# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager (name not given). Format as the invite describes it: one 30-minute video call. Built as a hiring-manager-style round, since an office manager is the likeliest person to be buying a day-to-day assistant.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores.
- Type key: **VAL** values alignment (not used here, no values round is detected). **EXP** work-experience deep-dive: do your claims survive follow-ups. **JD** role requirements: can you do the listed job, gaps included. **CO** company and strategy knowledge (none here, because research did not run). **CASE** a live problem from the actual job.
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", it names something the interviewer may probe that your material does not show. Answer from your real experience, or say plainly it was not yours or did not happen. Both are good answers.
- Highest-ROI prep in this pack: **B2**, the invoice question. Of the four duties in the ad, it is the one where your clinic work is nearest to the job's words without being the same thing, so it is the likeliest probe. Rehearse it until it is boring. Second: B3 and B4.

## Fit snapshot

Requirements are quoted from the ad as you described it in your message, so they are your summary's words, not the ad's own.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The appointment book is the nearest thing in your material to calendar work, and the words stay at the quote: "I ran the appointment book for four physios." The pack's observation: your material says the book, and shows nothing about calendars beyond it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show any travel booking. Answer slot: if you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and say how you would go about it |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word" — your message | medium | [grounded] | discovery | The quote is a skill level, not a list of documents. Say it as you said it: "I'm good with Word." Answer slot: expect a probe on what you have prepared in it. If you have a few kinds of document in mind, name them; if there are few, say so plainly |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | You rated Excel modestly, and the rating should stay modest. Say it as you said it: "I'm okay with Excel." Answer slot: expect a probe on what you have done in it. If you have used it for particular tasks, name them; if not, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your quote is chasing unpaid invoices. The pack's observation: it does not show which side of the money those invoices sat on, or any step beyond chasing. The words stay at the quote: "I chased unpaid invoices." Answer slot at B2 |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Small live problems: a double-booked slot, a trip to arrange, a mismatched invoice | High. In a 30-minute call with an office manager, practical what-would-you-do questions are the cheapest way to test an assistant. Weighted from the hiring-manager prior; the invite's own words give one session, no loop beyond it | Ask one clarifying question first, then say your steps in order. Rehearsed on A1 to A5. These ask nothing about your past |
| Skeptic | Quiet probing of what the clinic did not cover | High. Two of the four duties (travel, supplier invoices) and Excel are where your material is thinnest | Say what your quotes carry, then how you would learn the rest. Rehearsed on B1 to B5 |
| Conversational | Friendly opener, "walk me through your story", casual skill checks | Medium to high. An office manager rather than a technical specialist suggests a relaxed register, and casual questions are still scored | One 90-second arc built from your quoted sentences. Rehearsed on C1 to C4 |
| Data-Driven Prober | Pressing on what exactly was yours and how you tracked things | Medium. Your CV material is short, so each line gets pressed | Know what was yours alone, and say plainly when something was shared. Rehearsed on D1 to D3 |
| Pressure | A blunt "why you over someone experienced" | Low to medium. Possible in a short call; not signalled by anything you shared | Pause, hold the quoted position, concede specifically. Rehearsed on E1 and E2 |

Values and Peer personas are left out: no values round is detected, and the invite names no peer in the call.

## Question banks

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two colleagues both want the same Thursday 10am slot with the same person, and both say theirs is urgent. What do you do?" | CASE | [generic] | Structure it: first ask what the person being booked prefers or whether there is a priority rule; check whether either meeting can move or shorten; offer each a concrete alternative; confirm the outcome in writing to everyone; note the rule you used so the next clash is quicker. The question asks nothing about your past, so the guidance makes no claim about it | Live version of F1's calendar duty. CASE because it scores structure, not history |
| A2 | "Someone needs to be in Lisbon for a Tuesday 9am meeting and back for a Thursday afternoon event. How would you plan the booking?" | CASE | [generic] | Clarify first: budget or policy limit, preferred times, flexibility, who approves. Then outline: options within the limit, a short comparison, approval before booking, a written itinerary with times and confirmations. If travel booking is new to you, this structure is how you would learn it. No claim about your past is made | F2 is where the material is silent, and a structured answer is the strongest honest preparation. CASE because it is a live problem |
| A3 | "A supplier invoice arrives and the amount does not match what was ordered. What do you do?" | CASE | [generic] | Structure: do not approve it yet; check it against the order and any delivery record; ask the person who placed the order; query the supplier in writing if needed; log what you found and the outcome. Say you would follow the company's own procedure and ask what it is | F5's duty as a live problem; it lets you show careful handling without claiming invoice experience. CASE |
| A4 | "You pull together a monthly spreadsheet from three people's figures and the totals do not agree. How do you handle it" | CASE | [generic] | Structure: find where the totals differ before changing anything; ask the person who owns each figure; keep a note of what was corrected and why; never overwrite a number silently. Say what check you would run before sending. No past claim is made | F3 and F4's duty as a live problem; scores care and honesty about errors. CASE |
| A5 | "You inherit a shared calendar for three people and it is a mess. Where do you start" | CASE | [generic] | Structure: ask each person what matters most and what is fixed; list what is double-booked or unclear; fix the fixed items first; agree how requests will reach you. Close with how you would confirm the new order with each of them. No past claim is made | F1 again, this time as a start-up task for a remote assistant. CASE |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is a clinic front desk. Which part of this job will be newest to you on day one" | JD | [grounded] "I ran the appointment book for four physios"; "I'm good with Word, okay with Excel" | Name the newest parts from your own list. The pack's observation is that your material shows nothing on travel or supplier-side invoices, so those are the likeliest to be newest. Then say how you would close each: ask for a walkthrough, practise on a sample, check your first few pieces of work with the office manager. Anchor on what you have said: "I ran the appointment book for four physios." Answer slot: if any of these is less new to you than your material shows, say so in your own words | The standard skeptic opener, built on F1 to F5. JD because it scores honest self-assessment against the listed duties |
| B2 | "The job involves processing supplier invoices. What invoice work have you done" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if any other step of the invoicing was yours, say which and what you did, in your own words; if none was, or it was not yours, say so plainly and stay with the chasing you did. Hold through two follow-ups by returning to the chasing, never by adding to it. Then concede specifically and move to a plan: ask how their invoices flow, who approves, what checks they want, and offer to do a few with oversight first | F5 is where the ad's wording presses hardest on a thin match, so this objection arrives in some form. JD because it scores a stated duty |
| B3 | "Have you booked travel for anyone before" | JD | [grounded] | Answer slot: if you have, say what and for whom, in your own words; if you have not, say so plainly, then say how you would do it: ask for preferences and the budget limit, offer options, get approval before booking, send a written itinerary. Do not describe a booking you did not make | F2 is silent in your material, and a plain question gets a plain answer. JD |
| B4 | "How would you rate your Excel, and what have you used it for" | JD | [grounded] "okay with Excel" | Say it as you said it: "I'm okay with Excel." Answer slot: if you have used it for particular tasks, name them in your own words; if you have not used it for much, say so plainly and say what you would practise first. Do not rate yourself higher under pressure. Offer to do a short test task if they want one | F4's thin evidence, rehearsed so the honest answer is ready. JD |
| B5 | "Why a remote admin role, after working in a clinic" | EXP | [generic] | Answer slot: give your actual reason in your own words, and one real reason for this role in particular. The guidance supplies none. Keep it short and consistent with what you tell them elsewhere in the call | Motivation consistency is what skeptics score; EXP because it tests whether your story holds together |

### C. Conversational (weight: medium to high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. What led you here" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | A 90-second arc with three beats: the clinic, "two years as a receptionist at a physiotherapy clinic"; what you ran there, in the quoted words; what draws you to this role, in your own words. Stop there; do not add duties the quotes do not state | The biography question arrives in every call, however casual. EXP |
| C2 | "Tell me about running the appointment book for four physios" | EXP | [grounded] "I ran the appointment book for four physios" | Story beats are only the quote's: you ran it, for four physios. Tell it in your own words. Answer slot: expect a probe on how you handled changes or clashes. If you did, say how and what part was yours; if there were none, or it was not yours, say so plainly and stay with the book you ran | F1 is your best evidence for the calendar duty and the likeliest place for a follow-up. EXP |
| C3 | "What are you using Word and Excel for these days" | JD | [grounded] "I'm good with Word, okay with Excel" | Answer slot: say what you actually use each for, in your own words; if the use is light, say so plainly. Keep the quoted levels: "good with Word, okay with Excel" | A casual question on a listed duty is still scored. JD |
| C4 | "How do you feel about working at home on your own all day" | JD | [grounded] | Answer slot: if you have worked remotely before, say how it went; if not, say so plainly and describe how you would set up the day: fixed hours, a task list, regular check-ins. Do not claim remote experience you do not have | The role is remote, so working alone is a natural casual question. JD |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What part of the appointment book for four physios was yours alone" | EXP | [grounded] "I ran the appointment book for four physios" | Answer slot: say which parts were yours, in your own words; if others shared it, or some of it was not yours, say so plainly and return to "I ran the appointment book for four physios." Precise attribution is a credibility gain | Probers test attribution on every line. F1 supplies the line. EXP |
| D2 | "When you chased unpaid invoices, how did you keep track of which were outstanding" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you kept a list, system or routine, describe it in your own words; if there was no tracking of your own, or it was not yours, say so plainly and stay with "I chased unpaid invoices." Do not name a system or method you did not use | Probers go two levels deeper on any process claim. F5 is that claim. EXP |
| D3 | "How do you check a document or spreadsheet is right before it goes out" | JD | [generic] | Answer slot: describe your actual habit in your own words; if you have no fixed routine, say so plainly and say what you would start doing: a read-through, checking numbers against the source, a second look after a break | Accuracy is the quiet requirement of every listed duty. JD |

### E. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone with PA or finance experience" | JD | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices" | Hold-then-concede. Pause, then hold: "I ran the appointment book for four physios" and "I chased unpaid invoices." If pushed twice, concede specifically that your material does not show travel booking or supplier-side invoice work, and give the plan: a fast start, questions early, work checked in the first weeks. Do not stretch the quoted lines to cover those gaps | The blunt version of F1 to F5. JD because it scores the match to the listed duties |
| E2 | "That appointment book. How much of it was actually you" | EXP | [grounded] "I ran the appointment book for four physios" | Hold on the quote at its own scope: "I ran the appointment book for four physios." Answer slot: if any of it was shared or not yours, say so plainly and say what part was yours; do not retreat from the quote unless that is the truth | The attribution probe in pressure form. EXP |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, A5, C2, D1, E1 |
| "booking travel" | A2, B3 |
| "preparing documents in Word and Excel" | A4, B4, C3, D3 |
| "processing supplier invoices" | A3, B2, D2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role" | Shows you are thinking about doing the job, and gives you the real priorities to rehearse against |
| R2 | "Whose calendars would I be managing, and how do requests normally reach you" | Shows you already think about how the duty works in practice, and tells you what the volume is |
| R3 | "How do supplier invoices reach the team, and who approves them" | Shows you treat invoicing as a process with approvals, and lets you ask for the step-by-step you would otherwise guess |
| R4 | "What training or handover would I get for the travel and invoice parts" | Gives the interviewer an easy way to describe support, and is an honest signal that you plan to learn those parts |
| R5 | "How does the team stay in touch day to day when everyone is remote" | Prepares you for the remote working pattern and shows you have thought about it |
| R6 | "What would you want me to have learned by the end of three months" | Turns the call toward a shared target, and tells you what the interviewer scores most |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars or diaries beyond the clinic's book | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says the book, and nothing beyond it |
| Processed supplier invoices, or handled accounts or payments | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: your material says the chasing, not other invoice steps. B2's slot stays inside the chasing |
| Strong or advanced Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel." B4's slot asks only what you have used it for |

## Sources

Provided documents: your message, containing the invite text, your description of the ad's duties, and your background. No dossier was consumed.

Searches sent and what came back:

- "Brennock Facilities Ltd values careers interview process": refused
- A search for reports of recruitment scams that use this company's name: refused

Research tier: L1 — searches 2 of 6, both refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | The one search touching this target was refused. It would have fed a values cheat sheet; none is detected, so section 10 is dropped |
| 2. interview process | unavailable | The same refused search. Persona weights rest on the invite's own words (one 30-minute video call with the office manager) and the hiring-manager prior |
| 3. strategy and recent news | unavailable | No search ran after the first was refused. It would have fed a CO question; the pack has none |
| 4. interviewer name | n/a | No name was given, so there was no query to form |
| 5. representative JD | unavailable | Search was refused. It would have turned rows that quote your summary into rows quoting the ad's own wording |
| Unnumbered: scam-report search | unavailable | Refused. It would have been background only and moved no row |

## Upgrade menu

- The ad's full text → the four requirement quotes in the fit snapshot become the ad's own words, and any further duty gets a row and a question
- Your full CV or a fuller account of the clinic work → more rows can carry your own quoted sentences, and the guidance cells stop leaning on two sentences
- A short answer to the travel, Excel and invoice slots in your own words → F2, F4 and F5 are regenerated with your quotes
- The office manager's name → an interviewer read and a reverse question tied to their own path
- Your prep time → a prioritized schedule sized to it
- A retry of company research → values and process rows built from sources, if the host allows searches
- A tuesday-dossier.md → verified evidence and any prohibited claims carried in, so the highest-ROI objection is evidence-derived rather than inferred
