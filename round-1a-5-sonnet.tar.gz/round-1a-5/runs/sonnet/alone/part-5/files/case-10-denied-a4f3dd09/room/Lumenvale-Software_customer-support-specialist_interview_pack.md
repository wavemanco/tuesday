# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Round:** one session, a text chat with the support team lead, as your message describes it. No interviewer name was given. **Built on this assumption:** the team lead is the person you would report to, so the pack uses hiring-manager weights. If that is wrong, the weights change (see the questions at the end of the message that came with this file).

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores.
- Type key: **VAL** values and behaviour; **EXP** work-experience deep-dive; **JD** the role's stated requirements; **CO** company and strategy knowledge; **CASE** a live problem from the role.
- Provenance labels: `[grounded]` traces to what you wrote or the requirements you listed; `[inferred]` is this pack's derivation; `[generic]` is a role-family pattern with no claim about you or Lumenvale.
- The guidance is scaffolding, not a script. It is speakable in about two minutes. Say it in your own words.
- This pack has no VAL or CO questions. No values-style round is documented anywhere in your material, and the company searches were refused (see Sources). Nothing here asserts a fact about Lumenvale.
- Answer slots are instructions for the interview, not questions for you now. Where a slot offers two branches, either one is a good answer if it is true.

## Fit snapshot

Requirements are the four you listed from the job ad. Every quote in the evidence column is your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: three years, customer service advisor, an energy supplier. Do not rename the job title |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say it at its own scope: "I use Freshdesk every day." Whether it counts as the ad's "similar ticketing tool" is the interviewer's call. Answer slot: expect a probe on how you use it day to day. Say what you do in it, in your own words. If asked about any other tool, say plainly which you have used and which you have not, and return to Freshdesk |
| F3 | "clear written communication" — job ad, as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote counts calls and emails together. Your material does not show how much of it was written or how clear the writing was. Answer slot: expect a probe, and note that this interview is itself a text chat. If anything showed how your written replies landed, say what it was, in your own words. If nothing did, say so plainly and stay with "around 60 calls and emails a day" |
| F4 | "confidence handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: expect a probe. If a case went above your level, say what it was and what part was yours, in your own words. If none did, or it was not yours, say so plainly and stay with the calls and emails you answered |
| F5 | Support experience inside a software company — your own flag, not a line of the ad you listed | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Coaching or onboarding teammates (role-family pattern, not in the ad you listed) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap. Keep it at its own scope: four new starters, the refunds process, last year, and you trained them. The requirement is a pattern, so it raises no slot. If asked about how it went, answer from what happened |

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Probes the software gap and the thin rows (F3, F4) | High. You named the software gap yourself (F5). F3 and F4 are the thinnest requirement rows. A team lead hiring is also the hiring-manager prior, which favours gap-probing | Rehearse the one objection until it is boring: say the gap plainly first, then hold what your quotes carry |
| Case/Strategist (bank B) | Live support scenarios, answered in writing | High. This is the hiring-manager prior. A text chat also lends itself to written scenarios (my inference, not a documented fact about Lumenvale) | Clarify, then structure, then act, then record. Think in the open and keep the reply short |
| Conversational (bank C) | Friendly opener, "walk me through your journey" | Medium. Any chat opens this way, and the questions are still scored | A short arc built only from your own sentences |
| Data-Driven Prober (bank D) | Reads your lines closely and asks how a figure was counted | Medium. You gave one figure (around 60 a day) and one attribution claim (the training) | Know what you can and cannot say about each, and say plainly when you do not know |
| Pressure (bank E) | A hard customer scenario, or a challenge to your last answer | Low to medium. The ad's escalation requirement invites it. A text chat makes interrupting and time-boxing harder, so the weight stays low | Pause, restate, hold what you stated, concede what you do not know |

Not included: Peer (the interviewer is a team lead, not a peer) and Values (no values-style round is documented). The letter F is skipped so question IDs do not collide with fit rows.

**Highest-ROI prep: A1.** The software-company gap is yours and stated, so some form of this question is the one most likely to arrive.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've come from an energy supplier. How will you get up to speed on a software product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | Hold then concede. Open by saying the gap first, in your words: "I've never worked for a software company." Then give your own plan for learning the product, as a plan and not a past. The pack supplies none. Hold through two follow-ups by returning to the three years and the daily Freshdesk use. Concede specifically what you do not yet know. Never claim software exposure you did not state | F5 is the stated gap and the likeliest first probe. JD because it scores whether the role is doable from this background; the hold-then-concede shape is the Skeptic's bar |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name one weakness before they do, from what you know to be true. Your material states one: "I've never worked for a software company." Answer slot: if a different requirement feels weaker to you, name that one instead and say why, in your own words | F5 plus the thin rows F3 and F4. JD because it scores honest self-assessment against the ad |
| A3 | "Your background is energy supply. Why customer support at a software company, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Answer slot: give your own reason, in your own words. Your material states none, so the pack supplies none. If your honest reason is simply the role itself, say that plainly. Keep it consistent with what you said in your application | F5 is where motivation gets tested. EXP because it scores whether your story holds together |
| A4 | "The ad asks for Zendesk or a similar tool. Talk me through how you use your ticketing tool." | JD | [grounded] "I use Freshdesk every day" | Say it at its scope: "I use Freshdesk every day." Answer slot: expect a probe on what you do in it day to day. Say what you actually do, in your own words. If asked about any other tool, say plainly which you have used and which you have not, and return to Freshdesk. The pack names no Freshdesk features for you | F2 is the evidence for the tool requirement. JD because it scores the ad's own line |
| A5 | "Sixty seconds: why you over a candidate who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year"; "I've never worked for a software company" | Hold then concede. Hold what the quotes carry: three years as a customer service advisor, around 60 calls and emails a day, and the four new starters you trained. Say the software gap yourself in a clause, then stop. Do not claim you are better than the other candidate. Say what you bring and what you would need to learn | F1, F6 and F5 together make the Skeptic's comparison. JD because it scores fit against the stated requirements |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry: they were charged twice and want a refund today. Your ticket doesn't show whether the first charge went through. Walk me through your reply." | CASE | [generic] | Structure it: what you need to know first, how you acknowledge the problem, what you can honestly promise and what you cannot, when they will hear next, and what you record in the ticket. If it needs someone above you, say so and say what you would hand over. The question needs no claim about your past, so the guidance makes none | A live billing-and-refund scenario of the kind the role-family involves. `[generic]` because it is a pattern, not a fact about Lumenvale |
| B2 | "A customer says the app's new feature doesn't work, and you don't yet know the product well. What do you do in the next ten minutes?" | CASE | [generic] | Structure it: ask for what you need (what they were doing, what they saw), say what you do not know rather than guess, find the answer or the right colleague, set an honest expectation, and pass it on with the full details if it is not yours to fix. No claim about your past | Tests the F5 gap as a live problem rather than a history question; a strong answer shows how you work when you do not know |
| B3 | "Ten tickets land at once: a billing dispute, a how-to question, a login problem, and an angry customer who has waited three days. What order, and why?" | CASE | [generic] | State your ordering rule out loud before you apply it, then apply it, then say what you would tell the people who wait. Concede that you would check the team's own priorities. No claim about your past | A prioritisation scenario. It scores structure and reasoning, not a right answer |
| B4 | "A customer writes: 'This is the third time I've written. Nobody has fixed it. I want to cancel.' Write me your reply, here, now." | CASE | [generic] | Write it as you would send it: short, acknowledges the repeat, says what you will do next and by when, and asks one question only if you need to. Plain words, no jargon. This is a live sample of your written communication, so read it back once before sending | Covers F3 directly: the medium is a text chat, so the reply is the evidence. CASE delivery with JD content |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: how did you end up in customer service?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I trained four new starters on our refunds process last year"; "I use Freshdesk every day" | A 90-second arc built only from your sentences: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, the four new starters you trained on the refunds process last year, and Freshdesk daily. Answer slot: how you came to the job and what you want from this one are yours to say, in your own words; the pack supplies neither | The usual opener. F1, F2, F3 and F6 are what an arc can draw on |
| C2 | "What does a good support reply look like to you?" | JD | [generic] | Say what you believe a good reply is, in a few concrete features, and keep it short. Describe your own habits only if they are true. The question needs no claim about your past | Casual in register but it scores F3 (clear written communication). `[generic]` because it asks for a view, not a history |
| C3 | "How comfortable are you picking up a new ticketing system?" | JD | [grounded] "I use Freshdesk every day" | Say it at its scope: "I use Freshdesk every day." Answer slot: if you have picked up a new tool before, say which one and how it went, in your own words. If you have not, say so plainly and say how you would approach a new one | F2 again from another angle. JD because the ad names the tool requirement |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that figure counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Weakest-assumption move. Answer slot: say how it was counted, what it is sensitive to (a quiet day, a busy one), and which assumption behind it you would defend least, each in your own words. If you do not know how it was counted, say so plainly and stay with "around 60 calls and emails a day". Never round it up or restate it as emails alone | F3's quote is the one figure in your material. EXP because the probe scores whether the number survives |
| D2 | "Of those, how many were emails and how many were calls?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you know the split, say it in your own words. If you do not, say so plainly and stay with "around 60 calls and emails a day". Do not estimate the written share to make the written-communication row look stronger | F3's gap is that the quote mixes the two. This is the follow-up that exposes it |
| D3 | "Which part of the refunds training was actually yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Use the quote's own attribution: "I trained four new starters on our refunds process last year." Beats: four new starters, the refunds process, last year, you trained them. If the answer involves anyone else, or a part you did not do, say so plainly. Never call it a programme you designed or owned | F6 is the attribution probe a prober aims at. EXP because it tests what was actually yours |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "When have you handled a case that needed to go above your level?" | JD | [grounded] "answering around 60 calls and emails a day" | Selection scaffold: pick a case with a named stake, something you decided or passed on, and an outcome you know. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is "answering around 60 calls and emails a day", or how you would handle it | F4 is a discovery row with no evidence. JD because it scores the ad's escalation line; the open prompt keeps the question from presupposing an event |
| E2 | "A customer says you're useless and demands your manager. What do you say?" | CASE | [generic] | Pause. Restate what they want. Stay level, say what you can do now, and say honestly what getting someone senior would involve and how long it takes. Hold your position through a second push, and concede only what is true. No claim about your past | A composure case for the escalation requirement, labelled CASE because it is a live problem. `[generic]` since it is a pattern |
| E3 | "Is there anything in your answers so far that you'd now write differently?" | JD | [generic] | Pause before answering. If one answer could be clearer, say which and restate it in one short sentence. If not, say so plainly. Do not spiral into apologising. In a text chat this is also a live read of your writing | Covers F3 as a composure probe. `[generic]` since it asks for no claim about your past |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" (F1) | A5, C1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | A4, C3 |
| "clear written communication" (F3) | B4, C2, D1, D2, E3 |
| "confidence handling escalations" (F4) | E1, E2, B1 |
| Software-company context (F5) | A1, A2, A3, A5, B2 |
| Training teammates (F6) | D3, A5, C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first month look like for someone joining the team who is new to your product?" | It opens the software gap yourself and turns it into a ramp-up conversation instead of an objection |
| R2 | "What do the tickets that get escalated usually look like, and who picks them up?" | The ad lists escalations. The answer tells you what the role really asks of you, and it shows you take the requirement seriously |
| R3 | "Which ticketing tool does the team use, and how are new starters trained on it?" | It shows you are ready to learn the team's tool, and the answer tells you how much of F2 is a requirement and how much is a preference |
| R4 | "How does the team review the quality of written replies?" | It ties to the written-communication requirement and tells you what good looks like for them |
| R5 | "What happens after this chat? Is there a further step, such as a call with the team?" | It lets you prepare for the next format, and it shows you are thinking about the process end to end |
| R6 | "What would tell you in three months that this hire has worked?" | A concrete success measure to aim at, and a strong close to the chat |

## Prohibited claims

Not coached in any cell of this pack. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2: the ad names Zendesk, and your quote names Freshdesk | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's own observation: your material says Freshdesk, not Zendesk |
| Handles around 60 emails a day | Inflated form of F3: the quote counts calls and emails together | F3's quote at its own scope: "answering around 60 calls and emails a day". The split is not in your material |
| Designed or owned the refunds process, or ran a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year" |
| Has worked in, or supported, a software product | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." Then a plan, never a past |

F4 is not listed. Your material is silent on escalations, so it is an answer slot (E1), not a prohibited claim.

## Sources

**Provided:** your message, which holds the invite's text, the four requirements you listed from the job ad, and your background. No full job ad text and no CV were provided.

**Searches sent** (all refused: the search permission was not granted in this session):

- "Lumenvale Software company values": refused
- "Lumenvale Software interview process customer support specialist": refused
- "Lumenvale Software news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have fed a values bank and a company-values reverse question. No VAL question was written |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have checked the loop. The persona weights rest on your own description of one text chat with the team lead, plus an assumed hiring-manager relationship |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have fed at least one CO question. None was written |
| 4. `{interviewer name} {company}` | n/a | The interviewer is described only as "support team lead" and is unnamed. There is no interviewer read |
| 5. representative `{role title}` JD | skipped | The four requirements you listed fix the fit snapshot and the JD-tagged questions |

Nothing in this pack is a claim about Lumenvale's values, process or strategy.

## Upgrade menu

- The full text of the job ad → F1 to F4 become verbatim quotes, and any requirement you did not list (hours, shift pattern, product knowledge, location) gets its own row
- Your CV → evidence cells quote your CV's words, and rows F1 to F3 and F6 can be re-graded
- An answer to the slots outside a drill (a Zendesk answer for F2, how your written replies landed for F3, an escalation you handled for F4) → the matching rows regenerate on your own words
- A support-quality or customer-satisfaction report, a ticket-handling export, or your training notes for the refunds process → the artifacts that would lift F1, F3 and F6 from medium or low toward high
- The team lead's name and role → an interviewer read, tailored weights and a reverse question tied to their path
- Lumenvale's published values or interview page, pasted, or the recruiter's description of the process → a values bank and company-specific questions in place of the refused searches
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), if search is permitted in your session → a strategy brief and current-company questions
- A `tuesday-dossier.md` from an earlier check → verified evidence, an evidence-derived top objection and a prohibited-claims list from that source
