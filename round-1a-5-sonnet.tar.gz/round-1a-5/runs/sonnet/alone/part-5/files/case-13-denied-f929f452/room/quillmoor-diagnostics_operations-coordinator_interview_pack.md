# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Round: recruiter screen with Hannah Lowther, Talent Partner. A 30-minute phone call on Thursday at 2pm; she rings the mobile number on your application. Her own words on what she will cover: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries both.
- Type key: VAL is behavioral or values alignment. EXP is a work-experience deep-dive. JD is role or advert-driven. CO is company and strategy knowledge. CASE is a live problem.
- Provenance key: `[grounded]` traces to your message, the advert or Hannah's message. `[inferred]` is derived from a representative source. `[generic]` is a role-family pattern with no claim about you or Quillmoor.
- Guidance is scaffolding, not a script. Each cell quotes the sentence of yours it rests on. Where the material is silent, the cell is an answer slot: an instruction for the interview, answered from your own experience, with an honest second branch.
- The highest-ROI prep in this pack is B1. It will be asked in some form, by Hannah or by the hiring manager after her.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap on years or title. Say it in the quote's own terms. It is self-reported with nothing inspected behind it, so expect a probe on what the four years covered |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and says nothing about planning or QA. The words stay at "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on whether your scheduling touched a quality or production function is likely. If any of it did, say which and how, in your own words. If none did, say so plainly and stay with the depots |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Lead with chasing suppliers when orders slip, in the quote's words. The quote says schedule and chase and does not say how deliveries are tracked, so describe only those two |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Lead with the quote's terms: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. The figure raises four slots, rehearsed in C1, C2, C3 and E2: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show regular reporting of any kind. Answer slot: the advert names weekly on-time dispatch reporting, so expect a probe. If you report on deliveries in any regular way, say what and how often, in your own words. If you do not, say so plainly and stay with scheduling and chasing |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [grounded] | discovery | The sentence says spreadsheet. It does not say which tool or what you did in it. Answer slot: the advert's confidence line makes a probe on the tool and on what you did in it likely. If it was Excel, say what you did in it, in your own words. If it was another tool, say so plainly |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Words you can give: "I've never used SAP", which you stated, and "we run our own in-house stock system" at its own scope. Your material does not say whether that system is an ERP, so do not call it one. Answer slot: if asked how it compares, say what you do in it if you work in it yourself, in your own words. If you do not, or you are unsure it compares, say so plainly |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | A term shown met by your own words, the strongest evidence a constraint like this has. Say it in those words. Your limit is worded "wouldn't want more than three", a preference, and the pack keeps it at that strength. The advert asks for two days |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | A term shown met: your figure sits inside the advertised band. Say it in your words |
| F10 | "what's prompting a move" — Hannah's LinkedIn message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. Say it in the quote's words and stop; the reason is stated and needs nothing added |

Notice period has no row: Hannah asks for it, your material does not state it, and it is not a requirement of the advert. It is handled as a logistics slot in A3.

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, unstructured; logistics asked as chat: pay, notice, hybrid, the reason for the move | High. A recruiter screen starts here, and Hannah's own message lists the four topics. The risk is treating it as unscored | Know your four logistics answers in your own words before the call; treat the casual questions as scored |
| B. Skeptic | Quiet probing of what the advert asks and your material does not show: production scheduling, reporting, Excel, SAP | High, raised from the "light" prior for this round. F2, F5, F6 and F7 are the rows no quote fully reaches, and a screen is where a recruiter checks them | Rehearse the single most predictable objection (B1) until it is boring. Give what your quotes carry, say the limit plainly, never bluff |
| C. Data-Driven Prober | Asks how the one figure on your background was counted | Medium. You have one figure (F4), so one cluster. A recruiter may ask casually; a hiring manager will ask closely | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| D. Case / Strategist | Light live problems; "what do you know about us" | Medium-low. Unusual in a recruiter screen, but the advert's duties invite a quick situational check, and it is practice for the next round | Clarify, then structure, then answer; think aloud |
| E. Pressure | Time-boxed "why you" challenges | Low. The register here is friendly; two items cover the "why you" and attribution probes | Pause, restate the question, hold your position through two follow-ups, concede only what you do not know |

Loop: Hannah's message establishes this session, a 30-minute phone call with the recruiter. Later rounds are not established by any source I could read. The generic fallback (screen, then hiring manager, then panel) applies to them with flat weights, and this pack weights only this call.

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me about your role at the moment." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." and "I schedule deliveries for our three depots and chase suppliers when orders slip." | Tell the beats the quotes state, in your own words: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for your three depots, chasing suppliers when orders slip. Stop when the beats run out, at about 90 seconds. If asked about anything the quotes do not cover, answer only from what you actually know | F1 and F3 are the evidence for the years and the core duty. EXP because a casual opener still tests whether the background holds together when told aloud |
| A2 | "What are your salary expectations for the role?" | JD | [grounded] "I'm hoping for £42,000." | Your own words were: "I'm hoping for £42,000." Say that and stop. If asked what you earn now, decline with no figure, for example: "I'd rather focus on the range for this role." | Hannah named salary as her first topic. F9 shows the figure inside the advertised band. JD because pay is a term of the listed job |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, in your own words. Your material does not state it, so there is nothing to quote here. If you are unsure of the exact terms, say so plainly and say when you will confirm | Hannah named notice period as her second topic. Nothing in your material carries it, so the guidance is a slot. JD because it is a term of the listed job |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words were: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Lead with the two days. The limit is yours to raise or to hold until more days come up. If asked about the commute, those same words are your answer | F8 shows the hybrid term met. JD because the pattern is a stated term of the role |
| A5 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words were: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it in about thirty seconds and stop. If asked a follow-up on the Reading offer, return to those same words | F10 is the stated reason. EXP because the reason for leaving is scored for consistency with the rest of the story |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules between planning, the warehouse and QA. What have you done that's closest to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: the advert names planning, the warehouse and QA, so a probe on whether your scheduling touched a quality or production function is likely. If any of it did, say which and how, in your own words. If none did, say so plainly and stay with the depots. Hold through two follow-ups by returning to that sentence, never by adding to it, and concede only what you do not know, specifically | F2 is the thinnest of the advert's duties, and it is a duty, not a plus, so this objection arrives in some form. JD because it scores the stated responsibility; the Skeptic frame is how a recruiter checks it |
| B2 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Choose the part you would honestly rank weakest, not the safest-sounding one. If it is SAP, your words were: "Never used SAP — we run our own in-house stock system." Then say how you would learn it, as a plan and never as a past | F7 is the row where you stated the gap yourself; F2, F5 and F6 are the others a Skeptic can reach for. JD because it scores fit against the listed requirements, including its gaps |
| B3 | "Have you worked with SAP or a similar ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain and short: "I've never used SAP", then "we run our own in-house stock system", at that scope and no wider. Answer slot: the advert says SAP or similar, so expect a probe on whether the in-house system is comparable. If you work in it yourself, say what you do in it, in your own words. If you do not, or you are unsure it compares, say so plainly and leave the comparison to the interviewer | F7 carries both the stated gap and the adjacent work. The advert lists ERP as a plus, which the Skeptic frame will test directly. JD because it scores a stated requirement |
| B4 | "The role reports weekly on on-time dispatch. Is that something you've done?" | JD | [grounded] | Answer slot: if you report on deliveries in any regular way, say what and how often, in your own words. If you do not, say so plainly and stay with scheduling and chasing suppliers. The quotes you gave do not mention reporting, so the pack supplies no story here | F5 is the one advert duty with no evidence at all, which is a free miss unless rehearsed. JD because it scores a stated responsibility |
| B5 | "The advert asks for confidence with Excel. Where do you stand on that?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the quote says: "I rebuilt our stock-count spreadsheet." Answer slot: the advert's confidence line makes a probe on the tool and on what you did in it likely. If it was Excel, say what you did in it, in your own words. If it was another tool, say so plainly. Do not rate yourself with a word you cannot back up in the next question | F6 touches the requirement without showing it is met. JD because it scores a listed skill |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the drop in stock discrepancies was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the figure exactly as you gave it: "discrepancies fell by about a third over a year", about a third, not a rounded percentage. Answer slot: say how it was counted, in your own words. If you do not know the counting basis, say so plainly and say what you do know | F4 is the only figure, so it is the magnet target. EXP because the probe tests whether a number survives its own definition |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Name, in your own words, the weakest assumption you know of before they do. The pack does not name one for you. If none comes to mind, say so plainly and say what you would want to check | F4 again; the weakest-assumption move converts a probe into a credibility gain. EXP because it tests whether you know your own number's limits |
| C3 | "Take me through what the rebuild actually involved." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The beat the quote states is "I rebuilt our stock-count spreadsheet." Answer slot: the interviewer will ask what you changed, so say what you changed and why, in your own words. If part of it was not yours, or you cannot recall the detail, say so plainly and return to the sentence | F4's rebuild is the verb a prober presses on. EXP because it separates what you did from what the sentence implies |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What do you know about Quillmoor, and why us?" | CO | [generic] | Research did not run for this pack, so nothing here is about Quillmoor. Selection scaffold: pick two things you have actually read in the advert and say why each interests you. If you have not read beyond the advert, say so plainly and say what in the advert drew you | The upgrade menu says what a search or a pasted company page would add. CO because it scores homework; it stays generic until there is something to ground it on |
| D2 | "A key supplier tells you on Thursday that an order QA needs on Monday will be a week late. Walk me through what you do." | CASE | [generic] | Structure it aloud: what you would ask first, what you would do about Monday today, who needs to hear it (planning, the warehouse and QA are the three the advert names) and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's chase-late-orders duty (F3's requirement), asked as a decision. CASE because it scores structure; generic because it is a pattern, not a fact about this employer |
| D3 | "Planning wants to move a run forward a day, the warehouse can't receive the materials until the following day, and QA needs its samples first. How do you approach it?" | CASE | [generic] | Clarify before structuring: what is fixed and what can move, and who decides. Then state the objective, the options, the trade-offs and what you would tell each of the three teams. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | From the advert's three-way coordination duty (F2's requirement). CASE because it scores clarify-then-structure; generic, and the likeliest format for the next round |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, when other candidates already use SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." and "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. Concede what you stated: "I've never used SAP." Hold with what the quotes carry: "I schedule deliveries for our three depots and chase suppliers when orders slip." Add nothing to it. Hold through two follow-ups | F7 holds the stated gap and F3 the core-duty evidence. JD because it scores the listed requirements head on; Pressure because it is time-boxed |
| E2 | "That drop in discrepancies: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say what part was yours, in your own words. If others contributed, or something other than the rebuild played a part, say so plainly. Hold through two follow-ups by returning to the sentence: "I rebuilt our stock-count spreadsheet." Concede what you do not know, specifically, and do not fold on what you did | F4's attribution is the standard pressure probe on a figure. EXP because it tests precise attribution |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, B2, D3 |
| Track supplier deliveries and chase late orders | A1, D2, E1 |
| Keep stock records accurate | C1, C2, C3, E2 |
| Report weekly on on-time dispatch | B4 |
| Confident with Excel | B5 |
| ERP experience (SAP or similar) a plus | B2, B3, E1 |
| Hybrid: two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |
| Hannah's topic: notice period | A3 |
| Hannah's topic: what's prompting a move | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with day to day across planning, the warehouse and QA, and how do those three teams currently hand over to each other?" | The advert makes that three-way seam the job; asking about it shows you read the duty as coordination |
| R2 | "What would the first month look like for someone in this role?" | It shows you are planning to be useful quickly, and the answer tells you what is expected first |
| R3 | "Which system does the team use for stock and orders today, and how is a new starter trained on it?" | The advert calls ERP a plus; the answer shows how much weight it carries and how much of the learning is on the job |
| R4 | "How is on-time dispatch reported today, and who reads the weekly report?" | It shows you take the reporting duty seriously and tells you the audience |
| R5 | "Is two days at Avonmouth the expected pattern over time, or does it change at certain points?" | It checks whether the hybrid pattern is stable, which matters to a limit you hold of three days |
| R6 | "What are the next steps after this call, and who would I meet next?" | It signals interest in progressing and gives you the shape of the later rounds, which no source I could read has established |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Production scheduling experience | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: your material says delivery scheduling, not production scheduling. B1's slot stays inside the depots |
| Having used SAP | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." No slot |
| The in-house system as an ERP | Inflated form of F7 | F7's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material does not say whether that system is an ERP. B3's slot asks only what you do in it |
| An exact or causal form of the stock figure | Inflated form of F4 | F4's quote at its own scope: "discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence says about a third and does not say what share of the fall was the rebuild. C1, C3 and E2 ask only how it was counted and which part was yours |
| Advanced or expert spreadsheet skills | Inflated form of F6 | F6's quote at its own scope: "I rebuilt our stock-count spreadsheet." The limit is the pack's observation: the sentence says spreadsheet, not the tool or what it held. B5's slot asks only the tool and what you did in it |

## Sources

Provided documents: the advert as pasted in your message, your background notes in your message, and Hannah's LinkedIn message as quoted in your message. No dossier was present.

Searches sent, each refused, so nothing came back from any of them:

- `Quillmoor Diagnostics company values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics Avonmouth news` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have grounded D1 and the "why us" answer; D1 is a `[generic]` scaffold instead |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | The search was refused. It would have named the later rounds; the generic fallback applies to them, said plainly in the persona section |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | The search was refused. It would have fed D1 with current company context |
| 4. `Hannah Lowther Talent Partner Quillmoor Diagnostics` | unavailable | The search was refused. It would have supplied an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period in your own words → A3 changes from an instruction to your own sentence
- Your answers to the slots in F2, F5, F6 and F7 (whether your scheduling touched a production or quality function, whether you report on deliveries, which tool the spreadsheet was in, what you do in the in-house system) → those rows gain evidence, and B1 and B3 to B5 become story-mapped
- The before and after discrepancy counts from your stock-count spreadsheet → F4 can rise from medium to high, and C1 to C3 gain defensible detail
- Permission to run web searches, or a pasted Quillmoor careers or about page → D1 becomes `[grounded]`, and an interviewer read and a reverse question tied to Hannah's path become possible
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for D1 and grounded company context for later rounds
- Any prep email from Hannah about the later rounds → the loop's rounds replace the generic fallback, and persona weights follow them
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and a stated strategy for each weak area, in place of this pack's inferred objection
