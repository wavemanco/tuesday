# Interview pack — Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager, on a 30-minute video call. Relationship not stated; this pack assumes the office manager would be your line manager (a hiring-manager round).

## How to use this pack

Personas describe how a question arrives (friendly, skeptical, time-boxed). Types describe what the question scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral: what your past behavior shows |
| EXP | Work-experience deep-dive: whether your CV claims survive follow-ups |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no company research ran, see Sources) |
| CASE | A live problem from the role, worked through aloud |

Where guidance says Answer slot, it is an instruction for the interview: answer from your own experience, or say plainly it was not yours or did not exist. Both are good answers.

## Fit snapshot

Requirements are the four duties you gave me from the ad. Evidence is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your words are the appointment book, so keep them: "I ran the appointment book for four physios." Do not swap in the ad's word for yours. Nothing has been inspected behind this line, so expect a probe on it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if booking travel, rooms or events for other people was part of any job you have had, say what it was, in your own words; if none was, say so plainly and stay with the appointment book you ran |
| F3 | "preparing documents in Word and Excel" (Word part) — the ad, as you described it | "I'm good with Word" — your message | medium | [grounded] | none | No gap, but a self-rating with nothing inspected behind it. Lead with your own words: "I'm good with Word." Answer slot: if asked what you have prepared in it, name what it was; if you have prepared little, say so plainly and say what you use it for |
| F4 | "preparing documents in Word and Excel" (Excel part) — the ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | Your word is "okay", and the words stay there: "I'm okay with Excel." Answer slot: if asked what you can do in it, say what you have done; if it has been basic, say so plainly. Then say, as a plan and never as a past, what you would learn first |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says you chased unpaid invoices; it does not say which side of the invoice you were on. The words stay at that scope: "I chased unpaid invoices." Answer slot: say what you did when one stayed unpaid and which steps were yours; if none were yours to decide, say so plainly and stay with the chasing |

## Persona table

The loop rests on your own words: one 30-minute video call with the office manager. No loop source names a values round, so none is assumed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of F2, F4 and F5, and of why this job | Highest. A hiring-manager round buys capability and checks gaps, and three of your five rows are thin | Rehearse A2 until it is boring: your own words from F5, then the slot, never a stretch |
| Case/Strategist (bank B) | Small live problems from the four duties | High. The role is practical, so scenarios are the quickest test in 30 minutes | Clarify first, then structure, then answer; think aloud |
| Conversational (bank C) | Friendly opener, casual questions about Word and your path | High. A short video call opens this way; casual questions are still scored | A 90-second arc built from F1 and F5; answer the Word question concretely |
| Data-Driven Prober (bank D) | Follow-ups on "four physios", "okay with Excel" and the invoices | Medium. Your lines are short, which invites a second question | Know what you can say about each line, and say plainly where you stop |
| Values/Behavioral (bank E) | A story question or two | Low. No values round is documented, so only the generic stems | Pick one real example and keep to what happened |
| Pressure (bank F) | A time-boxed "why you" and "how much was you" | Low to medium. It can come from a short, direct manager | Hold your position through two follow-ups, concede only what is true |

Peer Evaluator is left out: it applies if the office manager is a peer on the team. If so, tell me and I will add a bank.

## Question banks

Highest-ROI prep: A2, the supplier-invoice question. It is aimed at F5, where your material is thinnest against the ad.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Name it in your own words, starting from "I'm okay with Excel". Then give your plan: what you would learn first and how. Say it as a plan, never as something already done | F4 is the thinnest of the four duties you listed, so this is where a skeptic starts; JD because it scores the stated duties |
| A2 | "What experience do you have with processing supplier invoices?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Your hold is only what the quote carries: "I chased unpaid invoices." Answer slot: say what you did when one stayed unpaid and which steps were yours; if none were yours to decide, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it | F5 is where the ad's invoice duty presses hardest on your material; JD because it scores a stated duty |
| A3 | "Why this job, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Give your actual reason, in your own words; the pack does not supply one. Start from your two years as a receptionist at a physiotherapy clinic, then say what you want next. Keep it to what is true | Motivation consistency is the standard Skeptic probe; EXP because it tests whether your path hangs together |
| A4 | "Tell me about booking travel for someone else." | JD | [grounded] | Selection scaffold: pick a time you arranged bookings for another person, with a named person, a constraint you worked around and a result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 has no quote behind it, so this is an open prompt for you to answer from your own life; JD because the ad lists it |
| A5 | "You would be working remotely. What in your background shows you can work without someone beside you?" | EXP | [grounded] "ran the appointment book for four physios" | Story-mapped on F1: the appointment book and the four physios, which are the beats the quote states, told in your own words. Answer slot: if some decisions about the book were yours to make without asking, say which; if not, say so plainly and describe how you ran it | The title says remote, which raises independence; EXP because it tests what was actually yours |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people you support ask for the same hour on the same day, and both say it is urgent. What do you do?" | CASE | [generic] | Structure it: what you would ask each of them first, who decides priority, what options you can offer, how you confirm the outcome in writing, and what you record. The problem asks nothing about your past, so the guidance claims nothing | Live problem from the calendars duty (F1's requirement), asked as a decision; generic because it is a pattern for the problem |
| B2 | "A colleague needs to be in two cities in three days, arriving before a 9am meeting. What do you need to know before booking anything?" | CASE | [generic] | Clarify first: the budget and any travel rules, how flexible the times and fares are, preferred options, who confirms. Then offer two or three options, confirm before you book, send the itinerary and note what to do if something changes | Live problem from the travel duty (F2's requirement); a generic pattern, no claim about your past |
| B3 | "A supplier invoice arrives and the amount does not match what was ordered. Walk me through what you do." | CASE | [generic] | Check the invoice against the order, find out who raised the order, hold the invoice unpaid until it is resolved, contact the supplier with the specific difference, and record the outcome. Say it step by step | Live problem from the invoices duty (F5's requirement); generic, since it is a pattern for the problem |
| B4 | "You are asked for a one-page summary of a spreadsheet of monthly costs by Friday. What do you ask first?" | CASE | [generic] | Clarify the audience and what decision it is for, what period and columns matter, the format, and who checks the figures. Then structure: what goes at the top, what the table shows, what you flag. Plain and short | Live problem from the documents duty (F3 and F4's requirement); generic, with no claim about your skills |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you end up in admin?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message; "ran the appointment book for four physios"; "chased unpaid invoices" | A 90-second arc made only of your own lines: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices. Then say why this job, in your own words | The standard friendly opener; F1 and F5 are its raw material; EXP because it tests whether your story holds together |
| C2 | "Which of the duties in the ad appeals to you most?" | JD | [grounded] | Pick one of the four from the ad and say why, in your own words. If you choose one your material is thin on, say that you are keen to learn it rather than implying experience | A casual question that is still scored for genuine interest; JD because it refers to the ad's duties |
| C3 | "What do you actually use Word for these days?" | JD | [grounded] "I'm good with Word" | Start from your own words: "I'm good with Word." Answer slot: name what you have prepared in it; if you have prepared little, say so plainly and say what you use it for | F3 is the one skill you rated well, so expect a concrete follow-up; JD because Word is in the ad |
| C4 | "If you started tomorrow, what would your first week look like?" | JD | [generic] | A plan, not a past: learn the systems and who to ask, find out which calendars and recurring tasks you would look after, and agree what to do first. Ask what the first priority is | Pattern for the question; it makes no claim about you; JD because it tests understanding of the role |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the appointment book you ran for four physios." | EXP | [grounded] "ran the appointment book for four physios" | Beats the quote states: the appointment book, and the four physios, told in your own words. Defend-the-number slots: say how "four" was counted and whether it stayed four; name the assumption behind it you would defend least, or say plainly that you do not know of one; say which part of running the book was yours | F1 holds the one figure in your material, so a prober goes straight to it; EXP because it tests attribution |
| D2 | "You say you are okay with Excel. What can you do in it, and where do you stop?" | EXP | [grounded] "okay with Excel" | Say what you have done in it, in your own words, and where you stop, plainly. Answer slot: if what you have done is basic, say so, then say what you would learn first. Never describe a skill you do not have | F4 is low confidence, so the honest answer is rehearsed before the probe lands; EXP because it tests the claim |
| D3 | "Tell me about the unpaid invoices you chased." | EXP | [grounded] "chased unpaid invoices" | Say what you chased, in those words. Answer slot: if one case stands out, say what happened and what part was yours; if none does, say so plainly and describe what the chasing involved for you | F5 is the closest your material comes to the invoices duty; EXP because it tests what you did |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell someone something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a real time with a named person, what you said, and how things stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem adapted to an admin role; no values round is documented, so this is generic |
| E2 | "When did you put the person in front of you ahead of the usual process?" | VAL | [generic] | Selection scaffold: pick a real moment with a named stake, what you chose and the result. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem adapted; generic for the same reason as E1 |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has worked in an office?" | JD | [grounded] "ran the appointment book for four physios"; "chased unpaid invoices" | Pause, restate the question, then hold on what you said: you ran the appointment book for four physios and you chased unpaid invoices. Hold through two follow-ups. Concede only what is true: that you would need to learn their systems | A time-boxed challenge to your background; JD because it tests fit to the listed duties |
| F2 | "That appointment book. How much of it was actually you?" | EXP | [grounded] "ran the appointment book for four physios" | Hold "I ran the appointment book for four physios" through two follow-ups. Answer slot: say which parts were yours and which were shared; if all of it was yours, say so, and if you do not know, say so plainly. Never claim more than the quote | The standard attribution probe; EXP because it tests whether "ran" survives a second question |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "managing calendars" | A5, B1, D1, F1, F2 |
| "booking travel" | A4, B2 |
| "preparing documents in Word and Excel" | A1, B4, C3, D2 |
| "processing supplier invoices" | A2, B3, D3 |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | Shows you are thinking about doing the job and gives you the priorities |
| R2 | "Which of the four areas, calendars, travel, documents or invoices, takes up most of the week?" | Shows you have read the ad closely and tells you where to spend your prep |
| R3 | "Which tools does the team use for calendars, travel booking and invoices?" | A practical question that surfaces the tool gaps from F2 and F4 on your terms |
| R4 | "Who would I work with day to day, and how does the team keep in touch when everyone is remote?" | Shows you have thought about working at a distance, which the title raises |
| R5 | "What happens after this call, and what is the timeline?" | A process question with a prep reason: it tells you whether another round needs preparing |
| R6 | "What separates someone doing well in this role from someone who is only coping?" | Gets you the manager's own measure of the job |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation, not words for you: your material says chasing unpaid invoices, and does not say which side of the invoice you were on |
| Managed calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The ad's word for the duty is not yours |
| Strong or advanced Excel skills | A claim your own quote contradicts | Your own words: "okay with Excel." Nothing more |

## Sources

Provided documents: the invite text and your background as pasted in your message.

Searches sent: "Brennock Facilities Ltd values" — refused. "Brennock Facilities Ltd interview process remote administrative assistant" — refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. It would have fed a values cheat sheet, which is not in this pack |
| 2. `Brennock Facilities Ltd interview process remote administrative assistant` | unavailable | The search was refused. The loop rests on your own description instead: one 30-minute video call with the office manager |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | No call was sent because search was not available. It would have fed CO questions, so the pack has none |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The four duties you gave fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The ad's full text → any requirement beyond the four becomes a quoted fit-snapshot row with its own questions
- Your own answers to the answer slots on F2, F4 and F5, typed out in your words → those rows move from silence to quoted evidence and the banks are regenerated against them
- Who the office manager is to you (your manager, a peer, or standing in for someone else) → persona weights are recomputed and a peer bank is added if needed
- Search access: up to 6 searches and 2 fetches at the default tier, and a deeper pass of 6 more searches and 2 more fetches with several more minutes → published values, documented interview process and company-strategy CO questions
- A `tuesday-dossier.md` → verified evidence and ready-made limits on what to claim, so the fit rows carry firmer confidence
