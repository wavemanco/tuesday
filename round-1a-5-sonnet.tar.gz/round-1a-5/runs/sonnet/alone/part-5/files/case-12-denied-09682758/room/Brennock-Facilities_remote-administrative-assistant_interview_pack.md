# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format as the invite states it: a 30-minute video call. Relationship: a manager-type interviewer, so the pack is weighted with the hiring-manager prior. The invite says only "office manager", so correct the weights if that person is a peer or an HR contact.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding for your own words, not a script: say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment with published company values (none in this pack: no values round is detected) |
| EXP | Work-experience deep-dive: does your background survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed duties, gaps included |
| CO | Company and strategy knowledge (none in this pack: no company research was available) |
| CASE | A live problem from the actual role, answered by structuring it aloud |

An answer slot is an instruction for the interview, not a question for you here. If you did the thing, say how in your own words; if you did not, or it was not yours, say so plainly and return to what you did do.

**Highest-ROI rehearsal: A2.** The ad's invoice duty is the line your material reaches least directly, so expect a probe on it in some form. Rehearse A2 until the honest answer is boring.

## Fit snapshot

Requirements are the duties as you described the ad to me. The full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | presentation | A self-report with nothing inspected behind it. Your words: "I ran the appointment book for four physios." Say it in the quote's own terms and let the interviewer draw the link to calendars. Your material says the appointment book, and the bridge goes no wider than that |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: the ad's travel line makes a probe on what you have arranged likely. If you have arranged travel for anyone, say what and for whom, in your own words; if you have not, or it was not your job, say so plainly and describe how you would go about it |
| F3 | "preparing documents in Word" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | presentation | A self-rating with nothing inspected behind it, so expect a probe on what you make in Word. Your words: "I'm good with Word." Answer slot: if you have prepared documents in Word, name one and what it was for; if you have not at work, say so plainly and say what you have used it for |
| F4 | "preparing documents in ... Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | The quote touches Excel without showing what for. Your words: "okay with Excel." Answer slot: the ad's Excel line makes a probe on what you have used it for likely. If you have used it for any task, say which, in your own words; if you have not beyond the basics, say so plainly and say what you would learn first |
| F5 | "processing supplier invoices" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says you chased unpaid invoices, and the ad says processing supplier invoices. Your words: "I chased unpaid invoices." Answer slot: if any of your clinic work involved handling invoices that came in from suppliers, say what; if none did, or it was not yours, say so plainly and stay with the unpaid invoices you chased |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work remotely from your own home with a suitable setup. This row is surfaced, not bridged |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed or managed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation, not words for you: your material says the invoices you chased, not supplier invoices. A2's slot stays inside what you chased |
| Advanced or expert Excel skills | Contradicted by your quote on F4 | Your own words: "okay with Excel." |
| Managed calendars across the organisation | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says the appointment book, not calendars generally |

## Persona table

The invite gives one session: a 30-minute video call with the office manager. Weights start from the hiring-manager prior (Case plus Skeptic) and were adjusted for a short call: a conversational opener is likely and a Pressure style is less so. There is no interviewer profile, so no signal adjusts them. Correct them if you know something I don't.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the gap between reception work and this role's duties | Highest. F2, F4 and F5 are where your material is thinnest, and a manager buying capability tests exactly there | Rehearse the likeliest objection (A2) until it is boring. Use only your own quoted words and name the limit plainly |
| B. Case/Strategist | Small live problems from the actual duties: clashes, a travel booking, an invoice query | High. The ad's duties translate directly into live problems, and a manager scores structure | Clarify first, then structure, then answer; think aloud; say which steps you know and which you would check |
| C. Conversational | Friendly opener and casual questions about your clinic work and why this job | Medium-high. A 30-minute video call usually opens with the biography question, and casual questions are still scored | Prepare a 90-second arc from your quoted sentence; treat casual questions about Word, Excel and remote working as scored |
| D. Data-Driven Prober | Reads your line closely and asks what part was yours | Low-medium. Your material has one number, the four physios, and no metrics | Know what was yours and say where it was shared |
| E. Pressure | Time-boxed challenge on why you | Low. Nothing in the invite signals a stress style, but a manager may test composure on the career step | Pause, restate, hold your position through two follow-ups, concede only what is true |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "I'm good with Word, okay with Excel" | Pick the duty where your own material is thinnest and name it plainly, then say your first step to close it. If you pick Excel, your own words are: "I'm good with Word, okay with Excel." Answer slot: say what you have used Excel for; if nothing beyond the basics, say so and say what you would learn first | The pack's read is that F2 and F4 are the thinnest rows, and a manager asks for the self-assessment before the probe. JD because it scores the stated duties; inferred because the pick is yours to make |
| A2 | "You chased unpaid invoices at the clinic. This role processes supplier invoices. What carries over?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if any of your clinic work involved handling invoices that came in from suppliers, say what and what part was yours, in your own words; if none did, say so plainly and stay with the unpaid invoices you chased. Hold through two follow-ups by returning to the quote, never by adding to it. The honest branch is a limit, not a confession | F5 is where the invoice duty presses hardest against the evidence, so this objection arrives in some form. JD because it scores a stated duty |
| A3 | "Tell me about a time you arranged travel or a trip for someone else." | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | An open prompt, so pick the instance yourself. Selection criteria: a named person you arranged it for, what you had to check, and how it turned out. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I ran the appointment book for four physios." Or say how you would handle a booking | F2 has no evidence in your material, and the ad names travel. JD because it scores a stated duty, with a selection scaffold because no quote carries a story |
| A4 | "How comfortable are you with Excel, honestly?" | JD | [inferred] "I'm good with Word, okay with Excel" | Say it in your own words: "okay with Excel." Answer slot: if you have used it for any task, say which; if not beyond the basics, say so plainly and say what you would learn first. Do not describe a spreadsheet task you did not do | F4 is low confidence, and a manager checks the self-rating against a task. JD because the ad lists Excel |
| A5 | "Why move from a clinic reception to a remote admin role?" | EXP | [generic] | Give your actual reason in your own words, and choose a reason you can say twice without it changing. Nothing in your material states one, so the pack supplies none | A motivation probe is nearly certain in a manager call. EXP because it tests whether your account of your own history is consistent |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people ask you to book the same slot for different meetings. What do you do?" | CASE | [generic] | Structure it aloud: ask who has priority or who can decide, check for another slot that suits both, tell both people promptly, and record what was agreed. The question needs no claim about your past, so the guidance makes none | F1's requirement, set as a decision. CASE because it scores structure, and generic because it is a pattern for the problem |
| B2 | "A manager wants a trip booked and the best option is over their budget. Talk me through it." | CASE | [generic] | Clarify first: the budget's owner, the dates' flexibility, what matters most. Offer two or three options with their trade-offs and let the manager decide. Say what you would confirm before booking. No claim about your past | F2's requirement as a live problem, which suits a row with no evidence. CASE, generic |
| B3 | "A supplier invoice arrives that doesn't match what was ordered. What do you do?" | CASE | [generic] | Structure it: check it against the order, ask the person who ordered, query the supplier in writing, hold it rather than pay it while it is unresolved, and keep a note. Say which of these steps you know and which you would ask about | F5's requirement as a live problem, so you can show reasoning without claiming experience. CASE, generic |
| B4 | "I give you a spreadsheet of this month's supplier invoices. How would you check it for duplicates?" | CASE | [generic] | Think aloud: what columns you would expect, how you would spot repeats, what you would do with a suspected duplicate. Say which Excel steps you know and which you would look up. The guidance claims no skill beyond your own words on F4 | F4's requirement set as a task. CASE, generic |
| B5 | "I need a short letter to a supplier by tomorrow. How do you approach it, and what do you check before it goes?" | CASE | [generic] | Clarify the purpose and the tone, draft it, check names, dates and amounts, and ask for a quick review before sending. No claim about documents you have written | F3's requirement set as a task. CASE, generic |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc with only the beats the quote states: two years, receptionist, a physiotherapy clinic, the appointment book for four physios, chased unpaid invoices. Tell them in your own words. Answer slot: add why this role, in your own reason; if you are not sure of it yet, say what draws you to the duties | The standard opener, and a casual question that is scored. EXP because it tests whether your account matches your material |
| C2 | "Tell me about running the appointment book for four physios." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Beats the quote states: the appointment book, four physios. Answer slot: the ad's calendar line makes a probe on how you handled the book likely. If you decided how changes to it were handled, say how, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you ran the book | F1 is the evidence for the calendar duty and the likeliest place to be probed. EXP because it tests what was actually yours |
| C3 | "You'd be working from home. How would you set yourself up, and how would you stay on top of things?" | JD | [generic] | Describe your real setup and routine in your own words. If part of it is not in place yet, say which part and what you would do about it. Nothing in your material describes your home setup, so the pack supplies none | F6 is a gate your material does not establish, and a manager of a remote role asks. JD because remote working is a stated term of the role |
| C4 | "Tell me about a document you've put together in Word that you were pleased with." | JD | [grounded] "I'm good with Word, okay with Excel" | An open prompt, so choose the instance yourself. Selection criteria: what it was for, who read it, what you did to get it right. If no such document comes to mind, say so plainly, then give the nearest thing your material does carry: "I'm good with Word." Or say how you would approach one | F3's requirement. JD because it scores a listed duty, with a scaffold because no quote carries a story |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said you ran the appointment book for four physios. Which part of that was yours?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Your own words on it: "I ran the appointment book for four physios." Answer slot: if others also worked on the book, say who did what; if you ran it alone, say so plainly. Name the part you would defend least before they ask | F1 holds the one number in your material, four physios, so this is the defend-the-number question. EXP because it tests attribution |
| D2 | "Which part of the invoice chasing was yours, and which was someone else's?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Your own words: "I chased unpaid invoices." Answer slot: if another person set the process or approved write-offs, say who did what; if you handled it end to end, say so plainly. Do not add any step your quote does not state | F5 is the row a prober tests for attribution. EXP because it scores what was actually yours |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we choose you?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Pause, restate the question, then use only the quote's beats: two years as a receptionist, the appointment book for four physios, the unpaid invoices you chased. Hold that position through two follow-ups. Concede specifically where the interviewer is right, for example that the supplier-invoice and travel duties are new to you if they are, and never fold on what the quote does carry | F1 and F5 are the evidence a manager weighs against the other duties. EXP because it tests whether your account holds under time pressure |
| E2 | "This is a step from reception into an office role. What makes you think you're ready?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Hold-then-concede: say what you did in the quote's words, then say plainly which duties on the list are new, and what you would learn first. Answer slot: if you have a reason you are ready beyond the quote, give it in your own words; if not, stay with the quote | The reception-to-office step is the objection the fit snapshot exposes most visibly. JD because it scores readiness for the listed duties |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 managing calendars | B1, C2, D1, E1 |
| F2 booking travel | A3, B2 |
| F3 preparing documents in Word | B5, C4 |
| F4 preparing documents in Excel | A1, A4, B4 |
| F5 processing supplier invoices | A2, B3, D2, E1 |
| F6 remote working | C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you are thinking about the work rather than the interview, and the answer tells you what to practise first |
| R2 | "Which tools do you use for calendars, travel and invoices?" | The answer tells you which of Word, Excel and any other tool matters most, so your prep after the call is specific |
| R3 | "Which of the four duties takes up most of a typical week?" | It shows you where the weight of the job sits, which tells you how much F2 and F5 will matter in practice |
| R4 | "How do supplier invoices move from arriving to being paid here?" | You get to learn the process rather than pretend to know it, which suits a gap you have named plainly |
| R5 | "How does the team stay in touch day to day when the work is remote?" | It shows you have thought about remote working and gives you the working pattern |
| R6 | "What are the next steps after this call, and is the next stage another video call?" | A prep reason: it tells you what to get ready for and when |

## Sources

Provided documents: the interview invite (your message) and your description of the ad's duties and of your own background. No full ad text and no CV were supplied. No dossier was present.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Searches sent:

- "Brennock Facilities Ltd values": refused
- "Brennock Facilities Ltd interview process administrative assistant": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The search was refused. It would have fed a values cheat sheet, but no values-style round is detected for this loop, so no section is missing |
| 2. `{company} interview process {role family}` | unavailable | The search was refused. The loop rests on the invite's own words, one 30-minute video call with the office manager, so the persona weights follow the hiring-manager prior |
| 3. `{company} strategy` / recent news | unavailable | No call was sent after the first two were refused. It would have fed CO questions, so this pack has none |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The duty list you gave fixes the fit snapshot's requirement rows and the JD-tagged questions |

Everything about the employer in this pack comes from the invite. Nothing is asserted about the company's values, strategy or process.

## Upgrade menu

- The full ad text → F1 to F5 would quote the ad's own lines instead of your description, and the JD-tagged questions would be checked against the whole list
- Whether you can work remotely from your own home with a suitable setup → F6 would be settled and C3 tailored to your real setup
- Anything you did at the clinic involving supplier invoices, booking travel or Excel, in your own words → F2, F4 and F5 would be rewritten from your quotes and A2, A3 and A4 retuned
- The office manager's name → a reading of their public professional footprint, persona weights adjusted to it, and a reverse question tied to their path
- A page from the employer's own website describing its values or interview process, or search permission → a values sheet if a values round exists, and CO questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief and strategy-based CASE questions, if search permission is granted
- A tuesday-dossier.md from an earlier evaluation → verified evidence and prohibited claims in place of the locally built list
