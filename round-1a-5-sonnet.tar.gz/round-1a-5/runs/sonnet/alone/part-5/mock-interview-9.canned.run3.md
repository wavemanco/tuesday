I'm still loading the skill's reference files (personas, research rules, the reframing audit). Once they're read, I'll build your prep pack.
I saved your prep pack. I built it for the panel the invite describes: Principal Vantongeren plus two fourth-grade team members. The district's own hiring page describes the same format.

You included a Social Security number. I don't need it and haven't used it. It isn't in the pack or in any search, so I'd also leave it off anything you send ahead.

**What's in it**
- **Your license:** it meets the invite's one hard requirement as you stated it, so it gets no question.
- **Biggest gap:** your own note that you've never taught fourth grade. Question A1 is the one to rehearse first.
- **The principal:** a reading specialist for nine years before becoming principal. Expect real depth on reading instruction.
- **The district:** its three published beliefs shape the values questions, and the August 2026 literacy plan shapes one strategy question.
- **Answer slots:** where your material is silent, the pack has instructions for what to say if it's true and what to say if it isn't, not invented specifics.

**Research limits**
- I read two district pages in full: the beliefs and the hiring process.
- The board literacy plan and the principal's profile are from search-result summaries only. Read the full board item before Thursday.
- The job-board listing I found moved nothing in the pack, because I had no full posting to build on.

Say the word and I'll play the skeptical principal on A1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Pack file: `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-5/rooms/case-9-canned-62c840d3/halvering-elementary_fourth-grade-teacher_interview_pack.md`

Three questions that would change the pack:
1. Can you paste the full job posting, or would you rather I go without it? It would turn two role-family rows into quoted requirements.
2. Did HR say anything about format, such as a sample lesson, a portfolio or topics to prepare? A prepared item would get its own build section.
3. Do you want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes)? It would add a fuller read of the board's literacy plan and the principal's talk.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (their names and roles were not given)
**Built on this assumption:** the panel the invite describes, which the district's own hiring page also describes (one 45-minute building panel, the principal and two grade-level teachers). No job posting was supplied, so the role requirements below come from the invite and from the district's published pages, and two rows are plain role-family prose.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether the lines in your material survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the district's current direction |
| CASE | A live problem from the role, scored on structure and reasoning |

The single highest-ROI prep in this pack is **A1**, the fourth-grade question. It will be asked in some form, and a calm, plain answer changes the interview.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, so it routes like any other row. Say it in the stated terms: the license, the elementary endorsement, active through June 30, 2029. It is a stated line with nothing inspected behind it, so expect HR or the panel to confirm it against the record. This pack has not checked the record, and the license number is kept out of this file |
| F2 | "Fourth Grade Teacher position at Halvering Elementary School" — the invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | Words for the gap: "I've never taught fourth grade." Adjacent work at its own scope: I have taught third grade for six years at a public elementary school in Joliet. How you would learn the grade is a plan, never a past, and A1 and A2 hold it. Nothing here claims to know what fourth grade requires |
| F3 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford beliefs page; "Panels ask about reading instruction" — Orrinsford careers page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says the curriculum move and the club, and the words stay there: "I led our grade level's move to a new reading curriculum in 2024. I've run the after-school reading club for the last two years." Answer slot: the belief makes a probe on the details of the move and the club likely. If any part of either was yours to set, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and stay with the move and the club |
| F4 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your material says a weekly email, not conversations with each family, and the words stay there: "I write a weekly email to families." Answer slot: the belief makes a probe on the email's details likely. If any part of it was yours to set, such as what went in it or who received it, say which, in your own words; if there was no such decision, or it was not yours, say so plainly and stay with the weekly email |
| F5 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford beliefs page | none given | none | [grounded] | discovery | Your material is silent here, so the words are an answer slot: the belief makes a probe on how assessment results shaped your teaching likely. If results ever changed what you taught or how, say what, in your own words; if none did, or it was not yours, say so plainly, then say how you would use results in a fourth-grade room, as a plan |
| F6 | "Panels ask about reading instruction, classroom routines and how you work with families." — Orrinsford careers page, the classroom-routines topic | none given | none | [grounded] | discovery | Strong evidence would be a routine you set up or used, what it was for, how you taught it to students, and what you changed. Selection scaffold: pick one routine from your own classroom; if none comes to mind, say so plainly, then say how you would set one up. B5 rehearses that as a plan |
| F7 | Work with a grade-level team: a role-family expectation, written without a source; the invite puts two fourth-grade team members on the panel | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [generic] | presentation | Say the sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." The title is a separate fact: "I've never been a team lead." Say both as they stand; neither is offered as proof of how you work on a team |

## Reading the interviewer

Public professional footprint only. The two team members' names were not given, so nothing was researched about them.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page | [grounded] | Expect depth on reading instruction, which also matches the careers page's panel topics. B1, B2 and E3 are the rehearsal, and R1 is the reverse question tied to her path |
| Her 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | ilprincipalsforum.example speaker page | [grounded] | Only the one-line summary was read, not the talk. Use her vocabulary in B1 only where it matches what you would actually do, and do not imply you have seen the talk unless you have |
| Reading is her field; the sentence in your material nearest it is "I've run the after-school reading club for the last two years" (F3) | Her page above; your CV | [grounded] | Shared domain, not a shared career jump: your material carries no side of a jump, so none is offered. Say the sentence as it stands and let her ask |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Provenance | Counter-strategy |
|---|---|---|---|---|
| A. Skeptic | Quiet probing of the fourth-grade gap, and why this move, why here | High. The panel holds a principal (hiring-manager prior: Case plus Skeptic) and the biggest gap in the material is F2, which you stated yourself | [grounded] | Rehearse A1 until it is boring: plain acknowledgment, adjacent fact, a plan |
| B. Case/Strategist | Live problems on reading time, routines and a student who is behind | High. The district's careers page says panels ask about reading instruction and classroom routines, and the principal's public work is in reading | [grounded] | Clarify, objective, grouping, approach, how you would check it, risks; think aloud |
| C. Peer Evaluator | The two fourth-grade teachers asking where you fit and what you would need | High. Peers sit on the panel, and the peer prior is Peer Evaluator plus Prober | [grounded] | Reciprocity: what you would bring and what you would need; principles, not claims to know their seams |
| D. Values/Behavioral | Stories keyed to the district's three beliefs | Medium. The beliefs page says they guide every hire, but the careers page names no values round, so they are treated as themes and no values cheat sheet is built | [grounded] | Choose real stories; "we" for context, "I" for contribution; where none comes to mind, say so |
| E. Conversational | Opening biography and a casual question about the reading club | Medium. A panel usually opens warmly, and these questions are still scored | [generic] | A 90-second arc built only from your own sentences |
| F. Data-Driven Prober | Asking how you knew the curriculum worked | Low. The peer prior includes it, but your material carries no figures to defend, so it gets two questions | [grounded] | Say what you know and plainly what you do not |
| G. Pressure | Time-boxed challenge on the fourth-grade gap and on how much of the move was yours | Low. Nothing indicates a stress style; kept because the fourth-grade gap invites a short challenge | [generic] | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, not fourth. What will be hardest about the move?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Lead with the plain acknowledgment in your stated words: "I've never taught fourth grade." Then the adjacent fact at its own scope: six years teaching third grade at a public elementary school in Joliet. Then the hard part, as a plan and never as a past: name the one thing about the grade you most want to learn first and how you would learn it, in your own words; if you do not yet know what differs, say so plainly and say who you would ask. Do not claim fourth-grade experience or describe fourth graders for them. Hold through two follow-ups by returning to the third-grade sentence and the plan | F2 is the biggest gap and the question every panel member can ask; JD because it scores the role's own title, and the Skeptic delivers it quietly |
| A2 | "What would you do in your first month to get up to speed on fourth grade?" | JD | [generic] | A plan, so every sentence is future: what you would ask for first, whom on the team you would ask, what you would watch in the first weeks. Name nothing you have already done. If they ask about a curriculum you have not seen, say so plainly | F2 turned into a ramp question; [generic] because it is a pattern for the problem and makes no claim about your past |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name the weakness your material actually shows: "I've never taught fourth grade." Add one sentence on what you would do about it. If another real weakness comes to mind, say it in your own words; do not invent a modest-sounding one. A calibrated answer beats a bluff | F2 again, from a different angle, so the answer has to hold under rephrasing; JD because it scores fit to the listed job |
| A4 | "Why this move, and why Halvering?" | EXP | [grounded] | Give your actual reasons, in your own words; this pack does not know them and will not supply them. The district publishes three beliefs, Every Child a Reader, Families Are Partners and Teach for Tomorrow, Not for the Test, and the principal's public path is in reading. Use one only if it is a real reason for you, and say it as a reason, not a compliment | The motivation probe every Skeptic asks; EXP because it tests whether your story about your own choices holds, and F3 to F5 are where the beliefs touch your material |
| A5 | "A parent asks why a teacher who has never taught fourth grade is in front of their child. What do you say?" | CASE | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I write a weekly email to families" | Structure: acknowledge, ground, plan, invite. Acknowledge without defensiveness: "I've never taught fourth grade." Ground in the sentence you have: six years teaching third grade. Then what you would do to keep that parent informed, as a plan; you may say "I write a weekly email to families" as a fact, but do not say what families made of it | F2 and F4 meet here; CASE because it is a live problem with a hostile premise built in |

### B. Case/Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A class of fourth graders is reading at very different levels, and you have one reading block. How do you structure it, and what do you want to know first?" | CASE | [generic] | Think aloud in order: clarify (how long the block is, what data exists, what materials the team already uses), objective, how you would group students, approach, how you would check it is working, risks. Challenge one premise respectfully, such as whether one block is enough. These are options you would weigh, not claims about your past. If they steer toward small groups or conferences, use their words only where they match what you would do | The careers page lists reading instruction as a panel topic and the principal's work is in reading (see Reading the interviewer); CASE because it is a live problem |
| B2 | "A student joins your fourth-grade class reading well below grade level. What do you do in the first two weeks, and who do you involve?" | CASE | [grounded] | Structure: what you would find out first, what you would put in place, whom you would involve (the family, colleagues, and whatever support the school has, which you would ask about), and how you would know it is working. Plan only, no claim about students you have taught | The beliefs page frames reading as the district's first belief; CASE because it is a decision under uncertainty; F3 is the nearest evidence and this question asks nothing of it |
| B3 | "In August the board adopted a three-year literacy plan, with a new grades 3–5 reading curriculum from fall 2027. What would you want to know about it before it reaches a fourth-grade classroom?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what you know and how you know it. Only a one-line summary of the board item was read for this pack, so read the full item before Thursday and say only what you have read. Then your questions: what the curriculum is, when training happens, how the first year is staged. If the panel links it to your history, say the sentence as it stands, "I led our grade level's move to a new reading curriculum in 2024", and if asked what the move involved, describe what you did in your own words and say plainly which parts were not yours | The one question built on the district's current direction; CO because it tests homework, and F3 is the link the panel may draw |
| B4 | "How would you tell, week to week, whether your fourth graders are growing as readers, and what would you change when they aren't?" | CASE | [grounded] | Structure: what you would look at, how often, what decision it triggers, what you would stop doing. The district's own belief gives you a frame if you agree with it: "assessments inform teaching and never replace it". Plan only, no figures | F5 is silent in your material, so this rehearses the plan without claiming a past; the belief is the raising source |
| B5 | "It's the third week of school and transitions between subjects take ten minutes each. What do you do?" | CASE | [generic] | Clarify what the ten minutes consist of, diagnose, teach the routine directly, practice it, recheck, and say what you would drop if it fails. A plan, with no claim about routines you have run | F6: the careers page names classroom routines as a panel topic; [generic] because the problem is a pattern, not a fact about this school |

### C. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our fourth-grade team plans together. Where do you see yourself fitting in, and what happens when you disagree with the team?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity first: what you would bring and what you would need, and say you would want to learn how the team already plans rather than pretend to know its seams. Where the sentence helps, say it as it stands and no further. For disagreement, pick a real one with a colleague: what it was, what you said, how it ended, what you would do differently; if no such time comes to mind, say so plainly, then say how you would handle it | F7 is the team-work requirement; Peer Evaluator because two grade-level teachers sit on the panel |
| C2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | "We" for context, "I" for contribution. Say the move sentence as it stands, and say plainly which parts were shared or not yours. If a title comes up, "I've never been a team lead." Say the two together as they stand so neither is pulled out as a contradiction | F7 holds both quotes; EXP because it tests attribution honesty |
| C3 | "What could you give our team in your first month, and what would you need from us?" | JD | [generic] | Reciprocity, as a plan: offer only what you could truthfully offer, and name what you would need, such as the team's current materials and time in their classrooms. No claim about your past | The peer prior: they are pricing what you cost and contribute to their work; F7 for the team requirement |
| C4 | "What was your part in your grade level's move to a new reading curriculum?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say the sentence at its scope, then describe what you actually did in your own words. Where others did parts, or a part was not yours, say so plainly. Add no steps you did not take | The most-quoted line in F3 and F7, asked collegially; EXP because it checks what was yours |

### D. Values/Behavioral (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader is one of our beliefs. Tell me about a time a student struggled with reading and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: neither sentence carries a student story, so pick one real student situation, no names: what you tried, what happened, what you would change. "I" for what you did, "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the club or the move as the sentences state them, or how you would handle it | F3; VAL because the belief is the district's published language |
| D2 | "Families Are Partners: each teacher speaks with every family each term. Tell me how you've worked with families." | VAL | [grounded] "I write a weekly email to families" | Story-mapped on F4: the beats the sentence states are weekly, an email, to families. Say it in your own words. Answer slot: the belief makes a probe on the email's details likely. If any part of it was yours to set, such as what went in it or who received it, say which; if there was no such decision, or it was not yours, say so plainly and stay with the weekly email. Do not say what families made of it | F4 is the evidence, and the gap between an email and a conversation is the likeliest probe |
| D3 | "Teach for Tomorrow, Not for the Test. Tell me about a time assessment results changed how you taught." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: pick a real time: what the results showed, what you changed, what happened. Your material carries no such story. If none comes to mind, say so plainly, then give the nearest thing your material carries, the move sentence as it stands, or how you would use results as a plan | F5 is silent, so this is the honest-branch rehearsal |

### E. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: how did you come to teaching, and to this role?" | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc built only from those sentences: the license and endorsement, six years of third grade in Joliet, the move, the club, the weekly email. How you came to teaching, and why fourth grade now, are yours to tell; this pack has nothing on either and will not supply them | The biography opener is scored; F1 to F4 hold every sentence the arc may use |
| E2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Story-mapped on F3: the beats the sentence states are after-school, a reading club, two years. Tell it in your own words. Anything further a panel asks, such as what happens in a session or what changed, is answered only from what you actually did and saw; where you do not know or did not track it, say so plainly | A casual-register question that is still scored; F3 is its evidence |
| E3 | "What are you reading or trying in reading instruction these days?" | JD | [generic] | Name something real you have read, tried or are curious about. If nothing recent comes to mind, say so plainly and say what you would start with. Do not name a program you have not used | Persona stem on a hot topic: reading instruction is a panel topic and the principal's field |

### F. Data-Driven Prober (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "After your grade level moved to the new reading curriculum, how did you know whether it was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say the sentence. Answer slot: the district's belief that assessments inform teaching makes a probe on how it was checked likely. If your grade level looked at anything, assessment results, student work or something else, say what, in your own words, and which part was yours; if nothing was checked, or it was not yours, say so plainly and stay with the sentence. Offer no result you cannot say how you know | F3 and F5; no figure in your material, so this is the nearest thing to a defend-the-number question |
| F2 | "Which line on your CV would you defend least?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Choose from your own judgment and say plainly what the line states and what it does not. The pack's observation is that the two reading lines are stated without steps or results behind them. Naming your own weakest line first turns a gotcha into credibility | F3; a prober's version of the weakest-assumption move |

### G. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade"; "I've run the after-school reading club for the last two years" | Pause and restate the question. Open with what the sentences say, in your words: six years in third grade, the reading club. Concede plainly what is true: "I've never taught fourth grade." Make no claim about other candidates. Hold through two follow-ups by returning to the sentences; concede specifics, never fold on the core | F2 under time pressure; JD because it scores fit to the role |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold the sentence through two follow-ups: "I led our grade level's move to a new reading curriculum in 2024." Concede specifically which parts were shared or not yours. If they point at the title, say both as they stand: you led the move, and "I've never been a team lead" | F3 and F7; the stem is the stress version of C4 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license and endorsement | none, and why: it is a held term the material shows met, so it asks nothing; say it in the stated terms if confirmed |
| F2 fourth grade | A1, A2, A3, A4, A5, G1 |
| F3 reading instruction | B1, B2, B3, C4, D1, E1, E2, E3, F1, F2 |
| F4 families | A5, D2 |
| F5 assessment | B4, D3, F1 |
| F6 classroom routines | B5 |
| F7 grade-level team | C1, C2, C3, C4, G2 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You came to the principal's role after nine years as a reading specialist. What from that work do you most hope a new fourth-grade teacher carries into the reading block?" | Ties to her own path, and turns an interrogation into a conversation between people in the same field | [grounded] |
| R2 | "Your talk on weekly reading conferences in grades 3 to 5 stayed with me. How does that look in a fourth-grade classroom here?" | Shows you looked at her work, not just the school. Ask it only if you have read at least the abstract | [grounded] |
| R3 | "The board adopted a three-year literacy plan in August. What will the fourth-grade team's first year with the new reading curriculum look like, and where would a new teacher fit?" | A current-direction question that shows the homework in B3 | [grounded] |
| R4 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two peers: it shows you are thinking about their load, not only your own | [generic] |
| R5 | "Families Are Partners asks each teacher to speak with every family each term. How does the team make that happen day to day, and what supports a newcomer?" | Uses the district's own belief and shows you read it | [grounded] |
| R6 | "What does a strong first semester look like for someone new to the grade?" | Turns your biggest gap into a shared plan | [generic] |
| R7 | "References are taken up after the panel. What are the next steps, and when should I expect to hear?" | A process question with a prep reason: it tells you what follows Thursday | [grounded] |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | The plain acknowledgment F2 gives: "I've never taught fourth grade." No slot |
| Has been a team lead | A negative you stated, F7 | The plain acknowledgment F7 gives: "I've never been a team lead." No slot |
| Owned the new reading curriculum's rollout | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the move, not the rollout or its steps. The slots stay inside the move and the club |
| Has a reading plan in place for every student | Inflated form of F3 | F3's quotes at their own scope. The limit is the pack's observation: your material says the curriculum move and the club, not students' individual reading |
| Speaks with every family each term | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says a weekly email, not conversations with each family. D2's slot stays inside the email |

## Sources

**Provided:** the interview invite and the résumé text you pasted. A line of personal ID in your message was not used, and no license number went into any search or this file. No dossier was consumed.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three beliefs by name, from the fetched beliefs page. They raise the F3 to F5 rows and the D, B2, B4 and F1 questions; no values cheat sheet, since no loop source names a values round |
| 2. `Orrinsford Community School District interview process` | yes | One 45-minute building panel, principal plus two grade-level teachers, with named topics; it fixes the persona weights and removes the archetype fallback |
| 3. `Orrinsford Community School District strategic plan` | yes | The August 2026 board literacy plan, from the search result's summary only (the page was not fetched); it feeds B3 and R3 |
| 4. `Dolores Vantongeren principal Halvering Elementary School` | yes | The principal's career pattern and talk, from the search result's summary only; it feeds the interviewer read, B1 and R1 and R2 |
| 5. representative `fourth grade teacher` JD | yes | `fourth grade teacher job description Illinois elementary school` returned a job board listing. It moved nothing: its text is a search-result paraphrase, not a raising source, so no row or question rests on it |

Queries sent:

- `Orrinsford Community School District mission values` returned https://orrinsfordschools.example/about/mission-and-beliefs
- `Orrinsford Community School District teacher interview process panel` returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- `Orrinsford Community School District strategic plan` returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- `Dolores Vantongeren principal Halvering Elementary School` returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- `fourth grade teacher job description Illinois elementary school` returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/careers/how-we-hire-teachers

## Upgrade menu

- The full fourth-grade job posting → F6 and F7 become quoted requirements, and answer slots can attach where the posting raises them
- The names and roles of the two fourth-grade team members → a read on each peer and persona weights per panel member
- HR's prep note, if any, on format → a build section for any sample lesson, portfolio or prepared item they name
- Your own answers to the slots in F3, F4 and F5 → quoted evidence in the snapshot, with the rows and questions that draw on them regenerated
- A copy of your license record → F1 confidence from medium to high
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the full text of the board's literacy plan, recent district news and the principal's talk, for a grounding brief and sharper CO questions
- A tuesday-dossier.md from an earlier evidence review → verified evidence and prohibited claims carried in, and the objection worth the deepest rehearsal taken from it instead of inferred
