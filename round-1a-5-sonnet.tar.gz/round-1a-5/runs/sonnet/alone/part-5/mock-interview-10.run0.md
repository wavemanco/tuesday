I'm researching Lumenvale Software (its values, how it runs interviews, and recent news) before I build your prep pack. I'll write the pack once the results are in.
Web search was refused, so I'm building the pack from what you sent and marking anything it can't source. Writing it now.
Before the prep, one thing in the invite: it says "Our hiring process is fully remote and is carried out entirely on Telegram" and "your interview will be a text chat here with our support team lead, and if you are successful your offer and onboarding will be completed in this chat as well". A process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Until you've checked, don't pay anything or send documents or bank details through the chat. Check by finding Lumenvale's contact details on its own website or careers page, not through this chat, and ask whether the invite is theirs. The invite may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-5/rooms/case-10-denied-6200768a/lumenvale-software_customer-support-specialist_interview_pack.md`. I built it for one text chat with the support team lead, assuming they would be your line manager. Web search was refused, so the pack uses only what you sent. Anything I couldn't source is labelled `[generic]` or `[inferred]`. The pack has 20 questions, reverse questions, and a list of claims it won't coach.

The pack's main finding is that your Freshdesk, volume and training lines map well to the ad. The gaps are escalations, where nothing in your message shows an example. Zendesk is the other: you named Freshdesk, not Zendesk. The biggest is software-company experience, which you've said you lack. The most likely hard question is A1, "I don't see software-company experience in your background." The pack coaches you to say the limit plainly, then return to what you did do. Because the interview is typed, your written answers are the writing sample, so B2 has you practise a live written reply.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead the person you'd report to, and have you been told anything about what the chat will cover? Could you paste the full text of the ad? It would let me turn the `[inferred]` rows into grounded ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

- **Role:** Customer Support Specialist (remote), Lumenvale Software
- **Interviewer:** the support team lead, not named. Relationship assumed to be the person you would report to, so the pack is weighted as a hiring-manager round
- **Format:** one text chat on Telegram, per the invite's own words. Every answer you give is a piece of your writing, and it is scored as one

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. The guidance is scaffolding, not a script: say only what you did, in your own words, and where a cell says answer slot, answer from your real experience or say plainly it was not yours. Because the interview is typed, rehearse by typing short, clean paragraphs rather than speaking.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including the gaps |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem from the role, reasoned through |

Highest-ROI prep in this pack: **A1**, the software-company question. It is aimed at the one thing your material says you do not have, and it will be asked in some form.

## Fit snapshot

The requirements are the ad's, as you described them in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on years, but a line with nothing inspected behind it, so expect a probe. The ad says support and your title says service advisor, so give your title as it is and let the interviewer map it. Lead with the quote's own terms: the three years, the title, the energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your material names Freshdesk and not Zendesk, and the words stay there: "I use Freshdesk every day." Name the tool plainly and stop. Whether it is the ad's similar tool is the interviewer's call, so do not claim Zendesk |
| F3 | "clear written communication" — job ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows volume across calls and emails together, not how well you write. Answer slot: the ad's written-communication line, and an interview held entirely in writing, make a probe on how you write likely. If anything about how your written replies were judged is something you can speak to, say what it was; if nothing was, say so plainly and stay with what you can speak to |
| F4 | "confidence handling escalations" — job ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad's escalation line makes a probe likely. If you handled any, say what happened and what part was yours, in your own words; if none came to you, or they went to someone else, say so plainly and stay with the work you can speak to |
| F5 | familiarity with how a software company works (role-family, not in the ad as you described it) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn it, said as a plan and never as a past. Never a claim to software-company experience |
| F6 | teaching colleagues a process (role-family, not in the ad as you described it) | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap, but a CV-style line with nothing inspected behind it. Keep it at its own scope: you trained four new starters, on your refunds process, last year. Not a programme, not a team you led |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the software-company gap, Zendesk versus Freshdesk, the years, why this move | High. The invite describes one chat with the support team lead, and a hiring-manager round leans Skeptic plus Case. Your own message states one gap (F5) and your material shows nothing on escalations (F4), which pushes the Skeptic up | Rehearse A1 until it is boring. Say the limit in your own stated words, then return to what you did do |
| Case (B) | Live support scenarios you answer in writing | High. Same prior, and in a text chat the written answer to a scenario is the clearest sample of your writing they will get | Clarify, then acknowledge, then act, then say what happens next. Short paragraphs |
| Data-Driven Prober (C) | Reads your lines closely: the 60 a day, the four starters, Freshdesk | Medium. You gave three specific claims and a number, which invites a close read, but the role is not analytical | Know how the figure was counted, or say plainly you do not know |
| Conversational (E) | Friendly opening: the journey, a typical day | Medium. Most chats open this way and it is scored | Pre-write a short arc from your own sentences |
| Pressure (D) | Time-boxed or pushed challenges | Low to medium. A support lead may test composure on escalations, but nothing says this lead is a stress interviewer | Pause, restate, hold the position the quotes carry, concede only what is true |
| Values (F) | Behavioural stems | Low. No source I could read documents a values round, so these use the standard stems and are `[generic]` | Choose a real story or say plainly none comes to mind |

## Question banks

### A. Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see software-company experience in your background. How would you handle supporting a software product?" | EXP | [grounded] "I've never worked for a software company"; "I use Freshdesk every day" | Hold-then-concede, in three beats. Beat 1: "I've never worked for a software company." Beat 2: "I use Freshdesk every day." Beat 3: how you would get up to speed on the product, as a plan for your first weeks in your own words, never as something already done. On a follow-up, return to beats 1 and 2. Do not claim software or product experience, and do not concede more than the quote does | F5 is the biggest stated gap and this is the likeliest form of the objection. EXP because it tests whether your background survives the probe, with JD content |
| A2 | "The ad names Zendesk. Have you used it?" | JD | [grounded] "I use Freshdesk every day" | Say "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how much, in your own words; if you have not, say so plainly and stay with Freshdesk. Then, if you want, say how you would get up to speed on a new tool, as a plan | F2 maps Freshdesk to the ad's tool line and the interviewer decides whether it counts. JD because it scores a stated requirement |
| A3 | "The ad asks for 2+ years in customer support. Walk me through those years." | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day" | Tell it in the quotes' own beats: the three years, your title, the energy supplier, answering around 60 calls and emails a day. Use your title as written. Add nothing the quotes do not state | F1 is the evidence for the years requirement. The question is premised on F1's own quote, so it carries no slot |
| A4 | "Which part of this ad would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Choose honestly, from your own judgement, between the ad's lines. The pack's observation: your material shows no escalation work (F4), names Freshdesk and not Zendesk (F2), and states no software-company background (F5). Say the one you judge weakest, plainly, then the first thing you would do about it. Never close the gap with a claim | Skeptic stem. F4, F2 and F5 are where the ad presses hardest, so the honest answer is chosen in advance |
| A5 | "Why software support, and why now?" | EXP | [generic] | Instruction: give your actual reason in your own words, in one or two sentences. The pack does not supply one. Keep it to what is true for you | Motivation consistency is scored in a Skeptic round and no quote in your material states a reason |

### B. Case (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in furious: a software update broke their work and they want a manager now. How do you reply?" | CASE | [generic] | Structure it: what you would ask first (what happened, what they have tried, what it is costing them), an acknowledgement before any fix, what you can do now, what you cannot promise, when and how it goes to someone else, and when they will hear from you next. The question needs no claim about your past, so the guidance makes none | F4's requirement, asked as a decision. CASE with JD content. `[generic]` because it is a pattern for the problem |
| B2 | "Here is a customer's message: 'Your app logged me out and my saved reports are gone.' Write the first reply, now." | CASE | [generic] | Short and clean: acknowledge the problem, do not promise recovery yet, ask the one or two questions you most need answered, say what happens next and when. Plain words, no filler. This is your written-communication sample, so check spelling before you send | F3's requirement tested directly in the medium the interview uses. CASE delivery, JD content |
| B3 | "A customer asks about the product and you do not know the answer. What do you do in the next ten minutes?" | CASE | [generic] | Say you would not guess. Find out from the team or product material, tell the customer you are checking and when you will come back, then follow through. State the order you would do it in | Probes the software gap (F5) without naming it. Honest uncertainty is what is scored |
| B4 | "Your queue has twelve open tickets and three just arrived marked urgent. How do you decide what to do next?" | CASE | [generic] | Name your criteria aloud: customer impact, time sensitivity, what can be answered quickly. Say what you would check before reordering and what you would tell the waiting customers | Ticket handling is the day job and your tool experience (F2) is Freshdesk. CASE because it asks for structure, not an answer |
| B5 | "When do you resolve something yourself, and when do you escalate it?" | JD | [grounded] | Give criteria rather than a story: whether you have the knowledge and authority, the customer's risk, the time left. Then what a good handover contains: what happened, what has been tried, what the customer needs, and by when. Make no claim about escalations you have handled | The ad's escalation line (F4) raises it. JD because it scores the stated requirement, CASE in delivery |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around 60 calls and emails a day. How was that figure counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the figure as you gave it: calls and emails together, around 60 a day. Answer slot: say how it was counted if you know; if you do not know how it was counted, say so plainly. Say what it varies with, in your own words, and name the assumption behind it you would defend least before they do. Say which part was yours | F3 and F1 carry the figure, so a defend-the-number question is likely. EXP because it tests attribution |
| C2 | "Walk me through training the four new starters on the refunds process." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats the sentence states: four new starters, your refunds process, last year, and that you trained them. Tell it in your own words and add no further beat. If asked how much was yours, say which part was yours; if others did part of it, say so plainly | F6 is the only evidence of teaching others. EXP because it tests what was actually yours |
| C3 | "You use Freshdesk every day. What do you actually do in it?" | EXP | [grounded] "I use Freshdesk every day" | Say what you do in it, in your own words and only what is true. If most of it is answering tickets, say that plainly. Do not name features you have not used | F2 is a one-line claim, so expect a request for the detail behind it |

### D. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have sixty seconds: why you over someone who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I've never worked for a software company" | Pause first. Hold on what you did: "3 years as a customer service advisor at an energy supplier." Concede the limit in your stated words: "I've never worked for a software company." Do not say you are better. Hold through two follow-ups, returning to the same quotes | F1 and F5 are the pair this question sets against each other. Pressure delivery, JD content |
| D2 | "Thirty seconds: a time you handled an escalation." | JD | [grounded] | Selection scaffold: pick an occasion where a customer's issue needed more than you could resolve alone. It needs the customer's problem, what you personally did, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Hold your answer through two follow-ups and concede only what is true | The ad's escalation line (F4) raises it and no quote carries a story, so this is a scaffold. Time-boxed to test composure |

### E. Conversational (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | Write a short arc from those three beats in your own words. Then, in one or two sentences, say your own reason for this role. The pack does not supply one | F1, F2 and F6 are your whole story, so a casual opener is a scored one |
| E2 | "What does a typical day look like for you right now?" | EXP | [grounded] "answering around 60 calls and emails a day"; "I use Freshdesk every day" | Use those two beats and nothing else, in your own words. Anything beyond them only if it is true and yours | F3 and F2 are the day-to-day evidence. A casual question still tests economy |
| E3 | "What makes a written reply to an upset customer a good one?" | JD | [generic] | A view, not a story: acknowledge the problem, answer what they actually asked, say what happens next and when, keep it short. It asks nothing about your past, so the guidance claims nothing | The ad's written-communication line (F3), asked casually. `[generic]` because it is a pattern |

### F. Values (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a choice you made, and an outcome you can state truthfully. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem. No published values were available to me, so this is not mapped to any of the company's own |
| F2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs what you said, how they reacted, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem, included so you do not meet the style cold. `[generic]` |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | A3, E1 |
| "experience with Zendesk or a similar ticketing tool" | A2, C3 |
| "clear written communication" | B2, E3, and the chat itself |
| "confidence handling escalations" | B1, B5, D2 |
| Software-company familiarity (role-family) | A1, A4, D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first month look like for someone new on the team?" | Shows you are thinking about contributing from the start, and tells you the bar |
| R2 | "Which tools does the team work in day to day, and how long does onboarding on the product usually take?" | Turns your tool and software questions into curiosity, and tells you the real ramp |
| R3 | "How are escalations handled here: who takes them, and what does a good handover look like?" | Shows interest in the part of the ad you have least evidence for, and gives you their vocabulary |
| R4 | "How does the team judge good support, beyond ticket volume?" | Written quality and care are scored, and their answer tells you what to emphasise |
| R5 | "Will there be another stage after this chat, and in what format?" | A process question with a prep reason: it tells you whether to prepare for a call or a live exercise |
| R6 | "What is the hardest thing about supporting the product right now?" | Invites an honest conversation and shows you expect the work to be hard |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk. A2's slot lets either branch be true |
| Has software-company or software-support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Led or ran a training programme, or managed a team | Inflated form of F6 | F6's quote at its own scope: four new starters, your refunds process, last year. C2's slot asks only which part was yours |
| Answered around 60 emails a day, or any split of the figure | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day". The limit is the pack's observation: the figure counts calls and emails together |

## Sources

Provided documents: your message (the invite's text, the ad's four requirements as you described them, and your background). No dossier was provided.

Searches sent, all refused: "Lumenvale Software company values", "Lumenvale Software interview process customer support specialist", "Lumenvale Software news strategy". No pages were fetched. Nothing in this pack comes from outside what you sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Every call was refused. It would have supplied the company's own value names for a values cheat sheet and mapped VAL questions. Section F uses standard stems instead |
| 2. `Lumenvale Software interview process customer support` | unavailable | Every call was refused. It would have shown whether other rounds follow. The one session is established by the invite's own words, so the persona weights rest on that |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO question and the product-side CASE questions, which are `[generic]` as a result |
| 4. `{interviewer name} Lumenvale Software` | n/a | The team lead is not named, so there was no query to form. The interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you gave fix the fit snapshot and the JD-tagged questions. The full ad text would add to them |

## Upgrade menu

- The full text of the ad → any further requirements become rows, and `[inferred]` rows such as F3 become `[grounded]`
- The team lead's name and role → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their path
- Anything you are told about the format, such as a writing exercise or a focus area → coverage and a build section for any announced deliverable
- Your answers to the answer slots in F3, F4, A2 and C1, given outside a drill → F3 and F4 move from silence to quoted evidence and A2 and C1 become story-mapped
- A CV, or a performance review or quality-score report from your current job → F1, F2, F3 and F6 move from medium or low confidence toward high
- The company's careers page, values page or product description, pasted in → a values cheat sheet if a values round is documented, and CO questions grounded in what the company says
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, if search access is granted → a strategy brief and role-family loop reports
- A `tuesday-dossier.md`, if you have one → verified evidence and the strategy limits on your weak areas
