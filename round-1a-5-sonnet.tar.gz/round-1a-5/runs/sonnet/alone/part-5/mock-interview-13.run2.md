Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-5/rooms/case-13-denied-5396b711/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for Hannah's recruiter screen from the advert, your description of your background, and her message. It covers her four topics (pay, notice, hybrid, why you're moving) and the gaps in the advert.

The web searches I tried on Quillmoor and Hannah were refused, so the pack has nothing on Quillmoor beyond the advert. The Sources section lists the searches, and the upgrade menu says what permission to search would add.

SAP is the likeliest hard question, because the advert names it and you've said you haven't used it. The pack calls B2 your highest-ROI rehearsal.

Say the word and I'll play Hannah on B2.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What's your notice period at the wholesaler? You didn't mention it and Hannah has it on her list. Until you tell me, the pack leaves it as an instruction in A2 and marks it unestablished in F12.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday at 2pm
**Interviewer:** Hannah Lowther, Talent Partner (recruiter). Her own agenda, from her LinkedIn message: "I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."
**Version:** first pack, no changes yet.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Every question carries both, so you can see where your preparation is thin.
- Guidance is scaffolding, not a script. Say it in your own words. Anything in quotation marks in a Provenance cell is something you said to me, and the guidance goes no further than that sentence.
- An answer slot is an instruction for the interview. It asks nothing of you here. A logistics slot (pay, notice, location, reason for leaving) is filled by your own words only.
- Provenance labels: `[grounded]` traces to a document or statement you gave me. `[inferred]` is this pack's derivation, named. `[generic]` is a role-family pattern with no claim about Quillmoor or about you.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

No VAL or CO questions appear. No source here names a values round, and company research could not run (see Sources).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says depot deliveries, not production schedules, and nothing inspected sits behind it. The words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you worked with likely. If you worked with teams like that, say who and what you agreed, in your own words; if not, or it was not yours, say so plainly and stay with the depot deliveries |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Scheduling deliveries to depots is not shown to be tracking what suppliers deliver. Answer slot: if you keep track of supplier deliveries, say how, in your own words; if you do not, or it is someone else's, say so plainly and stay with scheduling the depot deliveries and chasing suppliers |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms: "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a probe. Keep the number on what it counts: discrepancies, about a third, over a year. The four slots a figure raises are in C1 to C3 and E2 |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show reporting. Answer slot: if you report on deliveries or dispatch, say what, how often and to whom, in your own words; if you do not, or it is not yours, say so plainly and stay with scheduling deliveries and chasing suppliers |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Say it in the sentence's own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not Excel, and does not show what you did in it. Answer slot: if it was Excel, say so and what you did in it, in your own words; if it was another tool, or little of the work was yours, say so plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert marks ERP as "a plus" |
| F9 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your sentence names an in-house stock system and does not show whether you work in it or whether it is like an ERP. Answer slot: if you work in it, say what you do in it, in your own words; if you do not, or it is not comparable, say so plainly |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | No gap. Your figure sits inside the advert's band. Your own words are the whole slot |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap. Your own words are the whole slot |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and Hannah has it on her list. A2 holds the slot; this pack supplies no figure |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, B3, D2 |
| Track supplier deliveries | B1, D1 |
| Chase late orders | A5, D1, E1 |
| Keep stock records accurate | A5, C1, C2, C3, E2 |
| Report weekly on on-time dispatch | B4, D3 |
| 2+ years in operations or logistics coordination | A5, B3, E1 |
| Confident with Excel | B5 |
| ERP experience (SAP or similar) | B1, B2, E1 |
| £38,000–£44,000 | A1 |
| Hybrid, two days at Avonmouth | A3 |
| Notice period | A2 |
| What's prompting a move | A4 |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (bank A) | Friendly, unstructured; Hannah's four logistics topics and an opener about your current role | High. Her own message lists pay, notice, hybrid and the reason for moving, and the prior for a recruiter screen is conversational logistics plus motivation-consistency `[generic]` | Give each logistics answer in your own words and stop. Build the A5 arc from its three quoted sentences only |
| Skeptic, light (bank B) | Quiet probing of the advert's gaps: SAP, wholesaler to manufacturer, reporting, Excel | Medium-high. The advert names SAP and Excel, and your material carries a stated SAP negative (F8) | Rehearse B2 until it is boring. Bridge only from the sentences you gave, and say the limit plainly |
| Data-Driven Prober (bank C) | Asks how "about a third" was counted | Medium. Quantified claims draw probes, and a recruiter screen may test one lightly `[generic]` | Say how it was counted if you know; say plainly if you do not |
| Case / Strategist (bank D) | A live supplier or scheduling problem | Low on this call: Hannah's message lists no case. Higher in a later round with a hiring manager, though no source here describes later rounds `[generic]` | Clarify, then structure, then answer. The cases make no claim about your past |
| Pressure (bank E) | Sixty-second challenges on SAP and attribution | Low. A recruiter screen rarely time-boxes, but a knock-out check can arrive curt `[generic]` | Pause, restate, hold on what your sentences carry, concede the SAP gap in one specific sentence |
| Values / Behavioural, Peer | Not planned | Not weighted: no source names a values round, and Hannah is not a peer | None needed |

## Question banks

Highest-ROI prep in this pack: **B2**, the SAP question. The advert names SAP, and you have told me you have not used it, so it will be asked in some form.

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled by your own words: "I'm hoping for £42,000." Say it once and stop. If asked what you earn now, decline with no figure: "I'd rather focus on the range for this role." | F10 is the pay row. JD because it scores the advert's stated band; Hannah named it first on her list |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words, as your contract states it. Your material does not give one, so this pack supplies none | F12 is the gate row. Hannah named it; JD because notice is a term of the job |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled by your own words, the sentence above. If she asks about the commute or a third day, your own words were that same sentence. Nothing added | F11 is the location row. JD because the advert states the pattern |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, filled by your own words: the Bristol office is closing next year, the only offer is relocating to Reading, which you don't want. If she returns to it, your own words were: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Nothing added | Hannah named it. Recruiter screens score whether the reason is consistent; EXP because it tests what your actual reason is |
| A5 | "Tell me about your current role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with only the beats the sentences state: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for your three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Tell it in your own words and stop. Add detail only if you can stand behind it aloud | F6, F3 and F4 are the rows it draws on. EXP because casual opener questions are still scored for economy |

### B. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would be your weakest on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Name your own weakest part first, before she does. Your material points to two candidates: the SAP line, in your own words "Never used SAP — we run our own in-house stock system.", and the production-schedules line, where your sentence is about depot deliveries. Pick the one you honestly find weaker, then say how you would close it, as a plan and never as a past | F8 and F1 are the two largest gaps. JD because it asks you to read the advert against yourself |
| B2 | "Have you used SAP or anything like it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The deepest rehearsal. Level 1, hold: "I've never used SAP." Then the other half of your sentence at its own scope: your company runs its own in-house stock system. Answer slot: the advert says "SAP or similar", so expect a probe on the in-house system. If you work in it, say what you do in it, in your own words; if you do not, or it is not comparable, say so plainly. Level 2, "how would you pick it up?": say how you would go about learning it, as a plan, and promise no speed. Level 3, "so that's a no on ERP?": concede the SAP gap in one specific sentence, return to the in-house system sentence, and add no experience | F8 is the stated gap and F9 the open half. It will be asked because the advert names SAP; JD because it scores a listed requirement |
| B3 | "The role is at a diagnostic-test manufacturer and your background is a building-supplies wholesaler. How would your experience transfer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what the sentences say: four years as a logistics coordinator; you schedule deliveries for three depots and chase suppliers when orders slip. Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If you worked with teams like that, say who and what you agreed, in your own words; if not, or it was not yours, say so plainly and stay with the depot deliveries. Do not call the work production scheduling; let her draw any inference | F1 and F6. JD because it tests whether the listed job's core duty is reachable from your background |
| B4 | "The role includes a weekly report on on-time dispatch. Have you produced reports like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot, F5: if you report on deliveries or dispatch, say what, how often and to whom, in your own words; if you do not, or it is not yours, say so plainly and stay with scheduling deliveries and chasing suppliers | F5 is the requirement with no evidence. JD because the advert lists it |
| B5 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the sentence says: you rebuilt the stock-count spreadsheet. Answer slot: if it was Excel, say so and what you did in it, in your own words; if it was another tool, or little of the work was yours, say so plainly. Do not describe features you have not used | F7. JD because the advert asks for Excel confidence |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say how it was counted, in your own words; if you do not know, say so plainly rather than reconstructing it. Keep the number on its noun: discrepancies, about a third, over a year. Do not turn it into a precise percentage | F4. EXP because it tests whether the headline figure survives |
| C2 | "What is that figure most sensitive to?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if you know something the figure moves with, say it in your own words; if you have not looked, say so plainly | F4. EXP because sensitivity is one of the four slots a figure raises |
| C3 | "Which assumption behind 'about a third' would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The weakest-assumption move: name, in your own words, the assumption you would defend least before she does. If none comes to mind, say plainly that you do not know how the figure was counted, and say what you would check | F4. EXP because naming your own weak point turns a gotcha into credibility |

### D. Case / Strategist (low on this call)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that an order the warehouse needs on Thursday will be four days late. What do you do?" | CASE | [generic] | Clarify first: what the order feeds, who depends on it, and whether a part delivery or an alternative exists. Then the objective, the options, who to tell and when, how you would record it, and what you would check next. The question needs no claim about your past, so the guidance makes none | The advert's supplier-tracking line (F2, F3), asked as a decision. [generic] because it is a pattern for the problem |
| D2 | "Two production runs need the same warehouse slot and QA time. How do you decide which goes first?" | CASE | [generic] | Clarify the constraints and who owns priority. Propose principles for the trade-off rather than pretending to know the seam between teams, and say you would bring the trade-off to planning. No claim about your past | The advert's planning, warehouse and QA line (F1), asked as a decision |
| D3 | "On-time dispatch fell last month. How would you work out why?" | CASE | [generic] | Define the measure first: what counts as on time and from when. Then split it by where the delay arises, compare with earlier weeks, and form and test hypotheses. No claim about your past | The advert's weekly dispatch report (F5), asked as a diagnosis |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I move you forward when you haven't used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. Hold on what the sentences carry: four years as a logistics coordinator; you schedule deliveries for three depots and chase suppliers when orders slip. Concede the one specific gap: "I've never used SAP." Hold through two follow-ups by returning to those sentences, and let the concession stay as narrow as SAP | F8 and F6. Pressure tests whether you stay level; JD because it scores the same requirement as B2 |
| E2 | "How much of that fall in discrepancies was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Anchor on the sentence: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Answer slot: if other people or other changes contributed, say what, in your own words; if you cannot separate them, say so plainly. Do not claim the rebuild alone caused the fall, and do not shrink it either | F4. EXP because attribution probes exist to catch inflation |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first three months look like in this role?" | Moves from screening to the work, and gives you the success measure before the next round |
| R2 | "Which systems does the team work in day to day, and how are new starters trained on them?" | The advert lists SAP or similar as a plus; this asks about the ramp without raising your gap yourself |
| R3 | "Who does the role work with most across planning, the warehouse and QA?" | Uses the advert's own three teams and shows you read it |
| R4 | "Is this a new position or a replacement, and how big is the team around it?" | Tells you what you would be joining, and is a normal recruiter-answerable question |
| R5 | "What does the hiring manager see as the biggest challenge in the role right now?" | Gets the manager's priority through Hannah before you meet them |
| R6 | "After this call, who would the next conversation be with, and what would it cover?" | Lets you prepare the right persona bank for the next round |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says depot deliveries, not production schedules. B3's slot stays inside the depot deliveries |
| Confident in Excel, or built the stock-count tool in Excel | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." B5's slot asks only what tool it was |
| Cut discrepancies by a third through the rebuild | Inflated form of F4 | The quote at its own scope: "about a third over a year". E2's slot asks only which part was yours |
| Has SAP experience | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never used SAP." No slot |
| A pay range, a floor or room to move on £42,000 | You gave one figure, F10 | Your own words: "I'm hoping for £42,000." |
| Willingness to be on site more than three days a week | Contradicted by F11 | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

## Sources

**Provided documents:** the advert text as you pasted it; your own description of your background and what you would tell Hannah; Hannah Lowther's LinkedIn message. Hannah's message is the loop source: it establishes this one 30-minute phone call, and no source describes any later round.

**Searches sent, all refused (the host did not grant permission to search):**

- "Quillmoor Diagnostics company values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth Bristol news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have moved a values cheat sheet only if a source named a values round, and none did |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have described the rounds after this call, so persona weights for later rounds rest on no documented process |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO question, so none is in this pack |
| 4. `{interviewer name} {company}` | unavailable | Every call was refused. It would have supplied Hannah's public professional footprint, so the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to run web searches → the four targets above; a Quillmoor-specific CO question; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) for a strategy brief and later-round reports
- Your notice period → A2 and F12, which stay unestablished until you give it
- Your own words on the answer slots under F1, F2, F5, F7 and F9 → those rows and B1 to B5 regenerate with what you say
- The stock-count spreadsheet itself, or a before-and-after discrepancy report → F4 and F7 can move from `medium` and `low` toward `high`, and C1 to C3 get your own counting method
- A sample of any delivery or dispatch report you produce → F5 and B4
- Hannah's description of the next stage, or her LinkedIn profile text → persona weights for the following round and a tailored reverse question
- A tuesday-dossier.md from job-underwriter, if you already have one → an evidence-derived top objection and verified prohibited claims, in place of the ones this pack inferred
