Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says that with the cheque for €1,850 "you deposit the cheque and send the balance on to the vendor". Fees, passport and bank details before any offer, and a cheque you pay on from, are a known scam pattern, and these requests are very likely a scam. Hold all three, and the interview slot, until you have checked the invite with the employer using a phone number or address from its own website or careers page, not the sender's email or anything in the invite. If you have already paid or sent anything, call your bank using the number on your card. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /var/tmp/tuesday-measure/1a5/runs/sonnet/alone/part-5/rooms/case-12-denied-c81a4cc9/Brennock-Facilities_remote-administrative-assistant_interview_pack.md. It has 18 questions, a fit snapshot against the duties you listed, a prohibited-claims table and six reverse questions. I built it as a hiring-manager-style round, since the interviewer is the office manager on a 30-minute call.

Two things limit it:
- **No company research.** The web searches were refused, so nothing in the pack comes from the company's own published material. The company question (C2) is generic, and the persona weights rest on your description of the call.
- **Thin material on you.** The ad and your background came from your message, not a full ad or CV. Several rows say "none given" and ask you to answer from your own experience.

The most important question to rehearse is B1, about supplier invoices. You chased unpaid invoices, and the ad says processing supplier invoices. Say plainly what you have and haven't done there, and don't stretch it.

Say the word and I'll play the office manager on B1 so you can practise it live. I can also save a tuesday-dossier.md recording the gaps this prep exposed, or turn the pack into a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: a 30-minute video call, one session. Built as a hiring-manager-style round, because an office manager running a short call for an admin role most likely screens for day-to-day fit; if that is wrong, the persona weights below change.

## How to use this pack

- Personas describe how a question arrives (the style of the person asking). Types describe what is being scored. Each question carries both.
- Type key: VAL is behavior against published values (none detected in this pack). EXP is a deep-dive on what you actually did. JD is the stated role requirements. CO is knowledge of the company. CASE is a live problem from the job.
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", it tells you what to say about your own experience only if it is true, and gives the plain alternative if it is not.
- Highest-ROI prep in this pack: question B1, the supplier-invoice question. It is the likeliest place the interview presses.

## Fit snapshot

The requirements are the ad's duties as you relayed them. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you relayed it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your words already reach the requirement in other terms, so keep them: "I ran the appointment book for four physios." The ad says calendars and you say appointment book; use your own term and let the interviewer make the link. Answer slot: expect a probe on how the book was run day to day. Say what you did and which parts were yours, in your own words; if some parts were set by others, say so plainly |
| F2 | "booking travel" — the ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: if you have booked travel for anyone, say for whom and what you booked, in your own words; if you have not, or it was not yours, say so plainly and say how you would go about learning it |
| F3 | "preparing documents in Word and Excel" — the ad, as you relayed it (Word) | "I'm good with Word" — your message | low | [grounded] | discovery | Keep the words at their scope: "I'm good with Word." Your material says a self-rating, not what you prepare in it. Answer slot: expect a probe on what documents you prepare. Name them in your own words; if your use is mostly basic, say so plainly |
| F4 | "preparing documents in Word and Excel" — the ad, as you relayed it (Excel) | "okay with Excel" — your message | low | [grounded] | discovery | Keep the words at their scope: "okay with Excel." Do not round it up. Answer slot: say what you do in it, in your own words; if it is no more than basic use, say so plainly, then say how you would build it up. The learning is a plan, not a past |
| F5 | "processing supplier invoices" — the ad, as you relayed it | "chased unpaid invoices" — your message | low | [grounded] | transferability | Your words stay at their own scope: "I chased unpaid invoices." The pack's observation is that your material says chasing unpaid invoices, not processing supplier invoices, and does not show which side of the invoice you were on. Answer slot: if any of your invoice work involved invoices you received and passed on, say what it involved; if it was only chasing unpaid ones, or you never handled supplier invoices, say so plainly and stay with chasing |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | discovery | Your material does not show remote or home-based work. Answer slot: if you have worked on your own or from home, say what that looked like, in your own words; if not, say so plainly and say how you would set up a working day alone |

## Persona table

The loop rests on your own words (one 30-minute call with the office manager) and no company source, so weights come from the hiring-manager prior, adjusted for a short admin-role call.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Small practical problems from the ad's duties: a double-booked hour, a trip to arrange, a mismatched invoice | High. Hiring-manager prior, and the ad's four duties are all easy to turn into a live scenario in 30 minutes | Clarify first, then say your steps aloud. Claim nothing about your past in a case answer |
| B. Skeptic | Probing the clinic-to-admin move, the invoice duty, Excel, and working remotely | High. The fit snapshot has one transferability row (F5) and four discovery rows, and a skeptic goes where the material is thin | Rehearse B1 until it is boring. Say plainly what you have not done, and give a concrete way you would learn it |
| C. Conversational | Friendly opener: the journey, what you know about them | Medium. A 30-minute video call usually opens casually, and casual questions are still scored | Have a 90-second arc ready, built only from your own sentences |
| D. Data-Driven Prober | Line-by-line on the appointment book and the invoice chasing | Medium-low. An office manager may check details of the work you describe | Know what was yours and what was not, and say "I don't know" where you don't |
| E. Pressure | A short sharp challenge: why you rather than someone experienced | Low. Unusual for this kind of role, but cheap to rehearse | Pause, restate, hold your position through two follow-ups, concede only what is true |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers ask for the same hour in the diary. How do you decide, and what do you say to each?" | CASE | [generic] | Structure it: find out what each meeting is for, ask who sets priority between them, check whether either can move, offer the second person alternatives, tell both what was decided and why. The question needs no claim about your past, so the guidance makes none | Live version of the ad's calendar duty (F1's requirement). CASE because it scores structure, not history |
| A2 | "A manager needs a three-day trip booked and leaves tomorrow. What do you need to know first?" | CASE | [generic] | Clarify before you book: dates and times, budget and approval, traveller details and preferences, who pays, what must be flexible. Then say how you would present two options and confirm before booking. No claim about your past is needed | Live version of the ad's travel duty (F2's requirement), where your material is silent. A case answer lets you show method without a past claim |
| A3 | "An invoice arrives that does not match what was ordered. Walk me through what you would do." | CASE | [generic] | Say your steps: compare the invoice with the order, note exactly what differs, ask the person who approved the order and the supplier, hold it until it is resolved, and keep a record of who said what. Ask what the company's own process is rather than assuming one | Live version of the ad's invoice duty (F5's requirement). Hardest area for your material, so a method answer is the safe footing |
| A4 | "You have forty supplier invoices to track in a spreadsheet. How would you set it up?" | CASE | [generic] | Describe only what you could do today: columns for supplier, amount, due date and status, a way to sort and filter. Where you are unsure of a feature, say you would look it up rather than naming one you have not used | Live version of the ad's Excel duty (F4's requirement). Rehearsing it aloud shows where your skill ends before the interviewer finds out |
| A5 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the appointment book, and the four physios, which are the beats the quote states. Tell them in your own words. Answer slot: expect a probe on how the day to day worked. Say what you did and which parts were yours; if some parts were set by others, or there was no such step, say so plainly and describe how you ran the book | F1 is your clearest evidence for the calendar duty. EXP because it tests what was actually yours |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is a physiotherapy clinic. What makes you think you can handle supplier invoices?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold what the quote carries: "I chased unpaid invoices." Answer slot: if any of your invoice work involved invoices you received and passed on, say what it involved, in your own words; if it was only chasing unpaid ones, or you never handled supplier invoices, say so plainly and stay with chasing. Hold through two follow-ups by returning to what you did, never by adding to it. Close with a plan for learning the rest, said as a plan | F5 is the biggest gap against the ad's duties, so this objection arrives in some form. JD because it scores the stated requirement. Deepest rehearsal because it aims where the material is thinnest |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Choose from your honest list, using F2, F4 and F5 as the likeliest candidates. Name one, say plainly where you stand today, and give one concrete way you would close it in the first weeks. If you cannot pick, say so and give the nearest one | Standard Skeptic stem. Candid self-assessment is what it scores. JD because it maps to the ad's duties |
| B3 | "Why are you looking to leave the clinic?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Logistics slot: give your actual reason in your own words, in one or two sentences, pointing forward rather than back. The quote gives only the two years and the role, so the pack supplies no reason | Motivation-consistency probe from the clinic-to-admin move. EXP because it tests whether your story holds together |
| B4 | "This is a remote role. When have you worked on your own without anyone beside you?" | VAL | [grounded] | Selection scaffold: pick a stretch where you worked without a colleague nearby. It needs a named task, how you kept on track, and who you checked in with. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set up a working day alone | The role title is "Remote" (F6). Open prompt, so it supplies no event. VAL because it scores self-direction rather than a skill |
| B5 | "You said you're okay with Excel. What can you actually do in it today?" | JD | [grounded] "okay with Excel" | Hold at the quote's scope: "I'm okay with Excel." Answer slot: say what you do in it, in your own words; if it is no more than basic use, say so plainly, then say how you would build it up. Do not name a function you have not used | F4 is the Excel evidence and the ad names Excel. JD because the interviewer is checking a stated requirement |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | A 90-second arc with only the beats you have given: two years as a receptionist at a physiotherapy clinic, then why this role, in your own words. Keep it to three or four sentences and stop | The opener of most calls. EXP because it sets the story every later answer is checked against |
| C2 | "What do you know about us?" | CO | [generic] | No company facts were established for this pack, because the research searches did not run (see Sources). Read what the company publishes about itself before the call and say only what you read there, in your own words. If you found little, say so plainly and ask the interviewer to tell you more | Homework check. `[generic]` because nothing about this employer was researched, so the pack supplies no company facts |
| C3 | "Tell me about a time you were juggling several people's requests at once." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the appointment book, and the four physios, which are the beats the quote states. Answer slot: if any of them wanted the same slot, say what you did and which part was yours; if that never happened, say so plainly and stay with the book you ran | The ad's calendar duty is the raising source for the theme. EXP because a story is tested against what you did |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through what you did when an invoice stayed unpaid." | EXP | [grounded] "chased unpaid invoices" | Tell it at the quote's scope: you chased unpaid invoices. Answer slot: say what the chasing involved, in your own words; if there was no set routine, or part of it was someone else's job, say so plainly and describe what you did | F5's evidence is the only invoice material you have given. EXP because it tests the detail behind a one-line claim |
| D2 | "How much of the appointment book was your call, and how much was set for you?" | EXP | [grounded] "I ran the appointment book for four physios" | Answer slot: say which decisions were yours and which were set by the physios or the clinic, in your own words; if you followed rules set by others, say so plainly. The quote says you ran the book and nothing about who set its rules | Attribution probe on F1. EXP because it tests precision about what was yours |
| D3 | "How do you check your own work before a document goes out?" | JD | [generic] | Selection scaffold: pick a way you really check, such as reading it aloud, comparing figures to the source, or having someone else look. If you have no routine yet, say so plainly and say what you would start doing | The ad names document preparation (F3's requirement). Open prompt, so it supplies no event |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has done supplier invoices for years?" | JD | [grounded] "chased unpaid invoices" | Pause, restate the question, then hold what the quote carries: "I chased unpaid invoices." Hold through two follow-ups. Concede only what is true. Answer slot: if you have not processed supplier invoices, say so plainly, then say how you would learn it, as a plan | Pressure version of B1, so the same concession wording is rehearsed under time. JD because it scores the invoice requirement |
| E2 | "If I offered you the job today, what would you want to know before saying yes?" | JD | [generic] | Have a short list ready: pay, working hours, who you would report to, how the work is set up day to day, and what the first weeks look like. Ask them plainly. Do not give a salary history | Closing-style question that tests whether you have thought about the job. `[generic]` because it carries no claim about your past |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "managing calendars" | A1, A5, C3, D2 |
| "booking travel" | A2, B2 |
| "preparing documents in Word and Excel" | A4, B5, D3 |
| "processing supplier invoices" | A3, B1, B2, D1, E1 |
| "Remote Administrative Assistant" | B4, B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you are thinking about doing the job well, and the answer tells you what they weigh most |
| R2 | "Which tools do you use for calendars, travel and invoices, and would I be trained on them?" | It gets at F2, F4 and F5 without claiming any of them, and shows you would learn their way of working |
| R3 | "Who would I report to day to day, and how do you stay in touch with someone working remotely?" | A remote role depends on the working relationship, and it signals you have thought about working alone (F6) |
| R4 | "How are supplier invoices approved here, and who would I check with when one looks wrong?" | It shows care about getting invoices right, and it is the question B1 and A3 point toward |
| R5 | "What happens after this call, and is there anything I should prepare?" | It makes the next step clear and lets you prepare for it |
| R6 | "What takes up most of the week in this role?" | It shows interest in the real work and tells you which of the four duties dominates |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for senior staff or a whole office | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says an appointment book for four physios, not wider calendar management |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: your material says chasing unpaid invoices, not processing supplier invoices |
| Strong or advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel." The limit is the pack's observation: your material says okay, not advanced |
| Expert Word skills | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word." The limit is the pack's observation: your material says good, not expert |

## Sources

Provided: your message, which held the invite text, the ad's duties as you described them, and your background. Nothing was pasted as a full ad or a CV, so requirements and evidence are quoted from your message.

Searches sent:

- "Brennock Facilities Ltd values" — refused
- "Brennock Facilities Ltd interview process administrative assistant" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. It would have fed a values cheat sheet, which is dropped here |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | The search was refused. It would have documented the loop. The persona weights rest on your own description of the call and on the hiring-manager prior |
| 3. `Brennock Facilities Ltd strategy` and recent news | unavailable | No call was sent, because search permission was refused on the first two. It would have grounded a company-strategy question, so C2 is `[generic]` |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. representative `Administrative Assistant` JD | skipped | The ad's duties as you relayed them fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the five requirement quotes in the fit snapshot become the ad's own words rather than your relay of them, and any duty you did not mention gets a row and a question
- Your CV, or a few more lines on the clinic job → rows F2 to F6 can move from "none given" to quoted evidence, and the answer slots in B1, B5 and D1 can become story-mapped answers
- Your own answers to the answer slots in F1 to F6 → each row's bridge firms up, and the matching bank questions regenerate
- The office manager's name, and anything the recruiter said about what the call will cover → persona weights read from their public footprint, and a reverse question tied to their path
- Permission for web search → the values, loop and strategy targets in Sources can run, and C2 can be grounded in the company's own published material
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a strategy brief and recent organization context for the CO questions
- A tuesday-dossier.md → recorded gaps and verified evidence from earlier sessions, which would sharpen the highest-ROI objection and set firm limits on the guidance
