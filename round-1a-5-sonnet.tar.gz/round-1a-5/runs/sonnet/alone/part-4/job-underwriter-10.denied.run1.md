Loading the search tool, then I'll run the research targets: Fernquay's site, a salary sweep, and Ronan Kehoe's public professional footprint.
**Yes, it's worth pursuing, and you should take the call. I can't establish Fernquay from here, so treat it as conditional on a few checks. Status: `conditional_go`.**

On "is it legit": my searches were refused, so I couldn't confirm Fernquay exists as the posting describes. What the message actually asks of you is a 45-minute video call. It asks for no payment, ID or bank details.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52–60k)
- `must_have`: direct: R3, R4, R5, R6
- `important`: adjacent: R7 (Own booking flow end to end), R8 (First designer, no design peer)

R7: checkout is one part of a booking flow. R8: a bridge, its limit named. R2: awaiting your pay floor.

**Opportunity ledger.** The posting's terms are specific, but the employer isn't established (RR1), and equity terms (RR2), first-year outcomes (RR3) and runway (RR4) are open. The terms it does state are transparent (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52–60k); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies, meaning a live posting on their own site and an invite from a company-domain address (RR1); (2) the pay meets your floor (R2); (3) the first-designer gap is framed honestly as a bridge, never as sole-designer experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person Galway company making booking software for sea-kayak and surf schools. Not independently established; you report finding little online | `[grounded]` posting and your report |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers, work most closely with the co-founder | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office, the rest flexible | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Scope read | Broad: research, flow design and delivery for one person. A first design hire at a team this size typically also sets up the design process | `[inferred]` from "first designer" plus three named duties; `[generic]` for the norm |
| Market calibration | Not calibrated. The salary search was refused, and I won't set the band against a figure from memory | `[grounded]` posting's figure only |
| Unknowns | Equity form and vesting; runway; first-year outcomes; who reviews design work; whether the posting is on their own site | — |
| Contradictions | None between the posting and the WhatsApp message as pasted (co-founder Ronan, CTO Saoirse, a video call). The emailed invite wasn't pasted, so I haven't seen it | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location is met. You haven't said whether the two-day pattern suits you | `[grounded]` your statement; `[inferred]` that this meets the gate | Confirm on the call |
| R2 | Pay €52,000–€60,000 plus equity (your floor unknown) | hard_gate | unclear | none | hard_gate | No floor was given, so the band can't be checked against anything | `[grounded]` posting figure; floor not supplied | Q1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years at a Dublin travel-booking company. Self-reported, no artifact inspected yet | `[grounded]` your background | Portfolio or CV link raises it |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" over 4 years; no artifact inspected | `[grounded]` your background | Link a file or case study |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Whether you designed the studies, not just ran sessions, isn't stated, so I'd expect a probe | `[grounded]` your background | Say what you planned and synthesised |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your background | None |
| R7 | Own the booking flow end to end | important | adjacent | medium | discovery | You redesigned the checkout, which is one part of a booking flow. Search, availability, cancellation and emails are unstated | `[grounded]` checkout redesign; `[inferred]` that the wider flow may exist | G2 |
| R8 | First designer, no design peer | important | adjacent | medium | transferability | Inferred from "You would be our first designer". You've never been the only designer; adjacent: a checkout redesign owned inside a squad | `[inferred]` from the JD; `[grounded]` your statement | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working as the only designer (R8, important) | transferability | Carries over: owned a checkout redesign and ran monthly research inside a squad. Limit: no evidence of setting design process, tooling or priorities with no peer to critique | The posting says "first designer", so this is the gap an interviewer is most likely to probe | A side project or freelance job; a stretch when the lead was away; deciding with only engineers to review | The "one messy real project" they ask for: your checkout work with its dead ends | `[inferred]` bridge; `[grounded]` posting invites a messy project |
| G2 | Ownership beyond checkout (R7, important) | discovery | Checkout is established; other flow stages are not | "End to end" is the headline duty | Availability or search screens; cancellation and rebooking; payment failures; confirmation emails | Case study screens or a flow map | `[grounded]` background silent beyond checkout |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who is on the call? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | Form (options or shares), vesting and dilution may change its worth | `[inferred]` from the posting's silence | Is the equity options or shares, and what are the vesting schedule and cliff? | unresolved |
| RR3 | No first-year outcomes for a broad mandate | unknown | — | "own the booking flow end to end" | Success may be undefined | `[inferred]` from the posting's silence | What should this role have shipped by month 6 and month 12? | unresolved |
| RR4 | Funding and runway unstated | unknown | — | "We are six people" | A small team's runway can be short, and the posting doesn't say | `[generic]` pattern for small teams | Are you funded, and for how long? | unresolved |
| RR5 | Terms disclosed: pay band, equity range, hybrid pattern, who you'd work with | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Transparent terms make the role checkable | `[grounded]` posting | Who sets the product roadmap, you or Ronan? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp message as routine scheduling for a video call. Before the call, find Fernquay's website yourself and check the invite came from that domain. Recall where you found the posting: their own site or page would help RR1 | A first approach by a co-founder at a six-person company is ordinary | `[generic]` hiring pattern; `[grounded]` RR1 | pending your approval |
| A2 | Ask RR1–RR4 verbatim on the call | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | On "first designer": say plainly what you owned inside a squad and that you haven't been the sole designer | A bridge with its limit stated (R8) | `[grounded]` R8 | pending your approval |
| W1 | Prepare a short, honest walk-through of the checkout redesign, dead ends included | They asked for "one messy real project" (G1, G2) | `[grounded]` posting | pending your approval |
| E1 | CV: lead the checkout redesign and monthly usability sessions with outcome language; add nothing new | R5, R7 | `[grounded]` your background | pending your approval |

Everything above, including the advice in A1–A3, is proposed and not final until you approve it.

## Evidence status

Verified: none yet. Your background is self-report, so each claim is a lead until you confirm it or share an artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Fernquay booking software sea kayak surf schools Galway", "Fernquay Product Designer Galway careers") were refused. It would have shown whether the company and posting exist as described (RR1, contradictions row) |
| 2. Role-family sweep | unavailable | One search (product designer pay in Ireland) was refused. It would have given the market calibration and a pay check for R2 |
| 3. Hiring manager's footprint | unavailable | One search (Ronan Kehoe, named in your message) was refused. It would have informed the scope read and which story to lead with |

## Dossier and upgrade menu

I can save all this as `tuesday-dossier.md` if you'd like to carry it forward.

- Permission to run searches (1 search and 2 fetches remain at this tier) → the three targets above, which could resolve RR1, calibrate pay and sharpen your call positioning.
- A link to the live posting or their careers page, or the invite's sender domain → RR1.
- Your pay floor → R2 resolves.
- A portfolio link, the checkout case study or sanitised research artifacts (a plan, a synthesis board) → R3–R7 from `medium` toward `high`.

## Questions

Q1 (R2): What is the lowest salary you'd accept for this role?

Q2 (G1): Have you ever made design decisions with no designer to review them, and what did you decide alone?

Q3 (G2): Beyond checkout, which steps of the booking journey did you personally own, and what changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.