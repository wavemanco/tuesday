I'll read the reference files the skill requires before building the assessment.
I've run the research searches and found the company's own site. Now I'm checking its about page for a careers link, then I'll write up the assessment.
# Job Underwriting — Product Designer at Fernquay

## Decision snapshot

**Yes, it's worth taking the call, and what I could check says Fernquay is a real, small company. Status: `conditional_go`.** You've already applied and been invited to a call, so I've read this as the interviewing stage.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6
- `important` — adjacent: R7 (Own the booking flow end to end), R8 (Research calls with school owners) · unclear: R9 (Work as first designer, no design peers)

R7 — a credible bridge from the checkout work, its limit named; R9 — your own flag, no evidence either way yet; R2 — waiting on your pay floor.

**Opportunity ledger.** The employer matches its posting on everything I could check. Three things are unknown: where the role is listed (RR1), what the equity is worth (RR2) and who reviews the design work (RR3). The published pay band counts in its favour (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay on offer clears your own floor, and the equity terms are explained (R2, RR2); (2) it becomes clear in the call who reviews your work and which booking-flow decisions are yours (RR3, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About Fernquay page (fernquay.example/about), fetched |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` posting |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, and earlier spent five years as product lead at a Galway travel-software company. That is consistent with how the posting names him | `[grounded]` search result for "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only, not fetched |
| Scope read | Research, interaction design and shipping, all on one product area. The posting names no brand, marketing or visual-identity work | `[grounded]` posting |
| Market calibration | In a 2026 Irish survey (n=520), designers with 3–5 years have a median base of €57,000, with the middle half between €51,500 and €62,000. The posting's €52,000–€60,000 sits inside that range. The survey is Ireland-wide, not Galway- or startup-specific | `[generic]` role-family sweep, survey snippet only; `[grounded]` posting for its own figure, and your 4 years |
| Unknowns | Where the role is listed on Fernquay's own site; equity terms; reporting line and design review; the interview process after this call | `[grounded]` posting and about page are silent on each |
| Contradictions | None between the posting and the about page on size, city or founders | `[grounded]` both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office is within reach. You didn't state your own limits on office days, so confidence stays at `medium` | `[grounded]` your message and posting | none |
| R2 | Pay: €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the figure, but no pay floor of yours was given, so I can't say whether it clears. Confidence is `none` because there is no statement of yours to grade | `[grounded]` posting; your floor not given | Ask your floor (closing question R2) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. A background typed into chat is self-report, so `medium` is the ceiling until something inspectable is seen | `[grounded]` your message | Your portfolio or the checkout case study would raise it to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. That shows frequency of use, not depth, which a file or case study shows better | `[grounded]` your message | Same artifact as R3 |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your message | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned the checkout flow of a travel-booking product. Checkout is one stage of a booking flow, and what you owned of the other stages isn't stated. Booking flows usually also cover availability, selection and changes | `[grounded]` your message; `[generic]` what a booking flow usually spans | G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were usability sessions with customers. Calls with business owners are a different kind of research from usability testing, and you haven't said whether any of yours were owner conversations | `[grounded]` your message; `[generic]` the difference between the two kinds of research | G3 |
| R9 | Work as first designer, with no design peers | important | unclear | low | discovery | The posting says "You would be our first designer". You told me you've never been the only designer, and nothing shows how you work without design peers. Not a stated requirement, so it rests on the posting's wording | `[inferred]` from the posting's "first designer" and "one messy real project" | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow beyond checkout (R7, important) | transferability | A checkout redesign. Nothing on what you owned before or after it | The role is "own the booking flow end to end", and checkout is the part you've shown | Choosing a time slot or date; availability and sold-out states; confirmation and reminder messages; rebooking or cancellation; a booking flow you scoped and shipped | The checkout case study they've seen, a flow diagram, before/after results | `[grounded]` your message names only checkout; `[generic]` the other stages listed |
| G2 | Working without design peers (R9, important) | discovery | No evidence either way. Your team had other designers | You'd be the only designer reporting to a founder, and an interviewer is likely to ask how you'd set direction alone | A side project or freelance job where you were the only designer; a stretch where you set priorities or design standards yourself; building or maintaining a component library alone | A real, unfinished project. The posting asks for exactly that | `[grounded]` your own statement that you've never been the only designer; `[generic]` that small-team roles probe this |
| G3 | Owner-level research (R8, important) | transferability | Usability sessions with customers, not owner-level discovery calls | The posting names calls with school owners as a duty | Interviews with people who run a business; research with a customer's staff rather than end customers; a discovery round that changed what was built | A research plan, a synthesis note or a readout | `[grounded]` your message; `[generic]` how owner research differs from usability testing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not found on Fernquay's own site | unknown | — | "Product Designer — Fernquay" | The role may be listed at another address, or shared by direct outreach only. The posting could also be a copy of a listing elsewhere | `[inferred]` from one fetch of Fernquay's site at its careers address returning no page, and the about page naming no openings | Where is this role listed on Fernquay's own site, and which email address will the interview invite come from? | unresolved |
| RR2 | Equity in a company funded by its customers | unknown | — | "plus 0.5–1% equity" | With no outside funding round, there is no priced share to anchor the equity's worth. Vesting and share terms are unstated | `[grounded]` about page says "funded by its customers"; `[inferred]` that this leaves the value unanchored | What are the vesting terms, and what does 0.5–1% represent in the company's share count today? | unresolved |
| RR3 | Authority and design review unspecified for a sole designer | unknown | — | "You would be our first designer: own the booking flow end to end" | You may be accountable for the flow with no design peer for review, and decisions may rest with the co-founder | `[inferred]` from the posting's scope against its silence on review and decision rights | Who reviews design work day to day, and which booking-flow decisions are yours rather than Ronan's? | unresolved |
| RR4 | Pay band and equity stated up front | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The band is published and lies within the survey's range for 3–5 years. The employer is open about pay | `[grounded]` posting; `[generic]` survey range from the role-family sweep | Is the band fixed, or does it move with experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before the call, confirm the calendar invite comes from an address at the domain on Fernquay's own website, and ask Fernquay through its own site to confirm the WhatsApp contact. WhatsApp scheduling for a video call is a routine step in itself | You said the WhatsApp route felt odd. The invite is the one thing you can check | `[generic]` scheduling over chat for a call held elsewhere is routine; `[grounded]` RR1 | pending your approval |
| P2 | Ask RR1, RR2, RR3 and RR4's questions in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P3 | Lead with the checkout redesign, said in your own words: "redesigned our checkout flow", "monthly usability sessions with customers", "squad with four engineers". State what you owned and what the squad owned | These are your own sentences. Ronan's background is in travel software, and yours is a travel-booking company | `[grounded]` your message; `[grounded]` his profile snippet | pending your approval |
| P4 | Offer one real, in-progress project instead of a polished deck | The posting asks for it: "we would rather see one messy real project than a polished deck" | `[grounded]` posting | pending your approval |
| P5 | Say the sole-designer gap yourself, in your own words: you've never been the only designer. Then say what you did do without design peers, if G2's answer gives you something | It's the thing an interviewer will most likely find | `[inferred]` from R9 | pending your approval |

I'm not proposing any CV edits. Everything in this plan is a proposal pending your approval, and none of it is final wording.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about). Fetched that page, and tried fernquay.example/careers, which returned no page. Role reality's organization and contradictions rows moved. The careers result set RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), snippet only. It fed the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. It fed role reality's hiring-manager row and plan row P3 |

## Closing

I can write all of this into `tuesday-dossier.md` if you'd like to carry it forward.

**Upgrade menu**
- A portfolio link or the checkout case study they've seen would move R3 and R4 toward `high` and show how much of the flow R7 covers.
- Your pay floor would close R2, and the decision becomes `go` or `no_go` on that gate.
- Answers to the questions below would firm up R7 and R9.
- Where the role is listed on Fernquay's site, and the invite's sender address, would close RR1.
- The equity terms would close RR2.
- A deeper research pass on Fernquay (customer reports, news, hiring history; up to 5 more searches and 2 more fetches) will run if you say the word.

**Questions**

R2 — What is the lowest base salary you would accept for this role?

G1 — Besides checkout, which other parts of the booking flow (choosing a slot, availability, confirmations, changes or cancellations) did you personally design, and what did you own versus the squad?

G2 — Have you ever worked without another designer to review or direct your work, whether on a side project, a freelance job or a stretch at your company, and what did you decide alone?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.