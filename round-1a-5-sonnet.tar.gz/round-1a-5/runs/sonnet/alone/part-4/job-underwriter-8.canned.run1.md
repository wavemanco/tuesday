I've read the underwriting rules and I'm now loading the web search tool. I'll check whether Velloway Logistics can be found on its own site, then write up the assessment.
# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, I wouldn't go ahead. I can't establish the firm from here. The requests in these messages (RR1, RR2, RR3 and RR4) are very likely a scam, so send, pay and deposit nothing. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R2, R3, R4
- `important`: unclear: R5 (A quiet place to work)

R1: the stated pay can't be checked against your floor. R2, R3, R4: your own background lines up (all `medium`, your description only).

**Opportunity ledger.** Four confirmed severe requests: ID and bank details before any offer (RR1), paying for equipment (RR2), depositing a cheque and forwarding most of it (RR3), and a process run wholly on Telegram (RR4). Behind them, the employer isn't established (RR5), the contact address isn't tied to a company site (RR6), and the pay terms are loose (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** you would need all of the following. The employer is confirmed through contact details on its own website. You get a written offer from its own domain. Nothing is asked of you in money, cheque or bank details beforehand. The interview takes place outside chat. The pay terms are in writing and meet your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. A search for the company's official site and careers page returned nothing, so it is not established | `[grounded]` search returned no results |
| Role | Remote Order Processing Coordinator, "15–30 a week", "No experience needed, full training provided" | `[grounded]` posting |
| Pay as stated | "Up to €26 an hour plus commission". At 15 to 30 hours a week, 52 weeks, that is at most €20,280 to €40,560 a year, and only at the top rate. Commission terms are not given | `[grounded]` posting; `[inferred]` arithmetic from the posting's figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200, middle range €28,400 to €34,100. The survey excludes commission-only and freelance work, so it is a loose comparison for an hourly, variable-hours post | `[generic]` Pennoral 2026 pay guide, search snippet only |
| Process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews". The offer also came in chat | `[grounded]` posting and your messages |
| Unknowns | Who the employer is; whether this is employment or contracting; commission rules; who "our equipment partner" is | — |
| Contradictions | The kit price asked is €349, but the cheque plan has you forward €2,500 (€2,850 less the €350 you keep) | `[grounded]` arithmetic on your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your floor, which you stated. Fit is unclear because pay is "up to €26" with variable hours and unspecified commission. Full rate on 30 hours clears the floor; full rate on 15 hours does not | `[grounded]` your statement; posting figures | Written pay terms; see G1 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day for three years is relevant, but it is your own description and nothing has been inspected | `[grounded]` your description | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel | `[grounded]` your description | none |
| R4 | Good written English | must_have | direct | medium | none | Written customer replies are the daily work; read from your role, not shown by a sample | `[inferred]` from your ticket work | none |
| R5 | A quiet place to work | important | unclear | none | discovery | Nothing in your message either way | `[grounded]` silence | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | An hourly ceiling and variable hours, with no guaranteed hours or commission rules | Whether the job clears €30,000 depends entirely on hours and rate actually paid | Not applicable; it is a term | Written contract or offer from a verified employer stating rate, guaranteed hours and commission | `[grounded]` posting |
| G2 | Quiet workspace (R5, important) | discovery | Not stated | It is a listed requirement | Not applicable | Your own confirmation | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | These details would be asked before the role is offered or any employer is confirmed. Asking for them at the screening stage is a known pattern in recruitment scams | `[generic]` known pattern; `[grounded]` the quoted message | Did your organisation ask applicants for bank, PPS and passport details before a written offer, and is the chat handle one of your recruiters? | confirmed |
| RR2 | Paying for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Payment is asked of you before any wages exist. Same route and hold as RR1 | `[grounded]` the quoted message | Does your organisation require new hires to pay for their own equipment, and who is the "equipment partner"? Ask through RR1's route | confirmed |
| RR3 | Cheque deposit and forwarding most of it | red_flag | high | "Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | You would send out €2,500 of your own money while the cheque is still uncleared, against a kit price of €349. If the cheque is later returned, the bank can reverse the credit | `[grounded]` arithmetic on the messages; `[generic]` how returned cheques are handled | Does your organisation pay new hires by cheque and ask them to forward part of it? Ask through RR1's route | confirmed |
| RR4 | Hiring and offer wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | No interview you can place, and an offer that closes it in the same chat. Alone this gets no verdict; it is a sign to check | `[grounded]` posting and messages | Can I speak to the hiring manager by phone or video, and will I get a written offer from your company email? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[grounded]` search returned nothing; `[generic]` the three possibilities are patterns, none ranked | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Contact address not tied to a company site | risk_signal | medium | "Any problems, email ..." | The address's domain is not one I could connect to a company site, because I found no site. Who wrote the messages is unresolved | `[inferred]` from the missing site | Is this address one your organisation uses, and is it listed on your own website? | unresolved |
| RR7 | Pay structure loose | unknown | — | "Earn up to €26 an hour plus commission on every order you process" | The effective annual pay may fall well below the market band shown in role reality, depending on hours and commission | `[inferred]` from "up to" and the withheld commission terms, against the `[generic]` band | What is the guaranteed hourly rate, the minimum weekly hours, and the commission rate? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't paste or send your IBAN, PPS number or passport photo. I don't need them for this | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Don't make the €349 payment or lodge the cheque. If a cheque arrives, don't lodge it | see RR2, RR3 | `[grounded]` RR2, RR3 | pending your approval |
| A3 | Find the company's own website independently and use only the contact details there; if you can't find one, treat that as RR5 unresolved | see RR5 | `[grounded]` RR5 | pending your approval |
| A4 | Report the posting to the jobs site and the Telegram account to Telegram, and tell your bank if you've shared anything | Reporting is advice, and your call | `[generic]` common practice | pending your approval |
| A5 | Put your effort into other openings: customer support or order-management roles that name a salary of at least €30,000 and hire by interview | The median salaried band sits near your floor, so such roles are realistic | `[generic]` Pennoral band | pending your approval |
| E1 | In other applications, lead with your own stated facts: about 60 Zendesk tickets a day for three years, training two new starters, and keeping the weekly Excel tracker | see R2, R3, R4 | `[grounded]` your description | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official website careers"; no results, so not established. Fed RR5 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary home-based customer service logistics"; it returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), read from its snippet only. Fed the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given; the Telegram handle isn't a name. A name would feed the scope read |

## Dossier offer

I can write all of this up as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- The link to the live posting and the jobs site's name → RR5 and RR6 could be checked against the posting itself.
- Written pay terms from a verified employer → R1 and RR7 close.
- A hiring manager's name from a verified source → role reality's scope read.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) → says what, if anything, public sources show. Say the word and it runs.

## Questions

1. (G1, R1) Would you like me to help search for roles that state a salary of at least €30,000 and suit your Zendesk background?
2. (RR5) Which jobs site was the posting on, and can you paste its link so I can read the live listing?

Answer in text, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.