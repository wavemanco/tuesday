I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, it's worth taking the call, but I can't establish Fernquay from here. Neither the posting nor the WhatsApp message asks you for money, bank details or ID. Status: `conditional_go`, held there by RR1 (employer not verified) and R2 (pay floor unchecked).**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R8 · adjacent: R6 (Own the booking flow end to end)
- `important`: adjacent: R7 (Research calls with school owners), R9 (First designer, no design peers)
- `preferred`: direct: R10

R6 — checkout is one part of a booking flow, so its ownership scope needs confirming; R7 — a credible bridge from usability sessions, its limit named; R9 — a credible bridge from squad work, its limit named; R2 — waiting on your pay floor.

**Opportunity ledger.** RR1 — Fernquay can't be established from here, which holds the status at `conditional_go`; RR3, RR4, RR5 — unknowns to put to them; RR2 — pay and scope are stated; the WhatsApp scheduling message takes no entry (role reality, Process row).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: Fernquay's own site shows the company and this role; (2) R2: the pay meets your floor; (3) R6 and R9 are framed as adjacent, never as full end-to-end or sole-designer experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, described as six people in Galway making booking software for sea-kayak and surf schools. Its existence is not established: my searches were refused and you report finding little online | `[grounded]` JD; `[grounded]` your report |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Closest collaborator | Co-founder Ronan Kehoe. The WhatsApp sender, "Ronan from Fernquay", matches the co-founder the JD names, and the CTO Saoirse is not contradicted by "two engineers" | `[grounded]` JD and your message |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Working pattern | Hybrid: two days a week at a Galway office, the rest from anywhere. No office address is given | `[grounded]` JD |
| Scope read | Coherent: all three duties sit around one product, with no unrelated functions bundled in | `[inferred]` from the JD's duty list |
| Process so far | The co-founder messaged on WhatsApp to schedule a 45-minute video call, with the invite emailed. That is scheduling for an interview held on video, and nothing in it asks for money, bank, tax or ID details | `[grounded]` your message; `[inferred]` reading of it |
| Market calibration | Not run: the role-family search was refused, so there is no market band for this title and the pay stands uncalibrated | — |
| Unknowns | Employee or contractor basis; equity terms; runway and paying customers; who reviews design work; first-year outcomes | `[grounded]` JD silence |
| Contradictions | None between the JD and your message | `[grounded]` JD and your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year, so the location works. Confidence is `medium` because this is intake prose, and I haven't asked whether the two office days suit you | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 (your floor unknown) | hard_gate | unclear | none | hard_gate | The posting states the pay. You haven't given a floor, so whether it is met isn't established | `[grounded]` JD; no constraint stated | Tell me your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer at a Dublin travel-booking company. It is confirmed and specific, but no CV or portfolio has been inspected | `[grounded]` your background | CV dates would raise to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | You state daily Figma use. Nothing inspectable yet | `[grounded]` your background | Portfolio link would raise it |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The limit: that is usability work, and I don't know whether it included planning or recruiting | `[grounded]` your background | A sanitized research plan or synthesis would raise it |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow. Checkout is part of a booking flow, and I don't know whether your scope reached beyond it | `[grounded]` your background; `[inferred]` that checkout is only part of a booking flow | See G1 |
| R7 | Run research calls with school owners | important | adjacent | medium | transferability | Your customer usability sessions are the bridge. Limit: nothing shows interviews with small-business owners or discovery-style research | `[grounded]` your background | See G2 |
| R8 | Work directly with engineers; ship alongside two engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R9 | First designer, no design peers | important | adjacent | medium | transferability | You owned a checkout redesign inside a squad. Limit: you have never been the only designer, and this role has no design peer | `[grounded]` your background and JD | See G3 |
| R10 | One real project to show, messy welcome | preferred | direct | medium | none | You submitted a checkout case study, and the message says it was liked. I haven't seen it | `[grounded]` JD and your message | Share it if you want it reviewed |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Scope of the booking flow you touched (R6, must_have) | discovery | You redesigned checkout. The flow before and after payment isn't mentioned | The JD says "end to end", and this decides how far to claim | Availability or search screens; confirmation and cancellation emails; rebooking; specs worked through with engineers | Case study sections, a flow map, before/after screens | `[grounded]` your prose; `[inferred]` that scope is what an owner would be asked about |
| G2 | Research with business owners (R7, important) | transferability | Customer usability sessions, not owner interviews | The role's research is with school owners | Calls with agents, operators or suppliers; reviewing support calls; interviews that fed a roadmap | A sanitized plan or synthesis | `[grounded]` your prose |
| G3 | Working as the only designer (R9, important) | transferability | Squad work with engineers, never the only designer | There would be no design peer here | Decisions made without a design review; a shared component library you set up | A Figma library or a decision log | `[grounded]` your prose and JD |
| G4 | Pay floor (R2, hard_gate) | hard_gate | No floor stated | Pay is a gate term, and it decides R2 | Not applicable | Your own figure | `[grounded]` your prose |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` your report of little online | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay range and role scope stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity"; "own the booking flow end to end" | The posting is concrete about pay and mandate | `[grounded]` JD | What does success look like in the first year? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Its value depends on terms the posting doesn't give | `[inferred]` from the JD's silence | Is the equity options or shares, and what are the vesting schedule and strike price? | unresolved |
| RR4 | Runway and customer base unstated | unknown | — | "We are six people in Galway" | The posting says nothing on funding or paying schools | `[inferred]` from the JD's silence | How long is the runway, and how many schools pay today? | unresolved |
| RR5 | Design decision-making unstated | unknown | — | "You will work most closely with our co-founder, Ronan Kehoe." | As first designer, design direction may rest with the co-founder, with no one to review your work | `[inferred]` from "first designer" and the named collaborator | When you and a founder or engineer disagree on a design call, who decides? | unresolved |

RR1 caps the status at `conditional_go` until the posting and employer verify. What would clear it is a link to the live posting on Fernquay's own careers page, and an invite whose sender domain matches Fernquay's own website.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own website and the posting on it, and check that the emailed invite comes from the same domain. Use contact details from that site, not the WhatsApp thread | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put the questions of RR1, RR3, RR4 and RR5 to Ronan and Saoirse verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Confirm the pay is within the posted range and the contract basis, once you've settled your floor | see R2 | `[grounded]` JD | pending your approval |
| A4 | Proposed wording: "I redesigned the checkout flow at a Dublin travel-booking company and ran monthly usability sessions with customers. I worked in a squad with four engineers. I have not been the only designer before, and this role would be my first." | Keeps R6 and R9 honest. Each clause traces to your own sentences | `[grounded]` your background | pending your approval |
| A5 | Walk through the checkout case study, including what didn't work, since the posting prefers one messy real project to a polished deck | see R10 | `[grounded]` JD | pending your approval |

Every row above, including the wording in A4, is proposed and pending your approval; nothing is final until you say so.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; both refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland startup 3-5 years experience 2026"; refused. It would have moved the market calibration row and the R2 pay comparison |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have moved role reality's scope read and A4's positioning |

Everything labeled `[generic]` or `[inferred]` above is reasoning from your messages and the posting alone.

I can write all of this into a `tuesday-dossier.md` to keep, if you'd like.

## Upgrade menu

- Your pay floor and any other non-negotiables → R2 resolves, and the hard-gates line loses its "constraints not given" flag.
- The link to the posting, plus Fernquay's website → RR1 can be checked against their own pages.
- Permission to run web searches (up to 5 searches and 2 fetches) → RR1, the market calibration row and the scope read.
- Your portfolio or the checkout case study → R4, R6 and R10 can move to `high`.
- A sanitized research plan or synthesis → R5 and R7.

## Questions

- **R2** — What is your pay floor, and are there other things you wouldn't trade, such as the two office days?
- **R6** — Beyond the checkout screens, which other parts of the booking flow did you design or change, and what was yours versus the squad's?
- **RR1** — Where did you find the posting: Fernquay's own site, a job board or LinkedIn? Can you send me the link?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.