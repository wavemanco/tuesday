I'll read the reference files the skill points to before building the assessment.
Now the decision/snapshot rules, output discipline, and the research rules.
**Yes, it's worth applying, but with conditions. Status: `conditional_go`.** You meet both licence and registration gates as you've stated them. The gaps are experience gaps, and the posting seems to expect some of them to be closed on the job.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3; adjacent: R5 (Caring for housebound adults at home); unclear: R4 (Clear, timely written records); absent: R10 (Small caseload of your own)
- `important`: direct: R6a, R7a, R9; adjacent: R6b (Leg-ulcer care); unclear: R7b (Continence care), R8 (End-of-life visits), R11 (Care planning)
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R5 and R6b are credible bridges with their limits named; R10 and R12 are things you told me you haven't done.

**Opportunity ledger.** The employer matches its own About page and publishes a pay range (RR4). Open items are whether the posting is live (RR1), the hours and rota (RR2), support for a first-time caseload holder (RR3), how mileage works alongside pool cars (RR5), and whether Doppler training is provided (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting verifies on the employer's own careers page (RR1).
  2. First-caseload support is confirmed in the informal chat (R10, RR3).
  3. Leg-ulcer and Doppler work are framed as not yet done, with training confirmed (R6b, R12, RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` About page fetched |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Structure | A small caseload of your own, supported by a senior community nurse. Pool cars provided, mileage paid | `[grounded]` JD |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silent |
| Scope read | A newly-qualified-to-experienced Band 5 entry into community work, with Doppler listed as desirable rather than essential. That reads as a post that expects some skills to be taught on the job | `[inferred]` from "Desirable" wording and the supported-caseload line |
| Market calibration | The advert's £31,050–£37,800 spans a published 2026 survey's middle range for Band 5 community staff nurses in England (median £34,300; middle half £32,400–£36,600). Pool cars are less common than mileage-only terms in that survey (24% pool or lease car; 61% mileage). The band is a pattern, not this employer's offer | `[grounded]` JD figure; `[generic]` survey band (Wardround 2026 pay guide, n=1,240) |
| Team lead footprint | The named contact leads the Halifax district nursing team after eleven years as a district nurse. She has spoken at a community nursing forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page; public professional footprint only |
| Unknowns | Closing date, hours and rota, induction length, which hub, how mileage applies | `[grounded]` JD silent |
| Contradictions | None found: the posting's organization, location and service match the About page. The careers page could not be reached, so liveness is unconfirmed (RR1) | `[grounded]` About page; careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration as a Registered Nurse (Adult) with revalidation due March 2028. Stated, not checked: the NMC online register entry is yours to confirm is current | `[grounded]` CV | Check your own register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK category B licence. Stated, not checked: your driving record on the DVLA's online service is yours to check. Pool cars are provided | `[grounded]` CV | Check your driving record is current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length of experience is not a gate, so it is graded as an ordinary requirement | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | none | discovery | The CV is silent on record-keeping and on any electronic record system. Nothing is claimed here beyond what you wrote | `[grounded]` CV silence | G4 |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge is real home-visiting. Limit: short post-discharge visits, not an ongoing housebound caseload | `[grounded]` CV; `[inferred]` that ongoing care differs | G1 |
| R6a | Wound care (the advert pairs it with leg-ulcer care) | important | direct | medium | none | Wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6b | Leg-ulcer care | important | adjacent | low | transferability | Pressure-ulcer and surgical wound care are credible neighbours. Limit: the CV does not mention leg ulcers or compression | `[grounded]` CV; `[inferred]` adjacency | G2 |
| R7a | Catheter care | important | direct | medium | none | Catheter care is on your CV | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | none | discovery | Not on the CV | `[grounded]` CV silence | G3 |
| R8 | End-of-life visits | important | unclear | none | discovery | Not on the CV. An acute medical ward may have involved this, but that is not something I can claim for you | `[grounded]` CV silence | G3 |
| R9 | Insulin administration | important | direct | medium | none | Insulin administration is on your CV | `[grounded]` CV | none |
| R10 | Hold a small caseload of your own, supported by a senior community nurse | must_have | absent | none | capability | You told me you have never held your own caseload. The advert pairs the caseload with senior support. Whether the discharge-to-assess visits had any independence is the open adjacent question | `[grounded]` your statement and JD | G5 |
| R11 | Care planning | important | unclear | none | discovery | Not on the CV | `[grounded]` CV silence | G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You told me you have never done one. It is listed as desirable, not essential | `[grounded]` your statement and JD | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Depth of home visiting (R5, must_have) | transferability | 18 months of first-week post-discharge visits. Not shown: how independent the visits were, or whether you planned your own visiting list | Likeliest bridge to the caseload gap (R10), so it matters most to the application | Visiting alone and deciding your own priorities for the day; escalating to a GP or community team; handing over to district nurses | Secondment description or the team's role outline | `[grounded]` CV; `[generic]` that this bridges toward caseload work |
| G2 | Leg-ulcer care (R6b, important) | transferability | Pressure and surgical wound care; no leg ulcers or compression stated | The advert names leg-ulcer care in its duties, so this is the likeliest probe | Applying or reviewing compression bandaging on the ward; seeing a vascular or tissue viability nurse assess; any leg-ulcer patients you dressed | A wound-care competency record or training certificate | `[grounded]` CV; `[inferred]` likeliest probe from the advert's wording |
| G3 | Continence care, end-of-life care, care planning (R7b, R8, R11, all important) | discovery | The CV is silent on all three | Each is a listed duty, and any one that is true and specific strengthens the application | Bladder and bowel care; caring for dying patients and their families; writing or updating care plans or discharge plans | Ward competency record, a discharge-to-assess plan format | `[grounded]` CV silence |
| G4 | Records and electronic patient record (R4, must_have) | discovery | No mention of record systems | An essential criterion that the CV does not address | Electronic patient record or e-observations on the ward; documenting handovers or discharge plans | Name of the system used | `[grounded]` CV silence |
| G5 | Caseload ownership (R10, must_have) | capability | You have not held one | The posting pairs it with senior support, so the closure path is the employer's own induction. Whether that exists is RR3 | n/a. The only adjacent evidence is G1 | n/a | `[grounded]` your statement; `[inferred]` that induction is the closure path |
| G6 | Doppler assessment (R12, preferred) | capability | You have not done one | It is desirable, not essential. Closure path: training on joining, to be confirmed in RR6 | n/a | n/a | `[grounded]` your statement and JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not seen on the employer's own site; no closing date | unknown | — | "For an informal chat about the role, contact Rhiannon Mabbott" | The About page says vacancies are on a careers page, but the address I tried returned no page. The posting may be live at another address, or stale | `[inferred]` from the About page's pointer against the failed fetch | Can you point me at this role on your careers site, and what is the closing date? | unresolved |
| RR2 | Hours, rota and weekend working unstated | unknown | — | "caring for housebound adults in their own homes" | Community nursing teams commonly run across seven days, which may not suit every candidate | `[generic]` role-family pattern, not a claim about this employer | What hours, weekends and on-call, if any, does this post involve? | unresolved |
| RR3 | Support for a first-time caseload holder unspecified | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse" | Support is named but its form is not: induction length, shadowing, competency sign-off | `[inferred]` from the JD naming support without detail | What induction, shadowing and sign-off are in place before I hold a caseload alone? | unresolved |
| RR4 | Pay range, vehicles and structure are published | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | The range spans the middle of the survey band, and pool cars are less common than mileage-only terms | `[grounded]` JD figures; `[generic]` survey comparison | Where on the range would this post start? | noted |
| RR5 | Mileage paid alongside pool cars | unknown | — | "pool cars are provided"; "plus mileage" | Mileage may apply to personal-car use or to travel between hubs, rather than to every visit | `[inferred]` from the two phrases appearing together | When is mileage paid, given pool cars are provided? | unresolved |
| RR6 | Doppler training provision unstated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The team lead has spoken publicly on Doppler training for staff new to community work, so training may exist. That is not a statement of what this employer offers | `[inferred]` from the speaker page, not a claim about the employer's terms | Is Doppler training provided on joining, and how soon? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: move the discharge-to-assess secondment to the top of your experience, worded as you wrote it: "seconded to the discharge-to-assess team for the last 18 months, visiting patients at home in their first week after discharge" | R5, G1 | `[grounded]` CV | resume_edits_pending_approval |
| E2 | CV: a skills line using your own terms only: "wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" | R6a, R7a, R9 | `[grounded]` CV | resume_edits_pending_approval |
| E3 | Supporting statement: say plainly that you have not yet held your own caseload or done a Doppler assessment, and ask about training | R10, R12 | `[grounded]` your own statements | pending your approval |
| A1 | Use the informal chat the advert invites, and ask the questions in RR1, RR3, RR5 and RR6 word for word | The advert offers the chat | `[grounded]` JD and register | pending your approval |
| A2 | Before applying, check your NMC register entry and DVLA driving record are current | R1, R2 are stated, not checked | `[grounded]` rows R1, R2 | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this, and I haven't used or repeated it. Your NMC and driving details are in the map as stated, not checked.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched that page, which added nothing beyond the search snippet, and fetched calderbrookhealth.example/careers, which returned no page. Moved role reality's organization row, and opened RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change 2026/27 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the team lead row, RR6 and the plan |

I can offer the dossier as `tuesday-dossier.md` whenever you want it, for the interview rehearsal skill or your own records.

**Upgrade menu**

- Your CV's discharge-to-assess role outline or a secondment letter would raise R5 toward `high`.
- A wound-care competency record or training certificate would firm up R6a and R6b.
- A direct link to the live posting, or a recruiter email domain, would close RR1.
- The informal chat's answers on rota, induction, mileage and Doppler training would close RR2, RR3, RR5 and RR6.
- Any hours, pay-floor or travel limits would let me check R1 and R2's gate rows against what you can't trade, which I haven't been able to do.
- A deeper research pass on the employer (leadership, staff reports, recent news; up to 5 more searches and 2 more fetches) is available if you say the word.

**Questions**

G1 — On those first-week home visits, what did you decide and do on your own, such as planning your own visits, assessing the patient or escalating to a GP, and what did you hand on to others?

G2 — Have you applied or reviewed compression bandaging, or cared for leg-ulcer patients on the ward, even occasionally?

G3 — Have you cared for dying patients, done bladder and bowel care, or written or updated care plans? Which of those, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.