Running the first research searches now: the company, the role-family pay band, and the co-founder's public professional footprint.
Short answer: yes, worth continuing, with a few things to ask on the call. I found nothing that looks wrong with the company or the WhatsApp message. I checked their website and the co-founder's public profile, and nothing contradicts what you were told.

## Decision snapshot

**Yes, this is worth pursuing, and the WhatsApp contact is a routine step. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R7 · unclear: R8 (Pay within the stated €52,000–€60,000 band)
- `must_have` — direct: R1, R2, R3, R4 · adjacent: R5 (Own the booking flow end to end)
- `important` — absent: R6 (First and only designer)
- `preferred` — none present in this map

R5 (`medium`) — a close bridge with its limit named. R6 — you have never worked without design peers, so it is the one real gap.

**Opportunity ledger.** The company checks out as described, and the pay is stated and sits inside the market band (RR1). The open items are equity terms (RR2), who decides what between you and the co-founder (RR3), and how a customer-funded company sustains a new hire (RR4).

- **Hard gates:** none failed; unconfirmed: R8 (Pay within the stated €52,000–€60,000 band); met: R7 `medium`; your non-negotiables were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) equity terms are explained concretely (RR2); (2) you are comfortable being the only designer, and the role comes with real decision rights (R6, RR3); (3) the pay band clears your floor (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people, is based in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers. | `[grounded]` Fernquay "About" page |
| Posting is live and consistent | The careers page lists the same role: first design hire, hybrid with two days a week in Galway, €52,000–€60,000 plus equity, apply with one real project. | `[grounded]` careers page fetched |
| Mandate | Own the booking flow, run research calls with school owners, and ship alongside two engineers. | `[grounded]` your pasted posting |
| Scope read | Bounded and sensible for a first designer. It also puts product, research and design on one person with no design peer. | `[inferred]` from the three duties against "first designer" |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years. That is close to your own domain. | `[grounded]` his public professional profile (snippet) |
| Market calibration | €52,000–€60,000 sits inside the survey's range for product designers with 3–5 years in Ireland (median €57,000, interquartile range €51,500–€62,000). This is a market pattern, not a statement about this employer. | `[generic]` Tillerby 2026 salary report; `[grounded]` posting figure |
| Unknowns | Equity terms; decision rights; the company's runway; who the "two engineers" report to. | — |
| Contradictions | None between the posting, the careers page, the About page and the WhatsApp message. I don't know how you applied, so the "apply to jobs@" route is not checked against it. | `[grounded]` pages compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You state 4 years at a Dublin travel-booking company. It is your own account, with no document read yet. | `[grounded]` your background, as stated | CV or LinkedIn dates would raise to `high` |
| R2 | Strong Figma | must_have | direct | medium | none | You use Figma daily. "Strong" is judged from files, and none were seen. | `[grounded]` your statement | A Figma file or case study link would raise to `high` |
| R3 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The role asks for research calls with school owners, which may be more exploratory than usability testing. I'd name that difference if asked. | `[grounded]` your statement; `[inferred]` on the difference | Prepare one example of what a session changed |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. | `[grounded]` your statement | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a travel company's checkout flow. Checkout is part of a booking flow. Whether you also owned selection, availability or post-booking steps is unknown. | `[grounded]` your statement; `[inferred]` on the scope difference | See G2 |
| R6 | First and only designer | important | absent | none | transferability | You have never been the only designer. The nearest evidence is owning checkout inside a squad. The limit is that you had no design peers to lean on or to set direction. | `[grounded]` your statement | See G1 |
| R7 | Hybrid: two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. I haven't confirmed that the office commute works for you. | `[grounded]` your statement and posting | none |
| R8 | Pay: €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor was not given, so I can't say whether it clears. | `[grounded]` posting; your floor not given | Question R8 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R6, important) | transferability | You have worked inside a squad, with no sole-designer role. | It is the main change from your current setup, and it is likely to be probed on the call. | Setting a design system or conventions others adopted; making design calls without a review; side or freelance projects; mentoring or onboarding a junior | A design system page, a decision log, a freelance or side-project file | `[grounded]` your statement; `[generic]` that it is likely to be probed |
| G2 | Booking flow end to end (R5, must_have) | discovery | Your checkout redesign is clear. The steps before and after it are not. | It decides whether R5 is `adjacent` or `direct`. | Ownership of search, selection, availability or confirmation screens; post-booking changes or cancellations | A flow diagram or before/after screens (sanitized) | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in line with the market band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The employer is transparent about pay. | `[grounded]` posting and careers page agree; `[generic]` band | Is the band fixed, or does it depend on level? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage may come with vesting, a cliff or later dilution that change its value. | `[inferred]` from the posting giving a percentage and no terms | What are the vesting schedule, cliff and strike price, and what is the current share count? | unresolved |
| RR3 | Decision rights between designer and co-founder | unknown | — | "You will work most closely with our co-founder, Ronan Kehoe" | Because he is a former product lead, product decisions may stay with him. | `[inferred]` from his stated background and the posting's wording | Which product and design decisions does this role make alone, and which go to you or Saoirse? | unresolved |
| RR4 | Runway for a new hire | unknown | — | "funded by its customers" | A company funded by customers may have limited runway for hires. The About page gives no revenue or headcount-growth figures. | `[inferred]` from the funding line; `[generic]` that this model carries less outside cash | How long is the runway, and what would the first year's hiring plan depend on? | unresolved |
| RR5 | Independent corroboration is thin | unknown | — | "Six people in Galway" | The only sources found are the company's own pages and a public profile. That fits a small company but means customers or press were not checked. | `[inferred]` from the sources found | Can you name two or three customer schools I could look at? | unresolved |

The WhatsApp message asks for nothing but a 45-minute video call. Scheduling by chat for an interview held elsewhere is routine, so it has no register entry. If you want a habit anyway, accept the invite only if it arrives from an address on Fernquay's own domain (`fernquay.example`), as in action A1.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the calendar invite comes from an address on Fernquay's own domain, then reply to confirm the time. | A routine habit. | `[grounded]` careers page domain | pending your approval |
| A2 | Lead with the checkout redesign as the messy real project. Say plainly that it was one part of a flow, done inside a squad. | They asked to see "one messy real project", and R5 and R6 limits stay stated. | `[grounded]` posting; your statement | pending your approval |
| A3 | Ask RR2, RR3 and RR4 verbatim on the call. | The register is your interview prep. | `[grounded]` register | pending your approval |
| A4 | Say honestly that you have not been the only designer, then describe what you would do first. Do this only after your answer to G1. | It avoids overstating and gives a credible path. | `[grounded]` R6 row | pending your approval |
| A5 | Decide your pay floor before the call. | R8 stays unconfirmed until you do. | `[grounded]` R8 row | pending your approval |

No CV edits are proposed (`resume_edits_pending_approval`: none).

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay careers product designer Galway". Fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality: the organization and contradictions rows. The posting is live and consistent. |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3+ years startup Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Role reality: the market calibration row, and RR1. |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality: the hiring-manager row. His travel-software background informed the positioning in A2 and the RR3 hypothesis. |

I can add a dossier file, `tuesday-dossier.md`, if you want one.

## Upgrade menu

- A Figma file or case study link would raise R2 and R3 toward `high`.
- Your CV dates would raise R1 toward `high`.
- Your answer on G2 settles whether R5 is `adjacent` or `direct`.
- Your pay floor settles R8.
- Their answers on equity, decision rights and runway close RR2, RR3 and RR4.
- A deeper research pass on Fernquay (customers, funding or revenue signals, recent news; up to 5 more searches and 2 more fetches) will run if you say the word.

## Questions

```text
G1 — Have you ever made design decisions with no other designer reviewing them,
such as a design system, a freelance job or a side project? What did you own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
```

```text
G2 — Beyond the checkout screens, did you own any other steps of the booking
journey (search, selection, availability, confirmation, changes or cancellations)?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
```

```text
R8 — What is your minimum acceptable salary, and how much weight would you put on the 0.5–1% equity?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
```

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.