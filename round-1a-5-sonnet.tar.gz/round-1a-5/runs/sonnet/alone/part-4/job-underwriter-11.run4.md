Reading the skill's evidence rules before I write the assessment.
Next I'm loading the search tool. I want to check that both employers exist and get market context for the two roles.
**Femi, one is worth applying to and one isn't.** I assessed each posting separately. Both postings and your background came from your message. I tried four web searches on the two employers and the pay market, and all four were refused, so none of the company or salary context below is checked.

---

# 1. Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Yes, this one is worth your time, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: D8 (Hybrid, three days a week in Rotterdam)
- `must_have`: direct: D1, D2, D3, D4 · unclear: D5 (Temperature compliance across the refrigerated fleet)
- `important`: adjacent: D6 (Work with depot managers on route changes)
- `preferred`: adjacent: D7 (Dutch a plus)

D5 — the cold-chain half of the job, nothing in your history yet; D6 (`medium`) — you ran the route review, and whether it changed routes is unstated.

**Opportunity ledger.** Concrete, tool-named duties (DR3). Pay is not stated (DR1), and the employer is unverified because research did not run (DR2).

- **Hard gates:** none failed; unconfirmed: D8 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam commute works for you, see D8; (2) the employer and posting verify on Duinvaart's own site, see DR2; (3) the cold-chain bridge is framed honestly as adjacent, never as temperature-compliance experience, see D5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, operating a refrigerated fleet and depots | `[grounded]` posting header; not independently checked |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst post that reports and advises. No team, budget or decision rights are mentioned, which fits an individual-contributor role | `[inferred]` from the duty list and its silence on authority |
| Market calibration | Not established: the role-family searches were refused, so there is no pay band or title norm to give | `[grounded]` search refused |
| Unknowns | Salary, level, first-90-days outcomes, who you would report to | `[grounded]` posting silent |
| Contradictions | None found in the text you pasted; the careers page was not reached to cross-check | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You state 4 years as an operations analyst at a parcel carrier in Amsterdam; no document inspected yet | `[grounded]` your message | CV or LinkedIn dates would raise to `high` |
| D2 | Strong SQL | must_have | direct | medium | none | "SQL ... daily"; no sample query or artifact seen | `[grounded]` your message | none needed now |
| D3 | Power BI or Tableau; build weekly dashboards | must_have | direct | medium | discovery | You say Power BI daily, "including the on-time delivery dashboard our depot managers use". Whether you built it or maintained it is not stated, so carry it as "worked on" until you confirm | `[grounded]` your message; ownership unstated | Ask DG2; a sanitised screenshot would raise to `high` |
| D4 | Track on-time delivery | must_have | direct | medium | none | The on-time delivery dashboard is the same metric the posting names | `[grounded]` your message | none needed now |
| D5 | Track temperature compliance across a refrigerated fleet | must_have | unclear | low | discovery | Nothing you gave touches temperature or condition compliance. Parcel on-time work is related, but I will not call it equivalent. Cold-chain roles usually treat temperature excursions as a distinct, regulated measure | `[grounded]` no evidence in your message; `[generic]` on how such roles treat it | Ask DG1 |
| D6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You "ran our weekly route-performance review" and depot managers use your dashboard. Whether the review produced route changes is unstated | `[grounded]` your message | An example of a route change that came out of the review would make this `direct` |
| D7 | Dutch a plus | preferred | adjacent | medium | transferability | "Conversational, not fluent." The posting asks only for a plus. State it as conversational, never as fluent | `[grounded]` your message | none; say it plainly |
| D8 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | The posting states the term; your limits on commute, pay and schedule were not given, so this cannot be checked. Confidence is `none` because no constraint of yours is on record | `[grounded]` posting states it; your constraints absent | Ask D8 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| DG1 | Temperature compliance (D5, must_have) | discovery | No condition-based or compliance measure in what you gave | It is half the posting's stated purpose; an answer could confirm D5 as `adjacent`, or leave it open | Reporting on breaches, exceptions or SLA misses; handling temperature-sensitive or high-value parcels; any audit or regulated-delivery reporting | A sanitised report, a metric definition, or a dashboard page | `[grounded]` CV silence; `[generic]` that interviewers for this role will probe it |
| DG2 | Dashboard ownership (D3, must_have) | discovery | You use the dashboard daily; build versus maintain is unclear | "Built" and "maintained" are different claims in an interview | Designing the data model or the SQL behind it; adding metrics at depot managers' request; owning its refresh | A screenshot with figures removed, or the SQL outline | `[grounded]` your wording; `[inferred]` that the distinction will be probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Pay and level not stated | unknown | — | "Operations Analyst ... 2+ years" (no figure given) | The post may sit at a level below your 4 years, or pay may suit you; your floor is unknown and no band could be researched | `[grounded]` posting silent | What salary range and level is budgeted for this post? | unresolved |
| DR2 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; no search succeeded either way | `[generic]` pattern for employers of unknown size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| DR3 | Duties concrete and tool-named | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet, build weekly dashboards in Power BI" | Day-to-day scope is defined and matches tools you use | `[grounded]` posting | What would a good first 90 days look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| DA1 | Lead with your own words: "SQL and Power BI daily, including the on-time delivery dashboard our depot managers use" and "ran our weekly route-performance review". Add no word like "built" or "owned" until DG2 is answered | See D3, D4, D6 | `[grounded]` your message | pending your approval |
| DA2 | State Dutch as conversational | See D7 | `[grounded]` your message | pending your approval |
| DA3 | Confirm the posting and employer on Duinvaart's own website before investing in a tailored application | See DR2 | `[grounded]` DR2 | pending your approval |
| DA4 | Ask DR1 and DR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

---

# 2. Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**No, this one isn't worth your time. K1, K2, K3 and K6 are `absent` must-haves, and you've said you've never worked in planning. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: K8 (On-site in Utrecht)
- `must_have`: adjacent: K4 (Run the weekly S&OP meeting), K7 (Fluent Dutch) · unclear: K5 (Advanced Excel) · absent: K1 (3+ years of supply or demand planning in FMCG), K2 (Own the 13-week supply plan), K3 (Balance production capacity against the forecast), K6 (SAP IBP or a similar planning system)

K1, K2, K3, K6 — the planning work itself, with no evidence; K4 (`medium`) — a real bridge, limit named; K7 (`medium`) — conversational against fluent.

**Opportunity ledger.** Scope is clear and concrete (KR3). Pay is withheld (KR1), and the employer is unverified because research did not run (KR2).

- **Hard gates:** none failed; unconfirmed: K8 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** facts that would have to differ are K1, K2, K3 and K6, meaning planning experience in FMCG and with a planning system. Nothing in the posting suggests those are optional.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready-meals | `[grounded]` posting; not independently checked |
| Mandate | Own the 13-week supply plan, balance capacity against the forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A full planning-ownership post, not an analyst role that touches planning | `[inferred]` from "own" and the stated years of planning experience |
| Market calibration | Not established: searches refused; no band given | `[grounded]` search refused |
| Unknowns | Salary, team size, authority over the plan, outcomes for the first year | `[grounded]` posting silent |
| Contradictions | None found in the pasted text; careers page not reached | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning, and a titled-years line like this is usually screened literally | `[grounded]` your statement; `[generic]` on how such lines are screened | Closure path: a planning role first. Carry as a material risk |
| K2 | Own the 13-week supply plan | must_have | absent | none | capability | No planning ownership in your history | `[grounded]` your statement | Same as K1 |
| K3 | Balance production capacity against the forecast | must_have | absent | none | capability | Your route-performance work looks back at results; nothing you gave shows forward capacity balancing | `[grounded]` your message | Same as K1 |
| K4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: that is a performance review, not a cross-functional meeting that agrees a forward plan | `[grounded]` your message; limit `[inferred]` from the two meeting types | Moot on current evidence |
| K5 | Advanced Excel | must_have | unclear | low | discovery | You named SQL and Power BI; Excel was not mentioned | `[grounded]` CV silence | Moot on current evidence |
| K6 | SAP IBP or similar planning system | must_have | absent | none | capability | No planning system in your history | `[grounded]` your statement | Same as K1 |
| K7 | Fluent Dutch | must_have | adjacent | medium | transferability | "Conversational, not fluent": real but short of what is asked. A recognised language-level result would show where you stand | `[grounded]` your message | Never claim fluency |
| K8 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | The term is stated; your limits were not given | `[grounded]` posting; your constraints absent | Ask only if you reconsider |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| KG1 | Planning experience and system (K1, K2, K3, K6, must_have) | capability | No direct or adjacent planning evidence | These are the role's core duties, and they decide the status | Planning-adjacent analysis you may not think of as planning, though you said you have none | n/a | `[grounded]` your statement |

Closure path: gain planning experience first. A role that mixes analysis with planning is one route; roles asking for 3+ years of planning will probably screen you out meanwhile `[generic]`.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KR1 | Pay not stated | unknown | — | "Supply Planner ... 3+ years" (no figure given) | Pay cannot be set against your floor; no band researched | `[grounded]` posting silent | What salary range is budgeted for this post? | unresolved |
| KR2 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; no search succeeded either way | `[generic]` pattern for employers of unknown size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| KR3 | Scope concrete | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The mandate is clearly defined | `[grounded]` posting | What would a successful first year look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| KA1 | Don't apply on current evidence; put the time into Duinvaart-type analyst roles | See K1, K2, K3, K6 | `[grounded]` map | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht" were refused. It would have settled DR2 and KR2 and cross-checked the posting |
| 2. Role-family sweep | unavailable | Searches on Rotterdam operations-analyst pay and on Netherlands FMCG supply-planner pay and requirements were refused. They would have filled both market-calibration rows and set DR1 and KR1 against a band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Closing

If you'd like, I can write all this into a `tuesday-dossier.md` you can keep and update.

**Upgrade menu**

- Permission to search again would close DR2 and KR2 and give a pay band for DR1. Only 1 L1 search remains; a deeper pass is up to 5 more searches and 2 more fetches.
- A link to the live posting on Duinvaart's careers page would close DR2 directly.
- A sanitised dashboard screenshot would raise D3 to `high`.
- An example of a route change from your weekly review would make D6 `direct`.
- Your CV would let me check D1 against dates.
- A hiring manager's name would sharpen the scope read.

**Questions**

DG1 — At your parcel carrier, did you ever track or report anything like a service-condition or compliance measure (breach rates, SLA exceptions, temperature- or value-sensitive parcels), and what did you do with it?

DG2 — On the on-time delivery dashboard depot managers use, did you build it, extend it, or maintain someone else's, and could you share a version with figures removed?

D8 — What are your limits on commuting to Rotterdam three days a week and on pay, so I can check both against this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.