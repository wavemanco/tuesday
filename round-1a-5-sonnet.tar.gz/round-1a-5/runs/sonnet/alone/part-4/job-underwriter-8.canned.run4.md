**No, don't go ahead with this one. Status: `no_go`.** Four requests in these messages are confirmed severe red flags (RR1, RR2, RR3, RR4). I can't establish the firm from here, and the requests are very likely a scam. This is about what's being asked of you, not your fit. Your background matches the posting's stated requirements.

**Fit ledger.**

- `hard_gate` — unclear: R1 (At least €30,000 a year)
- `must_have` — direct: R3, R4 · adjacent: R2 (Strong attention to detail)
- `important` — unclear: R5 (A quiet place to work)

R3 (`medium`) — your Excel tracker, self-reported, no artifact; R1 — met only at the top rate and roughly 22+ hours a week.

**Opportunity ledger.** The role as described isn't what these messages ask of you: money out (RR1, RR2), personal and bank details before any written offer (RR3), and a process that runs only in chat (RR4). The employer can't be established (RR5), and the contact address is off any employer domain (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (At least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer is verified independently, through contacts you find yourself. The payment, cheque and early-details requests are withdrawn or shown not to come from it. The pay terms are put in writing.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. Two searches returned nothing attributable, so its existence, size and product are not established | `[grounded]` searches below |
| Role | Remote order processing coordinator, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Pay against your floor | Reaching €30,000 at €26 an hour needs about 22 hours a week all year. "Up to" means the base rate isn't stated | `[inferred]` arithmetic from the posting's figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200, interquartile range €28,400–€34,100. A €26 hourly ceiling for a no-experience role sits well above that band, so the posting's pay is worth a question | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide (search snippet); `[grounded]` posting for the €26 |
| Contradictions | The posting mentions no equipment purchase, but the messages require €349 for a "work kit". The cheque is €2,850, so you'd send on about €2,500 against a €349 stated price | `[grounded]` posting against your messages |
| Unknowns | The employing entity, contract type, base rate, commission terms, who actually sent the messages | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | At least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. Fit is unclear because the posting gives only a ceiling and variable hours | `[grounded]` your statement; posting | G1 |
| R2 | Strong attention to detail | must_have | adjacent | medium | discovery | About 60 tickets a day is volume, and a weekly tracker is care, but there's no artifact | `[grounded]` your account of your work | none for this role |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Three years of written ticket work in Zendesk | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` silence | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Income of at least €30,000 (R1, hard_gate) | hard_gate | "Up to €26" and 15–30 hours; no base rate, no guaranteed hours, commission unspecified | A pay floor can't be confirmed from a ceiling | Salaried roles with a stated base salary | A written offer with base pay and contracted hours | `[grounded]` posting; `[generic]` band above |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Paying up front for a "refundable" kit is a known pattern in fake-job requests. The sender's identity is unresolved | `[grounded]` quote; `[generic]` pattern | Ask the employer, through contact details you find yourself on its own site, whether it requires this payment. Don't use the chat or the email address in the messages | confirmed |
| RR2 | Cheque deposit, then forwarding funds | red_flag | high | "Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | This request is very likely a scam. Don't deposit the cheque. A cheque can show in your account before it has cleared; if it's returned, the money you sent on is yours to cover. The forwarded amount is also far above the stated kit price | `[grounded]` quote and amounts; `[generic]` how cheques clear | As RR1 | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" (sent before the chat interview, with no written offer) | Together these are enough to open accounts or commit identity fraud. No written offer naming the role and pay existed when they were requested | `[grounded]` quote and sequence | As RR1 | confirmed |
| RR4 | Hiring run wholly in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Interview and offer both happened only in chat, so nothing places the sender at an employer | `[grounded]` posting and your messages | As RR1 | confirmed |
| RR5 | Employer not established | risk_signal | medium | — | Possible reasons, none ranked as likely: the firm is too new or small for a web footprint, the posting is stale, the name differs from how it's searchable, or it isn't actually hiring | `[grounded]` two searches, no attributable result | Can you share the jobs-site link, or the firm's own careers page? | unresolved |
| RR6 | Contact off any employer domain | risk_signal | low | "velloway.hr@postmail.example" | This shows only that the address isn't on a company domain. Whether the named employer is involved is unproven. Check the firm's own website for its contacts | `[grounded]` quote | Does the firm's own site list this address? | unresolved |
| RR7 | Stated pay far above the band | risk_signal | low | "Earn up to €26 an hour plus commission" | Well above the salaried median for a no-experience role. I rate it low because "up to" may be a ceiling few reach | `[inferred]` against `[generic]` band | What is the guaranteed base rate in the contract? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Keep your IBAN, PPS number and passport photo to yourself. Pay nothing, and if a cheque arrives, don't lodge it | see RR1–RR3 | `[grounded]` register | pending your approval |
| A2 | If you want to check the firm, search Ireland's Companies Registration Office public register yourself | An independent route that doesn't rely on the chat | `[generic]` | pending your approval |
| A3 | Keep the messages and tell the jobs site about the posting | Leaves a record, and the site can look at it | `[generic]` | pending your approval |
| A4 | Aim at salaried customer-operations roles with a stated base of €30,000 or more | Your floor sits inside the market band above | `[generic]` band; `[inferred]` fit | pending your approval |
| E1 | In real applications, lead with the weekly Excel tracker and training two new starters, as you described them | Your most concrete, checkable strengths | `[grounded]` your account | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers order processing coordinator"; neither returned a result. Role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland remote", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), read as a search snippet. The market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you'd like it, I can save this as a `tuesday-dossier.md` for your records.

**Upgrade menu**

- The jobs-site link, or any company website the posting points to → RR5 and role reality's organization row may close.
- A written offer stating base pay and contracted hours → R1 and RR7.
- A deeper research pass on the firm's name (up to 5 more searches and 2 more fetches) → RR5. Say the word and it runs.

**Questions**

1. (RR5) Which jobs site was the posting on, and did it link to a company website?
2. (RR3) What personal details did you give in your chat answers, for example your full name, address, phone or CV?
3. (R1, G1) Would you consider salaried roles with a stated base of €30,000 or more, or is setting your own hours essential?

Answer in text, paste a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.