I'll read the reference files the skill points to before building the assessment.
I've run three searches: the employer, the Band 5 pay band, and the team lead's public profile. Now I'm checking the employer's careers page to see whether this posting is live.
# Job underwriting: Community Staff Nurse, Band 5, Calderbrook Community Health CIC

## Decision snapshot

**Yes, Aoife, this one is worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R6, R8, R10 · adjacent: R5 (Home care of housebound adults) · unclear: R7 (Leg-ulcer care), R9 (Continence care), R11 (End-of-life visits) · absent: R12 (Own small caseload)
- `preferred`: absent: R13 (Doppler assessment)

R5: a credible bridge, its limit named; R12: absent, with the advert's senior-nurse support noted; R4, R7, R9, R11: unclear, awaiting your answers.

**Opportunity ledger.** The employer's own page matches the advert (RR1). Pay is stated and pool cars are provided (RR3), and supervision of the caseload is stated (RR4). Open points are the posting not yet confirmed on the employer's careers page (RR2), the unstated hours and rota (RR5), and mileage listed beside pool cars (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed on Calderbrook's own careers page (RR2); (2) hours, rota and mileage terms are checked against your own constraints once you state them (RR5, RR6); (3) the caseload and leg-ulcer gaps are framed as adjacent experience or learning, never as experience you hold (R5, R7, R12).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` employer's About page |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record. A small own caseload, supported by a senior community nurse | `[grounded]` advert |
| Scope read | An entry-level community post. The caseload is small and supervised, and the essential list asks for one year of post-registration experience | `[inferred]` from the advert's "small caseload", "supported by" and one-year essential |
| Market calibration | The advert's £31,050–£37,800 spans the survey's median of £34,300 (interquartile range £32,400–£36,600). In that survey a pool or lease car is the less common arrangement, so provision here is a positive, not the norm. The band is a pattern, not this employer's offer | `[generic]` Wardround 2026 community nursing pay survey (n=1,240); `[grounded]` advert for its own figures |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (search snippet only) |
| Unknowns | Hours, rota, weekend and on-call work; induction for nurses new to community; how mileage works alongside pool cars; closing date; start date | `[grounded]` advert silence on each |
| Contradictions | None found between the advert and the About page. The careers page was not retrievable, so the posting itself is not confirmed there | `[grounded]` About page against advert; careers page returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Registration stated as active, revalidation due March 2028. Stated, not checked. The register entry is the inspectable proof and the check is yours | `[grounded]` CV | You confirm your own NMC register entry shows active |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | Full licence, category B, stated. Stated, not checked. Your driving record is the proof | `[grounded]` CV | You confirm your licence status on your driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, well past the one-year essential | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on records and on any record system. No basis to claim it beyond a lead | `[grounded]` CV silence | Not asked this turn; add a line only if you confirm the detail |
| R5 | Care of housebound adults in their own homes | important | adjacent | medium | transferability | Eighteen months on the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: no stated ongoing care of housebound patients | `[grounded]` CV; `[grounded]` advert | See G1 |
| R6 | Wound care | important | direct | medium | none | Wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | unclear | low | discovery | Leg ulcers are not named in the CV's wound care. May exist, unstated | `[grounded]` CV omission | See G2 |
| R8 | Catheter care | important | direct | medium | none | Catheter care stated | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | The CV names catheter care only; broader continence care is unstated | `[grounded]` CV omission | Not asked this turn |
| R10 | Insulin administration | important | direct | medium | none | Insulin administration stated | `[grounded]` CV | none |
| R11 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care | `[grounded]` CV silence | See G3 |
| R12 | Own small caseload, with care planning, supported by a senior community nurse | important | absent | none | capability | You confirm you have never held your own caseload. Closure path: the advert says support is provided, so the question is how ramp-up works, not whether you can skip it | `[grounded]` your statement; `[grounded]` advert | Ask at the informal chat (plan Q1) |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You confirm you have never done one, and it is desirable, not essential. The team lead's public talk on Doppler training for staff new to community work suggests training is a topic for the team. Whether it is offered to hires is unknown | `[grounded]` your statement; `[grounded]` speaker page; `[inferred]` as to the offer | Ask at the informal chat (plan Q1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working alone with your own visits (R5, R12) | transferability | Home visits in the discharge-to-assess role. Nothing says who set the visit list or made the decisions at the door | It is the nearest bridge to a caseload, and it sets how honestly the application can describe it | Planning your own visit order; escalating a deteriorating patient from a home visit; deciding on a dressing or review without a senior present | A team rota or visit list, a service description, a reference from the team lead | `[grounded]` CV; `[inferred]` that it is the nearest bridge |
| G2 | Leg-ulcer care (R7) | discovery | Wound care is stated, but leg ulcers and compression are not | Leg-ulcer care is a named duty, and the team lead has spoken on it publicly | Dressing or reviewing venous leg ulcers on the ward; applying or advising on compression; a leg-ulcer teaching session | A training certificate, a competency sign-off | `[grounded]` CV; `[grounded]` advert |
| G3 | End-of-life care (R11) | discovery | Silent in the CV | A named duty in the advert | Caring for dying patients on the ward; anticipatory medicines; supporting families; a discharge to die at home | Competency record, a training certificate | `[grounded]` CV silence; `[grounded]` advert |
| G4 | Records and continence (R4, R9) | discovery | The CV is silent on both | R4 is an essential in the advert, so a line on it is worth having | The record system used on the ward and in the discharge team; bladder and bowel assessments | The system's name, an audit result | `[grounded]` CV silence |
| G5 | Doppler (R13) | capability | Never done, confirmed by you | Desirable only | A closure path, not a recall prompt: ask whether training is provided | The employer's induction outline | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the advert | positive_signal | — | "community interest company running adult community nursing … across Calderdale under an NHS contract" | Calderbrook exists as described, and the team lead is a named public member of its Halifax team | `[grounded]` About page and speaker page | Who sits on the interview panel? | noted |
| RR2 | Posting not confirmed on the employer's careers page | unknown | — | "Current vacancies are listed on our careers page" | The posting may be live under a different address, closed, or listed elsewhere | `[inferred]` from the careers fetch returning no page | Can you point me to this role on your own careers page, and give its closing date? | unresolved |
| RR3 | Pay stated and pool cars provided | positive_signal | — | "£31,050–£37,800 a year"; "pool cars are provided" | Transparent pay, with a benefit less common in the survey | `[grounded]` advert; `[generic]` survey pattern | Where in the band do new-to-community nurses usually start? | noted |
| RR4 | Supervision and a small caseload are stated | positive_signal | — | "a small caseload of your own, supported by a senior community nurse" | The entry level is realistic for a nurse new to community | `[grounded]` advert | What does the first three months look like before the caseload is full? | noted |
| RR5 | Hours, rota, weekends and on-call unstated | unknown | — | none in the advert | Community nursing rotas may include weekends or evenings, but this advert does not say | `[generic]` role-family pattern | What are the working hours, and is there weekend or on-call work? | unresolved |
| RR6 | Mileage stated beside pool cars | unknown | — | "pool cars are provided … plus mileage" | Mileage may apply only when a personal car is used, or the advert may be loosely worded | `[inferred]` from the two phrases side by side | When is mileage paid, given that pool cars are provided? | unresolved |

## Application plan

Everything in this section is proposed and nothing is finalized until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the existing line to its own opening Experience bullet, wording unchanged: "seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge" | R5; it is your nearest evidence of home visiting | `[grounded]` CV, your own sentence | resume_edits_pending_approval |
| E2 | Group "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" under one clinical-skills line, wording unchanged. Add leg-ulcer care, end-of-life care or continence care only if you confirm them | R6, R8, R10; the advert's duties | `[grounded]` CV | resume_edits_pending_approval |
| Q1 | At the informal chat with Rhiannon Mabbott, ask: how does a nurse new to community build up a caseload, is Doppler training provided, and what are the hours and rota? Say plainly that you have not held your own caseload or done Doppler assessment | R12, R13, RR4, RR5 | `[grounded]` your statements; `[grounded]` advert | pending your approval |
| A1 | Check your own NMC register entry and driving record before you apply | R1, R2 | `[grounded]` stated, not checked | pending your approval |
| A2 | Confirm the posting and closing date on Calderbrook's careers page | RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. R1 and R2 are your statements and the checks are yours. Your National Insurance number was not needed, was not used, and is not repeated here.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved role reality's organization and contradictions rows, RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change pay scale 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott); snippet only. Moved the hiring contact row, R13 and plan Q1 |

## One-line dossier offer

I can write all of this to `tuesday-dossier.md` for you to keep.

## Upgrade menu

- A line on how you worked at the door in the discharge team (G1) → R5 and R12 firm up, and E1 can carry more.
- Any leg-ulcer or end-of-life training or competency record (G2, G3) → R7 or R11 moves from unclear to a firmer band.
- Your constraints on pay floor, hours, days and travel → the hard-gates line can check RR5 and RR6 against them.
- A deeper research pass on Calderbrook (recent news and public staff reports; up to 5 more searches and 2 more fetches) → RR1, RR2 and the opportunity ledger; say the word and it runs.

## Questions

G1: In the discharge-to-assess role, who decided your visit order and what you did at each home, and was there a time you had to act alone, such as escalating or changing a plan, without a senior present?

G2: Have you cared for leg ulcers, whether dressing or reviewing them or applying compression, and do you hold any training or sign-off for it?

G3: Have you cared for patients at the end of life on the ward or through a discharge home to die, and what part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.