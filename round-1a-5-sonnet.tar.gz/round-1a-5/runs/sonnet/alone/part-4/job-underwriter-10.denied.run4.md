I've read the skill's reference files, and I'm now loading the search tool so I can check whether Fernquay exists, what the role pays in Ireland, and Ronan Kehoe's public professional footprint.
Search permission was denied, so I couldn't verify Fernquay. The analysis below uses only what you pasted, and everything that rests on research is marked as not done.

# Job Underwriting Assessment: Product Designer at Fernquay

## Decision snapshot

**Yes, it's worth taking the call and applying. I couldn't confirm Fernquay exists from here, so verify it before you invest much effort (RR1). Nothing in the posting or the WhatsApp message asks you for money or personal details. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two Galway office days), R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Research calls with school owners), R8 (Own the booking flow end to end)
- `important`: adjacent: R9 (First designer, no design peer)

R8 — checkout is one stage of a booking flow, so your ownership needs confirming; R6 — usability sessions are not discovery calls with owners; R9 — never being the only designer is the main stretch.

**Opportunity ledger.** The employer can't be established from here (RR1), and the equity terms are unstated (RR3), but pay is published (RR2), and the message matches your application (RR5). Success measures are not stated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two Galway office days), R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies through its own site and an invite from its own domain (RR1); (2) pay and equity terms are confirmed in writing before you commit deeply (R2, RR3); (3) you go in with the first-designer stretch named honestly as a stretch (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person company in Galway building booking software for sea-kayak and surf schools; I could not attribute it to a public entity (RR1) | `[grounded]` posting text; entity not established |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reports to / works with | Co-founder Ronan Kehoe, most closely | `[grounded]` posting |
| Working pattern | Hybrid: two days a week at the Galway office, otherwise flexible | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | A broad solo-designer remit: design, research and flow ownership in one seat | `[inferred]` from "first designer" against the three duties listed |
| Market calibration | Not obtained. The pay search was refused, so I make no claim about whether this band is normal | `[grounded]` the band comes from the posting; no market figure is claimed |
| Outcomes in 90 days or a year | Not stated; the posting names no deliverables or success measures | `[grounded]` posting silence |
| Unknowns | Equity terms; whether a work task will be asked for ("one messy real project"); design mentoring or peers; success measures | `[inferred]` from the posting's silence |
| Contradictions | None between the posting and the WhatsApp message; the company's own careers page was not checked | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | unclear | medium | hard_gate | You live in Galway, which suits the location. You haven't said whether two fixed office days work for you, and no constraints were given. | `[grounded]` your background and the posting | Q1 |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so I can't say whether the band meets it. Confidence is `none` because there is no stated constraint to grade. | `[grounded]` posting figure; no floor stated | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer at a Dublin travel-booking company. This is your own account with no artifact inspected. | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is your own statement. No file or case study has been inspected here. | `[grounded]` your background | none |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. | `[grounded]` your background | none |
| R6 | Run research calls with school owners | must_have | adjacent | medium | transferability | Usability sessions carry over to research calls. The limit is that you haven't mentioned discovery conversations with business buyers, and school owners are the buyers of the software. | `[grounded]` your sessions; `[inferred]` that owners are the buyers | Q3 |
| R7 | Work directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. | `[grounded]` your background | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a checkout flow, which is one stage of a booking flow. Whether you owned the stages before and after it is unknown. | `[grounded]` your checkout redesign; `[inferred]` that checkout is one stage | Q2 |
| R9 | Be the first designer, with no design peer | important | adjacent | medium | transferability | Your checkout ownership and your own research sessions are a credible bridge. The limit is that you have never been the only designer, and you said so. | `[inferred]` from "first designer" in the posting; `[grounded]` your statement | Name it as a stretch. Ask what design support exists (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R8, must_have) | discovery | A checkout redesign. The stages before and after it are not described. | The posting centres on owning the whole flow, and the answer decides how you frame your fit. | Search or availability screens you shaped; confirmation and cancellation emails; handoff specs you wrote | The checkout case study you already sent, plus any before-and-after flow map | `[grounded]` your description; `[inferred]` that the posting's emphasis makes this the likeliest probe |
| G2 | Research with business owners (R6, must_have) | transferability | Usability sessions with customers; no calls with owners or buyers mentioned | The posting names owner calls as a core duty. | Calls with partners, suppliers or operators at your travel-booking company; sales-support sessions; discovery interviews you ran | A discussion guide or synthesis note, with confidential details removed | `[grounded]` your description; `[inferred]` the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a hiring employer. You report finding little online. | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` your report of thin results | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay band stated openly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The employer states its pay up front. I could not set it against a market band. | `[grounded]` posting | What is the progression after year one? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage is given, but not the vesting, share class, strike price or dilution. | `[grounded]` posting silence | What are the vesting schedule, share class and strike price, and what is the current fully diluted share count? | unresolved |
| RR4 | Success measures and design support unstated | unknown | — | "own the booking flow end to end" | A solo-designer seat with no stated outcomes or design peer may mean unclear priorities. | `[inferred]` from the scope against the posting's silence | What would a good first six months look like, and who gives you design feedback? | unresolved |
| RR5 | The message matches your application | positive_signal | — | "we loved the checkout case study" | The follow-up refers to your submitted work, names the CTO and gives the call length. | `[grounded]` the WhatsApp message you pasted | Who else will join the call after Saoirse? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat WhatsApp scheduling as routine. Before the call, confirm the invite came from an address on Fernquay's own website, and ask Ronan to confirm the time by email too | A chat message to schedule a video call is a normal step, and the check costs you little | `[generic]` small-company hiring practice; `[grounded]` your message | pending your approval |
| Q1 | Ask the RR1, RR3 and RR4 questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Lead with the two things you wrote: you redesigned a checkout flow, and you ran monthly usability sessions with customers. Don't call them end-to-end ownership or discovery research until you've answered Q2 and Q3 | Each clause traces to your own sentences | `[grounded]` your background | pending your approval |
| P2 | Say plainly that you've been in squads and not the only designer, then ask how design feedback works | You said so, and stating it avoids a probe later | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer job Galway careers" were both refused. This would have moved RR1 and the organization row in role reality. |
| 2. Role-family sweep | unavailable | A search for "product designer salary Ireland startup mid-level" was refused. It would have moved the market calibration row and RR2. |
| 3. Hiring manager's public footprint | unavailable | A search for the co-founder's name with the company was refused. It would have moved the scope read and P1. |

## Upgrade menu

- Allow web search in this session → the three L1 checks above rerun, which could close RR1 and fill in the market calibration.
- Search access would also allow one deeper company pass (up to 5 more searches and 2 more fetches). Say the word if you want it.
- Fernquay's careers page link, or the domain of the email invite → RR1 gets resolved or confirmed.
- Your salary floor and your view on two office days → R1 and R2 move to `direct` or `hard_gate_fail`.
- The checkout case study, or a flow map of it → R4 and R8 can rise to `high` once I've inspected it.
- Equity terms in writing → RR3 closes.
- A dossier of this assessment, if you'd like one: `tuesday-dossier.md`, saved for later use.

**Questions**

Q1 (R1, R2): Do the €52,000–€60,000 band and two Galway office days a week both meet your own terms?

Q2 (R8): In the checkout redesign, which stages did you personally own, from research through to what engineers shipped?

Q3 (R6): Have you run conversations with business owners or buyers, as opposed to usability sessions with end customers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.