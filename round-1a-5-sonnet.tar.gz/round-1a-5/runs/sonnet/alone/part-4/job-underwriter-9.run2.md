Checking whether Marrowgate Housing exists as described, and what the market pays for this role, before I give you the assessment.
**Yes, this is normal. Your rule is sound before an offer, but this is after one.** The offer asks for the details only once you accept. It names the role, pay, manager and hours, and it follows two in-person interviews. Status: `conditional_go`. I'd accept, on the conditions below.

I tried two web searches to check Marrowgate and the market pay for this role, and both were refused. Nothing here comes from outside research, so I haven't checked the company myself. You've met them in person, which counts for a lot. Please don't paste your PPS or passport numbers to me; I don't need them.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R3 · unclear: R1 (Hybrid, two days a week in the Limerick office), R2 (Salary €38,000–€42,000)
- `must_have` — direct: R4, R7, R9, R11 · adjacent: R6 (Monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important` — unclear: R10 (Answering staff payroll queries) · absent: R8 (Pension changes)

R6 — a credible bridge, its limit named; R8 — never done hands-on, by your own account; R5 — Irish tax knowledge not yet shown in your background.

**Opportunity ledger.** The offer matches the ad and the process you went through (RR1). Three things are open: contract terms beyond the email (RR3), who owns pension changes (RR2), and cover for a 240-person payroll (RR4).

- **Hard gates:** none failed (R3 `direct`); unconfirmed: R1 (Hybrid, two days a week in the Limerick office), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) a written contract, with probation, notice, pension and leave terms, before you resign from your current job (RR3); (2) the €40,000 and the two Limerick days meet your own limits (R1, R2); (3) pension changes are raised openly and training is agreed (R8, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer email. Existence not checked by me (search refused) |
| Mandate | Run monthly payroll for 240 staff, starters, leavers and pension changes, monthly payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` ad |
| Offer | Permanent, €40,000, reporting to Declan Garvagh, Finance Manager, hybrid with two days a week in the Limerick office, start after your notice period | `[grounded]` offer email |
| Market calibration | Not established, because the role-family search was refused. The offer sits at the midpoint of the advertised €38,000–€42,000 | `[grounded]` ad and offer figures; no market band |
| Unknowns | Contract terms beyond the email; which two office days; payroll software; team size and cover; who handles pension changes now | `[inferred]` from what the ad and offer leave out |
| Contradictions | None between the ad and the offer on title, pay band, hybrid pattern or location | `[grounded]` ad compared with offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The ad and offer state it. You haven't told me your location or limits, so I can't call it met | `[grounded]` ad and offer; your constraints not given | G5 question |
| R2 | Salary €38,000–€42,000 | hard_gate | unclear | none | hard_gate | Offer is €40,000. Your own minimum is not given | `[grounded]` ad and offer; your floor not given | G5 question |
| R3 | Payroll qualification or working towards one | hard_gate | direct | medium | none | You hold the Payroll Technician certificate (2024). It is self-reported, with nothing inspected | `[grounded]` your background | A copy of the certificate would raise to high |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff at a hotel group | `[grounded]` your background | A reference from the hotel group would raise to high |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You describe payroll work but not which tax regime or filings you handled. Your PPS number suggests Irish, but that is not evidence of this | `[grounded]` background silent on the tax detail; `[inferred]` likely relevant | G3 question |
| R6 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Strong bridge: full payroll cycles for 90 staff. Limit: not run at 240 headcount or on a monthly cycle | `[grounded]` background; `[inferred]` adjacency | Name this limit honestly if asked |
| R7 | Process starters and leavers | must_have | direct | medium | none | Starters and leavers are stated in your background | `[grounded]` your background | none |
| R9 | Reconcile payroll to the general ledger monthly | must_have | direct | medium | none | You did a monthly payroll-to-ledger reconciliation | `[grounded]` your background | none |
| R11 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your background | none |
| R10 | Answer staff payroll queries | important | unclear | none | discovery | Your background doesn't mention it | `[grounded]` background silent | Low priority, no question asked |
| R8 | Pension changes | important | absent | none | capability | In your words: "I've never done pension changes myself — my manager handled those." Role-family point: pension changes usually follow scheme rules, so training on this employer's scheme is the normal closure | `[grounded]` your statement; `[generic]` on scheme-specific training | Ask for training and the scheme details (RR2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R8, important) | capability | You have seen them handled but haven't processed them | It is a named duty, and the first month will test it | Anything you prepared for the pension scheme: enrolments, opt-outs, contribution changes, even partial or supporting work | A scheme guide or procedure note you worked from | `[grounded]` your statement; `[generic]` that scheme-specific training is normal |
| G2 | Monthly payroll at 240 staff (R6, must_have) | transferability | Bridge from 90 staff on a fortnightly cycle | Scale is a step up even if the method is the same | Larger or multi-site runs, or monthly pay for any group | A payroll run summary, with figures sanitised | `[grounded]` your background |
| G3 | Irish PAYE, PRSI, USC (R5, must_have) | discovery | Payroll is stated, but not the Irish tax handling | A must-have row left unclear | Calculating or checking deductions, year-end returns, Revenue filings, a payslip review | A sanitised payslip layout or a year-end checklist | `[grounded]` background silent on regime |
| G4 | Staff payroll queries (R10, important) | discovery | Not mentioned | Part of the daily job | Handling pay queries or payslip errors | An example resolution, with names removed | `[grounded]` background silent |
| G5 | Your own limits on location and pay (R1, R2, hard_gate) | hard_gate | I don't know your minimum or your commute | These are gates I can't mark met without your words | Your stated minimum salary and the days you can reach Limerick | Your own words are enough | `[grounded]` your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer consistent with the ad and your interviews | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The role, pay, manager and hybrid pattern are specific and match the advertised terms | `[grounded]` ad compared with offer email | Can you confirm the contract will carry the same title, pay and reporting line? | noted |
| RR2 | Pension-change ownership unclear | unknown | — | "process starters, leavers and pension changes" | The post may have no one to cover pension changes while you learn them | `[inferred]` from the ad's duty list and your gap | Who handles pension changes now, and what training or handover will I get? | unresolved |
| RR3 | Terms beyond the email not stated | unknown | — | "starting on a date we agree once your notice period ends" | A full contract, with probation, notice and pension and leave terms, may follow separately | `[inferred]` from what the email omits | Will a written contract with probation, notice, pension and leave terms be issued before I give notice? | unresolved |
| RR4 | Team and cover for 240 staff | unknown | — | "Run the monthly payroll for our 240 staff" | The post may be sole payroll, with no named cover for leave or peaks | `[inferred]` from the ad's silence on team size | Is this a sole-payroll post, who covers my leave, and which system do you use? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter your bank details, PPS number and passport scan only in the employer's own portal, reached from an address you have checked on its website. Don't send them by email reply | Details go only where the employer controls the page | `[generic]` standard onboarding practice | pending your approval |
| A2 | Ask for the written contract before you serve notice, and use the five working days to get it | Your notice period depends on the terms, and RR3 is open | `[generic]` how offers usually convert to contracts | pending your approval |
| A3 | Raise pension changes openly. Proposed wording: "I haven't processed pension changes myself; my manager handled them at the hotel group, so I'd like to understand your scheme and what training there is." | Traces to your own sentence; it names the gap and asks for the closure | `[grounded]` your statement | pending your approval |
| A4 | Bring the original passport on your first day, as the offer asks | Stated in the offer | `[grounded]` offer email | pending your approval |

**Optional extra, built only on your approval:** a short acceptance email that also asks for the written contract and the pension-change handover, since the five-day window makes that your next step.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Marrowgate Housing Limerick housing association" was refused. It would have checked that the employer exists and matches the posting |
| 2. Role-family sweep | unavailable | Search "payroll administrator Ireland salary 2026 PAYE PRSI USC" was refused. It would have given a market band for the calibration row |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh is named, so a query could be formed, but no search was sent because permission was refused. It would have fed the scope read |

I'd be glad to turn this into a saved dossier if that would help you track the open items.

## Upgrade menu

- Permission to search → target 1 would confirm Marrowgate and its careers page; target 2 would set the €40,000 against a market band.
- Your minimum salary and commute limits → R1 and R2 close, and the hard-gates line gains certainty.
- Your answer on Irish tax work → R5 moves toward `direct`.
- A copy of the certificate or a hotel-group reference → R3 and R4 move to `high`.
- A deeper pass on the company (up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

G5 — Does €40,000 meet your own minimum, and can you reach the Limerick office two days a week without trouble?

G3 — Was your hotel group payroll Irish, and did you handle the PAYE, PRSI and USC calculations or Revenue filings yourself?

RR3 — Have you received only this email, or a full contract as well?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.