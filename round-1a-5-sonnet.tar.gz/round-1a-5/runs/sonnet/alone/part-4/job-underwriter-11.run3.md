Search permission was denied, so everything below rests on your pasted text and background, and nothing about either employer has been checked.

## Decision snapshot

**Duinvaart (Operations Analyst): yes, worth your time. Status: `conditional_go`.**
**Kroonhaven (Supply Planner): not on this evidence. R10 and R12, both `must_have` rows, are absent. Status: `no_go`.**

**Fit ledger, Duinvaart**
- `hard_gate`: unclear: R1 (Hybrid, three days a week in Rotterdam)
- `must_have`: direct: R2, R3, R4
- `important`: direct: R5a, R6 · unclear: R5b (temperature compliance)
- `preferred`: adjacent: R7 (Dutch a plus)

R5b is the open question on the substance; R1 waits on your location.

**Fit ledger, Kroonhaven**
- `hard_gate`: unclear: R8 (On-site in Utrecht)
- `must_have`: adjacent: R9 (fluent Dutch) · unclear: R11 (advanced Excel) · absent: R10 (3+ years supply or demand planning in FMCG), R12 (SAP IBP or similar planning system)
- `important`: adjacent: R13 (run the weekly S&OP meeting)

R10 and R12 — no planning work or planning system in your history; R9 — a language level below the stated one.

**Opportunity ledger.** Duinvaart: the duties are specific and match your tools (RR3). Its employer is unchecked (RR1) and its pay is not stated (RR2). Kroonhaven: employer unchecked (RR4) and pay not stated (RR5).

- **Hard gates, Duinvaart:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Hard gates, Kroonhaven:** none failed; unconfirmed: R8 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go (Duinvaart):** (1) R1 is workable for where you live; (2) G1 shows you have temperature or cold-chain exposure, or you accept R5b as a learning gap; (3) the posting verifies on Duinvaart's own careers page (RR1).
- **What would change Kroonhaven:** R10 and R12 would need to be backed by planning work or planning-system experience you haven't mentioned.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart: organization | Duinvaart Cold Chain, Rotterdam, with a refrigerated fleet | `[grounded]` JD |
| Duinvaart: mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Duinvaart: working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Duinvaart: scope read | An analyst post built around one team's reporting loop, with no people management | `[inferred]` from the duty list |
| Duinvaart: unknowns | Pay; fleet size; how temperature data is captured; working language | `[grounded]` JD silent on each |
| Kroonhaven: organization | Kroonhaven Foods, Utrecht, with a chilled ready-meals range | `[grounded]` JD |
| Kroonhaven: mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Kroonhaven: working pattern | On-site in Utrecht, no hybrid stated | `[grounded]` JD |
| Kroonhaven: scope read | A planner who owns the plan end to end and chairs the cross-functional meeting, not an analyst supporting someone else's plan | `[inferred]` from "own" and "run" in the JD |
| Kroonhaven: unknowns | Pay; team size; which planning system is actually in use | `[grounded]` JD silent on each |
| Contradictions | None visible inside either posting. Neither could be checked against the employer's own pages. | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Duinvaart: hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You gave no location or schedule constraint. Your current job is in Amsterdam, but where you live is not stated. | `[grounded]` no constraint stated | G2 |
| R2 | Duinvaart: 2+ years in logistics or operations analysis | must_have | direct | medium | none | Your stated 4 years as an operations analyst at a parcel carrier is specific. It is self-reported with nothing inspected yet, so `medium`. | `[grounded]` your background | none |
| R3 | Duinvaart: strong SQL | must_have | direct | medium | none | You use SQL daily. Confirmed and specific, with no artifact inspected. | `[grounded]` your background | none |
| R4 | Duinvaart: Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily and built the on-time delivery dashboard your depot managers use. | `[grounded]` your background | A sanitized screenshot would raise it to `high` |
| R5a | Duinvaart: track on-time delivery | important | direct | medium | none | You built the on-time delivery dashboard, so this is a direct match. | `[grounded]` your background | none |
| R5b | Duinvaart: track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | You mentioned no temperature-controlled or cold-chain work. A parcel carrier may or may not have had any. | `[grounded]` your background is silent on it | G1 |
| R6 | Duinvaart: work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your dashboard. | `[grounded]` your background | none |
| R7 | Duinvaart: Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is the same skill at a lower level. The limit is that it falls short of fluent. | `[grounded]` your stated level | State it as conversational, never as fluent |
| R8 | Kroonhaven: on-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or commute constraint was given, and the posting offers no hybrid. | `[grounded]` no constraint stated | G2 |
| R9 | Kroonhaven: fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch does not meet "fluent". A role that chairs a weekly meeting likely runs in Dutch. | `[grounded]` your stated level; `[generic]` that chairing a meeting needs the working language | Carry as a probable screen-out |
| R10 | Kroonhaven: 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning. This is an experience length, not a gate. | `[grounded]` your own statement | G3 |
| R11 | Kroonhaven: advanced Excel | must_have | unclear | low | discovery | Your background lists SQL and Power BI but not Excel. Analyst roles commonly use it. | `[grounded]` background silent; `[generic]` that analyst roles commonly use Excel | Ask only if you want to pursue this role |
| R12 | Kroonhaven: SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems. No planning-system use is stated. | `[grounded]` your background | G3 |
| R13 | Kroonhaven: run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review, which is a recurring cross-team review. The limit is that you have not run a meeting that balances demand, supply and capacity. | `[grounded]` your background | Use as a bridge only if you apply |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b, important) | discovery | Your background is silent on temperature-controlled work. | It is the one duty at Duinvaart you cannot yet point to | Tracking chilled, pharma or fresh-food parcels; a cold-chain client contract; any compliance measure beyond on-time delivery | A dashboard screenshot or a report extract | `[grounded]` background silence; `[inferred]` that it could lift R5b from `unclear` |
| G2 | Location workability (R1 and R8, hard_gate) | hard_gate | No home location or commute limit was stated. | A gate nothing settles yet, for both roles | none | none | `[grounded]` no constraint stated |
| G3 | Planning experience (R10 and R12, must_have) | capability | No planning work or planning system in your history | These two rows are why Kroonhaven is `no_go`. A path in would be a more junior planning role, or planning-system coursework. | none | none | `[grounded]` your statement; `[generic]` that such paths exist |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart not checked against its own pages | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The posting was not compared with the company's careers page, because the search was denied. Nothing in the text suggests a problem. | `[grounded]` search denied | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Duinvaart pay not stated | unknown | — | no salary in the posting | The figure may or may not meet your floor, which you haven't given | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Duinvaart duties are concrete | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The mandate is specific and matches the tools you use | `[grounded]` JD | How many depots and vehicles would this role cover? | noted |
| RR4 | Kroonhaven not checked against its own pages | unknown | — | "Kroonhaven Foods, Utrecht" | Same as RR1: unchecked because the search was denied, with no sign of a problem in the text | `[grounded]` search denied | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR5 | Kroonhaven pay not stated | unknown | — | no salary in the posting | The figure is unknown, and no floor was given to compare it against | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |

## Application plan

Every row below is `resume_edits_pending_approval`, and that covers the advice as well as the table. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | For Duinvaart, lead the CV with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran | see R4, R5a, R6 | `[grounded]` your background | pending your approval |
| E2 | State your Dutch as conversational. Don't claim fluent anywhere. | see R7, R9 | `[grounded]` your stated level | pending your approval |
| W1 | Offer a sanitized dashboard screenshot | see R4 | `[grounded]` R4 row | pending your approval |
| Q1 | Ask the RR1, RR2 and RR3 questions verbatim in the interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Apply to Duinvaart once G2 confirms the commute works | see R1, RR1 | `[grounded]` R1 row | pending your approval |
| A2 | Skip Kroonhaven unless you want to pivot into planning. If you apply anyway, present yourself as an analyst moving toward planning. | see R10, R12 | `[grounded]` R10, R12 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals"; both were refused for lack of permission. This would have moved RR1 and RR4 and role reality's contradictions row. |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Rotterdam salary Netherlands" and "supply planner FMCG Netherlands salary Dutch required"; both were refused. This would have moved a market calibration line and RR2 and RR5. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Dossier offer

If you want a record to carry into later turns, I can write `tuesday-dossier.md` from this assessment.

## Upgrade menu

- Search permission → RR1 and RR4 resolve, and a market pay band lands in role reality (the same four searches, no more).
- Your location and any hard limits (G2) → R1 and R8 settle, and the hard-gates lines stop carrying the "constraints not given" flag.
- Your pay floor → RR2 and RR5 become checkable against it.
- An answer to G1, or a sanitized dashboard screenshot → R5b or R4 firms up.
- A hiring manager's name → role reality's scope read and which story the plan leads with.

## Questions

G1 — At the parcel carrier, did you track or report anything temperature-controlled or time-sensitive, such as chilled parcels or a cold-chain contract? What did you own?

G2 — Where do you live, and is three days a week in Rotterdam (Duinvaart) or five days on-site in Utrecht (Kroonhaven) workable for you?

RR2 — Do you have a minimum salary you won't go below?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.