I'm still reading the skill's reference files (decision rules, question selection), and then I'll write the assessment.
**Research tier: L1 — searches 4 of 5, fetches 0 of 2**

## Decision snapshot

**Yes, worth taking the call, and nothing in what you shared or what I could find points away from it. Fernquay's own pages match the posting (RR1). I can't see your pay floor, so R2 stays open · `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R8 (Own the booking flow end to end)
- `important` — adjacent: R6 (Research calls with school owners), R9 (First designer)

R8 (`medium`) — checkout is one part of a booking flow, ownership scope not yet stated; R9 (`low`) — no evidence either way on solo design work, and you've told me you haven't done it.

**Opportunity ledger.** Consistent and transparent: the employer's own pages agree with the posting (RR1), and the stated pay sits inside the market band (RR4). Open items are the runway of a customer-funded company (RR3), the equity terms (RR2), and who decides design direction (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your own minimum salary is at or below the stated band — R2; (2) runway and equity terms get concrete answers on the call — RR2, RR3; (3) you are comfortable being the only designer and say so plainly, not as a gap you hide — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` search result for fernquay.example/about |
| Mandate | First design hire: own the booking flow, run research calls with school owners, ship alongside two engineers | `[grounded]` your pasted JD; the careers page confirms "our first design hire" |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` JD; careers page agrees |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity. The careers page repeats the cash figure and says only "plus equity" | `[grounded]` JD; careers page |
| Market calibration | For product designers with 3 to 5 years in Ireland, median base €57,000, interquartile range €51,500–€62,000. The posted band sits inside that range, close to the median. This is the market, not Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report; `[grounded]` JD for the posted figures |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and was previously a product lead for five years at a Galway travel-software company | `[grounded]` search result for his Fernquay profile (roles only) |
| Scope read | You would work closely with a product-minded CEO, so design direction may sit largely with him (RR5) | `[inferred]` from his product-lead background against the JD's "work most closely with our co-founder" |
| Contradictions | None between the JD and the careers page. The About page names Saoirse Doyle as co-founder; the CTO title appears only in the WhatsApp message. The About page adds sailing schools to the JD's "sea-kayak and surf" | `[grounded]` About and careers pages against your two pasted texts |
| Unknowns | Equity terms, runway, design decision rights, how many customers | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, so the location term looks met. I don't know your commute or whether two fixed office days suit you | `[grounded]` your message | Ask in Q1 |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The JD states the pay clearly. You haven't given a minimum, so I can't say whether it clears it | `[grounded]` JD; your floor not given | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | You describe 4 years as a product designer at a Dublin travel-booking company. A CV-level claim, no artifact inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily", self-reported. Your checkout case study would be the inspectable proof | `[grounded]` your background | Send the case study with the application |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Usability testing is one kind of research; the JD doesn't specify the kind | `[grounded]` your background | none |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were with travel customers. Calls with small-business owners about how they run their schools are a different audience and a different kind of conversation. Limit: you've mentioned no interviews with business owners | `[grounded]` your background; `[inferred]` that owner calls differ in kind from usability sessions | See G3 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow, which is one part of a booking flow. Whether you owned availability, selection and confirmation too is not stated. Resolved downward until you say | `[grounded]` your background; `[inferred]` that checkout is a part of a booking flow | G1 |
| R9 | You would be our first designer | important | adjacent | low | transferability | You've never been the only designer. Your checkout work in a squad is adjacent, but nothing shows you setting direction, tools or process without design peers | `[grounded]` your background | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking-flow ownership (R8, must_have) | discovery | A confirmed checkout redesign. Scope beyond checkout, and who made the final design calls, are unstated | A must-have at `adjacent`. The JD's "end to end" is the phrase most likely to be probed | Design work on availability or date selection, basket, payment or confirmation emails; calls you made where no one else reviewed the design | Your checkout case study, flow maps, before and after screens | `[grounded]` background silent on scope; `[generic]` that "end to end" gets probed |
| G2 | Working as the only designer (R9, important) | transferability | No sole-designer experience, stated by you | The role is a first design hire, so how you'd cope without design peers is the central question | A side project, freelance job or internal tool where you made every design decision; setting up a component library or research habit in a squad | A side project or a Figma file you built from scratch | `[grounded]` your statement; `[inferred]` that the gap is central, from the JD's "first designer" |
| G3 | Research with business owners (R6, important) | transferability | Usability sessions with customers only | Fernquay's research is with school owners, not consumers | Calls with partners, suppliers, B2B clients or internal stakeholders about how they work | A discussion guide or a research summary | `[grounded]` background; `[inferred]` that owner calls differ. No question on G3 this turn: the budget went to higher-impact rows |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer, role and pay consistent across the company's own pages | positive_signal | — | "Open now: Product Designer, our first design hire. Hybrid, two days a week in Galway. €52,000–€60,000 plus equity." | The posting is live and matches your copy | `[grounded]` careers page against your pasted JD | Who else on the team would I work with day to day? | noted |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may come with vesting, a strike price or dilution terms that change its value | `[generic]` early-stage equity usually has such terms | What are the vesting schedule and strike price, and what is the latest valuation or share count? | unresolved |
| RR3 | Customer-funded six-person company | risk_signal | low | "funded by its customers" | A bootstrapped firm depends on revenue; the salary is only as durable as customer income and growth | `[inferred]` from "funded by its customers" on the About page | How many schools use Kelproster, how fast is it growing, and how many months of runway are there at the current burn? | unresolved |
| RR4 | Pay stated and within the market range | positive_signal | — | "€52,000–€60,000" | The band is transparent and near the market median for this experience | `[grounded]` JD; `[generic]` salary report median and range | Is there room within the band, and how is it set? | noted |
| RR5 | Design decision rights unclear | unknown | — | "You will work most closely with our co-founder, Ronan Kehoe" | The CEO may effectively set product direction, and "own the booking flow" may mean ownership of execution, not of decisions | `[inferred]` from the JD's wording against his product-lead background | When you and Ronan disagree on a design decision, who decides? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite came from an address on fernquay.example and that the call link is the one in that email. Their careers page says applications go to jobs@fernquay.example | Moving to WhatsApp to arrange a call is ordinary for small companies. The invite's email domain is a quick way to confirm who sent it | `[generic]` small teams often schedule by chat; `[grounded]` careers page address | pending your approval |
| A2 | Lead with the checkout redesign as your real project, since they have said they liked it. Suggested wording: "I redesigned the checkout flow at a Dublin travel-booking company, ran monthly usability sessions with customers, and worked in a squad with four engineers." | See R3, R5, R7, R8. Every clause traces to your own sentences | `[grounded]` your background | pending your approval |
| A3 | Say plainly that you haven't been the only designer, and say which parts of the checkout work you'd carry over | See R9. Naming it first is easier to defend than being asked | `[inferred]` from the JD's emphasis on a first designer | pending your approval |
| A4 | Ask the questions in RR2, RR3 and RR5 on the call, and bring the question about school owners' habits | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Rehearsing the call itself is the job of the mock-interview skill.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (result: "About Fernquay", fernquay.example/about) and "Fernquay product designer Galway careers" (result: "Product Designer — Fernquay careers", fernquay.example/careers/product-designer). I read the result text only and fetched neither page. Role reality's organization, pay and contradictions rows; RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 2026 3-5 years experience startup" (result: "Tillerby 2026 Ireland Design Salary Report", tillerby.example/2026-ireland-design-salary-report). Market calibration row; RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder" (result: "Ronan Kehoe — Co-founder, Fernquay", linkedin.example/in/ronan-kehoe). Role reality's hiring manager and scope rows; plan A2's positioning |

## Dossier offer

If you want a record of this assessment to carry forward, I can write it up as a `tuesday-dossier.md`.

## Upgrade menu

- Your answer on pay and office days → R1 and R2 close, and the status likely moves to `go`.
- A link to the checkout case study → R4 and R8 can go to `high`, and A2's wording gets checked against what it shows.
- An answer on G1 → R8 resolves or its limit is named.
- An answer on G2 or a side project → R9's bridge strengthens or the limit is named.
- Calls with business owners or other B2B stakeholders → R6's bridge strengthens.
- Fernquay's customer count, funding history or recent news → RR3 closes or escalates. A deeper research pass would look at this (up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **R1 and R2** — Is €52,000–€60,000 at or above your minimum, and do two fixed office days a week in Galway work for you? Is there any other deal-breaker, such as start date or notice period?
2. **G1** — In the checkout redesign, which parts did you personally own, who made the final design calls, and did your work reach beyond checkout into availability or date selection?
3. **G2** — Have you ever made design decisions without another designer reviewing them, on a side project, freelance job or internal tool? What did you do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.