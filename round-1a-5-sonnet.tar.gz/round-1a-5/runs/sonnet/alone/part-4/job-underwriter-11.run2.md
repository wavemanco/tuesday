Checking whether both employers exist and are hiring as described, before I write the assessment.
## Decision snapshot: Role A, Operations Analyst, Duinvaart Cold Chain

**Yes, worth your time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: A-R1 (Hybrid, three days in Rotterdam)
- `must_have` — direct: A-R2, A-R3, A-R4
- `important` — direct: A-R5, A-R7 · unclear: A-R6 (Temperature compliance tracking)
- `preferred` — adjacent: A-R8 (Dutch a plus)

A-R6 — the one real domain gap, and it may be a discovery gap rather than a capability one; A-R8 — conversational Dutch against a "plus".

**Opportunity ledger.** The role is clearly scoped (A-RR3), but the employer was not checked (A-RR1) and the pay is withheld (A-RR2).

- **Hard gates:** none failed; unconfirmed: A-R1 (Hybrid, three days in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the three Rotterdam days work for you (A-R1); (2) the employer and posting verify (A-RR1); (3) cold-chain compliance is framed as adjacent unless you have real temperature-tracking work to show (A-R6).

## Decision snapshot: Role B, Supply Planner, Kroonhaven Foods

**No, I wouldn't spend your time here. Status: `no_go`.** The must-haves are the problem: planning experience, SAP IBP and the capacity-versus-forecast plan are absent (B-R2, B-R5, B-R6), and Dutch is short of "fluent" (B-R3). You asked for a worthwhile use of time, and this fails on capability, not wording.

**Fit ledger.**

- `hard_gate` — unclear: B-R1 (On-site in Utrecht)
- `must_have` — adjacent: B-R3 (Fluent Dutch) · unclear: B-R4 (Advanced Excel) · absent: B-R2 (3+ years planning in FMCG), B-R5 (SAP IBP or similar), B-R6 (Own the 13-week supply plan)
- `important` — adjacent: B-R7 (Run the weekly S&OP meeting)

B-R7 — your review-meeting experience is a real bridge, but one row can't carry the role.

**Opportunity ledger.** The role is clearly owned (B-RR3), but the employer was not checked (B-RR1) and the pay is withheld (B-RR2).

- **Hard gates:** none failed; unconfirmed: B-R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a planning role you've held in FMCG, or the employer treating planning as learnable on the job. Neither is in the posting.

## Role reality

| Element | Role A | Role B | Provenance |
|---|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | Kroonhaven Foods, Utrecht; chilled ready-meals | `[grounded]` your pasted postings; existence not checked |
| Mandate | Track on-time delivery and temperature compliance, weekly Power BI dashboards, route changes with depot managers | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP | `[grounded]` postings |
| Working pattern | Hybrid, three days a week in the office | On-site | `[grounded]` postings |
| Scope read | An analyst post that reports on and advises operations, with no stated decision rights | A planner post that owns the plan | `[inferred]` from the verbs "track", "build", "work with" against "own" and "run" |
| Market calibration | Not established: the pay searches were not permitted | Not established, same reason | `[grounded]` no figure in either posting |
| Unknowns | Salary, reporting line, whether Dutch is needed day to day | Salary, planning tool in use, team size | — |
| Contradictions | None visible in the text provided | None visible | `[grounded]` postings only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A-R1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | Your location and commute limits were not given. You worked in Amsterdam, which suggests a commute is plausible but isn't confirmed | `[grounded]` posting; your constraints not stated | Question 1 |
| A-R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; stated by you, no artifact seen | `[grounded]` your background | none |
| A-R3 | Strong SQL | must_have | direct | medium | none | Used daily, per you; no sample seen | `[grounded]` your background | A sanitized query would raise it to high |
| A-R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the dashboard depot managers use | `[grounded]` your background | A screenshot or description of the dashboard would raise it to high |
| A-R5 | Track on-time delivery | important | direct | medium | presentation | The on-time delivery dashboard is the same metric the role tracks. Lead with it | `[grounded]` your background | CV edit E1 pending approval |
| A-R6 | Track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | Nothing in what you gave me touches temperature. Parcel work may have had service or exception compliance metrics that work as a bridge, but that is unknown | `[grounded]` silence in your background | Question 2 |
| A-R7 | Work with depot managers on route changes | important | direct | medium | presentation | You ran the weekly route-performance review, and depot managers use your dashboard | `[grounded]` your background | CV edit E1 pending approval |
| A-R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch against a "plus". It isn't a gate in the posting | `[grounded]` your statement and posting wording | Question 3 |
| B-R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and constraints were not given | `[grounded]` posting; constraints not stated | Question 1 |
| B-R2 | 3+ years supply or demand planning in FMCG | must_have | absent | high | capability | You said you have never worked in planning. FMCG is also unevidenced. Confidence grades your own statement | `[grounded]` your statement | none: a capability gap, not a wording one |
| B-R3 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational is short of fluent, and the posting states it as a requirement, not a plus | `[grounded]` your statement and posting | none |
| B-R4 | Advanced Excel | must_have | unclear | low | discovery | Excel was not mentioned. SQL and Power BI don't evidence it | `[grounded]` silence in your background | An example of a complex model you built would settle it |
| B-R5 | SAP IBP or a similar planning system | must_have | absent | medium | capability | No planning-system experience was mentioned. Power BI is reporting, not planning | `[grounded]` your background | none |
| B-R6 | Own the 13-week plan, balancing capacity against forecast | must_have | absent | medium | capability | Route performance review is analysis of past results, not forward capacity balancing | `[inferred]` from the two role descriptions | none |
| B-R7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly review. S&OP is a cross-functional planning forum, so the facilitation carries over and the content doesn't | `[grounded]` your background; `[generic]` S&OP scope | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| A-G1 | Temperature compliance (A-R6, important) | discovery | Nothing on cold chain or compliance tracking | It's the one domain-specific duty in the posting | Service-level or exception tracking, time-critical or temperature-sensitive parcels, audit or SLA reporting | A sanitized dashboard view or metric definition | `[grounded]` silence; `[inferred]` bridge |
| A-G2 | Dutch working level (A-R8, preferred) | transferability | Conversational | Matters mainly if depot managers work in Dutch | Depot calls or meetings you already handle in Dutch | A line saying where you use Dutch at work | `[grounded]` your statement |
| B-G1 | Advanced Excel (B-R4, must_have) | discovery | No evidence either way | One must-have that could be recoverable | Models with lookups, scenarios, or forecasting | A sanitized workbook | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| A-RR1 | Employer and posting not checked | unknown | — | "Duinvaart Cold Chain, Rotterdam" | Search was not permitted, so nothing is confirmed about the firm or whether the posting is live | `[grounded]` research not run | Can you point me to this role on your own careers page, and say who I'd report to? | unresolved |
| A-RR2 | Salary withheld | unknown | — | no figure in the posting | May sit below or at the usual band, or simply not published | `[inferred]` from the posting's silence | What is the salary range for this role? | unresolved |
| A-RR3 | Clear weekly outputs and metrics | positive_signal | — | "build weekly dashboards in Power BI" | Success is measurable, and your experience matches it directly | `[grounded]` posting | Which metrics does the depot team care about most right now? | noted |
| B-RR1 | Employer and posting not checked | unknown | — | "Kroonhaven Foods, Utrecht" | Same as A-RR1 | `[grounded]` research not run | Can you point me to this role on your own careers page, and say who I'd report to? | unresolved |
| B-RR2 | Salary withheld | unknown | — | no figure in the posting | Same as A-RR2 | `[inferred]` from the posting's silence | What is the salary range for this role? | unresolved |
| B-RR3 | Clear ownership and demanding scope | positive_signal | — | "Own the 13-week supply plan" | A real role, with a defined remit | `[grounded]` posting | How is the S&OP forum structured today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | For Role A, lead the CV with the on-time delivery dashboard and the weekly route-performance review, in outcome bullets | see A-R5, A-R7 | `[grounded]` your background | pending your approval |
| E2 | For Role A, say nothing about temperature compliance unless you have real tracking work, and note it as adjacent or learning if asked | see A-R6 | `[grounded]` A-R6 row | pending your approval |
| A1 | Confirm the Rotterdam commute before investing in the application | see A-R1 | `[grounded]` posting | pending your approval |
| A2 | Ask the A-RR1 and A-RR2 questions verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Skip Role B and use the time on analyst or operations roles close to your background | see B-R2, B-R5, B-R6 | `[inferred]` from the B-row gaps | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for each firm's careers page were refused by permissions, so existence and live posting are unchecked (A-RR1, B-RR1) |
| 2. Role-family sweep | unavailable | A salary and scope search was refused, so market calibration is blank and the pay questions stand unanswered |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

If you'd like, I can write all of this up as a `tuesday-dossier.md` you can keep and update.

## Upgrade menu

- Permission to search the web → both employers checked, a pay band for each role, the A-RR1 and B-RR1 entries resolved.
- Where you live and what commute you'll accept → A-R1 and B-R1 resolve, and Role A's status likely moves to `go` or `no_go`.
- Any temperature, SLA or compliance tracking in your parcel work → A-R6 resolves.
- A sanitized SQL sample or dashboard screenshot → A-R3 and A-R4 rise to `high`.
- The hiring manager's name for Role A → role reality's scope read, and which story the application plan leads with.

## Questions

1. (A-R1, B-R1) Where are you based, and is three days a week in Rotterdam workable?
2. (A-R6) Did your parcel work include any compliance-type tracking, such as SLA breaches, time-critical or temperature-sensitive parcels, or exception reporting?
3. (A-R8) Could you do depot conversations or write a short update in Dutch, or would English be needed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.