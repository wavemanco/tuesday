I've run the checks (two searches), so here is the full assessment.

## Decision snapshot

**No, I wouldn't treat this as legitimate, and I wouldn't go ahead. This job is very likely a scam: RR1, RR2, RR3 and RR4 are each a confirmed `severity: high` demand. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3
- `important` — adjacent: R4 (Strong attention to detail) · unclear: R5 (A quiet place to work)

R1 — pay floor unsettled, since the posting gives only a ceiling; R4 (`low`) — adjacent, no accuracy outcome stated.

**Opportunity ledger.** RR1, RR2, RR3 and RR4 are demands made of you (pay for equipment, deposit a cheque and forward money, hand over bank, tax and ID details, and be hired wholly by chat). I can't establish the firm from here (RR5), and RR6 and RR7 are smaller signals.

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer verified independently through its own website, no payment, cheque or personal details asked for before a written offer, an interview held outside chat, and a written pay rate and hours that clear your €30,000 floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. The posting names no website, address or contact person. A search for the firm and role returned nothing, so the employer is not established | `[grounded]` posting; `[grounded]` search returned no results |
| Mandate | Remote order processing coordinator, "15–30 a week", "up to €26 an hour plus commission", "no experience needed, full training provided" | `[grounded]` posting |
| Process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Scope read | An entry-level, no-experience post. Your three years of ticket work sits above what it asks for | `[inferred]` from the posting's "no experience needed" against your background |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200 a year, interquartile range €28,400 to €34,100. The guide excludes commission-only and freelance work, so it is a pattern, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide (n=1,140) |
| Unknowns | Who the employer is; whether this is employment or self-employment; the guaranteed hours; the commission rate; who pays | `[grounded]` posting silent on each |
| Contradictions | The posting mentions no equipment cost, but the chat asks you to buy a "work kit". The cheque (€2,850) is far larger than the kit price (€349) | `[grounded]` posting against your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) against "up to €26 an hour", 15–30 hours a week, plus commission | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because the posting gives a ceiling, not a rate, and hours vary. At €26 an hour you would need about 22 hours every week to reach €30,000, and 15 hours gives €20,280. Commission is unquantified | `[grounded]` your message and the posting; arithmetic `[inferred]` from those figures | Only if the employer verifies (RR5): ask for a written rate, guaranteed hours and contract type |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. It is specific but self-reported, with no artifact to inspect | `[grounded]` your message | None. A sanitized tracker screenshot would raise it to high |
| R3 | Good written English | must_have | direct | medium | none | About 60 written Zendesk tickets a day for three years, as you describe it. No artifact inspected | `[grounded]` your message | None |
| R4 | Strong attention to detail | important | adjacent | low | transferability | Tracker upkeep and ticket volume point this way. Limit: you gave no accuracy or error result | `[inferred]` from the tracker and ticket work you described | See G2 |
| R5 | A quiet place to work | important | unclear | none | discovery | You haven't said, so there is no claim to grade | `[grounded]` your message silent | None unless RR5 resolves |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | A ceiling of €26 an hour, variable hours, commission unstated | Your floor is a term, and wording can't settle it. Only a written rate and hours can | Not applicable, since this is a term and not experience | A written offer or contract from a verified employer naming rate and guaranteed hours | `[grounded]` posting; `[inferred]` that only a written term settles it |
| G2 | Attention to detail (R4, important) | transferability | Tracker upkeep and ticket volume, no accuracy result | A low-priority row, so it would only matter if the role verified | Error-rate or quality-audit scores on tickets; a tracker you reconciled and corrected; a process you tightened | A sanitized quality report or tracker sample | `[inferred]` bridge from the tracker and ticket work you described |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | The posting mentions no cost to you, and a request to pay for the job or its equipment is a sign this request is very likely a scam. Who sent it, and whether the named employer is involved, is unresolved | `[grounded]` the message and the posting; `[generic]` that paying for a job is a known scam pattern | Ask the employer, through contact details you find yourself on its own website or careers page, never the chat or the address in these messages: "Do you ask new hires to pay €349 for a laptop and headset, and who is the equipment partner?" | confirmed |
| RR2 | Cheque to deposit, most of it to be sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | The amount forwarded is far above the €349 kit price in RR1. A cheque credited to your account can be returned unpaid after bank checks, which would leave you owing what you sent on. This request is very likely a scam | `[grounded]` the message and RR1's amount; `[generic]` how cheque reversal works | Same route as RR1: "Are you posting me a cheque, and why is its value far above the kit price?" | confirmed |
| RR3 | Bank, tax and ID details asked for before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Asked before the chat interview and before any written offer naming role and pay. These details are routine only after a credible written offer | `[grounded]` the message and its order; `[generic]` that these details are routine only after an offer | Same route as RR1: "Do you collect bank, PPS and passport details before a written offer, and through what system?" | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interview and offer happen only in chat, with no verifiable person or place. The posting, not the sender, says so | `[grounded]` the posting and the "you passed the interview" message | Same route as RR1: "Will there be an interview by phone or video, and with whom?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The firm may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is ranked as likely | `[generic]` pattern for firms with no footprint, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Contact address not on a site the posting names | risk_signal | low | "Any problems, email velloway.hr@postmail.example." | The posting names no website, so the address cannot be matched to an employer domain | `[inferred]` from the posting's silence on any site | Which website is your own, and which email address there can I use? | unresolved |
| RR7 | Pay ceiling above market band for a no-experience role | risk_signal | low | "Earn up to €26 an hour plus commission" | At the 30-hour top that is €40,560 a year, above the €28,400 to €34,100 interquartile range for salaried coordinators. "Up to" may be a ceiling few reach, and the guide excludes commission-only work, so the comparison is loose | `[grounded]` posting figure; `[generic]` Pennoral band; arithmetic `[inferred]` | What is the guaranteed hourly rate and the typical commission? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo. I don't need them and won't use them, so don't paste them here either | see RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Don't pay the €349 | see RR1 | `[grounded]` RR1 | pending your approval |
| A3 | If a cheque arrives, don't lodge it or send any part of it on. Show it to your bank | see RR2 | `[generic]` how banks handle suspect cheques | pending your approval |
| A4 | Look for the employer's own website yourself and use only contact details found there. If you can't find one, treat the employer as unresolved and stop | see RR5 | `[grounded]` RR5 | pending your approval |
| A5 | Report the posting to the jobs site where you found it | Lets the site act on it | `[generic]` jobs sites usually take reports | pending your approval |
| A6 | Put your effort into other openings: salaried coordinator roles at courier and logistics employers, applied for through their own careers pages. Your Zendesk and Excel work fits R2 and R3, and the salaried median in the band is close to your €30,000 floor | see R1, R2, R3 | `[generic]` the Pennoral band; `[grounded]` your background | pending your approval |

Offer beyond this assessment: I can draft a short reply that ends the chat without sharing anything, written on your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator"; it returned no results, so the employer is not established. This moved the organization row in role reality and RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly rate", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This moved the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

The dossier is available as `tuesday-dossier.md` whenever you want it, and I'll write it on your word.

Upgrade menu:

- The jobs site where you found the posting, and any company website it linked → RR5 may resolve, or confirm the employer cannot be matched.
- Any written statement of rate, hours and contract type from a verified employer → R1 can be settled.
- A hiring manager's name from a verified source → role reality's scope read.
- A sanitized tracker screenshot or quality report → R2 to high and R4 to a firmer fit, which matters for other roles.
- A deeper research pass on this employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

RR5 — Which jobs site was the posting on, and did it link to a company website?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.