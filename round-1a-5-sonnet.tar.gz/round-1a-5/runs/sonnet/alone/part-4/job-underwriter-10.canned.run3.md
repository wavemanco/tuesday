I'll read the skill's reference files before building the assessment.
Research is done: 3 searches and 2 page fetches on the company, the pay band and the co-founder. Here's the assessment.

## Decision snapshot

**Yes, worth taking the call. On what I could check, Fernquay matches its own About page, and the message asks nothing of you beyond a call time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5a, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R5b (Research calls with school owners), R8 (Work as the first designer)

R7 — the checkout redesign is the closest evidence, with its limit being anything past checkout; R5b — usability sessions bridge toward owner interviews, limit named; R8 — adjacent only, since you have never been the sole designer; R2 — your pay floor is not yet stated.

**Opportunity ledger.** Pay and equity are stated up front (RR1) and the hiring style is realistic (RR5). Equity terms are unstated (RR2), the sole-designer scope needs probing (RR3), and the posting did not appear on the careers page I tried (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the salary band meets your own floor — R2; (2) the equity terms turn out to be real and explained — RR2; (3) you get a clear answer on who reviews your design work and how you reach school owners — RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, based in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page fetched (fernquay.example/about); the posting's "kayak and surf" is narrower than the page's "sea-kayak, surf and sailing", which is not a conflict |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with Ronan Kehoe | `[grounded]` posting |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office | `[grounded]` posting |
| Co-founder | Ronan Kehoe is listed as co-founder and CEO, with five years before that as a product lead at a Galway travel-software company | `[grounded]` search-result snippet of his public profile, page not fetched |
| Scope read | One designer covering design, research and shipping on one product at a six-person company reads as a normal first-designer remit, with design critique and priorities likely coming from the founders | `[inferred]` from the posting's responsibility list against its team size |
| Market calibration | The posted band sits inside the interquartile range (€51,500–€62,000) of a 2026 Irish survey for 3–5 years' experience, whose median is €57,000. That survey is Ireland-wide, so it is not a Galway or startup figure | `[generic]` role-family sweep: one salary search, snippet only (n=520) |
| Unknowns | Success measures for the first 90 days and first year (the posting states none); equity terms; who gives design feedback; how school owners are reached for research; where the posting is listed | `[grounded]` posting silence |
| Contradictions | None between the posting, the WhatsApp message and the About page. The page does not state Saoirse's title, and the careers page I tried returned no page | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the commute term is met. Whether two fixed office days suit you is not stated, so the band is `medium` | `[grounded]` your message; posting | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the pay, but you have not given a floor, so the gate is not established | `[grounded]` posting; your floor absent | G4 question: does it meet your floor? |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, your own account with no document yet | `[grounded]` your background prose | A CV or profile with dates would raise this |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated. Whether it is strong is judged on artifacts, and the posting itself asks for one real messy project | `[grounded]` your prose | Share a Figma file or case-study link, which would raise this to `high` |
| R5a | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, run by you | `[grounded]` your prose | Session guide or a findings write-up would raise this |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your prose | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | Redesigning a travel-booking checkout is close work in the same domain. The limit is that checkout is one stage, and it is unknown whether you owned the stages around it | `[grounded]` your checkout redesign; `[inferred]` that "end to end" spans more than checkout | G1 |
| R5b | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions carry over to the craft. The limit is that it is unknown whether your customers were business operators, and open discovery calls differ from testing a flow | `[grounded]` your prose; the limit is `[inferred]` from the posting's wording | G2 |
| R8 | Work as the first designer | important | adjacent | medium | transferability | Four years of ownership of a redesign and research, but always alongside other designers, by your own account | `[grounded]` your statement; requirement `[inferred]` from "You would be our first designer" | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole booking flow (R7, must_have) | discovery | A checkout redesign, but nothing on the stages before or after it | R7 is the posting's lead responsibility, and this is the likeliest probe in the call | Availability or search, basket, payment failures, confirmation emails, change and cancel flows, any operator-side tooling | Your checkout case study (they have already seen it), before/after numbers | `[grounded]` prose names checkout only; `[generic]` that "end to end" is probed on scope |
| G2 | Research with business owners (R5b, important) | transferability | Monthly usability sessions, but it is unclear who the customers were | The role's research is with school owners, who are business operators | Calls with operators, agents or suppliers; support-call listening; field visits | A discovery guide or synthesis doc | `[grounded]` your prose |
| G3 | First-designer operation (R8, important) | transferability | Never the only designer | Nobody in a six-person team reviews design, so this limits what you can say about yourself | Setting up a Figma library, running critiques, setting a squad's design priorities, covering a design gap | A component library, a design-principles page | `[grounded]` your statement; `[generic]` that solo-designer roles test this |
| G4 | Pay floor (R2, hard_gate) | hard_gate | A stated band and no stated floor | A failed pay gate caps the decision, and only you can set it | Not applicable: this is your term to state | None needed | `[grounded]` posting; your floor absent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and equity stated in the posting | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The compensation is concrete, and the band sits inside the survey range in role reality | `[grounded]` posting; `[generic]` band | Is the salary range firm, or negotiable within it? | noted |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The equity may be options or shares with vesting terms not yet shared. With no outside funders, the percentage is of a closely held firm | `[inferred]` from "funded by its customers" on the About page and the posting's silence | Is the equity options or shares, over what vesting period, and what is the fully diluted share count? | unresolved |
| RR3 | Sole-designer scope | risk_signal | low | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | Design, research and shipping fall to one person with no design peer or stated success measure | `[inferred]` from the responsibility list and the posting's silence on success measures | How will success be measured in the first 90 days, who reviews your design work, and how do I reach school owners for research? | unresolved |
| RR4 | Posting not found on the careers page | unknown | — | "Product Designer — Fernquay" | The posting may be listed elsewhere, or the company may simply have a small web footprint | `[generic]` pattern for companies founded in 2023; the page absence is `[grounded]` | Where is this role listed on your own site? | unresolved |
| RR5 | Hiring style | positive_signal | — | "we would rather see one messy real project than a polished deck" | The process values real work over polish | `[grounded]` posting | What would the ideal project walk-through cover? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite came from an address on Fernquay's own website domain, and open the video link only from that invite | Scheduling a video call by WhatsApp is routine, and the message asks for nothing beyond a time. This check is advice, not a condition. Founders at small companies often message candidates directly | `[generic]` small-company pattern | pending your approval |
| A2 | Lead with the checkout redesign, since they raised it themselves, and expect detailed questions on it | The message cites it, and his public profile shows product-lead work at a travel-software company | `[grounded]` message; `[inferred]` from his profile | pending your approval |
| A3 | Say plainly what was yours and what the squad's, and that you have not been the only designer | See R8 and R7; precise ownership holds up better under questions | `[grounded]` your statements | pending your approval |
| A4 | Ask the questions from RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Decide your pay floor before the call | See R2; it decides whether the band is workable | `[grounded]` R2 | pending your approval |
| A6 | Prepare one real project walk-through, including what did not work | RR5; they said they prefer messy real work | `[grounded]` posting | pending your approval |

Everything above is proposed. Nothing is final until you approve it, and that includes the prose advice and the table. I have proposed no CV wording.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about). Fetched fernquay.example/careers, which returned no page, and fernquay.example/about, which repeated the snippet. Moved: role reality's organization and contradictions rows, and RR4 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup first designer", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), read as a snippet only. Moved: market calibration `[generic]` and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. Moved: the co-founder row in role reality and A2 |

If you want it, I can save all of this as `tuesday-dossier.md` so a later turn can pick it up.

## Upgrade menu

- A link to your checkout case study or a Figma file → R4 could reach `high`, and R7 and R5a firm up.
- Your CV with dates → R3 firms up.
- Where you saw the posting → RR4 can close.
- Your pay floor → R2 and the hard-gates line resolve.
- A deeper research pass on Fernquay (customer and news coverage, up to 5 more searches and 2 more fetches) → feeds the register; say the word and it runs.

G4 — Is €52,000–€60,000 plus equity something you would accept, meaning it meets your pay floor?

G1 — Beyond checkout, which parts of the booking journey did you personally own, and what changed after your redesign?

G3 — Have you ever made design decisions with no other designer to review them, such as setting up a Figma library, running critiques or setting a squad's priorities? What was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.