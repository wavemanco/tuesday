I'll read the skill's reference files before building the assessment.
I've run four searches: the company, the live posting, Ronan's public profile, and a salary benchmark. Next I'll fetch the careers page to check it matches what you pasted, then write the assessment.
# Job underwriting: Product Designer at Fernquay

## Decision snapshot

**Yes, this is worth taking forward, and the employer checks out against its own pages. Status: `conditional_go`.** You've already applied. The decision is about taking the call and pursuing the role.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Run research calls with school owners), R9 (First designer, no design peer)

R7: the checkout redesign is a credible bridge, but ownership of the whole flow isn't shown yet; R9: you've never been the only designer, so this is the row to test in the call; R2: waiting on your pay floor.

**Opportunity ledger.** The role is sound and transparent: the pay band, hours and equity are stated (RR1, RR5). Three things are unknown: the equity terms (RR2), the company's runway (RR3), and the support a first designer would get (RR4). The WhatsApp message is a routine scheduling step: it asks for a video call, with the invite sent by email. It takes no register entry and no condition.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay band clears your own floor (R2); (2) equity terms are shown in writing before you weigh the equity (RR2); (3) the call shows how a first designer is supported, and you are comfortable with that (R9, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about |
| Posting | Live on the company's own careers page. Same title, hybrid two days in Galway, same salary band; it says to apply with one real project | `[grounded]` careers page fetched |
| Mandate | First design hire: own the booking flow, run research calls with school owners, ship with two engineers, work closest with Ronan | `[grounded]` your pasted posting |
| Hiring contact | Ronan Kehoe is co-founder and CEO at Fernquay, previously product lead at a Galway travel-software company for five years | `[grounded]` public profile snippet |
| Scope read | A broad solo-designer remit (flow ownership, research and delivery together) typical of a first design hire at a six-person company, not oversized | `[inferred]` from the posting's three duties against the team size |
| Market calibration | €52,000–€60,000 sits inside the survey's range for 3–5 years' experience (median €57,000; interquartile range €51,500–€62,000). The survey covers Ireland as a whole, so it is not a Galway or small-startup figure | `[generic]` Tillerby 2026 Ireland Design Salary Report; `[grounded]` posting for the band |
| Unknowns | Your pay floor against the band; equity terms; runway; who reviews design work; first-90-day outcomes (not stated) | `[grounded]` posting silence |
| Contradictions | None found between your posting, the careers page and the about page. The about page snippet names Saoirse Doyle as a founder but doesn't state her title, so "CTO" in the message is unconfirmed, not contradicted | `[grounded]` pages read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week in the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year; the office days are compatible with living there. Your statement is unprobed prose | `[grounded]` your background, posting | none |
| R2 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | You gave no pay floor, so the band can't be checked against it. The band is stated plainly | `[grounded]` posting; your floor not given | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, in your words. A length requirement, so graded as experience, not a gate | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" across those four years. No portfolio file seen, so medium | `[grounded]` your background | Share the case study you sent, to raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The limit: that is usability testing, and the posting's research is calls with school owners (R8) | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; the posting has two | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow at a travel-booking company. That carries over directly, but you haven't described owning the whole flow from search through to confirmation. Strengthener: a before-and-after of the checkout work | `[grounded]` your background; `[inferred]` the limit, from what you described | Gap queue G3 |
| R8 | Run research calls with school owners | important | adjacent | low | discovery | Your sessions were with travel customers; school owners are small-business operators. Whether you have run discovery interviews, not only usability sessions, is unknown | `[grounded]` your background; `[inferred]` that discovery is untested | Question R8 below |
| R9 | First design hire: no design peer or lead | important | adjacent | medium | transferability | You've never been the only designer. Adjacent: you redesigned a flow and ran your own sessions with engineers, though inside a larger company. Inferred requirement from "our first designer" | `[inferred]` from the posting; `[grounded]` your statement | Question R9 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | The band is stated; your minimum isn't | A gate row stays unconfirmed until you set your floor against it | Your current salary range and what you would accept; any benefit you value at a figure | None needed | `[grounded]` posting and your message |
| G2 | Research with school owners (R8, important) | discovery | Monthly usability sessions with customers; no mention of discovery interviews or business-owner research | The role's research calls are with owners, so which kind you have done decides how to position R5 and R8 | Interviewing business customers or partners; a research round that changed a roadmap; talking to non-end-user stakeholders such as agents or venue operators | A research summary, a session guide, a findings deck | `[grounded]` your background; `[generic]` that first-designer roles in small B2B firms lean on discovery calls |
| G3 | Whole-flow ownership (R7, must_have) | transferability | Checkout redesign confirmed; wider ownership not described | The posting says end to end, and your bridge is strongest when its limit is stated | Part of the flow you also touched, such as search, basket or confirmation emails; checkout metrics you tracked after launch | The checkout case study you already sent, with before-and-after screens | `[inferred]` bridge from the checkout redesign you described |
| G4 | Sole-designer experience (R9, important) | transferability | Squad work with four engineers; always alongside other designers | The posting makes you the whole design function, so the call is where this is tested | Setting up a component library or design standards for a squad; running critique or design reviews yourself; being the one designer on a project or a side build | A design-system file, a process doc, a freelance or side project | `[grounded]` your statement; `[generic]` that solo roles test self-direction |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and within the survey's range | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The band is transparent and reasonable for the experience asked | `[grounded]` posting; `[generic]` survey range | Is the band fixed, or does it move with experience? | noted |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The share is stated but vesting, share class, exercise price and dilution may not be | `[inferred]` from the posting giving a percentage and nothing else | What are the vesting schedule, share class and exercise price, and could I see the terms in writing? | unresolved |
| RR3 | Runway unknown for a customer-funded company | unknown | — | "funded by its customers" | Salary and equity depend on customer revenue. Customers are schools, so income may be seasonal | `[grounded]` about page; `[inferred]` seasonality from the customer type | How much runway does the company have at current revenue, and is this hire budgeted beyond the first year? | unresolved |
| RR4 | First designer with no stated design support | risk_signal | low | "You would be our first designer" | There may be no one to review design work or set standards. Held at `low`: the posting names the co-founder as your closest partner | `[inferred]` from "first designer" against silence on review and mentoring | Who reviews your work, and who decides when design and engineering disagree? | unresolved |
| RR5 | Posting is specific and consistent across sources | positive_signal | — | "we would rather see one messy real project than a polished deck" | The careers page, about page and posting agree on role, location, pay and process | `[grounded]` careers page fetched, about page | What does the process look like after the call? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, confirm the invite came from a Fernquay address, or reply to the contact on the careers page (jobs@fernquay.example). WhatsApp scheduling is routine; this is only a quick check that it's the same people | see RR5 | `[grounded]` careers page | pending your approval |
| A2 | In the call, lead with the checkout redesign and the monthly usability sessions, in your own words and at the scale you gave | see R5, R7 | `[grounded]` your background | pending your approval |
| A3 | Say plainly that you have worked in a team of designers and engineers and haven't been the only designer, then say how you would set up reviews and standards | see R9, RR4 | `[grounded]` your statement | pending your approval |
| A4 | Ask the verification questions from RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Bring one real project, messy is fine, as the posting asks. The checkout case study is the obvious candidate | see R4, R7 | `[grounded]` posting | pending your approval |

Interview rehearsal for the call is mock-interview's job.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (returned About Fernquay, fernquay.example/about) and "Fernquay product designer job Galway"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality's organization and contradictions rows: the company exists as described and the posting is live and consistent, so no failed-attribution entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup first designer 3+ years", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). The market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), a snippet only. Role reality's hiring-contact row; it keeps to his role and career, nothing personal |

I can produce `tuesday-dossier.md` with all of this whenever you want it.

**Upgrade menu**

- Your pay floor → R2 closes and the hard-gates line resolves.
- The checkout case study or a Figma file → R4 to `high`, and R7's bridge gets a concrete before-and-after.
- An example of discovery interviews, or a note that you've done none → R8 resolves.
- Any design-system, process or side-project work → R9 and RR4.
- The equity terms in writing → RR2 closes.
- A deeper research pass on Fernquay (customer base, past hiring, any public reports; up to 5 more searches and 2 more fetches) → RR3 and a firmer read on stability. Say the word and it runs.

**Questions**

1. R2: What is the lowest salary you would accept for this role, and is the equity something you would trade pay for, or only a bonus?
2. R8: Have you run discovery-style interviews with business customers or partners, not only usability sessions? What did you learn, and did it change a decision?
3. R9: Have you ever set up design standards, a component library or review habits on your own, even on a side project or inside a squad with no design lead?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.