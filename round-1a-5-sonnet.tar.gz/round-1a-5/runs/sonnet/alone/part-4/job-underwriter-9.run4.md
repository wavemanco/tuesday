I'm checking whether Marrowgate Housing and the salary range hold up publicly. I'm running three searches, then I'll write the assessment.
## Decision snapshot

**Yes, this is routine: after a written offer, an employer asks for bank details, a PPS number and passport proof of right to work. Your rule is right for requests made before an offer. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two Limerick office days), R2 (Salary €40,000 offered), R3 (Right-to-work check)
- `must_have`: direct: R4, R6, R7 · adjacent: R8 (Monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI, USC)
- `important`: direct: R9, R10 · unclear: R12 (Staff payroll queries) · absent: R11 (Pension changes)

R5 — jurisdiction of your payroll work not stated; R8 — a credible bridge, its limit named; R11 — you told me you haven't done these yourself.

**Opportunity ledger.** The written offer matches the ad and sets out role, pay and reporting line (RR4). The unknowns are the pension handover (RR2), whether this is a sole post (RR3), the contract terms (RR5), and that I couldn't check the employer against public sources (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two Limerick office days), R2 (Salary €40,000 offered), R3 (Right-to-work check); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your own limits on R1, R2 and R3 are confirmed (G1); (2) R5 is confirmed as Irish-regime work (G2); (3) a pension-changes handover is agreed before you start (RR2, R11); (4) the employer is checked against public sources, which I couldn't do (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, as stated in the ad and the offer | `[grounded]` ad and offer as you pasted them; not checked publicly |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, monthly payroll-to-ledger reconciliation, staff queries | `[grounded]` ad |
| Terms | Permanent, €40,000 (ad band €38,000–€42,000), hybrid with two Limerick office days, reporting to Declan Garvagh, Finance Manager | `[grounded]` ad and offer |
| Scope read | Neither the ad nor the offer names a payroll team, a system or cover, so this may be a sole payroll post | `[inferred]` from the silence of both on team and system |
| Market calibration | Not run, because the salary search was refused | `[grounded]` search refusal; see evidence status |
| Unknowns | Payroll software; cover for leave and year-end; pension scheme and handover; probation and notice terms | `[grounded]` absent from ad and offer |
| Contradictions | None between ad and offer on title, location, hybrid pattern or pay band | `[grounded]` both texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | You attended two interviews at their office, but you haven't stated any commuting limit | `[grounded]` your account of the interviews; no constraint stated | G1 question |
| R2 | Salary €40,000 offered, within the ad's €38,000–€42,000 | hard_gate | unclear | none | hard_gate | No pay floor from you, so I can't say whether the offer meets it | `[grounded]` offer text; no floor given | G1 question |
| R3 | Right-to-work check by passport | hard_gate | unclear | none | hard_gate | The offer states the check. Nothing you've told me settles it either way, and I don't need your passport details | `[grounded]` offer text | Nothing to send me; the employer checks this |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff at a hotel group, in your own account | `[grounded]` your stated background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say which tax regime the hotel group's payroll ran under or which parts you handled | `[grounded]` background silent on jurisdiction | G2 question |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your stated background | none |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; the certificate itself hasn't been inspected | `[grounded]` your stated background | A copy would raise it to high |
| R8 | Run the monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff. The monthly work you described is the ledger reconciliation, not monthly payroll runs. Limit: 240 staff against 90, and monthly runs not described | `[grounded]` your stated background | See G3 |
| R9 | Reconcile payroll to the general ledger each month | important | direct | medium | none | You did the monthly payroll-to-ledger reconciliation | `[grounded]` your stated background | A sanitized sample would raise it to high |
| R10 | Process starters and leavers | important | direct | medium | none | Starters and leavers were part of your hotel-group payroll | `[grounded]` your stated background | none |
| R11 | Process pension changes | important | absent | none | capability | You've never done them yourself; your manager handled them | `[grounded]` your statement | See G4 |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Your background is silent on staff queries | `[grounded]` background silent | Optional; see G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Your limits on commute, pay and right to work (R1, R2, R3, hard_gate) | hard_gate | The offer terms are stated, but not whether they meet your limits | A gate that is unconfirmed can't be called met; you can't accept safely without knowing | Your commute to Limerick on office days; your minimum salary; your right to work in Ireland | Nothing to attach | `[grounded]` constraints not given |
| G2 | Irish tax and social-insurance knowledge (R5, must_have) | discovery | Three years of payroll are stated, but not the jurisdiction or which statutory deductions you handled | It's a named must-have in the ad; confirming it is the quickest way to firm up the map | Running PAYE, PRSI or USC deductions; Revenue payroll filings; year-end returns; resolving a deduction error | A payslip layout with details removed, or the course syllabus | `[grounded]` background silent; `[generic]` that such a requirement is usually tested in interview |
| G3 | Scale and cadence (R8, must_have) | transferability | Fortnightly payroll for 90 staff, plus monthly reconciliation | The interview bridge: the same cycle work at a smaller scale. Limit: 240 staff and monthly runs unproven | A month-end close that rolled up several pay runs; a large starters-and-leavers month | A sanitized reconciliation or pay-run checklist | `[inferred]` bridge from your account |
| G4 | Pension changes (R11, important) | capability | You've not done them; no adjacent work stated | Listed duty in the ad that is untested for you | None stated; a closure path rather than a recall prompt | A course or provider training; the employer's handover plan | `[grounded]` your statement |
| G5 | Staff payroll queries (R12, important) | discovery | Not covered by your background | Low impact: most payroll roles handle queries, so likely easy to evidence | Answering payslip or deduction queries; dealing with HR or managers on corrections | none needed | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked against public sources from here | unknown | — | "Marrowgate Housing, a housing association in Limerick" | Nothing suggests a problem. Your two in-person interviews at their office support it, but I couldn't run the checks | `[inferred]` from your account of the interviews; searches refused | Can you point me to the role on your own careers page? | unresolved |
| RR2 | Pension changes in scope, with no handover mentioned | unknown | — | "process starters, leavers and pension changes" | They may expect you to pick it up on the job, or have a procedure in place | `[inferred]` from the ad's silence on training | Who will show me how pension changes are processed here, and which scheme and system do you use? | unresolved |
| RR3 | Team, cover and system unstated | unknown | — | "Run the monthly payroll for our 240 staff" | This could be a sole post with no cover at leave or year-end | `[inferred]` from the ad's silence on team and system | Is this a one-person payroll function, and who covers me during leave? | unresolved |
| RR4 | Written offer names role, pay, reporting line and hybrid terms | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The terms are specific and consistent with the ad | `[grounded]` offer compared with ad | Can I have the written contract before I resign? | noted |
| RR5 | Contract terms not in the email | unknown | — | "starting on a date we agree once your notice period ends" | Probation, notice period and pension scheme may be in the contract but aren't in the email | `[inferred]` from the offer's silence on them | What are the probation, notice and pension terms in the contract? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | When the portal link arrives, enter your bank details, PPS number and passport scan only in the employer's own portal, at the address its own website gives. Bring the original passport on day one | Payroll and right-to-work details are standard onboarding after a written offer | `[generic]` routine onboarding | pending your approval |
| A2 | Ask for the written contract and its terms before you resign (RR5) | The email states the pay and permanence but not the probation, notice or pension scheme | `[grounded]` RR4, RR5 | pending your approval |
| A3 | Put the RR2 and RR3 questions to Declan Garvagh before or when you accept, and agree a handover for pension changes | It closes R11 and RR2 | `[grounded]` register | pending your approval |
| A4 | Reply within the five working days the offer sets, counted from the day it was emailed | It is the deadline stated in the offer | `[grounded]` offer text | pending your approval |
| A5 | If asked about R8 and R11, say: "I ran fortnightly payroll for 90 staff at a hotel group and did the monthly payroll-to-ledger reconciliation. I haven't done pension changes myself; my manager handled those." | Each clause traces to your own account, and it keeps the scale and cadence limits visible | `[grounded]` your stated background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers Payroll Administrator Limerick"; both were refused. It would have moved RR1 and the contradictions row of role reality |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland Limerick 2026"; refused. It would have moved the market calibration row and whether €40,000 sits inside the normal band |
| 3. Hiring manager's public footprint | unavailable | No search was sent. Your offer names Declan Garvagh, so a query was possible; research was not permitted. It would have shaped the scope read and A3 |

I'm happy to save this as `tuesday-dossier.md` if you'd like a copy to keep.

## Upgrade menu

- Allowing web search would run targets 1 to 3, close RR1, and add the salary calibration and a read on the hiring manager's published professional background.
- A copy of your payroll certificate would raise R7 to `high`.
- A sanitized reconciliation sample or pay-run checklist would raise R9 and R8's bridge.
- Your answers on G1 and G2 would settle the three gates and R5.
- The written contract would close RR5.

## Questions

G1 — Is €40,000 at or above your minimum, and can you commit to two days a week in the Limerick office from where you live now?

G2 — In your hotel-group payroll, which tax and social-insurance regime were you running (Irish PAYE, PRSI and USC, or another), and which calculations, deductions and filings did you handle yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.