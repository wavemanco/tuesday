I'm checking whether Fernquay exists as described, and running one salary sweep, before I write the assessment.
**Yes, it's worth taking the call, on conditions. I couldn't verify Fernquay from here, and neither the posting nor the WhatsApp message asks you for money or personal details. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R8 (Hybrid: two office days a week in Galway), R9 (Pay €52,000–€60,000)
- `must_have`: direct: R1, R2, R3, R4
- `important`: adjacent: R5 (Own the booking flow end to end), R6 (Research calls with school owners), R7 (First designer)

R5: checkout is your nearest evidence, and its end-to-end limit is named; R6: usability sessions carry over, owner interviews aren't shown yet; R7: you've never been the sole designer, so the bridge is your checkout ownership.

**Opportunity ledger.** The employer is not established from my side (RR1), the equity terms are unstated (RR3), and scope and runway are unknown (RR2, RR5). Pointing the other way, the posting is transparent about pay, people and scope (RR4).

- **Hard gates:** none failed; unconfirmed: R8 (Hybrid: two office days a week in Galway), R9 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies on its own site (RR1); (2) the pay and office days meet your own limits (R8, R9); (3) the equity and runway answers are acceptable (RR3, RR5); (4) your first-designer bridge is framed as adjacent, never as sole-designer experience (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools. I could not check this against any outside source | `[grounded]` posting only |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid with two days a week in Galway | `[grounded]` posting |
| Scope read | A coherent first-designer remit: one product surface, a named partner, a small team. No success measures or first-year outcomes are stated | `[inferred]` from the posting's scope against its silence on outcomes |
| Market calibration | Not calibrated. The salary sweep could not run, so I give no band against €52–60k | `[grounded]` research tier below |
| Consistency | The posting and the WhatsApp message agree on names and roles: Ronan as co-founder, a CTO, the checkout case study. I did not check the company's own pages | `[grounded]` your two pasted texts |
| Unknowns | Equity terms, funding and runway, the current booking flow's state, and what the "messy real project" would involve | `[grounded]` posting silence |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer at a Dublin travel-booking company. It is confirmed and specific, with no inspectable artifact seen | `[grounded]` your intake | none |
| R2 | Strong Figma | must_have | direct | medium | none | You use Figma daily. A file or the checkout case study you sent them would be the inspectable artifact in design | `[grounded]` your intake | Share the case study link, which would raise this to high |
| R3 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Whether these included discovery interviews isn't stated, and that is covered in R6 | `[grounded]` your intake | none |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your intake | none |
| R5 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned checkout at a booking company. The limit is that checkout is one stage, and the other stages' ownership isn't stated | `[inferred]` from your checkout claim against the posting's "end to end" | G4 |
| R6 | Run research calls with school owners | important | adjacent | medium | discovery | Usability sessions with customers carry over. Whether you've spoken with the business owners behind a booking product is unknown. Small B2B firms usually expect the designer to do their own discovery | `[grounded]` your intake; `[generic]` for the last clause | G3 |
| R7 | First designer, no design peers (implied) | important | adjacent | medium | transferability | You have never been the only designer. The limit is that you haven't set up a design process alone. The bridge is that you owned a flow redesign and ran research monthly | `[inferred]` from the posting's "first designer" and your intake | G5 |
| R8 | Hybrid: two days a week at the Galway office | hard_gate | unclear | low | hard_gate | You moved back to Galway last year, which is indirect. You haven't stated an office-day limit | `[grounded]` your intake; no constraint stated | G1 |
| R9 | Pay €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so the band can't be tested against anything | `[grounded]` no constraint given | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Your limits on hybrid and pay (R8, R9, hard_gate) | hard_gate | The posting states both terms; you have stated no limits | A failed gate would make this `no_go`, so the decision waits on it | Your minimum salary, your commute, how many office days you can do | None | `[grounded]` posting terms, no constraint given |
| G3 | Research with business owners (R6, important) | discovery | Usability sessions with customers are confirmed. Conversations with the businesses behind the bookings are not shown | Owner calls are named in the posting, so the call will likely probe it | Calls with tour operators or activity suppliers; supplier-side feedback sessions; onboarding interviews with partners | A research plan, a synthesis doc, a quote wall (sanitised) | `[grounded]` intake silence; `[generic]` that the call will probe it |
| G4 | Ownership beyond checkout (R5, important) | transferability | Checkout is confirmed. Search, availability, confirmation and post-booking changes aren't mentioned | "End to end" is the posting's wording for the main responsibility | Designing availability or search screens; handling changes and cancellations; the booking confirmation flow | A flow map or the case study | `[inferred]` from the posting against your intake |
| G5 | Working with no design peers (R7, important) | transferability | You have worked in an engineer-heavy squad but always had design colleagues | The posting makes you the first designer | Setting up shared components; a design review process; deciding priorities with a product owner | Component library, design-ops notes | `[grounded]` your intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope and decision rights for a sole designer | unknown | — | "own the booking flow end to end" | Ownership may come without a design lead or an agreed way to set priorities | `[inferred]` from the posting's "first designer" and its silence on decision rights | Who decides the booking flow's priorities, and what research exists today? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value depends on vesting, share class and dilution, none of which are stated | `[generic]` how equity value depends on its terms; `[grounded]` the posting gives only a range | Is it shares or options, on what vesting schedule, and 0.5–1% of what share count? | unresolved |
| RR4 | Transparent terms and named people | positive_signal | — | "€52,000–€60,000", "co-founder, Ronan Kehoe" | The pay band, scope and a named partner suggest a posting written with intent | `[grounded]` posting | What would success look like in your first year? | noted |
| RR5 | Funding and runway for a first design hire | unknown | — | "We are six people" | A six-person firm's ability to keep a hire depends on its funding, which the posting doesn't say | `[generic]` small-team hiring depends on runway; `[grounded]` the posting is silent | How long is the current funding, and is this role budgeted within it? | unresolved |

## Application plan

Every row is a proposal, including the suggested wording in A3. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's website and careers page yourself, and check that the invite came from an address on that site's domain. Scheduling a video interview by WhatsApp is routine | see RR1 | `[generic]` how interviews are commonly scheduled | pending your approval |
| A2 | Ask RR1, RR2, RR3 and RR5's questions on the call, in your own words | The register doubles as interview preparation | `[grounded]` the register | pending your approval |
| A3 | Lead with: "I redesigned our checkout flow at a Dublin travel-booking company, ran monthly usability sessions with customers, and worked in a squad with four engineers. I haven't been the only designer." Every clause traces to your own sentences | see R3, R4, R5, R7 | `[grounded]` your intake | pending your approval |
| A4 | If asked for a "messy real project", ask about scope, time and whether it's paid before you agree | The posting asks for a sample without defining it | `[inferred]` from the posting's wording | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers product designer" were refused. They would have moved the organization row, the consistency row and RR1 |
| 2. Role-family sweep | unavailable | The search for product designer salaries and first-designer equity in Ireland was refused. It would have moved the market calibration row, R9 and RR4 |
| 3. Hiring manager's public footprint | unavailable | The search on the co-founder named in the posting was refused. It would have moved the scope read and A3's positioning |

I did not retry the refused searches.

I can save this as a `tuesday-dossier.md` to carry forward if you'd like.

**Upgrade menu**

- Your checkout case study link or a Figma file raises R2 and R3 to high.
- Your pay floor and office-day limits close R8 and R9, and the decision likely simplifies.
- Search permission lets targets 1–3 run, which could close RR1 and calibrate the pay band.
- Their answers on equity, runway and scope close RR2, RR3 and RR5.
- Your answers to G3 and G4 strengthen R5 and R6.

**Questions**

G1 — Where do you stand on this role's two terms, €52,000–€60,000 and two office days a week in Galway? Is either a limit you wouldn't move on?

G3 — Have you ever spoken one-to-one with the businesses your company's bookings came through? What did you ask them, and what changed?

G4 — Beyond checkout, which other stages of the booking journey did you personally design, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.