I've read the skill's rules and am now checking the last two reference files. I'll also try the employer checks the skill calls for, then write the assessment.
## Decision snapshot

**Yes, Aoife, this one is worth applying for — `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · adjacent: R5 (Caring for housebound adults in their own homes) · unclear: R4 (Clear, timely written records)
- `important` — direct: R7a, R8a, R9 · adjacent: R6 (Own small caseload) · unclear: R7b (Leg-ulcer care), R8b (Continence care beyond catheters), R10 (End-of-life visits), R11 (Care planning)
- `preferred` — absent: R12 (Doppler assessment)

R5 and R6 — credible bridges, their limits named; R4, R7b, R8b, R10, R11 — the CV is silent; R12 — a confirmed absence in a preferred row.

**Opportunity ledger.** The role is sound and well defined, with supervision (RR2) and a stated salary (RR4). Open points are whether the posting is live (RR1), the shift pattern (RR3) and the employment terms (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting is confirmed live (RR1).
  2. The CV shows records and care-planning evidence you actually have (R4, R11).
  3. The home-visiting bridge is framed as adjacent, never as an existing caseload (R5, R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` its "About" page, as returned by search |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning | `[grounded]` JD |
| Support and records | Small own caseload, supported by a senior community nurse; electronic patient record; pool cars plus mileage | `[grounded]` JD |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | An entry route into community nursing: one year's post-registration experience is the only experience bar, and Doppler is "desirable". Leg-ulcer work looks like a real part of the work, and Doppler looks teachable on the job | `[inferred]` from the JD's essential/desirable split and the team lead's talks |
| Market calibration | A 2026 survey of England Band 5 community staff nurses (n=1,240) gives median basic pay £34,300, interquartile range £32,400 to £36,600; 61% were paid mileage and 24% had a pool or lease car. The posting's £31,050–£37,800 brackets that range. This is a survey pattern, not this employer's offer to you | `[generic]` one survey snippet; `[grounded]` JD for the posted range |
| Unknowns | Whether the posting is live; shift and weekend pattern; caseload size and induction; whether terms follow NHS terms | — |
| Contradictions | None found between the JD and the About page. I could not read the careers page | `[grounded]` About page snippet; careers address I tried returned no page |

## Evidence map

Your CV is self-report, so nothing sits above `medium` yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration as a Registered Nurse (Adult), revalidation due March 2028. Stated, not checked by me | `[grounded]` CV | Check your own entry on the NMC register before applying |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated, not checked by me | `[grounded]` CV | Check your own driving record on the DVLA site before applying |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, against a one-year bar | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV never mentions documentation or record systems. Ward nurses document as a matter of course, but that is not evidence of your records | `[grounded]` CV silence; `[generic]` ward nursing involves documentation | Ask which record system you used and how you documented the home visits (not asked this turn) |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge. Limit: short post-discharge visits, not ongoing care of housebound patients | `[grounded]` CV; `[inferred]` that the bridge is credible | See G2 |
| R6 | Holds a small caseload of their own, supported by a senior community nurse | important | adjacent | medium | transferability | You have never held your own caseload (your statement). The home visits are adjacent, but the CV does not say whether you visited alone or planned your own visits. The JD's built-in senior support narrows the gap | `[grounded]` your statement, CV, JD | See G2 |
| R7a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds, as you state | `[grounded]` CV | none |
| R7b | Leg-ulcer care | important | unclear | low | discovery | The CV names pressure ulcers and surgical wounds, not leg ulcers or compression | `[grounded]` CV silence | See G1 |
| R8a | Catheter care | important | direct | medium | none | Catheter care, as you state | `[grounded]` CV | none |
| R8b | Continence care beyond catheters | important | unclear | low | discovery | The CV says catheter care only | `[grounded]` CV silence | Carried, not asked this turn |
| R9 | Insulin administration | important | direct | medium | none | Insulin administration, as you state | `[grounded]` CV | none |
| R10 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Acute medical wards often see patients who are dying, but that is a pattern, not your history | `[grounded]` CV silence; `[generic]` ward pattern | See G3 |
| R11 | Care planning | important | unclear | low | discovery | The CV is silent on writing or contributing to care plans | `[grounded]` CV silence | See G2 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one, and that is your own statement | `[grounded]` your statement | Say so plainly; see G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7b, important) | discovery | Wound care is stated, but not leg ulcers or compression | It is a named duty, and the team lead has spoken on leg-ulcer clinics | Applying or watching compression bandaging; dressing venous ulcers on the ward; leg-ulcer patients seen on discharge visits | A competency record or training certificate | `[grounded]` CV and talk topics; `[inferred]` that it is a real part of the work |
| G2 | Home visiting, own visit list, care planning (R5 must_have, R6, R11) | discovery | Home visits are stated; lone working, planning your own visits and care plans are not | R5 is a must-have at `adjacent`, and this is the bridge that decides how strong it reads | Visiting alone; deciding visit order; writing or updating a plan of care; escalating a concern from a home visit | A sanitized visit-note template or discharge-to-assess role description | `[grounded]` CV; `[generic]` home-visiting nurses normally plan their own visit lists |
| G3 | End-of-life care (R10, important) | discovery | The CV is silent | It is a named duty; a concrete example would lift it from a gap | Caring for dying patients on the ward; a rapid discharge home to die; last-days care plans; supporting families | A reflective account or training record, anonymised | `[grounded]` CV silence |
| G4 | Records on an electronic patient record (R4, must_have) | discovery | The CV is silent | It is an essential criterion, so a one-line CV fix likely closes it | Ward EPR use; documenting home-visit outcomes | A CV line | `[grounded]` CV silence |
| G5 | Continence care beyond catheters (R8b, important) | discovery | The CV says catheters only | Likely covered on the ward, but unrecorded | Bladder and bowel care, continence assessments | A CV line | `[grounded]` CV silence |
| G6 | Doppler assessment (R12, preferred) | capability | No evidence, and you confirm you have never done one | A preferred, not essential, item; closure is training | Nothing to recall; this is a confirmed absence | A completed Doppler course or sign-off | `[grounded]` your statement; `[inferred]` that it is teachable here, from the team lead's talk on Doppler training |

G4 and G5 are not asked this turn, to keep within the question limit. Nothing in G6 needs a question to you.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not yet located on the employer's own careers page | unknown | — | "Join our district nursing team" | The post may be listed elsewhere, closed, or I used the wrong address. The address I tried was my guess, so its failure is not evidence of anything | `[inferred]` from one failed page fetch | Is this post open, and what is the closing date? | unresolved |
| RR2 | Supported entry to a caseload | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse." | A defined route into independent work, which matters because you have not held a caseload | `[grounded]` JD | What does the first month look like, and how does the caseload build up? | noted |
| RR3 | Shift pattern and out-of-hours expectations not stated | unknown | — | "caring for housebound adults in their own homes" | The post may include weekends or rotas the advert does not mention | `[inferred]` from the JD's silence | What shifts and weekend rota does the post carry? | unresolved |
| RR4 | Salary stated and in the survey range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posted range brackets the survey's middle range, so it looks market-normal. Where you would sit in it is open | `[grounded]` JD figure; `[generic]` one survey, England, 2026 | Where in the range would someone with five years' post-registration experience start? | noted |
| RR5 | Employment terms beyond pay unstated | unknown | — | "Calderbrook Community Health CIC" | A community interest company working under an NHS contract may set its own pension, leave and sickness terms | `[inferred]` from the JD's silence and the About page's description | Do pension, leave and sick pay follow NHS terms? | unresolved |

## Application plan

Every row and every sentence of advice in this section is pending your approval, as are the edits below.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: open the CV with "Registered Nurse (Adult). Five years as a staff nurse on an acute medical ward at a district general hospital, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." | It puts the home visiting first. Every clause is from your CV, and "caseload", "housebound" and "district nursing" are not used | `[grounded]` CV, audited clause by clause | pending your approval |
| E2 | Record in the application that you have not done Doppler assessment and would welcome training: "I haven't carried out Doppler assessments and would welcome training." | It matches your statement, and the item is desirable only | `[grounded]` your statement | pending your approval |
| E3 | Add records, care-planning, leg-ulcer and end-of-life lines only after you answer G2, G1, G3 and G4 | Nothing can be added that your answers do not confirm | `[grounded]` rows R4, R7b, R10, R11 | pending your approval |
| A1 | Use the invited informal chat with Rhiannon Mabbott. Ask RR1, RR3 and RR5, and "how does the caseload build up?" from RR2 | The advert invites it, and the register doubles as questions to ask | `[grounded]` JD | pending your approval |
| A2 | Check your NMC register entry and your DVLA driving record yourself before applying | Both gates rest on your own statement; I checked neither | `[grounded]` R1, R2 | pending your approval |

Offer beyond the standard output: a one-page question sheet for the chat with Rhiannon Mabbott, built from the register's questions. It suits this role because the advert invites an informal chat. I'll build it only if you approve.

## Evidence status

Verified: none yet.

Your National Insurance number isn't needed for this assessment. I haven't used or repeated it. Your NMC PIN also isn't needed, so I haven't repeated it either.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 district nursing vacancy". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). I then tried calderbrookhealth.example/careers, which returned no page. It moved the organization row and made RR1, the posting-live question, an open point |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nursing Agenda for Change pay scale 2026/27 requirements Doppler leg ulcer", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the scope read and the chat advice in A1 |

## Dossier offer

If you'd like, I can save all of this as a `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- A link to the live posting, or the careers page address → RR1 closes and the employer's pages can be read directly.
- Your answers to G2, G1, G3 and G4 → R5, R6, R7b, R10, R11 and R4 can rise toward `medium` or `high`, and CV lines can be proposed.
- A visit-note template or role description from the discharge-to-assess team, sanitized → R5 and R6 can reach `high`.
- Your pay floor, hours or location needs → the hard-gate line can check them. I've assumed you are evaluating, not yet applying.
- A deeper research pass on Calderbrook (leadership changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. G2 — In the discharge-to-assess role, did you visit patients on your own, plan your own visit list, and write or update a plan of care for each person? What was yours and what was the team's?
2. G1 — Have you dressed or managed leg ulcers, including compression bandaging, on the ward or on home visits? What did you do, and under whose supervision?
3. G3 — Have you cared for patients at the end of life, on the ward or at home? What were you responsible for?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.