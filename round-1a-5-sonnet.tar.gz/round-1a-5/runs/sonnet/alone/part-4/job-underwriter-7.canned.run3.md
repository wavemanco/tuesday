I'm reading the skill's remaining reference files (output rules, interaction grammar, evidence model, gap taxonomy) so the assessment follows its required format. Then I'll write it up.
## Decision snapshot

**Yes, this one is worth applying for, on two conditions. Status: `conditional_go`.** I've assumed you're at the evaluating stage.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R6, R8 · adjacent: R5b (Leg-ulcer care), R11 (Home visiting of housebound adults) · unclear: R7 (Continence care), R9 (Care planning), R10 (End-of-life visits) · absent: R12 (Own small caseload)
- `preferred` — absent: R13 (Doppler assessment for leg ulcers)

R5b and R11 — credible bridges, limits named; R12 and R13 — gaps stated plainly, with closure paths; R4, R7, R9 and R10 — not disproved, because your CV is silent on them.

**Opportunity ledger.** The role looks sound on what the advert states: the pay is in the market range (RR3), and you get a senior nurse's support plus pool cars (RR4). Two things are open: whether the posting is live (RR1), and the hours and contract basis (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live (RR1); (2) you can evidence clear written records, the R4 essential (R4); (3) the two gaps R12 and R13 are stated plainly in your application, never papered over.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` its own "About Calderbrook Community Health" page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Team lead's footprint | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. She spoke at the 2025 community nursing forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | An ordinary entry-level community post, with no bundled roles and no responsibility without support. The team lead's talk on Doppler training for staff new to community work suggests Doppler is taught on the job, which would fit "desirable" | `[inferred]` from the advert's wording and the speaker page |
| Market calibration | Band 5 community staff nurse, England: median basic pay £34,300, interquartile range £32,400 to £36,600; 61% of respondents were paid mileage and 24% had a pool or lease car. The posting's £31,050–£37,800 spans that range, and its pool cars are the less common arrangement. This is a pattern, not this employer's offer to you | `[generic]` Wardround 2026 pay guide (n=1,240); `[grounded]` advert for its own figures |
| Unknowns | Closing date; hours, weekend and evening cover; permanent or fixed-term; size of the "small caseload"; where in Calderdale the patch is | `[grounded]` advert silent |
| Contradictions | None between the advert and the About page. The advert itself could not be found on a careers page (RR1) | `[grounded]` About page; the careers address I tried returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration, revalidation due March 2028. This is stated and not checked; confidence is medium because I have not inspected anything | `[grounded]` your CV text | Check your own entry on the NMC online register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated, not checked | `[grounded]` your CV text | Check your licence record on the official driving-licence service; a recent endorsement count would matter for pool-car cover |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward is well over one year | `[grounded]` your CV text | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | Your CV says nothing about documentation or record systems. I am not assuming ward notes count, because the advert names an electronic patient record specifically | `[grounded]` CV silence | See G1 |
| R5a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds are stated | `[grounded]` your CV text | none |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care carry over; leg-ulcer care, compression and its assessment are not stated | `[grounded]` your CV text; `[generic]` leg ulcers need different assessment from pressure ulcers | See G3 |
| R6 | Catheter care | important | direct | medium | none | Stated | `[grounded]` your CV text | none |
| R7 | Continence care | important | unclear | low | discovery | Catheter care is stated; wider continence care is not | `[grounded]` CV silence | See G2 |
| R8 | Insulin administration | important | direct | medium | none | Stated | `[grounded]` your CV text | none |
| R9 | Care planning | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | See G2 |
| R10 | End-of-life visits | important | unclear | low | discovery | Not stated. An acute ward may have given you this experience, but I won't assume it | `[grounded]` CV silence | See G2 |
| R11 | Home visiting of housebound adults | important | adjacent | medium | transferability | Eighteen months on discharge-to-assess, visiting patients at home in their first week after discharge. Limit: those are recently discharged patients, not long-term housebound ones, and whether the visits were yours to plan is not stated | `[grounded]` your CV text | Use this as the lead evidence |
| R12 | A small caseload of your own | important | absent | none | capability | You say you have never held a caseload. The advert says it comes with senior-nurse support, which is how the role itself frames the step | `[grounded]` your statement and the advert | See G4 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you have never done one. It is "desirable", not essential | `[grounded]` your statement and the advert | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | No mention of record systems or documentation | It is the only essential requirement your CV leaves open | Electronic notes or charting on the ward; discharge documentation; D2A visit records; audits of your documentation | A named system, or a short description of what you documented | `[grounded]` CV silence; `[inferred]` that it is the one essential left open |
| G2 | Continence, care planning, end-of-life (R7, R9, R10, important) | discovery | The CV is silent on all three | Each is a named duty; confirmed experience moves them to `direct` | Caring for dying patients on the ward; contributing to or updating care plans; bladder and bowel care beyond catheters | Anonymised care-plan extract or ward training record | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5b, important) | transferability | Other wound types are covered | A named duty and the team lead's own speciality | Applying compression or dressings to leg wounds; assessing a patient with venous or mixed ulcers | Training certificate or competency sign-off | `[grounded]` CV and advert; `[inferred]` the speciality from the speaker page |
| G4 | Own caseload (R12, important) | capability | Never held one | The advert expects it, but with support | None to recover. D2A planning may be adjacent evidence, which G4's question asks about | None | `[grounded]` your statement |
| G5 | Doppler assessment (R13, preferred) | capability | Never done one | Desirable only. The team lead has spoken on Doppler training for new community staff, which suggests it may be taught | None to recover. Closure path: ask in the informal chat whether training is offered | None | `[grounded]` your statement and the speaker page; `[inferred]` that training may be offered |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on a careers page | unknown | — | "Join our district nursing team caring for housebound adults in their own homes" | The About page says vacancies are listed on a careers page. The address I tried returned nothing, but I guessed that address, so the posting may simply sit elsewhere | `[inferred]` from one failed fetch against the About page's statement | Is this role currently open, and what is the closing date? | unresolved |
| RR2 | Hours, rota and contract basis unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Hours, weekend and evening cover and permanence may be set at interview | `[inferred]` from the advert's silence | What are the working hours and the weekend or evening cover, and is the post permanent? | unresolved |
| RR3 | Pay stated and in range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The stated range spans the survey's interquartile range, so it is not a pay mismatch | `[grounded]` advert; `[generic]` survey band | Where in the range would someone with five years' ward experience start? | noted |
| RR4 | Support and pool cars stated | positive_signal | — | "supported by a senior community nurse"; "pool cars are provided" | Real support for a first caseload, and no need to use your own car. Pool cars are the less common arrangement in the survey | `[grounded]` advert; `[generic]` survey | How is the senior nurse's support structured in the first months? | noted |

## Application plan

`resume_edits_pending_approval` — nothing below is final until you approve it. That covers the table and the notes under it alike.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Give the discharge-to-assess secondment its own entry at the top of your experience, in your own words: "seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge" | See R11. Reordering only, no new fact | `[grounded]` your CV text | pending your approval |
| E2 | Put "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" together near the top | See R5a, R6, R8. Your wording, unchanged | `[grounded]` your CV text | pending your approval |
| W1 | In your covering note, lead with five years on an acute medical ward and eighteen months visiting patients at home on discharge-to-assess. State plainly that you have not held your own caseload or done a Doppler assessment | R12 and R13 are stated, never hidden. Every clause traces to your own sentences | `[grounded]` your CV and statements | pending your approval |
| A1 | Take up the advert's offer of an informal chat with Rhiannon Mabbott. Ask the RR1 and RR2 questions | Settles the open items before you invest effort. The advert invites the call | `[grounded]` advert | pending your approval |
| A2 | Check your NMC register entry and your licence record before applying | R1 and R2 are your own statements, not verified. The check is yours to make | `[grounded]` your CV text | pending your approval |

## Evidence status

Verified: none yet. You also pasted your National Insurance number. It isn't needed, and I haven't used or repeated it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization row is established; the live-posting check stays open as RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's scope read and the positioning in A1 |

I can also run a deeper pass on Calderbrook (public staff and candidate reports, recent news, leadership changes), using up to 5 more searches and 2 more fetches. Say the word and it runs.

I can write all this up as a `tuesday-dossier.md` file if you'd like to keep it.

**Upgrade menu**

- Your working-pattern needs, pay floor and any other non-negotiables → the hard-gates line can check the role's terms against them. At the moment it can't.
- The registration and licence checks → R1 and R2 move from stated to confirmed.
- A named record system or a description of your documentation → R4 moves from `unclear`, and the one open essential closes.
- An anonymised care plan or training record → R9 and R10 firm up.
- The recruiter's or team lead's answer on hours, contract and closing date → RR1 and RR2 close, and the `conditional_go` likely becomes `go` or `no_go`.

**Questions**

- G1 — Which electronic patient record systems have you used on the ward and in discharge-to-assess, and what did you record in them?
- G2 — Have you been involved in end-of-life care, continence care beyond catheters, or writing or updating care plans? What was your part?
- G4 — On discharge-to-assess, did you plan your own day's visits and manage a list of patients, or were visits allocated to you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.