I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, this is worth continuing, with conditions. Status: `conditional_go`.** The WhatsApp message only schedules a video call and asks for no money, documents or personal details. Scheduling a call by chat, with the invite emailed, is a routine step. I couldn't establish Fernquay from here, though (RR1). That caps the status at `conditional_go` until you've checked the company yourself.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer, no design peers) · unclear: R9 (Research calls with school owners)

R7 — checkout is one stage of a flow, limit named; R8 — never the only designer, so a bridge at best; R9 — unclear who your usability sessions were with.

**Opportunity ledger.** The posting is concrete: stated pay and equity, a named co-founder, a bounded scope (RR5). Against that, the employer is not established from here (RR1), success measures and decision rights are unstated (RR2), pay is unchecked against the market and equity terms are unstated (RR3), and what the work-sample preference means in practice is unclear (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay's own website and careers page confirm the company and this posting (RR1); (2) the salary clears your floor (R2, G1); (3) the call gives concrete answers on decision rights and success measures (RR2); (4) your checkout work is framed as what it was, never as end-to-end ownership (R7, R8).
- **What would change this:** a salary below your floor makes R2 `hard_gate_fail` and the status `no_go`. A careers page that confirms the role and a clean call move it toward `go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. This is the posting's own description; I couldn't check it independently | `[grounded]` JD header and body |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with the co-founder | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in the Galway office, the rest flexible | `[grounded]` JD |
| Pay | €52,000–€60,000 plus 0.5–1% equity; vesting, strike price and valuation not stated | `[grounded]` JD |
| Process | 45-minute video call with the co-founder and the CTO. Time arranged by WhatsApp, invite and link by email. The message asks for no payment, documents or personal details | `[grounded]` WhatsApp message |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | A bounded remit: one flow, two engineers, one research audience. The unknown is how much sits around it (tooling, standards, design review), since there is no existing designer | `[inferred]` from the JD's scope language against its silence on outcomes |
| Sole-designer pattern | A first-designer post at a six-person company typically means no design peer to review work and no established design system | `[generic]` role-family pattern, not a claim about Fernquay |
| Market calibration | Not established. The salary sweep did not run, so I can't place €52,000–€60,000 against the market for this title and seniority | `[grounded]` research tier line below |
| Unknowns | Decision rights; success measures; equity terms; who the CTO is beyond the first name; what the work-sample preference involves | — |
| Contradictions | None between the posting and the message: the co-founder named in the JD wrote to you, and the CTO and the "checkout case study" fit what you sent. The posting has not been checked against the company's own careers page | `[grounded]` the two texts you provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the office days are reachable. You haven't said whether two fixed office days suit you. Medium because it's unprobed prose | `[grounded]` your background, "moved back to Galway last year"; JD | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so I can't say whether the range meets it. No claim exists to grade | `[grounded]` JD states the range; your floor not given | G1: state your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, confirmed and specific but with no inspectable artifact yet. The length-of-experience requirement is met on the stated figure | `[grounded]` your background | A portfolio link would raise to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" across four years. Unprobed, no files inspected | `[grounded]` your background | Portfolio or case study with Figma files would raise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | discovery | Monthly usability sessions with customers is research you ran. Not yet clear whether you planned and recruited them, or ran only evaluative sessions rather than discovery interviews. Medium, with the caveat named | `[grounded]` your background; `[generic]` that "run your own" is often probed for who planned and recruited | G5: held for a later turn |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow at a booking company, and Ronan wrote that they loved the checkout case study. Limit: checkout is one stage of a flow. Whether you owned the stages before it, or decided what shipped, is not confirmed | `[grounded]` your background and the WhatsApp message | G2: which other stages, who decided |
| R8 | First designer: no design peers or existing design practice | important | adjacent | low | transferability | You have never been the only designer anywhere. Adjacent work: you owned a checkout redesign inside a squad. Limit: nothing shows you setting up design standards or working with no design review. Low because the adjacent claim is thin | `[grounded]` your statement and JD "first designer" | G4: held for a later turn |
| R9 | Research calls with school owners (small business operators) | important | unclear | low | discovery | Your sessions were with "customers". That could be travellers or the travel businesses selling to them, and I take the reading that claims less. Operators and consumers are different audiences | `[grounded]` your background; JD | G3: who the customers were |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against €52,000–€60,000 (R2, hard_gate) | hard_gate | The range is stated; your floor is not | A gate not established stays visible. A figure below your floor would end this | Not experience: your own number, and how you weigh 0.5–1% equity | Your own figure | `[grounded]` JD range; your floor not given |
| G2 | Booking flow beyond checkout (R7, must_have) | transferability | A confirmed checkout redesign; nothing on other stages or on who decided what shipped | R7 is the must-have furthest from `direct`, and the call is about it | Search or availability screens, booking changes or cancellations, a design handed over and shipped by you, or a decision you made rather than recommended | Your checkout case study, a before/after of any other stage | `[grounded]` your background; `[generic]` that end-to-end ownership is the claim a first-designer interview probes |
| G3 | Research with operators (R9, important) | discovery | "Customers" is not specific about who | Research with school owners is a named duty of the role | Sessions with suppliers, hosts or agencies; interviews with a small business owner about their admin; any contact with people who run the thing customers book | A research plan, a synthesis deck, a recruiting note (sanitized) | `[grounded]` your wording; `[inferred]` the audience may differ from the role's |
| G4 | Working as the only designer (R8, important) | transferability | Never solo; owned a redesign within a squad | The post has no design peer | Setting a convention a squad then used, or covering for a designer's absence | A shared component or guideline you made | `[grounded]` your statement |
| G5 | Who planned and recruited the sessions (R5, must_have) | discovery | Sessions confirmed; your role in planning not stated | Would move R5 from `medium` toward `high` | Writing a discussion guide, recruiting participants, synthesizing findings | A guide, a findings summary | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "six people in Galway making booking software for sea-kayak and surf schools" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the search did not run, so nothing was found either way | `[generic]` pattern for companies of this size, not a claim about this one | Where is this role listed on your own careers page? | unresolved |
| RR2 | Success measures and decision rights not stated for a first-designer post | unknown | — | "own the booking flow end to end" | The post may carry a flow's outcomes without stated authority over what ships | `[inferred]` from the JD's scope language against its silence on outcomes and authority | What would this role have achieved in its first year, and who decides what ships? | unresolved |
| RR3 | Pay unchecked against the market; equity terms unstated | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | The range may sit above, within or below the band for a designer with 3+ years in Ireland. 0.5–1% means little without vesting, strike price and the company's valuation | `[inferred]` from the stated figures against the withheld equity terms; band not established | What are the vesting schedule, cliff and strike price on the equity, and is the salary range open to negotiation within it? | unresolved |
| RR4 | Work-sample preference | unknown | — | "we would rather see one messy real project than a polished deck" | It may mean showing existing work, or it may later become a request for new work done for them | `[inferred]` from the sentence, which names a preference and no task | Is the sample expected to be existing work, and is there any exercise beyond it? | unresolved |
| RR5 | Stated pay, named co-founder, bounded scope | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity"; "our co-founder, Ronan Kehoe" | The posting gives figures and names the person you'd work with, which is more than many postings do | `[grounded]` JD | Who else would I work with day to day beyond the two engineers? | noted |

## Application plan

Every row is proposed and nothing here is final until you approve it. That covers the advice rows as much as any wording. No CV edits are proposed this turn.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, open Fernquay's own website and careers page yourself, and see that this posting is on it and that the calendar invite comes from an address on that site's domain | RR1: the employer is not established from here. This is advice, not a condition on the call | `[grounded]` RR1 | pending your approval |
| A2 | Describe your checkout work as a checkout redesign within a squad of four engineers, and say plainly you haven't been the only designer. Don't claim end-to-end ownership of the flow unless G2's answer supports it | R7, R8. Ronan already said they liked the checkout case study, so lead with it | `[grounded]` your background; their message | pending your approval |
| A3 | Be ready to say who the customers in your usability sessions were, and who planned and recruited them | R5, R9 | `[grounded]` the R5 and R9 rows | pending your approval |
| A4 | Ask RR1, RR2, RR3 and RR4's questions verbatim on the call, including the equity terms | The register doubles as interview preparation | `[grounded]` the register | pending your approval |
| A5 | If they ask for a work sample, offer one existing project. Check the scope of any further task before agreeing to it | RR4 | `[inferred]` from RR4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer careers" were both refused (search permission not granted). No pages were read. It would have set role reality's organization and contradictions rows and RR1; RR1 stays at its standing entry |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland 2026 startup first designer mid-level" was refused. No pages were read. It would have set market calibration and RR3; both stay unestablished |
| 3. Hiring manager's public footprint | unavailable | A name was given, so the query was formed ("Ronan Kehoe Fernquay co-founder") and refused. It would have set the scope read and which story the plan leads with |

## Dossier offer and upgrade menu

I can write all of this to `tuesday-dossier.md` so you can carry it forward, if you'd like.

- The URL of Fernquay's own careers page or the live posting → RR1 and the role reality rows (a link you give is read as an input and isn't charged to the research budget).
- Your checkout case study or portfolio, with the Figma files → R3, R4 and R7 can reach `high`, and the checkout row's limit narrows.
- Answers to G1, G2 and G3 → R2 clears or fails, R7 firms up, and R9 resolves.
- A salary-band search, if search is permitted → market calibration and RR3.
- A deeper company pass (funding and leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches). It runs only if you say so and search is permitted.
- Rehearsing the call is the job of the mock-interview skill, not this one.

Questions, all optional:

G1 (R2) — What is the lowest base salary you would accept, and does €52,000 clear it?

G2 (R7) — Beyond checkout, which other stages of the booking flow did you personally design or own, and who decided what shipped?

G3 (R9) — In your monthly usability sessions, who were the customers: travellers booking trips, or the businesses selling to them? And who planned, recruited and ran the sessions?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.