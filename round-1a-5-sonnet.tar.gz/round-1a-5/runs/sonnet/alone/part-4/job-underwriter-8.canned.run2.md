I've read the skill's rules. Next I'm loading the web tools to check whether the employer can be found and to calibrate the pay.
**Decision snapshot**

**No, don't go ahead. I can't establish the firm from here, and the requests in these messages (RR1, RR2, RR3, RR4) are very likely a scam, so send nothing yet. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (income of at least €30,000 a year)
- `must_have` — direct: R3, R4 · adjacent: R2 (strong attention to detail)
- `important` — adjacent: R6 (order handling) · unclear: R5 (a quiet place to work)

R2 — adjacent, accuracy not yet evidenced; R6 — parcel queries are a bridge, order entry untested.

**Opportunity ledger.** RR1, RR2, RR3 and RR4 each ask for something that should not be asked of an applicant. RR5 records that the employer could not be found, and RR6 records pay that can't be checked against your floor.

- **Hard gates:** none failed; unconfirmed: R1 (income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** all four requests withdrawn, and a written offer from an employer you can confirm on its own website, with pay terms that meet R1.

I'm not using or repeating your IBAN, PPS number or passport details, and I don't need them for this assessment. Keep them to yourself for now.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. Two searches returned no results, so the employer is not established | `[grounded]` searches by that name returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "set your own hours" | `[grounded]` JD |
| Pay as stated | "up to €26 an hour plus commission". At 15 hours a week that is about €20,280 a year; at 30 hours, about €40,560. Your €30,000 floor needs about 22 hours a week at the top rate, all year | `[grounded]` JD rate; `[inferred]` arithmetic on 52 paid weeks at the top rate |
| Process | Applying, "interview" and offer all on Telegram, no calls or video | `[grounded]` JD and messages |
| Market calibration | Order processing and customer operations coordinators in Ireland have a median salary of €31,200 (middle half €28,400 to €34,100). The guide covers salaried roles only. That median works out to roughly €15 an hour at 40 hours a week | `[generic]` role-family sweep this session, one pay guide; `[inferred]` hourly conversion |
| Unknowns | Employer's identity, employment type (employee or contractor), guaranteed hours, how commission is paid | `[grounded]` JD silent on each |
| Contradictions | The posting says "No experience needed, full training provided". The messages then ask for payment and bank, tax and passport details before any interview | `[grounded]` JD against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor, which is specific and yours. Fit is unclear because the posting gives only "up to €26 an hour" over 15–30 hours, with no guaranteed hours | `[grounded]` your statement; `[inferred]` from the JD's ranges | Get pay terms in writing from an employer you can confirm independently |
| R2 | Strong attention to detail | must_have | adjacent | medium | discovery | You handled about 60 tickets a day and kept a team tracker. Neither shows accuracy directly. Intake prose is capped at `medium` | `[grounded]` your background as typed | See G1 |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Not yet inspected | `[grounded]` your background as typed | none |
| R4 | Good written English | must_have | direct | medium | none | Three years of written Zendesk ticket replies. Not yet inspected | `[grounded]` your background as typed | none |
| R5 | A quiet place to work | important | unclear | none | discovery | You haven't said | `[grounded]` nothing stated | Your own call; it affects nothing else here |
| R6 | Order handling (inferred from the title "Order Processing Coordinator") | important | adjacent | medium | transferability | Parcel-courier tickets deal with order and delivery status. Limit: entering or processing orders is not shown | `[inferred]` from the title; `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R2, must_have) | discovery | Volume and a tracker, but nothing showing accuracy | It would matter for any openings you pursue instead | Ticket quality scores, error rates on your tracker, corrections you caught, the checklist you used when training new starters | A quality-score screenshot, a team review, or the tracker itself with names removed | `[grounded]` the background as typed; `[generic]` that coordinator roles screen on accuracy |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | This request asks for what is needed only after a written offer. The sender's identity is unresolved | `[generic]` a known pattern in recruitment scams | Do you ask applicants for bank, PPS and passport details before a written offer? | confirmed |
| RR2 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Paying to get a job is a sign this request is not an employer's | `[generic]` a known pattern in recruitment scams | Do you require applicants to pay for equipment? See RR1 for the route | confirmed |
| RR3 | Cheque to lodge, with most of it sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque you pass money on from can be returned after the funds appear, leaving you out of pocket | `[generic]` a known pattern in recruitment scams | Do you send cheques to new starters to forward to a supplier? See RR1 for the route | confirmed |
| RR4 | Process run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the offer both happened only in chat, so no step can be placed with a named employer. The check is whether the role exists on an employer's own site | `[grounded]` the posting and messages | Can you point me to this role on your own careers site, and name who I would be speaking to? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` possibilities side by side, none ranked | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay above market norms, with no guaranteed hours | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process" | €26 an hour for "no experience needed" sits above the salaried median in role reality. "Up to" and a flexible 15–30 hours may leave your floor out of reach. I took the lower severity because the band is salaried-only | `[generic]` one salary guide against the posting's figure | What hourly rate and minimum weekly hours does the contract guarantee? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or €349 transfer. If a cheque arrives, don't lodge it | See RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If you want to check the employer, use only contact details from a company website you find yourself, not the Telegram handle or the velloway.hr address | See RR1, RR5 | `[grounded]` register | pending your approval |
| A3 | Report the posting to the jobs site you found it on | A posting that leads to these requests may be live for other applicants | `[generic]` how job boards handle reports | pending your approval |
| A4 | Aim the same effort at customer-operations openings listed on employers' own careers pages. R3 and R4 map directly there; R2 and R6 are adjacent. I'm proposing no CV wording | See R2, R3, R4, R6 | `[grounded]` R-rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers order processing coordinator remote"; both returned no results, so the employer is not established. This moved role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary per hour", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This moved market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I've published nothing. If you'd like this written up as a file, I can produce `tuesday-dossier.md`.

## Upgrade menu

- A link to the live posting on the jobs site, or the employer's own careers page → RR4 and RR5 can be checked against it.
- Any written pay terms you receive from an employer you've confirmed → R1 resolves, and RR6 is set against the stated hours.
- A quality score, a review or your tracker with names removed → R2 moves toward `direct` and `high` evidence.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Do you have anything that shows how accurate your ticket work was, such as quality scores, error rates, or corrections you caught on the tracker? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.