I'll read the skill's reference files first.
Research is done, apart from one last check. The careers page I guessed doesn't exist, so I'm fetching the company's About page to see if it links the live posting. Then I'll write the assessment.
# Is this Calderbrook role worth applying for?

## Decision snapshot

**Yes, apply. Neither gate fails (R1 and R2 are both `direct`), so the status is `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R6a, R7, R10 · adjacent: R5b (leg-ulcer care), R11 (own small caseload) · unclear: R6b (continence care), R8 (care planning), R9 (end-of-life visits)
- `preferred` — absent: R12 (Doppler assessment)

R4 — essential, and your CV is silent on records; R11 (`low`) — your discharge-to-assess home visits are the bridge, with the limit named; R12 — preferred, a training question for the informal chat.

**Opportunity ledger.** The role is concrete: duties, a supervising senior nurse and a named contact are stated (RR5), and the employer matches its own About page (RR6). The open points are whether the posting is live (RR1), induction for a nurse new to community work (RR2), the rota (RR3) and where you'd start in the pay range (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live (RR1); (2) you can evidence clear written records (R4, G1); (3) the caseload and Doppler gaps (R11, R12) are presented as what they are, adjacent and not held, and never as a caseload you've carried.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. It was founded in 2015, has 410 staff and works from four locality hubs. | `[grounded]` About page, fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, recorded on an electronic patient record | `[grounded]` advert |
| Structure | A small caseload of your own, supported by a senior community nurse; pool cars provided | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` advert |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England (n=1,240) gives a median basic pay of £34,300 and an interquartile range of £32,400–£36,600. The advert's range encloses that interquartile range, so there is no pay mismatch. In the same survey 24% had a pool or lease car and 61% were paid mileage. | `[generic]` Wardround 2026 pay guide, one search; a pattern, not this employer's offer |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` forum speaker page |
| Scope read | A bounded entry-level community post: supported caseload, defined clinical list. Nothing in the advert suggests duties beyond the title. | `[inferred]` from the advert's wording on support and caseload size |
| Unknowns | Whether the posting is live, induction and competency sign-off, rota and out-of-hours cover, pay placement, and when mileage applies given pool cars | `[inferred]` from the advert's silences |
| Contradictions | None between the advert and the About page. The careers page was not reached at the address tried. | `[grounded]` fetch returned no page at that address |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration, with revalidation due March 2028. This is stated, not checked. | `[grounded]` your CV | Check your own entry on the NMC online register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. This is stated, not checked, and the advert says pool cars are provided. | `[grounded]` your CV | Check your own DVLA licence record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | You state five years as a staff nurse on an acute medical ward. A length-of-experience requirement is not a gate, and your five years exceed the one asked for. | `[grounded]` your CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | Your CV says nothing about records or the systems you used. I can't claim record-keeping you haven't stated. | `[grounded]` CV silence | Ask G1 |
| R5a | Wound care | important | direct | medium | none | Your CV names pressure ulcers and surgical wounds. | `[grounded]` your CV | none |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Wound care carries over. Your CV does not mention leg ulcers, and leg-ulcer care is a specific skill set. `[generic]` | `[grounded]` CV; `[generic]` on the specificity | Name the limit plainly and ask about training (A1) |
| R6a | Catheter care | important | direct | medium | none | Your CV states catheter care. | `[grounded]` your CV | none |
| R6b | Continence care beyond catheters | important | unclear | low | discovery | Your CV mentions only catheter care. | `[grounded]` CV silence | Fold into G2 if relevant |
| R7 | Insulin administration | important | direct | medium | none | Your CV states insulin administration. | `[grounded]` your CV | none |
| R8 | Care planning | important | unclear | low | discovery | Your CV does not mention care planning. I won't infer it from the discharge-to-assess secondment. | `[grounded]` CV silence | Ask only if the answers to G3 open it up |
| R9 | End-of-life visits | important | unclear | low | discovery | Your CV is silent on end-of-life care. | `[grounded]` CV silence | Ask G2 |
| R10 | Visiting patients in their own homes | important | direct | medium | none | You spent 18 months on secondment to the discharge-to-assess team, visiting patients at home in their first week after discharge. The limit is that these were short post-discharge episodes, not an ongoing district caseload. | `[grounded]` your CV | none |
| R11 | Holding a small caseload of your own | important | adjacent | low | transferability | You say you have never held your own caseload. Your discharge-to-assess visits are the nearest evidence, but it is not yet clear whether you owned those patients or carried out allocated visits. I took the lower band for that reason. | `[grounded]` your statement and CV | Ask G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you have never done one. It is preferred, not essential. The closure path is training, so the question is whether Calderbrook provides it (A1, RR2). | `[grounded]` your statement | Ask in the informal chat |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | Nothing on records or systems in your CV | R4 is the one `must_have` row below `direct`, so settling it could move `conditional_go` to `go` | Electronic or paper records on the ward; discharge-to-assess visit notes; handover documents; any documentation audit or feedback | A documentation audit result, a competency record that includes record-keeping, or a manager's reference line | `[grounded]` CV silence; `[inferred]` that resolving it moves the status |
| G2 | End-of-life care (R9, important), continence (R6b) | discovery | Your CV has no palliative or continence content | End-of-life visits are a named duty in the advert, and an interviewer is likely to ask about them `[generic]` | Caring for dying patients on the ward; discharge visits to patients on a palliative pathway; supporting families | A palliative-care competency or training record | `[grounded]` CV silence; `[generic]` on interview likelihood |
| G3 | Caseload ownership (R11, important) | transferability | Home visits are evidenced, but whether you owned them is unclear | Your answer decides how truthfully the "own caseload" line can be stated | Deciding visit frequency; re-planning care; escalating to GPs or community teams; following the same patients across the week | A secondment role description, or a service summary of the discharge-to-assess team | `[grounded]` your statement and CV; `[inferred]` on what ownership would look like |
| G4 | Leg-ulcer care and Doppler (R5b, R12) | capability | No leg-ulcer or Doppler evidence | Preferred only, but R5b is a named duty | Any leg-ulcer dressing or compression work on the ward; any Doppler observation | A training certificate, if you hold one | `[grounded]` your statement and CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Join our district nursing team caring for housebound adults in their own homes" | The careers page was not reached at the address tried, and the posting may sit on another page | `[grounded]` the fetch returned no page at that address | Can you point me to this vacancy on your careers page, and give its closing date? | unresolved |
| RR2 | Induction and competency sign-off unstated | unknown | — | "supported by a senior community nurse" | Support is named, but its form is not. Leg-ulcer and Doppler competence for a newcomer may be signed off during the post. | `[inferred]` from the advert's silence | What induction and competency sign-off does a nurse new to community work receive, and does it include Doppler training? | unresolved |
| RR3 | Rota and lone working unstated | unknown | — | "end-of-life visits" | Visits could fall outside weekday hours, and the rota is not given | `[inferred]` from the advert's silence | What does the rota look like (weekends, evenings, on-call), and how is lone working supported? | unresolved |
| RR4 | Pay placement and mileage unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Your start point within the range is not given. The survey median sits inside the range. "Plus mileage" may apply only to personal-car use. | `[generic]` survey band; `[inferred]` from "pool cars" beside "mileage" | Where would a nurse with five years' post-registration experience start in this range, and when is mileage paid given pool cars? | unresolved |
| RR5 | Concrete duties and supervision stated | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse." | Scope is bounded and support is named | `[grounded]` advert | How is the senior nurse's support structured: shared visits, supervision frequency? | noted |
| RR6 | Employer matches the advert | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | The employer exists as described, running adult community nursing in Calderdale | `[grounded]` About page | How large is the Halifax team, and how many nurses are at Band 5? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open your CV's summary with the line below and keep the wording. Proposed line: "Five years as a staff nurse on an acute medical ward; the last 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge." | See R3, R10. Every clause traces to your own CV. | `[grounded]` your CV | pending your approval |
| E2 | Add a records line only after you answer G1, using your own wording | See R4. I won't write it from nothing. | `[grounded]` R4 row | pending your approval |
| A1 | Take up the advert's offer of an informal chat with Rhiannon Mabbott. Proposed framing: "I haven't done Doppler assessment. Is training provided for staff new to community work?" | See R12, RR2. It is candid, and her published talk on Doppler training for newcomers makes it a natural question. | `[grounded]` advert and forum page | pending your approval |
| A2 | In the chat or at interview, describe discharge-to-assess as home visiting, and don't call it a caseload unless G3 shows you owned those patients | See R11. Per the reframing audit, a kind and scope change here would fail the first follow-up question. | `[grounded]` your statement and CV | pending your approval |
| Q1 | Ask RR1 to RR4 verbatim in the chat or at interview | The register doubles as interview preparation. | `[grounded]` register | pending your approval |
| C1 | Check your own NMC register entry and DVLA licence record before applying | See R1, R2. Both are stated, not checked, and the checks are yours to make. | `[grounded]` rows R1, R2 | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment, so I haven't used or repeated it.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). I fetched that page and the careers address calderbrookhealth.example/careers, which has no page. Moved role reality's organization and contradictions rows, RR6 and RR1. |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nursing role Agenda for Change pay 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR4. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved role reality's hiring manager row and A1. |

## Closing run

I can save this assessment as `tuesday-dossier.md` if you'd like to keep it or build on it.

**Upgrade menu**
- Your NMC register entry and DVLA licence record, checked by you, would firm up R1 and R2.
- A signed ward competency record covering wound care, catheters and insulin would lift R5a, R6a and R7 toward `high`.
- A secondment role description or service summary for the discharge-to-assess team would settle R10 and R11.
- A pay floor, hours or travel limits would let the hard-gates line check against your constraints.
- A link to the live posting would close RR1.
- A deeper pass on Calderbrook (leadership and service changes, inspection and staff reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — On the ward and in the discharge-to-assess team, what did you record and where (an electronic record, paper notes, handover documents), and has anyone audited or commented on your documentation?

G2 — Have you cared for patients at the end of life, on the ward or on home visits? What was your part in it?

G3 — On your discharge-to-assess visits, did you own particular patients through their first week (deciding visit frequency, re-planning care, escalating), or were visits allocated for you to carry out?

Answer each in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.