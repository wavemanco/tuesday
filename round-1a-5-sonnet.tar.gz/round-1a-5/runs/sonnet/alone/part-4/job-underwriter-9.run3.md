I'm reading the skill's reference files so the assessment follows its format. Then I'll give you the verdict.
**Yes, it's normal to be asked for bank details, PPS number and passport after a written offer. It isn't a reason to turn the job down. Your caution is right for a stage *before* an offer, but this is onboarding. Status: `conditional_go`, because I couldn't verify the employer myself (RR1).**

My web searches were refused, so nothing below is checked against outside sources.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Right to work in Ireland), R2 (Two office days in Limerick), R3 (Salary €38–42k, offered €40,000)
- `must_have` — direct: R4, R6, R7, R9, R10 · adjacent: R8 (Monthly payroll for 240 staff) · unclear: R5 (PAYE, PRSI and USC knowledge)
- `important` — unclear: R12 (Answering staff payroll queries) · absent: R11 (Pension changes)

R8 — a credible bridge, its limit named; R11 — you've never done these yourself, the only weak row; R5 — the one must-have I can't read from what you told me.

**Opportunity ledger.** The offer matches the ad on title, hybrid pattern, salary band and 240-staff scale, and it names your manager (RR3). The employer isn't established by my own sources (RR1). The contract terms haven't been seen (RR2), and support for the pension work is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Right to work in Ireland), R2 (Two office days in Limerick), R3 (Salary €38–42k, offered €40,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the portal link and the sender are confirmed through contact details on Marrowgate's own site — RR1; (2) you've seen the written contract terms before you resign — RR2; (3) you know who will teach you pension changes — R11, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` ad and offer text; not independently confirmed |
| Role | Permanent Payroll Administrator at €40,000, reporting to Declan Garvagh, Finance Manager; hybrid, two office days | `[grounded]` offer email |
| Onboarding requests | Bank details, PPS number and passport scan, all requested only after you accept, through a portal. The original passport is brought in person on day one | `[grounded]` offer email |
| Is that sequence ordinary? | Salary details and a PPS number are what an employer needs to pay you and report you to Revenue. A right-to-work check is a standard onboarding step. Taking them after a written offer is the usual order, and taking them before one is the pattern to refuse. I couldn't check this against Revenue or employer guidance | `[generic]` common onboarding pattern; not verified this session |
| Interview history | Two in-person interviews at their office | `[grounded]` you told me |
| Unknowns | Contract, probation and pension-scheme terms; who handles pension changes today; which payroll system they use | — |
| Contradictions | None between the ad and the offer | `[grounded]` the two texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland (passport check) | hard_gate | unclear | low | hard_gate | You haven't stated your work-eligibility position, so I can't mark it met | `[grounded]` offer text; nothing from you | G4 |
| R2 | Two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | You interviewed at the office, but you haven't told me your commute or schedule constraints | `[grounded]` ad; constraints not given | G4 |
| R3 | Salary €38,000–€42,000; offered €40,000 | hard_gate | unclear | low | hard_gate | €40,000 sits inside the band the ad stated, but I don't know your floor | `[grounded]` ad and offer; floor not given | G4 |
| R4 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff exceeds the requirement. It rests on your CV statement alone | `[grounded]` your account | none |
| R5 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You didn't say your hotel payroll ran under Irish rules or that the Payroll Technician cert covered them | `[grounded]` silence in your account | G1 |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your account | none |
| R7 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your account | none |
| R8 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | The carry-over is full-cycle payroll. The limit is 90 staff on a fortnightly cycle against 240 monthly, roughly 2.7 times the headcount | `[inferred]` from the two scales | G2 |
| R9 | Process starters and leavers | must_have | direct | medium | none | You did both at the hotel group | `[grounded]` your account | none |
| R10 | Monthly payroll-to-general-ledger reconciliation | must_have | direct | medium | none | You did exactly this monthly | `[grounded]` your account | none |
| R11 | Process pension changes | important | absent | none | capability | You've never done them; your manager did | `[grounded]` your account | G3 |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Your account doesn't mention staff queries | `[grounded]` silence in your account | skipped, minor |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish tax knowledge (R5, must_have) | discovery | Hotel payroll and a cert, but no statement that either was Irish-rules based | A must-have I can't currently read, and an interview or probation check would probe it | Irish PAYE and USC tables, PRSI classes, Revenue payroll submissions, year-end returns | Cert syllabus, a sanitised payslip layout, a Revenue-submission screenshot | `[grounded]` silence; `[generic]` that employers probe this |
| G2 | Scale of 240 staff, monthly (R8, must_have) | transferability | 90 staff, fortnightly, with monthly reconciliation | The jump is in headcount and cycle, not in kind of work | Any month-end close you owned; peak runs such as seasonal starters | A reconciliation workbook, sanitised | `[inferred]` bridge from your account |
| G3 | Pension changes (R11, important) | capability | No direct or adjacent evidence; carried as a minor risk, since it's one duty of several | The role lists it as a duty, so you'd be learning it on the job | Any pension deduction setup or opt-out you assisted with | None expected | `[grounded]` your statement |
| G4 | Your own limits (R1, R2, R3, hard_gate) | hard_gate | The offer meets the ad's terms; your constraints weren't given | Gate rows stay unconfirmed until you say they're met | Pay floor, commute, notice period | None needed | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from my sources | risk_signal | medium | "Marrowgate Housing People Team" | My searches were refused, so I can't confirm the employer, the live posting or the sender domain. Your two in-person interviews at their office are the stronger evidence they exist | `[generic]` a standing check when research is unavailable; not a claim about this employer | Can you confirm the portal link will sit on your own website's domain, and give me a number for the People Team to confirm it? | unresolved |
| RR2 | Contract terms not yet seen | unknown | — | "Please reply to accept within five working days" | The offer email states title, pay and hours pattern, but not probation, pension scheme or notice terms | `[inferred]` from what the email omits | Could you send the written terms, including probation and pension scheme, before I accept? | unresolved |
| RR3 | Offer matches the ad | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The role is concretely defined, with a named manager and pay inside the advertised band | `[grounded]` offer compared with the ad | Who else is on the payroll team? | noted |
| RR4 | Support for pension changes unstated | unknown | — | "process starters, leavers and pension changes" | Pension changes are a stated duty, and the role may not have a named person to learn from | `[inferred]` from the ad's silence on training | Who handles pension changes now, and what handover will I get? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept, when you choose to, by replying to the email only, with no documents attached. Ask in the same reply for the written terms | see RR2; nothing in the acceptance needs sensitive data | `[grounded]` offer says portal links follow acceptance | pending your approval |
| A2 | Before using the portal link, check its web address matches marrowgatehousing.ie. Then call the number on their own website, not one from the email, and ask whether the People Team sent it | see RR1 | `[generic]` a basic check before entering any personal data | pending your approval |
| A3 | Enter bank, PPS and passport details only in that portal, never by email or message. Take the original passport to day one as asked | keeps the sensitive data on one channel | `[generic]` general data-handling practice | pending your approval |
| A4 | Ask Declan Garvagh who will cover pension changes during your first months | see R11, RR4 | `[grounded]` RR4 | pending your approval |

Beyond the assessment: I could draft the short acceptance email for A1, with its request for the terms, if you approve.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; the call was refused. It would have moved the contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator Ireland salary 2026 PAYE PRSI USC"; refused. It would have given a market calibration for R3 |
| 3. Hiring manager's public footprint | unavailable | A name was given (Declan Garvagh), but no search was sent because search had just been refused. It would have moved the scope read in role reality |

## Upgrade menu

- Allowing web search lets me check the employer and the live posting, which could close RR1 and move the status towards `go`.
- A salary-band search would calibrate R3 against the market.
- Your answer on each of G1, G2 and G4 firms up R5, R8 and R1 to R3.
- The written contract closes RR2.
- A deeper pass on Marrowgate (leadership changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches) is available if you say the word.

One dossier file, `tuesday-dossier.md`, can save all of this if you want it.

**Questions**

- G1 — Did your hotel payroll and your Payroll Technician cert run under Irish PAYE, PRSI and USC rules, and did you apply them yourself?
- G4 — Are €40,000 and two office days a week in Limerick within what you need, and is your right to work in Ireland straightforward?
- RR1 — Did the offer come from the same address or contact that arranged your interviews?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.