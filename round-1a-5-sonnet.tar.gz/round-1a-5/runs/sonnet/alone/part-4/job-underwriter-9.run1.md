Two web searches were refused, so I'm using only what you pasted. Here's the assessment on that basis.

# Underwriting: Payroll Administrator, Marrowgate Housing

## Decision snapshot

**Accept, once the conditions below are met. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unknown against your constraints: R9 (Two days a week in Limerick), R10 (Pay band €38–42k)
- `must_have`: direct: R1, R3, R4 · unclear: R2 (Irish PAYE, PRSI, USC)
- `important`: direct: R5, R6 · adjacent: R8 (Monthly run for 240 staff) · absent: R7 (Pension changes) · unclear: R11 (Staff payroll queries)

**Hard gates.** R9 and R10 are both unknown. You haven't told me your commute or pay floor. The €40,000 offer sits inside the advertised band.

**Opportunity ledger.** The offer looks routine and credible. It follows two in-person interviews and comes from a company-domain address. The requests for bank details, PPS number and passport come after a written offer, through a portal. That is standard practice, not a warning sign (RR1). Two things are open. I couldn't verify the employer independently (RR2), and the offer is missing some terms (RR3).

## Role reality

- **Role.** Payroll Administrator at a Limerick housing association. You run monthly payroll for 240 staff. You also handle starters, leavers and pension changes, reconcile payroll to the general ledger, and answer staff queries. You report to the Finance Manager. The salary is €40,000 and the post is permanent and hybrid. [grounded: ad and offer]
- **Scale step-up.** You'd move from fortnightly payroll for 90 staff to monthly payroll for 240. The mechanics are the same but the volume is higher. [inferred]
- **Market calibration.** I couldn't check the pay band. A €38–42k range for a payroll administrator with 2+ years and a qualification is plausible in Ireland outside Dublin. [generic]
- **Unknowns.** The offer doesn't state:
  - the start date (it says "agreed once your notice period ends")
  - probation
  - pension scheme terms
  - annual leave
  - a contract date
  - who handles pension changes today

  [grounded: absent from the offer text]
- **Contradictions.** None. The ad and the offer agree on title, hybrid pattern and salary band. [grounded]

## Evidence map

| # | Requirement | Priority | Fit | Evidence | Gap | Confidence |
|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | 3 years at a hotel group [grounded: your account] | none | medium (self-reported) |
| R2 | Irish PAYE, PRSI, USC | must_have | unclear | Payroll Technician cert 2024. You haven't said whether the hotel group was in Ireland. | discovery | low |
| R3 | Strong Excel | must_have | direct | Daily use, pivot tables, XLOOKUP | none | medium |
| R4 | Payroll qualification | must_have | direct | Payroll Technician certificate, 2024 | none | medium |
| R5 | Monthly payroll-to-GL reconciliation | important | direct | You did this monthly | none | medium |
| R6 | Starters and leavers | important | direct | You processed both | none | medium |
| R7 | Pension changes | important | absent | Your manager handled these | capability (learnable) | high |
| R8 | Run payroll for 240 staff | important | adjacent | 90 staff, fortnightly | transferability | medium |
| R9 | Hybrid, two days in Limerick | hard_gate | unclear | Your location isn't stated | discovery | low |
| R10 | Pay €38–42k | hard_gate | unclear | €40,000 offered. Your floor isn't stated. | discovery | low |
| R11 | Staff payroll queries | important | unclear | Not mentioned in your background | presentation | low |

## Gap recovery queue

All provenance labels are [inferred] unless stated.

- **R2:** Close it by confirming your hotel payroll ran under Irish Revenue rules. If it did, this is a presentation gap, not a capability gap.
- **R7:** This is a real gap, and you shouldn't dress it up. Pension changes are learnable on the job. What would close it is a named person or process at Marrowgate that supports you during your first months.
- **R8:** The mechanics carry over from your current work. Monthly cycles for 240 staff mean larger volumes, not a different task.
- **R11:** You likely answered staff payroll queries at the hotel group. Confirming that makes this a presentation gap.
- **R9 and R10:** These need only your own constraints.

## Opportunity risk register

All provenance labels are [grounded] from the offer text unless stated.

| ID | Class | Severity | Entry |
|---|---|---|---|
| RR1 | positive signal | n/a | The offer follows two in-person interviews. The offer is in writing, comes from a company-domain address, and names your manager and the pay. The requests for bank details, PPS number and passport come after acceptance, via a portal. A payroll employer needs your PPS number to register you with Revenue, and your bank details to pay you. A right-to-work check is routine. No money is requested, and none is needed from you. |
| RR2 | risk signal | medium | I couldn't confirm independently that the employer is as described, because search was refused. The in-person interviews weigh strongly in its favour. Too-new or too-small companies, stale postings and non-hiring employers can't be told apart without checking. To resolve it, look up Marrowgate on its own website, and check that the link in the portal email goes to the same domain. [inferred] |
| RR3 | unknown | low | There's no contract or statement of terms yet, and no probation, pension or leave detail. Irish employers must give a written statement of core terms within five days of your start. [generic] Ask for the full contract before you resign from your current job. |

Two points on the data requests:

- **Passport scan.** A scan before day one is somewhat more than strictly needed, since you'll bring the original on your first day anyway. You can reasonably ask whether the scan can wait until then. Many employers are happy with that. [generic]
- **How to submit.** Submit through the portal only after checking that its address is on the Marrowgate domain or a named payroll or HR provider. Never send these details by plain email.

## Application plan

There's no resume work to do, since you've already been offered the job. [inferred]

1. Reply within the five working days with a short acceptance. Make it subject to a written contract and agreed start date. Wording for you to approve: "I'm delighted to accept, subject to receiving the written contract and agreeing a start date after my notice period." Nothing is sent until you approve it.
2. Don't resign from your current job until you hold the signed contract.
3. Be straightforward about pension changes. You can say you haven't run them end to end and ask how that work is supported. Don't claim experience you lack.

## Evidence status

Research tier: L1: searches 2 of 5 (both refused, no results), fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | The search was refused, so I couldn't check that Marrowgate exists as described. |
| 2 | Role-family sweep (market pay and scope) | unavailable | The search was refused. The calibration is [generic]. |
| 3 | Hiring manager's public footprint | unavailable | The search was refused. I'd use only Declan Garvagh's public professional footprint, and only if you want it. |

## Closing

I can write all of this up as `tuesday-dossier.md` if you'd like.

**Upgrade menu.**

- **Your pay floor and commute:** these would resolve the two hard gates.
- **A look at the contract:** this would let me check terms and pension details.
- **Search access:** it would settle RR2 and verify the pay band.

**Questions.**

1. (R2) Was your hotel group's payroll run in Ireland under Revenue rules (PAYE, PRSI, USC)?
2. (R7, R11) Had you any exposure to pension changes or staff payroll queries, even partial?
3. May I retry the company check once search permission is granted?

Answer in a line each, or say "skip".

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.