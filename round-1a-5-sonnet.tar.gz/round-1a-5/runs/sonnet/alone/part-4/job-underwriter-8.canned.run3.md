Running the research searches on the employer and the role family, then I'll write up the assessment.
I searched for the employer and for pay in this role family. Both searches are in the evidence status near the end.

## Decision snapshot

**No — don't go ahead, and don't send the IBAN, PPS number or passport photo. Status: `no_go`. These messages are very likely a scam, so please don't deposit the cheque.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

R2, R3, R4 — your background matches what the posting asks; R1 — the posting gives only a ceiling, so your floor can't be confirmed.

**Opportunity ledger.** This is where the case fails. RR1, RR2, RR3 and RR4 are demands for payment, a cheque deposit, bank and ID details before any offer, and hiring wholly by chat. The employer is not established (RR5), the contact route is unverified (RR6), and pay is stated only as a ceiling (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the status would only move if no payment, cheque or ID/bank details were asked before an offer. It would also need a written offer from an employer you can verify independently, with the pay stated.

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your IBAN, PPS number and passport aren't needed for this assessment. I haven't repeated them, and I'd keep your IBAN out of any chat.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | The employer could not be found on the web from here | `[grounded]` search returned no results |
| Mandate | "Remote Order Processing Coordinator", processing orders and working in spreadsheets | `[grounded]` posting |
| Pay as posted | "Up to €26 an hour plus commission", 15–30 hours a week, with no floor or commission rate stated | `[grounded]` posting |
| Pay arithmetic | €26 × 15–30 hours × 52 weeks is about €20,300–€40,600 a year, and that is the top of the range, not an offer | `[inferred]` from the posting's figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland have a median base of €31,200 (interquartile range €28,400–€34,100). The guide excludes commission-only and freelance work, so it is a band, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Unknowns | Who the employer is, whether the post is employment or freelance, the pay floor and commission rate, where the work is based | — |
| Contradictions | The equipment is priced at €349, yet the cheque scheme has you forward the balance after €350 of "bonus". The cheque is €2,850, so that balance is far larger than €349. Payroll details were also asked for before the interview, and the job was then "yours" after a chat | `[grounded]` the three messages you quoted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your non-negotiable) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor. Fit is `unclear` because the posting gives "up to" €26 an hour with hours of 15–30 a week. The top of that range clears €30,000 and the bottom does not, and commission is unquantified | `[grounded]` user-confirmed constraint and posting; `[inferred]` arithmetic | RR7's question, if the role ever verifies |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and a weekly tracker are relevant, but this is self-reported background and no artifact has been inspected | `[grounded]` your background as stated | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; self-reported | `[grounded]` your background as stated | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket replies at volume for three years; self-reported, no sample inspected | `[grounded]` your background as stated | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Your background doesn't say. It is a minor point on a posting that doesn't verify | `[grounded]` silence in your background | none — minor |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | "Up to €26 an hour plus commission" with no minimum and no commission rate | A ceiling doesn't show whether €30,000 is reachable. The question is moot while RR1–RR4 stand | None applies; this is a term of the role, not experience | A written offer stating base pay and commission | `[grounded]` posting wording; `[inferred]` that it is moot while the severe flags stand |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. Asking you to pay for the job's equipment is a known pattern in fake job offers | `[generic]` known pattern; `[grounded]` the quoted request | Did your organization ask me to pay €349 to an equipment partner? Please ask this through contact details on your own website, not the chat or the address these messages came from | confirmed |
| RR2 | Cheque to deposit, with the balance forwarded | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. Don't deposit the cheque. The amount is also far above the €349 kit price | `[generic]` known pattern; `[grounded]` the quoted request and the €349 stated earlier | See RR1, same route | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | These details were requested before any written offer, so the step is not routine onboarding. Hold them | `[grounded]` the quoted request and its timing | See RR1, same route | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The posting says there are no calls or video interviews. A job that is both offered and filled only in chat is a pattern to be careful with, whoever sent the messages | `[generic]` pattern; `[grounded]` posting | See RR1, same route | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this employer; `[grounded]` search returned nothing | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Contact route not shown to belong to the employer | risk_signal | medium | "Any problems, email ..." | The address in the chat may not belong to the employer, so the messages may not come from who they name | `[inferred]` from the address being given in the chat, not found on an employer site | Does your organization use this address for hiring? Please ask this through contacts on your own website | unresolved |
| RR7 | Pay stated only as a ceiling | unknown | — | "Earn up to €26 an hour plus commission on every order you process." | The base may sit below the €31,200 market median and below your floor once hours are set | `[inferred]` posting wording against the `[generic]` Pennoral band | What is the guaranteed hourly base, and what is the commission rate? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no €349, no cheque deposit or onward transfer, no IBAN, PPS number or passport photo | See RR1–RR3 | `[grounded]` register | pending your approval |
| A2 | Check each request with the named employer, using contacts you find yourself on its own website. Ask your bank about any cheque you receive before acting | See RR1–RR2, RR6 | `[grounded]` register; `[generic]` that a deposited cheque can later be reversed | pending your approval |
| A3 | Keep screenshots of the chat and the posting | A record helps if you report it or contact your bank | `[generic]` common advice | pending your approval |
| A4 | Put your effort into other openings in customer operations. Your Zendesk, training and Excel tracker evidence fits that family, and its salaried median of €31,200 clears your floor | See R2–R4, R1 | `[inferred]` fit from your background; `[generic]` band | pending your approval |

I'm proposing no CV wording this turn. Nothing above is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official website careers" and got no results, so the employer is not established. This produced RR5 and left the posting's liveness unverifiable |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator hourly pay Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This gave the market calibration and the RR7 comparison |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a chat handle, so there was no query to form |

## Upgrade menu

- A link to the role on the employer's own careers site, or a written offer on letterhead from a domain you can verify. This would address RR5 and RR6.
- The guaranteed base pay and commission rate in writing. This would settle R1 and RR7.
- A deeper research pass (up to 5 more searches and 2 more fetches) on the employer and on reports of recruitment scams that use this company's name. Say the word and it runs.

That is a search for existing public reports; it can't tell you who sent these messages.

I can offer one extra if you'd like it. I could draft a short reply for you to approve that declines politely and sends nothing. It would stay in your hands to send.

If you haven't already deposited the cheque or sent money, you're in a safe position. Say so if you have, because the advice changes.

RR2 — Has the cheque arrived, or have you replied with any details or payment? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.