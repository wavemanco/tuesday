Use the Read tool instead.
# Decision snapshots

## Duinvaart Cold Chain — Operations Analyst (Rotterdam)

**Yes, worth applying. Status: `conditional_go`.** D-R2, D-R3, D-R4 and D-R5a, the core analyst requirements, sit `direct`. The employer and the commute are still unverified.

**Fit ledger.**

- `hard_gate` — unclear: D-R1 (Hybrid, three days a week in Rotterdam office)
- `must_have` — direct: D-R2, D-R3, D-R4, D-R5a · unclear: D-R5b (Temperature compliance tracking)
- `important` — direct: D-R6 · adjacent: D-R7 (Working with depot managers on route changes)
- `preferred` — adjacent: D-R8 (Dutch a plus)

D-R5b — temperature compliance unconfirmed; D-R7 — a weekly review is not yet route changes; D-R8 — conversational Dutch against a plus.

**Opportunity ledger.** The duties are concrete (DRR3). The employer is not established (DRR1) and the salary is withheld (DRR2).

- **Hard gates:** none failed; unconfirmed: D-R1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, DRR1; (2) the three-day Rotterdam commute works for you, D-R1; (3) temperature compliance is not claimed unless you confirm real exposure, D-R5b.

## Kroonhaven Foods — Supply Planner (Utrecht)

**No, not worth your time as written. Status: `no_go`.** K-R2, K-R3 and K-R5, three planning must-haves, are `absent`, and no bridge from your background reaches them.

**Fit ledger.**

- `hard_gate` — unclear: K-R1 (On-site in Utrecht)
- `must_have` — adjacent: K-R6 (Run the weekly S&OP meeting), K-R7 (Fluent Dutch) · unclear: K-R4 (Advanced Excel) · absent: K-R2 (3+ years supply or demand planning in FMCG), K-R3 (Own the 13-week supply plan), K-R5 (SAP IBP or similar planning system)

K-R2, K-R3, K-R5 — planning work and tools absent; K-R6 — a credible bridge, its limit named; K-R7 — your Dutch level sits below the stated one.

**Opportunity ledger.** The role itself is clearly specified (KRR3). The employer is not established (KRR1) and the salary is withheld (KRR2).

- **Hard gates:** none failed; unconfirmed: K-R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** documented hands-on supply or demand planning work, a planning-system tool you have used, and Dutch at the stated level. Alternatively, the employer would have to accept an analyst background in place of planning experience. The decision rests on your fit gaps, not on anything wrong with the opportunity.

---

# Duinvaart Cold Chain — full assessment

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, a refrigerated-fleet operator in Rotterdam | `[grounded]` JD header; existence not checked, see DRR1 |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An individual-contributor analyst post. No team, budget or decision rights are stated | `[inferred]` from the JD's silence on reports and authority |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not calibrated. The role-family sweep could not run, so no pay or scope band is offered rather than one from memory | `[generic]` no research ran, see Evidence status |
| Unknowns | Salary; whether "route changes" means recommending or deciding; team size; fleet size | — |
| Contradictions | None found in what was provided | `[grounded]` JD and your background |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D-R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | The JD fixes the term. You have not stated where you live or any commute limit, and your current employer is in Amsterdam | `[grounded]` JD; no constraint given | Commute question below |
| D-R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You describe 4 years as an operations analyst at a parcel carrier. A length requirement is graded as fit, not as a gate. Medium because it is self-reported with no artifact | `[grounded]` your stated background | D-E1 |
| D-R3 | Strong SQL | must_have | direct | medium | none | You use SQL daily. "Strong" is self-assessed | `[grounded]` your stated background | A sanitized query sample would raise to high |
| D-R4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily | `[grounded]` your stated background | A sanitized dashboard screenshot would raise to high |
| D-R5a | Track on-time delivery | must_have | direct | medium | none | The on-time delivery dashboard your depot managers use is the same metric | `[grounded]` your stated background | D-E1 |
| D-R5b | Track temperature compliance | must_have | unclear | none | discovery | Nothing in your background mentions temperature-controlled freight. Whether your carrier carried any is unknown | `[grounded]` background silent | Temperature question below |
| D-R6 | Build weekly dashboards in Power BI | important | direct | medium | none | You use Power BI daily, including the on-time delivery dashboard. Whether you built it or maintain it, and its refresh cadence, are not stated, so proposed wording avoids claiming either | `[grounded]` your stated background | Confirm authorship before any "built" wording |
| D-R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | Depot managers use your dashboard and you ran the weekly route-performance review. A performance review is not route changes, and whether any change followed is unstated | `[grounded]` your stated background; `[inferred]` adjacency | Route-changes question below |
| D-R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is partial evidence for a preferred item. The limit is that it is not fluent | `[grounded]` your stated level | State it as "conversational", never higher |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| D-G1 | Temperature compliance (D-R5b, must_have) | discovery | Silence on temperature-controlled freight | It is half of the role's named tracking duty, and the one must-have row that is `unclear` | Temperature-sensitive parcels such as pharma or food; excursion or SLA-breach reporting; any sensor or telematics data you analysed | A sanitized report or dashboard view | `[grounded]` background silence; `[generic]` that cold-chain roles probe this first |
| D-G2 | Route changes with depot managers (D-R7, important) | discovery | A review and a dashboard, with no stated change that followed | It decides whether this row is `direct` or stays `adjacent` | A route or schedule change that came out of your review; a depot manager acting on your analysis | A review pack or a change log | `[grounded]` background; `[inferred]` row movement |
| D-G3 | Commute (D-R1, hard_gate) | hard_gate | Location and limits not stated | A failed gate caps the decision, and an unknown one stays on the snapshot | Not applicable. This is a fact about your circumstances, not experience | None | `[grounded]` JD term; constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DRR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | It may be too small or new to have a footprint, the posting may be stale, or it may not be a live hiring employer. None of these is more likely than the others on the evidence here | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who I would interview with? | unresolved |
| DRR2 | Salary withheld | unknown | — | no figure in the posting | The pay may fall outside what you need, or it may simply not be published | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| DRR3 | Concrete duties named | positive_signal | — | "Track on-time delivery and temperature compliance… build weekly dashboards in Power BI" | The scope is well defined and checkable | `[grounded]` JD | Who owns the temperature-compliance data today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| D-E1 | Resume line: "Four years as an operations analyst at a parcel carrier in Amsterdam; SQL and Power BI daily, including the on-time delivery dashboard depot managers use." | D-R2, D-R3, D-R4 and D-R5a. It reuses your own sentence | `[grounded]` your stated background | `resume_edits_pending_approval` |
| D-E2 | Resume line: "Ran the weekly route-performance review." | D-R7. It states what you said and no more | `[grounded]` your stated background | `resume_edits_pending_approval` |
| D-E3 | Describe your Dutch as "conversational". Make no temperature-compliance or route-change claim until you answer D-G1 and D-G2 | D-R8, D-R5b and D-R7. This keeps the application inside what you have said | `[grounded]` your stated level and background | pending your approval |
| D-A1 | Before investing in an application, confirm the posting on the company's own careers page or through the recruiter's email domain | DRR1 | `[grounded]` DRR1 | pending your approval |

---

# Kroonhaven Foods — full assessment

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, a chilled ready-meals producer in Utrecht | `[grounded]` JD header; existence not checked, see KRR1 |
| Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A planning-owner role. The plan is yours to hold, and the S&OP meeting makes you the convener | `[inferred]` from "own" and "run" in the JD |
| Market calibration | Not calibrated. The sweep could not run, so no band is offered | `[generic]` no research ran, see Evidence status |
| Unknowns | Salary; team size; who attends S&OP; whether training is offered | — |
| Contradictions | None found in what was provided | `[grounded]` JD and your background |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K-R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | The JD fixes the term. Your location and commute limits are not stated | `[grounded]` JD; no constraint given | Commute question below |
| K-R2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You say you have never worked in planning, and a parcel carrier is not FMCG. Work near a length requirement is evidence, but none exists here | `[grounded]` your statement | Closure path in K-G1 |
| K-R3 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your statement | Closure path in K-G1 |
| K-R4 | Advanced Excel | must_have | unclear | none | discovery | Your background states SQL and Power BI and does not mention Excel | `[grounded]` background silent | None; you did not answer for this row, and the decision does not turn on it |
| K-R5 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are query and reporting tools, not planning systems | `[grounded]` your stated tools; `[generic]` that planning systems are a distinct tool class | Closure path in K-G1 |
| K-R6 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran the weekly route-performance review. A delivery-performance review is a different kind of meeting from one balancing demand, supply and capacity | `[grounded]` your stated background; `[inferred]` adjacency | Frame as "ran a weekly review", never as S&OP |
| K-R7 | Fluent Dutch | must_have | adjacent | medium | transferability | Your Dutch is conversational. The posting asks for fluent | `[grounded]` your stated level | None; this is a level gap |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| K-G1 | Planning work, tools and FMCG context (K-R2, K-R3, K-R5, all must_have) | capability | No planning role, plan ownership or planning-system use | Together these are the core of the post, and none of the three has a bridge | Nothing in your stated background counts | None to request | `[grounded]` your statement; `[generic]` that analyst-to-planner moves usually start at junior or analyst-grade planning posts |
| K-G2 | Commute (K-R1, hard_gate) | hard_gate | Location and limits not stated | An unconfirmed gate stays on the snapshot | Not applicable | None | `[grounded]` JD term |

Closure path for K-G1: aim at planner-analyst or junior-planner postings, and build planning-system and S&OP vocabulary first. That path is a pattern, not a claim about Kroonhaven.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KRR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | It may be too small or new to have a footprint, the posting may be stale, or it may not be a live hiring employer. None of these is more likely than the others on the evidence here | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who I would interview with? | unresolved |
| KRR2 | Salary withheld | unknown | — | no figure in the posting | The pay may fall outside what you need, or it may simply not be published | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| KRR3 | Clear scope | positive_signal | — | "Own the 13-week supply plan… run the weekly S&OP meeting" | Success is measurable | `[grounded]` JD | Who owns the forecast the plan balances against? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| K-A1 | Do not spend application effort on this post as written | `no_go`, driven by K-R2, K-R3 and K-R5 | `[grounded]` the map | pending your approval |
| K-A2 | If you apply anyway, use only: "Ran the weekly route-performance review." Do not call it S&OP or planning | K-R6 | `[grounded]` your stated background | `resume_edits_pending_approval` |
| K-A3 | If you proceed, ask KRR1 and KRR2 verbatim before the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

---

## Evidence status

Verified: none yet. Your background is self-reported, so every `direct` and `adjacent` row stays at `medium`.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused, so both employers are not established. DRR1 and KRR1 stand as standing entries, and no company fact beyond the JD text is used |
| 2. Role-family sweep | unavailable | Searches for operations-analyst and supply-planner pay and scope were refused. Both market-calibration rows read "not calibrated" |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can write this up as `tuesday-dossier.md` for both roles whenever you want it.

## Upgrade menu

- Web search allowed → targets 1 and 2 run for both roles. That could clear DRR1 and KRR1 and add a pay band against RR2 and KRR2. A deeper pass could follow (up to 5 more searches and 2 more fetches).
- A sanitized query sample or dashboard screenshot → D-R3 and D-R4 move toward `high`.
- Your answer on temperature work → D-R5b resolves, or stays `unclear`, and the Duinvaart decision firms up.
- A hiring manager's name for either role → the scope read and the positioning advice can be tuned.

## Questions

1. **D-R1 and K-R1** — Where do you live, and could you commute to Rotterdam three days a week, or to Utrecht on-site every working day?
2. **D-R5b** — Did your carrier handle any temperature-sensitive parcels, and did you track or report on them in any way?
3. **D-R7** — Did your weekly route-performance review ever lead to a route or schedule change, and what was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.