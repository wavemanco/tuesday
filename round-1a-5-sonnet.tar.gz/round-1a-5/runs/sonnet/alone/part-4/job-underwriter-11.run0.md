Quick status: I've loaded the underwriting method and am now checking whether both employers and postings can be found publicly, before I write up the two roles.
# Decision snapshots

**Your question, answered in your words: FIRST (Duinvaart Cold Chain), yes, it's worth your time on conditions: `conditional_go`. SECOND (Kroonhaven Foods), no, I wouldn't spend application effort on it: `no_go`. RB2, RB3 and RB6, three must-haves, have no planning evidence behind them.**

## FIRST: Operations Analyst, Duinvaart Cold Chain, Rotterdam

**Fit ledger.**

- `hard_gate` — unclear: RA1 (Hybrid, three days a week in Rotterdam office)
- `must_have` — direct: RA2, RA3, RA4, RA5; unclear: RA6 (Temperature compliance across refrigerated fleet)
- `important` — adjacent: RA7 (Work with depot managers on route changes)
- `preferred` — adjacent: RA8 (Dutch a plus)

RA6 — cold-chain compliance isn't evidenced yet; RA7 — ownership of route changes is unconfirmed.

**Opportunity ledger.** The role is clearly scoped (RRA4). The employer could not be checked from here (RRA2), the pay is not stated (RRA3), and what temperature compliance involves day to day is unknown (RRA1).

- **Hard gates:** none failed; unconfirmed: RA1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RRA2); (2) you confirm you can do three office days in Rotterdam (RA1); (3) the cold-chain gap is stated plainly as adjacent and never claimed as refrigerated-fleet experience (RA6).

## SECOND: Supply Planner, Kroonhaven Foods, Utrecht

**Fit ledger.**

- `hard_gate` — unclear: RB1 (On-site in Utrecht)
- `must_have` — adjacent: RB4 (Run the weekly S&OP meeting), RB7 (Fluent Dutch); unclear: RB5 (Advanced Excel); absent: RB2 (3+ years supply or demand planning in FMCG), RB3 (Own the 13-week supply plan), RB6 (SAP IBP or similar planning system)

RB2, RB3, RB6 — no planning evidence; RB7 — conversational Dutch against a fluent bar.

**Opportunity ledger.** The role is clearly scoped (RRB3). The employer is unverified (RRB1) and the pay is not stated (RRB2).

- **Hard gates:** none failed; unconfirmed: RB1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would have to differ for this to move off `no_go`:** documented planning work or a planning-system exposure (RB2, RB3, RB6), and Dutch at working fluency (RB7). Nothing in your background as given supplies any of these. The call is yours, but this is the weaker use of your applications.

---

# FIRST — detail

## Role reality (FIRST)

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, a refrigerated-fleet operator by the posting's description; not independently established | `[grounded]` posting header; existence unchecked |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A mid-level analyst post: reporting plus depot-manager collaboration, no team or budget ownership stated | `[inferred]` from the posting listing no reports, budget or decision rights |
| Market calibration | Not given. The salary sweep did not run and I won't quote a band from memory | `[generic]` no band available |
| Unknowns | Pay; what temperature compliance data looks like; how often route changes happen; whether "Dutch a plus" means Dutch-language meetings | `[grounded]` posting silence |
| Contradictions | None within the posting text; the careers page could not be compared | `[grounded]` posting only |

## Evidence map (FIRST)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RA1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | Your location, commute and willingness are not stated, and your current job is in Amsterdam. Nothing settles the term, so it stays unconfirmed | `[grounded]` posting term; your constraints not given | Question 1 in the closing block |
| RA2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. A years requirement is a screening term, not a gate, and your stated tenure exceeds it. Self-reported, no artifact inspected | `[grounded]` your background, self-reported | none |
| RA3 | Track on-time delivery | must_have | direct | medium | none | You built the on-time delivery dashboard your depot managers use. The artifact has not been inspected | `[grounded]` your background, self-reported | A sanitized screenshot would raise this to `high` |
| RA4 | Strong SQL | must_have | direct | medium | none | SQL daily for four years. Nothing inspectable yet | `[grounded]` your background, self-reported | A sanitized query sample would raise this to `high` |
| RA5 | Power BI or Tableau, weekly dashboards | must_have | direct | medium | none | Power BI daily, and the dashboard is used by depot managers. The weekly cadence is not stated | `[grounded]` your background, self-reported | Confirm the refresh cadence when you edit the CV |
| RA6 | Temperature compliance across the refrigerated fleet | must_have | unclear | low | discovery | Your background states no temperature-controlled or compliance work. Parcel delivery tracking is indirect context only. A refrigerated fleet likely brings sensor and log data you haven't touched, and the posting does not say. Nothing is claimed here beyond the lead | `[inferred]` from parcel on-time work against the posting's compliance language; `[generic]` that cold-chain roles usually involve sensor or logger data | Question 2 in the closing block |
| RA7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether the reviews led to route changes you proposed or drove is not stated | `[grounded]` your background, self-reported | Question 3 in the closing block |
| RA8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, by your own account. Useful for depot staff, but it is not fluency and shouldn't be described as such | `[grounded]` your statement | State it as "conversational" on the CV |

## Gap recovery queue (FIRST)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (RA6, must_have) | discovery | No temperature or compliance work stated | It is the one domain-specific must-have; a bridge here narrows the likeliest objection | Temperature-sensitive or time-critical parcels; SLA or compliance breach tracking; exception reporting to depot managers; any audit or regulatory reporting you fed | A sanitized exception report, an SLA dashboard view, a compliance-metric definition | `[grounded]` background silence; `[generic]` that domain fit is the usual objection for cross-sector moves |
| GA2 | Route changes (RA7, important) | discovery | Reviews run, outcomes not stated | Moves RA7 from `adjacent` toward `direct` | Route or depot-schedule changes that followed a review; a recommendation a depot manager acted on | A review pack or a change log | `[grounded]` background; `[inferred]` that outcomes are what the posting is probing |

## Opportunity risk register (FIRST)

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRA1 | Compliance scope unspecified | unknown | — | "temperature compliance across our refrigerated fleet" | Compliance work may mean monitoring regulatory standards or customer SLAs, which is different analysis from delivery tracking | `[inferred]` from the posting's brevity on compliance | What does temperature compliance tracking involve here, and which data sources feed it? | unresolved |
| RRA2 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; none of these is more likely than the others. Capped at medium on the standing rule | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RRA3 | Pay not stated | unknown | — | (no figure in the pasted text) | Pay may sit anywhere relative to your target; I have no market band to compare against | `[inferred]` from the posting silence; `[generic]` that withheld pay is worth one question | What salary range is budgeted for this post? | unresolved |
| RRA4 | Concrete deliverables and counterparts | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The scope is defined enough to judge in an interview | `[grounded]` posting | Who are the dashboard's main users today? | noted |

## Application plan (FIRST)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| AA1 | Confirm the posting is live on the company's own careers page before investing time | RRA2 | `[grounded]` RRA2 | pending your approval |
| EA1 | Put the on-time delivery dashboard first: name its users (depot managers), the cadence you ran (weekly route-performance review) and the tools, SQL and Power BI | RA3, RA4, RA5, RA7 | `[grounded]` your background | pending your approval |
| EA2 | State Dutch as "conversational" and make no cold-chain claim; if question 2 turns up compliance-type work, add it as adjacent | RA6, RA8 | `[grounded]` your statement | pending your approval |
| WA1 | A sanitized screenshot of the dashboard, scrubbed of company and customer data | RA3 | `[grounded]` RA3 | pending your approval |
| QA1 | Ask RRA1, RRA3 and the RRA2 question in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row in both application plans, and the advice in them, is a proposal. Nothing becomes CV or outreach wording until you approve it.

---

# SECOND — detail

## Role reality (SECOND)

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, a chilled ready-meals maker by the posting's description; not independently established | `[grounded]` posting header; existence unchecked |
| Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A full planning-ownership role: the plan and the meeting both sit with the post-holder | `[inferred]` from "own" and "run" in the mandate |
| Market calibration | Not given; the sweep did not run | `[generic]` no band available |
| Unknowns | Pay; team around the planner; planning system in use | `[grounded]` posting silence |
| Contradictions | None found within the posting text | `[grounded]` posting only |

## Evidence map (SECOND)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RB1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location and willingness are not stated, so the term stays unconfirmed | `[grounded]` posting term; your constraints not given | Question 1 in the closing block |
| RB2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You told me you have never worked in planning. A years requirement is a screening term, not a gate, but your stated history leaves nothing to count toward it. Likely screened literally | `[grounded]` your statement; `[generic]` that titled-years requirements are usually screened literally | none: closure would need real planning exposure |
| RB3 | Own the 13-week supply plan; balance capacity against forecast | must_have | absent | none | capability | The core duty of the post, with no planning evidence behind it | `[grounded]` your statement | none: closure path is a planning role first |
| RB4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. Carries over: running a recurring cross-team operating forum. Limit: yours looked back at performance; an S&OP meeting reconciles forward supply, demand and finance, which you haven't done. Strengthener: a review pack | `[grounded]` your background; `[generic]` what S&OP covers | A sanitized review agenda would narrow the limit |
| RB5 | Advanced Excel | must_have | unclear | low | discovery | Not stated. Daily SQL and Power BI use is indirect context; nothing shows Excel depth | `[inferred]` from adjacent tooling | A one-line answer closes it |
| RB6 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analytics tools, not planning systems, and you've worked in none | `[grounded]` your statement; `[generic]` that planning systems differ from BI tools | none |
| RB7 | Fluent Dutch | must_have | adjacent | medium | transferability | Your Dutch is conversational, by your own account, which is a step short of fluent. Wording can't close that; only the language level does | `[grounded]` your statement | none |

## Gap recovery queue (SECOND)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GB1 | Planning core (RB2, RB3, RB6, must_have) | capability | No planning work, no planning system | Three must-haves are absent, and they are the role's core duties | A forecast-versus-capacity exercise you owned, a capacity or volume plan you built, a planning tool you configured | A planning workbook or capacity model | `[grounded]` your statement; `[inferred]` the closure path is a planning-adjacent role first |
| GB2 | Dutch fluency (RB7, must_have) | transferability | Conversational | Fluency decides whether you can run a Dutch-language meeting | Meetings you've already held in Dutch | A language certificate level | `[grounded]` your statement |

## Opportunity risk register (SECOND)

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRB1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The employer may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; none is more likely than the others | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RRB2 | Pay not stated | unknown | — | (no figure in the pasted text) | Pay may sit anywhere relative to your target; no band to compare against | `[inferred]` from the posting silence | What salary range is budgeted for this post? | unresolved |
| RRB3 | Clear ownership and cadence | positive_signal | — | "Own the 13-week supply plan ... run the weekly S&OP meeting" | The responsibilities are specific and measurable | `[grounded]` posting | Which commercial and production teams attend the weekly S&OP meeting? | noted |

## Application plan (SECOND)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| AB1 | Hold applications to this post; use the time on FIRST-type roles | RB2, RB3, RB6 | `[grounded]` map | pending your approval |
| AB2 | If you apply regardless, ask RRB1 to RRB3 verbatim, and make no planning claim on the CV | The register travels with a `no_go` | `[grounded]` register | pending your approval |
| AB3 | Look for openings that sit next to planning, such as demand or supply analytics, where SQL and Power BI are the core tools | RB4 shows a bridge, and analysts often move toward planning that way | `[generic]` role-family pattern | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches, one per employer ("Duinvaart Cold Chain Rotterdam Operations Analyst" and "Kroonhaven Foods Utrecht Supply Planner chilled ready-meals"), were refused. This would have confirmed that each employer exists and that each posting is live. Without it, RRA2 and RRB1 stand as unresolved standing entries |
| 2. Role-family sweep | unavailable | One search ("operations analyst logistics salary Netherlands Rotterdam vs supply planner FMCG salary Netherlands") was refused. It would have supplied the market calibration rows and a pay check for RRA3 and RRB2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want, I can save this as `tuesday-dossier.md` so later turns pick up where this leaves off.

## Upgrade menu

- Permission to run searches → both employers get checked and RRA2 and RRB1 can resolve; a salary band replaces the empty market calibration rows.
- A sanitized screenshot of your on-time delivery dashboard → RA3 to `high`; a SQL sample → RA4 to `high`.
- Your answer on temperature-sensitive or compliance work → RA6 moves from `unclear` toward `adjacent`.
- A recent review agenda or pack → RA7 and RB4 firm up.
- The hiring manager's name for either post → role reality's scope read and which story to lead with.

## Questions

1. **RA1, RB1** — Where do you live now, and would you do three office days a week in Rotterdam for FIRST, or work on-site in Utrecht for SECOND? Is anything about commuting or relocating a dealbreaker? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **RA6** — At the parcel carrier, did you ever track temperature-sensitive or time-critical shipments, SLA or compliance breaches, or exception reporting that went to depot managers? What did you own, and what happened? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **RA7** — Did your weekly route-performance review lead to route or depot-schedule changes you recommended or made? Which ones, and what changed? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.