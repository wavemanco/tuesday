I'm checking whether Marrowgate Housing exists as described and what Irish payroll roles pay. Then I'll write up the assessment.
# Job Underwriting Assessment: Payroll Administrator, Marrowgate Housing (Limerick)

## Decision snapshot

**Worth accepting, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Two office days in Limerick), R2 (Salary €38,000–€42,000)
- `must_have` — direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — direct: R7, R8 · adjacent: R11 (Monthly payroll for 240 staff) · unclear: R10 (Answering staff payroll queries) · absent: R9 (Pension changes)

R9 — a stated gap on a task the role names; R4 — likely met, unconfirmed.

**Opportunity ledger.** Being asked for bank details, PPS number and a passport scan is the normal sequence once a written offer is accepted: payroll needs the first two, and the right-to-work check needs the passport. Your rule is still a good one for an ad, a recruiter's first message, or anything before an offer. Here the request came after two in-person interviews and a written offer, and the portal link only follows your acceptance (RR4). The open points are practical: the offer says nothing about pension scheme, probation, notice or leave (RR2), and this check could not confirm the employer independently (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Two office days in Limerick), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found in the ad or offer as provided.
- **Conditions for go:** (1) the employer is confirmed as an existing housing association — RR1; (2) pension scheme, probation, notice and leave are in writing before you accept — RR2; (3) your pension-changes gap is stated honestly — R9, G1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` ad; existence not independently confirmed (RR1) |
| Mandate | Run monthly payroll; starters, leavers, pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` ad |
| Terms offered | €40,000 permanent, hybrid with two office days, reporting to Declan Garvagh, Finance Manager. Start date agreed after your notice period | `[grounded]` offer email |
| Scope read | Looks like a single-person payroll seat for 240 staff, so cover for leave and year-end rests on one person | `[inferred]` from the ad naming one post for the whole run |
| Market calibration | Not established. The salary search did not run. The only anchor is the ad's own range, where €40,000 is the midpoint | `[grounded]` ad range and offer; no `[generic]` band given |
| Unknowns | Payroll software, number of pension schemes, who handles pension changes today, cover arrangements, contract terms beyond the email | — |
| Contradictions | None between ad and offer on title, hybrid pattern, office days or location; salary sits inside the advertised range | `[grounded]` ad compared with offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Limerick | hard_gate | unclear | none | hard_gate | Role terms are clear and you interviewed at the office; your own commute or location limits were not given | `[grounded]` ad and offer; constraint not stated | Q3 |
| R2 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | Offer is inside the advertised range; your minimum was not given | `[grounded]` ad and offer; constraint not stated | Q3 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated by you, no document seen | `[grounded]` your account | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say whether the hotel payroll and your certificate were Irish. Likely, but not stated | `[inferred]` from the Irish setting | Q1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your account | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; awarding body not stated | `[grounded]` your account | none |
| R7 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | You did exactly this monthly | `[grounded]` your account | none |
| R8 | Process starters and leavers | important | direct | medium | none | Part of your hotel-group role | `[grounded]` your account | none |
| R9 | Process pension changes | important | absent | high | capability | You said you never did them; your manager did | `[grounded]` your statement | G1 |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | Not mentioned. Running payroll usually involves it, but that is not evidence | `[inferred]` from the duties you described | none, minor |
| R11 | Run payroll for 240 staff on a monthly cycle | important | adjacent | medium | transferability | Same mechanics at 90 staff and fortnightly; the headcount is roughly 2.7 times larger. Your monthly work was the reconciliation | `[inferred]` adjacency from your account | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R9, important) | capability | Never done; watched or supported only if that is true | A named duty in the ad, and one they may ask about | Pension deductions you processed from a manager's instruction; pension contributions you reconciled in the ledger | A description of what you did touch (see Q2) | `[grounded]` your statement; `[inferred]` adjacent touchpoints |
| G2 | Scale of 240 staff (R11, important) | transferability | 90 staff, fortnightly | Larger headcount means more starters, leavers and exceptions per run | Peak-period runs, large starter batches at the hotel group | Headcount at your busiest run | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not independently confirmed in this check | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | Possible reasons, side by side: the search did not run; the body is small and has little web presence; the posting is old | `[inferred]` from the search being refused | Is Marrowgate on the public register of approved housing bodies, and does its own website list this vacancy? | unresolved |
| RR2 | Offer lacks written terms beyond title, salary, hybrid | unknown | — | "permanent post of Payroll Administrator at €40,000 a year" | Pension scheme, probation, notice period and leave may sit in a contract sent later | `[inferred]` from the email's silence | Can I see the contract or terms statement before I accept? | unresolved |
| RR3 | One post covers payroll for 240 staff | unknown | — | "Run the monthly payroll for our 240 staff" | Cover during your leave and year-end may be thin | `[inferred]` from the ad | Who covers payroll when you're away, and what payroll system is used? | unresolved |
| RR4 | Onboarding portal link not seen yet | unknown | — | "we will send you a link to our onboarding portal" | A portal on the employer's own domain or a named HR/payroll provider is normal | `[generic]` onboarding pattern | Which domain or provider hosts the portal? | unresolved |
| RR5 | Two in-person interviews, a written offer and an in-range salary | positive_signal | — | "two interviews in person at their office" | The hiring process looks genuine and ordinary | `[grounded]` your account and the offer | Who attended your interviews, and was Declan Garvagh one of them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | When the portal link arrives, check its domain is marrowgatehousing.ie or a provider the People Team names, or type the address yourself. Do not give passport or bank details by plain email | Passport scans belong in the portal, not an inbox | `[generic]` onboarding practice | pending your approval |
| A2 | Reply to ask for the written contract, pension scheme, probation, notice and leave before the five-day deadline. You can ask politely for a short extension if needed | See RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Tell Declan plainly that you have not run pension changes yourself and ask what training or handover covers them. Do not describe your manager's work as yours | The gap is real and the offer likely already priced it in. Honesty here protects you in the first month | `[grounded]` R9 | pending your approval |
| A4 | Ask what payroll system is used and who covers when you're away | See RR3 and R11 | `[grounded]` RR3 | pending your approval |
| A5 | Salary: €40,000 is the range's midpoint; you could ask whether the upper end is available given your certificate. Optional | You meet the stated experience and qualification requirements | `[inferred]` from R3, R6 against the ad range | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have checked that Marrowgate exists as described and that this vacancy is live; feeds RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Would have set €40,000 against Irish payroll pay for the title; feeds market calibration and A5 |
| 3. Hiring manager's public footprint | unavailable | Would have read Declan Garvagh's public professional background for the scope read |

I can save this as `tuesday-dossier.md` if you want a copy to keep.

## Upgrade menu

- Granting search permission lets me rerun targets 1 to 3, which would close or sharpen RR1 and the market line.
- Your contract or terms statement closes RR2.
- The portal link's domain, once it arrives, closes RR4. Paste the address only, not any login details.
- A short description of any pension-related work you touched would strengthen G1.
- Your minimum salary and commute limits would settle R1 and R2.

## Questions

1. **R4 / G2-adjacent:** Was your hotel-group payroll run on Irish PAYE, PRSI and USC, and is your Payroll Technician certificate an Irish one?
2. **G1 / R9:** What, if anything, did you personally touch on pension changes, such as deductions, contribution checks or ledger entries? Did the interviewers know you hadn't run them?
3. **R1 / R2:** Do you have any non-negotiables, such as a minimum salary or a limit on commuting to Limerick?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.