The three Atlas searches were refused, so I'm building the pack from your JD and background alone and labeling anything Atlas-specific as generic. I'm writing it now.
Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`, with 22 questions across seven interviewer styles. You don't know who is interviewing you, so I built it as a full-loop pack with equal weight on every style. That is weaker than a pack built for a known round. The pack is built only from your JD and your background, because my three Atlas web searches were refused. The Atlas-specific questions (A3, and the values and strategy ones) are generic, and the pack says so. Spend some of your own prep time on Atlas's site and news.

The one to rehearse hardest is B1, the jump from 3 supervisors to 12. It will come up in some form, so practice saying the number first, conceding the size of the step, and holding there.

Say the word and I'll play the Skeptic on B1, so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the first conversation with a hiring manager, a peer, a recruiter or a panel? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (the JD describes it as regional logistics, 800 employees)
**Interviewer and relationship:** not known
**Round type:** not known. This is a full-loop pack with flat persona weights, which is noticeably weaker than a pack built for a known round (see the upgrade menu).

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Guidance is scaffolding, not a script. Say things in your own words.
- Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. If a cell cannot be quoted, it is a selection scaffold or an answer slot instead.
- An answer slot is an instruction for the interview, not a question for me. It gives two honest branches: say how it went if it was yours, or say plainly that it was not and return to what your own sentence states.
- The highest-ROI prep in this pack is B1. It will be asked in some form, and a calm, rehearsed answer changes the interview.

| Tag | Name | What is being scored |
|---|---|---|
| VAL | Behavioral and values | Whether past behavior shows the behaviors the role needs, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and you can say exactly what was yours |
| JD | Role and JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Live problem | Structure and reasoning on a problem from the actual role |

## Prep triage

You have until next week. Do these in order; each is tied to a section below.

1. Say B1 aloud three times, ending each time on the three supervisors you lead today (F3).
2. Rehearse B2 and F3 together: one calm sentence on Power BI, then Excel at its own scope (F4, F5).
3. Work out on paper how the 40% in C1 was counted. If you do not know, practice saying so plainly (F2).
4. Write your own timeline of when you started leading people, for B4 (F6).
5. Spend your own time on Atlas's public website and recent news for A3, because this pack could not research it. Write down only what you actually find.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your sentences say warehouse and distribution and the site's surge plan, where the JD says terminals and four sites, and nothing is inspected behind them. Words stay at the quotes: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on multi-site scope likely. If you had responsibility beyond that plan, say what and for how many people, in your own words; if you did not, say so plainly and stay with the plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your quote is a mis-pick result, and it does not mention on-time performance or cost per shipment. Words stay at the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked either measure, say which and how it was counted, in your own words; if you did not, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your quote says three supervisors and the JD says twelve; that distance is the pack's observation, not words for you. Words stay at the quote: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led or coordinated supervisors beyond those three, say how many and what your part was, in your own words; if you have not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel part) | "solid Excel" — your message | low | [inferred] | discovery | Derived from the gap between a skill and a deliverable: being solid in Excel does not show that you built reporting in it, and the quote does not say. Words stay at the quote: "I'm solid in Excel." Answer slot: if you built reports that others used, say what they showed and who used them, in your own words; if you did not, say so plainly and say how you use Excel |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI part) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then a plan in the future tense and never a past: what you would learn first. If you do spend time in Power BI before the interview, tell me and this row changes; until then nothing here says you have |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years in the work is not the same as five years leading, and your material does not show how many of the seven involved leading people. This is a length-of-experience requirement, so it is graded here and not treated as a hard gate. Answer slot: the JD marks it required, so a probe on your leadership timeline is likely. Say when you started leading people and in what role, in your own words; if the leading years total fewer than five, say so plainly and stay with what your two sentences state |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the JD's plus in its own terms, with nothing inspected behind it (the certificate would be the inspectable artifact), so expect a probe on where you applied it. Words: "I'm green belt certified." Your material states the certification and the pick-path redesign as separate sentences and does not connect them; the words here do not either. Answer slot: if you applied the certification at work, say where, in your own words; if you did not, say so plainly and say what the certification covered |

## Persona table

No loop source was available, so the loop is not established. The fallback archetype is Generic (screen, then hiring manager, then panel): flat weights, and no values-style round is assumed. `[generic]` The weights below are therefore equal, and the pack still touches every plausible persona so you do not meet a style for the first time live.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case and Strategist | Live problems from the role: diagnose, plan, prioritize | Equal. Round type unknown, and an operations role often includes a live problem | Clarify, then objective, segmentation, approach, metrics, risks; think aloud | A |
| Skeptic | Quiet, persistent probing of the gaps | Equal weight, with one extra question (B4) only because the JD's 5+ years requirement needs a home. The fit snapshot's biggest gaps (F3, F5, F6) live here | Rehearse the most predictable objection until it is boring; bridge only from your own sentences; say the limit plainly | B |
| Data-Driven Prober | Reads line by line, asks how numbers were counted | Equal. The pack holds one quantified claim (F2) and probers go straight to those | Know what you can and cannot say about how the figure was counted; name the assumption you would defend least before they do | C |
| Pressure | Interrupts, time-boxes, tests composure | Equal. Plausible in any round that includes a senior interviewer | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real | D |
| Values and Behavioral | Scenario probes, STAR-shaped stories | Equal. No values round is known; the questions are themed from the JD and the persona's standard stems | Choose stories where the hard truth actually landed; "we" for context, "I" for contribution | E |
| Conversational | Friendly, unstructured, still scored | Equal. Common in first conversations | Prepare a short arc for the biography question; treat casual questions about JD topics as scored | F |
| Peer Evaluator | Seam-splitting, credit and collaboration probes | Equal. The role sits beside other site and function leaders | Reciprocity framing; propose seam principles instead of pretending to know the seam | G |

## Question banks

### A. Case and Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your terminals has dropped from the week before. Diagnose it. What do you need to know first?" | CASE | [generic] | Structure aloud: clarify what on time is measured against and since when; segment (by site, shift, lane, customer, inbound versus outbound); state a hypothesis early; say what you would check and in what order; name a risk. The question needs no claim about your past, so the guidance makes none | The JD's on-time performance line (F2's requirement) asked as a live problem; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "A surge hits all four sites in the same week. How do you decide where people and attention go first?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: name what is scarce, which site is closest to failing, what you move first and what you leave alone. If you draw on your own peak work, say it only at its own scope: "I ran the site's peak-season surge plan two years running." Add nothing the sentence does not say | F1's requirement is the four-site line, and this is how it is likely to be tested live; CASE because it scores structure under multi-site pressure |
| A3 | "What do you know about Atlas Freight, and where do you think its terminals face the most pressure?" | CO | [generic] | This pack could not research Atlas, so it supplies no facts. The JD gives you "regional logistics, 800 employees" and four sites, and that is all. Do your own pass on Atlas's public site and news, say what you found and label what you are inferring, and give no figures you cannot source | Company homework is asked in most loops; `[generic]` because the research searches were refused, which is the honest cost of the missing research |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role leads twelve supervisors. You currently have three. How do you handle that step up?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Highest-ROI prep in this pack. Say the number before they do: "I'm currently a senior shift manager over 3 supervisors." Concede the size of the step specifically (twelve is four times three) and do not argue it away. Hold through two follow-ups by returning to the three you lead, never by adding to them. Rehearse these follow-up levels aloud, in your own words: what breaks first at twelve; which part of leading twelve you would be least ready for; what you would want to have learned by day 90. The pack supplies none of those answers. Answer slot: if you have led or coordinated supervisors beyond those three, say how many and what your part was; if you have not, say so plainly and stay with the three. Then give a ramp plan in the future tense: what you would learn first, who you would meet, what you would leave unchanged at the start | F3 is the biggest scale gap and the question the interview most likely turns on; JD because it scores the stated requirement, Skeptic because it probes the distance |
| B2 | "The role builds reporting in Excel and Power BI. Where are you on Power BI?" | JD | [grounded] "solid Excel, never used Power BI" | Open with the plain acknowledgment: "I've never used Power BI." Then Excel at its own scope: "I'm solid in Excel." Do not soften it into "familiar with" or "some exposure". Answer slot: if you built reports that others used in Excel, say what they showed and who used them, in your own words; if you did not, say so plainly. Then say what you would learn first, as a plan | F4 and F5 together; a stated gap is best handled by stating it first, and the mid-list requirement is where a free miss hides |
| B3 | "Your background is warehouse and distribution, and this role runs terminals. Which part would you be weakest at on day one?" | JD | [grounded] "7 years in warehouse and distribution ops" | Choose the weakest part from your own honest read; the pack does not know it. Answer slot: if any of your seven years were spent in terminal work, say which and what you did, in your own words; if not, say so plainly and stay with "7 years in warehouse and distribution ops". Then name one thing you would learn first and from whom, as a plan | F1 is where the terminal wording differs from your sentence; the question is a standard Skeptic stem applied to the JD |
| B4 | "The role requires five-plus years of operations leadership. How many of your seven years were spent leading others?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer from your own timeline: when you started leading people, in what role, and since when you have led supervisors. Answer slot: if the leading years total fewer than five, say so plainly and stay with what your two sentences state, seven years in the work and currently over 3 supervisors; if they total five or more, say how, in your own words | F6 is a required line that may be screened literally, so a probe on it is likely; JD because it scores the stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 40% reduction in mis-picks." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold what the sentence states: "I cut mis-pick rate 40% by redesigning the pick path." Answer in your own words on the four things a figure raises: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no baseline, method or denominator | F2's headline figure is the one quantified claim, and probers go straight to those; name the weakest assumption before they do and it becomes credibility |
| C2 | "That result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you did in your own words and no more: "we" for context, "I" for contribution. If part of it was shared or someone else's, say which part and stay with the part that was yours | F2; attribution probes exist because interviewers ask them, and the rehearsal is precise honesty |
| C3 | "The role is measured on on-time performance and cost-per-shipment. Which of those figures have you tracked?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Before using either term, be ready to say how you would define it, and ask how Atlas defines it. Answer slot: if you tracked either figure, say which and how it was counted, in your own words; if you did not, say so plainly and return to "I cut mis-pick rate 40% by redesigning the pick path" | F2's requirement is the two outcome measures, and the quote is adjacent to them; JD because it scores the stated requirement |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should I put you over twelve supervisors across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Anchor in what you stated: "I'm currently a senior shift manager over 3 supervisors, with 7 years in warehouse and distribution ops, and I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to those sentences, not by adding to them. Concede one thing specifically, the size of the step, rather than folding on the core claim. Do not tell them what your record proves; describe it and let them draw the inference | F3 under time pressure; JD because it scores the stated requirement, delivered by a Pressure persona |
| D2 | "You are thirty days in. On-time performance is down at the worst of your four sites, and its supervisor is well liked and not delivering. You have two minutes. What do you do?" | CASE | [generic] | Pause, then ask the one or two things you need to know before deciding. Make a decision and say what you would check first. Hold your position through a push-back and concede only a specific, real point. The question sets a scenario and asks nothing about your past, so the guidance makes no claim about it | A live people-and-performance problem from the JD's two lines on leading supervisors and on-time performance; `[generic]` because it is a pattern, not a fact about Atlas |
| D3 | "Why leave a senior shift manager role for this one?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Give your actual reason, in your own words, stated forward. The pack does not know your reason and supplies none. Choose one you can still stand behind after the next "and what else?" | F3 supplies the current role; EXP because it tests motive consistency, a standard Pressure and Skeptic probe |

### E. Values and Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, what you actually said, what changed and a relationship that stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values-style stem; no values round is established, so this rehearses delivery rather than a published value |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision, not a slogan: the metric, the customer, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard stem; freight is customer-facing, so the question is likely in some form |
| E3 | "Tell me about a time you led supervisors through a change." | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "currently a senior shift manager over 3 supervisors" | Choose the instance yourself. If the pick-path redesign is the one you choose, tell it with only what your sentence states. Answer slot: if you led supervisors through that change, say how, in your own words; if you did not, or they were not involved, say so plainly and return to the redesign as your sentence states it. If another instance fits better, use the selection test: a named stake, what you did, what changed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3's requirement is leading supervisors; VAL because the answer is a behavior story, JD in content |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc in three beats: where you have spent your time ("I've spent 7 years in warehouse and distribution ops"), where you are now ("I'm currently a senior shift manager over 3 supervisors"), and why this role, in your own words. The pack does not know the steps between, so supply them yourself in your own words | F1 and F3; a casual biography question is scored on economy and genuine interest |
| F2 | "Lean and Six Sigma: are you actually playing with that these days?" | JD | [grounded] "green belt certified" | Start with the sentence: "I'm green belt certified." Answer slot: if you applied the certification at work, say where, in your own words; if you have not, say so plainly and say what the certification covered. Casual questions about JD plus-skills are still scored | F7's requirement is the JD's plus, and a casual register is where it will be asked |
| F3 | "How comfortable are you with Excel for reporting?" | JD | [grounded] "solid Excel, never used Power BI" | Say it at its own scope: "I'm solid in Excel." Answer slot: if you built reports that others relied on, say what they showed and who used them, in your own words; if you did not, say so plainly and describe how you use Excel. Do not drift into Power BI claims | F4's requirement asked in a casual register |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "If you were running all four sites and I ran one, where is the seam between us, and what happens when we disagree?" | CASE | [generic] | Propose seam principles, not a pretend map of the seam: who decides what, what each of you needs from the other, how you escalate. Frame what you would offer the other site, not only what you would need. The question sets a scenario and asks nothing about your past, so the guidance makes none | The JD's four-site line (F1's requirement) means site peers exist; `[generic]` because the actual structure is unknown |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a real instance where work crossed teams, say what each side did, and say what you did, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard peer stem; a collaboration probe |
| G3 | "What would you need from me in your first month?" | JD | [generic] | Ask for definitions and data before asking for resources: how on-time and cost-per-shipment are defined, and where each site stands. Offer something in return, such as how you would keep the peer informed. The question needs no claim about your past, so the guidance makes none | A reciprocity question; the JD's two outcome measures (F2's requirement) are the natural first asks |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B3, G1 |
| "drive on-time performance and cost-per-shipment down" | A1, C3, G3 |
| "lead a team of 12 supervisors" | B1, D1, E3 |
| "build reporting in Excel/Power BI" | B2, F3 |
| "5+ years operations leadership required" | B4 |
| "Lean/Six Sigma a plus" | F2 |
| Headline CV figure: mis-pick rate | C1, C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does Atlas define on-time performance and cost-per-shipment, and where are the four sites against them today?" | It shows you start from agreed definitions, and it gets you the baseline the JD's two measures hang on |
| R2 | "What does the supervisor team look like across the four sites: where is it strongest and where is it thin?" | It treats the twelve supervisors as the job, and the answer tells you where your first 30 days go |
| R3 | "What reporting do you use today, and what would you want rebuilt first?" | It opens an honest Excel and Power BI conversation on your terms |
| R4 | "What would a good first 90 days look like for this role?" | It converts the interview into a shared target and gives you a standard to be measured against |
| R5 | "What is hardest about running daily operations across four sites that the job description does not say?" | Rapport-style interviewers weight this slot heavily, and the answer is information no posting gives |
| R6 | "How does peak season work at Atlas, and who owns the surge plan today?" | It lets your own surge-plan sentence (F1) become relevant without you claiming more than it says |

## Prohibited claims

Built locally from the fit snapshot before the banks were written. None of these is coached, softened or implied in any cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed twelve supervisors, or any team beyond the three quoted | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says three, the JD says twelve. B1 and D1 hold at the three |
| Owned or ran operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material names the site's surge plan and warehouse and distribution work, not four sites. A2's guidance stays inside the sentence |
| Reduced late deliveries or shipment cost | Inflated form of F2 | F2's quote at its own scope: a mis-pick result. C3's slot asks only what was tracked |
| Power BI experience or familiarity | Negative the candidate stated, F5 | The plain acknowledgment: "I've never used Power BI." No slot |
| Five or more years leading operations | Inflated form of F6 | F6's quotes at their own scope. The limit is the pack's observation: seven years in the work is shown, the leading years are not. B4's slot stays inside your own timeline |

## Sources

Provided documents: the job description text and the background you pasted into your message. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused (nothing returned):

- "Atlas Freight regional logistics values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have supplied official value names for the VAL bank and, if a values round were documented, a values cheat sheet; none is built, and the VAL questions are generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have established the loop and moved the persona weights; the weights stay flat on the Generic archetype |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have moved the CO bank; A3 stays generic and R1 to R6 ask instead of assume |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (hiring manager, peer, recruiter, panel) → reweights every persona and bank, and can drop or deepen whole sections
- The interviewer's name and role → an interviewer read, mirror opportunities and a reverse question tied to their own path
- The recruiter's prep email, if any → coverage of any announced case, presentation or take-home, and the loop structure
- Web search working in this session, or Atlas's careers, values or strategy pages pasted → Atlas-specific CO and CASE questions replace the generic ones; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) adds a grounding brief
- Your CV or resume bullets → more evidence cells become exact quotes and some `[inferred]` rows become `[grounded]`
- Answers to the answer slots in F1, F2, F3, F4, F6 and F7, stated in your own words → those rows move from slots to story-mapped answers
- Inspectable proof, such as the belt certificate, a before-and-after tally for the pick-path redesign, or an Excel report you built → the medium rows (F1, F2, F3, F6, F7) can rise to high
- A `tuesday-dossier.md` from an earlier fit check → verified evidence, absolute prohibited claims and the evidence-derived top objection would arrive pre-graded; none was present, and this pack is complete without it
