Web searches were declined, so I'm building the pack from your JD and background only. I'll label everything else as generic and write the pack file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-7-denied-048d3264/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, assuming Tobias is who you'd report to.

My four web searches were all declined. That covered Saltmarsh's values and process, recent strategy, and Tobias's public background. So nothing in the pack comes from the web, and anything company-specific is marked generic or left out.

The pack is built from your JD and the background you typed. Your retention and "never worked on a game with in-app purchases" lines are the thinnest parts of your evidence, and B1 is the question to rehearse hardest.

Say the word and I'll play Tobias as the Skeptic on B1, the in-app-purchases question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter say anything about the format, such as a task, a presentation or the topics to expect? Either answer would reweight the banks.
Can you paste your CV text, or tell me to skip it? Your actual wording would replace the summary you typed in the evidence cells.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Built as a hiring-manager round, 60 minutes, on Friday. The relationship is an assumption: you gave the title, not the relationship, and the persona weights below follow it.

Candidate: Femi.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values (none asked for here: no values-style round is detected) |
| EXP | Whether the claims in your background survive scrutiny, and what was actually yours |
| JD | A stated responsibility or requirement in the job description |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem from the role, scored on structure |

An answer slot is an instruction for the interview, not a question for you now. A label in square brackets says where a row came from: grounded means your own words or a supplied document, inferred means derived from them with the derivation named, generic means a role-family pattern with no claim about you or Saltmarsh.

## Prep triage

You have until Friday. In this order, then stop:

1. B1: say it aloud three times, out loud, until the concession is boring. It is the highest-ROI prep in this pack.
2. A1, A2 and A3: practise the structure (clarify, objective, segments, approach, metrics, risks) aloud on each. The method matters more than the answer.
3. D1: time your 90-second arc.
4. C1 and B2: write down, privately, what you do and do not know about how the retention numbers were counted and what part of the reporting was yours.
5. Pick three reverse questions from the list and rehearse the wording.

Everything else is insurance.

## Fit snapshot

Your evidence cells are the sentences from your message; no CV text was supplied. Requirements are quoted from the JD you pasted. F9 and F10 are not JD requirements; they are rows for limits you named, because an interviewer will probe them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, with nothing inspected behind it; the JD says live events and two titles. The words stay at the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-title wording makes a probe likely. If any drops were events with a set start and end, or you ever ran a calendar for a second title, say which and how, in your own words; if not, or it was not yours, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote touches the calendar, not who you worked with, so the pack does not say you coordinated any group. Answer slot: if you coordinated any of those four groups on a drop, say which and what you needed from them, in your own words; if you did not, or someone else did, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or chose the KPIs. The words stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose what went into those numbers or wrote any review around them, say how; if that was not yours, or there was no such review, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the quote's own terms: you wrote it and QA still uses it. Lead with it as the quote says it, because a named artifact beats an adjective. Expect a probe on whether you ran it on each release. Answer slot: if you ran or updated it on releases, say how; if not, or that was someone else's, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Not a gate: a length-of-experience requirement is graded like any other. Your material gives four years as an associate producer and does not say how the title was run after launch. Answer slot: if asked, say in your own words how your main title was run after launch; if it was not run as a live-service game, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: the quote reaches the requirement in its own terms. Lead with it as written: weekly, main title, two years. Nothing is inspected behind it, so a sample week of the calendar would raise it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in role terms, but nothing is inspected behind it. Expect a probe on how the numbers were counted (C1). The words stay at the quote |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written artifact exists; nothing shows how clear it is or who read it. Answer slot: if you wrote updates, reviews or summaries that others read, say what and for whom; if the checklist is your main example, say so plainly |
| F9 | Team leadership: not in the JD, whose word is "coordinate"; flagged because your message names it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated it. Words: "I haven't led a team." Say it once, plainly, with nothing added to make it smaller |
| F10 | In-app-purchase experience: not in the JD; flagged because your message names it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated it. Words: "I haven't worked on a game with in-app purchases." Then a plan, never a past: name the first things you would learn and how you would learn them, in your own words |

## Persona table

Relationship prior for a hiring manager: Case/Strategist and Skeptic dominant. No interviewer profile and no loop source beyond your own note of one 60-minute session with Tobias, so there are no interviewer or loop adjustments and no archetype fallback; the weights below are the prior plus my judgment where marked. Recalibrate if you know something I don't.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | Live problems from the job: plan this, diagnose that | High: hiring-manager prior; the JD is built around planning and running events | Clarify, objective, segments, approach, metrics, risks, aloud; challenge one premise politely |
| Skeptic (bank B) | Quiet probing of what your material does not show | High: hiring-manager prior; F9 and F10 are limits you stated, and F1 to F3 are thin. Highest-ROI prep: B1 | Rehearse the most predictable objection until it is boring; concede plainly, then return to what you did |
| Data-Driven Prober (bank C) | Reads your background line by line and asks how things were counted | Medium: my judgment, since the JD names retention metrics and KPIs and your retention line is a reporting line | Say what you know about how a number was counted, and plainly say when you do not |
| Conversational (bank D) | Friendly openers that are still scored | Medium: any round opens this way | A scripted 90-second arc; treat casual questions as scored |
| Pressure (bank E) | Challenges your standing: why you, how much was you | Medium: your stated limits invite it | Pause, restate, hold through two follow-ups, concede only what is true |
| Values/Behavioral | No bank | Low: no values-style round is detected, because nothing you gave names one | None built; stories in D1 and B-bank cover the ground |
| Peer Evaluator | No bank | Low: Tobias heads the function, so a peer frame is not the prior; coordination probes show up in A2 and E1 | None built |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the next eight weeks of live events for a mobile title you have just joined. What do you need to know first?" | CASE | [generic] | Clarify first, aloud: what the title's goals are for the period, what the current cadence is and what it delivered, which player groups matter, what lead time design, art and engineering need, and what is already locked. Then objective, segments, approach, metrics and risks. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | Tests the F1 requirement as a plan from a blank page; CASE because it is a live problem, and it is asked first because the hiring-manager prior weights it high |
| A2 | "Two titles, one calendar. Two events both want the same art and engineering slot in the same week. How do you decide?" | CASE | [generic] | Ask what each event is for and whether its date is fixed, what can move and what moving costs, and who owns the decision. Then bring options with a recommendation, and say how you would write the trade-off down for the teams. No claim about your past | Tests the F1 two-title wording and the F2 coordination wording; CASE because it is a trade-off set in the role |
| A3 | "Retention for players who joined during an event is well below the last event's. Diagnose it." | CASE | [generic] | Clarify the definition: which retention, which cohort, against which baseline. Then split by player group and by what changed between the two events, rank hypotheses, say what you would check first, and what you would report and to whom. If you do not know a metric's name here, say what you would look up | Tests F7 and the KPI half of F3 as a diagnosis; generic because it is a pattern for the problem, not a fact about Saltmarsh |
| A4 | "An event goes live with a bug that players can see. Walk me through the first hour, then what goes in the post-event review." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | The first hour: confirm what is broken and who it affects, who owns the fix, hold, hotfix or roll back with engineering and QA, what community tells players, and a timeline logged as you go. The review: timeline, cause, what changes, owner and date for each change. About the checklist you may say, at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: the JD's checklist line makes a probe on keeping it current likely. If you updated it or ran it on releases, say how; if not, or that was not yours, say so plainly and stay with the checklist you wrote | Tests F4 and the review half of F3; CASE because the question asks about no past, and the checklist line is offered at the quote's scope only |
| A5 | "What does a good post-event review contain, and who needs to see it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A review compares the event's objective with the result, names the KPIs and what moved them, what worked and what did not, and decisions with owners; say who reads it and what they decide from it. About your own history, only: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's line on owning the review makes a probe likely. If you chose what went into those numbers or wrote anything around them, say how; if that was not yours, or no such review existed, say so plainly and stay with presenting them | The JD's "own the post-event review" line, F3, is the row with the thinnest bridge; JD because it scores a stated responsibility |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. What would you need to learn first, and how would you learn it?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Say the limit yourself, early, in your own words: "I haven't worked on a game with in-app purchases." Then a plan, not a past: name the first things you would learn and how, in your own words, and do not describe any practice around purchases that you have not done. Hold through two follow-ups by returning to what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years." and "Presented the monthly retention numbers to the studio head." Likely follow-ups: what would you do in your first month; how would you know you were getting it wrong; who would you ask. Concede specifically and keep the core standing; a concession is not a confession | F10 is a limit you named. The JD does not mention purchases, so that this is probed is my judgment, not a fact about Tobias; it is ranked first because it is the gap you stated and the one with no adjacent evidence. JD because it scores fit to the role |
| B2 | "The JD says you will own the post-event review and the KPIs it reports. What have you owned there?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Hold only what the quote carries: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went in or wrote a review around them, say how and what was yours; if that was not yours, or there was no review step, say so plainly and describe presenting them. Hold through two follow-ups by returning to the presenting, never by adding to it | F3 is where the JD presses hardest on thin evidence, so the objection arrives in some form; JD because it scores the stated requirement |
| B3 | "You ran the calendar for your main title. We have two titles to run. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever ran or fed a calendar for a second title, say how; if you ran only that one, say so plainly. Then say what you would need to find out first about the second title, as a plan | The JD's two-title wording on F1 is the likeliest stretch; JD because it scores the stated scope |
| B4 | "You have worked at a puzzle-game studio. Why live operations here, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Give your actual reason, in your own words, in one or two points; keep it consistent with what you tell any recruiter. Do not say more about the move than is true for you. Nothing in the pack supplies the reason, because only you have it | A motivation probe is the standard Skeptic check; EXP because it tests whether the story across your background holds together |
| B5 | "The role asks for 3+ years producing live-service games or apps. How does your background map to that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Say the facts at their scope: four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar for your main title for the last two years. Let the interviewer draw the inference. Answer slot: if asked how the title was run after launch, say in your own words; if it was not run as a live-service game, say so plainly and stay with the calendar | F5 is a discovery row and the JD states the requirement outright, so it is a likely early check; JD because it scores the stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented: how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Your material carries no figure, so the slots are the four any number raises, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how something was counted, say so plainly and say what you would check first. Never explain a method you cannot repeat under a second question | F7 and F3 are the evidence behind the retention requirement, and a probe goes to counting first |
| C2 | "You wrote the release checklist QA still uses. Walk me through what is on it and how QA uses it today." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Describe the checklist in your own words and how QA uses it; the pack does not supply what is on it. Answer slot: the JD's line on managing it with QA makes a probe on running it each release likely. If you ran or updated it, say how; if it stayed as written, or someone else ran it, say so plainly and stay with the checklist you wrote | F4 is a named artifact, so a prober asks for it line by line |
| C3 | "Walk me through a typical week of the calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on the quote's own beats: weekly, content drops, your main title, the last two years. Answer slot: the JD's coordination line makes a probe on the people involved likely. If you worked with design, art, engineering or community on a drop, say who and what you needed from them; if not, or others did, say so plainly and stay with the calendar | F6 and F2 are where a prober tests whether the calendar was yours; EXP because it tests what you actually did |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: how did you get here, and why live operations?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc in your own words, one clause per beat, in order: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title for the last two years; the release checklist QA still uses; the monthly retention numbers you presented to the studio head. Close on why this role, in one or two sentences that only you can supply | Every interview opens with a version of this and it is scored; EXP because it is the CV in motion |
| D2 | "What are you playing and following in mobile live events these days?" | CO | [generic] | Name only games and events you have actually looked at, and one specific thing you noticed in how an event was structured or paced. Do not name a title you have not opened. If you can, spend time in the two titles the JD refers to before Friday and say what you saw, since nothing here establishes which they are | The conversational stem on the JD's own subject; CO because it tests homework, and generic because research was unavailable |
| D3 | "How do you keep people informed in writing when an update is moving?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | The JD's wording on clear written communication raises this. At its own scope: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote updates, reviews or summaries that others read, say what and for whom; if the checklist is your main example, say so plainly. If you can bring a short writing sample you can share, say so | F8 is a discovery row; JD because it scores a stated requirement asked casually |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You haven't led a team, and the JD has you coordinating design, art, engineering and community. Why would they work to your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate. Concede plainly: "I haven't led a team." Hold on what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you coordinated any of those groups on a drop, say how, in your own words; if not, say so and say what you would need from each group first. Never claim authority you did not have | F9 and F2 are the pair a Pressure question joins; JD because it tests the stated coordination duty |
| E2 | "Sixty seconds: why should we hire you over someone who has already run live events on a game with purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | Hold: say the three facts at their scope, in your own words. Concede the limit in one sentence: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the facts, never by adding to them. Do not claim the other candidate's experience | F10 against the rest of the evidence; JD because it scores fit to the role under time pressure |
| E3 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Then separate what was yours alone from what was shared, using we for context and I for your contribution. Answer slot: if others set parts of it, say which; if some decisions were not yours, say so plainly and stay with what you ran | The attribution probe on F1 and F6; EXP because it tests the claim, not the job |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, B3, C3, E3 |
| "coordinate design, art, engineering and community teams on each update" | A2, C3, E1 |
| "own the post-event review and the KPIs it reports" | A4, A5, B2, C1 |
| "manage the release checklist with QA" | A4, C2 |
| "3+ years producing live-service games or apps" | B5, D1 |
| "experience running a content calendar" | B3, C3, E3, D1 |
| "comfortable with player-retention metrics" | A3, C1 |
| "clear written communication" | D3 |

Stated limits (F9, F10) are covered by B1, E1 and E2.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the live-events calendar look like today for each of the two titles: how far ahead is it planned, and what moves it?" | A producer's first question, and the answer tells you what you inherit |
| R2 | "Who signs off each update, and where do design, art, engineering and community disagree most often?" | Shows you think about decisions across teams, and surfaces the real friction |
| R3 | "What does the post-event review look like now: who attends, and which KPIs does it report?" | Ties to the JD's own wording and shows you are already thinking about what you would own |
| R4 | "How much of the role's day-to-day touches in-app purchase decisions?" | Asks about the one area you named as new without assuming the answer, and turns B1 into a planning conversation |
| R5 | "How is the release checklist handled between the producer and QA today, and who runs it on release day?" | Connects to your own artifact and shows you care about the handover |
| R6 | "Is there a format the team uses for writing up decisions and post-event findings that I should read before starting?" | Signals that you take written communication seriously and prepares your first week |
| R7 | "What would make you say, six months in, that hiring me was the right call?" | Gives you the interviewer's scoring sheet in their own words |

## Prohibited claims

Built before the banks. Each entry is something this pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." No slot |
| Had in-app-purchase or monetization experience | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says one main title's content-drop calendar. B3's slot stays inside the calendar |
| Owned the post-event review or set the KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says presenting the numbers. A5 and B2 stay inside it |
| Drove or improved retention | Inflated form of F7 | F7's quote at its own scope: your material says you presented the numbers, not what they did. C1 asks only how they were counted |
| Managed QA or ran the release process | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses. C2's slot stays inside it |

## Sources

Provided: the JD and the background you typed in your message. No dossier, no CV file, no interviewer profile, no recruiter notes.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search was refused, so nothing from the web is in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Query "Saltmarsh Games values mobile game studio": refused. Would have named published values for the themes of behavioral questions; no values-style round is detected either way |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Query "Saltmarsh Games interview process live operations producer": refused. Would have shown the loop and whether a values round exists; the weights rest on the hiring-manager prior instead |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Query "Saltmarsh Games strategy news mobile titles": refused. Would have grounded a company-specific CO question; D2 is generic instead |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Query "Tobias Wrenfield Saltmarsh Games": refused. Would have supplied the interviewer read and a reverse question tied to their path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV text: the evidence cells in F1 to F8 would quote your CV instead of the summary you typed, which can raise rows now at low or medium
- An inspectable work sample (a sample week of the content calendar, the release checklist itself, or a retention report you can share): would raise F4, F6, F7 and F8 beyond medium and low
- Your own answers to the answer slots in F1, F2, F3, F4, F5 and F8, given outside a drill: they enter the snapshot as quoted evidence and the rows that draw on them are rebuilt
- The recruiter's prep email, if there is one: coverage of any announced deliverable or format, and a firmer round type
- The interviewer's public profile or writing, if you want to share it: an interviewer read, tuned persona weights and a reverse question tied to their own path
- Permission to search: the default research pass (Saltmarsh's published values and loop, recent strategy, and Tobias's public professional footprint) would replace D2's generic label and the missing sections. A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, is available once the first has run
- A `tuesday-dossier.md` from an earlier underwriting of this role would add confirmed evidence and a named top objection
