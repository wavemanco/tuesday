Loading the playbook is done. I'm running the default research pass now: Northwind's published values, its interview process, and Dan's public footprint. After that I'll write the pack.
The prep pack is saved as `Northwind-Data_senior-gtm-strategy-lead_interview_pack.md` in the working directory. It has 22 questions across six interviewer personas, plus the fit snapshot, a read on Dan, seven reverse questions and a list of claims it won't coach. I built it for a single 60-minute conversation with Dan as Priya's peer.

The search tool was refused for all three calls, so I couldn't check Northwind's values, its interview process or Dan's public footprint. The pack rests on what you gave me: the JD highlights, Priya's summary, Dan's profile description and your research note. The Sources section records each refused search. That also means the pack has no values-based questions and no deeper read on Dan.

- **Highest-ROI prep:** D1, "Which part of this role would you be weakest at on day one?" Priya's stated lack of sales-ops and quota-setting experience is the objection Dan is most likely to press. D1 has her say it plainly, then give a ramp plan, with two rehearsed follow-ups.
- **Rest of the pack:** The prober bank (A) leads, built around the ~$400M figure, the SQL claim and the revenue model. The peer bank (B) and the pricing and strategy case bank (C) follow. P1 and P2 are the pressure versions of the quota gap and the $400M attribution.
- **Answer slots:** Where her summary doesn't show a practice the JD or Dan would ask about, the guidance is an answer slot rather than a story. An example is whether the carrier model went beyond economics into partner-motion design. Her real CV wording would turn most of these into mapped stories.

I can play Dan as the Skeptic on D1, the question the pack names as highest-ROI, whenever you like. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

Two questions that would reshape the pack:
1. Can you paste the exact wording of Priya's CV lines for the ~$400M proposal, the carrier revenue model and the annual volume targets?
2. Did the recruiter name any focus areas or a deliverable, such as a presentation or take-home, for this conversation?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data, a peer (both report to the same VP). **Round:** one 60-minute conversation. Built at research tier L0 in effect, because every search was refused this session. See Sources.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script.
- Types: **EXP** work-experience deep-dive (do your claims survive scrutiny). **JD** role requirements (can you do the listed job, gaps included). **CO** company and strategy knowledge. **CASE** a live problem from the role. **VAL** behavioral alignment with published company values. No VAL question appears, because no published Northwind values were available.
- Every question carries a provenance label. A candidate sentence behind a guidance cell is quoted in the Provenance column. Where the notes say nothing, the guidance is an answer slot: an instruction for the interview, with one honest branch for "this did not happen, or was not mine".
- The highest-ROI prep in this pack is **D1**, the day-one-weakness question, with P1 and P2 as its Pressure versions. Rehearse those first.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and a proposal, not launching or owning a go-to-market, and the words stay at the proposal: "I proposed a store-surface change." Answer slot: the JD's "own" line makes a probe on go-to-market work likely. If any of your product-strategy work involved bringing something to market, say what and which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | discovery | The material does not show analysis of customers across those stages, and the one quote is consumer-tech. Answer slot: if any analysis of how customers move through stages of a relationship was yours, say what it covered; if none was, say so plainly and say how you would start on it |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap on the face, but "skilled" is an adjective with nothing inspected behind it, so expect a probe. A named analysis beats the adjective. Answer slot: if you wrote the queries or built the dashboard for an analysis yourself, say which one; if others did part of it, say which part was yours |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model, not a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you shaped how a partnership worked beyond its economics, say what and which part was yours; if you did not, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already speaks to it in role-relevant terms: "I set annual volume targets with cross-org consensus." Expect a probe on how consensus was reached. Answer slot: if there was disagreement along the way, say what it was and how it resolved; if consensus came without any, say so plainly |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The words stay at daily use: "I use AI tools every day." The material does not show AI product or program work, and Compass is a product launch, so do not let the answer drift toward it |
| F7 | Role-family, unquoted: sales-ops and quota-setting fluency, since the interviewer owns sales strategy | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it was stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Source: the profile description supplied in the coach's message. No public-footprint research could run (see Sources).

| Signal | Implication for this conversation |
|---|---|
| Self-describes as "relentlessly data-driven" | Every number is probed to its assumptions. The Prober bank is the largest. |
| Career spine in pricing and monetization | Cases arrive in pricing, packaging and unit-economics terms. Use that vocabulary when answering cases. |
| One early-stage-startup chapter | Expect interest in how you work without a playbook, and a probe on big-company pace. Do not claim a builder history your material does not carry. |
| Peer, same VP | He is pricing what you cost and contribute to his work: where the seam sits, what you need from him, and what you bring him. |

Mirror opportunity: his monetization path and F4's quote, "built a partner-level revenue model used in carrier negotiations". Mention it only in the quote's own terms, as a revenue model, and let him draw the parallel to his pricing work. Do not call your work pricing.

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Line-by-line probing of the $400M figure, the revenue model and the SQL claim | Top (5 questions). Peer prior plus his "relentlessly data-driven" self-description | Know and say how each figure was counted, or say plainly you do not know; name the weakest assumption before he does |
| B. Peer Evaluator | Seam-splitting, credit, disagreement, what you need from him | High (4). Relationship prior for a peer | Reciprocity framing; propose seam principles, not a map you cannot know |
| C. Case/Strategist | Live GTM, pricing and partner-motion problems on his roadmap | High (4). Pricing spine tilts cases his way; strategy priorities supply the material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| D. Skeptic | The sales-ops, quota and consumer-to-B2B gaps | Mid (3). The gaps are known from the notes and he owns the adjacent discipline | Rehearse D1 until it is boring; bridge only from your stated work |
| E. Conversational | Biography opener, casual AI question | Low (2). The AI question is the JD's plus, asked casually | A 90-second arc; treat casual questions as scored |
| P. Pressure | Time-boxed "why you" and attribution challenges | Low (2). A peer is less likely to stress-test, but the hardest gap invites it | Pause, restate, hold through two follow-ups, then concede specifically |

Loop basis: the coach's words establish one 60-minute conversation with a peer. No values-style round is detected, so there is no values cheat sheet.

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F1, at the quote's scope: you proposed the change, and the figure is what it was credited with. Answer slot: say who credited it and how it was counted, in your own words; if you do not know how it was counted, say so plainly and return to the proposal. Name no method you cannot repeat under a second question | F1 holds the headline metric, and a prober opens on it. EXP because it tests what was counted and what was yours |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move, in your own words: name the assumption you know of before he does. Answer slot: if you know one, name it and say what it is sensitive to; if you do not know how the figure was built, say so plainly and say which part was yours | The stem every prober uses on a CV number. Coaching it converts a gotcha into credibility, and F1 is the row it tests |
| A3 | "Tell me about an analysis you ran yourself in SQL, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one where you wrote the queries and chose the cut, and say what question it answered and what happened because of it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries: "I'm skilled in SQL and Tableau", and how you would approach one here | The JD asks for independent analysis, and F3's quote is an adjective. EXP-style depth, JD-tagged because it scores the stated requirement |
| A4 | "Here is a table of accounts by product, region, seat count and renewal date. How would you find whitespace?" | CASE | [generic] | Clarify first: what the data really holds and how Northwind defines land, adopt, expand and renew. State a hypothesis, segment, say what you would query, name how you would sanity-check the answer, and say where it could mislead you. The question needs no claim about your past | F2's requirement as a live problem, with the prober's checking instincts built in. A pattern for the problem, not a fact about Northwind |
| A5 | "Two new product lines, no history. How do you set success metrics before there is any baseline?" | CASE | [generic] | Structure: what decision each metric serves, leading versus lagging, what you would set as a provisional target and how you would revise it, and what would make you change your mind. No claim about your past | F1's requirement rehearsed as reasoning; a data-driven peer scores whether you know your assumptions |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map: who owns the question, who owns the number, how disagreements are surfaced and resolved. Reciprocity: what you bring to his team, not only what you need. No claim about your past | The persona stem for a peer. F5's requirement tested in his terms |
| B2 | "Tell me about a time you disagreed with a peer on a number or a target." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: you set annual volume targets, with consensus across orgs; tell it in your own words. Answer slot: if there was a disagreement on a target, say what it was, what you did and how it resolved; if consensus came without one, or the target was not yours to set, say so plainly and describe how the consensus was reached | A disagreement story is the peer stem. EXP rather than VAL because no published values were available |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quote's scope: you proposed the change. Answer slot: if other teams built, shipped or measured parts of it, say which, in your own words; if you did part of it, say which part; if none of it spanned teams, say so plainly and stay with the proposal | The credit probe lands on the $400M line first, and F1 is where inflated attribution would show |
| B4 | "Sales strategy lives close to quotas and territories in my world. What do you need from me, and what do you bring?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations" | Say it first and plainly: "I haven't had classic sales-ops or quota-setting experience." Then reciprocity at the quote's scope: "I built a partner-level revenue model used in carrier negotiations." Then what you would ask him for, as a plan, not a past. Never call the volume targets quotas | F7 is the gap a peer in sales strategy will price most directly. JD because it scores how you work with him; the gap is the content |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The main competitive threat is bundling by a much larger platform vendor. How does that change the go-to-market for a new product line?" | CO | [grounded] research note: "main competitive threat is bundling by a much larger platform vendor" | Clarify which product line and which buyers the bundle reaches first. Then options: what the bundle cannot match, where packaging and price can protect the line, who you would reach before the bundle does, what you would stop doing. Challenge one premise respectfully. No claim about your past | The strategy-grounded question. A pricing-spine interviewer will go to packaging first |
| C2 | "Design a partner motion for a new product line. Who are the partners, what does each side give, and how do you know it is working?" | CASE | [generic] | Clarify the product and the buyer; segment partner types; state what each side gives and gets; define two or three leading signals; name the risks, such as channel conflict and partners with a competing incentive. No claim about your past | The JD marks partner-motion design as required, and F4's evidence is a model, so the design is rehearsed as a live case |
| C3 | "Enterprise expansion and profitability pull on discounting differently. How do you think about price on a new product line?" | CASE | [grounded] research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Clarify the product's stage and who the buyer is. Then land versus expand pricing, what a discount buys and what it costs, how you would test before committing, and what profitability changes. Speak in packaging and unit-economics terms; that is his native language | His pricing spine makes this the likeliest case. The two priorities it sets against each other come from the note |
| C4 | "Of enterprise expansion, the Compass launch and profitability, which should these product lines serve first, and which would you let slip?" | CO | [grounded] research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Pick one and defend it: the criterion, what you would give up, and what you would need to know to change your mind. Saying no to one is the point. No claim about your past | The role owns GTM for two lines, so priority trade-offs are the job. The anti-pick is what scores as judgment |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | **Highest-ROI rehearsal in the pack.** Say it plainly: "I haven't had classic sales-ops or quota-setting experience." Then a ramp plan, as a plan: what you would ask Dan and the VP for and what you would read first. Hold through two follow-ups. Level 1: "Quota design is half my job. Why you?" Answer from the quotes you do have, at their scope, and do not widen them. Level 2: "So what do you not know?" Concede specifically: how quotas are set here, and how territory and capacity feed them. The limit is named before he asks for it. Never describe the volume targets as quotas | F7 is the single most predictable objection, and a rehearsed, non-defensive answer changes the interview. JD because the objection is aimed at the listed job |
| D2 | "You spent nine years inside a large consumer-tech company. What makes you think that carries over to B2B data infrastructure?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | The quote at its own scope: nine years in product strategy and ops. Answer slot: if any of that work involved business counterparties or enterprise-style negotiation, say what and which part was yours; if none did, say so plainly and say how you would learn the buyer. Do not claim B2B exposure the notes do not show | F2 is where the background mismatch sits. A peer asks it collegially, so it is rehearsed as an honest plan |
| D3 | "Partner-motion design is a required piece here. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The quote at its scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you shaped how a partnership worked beyond its economics, say what and which part was yours; if you did not, say so plainly and return to the model | The JD names it as required, and F4's evidence stops at the model. The honest branch is a limit, not a confession |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the quote's two beats: two years in strategy consulting, then nine in product strategy and ops. Say in your own words why you are moving to this role and to Northwind; the notes do not state it, and an invented reason is the one he will probe | Casual openers are scored. F1 supplies the arc |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools you use and for what, in your own words, at the scope of "I use AI tools every day." If any use bears on analysis or planning work, say how; if nothing goes beyond daily use, say so plainly. Do not present it as AI product work | The JD's AI plus asked casually, with Compass in the background. F6 is the row |

### P. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause and restate. Concede first, specifically: "I haven't had classic sales-ops or quota-setting experience." Then hold on what the quotes carry, at their scope: you built a partner-level revenue model used in carrier negotiations, and set annual volume targets with cross-org consensus. Hold through two follow-ups by returning to those lines, never by adding to them | F7 in a time-boxed register. The hold uses only what F4 and F5 say |
| P2 | "That ~$400M result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quote: you proposed the change. Answer slot: if others built, launched or measured parts of it, say which; if you did some of it, say which part; if you do not know how the credit was assigned, say so plainly. Do not fold on what you proposed, and do not widen it | The attribution probe that exists to catch inflation. F1 is its row |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | A5, C1, C3, C4 |
| identify whitespace across land/adopt/expand/renew | A4, D2 |
| run independent analysis in SQL and Tableau | A3, A4 |
| partner-motion design experience required | C2, D3 |
| strong cross-functional influence | B1, B2, B3 |
| AI experience a plus | E2 |
| Role-family: sales-ops and quota-setting fluency | B4, D1, P1 |
| Published values (VAL) | none: no Northwind values were available, so no VAL question is written |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization. How does that shape how you want a new product line packaged before it reaches a sales team?" | Ties to his own career path and gives him his native subject |
| R2 | "You have also been through an early-stage company. What from that applies to launching a product line here, and what does not?" | Ties to his startup chapter and invites a peer conversation |
| R3 | "What could a new person on my side do in their first month that would genuinely help your team?" | The reciprocity question for a peer |
| R4 | "How do the two new product lines and Compass each show up in the targets your team is working to?" | Shows you read the strategy and asks where the seam really is |
| R5 | "When a larger platform vendor bundles against us, which deals do you see it affecting first?" | Uses the competitive-threat frame and invites his data |
| R6 | "How far do Sales and Product trust the data on where customers sit across land, adopt, expand and renew?" | Aims at the whitespace requirement and his data-driven bent |
| R7 | "What would make this role a clear success twelve months in, from where you sit?" | Asks what he scores, from the peer's side |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has set quotas, or has sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." No slot. The volume targets in F5 stay at their own scope, and the pack's observation is that the material says volume targets, not quotas |
| Designed or ran partner motions | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model, not a motion. D3's slot stays inside the model |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The material says proposed, and credited |
| Owned or launched a go-to-market | Inflated form of F1 | F1's quotes at their scope. The material says product strategy and ops, and a proposal |
| Built or led AI products or programs | Inflated form of F6 | "I use AI tools every day." The material says daily use |

## Sources

Provided documents, all in the coach's message: the JD highlights, the candidate summary, the interviewer's profile description and the research note on Northwind's priorities and competitive threat. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Query "Northwind Data company values": refused. Would have fed a values cheat sheet and VAL questions |
| 2. `Northwind Data interview process` | unavailable | Query "Northwind Data interview process strategy GTM": refused. Would have checked loop structure; the coach's words already establish one session with a peer, so persona weights rest on that |
| 3. `Northwind Data strategy` / recent news | skipped | The pasted research note supplies the priorities and the competitive threat that feed the CO bank. Its age was not verified |
| 4. `Dan Kovac Northwind Data` | unavailable | Query "Dan Kovac Director of Sales Strategy Northwind Data": refused. Would have fed the interviewer read with talks and writing; it rests on the profile description alone |
| 5. representative Senior GTM Strategy Lead JD | skipped | The JD highlights were supplied. They are highlights, not the full text |

## Upgrade menu

- The JD's full text → mid-list requirements get their own quoted rows, and F1 to F6's requirement cells quote the posting rather than highlights
- The exact wording of Priya's CV lines for the $400M proposal, the carrier model and the volume targets → the answer slots in A1, A2, B2, B3, D3 and F2 turn into quoted story maps
- Her answers to those slots, stated outside a drill → F1, F4 and F5 regenerate with the new quotes
- The recruiter's prep email → focus areas and any pre-declared deliverable, which this pack otherwise assumes are absent
- Dan's talks, posts or public writing → a real interviewer read and a sharper R1 and R2
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, and it needs search permission that this session did not grant → a strategy brief for C1 to C4, role-family loop reports and recent org context
- A tuesday-dossier.md from an earlier evaluation of this role, if one exists → D1's ramp plan and the prohibited list would rest on verified evidence rather than local inference
