Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-8-denied-23d21683/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop for 4 December, with each interviewer known by role only because none has been named. It has a fit snapshot against the JD, a question bank and reverse questions per round, a values cheat sheet for the panel, and a nine-day prep order.

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 4 December 2026, built from the recruiter's email.

| Round | Who | Length | Format |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Conversation |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four published values |

No interviewer names have been assigned yet, so every persona weight below rests on the round's relationship and format, not on a person.

## How to use this pack

- Personas are how a question arrives. Types are what is being scored.
- Type key: VAL is behavioural or values alignment. EXP is a work-experience deep-dive. JD is a question from the role's stated requirements. CO is company and strategy knowledge. CASE is a live problem.
- Answer guidance is scaffolding, not a script. Say only what you actually did, in your own words.
- A line that begins "Answer slot" is an instruction for the interview. It asks you for nothing here.
- Question IDs run across the whole loop: A and B are round 1, C, D, E and G are round 2, H, J and K are round 3. Rows F1 to F9 are the fit snapshot.

## Prep triage

There are nine days from 25 November to 4 December. This is the order that matters.

1. Write your answers to the slots in F1, F3, F7 and F9, one or two lines each. They feed A1, E1, E2 and E3, which are the questions on your own work. Nothing else in the pack improves as much.
2. Rehearse D1 aloud until it is boring. It is the highest-ROI prep in this pack, and B1 is the same question in a friendlier register. Do it three times, including the follow-ups.
3. Time yourself on the case. Say J1 aloud in 20 minutes with the structure in its guidance; then J2 and J3.
4. For each of the four values, pick one real situation and write three bullets: what happened, what you did, how it ended (H1 to H4). Only what happened.
5. Write your own answers to A2 to A5, the logistics, so none of them is improvised.
6. Read G1 and H5 once, and decide what you actually think before you rehearse either.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what lay beyond the log likely. If any part of the process beyond the log was yours, say which part and how you decided, in your own words; if there was no such part, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD (the contact-centre half of F1's line) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says you built a monthly complaints spreadsheet a regional manager uses; it does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it counted either, say what was counted and how, in your own words; if it counted something else, or neither, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I trained new tellers on our escalation script." That is tellers and a script, not supervisors and coaching. Answer slot: the JD says supervisors, so expect a probe on whether you have helped anyone beyond new tellers. If any of your work involved helping a supervisor or colleague handle an escalation, say what and how, in your own words; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital or product team, or on any self-service channel, say what and which part was yours, in your own words; if not, say so plainly and say what you would want to learn first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Reword only the quote: "I've spent six years in retail banking, the last three as a branch supervisor." Whether the employer counts branch work as customer operations is theirs to say, so the words do not claim it; RQ1.1 asks |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" is your word; whether the log was kept under outside rules is not shown. Answer slot: the JD's regulated line makes a probe on what made your log formal likely. Say what made it formal and what it required of you, in your own words; if you do not know what made it formal, or it carried no outside requirement, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A limit you stated. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first one, said as a plan. The quote does not say what you have presented at regional level or elsewhere; the upgrade menu asks |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: the JD names Excel, so expect a probe on the tool and what it did. Say which tool you built it in and what it did, in your own words; if it was another tool, say so plainly and stay with what you built |

## Prohibited claims

Built from the snapshot before any question was written. Each entry is something this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the log, not the process. E1's slot stays inside the log |
| Has handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The material says formal, not regulated. E3's slot asks only what made the log formal |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: tellers and a script. C2's slot stays with the tellers |
| Has reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. E2's slot asks only what the spreadsheet counted |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |
| Built the reporting in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. E2's slot asks which tool |

---

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, logistics first | top. A recruiter screen's prior is Conversational plus a light Skeptic. The email gives no signal that moves it | Treat casual questions as scored. Script the journey arc and the four logistics answers in advance |
| Skeptic | Quiet knockout checks on the gaps | mid. A screen is where a stated gap against the JD is checked first; the JD's contact-centre line (F2) and years line (F6) are the likeliest | Say the limit plainly, then the plan. Never bluff a competency |

## Question bank: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc from these beats only: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; the monthly complaints spreadsheet. Keep each at its quote's scope. Answer slot: say your actual reason for wanting this role, in your own words, and keep it the same in every round | The opener of every screen; F6 and F1 give the arc its spine. EXP because it tests what you actually did |
| A2 | "What are your salary expectations?" | JD | [generic] | Logistics slot. Either give your own number, or ask for the role's band first; say only what you would actually accept, in your own words. The JD and the recruiter's email state no pay, so there is nothing to react to yet. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a standard screen item; JD because it is a term of the listed job |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, as your contract states it, in your own words. If you are not sure, read your contract before 4 December | A standard screen item; JD because it is a term of the listed job |
| A4 | "Where would you be working from, and how often?" | JD | [generic] | Logistics slot. Say where you can work and how often, as it is true for you. The JD and the recruiter's email state no location or office pattern, so ask RQ1.4 | A standard screen item; JD because it is a term of the listed job |
| A5 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot. Give your actual reason in one or two sentences, in your own words, and stop. Say it aloud once before the day | A standard screen item; EXP because it tests motivation consistency across the loop (D3 returns to it) |

## Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. You haven't worked in one. How would you handle that side?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Hold, then concede, from the quotes only. Open with the plain acknowledgment: "I haven't worked in a contact centre." Then the nearest thing you did say, at its scope: "I handled the branch's formal complaints log." Then a plan in your own words: who you would sit with first, what you would read, what you would ask in your first weeks. Choose steps you would really take. Do not claim the log is equivalent | F2 is the JD's biggest stated gap, so this arrives in round 1 in a friendly register; D1 is the same question with more follow-ups |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Selection scaffold. Your material states two limits: F2 and F8. Pick the one that is truly your weakest, say it in the quote's plain words, then name your first step. If neither is, say so plainly and name the one that is | A persona stem built from F2 and F8; JD because it scores honest self-assessment against the listed job |
| B3 | "The role asks for four-plus years in financial-services customer operations. How does your background fit that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | State it in the quote's terms: "I've spent six years in retail banking, the last three as a branch supervisor." Then stop; whether branch work meets their definition is theirs to say, and RQ1.1 asks it | F6 is a years requirement a screen checks first; JD because it is a stated requirement |

## Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| RQ1.1 | "Does the financial-services customer operations requirement count time as a branch supervisor?" | Settles F6 in one line, before the later rounds |
| RQ1.2 | "Can you share the names and roles of the Head of Member Services and the two branch managers, and any format notes for the 20-minute case?" | Unlocks the interviewer read and the case's shape, which this pack cannot know |
| RQ1.3 | "How much of the role's day-to-day sits in the contact centre, and how much in branches?" | Tells you how much weight F2 carries in practice, from the person who can say |
| RQ1.4 | "Where would the role be based, and what is the expected office pattern?" | Fills the location slot in A4 from their side |
| RQ1.5 | "What happens after 4 December, and when do you expect to decide?" | Closes the loop on timing; every screen leaves room for it |

---

# Round 2: the Head of Member Services (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes, STAR-shaped stories | top. The recruiter calls the round mostly behavioural; a hiring manager's prior is Case plus Skeptic, moved by that word | Where a quote carries a story, map it; where none does, use the scaffold and its honest branch. "We" for context, "I" for contribution |
| Skeptic | Quiet, persistent probing of the gaps | mid. A manager is buying capability and checking the gaps (F2, F8) | Rehearse D1 until it is boring; bridge only from what you said; give a concrete ramp |
| Data-Driven Prober | Reads your material line by line | mid. The role reports monthly, so the manager is likely to test the one reporting artefact you have named (F3, F9) | Know what you can and cannot say about what the spreadsheet counted, and say plainly where you do not know |
| Case/Strategist | A live problem or strategy question | low. "Mostly behavioural" leaves a smaller share for it, and round 3 holds the case | Clarify before structuring; think aloud; challenge one premise respectfully |

## Question bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, what you actually said, how it was received, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; F3's monthly reporting and F8's senior audience make it likely. VAL because it tests behaviour, not a published value by name |
| C2 | "Tell me about a time you helped someone through a difficult escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: the new tellers and the escalation script are the beats the quote states; tell them in your own words. Answer slot: the JD says supervisors, so expect a probe on whether any of it involved a supervisor or a live escalation. If so, say what and how; if not, or it was not yours, say so plainly and stay with the tellers and the script | F4 is the evidence for the coaching requirement and its likeliest probe; JD because it scores a stated requirement |
| C3 | "When did you put a member ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time with a named member situation, the metric in tension, what you decided, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that maps to the first published value, and to a role that reports on complaint numbers (F3). VAL |
| C4 | "Tell me about a time you worked with a team outside your own on a shared problem." | JD | [grounded] | Selection scaffold, from the JD's digital line (F5). Pick a time with a named team, what the shared problem was, what part was yours, and how it ended. If no such time comes to mind, say so plainly, then say how you would start working with a digital team on a self-service journey | F5 has no evidence either way, so the scaffold's honest branch matters here. JD because it scores the stated requirement |

## Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role owns complaints across branches and the contact centre, and you haven't worked in a contact centre. Why should we think you can own that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry. Open: "I haven't worked in a contact centre." Then the log at its scope: "I handled the branch's formal complaints log." Then your ramp plan in your own words: who you would sit with, what you would read, what you would ask first. Follow-up 1: "What would be hardest about it?" Name one real thing, in your own words. Follow-up 2: "Your log was one branch. How do you know the centre works the same way?" Concede exactly: you do not know yet, and the plan is how you find out. Follow-up 3: "A team leader there challenges your plan in your first week. What do you say?" Listen first, then say what you would change. Never claim equivalence, and never fill the gap with a practice you did not state | F2 is the sharpest stated gap against the role's headline line, so this question arrives in some form; JD because it scores the stated requirement |
| D2 | "The role presents to senior leaders. You haven't presented above regional level. How would you approach your first one?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then what you would do to prepare, in your own words: what you would put in front of them first, who you would test it with. One adjacent fact, at its scope: "I built the monthly complaints spreadsheet our regional manager uses." It shows a regional reader, not a presentation, so do not stretch it | F8 is a stated limit against a stated requirement, and the manager is the likeliest to ask. JD because it scores the listed job |
| D3 | "Why this role, why Ashgrove, and why now?" | CO | [grounded] | Selection scaffold. Pick one of the four published values you actually care about and say why, in your own words; add one item from the strategy brief only if you believe it, and do not recite the brief. Keep it consistent with what you said in A5 and A1 | Persona stem for motivation consistency. CO because it tests homework depth against the published values and strategy; no claim about your past is made |

## Question bank: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: the branch, the log and its formal status are the beats the quote states; tell them in your own words. Answer slot: the JD's end-to-end line makes a probe on what lay beyond the log likely. If any part beyond the log was yours, say which and how you decided; if there was no such part, or it was not yours, say so plainly and describe how you handled the log | F1 is the evidence for the ownership requirement and the likeliest place to be probed; EXP because it tests what was actually yours |
| E2 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F9: you built it, it is monthly, a regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel, so expect a probe on what it counted and in which tool. If it counted either figure, say how each was counted; if it counted something else, say so plainly; say which tool it was built in. Do not describe a feature you did not build | F3 and F9 both rest on this one quote, so the probe is likely; EXP because it tests attribution |
| E3 | "The role asks for experience handling regulated complaints. Where does that show in your background?" | JD | [grounded] "I handled the branch's formal complaints log" | Quote at its scope: "I handled the branch's formal complaints log." Answer slot: say what made the log formal and what it required of you, in your own words; if you do not know what made it formal, or it carried no outside requirement, say so plainly and stay with the log. Do not recite rules from memory | F7 is a hard JD requirement with one quote behind it; JD because it scores the stated requirement |

## Question bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The strategy brief aims to move 40% of member service to digital channels by 2028. What does that mean for how complaints are handled?" | CO | [grounded] | The brief is available to every candidate, so do not recite it. Bring one consensus item to show you read it (the 40% by 2028), then one thesis of your own with its concession. A thesis option, to hold only if you believe it: when a member is already unhappy, a self-service journey that fails them costs more than it saves, so decide which complaint types stay person-led; concede that simple cases can be faster digitally. Say what you would want to know first | The brief's digital target meets the JD's digital line (F5). CO because it tests strategy fluency; the thesis is this pack's derivation, so choose your own if you disagree |
| G2 | "The same complaint keeps arriving by phone and in branch, and a self-service journey is being designed. How would you use the complaints to shape it?" | CASE | [generic] | Structure it: ask what is known so far, state the objective from the member's side, split the complaints by where they start, say how you would work with the digital team, name what you would measure, and name the risk of a journey that hides a complaint. Think aloud. The question needs no claim about your past | A live problem from the JD's digital and reporting lines (F5, F3), asked as a decision |

## Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| RQ2.1 | "Who reads the monthly complaints report today, and what decision does it feed?" | Gives you the audience to rehearse F3 and F8 against |
| RQ2.2 | "Where do complaints get stuck between branches and the contact centre right now?" | Points at F1 and F2 from the manager's side |
| RQ2.3 | "How do the digital team and member services work together today, and where would this role sit in that?" | Settles F5 and what the JD's digital line means in practice |
| RQ2.4 | "How do you expect the move to five hubs to change what branch supervisors need from this role?" | Ties F4 to the strategy brief |
| RQ2.5 | "What would a good first 90 days look like?" | Gives you the success measure to rehearse against |

---

# Round 3: the panel of two branch managers (60 minutes, including a 20-minute case; values scored)

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes scored against the four values | top. The recruiter says the panel scores against the four values, and a loop source (the email) names the round as the values round | Map a story to each value where a quote carries one; use the scaffold and its honest branch where none does |
| Case/Strategist | The 20-minute complaint-escalation case | mid. The email names the case, though its content is unknown | Clarify, state the objective, structure, name the metrics and risks; think aloud |
| Peer Evaluator | Seam-splitting between branches and the role | mid. Panels blend each member's relationship; branch managers are the role's closest stakeholders, since supervisors in their branches would be coached by it | Reciprocity: what you bring their branches. Propose principles for the seam; do not pretend to know it |

The Skeptic is lower here: round 2 carries it, and D1 can return in a collegial form, so keep your D1 answer.

## Question bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold, for the value "Members First, Always". Pick a time with a named member situation, the decision you made, and what it cost or changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Maps to the first published value. The theme comes from the values text you pasted |
| H2 | "Tell me about a time something had to be explained to someone more than once." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold, for the value "Plain Words". Pick a time with a named person, what was unclear the first time, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which may be "trained new tellers on our escalation script", or how you would handle it. That quote does not show the script was plain, so do not say it was | Maps to the second published value. The nearest quote is offered as a possibility, not a story |
| H3 | "Tell me about a time you did something for a member or a community that no number would have captured." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold, for the value "Neighbours, Not Numbers". Pick a time with a named person or place and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, such as the three years as a branch supervisor, or how you would handle it. That quote does not say what you did for any town, so add nothing to it | Maps to the third published value. The branch managers on this panel run branches, so this value is likely to be probed closely |
| H4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, for the value "Own the Fix". Pick a time with a named problem, what keeping hold of it meant day to day, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which may be "I handled the branch's formal complaints log", or how you would handle it. That quote does not show a problem followed to its end | Maps to the fourth published value, and to the JD's ownership line (F1) |
| H5 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. How does that sit with 'Neighbours, Not Numbers'?" | CO | [inferred] the pairing of the brief's hub plan with the published value is this pack's own derivation | Do not defend or attack the strategy. Answer from the member's side of the counter: what members in a town that loses its branch need from complaints handling, and who keeps hold of a complaint that crosses a branch and a hub. Concede that consolidation has a cost to towns. Which branches are affected is not known, so do not guess it | The published value and the published strategy pull against each other, and the panel is two branch managers whose own branches may be affected; this is the pack's reading and labeled so |

## Question bank: Case/Strategist

The case is 20 minutes and its content is unknown, so ask the recruiter (RQ1.2) for its format. These three prepare the structure, not the answer.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member complains in branch about a charge on their account. The supervisor cannot resolve it and escalates it to you. Walk us through what you do." | CASE | [generic] | Say the structure aloud: what you would ask first and from whom; the objective from the member's side; who keeps hold of the complaint, and for how long; what you would tell the member, in plain words; what you would record and report. Ask which rules and timelines apply and confirm them rather than reciting them from memory. Think aloud. The question needs no claim about your past | The case is a complaint escalation, so the JD's ownership and regulated lines (F1, F7) are in scope. It is also the nearest thing to presenting you will do in this loop (F8) |
| J2 | "The same complaint arrives from three branches and the contact centre in one month. What do you do?" | CASE | [generic] | Structure it: what you would check first; whether it is one problem or several; who owns the fix; what the monthly report would show and what decision it would feed; whether a self-service journey could prevent it. Name the risk of fixing the symptom. The question needs no claim about your past | A live problem from the JD's reporting, contact-centre and digital lines (F3, F2, F5) |
| J3 | "A branch supervisor tells you the escalation process just adds work to their day. How do you coach them?" | CASE | [generic] | Structure it: ask what they have seen before you explain anything; say what the process is for from the member's side, in plain words; agree one change to try and when you will check it. Think aloud. The question needs no claim about your past | A live problem from the coaching line (F4), asked as a decision |

## Question bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Our branches sit alongside member services. Where is the seam between a branch's complaint handling and your role, and what happens when we disagree?" | JD | [inferred] a possible seam is derived from the JD's "Own the member complaints process" and the value "whoever finds the problem keeps hold of it until it is solved" | Propose principles for the seam; do not pretend to know it. One option, to hold only if you believe it: the role owns the process and the reporting, and whoever finds a complaint keeps hold of it. Concede that you would need to hear where that breaks in each branch. On disagreement, say how you would resolve it with a branch manager, in your own words. If the panel returns to the contact centre, use your D1 answer unchanged | Peer questions test partnership fit; K1 puts the ownership line (F1) and coaching line (F4) into collegial terms |
| K2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold. Pick a time with a named team, what each side contributed, and how credit was shared. If no such time comes to mind, say so plainly, then say how you would handle it, in a way you would actually act | A persona stem; it tests reciprocity and tact together |
| K3 | "What would you do in your first month that would genuinely help our branches?" | JD | [generic] | A reciprocity answer, as a plan and never as a past: pick two steps you would really take, such as asking each branch what its recent escalations looked like and asking what the monthly report would need to show them. Say what you would ask, not what you already know | Reciprocity framing for a panel of the role's closest stakeholders; JD because it scores partnership in the listed job |

## Values cheat sheet

The values are quoted from the page you copied on 25 November 2026. The panel scores against all four.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a story. Selection scaffold, ending in its honest branch: H1 |
| Plain Words | If a member needs it explained twice, the writing was wrong | F4: "trained new tellers on our escalation script" is the nearest material; it does not show the script was plain. Selection scaffold, ending in its honest branch: H2 |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor" is the nearest material; it does not show what you did for a town. Selection scaffold, ending in its honest branch: H3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log" is the nearest material; it does not show a problem followed to its end. Selection scaffold, ending in its honest branch: H4 |

## Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| RQ3.1 | "Which kinds of complaint are hardest for your branches to escalate today?" | Points the case (J1, J3) and the coaching line (F4) at their real problem |
| RQ3.2 | "When a complaint leaves your branch, how do you hear what happened to it?" | Tests the seam in K1 from their side |
| RQ3.3 | "How does 'Own the Fix' work today when a complaint crosses a branch and the contact centre?" | Ties the published value to the JD's cross-channel ownership line (F1, F2) |
| RQ3.4 | "What should this role protect for your members as eight branches become five hubs?" | Picks up H5 as a question, not a position |
| RQ3.5 | "What could someone in this role do in the first month that would genuinely help your branch?" | The reciprocity question for a panel of the role's closest stakeholders |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own the member complaints process end to end across branches | E1, J1, K1, RQ2.2 |
| Across branches and the contact centre | B1, D1, J2, RQ1.3 |
| Report monthly on complaint volumes and resolution times | E2, J2, C1, RQ2.1 |
| Coach branch supervisors on escalations | C2, J3, K1, RQ3.1 |
| Work with digital teams on self-service journeys | C4, G1, G2, RQ2.3 |
| 4+ years in financial-services customer operations | A1, B3, RQ1.1 |
| Experience handling regulated complaints | E3, J1 |
| Confident presenting to senior leaders | D2, J1 |
| Comfortable with Excel reporting | E2 |

Logistics (pay, notice, location, reason for leaving) are A2 to A5.

## Sources

Provided documents:

- The job description, pasted.
- The values text, pasted, copied on 25 November 2026 from ashgrovecu.org/about/values. It was not fetched.
- The recruiter's email on the process. It establishes the loop: three rounds on 4 December, who runs each, how long, and the case and values scoring.
- The 2026 strategy brief published in July 2026. Only the four points you relayed are in hand: 40% of member service digital by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, and app-only banks as the main pressure. The brief itself was not read.
- Your background message.

Searches sent: none. Fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet or the VAL bank: the pasted values text already supplies the four values by name |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved the persona weights or the rounds: the recruiter's email already supplies the three rounds, their lengths, who runs them, and the values and case scoring |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO questions: the July 2026 brief, about four months old, supplies current priorities in the four points you relayed. The full brief is not in hand, which the upgrade menu notes |
| 4. interviewer name | n/a | No name was given, so there was no query to form. The interviewer read is absent; the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, once assigned → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to each one's path (RQ1.2 asks the recruiter)
- Your answers to the slots in F1, F3, F7 and F9, and anything you have presented at regional level or elsewhere (F8), one or two lines each, said outside a drill → those rows are regenerated from your own words and E1, E2, E3 and D2 get sharper
- An anonymised screenshot or sample of the monthly complaints spreadsheet → F3 and F9 can rise from medium toward high, and E2 can name what it actually shows
- Your CV text → the F rows draw on your full wording instead of the summary in your message
- The full July 2026 strategy brief → G1 and H5 can draw on the brief's own wording, not the four points relayed
- The case format and any pre-read from the recruiter (RQ1.2) → J1 to J3 can be tuned to the real case
- A tuesday-dossier.md from an earlier evidence review → verified evidence and a prohibited-claims list that would sharpen the weak rows (F1, F2, F5, F8)
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, covering the full strategy brief, recent organisation context, and loop reports for similar roles → more specific CO questions in G1 and H5, and any interviewer footprints once names are assigned
