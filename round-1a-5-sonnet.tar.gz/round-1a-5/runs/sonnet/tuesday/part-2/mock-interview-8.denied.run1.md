Dara, your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. It has a shared fit snapshot and a mini-pack for each of the three rounds on 4 December, with 11 questions per round and 5 reverse questions per round. I built it from what you pasted and ran no searches. The recruiter's email already fixes the loop, and your values text and strategy points cover the rest.

The biggest gap is the contact centre, because the JD says to own complaints "across branches and the contact centre". I named D1 (round 2, Head of Member Services) as your highest-ROI prep, and it will come up in some form in every round. Your material carries "I haven't worked in a contact centre" as an honest concession. Your plan for learning it needs to be your own. Presenting above regional level is the next gap, and the pack covers it the same way (B2, D4).

None of your four background sentences carries a story for any of the four values, so the round-3 values questions are selection scaffolds. Each ends with an honest branch if no example comes to mind.

Your material doesn't show what the spreadsheet counted, what "formal" meant in your complaints log, or whether you've done any digital-team work. Those are answer slots, and your answers would make the pack stronger.

Say the word and I'll play the Skeptic on D1, the highest-ROI question, in a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union: interview pack for Dara

Prepared 25 November 2026 for three rounds on 4 December 2026. Loop mode: one shared fit snapshot, then a mini-pack per round.

- Round 1: recruiter, 30 minutes
- Round 2: Head of Member Services, who would be your manager, 45 minutes, mostly behavioural (the recruiter's words)
- Round 3: panel of two branch managers, 60 minutes, including a 20-minute case on a complaint escalation; also the values round, scored against the four values (the recruiter's words)
- Interviewer names are not assigned, so there is no interviewer read.
- Highest-ROI prep in the pack: D1, the contact-centre question. It arrives in some form in every round.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words. An answer slot is an instruction for the interview, not a question for me, and each has an honest second branch.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether what you say you did survives follow-up |
| JD | A listed responsibility or requirement, including the gaps |
| CO | How well you know Ashgrove and its strategy |
| CASE | A live problem, scored on structure and reasoning |

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I handled the branch's formal complaints log." Your material says one branch's log, and the pack does not widen it. Answer slot: the JD's first responsibility makes a probe on what handling the log involved likely. If any part of it was yours to decide, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and describe how you handled it |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Words at the quote's scope: "I built the monthly complaints spreadsheet our regional manager uses." The sentence does not say what the spreadsheet counted or which software it was in. Answer slot: the JD's reporting line makes a probe on what it counted likely. If it counted anything, say what and how each count was worked out, in your own words; if it counted nothing you can describe, or you do not know how a figure in it was worked out, say so plainly and say what it did hold |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Words at the quotes' scope: "I trained new tellers on our escalation script," and "I spent the last three years as a branch supervisor." Your material says tellers, not supervisors, and "our" script, not one you wrote. Answer slot: the JD's coaching line makes a probe on what your training of the tellers involved likely. If you can say what you did, say it in your own words; if you do not know, or how it was run was not yours to decide, say so plainly and stay with the sentence |
| F5 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Reading "formal" as possibly meaning regulated is this pack's inference; your material does not show it, and the pack does not close it. Words: "I handled the branch's formal complaints log." Answer slot: expect a probe on what "formal" meant in your log. If you know what made a complaint formal there, say it in your own words; if you do not know, or it was only what the branch called it, say so plainly and stay with the log |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length, and a CV line with nothing inspected behind it, so expect a probe. Lead with the quote in its own terms: "I have six years in retail banking, the last three as a branch supervisor." Your material does not say what the first three years were; describe the role you actually held |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A limit you stated. Words: "I haven't presented to anyone above regional level." The JD does not say who the senior leaders are, so the limit may or may not fall short; the recruiter can say (X2). Then how you would prepare, said as a plan and never as a past |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Reword only the quote: "I built the monthly complaints spreadsheet our regional manager uses." It says spreadsheet, not Excel, so use your own word for the tool. Nothing about what is inside it until you say it |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here, which is a silence, not a stated absence. Answer slot: the JD's line makes a probe on digital work likely. If you have worked with a digital or online team on how members get help, say who and what part was yours, in your own words; if you have not, say so plainly and say how you would find out which complaints members could settle without a person |

## Grounding brief

The four points below are the ones you were sent from Ashgrove's July 2026 strategy brief. Treat dates as plans, not outcomes.

| Item | As supplied | Source | Provenance | Used in |
|---|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | 2026 strategy brief, via the recruiter | [grounded] | A3, E2, Y4 |
| Hubs | "consolidate eight branches into five hubs over 2027" | 2026 strategy brief, via the recruiter | [grounded] | A3, J2, Z3 |
| Lending | "launch a small-business lending product in Q1 2027" | 2026 strategy brief, via the recruiter | [grounded] | A3 only |
| Competition | "the main competitive pressure is app-only banks" | 2026 strategy brief, via the recruiter | [grounded] | A3, E2 |

## Round 1 — recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly and unstructured: your journey, why Ashgrove, logistics, then requirement checks | high — the relationship prior for a recruiter screen; the email gives the length and nothing on content, so the prior stands | Pre-script the 90-second arc (A1); treat every casual question as scored; use the reverse slot (X1 to X5) |
| Skeptic (light) | Knockout checks on the posting's requirements, asked politely | medium — the prior adds a light Skeptic; the JD's contact-centre and senior-leader lines are where F2 and F7 sit | Rehearse the plain acknowledgment until it is boring (B1, B2); answer, then give the plan |

### Conversational bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Build a 90-second arc from these beats only, in your own words: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close on your own reason for wanting this role, in your own words. Run it aloud until it fits under two minutes | A recruiter opens here, and F6 and F1 are what it has to establish. EXP because it tests whether the written line holds in your voice |
| A2 | "What drew you to a member-owned credit union?" | CO | [grounded] Ashgrove's published values, as you pasted them | Give your actual reason in two sentences, in your own words. If a published value matches it, use the value's own words, for example "Members First, Always — we decide from the member's side of the counter", and say why it matches; if none does, leave the values out. Do not recite the list | Motivation consistency is the recruiter's main scored item in a friendly register. CO because it tests whether you know how Ashgrove describes itself |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] The strategy points you were sent, in the grounding brief | Pick one item from the brief, in its own wording, and say which part of this role it touches. The four are: 40% of member service digital by 2028; eight branches into five hubs over 2027; a small-business lending product in Q1 2027; app-only banks as the main competitive pressure. Choose the one you can say something specific about, say you read the brief if asked how you know, and predict nothing beyond what it says | The strategy-grounded question for this round; E2 and J2 go deeper. CO because it tests homework, not experience |
| A4 | "Remind me how long you've been in financial services, and where." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it as the sentence says: six years in retail banking, the last three as a branch supervisor. The JD lists four or more years, so state the number plainly and stop. If asked about the first three years, describe the role you actually held, in your own words | F6 is the requirement a recruiter checks first and the one your material clears. JD because it checks a listed requirement |
| A5 | "The role needs someone comfortable with Excel reporting. What have you built?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence: you built the monthly complaints spreadsheet your regional manager uses, and name the software in your own word. Answer slot: the JD's reporting line makes a probe on what it counted likely. If it counted anything, say what and how each count was worked out, in your own words; if you do not know how a figure in it was worked out, say so plainly, and say what the spreadsheet did hold | F8 and F3 meet here, and one follow-up checks them. JD because it scores a listed requirement |
| A6 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot. Give your own number, or ask for the role's band first; the posting you pasted gives no pay, so any figure is yours alone. If asked what you earn now, you can decline: "I'd rather focus on the range for this role." | Pay is the logistics item every recruiter raises, and the only safe answer is your own. JD because pay is a term of the listed job |
| A7 | "What's your notice period, and when could you start?" | JD | [generic] | Logistics slot. Give your actual notice period and earliest start date, as they really stand. If you need to check your contract, say you will confirm it by a day you name, and then do | Notice is the second logistics item. JD because it is a term of the listed job |
| A8 | "The role covers branches and the contact centre. Is getting to those sites workable for you?" | JD | [generic] | Logistics slot. State where you are based and which sites you can reach, and how often, in your own words. If you do not yet know which sites the role covers, say so and ask the recruiter | Location is the third logistics item. JD because the premise is the JD's own sites |
| A9 | "Why are you looking to move?" | EXP | [generic] | Logistics slot. Give your actual reason in one or two sentences, in your own words, true as stated. Nothing in this pack supplies it | The reason for leaving is checked against A2 for consistency. EXP because it asks about your own history |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Answer with the gap your material already states, plainly: "I haven't worked in a contact centre." Then a plan in the future tense, in your own words: what you would ask to see first, who you would ask to sit beside, and what you would leave unchanged until you understood it. If asked for a second, B2 has its limit. Do not say "nothing" | F2 is the largest gap against the JD's central line, and a recruiter's knockout check lands on it first. JD because it scores a listed responsibility |
| B2 | "What's your experience presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the limit as you gave it: "I haven't presented to anyone above regional level." Answer slot: if you have presented to anyone at regional level, say who and what, in your own words; if what you did there was not presenting, say so plainly. Then ask who the monthly report goes to, since the JD does not say who the senior leaders are | F7 is a stated limit against a listed requirement, so a screen will test it. JD because it scores the requirement as written |

### Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| X1 | "Who owns complaints today across the branches and the contact centre, and what would move to this role?" | It turns the JD's first responsibility into a scope you can plan around, and shows you read it as an ownership role |
| X2 | "Who would I present the monthly report to, and how senior is that audience?" | It settles what the JD's senior-leaders line means for F7 without conceding anything in the room |
| X3 | "Which digital teams would I work with on self-service journeys, and what are they working on now?" | It meets the JD's digital line head on and ties it to the 40% target |
| X4 | "What will the case in the panel round look like, and is there anything you can share in advance?" | The 20-minute case is the least-known item in the loop, and a recruiter can often say what format it takes |
| X5 | "What do you expect the Head of Member Services to most want to be sure of after meeting me?" | It hands you the recruiter's own read of round 2 before you walk in |

## Round 2 — Head of Member Services, 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" scenarios | high — the recruiter calls the round "mostly behavioural", which lifts it above the hiring-manager prior | Story-map where a quoted sentence carries the story and use a selection scaffold with its honest branch where none does; "we" for context, "I" for contribution |
| Skeptic | Quiet, persistent probing of the gaps | high — the hiring-manager prior is buying capability and derisking gaps, and F2, F1 and F7 sit under this manager's own remit | Rehearse the single most predictable objection (D1) until it is boring; concede what is true, hold what the quotes carry |
| Case / Strategist | Live problems on the manager's own roadmap | medium — the hiring-manager prior includes them, the recruiter's "mostly behavioural" lowers them, and the strategy brief supplies roadmap vocabulary | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| Conversational | Opening rapport | low — an opening only; reuse the A1 arc | No separate bank |

### Values / Behavioral bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through handling an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped at the quote's scope: you trained new tellers on the escalation script, and it was "our" script, so do not call it yours. Tell that in your own words. Answer slot: the JD's coaching line makes a probe on what your training of the tellers involved likely. If you can say what you did, say it; if you do not know, or how it was run was not yours to decide, say so plainly and stay with the sentence | F4 is the nearest material to the JD's coaching line. JD because it scores that listed responsibility |
| C2 | "Tell me about a complaint you followed all the way through." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | No quoted sentence carries a single complaint, so this is a selection scaffold. Pick one complaint where you can say who raised it, what you did, what you decided, how it ended and which part was yours, with nothing you could not repeat under a second question. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry: you handled the branch's formal complaints log. Do not stretch the log into a case | F1 is the JD's centre of gravity, and a manager tests it with this question. JD because it scores the first listed responsibility |
| C3 | "Tell me about a time you had to give leadership an unwelcome number or message." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | No quoted sentence carries this, so it is a selection scaffold: pick a time with a named stake, a moment you said it, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you built the monthly complaints spreadsheet your regional manager uses, which does not say it carried a message, so say only that. Or say how you would handle it | A behavioural probe drawn from the Values / Behavioral stems, touching F3 and F7. EXP because it tests what you actually did |
| C4 | "Tell me about a time you worked with another team to fix something members were struggling with." | JD | [grounded] The JD's digital-teams line | No quoted sentence carries cross-team work, so this is a selection scaffold: pick a problem members had, name the other team, say what each side did and which part was yours. If no such time comes to mind, say so plainly, then say how you would approach working with a digital team on a problem you had spotted | F9 is a silence in your material, so this question is where it surfaces. JD because it scores the listed digital line |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role covers the contact centre as well as branches, and you haven't worked in a contact centre. How will you earn credibility with that team?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack, and the hold is only what the quotes carry. Concede first, plainly: "I haven't worked in a contact centre." Hold through two follow-ups by returning to what you handled: the branch's formal complaints log, and training new tellers on the escalation script. Do not imply contact-centre work, and do not argue that either transfers; say what you would need to learn. Then the plan in the future tense, in your own words: what you would ask to see first, who you would ask to sit beside, what you would leave unchanged until you understood it. If pushed on whether that is enough, say what is true: your experience is the branch side | F2 is the largest gap against the JD's central line, so some version of this arrives in every round. JD because it scores the listed responsibility; Skeptic delivery because it probes a stated gap |
| D2 | "Your complaints work was at one branch. This role covers the whole credit union. What makes you think it scales?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold the sentence at its scope: you handled the branch's formal complaints log. Do not argue that it scales; say what the sentence covers, then what you would want to find out about the other branches and the contact centre before saying more. Answer slot: expect a probe on what handling the log involved. If any part of it was yours to decide, say which and how you decided; if there was no such decision, or it was not yours, say so plainly and describe how you handled it | F1 is the likeliest place to be pressed on scale. JD because it scores the first listed responsibility |
| D3 | "The JD asks for experience handling regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the sentence: you handled the branch's formal complaints log. Answer slot: expect a probe on what "formal" meant in your log. If you know what made a complaint formal there, say it in your own words; if you do not know, or it was only what the branch called it, say so plainly and stay with the log | F5 rests on a reading the material does not confirm, so the slot asks what the word meant and nothing wider. JD because it scores a listed requirement |
| D4 | "You haven't presented above regional level. How would you prepare for senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Concede it as you said it: "I haven't presented to anyone above regional level." Then the plan, in the future tense, in your own words: who the audience is and what decision they need to make, what you would say you do not yet know, and who you would rehearse with. Do not claim a presenting record | F7 is the limit a manager will test because this person would be your first senior audience. JD because it scores the listed requirement |

### Case / Strategist bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Complaint volumes at one branch have risen for three months running. How would you work out why?" | CASE | [generic] | Clarify first: what counts as a complaint, which categories moved, over what period, and whether anything changed in how they are logged. Then objective, segmentation (category, channel, member group, time), approach (read a sample of the complaints themselves, not only the counts), measures, and risks. Challenge one premise aloud: is volume rising, or is recording changing. The question asks about no past, so the guidance makes no claim about it | A live problem from the JD's reporting line, in the manager's likeliest register. CASE because it scores structure; [generic] because it is a pattern for the problem, not a fact about Ashgrove |
| E2 | "Ashgrove wants 40% of member service on digital channels by 2028. What should that mean for how complaints are handled?" | CO | [grounded] The strategy points you were sent, in the grounding brief | Ask first what counts as member service in the 40% and where complaints sit in it. Then which complaint types a member could start and finish digitally and which need a person, what a digital route must still give a member (one owner, a reply in plain words), and how you would measure it by channel. Name risks, such as members who cannot or will not use digital. Claim no digital work; F9 has its own slot | The CO question that touches the JD's digital line. CO because it tests whether you can think at Ashgrove's altitude, with CASE delivery |
| E3 | "How would you build a monthly complaints report that senior leaders would actually read?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Think aloud: who reads it and what decision it supports; the few measures that matter and the trend against earlier months; what you would flag as unknown. If you draw on your own work, say "I built the monthly complaints spreadsheet our regional manager uses" and stop; what it counted is A5's slot | F3 and F7 meet in this case. CASE because it asks for a design, not a history |

### Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| Y1 | "What would you want this role to have changed in the first 90 days, and in the first year?" | It asks your manager to define success, which is the real scoring sheet for a lead |
| Y2 | "Which complaint types or channels worry you most today?" | It shows you are already thinking about where the work is, and it answers where to start |
| Y3 | "How do you see the split between this role, the branch managers and the contact centre lead?" | It surfaces the seams you will have to work across, and they are the JD's own scope |
| Y4 | "How will the move to 40% digital service and the hubs plan change what this role owns?" | It ties the role to the strategy brief and invites the manager's view, not a recitation |
| Y5 | "Where would you expect someone new to this seat to struggle first, and what support is there?" | It invites candour about the learning curve, which suits a candidate with stated gaps |

## Round 3 — panel of two branch managers, 60 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the four published values | high — the recruiter says the panel is the values round and scores against the four values | One story or scaffold per value (cheat sheet below); "we" for context, "I" for contribution |
| Case / Strategist | A live complaint escalation, 20 of the 60 minutes | high — the recruiter's own words name the case and its length | Clarify, structure, answer; think aloud; the real case will differ, so rehearse the structure, not the content |
| Peer Evaluator | Seams, collaboration, "what do you need from us" | medium — the JD's coaching line makes these branch managers the people whose supervisors the role would work with; that link is this pack's derivation | Offer seam principles and ask, never pretend to know their seam; show reciprocity |
| Skeptic | Quiet probing of the same gaps in a collegial register | low — scoring here is against values and the case, but gaps return in collegial packaging | Same plain acknowledgment and plan as D1 |

### Values / Behavioral bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | No quoted sentence carries a decision made from a member's side, so this is a selection scaffold. Pick one decision where you can name what the member needed, the easier option you did not take, who bore the cost, and which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you handled the branch's formal complaints log. Or say how you would decide such a case | Value one, "Members First, Always". F1 supplies only the nearest sentence. VAL because the panel scores it against the published value |
| G2 | "Tell me about a time you had to explain something to a member more than once." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | No quoted sentence carries this, so it is a selection scaffold. Pick a time where the first explanation did not land, say what you changed in the words and what happened next, with nothing you cannot repeat. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you trained new tellers on the escalation script, which does not say it was about wording, so say only that. Or say how you would fix an explanation that failed | Value two, "Plain Words". F4 supplies only the nearest sentence. VAL because it is scored against the published value |
| G3 | "Tell me about a time you treated a member in your branch as a neighbour, not a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | No quoted sentence carries this, so it is a selection scaffold. Pick one situation where you can name what the member's circumstances were without identifying them, what you did and which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you spent the last three years as a branch supervisor. Or say how you would handle it | Value three, "Neighbours, Not Numbers". F4 holds the only branch-level sentence. VAL because it is scored against the published value |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | No quoted sentence carries a problem followed to its end, so this is a selection scaffold. Pick one problem you found yourself and say each step you personally took, who else was involved, how it ended and what stayed unsolved. If no such problem comes to mind, say so plainly, then give the nearest thing your material does carry: you handled the branch's formal complaints log. Or say how you would hold a problem to its end | Value four, "Own the Fix". F1 supplies only the nearest sentence. VAL because it is scored against the published value |

### Case / Strategist bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member has complained three times in a month about the same problem, and the branch supervisor has escalated it to you. Walk us through what you do." | CASE | [generic] | Clarify first: what happened each time, what the member has asked for and been told, whether any deadline is running on the complaint, and whether the supervisor has already said anything to the member. Then the objective: settle it for the member and stop it recurring. First move: one named owner, and tell the member who and by when. Reply in plain words; find why it came back; close the loop with the supervisor. Say the setup will differ from the panel's real case | The recruiter says the case is a complaint escalation. This setup is the pack's own, not Ashgrove's, so rehearse the structure. CASE because it scores structure; it uses the four values without asserting a past |
| H2 | "Now the first complaint came in through the contact centre, and the branch only heard about it on the third. What changes?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Ask, do not assert: what the contact centre recorded, what the member was told, and where the hand-off lost the history. Propose one record the complaint follows, whichever door it came through. If pressed on how the contact centre works, say plainly "I haven't worked in a contact centre", then what you would ask to see | F2 is where the gap shows inside a case. CASE because it extends H1 with the JD's two-channel scope |
| H3 | "The supervisor handled it badly in front of the member. How do you coach them?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Think aloud: talk soon and in private, start by asking what they saw and were trying to do, agree one change, check back later. Your material carries tellers, not supervisors, so if asked whether you have done this, answer from what you did, in your own words | F4 is the nearest material to the JD's coaching line, and branch managers have a stake in the answer. CASE because it asks for a method, not a history |

### Peer Evaluator bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Where is the seam between your role and a branch manager's on an escalation, and what happens when we disagree?" | JD | [generic] | Do not pretend to know their seam. Offer principles and ask which they already work to: who the member hears from, who decides what is offered, how a disagreement gets settled quickly. If asked for a time you disagreed with an equal, pick one where you held a position and kept the relationship; if none comes to mind, say so plainly | The JD makes branch managers your working partners. JD because it scores the coaching and escalation lines; peer delivery |
| J2 | "Eight branches are becoming five hubs over 2027. What should that mean for how complaints are handled?" | CO | [grounded] The hubs point from the strategy points you were sent | Stay neutral and respectful, because this panel may be affected by the change. Ask what has been decided and when, then principles: a member should not have to retell a complaint, a complaint keeps one owner through the change, and local knowledge counts, in line with the value "every branch is part of its town". Offer no view on the plan itself | The CO question for branch managers and the only one that touches the hubs. CO because it tests strategy fluency; Peer delivery |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Why would a branch supervisor listen to you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from what the sentences carry: you spent the last three years as a branch supervisor, and you trained new tellers on the escalation script. Say what coaching would look like for you in the future tense: ask what they saw, agree one change, check back. Answer slot: expect a probe on what your training of the tellers involved. If you can say what you did, say it in your own words; if you do not know, or how it was run was not yours to decide, say so plainly and stay with the sentence | F4 is where a branch panel will press. JD because it scores the coaching line |
| K2 | "Which of our four values would be hardest for you to live up to?" | VAL | [grounded] Ashgrove's published values, as you pasted them | Answer honestly. The pack's observation is that none of your sentences, as given, carries a story for any of the four, so choose the one where your own examples are thinnest, say so, and say what you would do about it. Do not answer "none" and do not pick the safest | Honest self-assessment is what a Skeptic scores. VAL because the four values are the scoring sheet |

### Values cheat sheet

Detected because the recruiter says the panel scores against the four values. None of your sentences carries a story for any value as given, so each row is a selection scaffold whose honest branch is the nearest sentence.

| Value (official name) | Working meaning | Mapped story or scaffold | Rehearsed in |
|---|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | Scaffold ending in its honest branch (G1); nearest sentence, F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | G1, H1 |
| Plain Words | If a member needs it explained twice, the wording was wrong | Scaffold ending in its honest branch (G2); nearest sentence, F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | G2, H1 |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold ending in its honest branch (G3); nearest sentence, F4: "6 years in retail banking, the last 3 as a branch supervisor." | G3, J2 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold ending in its honest branch (G4); nearest sentence, F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | G4, H1 |

### Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| Z1 | "Which part of the escalation route works well for your branch, and which part would you change first?" | It asks them for their own experience of escalations, which is the case's subject |
| Z2 | "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" | The reciprocity question; it shows you are thinking about what you bring them, not only what you need |
| Z3 | "As eight branches become five hubs over 2027, how do you want complaints from your members handled during the change?" | It takes the hubs plan seriously from their side of the counter without offering a view of it |
| Z4 | "Which of the four values do you see most in your best supervisors?" | It shows you are listening for stories, not slogans, and it hands you their scoring language |
| Z5 | "How would you want to hear about a complaint pattern affecting your branch, and how fast?" | It sets the working rhythm between you and the branches before you have it |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 complaints process across branches | A1, C2, D2, G4, H1 |
| F2 the contact centre | B1, D1, H2 |
| F3 monthly reporting | A5, C3, E1, E3 |
| F4 coaching supervisors | C1, H3, K1 |
| F5 regulated complaints | D3 |
| F6 four or more years | A4 |
| F7 presenting to senior leaders | B2, D4 |
| F8 Excel reporting | A5, E3 |
| F9 digital teams | C4, E2 |
| The four values | G1, G2, G3, G4, K2 |

Your material gives no headline figures beyond tenure (F6), so no defend-the-number row was written. One will be added if you share a figure.

## Prohibited claims

Built from the fit snapshot before the question banks were written. Each entry is not coached in any round.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log. D2's slot stays inside the log |
| Worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says a spreadsheet, not what it counted. A5's slot asks only what it counted |
| Presented complaint results to the regional manager | Inflated form of F3 | F3's quote at its own scope: you built the spreadsheet the regional manager uses, which does not say you presented it |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says tellers, not supervisors. K1's slot stays inside the training of the tellers |
| Wrote or designed the escalation script | Inflated form of F4 | The quote's own word: "our escalation script" |
| Handled regulated complaints | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says a formal complaints log. D3's slot asks only what "formal" meant |
| Presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description you pasted; Ashgrove's four values as you pasted them, copied on 25 November 2026 from the values page; the recruiter's email on the process; the four strategy points you were sent from Ashgrove's July 2026 strategy brief; your four-sentence background in your message. The recruiter's email establishes the loop: three sessions, who runs each, and the case. No tuesday-dossier.md was present.

No searches or fetches were sent. The values page named as the source of your pasted text was not fetched.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values fix the cheat sheet and the VAL questions; a search could not have changed them |
| 2. Ashgrove interview process, member service roles | skipped | The recruiter's email fixes the three sessions, who runs each and the case, which fixes the persona weights and the values-round placement |
| 3. Ashgrove strategy and recent news | skipped | The four brief points you were sent, from July 2026, fix the CO questions and the grounding brief |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name has been assigned, so there was no query to form; the upgrade menu says what a name would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your full CV, or a longer account of the complaints work → more quoted sentences, so F1, F3, F4 and F5 can move from answer slots to mapped stories
- Your own answers to the four slots a recruiter or manager is likeliest to probe (what the spreadsheet counted, what "formal" meant in your log, what your training of the tellers involved, any contact with a digital team) → F3, F4, F5 and F9 and their bank rows
- Your pay, notice, location and reason for leaving in your own words → A6 to A9 become your quoted words
- Interviewer names, once assigned → an interviewer read, persona weights from their public footprint, and reverse questions tied to their paths
- Anything the recruiter tells you about the round-3 case, such as format or materials → H1 to H3 move from a generic structure to the real one
- How many hours you have before 4 December → a prep triage in priority order
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → loop reports for member-service and complaints roles, recent leadership or structure changes at Ashgrove, and more of the strategy brief beyond the four points you were sent
- A tuesday-dossier.md → verified evidence and a prohibited-claims list that would replace the one built locally in this pack
