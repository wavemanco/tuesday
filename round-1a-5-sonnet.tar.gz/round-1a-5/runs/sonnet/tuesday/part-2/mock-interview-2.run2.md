Web search was denied, so I'm building the pack from your JD and background alone. Writing the pack file now.
Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles and six reverse questions. It also has a table of claims it won't coach, and it covers every line of the JD.

I built it for a hiring-manager round, since you didn't say who you're meeting.

Web search was denied, so nothing in it comes from research into Atlas Freight. Company-specific lines are labeled generic. Interviewer weights follow a standard hiring-manager pattern, not Atlas's actual process. The upgrade menu says what allowing search would add.

The highest-value prep is question B2: "twelve supervisors across four sites, and you're over three today." Expect it in some form. The next most likely probes are terminal operations, Power BI, and how many of your seven years were leadership. The pack gives you honest wording for each. For Power BI, the wording is "I have never used Power BI," followed by a plan.

Say the word and I'll play the Skeptic on B2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, or convert the pack to Word.

Who are you meeting first (a recruiter, your future manager, or a panel), and has anyone told you what they'll focus on or asked you to prepare anything?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Built for a hiring-manager round, since your note didn't say who you're meeting. Interviewer: unknown. Web search was not available, so nothing here rests on research into Atlas Freight; every company-specific line is labeled `[generic]` and the upgrade menu says what research would add.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values or principles, not generic virtue |
| EXP | Whether the claims on your background survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. It has two honest branches: say how you did it, in your own words, or say plainly that there was no such step or it was not yours, and return to what your own words already carry.

The highest-ROI prep in this pack is B2, the jump from three supervisors to twelve across four sites. It will be asked in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and one site's surge plan, not terminal operations and not four sites, with nothing inspected behind it. The words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on multi-site work likely. If any of your work spanned more than one site, say which and how, in your own words; if none did, say so plainly and stay with the site you work in |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material carries a mis-pick figure, not on-time performance or cost per shipment, and the bridge does not stretch it. Answer slot: the JD names both measures, so expect a probe on what you tracked. If you tracked either, say what and how it was counted; if you tracked neither, say so plainly and return to the mis-pick work |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. The words stay there: "I'm a senior shift manager over 3 supervisors." Answer slot: the JD's twelve makes a probe on span likely. If you have led more than three people at any point, say how many and in what role; if not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD (Excel) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" does not show that you built reporting others used. Answer slot: if you built reports in Excel, say what they showed and who used them; if you did not, or no one else used them, say so plainly and say what you would build first |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would reach working level, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your seven years are in operations; your material does not show how many of them were in a leadership role. Answer slot: if you held a leadership role for part of the seven, say which years and what role; if fewer than five of them were leadership, say the number plainly |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the plus in role-relevant terms: "I'm green belt certified." No certificate was inspected, so expect a probe on the program. Your material says nothing about Lean practice beyond the belt, and does not link the belt to any project |

## Persona table

Weights rest on a pattern, not on Atlas Freight's documented process: no loop source was read, so the pack falls back to the Generic archetype (screen, hiring manager, panel; flat weights) and tilts it by the hiring-manager prior in `personas.md`. If you tell me who you are actually meeting, every bank reweights.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: diagnose on-time, break down cost, standardize across sites | High. A hiring manager is buying capability against the JD's own measures, and the JD is operations-heavy. 5 questions | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of the gaps: scale, terminals, Power BI, years of leadership, why now | High. The hiring-manager prior pairs Case with Skeptic, and F1, F3, F5 and F6 are the rows a skeptic reads first. 5 questions | Rehearse the most predictable objection until it is boring; bridge only from what you stated; say the limit plainly |
| C. Data-Driven Prober | Line-by-line on your numbers: how counted, what it is sensitive to | Medium. The role is measured on two metrics and you have one headline figure. 3 questions | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name the assumption you would defend least |
| D. Pressure | Interrupts, time-boxes, asks how much was actually you | Medium. A manager of twelve supervisors is tested on composure. 3 questions | Pause, restate, anchor in your own words, hold through two follow-ups, then concede only what is real |
| E. Peer Evaluator | Seams between sites, disagreement with equals, credit | Low to medium. A site-peer may sit on a panel. 2 questions | Reciprocity framing; propose principles, not a seam you have not seen |
| F. Conversational | Friendly openers that are still scored | Low to medium. Every loop opens with one. 2 questions | A pre-scripted 90-second arc; treat casual questions on JD topics as scored |
| G. Values / Behavioral | Scenario probes, STAR-shaped | Low. No values-style round is detected: no loop source was read and the Generic archetype carries none. 2 questions | "We" for context, "I" for contribution; pick a story where the hard truth landed, or say none comes to mind |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose on-time performance drops at one of the four sites. What do you need to know first, and how do you structure the first week?" | CASE | [generic] | Clarify before structuring: how on-time is defined, which lanes and shifts, when it began. Then objective, segmentation by site, shift and customer, approach, the measures you would watch, the risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's on-time requirement (F2) asked as a decision. CASE because it scores structure over the right answer |
| A2 | "Suppose cost per shipment is rising while volume is flat. How would you break it down?" | CASE | [generic] | Define the measure first, then split it: what is in the numerator, what moves the denominator, which sites and lanes differ. State what you would check before acting, and what you would not conclude from one month. No claim about your past | The JD's cost-per-shipment line (F2) as a diagnostic. Likely because it is the second of the role's two headline measures |
| A3 | "Suppose the four sites run the same process four different ways. Where do you start standardizing, and where do you leave it alone?" | CASE | [generic] | Measure variation before changing it; standardize where variation costs on-time or cost; leave alone what a site does differently for a reason you can name. Name a Lean or Six Sigma tool only if you have actually used it. No claim about your past | Covers the multi-site line (F1) and the Lean plus (F7). CASE because the answer is a method |
| A4 | "Design the weekly operations report you would give the four site leads. What is on it, and what would you build it in?" | JD | [grounded] "solid Excel" | Design on paper first: the audience, the decision each measure drives, the cadence, the JD's two measures. If asked about tooling, your material says "solid Excel", so say Excel in those words. Answer slot: the JD lists reporting, so expect a probe on what you have built. If you built reports in Excel that others used, say what they showed; if you did not, say so plainly and describe what you would build first | The reporting requirement (F4). JD because it scores the stated requirement, CASE in delivery |
| A5 | "Suppose one supervisor's team misses on-time targets three weeks running while the other sites hit theirs. What do you do?" | CASE | [generic] | Establish facts before judging; separate a process cause from a performance cause; a conversation before a plan; a support plan with a review date; the point at which you escalate. No claim about your past | The twelve-supervisor line (F3) as a live problem. Likely from a hiring manager who has to trust you with other managers' people |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why this role, and why now?" | JD | [generic] | Selection scaffold: pick a reason that is true for you and that points toward the job, not away from your current one; it needs a specific thing about this role you can name from the JD's own words. Name a fact about Atlas Freight only if you have read it yourself on their own site, because this pack could not. If no reason comes to mind, say so plainly, then give the nearest thing that is true for you | The standing skeptic probe: motivation consistency. No claim about your history, so no fit row |
| B2 | "This role has twelve supervisors across four sites, and you're over three today. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI prep in this pack. Say it once, calmly, from the quote: "I'm a senior shift manager over 3 supervisors." Name the limit before they do. The pack's observation is that your material shows three supervisors, not twelve and not four sites (F1, F3). Answer slot: if you have led more than three people or worked across more than one site at any point, say which, how many and in what role, in your own words; if not, say so plainly and stay with the three. Follow-up one and two: hold by returning to the sentence, never by adding to it. Then concede in specifics: if twelve across four sites is larger than anything you have led, say so plainly, then give the plan as a plan, what you would learn first and who you would meet first | F3 is the gap this objection presses hardest, F1 compounds it. Deepest rehearsal because it will arrive in some form and a calm, specific concession changes the interview. JD because it scores the stated requirement |
| B3 | "Your background reads warehouse and distribution. How would you handle terminal operations?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote at its scope: "I have 7 years in warehouse and distribution ops." The pack's observation is that your material does not show terminal operations (F1). Answer slot: terminal operations are the JD's own words, so expect a probe on what carries over. If any of your work involved freight moving through a terminal, say what; if none did, say so plainly, then give a plan for learning how a terminal's day runs, as a plan | F1 again, the other half of the experience gap. EXP in delivery, JD in what it scores |
| B4 | "The role builds reporting in Excel and Power BI. Where are you on Power BI?" | JD | [grounded] "never used Power BI"; "solid Excel" | Say it first and plainly, in your own words: "I have never used Power BI." Then Excel at the scope you stated: "solid Excel." Then how you would reach working level, said as a plan. Name no course, project or date you have not committed to. Do not offer a claim that Excel skill transfers; let the interviewer judge that | F5 is a stated gap and F4 is thin; the honest candor is the answer. Rehearsed so the first sentence is not defensive |
| B5 | "The role asks for 5+ years of operations leadership. Which of your seven years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: the years and the role titles are yours to give, in your own words. If part of the seven was leadership, say which years and what role; if fewer than five were, say the number plainly. The quotes carry seven years in operations and a current role over three supervisors, nothing about the years before | F6. Likely because "required" in a posting is often screened literally. JD because it scores a stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The sentence carries the figure and the redesign. Answer slot: say how the 40% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of the work was yours, each in your own words. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F2's only figure, and the headline number on your background. EXP because it tests whether the number survives scrutiny |
| C2 | "On-time performance and cost per shipment are this role's two headline measures. What have you tracked?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you tracked, from your own work; the quote carries mis-pick rate. Answer slot: if you tracked on-time performance or cost per shipment, say what and how it was counted; if you tracked neither, say so plainly, return to the mis-pick work, and say what you would track first | F2. The question's premise is the JD's, and the guidance does not adopt it |
| C3 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The sentence carries the plan, the site, and two years running; tell those in your own words. Where a probe goes past the sentence, answer from what you did and say plainly what was not yours. The pack adds nothing about what the plan contained | Your one planning example, and the likeliest follow-up after the number. No fit row, since the JD does not mention peak |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "never used Power BI" | Pause and restate the question. Offer the three quotes at their own scope, in that order, in your own words. Hold through two follow-ups by returning to them. Concede only what is real: "I have never used Power BI." Then return to the quotes. Say nothing about the internal candidate | Pressure tests composure on an unanswerable comparison. F5 supplies the one sourced concession |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold on the sentence: the redesign of the pick path is the part the quote states. Answer slot: if any part of the work was someone else's or a team's, say which part and whose; if all of the redesign was yours, say that. Do not widen the claim under a second follow-up, and do not fold on the core claim to restore harmony | F2's figure under a pressure delivery. Attribution is the probe |
| D3 | "Green belt: which program, and what did you do with it?" | JD | [grounded] "green belt certified" | The sentence carries the credential at its own scope: "I'm green belt certified." Answer slot: the JD lists Lean/Six Sigma as a plus. Say which program and who issued it; if you applied it to a project, say which one; if you did not, or the pick-path work was separate from it, say so plainly. Do not link the belt to the pick-path redesign unless that is true | F7. The pack does not know whether the belt and the pick-path work were connected, so it is an answer slot |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Suppose two sites both need the same resource on the same day. How do we decide, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a seam you have not seen: what you would ask first, what the shared measure is, who decides when two site leads disagree, and how you keep the relationship afterward. Reciprocity: what you would offer the other site. No claim about your past | F1's four sites, from the peer's side. CASE because it is a live problem |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams and your part was real but not the whole; it needs a named stake and a clear split of who did what. Say "we" for the shared result, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for peer evaluators. EXP because it tests what you actually did, though no row fits |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc, in your own words, built only from these five sentences at their own scope: the seven years, the current role, the pick-path result, the surge plan, the belt. Add no titles or dates the quotes do not give; supply them from your own history if you want them. End on why this role, not on a summary | F3, F6 and F7 carry the arc's spine. The opener is scored, and a rehearsed arc buys economy |
| F2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | The quote carries the belt, not current practice. Answer slot: if you use a Lean or Six Sigma tool at work now, say which and where; if you do not, say so plainly and say what you would look at first in the first month | F7. A casual question on a JD plus is still scored |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the truth was unwelcome and landed anyway; it needs a named stake, a moment you did not soften it, and an intact relationship at the end. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for values rounds. No company values were read, so this is themed by the persona, not by Atlas Freight's own principles |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the metric and the customer pulled apart, with a real cost to you on one side; name what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; freight has customers and internal measures, so the tension is plausible, though this pack makes no claim about Atlas Freight |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B2, B3, E1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, A5, C2 |
| "lead a team of 12 supervisors" | A5, B2 |
| "build reporting in Excel/Power BI" | A4, B4 |
| "5+ years operations leadership required" | B5, F1 |
| "Lean/Six Sigma a plus" | A3, D3, F2 |

Every headline figure on your background has a defend-the-number question: C1 and D2.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of the four sites is closest to where you want on-time performance to be, and what is it doing differently?" | Shows you think across sites rather than from one, and gives you a first place to look |
| R2 | "How is cost per shipment defined here, and how often is it reported?" | The JD names it, and the definition decides what your first reporting job would be |
| R3 | "What does reporting look like today: what lives in Excel, what lives in Power BI, and who builds it?" | Asks about the tools openly, which turns the Power BI gap into a question about onboarding and lets you ask what a first month would involve |
| R4 | "Of the twelve supervisors, how many are new to the role, and what support do they get?" | Shows you are thinking about the team's shape, not just the title |
| R5 | "What would the four site leads say they need most from this role in the first month?" | Asks for the first month in the site leads' terms, not the interviewer's |
| R6 | "How does the operation plan for its busiest weeks, and where would this role plug into that plan?" | Gives you a way to talk about planning rhythm without presuming how Atlas does it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has 5+ years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: seven years in operations, a current role over three supervisors. The limit is the pack's observation: the material does not show how many years were leadership. B5's slot stays inside that |
| Has led twelve supervisors, or led across multiple sites | Inflated form of F1 and F3 | "I'm a senior shift manager over 3 supervisors." The limit is the pack's observation. B2's slot asks only about your own history |
| Has run terminal operations | Inflated form of F1 | F1's quotes at their own scope. B3's slot asks only what of your work involved freight through a terminal |
| Improved on-time performance or cut cost per shipment | Inflated form of F2 | F2's quote at its own scope: the mis-pick figure. C2's slot asks only what you tracked |
| Has built reporting or dashboards others rely on | Inflated form of F4 | "Solid Excel." A4's slot asks only what you built, if anything |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I have never used Power BI." Then a plan, never a past |
| The green belt produced the pick-path result | Inflated form of F7 and F2 | F7's and F2's quotes, each at its own scope, unlinked. D3's slot asks only whether the two were connected |

## Sources

Provided documents: the job description text you pasted (a one-paragraph summary of the posting), and the background summary in your message. Nothing else was provided. No dossier was present.

Searches sent, all refused (the host did not grant search permission):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have decided whether a values cheat sheet exists and supplied the principles by name; with it missing, the VAL questions are themed by persona stems and labeled `[generic]` |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have established the loop and the persona weights; the pack falls back to the Generic archetype, said plainly in the persona table |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have fed CO questions and a grounding brief; the pack has none |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search allowed → the three refused targets run: Atlas Freight's published values (decides whether a values cheat sheet exists), its documented loop (replaces the Generic-archetype persona weights), and a strategy sweep (adds CO questions grounded in current priorities)
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, once search is allowed → a strategy brief and recent-org-context for the CO bank
- Who you are meeting and their relationship to the role → every persona weight recomputed and banks added or dropped
- The interviewer's name → an interviewer read from their public professional footprint, and a reverse question tied to their own path
- The recruiter's prep email or any stated focus areas → coverage of any pre-declared deliverable, and the weights tuned to what they said
- Your answers to the slots in F1, F2, F3, F4, F6 and F7, said in your own words outside a drill → those rows become quoted evidence and the guidance upgrades from answer slots to story maps
- The full posting text rather than the one-paragraph summary → more requirement rows, and `[inferred]` and `[generic]` lines become `[grounded]`
- Your CV, not only the one-paragraph background → more quotes for the evidence column, and defend-the-number questions on every figure it carries
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and any prohibited claims carried in; the pack does not need it
- How much prep time you have before next week → a prioritized schedule sized to it
