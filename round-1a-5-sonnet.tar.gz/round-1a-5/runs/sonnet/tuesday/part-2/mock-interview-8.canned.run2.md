Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-8-canned-4f6dfa57/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as three round-by-round mini-packs on one shared fit snapshot. It has about 32 questions, five reverse questions per round, and a values cheat sheet for the panel. I ran no web searches. Your values text, the recruiter's email, the JD and your summary of the strategy brief already covered everything a search could have changed.

- **Biggest prep item:** question 2B2, "You've never worked in a contact centre. How would you own complaints there?" The role owns complaints "across branches and the contact centre", so expect it in some form in all three rounds. The pack gives you a plain opening line, a plan, and a hold-then-concede answer for the follow-ups.
- **Second gap:** presenting to senior leaders. It gets the same treatment, in 1B2 and 2B3.
- **Values tension:** "Neighbours, Not Numbers" sits awkwardly with a role that reports volumes and resolution times every month. Panel question 3C3 is built to test exactly that.
- **Where your material is thin:** the JD says "regulated complaints", "coach supervisors" and "Excel". Your sentences say "formal complaints log", "trained new tellers" and "spreadsheet". The pack uses your own words and marks each of these as an answer slot. Fill them in only if they're true.

Say the word and I'll play the hiring manager on 2B2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

Two things would sharpen it:
1. Can you paste your CV? The 3C1–3C3 values stories are scaffolds because none of your sentences carries them yet.
2. Did the recruiter say whether the 20-minute case comes with material beforehand or is cold? If there's a pre-read, I'll add a build section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of all three rounds:** 4 December 2026. **Mode:** loop — three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | Who | Length | What the recruiter said it is |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Opening conversation |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; "the values round — they score against the four values" |

Interviewer names are not assigned yet, so there is no interviewer read. Persona weights rest on each round's relationship and on the recruiter's description of it, and the reasoning is shown so you can change it.

**The highest-ROI prep in this pack is question 2B2**, the contact-centre gap. The role is to own complaints "across branches and the contact centre", and your material says you have never worked in a contact centre. It will be asked in some form in rounds 1, 2 and 3. Rehearse it until it is boring.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did. Wording marked "pending your approval" is proposed language. Change anything that is not how you would say it.

Question IDs read round, persona letter, number (so 2B2 is round 2, Skeptic, second question). Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, G Data-Driven Prober.

| Type | What is being scored |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether what you say you did survives follow-up, and exactly which part was yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Where it says "if you did this, say how; if not, say so plainly", both branches are good answers. The honest branch is a limit, not a confession.

## Fit snapshot (shared by all three rounds)

Evidence is quoted from your message and nothing else. Where the material says nothing, the cell says `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but your own words with nothing inspected behind them, so expect a probe. Lead with it in its own terms: you have six years in retail banking, the last three as a branch supervisor |
| F2 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and a teller script, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the steps around the log likely. If any step before or after the log was yours, say which and what you did, in your own words; if the log was the whole of your part, or the other steps were not yours, say so plainly and stay with the log |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim that branch complaint handling is the same work |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The log is formal, and your material does not show what rules applied to it. Answer slot: the JD's requirement on complaints experience makes a probe on what governed your log likely. If any rules, deadlines or reporting duties applied to the complaints you logged, say which, in your own words; if none did, or you did not deal with them, say so plainly and stay with the log you kept |
| F5 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan. Never a description of a presentation to senior people |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, and the JD says Excel. Answer slot: if you built it in Excel, say so; if it was another tool, say which, plainly. The sentence itself stays whole: "I built the monthly complaints spreadsheet our regional manager uses." |
| F7 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence shows a monthly complaints sheet, not what it counted. Answer slot: if it showed volumes or resolution times, say which, in your own words; if it showed something else, or you do not recall, say so plainly and stay with the sheet |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | transferability | Your material says new tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: expect a probe on coaching people more experienced than new tellers. If you have coached a supervisor or a peer on an escalation, say what and how, in your own words; if you have not, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if any of your branch work touched a digital or self-service channel, say what, in your own words; if none did, say so plainly and say how you would start working with a digital team |

## Grounding brief — Ashgrove's 2026 strategy

Built from your summary of the brief Ashgrove published in July 2026. The brief itself was not pasted, so this is as complete as your summary.

| Fact | Source | Provenance | Why it matters for this role |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, via your summary | [grounded] | Self-service journeys are in the JD, and complaint routes will shift channel |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, via your summary | [grounded] | The panel are branch managers, and this change is theirs. Treat it with care and do not guess what it means for any one branch |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief, via your summary | [grounded] | A new product brings new complaint types and a new kind of member |
| Main competitive pressure is app-only banks | 2026 strategy brief, via your summary | [grounded] | A complaint handled badly is a reason to leave, and an app-only bank is the easy place to go |

Use these to sound current, not to recite. Bring one fact to show you read it, then one view of your own.

---

# Round 1 — The recruiter (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly, unstructured; pay, notice, location and reason for leaving arrive as asides | High. A recruiter screen is a Conversational round with logistics, and the risk is treating it as unscored | A 90-second arc for "walk me through the journey". Your own answer on each logistics item. Plain words from the first minute, since "Plain Words" is a published value |
| B Skeptic | Quiet knock-out checks on the two gaps the JD makes obvious | Medium. The JD names the contact centre and senior leaders, and your material has a stated gap on each | Say each gap plainly once, then the plan. Do not defend |

## Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with four beats, each one your sentence's own: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; the escalation script for new tellers; the monthly complaints spreadsheet. Tell them in your own words and do not add a fifth beat. Answer slot: why this role next is yours to give. Say your actual reason, in one or two sentences | The opener sets the frame for the whole screen. F1, F2 and F6 are the evidence it draws on; EXP because it tests what was actually yours |
| 1A2 | "What's prompting you to look for a move?" | EXP | [generic] | Logistics slot. Give your actual reason, in your own words, in one or two sentences. Say what is true, and keep it about this decision rather than anyone you worked with. If you would rather not go into detail at a first call, say so plainly | The reason for leaving is asked in every recruiter screen, and the only safe answer is your own. EXP because it tests consistency of motivation |
| 1A3 | "What interests you about Ashgrove?" | CO | [grounded] | Pick one thing that is actually true for you from the published material: a value by its name, or one item from the 2026 strategy brief. Say it in one sentence and why it matters to you. If nothing comes to mind, say so plainly and give the nearest thing that is true | CO because it tests homework; the four values and the four strategy facts are in the grounding brief. Chosen over a generic question because a recruiter listens for something specific |
| 1A4 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, in your own words | A knock-out logistics check. The JD gives the job's terms; the notice is yours alone |
| 1A5 | "What are you looking for salary-wise?" | JD | [generic] | Logistics slot. Choose between giving your own number and asking for the role's band first; both are normal. If asked what you earn now, you may decline: "I'd rather focus on the range for this role." | Pay is asked in every recruiter screen. The only safe answer is your own |
| 1A6 | "Is where the role is based workable for you?" | JD | [generic] | Logistics slot. Say your own constraints on where and how you can work. The JD gives no location, so if the recruiter has not said where the role sits, ask where it is based | A logistics check; the JD does not state a location, so this is the recruiter's term to supply |
| 1B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the weaker one first and keep it short: "I haven't worked in a contact centre." Then one line of plan, pending your approval: you would start by learning how complaints reach the contact centre and who keeps hold of them there. Then stop. Do not add "but" and a broader claim | A stock Skeptic stem, aimed at F3. JD because it scores a stated requirement |
| 1B2 | "The role presents to senior leaders. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I've never presented to anyone above regional level." Then how you would prepare, as a plan pending your approval. Do not describe a presentation you have not given | F5 is a stated gap, so the premise is yours and the honest answer is short. JD because the requirement is in the JD |

Proposed wording in this table: pending your approval.

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1R1 | "Does the contact centre sit inside this role's day-to-day, or does it sit with another team?" | Settles how much of the role the contact-centre gap actually touches |
| 1R2 | "What will the case in the panel round look like, and is any material shared beforehand?" | A process question that tells you how to prepare for the longest single task |
| 1R3 | "Who reads the monthly complaints report, and who sees it beyond Member Services?" | Shows you are thinking about the audience, which is where your stated gap lies |
| 1R4 | "What does the Head of Member Services most want fixed first?" | Gets the role's real priority before round 2, so your answers there can aim at it |
| 1R5 | "What happens after 4 December, and when do you expect to decide?" | Practical, and closes the call on next steps rather than on silence |

---

# Round 2 — The Head of Member Services (45 minutes, your future manager)

## Persona table, round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | "Tell me about a time…" scenarios | Highest. The recruiter called this round "mostly behavioural" | Pick a real moment for each; "we" for context, "I" for what you did. Where none comes, say so plainly and give the nearest true thing |
| B Skeptic | Probes the gaps a manager is buying, and derisking | High. A hiring manager is paying for capability and checking for gaps, and F3 and F5 are on the page | Say each gap plainly, then the plan. The contact-centre question gets the deepest rehearsal |
| D Case/Strategist | Live problems from the role and the brief | Mid. A manager's prior is case work, and the strategy brief gives live roadmap items | Clarify, then objective, then approach, then measures, then risks. Think aloud |
| G Data-Driven Prober | Reads your own sentences line by line | Low-mid. Your log and your spreadsheet are the two things to probe | Say what the thing was, in your own words, and where it stops |

## Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Tell me about a time you had to tell someone more senior than you something they did not want to hear." | VAL | [generic] | Selection scaffold. Choose a moment with a named stake, a point where you did not back off, and a working relationship intact afterwards. Tell it in the first person for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem from the Values/Behavioral persona, and the JD's senior-leaders line raises it. `[generic]` because it asks for no claim about your past |
| 2C2 | "Tell me about an escalation you handled, and what you would do differently now." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your sentence gives two things: the log, and the teller script. Pick the escalation from the log if one comes to mind and tell it in your own words. Answer slot: if you led any step of it, say which; if it passed to someone else at some point, say so plainly and say what part was yours. The "do differently" half is yours to give | The JD's coaching-on-escalations line raises it; F2 is the evidence. EXP because it tests what was actually yours |
| 2C3 | "Tell me about a time you coached someone through a difficult conversation with a member." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats your sentence states: new tellers, an escalation script. Say that, in your own words. Answer slot: if you coached anyone other than new tellers, or coached through a live conversation, say what and how; if you did not, say so plainly and stay with the tellers | The role coaches supervisors on escalations, and your sentence reaches only tellers. F8 is the row |
| 2C4 | "Tell me about a time you worked with a team outside your own branch." | JD | [generic] | Selection scaffold. Choose a real piece of work that crossed a boundary, with what the other team needed and what you did. If a digital or self-service team was involved, say so; if none was, say so plainly and say how you would start working with one. If no such time comes to mind, say so plainly and give the nearest thing your material does carry | The JD names digital teams and self-service journeys, and F9 has no evidence either way |
| 2B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The same two lines as 1A: name the contact centre first, then the plan; then the presenting line, the same way. The manager will ask which is bigger. Pick one and give a reason, and do not rank them by how well they sound | A stock Skeptic stem, aimed at F3 and F5. Repeated from round 1 because a manager will ask it with more follow-ups |
| 2B2 | "You've never worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI prep in the pack.** Opening, in plain words: "I haven't worked in a contact centre." Then the plan, pending your approval: you would start by learning how complaints reach the contact centre, reading what is logged there, and asking the team where a complaint gets stuck. Follow-up one, "what do you actually know about contact centres?": say what is true, and your material gives nothing, so answer with how you would learn. Follow-up two, "isn't that a big gap for an end-to-end role?": hold and then concede. Agree that it is a gap, concede that you would lean on the contact centre team in the first weeks, and hold your own ground at its own scope: "I handled the branch's formal complaints log." Never say branch complaint work and contact-centre work are the same work | The role is to own complaints across branches and the contact centre, so this objection arrives in some form. F3 is the row. JD because it scores the stated requirement |
| 2B3 | "You'd report monthly to senior leaders. You've not presented above regional level. How would you get ready?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first: "I've never presented to anyone above regional level." Then a plan, pending your approval, for the first month: ask what senior leaders want from the report, ask to see a past one, and agree who reviews your first one before it goes up. Do not describe presenting you have not done | F5 is a stated gap, and a manager is the person who will help close it. JD because it scores the stated requirement |
| 2D1 | "By 2028 Ashgrove wants 40% of member service on digital channels. What happens to the complaints process as that shifts?" | CASE | [grounded] | Clarify first: what counts as a complaint on each channel, and where a complaint is recorded today. Then the objective: one owner and one record per complaint, whatever the channel. Then approach, then measures (volumes and resolution times, by channel), then risks: a complaint that starts in the app and ends at a counter. Think aloud and challenge one premise respectfully. Make no claim about your own past | A live problem from the brief and the JD's self-service line. CO and CASE, because the strategy fact is the setting and the structure is what is scored |
| 2D2 | "Eight branches become five hubs over 2027. What happens to how complaints are handled in a branch town?" | CASE | [grounded] | Clarify first: what is changing for the members in each town, and what stays. Then the objective: a member should not need to explain a complaint twice because a branch moved. Then approach, measures, risks. Link to "Neighbours, Not Numbers" in your own words. Make no claim about your own past | A live problem from the brief, written so the structure is what is scored. CO and CASE |
| 2D3 | "What would you put in the monthly complaints report, and what would you want to know first?" | CASE | [grounded] | Clarify who reads it and what they decide from it. Then the measures the JD names, volumes and resolution times, and what else you would ask for. Think aloud. Make no claim about your own past here; the next question is where your spreadsheet comes in | The JD's reporting line raises it, and F7 is where your material is thin. CASE because it asks for structure |
| 2G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it is, in the sentence's own words, and who uses it. Answer slot: if it was built in Excel, say so; if it was another tool, say which. If it showed volumes or resolution times, say which; if it showed something else, say so plainly. Name the assumption in it you would defend least, in your own words, or say plainly that you do not know how a figure was counted | F6 and F7 are the rows. EXP because it tests exactly what you built, and a Prober reads your own sentence line by line |
| 2G2 | "Tell me about the formal complaints log you handled. How did it work?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Describe the log in your own words: what it held, and what your part was. Answer slot: the JD's requirement on complaints experience makes a probe on what governed it likely. If any rules, deadlines or reporting duties applied to those complaints, say which; if none did, or you did not deal with them, say so plainly and stay with the log | F4 is the row, and F2 is the evidence. EXP because it tests what was actually yours |

Proposed wording in this table: pending your approval.

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 2R1 | "Where do complaints go wrong today: in the branches, in the contact centre, or between them?" | Names the seam the role exists to own, and signals you are thinking end to end |
| 2R2 | "As 40% of service moves to digital, who owns the complaint journey inside the app?" | Ties your role to the brief and to the JD's digital-teams line |
| 2R3 | "How are supervisors coached on escalations today, and where does it fall short?" | Your closest evidence is training tellers on a script, so this tells you the starting point |
| 2R4 | "What support would I have on the contact-centre side in the first three months?" | Turns your biggest gap into a shared plan |
| 2R5 | "What would make you say, in a year, that this role had worked?" | A manager scores how well you listen for their measure |

---

# Round 3 — The panel of two branch managers (60 minutes)

The recruiter says the panel scores against the four values and includes a 20-minute case on a complaint escalation. The case, then, is a third of the time, and the rest is values and working-together questions.

## Persona table, round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | Scenario probes tied to the four values by name | Highest. The recruiter says the panel scores against the four values | One story per value where your material carries one, a selection scaffold where it does not. Speak in plain words |
| D Case/Strategist | The 20-minute complaint-escalation case | High. A fixed 20 minutes of a 60-minute round | Clarify before structuring. Say your structure aloud |
| E Peer Evaluator | "Where's the seam, and what happens when we disagree?" | Mid. This is my judgment, not the recruiter's: the role coaches branch supervisors, who work for these managers, so I treat them as peers in effect. If you know otherwise, tell me and I will reweight | Offer seam principles, not a map. Say what you would bring them |
| A Conversational | A warm opener | Low. One question, since a values round is scored all the way through | A short, true, specific answer |

## Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Members First, Always: tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold. Choose a real decision with a named member or situation, what the alternative was, and what it cost you or the branch. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the published value. VAL because it scores the first of the four values by name |
| 3C2 | "Plain Words: tell me about a time something you said or wrote to a member had to be explained twice." | VAL | [grounded] | Selection scaffold. Choose a real moment, what was unclear, and what you changed so it did not happen again. The value says that if a member needs it explained twice, "we wrote it wrong", so own the first version. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by the published value. VAL because it scores the second value, and the answer will be heard for its own plainness |
| 3C3 | "Neighbours, Not Numbers: you'd report monthly on volumes and resolution times. How do you stop a number hiding a member, or a town?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The tension is real: a monthly report is numbers. Structure the answer: say what the numbers are for, what they cannot show, and what you would add so a branch's story is not lost. Your sentence gives you the sheet, nothing about what it showed. Answer slot: if your sheet or its reading ever hid a member's story, say what; if it did not, say so plainly and say what you would add now | Two of the panel's concerns meet here: the value, and the JD's reporting line. F7 is the row. VAL because it is scored against the third value |
| 3C4 | "Own the Fix: tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your sentence gives the log. Choose a complaint from it if one comes to mind. Answer slot: if a complaint stayed with you until it was solved, say which and how it ended, in your own words; if none did, or it passed to someone else, say so plainly and say how you would keep hold of one now | The strongest value-to-evidence match in your material, and still thin: F2 is the row. VAL because it scores the fourth value |
| 3D1 | "A member raised a complaint at a branch and it was not resolved. They phoned the contact centre and told the story again, and now they are back at the branch. The supervisor does not know whether to log it as new or add it to the old one. Talk us through what you do, starting with what you would want to know." | CASE | [generic] | Clarify first: what the member wants, what has been said and recorded where, and whether any time limit is running. Objective: one owner, one record, and the member does not tell it a third time. Approach: today, who keeps hold of it, and what you would say to the member; this week, what the supervisor needs; later, why the two channels did not talk. Measures: resolution time and repeat contacts. Risks: a duplicate record and a member who gives up. Make no claim about your own past | The panel's 20-minute case is a complaint escalation. `[generic]` because the recruiter gave no case material; this is the pattern the case is likely to follow. CASE because structure is scored |
| 3D2 | "The supervisor says the contact centre should take it, and the contact centre says the branch should. Who owns it?" | CASE | [grounded] | Answer from the value, in your own words: whoever found the problem keeps hold of it until it is solved. Then the practical form: one named owner today, and a rule about who owns a complaint when it moves between channels. Challenge one premise respectfully: ownership should not depend on whose queue it sits in | Raised by "Own the Fix" and by the role's end-to-end line. CASE because it is a live seam problem |
| 3D3 | "Suppose the member says they will move to an app-only bank. What changes?" | CO | [grounded] | The brief names app-only banks as the main competitive pressure. Say what changes in the next hour: speed, a named person, a plain explanation. Do not promise what you could not deliver. Think aloud, and do not turn it into a lecture on competitors | CO because it uses the brief's competitive frame, and CASE because it is a live problem on the same case |
| 3D4 | "Say the first two sentences of your reply to the member, out loud." | CASE | [generic] | Plain Words in practice. Short sentences, no process words, one thing the member needs to know and one thing you will do, and who will do it. If it needs explaining twice, it was written wrong. Proposed wording is yours to write, pending your approval | The panel will hear whether you meet the value you were asked about. `[generic]` because it asks for no claim about your past |
| 3E1 | "You would coach our supervisors on escalations. Where is the seam between you and us, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Offer principles, not a map: the manager owns the supervisor, and you own the escalation standard and the coaching. Disagree in private, first, and by the member's side of the counter. You may say you have spent the last three years as a branch supervisor, in those words. Do not say what coaching you received or gave, because your material does not say | A stock Peer Evaluator stem aimed at F8, and the panel's self-interest. JD because it scores the coaching line |
| 3E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold. Choose a real piece of shared work, what you did, and how credit was shared. Say "we" for the work and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stock Peer Evaluator stem. `[generic]` because it asks for no claim about your past |
| 3E3 | "Our branches change a lot over the next two years. What could you do in your first month that would help us and not add to our load?" | CO | [grounded] | Reciprocity: say what you would bring them before what you would need. A short plan, pending your approval: spend time with supervisors before changing anything, and ask each branch what its hardest escalation is. Do not guess what the change to hubs means for any one branch | The brief's branch-to-hub move is theirs. CO because it reads the brief, and it is a reciprocity question for a peer-like panel |
| 3A1 | "What draws you to a credit union that its members own?" | CO | [grounded] | The JD says "member-owned". Say one thing that is true for you, in one sentence. If nothing comes to mind, say so plainly and give the nearest true thing | A warm opener. CO because it tests whether you know what Ashgrove is |

Proposed wording in this table: pending your approval.

## Values cheat sheet (round 3)

The four values are as published on Ashgrove's values page, copied by you on 25 November 2026. A story is mapped only where one of your sentences carries it.

| Value (official name) | Working meaning | Your mapped story, or a scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, no sentence of yours carries a story: choose a real decision with a named member or situation, what the alternative was, and what it cost. If none comes to mind, say so plainly and give the nearest true thing — 3C1 |
| Plain Words | If a member needs it explained twice, the wording was wrong | Scaffold, no sentence of yours carries a story: choose a real moment something had to be explained twice, and what you changed. If none comes to mind, say so plainly and give the nearest true thing — 3C2, 3D4 |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold, no sentence of yours carries a story: choose a real moment the town or the member mattered more than the figure. If none comes to mind, say so plainly and give the nearest true thing — 3C3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat the sentence states is the log. Whether a complaint stayed with you to the end is an answer slot at 3C4 |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 3R1 | "What escalations are hardest for your supervisors today?" | Names what the role will coach, and shows you will start from their problems |
| 3R2 | "What do you wish the complaints process did differently for your branch?" | Asks for the managers' own view, which is where a peer-like panel is most open |
| 3R3 | "How do you expect the move to hubs to change what supervisors need from complaints coaching?" | Reads the brief without guessing at a branch's future |
| 3R4 | "What does Neighbours, Not Numbers look like in how your branch handles a complaint?" | Asks for the panel's own example of a value they will score you on |
| 3R5 | "What would make you say, a month in, that this role had helped your branch?" | The reciprocity question for a peer-like panel |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| 4+ years in financial-services customer operations | 1A1 |
| Own the member complaints process end to end | 1A1, 2C2, 2G2, 3C4, 3D1, 3D2 |
| Across branches and the contact centre | 1B1, 2B1, 2B2 |
| Experience handling regulated complaints | 2G2 |
| Report monthly on complaint volumes and resolution times | 2D3, 2G1, 3C3 |
| Coach branch supervisors on escalations | 2C2, 2C3, 3E1 |
| Work with digital teams on self-service journeys | 2C4, 2D1 |
| Confident presenting to senior leaders | 1B2, 2B1, 2B3 |
| Comfortable with Excel reporting | 2G1 |
| Pay, notice, location, reason for leaving (recruiter screen) | 1A2, 1A4, 1A5, 1A6 |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log and a teller script, not the process end to end. The slot at F2 stays inside the log |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says a formal log, not what governed it. The slot at F4 asks only what applied to the complaints you logged |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "I trained new tellers on our escalation script." The slot at F8 stays with the tellers |
| Has contact-centre experience | A negative you stated, F3 | The plain acknowledgment F3 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F5 | The plain acknowledgment F5 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description (your message); the text of Ashgrove's values page, copied by you on 25 November 2026 from ashgrovecu.org/about/values (not fetched); the recruiter's email on the process (your message); your summary of the 2026 strategy brief Ashgrove published in July 2026 (the brief itself not pasted); your background (your message). No `tuesday-dossier.md` was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted fixes the cheat sheet and the VAL questions, by name |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the loop: three sessions, who runs each, and what each holds. Persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | Your summary of the July 2026 brief supplies the four current priorities that feed the CO and CASE questions |
| 4. interviewer name and company | n/a | No names were given, only roles, so there was no query to form. The interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the F9 row and any row marked `none given` or `low` could take a quoted sentence, and more of your sentences means more story-mapped answers in place of scaffolds
- The strategy brief itself, pasted → the CO and CASE questions are built from your four-line summary and would be sharpened by the brief's own wording
- The recruiter's answer on whether the case comes with material in advance → a build section for it, if it is a pre-declared deliverable
- The interviewers' names → an interviewer read, persona weights adjusted by their public professional footprint, and reverse questions tied to their paths
- Which complaints rules apply at Ashgrove, from the recruiter or from you → a sharper slot at F4 and 2G2
- Your answers to the slots at F2, F4, F6, F7, F8 and F9 → those rows move from discovery or transferability toward `none`, and the matching questions become story-mapped
- Hours you can give each day before 4 December → a prep triage section, listing the few things worth doing first
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent organisation context, loop reports for this role family, and a fuller grounding brief
- A `tuesday-dossier.md` from an earlier job-underwriter run → verified evidence and a prohibited-claims list from that run, in place of the ones built here
