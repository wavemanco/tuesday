The web searches were refused, so the pack runs without any company research. I'm now writing it from your JD and your background alone.
Femi, your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-7-denied-dd4bd7c7/saltmarsh-games_live-operations-producer_interview_pack.md`. It covers 20 questions across seven interviewer styles, plus a requirement-coverage table, 6 reverse questions and a short prep triage for the next two days.

- **No company research ran.** All four web searches were refused (company values, interview process, strategy, and Tobias). Everything company-specific is generic and labeled that way.
- **Assumption:** I built it as a hiring-manager round, since you didn't say how Tobias relates to the role. That weights case-style and skeptical questions highest.
- **Highest-ROI prep:** the two things you told me you haven't done, which are leading a team and working on a game with in-app purchases (B1 and B2). Rehearse a plain acknowledgment of each, then what you would learn first.
- **Where your material is thinnest:** working directly with design, art, engineering and community (F6). Your material doesn't show it, so the pack gives you answer slots to fill in your own words.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future direct manager, their skip-level or a peer, and did the recruiter mention any focus areas or something to prepare in advance?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. **Format:** 60 minutes, Friday. **Relationship:** not stated. This pack is built as a hiring-manager round, and a different relationship changes the persona weights below.

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Rehearse both, because the same fit question can come as a friendly aside or a time-boxed challenge.
- **Type key:**
  - **VAL**: whether past behavior shows values, not generic virtue.
  - **EXP**: whether your stated experience survives scrutiny, and what was actually you.
  - **JD**: whether you can do the listed job, gaps included.
  - **CO**: whether you know the company and its market.
  - **CASE**: structure and reasoning on a live problem from the role.
- **Guidance is scaffolding, not a script.** Every line about your past rests on a sentence you wrote, quoted in the Provenance column. Where your material is silent, the guidance is an answer slot: an instruction for the interview, with an honest branch for "that wasn't mine" or "that never happened".
- **IDs:** fit-snapshot rows are F1 to F9. Question banks use A to E, then G and H, so no question ID collides with a fit row.

## Prep triage

This is sized to the two days between now and Friday.

1. **B1 and B2.** These are the two things you told me you haven't done. Say each plain acknowledgment aloud until it is boring. This is the highest-ROI prep in the pack.
2. **A1, A3 and A5.** Think aloud through the case structure each time: clarify, objective, options, trade-offs, what you would report.
3. **C1.** Walk through the monthly retention numbers and fill in each answer slot in your own words.
4. **E1.** Time your 90-second arc.
5. **Reverse questions.** Pick three.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, with nothing inspected behind it, and the words stay at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD names two titles, so expect a probe on competing asks. If you ever kept the calendar for more than one title at once, say how you handled competing asks, in your own words; if you kept it for one title only, say so plainly and stay with that |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, your main title, two years |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material states four years as an associate producer and two years on the weekly calendar. Answer slot: the JD's years line makes a probe on what the four years covered likely. If either of the earlier two years involved the same kind of work as the calendar, say what; if not, say so plainly and stay with the two years |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it. Lead with it in the quote's terms: "I presented the monthly retention numbers to the studio head." The line says presented, so expect the probe in C1 on who built the numbers and how they were counted |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly retention numbers is adjacent to owning an event review, and the words stay at presenting. Answer slot: the JD asks for ownership of the review, so expect a probe. If you ran any review of how a drop performed, say what it covered and what changed afterwards, in your own words; if you did not, or it was not yours, say so plainly and stay with presenting the monthly numbers |
| F6 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show work with any of these four teams. Answer slot: if you worked with any of them to land the weekly drops, say which and what you did, in your own words; if you did not, or it was not your part, say so plainly and describe what you did with the calendar |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, and the words stay at that: "I wrote the release checklist our QA team still uses." Answer slot: if others shaped or changed the checklist since, say who and what; if it was yours throughout, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist another team still uses is written work that has been used, at that scope only. Expect a request for something the interviewer can read; the upgrade menu names what to bring |
| F9 | Monetisation literacy for mobile live-ops: a role-family expectation, not in the JD, no source | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Persona table

No loop source establishes the loop, so the weights rest on the hiring-manager relationship prior and the generic archetype (flat tilt), plus one judgment shown below.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist (bank A) | Live problems from the role: schedule collisions, a blocked release, a retention dip | high | Hiring-manager prior; the JD is built around planning and running | Clarify, objective, options, trade-offs, what you would report; think aloud |
| Skeptic (bank B) | Quiet, persistent probing of what is not in your background | high | Hiring-manager prior; you stated two absences (F9) | Rehearse the single most predictable objection until it is boring |
| Data-Driven Prober (bank C) | Line-by-line probing of the retention numbers and KPIs | medium | Judgment from the JD: it names KPIs and retention metrics twice (F4, F5), and a Head of Live Operations may care about them. This is a reading, not an interviewer signal | Know what you can and cannot say about how the numbers were counted; say plainly where you do not know |
| Conversational (bank E) | A friendly opener, then the biography question | medium | Openers are common in any round; the danger is treating them as unscored | A 90-second arc; treat casual questions as scored |
| Peer Evaluator (bank D) | The seam between producer and design, art, engineering, community | low | The JD's coordination line (F6); a head of function is less likely to play peer | Propose seam principles instead of claiming to know their seam |
| Pressure (bank G) | Time-boxed challenges to your motives and your claims | low | No signal the round is a stress round | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (bank H) | Scenario probes on hard truths and trade-offs | low | No source shows a values round | Pick a story that fits, or say plainly that none comes to mind |

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have two titles and one week where both want a big event. How do you decide what runs, and what do you need to know first?" | CASE | [generic] | Clarify first: what each title is trying to move, what is already committed, and how much design, art and engineering capacity the week has. Then state an objective, lay out two or three options, name what each costs the other title, pick one, and say how you would tell the teams. Think aloud and challenge one premise respectfully. This needs no claim about your past, so the guidance makes none | F1's two-title requirement is the part of the role your material is thinnest on, so a live problem tests it directly |
| A2 | "An update ships Thursday and QA finds a blocker Wednesday night. Walk me through your next two hours." | CASE | [generic] | Say who has to know and who makes the call before you say what you would decide. Lay out the options (hold, cut the affected content, ship with a known issue), what each costs players and teams, and what you would write to the four teams. No claim about your past | F7's checklist-with-QA requirement, asked as a decision rather than a document |
| A3 | "Retention dipped after an event. Diagnose it." | CASE | [generic] | Clarify before diagnosing: which retention measure, which players, compared with what, and what else shipped that week. Then give hypotheses and how you would check each, and say what you would report. No claim about your past | F4 and F5: the JD pairs retention metrics with owning the KPIs a review reports |
| A4 | "What would your first 30 days look like?" | JD | [generic] | Say it as a plan, never as a past: what you would read (the calendar, past reviews, the release process), who you would meet, and what you would not change yet. Keep to three to five items and say what you would want to know by day 30 | F6 and F1 are where a new producer's first month matters most |
| A5 | "How would you set up a post-event review so it changes what you run next?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: what the event set out to move, what happened, why you think so, what changes next time, who needs to hear it. Write it so someone who was not in the room could act on it. From your material: "I presented the monthly retention numbers to the studio head." Answer slot: the JD asks for ownership of the review. If you ran any review of how a drop performed, say what it covered and what changed afterwards, in your own words; if you did not, or it was not yours, say so plainly and stay with presenting the monthly numbers | F5 is the JD's ownership line; F8 applies because a review is a written artefact |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. Where does that hurt you first in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment in your own words: "I haven't worked on a game with in-app purchases." Do not pad it or apologise. Then say what you would learn first and from whom, as a plan and never as a past. The calendar line stays at its own scope and does not stand in for monetisation experience. Hold through two follow-ups by repeating the acknowledgment and the plan, never by claiming exposure you did not have. Answer slot: if any part of your studio's work touched how the game earned money, say what you saw first-hand; if none did, say so plainly and stay with the plan | F9 is the objection most likely to be asked in some form, and a rehearsed non-defensive answer changes the interview |
| B2 | "You've never led a team, and this role coordinates design, art, engineering and community on every update. How would you get that coordination to work?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Plain acknowledgment first: "I haven't led a team." Then the coordination at the scope your material carries: you ran the weekly calendar for two years and wrote the checklist QA still uses. Answer slot: the JD names design, art, engineering and community. If you worked with any of those teams to land the weekly drops, say which and what you did, in your own words; if you did not, or it was not your part, say so plainly and describe what you did with the calendar | F6 is the thinnest evidence cell against a requirement the JD lists in full |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick from where your material is thinnest, not where it feels safest. The pack's reading is that your material shows no in-app-purchase work (F9) and nothing on working with design, art, engineering or community (F6). Say your pick in one sentence, say what you would do about it in the first month, and stop. For the first, the words are "I haven't worked on a game with in-app purchases." | F9 and F6; the question is a Skeptic staple, so choosing and rehearsing the answer beats improvising it |
| B4 | "You've run a weekly content-drop calendar for your main title. What changes when it is live events across two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold at the quote's scope: "For two years I ran the weekly content-drop calendar for our main title." Say what carries over and name honestly what is new: two titles, and events. Answer slot: if you ever kept schedules for more than one title or ran anything event-shaped, say what and how; if not, say so plainly and stay with the weekly calendar | F1 and F2 are your strongest row and its limit; the probe is whether the strength transfers |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F4: the numbers were monthly and the audience was the studio head, which are the beats the quote states. Tell them in your own words. Answer slots, each in your own words: how the numbers were counted; what they are most sensitive to; the assumption behind them you would defend least; which part was yours. If you do not know how something was counted, say so plainly. If someone else prepared the numbers and you presented them, say so | F4 is the evidence for the retention requirement and the line a prober tests first; EXP because it tests what was yours |
| C2 | "Which retention measure would you lead with in an event review, and which would you trust least?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Pick a measure you have actually worked with and say what it shows and what it hides. Your material says you presented monthly retention numbers; it does not name the measures. Answer slot: name the measure or measures in those numbers, in your own words; if you do not remember or did not choose them, say so plainly, and name the one you would start with and why | F4 and F5; the JD pairs retention metrics with KPI ownership |
| C3 | "An event ran and retention moved. How do you tell what the event did from what else changed that week?" | CASE | [generic] | Structure: compare against a baseline or a group that did not see the event, check what else shipped, look at seasonality and sample sizes, and say what you could not separate. No claim about your past | F5; a case that scores the reasoning behind a KPI report |

### D. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where does a producer's job end and a designer's begin on an event?" | CASE | [generic] | Propose seam principles instead of pretending to know their seam: who owns what, who decides when two teams disagree, and what you bring them, such as a clearer calendar and earlier warning. Show spine and tact together: say where you would hold and where you would defer | F6; the JD's coordination line, asked as a collaboration scenario |
| D2 | "How do you handle credit when a drop's success spans teams?" | VAL | [generic] | Use "we" for context and "I" for your own contribution. Pick one instance from your material where work spanned teams; if none comes to mind, say so plainly, then describe how you would handle credit | F6 again; credit-sharing probes test partnership fit |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get into producing, and why Saltmarsh?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc of the four quoted beats, in your own words and in that order, stopping at about 90 seconds. Answer slot: why Saltmarsh. Say your own reason in your own words; this pack does not supply one | F2, F3, F4 and F7 are the beats the quotes carry; casual openers are scored |
| E2 | "What are you playing or following in live-service mobile right now?" | CO | [generic] | Name something you have actually played, read or tried, say what you noticed about how it runs its calendar, and stop. If nothing comes to mind, say so plainly and name what you would look at before Friday | F1; a casual question about a hot JD topic is still scored |

### G. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has already run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold on the quote: "For two years I ran the weekly content-drop calendar for our main title." Concede the one thing you stated: "I haven't worked on a game with in-app purchases." Hold through two follow-ups, concede specifically and not generally, and never fold on the calendar just to restore harmony. Claim nothing beyond the quote | F1, F2 and F9; Pressure tests composure on the same gap as B1 |
| G2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold at what the quote says: you wrote it, and QA still uses it. Answer slot: if others shaped or changed it, say who and what; if it was yours throughout, say so plainly. Hold through two follow-ups by returning to the checklist and not adding to it | F7; attribution probes exist to catch inflation, so rehearse the plain version |

### H. Values/Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection criteria: a named stake, a moment you did not soften it, and an intact relationship at the end. Your material says you presented to the studio head monthly; it does not say any month carried hard news. Answer slot: if one did, say what the news was and what happened next; if none did, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4; the only leadership-facing line in your material |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time you made a call for players over a number or a date; it needs a named trade-off and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7; a common values probe in live-service teams, rehearsed because the answer cannot be improvised |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A4, B4, E2 |
| "coordinate design, art, engineering and community teams on each update" | A2, B2, D1, D2 |
| "own the post-event review and the KPIs it reports" | A3, A5, C1, C2, C3 |
| "manage the release checklist with QA" | A2, G2 |
| "3+ years producing live-service games or apps" | B3, B4, E1, G1 |
| "experience running a content calendar" | A1, B4, E1 |
| "comfortable with player-retention metrics" | A3, C1, C2, C3 |
| "clear written communication" | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make you say, ninety days in, that this hire is going well, and what would make you say it is not?" | It gets the scoring bar in the interviewer's own words, which you can rehearse against |
| R2 | "How is the events calendar for the two titles set today, and where do they compete for the same capacity?" | It shows you have already thought about the trade-off in A1 |
| R3 | "What does the post-event review look like now, and which KPIs does it report?" | The JD makes you the owner of both, so asking shows you read the role |
| R4 | "Which team is hardest to get time from on an update, and what has worked so far?" | It treats coordination as a working problem, which is how B2 should sound |
| R5 | "Is there an existing release checklist with QA that I would inherit, and how is it used?" | It ties to the checklist your material carries and invites a concrete answer |
| R6 | "How do monetisation goals shape the events calendar, and what should a new producer learn about that first?" | It turns the F9 gap into a conversation about a learning plan |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title, not live events across two titles |
| Produced live-service titles for three or more years | Inflated form of F3 | F3's quotes at their own scope: four years as an associate producer, two of them on the weekly calendar. B4's slot stays inside the calendar |
| Owned post-event reviews and their KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says you presented the monthly numbers, not that you owned a review |
| Managed releases with QA | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist, not that you ran releases against it |
| Led a team | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |

## Sources

**Provided documents:** the job description as pasted, and your background as you wrote it in your message.

**Searches sent, none returned a result:**

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio strategy news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Nothing in this pack about Saltmarsh Games, its loop, its strategy or Tobias Wrenfield comes from outside the two provided documents.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have moved the values cheat sheet, which is absent, and the VAL bank's themes, which come from persona stems |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Every call was refused. It would have fixed the loop structure; persona weights rest on the generic archetype and the relationship prior |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call was refused. It would have grounded the CO bank in current priorities; E2 stays generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have supplied the interviewer read and a reverse question tied to their path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission, or a pasted careers page, values page or interview-process note → the values cheat sheet, the real loop structure, and CO questions on Saltmarsh's actual strategy; rows 1 to 4 above rerun
- A deeper research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes) → the company strategy brief and the interviewer's published talks, which sharpen the CO bank and the reverse questions
- Your relationship to Tobias Wrenfield (direct manager, skip-level or peer) → persona weights recomputed and the banks reordered
- The recruiter's prep notes, including any presentation or take-home → a build section for each declared deliverable; none is assumed here
- Your answers to the slots in F1, F3, F5, F6 and F7, and in C1 → those rows become story-mapped answers instead of slots
- Your release checklist, and a sanitised sample of a monthly retention deck or weekly calendar → F2, F4, F7 and F8 can rise from medium to high confidence, and F8 gets the written sample the interviewer may ask for
- A tuesday-dossier.md from a job-underwriter run, if you have one → verified evidence and approved prohibited claims; this pack is complete without it
