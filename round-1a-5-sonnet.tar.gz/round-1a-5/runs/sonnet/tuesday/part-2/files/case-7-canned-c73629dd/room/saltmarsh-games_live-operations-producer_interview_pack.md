# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: the 60-minute interview on Friday. Saltmarsh's interviewing page describes it as the Outage Hour, a single 60-minute interview with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation. This pack assumes Tobias is the hiring manager. That is unconfirmed, and the persona weights rest on it.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values |
| EXP | Whether the claims in your background hold up when probed |
| JD | The stated responsibilities and requirements of the role |
| CO | Whether you know the company's current direction |
| CASE | A live problem set in the role, reasoned through aloud |

Answer slots in the guidance are instructions for the interview, not questions for you now. Where a slot offers two branches, either one is a good answer if it is true.

## Prep triage

You have until Friday, so this is sized to Wednesday evening and Thursday. Do these in order.

1. C1, out loud, three times. It is the highest-ROI rehearsal in this pack: the objection you are most likely to hear, and the one where the material is thinnest.
2. A1 and A2, the tabletop. Practise the order of your first moves aloud: clarify, scope, who to bring in, what players are told.
3. B1 to B4. Decide for each whether a real story comes to mind. If one does not, practise the honest branch.
4. D1, the retention numbers: what you can and cannot say about how they were counted.
5. Reverse questions 1 to 3.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says weekly content drops for one main title, not live events and not two titles, so the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two titles make a probe on running more than one calendar likely. If you ever ran or reconciled a second calendar, say how, in your own words; if not, say so plainly and stay with the one title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD names four disciplines, so expect a probe on which of them you worked with on a drop. Say which you did and what you needed from each, in your own words; if some were not part of your drops, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says monthly retention numbers presented, not post-event reviews. Answer slot: the JD's post-event review makes a probe on that likely. If you looked back on a drop and wrote up what happened, say how; if that was not something you ran, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | A real line with nothing inspected behind it, so expect a probe on it. Lead in the quote's own terms: you wrote the release checklist, and your QA team still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The years are stated; your material does not say whether the title was a live service. Answer slot: the JD's live-service wording makes a probe likely. If it was, say what that meant week to week, in your own words; if not, say so plainly and stay with the weekly drop calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it. Lead with it in the quote's own terms: you ran it, weekly, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in wording. Expect a probe on how the numbers were counted, which D1 rehearses |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist touches written communication without showing it. Answer slot: if you wrote drop notes, summaries or player-facing updates, say which, in your own words; if not, say so plainly and stay with the checklist |
| F9 | Working on a game with in-app purchases (role-family, not in the JD) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F10 | Leading a team (role-family, not in the JD) | "Never led a team" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never led a team." The JD asks for coordination (F2), not reports, so keep the two apart |

## Reading the interviewer

Public professional footprint only. The talk entry rests on a search-result summary; the talk itself was not read.

| Fact | Provenance | What it means for you |
|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] GDC 2026 talk listing | A release checklist is native ground for him, so expect depth on F4 and D3. State only what the line says |
| Gave the GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | [grounded] GDC 2026 talk listing | His theme sits next to the published value "Ship the Patch Not the Promise" (B2). Describe your work at exactly the scope it had; an over-claim is the thing his argument is about |
| Mirror opportunity: his QA background beside your F4 line, "Wrote the release checklist our QA team still uses" | [inferred] his path against F4 | Say the F4 line plainly and let him ask about it. Do not claim a shared path beyond the two facts |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event | High. The interviewing page documents the tabletop as the first half of the session, and a hiring-manager round tilts toward live problems | Clarify, then objective, then who to involve, then what players are told, then risks; challenge one premise respectfully | A, 5 questions |
| Values/Behavioral | The values conversation: the three published values | High. The interviewing page documents a values conversation in this session | Choose a story only where one actually fits; "we" for context, "I" for what you did; where none fits, say so | B, 4 questions |
| Skeptic | Quiet probing of the gaps you have stated | Medium-high. Hiring-manager prior, plus two gaps you named yourself (F9, F10) | Rehearse the single most predictable objection until it is boring: name the limit, then the plan | C, 4 questions |
| Data-Driven Prober | Depth on the retention numbers and the checklist | Medium. F7 and F4 are the lines most likely to be read closely, and his public theme is accuracy about what shipped | Know what you can say about how a number was counted, and say plainly what you do not know | D, 3 questions |
| Pressure | Time-boxed answers during the tabletop | Medium-low. The tabletop is a live problem; whether he interrupts is not documented, so this is inferred | Pause, restate, hold the position through two follow-ups, concede specifically | E, 2 questions |
| Conversational | The opening: walk me through your background | Low-medium. Any session opens somewhere; it is still scored | A 90-second arc built only from your own lines | F, 2 questions |

The highest-ROI prep in this pack is C1. It is inferred from your own stated gap and from the Larkspur announcement (Sources); no underwriter named it.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The event servers go down forty minutes into a live event and you are the producer on call. What do you do first?" | CASE | [generic] | Clarify before structuring: what is down, for whom, since when, what engineering already knows. Then name who you would pull in (the JD lists design, art, engineering and community), what players are told and when, and what you will not promise yet. Think aloud and challenge one premise, such as whether the event should keep running at all. The question needs no claim about your past, so the guidance makes none | The interviewing page documents a tabletop on a simulated outage during a live event; the scenario itself is a pattern, not a fact about Saltmarsh. CASE because it scores structure under a live problem. F2 is why the cross-team step is worth saying aloud |
| A2 | "Community is flooded with players asking what happens to their progress and engineering says an hour, maybe more. What do you post, and when?" | CASE, JD | [grounded] | Say only what is known, say when the next update comes, and keep a promise out of the post that engineering has not confirmed. Saltmarsh's published value is "we announce what is built, not what is hoped"; let the post show it rather than quote it. Make no claim about your past | Written player communication is the part of the tabletop that tests F8's requirement, and the published value gives the interviewer a scoring lens. CASE for the delivery, JD for the written-communication requirement |
| A3 | "The event is over. What does your post-event review cover, and what goes in the KPI report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Start from your own words: "I presented the monthly retention numbers to the studio head." Then structure the answer you would build, as a plan: what was planned against what shipped, which measures, what you would change next time. Answer slot: the JD says you own the review and its KPIs. If you ran reviews after drops, say how; if you did not, say so plainly and stay with the monthly presentation | F3 is the JD's headline ownership line with the thinnest quote behind it. JD because it scores a stated responsibility |
| A4 | "From February 2027 both titles share one events calendar. How do you decide what goes on it?" | CO, CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: what shared means, whether the two audiences overlap, what the single team can ship per week. Then objective, constraints, risks, and one premise you would challenge. Start from your own words at their scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ever reconciled more than one calendar, say how; if not, say so plainly and stay with the one title | Project Larkspur (Sources) puts a shared calendar in front of this role, and F1 is the row it presses on. CO because it needs current direction, CASE for the delivery |
| A5 | "What has to be true before an update ships?" | JD, CASE | [generic] | Open with a few conditions you would insist on and why each protects players, then how you would confirm them with QA rather than assume them. Keep it to conditions and method; the question asks about no past, so the guidance makes none | JD because the role manages the release checklist with QA (F4). Generic because it is a pattern for the problem; D3 is where your own checklist comes in |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a time the schedule said one thing and what players reported or did said another, and you held, moved or changed a drop. It needs the named stake, your decision and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | The first published value; no quoted line carries a disagreement, so this is a scaffold, not a story map. F1 is the nearest evidence |
| B2 | "Ship the Patch Not the Promise: tell me about a time something that had been announced turned out different from what shipped." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: pick a time something said to be coming was not ready or came out different, where you told someone or corrected it. It needs what had been said, who you told and what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries, "Wrote the release checklist our QA team still uses", or how you would handle it | The second published value and the theme of his GDC talk. F4 is the nearest evidence and carries no incident |
| B3 | "Leave the Build Greener: every release should leave the checklist better than it found it. Tell me about something you left better than you found it." | VAL, EXP | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote the release checklist, and your QA team still uses it. Tell those two beats in your own words. Answer slot: the value asks what got better. If the checklist changed after releases, say what and why; if you wrote it once and it was not revisited, say so plainly and stay with the checklist | The third published value, and the checklist is where F4 meets it. EXP because it tests what was actually yours |
| B4 | "Tell me about a time you gave leadership a number they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time a number you reported was unwelcome, and say what you showed, how it was received and what happened after. It needs a named stake and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "Presented the monthly retention numbers to the studio head", or how you would handle it | Persona stem for the values interviewer, tied to Players Before Plans. F7 is the nearest evidence and carries no unwelcome number |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Both titles move to a season-pass model next February, and you have never worked on a game with in-app purchases. What do you do in your first month?" | JD, CO | [grounded] "never worked on a game with in-app purchases" | The deepest rehearsal. Name the limit before it is asked for: "I've never worked on a game with in-app purchases." Then a plan, said as a plan: what you would ask to see first and who you would ask, in your own words. Follow-up one, what do you know about it now: answer only from what you have really read or seen; if nothing, say so plainly. Follow-up two, why take the risk: return to your own lines at their own scope, "I ran the weekly content-drop calendar for our main title for the last two years" and "Presented the monthly retention numbers to the studio head", without saying they cover purchase data. Follow-up three, what if it takes longer than a month: concede that it may, and say what you would deliver in the meantime | F9 is your stated gap and the announcement (Sources) puts a purchase-based model in front of the role; this is the highest-ROI prep in the pack. JD and CO because it joins the requirement to current direction |
| C2 | "You have told me you have never led a team. Four disciplines have to hit your calendar's dates. How do you get them there?" | JD, EXP | [grounded] "Never led a team" | Name the limit first: "I've never led a team." Then say how you would work with design, art, engineering and community on dates they do not report to you. Answer slot: if you coordinated any of those disciplines on a drop, say which and what you needed from each; if not, say so plainly and describe how you would start | F10 is your stated gap and F2 is the requirement it presses on; the JD asks for coordination, so the answer stays on coordination |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Selection scaffold: choose from your own honest read, and say why and what you would do about it in the first weeks. This pack observes that your material is thinnest on two titles (F1), the post-event review (F3) and coordination (F2); pick the one you actually believe, not the one that sounds safest. If you cannot pick, say so plainly and give the area you would ask about first | Persona stem for the Skeptic. The thin rows are named as the pack's observation, not as words for you |
| C4 | "Tell me about the game you spent four years on and how its content ran week to week." | EXP, JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" | Say it in your own words at the scope the lines carry: four years as an associate producer at a puzzle-game studio, and you ran the weekly content-drop calendar for the main title for the last two. Answer slot: the JD asks for live-service experience. If the title was a live service, say what that meant day to day; if not, say so plainly and stay with the weekly calendar | F5 is a years requirement that the quote meets in length but not in kind; this question lets the interviewer test the kind |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. Which measures, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start from your own words: "I presented the monthly retention numbers to the studio head." Answer slot for each of these, in your own words: which measures you presented, how they were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. For any of them you do not know, say plainly that you do not know how that was counted | F7 is the metric line a prober reads first. EXP because it tests attribution and honesty about the numbers |
| D2 | "Day-7 retention is down 20 percent the week after an event. Diagnose it." | CASE, JD | [generic] | Clarify before diagnosing: down against what baseline, for which players, since when, and what shipped with the event. Then segment, check for a data problem before a player problem, and say what you would look at first. Name the assumption you would trust least. The question asks about no past, so the guidance makes none | Persona stem for a metric drop, aimed at the JD's retention requirement (F7). CASE because it scores structure |
| D3 | "Tell me about the release checklist you wrote: what is on it and why?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say it at its scope: "I wrote the release checklist our QA team still uses." Answer slot: the JD says you manage the checklist with QA, and his background is QA. Say what is on it and why in your own words; if QA shaped parts of it, say which; if you cannot recall an item, say so plainly | F4 is a line with nothing inspected behind it, and the interviewer's own path (reading above) makes it a likely target |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you as the producer on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses" and "Presented the monthly retention numbers to the studio head" | Pause, restate the question, then hold on those three lines at their own scope and nothing more. Hold through two follow-ups by returning to them, never by adding to them. Concede specifically: "I've never worked on a game with in-app purchases" (source: your message). A concession is not folding | The pack's compact version of F1, F4 and F7 under time pressure. F9 is the concession the interviewer is likeliest to extract |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the line at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names four disciplines. If design, art, engineering or others fed or changed the calendar, say what you owned and what they did; if it was yours alone, say so plainly. Concede only what is true | Persona stem for attribution under pressure, aimed at F1. EXP because it tests what was actually yours |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey: how did you get to live operations?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc built only from your lines: four years as an associate producer at a puzzle-game studio, then the weekly calendar you ran for the main title. Add "Wrote the release checklist our QA team still uses" or "Presented the monthly retention numbers to the studio head" only if they fit your telling. Answer slot: say your actual reason for this role and this studio, in your own words; do not borrow a reason | The opener is scored. F5 and F6 supply the arc; the reason is yours to give |
| F2 | "Tell me about a live event in any game that you would steal from." | JD | [generic] | Selection scaffold: pick an event whose design you can explain: what it asked players to do, why it held attention, what you would change for these titles. If none comes to mind, say so plainly, then say what you would look for in a good event | A casual question about a hot JD topic, the live-events calendar (F1). It is scored even though it sounds safe |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" (F1) | A4, E2, F2 |
| "coordinate design, art, engineering and community teams on each update" (F2) | A1, C2 |
| "own the post-event review and the KPIs it reports" (F3) | A3, B4 |
| "manage the release checklist with QA" (F4) | A5, B3, D3 |
| "3+ years producing live-service games or apps" (F5) | C4, F1 |
| "experience running a content calendar" (F6) | A4, B1, E1 |
| "comfortable with player-retention metrics" (F7) | D1, D2 |
| "clear written communication" (F8) | A2 — no question probes your own writing, because the interview is spoken and the JD names no format |
| Working on a game with in-app purchases (F9) | C1, E1 |
| Leading a team (F10) | C2 |

## Values cheat sheet

A values-style round is documented by Saltmarsh's interviewing page. Value names are from its values page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted line carries a disagreement. Selection scaffold, B1: pick a time you held or moved a drop for players. If none comes to mind, say so plainly, then give the nearest thing your material carries, F1, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted line carries a corrected announcement. Selection scaffold, B2: pick a time what was said differed from what shipped. If none comes to mind, say so plainly, then give the nearest thing your material carries, F4, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses" — your message. Beats are the two the quote states; what changed is B3's answer slot |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "Project Larkspur retires per-title event teams in favour of a single live-ops group. Where does this role sit in that group, and what does the first shared calendar look like?" | Shows you read the September announcement and goes straight at the structure A4 and C1 turn on | [grounded] Larkspur announcement summary (Sources) |
| 2 | "You came to live operations from QA. What did QA teach you about running a live event that you would want a producer to carry?" | Ties to his own path and invites him to talk about the checklist ground where F4 sits | [grounded] GDC 2026 talk listing |
| 3 | "Your talk argues a live team is judged by how often its patch notes describe what actually shipped. How does the team measure that today?" | Shows you took his argument seriously and asks about the measure behind the published value "Ship the Patch Not the Promise" | [grounded] GDC 2026 talk listing; values page |
| 4 | "A month after an event, what should the post-event review show that the team cannot see today?" | Tells you what you would be asked to own in F3 and signals you think past the event | [inferred] from the JD's post-event line |
| 5 | "How does the producer's release checklist work with QA today, and who edits it?" | Maps to F4 and to the value "Leave the Build Greener"; the answer tells you what manage the checklist means in practice | [inferred] from the JD and the values page |
| 6 | "What gap would you expect a new producer to close in the first 90 days?" | Gives him room to name F9 or F10 himself, which is a better place to hear it than a closing silence | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F10 | "I've never led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | "I've never worked on a game with in-app purchases." Then a plan, never a past |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says weekly content drops for one main title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says monthly retention numbers presented. A3's slot stays inside that |
| Managed the release checklist with QA on each release | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says you wrote it and QA still uses it |

## Sources

Provided documents: your message, which carried the JD text and your background. No dossier was present.

Searches and fetches sent:

| Query or URL | Returned |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Fetch: https://saltmarshgames.com/values | Page read: the three values and their definitions |
| Search: Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Fetch: https://saltmarshgames.com/careers/interviewing | Page read: recruiter call, then the Outage Hour; no take-home |
| Search: Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur (search-result summary only, not fetched) |
| Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search-result summary only, not fetched) |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B, three values by name |
| 2. Saltmarsh Games interview process, live operations | yes | The loop: one session, tabletop then values conversation; persona weights and the detected values round |
| 3. Saltmarsh Games strategy / recent news | yes | A4, C1 and reverse question 1, from the September 2026 Project Larkspur announcement; summary only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer reading and reverse questions 2 and 3; talk listing summary only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is the person you would report to, and what the recruiter said about the Outage Hour → persona weights and banks restructure if he is a peer or skip-level
- Your CV text, or its bullets → F1 to F8 rest on your message; CV bullets with any figures would add defend-the-number slots to D1 and E2
- Your answers to the answer slots in F1, F2, F3, F5 and F8 → those rows move from discovery or transferability toward role-relevant evidence, once you state them outside a drill
- The GDC talk itself, or the full Larkspur announcement → the interviewer reading and A4 currently rest on search-result summaries
- A tuesday-dossier.md from an earlier check of this role → verified evidence and a named top objection, replacing this pack's inferred ones
