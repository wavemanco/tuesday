# Interview prep pack: Product Manager, Platform APIs at Quartzline

- Round: one 45-minute conversation with the hiring manager, Thursday. Interviewer name not given.
- Built on: your pasted dossier (`handoff_to_mock_interview` and `role_profile`) and your note about the round. No company research was possible (see Sources).
- Highest-ROI prep: A1, the objection the dossier names. Do it first, and do D1 right after it.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether claims about your experience survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no strategy research ran) |
| CASE | A live problem set in the role |

An answer slot is an instruction for the interview, not a question for me. Either branch of a slot is a good answer.

## Fit snapshot

None of the five requirements is a gate: years of experience is graded on evidence, and the dossier lists no hard gates. Quotes in the evidence column are the dossier's `verified_candidate_evidence` entries, word for word. Their confidence notes are in the Confidence column.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | R1 "3+ years product management experience" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | transferability | Adjacent, never PM experience; that is the dossier's stated condition. The quotes show integration leadership and a written playbook, and the pack observes that they do not show a PM title or years in that seat. Words, at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Plain acknowledgment, sourced from `prohibited_claims`: "I haven't held a product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | No bridge: the dossier's strategy for roadmap and prioritization authority is `acknowledge_gap`. Words, sourced from `prohibited_claims` and the `acknowledge_gap` area: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: what you would learn first about which roadmap decisions sit with the PM and which with the two squad leads. No answer slot. F5's quote stays at F5 and is not offered here as ownership |
| F3 | R2 "Shipped API or platform products" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote says integrations of the vendor's REST APIs; it does not show whether you shipped an API or platform product. The dossier lists R2 as high priority but gives it no strategy, so this grading is the pack's own. Answer slot: the requirement's wording makes a probe on what you shipped likely. If you shipped any API or platform product, say what it was and what part was yours, in your own words; if you did not, or the APIs were the vendor's to ship, say so plainly and stay with the integrations you led |
| F4 | R3 "Technical fluency: API docs, schemas" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quotes say architecture on REST API integrations and a written playbook; they do not say API docs or schemas. Words stay at those quotes. Answer slot: if any of that work involved reading or writing API docs or schemas, say which and how, in your own words; if none did, say so plainly and stay with the architecture and the playbook |
| F5 | R4 "Stakeholder management across engineering, sales, customers" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quotes reach clients and product; they do not name engineering or sales. The second quote is confirmed with limited inspectable proof, so expect a probe and volunteer its limit first. Words, at scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if your integration work also had you working with engineering or sales, say how and what your part was; if it did not, say so plainly and stay with clients and product |
| F6 | R5 "Agile delivery experience" — dossier role_profile | none given | low | [grounded] | discovery | No quote speaks to it, so nothing about your past goes in. The dossier's strategy is `clarify`. Answer slot: the requirement's wording makes a probe on how you have worked likely. If you worked that way, say how, in your own words; if you never did, say so plainly. Before answering, ask how Quartzline defines it for these squads |

## Persona table

The interviewer is unnamed, so no personal signals adjust these weights. The weights come from the hiring-manager prior plus your note that this is a single 45-minute conversation with the hiring manager. No loop source beyond your words was available.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Skeptic | Quiet probing of the title and roadmap gap | Highest. A hiring manager is derisking gaps, and the dossier names the objection | Rehearse the named objection until it is boring; name the limit before it is asked for |
| B. Case/Strategist | Live problems from the real roadmap: blocked partner, stalled adoption, prioritization | Highest. Hiring-manager prior; the role has two squads and an adoption metric to define | Clarify, structure, then answer; think aloud; ask where decision rights sit |
| C. Data-Driven Prober | Defend "30+" and the playbook line by line | Medium. One headline figure is in your material | Say how the figure was counted, or say plainly you don't know |
| D. Pressure | Time-boxed, interrupting versions of A1 | Medium. The same objection, delivered harder | Hold through two follow-ups, concede the roadmap and title plainly, never fold into claiming them |
| E. Conversational | "Walk me through the journey" opener | Medium-low. Opening minutes of most manager rounds, and still scored | A 90-second arc built only from your quoted sentences |
| H. Peer Evaluator | Seam with the two squad leads | Low. The squad leads may not be in this room, but the dossier flags the authority question | Offer principles for the seam rather than pretending to know it |
| G. Values/Behavioral | A stray behavioral question | Low. No values round is established and no values were researched | Selection scaffold with an honest branch |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; the plain acknowledgments rest on `prohibited_claims` and the `acknowledge_gap` area | The deepest rehearsal in the pack; the underwriter named this objection. Name the limit before it is pressed: "I haven't held a product manager title, and I haven't owned a roadmap." Then the adjacent case at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live, and I wrote the internal integration playbook my team uses." Say once that this is adjacent to the role, not the same job, and never call it PM experience. Don't say what it proves; stop and let them draw it. Close with a plan: what you would learn first about which roadmap decisions sit with you and which with the squad leads. Follow-up 1, "so what do you have on prioritization?": hold the same two quotes, repeat the acknowledgment, add nothing. Follow-up 2, "they've done it and you haven't": concede that, in those words, ask what the first quarter's bar would be, and don't compare yourself. Never fold into claiming the title, a roadmap or prioritization authority | The dossier names this objection; F1 and F2 are where it presses. JD because it scores the title-and-years requirement, with Skeptic delivery |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap` area for roadmap and prioritization authority | Name it first and plainly: owning the roadmap. Words: "I haven't owned a product roadmap." Then a plan, not a past: how you would learn where decision rights sit in your first weeks; reverse question RQ1 is the same question asked back. If pushed for a second area, go to A4's clarify route rather than inventing a claim about your past | F2 is the dossier-recorded gap; this is the standard Skeptic stem, so it arrives in some form |
| A3 | "Tell me about a time you were part of getting an API or platform product to market." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the requirement's wording makes a probe on what you shipped likely. If you shipped any API or platform product, say what it was and what part was yours, in your own words; if you did not, or the APIs were the vendor's to ship, say so plainly and describe the integrations you led, at the quote's own words: scoping, requirements, architecture, UAT, go-live. Don't use "shipped" for the integrations | F3 is a must-have with only adjacent evidence and no dossier strategy, so this is the likeliest unplanned probe. JD because it scores R2 |
| A4 | "What does agile delivery mean to you, and where have you worked that way?" | JD | [grounded] | Answer slot: the requirement's wording makes a probe on how you have worked likely. If you worked that way, say how and what your part was, in your own words; if you never did, say so plainly. Question-shaped opening: "Before I answer, how does Quartzline define agile delivery for these two squads? I'd rather answer against your definition than mine." Nothing about your past goes in beyond what you say here | F6 is a clarify area: the evidence may exist but was never established. JD because it scores R5 |
| A5 | "Walk me through how one of those quarterly roadmap-input sessions ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: volunteer the limit before it is extracted. Tell it at the quote's words: the sessions, quarterly, client evidence, fed to product. Say "ran" and "feeding", not "shaped", "drove" or "owned". Offer anything inspectable you are allowed to share, and if there is nothing beyond your own account, say that. Answer slot: the JD's partner-facing wording makes a probe on how you gathered the client evidence likely. If you gathered it in a particular way, say how, in your own words; if it was brought to you or there was no particular way, say so plainly and stay with the sessions you ran | F5 carries a medium-confidence claim that invites a probe; EXP because it tests what was actually yours |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says an authentication problem is blocking their integration, two other partners are waiting on the same fix, and a squad is committed to other work this quarter. What happens next?" | CASE | [generic] | Clarify first: what is blocked, for how many partners, how severe, and who decides when a squad's plan changes. Structure the answer: objective, who is affected, options, trade-off, what you'd tell the partners and when. Treat the squad lead as a co-decider; claim no authority you were not given. The question needs no claim about your past, so the guidance makes none | A live problem from the role's two-squad setup; F4's requirement is tested because you must follow the technical thread. Generic: a pattern, not a fact about Quartzline |
| B2 | "Partner API adoption has stalled. How would you diagnose it?" | CASE | [generic] | Start by asking how adoption is measured today and what the baseline is: the dossier flags both as unknown, and RQ2 asks the same. Then define candidate measures aloud, segment partners, trace the path from first call to live use, form hypotheses, and say how you would check each one. Supply no baseline or figure | Adoption metrics are a named responsibility with no stated baseline; the dossier lists this as a risk to validate |
| B3 | "You can fund one of three things next quarter: a new endpoint one large partner wants, better docs and a sandbox for every partner, or cleaning up a breaking change. How do you choose?" | CASE | [generic] | Reason it as how you would approach it, never as something you have done: criteria first (reach, risk, strategic fit, cost), what evidence you would want, who else must agree. Name that the squad leads co-own the call and that you would learn where decision rights sit. Don't imply you have set priorities for an engineering squad | The prioritization question that F2 makes dangerous; kept as a hypothetical so the answer needs no claim about the past |
| B4 | "Walk me through how you would run discovery with five partners who each want something different." | CASE | [generic] | Approach aloud: what you need to learn, how you would sample and segment the five, how you would separate requests from needs, and how you would turn the pattern into a decision that others can challenge. The question makes no claim about your past, so neither does the guidance. Your own-past anchor for this theme is A5 | Discovery with partners is a named responsibility; F5's client-facing evidence is the nearest material, handled in A5 |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say 30+ integrations. How were those counted, what counts as one, and which part of each was yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; and which part was yours. If you do not know how it was counted, say so plainly. Keep "Led" and "30+" attached to client integrations, as the quote has them | F1 and F3 both rest on this number, so it is the likeliest target for a prober. EXP because it tests attribution |
| C2 | "Walk me through one of those integrations from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one and tell it through the five stages the quote names, in your own words, saying plainly which parts were yours. The quote supplies only those stages, so no incident or outcome is supplied here; tell only what you actually remember and can stand behind | F1's strongest evidence has to survive a walk-through; EXP because it tests whether the claim is detailed |
| C3 | "Tell me about the integration playbook: what is in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Describe it at the quote's words: you wrote it, it is internal, and your team uses it. Answer slot: what it covers is yours to say. If the API docs and schemas line draws a probe, say whether it covers either. If it does not, say so plainly. Check what you may show before offering the document itself | F4 and F1 both lean on it; it is the dossier's inspectable artifact, so expect to be asked to go deeper |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; the acknowledgment rests on `prohibited_claims` | Sixty-second form of A1: "I haven't held a product manager title. I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live. That is adjacent to this job, not the same job, and I would want to know which roadmap decisions sit with me and which with the squad leads." Pause before answering and restate the question. Hold through two follow-ups; concede the title and roadmap plainly; never claim them | The time-boxed delivery of the named objection; same row evidence as A1 (F1, F2) |
| D2 | "That roadmap-input work: how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold at the quote's own attribution, "ran", and its own scope, "feeding client evidence to product". Concede specifically: if any part was shared or not yours, say which. If the whole was yours, say that. Don't upgrade "feeding" into "shaping" under pressure | F5's claim has limited inspectable proof, which is exactly where an attribution probe lands |
| D3 | "In week two a squad lead tells you that you don't have the context to override their plan. Respond." | CASE | [generic] | Don't fold and don't bristle. Acknowledge their context, ask where the decision sits, and propose a principle for disagreements (evidence on the table, a named decider, a review date). Claim no authority; the dossier flags squad authority as unverified, and RQ1 asks about it | The dossier's unresolved risk about squad-lead authority, delivered as a pressure scenario |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get from integrations to wanting a product role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats that are the quotes, at their own words: the client integrations you led; the playbook you wrote; the roadmap-input sessions you ran. Answer slot for the last beat: why this role and why now are yours to say, in your own words. If the move was less planned than an arc suggests, say so | The opener of most manager rounds; scored even when it feels casual. EXP because it tests the story you tell about your own history |
| E2 | "What are you actually working with in API products these days?" | JD | [generic] | Name something you actually read, build or use. If there is nothing, say so plainly and name what you would learn first. Don't name a tool you cannot discuss for two follow-ups | A casual question on the role's technical theme; scored as interest. Generic: a pattern for casual rounds |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "The two squad leads have been here a while. Where is the seam between your job and theirs, and what happens when you disagree?" | JD | [generic] | Offer principles, not a seam you can't know: who decides what, how disagreements are escalated, what evidence settles them. Say you would want to learn where decision rights sit now, which RQ1 asks directly. Reciprocity: what you bring them, such as client evidence, and what you need from them | The dossier flags decision authority versus the squad leads as asserted but not evidenced |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick one case where several parties contributed. Say what part was yours and which parts were not. If no such case comes to mind, say so plainly, then give the nearest your own words carry or how you would handle it. Use "we" for context and "I" for your contribution | The standard peer probe on credit; generic because no quote carries a cross-team story |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, and a relationship that was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no story and no ending | Stray behavioral question; no quote carries this story, so it stays a scaffold |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same criteria: a specific decision, the trade-off named, what it cost. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. F5's quotes carry no trade-off, so nothing is mapped | Stray behavioral question; scaffold only |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 3+ years product management experience | A1, A2, D1, D3, E1 |
| R2 Shipped API or platform products | A3, C1, C2 |
| R3 Technical fluency: API docs, schemas | B1, C3 |
| R4 Stakeholder management across engineering, sales, customers | A5, B4, D2, H1, H2 |
| R5 Agile delivery experience | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open question on decision authority; it reads as diligence and tells you whether the role's ownership is what the posting says |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's open question on adoption metrics; B2 rehearses the diagnosis, and this gets you the real starting point |
| RQ3 | "What does agile delivery look like for the two squads today, and where does the PM sit in it?" | Closes the clarify gap on R5 in the interviewer's own definition, so A4's answer can be checked against it |
| RQ4 | "Have you hired into this seat from outside a product track before, and what made it work?" | Surfaces how this manager actually weighs the title gap, which A1 and D1 are built around |
| RQ5 | "What would a strong first quarter look like for the person in this role?" | Turns your ramp plan from A1 into a target the interviewer has defined |
| RQ6 | "Will I meet the two squad leads before a decision is made?" | Tests the authority question from the other side; their involvement shows how the partnership is meant to work |

## Prohibited claims

Not coached in any answer, slot, hold or drill. The first three come from the dossier's `prohibited_claims`; the last two are built here from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The plain acknowledgment: "I haven't held a product manager title." Then F1's quote at its own scope |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area (F2) | The plain acknowledgment: "I haven't owned a product roadmap." No slot, no bridge |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | Leave it unsaid, or acknowledge it as sourced. B3 and D3 are hypotheticals and make no claim about the past |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope: integrations of the vendor's REST APIs. The limit is the pack's observation, not words for you. A3's slot stays inside the quote |
| Shaped or drove the roadmap | Inflated form of F5 | F5's quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product". The limit is the pack's observation: the quote says feeding, not deciding |

## Sources

- Provided documents: your pasted dossier (v1.1), consumed from `role_profile` (requirements and responsibilities stand as the JD's lines), `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the named objection, risks, employer questions, prohibited claims) and `decision` (context only). Your note: a 45-minute hiring-manager conversation on Thursday.
- The dossier carries no `evidence_map`, so rows F3 to F5 are graded by this pack and labeled `[inferred]`. R2 is in the dossier's high-priority list but in none of its weak-area entries.
- Searches sent, all refused (permission not granted): `Quartzline company values`; `Quartzline interview process product manager`; `Quartzline API platform strategy news`. No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have supplied official value names to theme G1 and G2; none is used, so those stay generic |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have documented the loop; persona weights rest on the hiring-manager prior and your own description of the round |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have supported CO questions; the pack has none and B1 to B4 are generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the requirements and JD-tagged questions |

## Upgrade menu

- Web search permission → company values, documented loop and strategy research, turning B1 to B4 and G1 to G2 from `[generic]` toward grounded themes. A deeper pass would add up to 6 searches and 2 fetches and take several more minutes.
- The interviewer's name → an interviewer read, adjusted persona weights and a reverse question tied to their career path.
- Recruiter guidance on what the 45 minutes will cover (focus areas, any pre-declared exercise) → weights set from stated focus instead of the manager prior; usually one email to the recruiter.
- The posting's own text → requirement cells that quote the posting rather than the dossier's `role_profile`.
- Your own answers to the slots in A3, A4, A5, C1, C3, F3, F4 and F5, said outside a drill → those rows become story-mapped.
- A session agenda, notes or deck from one roadmap-input session, if you may share it → the one inspectable artifact that could move F5's second quote from medium toward high.
