# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: he and Priya would report to the same VP.
**Round:** one 60-minute conversation, built in session mode. The only source for this structure is the coach's own message; no documented loop was found.

## How to use this pack

- **Personas** describe how a question arrives (the interviewer's style). **Types** describe what is being scored.
- Type key: **VAL** behavioral/values alignment; **EXP** work-experience deep-dive (do the claims survive scrutiny); **JD** role/JD-driven (can she do the listed job, gaps included); **CO** company and strategy knowledge; **CASE** live problem from the actual role.
- Provenance labels: `[grounded]` traces to something you provided (quoted beside it); `[inferred]` is a derivation the row names; `[generic]` is a role-family pattern with no claim about Northwind or Priya.
- Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: it names a probe that is likely and gives two honest branches, and neither branch is a fact about Priya until she says it.
- **Highest-ROI prep in this pack: D1.** It is the question most likely to be asked in some form (consumer-tech background, no classic sales-ops or quota-setting experience, sitting next to the Director of Sales Strategy). Rehearse it until the answer is boring.

## 4. Fit snapshot

Requirements are the JD highlights as the coach gave them, not the full JD text. F7 is a role-family requirement written from no source, so it is plain prose and `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material shows a proposal and a credit, not a go-to-market strategy or a launch, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's line on owning GTM for two new product lines makes a probe on launch work likely. If any of your work took a new offer to market, say what was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The pack pairs an ARR figure with the JD's lifecycle frame, and that pairing is its own derivation; the quote does not say what the change looked at. Answer slot: if any of your past work looked at where customers or partners were not using or renewing something, say what you looked at and what you found; if none did, say so plainly and say how you would start |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | The quote names both tools and says nothing about analyses run alone. Words: "I'm skilled in SQL and Tableau." Answer slot: a self-described data-driven interviewer will ask for an analysis in them. If you ran one end to end, name it and walk it through; if what you did was part of someone else's analysis, or no such analysis exists, say so plainly and stay with the skill |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote shows a model and its use, not a designed motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's requirement makes a probe on how partners were engaged likely. If any part of how a partner relationship was set up was yours to shape, say which and how you decided; if there was no such part, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | Lead with the quote in its own terms: you set annual volume targets, and there was consensus across orgs. Do not upgrade it to winning anyone over. Answer slot: if the orgs started in different places, say how you handled it; if they did not, say so plainly and describe how the consensus was reached |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | Words: "I use AI tools daily." Answer slot: expect "to do what". Name the tools and tasks in your own words. If you have built or shaped anything with AI beyond using it, say what and your part; if not, say so plainly |
| F7 | Sales-ops and quota-setting fluency, as a Director of Sales Strategy would weigh a peer — no source (role-family) | "No classic sales-ops or quota-setting experience." — the coach's notes, "set annual volume targets with cross-org consensus" — the coach's notes | none | [grounded] | capability | A gap the coach stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The pack's observation: your material says volume targets, not quotas, so the word stays "targets". Nothing is added to make the gap feel smaller |

## 7. Reading the interviewer

Built from the coach's description only. The search for his public footprint was refused, so nothing here comes from his talks or writing, and no fact is offered that the description does not carry.

| Signal (as given) | What it implies for this conversation |
|---|---|
| Profile self-describes as "relentlessly data-driven" | Every number is probed to its assumptions. Know how each CV figure was counted, or say plainly you do not know (A1, A2, A4, F1). Say definitions aloud before you give a number |
| Career spine in pricing and monetization roles | Pricing, packaging and unit-economics angles are his native language; the Case bank leans there (C2, C3). Expect the discount and packaging trade-offs to come up |
| One early-stage-startup chapter | Expect probes on pace and working with less (D3). The pack offers no builder or 0→1 story, because no quoted sentence carries one |
| Peer, same VP | He is pricing what you cost and contribute to his work. Seam and credit questions are likely (B bank), and reciprocity framing matters |

**Mirror opportunity.** His career spine is pricing and monetization (his path); F4 carries "built a partner-level revenue model used in carrier negotiations" (the candidate's side). That is shared revenue-model vocabulary, and nothing more. It is not pricing experience, and the prohibited list below says so.

## 8. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Reads the CV line by line, asks for inputs and denominators, goes two levels deeper | **Top, 5 questions.** Peer prior (Peer Evaluator plus Prober) and his "relentlessly data-driven" self-description both push it up | Know what you can and cannot say about how each figure was counted; say so plainly when you do not know; name the weakest assumption you know of before he does |
| B. Peer Evaluator | Seam-splitting, "what would you need from me", credit-sharing, collegial packaging of earlier objections | **High, 4.** The relationship prior is peer, and the same VP makes the seam a live topic | Reciprocity framing; propose seam principles rather than pretending to know the seam; show spine and tact together |
| C. Case / Strategist | Live problems on pricing, packaging, bundling, partner motion | **High, 4.** Raised above the usual peer weight because his pricing and monetization spine tilts cases toward packaging and unit economics, and the JD is a strategy role | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise per case |
| D. Skeptic | Quiet probing of the gaps: sales-ops, why leave, why here | **Mid, 3.** The JD's partner-motion and GTM-ownership lines meet a consumer-tech background and a stated sales-ops gap, so one objection is near-certain | Rehearse the single predictable objection (D1) until it is boring; bridges from stated evidence only; calibrated candor over bluffing a competency he owns |
| E. Conversational | Opening biography, casual question on AI | **Low, 2.** Peer rounds open friendly, but the substance is elsewhere | A 90-second arc; treat the casual AI question as scored |
| F. Pressure | Time-boxes, "how much was actually you" | **Low, 2.** Peers rarely run stress rounds, but a data-driven prober can press an attribution claim | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| G. Values / Behavioral | Scenario probes | **Low, 2.** No published values were read and no values-style round is documented, so this is not a scored values round; the themes come from persona stems and his own self-description | Story selection scaffolds ending in an honest branch |

Weights rest on the relationship prior and his described signals. No source documents this loop beyond your own words, so no archetype fallback is applied and no values cheat sheet is built.

## 9. Question banks

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure on your CV was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the quote at its own scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Then the four slots a figure raises, each in your own words. How it was counted: say what you know; if you do not know, say so plainly. What it is sensitive to: name it if you know it. The assumption you would defend least: name it before he does, or say you cannot name one. Which part was yours: the quote's verb is "proposed" and the credit is attached to the change, so say what was yours beyond the proposal, if anything, and what was others' | F1 and F2 hold the only quantified claim, and the interviewer's self-description makes it the first probe; EXP because it tests attribution and counting, and Prober because the delivery is "walk me through" |
| A2 | "Walk me through the revenue model you built: what went into it, and who used it?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: the model, built at partner level, used in carrier negotiations; those are the beats the quote states, so tell them in your own words. Answer slot: a Prober will ask what the inputs were and how you checked them. If you validated them, say how; if you did not, or you do not recall, say so plainly and return to the model and its use. Answer slot: on who used it, the quote says carrier negotiations; say who was in the room only if you know | F4 is the evidence for the partner requirement and the second CV claim a data-driven interviewer will open; EXP because it tests what the candidate did |
| A3 | "Tell me about an analysis you've run in SQL or Tableau, end to end: what was the question, and what did the data say?" | JD | [grounded] "skilled in SQL/Tableau" | The quote names two tools, not a story, so this is a selection scaffold. Pick an analysis where you wrote the query or built the view yourself, where you can say whose question it was, and where you know what changed because of it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Say the definition of each metric before you give its value | F3 is the JD's SQL and Tableau line; JD because it scores that stated requirement, and an open prompt because the quote carries no analysis to premise on |
| A4 | "Walk me through how the annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus", "No classic sales-ops or quota-setting experience." | The beats the quote states: you set annual volume targets, and there was consensus across orgs. Keep the word "targets"; the pack's observation is that your material shows no quota-setting, and a Director of Sales Strategy will hear the difference. Answer slot: if there was a method behind the numbers, say what went into it and who weighed in; if the numbers were negotiated without one, or set by others' inputs, say so plainly and describe how the consensus was reached. Name the assumption you would defend least | F5 and F7 meet here, and it is the place a stretch from "targets" to "quotas" would be caught by this interviewer specifically; EXP because it tests how the candidate's claim was built |
| A5 | "A new product line shows strong land numbers and weak adopt numbers. Which two cuts of the data would you run first, and what would each tell you?" | JD | [generic] | No claim about your past is needed. Clarify what counts as land and as adopt before you cut anything; state a hypothesis early; name two cuts and what result would change the plan; say aloud the weakest assumption of your own cuts. Close with what you would not conclude yet | F2's requirement ("identify whitespace across land/adopt/expand/renew") asked as a live problem: JD content, CASE delivery; `[generic]` because it is a pattern for the problem, not a fact about Northwind |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sales strategy and GTM strategy sit side by side here, and your background doesn't show classic sales-ops. How would you work with my team where that matters?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Words: "I don't have classic sales-ops or quota-setting experience." Then principles, not claims about a seam you have not seen: ask what his team already owns, agree up front who decides what, share definitions of the numbers you both use, escalate together to the shared VP. Offer something back in the quote's own terms, if you wish: "I set annual volume targets with cross-org consensus." Leave quotas out of it | F7 is a stated gap and B1 is where it returns in collegial packaging; JD because it scores fit to the listed GTM role as a partner to his team |
| B2 | "Where's the seam between your role and mine, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Seam principles: decision rights, shared definitions, a named path to the VP you share. Answer slot: if the orgs differed on the targets, say how you handled it, in your own words; if they did not, say so plainly and answer as a principle. Do not describe a disagreement the quote does not carry | F5 is the cross-functional influence requirement; JD because the requirement is scored, and Peer because the question is about parity, not authority |
| B3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use "I" for what the quote says you did, "we" for context: "I proposed a store-surface change; it was credited with a ~$400M ARR uplift." Answer slot: if the credit was shared or contested, say how you handled it; if it was not, say so plainly. Never claim the figure as yours alone | Credit-sharing probes are a peer staple, and F1's wording ("credited with") is already attribution language; VAL because it tests behavior toward a colleague, not a competency |
| B4 | "What would you need from me and my team in your first 90 days?" | JD | [generic] | Reciprocity first: what you would bring his team, then what you would ask for. Ask rather than assume how Northwind's sales-strategy team works. A short list: access to how pipeline and targets are defined, one example of a launch your team judged well, and a regular check-in | A peer prices what a hire costs his team; JD because it scores whether the role works alongside his; `[generic]` because it presupposes nothing about Northwind or Priya |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Enterprise expansion is a stated priority. If one of your two product lines had to land in enterprise, what would you want to know first?" | CO | [grounded] | Clarify before you structure: which line, what an enterprise buyer is today, what the current land motion produces. Then objective, segments, approach, metrics, risks. Raise packaging and the price metric early. Say what you would assume and what you would check. Challenge one premise respectfully | Enterprise expansion is the first of Northwind's three priorities in your research note; CO because it tests current strategy, with a CASE delivery |
| C2 | "Bundling by a much larger platform vendor is our main competitive threat. How does that change how you'd go to market for a new product?" | CO | [grounded] | Bring the consensus point first: where the bundle bites (buyers already on that platform) and where a standalone product still wins. Then one thesis-driven divergence, and the anti-pick: one thing you would not do, such as a blanket price match. Cover positioning, packaging and pricing response, and the early signal you would watch. Ask what you would need to know before committing | The competitive frame from your note, in his native pricing and packaging territory; CO because it tests whether she thinks at the company's altitude |
| C3 | "Compass, the AI copilot, is launching. How would you decide whether it is a standalone line, a bundled feature, or an expansion lever for existing accounts?" | CASE | [grounded] "uses AI tools daily" | Structure the decision: what each option optimises for, what would have to be true for each, how packaging and price interact with the bundling threat, what you would measure in the first quarter. One honest line from F6 is available: "I use AI tools daily." Do not claim anything about building AI | Compass is the second priority in your note and F6 is the JD's AI plus; CASE because it is a live decision; the pricing tilt follows his spine |
| C4 | "The JD asks for partner-motion design. If one product line needed a partner channel, how would you design it, and what do you need to know first?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Clarify first: what the partner brings, what the product needs from partners, what each side gains. Then segments of partners, economics, roles, how you would measure it, what would make you stop. Optional bridge at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of designing how a partner relationship worked was yours, say which; if not, say so plainly and answer as a design problem | F4 is a hard requirement with only adjacent evidence, so it gets both a JD and a live-problem form: JD content, CASE delivery |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Looking at this JD next to your background, where would you be weakest on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience.", "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Say the gap first, in the quote's own limits: "I don't have classic sales-ops or quota-setting experience." Then the nearest evidence at its own scope: you built a partner-level revenue model that was used in carrier negotiations, and you set annual volume targets with cross-org consensus. Then a ramp plan, said as a plan: what you would learn from his team in the first weeks and what you would ask of him. Follow-up 1, "what would you do about it": the plan again, no new claims. Follow-up 2, "why would a consumer-tech background transfer": answer slot, if any of your work touched enterprise or B2B customers, say what; if none did, say so plainly and return to the evidence above. Follow-up 3, "convince me you won't slow my team down": what you would not touch without them. Concede specifically ("that is a real gap; here is how I would close it"), and do not fold on what the quotes carry | The sales-ops gap (F7) and the adjacent-only partner evidence (F4) meet the interviewer's own territory; JD because it scores listed requirements including gaps |
| D2 | "Why leave a large consumer-tech company for an emerging-products role at a B2B data-infrastructure company, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: give your actual reasons in your own words; this pack does not supply one. Shape it as pull toward the role (the JD's two new product lines, partner motion, AI) rather than away from the old one, and keep it to three sentences. Do not invent a trigger event | A motivation probe, standard for a skeptic and sharper for a cross-segment move; EXP because the reason for leaving is scored as career consistency |
| D3 | "You've spent your recent years at a large company, and Northwind is about 3,000 people. What changes about how you work?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Principles first: what you keep, what you change, what you ask. A past example is a selection scaffold: pick a time you worked with less than you wanted (less data, fewer people, a tighter timeline), with a named constraint, a decision you made anyway, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | His startup chapter makes scale and scrappiness probes likely; EXP because it tests whether past context transfers |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops", "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus", "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc on the quotes: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Name the three headlines in their own words and stop. End with why this role, in your own words (see D2); the arc supplies no reason | Casual openers are scored; EXP because it sets up every probe that follows |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say what you use and for what, in your own words. Answer slot: if you have built or shaped anything with AI beyond using it, say what and your part; if not, say so plainly. Tie to the role as curiosity, not as claimed expertise | F6 is the JD's AI plus, asked casually, which is how plus-skills are usually probed |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That $400M, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate. Hold on the quote: "I proposed a store-surface change; it was credited with a ~$400M ARR uplift." Follow-up 1, "so you didn't build it": return to the proposal; answer slot, if more was yours, say what, and say what was others'. Follow-up 2, "credited by whom": answer slot, say who credited it and on what basis if you know; if you do not, say so plainly. Concede only what is true and specific, and do not fold on the proposal | The attribution probe on the pack's only headline figure; EXP because it tests what was the candidate's |
| F2 | "Sixty seconds: why should I want you as a peer?" | JD | [grounded] "No classic sales-ops or quota-setting experience.", "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus" | Three beats from the quotes: the partner-level revenue model used in carrier negotiations, the annual volume targets set with cross-org consensus, and "I use AI tools daily" if time allows. Do not compare yourself to anyone. If he returns to the gap, "I don't have classic sales-ops or quota-setting experience", say it once and move to the plan from D1 | A time-boxed challenge on fit; JD because it scores the match to a peer seat |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold. Pick a time where the message was unwelcome, you named it plainly, and the relationship was intact afterwards. It needs a named stake and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stock behavioral prompt; `[generic]` because no quoted sentence carries it |
| G2 | "Tell me about a time the data said one thing and the room wanted another." | VAL | [inferred] | A selection scaffold. Pick a time you can state the data, the room's preference and what was decided, and where you know your part in the decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Derived from his "relentlessly data-driven" self-description, so `[inferred]`; VAL because it tests behavior under disagreement |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C1, C3, D1 |
| "identify whitespace across land/adopt/expand/renew" | A5, C1 |
| "run independent analysis in SQL and Tableau" | A3 |
| "partner-motion design experience required" | C4, A2 |
| "strong cross-functional influence" | B2, B3, A4 |
| "AI experience a plus" | E2, C3 |
| Sales-ops and quota-setting fluency (role-family, not a JD line) | B1, D1, A4 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load, not only your own |
| R2 | "Your career has been in pricing and monetization. Where do you most want a GTM lead to push back on how your side sees a new product?" | Tied to his own path; it turns the interview into a peer conversation on ground he knows best |
| R3 | "You had an early-stage chapter. What from it do you still use here?" | Invites a builder story from him, and signals you listened to his path |
| R4 | "When your team and the GTM lead disagree on a number, what has worked, and what would you want it to look like?" | Opens the seam conversation on his terms, and shows you plan for disagreement |
| R5 | "For a new product's first year, which numbers do you trust early and which ones do you wait on?" | Speaks to his data-driven self-description, and tells you what he will hold you to |
| R6 | "Where is the bundling pressure from the larger platform vendor showing up first?" | Shows homework on the competitive frame without asserting anything about it |

## 13. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and this pack does not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led go-to-market strategy for a product line or a launch | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a proposal and a credit, not a go-to-market strategy |
| Drove, generated or owned the ~$400M ARR uplift | Inflated form of F1 | "I proposed a store-surface change; it was credited with a ~$400M ARR uplift." The credit is the quote's attribution |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations |
| Has pricing or monetization experience (to mirror the interviewer) | Inflated form of F4 | F4's quote at its own scope. The shared ground is revenue-model vocabulary, nothing wider |
| Set sales quotas, or has quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Won over or resolved conflict between orgs | Inflated form of F5 | F5's quote at its own scope: targets set with cross-org consensus. No conflict is supplied |
| Built or led AI products or AI strategy | Inflated form of F6 | "I use AI tools daily." |

## 14. Sources

**Provided documents:** the coach's message (JD highlights, a summary of the candidate's background, a description of the interviewer, and a research note on Northwind's three stated priorities and its main competitive threat). No CV text, full JD or dossier was provided. The research note was not checked against any page.

**Searches sent, all refused (the host did not grant search permission):**

- "Northwind Data company values principles" — refused
- "Northwind Data interview process strategy GTM" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. It would have supplied the official value names for VAL questions; with none read, VAL themes come from persona stems and the interviewer's own description, and no cheat sheet is built |
| 2. `Northwind Data interview process, GTM strategy` | unavailable | Every call was refused. It would have named the loop's rounds; persona weights rest on the relationship prior and your statement of one 60-minute conversation |
| 3. `Northwind Data strategy` / recent news | skipped | Your pasted note already supplies the priorities and competitive frame that feed the CO bank; no call was sent |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call was refused. It would have added his public talks and writing to the interviewer read; that section rests on your description alone |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Full JD text → the six requirements in F1 to F6 become full quotes, mid-list items get their own rows, and any hard requirement beyond your highlights gets a JD-tagged question
- Priya's CV lines, word for word → F1 to F7 now rest on the coach's notes, capped at `medium`; her own sentences would let the guidance quote her and not a summary
- The artifact that would raise a band, if it exists: the proposal write-up for the store-surface change and the readout where the ARR credit appears (F1, F2); the partner-level revenue model itself or a deck from the negotiations (F4)
- The recruiter's prep email → coverage of any pre-declared deliverable (a POV, case or presentation gets its own build section)
- Her answers to the answer slots in F1 to F6 → those rows and A1, A2, A3, A4, C4, D1, E2, F1 upgrade from slots to quoted stories
- Search permission → Northwind's published values, loop structure and Dan's public footprint, which would also tell you whether a values-style round exists
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for sharper CO and CASE questions, offered once
- A `tuesday-dossier.md` from an earlier evidence review → allowed strategies per weak area and absolute prohibited claims
