# Interview prep pack: Operations Manager, Atlas Freight

Round type, interviewer names and relationship: not known (your message says you know nothing about who is interviewing you). Built as a full-loop pack with persona weights close to flat, which is noticeably weaker than a pack built for a known round; the upgrade menu says what would sharpen it. Sources are your message alone: web search was refused in this session, so nothing here comes from research.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show what the employer says it values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually yours |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no research succeeded, so none could be grounded) |
| CASE | A live problem from the actual role, answered by structure and reasoning |

Provenance labels: `[grounded]` traces to something you wrote or the JD you pasted. `[inferred]` is this pack's derivation, named. `[generic]` is a pattern for the role with no claim about you or Atlas.

An answer slot is an instruction for the interview, not a question for you now: it names where an interviewer is likely to probe and gives two honest branches. Either branch is a good answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — the JD you pasted | "currently a senior shift manager over 3 supervisors" — your message, "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Keep the words at their scope: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." The pack's observation: your material shows a shift and a site's surge plan, not four sites and not terminals. Answer slot: the JD's four sites make a probe on reach likely. If any part of your role reaches beyond your own shift or site, say how far, in your own words; if none does, say so plainly and stay with the shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — the JD you pasted | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | transferability | Mis-pick rate is a different measure from on-time performance or cost per shipment, and the bridge should not stretch it. Words at their scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names both measures, so expect a probe on each. If you tracked either one in your work, say which and how it was counted; if you tracked neither, say so plainly and stay with the mis-pick figure |
| F3 | "lead a team of 12 supervisors" — the JD you pasted | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Words at their scope: "I'm currently a senior shift manager over 3 supervisors." The pack's observation: the JD's number is 12 and your material's is 3. Answer slot: expect a probe on how your approach changes at that size. If you have led more than 3 people at once, say when and how many; if not, say so plainly and describe, as a plan and never as a past, how you would approach 12 |
| F4 | "build reporting in Excel/Power BI" — the JD you pasted (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" does not show whether you have built reporting, and the bridge should not decide that for you. Answer slot: the JD says build reporting. If you have built reports or trackers in Excel, say what each showed and who used it; if you have not, say so plainly and say what you would build first |
| F5 | "build reporting in Excel/Power BI" — the JD you pasted (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past, and only steps you will actually take. If you do start before the interview, what you did is then yours to say. Never a claim to Power BI work |
| F6 | "5+ years operations leadership required" — the JD you pasted | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | Words at their scope: seven years in warehouse and distribution ops. The pack's observation: the JD asks about years of leadership and your material gives years in operations. Answer slot: expect a probe on how many of the seven years involved leading people. Say, in your own words, when you first led supervisors if you know; if fewer than five of the years involved leading, say so plainly and stay with the seven |
| F7 | "Lean/Six Sigma a plus" — the JD you pasted | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: green belt, certified. Your message does not say which body or discipline, so say it as you hold it. Do not describe the pick-path redesign as a belt project unless it was |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: scale, Power BI, terminals, years of leadership | High. With no round information, the weight rests on the fit snapshot: the JD's 4 sites and 12 supervisors against your 3, and the stated Power BI gap (F1, F3, F5) are what any round derisks. Raised one step above flat for that reason | Rehearse A1 until it is boring. Name the scale difference before they do. Bridge only from what the quotes carry |
| Case/Strategist | Live problems from the job: on-time slippage, rising cost per shipment, a first month with twelve supervisors | Medium-high. Operations-manager roles are commonly tested on live problems, and the JD is operational. No loop source was read, so this is a prior, not a finding | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise politely per case |
| Data-Driven Prober | Reads your one number line by line | Medium. The 40% mis-pick figure is the only metric you gave, and a prober goes straight to it | Say how it was counted, or plainly that you do not know. Name the assumption you would defend least before they do |
| Pressure | Interrupts, time-boxes, tests attribution | Medium. Unknown without the round; operations leadership interviews can include it | Pause, restate, anchor in what you stated, hold two follow-ups, concede specifically |
| Values/Behavioral | Scenario prompts about unpopular truths, customers versus metrics, accountability | Medium-low. No Atlas values were found, and no loop source or archetype detects a values round here, so the bank uses the persona's own stems | Pick a real instance, or say plainly that none comes to mind and give the nearest thing your material carries |
| Conversational | Friendly walk-through of your journey and interests | Medium. A relaxed first conversation is common, but the round is unknown. The danger is treating it as unscored | A 90-second arc built only from your own sentences |
| Peer Evaluator | Seams between sites, disagreement with equals, credit | Medium-low. Appears only if a site lead or peer manager is in the loop | Propose seam principles instead of pretending to know the seams. Show what you bring them |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over three supervisors today. This role has twelve supervisors across four sites. Which part of that step worries you most?" | JD | [grounded] "currently a senior shift manager over 3 supervisors", "ran the site's peak-season surge plan two years running" | The highest-ROI rehearsal in this pack: this question will arrive in some form, and a calm answer changes the interview. Hold only what the quotes carry: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Say the step yourself before they do: three supervisors to twelve, a shift to four sites. Follow-up one, "what don't you know yet": concede specifics you cannot know from outside, such as the sites and the twelve people, and say what you would learn first. Follow-up two, "why would it scale": return to the two quotes and add nothing to them. Answer slot: if any part of your role reaches beyond your own shift, say how far; if none does, say so plainly and describe, as a plan, how you would set about the wider scope | F1 and F3 are where the JD's numbers outrun the material, so this is the likeliest objection. JD because it scores a stated requirement. It gets the most follow-up levels in the pack |
| A2 | "This role builds reporting in Excel or Power BI, and you've never used Power BI. How do you close that?" | JD | [grounded] "never used Power BI", "solid Excel" | Concede the Power BI half plainly: "I've never used Power BI." Hold the Excel half at its own scope: "solid Excel." Answer slot: if you have built reports or trackers in Excel, say what each showed and who used it; if not, say so plainly. Then a learning plan with only steps you will take. Never describe Power BI work you have not done | F4 and F5. The negative is yours, so the plain acknowledgment is allowed. JD because the tool is named in the posting |
| A3 | "The posting asks for five-plus years of operations leadership. Where do you meet that?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the quote at its scope: seven years in warehouse and distribution ops. Answer slot: expect the follow-up on how many of those years involved leading people. Say when you first led supervisors if you know; if fewer than five of the years involved leading, say so plainly and stay with the seven | F6. The requirement is about leadership years and the material gives operations years. JD because it scores the stated requirement |
| A4 | "You come from warehouse and distribution. This role owns terminal operations. What would you need to learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the quote at its scope and do not claim to know how Atlas's terminals run. Answer slot: if any of your work touched terminal operations, say what; if not, say so plainly. Then, as a plan, what you would ask to see in your first two weeks | F1. The posting's word is terminals and your material's words are warehouse and distribution |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites has slipped over the past month. Walk me through your first week." | CASE | [generic] | Clarify first: how on-time is defined and measured, which shifts, lanes or customers, when it started and what changed. State the objective, split the problem into segments, say your approach, the metrics you would watch and the risks. Challenge one premise politely, such as whether it is the site or something upstream. The question needs no claim about your past, so the guidance makes none | F2 and F1. A live problem from the JD's on-time and four-site lines. CASE because it scores structure. Generic because it is a pattern, not Atlas's real situation |
| B2 | "Cost per shipment is rising across all four sites. Where do you look first, and what would you refuse to cut?" | CASE | [generic] | Define cost per shipment before diagnosing it. Separate changes in volume and mix from changes in efficiency. Name your first three places to look and why, then one cost you would refuse to cut and the reason, which is your call. Close with how you would know it worked | F2. CASE with JD content. Generic for the same reason as B1 |
| B3 | "You start Monday with twelve supervisors across four sites. How do you spend your first thirty days?" | CASE | [generic] | Objective first, then sequence: who you meet and in what order, what you ask each of them, what you change in thirty days and what you deliberately leave alone, how you would know it is working. A plan, never a past | F3. CASE because it is a plan under uncertainty. Generic: no claim about you |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% on mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say, in your own words, how the rate was counted and over what period, what it is sensitive to, which assumption behind it you would defend least, and which part of the redesign was yours. If you do not know how something was counted, say so plainly; that is an honest answer. Never add a method or a baseline you did not use | F2 supplies the only figure in your material, and a prober goes there first. EXP because it tests attribution |
| C2 | "Mis-pick rate is a quality measure. What happened to speed or cost per shipment when the pick path changed?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: the JD names on-time performance and cost per shipment, so expect this probe. If you tracked speed, throughput or cost around the redesign, say what you tracked and what it showed; if you did not, say so plainly and stay with the mis-pick figure | F2. The question connects your only metric to the JD's two measures. JD because it scores that requirement |
| C3 | "Tell me about something you built in Excel that other people relied on." | JD | [grounded] "solid Excel" | No quoted sentence carries a story here, so this is a selection scaffold. Pick a report or tracker you made, with a named reader, a question it answered and a decision it informed. If no such thing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build it | F4. An open prompt on a requirement the JD names |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Forty percent. How much of that was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold the sentence for two follow-ups: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if part of the work was shared or directed by others, say which part and whose; if it was yours alone, say so plainly. Concede only what you truly do not know, and name it specifically. Do not fold on the sentence to restore harmony | F2. Pressure tests composure and attribution honesty |
| D2 | "Sixty seconds: why you, over someone who has already run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops", "ran the site's peak-season surge plan two years running", "green belt certified" | Hold what the quotes carry, in their words: seven years in warehouse and distribution ops, the surge plan you ran two years running, green belt certified. Name the difference yourself: the JD says four sites and your material shows a shift and a site. Answer slot: if any of your reach goes beyond that, say how far; if not, say so plainly and say what you would do in your first weeks. Do not tell them what your record proves; describe it and let them conclude | F1, F6 and F7 together. JD because it scores fit to the stated role |
| D3 | "You ran the surge plan two years running. Which part of it was yours?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Say the sentence at its scope. Answer slot: if some part of the plan was yours, say which, in your own words; if you ran it as given, or the plan was someone else's, or there was no written plan, say so plainly and describe what running it involved for you. Never add an event or outcome from those two seasons that you did not tell me | F1. EXP because "ran" is a verb an interviewer will test |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose an instance with a named stake, a moment you did not fold, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's own stem, used because no Atlas values were found. Generic: no claim about you |
| E2 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Selection scaffold: an instance where the customer's need and an internal number pulled apart, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's own stem. It fits a role scored on on-time performance, though that is the pack's reasoning, not a sourced fact |
| E3 | "Tell me about a time you had to change how one of your supervisors worked." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | The quote gives you supervisors, not a story, so this is a scaffold: choose an instance with a specific behavior, what you said, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3. The JD's twelve supervisors raise it |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running", "green belt certified" | A 90-second arc told in your own words, using only these beats and in their scope: the seven years, where you are now, the pick-path result, the surge plan, the belt. Answer slot: the reason you want this role and why now is yours alone. Say it in your own words; the pack supplies none | F1, F6 and F7. EXP because it is your story told casually and still scored |
| G2 | "What are you actually working on in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say the credential as you hold it. Answer slot: if you have a current improvement effort, say what; if not, say so plainly and say what you would look at first in a new site. Do not call earlier work a belt project unless it was | F7. The persona's stem on the JD's plus-skill |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "With four sites under one manager, where do you expect the seams between them, and what do you do when two site leads disagree?" | CASE | [generic] | Propose seam principles instead of claiming to know them: who owns a shipment when it crosses sites, how a conflict is escalated and how fast. Ask how it works today. Show what you would give the site leads, not only what you would need | F1. Generic: it asks for no past |
| H2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others contributed to the pick-path redesign, say whose input and what, in your own words; if it was yours alone, say so plainly. Then your general practice for sharing credit, stated as what you do and never as an event you have not described | F2. The persona's stem, tested against your one result |

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A4, B1, D2, D3, H1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C1, C2 |
| "lead a team of 12 supervisors" | A1, B3, E3 |
| "build reporting in Excel/Power BI" | A2, C3 |
| "5+ years operations leadership required" | A3, D2, G1 |
| "Lean/Six Sigma a plus" | D2, G1, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do the four sites differ most in how they run, and which is hardest right now?" | Shows you expect differences between sites, and the answer tells you where your first month goes |
| 2 | "How is on-time performance defined and reported today, and who sees it?" | The JD names on-time performance. The answer shows what you would be measured against |
| 3 | "What does reporting look like today: what lives in Excel, what in Power BI, and who builds it?" | An honest way to learn how much Power BI matters without claiming anything |
| 4 | "What would the twelve supervisors say is working and not working?" | Signals you start with the people you would lead |
| 5 | "What would success look like at ninety days?" | Gives you the yardstick, and the answer is something you can plan against |
| 6 | "What could a new person in this seat do in the first month that would genuinely help you?" | A reciprocity question: it works with a peer or a manager and turns an interview into a working conversation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material shows a shift and a site's surge plan, not four sites. A1's slot stays inside your own role's reach |
| Led or managed a team of twelve supervisors | Inflated form of F3 | "I'm currently a senior shift manager over 3 supervisors." The limit is the pack's observation about the JD's number |
| Improved on-time performance or cost per shipment | Inflated form of F2 | The mis-pick quote at its own scope. C2's slot asks only what you tracked |
| Built reporting or dashboards in Excel | Inflated form of F4 | "Solid Excel" at its own scope. A2 and C3's slots ask only what you built |
| Has used Power BI, or built anything in it | Negative you stated, F5 | The plain acknowledgment: "I've never used Power BI." No slot |
| Has five or more years of leading operations | Inflated form of F6 | Seven years in warehouse and distribution ops at its own scope. A3's slot asks only how many involved leading |
| Applied Six Sigma or Lean on a project | Inflated form of F7 | "Green belt certified" at its own scope. G2's slot asks only about current work you actually have |
| Created the peak-season surge plan | Inflated form of "ran" in F1 | "I ran the site's peak-season surge plan two years running." D3's slot asks which part was yours, whichever answer is true |

## Sources

Provided documents: your message, which carried the job description lines and your background. No dossier was present, and no CV or other document was provided.

Searches sent, each refused by the host with no result:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight operations manager interview process": refused
- "Atlas Freight regional logistics strategy recent news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | All calls refused. It would have named the published values for a cheat sheet and VAL questions; none could be built, so E1 to E3 use the persona's own stems |
| 2. Atlas Freight interview process | unavailable | All calls refused. It would have fixed the loop structure and persona weights; weights stay near flat and the loop stays unknown |
| 3. Atlas Freight strategy and recent news | unavailable | All calls refused. It would have fed CO questions; there are none |
| 4. Interviewer name | n/a | No name was given, so there was no query; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD lines you pasted fix the fit snapshot and the JD questions |

## Upgrade menu

- The recruiter's invite or one email to the recruiter, asking the round type, who you meet and any stated focus areas → persona weights recomputed for that round, and an interviewer read if names are given
- The interviewer's name and title → a reverse question tied to their own path, and weights read from their public footprint
- The full job description → any requirement missing from the lines you pasted becomes a grounded row with its own questions
- Your CV → evidence rows cite its lines, which can lift F1 to F7 from medium toward high where it carries detail. In operations, what raises a band is the artifact itself: the before-and-after mis-pick report, the surge plan document, the belt certificate
- Your answers to the answer slots on F1, F3, F4 and F6 → those rows become story-mapped instead of scaffolded
- Atlas Freight's own values or careers page pasted in, or search access granted → a values cheat sheet, loop structure and CO questions; a deeper research pass would be up to 6 more searches and 2 more fetches, several more minutes
- The hours you have before the interview → a prep triage section sized to your time
- If the first round is a recruiter screen → logistics questions on pay, notice, location and reason for leaving, each answered in your own words
- A tuesday-dossier.md from an earlier job-underwriter run on this posting → a named top objection and verified evidence in place of this pack's inferred ones
