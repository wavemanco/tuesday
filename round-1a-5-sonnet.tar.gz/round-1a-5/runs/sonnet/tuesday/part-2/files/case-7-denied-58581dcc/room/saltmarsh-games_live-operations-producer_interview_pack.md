# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Format: one 60-minute interview, on Friday. Built on one assumption: a hiring-manager round, because your note did not say whether Tobias would be your manager or sits above that manager. Web research was not available for this pack, so it rests on the JD and your own background as you wrote it, and the sections that needed research are dropped or marked `[generic]`.

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes |
| EXP | Whether your background claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its products |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Do these in order. Everything else is insurance.

1. B2, the highest-ROI prep in the pack: the in-app-purchase question will be asked in some form. Rehearse your plain statement of it until it is boring.
2. B1 and B3: the live-service years and the coordination-without-leading question.
3. C1 and D1: the retention numbers you presented, and your 90-second walk through your background.
4. A1 to A5: the case problems. Practise the structure aloud, not the content.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material says the years and the associate-producer title, with nothing inspected behind it, and the words stay there: "I spent 4 years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service wording makes a probe on how your studio's title was run likely. Say how the weekly content drops fit into how the game was run, in your own words; if the title was not run that way, or you had no part in that, say so plainly and stay with the calendar you ran |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one main title's weekly content-drop calendar, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on scale likely. Say what else your calendar work covered besides the main title, if anything, in your own words; if nothing, say so plainly and stay with the main title's calendar |
| F3 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: a weekly content-drop calendar, run for two years, because a named cadence beats an adjective |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show how work with those teams was arranged. Answer slot: the JD's coordination line makes a probe likely. If you worked with any of design, art, engineering or community on a drop, say which and how it was agreed, in your own words; if you did not, or someone else did that, say so plainly and say what you would ask each team for first |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting the numbers, not producing them or owning a review, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event-review line makes a probe likely. If any review followed an event you worked on, say what you contributed, in your own words; if none did, or it was not yours, say so plainly and stay with the monthly numbers |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in terms: the quote says you wrote it and QA still uses it. The JD's word is manage and the quote's is wrote, so say wrote. Expect a probe on how it was made with QA (D2) |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in terms, but nothing inspected behind it, so expect a probe on how the numbers were counted (C1). Say it in the quote's terms: you presented the monthly retention numbers to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | discovery | A checklist is written, but the quote does not show it was clear to its readers. Lead with it in the quote's own terms. Answer slot: the JD's written-communication line makes a probe on how you write likely. If you have written material you can show or describe, say what it was and who it was for; if you have none, say so plainly and say how you would structure your first post-event review |
| F9 | Leading people — not in the JD, which asks for coordination; a role-family expectation | "Never led a team" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never led a team." Then how you would work with teams you do not lead, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Familiarity with in-app-purchase economies — not in the JD; a role-family expectation for mobile titles | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

No row is a gate: the JD names no location, pay, schedule or credential term.

## Persona table

Weights start from the relationship prior for a hiring manager (Case/Strategist and Skeptic), then adjust for the JD's emphasis on retention and KPIs (Prober up) and for the loop. Your note establishes one 60-minute session with Tobias and nothing about other rounds, and no loop source names a values-style round, so Values/Behavioral stays low. If you know something that changes this, say so and the banks reweight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 5 questions) | Live problems from the role: plan this calendar, diagnose this drop | High: hiring-manager prior, and the JD is a planning-and-running role | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic (B, 5 questions) | Quiet probing of the gaps: live-service years, in-app purchases, leading | High: hiring-manager prior, and F1, F2, F9 and F10 are where the material is thinnest | Rehearse the single most predictable objection until it is boring; bridges only from what you stated, with the limit said plainly |
| Data-Driven Prober (C, 3 questions) | Retention numbers and KPIs examined line by line | Medium: the JD names retention metrics and KPIs, and you presented monthly retention numbers | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (D, 3 questions) | Friendly opener and casual questions that are still scored | Medium: interviews open this way, and it is the hardest register to take seriously | Pre-script a 90-second arc; treat casual questions about the JD's topics as scored |
| Values/Behavioral (E, 2 questions) | Scenario probes about disagreement and hard messages | Low: no values-style round is documented for this loop and no published values were in hand | Pick stories where the hard truth landed; if none comes to mind, say so plainly |
| Pressure (F, 2 questions) | Time-boxed challenges to your claims | Low to medium: a head of function may test composure on the gaps | Pause, restate, hold through two follow-ups, concede specifically |

The Peer Evaluator is not banked: Tobias is a head of function, not a peer, under the relationship assumed above.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit the live-events calendar for two mobile titles, with eight weeks of content already in flight. Where do you start, and what do you need to know first?" | CASE | [generic] | Structure it aloud: what you would ask first (what each title's events are meant to achieve, what is locked, who signs off), the objective, how you would split the two titles, your approach to the next eight weeks, the measures you would watch, and the risks. The question needs no claim about your past, so the guidance makes none | The JD's first duty is the two-title calendar (F2); CASE because it is a live planning problem, `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "Design, art and engineering each want a different date for the same update. How do you decide, and what do you tell each of them?" | CASE | [generic] | Clarify what is actually fixed and what is preference, say what you would need from each team, state how the decision gets made and by whom, and say what you would tell each team and when. No claim about your past | The JD's coordination line (F4) as a decision problem; CASE because it scores structure under conflict |
| A3 | "A key metric on a live event is well below expectation on day two. Diagnose it." | CASE | [generic] | Ask which metric, against what baseline and for which players first; separate what changed (the event, a release, a bug, communication) from what did not; say what you would check first and what decision each finding would drive. No claim about your past | The persona's standard diagnostic stem, tied to the JD's KPI ownership (F5) |
| A4 | "An update ships Thursday and QA has just found a blocking bug. Walk me through your next hour." | CASE | [generic] | Clarify severity and scope, who needs to know now, what the options are (fix, delay, scope down), who decides, and what gets written down. No claim about your past | The JD's release-checklist duty with QA (F6) as a pressure case |
| A5 | "How would you decide what goes into a post-event review, and which KPIs it reports? How would you write it up so it gets read?" | CASE | [generic] | Start from what the event was meant to do and pick measures that answer that; say what decision the review should enable and how you would write it for readers who are not producers. No claim about your past | The JD's post-event-review and written-communication lines (F5, F8), asked as a method rather than a history |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role asks for three years producing live-service games or apps. How does your time as an associate producer map to that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Hold what the quotes carry: "I spent 4 years as an associate producer at a puzzle-game studio, and I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-service wording makes a probe on how your studio's title was run likely. Say how the weekly content drops fit into how the game was run, in your own words; if the title was not run that way, or you had no part in it, say so plainly and stay with the calendar you ran | F1 is the headline requirement and the material does not show it reached; JD because it scores the listed qualification |
| B2 | "You've said you've never worked on a game with in-app purchases. How would that show up in this role?" | JD | [grounded] "never worked on a game with in-app purchases" | The highest-ROI rehearsal in this pack. Say the limit before it is asked for: "I've never worked on a game with in-app purchases." Then a plan, never a past: in your first weeks you would ask how an event's results are read today, read the recent post-event reviews, and ask the team which numbers they treat as the success measure. Hold through two follow-ups by repeating the plain statement, then concede exactly what you do not know yet; do not fold on the rest of your background to restore harmony | F10 is a stated gap in a mobile live-ops role and the likeliest place a skeptic presses, so this objection arrives in some form; JD because it scores the role's terms |
| B3 | "You've said you've never led a team. This role coordinates design, art, engineering and community on each update. How would you get four teams moving to one date?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say it plainly: "I've never led a team." Then answer slot: the JD's coordination line makes a probe on how work with those teams was arranged likely. If you worked with any of those teams on a drop, say which and how it was agreed, in your own words; if you did not, or someone else did that, say so plainly and return to "I ran the weekly content-drop calendar for our main title for the last two years." Your material does not show either way whether you coordinated across those teams, so do not claim it | F9 and F4 together; JD because it scores the coordination duty against a stated gap |
| B4 | "You ran the calendar for your studio's main title. What changes when it is two titles at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on scale likely. Say what else your calendar work covered besides the main title, if anything; if nothing, say so plainly. Then answer as a plan: what you would ask first about the second title and what you would keep separate | F2 is adjacent evidence with a limit; JD because the two-title scope is stated in the JD |
| B5 | "Why a live-operations role at a mobile studio, and why now?" | JD | [generic] | Selection scaffold, in your own words: one thing in this JD you are moving toward (quote its line), one sentence from your background that carries over, and what you are not claiming. If no clear reason comes to mind, say so plainly, then give the nearest true thing. The pack supplies no reason; it is yours | The standard motivation probe for a Skeptic; `[generic]` because your note stated no motive |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Answer slot, four parts in your own words: how the numbers were counted, what they are most sensitive to, the assumption you would defend least, and which part was yours. If you built or pulled them, say so; if someone else produced them and you presented them, say so plainly and describe what you did with them. "I don't know how that was counted" is an honest branch | F7 is the CV-style headline number and probers go two levels deep on it; EXP because it tests attribution |
| C2 | "The role owns the KPIs the post-event review reports. Which retention measures would you put on a review, and what would you do with a result?" | JD | [generic] | Name measures you actually know and say what each would tell you; say what decision a result would change. Answer slot: if a decision at your studio ever followed from a retention number, say what and what part was yours; if none did, say so plainly and answer as a plan | F5 and F7; JD because it scores the listed KPI duty |
| C3 | "'Comfortable with player-retention metrics': which ones are you most comfortable with, and which least?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Name only the measures you have actually read in those monthly numbers, and say plainly which you have not worked with. The pack names none for you. Calibrated candor beats a long list you cannot defend on the second follow-up | F7; JD because it restates the requirement as a self-assessment |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with four beats, each one a clause from the quotes: the years as an associate producer at a puzzle-game studio, the weekly content-drop calendar you ran for two years, the release checklist QA still uses, the monthly retention numbers you presented. Add why this role in your own words; the pack does not supply the motive | F1 to F7; EXP because it is the CV walk-through, and a casual opener is still scored |
| D2 | "Tell me about the release checklist QA still uses. How did it come about?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Beats the quote states: you wrote it, QA still uses it. Answer slot: the JD's QA line makes a probe on how it was made with QA likely. If QA shaped it, say how, in your own words; if you wrote it alone and handed it over, say so plainly. Say "wrote", not "managed" | F6; JD because it scores the QA duty, delivered conversationally |
| D3 | "What are you playing these days, and have you played ours?" | CO | [generic] | Before Friday, play both of the studio's mobile titles yourself and note in your own words what you saw in their events and what you would ask about. The pack could not research the company, so it supplies no facts about the titles; anything you say about them must come from your own play | The only CO question the pack can honestly offer without research; casual register, still scored |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time with a named stake, what you said, and how the relationship stood afterwards. Your material says you presented the numbers; whether any presentation carried bad news is not in it. If one did, say what, in your own words; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's standard values stem; low weight because no values round is documented |
| E2 | "Tell me about a time you and another team disagreed about when something should ship." | VAL | [generic] | Selection scaffold: pick a time with a named stake, the other team's reason, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's coordination line (F4) as a behavioral probe; `[generic]` because no quote carries this story |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team" | Pause and restate the question. Hold on what the quotes carry: you ran the weekly content-drop calendar for your main title for two years, and you wrote the release checklist QA still uses. Concede exactly, once: "I've never led a team." Hold through two follow-ups by returning to the same facts rather than adding to them | F2 and F9; JD because it scores the qualification against a stronger rival |
| F2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if others shaped parts of it, say which parts were yours; if it was entirely yours, say so; if the writing was shared in a way you are not sure how to describe, say so plainly. Never round shared work up | F6; EXP because the persona's standard attribution probe |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B4, F1 |
| "coordinate design, art, engineering and community teams on each update" | A2, B3, E2 |
| "own the post-event review and the KPIs it reports" | A3, A5, C2 |
| "manage the release checklist with QA" | A4, D2, F2 |
| "3+ years producing live-service games or apps" | B1, D1 |
| "experience running a content calendar" | A1, B4, D1 |
| "comfortable with player-retention metrics" | C1, C2, C3 |
| "clear written communication" | A5, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good live event look like here, and which numbers do you look at first when one finishes?" | It shows you think from the post-event review outward, and the answer tells you how the KPIs you would own are read |
| R2 | "Which part of getting an update out takes the most effort today: design, art, engineering, community or QA?" | It uses the JD's own coordination terms and surfaces where the role's friction sits |
| R3 | "How do in-app purchases figure in how events are planned and reviewed here, and what should I learn first about that side of the job?" | It turns the stated gap in B2 into a ramp conversation instead of leaving it as an objection |
| R4 | "How are the release checklist and QA sign-off handled today, and what would you want to be different?" | It connects your checklist work to their process and invites them to say what they want changed |
| R5 | "What would you want to have seen from me by the end of the first month?" | It asks for a concrete bar, and it is a stronger close than "I think you've covered everything" |

## Prohibited claims

What this pack will not coach, and why. These are claims a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Produced a live-service title | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says the years and the associate-producer title, not how the title was run |
| Planned and ran a calendar across more than one title | Inflated form of F2 | F2's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Your material says one main title |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. Your material says presenting the numbers, not producing them or owning a review |
| Managed releases with QA | Inflated form of F6 | F6's quote at its own scope: wrote the checklist QA still uses. Your material does not say you managed the releases |
| Analysed retention data and drove decisions from it | Inflated form of F7 | F7's quote at its own scope: you presented the monthly numbers. How they were produced is C1's slot, not a claim |
| Led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never led a team." No slot |
| Worked on in-app purchases | Negative you stated, F10 | The plain acknowledgment F10 gives: "I've never worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD text and your background, both as written in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search was sent and refused: web search was not permitted in this session. Nothing from the web is used in this pack.

| Query | Outcome |
|---|---|
| Saltmarsh Games mobile game studio values | refused |
| Saltmarsh Games interview process Live Operations Producer | refused |
| Saltmarsh Games news strategy mobile titles | refused |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have named the published values for VAL questions; E1 and E2 are themed from persona stems and the JD instead |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have documented the loop; persona weights rest on your note and the hiring-manager prior |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have grounded a strategy-based CO or CASE question; D3 is the generic substitute |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have supplied the interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission for web research → the company's published values, documented loop structure, current strategy, and Tobias's public professional footprint; this would add a grounded CO or CASE question, an interviewer read, a reverse question tied to his career path, and weights read from his stated style. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief
- Whether Tobias would be your manager or sits above that manager → reweights every bank
- The recruiter's prep email, if one exists → any announced focus areas or deliverable, and any terms such as location or pay the JD does not state
- Your answers to the answer slots on F1, F2, F4, F5 and F8 → those rows become story-mapped and B1, B3, B4, C1 and D2 get sharper guidance
- A written piece you can share, such as a note you wrote for your team → a stronger answer to F8's clear-writing requirement
- A `tuesday-dossier.md`, if you have one → verified evidence and a named objection for the guidance cells
