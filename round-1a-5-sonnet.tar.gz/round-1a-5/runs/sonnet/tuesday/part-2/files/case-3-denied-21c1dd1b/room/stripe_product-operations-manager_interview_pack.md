# Stripe — Product Operations Manager: final-round interview pack

Round: final round. Interviewers: not known. Relationship: not known. Built from your one-line request alone: no job description, no CV, no interviewer information, and the web research I attempted was refused, so nothing in this pack is a fact about Stripe. Every row is labeled `[generic]`, which means a role-family pattern with no claim about Stripe or about you.

## How to use this pack

- Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored.
- Type key: **VAL** behavioral and values alignment; **EXP** work-experience deep-dive; **JD** role and job-description-driven; **CO** company and strategy knowledge; **CASE** hypothetical or live problem.
- Guidance is scaffolding, not a script. Where it asks you to pick an example, the example has to be yours, told in your own words. Where nothing comes to mind, the honest answer is to say so.
- Rows with nothing about you in them carry their label alone in the Provenance column. Once you add your background, the rows regenerate with your own sentences quoted beside the label.

## Persona table

No loop source establishes how this final round is structured, so the pack falls back to the Generic archetype (screen, hiring manager, panel) and says so: the weights below rest on a pattern, not on Stripe's documented process. A final round may be several sessions with different people; the pack does not assume a schedule.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gap between your background and the role; why this role, why now | Equal. No relationship is known, so no prior favors it; a final round tends to test motivation, so it gets a full bank | Rehearse the single most predictable objection until it is boring; build bridges only from experience you can name |
| Case / Strategist | Live problems set in the role: plan this, diagnose that | Equal. A product-operations role is process-and-judgment work, so live problems are plausible in any session | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values / Behavioral | Scenario probes, often from outside the function | Equal. Not detected as a named round: no loop source was read | "We" for context, "I" for contribution; pick stories where the hard truth actually landed |
| Data-Driven Prober | Goes two levels deeper on any number or analysis you offer | Equal. Applies to anyone who has reported metrics | Know how each number was counted and say plainly when you do not; name your weakest assumption before they do |
| Pressure / Stress | Interrupts, time-boxes, plays devil's advocate | Equal. Often appears in a final or skip-level conversation, but no seniority is known | Pause, restate the question, hold a position through two follow-ups, concede specifically rather than fold |
| Peer Evaluator | Seam-splitting with adjacent teams, credit, disagreement | Equal. A cross-functional role is likely to meet peers somewhere in the day | Reciprocity framing: what you bring their team; propose seam principles rather than pretending to know the seam |
| Conversational / Rapport | Friendly, unstructured; still scored | Equal. Openers like the biography question are near-universal | Prepare a 90-second arc; never answer "I think you've covered everything" to the reverse-question slot |

Flat weights, so each bank has three questions (21 in all). The highest-ROI prep without your background is **A1**: some version of "where would you be weakest" is the most predictable question for any candidate. Once I know your background, I can name your specific objection.

## Fit snapshot

No job description and no background were supplied, so this is the worksheet variant. The requirements are role-family patterns written as plain prose, not quotations from a posting. Evidence cells are empty until you give me your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches and programs across product, engineering and go-to-market teams (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a named launch or program, who was involved, and which part you owned. Selection scaffold: pick one cross-team effort where your part is clear to you; it needs a named stake and your own role stated plainly. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Running operating cadences: planning, reviews, status and escalation (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a recurring process you ran or changed, and what happened to it. Selection scaffold: pick a recurring meeting or review whose design you can describe; say what was yours to set. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using data to find and prioritize process problems (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a specific figure you used, how it was counted, and a decision it changed. Selection scaffold: pick an analysis you did yourself, ideally one you can walk through end to end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing senior stakeholders and driving decisions without direct authority (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a decision you helped reach that you did not have the authority to make alone, with the disagreement named. Selection scaffold: pick a time a senior person disagreed with a recommendation of yours. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Designing lightweight product-lifecycle processes: intake, prioritization, launch readiness (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a process you built or fixed, and how you knew it worked. Selection scaffold: pick a process you changed and what you measured afterward. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Working with technical and product depth in a fast-moving, ambiguous environment (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is work done where priorities shifted, and how you stayed useful to engineers and product managers. Selection scaffold: pick a period of change and describe your role in it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

Requirement coverage, mapping each row to the questions that cover it:

| Requirement | Questions |
|---|---|
| F1 | B1, G1, G3 |
| F2 | B2, E3, H2 |
| F3 | B3, D1, D2, D3 |
| F4 | C1, E1, E2, G2 |
| F5 | B2, C3, A3 |
| F6 | A1, A2, C2, H1 |

## Question banks

Question IDs skip the letter F so they do not collide with the fit-snapshot rows.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Pick one real gap you can name, say it plainly in one sentence, then give a concrete ramp plan: who you would talk to, what you would read, what you would ship first. Calibrated candor beats bluffing a competency the interviewer may own. If you can name no gap, say what you would verify in week one | Some form of this question is near-certain in a final round. JD because it scores the stated role; F1 to F6 are all candidates for the answer |
| A2 | "Why Product Operations, and why now?" | JD | [generic] | Give a two-part answer in your own words: what draws you to the work itself, and what in your path makes now the right time. Keep it to what is true; it should survive a follow-up asking what you would do if the role changed shape. If part of the answer is "I am still working that out", say so plainly | Motivation consistency is what the Skeptic scores. Tagged JD because it tests whether you understand what the job is |
| A3 | "Product operations means different things at different companies. What do you think the job is here, and what would make you wrong?" | CO | [generic] | State your working definition in one or two sentences, name the one assumption in it you are least sure of, and say what you would ask to test it. Where you have read something specific about the company, name the source; where you have not, say so and ask. Do not present a guess about the team as fact | Tests whether you can hold a hypothesis openly. CO because it needs company-specific homework, which this pack could not research; F5 is the process side of the answer |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A product launch has slipped twice and three teams each blame another. You are the product operations manager. What do you need to know first, and what do you do in the first week?" | CASE | [generic] | Clarify first: what the launch is, what slipped and why, who owns each dependency, what the deadline's real cost is. Then objective, a short list of hypotheses, a plan for the week, and how you would know it is working. Challenge one premise, such as whether blame is the right frame. The question needs no claim about your past | Live problems from the role's core coordination work (F1). Structure is scored over the "right" answer |
| B2 | "Every team says the planning process is too heavy, yet roadmaps still arrive late. Design the lighter version. How do you know it worked?" | CASE | [generic] | Diagnose before designing: where the time goes, which steps carry decisions and which carry reporting. Propose a minimum viable cadence, who decides what, and two or three measures you would watch. Say what you would remove and what you would refuse to remove. No claim about your past is needed | Tests process design and judgment on a classic product-operations problem (F2, F5) |
| B3 | "An adoption metric dropped 20% after a release. Diagnose it." | CASE | [generic] | Clarify definition and instrumentation first, then segment: time, cohort, platform, funnel step. Separate real change from measurement change before explaining anything. Say aloud which hypothesis you would test first and why. State what you would need that you do not have | Metric-diagnosis is the standard way to score data reasoning without a CV (F3) |

### C. Values / Behavioral

Values-style questions here follow persona stems, not Stripe's published values: no values page was read, so no mapping to named values is offered.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the message was unwelcome, you were the one who delivered it, and the relationship was intact afterward. It needs a named stake, what you actually said, and how it landed. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard persona stem for the Values interviewer; F4 is the requirement it feeds |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an example with a real tradeoff, where the internal metric would have looked better had you chosen the other way. Name the tradeoff, your decision, and what it cost. Do not claim the customer won if it is not true. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; scores whether past behavior shows customer judgment, not generic virtue (F6) |
| C3 | "How do you decide when to move fast and when to slow down for quality?" | VAL | [generic] | Describe your decision rule in your own terms: what makes a mistake cheap to undo versus expensive, who you consult, what you would do differently on a launch than on an internal process. Offer an example only if it is genuinely yours. No claim about your past is needed | An approach question that carries no premise about your history; it tests judgment in the tension a product-operations role lives in (F5) |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What would you measure to know a launch process is healthy?" | CASE | [generic] | Name three or four measures, one leading and one lagging, and what each would and would not tell you. Say how you would avoid gaming and what would make you change the measures. State which one you would trust least | Probers ask for the metric before the process; this needs no claim about your past (F3) |
| D2 | "Pick a number you have reported to leadership. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick a figure you can explain end to end. Prepare four things in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Offer the weakest assumption before they ask. If you do not know how it was counted, say so plainly, then say how you would find out | Probers go two levels deeper on any figure (F3); this is the defend-the-number rehearsal, ready before your numbers are known |
| D3 | "Choose one analysis you did yourself and walk me through it end to end." | EXP | [generic] | Selection scaffold: pick something where you can cover the question, the data, the method, the result, and what changed. Say what was yours and what was not. If no analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Offering an end-to-end walkthrough is the Prober's counter-strategy; F3 is the row it feeds |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give one reason tied to the role, one tied to how you work, and stop. Do not disparage anyone. Hold your position through two follow-ups; if they push, concede one specific uncertainty, not the whole case. Say only what you can support | Tests composure and economy under a time box (F4) |
| E2 | "Choose one result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result where you can separate your part from the team's. Say what was yours in one sentence, name who else mattered and what they did, and hold that position through two follow-ups. If part was not yours, say so plainly; that reads as credibility. If no such result comes to mind, say so, then give the nearest thing your material does carry | The attribution probe exists to catch inflation; rehearsing candor is the preparation (F4) |
| E3 | "I am not convinced this role needs to exist. Convince me." | CO | [generic] | Do not defend the role abstractly. Say what problem it would solve, for whom, and what you would look at to tell whether it is solving it. Concede the strongest version of the objection, then give the condition under which you would agree. Stay calm and short. Where you lack company-specific knowledge, say so rather than guessing | Devil's-advocate probe of motive and understanding (F2, F5) |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know their seam: who decides, who informs, how a disagreement is escalated and recorded. Say what you would need from them and what you would offer. Show spine and tact together | Peers price what the hire adds to or removes from their load (F1) |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your practice in plain terms: how you attribute, how you correct the record when credit is misplaced, and why. If you have an example that is truly yours, one sentence is enough; otherwise stay with the principle | Credit-sharing probe from the Peer persona (F4) |
| G3 | "What would you need from me in your first month, and what could you give my team?" | JD | [generic] | Answer both halves: two or three specific asks (context, access, introductions) and one thing you could deliver early that reduces their load. Keep the offer modest and honest about what you could not yet know | Reciprocity framing; asking for help and offering help both get scored (F1) |

### H. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in your own words: where you started, the two or three turns that mattered, and why this role is the next one. Every turn should be something you actually did; end on the present, not the past. Casual register is still scored | The biography question is near-universal and sets the frame for everything after (F6) |
| H2 | "What are you actually playing with these days in how teams plan and ship work?" | JD | [generic] | Name one thing you are genuinely experimenting with, such as a tool, a ritual or an idea, and say what you have learned. If nothing is true for you right now, say so and name what you would like to try | Rapport interviewers ask casual questions about hot topics for the role and still score them (F2) |
| H3 | "What have you read recently about where Stripe is headed, and what does it mean for this role?" | CO | [generic] | This pack could not research Stripe, so it supplies no facts. Do the reading yourself: name one or two sources you actually read, say what you took from them, and tie it to the work. If you have not read anything yet, say so plainly and say what you would read first. Do not repeat a point you cannot source | Homework depth is scored; this stays generic until research runs. Labeled `[generic]` for that reason |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What does a great first six months look like in this role, and what would make you say it was a miss?" | Shows you are thinking about outcomes, and its answer reveals how success is actually judged |
| 2 | "Where do product, engineering and go-to-market most often get stuck on each other, and what has been tried?" | Signals you understand the seam work the role exists for, and invites a candid account of a real problem |
| 3 | "How does product operations show up in planning and launch reviews today, and where is it still missing?" | Shows you want to find the real scope rather than assume it |
| 4 | "What did the last person or team that did this work get right, and what would you change?" | Draws out the honest expectations behind the role |
| 5 | "How do you decide what operations work is worth doing versus leaving to the teams?" | Shows you think about prioritization of your own effort |
| 6 | "What is the thing you wish candidates asked about this team and almost never do?" | Opens a peer-level conversation and rewards the interviewer for sharing |

## Prohibited claims

Nothing is listed. You have not supplied any sentence about your own past, so there is no stretched wording to guard against, and every answer slot above leaves room for the honest branch. As soon as you give me your background, this section is rebuilt from it before the banks are rewritten.

## Sources

Provided documents: your one-line request only. No job description, CV, interviewer information or dossier.

Search queries sent, all refused (permission to search was not granted):

- "Stripe operating principles values" — refused
- "Stripe interview process Product Operations Manager" — refused
- "Stripe strategy 2026 news annual letter" — refused
- "Stripe Product Operations Manager job description" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Every call was refused. Would have moved the values cheat sheet and the VAL bank; both are generic here |
| 2. `Stripe interview process Product Operations` | unavailable | Every call was refused. Would have moved persona weights and what the final round contains; weights are flat and the loop archetype is Generic |
| 3. `Stripe strategy` / recent news | unavailable | Every call was refused. Would have moved the CO bank, H3 and A3, which stay generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Every call was refused. Would have moved the fit snapshot's requirements and the JD-tagged questions, which are role-family patterns |

## Upgrade menu

- The job description text, or a link to it → the six `[generic]` fit rows become quoted requirements, and the JD-tagged questions turn `[grounded]`
- Your CV or a paragraph on your background → the evidence column fills with your own sentences, the question banks switch from selection scaffolds to story maps, and your most likely objection replaces the generic A1 placeholder
- Who you are meeting in the final and how they relate to the role (future manager, peer, cross-functional, skip-level), and their names if you have them → reweighted personas, an interviewer read, and a reverse question tied to their path
- The schedule, if your final is several sessions → per-session mini-packs
- The recruiter's prep email, if there is one → coverage of any focus areas or a pre-declared assignment
- Permission to search, or Stripe's published values and an interview-process source pasted in → the values cheat sheet, current-strategy CO questions and a documented loop in place of the generic archetype
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a strategy brief behind the CO bank
- A saved `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and prohibited claims carried in, never required
