# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not provided. Round: assumed to be a hiring-manager conversation, because your note did not say who you are meeting or which round it is. Mode: session. Built from the JD lines you pasted and the six sentences you wrote about your background. If the round or the person differs, the banks reweight.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Every question carries one persona (its bank), one type, a provenance label and the sentences of yours its guidance rests on.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the traits asked about, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Homework depth on the company's strategy and moves |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Where it quotes you, say it in your own words. Where it holds an answer slot, answer from what really happened: the second branch of every slot is always allowed. Bank letters skip F so they never collide with fit-snapshot rows F1 to F7. The highest-ROI prep in this pack is B1.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your quotes carry a shift-manager role and a site's surge plan, and the words stay there: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Your material says warehouse and distribution work, not terminals, and a shift and a site's plan, not four sites; that is the pack's observation, not words for you. Answer slot: the JD's four-sites line makes a probe on scope likely. Say what your own shift and the site's surge plan covered and which decisions were yours, in your own words; if a decision was not yours, say so plainly and stay with what you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your quote carries the mis-pick rate and the pick path, and the words stay there: "I cut the mis-pick rate 40% by redesigning the pick path." Your material does not show on-time performance or cost per shipment; that is the pack's observation, not words for you. Answer slot: the JD names both measures, so expect a probe on them. If you tracked either alongside the mis-pick rate, say which and what you know, in your own words; if you did not, or you cannot say, say so plainly and stay with the mis-pick rate |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The words stay at your quote's scope: "I'm currently a senior shift manager over 3 supervisors." The JD's number is twelve and yours is three, and the pack does not close that gap with wording. Answer slot: if asked how you lead the supervisors you have, say what you do, in your own words; if part of it is not yours, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD, the Excel half | "solid Excel" — your message | low | [inferred] | discovery | Derived from the JD's reporting line set against a self-description: "solid Excel" touches the requirement without showing what the Excel is used for. The words stay at your quote: "My Excel is solid." Answer slot: expect a probe on what you use it for. Say what you use it for, in your own words, and stay with that; if it is not reporting, say so plainly |
| F5 | "build reporting in Excel/Power BI" — JD, the Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then a plan stated as a plan, in your own words: what you would do first to learn it and how soon. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your quotes show seven years in operations and a current management role, not how many of those years were leadership, so the words are an answer slot. Expect the probe: give the number from your own record, with the roles it covers, in your own words; say it plainly whatever it is, and do not round up |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | discovery | Your quote says green belt and not which discipline, so name the certification in full in your own words: what the belt is in and who awarded it. Nothing inspected sits behind it, so expect a probe. Answer slot: if asked where it shows up in your work, answer from what you did; if nothing yet, say so plainly and stay with the certification |

## Persona table

Weights rest on the hiring-manager prior, with no interviewer signals and no documented loop, so no loop tilt is applied: the loop is on the Generic archetype, flat. If you are meeting a peer, a recruiter or a panel, the weights change.

| Persona | How it shows up | Likelihood and why | Counter-strategy | Bank |
|---|---|---|---|---|
| Case / Strategist | Live problems from the role: diagnose this, plan that | High: the hiring-manager prior, and the JD's on-time, cost and reporting lines are natural case material | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | A, five questions |
| Skeptic | Quiet, persistent probing of gaps and motive | High: a hiring manager is derisking, and F1, F3 and F5 give it targets | Rehearse the single most predictable objection (B1) until it is boring; bridges only from your quoted sentences; plans said as plans | B, four questions |
| Data-Driven Prober | Reads your claims line by line and asks how the number was counted | Medium: one headline figure (F2) invites a defend-the-number probe | Say plainly what you can and cannot say about how the figure was counted; name the assumption you would defend least before they do | C, three questions |
| Pressure / Stress | Time-boxes, interrupts, asks how much was actually you | Medium: the scale gap (F1, F3) and the years line (F6) are easy to press | Pause, restate, anchor in what you quoted, hold through two follow-ups, concede specifically | D, three questions |
| Conversational | Friendly opener such as walk me through the journey | Low: no basis in the material to weight it higher, but an opening biography question is kept because it is scored | A 90-second arc built only from your quoted sentences | E, two questions |
| Peer Evaluator | Seam-splitting between sites and teams | Low: the relationship is assumed to be a manager, not a peer | Propose seam principles rather than pretending to know the seam | G, two questions |
| Values / Behavioral | Scenario probes on behavior | Low: no loop source documents a values round and no company values were researched; themes here come from persona stems | A selection scaffold that ends in its honest branch | H, two questions |

## Question banks

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one site has slipped over the last few weeks. How do you diagnose it?" | CASE | [generic] | Clarify first: which site, which lanes or customers, and what on time is measured against. Then state the objective, split the problem by site, shift, day and cause, name the measures you would look at, and say what risks come with acting on thin data. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's on-time line, which F2 covers, set as a live problem. CASE because it scores structure, not history |
| A2 | "Cost per shipment is rising at one site while on-time performance is flat. Where do you look first?" | CASE | [generic] | Same sequence as A1. Say what you would need to see before deciding where to look, then give your first guess aloud and call it a guess. No claim about your past | The JD's cost-per-shipment line, which F2 covers, as a diagnosis. CASE because it scores reasoning under uncertainty |
| A3 | "You start on Monday with twelve supervisors across four sites. What do your first thirty days look like?" | CASE | [grounded] | Structure it as a plan: what you would ask each supervisor, what you would look at before changing anything, what you would tell the sites in week one, what you would report and to whom. Say it as a plan and never as a past. No claim about your past | The constructive half of B1: F1 and F3 are the scale gap, and this is where you show how you would approach it. CASE because it asks for a plan, not history |
| A4 | "Sketch the weekly report you would give the four sites. What is on page one?" | CASE | [grounded] "solid Excel, never used Power BI" | Design it on its own terms: who reads it, what decision it supports, a short list of measures, how often it refreshes, how you would check the numbers. If asked about your own Excel, say what you use it for, in your own words. If asked about Power BI, say "I have never used Power BI," then give your plan as a plan, in your own words | The JD's reporting line; F4 and F5 are why this is likely. CASE because the design is live, with JD content |
| A5 | "Peak season is coming and the volume forecasts are shaky. How do you plan the surge?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open with your quote's words: "I ran the site's peak-season surge plan two years running." Then structure the hypothetical on its own terms: objective, capacity levers, triggers, what you tell people and when. If asked what your plan covered, say so in your own words and which parts were yours; if a part was not yours, say so plainly | F1 holds the sentence this opens with. CASE because it sets a live problem rather than asking for the history |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You manage three supervisors today, and this role has twelve across four sites. What makes you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Open by stating your own scale before they do, in your quote's words: "I'm currently a senior shift manager over 3 supervisors." Say what you do in that role, in your own words, and do not borrow the JD's numbers. Answer slot: the jump is the probe, so say what you would do first in the role as a plan and not a past; if you have no plan yet, say what you would find out first. Follow-up 1, "Three is not twelve": hold by returning to the quote, adding nothing. Follow-up 2, "What breaks first at four sites?": name one thing in your own words and call it a guess. Follow-up 3, "What would you need from me to make it work?": answer as a plan. Concession wording: "Twelve is a larger team than the three I lead today." Let the interviewer draw the inference from what you did | F1 and F3 are the biggest gap in the snapshot, so this objection arrives in some form. JD because it scores the stated requirement |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "solid Excel, never used Power BI" | Choose by what is true for you; the material shows two candidates, the scale of the role (F1, F3) and Power BI (F5). If Power BI: say "I have never used Power BI," then your plan, as a plan, in your own words. If scale: "Twelve is a larger team than the three I lead today," then what you would find out first. Pick one and say it plainly; do not hedge across both | The persona's own stem, aimed at the snapshot's stated gaps. JD because it scores honest self-assessment against the listed job |
| B3 | "Your background is warehouse and distribution, and this role is terminal operations. What is different, and what would you need to learn?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: say what you know differs, in your own words; if you cannot name a difference yet, say so plainly and say what you would find out first in your first weeks, as a plan. Do not describe terminal work you have not done, and do not present warehouse work as terminal work | F1 covers the terminal requirement. JD because it scores the listed job and where your background meets it |
| B4 | "Why this role, and why now?" | EXP | [generic] | You gave this pack no reason, so it supplies none. Give your actual reason in your own words, make it about the job in front of you, and keep it the same as what you tell anyone else who asks | A motivation probe sits in most loops. EXP because it tests whether your story is consistent under cross-examination |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% cut in your mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it as you wrote it: "I cut the mis-pick rate 40% by redesigning the pick path." Four slots, each answered in your own words: how the rate was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of the redesign was yours. The pack names none of them. If you do not know how it was counted, say so plainly. Name your weakest assumption before they do | F2's headline figure. EXP because it tests whether the figure survives scrutiny and what was yours |
| C2 | "This role is measured on on-time performance and cost per shipment. Which of those have you tracked?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start from your quote: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked either measure alongside the mis-pick rate, say which, in your own words; if you did not, or you cannot say, say so plainly and stay with the mis-pick rate | The JD names both measures and F2 shows what the quote reaches. JD because it scores the stated requirement |
| C3 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats are the ones your sentence states: the site's surge plan, two years running. Say it as "I ran the site's peak-season surge plan two years running," then tell the rest in your own words: what the plan was and what your part was. Nothing further is supplied here; if a part was not yours, say so plainly and return to the sentence | F1 holds the sentence. EXP because it tests what was actually yours |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who already runs multiple sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause and restate the question. Anchor in sentences you can defend line by line: "I cut the mis-pick rate 40% by redesigning the pick path," "I ran the site's peak-season surge plan two years running," "I'm green belt certified." Describe what you did and let them draw the inference. Hold through two follow-ups by returning to those sentences, adding nothing. Concede specifically: "Twelve is a larger team than the three I lead today." | F1 and F3 make this the pressure form of B1. JD because it scores fit to the listed job |
| D2 | "That 40% result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The held position is only what the quote carries: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts of the redesign were yours, in your own words; if parts were done by others, or the decision was not yours, say so plainly and return to the sentence. Hold through two follow-ups by returning to the sentence, and concede the specific part that was not yours the first time it is asked, not the third | F2's figure under attribution pressure. EXP because it tests candor about your own share |
| D3 | "Five years of operations leadership is required. How many of your seven years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A time-boxed number question: give the number, then stop. Give the figure from your own record, in your own words, with the roles it covers, and say it plainly whatever it is. If the roles carried different amounts of leadership, say so and do not round up. If you cannot give the number now, say you will confirm it, and confirm it before the interview | F6 is the row behind this. JD because it scores the stated years line |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc whose beats are your four sentences in this order: seven years in warehouse and distribution operations; currently a senior shift manager over 3 supervisors; the 40% cut in mis-pick rate by redesigning the pick path; the site's peak-season surge plan, two years running. Your employers, titles and dates are yours to add, in your own words | An opening biography question is scored even when it sounds casual. EXP because it tests communication economy and consistency with the CV |
| E2 | "I see Lean and Six Sigma on the posting as a plus. Where does that show up in your work?" | JD | [grounded] "green belt certified" | Name the certification in full, in your own words: what the belt is in and who awarded it. If asked where it shows up in your work, answer from what you did; if nothing yet, say so plainly and stay with the certification | F7 covers the plus-line. JD because the JD raises it, in a casual register |

### Bank G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Four sites, twelve supervisors: where does a supervisor's call end and yours begin?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Propose seam principles as a starting point you would test with the supervisors, rather than pretending to know their seam. If asked how you divide decisions with the supervisors you have today, say what you do, in your own words; if there is no fixed line, say so plainly | F3's scale line asked collegially. JD because it scores the stated team requirement |
| G2 | "How do you handle credit when work spans sites?" | VAL | [generic] | Pick one occasion from your own material where work crossed teams, name your part and theirs, and say how it landed. If no such occasion comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's own credit stem. VAL because it scores behavior toward equals |

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time the message was unwelcome: name the stake, what you said, and how it landed; use I for what you said and we for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's own stem; no company values were researched, so no value is mapped. VAL because it scores behavior |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision where the two pulled apart: name what each side was, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's own stem, near the JD's on-time and cost lines. VAL because it scores a specific decision |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A3, B1, B3, D1, G1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, C2 |
| "lead a team of 12 supervisors" | A3, B1, B2, D1, G1 |
| "build reporting in Excel/Power BI" | A4, B2 |
| "5+ years operations leadership required" | D3 |
| "Lean/Six Sigma a plus" | E2 |

## Reverse questions

No interviewer profile exists, so none of these ties to the interviewer's path.

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would success look like in the first ninety days, and which numbers would tell us?" | It puts on-time performance and cost per shipment in the interviewer's own terms and tells you what you would be scored on |
| 2 | "Which of the four sites needs the most attention right now, and what is behind that?" | It shows you think in sites rather than one building and hands you a live problem to rehearse against |
| 3 | "How are on-time performance and cost per shipment reported today, and what tools does the reporting run in?" | It surfaces the reporting expectation behind F4 and F5 before you are hired rather than after |
| 4 | "Tell me about the twelve supervisors: where are they strongest, and where would they want support from this role?" | It addresses F3 by showing you plan to listen first |
| 5 | "What would you want to be different about how this role is run six months from now?" | It invites the interviewer's own priority, which no preparation can supply |

## Prohibited claims

This pack will not coach these. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Runs or has run terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope: "currently a senior shift manager over 3 supervisors" and "ran the site's peak-season surge plan two years running." The limit is the pack's observation, not words for you: the material says warehouse and distribution work, a shift and a site's plan |
| That your work improved on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path." The limit is the pack's observation: the material says the mis-pick rate. C2's slot asks only what you tracked |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors." The limit is the pack's observation: your quote says three |
| Built reports or dashboards | Inflated form of F4 | F4's quote at its own scope: "solid Excel." The limit is the pack's observation: the material is a self-description, not reports built |
| Has used Power BI | Negative the candidate stated, F5 | "never used Power BI" — your message. The plain acknowledgment: "I have never used Power BI." No slot |
| Held five or more years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops." The limit is the pack's observation: the material says years in operations, not years in leadership |
| Led Lean or Six Sigma projects, or that the pick-path redesign was one | Inflated form of F7 | F7's quote at its own scope: "green belt certified." The limit is the pack's observation: the material does not link the belt to any work |

## Sources

Provided documents: the JD lines pasted in your message, and your background as written in your message. No tuesday-dossier.md was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent:

- `Atlas Freight regional logistics company values`: refused
- `Atlas Freight interview process operations manager`: refused
- `Atlas Freight regional logistics strategy news`: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed the values cheat sheet and values-mapped VAL questions; neither is in this pack |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the loop's rounds and set persona weights; the pack uses the Generic archetype instead, flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have fed a CO bank; none is in this pack |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD lines you supplied already fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and which round, in your own words: reweights every bank and may add or drop a bank
- The interviewer's name and role: adds an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- Web search access for company research: the three searches above were refused in this session; with access the pack gains values, loop structure and strategy, a CO bank, and a values cheat sheet if a values round is documented. A deeper pass (up to 6 further searches and 2 further fetches, several more minutes) can run after that
- The full text of the posting: the pack rests on the six requirement lines you pasted; the full text may add requirement rows and JD-tagged questions
- The recruiter's prep email: adds coverage for any focus areas or pre-declared task
- Prep hours available: adds a prioritized prep schedule
- Your answers to the slots in F1, F2, F3, F4, F6 and F7, including how many of your seven years were leadership, which belt you hold and who awarded it, and whether you ever led more than three supervisors or worked beyond one site: those rows move from answer slots to quoted evidence
- The mis-pick report or site scorecard that shows the 40%, and your belt certificate: inspectable proof that can raise the confidence of F2 and F7
- A tuesday-dossier.md from a fit check by job-underwriter: would add an evidence-derived objection and prohibited claims in place of the ones inferred here; never required
