# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: one 60-minute interview, built on the assumption that Tobias is the hiring manager running the single session Saltmarsh's interviewing page calls the Outage Hour (a live-incident tabletop on a simulated outage during a live event, then a values conversation; no take-home).

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: where a cell quotes your sentence, say it in your own words at that scope; where it holds an answer slot, answer from your real experience or say plainly that the practice was not yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

You have until Friday. In order:

1. B1, aloud, until it is boring. It is the highest-ROI prep in this pack.
2. A1 and A2, aloud, once against a timer. The tabletop is half the session.
3. C1 to C3: pick real stories, or practise saying plainly that none comes to mind. Then B3.
4. Read the Project Larkspur announcement (A4, A5, V3) and watch Tobias's GDC talk if you can (V1).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | The words stay at the quote: "For the last two years I ran the weekly content-drop calendar for our main title." The quote says a content-drop calendar for one title; the pack observes it does not say live events or a second title. Answer slot: the JD's "two of our mobile titles" and "live-events" make a probe on both likely. If any drop was a timed event, or you worked on a second title's calendar, say which and how you planned it, in your own words; if not, say so plainly and stay with the weekly calendar for your main title |
| R2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with. Answer slot: the JD names four teams, so expect a probe on each. If you worked with any of them on a drop, say which and what you needed from them, in your own words; if you did not, or one was not part of your work, say so plainly and say how you would set up the working relationship |
| R3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The words stay at the quote: "I presented the monthly retention numbers to the studio head." Presenting is what the quote says; reviewing events and owning KPIs is not in it. Answer slot: the JD's "own ... the KPIs it reports" makes a probe on who chose what was reported likely. If you chose or defined any of what was in those numbers, say which, in your own words; if someone else set or built them, or there was no event review, say so plainly and stay with presenting them |
| R4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the quote's own terms: you wrote it, and the QA team still uses it. "I wrote the release checklist our QA team still uses." Writing the checklist is in the quote; running releases against it with QA is not, and E2 holds that slot |
| R5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The material shows four years as an associate producer and two years on the drop calendar; it does not show whether the live-service work covers more than those two. Expect the interviewer to count. Answer slot: if your main title was live for more of the four years, say for how long and what you produced across them, in your own words; if not, say so plainly and give the two years |
| R6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap in terms. It is a line with nothing inspected behind it, so expect a probe. Lead with the quote's terms: weekly, your main title, the last two years. A past calendar with sensitive detail removed would raise this to high |
| R7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in terms: the quote reaches the requirement. A named, regular presentation beats an adjective. Expect a probe on how the numbers were counted (E1) |
| R8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written document that others use is in the quote; how clear it was, and whether anyone else read your writing, is not. Answer slot: if you wrote anything else others relied on, name it; if the checklist is the main written piece, say so plainly. A2 asks you to write a player-facing line live |
| R9 | Season-pass model and one shared events calendar from February 2027 (not a JD requirement; Project Larkspur search result, page not fetched) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | The JD does not mention purchases; the announcement's season-pass wording is why a probe on it is plausible. A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative the candidate stated, R9 | The plain acknowledgment your sentence gives: "I've never led a team." B2's slot stays on working with the four groups, not on leading them |
| Has worked on a game with in-app purchases | Negative the candidate stated, R9 | "I haven't worked on a game with in-app purchases." No slot; B1 adds a plan, not a past |
| Ran live events, or calendars for two titles | Inflated form of R1 | R1's quote at its own scope. The limit is the pack's observation: the material says a content-drop calendar for one main title |
| Owned the post-event review or defined the KPIs | Inflated form of R3 | R3's quote at its own scope: you presented the monthly retention numbers. E1's slots ask only how they were counted and which part was yours |
| Managed releases with QA, or owned the release process | Inflated form of R4 | R4's quote at its own scope: you wrote the checklist and QA still uses it |
| Held a 3+ year live-service producer role | Inflated form of R5 | R5's two quotes at their own scope; the limit is the pack's observation, not words for you |

## Reading the interviewer

Public professional footprint only, from search-result summaries I did not open in full.

| Signal | Source | Practical implication |
|---|---|---|
| Head of Live Operations at Saltmarsh; previously a QA lead at a console studio | GDC 2026 talk listing (search result) | Expect detail on checklists, sign-off and what a build actually contains; D3 and E2 prepare for it |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Same listing | He listens for words that match reality. Any claim wider than your real scope is the one he will notice, which is why the prohibited list matters here more than usual |
| The same idea as the company value "Ship the Patch Not the Promise" | Values page | The player-facing message in A2 and the plain-acknowledgment habit in B1 both land with him |

Mirror opportunity: his vocabulary is checklists and patch notes; your own words from R4 are "Wrote the release checklist our QA team still uses." Use that sentence as it stands; I am not offering a shared career jump, because your material does not carry one.

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The tabletop on a simulated outage during a live event | Highest, 5 questions: hiring-manager prior plus the loop page documents the tabletop | Clarify, objective, who to pull in, decision, player message, record; think aloud |
| Skeptic (B) | Probes at R9, R5 and R2 | High, 4 questions: hiring-manager prior, and the fit snapshot has real gaps | Rehearse the most predictable objection until it is boring; calibrated candor |
| Values / Behavioral (C) | The documented values conversation, on the three published values | High, 4 questions: the loop page documents it and the values are in hand | A story where your own sentence carries one, a selection scaffold where none does |
| Pressure (D) | Time-boxing inside the tabletop | Mid, 3 questions: inferred from the tabletop format; no source describes his style | Pause, restate, anchor in what you said, hold through two follow-ups |
| Data-Driven Prober (E) | Detail on the retention numbers and the checklist | Low, 2 questions: his public QA background suggests detail, nothing says analytics-first | Know how each figure was counted; say plainly when you do not |
| Conversational (F) | The opener | Low, 2 questions: first minutes of any session | A short arc built only from your own sentences |
| Peer Evaluator | Not included | A hiring-manager session, not a peer one | None needed |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a live event. Players report they can't claim the event reward, and the support queue is filling. What do you do in the first thirty minutes?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Say what you need to know first (what is affected, who knows, what players can see). State the objective in one line. Name who you would pull in from the JD's own list: design, art, engineering, community. Decide whether to pause the event and say what you would tell players, then what you would record for the review. Challenge one premise politely | The loop page documents this format; R2 is the requirement it exercises. CASE because it is a live problem |
| A2 | "The build for Thursday's event slips a day, but the announcement already went out. What are your options, and what do you write to players?" | CASE | [generic] | No claim about your past. Lay out the options (hold the date, ship less, move the date) with the cost of each, choose one, and write the player-facing message aloud in two sentences that say only what is built. Then say what you would put in the post-event review | Tests the published value "we announce what is built, not what is hoped" and R8's written communication, in the form Tobias's talk argues for |
| A3 | "Retention for the last event came in below the one before. How do you diagnose it?" | CASE | [generic] | No claim about your past. Clarify what was compared and over what window, split by whoever is affected, name two candidate causes and what would confirm each, and say what you would report to leadership before you know the answer | The persona stem for the Case persona; exercises R3 and R7 without presupposing a past |
| A4 | "From February, Tidepool Tactics and Lantern Row move to one shared events calendar and the per-title event teams go away. What breaks first in a shared calendar, and what would you check before locking the first season?" | CASE | [grounded] | No claim about your past. The announcement is a public source every prepared candidate can read, so bring it as proof of homework, then add your own reasoning: collisions between the two titles, who owns priority when both want a weekend, how the retired per-title teams hand over. Say what you would ask, not what you know. I read only the announcement's summary, so confirm its details first | Larkspur is the current strategy source (Sources); CASE because it is a live problem on the role's calendar |
| A5 | "What do you know about where our two live titles are heading, and what would you want to learn in your first month?" | CO | [grounded] | No claim about your past. Give the consensus item in one line (the shared calendar and season-pass model from February 2027), then one question of your own that the announcement does not answer. Do not recite further | Differentiate from a public source rather than recite it; CO because it scores homework depth |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Say the limit first, in your words from the quote: "I haven't worked on a game with in-app purchases." Hold it through two follow-ups without softening or adding to it. Then give your ramp as a plan: what you would learn in the first weeks and who you would ask, said in the future tense. Concede plainly what you do not know about how a season pass changes the calendar. If a follow-up asks whether you can run that side, the honest answer is that you have not, and here is how you would start | R9 is the one gap you stated yourself and the announcement raises it, so this objection will arrive in some form; JD because it scores a requirement-shaped gap |
| B2 | "Our events touch design, art, engineering and community. How have you coordinated all four?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the calendar in your quote's terms. Answer slot: the JD's coordination line makes a probe on each team likely. If you worked with any of the four on a drop, say which and what you needed from them, in your own words; if any were not part of your work, or there was no such coordination, say so plainly and return to the calendar | R2 is the requirement and has no quote; the slot's second branch allows that the premise is false |
| B3 | "The posting asks for 3+ years producing live-service games or apps. Walk me through which of your years that covers." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Say both sentences at their own scope. Answer slot: if your main title was live for more of the four years, say for how long and what you produced across them; if not, say so plainly and give the two years. Do not round up | R5 is where a count will happen; JD because it scores a stated requirement |
| B4 | "Why leave puzzle games for live ops on these titles, and why now?" | JD | [generic] | Your reasons are yours; the pack supplies none. Give them in your own words in under a minute, and keep them consistent with what you tell the recruiter | Motivation consistency, asked in the Skeptic register |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Players Before Plans: tell me about a time the calendar and the players disagreed, and the players won." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time you moved, held or changed a drop because of how it would land for players. It needs a named stake, what you decided, and who you told. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you ran the weekly content-drop calendar for your main title for the last two years | Published value 1; the theme comes from the values page text |
| C2 | "Ship the Patch Not the Promise: tell me about a time you had to decide whether to announce something before it was built." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time you held an announcement, or worded one to match what was built. It needs the stake, the decision, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you wrote the release checklist your QA team still uses | Published value 2; the theme comes from the values page text |
| C3 | "Leave the Build Greener: tell me about a time a release process you worked with ended up better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on R4: you wrote the checklist, and your QA team still uses it; those are the beats the quote carries. Answer slot: the value's wording names the checklist, so expect a probe on whether it changed over time. If you revised it after releases, say what and why, in your own words; if it stayed as first written, or revisions were not yours, say so plainly and stay with having written it | Published value 3; R4 is the only row that carries a checklist story |
| C4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: choose a time the news was unwelcome and the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you presented the monthly retention numbers to the studio head | The Values persona's own stem; R3 and R7 are the nearest rows |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Two events both want the same weekend. Sixty seconds: which one gets it?" | CASE | [generic] | No claim about your past. Pause, restate the question, ask for the one fact you most need, decide, state the cost of the decision, and say what you would tell the event that lost. Hold the decision through two follow-ups, concede explicitly what you could not know, and do not fold just to end the pressure | Shared-calendar collisions are what A4 sets up; time-boxed delivery is the Pressure register |
| D2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The hold is only what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if any decision on what went into a drop, or when, was yours, say which and how you decided; if the decisions were someone else's, or there was no such step, say so plainly and describe how you ran the calendar. Hold through two follow-ups by returning to the sentence, never by adding to it | R1 is the likeliest attribution probe; EXP because it tests what was yours |
| D3 | "The sprint ends tomorrow, one bug is still open, and the event ships Friday. Do you sign off the release?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | State the decision rule you would apply, then your decision. Answer slot: the JD's QA line makes a probe on the checklist likely. If the checklist you wrote decided cases like this, say how; if it did not cover this, say so plainly and say how you would decide with QA. Hold through two follow-ups; concede what you would need QA to tell you | R4 is the requirement; his public QA background (Reading the interviewer) makes this one likely; CASE delivery under pressure |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly retention numbers you presented: how was each one counted, and which assumption behind them would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Four slots, each in your own words: how the numbers were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. If you do not know how one was counted, say so plainly; that is an honest branch. Name the weakest assumption before he does | R3 and R7 carry the numbers; the defend-the-number move is the Prober's whole test |
| E2 | "Walk me through the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on R4: you wrote it, and your QA team still uses it. Answer slot: the JD says "manage the release checklist with QA", so expect a probe on how releases ran against it. If you managed releases with it, say how, in your own words; if someone else ran them, or it was used differently, say so plainly and stay with having written it | R4 is your strongest row and a QA-lead interviewer will go deep on it |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences, in that order, in your own words. End with why this role, in your reasons, not mine. No adjectives you cannot back | The opener is scored; R1 to R7 are the rows it previews |
| F2 | "What are you actually playing or following in live ops these days?" | JD | [generic] | Name something you actually follow, a game, an event or a talk. If you follow none, say so and say what you would look at first. Do not invent a favorite | Casual questions on the JD's own domain are scored |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 live-events calendar for two titles | A4, D1, D2, C1 |
| R2 coordinate design, art, engineering, community | A1, B2 |
| R3 post-event review and KPIs | A2, A3, E1 |
| R4 release checklist with QA | C2, C3, D3, E2 |
| R5 3+ years live-service | B3, F1 |
| R6 content calendar | C1, D2, F1 |
| R7 retention metrics | A3, C4, E1 |
| R8 clear written communication | A2, A1 |
| R9 season-pass shift (not in the JD) | B1, A4, A5 |

## Values cheat sheet

Values are the three on Saltmarsh's published page, by name.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold in C1; no quoted sentence carries a disagreement, and the honest branch is saying so |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold in C2; the nearest quote is R4's "Wrote the release checklist our QA team still uses." |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | R4: "Wrote the release checklist our QA team still uses." Beats are the quote's; the rest is C3's slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| V1 | "You've argued that patch notes are a promise. How does the team check, release by release, that the notes matched what shipped?" | Ties to his own public talk and to the company's second value |
| V2 | "You came to live ops after time as a QA lead. What from that background do you most want a new producer to already have?" | Ties to his own path and invites him to teach |
| V3 | "From February, two titles share one events calendar. When both want the same weekend, who decides, and how is the producer's input used?" | Shows you read the strategy and asks about decision rights |
| V4 | "The posting describes a calendar for two titles. Does this role sit in the single live-ops group the announcement describes, and what does it own in the first season?" | Surfaces whether the role changed after the announcement |
| V5 | "Which post-event review in the last year changed how you ran the next event, and what changed?" | Signals you treat the review as the engine of the job |
| V6 | "What would make you say, ninety days in, that this hire was the right call?" | Turns the session into a joint definition of success |

## Sources

Provided: the JD text and the background you wrote in your message.

Searches sent:

1. "Saltmarsh Games values": https://saltmarshgames.com/values
2. "Saltmarsh Games interview process live operations producer": https://saltmarshgames.com/careers/interviewing
3. "Saltmarsh Games mobile studio strategy news": https://saltmarshgames.com/news/project-larkspur (summary only, page not fetched)
4. "Tobias Wrenfield Saltmarsh Games": https://talks.gdconf.example/2026/patch-notes-are-a-promise (summary only, page not fetched)

Fetches sent: the values page and the interviewing page, each read in full.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The values cheat sheet and C1 to C3, by official name |
| 2. Saltmarsh Games interview process, live ops producer | yes | The loop: a single hiring-manager session, tabletop then values conversation; persona weights and A1, A2, C1 to C4 follow it |
| 3. Saltmarsh Games strategy / recent news | yes | A4, A5, R9, B1, V3, V4: the September 2026 shared-calendar announcement |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read, V1, V2, and the weight on D3 and E2 |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV's exact bullets for the calendar, checklist and retention lines → the quotes in R1 to R8 become CV lines, and any figures raise defend-the-number slots
- Your answers to the slots in R1, R2, R3, R5 and R8 → those rows' confidence and gap types upgrade, and B2, B3 and E1 become story-mapped
- The recruiter's note on what the tabletop covers, if they will share it → A1 to A5 tighten to the actual scenario
- Confirmation that Tobias is the hiring manager → persona weights hold; a skip-level changes them
- A past calendar or the checklist itself, with sensitive detail removed → R4 and R6 move from medium to high
- A `tuesday-dossier.md` from an earlier session → verified evidence and a rejected-claims list would replace the locally built prohibited list
