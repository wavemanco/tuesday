# Interview prep pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role as you gave it: "Engineering Manager — Larkfield Systems (industrial IoT, ~600 people)".

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1. Tuesday | Director of Engineering, the hiring manager | 45 min | Your would-be boss |
| 2. Thursday | Two staff engineers and a product manager | 60 min | Panel; staff engineers read as technical peers, the PM as cross-functional (an assumption, see the persona table) |
| 3. Monday | VP Engineering | 30 min | Skip-level; the recruiter's description is "values and leadership philosophy" |

## How to use this pack

Personas are how a question is asked; types are what is being scored. Guidance is scaffolding, not a script: speak it in your own words, and say only what you actually did. Every question has a Provenance cell: a label, plus the sentences of yours the guidance rests on. A row labelled generic makes no claim about you.

Type key:

- VAL: behavioral and values alignment
- EXP: work-experience deep-dive, whether the claim survives scrutiny
- JD: role and requirement driven
- CO: company and strategy knowledge
- CASE: a live problem set in the role

Question IDs read round, persona letter, number (1A1 is round 1, persona A, question 1). The highest-ROI rehearsal in the whole loop is **1A1**. The hardware-roadmap gap is the one you named yourself, it sits on the role's own wording, and your would-be boss will ask it first.

## Prep triage

Two weeks, three rounds. The few things done well, in order:

1. Before Tuesday: 1A1 and 1A2, said aloud until the limit comes out plainly in your own words.
2. Before Tuesday: the reliability-quarter story and the 60% figure (1C1, 1C2). It returns in 2B3, 2C1 and 3C2, so settle how you count it and tell it identically every time.
3. Before Tuesday: your 90-second arc (1D1).
4. Before Thursday: your hiring loop and the "about 40 interviews" figure (2B1, 2B2), then the seam and credit questions (2A1 to 2A3).
5. Before Monday: 3A1 and 3C2 aloud, then the growth question (3A3), which your material does not yet cover.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message. Evidence is your own words, from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — your message, role description | "9 years engineering, 3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | The words stay at their scope: three years as a team lead of six. The pack observes that your material says six and says you have never managed managers, while the role text says two squads and eleven engineers and does not say whether leads sit beneath you. Answer slot: if you have led across more than one team or through other people, say how, in your own words; if not, or it was not yours, say so plainly and stay with the team of six |
| F2 | "own delivery" — your message, role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your sentence carries a reliability quarter pushed through against roadmap pressure, and a drop in on-call burden. It does not say what was delivered to a plan. Answer slot: the JD's delivery line makes a probe on what you delivered likely. If you owned dates or scope for the team's work, say what; if not, or it was not yours, say so plainly and stay with the sentence |
| F3 | "hiring" — your message, role description (own delivery, hiring and growth for 11 engineers) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Lead with it in its own terms: you run the loop, for backend roles. The figure counts interviews, so expect a probe on what exactly was counted |
| F4 | "growth for 11 engineers" — your message, role description | none given | none | [grounded] | discovery | Your material does not show this requirement either way. Answer slot: the JD names growth, so expect a probe on helping engineers develop. If you have helped someone grow, say who and what was yours; if there was no such case, or it was not yours, say so plainly and say how you would start |
| F5 | "partner with hardware and product on roadmap" — your message, role description | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated you have never owned one, and that stays word for word. The pack observes that the quote says owning and the JD says partnering, and your material is silent on partnering. Answer slot: if you have worked beside a hardware or product counterpart on any plan, say what it was and which part was yours; if not, or it was not yours, say so plainly and say how you would begin |
| F6 | "building device-management services" — your message, role description | none given | none | [grounded] | discovery | Your material does not show work in this domain either way. Answer slot: if you have touched devices, fleets or firmware in any way, say what and how far; if you have not, say so plainly and say what you would learn first |

Requirement coverage across the loop:

| Requirement | Question IDs |
|---|---|
| F1 Lead two squads | 1A2, 1A4, 3C1 |
| F2 Own delivery | 1B2, 1C1, 1C2, 2C1, 3C2 |
| F3 Hiring | 2B1, 2B2 |
| F4 Growth for 11 engineers | 3A3, 2D1 |
| F5 Partner with hardware and product on roadmap | 1A1, 1A2, 1B1, 2A1, 2A4, 2C2, 2C3 |
| F6 Building device-management services | 1B3, 1D2, 3B1, 3B2 |
| "industrial IoT, ~600 people" (company context) | 3B3 |

---

## Round 1: Tuesday, Director of Engineering (45 min)

Weights: relationship prior for a hiring manager is Case/Strategist plus Skeptic. I put the Skeptic first because the hardware-roadmap gap you named sits directly on a stated requirement. Loop source: your own words establish this session. Eleven questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the gap and the move from payments to industrial IoT | High. A boss buying capability derisks gaps first, and F5 and F6 are open | Rehearse the single predictable objection until it is boring; hold the stated limit plainly; calibrated candor over bluffing |
| B. Case/Strategist | Live problems from the role's own work | Medium-high. The Director is buying delivery judgment for two squads | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Reads your claims line by line, asks how the numbers were counted | Medium. You have two figures on the table | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| D. Conversational | Open "walk me through" and casual questions | Low-medium. Likely the opener, still scored | A pre-scripted 90-second arc; treat casual questions as scored |

### Persona A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "I don't see hardware work in your background. How would you handle the hardware side of this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this loop. Say your own words first: "I've never owned a hardware-adjacent roadmap." The JD's wording is "partner with hardware and product on roadmap", and you may point to that wording without claiming more. Answer slot: if you have worked beside a hardware or product counterpart on any plan, say what it was and which part was yours; if not, or it was not yours, say so plainly and move to how you would start. Hold through two follow-ups by returning to the same sentence, never adding to it; concede the specific limit, not the whole fit | F5 is the largest open requirement and the one you flagged. It is JD-tagged because it scores a stated responsibility, and a Skeptic delivers it |
| 1A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap" | Pick the limit you can state plainly and give a first-month plan for, then say it in your own words: the quotes are "I've never managed managers" and "never owned a hardware-adjacent roadmap". Say the second as a limit if asked. The plan is forward-looking: say what you would do in the first weeks, in your own words. No quoted sentence supplies a plan | F1 and F5 hold your two stated limits. The question is a standard Skeptic probe, and a rehearsed honest answer beats a defensive one |
| 1A3 | "Why leave a payments company for industrial IoT, and why now?" | JD | [grounded] "currently at a payments company" | Say what pulled you toward device-management work and what is specific to this role: one reason you can say in one breath. The pack supplies no reason; it is yours. If no honest reason comes to mind beyond the next career step, say that plainly | Motivation consistency is what a Skeptic scores. F6 is why the domain move gets asked |
| 1A4 | "Two squads and eleven engineers is a bigger group than six. What changes in how you lead?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" | Say your own words at their scope: three years as a team lead of six. Answer slot: the JD's "11 engineers" makes a probe on what changes likely. If you have led across more than one team or through other people, say how, in your own words; if not, or it was not yours, say so plainly and say what you would set up first, as a plan. Never describe leading eleven as something you have done | F1 is the scope step. EXP because it tests what you actually did at the size you have led |

### Persona B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "Suppose hardware dates on our roadmap keep slipping and product is pushing for features. What do you do in your first 30 days?" | CASE | [generic] | Clarify first: what you need to know, who owns each date, what slipping costs. Then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | F5's requirement set as a live problem. `[generic]`: a pattern for the problem, not a fact about this employer |
| 1B2 | "Product wants a feature this quarter, and the on-call load on the team is climbing. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure it before answering: what you need to know first, the cost of each path, who decides, how you would tell the trade-off to product. If asked whether you have faced it, your own sentence is the story, at its own scope: a reliability quarter pushed through against roadmap pressure. Further beats are an answer slot: who held the pressure and what was traded, in your own words; if there was no such trade, or it was not yours, say so plainly and stay with the sentence | F2 is the nearest evidence for delivery judgment. CASE because it is a live decision, with the reliability story as the optional bridge |
| 1B3 | "What would you want to know about our device-management roadmap before committing to a delivery date?" | CASE | [generic] | Ask clarifying questions in order: what depends on what, which dates are fixed by hardware, how changes are communicated, what has slipped before and why. No claim about your past; no company facts are asserted, since none were researched | F6 and F2 as a clarify-first exercise. The Director scores structure and vocabulary more than the answer |

### Persona C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "Your team's on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four slots, each in your own words. How it was counted. What it is sensitive to. The assumption behind it you would defend least; name it before they do. Which part was yours. If you do not know how it was counted, "I don't know how it was counted" is an honest branch. Do not say the work caused the whole drop unless you can say why | The figure is a headline metric. F2 is the probe target; EXP because it tests attribution |
| 1C2 | "Tell me about the reliability quarter. How did you get it through against roadmap pressure?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The beats your sentence states: a reliability quarter, roadmap pressure, you pushed it through, on-call burden dropped. Tell them in your own words. Answer slot: the JD's delivery and roadmap lines make a probe on who held the pressure and what was traded likely. If you negotiated or traded something, say what; if there was no such step, or it was not yours, say so plainly and stay with "pushed it through" | F2 again, as a story rather than a number. Prepare it once and tell it the same way in every round |

### Persona D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6"; "currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc built from those three sentences only: nine years of engineering, three as a team lead of six, now at a payments company, and the reliability quarter. Add why this role, in your own words; the pack supplies no reason | The opener is scored. F1 and F2 are the load-bearing rows |
| 1D2 | "What are you actually playing with in IoT or device management these days?" | CO | [generic] | Your material does not show work in this area. Answer slot: if you have hands-on time with anything adjacent, say what and how far; if you have none, say so plainly and say what you would start with, as a plan | F6 is open. CO because it checks homework depth; `[generic]` because it makes no claim about you or the company |

### Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does success look like for these two squads at six and twelve months, and who decides?" | Scopes ownership and shows a delivery orientation |
| R1.2 | "How do hardware and software roadmaps get reconciled today, and where does it hurt most?" | Turns your biggest gap into a working conversation with the person who owns the seam |
| R1.3 | "Is this seat new or a backfill, and what should the next manager do differently?" | Shows you are reading the situation you would inherit |
| R1.4 | "How are hiring and growth decisions made for these squads, and what is mine to decide?" | Draws the line on the people responsibilities the role names |
| R1.5 | "How do you like to work with your managers: cadence, written updates, escalation?" | Signals you are already thinking about working for them |

---

## Round 2: Thursday, panel of two staff engineers and a product manager (60 min)

Weights: a panel blends the top two personas of each member's relationship. I read the staff engineers as peers (Peer Evaluator plus Prober) and the PM as cross-functional (Values/Behavioral plus Conversational). If the staff engineers would be your seniors on technical matters, or report to you, the weights shift. Loop source: your own words establish this session. Twelve questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting, "what would you need from me", disagreement and credit probes | High. Two of three panelists are staff engineers, and the PM partners on the roadmap | Reciprocity framing; propose seam principles rather than pretend to know this org's seam |
| B. Data-Driven Prober | Competence probes in collegial packaging, numbers to their assumptions | Medium-high. Staff engineers test whether claims survive technical follow-ups | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| C. Values/Behavioral | Scenario probes, STAR-shaped stories, often from outside the function | Medium. The PM is outside engineering | "We" for context, "I" for contribution; map a story only where your own sentence carries one |
| D. Conversational | Casual questions that are still scored | Low-medium | Pre-scripted short answers; never "I think you've covered everything" in the reverse slot |

### Persona A: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Where does a manager's call end and a staff engineer's call begin, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claim to know this org's seam: who owns the outcome, who owns the technical call, how a disagreement gets named early, and what you would escalate. Offer what you bring to their work, not only what you need. No claim about your past | F5 and F1 in a peer register. `[generic]`: a pattern for the problem |
| 2A2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams; it needs a named other team, what each side contributed, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem for the Peer Evaluator. No quoted sentence of yours carries a cross-team case, so this is a scaffold |
| 2A3 | "What would you need from us in your first 90 days?" | JD | [generic] | Reciprocity first: what you would offer their work, then what you need. Keep the needs to access and context, such as the architecture decisions in flight and the hardware dependencies, and say them as asks, not claims | Reciprocity is what a peer evaluator scores. No claim about your past |
| 2A4 | "Product and hardware both want something this quarter and the squad can only do one. How do you decide?" | CASE | [generic] | Clarify first: what each request is worth and costs, who has the call, what dates are fixed. Then your decision rule and how you would tell the side that loses. No claim about your past | F5 as a live problem the PM cares about. CASE because it asks for a decision under constraint |

### Persona B: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "You said you run the hiring loop for backend roles. Walk me through it." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start with your own words: you run the hiring loop for backend roles. Answer slot: the JD's "hiring" line makes a probe on the loop's stages and how decisions are made likely. If you set the stages or the bar, say how, in your own words; if there was no such step, or it was not yours, say so plainly and describe how the loop actually runs | F3 is your strongest requirement match; probing it is how they test it |
| 2B2 | "About 40 interviews last year. How was that counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Four slots in your own words: what the figure counts (interviews you held, interviews in the loop, candidates), what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never turn interviews into hires | F3's headline figure. The figure counts interviews and can be misread upward |
| 2B3 | "On-call burden: what exactly did you measure, and what was the 60% against?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The same four slots as 1C1, told the same way: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. "I don't know how it was counted" is an honest branch. Consistency with round 1 matters more than polish | F2's number again, from engineers who will test the measurement |

### Persona C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Tell me about a time you pushed back on a roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The beats your sentence states: a reliability quarter, pushed through, roadmap pressure, on-call dropped. Tell them in your own words. Answer slot: who the pressure came from, what you said and how they reacted are not in your sentence. If you can say, do; if there was no such exchange, or it was not yours, say so plainly and stay with the sentence. Pick a story where the hard truth landed only if your material shows it did | F2 is the one story your material carries here. Open prompt, theme from the pushback persona stem |
| 2C2 | "Tell me about a time you worked closely with product to decide what to build." | VAL | [generic] | Selection scaffold: a named decision, what each side wanted, how it was settled, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F5's product half; no quoted sentence carries it |
| 2C3 | "Tell me about a time a dependency slipped and you had to re-plan with the team." | VAL | [generic] | Selection scaffold: a named dependency, who owned it, what you changed and what you told the team. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F5 and F2: hardware dates are the dependency the role is built around |

### Persona D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "How would you describe your management style in two sentences?" | VAL | [generic] | Pick two behaviors you can attach to an example in your own words, then say them as behaviors, not labels. The pack supplies no style for you. If you cannot yet name two, say what you aim for and that you are still building the evidence | F4 and F1: casual style questions are where a thin answer shows |
| 2D2 | "What would you want to know about the team before you took this on?" | JD | [generic] | Two or three real questions about the squads (size, seniority mix, current on-call load); asking them signals you read the role. No claim about your past | A casual question that doubles as the reverse-question warm-up |

### Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Where has the working relationship between engineering management and the staff engineers worked best here, and where has it been bumpy?" | Shows you want the seam principles from the people who live it |
| R2.2 | Reciprocity: "What could a new manager do in their first month that would genuinely help your work?" | Peer evaluators weight reciprocity heavily |
| R2.3 | "How does the roadmap get set between product, hardware and the squads, and where do you wish engineering showed up differently?" | Aimed at the PM; turns the F5 gap into a working conversation |
| R2.4 | "How do the squads weigh on-call and reliability work next to feature commitments?" | A real interest in the trade-off, and it invites their view without staking a claim |
| R2.5 | "How do staff engineers take part in hiring for these squads, if at all?" | Connects to the hiring responsibility without presuming how it works |

---

## Round 3: Monday, VP Engineering (30 min, "values and leadership philosophy")

Weights: skip-level prior is Case/Strategist plus Pressure. The recruiter's own words establish that this round assesses values and leadership, so Values/Behavioral goes to the top. Nine questions. No company values were researched, so there is no values cheat sheet; the VAL questions below are themed on the recruiter's description and the role description.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values/Behavioral | Leadership-philosophy and behavioral probes | High. The recruiter described the round this way | Stories only where your own sentence carries one; "we" for context, "I" for contribution |
| B. Case/Strategist | Altitude and strategy questions | Medium. Skip-level prior, and a VP will test how you think above the squads | Clarify, structure, think aloud; challenge one premise |
| C. Pressure | Time-boxed, devil's advocate, "how much of that was you" | Low-medium. Skip-level prior; thirty minutes make short, firm answers likely | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |

### Persona A: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "What is your leadership philosophy? How would your engineers describe how you lead?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | State one belief as a behavior, then offer one of your own sentences as what you did, without saying what it proves. Let the VP draw the inference. How your engineers would describe you is yours to say; the pack supplies nothing | The recruiter's description makes this the likeliest opener. F2 and F3 are the only sentences that can carry it |
| 3A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Persona stem. Your sentence carries a reliability quarter pushed through against roadmap pressure. Answer slot: whether the pressure came from leadership is not in your sentence. If it did, say who and what you said; if it did not, or you were not the one who said it, say so plainly and choose another instance or stay with the sentence | F2 is the only candidate story; the slot keeps it from being stretched |
| 3A3 | "Tell me about an engineer you helped grow." | VAL | [generic] | Selection scaffold: a named person, what they needed, what you did, and what changed for them. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F4 has no evidence in your material. The role names growth for eleven engineers |
| 3A4 | "Tell me about a time you got something wrong as a leader." | VAL | [generic] | Selection scaffold: a real mistake, what it cost, what you did next, and what you changed. If no such time comes to mind, say so plainly. Pick one with a hard truth that landed only if your material shows it did | Leadership-philosophy rounds probe self-awareness. No quoted sentence carries it |

### Persona B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3B1 | "Where should a device-management engineering org invest its next two quarters: reliability, new device types or customer features?" | CASE | [generic] | Clarify first: what the business needs, what is failing, what customers feel. Then segmentation, a decision rule, metrics and risks. Challenge one premise respectfully. No claim about your past | F6 and F2 at VP altitude. No strategy research ran, so this stays a method |
| 3B2 | "What makes industrial IoT hard to build software for?" | CO | [generic] | Give your own view as a view, not a fact about this company. Your material does not show domain work; say what you would want to learn instead of asserting. Add company facts only after you have read the company's own material | F6. CO because it checks homework at the company's altitude; `[generic]` because no research ran |
| 3B3 | "Why Larkfield, rather than the many other places you could go?" | CO | [grounded] "currently at a payments company" | Name what is specific to this role (two squads, device-management services, a company of about 600 people, as the role description gives it) and what is specific to your reasons. The reasons are yours; the pack supplies none | Closes the motivation thread for the VP. The company facts are limited to your own role description |

### Persona C: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Sixty seconds: why you over a manager who has already led two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6"; "I've never managed managers" | Hold with what you stated, at its scope: three years as a team lead of six. Describe what you did and let the VP draw the inference. Concede the specific limit in your own words: "I've never managed managers." Do not fold on the rest to restore harmony | F1 is the scope step. Hold-then-concede: two follow-ups held, then one named concession |
| 3C2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Persona stem. Hold your sentence: you pushed a reliability quarter through against roadmap pressure. Answer slot: what others on the team did, and how the figure divides between you and them, is not in your sentence. Say what was yours and what was theirs, in your own words; if you cannot say how it divides, say so plainly and stay with the sentence | F2's attribution under pressure. The drop is stated after your push, not caused by it, and the answer keeps that gap honest |

### Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What leadership behavior do you most want more of in your engineering managers?" | Matches the round's stated theme and signals you are asking for the bar |
| R3.2 | "Where is the industrial IoT business under the most pressure over the next year, and how does engineering feel it?" | Shows altitude; asks the VP to supply the facts you have not researched |
| R3.3 | "How do you want managers to handle disagreement with your own direction?" | Tests the leadership philosophy from the other side |
| R3.4 | "What does growth for a manager look like here, and what do you invest in?" | Speaks to the growth theme and to your own next step |
| R3.5 | "How are engineering managers evaluated here: what is in the review?" | Makes the bar concrete before you accept it |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or led through other leads | Negative the candidate stated | Your own words: "I've never managed managers." No slot |
| Owned or led a hardware-adjacent roadmap | Negative the candidate stated | Your own words: "never owned a hardware-adjacent roadmap". Any partnering is an answer slot inside that scope (1A1) |
| Led two squads or eleven engineers | Inflated form of F1 | "9 years engineering, 3 as a team lead of 6" at its own scope. The limit is the pack's observation: the material says six, not eleven |
| Owned the delivery of a plan, or caused the whole on-call drop | Inflated form of F2 | F2's sentence at its own scope. 3C2's slot asks only what was yours and what was others |
| Made about 40 hires | Inflated form of F3 | F3's sentence at its own scope: the figure counts interviews. 2B2's slot asks what was counted |

## Sources

Provided documents: your message (the role description, the three rounds and your background). Nothing else was read.

Searches, all refused (the host declined permission to search):

- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems strategy industrial IoT news": refused

No pages fetched. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have moved the values cheat sheet and the VAL questions by value name; both are absent |
| 2. Larkfield Systems interview process | unavailable | Would have checked the loop; your own words already establish all three sessions, so persona weights follow them |
| 3. Larkfield Systems strategy / recent news | unavailable | Would have grounded the CO and CASE questions; they are generic |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative role JD | skipped | The role description you pasted supplies the requirements the snapshot uses |

## Upgrade menu

- Permission to run web search, or the company's values page and any interview-loop notes pasted → the values cheat sheet, CO and CASE questions grounded in the company's own strategy, and a check of the loop
- The full posting text → mid-list requirements get rows and JD questions, and the F rows move from a one-line description to the posting's own wording
- The interviewers' names → a reading of each interviewer, persona weights from their public footprint, and a reverse question tied to their own paths
- The recruiter's prep email on the panel and the VP round → focus areas and any announced deliverable
- Your answers to the answer slots in F1, F2, F4, F5 and F6 → those rows' bridge language upgrades from slot to words you can say
- The on-call report or paging dashboard behind the 60% → F2 can move from medium toward high
- The interview schedule or scorecards behind the "about 40 interviews" → F3 can move from medium toward high
- A `tuesday-dossier.md` → verified evidence, the objection worth the deepest rehearsal, and absolute prohibited claims carried in
