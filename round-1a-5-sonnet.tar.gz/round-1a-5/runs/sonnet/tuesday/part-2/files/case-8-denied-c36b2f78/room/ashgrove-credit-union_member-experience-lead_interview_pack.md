# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Mode: loop, three rounds on 4 December 2026, built on 25 November 2026.

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | Recruiter (name not given) | 30 minutes | Screen |
| 2 | Head of Member Services, your future manager (name not given) | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers (not yet assigned) | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four published values |

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on.

| Type | What it tests |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your experience claims survive follow-up questions |
| JD | The listed duties and requirements, including the gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem, scored on structure and reasoning |

Guidance is scaffolding, not a script. Every line of proposed wording in this pack is pending your approval, and you should say only what you actually did. An "Answer slot" is an instruction for the interview, not a question for you now. It has two honest branches, and you take whichever one is true.

## Prep triage

Nine days from today (25 November) to 4 December. All three rounds fall on one day, so your answers have to agree with each other.

1. Rehearse the contact-centre objection out loud until it is boring: R1-B2, then R2-B1. This is the highest-ROI prep in the pack, because it will arrive in some form in all three rounds.
2. Run the shape of the case at least twice, on R3-D1 and R3-D2. Ask the recruiter what format and materials the 20-minute case uses (see the upgrade menu).
3. Choose your own answers to the logistics slots once (R1-A3 to R1-A6) and keep them identical across rounds. This is ten minutes of work.
4. Pick a real story for each of the four values from your own history (R2-C1 to R2-C3, R3-C1 to R3-C4). Where none comes to mind, use the honest branch in the guidance.
5. Prepare the plan for presenting to senior leaders: R2-B3 and R3-B1.

Everything else is insurance.

## Fit snapshot (shared across rounds)

Proposed wording below is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages around the log likely. If any stage before or after the log was yours to run, say which and how, in your own words; if there was no such stage, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The sentence says a monthly complaints spreadsheet, not what it counted, and the bridge is not stretched. Answer slot: the JD names volumes and resolution times, so expect a probe on what your sheet counted. If it counted either, say how each was counted, in your own words; if it counted something else, or neither, say so plainly, and say what it did count |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | A formal log touches the requirement without showing it was regulated, so the words stay at "formal". Answer slot: if the log fell under rules set outside the branch, say which and what part was yours; if you do not know, or applying them was not yours, say so plainly and stay with the log you handled |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor. A named role beats an adjective. Nothing inspected sits behind it, so expect a probe on what those years held |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Adjacent work: you trained tellers, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD asks about coaching supervisors. If you have coached or advised a supervisor on an escalation, say how, in your own words; if you have not, say so plainly and say how you would coach |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not Excel, and the words stay at spreadsheet. Answer slot: the JD says Excel, so expect a probe on the tool. If it was Excel, say what you built in it, in your own words; if it was another tool, say so plainly and say how you would carry the skill across |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: the JD names digital teams and self-service journeys, so expect a probe. If you have worked with a digital or product team on anything members use without staff, say what and your part, in your own words; if you have not, say so plainly, and say what you would want to learn from them first |

No row is a hard gate: none of the JD's requirements is a licence, credential, schedule, location or pay term. The length-of-experience line (F5) is graded like any other requirement.

## Grounding brief

Source: the four points you gave from the July 2026 strategy brief, plus the JD. The brief itself was not read in full.

| Item | What it says | Provenance |
|---|---|---|
| Size and ownership | Member-owned, about 900 staff (the JD's own line) | [grounded] |
| Digital shift | 40% of member service to digital channels by 2028 | [grounded] |
| Branch network | Eight branches consolidated into five hubs over 2027 | [grounded] |
| New product | Small-business lending product launches in Q1 2027 | [grounded] |
| Competition | Main competitive pressure is app-only banks | [grounded] |
| Implication to test: digital | Complaints will increasingly arrive through channels with no staff member present; derived from the 40% line | [inferred] |
| Implication to test: hubs | Members of a closing branch need an obvious place to complain during the move; derived from the eight-to-five line and the value "Neighbours, Not Numbers" | [inferred] |

## Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly questions on your story, pay, notice, location and reason for leaving | High. The recruiter-screen prior is Conversational plus a light Skeptic, and nothing in your inputs moves it | Treat casual questions as scored; use a short biography arc and your own answers to the logistics slots |
| Skeptic | Quick knockout checks on the 4+ years, regulated complaints and the contact centre | Low. The same prior, and the recruiter checks gaps briefly rather than probing them | Say limits plainly and early; do not stretch adjacent work |

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So — walk me through your journey and what brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | A 90-second arc using only the beats your sentences state: six years in retail banking, the last three as a branch supervisor, and the branch's formal complaints log you handled. Tell them in your own words and stop there. Answer slot: what draws you to this role is yours alone. Say in your own words why Ashgrove and why this role; if nothing specific does, say so plainly and say what you are looking for | A biography opener is scored on economy; F5 and F1 supply the beats, and EXP because it tests what you actually did |
| R1-A2 | "What do you know about Ashgrove, and what appealed to you?" | CO | [grounded] | Use only what you have read: a member-owned credit union with about 900 staff (the JD's line), and one of the four strategy points you were sent. Pick one and say in your own words what it means for a member who complains; do not recite all four. Answer slot: what appealed to you is yours. If one of the four values spoke to you more than the others, say which and why, plainly | The strategy brief and values are the two things any prepared candidate can name, so one chosen point scores better than a list; CO because it tests homework at the company's altitude |
| R1-A3 | "What salary are you looking for?" | JD | [generic] | A logistics slot, and the only safe answer is your own. Give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Recruiter screens almost always cover pay; JD because it scores the job's terms |
| R1-A4 | "What is your notice period?" | JD | [generic] | A logistics slot. Give your actual notice period, in your own words | The same logistics set; JD because it scores the job's terms |
| R1-A5 | "Where are you based, and what travel or site pattern works for you?" | JD | [generic] | A logistics slot. Give where you are based and the travel or site pattern you can really work, in your own words. The role covers branches and the contact centre, so the answer should hold for both | The JD spans several sites; JD because it scores the job's terms |
| R1-A6 | "Why are you looking to move?" | EXP | [generic] | A logistics slot. Give your own reason in your own words, and keep it the same in rounds 2 and 3. Answer slot: if you do not have a settled reason, say so plainly rather than inventing one | Motivation consistency across a same-day loop is what the recruiter notes; EXP because it tests the story's consistency |
| R1-B1 | "Take me through how your background lines up with the 4+ years and the regulated complaints." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Two beats, each in the quote's own terms: six years in retail banking, the last three as a branch supervisor; and the branch's formal complaints log you handled. Answer slot: the JD says regulated, and your sentence says formal. If the log fell under rules set outside the branch, say which and what part was yours; if you do not know, or applying them was not yours, say so plainly and stay with the log | F5 and F4 are the two checks a recruiter can screen on; JD because it scores listed requirements |
| R1-B2 | "The role covers the contact centre as well as the branches. You haven't worked in one, so how do you see that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Say it plainly and early: "I've never worked in a contact centre." Then stay with what your sentence carries, "I handled the branch's formal complaints log", and give a plan, not a past: what you would want to understand first about how complaints reach and leave the centre, in your own words. Do not guess how a contact centre works | F2 is the largest gap, and this is its first hearing; JD because it scores a stated requirement |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-V1 | "What does the process look like after today, who decides, and when will I hear?" | It shows you are planning the day, and it gets the timeline without pushing for an answer |
| R1-V2 | "Is there anything I should bring or prepare for the 20-minute case in the panel round?" | The case is the least predictable part of the loop, and the recruiter is the one person who may know its format |
| R1-V3 | "What is the salary band for the role?" | It gives you a range before you name a figure, which supports your answer to R1-A3 |
| R1-V4 | "Is the role based at one site, or across the branches and the contact centre?" | It answers the location question from their side and shows you take the cross-site scope seriously |
| R1-V5 | "What are the Head of Member Services and the panel each looking for most?" | A recruiter can often say what a round is weighing, which lets you tune your emphasis for the day |

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the contact-centre and senior-presenting gaps, and of why this role | High (4 questions). The hiring-manager prior is Case plus Skeptic, and the gaps in F2 and F8 sit exactly where a manager derisks | Rehearse the single most predictable objection until it is boring; hold, then concede only what is true |
| Values / Behavioral | "Tell me about a time" prompts mapped to the four published values | Mid (3 questions). The recruiter said the round is mostly behavioural, which moves Values up from the prior | Choose stories where the hard truth landed; use "we" for context and "I" for what you did |
| Data-Driven Prober | Line-by-line questions on the monthly spreadsheet | Low (2 questions). The JD names Excel reporting and monthly volumes and resolution times | Say what your sheet counted and what you do not know about how it was counted |
| Case / Strategist | A live problem on the strategy brief's own lines | Low (2 questions). The prior is Case, but a mostly behavioural round gives it less room | Clarify, then structure, then answer; challenge one premise politely |

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "This role owns complaints across the branches and the contact centre, and you haven't worked in a contact centre. Where does that leave you on day one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Name the limit before it is pressed: "I've never worked in a contact centre." Then your adjacent ground at its own scope: "I handled the branch's formal complaints log." Then a ramp plan in the future tense, in your own words: what you would learn first, and who you would ask. Hold through two follow-ups, and concede only that branch and contact-centre complaints may differ and that you would find out how; do not claim a similarity you cannot show. Answer slot: if any complaint in your log reached the branch through the contact centre, say how you saw it and what part was yours; if none did, or you never saw one, say so plainly and stay with the log | F2 and F1 together are the objection that will arrive in some form in all three rounds, so it gets the deepest chain; JD because it scores the headline requirement |
| R2-B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose the weaker of the two limits you have already stated, and say it plainly: "I've never worked in a contact centre" or "I've never presented to anyone above regional level". Then give one concrete step for closing it. Do not offer a manufactured weakness | F2 and F8 are the two stated limits; this is a standard Skeptic stem, and JD because it scores the listed requirements |
| R2-B3 | "The role asks for confidence presenting to senior leaders. How would you get ready for that?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Start with the plain limit: "I've never presented to anyone above regional level." Then a preparation plan in the future tense and your own words: the questions you would expect, how little you would put on the first page, and who you would rehearse with. Answer slot: if you presented from the monthly spreadsheet you built, say to whom and how; if you only sent it, or someone else presented it, say so plainly and stay with the sheet you built | F8 is capability, so the plan carries the answer; JD because it scores a stated requirement |
| R2-B4 | "Why this role, and why Ashgrove?" | EXP | [generic] | Give the same reason, in the same words, as your answer to R1-A1 and R1-A6. Answer slot: if your reason has shifted since the recruiter call, say so plainly and say which version is true; do not give two answers in one day | A manager compares notes with the recruiter; EXP because it tests the story's consistency |
| R2-C1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, because none of your sentences carries this story. Pick a time a decision was yours, the member's side and the branch's side pointed different ways, and you can name what you chose and what it cost. "I" for what you decided and "we" for the context. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would decide | Members First is the first published value; VAL because it scores behaviour against it |
| R2-C2 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F6: the escalation script and the new tellers you trained on it are the beats the sentence states, told in your own words. Answer slot: the value says that if a member needs it explained twice, the explanation was written wrong, so expect a probe on whether the script or your teaching changed. If you changed either after a member needed it explained twice, say what changed and what part was yours; if nothing changed, or it was not yours, say so plainly and stay with the training you gave | Plain Words is the second published value, and F6 is the nearest sentence to it; VAL because it scores behaviour against the value |
| R2-C3 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Pick a case where you found the problem, not only received it, and carried it to a close you can describe. Name the stake, what you did yourself, who else was needed, and how it ended. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would keep hold of one | Own the Fix and the JD's end-to-end line (F1) point at the same behaviour; VAL because it scores behaviour against the value |
| R2-F1 | "Tell me about the monthly complaints spreadsheet you built. What did it report?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built it, it is monthly, and your regional manager uses it, which are the beats the sentence states. Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted either, say how each was counted and the assumption in that counting you would defend least; if it counted something else, or neither, say so plainly and say what it did count | F3 and F7 are the evidence for the reporting requirements; EXP because it tests what you built. The weakest-assumption move is a slot because no figure was given |
| R2-F2 | "How would you set up monthly reporting that covers the branches and the contact centre together?" | JD | [grounded] | Think aloud and make no claim about your past. Ask what counts as a complaint in each place and whether the two records define it the same way. Say who owns each number. Name the two measures the JD itself names, volumes and resolution times, and what you would check before trusting a combined figure | F3 and F7 as requirements, and the cross-site scope of F2; JD because it scores listed duties |
| R2-D1 | "Eight branches become five hubs over 2027. What happens to complaints handling that year?" | CASE | [inferred] derived from the brief's eight-to-five hub line | Structure aloud. Clarify first: which branches, in which months, and where escalations land during the move. Objective: no complaint falls between two sites. Segment by who the member is and where they used to go. Name your measures, volumes and resolution times, and the risks: members of a closing branch, and handover gaps. Challenge one premise politely, such as whether volume is expected to rise during the move. Use their words: "Neighbours, Not Numbers" | A live problem on a published strategy line; CASE because it scores structure, with CO as the secondary tag |
| R2-D2 | "Digital wants 40 percent of member service on digital channels by 2028. How would you work with them on which complaint journeys go self-service?" | CASE | [inferred] derived from the brief's 40 percent line and the JD's digital-teams line | Clarify what self-service means here: reporting, tracking or resolving. Segment complaints by complexity and by how vulnerable the member is, and say which should never be self-service and why. Use their words: if a member needs it explained twice, the journey is wrong. Say what you would ask the digital team for and what you would offer from the complaints side, in your own words. Answer slot: if you have worked with a digital or product team on anything members use without staff, say what and your part; if not, say so plainly and say what you would learn first | F9 is a discovery gap, so the answer is a structure plus an honest slot; CASE because it is a live problem |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-V1 | "What would you want complaints reporting to show by the end of my first three months?" | It tells you what you will be scored on and shows you think in outcomes |
| R2-V2 | "Where does the complaints process break down today between the branches and the contact centre?" | It shows you are already looking for the seam and want to own the fix |
| R2-V3 | "As eight branches become five hubs, who will handle escalations, and where will the branch supervisors sit?" | It ties to the strategy and shows you have read it |
| R2-V4 | "Which digital self-service journeys are being built first, and how will they connect to complaints?" | It matches the JD's digital-teams line and invites a concrete answer |
| R2-V5 | "What do you see as the biggest gap in my background for this role, and how would you want me to close it?" | It turns the objection into a conversation you have prepared for, and you hear their view first |

## Round 3: panel of two branch managers (60 minutes, includes a 20-minute case, values-scored)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Open prompts scored against the four values | High (4 questions). The recruiter said the panel scores against the four values, so this round is a documented values round | Map a real story to each value, or use the honest branch; "we" for context and "I" for what you did |
| Case / Strategist | The 20-minute complaint-escalation case and a strategy question | Mid (3 questions). The recruiter announced the case | Clarify, objective, segmentation, approach, measures, risks; think aloud; challenge one premise |
| Peer Evaluator | Seam questions: where the role stops and the branches start | Mid (3 questions). The role coaches branch supervisors, and the panel are branch managers, so the seam matters to them (derived from the JD's coaching line and the panel's stated role, not from any named interviewer) | Offer seam principles, not a map you cannot know; say what you bring as well as what you need |
| Skeptic | Collegial versions of the contact-centre and senior-presenting objections | Low (2 questions). Panel members sometimes return the earlier objections in friendlier packaging | The same plain limits as round 2, and no new claims |

Proposed wording below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "When did you put a member's interest ahead of an internal target or process?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Pick a time a process or target pointed one way and the member's interest pointed another, and you chose. Name the stake, what you did, and what it cost. "I" for the choice and "we" for the context. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would choose | Members First, Always; a standard values-round stem. VAL because it scores behaviour against the value |
| R3-C2 | "Here is a complaint outcome that went against a member. Explain it to them the way you would on the phone." | VAL | [grounded] | A live explanation, so no claim about your past. Say the outcome first in one sentence, the reason in two, and what the member can do next in one. Use no jargon, and swap any word that would need a definition. Then stop, and ask the member what would be most useful to hear again | Plain Words is scored in the way you speak, not only in a story; VAL because it is scored against the value, with CASE delivery |
| R3-C3 | "Tell us about a time the numbers said one thing and the town in front of you said another." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold, because none of your sentences carries this story. Pick a time a figure or target and what you could see in your own branch pointed apart. Name the stake, what you did, and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "the last 3 as a branch supervisor", or how you would weigh the two | Neighbours, Not Numbers; the panel are branch managers, so a branch-level story is natural. VAL because it scores behaviour against the value |
| R3-C4 | "Tell us about a time you found a problem outside your own area and what you did next." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Name the problem, whose it was, what you did to keep hold of it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would keep hold of it. Keep the facts the same as your R2-C3 story if you use the same one | Own the Fix; VAL because it scores behaviour against the value |
| R3-D1 | "A member has complained three times about the same fee error, and it has now reached you as an escalation. Walk us through it." | CASE | [generic] | An illustrative case; the real one will differ, so practise the shape. Clarify first: what the member was told each time, what the record shows, what they want, and whether anything is time-limited. Objective: stop the error, put it right with the member, and find out why it came back. Say you keep hold of it until solved and that the member will be told who has it. The member should hear the answer once. Then root cause, one error or a pattern, and the measures you would watch: volumes and resolution times. Challenge one premise politely: is it one error or three | The recruiter announced a 20-minute case on a complaint escalation; CASE because it scores structure. [generic] because the real scenario is unknown |
| R3-D2 | "The supervisor says they followed the script. What do you say to them?" | CASE | [grounded] "trained new tellers on our escalation script"; "6 years in retail banking, the last 3 as a branch supervisor" | A coaching move, not a verdict. Ask what they saw and decided at each step, check the script against the case together, and agree the one thing to change. You can speak from the branch side at the scope of your sentences: the last three years as a branch supervisor, and training new tellers on the escalation script. Answer slot: if you have coached or advised a supervisor on an escalation, say how, in your own words; if you have not, say so plainly and say how you would start | A likely follow-up in the case, given the JD's coaching line (F6); CASE because it is a live coaching problem |
| R3-D3 | "Branches are consolidating into hubs while 40 percent of service moves to digital. How do you protect Neighbours, Not Numbers?" | CO | [inferred] derived from the brief's hub and digital lines and the value's own text | Name the tension out loud and do not pretend it away. Offer two or three ways complaints can keep a local face as options, not as claims about Ashgrove's plans: a named person who keeps hold of each complaint, outcomes explained in plain words, and complaint patterns reported by town. Say what you would measure, and what you would want to learn from branch managers first | The panel are branch managers; CO and VAL meet in this question, and the brief's hub line is the live one |
| R3-E1 | "Where does your job stop and ours start when a complaint escalates, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you cannot know: the member never has to repeat themselves, the person who found it keeps hold of it, and a disagreement goes to the case record first. Say what you bring to their supervisors as well as what you need. Disagreement story scaffold: pick a time you disagreed with an equal and the working relationship survived; if no such time comes to mind, say so plainly and say how you would disagree | A Peer Evaluator seam question from the JD's coaching line (F6) |
| R3-E2 | "How do you handle credit when a fix spans a branch and the contact centre?" | EXP | [generic] | Scaffold: pick a time work spanned teams, and say what you did and what was theirs. "We" for the context and "I" for your part. If no such time comes to mind, say so plainly, then say how you would handle it: name the others' contributions first | A standard Peer Evaluator stem; EXP because it tests attribution honesty |
| R3-E3 | "What would you need from us in your first month?" | JD | [generic] | Name two or three specific things you can ask for now: time with supervisors in their own branches, the most recent escalations, and an introduction to the contact-centre lead. Frame each as what you need and what you will give back. No claim about your past is needed | Reciprocity; the panel are the people your coaching will touch, and JD because it scores the coaching duty |
| R3-B1 | "How would you pitch complaints findings to the Head of Member Services and above?" | JD | [grounded] "I've never presented to anyone above regional level" | If asked about experience, give the plain limit: "I've never presented to anyone above regional level." Then structure: lead with the answer, one page, the two measures the JD names, the one decision you need, and what you do not yet know | F8 again, from the panel's side; JD because it scores a stated requirement |
| R3-B2 | "What do you think the contact centre does differently with a complaint than a branch?" | JD | [grounded] "Never worked in a contact centre" | You have said you have not worked in one: "I've never worked in a contact centre." So do not guess. Say what you would ask a branch manager and a contact-centre colleague, and what you would look at in both records. Then turn it to them: ask what they see from the branch side | F2 once more in collegial packaging; JD because it scores the cross-site scope |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-V1 | "How do escalations from your branch reach the complaints team today, and what would you want to change?" | It asks for their view of the seam you will work in |
| R3-V2 | "What could a new person in this role do in the first month that would genuinely help your branch?" | A reciprocity question for people who will work beside you |
| R3-V3 | "How do you expect the move to hubs to change what members bring to the counter?" | It ties to the strategy and to "Neighbours, Not Numbers" |
| R3-V4 | "Which of the four values is tested hardest in your branch?" | It shows you took the values seriously and invites a real example |
| R3-V5 | "How do your supervisors currently learn the escalation process?" | It matches the JD's coaching line and reveals what the role will inherit |

### Values cheat sheet (Round 3)

A values-style round is detected: the recruiter said the panel scores against the four values. The values are as you copied them from ashgrovecu.org/about/values on 25 November 2026.

| Value (official name) | Working meaning (paraphrased) | Mapped story or selection scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, because no sentence of yours carries a decision story. Nearest at its own scope, from F1: "I handled the branch's formal complaints log". Honest branch: if no time comes to mind, say so plainly and say how you would decide. See R2-C1 and R3-C1 |
| Plain Words | If a member needs it explained twice, the writing or explanation was wrong | F6: "trained new tellers on our escalation script". Beats: the script and the tellers you trained. Anything beyond that is an answer slot, in R2-C2. See also R3-C2 |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold. Nearest, from F6: "6 years in retail banking, the last 3 as a branch supervisor". Honest branch: if no time comes to mind, say so plainly and say how you would weigh the two. See R3-C3 and R3-D3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold. Nearest, from F1: "I handled the branch's formal complaints log". Honest branch: if no such case comes to mind, say so plainly and say how you would keep hold of one. See R2-C3 and R3-C4 |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| F1: own the member complaints process end to end | R1-B1, R2-B1, R2-C3, R3-D1 |
| F2: across branches and the contact centre | R1-B2, R2-B1, R2-B2, R3-B2 |
| F3: report monthly on complaint volumes and resolution times | R2-F1, R2-F2 |
| F4: experience handling regulated complaints | R1-B1 |
| F5: 4+ years in financial-services customer operations | R1-B1 |
| F6: coach branch supervisors on escalations | R3-D2, R3-E1 |
| F7: comfortable with Excel reporting | R2-F1, R2-F2 |
| F8: confident presenting to senior leaders | R2-B3, R3-B1 |
| F9: work with digital teams on self-service journeys | R2-D2 |
| Strategy (CO and CASE) | R1-A2, R2-D1, R2-D2, R3-D3 |
| Values | Members First, Always: R2-C1, R3-C1. Plain Words: R2-C2, R3-C2. Neighbours, Not Numbers: R3-C3, R3-D3. Own the Fix: R2-C3, R3-C4 |

## Prohibited claims

Built from the fit snapshot before the question banks were written. Nothing in this pack coaches these, and no slot, hold or bridge asserts or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns or owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation, not words for you: the material says the branch's log, not the process end to end. The slot in R2-B1 stays inside the log |
| Has worked in a contact centre or on contact-centre complaints | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." Plans only; no past |
| Has presented to senior leaders or executives | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." Plans only; no past |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says a monthly spreadsheet, not what it counted. R2-F1's slot asks only what it counted |
| Coached or managed branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "trained new tellers on our escalation script". The slot in R3-D2 stays inside what you did |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: the material says formal, not regulated |
| Built the report in Excel | Inflated form of F7 | F7's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". The limit is the pack's observation: the material says spreadsheet, not Excel |

## Sources

Provided documents: the JD; the four values copied from ashgrovecu.org/about/values on 25 November 2026; the recruiter's email on the three rounds; your summary of four points from the 2026 strategy brief Ashgrove published in July 2026 (the brief itself was not read in full); your background as you described it in your message. No dossier was present, and no interviewer information beyond roles exists, so there is no interviewer read and no delivery-coaching section. No deliverable was pre-declared, so there is no deliverable build section.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | skipped | Could not have moved the values cheat sheet or any VAL question: you pasted the values page text, copied this morning |
| 2. `{company} interview process {role family}` | skipped | Could not have moved the persona weights or the rounds: the recruiter's email gives three sessions, who runs each, and their lengths, and names the panel as the values round |
| 3. `{company} strategy` / recent news | skipped | Could not have moved the CO bank: the July 2026 brief, under six months old, supplies the strategy points you gave |
| 4. `{interviewer name} {company}` | n/a | No name was given for any interviewer, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, if you have one: the fit snapshot rests on your message alone, so rows F1 to F8 may move from discovery or transferability to presentation or none, and some low bands may rise.
- Your answers to the slots (what the monthly spreadsheet counted, whether the formal log fell under rules set outside the branch, whether you coached any supervisor, and whether you worked with any digital team): rows F1, F3, F4, F6, F7 and F9 would become grounded, and the matching slots in R2-F1, R1-B1, R3-D2 and R2-D2 would turn into story maps.
- The full July 2026 strategy brief text: the CO and CASE rows R2-D1, R2-D2 and R3-D3 currently rest on four points, and would gain specifics and be relabelled grounded where the brief supports them.
- The interviewers' names once assigned: this would add an interviewer read, adjust persona weights per round, and allow a reverse question tied to their own paths.
- The format of the 20-minute case, from the recruiter, usually one email: R3-D1 and R3-D2 are a generic escalation case today, and a real format would replace them.
- A tuesday-dossier.md from an earlier fit check, if you ever run one: it would add evidence-derived objections and an absolute prohibited-claims list in place of the locally built one. Nothing here depends on it.
