# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer names and the round's makeup: not given. Built as session mode with blended persona weights, because the schedule of sessions is unknown.

## How to use this pack

- Personas describe how a question is asked. Types describe what is scored.
- Types: VAL (behavioral / values alignment), EXP (work-experience deep-dive), JD (role / posting-driven), CO (company and strategy knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Every answer should be in your own words and about what you actually did.
- Nothing in this pack is grounded in your CV, a posting, or research on Stripe, because none was available. Every row is labeled generic. Where a question needs a story, the guidance tells you how to pick one from your own history, and each of those ends with an honest branch for when no story fits.
- The highest-ROI rehearsal is B1. It is inferred from the shape of the role and your note, not from your background, so it will sharpen once you share a CV.

## Fit snapshot (worksheet)

No CV, posting or background was provided, so this is the worksheet variant. Requirements are role-family patterns written as plain prose, not quotes from a Stripe posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or changes across several teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a launch or change you coordinated, with the teams involved and your own part in it named. Selection scaffold: pick one instance with a named date, named teams and a decision you personally drove; if none comes to mind, say so plainly, then give the nearest thing your history does carry, or how you would run it |
| F2 | Running an operating cadence such as planning, reviews or status reporting (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, with what it replaced or improved. Selection scaffold: pick a cadence you ran, what it was for, and what changed because of it; if none comes to mind, say so plainly, then give the nearest thing your history does carry, or how you would build one |
| F3 | Using data to find problems and track outcomes (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a metric you defined or tracked, how it was counted, and what decision it informed. Selection scaffold: pick one figure you can explain end to end, including its weakest assumption; if none comes to mind, say so plainly and say what you would measure first |
| F4 | Working with product, engineering and go-to-market partners without formal authority (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team and how it ended. Selection scaffold: pick one with a named stake and an intact relationship afterwards; if none comes to mind, say so plainly, then give the nearest thing your history does carry, or how you would handle it |
| F5 | Writing and communicating clearly to senior audiences (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a memo, update or decision document you wrote and who read it. Selection scaffold: pick one artifact and its audience; if none comes to mind, say so plainly, then give the nearest thing your history does carry |
| F6 | Understanding the company's product and customers (role-family pattern, no posting) | none given | none | [generic] | discovery | Nothing in your material shows this yet. Research on Stripe did not run, so any claim about its products or strategy is deliberately absent from this pack |

## Persona table

No loop source established the rounds, so persona weights rest on a generic final-round pattern, not on Stripe's documented process. If your final is several sessions, send the schedule and I will split this into per-session mini-packs.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problem on launches, process or metrics | Highest: an operations role is hired on structure and reasoning, and a final round usually tests it live | Clarify, then objective, then segmentation, approach, metrics, risks. Think aloud and challenge one premise politely |
| B. Skeptic | Probes why this role, why now, and where you are thinnest | High: finals derisk gaps, and I have no CV to say where yours are | Rehearse the most predictable objection until it is boring. Bridge only from adjacent things you have actually said, plus a ramp plan |
| C. Peer Evaluator | Seam-splitting with partner teams, credit, disagreement | Medium: product operations sits between teams, so a peer or cross-functional interviewer is plausible | Offer principles for the seam rather than pretending to know it. Bring a disagreement story that shows spine and tact |
| D. Values / Behavioral | Scenario probes on how you behave | Medium: behavioral content appears somewhere in most finals, but no values-style round is established for Stripe | Pick stories only from your own history, using the scaffolds below |
| E. Pressure | Interrupts, time-boxes, tests composure | Lower: a stress style is possible from a senior interviewer | Pause, restate, hold a position through two follow-ups, concede specifically |
| F. Conversational | Friendly, loose, still scored | Lower but real: the casual opener is scored | Prepare a 90-second arc for the biography question |

The Data-Driven Prober is left out because there are no CV figures to probe. It joins the pack once you share one.

## Question banks

Question types: VAL, EXP, JD, CO, CASE. All provenance is generic because no candidate sentence was available to quote.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product launch is slipping and three teams each say another team is the blocker. How do you find out what is really happening?" | CASE | [generic] | Structure it aloud: what you would ask first, who you would talk to and in what order, what evidence separates a real dependency from a stated one, how you would reset the plan, and what you would record. The question needs no claim about your past, so the guidance makes none | The core product operations problem, asked as a decision. Case because it scores structure, not history |
| A2 | "Sketch how you would set up a planning and review cadence for a product organization. What do you need to know first?" | CASE | [generic] | Clarify scope and audience first, then state the objective, the rhythm, who owns each input, how decisions get recorded and how you would know it is working. Name one premise you would challenge | Tests clarifying before structuring. Tied to F2 as a role-family pattern |
| A3 | "Adoption of a recently launched feature is 20% below plan. Diagnose it." | CASE | [generic] | Define the metric, check how it is counted, segment by customer type and funnel stage, separate a measurement problem from a real one, then propose what you would check first and what you would stop. Say plainly which assumptions you cannot verify from the chair | Tests F3. Metric-drop diagnosis is a standard live case for operations roles |
| A4 | "How would you decide which of five competing requests from product teams gets operations support this quarter?" | CASE | [generic] | State the criteria you would use, how you would get them agreed, who gets told no and how, and what you would revisit later. Include an explicit anti-pick, something you would decline | Operations roles are partly about saying no. Tied to F1 and F4 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Name one real gap in your own words, then a concrete ramp plan for the first 30 days. Choose the gap from the worksheet rows above where you honestly have the least. Do not claim a strength to avoid the question, and do not volunteer a gap that is really a strength in disguise. If you cannot name one, say so plainly and name the area where you have the least depth | A final round derisks gaps. I cannot see yours, so this is inferred from the pattern, not from your background |
| B2 | "Why product operations, and why Stripe, and why now?" | EXP | [generic] | Three short answers in your own words. Each reason should be one you can defend under a follow-up. For why Stripe, use only what you have personally read or used, since this pack has no research on the company to lend you. If your honest answer is thin, say so and say what you are doing to learn more | Motivation consistency is the Skeptic's main score. The company-specific half is left to you on purpose |
| B3 | "I do not see much overlap between your last role and this one. How would you handle that gap?" | JD | [generic] | Only use this question if a CV shows a real gap; until then, rehearse the shape. Name the nearest adjacent work you have actually done, say where it stops, then give your ramp plan. The pack cannot say what the overlap is until it sees your CV | Placeholder for the biggest background mismatch, to be replaced after a CV arrives |
| B4 | "What would make you leave this role within a year?" | EXP | [generic] | Answer from what you actually value in work, in your own words. Keep it consistent with your answer to B2. If no clear answer comes to mind, say so plainly and describe what you would want to know before accepting | Tests whether the motivation story survives cross-examination |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than a map: who owns the decision, who owns the process, how you escalate and how you keep the relationship. Do not pretend to know how this company draws the line. Ask what the current seam looks like | Seam-splitting is the Peer's native probe |
| C2 | "How do you handle credit when work spans several teams?" | VAL | [generic] | Use we for context and I for your contribution. Pick one cross-team piece of work from your own history where you can say clearly what was yours. If none comes to mind, say so plainly, then describe how you would handle credit | Collegial packaging of an attribution probe |
| C3 | "What could you do in your first month that would genuinely help my team?" | JD | [generic] | Reciprocity framing: what you would offer, not only what you need. Keep it to things a new person can do without context, such as listening, mapping how work currently flows, and fixing one small recurring irritant. Say what you would need to learn first | The Peer prices what the hire costs and contributes |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact afterwards. Say what the truth was and what you personally did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem. Its theme is the persona stem, not a Stripe value, since Stripe's published values were not retrieved |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a real tradeoff, a decision you made or influenced, and an outcome you can state honestly, including a cost if there was one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard behavioral stem. Not mapped to any Stripe value |
| D3 | "Tell me about a process you changed that other people did not want to change." | VAL | [generic] | Selection scaffold: pick one instance where you can state what the process was, who resisted, what you did and what happened. Keep your part separate from the team's. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | Tests F2 and F4 through behavior. Only a prompt, so it supplies no event |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has run product operations here before?" | JD | [generic] | Pause first. Hold one position through two follow-ups, built only on things you can say about yourself in your own words. Concede specifically where the other candidate is stronger, without folding on your core case | Hold-then-concede structure, rehearsed on the sharpest form of the Skeptic's question |
| E2 | "You have told me about the work you want to do. What would you stop doing here?" | CASE | [generic] | Pick one thing you would deliberately not do or would end, give the reason and the cost. Do not rescue the answer by adding a hedge. If the question lands on something you do not yet know, say so plainly | Tests composure and judgment under interruption |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc from your own history in three beats: where you started, the turn that mattered, and why this role is the next step. Every claim in it must be one you can support in a follow-up | The casual opener is scored |
| F2 | "What have you been reading or building lately that you are excited about?" | CO | [generic] | Name something real from your own recent work or reading and say why it interests you. If nothing comes to mind, say so plainly and name what you would like to learn | Casual questions on interests are scored for genuine interest |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-team launch coordination | A1, A4, D3 |
| F2 Operating cadence | A2, D3 |
| F3 Data and outcomes | A3 |
| F4 Partner teams without authority | A4, C1, C2, D3 |
| F5 Written and senior communication | none, and why: a spoken round does not test writing directly. A document or writing sample request may follow, so ask the recruiter |
| F6 Company and product understanding | B2, F2. Stripe-specific CO and CASE questions are not written, because research did not run |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this role, and what would make you say it was off track by day 60?" | Shows you think in outcomes and want an honest bar |
| R2 | "Where does product operations sit relative to product management and engineering, and where does that seam currently hurt?" | Takes the Peer's seam probe and turns it into your curiosity |
| R3 | "What is one process here that you would fix first if you had the time?" | Signals you are ready to take on real problems |
| R4 | "How does this team find out that a launch or change has gone wrong, and how quickly?" | Probes the operating cadence you would own |
| R5 | "What did the last person to do well in this role do differently?" | Asks for the success pattern from someone who knows it |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question, useful if you meet a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None built | No candidate sentences were provided, so there is nothing yet to stretch into an inflated form. This is a finding that the pack had nothing to inflate, not that nothing could be | When your CV arrives, this table is rebuilt from it. Until then, every selection scaffold ends in an honest branch, and no guidance cell asserts anything about your past |

## Sources

Provided documents: your message only (company, role and round).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | All calls refused. Would have supplied the official value names for a cheat sheet. No values-style round is established, so section 10 is dropped |
| 2. Stripe interview process, product operations | unavailable | All calls refused. Would have named the actual rounds and persona weights. The loop is a generic final-round pattern instead |
| 3. Stripe strategy and recent news | unavailable | All calls refused. Would have supplied the grounding for CO and CASE questions. Those are generic here |
| 4. Interviewer name and Stripe | n/a | No name was given |
| 5. Representative product operations JD | unavailable | All calls refused. Would have turned the fit snapshot rows from generic to inferred |

Searches sent, all refused:

- "Stripe operating principles values": refused
- "Stripe interview process Product Operations Manager": refused
- "Stripe strategy news 2026": refused
- "Stripe Product Operations Manager job description": refused

## Upgrade menu

- Your CV or a pasted summary of your background → the fit snapshot's evidence cells fill with your own sentences, the story scaffolds become story maps, and B1 and B3 sharpen to your real gaps
- The job description text → the fit snapshot's generic rows become grounded, and every requirement gets a JD-tagged question
- The final round's schedule and interviewer names → per-session mini-packs, interviewer reads and tailored reverse questions
- The recruiter's prep email → coverage of any announced deliverable or focus area
- Search access on Stripe → official values, loop structure and current strategy, which would turn generic CO and CASE questions into grounded ones
- A tuesday-dossier.md from an earlier job-underwriter run → verified evidence and prohibited claims, in place of what this pack had to leave open
