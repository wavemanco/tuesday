# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Assumed to be the hiring manager for this role; the persona weights below rest on that assumption.
- **Round:** one 60-minute interview, Friday. Saltmarsh's careers page describes its loop as a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home (Sources).
- **Version:** first build; nothing regenerated.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every question carries both, so you rehearse the delivery as well as the content. Guidance is scaffolding, not a script: where it quotes you, the quote is the whole claim, and where it gives an answer slot, the slot is an instruction for the interview and not a question for now.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Whether the claims in your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Labels in the Provenance columns: `[grounded]` traces to your message, the JD or cited research; `[inferred]` is derived, with the derivation named; `[generic]` is a role-family pattern with no claim about you or Saltmarsh, useful as rehearsal only.

## Prep triage

Work in this order and stop wherever time runs out.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the in-app-purchases question aloud until it is boring, including both follow-ups | C1, then D1 |
| 2 | Run the outage tabletop against a clock: first fifteen minutes, then the two-sentence player message spoken aloud | A1, A5, D2 |
| 3 | For each of the three values, decide whether a real instance exists. Where one does not, rehearse the honest branch | B1, B2, B3 |
| 4 | Read the Larkspur announcement and the values page once more, then run the shared-calendar question | A3, R1 |
| 5 | Write your own answers to the answer slots in the fit snapshot, because they recur across many questions | F1, F2, F3, F4, F5, F8 |

Everything else is insurance.

## The fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your message; no CV was supplied. The JD states no eligibility term (authorization, location, schedule, pay, credential), so no row is a gate and no gate question is asked. F9 and F10 are not JD requirements: they are the two gaps your message names, carried here because an interviewer is likely to raise them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title. It does not show events, or a second title, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-title lines make a probe on both likely. If any drops were events with a start and an end, say which and how you scheduled them; if all were content drops, or you planned for one title only, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD names four teams, so expect a probe on which of them you worked with. If you worked with any of design, art, engineering or community on a drop, say which and what you asked of them; if none, or it ran through someone else, say so plainly and say how you would start with each |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | discovery | The quote touches the KPI side by presenting retention numbers. It does not show a review, or who produced the figures, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or chose the figures, or any review followed a drop, say what it covered, in your own words; if the numbers came from someone else, or no review followed, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | The quote says you wrote it and that QA still uses it. It does not say who ran the checklist at each release, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on running it likely. If you ran it through releases with QA, say how it ran; if QA ran it, or it was not part of your releases, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your message gives four years as an associate producer and does not say whether the game was live-service. Keep the title as you wrote it: associate producer. Answer slot: if the game was updated on a schedule after launch, say how its updates ran; if it was not a live-service game, say so plainly and say what the weekly drops were |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in terms, though nothing inspected sits behind it, so expect a probe. Lead with it in the quote's own terms: you ran it, weekly, for your main title, for two years. A named calendar beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in terms, though nothing inspected sits behind it. Lead with the quote: you presented the retention numbers monthly to the studio head. Comfort beyond that is not claimed, and E1 is where a probe on how they were counted arrives |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | discovery | The checklist is written work others rely on, and the words stay at that: "I wrote the release checklist our QA team still uses." Answer slot: the JD's line makes a request for another example likely. If there is other writing that others used, say what it was and who used it; if the checklist is the only one, say so plainly and stay with it |
| F9 | Not in the JD; your message names it as a gap: working on a game with in-app purchases | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then what your material does carry (F6, F7) at its own scope, then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Not in the JD, which asks for coordination (F2) and says nothing of line management; your message names it as a gap: leading a team | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | Words: "I haven't led a team." Said once, plainly, then the coordination you can actually speak to, in F2's slot. Nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only. Rows I1 to I3 are facts and sources; I4 to I6 are this pack's reading of them.

| # | Signal | Source | Implication for this round | Provenance |
|---|---|---|---|---|
| I1 | Head of Live Operations at Saltmarsh Games | Your message; search result for his name | The Outage Hour is run by the hiring manager, per the careers page, so the tabletop and the values conversation are most likely his | [grounded] |
| I2 | Gave a GDC 2026 talk titled "Patch Notes Are a Promise", arguing a live team is judged by how often its patch notes describe what actually shipped | Search result snippet; the page was not fetched | His own public theme is announcements matching what shipped | [grounded] |
| I3 | Previously a QA lead at a console studio | Same snippet as I2 | His background includes release quality | [grounded] |
| I4 | I2 and the published value "Ship the Patch Not the Promise" say the same thing | Derived from I2 and the values page | Expect precision probes on whatever you claim: anything you say about your past will be tested against what you can actually back. The prohibited list below is the guard | [inferred] |
| I5 | I3 and F4 sit in the same professional area: release process | Derived from I3 and F4 | Mirror opportunity: if the conversation reaches release process, your own sentence is "Wrote the release checklist our QA team still uses" (F4). Use it as a professional point of contact, never as a shared-background play | [inferred] |
| I6 | I4 tilts him toward claim precision | Derived from I4 | Prober weighted up from its prior (persona table) | [inferred] |

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a simulated outage during a live event | Highest. The hiring-manager prior is Case plus Skeptic, and the careers page names the live-incident tabletop as half of the session. 5 questions | Clarify, then structure, then answer; say the player message aloud; speak in Saltmarsh's own value names |
| B. Values / Behavioral | The second half of the hour, as a values conversation | High. The careers page names the values conversation, and the values page publishes three values, each needing a question. 4 questions | Map a story where a quote of yours carries one; where none does, use the selection scaffold and the honest branch |
| C. Skeptic | Quiet probing of F9, F10 and the one-title calendar | High. Hiring-manager prior, and the biggest gaps in the snapshot are stated by you. 4 questions | Rehearse C1 until it is boring: plain acknowledgment, then the quotes at their own scope, then a plan |
| D. Pressure | Interruptions and time-boxing inside the tabletop | Mid. A simulated outage invites it, but no source says Tobias interrupts. 3 questions | Pause, restate, anchor in what you said, hold through two follow-ups, concede specifically |
| E. Data-Driven Prober | Retention and KPI follow-ups; precision on claims | Mid. The JD's KPI and retention lines, plus I4 and I6. 3 questions | Know what you can and cannot say about how each number was counted; name the weakest assumption first |
| F. Conversational | The opener, and a casual question about what you play | Low. Hiring-manager sessions often open softly, but the loop source names no warm-up. 2 questions | A 90-second arc built only from your own three sentences; treat casual questions as scored |
| G. Peer Evaluator | Not banked | The interviewer heads the function, so a peer style is implausible. If Tobias turns out not to be the hiring manager, this reweights | None needed unless the relationship changes |

## Question banks

Answer slots do not ask for a reply here; they are instructions for the interview.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Halfway through a live event, a reward isn't reaching some players. Engineering says the fix is a couple of hours out. Walk me through your first fifteen minutes." | CASE | [generic] | Clarify before you structure: what is confirmed and what is only suspected, how many players, since when, whether the event can be paused. Then three moves, in order: stop the damage, tell players what is true, get the right people in one place, with one owner per task. The JD names design, art, engineering and community; QA belongs in the room too. Say the player message aloud in two sentences: what you know, what you don't, when the next update comes. Promise nothing the build has not yet delivered | The careers page describes the session as a tabletop on a simulated outage, so this is the likeliest shape of the first half. CASE because it is a live problem; it also scores F2's coordination and F8's written-communication requirements in a live setting |
| A2 | "The outage is over. What goes in the post-event review, and who reads it?" | CASE | [generic] | Structure: the timeline in plain order, what players experienced, the cause, what players were told against what was true, then what changes, each change with an owner and a date, including the checklist and the calendar. Close on how you would know it worked: pick KPIs you can define, and say how each is counted. Write it so someone who was not there can act on it | Scores the JD's review line (F3) as a live task, and the published value about leaving the checklist better. CASE because it is asked as an exercise, not a record |
| A3 | "Project Larkspur puts Tidepool Tactics and Lantern Row on one shared events calendar. What would you want settled before the first shared event?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: what is shared (dates, tooling or decisions), who settles a clash, what each title's players expect. Then split events that must be shared from events that stay per-title, name the risk that one slip now touches two titles, and challenge one premise respectfully: ask whether the two titles in this role are these two. On your own calendar experience, your words are "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on planning alongside another plan likely. If any other team's or title's plan shared your calendar, say what and how clashes were settled; if none did, say so plainly and stay with the calendar you ran | F1 is where this presses. CO because it asks at the company's current-strategy altitude (Sources), with CASE delivery |
| A4 | "One title's season finale and the other title's launch event land on the same weekend. How do you decide?" | CASE | [generic] | Ask what is fixed and what can move. Weigh the cost to players first, the published value is "when the calendar and the players disagree, the players win", then team load and cost of a slip. Decide, tell the teams and the players, and record why. Speak your reasoning aloud, including the option you rejected | F1 and F6 are the requirements it scores. CASE because it is a live scheduling problem |
| A5 | "QA hasn't signed off the build the night before an event goes live, and the event is already announced. What do you do?" | JD | [generic] | Ask what QA found and whether it blocks or can ship as a known issue. Lay out the options: hold, ship reduced, ship with the issue disclosed. Ask who owns the call. Then the value, "we announce what is built, not what is hoped": tell players only what is true. Afterwards, change the checklist so the miss is caught earlier | The JD's manage-the-checklist-with-QA line, F4, as a live decision. JD because it scores a stated responsibility, with CASE delivery |

### B. Values / Behavioral

Four questions, not three: the published values need one question each, and the fourth is the stem a values round most often adds.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a moment when a drop's date, content or order was in tension with how players were responding or what they needed. It needs a named stake, a decision you made or argued for, and what happened. Show the choice, not the principle; "we" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | Published value "Players Before Plans" (Sources). No quote of yours carries a story for it, so this is a scaffold, not a story map; F6 is the nearest material |
| B2 | "Tell me about a time you held back an announcement because the thing wasn't built yet." | VAL | [generic] | Selection scaffold: pick a time you said "not yet", or corrected a date, because what was built did not match what was planned. It needs what was about to be promised, who pressed, what you said and when. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it: tell players only what is built and say when you will update them | Published value "Ship the Patch Not the Promise" (Sources). Nothing in your material is a held announcement, and the pack will not supply one |
| B3 | "Tell me about a time a release taught you something, and the next one went differently." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: the beats are what the sentence states, that you wrote the release checklist and that QA still uses it. Tell them in your own words. Answer slot: the published value makes a probe on the checklist's changes likely. If it changed after a release, say what changed and why; if it did not, or the changes were not yours, say so plainly and stay with having written it | Published value "Leave the Build Greener" names the checklist directly (Sources). F4 is the only row whose evidence carries a story for it |
| B4 | "Tell me about a time you delivered news a senior person didn't want." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time the news was unwelcome and it landed, with a named stake, what you said, and what the person did or understood. The nearest material your quote carries is: "I presented the monthly retention numbers to the studio head." Answer slot: whether any of those numbers were unwelcome is not in your material. If any were, say what and how it was received; if none were, or the numbers were not yours to explain, say so plainly and stay with presenting them | The values-round stem for a hard truth. F3 and F7 are the nearest rows, and neither carries an unwelcome message, so the scaffold ends in its honest branch |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see in-app purchases anywhere in your background. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | **The highest-ROI prep in this pack.** One: say the acknowledgment first, in one sentence, with no preamble and no apology: "I haven't worked on a game with in-app purchases." Two: then what your material carries, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head". Say them as facts, with no added claim about what they prove. Three: a plan, said as a plan and never as a past. Answer slot: say in your own words what you would learn first and who you would ask. Follow-up 1, "Why not hire someone who has?": return to step two and concede the specific: it is a real gap and it will take time. Follow-up 2, "What would you get wrong first?": answer slot: name, in your own words, the thing you would least trust yourself on yet; if you do not know yet, say so plainly | F9 is the likeliest and hardest objection, and the Larkspur announcement (Sources) makes the probe likelier, which is this pack's inference and not something the page says. F6 and F7 are the nearest material, and their limit is stated. JD because it scores the job's fit including its gap |
| C2 | "The role coordinates design, art, engineering and community on each update, and you haven't led a team. How do you get four teams to move for your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Acknowledge first: "I haven't led a team." Then your plan, said as a plan: what you would agree with each team at kickoff, such as what done means and who decides when two plans collide. Answer slot: if you have worked with any of design, art, engineering or community on a drop, say which and what you asked of them; if none, or it ran through someone else, say so plainly and say how you would start. Stay at coordination | F2 and F10. JD because the four-team line is the job's core |
| C3 | "You ran the calendar for your main title. This role plans for two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say the scope as it is: "I ran the weekly content-drop calendar for our main title for the last two years." Then your plan: what you would ask first about the two calendars, and what you would settle in the first weeks. Answer slot: if you ever planned for more than one title or alongside another plan, say how; if not, say so plainly and stay with the one calendar | F1. JD for the two-title line |
| C4 | "The role asks for 3+ years producing live-service games or apps. Tell me about your four years." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say it at its own scope and title: "4 years as an associate producer at a puzzle-game studio." Say associate producer; do not drop it. Then the calendar line. Answer slot: if the game was updated on a schedule after launch, say how its updates ran; if it was not a live-service game, say so plainly and say what the weekly drops were | F5, the JD's headline experience requirement, and the place a literal reading of the years would test the title |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, when you haven't led a team or worked on a game with in-app purchases?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate the question first. Hold: say the three sentences in order, as written, and nothing added. Concede the two gaps in plain words: "I haven't led a team, and I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the three sentences, never by adding to them | The Pressure delivery of C1's objection. F6, F4 and F7 are the held position; F9 and F10 are the concessions. EXP because it tests what is actually yours |
| D2 | "Stop. Your update told players the fix lands at six. Engineering just said maybe. What do you tell them now?" | CASE | [generic] | Pause, restate, and do not get defensive. Say what you know, what you don't, and when the next update comes, and correct the earlier message plainly: the published line is "we announce what is built, not what is hoped". If pushed to commit to a time, concede the uncertainty specifically and keep the next-update time | The interrupting-interviewer version of A1 inside the tabletop. Scores composure, and F8's written-communication line when the correction is worded aloud |
| D3 | "That retention reporting. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold exactly: "I presented the monthly retention numbers to the studio head." Answer slot: if you also built or chose the figures, say which parts, in your own words; if the numbers came from someone else and you presented them, say so plainly and stay with presenting them. Hold through two follow-ups by returning to the sentence, never by adding to it | The attribution probe on F3 and F7, the rows where the quote says presented and the JD says own |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which retention numbers did you present each month, and how were they counted?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Say which numbers in your own words. Answer slot: how each was counted. If you know, say so; name the assumption you would defend least before the interviewer does. If you do not know how a number was counted, say so plainly, which is an honest branch and not a failure. You gave no figure, so none appears here | F7. JD because the retention line is stated in the posting |
| E2 | "For a two-week event, which three KPIs would your post-event review report first, and why?" | JD | [generic] | Choose three you can define. For each: the decision it informs, how it is counted, over what window, against what comparison. Name the assumption you would defend least on one of them. This asks nothing of your past, so the guidance claims nothing of it | The JD's own line: own the post-event review and the KPIs it reports (F3). Built from the posting, not from Saltmarsh's practice |
| E3 | "How did you know a weekly drop had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if you measured a drop afterwards, say what you looked at and what you did with it; if you did not, or someone else did, say so plainly and stay with running the calendar | F3 and F6. The JD's review and KPI lines raise this probe |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | A 90-second arc built only from those three sentences, in that order, each beat what the sentence states, told in your own words. Why here is yours to state: answer slot: say what actually draws you to Saltmarsh. The values page and the Larkspur announcement are public (Sources) and can be named only if they are true for you | The opener is scored even when it is casual. F5, F6 and F4 are the three rows it draws on |
| F2 | "What are you playing right now, and what does its events calendar do well?" | JD | [generic] | Pick a game you actually play. Name one event or season in it and what players got from it, and say why it worked for them. Speak from what you saw as a player and claim no inside knowledge of how it was made | Casual questions about hot topics are still scored; this one tests live-events fluency. F1's requirement, asked in a friendly register |

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A4, C3, F2 |
| "coordinate design, art, engineering and community teams on each update" | C2, A1 |
| "own the post-event review and the KPIs it reports" | A2, E1, E2, E3, D3 |
| "manage the release checklist with QA" | A5, B3 |
| "3+ years producing live-service games or apps" | C4, F1 |
| "experience running a content calendar" | A4, C3, E3 |
| "comfortable with player-retention metrics" | E1, E2, D3 |
| "clear written communication" | none as a JD-tagged question: it is scored in how A1's player message and A2's review are worded, and a request for another sample is covered by F8's slot |
| Not in the JD: in-app purchases (F9) | C1, D1 |
| Not in the JD: leading a team (F10) | C2, D1 |
| Published value "Players Before Plans" | B1, A4 |
| Published value "Ship the Patch Not the Promise" | B2, A5, D2 |
| Published value "Leave the Build Greener" | B3, A2 |

## Values cheat sheet

A values-style round is detected because the careers page names a values conversation as part of the session (Sources). Value names are as Saltmarsh publishes them.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quote of yours carries a story. Use B1's selection scaffold and its honest branch; the nearest material is F6: "I ran the weekly content-drop calendar for our main title for the last two years" |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quote of yours carries a story. Use B2's selection scaffold and its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses". Beats: you wrote it, QA still uses it. B3 holds the answer slot on what changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Project Larkspur retires per-title event teams in favour of a single live-ops group. How does that change what this role owns, and are the two titles in the JD the two moving to the shared calendar?" | Shows you read the announcement, and the answer settles a scope question that reshapes bank A |
| R2 | "Your GDC talk, 'Patch Notes Are a Promise', argues that a live team is judged by how often its patch notes describe what actually shipped. What does a producer do day to day to keep that true?" | Ties to his own public work, so it signals you researched him and not just the company |
| R3 | "What does the post-event review look like today, and what is one thing a recent one changed?" | Maps to the value about leaving the checklist better, and to the JD's ownership line |
| R4 | "Which part of this role would you want me strongest at in the first month, and which part is fine to learn on the job?" | Gives him room to name what matters most, and turns the in-app-purchases probe into a plan |
| R5 | "How do design, art, engineering and community each hear about an event change, and who settles it when they disagree?" | Tests the seam that F2's requirement lives in, and shows you think in decisions, not just coordination |
| R6 | "What would you want to have seen from me by day ninety?" | A concrete bar for success; rapport-style interviewers weight this slot heavily |

## Prohibited claims

Built from the fit snapshot before the banks were written. Each entry lists wording this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Four years producing live-service games | Inflated form of F5 | F5's quote at its own scope: "4 years as an associate producer at a puzzle-game studio". The limit is the pack's observation: your message says associate producer and does not say live-service. C4's slot asks only how the game's updates ran |
| Ran live events, or ran the calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a content-drop calendar for one main title. C3's slot asks only whether the calendar was ever planned alongside another plan |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses. The limit is the pack's observation: the material says wrote, not ran. A5 and B3 slots stay inside the checklist you wrote |
| Owned the retention KPIs or the post-event review | Inflated form of F3 and F7 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head". The limit is the pack's observation: the material says presented, not owned. D3 and E1 slots ask only what was yours within presenting |
| Has led a team | Negative the candidate stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

**Provided documents:** the job description and the background in your message.

**Searches and fetches sent:**

| # | Call | What came back |
|---|---|---|
| 1 | Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| 2 | Search: Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| 3 | Search: Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur |
| 4 | Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise |
| 5 | Fetch: https://saltmarshgames.com/values | The three published values, with a one-line meaning each |
| 6 | Fetch: https://saltmarshgames.com/careers/interviewing | The loop description quoted at the top of this pack |

Source notes: the Larkspur announcement (September 2026) and the talk were read from their search-result snippets only; neither page was fetched. The snippet reads: Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group. The careers and values pages show no date in what was returned.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | The values cheat sheet and the VAL questions B1 to B3, by official name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Established the loop: one session, the hiring manager, a tabletop then a values conversation. Persona weights and bank A follow it |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur: A3, R1, and the likelier probe in C1. Read from the snippet only |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, R2, and the Prober tilt. Read from the snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's notes on the tabletop (format, materials, which kind of event) → restructures bank A around the real scenario and may add a graded-deliverable section
- Confirmation that Tobias is the hiring manager for this role → fixes the persona weights, which currently assume it
- Your answers to the answer slots in F1, F2, F3, F4, F5 and F8 → those rows move from discovery or transferability to story maps, and C2, C3, C4 and E3 become sharper
- The release checklist itself, with sensitive details removed → raises F4 and F8 from medium to high, because it is the one inspectable artifact in your background
- A sample of the monthly retention material you presented, with sensitive details removed → raises F3 and F7 from medium to high and sharpens E1
- A `tuesday-dossier.md` from an earlier evidence review → replaces this pack's locally built prohibited list and inferred top objection with a verified one
