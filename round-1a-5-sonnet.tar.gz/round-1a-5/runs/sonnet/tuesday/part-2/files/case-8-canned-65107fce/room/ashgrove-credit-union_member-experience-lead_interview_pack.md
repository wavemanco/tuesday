# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 4 December 2026. Round 1 is a 30-minute recruiter conversation, round 2 is 45 minutes with the Head of Member Services (your future manager, mostly behavioural), and round 3 is a 60-minute panel of two branch managers with a 20-minute complaint-escalation case, scored against the four values. Interviewer names are not assigned yet, so there is no interviewer read.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your own account of your work holds up, and what was actually you |
| JD | A requirement the posting states, gaps included |
| CO | Whether you can think at Ashgrove's altitude: strategy, competitors, recent moves |
| CASE | A live problem from the role, scored on structure |

Guidance is scaffolding, not a script. Every quoted sentence in the Provenance column is yours; a clause in the guidance that says what you did rests on one of those quotes. An answer slot is an instruction for the interview, not a question for you now.

**Highest-ROI prep: B5**, with its recruiter-screen form A7. The role covers the contact centre, and your own message says you have never worked in one. This question will arrive in some form in rounds 1 and 2. A calm, short, rehearsed answer changes the interview more than anything else here.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the log, not the process, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any later steps were yours, say which, in your own words; if the log was where your part ended, or there were no such steps, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your material says a formal complaints log; it does not show whether outside rules applied to the complaints in it. Answer slot: the JD's regulated-complaints line makes a probe on that likely. If outside rules applied, say what they were and what your part was, in your own words; if you do not know, or none applied, say so plainly and stay with the log you handled |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers, the JD says supervisors, and the words stay with tellers: "I trained new tellers on our escalation script." Answer slot: if you have ever coached a supervisor on an escalation, say what and how, in your own words; if not, say so plainly and say how you would approach it |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote shows a monthly spreadsheet your regional manager uses; it does not show what it counted. Answer slot: the JD's volumes and resolution times line makes a probe likely. If it counted either, say how each was counted, in your own words; if it tracked something else, say so plainly and stay with the spreadsheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says spreadsheet, not Excel. Answer slot: if you built it in Excel, say so and what you used it for, in your own words; if it was another tool, say which |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated gap. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing is claimed about what you have presented at regional level, because your message does not say |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent. Answer slot: if you have worked with a digital or product team on anything, say what and what your part was, in your own words; if not, say so plainly and say what you would want to find out first |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Say it in the quote's own terms: six years in retail banking, the last three as a branch supervisor. The JD's words are "customer operations"; let the interviewer map your years to them rather than renaming your roles. Expect a probe on what your branch work covered |

No row is a gate: the JD states no authorization, licence, location, schedule or pay term, and its years requirement is graded as ordinary experience.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end | B2, C5 |
| Across branches and the contact centre | A7, B5 |
| Report monthly on complaint volumes and resolution times | B8, B9 |
| Coach branch supervisors on escalations | B3, C9 |
| Work with digital teams on self-service journeys | C7, B11 |
| 4+ years in financial-services customer operations | A8 |
| Experience handling regulated complaints | A9 |
| Confident presenting to senior leaders | B1, B6 |
| Comfortable with Excel reporting | B8, B9 |

## Grounding brief

From the July 2026 strategy brief the recruiter sent you, as you summarised it to me. Paste the full brief and this section grows.

| Strategy fact | Source | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | Strategy brief, July 2026 | [grounded] |
| "consolidate eight branches into five hubs over 2027" | Strategy brief, July 2026 | [grounded] |
| "launch a small-business lending product in Q1 2027" | Strategy brief, July 2026 | [grounded] |
| "the main competitive pressure is app-only banks" | Strategy brief, July 2026 | [grounded] |

---

# Round 1: Recruiter conversation (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, logistics, motivation | Highest. A recruiter screen is a logistics, motivation and knockout round in a friendly register; the risk is treating it as unscored | A tight biography arc in your own words; treat every casual question as scored |
| Skeptic (light) | Knockout checks on the gaps | Lower but real. The contact-centre scope and the years requirement are the predictable checks | Concede plainly what your message says you have not done; then give the nearest true thing |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F9, F1, F5. The beats are the ones the quotes state: six years in retail banking, the last three as a branch supervisor; the formal complaints log; training new tellers on the escalation script; the monthly spreadsheet your regional manager uses. Tell them in your own words and stop at what the sentences say | The recruiter opens on this in almost any screen. EXP because it tests whether your account matches your material, delivered in a conversational register |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] "Members First, Always" "Plain Words" "Neighbours, Not Numbers" "Own the Fix" "move 40% of member service to digital channels by 2028" | Pick one published value or one point of the strategy that is true for you, and say why in your own words. Do not recite the list. If nothing in them is true for you, say so plainly and name what in the posting appeals | The values and strategy come from the pages you supplied, so a specific pick scores as homework. CO because it tests knowledge of Ashgrove itself |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first; either is honest. If asked what you earn now: "I'd rather focus on the range for this role" | The recruiter will ask for the job's terms. JD because pay is a term of the listed job |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A term of the listed job that the recruiter needs to schedule around |
| A5 | "The role spans the branches and the contact centre. Where would you be based, and is moving between sites workable?" | JD | [generic] | Logistics slot: say where you can work and how often, in your own terms | The JD's branches-and-contact-centre scope raises it, and the brief's consolidation into five hubs over 2027 is why site questions are live here. The hub point is inferred, so ask rather than assume |
| A6 | "Why are you looking to move?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, short and true. Expect it to be compared with your answer to A2 | A recruiter checks motivation against what you said about the role. EXP because it is your own account |
| A7 | "The role covers the contact centre as well as the branches. What's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Concede cleanly: "I've never worked in a contact centre." Then what your material does carry, at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then your own plan for learning the contact centre: who you would sit with and what you would want to see first. Do not claim the branch work is equivalent | F2 is the headline gap and a recruiter screens on it. JD because it scores the stated scope; the plan is the Skeptic's counter-strategy |
| A8 | "The role asks for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the quote's terms: six years in retail banking, the last three as a branch supervisor. Let them map it. Answer slot: if asked what your branch work covered, answer from your own experience in your own words; if the JD's term does not fit it, say so plainly | F9 is a presentation row: the years are not in doubt, the vocabulary is. JD because it scores a stated requirement |
| A9 | "Tell me about the formal complaints work you did in your branch." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 and F3: you handled the branch's formal complaints log, and trained new tellers on the escalation script. Answer slot: the JD asks for regulated-complaints experience, so expect a probe on what rules applied to the complaints in the log. If any did, say what they were and what your part was; if you do not know, or none applied, say so plainly and stay with the log you handled | F3 is a discovery row, so this is where it gets asked. JD because the JD's regulated-complaints line raises it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RA1 | "What would the first six months in this role most need to achieve?" | It shows you are thinking about outcomes, and it gives you the language the next two rounds will use |
| RA2 | "How are the contact centre and the branches structured today, and who do complaints sit with now?" | You cannot research this, and it is the structure your biggest gap sits inside |
| RA3 | "How will the panel score the case — structure, the four values, or both?" | The recruiter has said the panel scores against the values; this finds out how the case is scored |
| RA4 | "Which of the 2027 changes — the hubs or the lending launch — touches this role first?" | It shows you have read the brief and tells you where the role starts |
| RA5 | "What happens after round three, and by when?" | Ordinary process diligence, and it is the one thing a recruiter can always answer |

---

# Round 2: Head of Member Services (45 minutes, your future manager)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" scenarios | Highest. The recruiter described this round as mostly behavioural | Where a quote carries a story, map it; where none does, choose an instance with the scaffold, and use the honest branch if nothing fits |
| Skeptic | Probes the contact-centre and senior-presenting gaps | High. A hiring manager is derisking gaps, and F2 and F7 are both stated | Concede plainly, hold what your quotes carry, and add a plan |
| Data-Driven Prober | Asks what the monthly spreadsheet counted | Medium-low. The role reports monthly and the one reporting artifact in your material is the spreadsheet | Say what you know about how it was counted and say plainly what you do not |
| Case / Strategist | A live problem on the role, or the strategy | Lower. A hiring manager would normally lean on cases, but the recruiter said mostly behavioural | Clarify before you structure; bring one view of your own on the digital shift |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | JD | [generic] | Your material does not show a time like this, so use the scaffold: pick a time you told someone senior something they did not want to hear. It needs what you told them, how you told it and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7's requirement is confident presenting to senior leaders, and this is the behavioural form of it. JD content, behavioural delivery |
| B2 | "Tell me about a time you kept hold of a member's complaint until it was resolved." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1: the beat the quote states is that you handled the branch's formal complaints log. Answer slot: the JD says own the process end to end and Ashgrove's value is "Own the Fix", so expect a probe on one specific complaint. If you saw one through, tell what happened and which part was yours; if the log was where your involvement stopped, or there is no such case, say so plainly and stay with the log you handled | F1 is a transferability row, so the manager will test how far it goes. JD because it scores the end-to-end line; VAL delivery |
| B3 | "You trained new tellers on your escalation script — how did you go about it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: you trained new tellers on the escalation script, and those are the beats. Answer slot: the JD says coach branch supervisors, so expect a probe on the difference. If you have coached a supervisor on an escalation, say how; if not, say so plainly and say how you would approach it | F4's quote is the closest your material comes to the coaching duty. JD because it scores that duty |
| B4 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Your material does not show one, so use the scaffold: pick a time a member's situation pulled against a target or a procedure. It needs the member's situation, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always is the first published value, and a manager's behavioural round will probe it. VAL because it scores a published value |
| B5 | "This role owns complaints across the branches and the contact centre. You've worked branch-side. What's your plan for the contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Concede: "I've never worked in a contact centre." Hold only what the quote carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Follow-up one, "why would branch experience carry over?": return to that sentence and concede you do not yet know where the channels differ. Follow-up two, "what would you do in the first weeks?": your own plan, built as who you would sit with, what you would look at first and how you would test what you learned. Hold through both; do not fold on the plain acknowledgment to restore harmony, and do not add contact-centre claims | F2 is the stated gap on the role's headline duty, so this objection arrives in some form. JD because it scores the stated scope; the hold-then-concede shape is the Skeptic counter-strategy |
| B6 | "The role presents complaint results to senior leaders. Where have you presented, and to whom?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Plain acknowledgment first: "I've never presented to anyone above regional level." Answer slot: if asked what you presented at regional level, say what it was, in your own words; if you did not present there either, say so plainly. Then a plan, said as a plan: what you would present, how you would rehearse it and who you would ask for feedback | F7 is a stated gap and the JD says confident. JD because it scores that line |
| B7 | "Why a complaints role rather than staying in branch supervision?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Your reason, in your own words, tied to something true in the JD or the values. The beat your quote carries is the three years as a branch supervisor; do not add a reason you did not give. If asked what you would miss, say so honestly | A manager hiring someone out of a supervisor role will ask. EXP because it is your own account, with JD content |
| B8 | "Walk me through the monthly complaints spreadsheet you built — what did it report, and who relied on it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5 and F6: you built a monthly complaints spreadsheet that your regional manager uses. Answer slot: the JD asks for monthly reporting on volumes and resolution times in Excel, so expect a probe on how each was counted and what the figures were sensitive to. If it counted those, say how and name the assumption you would defend least; if it tracked something else, or was another tool, say so plainly and stay with what it did. If asked how much of it was you, say exactly what was yours | F5 and F6 are discovery rows resting on one sentence. EXP because it tests attribution; the weakest-assumption move is the slot |
| B9 | "The role asks for Excel reporting comfort. How would you check a workbook before its numbers reach senior leaders?" | JD | [generic] | Structure it in your own words: what the number means, where it comes from, how you would test it, and who sees it first. The content is your own working method; the pack supplies no method. If you would check differently, say so | The JD's Excel and monthly-reporting lines both need an answer. JD content with a CASE delivery, and the question asks about no past |
| B10 | "Complaint volumes rise in one channel and stay flat in the other. What do you want to know first?" | CASE | [generic] | Clarify before structuring: ask whether both channels count a complaint the same way before you accept the premise. Then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully. The question asks about no past | Hiring managers set live problems from the role; this one uses the two channels in the JD. CASE because it scores reasoning |
| B11 | "The strategy moves 40% of member service to digital channels by 2028. What does that mean for how complaints are handled?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | The brief is available to every candidate, so differentiate. Bring the consensus item to show you read it, then one view of your own: which kinds of complaint you think should stay person to person, and why, and which you think self-service could take. The view is your judgement, with reasons | The brief supplies the strategy, and a recited shared source scores as homework. CO because it tests thinking at the company's altitude |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RB1 | "How does complaint resolution time get reported to senior leaders today, and what would you want better?" | It ties to the monthly-reporting duty and tells you what good looks like |
| RB2 | "Where in the process do members wait longest today?" | It shows you think in the member's time, and it names the first problem you would own |
| RB3 | "How do the branches and the contact centre hand complaints to each other today?" | It goes straight at the seam your gap sits in |
| RB4 | "What would you want from me in the first thirty days?" | A manager hears a reciprocal, not a taking, question |
| RB5 | "What will make someone in this role a success by the end of the first year?" | It gives you the manager's own definition, which you can use in round 3 |

---

# Round 3: Panel of two branch managers (60 minutes, including a 20-minute case, scored against the four values)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One scenario per published value | Highest. The recruiter said the panel scores against the four values | Map a story to each value where a quote carries one; otherwise the scaffold and its honest branch |
| Case / Strategist | The 20-minute complaint-escalation case, and strategy | High. The recruiter named the case; the format beyond that is unknown | Clarify, objective, segmentation, approach, metrics, risks; think aloud; use the values as lenses |
| Peer Evaluator | Seam and disagreement questions with branch-side stakeholders | Medium. Branch managers run the branches whose supervisors you would coach, and that is an inference from the JD | Reciprocity framing and seam principles, not pretended knowledge of their seam |
| Conversational | Open and closing questions | Low. Present as warm-up and close | Treat casual questions as scored |
| Pressure | Time-boxing in the case | Low. No source says this panel applies pressure, so it is not banked | Pause, restate, answer what you were asked |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Your material does not show one, so use the scaffold: pick a time a member's situation, not the process, drove your decision. It needs the member's situation, the decision and what it cost internally. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always, whose stated meaning is deciding from the member's side of the counter. VAL because it scores a published value |
| C2 | "Tell me about a time you made something clearer for a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: you trained new tellers on the escalation script, and that is the beat the quote states. Answer slot: Plain Words says "if a member needs it explained twice, we wrote it wrong", so expect a probe on wording. If you changed any wording, say what and why; if not, say so plainly and stay with the training | The nearest quote to Plain Words in your material is a script you trained people on, which is why the slot exists. VAL because it scores a published value |
| C3 | "Tell me about a time a branch's local community shaped how you did something." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Your quote carries only the years and the supervisor role, so use the scaffold: pick a time something local to your branch, its members or its town changed a decision. It needs the local fact, the decision and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers, and two branch managers are the likeliest to probe it. VAL because it scores a published value |
| C4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5: you built the monthly complaints spreadsheet that your regional manager uses. Answer slot: Own the Fix says "whoever finds the problem keeps hold of it until it is solved", so expect a probe on the problem. If you found one the spreadsheet addressed, say what it was and what you did; if it was assigned, or there was no problem behind it, say so plainly and stay with what you built | The only artifact in your material you built yourself. VAL because it scores a published value |
| C5 | "A member's complaint has gone between the branch and the contact centre, and they are now angrier. You have twenty minutes: what do you do, and what do you change?" | CASE | [generic] | Your own structure: ask what the member was told and what has been done, and what rules or deadlines apply; the objective; who owns it from now; the immediate fix, the process gap and any coaching need; what you would report afterwards; the risks. Say the structure aloud first. The four values are good lenses: one named owner is Own the Fix, a plain message to the member is Plain Words. The recruiter did not describe the real case, so this is a rehearsal of the shape | The recruiter named a 20-minute escalation case and said the panel scores against the values. Using the values in the case is an inference, so check the format on the day. CASE because it scores structure |
| C6 | "The strategy consolidates eight branches into five hubs over 2027. How should complaints be handled while that happens?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" | Ask before you structure: what is known, who is affected and what members have been told. Make no claim about which branches or decisions; you have no source for them. Then your own view on keeping members informed in plain words. Tie it to Neighbours, Not Numbers only if you can say how | Two branch managers may well care about the consolidation, which is an inference from the brief and a value that says every branch is part of its town. CO because it tests strategy fluency |
| C7 | "How would you work with a digital team on a self-service journey?" | JD | [grounded] "work with digital teams on self-service journeys" | F8 is silent, so this is an answer slot: if you have worked with a digital or product team on anything, say what and what your part was; if not, say so plainly and say what you would want to find out first, and who you would ask. The brief's 40% digital goal is the context, not a claim about you | F8 is a discovery row with no evidence, and the JD's duty needs a rehearsed honest answer. JD because it scores that duty |
| C8 | "Where's the seam between you and a branch manager when a complaint escalates, and what happens when we disagree?" | JD | [generic] | Propose principles, not a pretended seam: a named owner at each point, the member hears one voice, and a disagreement is settled by what is best for the member. Use only the principles you would hold to. Then what you would bring a branch manager: what they would get from the role, not only what you would need | A peer-style probe from the people whose supervisors you would coach. JD because it scores working across branches |
| C9 | "One of our supervisors escalates almost everything to you. How do you coach them without taking the problem off them?" | JD | [generic] | A live problem, so no past is claimed. Ask why they escalate first: what they are unsure of, what they were told. Then one thing you would teach, one thing you would leave with them, and how you would check it worked. Own the Fix is the lens: the problem stays with them while you coach | F4 is thin evidence for coaching supervisors, and a case is the honest way to show the approach. JD because it scores the coaching duty; CASE delivery |
| C10 | "What would you want to learn from us in your first month?" | JD | [generic] | A plan, not a claim: which branches and teams you would visit, who you would ask and what you would listen for. Ask rather than assume, and mention listening to the branch's own picture of its town | A warm, easy-looking question that is scored. JD because it shows how you would start the role |

## Values cheat sheet

Detected: the recruiter said the panel is also the values round and scores against the four values. The names are copied from the page you supplied.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | No quote carries one. Scaffold at C1, with its honest branch |
| Plain Words | If a member had to have it explained twice, the wording was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The sentence does not show whether wording changed; the answer slot is at C2 |
| Neighbours, Not Numbers | Each branch belongs to its town | F9: "6 years in retail banking, the last 3 as a branch supervisor." It carries the role, not a story; scaffold at C3, with its honest branch |
| Own the Fix | Whoever spots a problem keeps hold of it until it is solved | F5: "I built the monthly complaints spreadsheet our regional manager uses." The answer slot is at C4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RC1 | "Which kind of complaint takes up most of your supervisors' time?" | It goes straight at the coaching duty from the branch's side |
| RC2 | "When a complaint escalates from your branch, what do you most wish happened differently?" | It asks the panel to describe the problem you would own |
| RC3 | "What does Neighbours, Not Numbers look like in your branch day to day?" | It shows you read the values and want theirs, not the website's |
| RC4 | "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" | The reciprocity question for a stakeholder panel: what you bring them |
| RC5 | "What would help your supervisors through the move to hubs?" | It takes the brief seriously and invites them to say what they need, without assuming anything about their plans |

---

## Prohibited claims

Built from the fit snapshot before the banks. None of these is coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the log, not the process |
| Handled regulated complaints | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says a formal complaints log and does not show what rules applied. A9's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." B3's slot stays with the tellers |
| Reported on complaint volumes and resolution times; built Excel reporting | Inflated form of F5 and F6 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." B8's slot asks only what it counted and what tool it was |
| Has contact-centre experience | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot on that point |

## Sources

Provided documents: the job description you pasted; the four published values you copied on 25 November 2026 (pasted text, so the page itself was not fetched); the recruiter's email on the three rounds; the four strategy facts from the July 2026 strategy brief as you summarised them; your background message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | skipped | The pasted values page fixes the cheat sheet and every VAL theme |
| 2. `{company} interview process {role family}` | skipped | The recruiter's email names three sessions, who runs each and what each holds, which fixes the loop and persona weights |
| 3. `{company} strategy` / recent news | skipped | The July 2026 brief you supplied fixes the CO bank and grounding brief, and is under six months old |
| 4. `{interviewer name} {company}` | n/a | No interviewer names are assigned, so there is no query to form |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and JD-tagged questions |

## Upgrade menu

- Your CV, or just the complaints and supervisor lines → more quoted sentences, so the discovery rows F3, F5 and F6 and several scaffolds could become story-mapped
- Your answers to the answer slots in F1, F3, F4, F5, F6 and F8, said outside a drill → those rows regenerate on your own quoted words
- What the recruiter said about the case format, and any material sent in advance → a build section if anything is pre-declared, and a better C5
- The full strategy brief → a fuller grounding brief and sharper CO questions
- Interviewer names, when assigned → an interviewer read, persona weights tuned to each person's public footprint, and a reverse question tied to their path
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisation context
- A `tuesday-dossier.md` → verified evidence, per-requirement strategies and the underwriter's named objection, which would sharpen the grading above
