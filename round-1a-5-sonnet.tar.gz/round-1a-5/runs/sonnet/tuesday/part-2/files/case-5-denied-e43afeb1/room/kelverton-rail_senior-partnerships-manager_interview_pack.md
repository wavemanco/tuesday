# Interview pack: Senior Partnerships Manager, Kelverton Rail

## 1. Title block

- Role: Senior Partnerships Manager, Kelverton Rail (per your note: UK rail-tech that sells scheduling software to train operating companies)
- Round: second round, panel, 60 minutes, Tuesday. The recruiter's words: "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." Then Q&A.
- Panel, from the recruiter's email: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Recruiter's warning: "Ross will push on commercials."
- Prep time: about four hours over the weekend.
- Built from your message and the recruiter's email only. No JD was supplied, the market report's text is not in this pack, and no research ran (see Sources).

## 2. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (none detected for this round, so no VAL questions) |
| EXP | Whether your experience claims survive scrutiny, and what was actually yours |
| JD | The stated role and its requirements, including the gaps |
| CO | Company and strategy knowledge, and whether you think at their altitude |
| CASE | A live problem from the actual role, scored on structure and reasoning |

An "Answer slot" is an instruction for the interview, not a question for you now. Fill it from your own experience, or take the honest branch it offers.

## 3. Prep triage (four hours)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 90 min | Build and rehearse the 15-minute POV aloud, twice, against a timer: one consensus item from the report, one thesis, one anti-pick, and the operator close | Section 5, A1, A5 |
| 2 | 60 min | Rehearse the single most likely objection until it is boring: no rail selling, no direct quota. Hold-then-concede, out loud | B1, B2, B4, C2 |
| 3 | 45 min | For each number you will say (6 to 40 partners, roughly £4M influenced), write down how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; or write "I don't know how it was counted" | C1, D1, D2 |
| 4 | 25 min | Choose three reverse questions and say why you want each answer | Section 11 |
| 5 | 20 min | One cold run: 15-minute POV, then B1 and D1 without notes | A1, B1, D1 |

Everything else in this pack is insurance.

## 4. Fit snapshot

The requirements are the recruiter's own words, because no JD was supplied. F4 is a role-family requirement written from no source, so it is plain prose and raises no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, with nothing inspected behind it, and the words stay there: "I took it from 6 partners to 40." Answer slot: the recruiter's ask makes a probe on how that channel work maps to operator partnerships likely. If parts of it map, say which and how, in your own words; if none does, say so plainly and stay with the channel as you described it |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay at that scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter's ask for the operator's view makes a probe on what "the other side" meant likely. If you worked with operators' own teams, say who and what you learned, in your own words; if the work was planning for operators from outside, or bus and light rail only, say so plainly and stay there |
| F3 | "Ross will push on commercials" — recruiter's email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Your material shows influenced revenue and a stated absence of a direct quota, so the words are theirs: "I haven't carried a direct quota, only influenced revenue." Answer slot: if a commercial probe asks what you were accountable for, say which part of the influenced revenue was yours and which was shared; if none was clearly yours, say so plainly |
| F4 | Credibility with train operating companies (role-family requirement, no source) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## 5. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. Your own words from the brief: no slides, "just talk us through it", and "Please land on what it means for the operators themselves."

**Grounded facts to build on**

- The ask (recruiter's email): "where you'd take our operator partnerships over the next 18 months", landing on "what it means for the operators themselves".
- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F3: "Never sold into rail specifically and never carried a direct quota, only influenced revenue"

I don't have the market report's text, so the theses below are shapes to test against it, not conclusions about Kelverton's market.

**Three defensible theses. Pick one, not all three.**

| Thesis | One line you could say | Mandatory concession | What it means for the operators (the close) | Provenance |
|---|---|---|---|---|
| T1 Deeper before wider | Make a few operator partnerships work end to end before adding more | Coverage is slower, some operators wait, and revenue lands later; Ross will test exactly that | Fewer, better-run changes, with a named counterpart on the supplier side | [generic] |
| T2 Measure what changes for the operator | Agree with each operator, up front, the outcome that tells both sides the partnership is working, and report against it | Outcomes are harder to tie to revenue, and some will be soft; say so before Ross does | Operators help set the yardstick and the supplier is held to it | [generic] |
| T3 A joint plan with dated commitments | Put dated commitments from both sides in writing for each partnership | It needs operators to commit, and it can over-promise if their side slips | Operators know what they must do, what they get and by when | [generic] |

**Differentiating from the report.** The report is available to every prepared candidate and to the panel, so reciting its list scores as homework. Bring one consensus item from it to show you read it. Then take one thesis above as a deliberate departure, with reasons. Then give one anti-pick, something you would explicitly not do, because a partnerships role includes saying no. I can't name the anti-pick without the report. The criterion is whichever item would spread effort thinnest across operators for the least change on their side. If the report's framing looks dated, don't correct the panel; use the current framing without comment.

**Time budget**

| Minutes | Beat |
|---|---|
| 1 | Frame: the question you are answering and your chosen thesis |
| 3 | Where operator partnerships stand: one consensus item, in the report's own terms |
| 6 | The thesis, the how, the anti-pick, and the concession said aloud |
| 3 | What it means for the operators: what changes on their side, what they are asked to commit to, and how they would know it is working |
| 2 | What you would need to learn first, and what you would not assume yet |

Your limits belong inside the talk, not after it. F4 is the one the panel will see first, so name it once, plainly, and move on to what you would learn.

## 8. Persona table

Weights come in three passes. Relationship priors: Deepa is your future manager, which tilts Case/Strategist and Skeptic. Ross is a senior commercial leader whom the recruiter says will push, which tilts Pressure and Data-Driven Prober. Interviewer signals: none, because the interviewer searches were refused. Loop: one 60-minute panel with a 15-minute graded deliverable, established by the recruiter's own words.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Probes the POV live: "what do you need to know first", "which would you stop" | High. A hiring manager's prior, and the first 15 minutes are a live strategy exercise | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully (A1 to A5) |
| Skeptic | Quiet, persistent probing of the rail and quota gaps | High. A hiring manager's prior, and F3 and F4 make the objection predictable | Rehearse the single objection until it is boring; stay inside the quotes; give a ramp plan (B1 to B5) |
| Pressure | Time-boxed challenges to your attribution and your fit, from Ross | Medium. The recruiter's warning about commercials, plus an executive prior | Pause, restate, hold through two follow-ups, then concede specifically (C1 to C3) |
| Data-Driven Prober | Wants the denominator on 6 to 40 and the roughly £4M | Medium. Commercial questioning lands on your two headline numbers | Know how each was counted, or say plainly that you don't (D1 to D3) |
| Conversational | Opening and closing chat that is still scored | Low. Present, but not dominant in a panel with a graded deliverable | A 90-second arc for the journey question; treat casual questions as scored (E1, E2) |
| Peer Evaluator | Seam-splitting between teams | Low. Neither panelist is your peer | Not given a bank; reverse question 2 covers the Partnerships and Commercial seam |
| Values/Behavioral | Scenarios mapped to published values | Not plausible. The recruiter's email names no values round, and no values page was read | Not given a bank |

## 9. Question banks

Quote key used in Provenance (each appears verbatim in the fit snapshot):

- P1 = "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"
- P2 = "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- P3 = "Never sold into rail specifically and never carried a direct quota, only influenced revenue"

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have fifteen minutes: where would you take our operator partnerships over the next 18 months, and what does it mean for the operators themselves?" | CASE | [grounded] | This is the graded deliverable, so build it from section 5. Clarify what "operator partnerships" covers, state the objective, segment the operators, give the approach and the measures, name the risks, then land on the operator's side. The question needs no claim about your past, so the guidance makes none | The recruiter's email sets this question and its required close. CASE because it is scored on structure |
| A2 | "Which operator partnerships would you stop investing in, and why?" | CASE | [generic] | Give the criterion before any example: what you would stop and the test you would apply. Say the concession aloud. Name no operator unless the report names one | The anti-pick is where a prepared candidate separates from the consensus. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A3 | "What would you need to know in your first 30 days before committing to a plan?" | CASE | [generic] | Structure it as what you would ask operators, what you would ask the commercial team, and what you would read. Keep it a plan, not a claim about Kelverton | F4 makes "what would you need to learn" the natural follow-up to your POV |
| A4 | "Pick one operator and walk me through how you would run the partnership with them for the first six months." | CASE | [generic] | Choose a hypothetical operator, name your assumptions, then run a sequence: goals agreed, owners named, first review date, how the operator would know it is working. No past claim is needed | Tests whether the POV turns into practice, and F2's operator view is where it is most likely to be pushed |
| A5 | "What in the market report our strategy team circulated did you agree with, and where would you depart from it?" | CO | [grounded] | The recruiter attached it, so expect it to come up. Bring one consensus item to show you read it, then one thesis-driven departure with your reasons. I don't have its text, so no specifics are given here. Don't correct the panel on a dated framing | The report is available to everyone in the room, so differentiate from it, never recite it. CO because it tests homework depth |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What do you know about operators that we would otherwise have to teach you?" | JD | [grounded] P3, P2 | The highest-ROI rehearsal in this pack. Hold first on what you said: "I've never sold into rail specifically." Then your own scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: if you worked with operators' own teams, say who and what you learned, in your own words; if the work was bus and light rail planning from outside, say so plainly and stay there. Two follow-ups: hold by returning to the quotes, never by adding to them. Then the ramp as a plan, said as what you would do in the first 30 days | F4 is the largest gap and F2 is the only evidence that touches it, so this objection will arrive in some form. JD because it scores the role's operator credibility |
| B2 | "You've never carried a direct quota. How would you handle a number in this role?" | EXP | [grounded] P3 | Hold: "I haven't carried a direct quota, only influenced revenue." Then as a plan, never a past: what you would ask Deepa about how the number is set and what is in your control. Do not claim a quota-like discipline you didn't state | F3 is the stated absence, and Ross is pushing on commercials. EXP because it tests what was actually yours |
| B3 | "Why rail-tech partnerships next?" | JD | [generic] | Give your actual reason, in your own words. This pack holds none of yours. Select it on three tests: it is specific to this role, it is true, and it holds under a second "why". If no reason comes to mind, say so plainly, then give the nearest honest thing you do have | The "why here, why now" probe is the Skeptic's stem and the one most rehearsed too late |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] P3 | Name one limit your material shows, before they do: not having sold into rail, or not having carried a direct quota. Concede it in one sentence and move to the ramp plan. Don't offer an invented weakness | A manager asks this to derisk F4 and F3. The calibrated answer is a real limit and a plan |
| B5 | "What from running an ISV channel transfers to operator partnerships, and what doesn't?" | EXP | [grounded] P1 | Quote what you said: "last 4 at a payments company running the ISV channel", and "took it from 6 partners to 40". Answer slot: if any ISV partners resembled operators in how they bought, adopted or measured value, say how, in your own words; if none did, say so plainly and name what doesn't transfer | F1 is the bridge from your channel work to this role, and the recruiter's operator framing makes this probe likely. EXP because it tests whether the transfer claim survives |

### C. Pressure (medium weight, Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "That result: how much of it was actually you?" | EXP | [grounded] P1, P3 | Hold on your own words: "took it from 6 partners to 40", and "roughly £4M of influenced revenue". Concede specifically that the revenue was influenced, not carried. Answer slot: say which parts were yours alone and which were shared, in your own words; if you don't know how much was yours, say so plainly | The pressure stem for a headline claim. F1 and F3 together are where it bites |
| C2 | "Sixty seconds: why you rather than someone who has sold into rail?" | JD | [grounded] P1, P2, P3 | Pause and restate. Hold only what the quotes carry: the ISV channel from 6 partners to 40, and five years in bus and light rail network planning. Concede the one limit plainly: "I've never sold into rail specifically." Don't claim to be better than a rail-experienced candidate | F4 is the sharpest form of the objection. JD because it scores the fit directly |
| C3 | "A major operator tells you our product doesn't fit how their planners schedule. What do you do in the room?" | CASE | [generic] | Don't defend first. Ask what doesn't fit, separate what you can change from what you can't, say what you would take back and by when. Hold your position through two follow-ups, then concede what you don't know. No claim about your past is needed | Tests composure on the operator relationship itself. CASE because it is a live problem |

### D. Data-Driven Prober (medium weight, Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] P1 | Answer slot: say in your own words how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you don't know how it was counted, say so plainly. Don't explain a method you can't repeat under a second question | The headline figure is where a commercial director starts. F1 carries it |
| D2 | "Six to forty partners: how was a partner counted?" | EXP | [grounded] P1 | Answer slot: say in your own words what counted as a partner at 6 and at 40, and which of the change was yours; if you don't know how it was counted, say so plainly | A count that moved by that much invites a denominator question. F1 carries it |
| D3 | "How would you measure whether an operator partnership is working, in numbers I'd put in front of the board?" | JD | [generic] | Separate what you can count directly from what you can only attribute. Say which measure you would trust least and why. Link it to thesis T2 if you chose it. No claim about your past | Ross will test whether you can think in numbers about operators. JD because commercials were named by the recruiter |

### E. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] P1, P2 | A 90-second arc from the quotes only: five years in transport consulting (bus and light rail network planning), then nine years in partnerships, the last four at a payments company running the ISV channel. Answer slot: if you had a reason for each move, say it in your own words; if not, say so plainly | The opening question in a panel and the first impression. EXP because it frames everything after it |
| E2 | "What are you reading or watching in rail-tech these days?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Name only what you have actually read. The report is the one source this pack knows you have, so refer to it as such and say what you took from it. Don't name sources you haven't read | A casual question that is still scored on homework depth |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A4, A5 |
| "Please land on what it means for the operators themselves" | A1, A4, B1, B5 |
| "Ross will push on commercials" | B2, C1, C3, D1, D2, D3 |
| Credibility with train operating companies | B1, B4, C2 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a successful operator partnership look like twelve months in, from the operator's side rather than ours?" | It echoes the recruiter's operator close and shows you are thinking at that altitude |
| R2 | "Where does the line sit between Partnerships and Commercial when an operator relationship has a number attached?" | Ross is in the room, and the seam is where a Partnerships hire most needs clarity |
| R3 | "How is the number for this role set: direct quota, influenced revenue, or a blend?" | It surfaces the quota question on your terms before it is used against you |
| R4 | "What would you want to be true of this hire by month three?" | It converts your ramp plan into their definition of success |
| R5 | "What do you think the market report gets right that most readers will skim past?" | It turns your homework into a two-way conversation, and the answer shows how they read their own strategy |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never sold into rail specifically." No slot |
| Has carried a direct quota or revenue number | Negative you stated, F3 | "I haven't carried a direct quota, only influenced revenue." No slot |
| Delivered or closed the roughly £4M | Inflated form of F1 | F1's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not delivered |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning, not train operating companies. B1's slot stays inside that planning work |

## 14. Sources

Provided documents: the recruiter's email as you quoted it, and your background as you stated it. The market report was attached for you, but its text is not in this pack.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The search was refused. It would have fed a values cheat sheet, which no detected round calls for |
| 2. Kelverton Rail interview process | unavailable | The search was refused. The recruiter's own words already fix the loop, so it would have moved little |
| 3. Kelverton Rail strategy and recent news | unavailable | The search was refused. It would have fed a grounding brief and made A5 and E2 specific rather than shapes |
| 4. Interviewers' public footprint | unavailable | Both searches were refused. They would have fed an interviewer read, persona signals and a reverse question tied to their paths |
| 5. Representative JD | unavailable | The search was refused. It would have turned the F rows' requirements from the recruiter's words into a fuller `[inferred]` list |

Queries sent, all refused:

- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail strategy train operating companies scheduling software news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager rail technology job description train operating companies": refused

No dossier was present.

## 15. Upgrade menu

- The market report's headline findings, pasted → A5, E2 and section 5's consensus item stop being shapes and become specifics
- The JD text, if you have it → the F rows quote the JD's requirements instead of the recruiter's words, and mid-list requirements get their own questions
- Web search permitted in this session → values, loop structure, strategy and the two interviewers' public footprints; it would add an interviewer read, persona signals, and a reverse question tied to their paths
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, and only if search is allowed → a strategy brief and recent org context for a grounding section
- Your answers to the slots in F1, F2 and F3, outside a drill → those rows quote your own words instead of asking
- One line from the recruiter on what "operator partnerships" covers and whether the role carries a number → B2, D3 and R3 tighten
- A `tuesday-dossier.md` from an earlier fit check, if you have one → verified evidence and prohibited claims in place of this pack's locally built list
