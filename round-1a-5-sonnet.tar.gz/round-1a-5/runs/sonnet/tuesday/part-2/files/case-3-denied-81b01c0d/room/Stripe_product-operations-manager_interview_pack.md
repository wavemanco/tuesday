# Stripe — Product Operations Manager — final-round prep pack

Interviewer: not given. Relationship: not given, so this pack blends several. Built from your message alone: no JD, no CV, and no research (web search was not permitted in this session).

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: VAL (do your past actions show the company's published values), EXP (do your experience claims survive scrutiny), JD (can you do the listed job, gaps included), CO (do you know the company and its strategy), CASE (a live problem, scored on structure and reasoning).
- Guidance is scaffolding, not a script. Anything about your own past must come from your own experience, in your own words. This pack has none of your material, so it writes no claim about you anywhere.
- Where guidance says "if no such time comes to mind, say so plainly", that is a real option. An honest limit rehearsed beats an invented story.
- B1 is the highest-ROI prep in this pack: it will be asked in some form, and a calm, specific answer changes the interview.

## Fit snapshot

You gave no JD and no CV, so this is the worksheet version. The requirements below are role-family patterns, written as plain prose and not quoted from any posting. The bridge column says what strong evidence would look like, then gives a selection scaffold.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating a launch or program across product, engineering and customer-facing teams (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be one named program, who was involved, and what part was yours. Selection scaffold: pick a time you kept several teams moving toward one date; it needs a named stake, a moment where teams disagreed, and a clear statement of which part you owned. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing and running repeatable processes for how products ship or get adopted (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a process that still ran after the first use, with the problem it fixed. Selection scaffold: pick a process you built or changed, say what it replaced, and say what you did not control. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Defining and tracking metrics, and diagnosing why one moved (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a metric you can explain end to end: how it was counted, what it is sensitive to, which assumption you would defend least. Selection scaffold: pick one number you would stand behind and rehearse those four. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing partners without formal authority and writing clear updates for senior readers (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be one disagreement that ended with the relationship intact, and one written update that changed a decision. Selection scaffold: pick the clearest of each. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizing competing requests and judging under ambiguity (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a trade-off where you said no to something, and why. Selection scaffold: pick one such choice, and state what was lost by it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No loop source was available, so the fallback archetype is Generic (screen, hiring manager, panel) with flat weights. That rests on a pattern, not on Stripe's documented process. Your note says "final round" but not how many sessions it holds or who runs them, so this is a single blended session. If it is several sessions, send the schedule and I will build per-session mini-packs.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live problem: plan this, diagnose that | Flat. Relationship unknown, so no prior applies. Depth is allocated for coverage, not predicted | Clarify, then objective, then segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Skeptic | Probes gaps and motivation: why here, why now, weakest area | Flat. Every candidate meets some version of this, and B1 is the most predictable | Rehearse B1 until it is boring. Build bridges only from your own stated evidence. Name a ramp plan |
| Values/Behavioral | Scenario prompts scored on past behavior | Flat. No values-style round is detected, because no loop source was read | Choose stories where the hard truth actually landed. Use "we" for context, "I" for your contribution |
| Data-Driven Prober | Walks a number back to its inputs | Flat. Relationship unknown | Know how each figure was counted and say plainly when you do not know |
| Peer Evaluator | Seam-splitting, credit, collaboration | Flat. Relationship unknown | Reciprocity framing. Propose seam principles instead of pretending to know the seam |
| Pressure | Interrupts, time-boxes, questions motive | Flat. Relationship unknown | Pause, restate, hold a challenged position through two follow-ups before conceding anything real |
| Conversational | Friendly, unstructured, still scored | Flat. Relationship unknown | A prepared 90-second arc for the biography question |

## Question banks

Every row is `[generic]`: with no CV, no guidance cell below makes a claim about your past. Open prompts ask you to choose an instance, and each guidance ends with the honest branch.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A cross-team product launch is two weeks out and three teams disagree on whether it is ready. What do you need to know first, and how do you proceed?" | CASE | [generic] | Clarify before structuring: who decides go or no-go, what readiness criteria exist, what delay costs against shipping unready. Then propose a lightweight readiness check, name the one risk you would watch, and say how you would tell the teams. This is a plan, said as a plan | F1 and F2 as a live problem. CASE because it scores structure |
| A2 | "A newly launched feature's usage is 20% below forecast four weeks in. Diagnose it." | CASE | [generic] | Ask how the forecast was built before trusting the gap. Segment: who was expected to use it, who found it, who tried and dropped. Separate a measurement problem from a product problem from a rollout problem. State what you would check first and what would change your mind | F3 as a live problem. The persona stem is the diagnose prompt |
| A3 | "Five product managers each ask you for support in the same quarter, and you can serve two. How do you decide?" | CASE | [generic] | Ask what the support is for and what happens without it. Propose criteria you would state aloud before ranking anyone. Say how you would tell the three who lose out, and what you would offer them instead | F5 as a live problem |
| A4 | "How would you keep customer-facing teams informed about what product teams are shipping? What do you need to know first?" | CASE | [generic] | Clarify who needs what, by when, and what they do with it. Propose one channel and one cadence, and a way to learn it is not working. Challenge one premise, for example whether more information is the actual need | F4 and F1 as a live problem |
| A5 | "Sketch the plan for rolling out a new internal process to several product teams. What do you need to know first?" | CASE | [generic] | Start with the problem the process solves and who feels it. Pilot with one willing team, define what success looks like before the pilot, and say what you would stop doing if it does not help | F2 and F5 as a live problem |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Look at the coverage table and pick the requirement where your own material is thinnest. Say which it is in one plain sentence in your own words, then say what you would do in the first 30 days about it and how your manager would see progress. Expect three follow-ups: why that gap is acceptable, what would convince them you will close it, and what happens if it takes longer than planned. Answer each from the same one gap, without adding strengths to cover it. If no gap comes to mind, say so plainly, then name the area where you would ask the most questions first | F1 to F5 all feed it. JD because it scores the stated requirement list, and Skeptic because it probes self-assessment |
| B2 | "Why Stripe, why Product Operations, and why now?" | JD | [generic] | Three short parts, each from your own reasons. Any fact about the company you cite must come from a source you have read and can name, because this pack could not research it. If no reason comes to mind for one part, say so plainly, then say what you would want to find out | Motivation consistency is what a skeptic scores. Tagged JD for the role part and CO for the company part |
| B3 | "Walk me through what you would do in your first 30 days." | JD | [generic] | A plan, said as a plan: listen and map who depends on this team, pick one visible piece of work that a stakeholder would notice, and ask what success looks like at 90 days. Do not describe it as something you have done | F1, F2 and F5 as a forward-looking probe |
| B4 | "Pick the one responsibility of this role you have least direct experience with. How would you handle it?" | JD | [generic] | Choose from your own material, not from this pack. Say plainly what you have and have not done, then describe how you would learn it and who you would ask. If you cannot pick one, say so plainly, then describe how you would find out where your gaps are | Probes whether the candidate's self-assessment survives cross-examination |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time the hard truth actually landed. Name the stake, what you said, and how the relationship stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4. Persona stem. Not tied to Stripe's published values, which this pack could not read |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision, not a general attitude: the metric, the customer need, who disagreed, what happened. Use "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5. Persona stem |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number from your work that you would stand behind. Walk me through how it was counted." | EXP | [generic] | Four things, each in your own words: how it was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F3. A prober reads for the denominator |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it yourself before they do. If you cannot name one, say so plainly and say what you would check first | F3. Follow-up to D1 |
| D3 | "What would you want to measure in the first 90 days to know this role is working?" | JD | [generic] | Propose two or three measures, say what each would change, and say what you would need to learn before trusting them. Say which you would drop first | F3 as a forward-looking probe |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for a seam rather than claiming to know this one: who owns the decision, who is consulted, how a disagreement is escalated. If you have a disagreement from your own experience that ended well, use it; if not, say so plainly and describe your approach | F1 and F4. Persona stem |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | "We" for the shared outcome, "I" for your own contribution, and name the other team's part specifically. If no instance comes to mind, say so plainly and describe how you would handle it | F4. Persona stem |
| E3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity: one concrete ask and one concrete offer, each framed as a plan. Do not claim to know their team's pain points | F1. A peer prices what the hire costs and contributes |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two reasons from your own material in plain terms. Hold the position through two follow-ups, concede specific uncertainty where it exists, and do not fold on the core claim to restore harmony | Persona stem. Tests composure more than content |
| F2 | "Tell me about a result you are proud of. How much of it was actually you?" | EXP | [generic] | Say what was yours, what was shared, and what others did. Precise attribution beats a large one, because the second follow-up exists to find the seam. If no instance comes to mind, say so plainly | Persona stem. Attribution honesty |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A prepared arc of about 90 seconds: where you started, the one or two turns, and why this role is the next step. Every step comes from your own history, in your words | Casual questions are still scored. This one comes first in many conversations |
| G2 | "What have you been reading or working on lately that has shaped how you think about product operations?" | JD | [generic] | Pick something real that you can discuss for two minutes. If nothing comes to mind, say so plainly, then name the question you are currently curious about | Rapport-style interviewers score genuine interest |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-team coordination | A1, A4, B3, E1, E3 |
| F2 Repeatable processes | A1, A5, B3 |
| F3 Metrics and diagnosis | A2, D1, D2, D3 |
| F4 Influence and written updates | A4, C1, E1, E2 |
| F5 Prioritization under ambiguity | A3, A5, C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like in this role at 90 days and at a year?" | It surfaces the real scoring sheet and lets you check your own plan against it |
| R2 | "Which cross-team process in this area is working least well today, and what has been tried?" | It shows process thinking and tells you what the job is for |
| R3 | "How does this team decide what it says no to?" | Prioritization is a core skill here, and the answer shows how decisions get made |
| R4 | "What has changed in how the team works in the last year, and what prompted it?" | It signals you care about how the team evolves, not only where it is now |
| R5 | "What do people who do well in this role tend to do in their first three months?" | It converts a vague success picture into behaviors you can plan around |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer interviewer. It frames you as adding load-reducing capacity |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No candidate material was provided, so there is no sentence of yours to inflate and no stated negative to protect | Every story comes from your own experience, and every open prompt ends in an honest branch. If you supply a CV, this section is rebuilt against it |

## Sources

Provided documents: your message only. No JD, CV, dossier or interviewer information.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, each refused by the host:

- "Stripe operating principles values" — refused
- "Stripe interview process Product Operations Manager final round" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job description" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet and VAL questions tied to published value names. None built, so C1 and C2 are persona stems |
| 2. Interview process, role family | unavailable | Would have fixed the loop and persona weights. Weights are flat, on the Generic archetype |
| 3. Strategy and recent news | unavailable | Would have grounded a CO or CASE question in current priorities. All CO content here is generic |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. No interviewer read |
| 5. Representative role JD | unavailable | Would have turned the five role-family rows into inferred rows built on a real posting |

## Upgrade menu

- Job description text → the five `[generic]` requirement rows become `[grounded]`, and the coverage table checks against the posting's own list
- Your CV or a few lines about your background → the worksheet becomes a real fit snapshot, and guidance becomes story-mapped instead of selection scaffolds
- Who you are meeting and how many sessions the final holds → persona weights and per-session mini-packs
- Interviewer names → an interviewer read and a reverse question tied to their path
- The recruiter's prep email → coverage of any pre-declared deliverable, and the stated focus areas
- Web search access → values, loop structure and strategy sources, a values cheat sheet if a values round is documented, and CO questions grounded in current priorities. A deeper pass would add up to 6 searches and 2 fetches and take several more minutes
- A `tuesday-dossier.md` from an earlier role assessment, if you have one → verified evidence and prohibited claims, with no change to what this pack needs to run
