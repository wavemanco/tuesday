# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer unnamed. Built on your dossier (underwriting decision: conditional_go; condition: the bridge is positioned as adjacent, never as PM experience).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep: B1.** Your dossier's underwriting named that objection, so it is the one most likely to be asked in some form. Rehearse B1 first, then F2, which is the same answer under pressure.

## Fit snapshot

Requirement lines are quoted from the dossier's `role_profile`. Evidence is quoted from the dossier's `verified_candidate_evidence`. R1 is a length-of-experience requirement, so it is graded as a gap, not as a hard gate; the dossier lists no hard gates.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | Strategy `bridge`, derived from the underwriter's framing: adjacent work with its limit named, never PM experience. Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT and go-live." The limit, as the pack's observation: that is integration delivery, and it does not count as years of product management. The dossier's decision prose gives a tenure that no verified entry carries, so no tenure figure is used anywhere in this pack until you state one in your own words |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile | none given | none | [grounded] | capability | Strategy `acknowledge_gap`, so no bridge. The dossier's `prohibited_claims` lists "Having owned a product roadmap" and "Having set prioritization for an engineering squad", and its `uncertain_or_weak_areas` records the roadmap and prioritization sub-claim as `acknowledge_gap`. Words, sourced by those two fields: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past: what you would learn first and from whom. No answer slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | R2 is a must-have, but the dossier does not grade it in `uncertain_or_weak_areas`, so this grade is the pack's own. The quote says client integrations of the vendor's REST APIs; it does not show whether you shipped the API product itself. Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the JD's shipped-products line makes a probe on what went live and what part of it was yours likely. If the integrations you led are what went live, say what that covered, in your own words; if any wider piece was yours, say what; if there was no wider piece, or it was not yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [grounded] | presentation | The evidence already reaches this in other terms, and the words stay in the quotes: "I led 30+ end-to-end client integrations of the vendor's REST APIs, including architecture, and I wrote the integration playbook my team uses." The pack's observation: your material does not name API docs or schemas, so neither word goes in your answer unless you can speak to it from your own work (A4 holds the slot). The playbook is the inspectable artifact the dossier notes; it is an internal document, so describe what it covers and share it only if you have cleared that |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The client side is carried at the quotes' scope. The second quote is medium: confirmed, limited inspectable proof, so volunteer that limit before a prober extracts it. Engineering and sales are not shown by either quote. Answer slot: the JD's line on engineering, sales and customers makes a probe on the engineering and sales sides likely. If you worked with either, say who and what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the clients |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | Strategy `clarify`; confidence is the dossier's grade. None of your three verified entries speaks to Agile delivery itself, so nothing is quoted. Answer slot: the JD's Agile line makes a probe on how you have worked with delivery cadences likely. If you worked that way, say how, in your own words; if you never did, say so plainly. Either way, add the honest clarifier: "Here's what I'd want to confirm about how you define it here" |
| F7 | "Run discovery with integration partners" — dossier role_profile | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Words stay at the quote: "I ran quarterly roadmap-input sessions feeding client evidence to product." The pack's observation: the quote says clients, not integration partners, and sessions that fed evidence to product, not discovery you ran. Say the medium limit before it is asked for |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote reaches requirements and go-live for client integrations; it does not show specs or engineering squads. Words stay there: "Scoping and requirements were part of the client integrations I led." Answer slot: if you wrote the requirements for any of those integrations, say what they covered and who built from them, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the integrations you led. The playbook is documentation, not requirements, so do not offer it as the same thing |
| F9 | "Define and track adoption metrics" — dossier role_profile | none given | none | [grounded] | discovery | Strong evidence here would be a figure you defined or tracked for something you delivered, with how it was counted. Answer slot: the JD's adoption-metrics line makes a probe on whether you tracked adoption of anything you delivered likely. If you did, say what was counted and how, in your own words; if not, or it was not yours, say so plainly and say what you would measure first (A1 rehearses that) |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems drawn from the role's responsibilities: adoption, roadmap order, a partner escalation | High. A hiring-manager round starts from this prior, and the role profile's responsibilities are plan-and-prioritize work. No interviewer profile exists to adjust it | Clarify, objective, segmentation, approach, metrics, risks; think aloud; ask who decides before answering who decides (A1, A2, A5) |
| Skeptic | The title and roadmap objection, then the Agile and day-one-weakness probes | High. The dossier names the objection and records three weak areas | Rehearse B1 until it is boring; name the limit before it is asked for; plain acknowledgment where the dossier gives one |
| Data-Driven Prober | The 30+ figure and the medium-confidence sessions | Medium. The dossier carries one number and one entry with limited inspectable proof, both natural probe targets | Know what you can and cannot say about how the 30+ was counted; say plainly where you do not know (C1, C2) |
| Conversational / Rapport | Biography opener, a casual "what would you ask a partner" | Medium. You described the session as a conversation, which raises the opener and homework questions | A 90-second arc built only from your three verified entries (D1); treat casual questions as scored |
| Peer Evaluator | The seam with the two squad leads | Low. The interviewer is the hiring manager, not a peer; the squad leads are the peers, so expect the seam as a hypothetical | Propose seam principles rather than pretending to know the seam (E1) |
| Pressure | The same objection, harsher and time-boxed | Low. A conversation register makes it less likely, but B1's answer must survive it | Pause, restate, hold the same sentences through two follow-ups, concede only what the dossier sources (F1, F2) |
| Values/Behavioral | Unpopular-truth and customer-first prompts | Low. Nothing you have said names a values round, and no loop source for one was read | Selection scaffolds with an honest branch (G1, G2) |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose partner adoption of an API platform has flattened: partners finish integrating, then call volume stays flat. Diagnose it. What do you need to know first?" | CASE | [generic] | Think aloud in this order: what "adoption" means here and how it is measured today, the objective, how you would segment partners, your approach, the metrics, the risks. Name the one metric you would trust least, and why, before they ask. The question needs no claim about your past, so the guidance makes none | Covers the adoption-metrics responsibility (F9). CASE because it is a live problem; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "You inherit the roadmap for the partner API platform, with two engineering squads and requests from sales and partners. How do you decide what goes first, and who has the final say?" | CASE | [generic] | Ask before structuring: which decisions are yours and which sit with the squad leads, since the dossier records that as unresolved. Then give principles for deciding, said as how you would work, not as something you have done. Say which inputs you would weigh and from whom, and where you would hand the call to a squad lead. Do not open with a past example of setting priorities: that claim is on the prohibited list | The roadmap responsibility is where F2's gap presses hardest; CASE because it asks for a method on a hypothetical |
| A3 | "The role asks for shipped API or platform products. What have you shipped, and what was your part in it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3 at the beats the quote states: the 30+ client integrations, the vendor's REST APIs, scoping, requirements, architecture, UAT, go-live; tell them in your own words. Answer slot: the JD's line asks for shipped products, so expect a probe on what went live and what part of it was yours. If the integrations you led are what went live, say what that covered; if any wider piece was yours, say what; if there was no wider piece, or it was not yours, say so plainly and stay with the integrations | R2 is a must-have, so it needs a JD question (F3). JD because it scores the stated requirement; the dossier did not grade it, so the slot protects you |
| A4 | "How comfortable are you with API docs and schemas, and what would you check first in a schema?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Lead with the quotes in their own terms: "I led 30+ end-to-end client integrations of the vendor's REST APIs, including architecture, and I wrote the integration playbook my team uses." Answer slot: the JD's docs-and-schemas line makes a probe on whether you worked with them directly likely. If you did, say what and your part, in your own words; if not, or it was someone else's job, say so plainly and stay with the architecture of the integrations. For the second half, answer as a method, not as a memory | R3 coverage (F4). JD because it scores a stated qualification; the playbook is the inspectable proof the dossier notes |
| A5 | "A partner says an API's error behavior is why their integration slipped. Sales wants a custom fix; the squad lead calls it out of scope. What do you do?" | CASE | [generic] | Facts first: what happened and how far it reaches. Then who decides, asked rather than assumed. Lay out the options and their costs, say what you would tell each of the three parties separately, and name one position you would hold and one you would concede. No claim about your past is needed | R4 across engineering, sales and customers (F5), asked as a decision on a hypothetical |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The highest-ROI rehearsal, and the objection is the underwriter's wording. Its two negatives are sourced by the dossier's `prohibited_claims` and by its `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)". Pause and restate both parts. Then the plain acknowledgment: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the adjacent case with its limit named before it is asked for: "What I bring is adjacent: I led 30+ end-to-end client integrations of the vendor's REST APIs, and I wrote the integration playbook my team uses. That is integration delivery, not product management, and I'm not presenting it as the same thing." On the comparison, say the role asks for the title's experience, that you are offering adjacent evidence, and invite them to test it. Follow-up 1, "So you've never prioritized for a squad": hold the sourced acknowledgment, then give the ramp plan as a plan. Follow-up 2, "Then why not hire the PM": return to the same two sentences and add nothing. Follow-up 3, "What would make you fail in six months": name the limit yourself, roadmap ownership and prioritization across two squads, then the ramp plan. The roadmap-input sessions are left out on purpose: they sit next to roadmap ownership and would read as a bridge the dossier closed; C2 holds them | The dossier names this objection (F1, F2). JD because it scores the stated R1; deepest rehearsal means the most follow-up levels and an exact concession, with no more affirmative content than the quotes carry |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap` area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it yourself, plainly: owning the roadmap and setting priorities across two squads, which is the dossier's `acknowledge_gap` area. Then the ramp plan, as a plan. Do not hunt for a smaller weakness to look modest, and do not volunteer Agile as a weakness: the dossier has it as something to clarify (B3), not something you lack | Standard Skeptic stem, aimed at F2. JD because it scores the listed job, gaps included |
| B3 | "How much of your delivery work has been Agile, inside a product team?" | JD | [grounded] | Strategy `clarify`: none of your three verified entries speaks to Agile delivery, so nothing is quoted. Answer slot: the JD's Agile line makes a probe on how you have worked with delivery cadences likely. If you worked that way, say how, in your own words; if you never did, say so plainly. Add the honest clarifier: "Here's what I'd want to confirm about how you define it here," then ask how the two squads run delivery | R5 is preferred, not must-have (F6), but it is a likely screening question and the dossier marks it for clarification |
| B4 | "Why this move, and why now?" | JD | [generic] | Your material carries no reason, so none is supplied. Pick a reason that is about the work, and test it by asking whether you would still give it if the title were different. Say it in your own words and keep it consistent with what you are not claiming in B1. If you have no settled reason yet, say what you are trying to find out in the role | Motivation consistency is what a Skeptic scores; JD because it asks whether you want the listed job rather than a title |
| B5 | "What would you need to learn first to earn the two squad leads' trust, and how would you go about it?" | JD | [generic] | This is a plan, never a past claim. Name what you would learn first, from whom, and in what order, and what you would ask each squad lead. Tie it to the open question of decision authority: you would want to know which calls are yours before you make any | Covers driving delivery with two squads (F8) and the dossier's unresolved authority risk; it is also your ramp plan from B1 |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words, none supplied here: how the 30+ was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how a count was made, say so plainly. Keep "30+" attached to the client integrations, not to the APIs or the stages | The one headline number in your material (F1); every figure gets a defend-the-number question |
| C2 | "Tell me about the quarterly roadmap-input sessions. What did you bring to them, and what came of it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the quote states: quarterly sessions, you ran them, client evidence, fed to product; tell them in your own words. Volunteer the limit first: the dossier has this at medium, confirmed with limited inspectable proof. Answer slot: the JD's roadmap line makes a probe on whether any of it changed what product did likely. If something did, say what and which part was yours; if nothing was taken up, or product decided elsewhere, say so plainly and stay with the sessions you ran. Say "input", never "ownership" | The medium-confidence entry is where a prober will find a seam (F5, F7) |
| C3 | "What would you put in a spec for a partner API change?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer the method as a hypothetical: what a squad needs in order to build, and what you would ask partners first. About your past, stay at the quote: "Scoping and requirements were part of the client integrations I led." Answer slot: if you wrote the requirements for any of those integrations, say what they covered and who built from them, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the integrations. Do not offer the playbook as the same thing | Covers the spec-writing responsibility (F8); JD because it scores the stated duty |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with only the beats the quotes state: you led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live; you wrote the integration playbook your team uses; you ran quarterly roadmap-input sessions feeding client evidence to product. Add no years, employers, titles or team sizes unless you state them as your own. Close with your reason for this role, in your own words, consistent with B4 | The opener is scored even when it feels casual; it draws on F1, F4 and F7 |
| D2 | "What do you know about how Quartzline's partners use the API today?" | CO | [generic] | No research ran, so the pack holds nothing about Quartzline beyond the dossier and will not guess. Do this homework yourself before Thursday: look at whatever Quartzline publishes for developers or partners, if anything, and bring back observations labeled as yours. If you find nothing, say what you looked at and turn it into a question, using the dossier's open item on how adoption is measured today. Never bluff | The company-knowledge question is labeled `[generic]` because the research that would ground it was refused |
| D3 | "If you sat down with one of our integration partners next week, what would you want to learn from them?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer forward: who they are, what they are trying to ship, where their integration is hardest, what they would change. If you want one past anchor, use only the quote: "I ran quarterly roadmap-input sessions feeding client evidence to product." State the limit: those were clients, not integration partners, and sessions that fed evidence to product, not discovery you ran | The discovery responsibility (F7); JD because it scores the listed duty |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The two squad leads and you disagree about what ships next. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know the seam: ask which decisions are the PM's alone, agree decision rights up front, bring evidence to a disagreement, and say when you would escalate. Offer reciprocity as method, what you would do to lower the squad leads' load, not as a claim about what you already did | The seam is the dossier's unresolved authority risk; CASE because it is a live scenario with no past claim |
| E2 | "Tell me about a time a customer and an engineering team wanted different things. What did you do?" | EXP | [generic] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick an instance with a named stake, what you did, and how the relationship ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the client integrations you led, at the quote's own scope, or give how you would handle it (A5) | R4's engineering and customer sides (F5); the pack has no conflict story from you, so this is a scaffold |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold only what the quote carries: "I led them." Hold it through two follow-ups by returning to that sentence. Concede specifically and only where true. Answer slot: if any stage of any integration was someone else's, say which and whose; if all of it was yours, say so plainly; if you do not know how a count was made, say so | The attribution probe on F1; hold-then-concede means you do not fold on the core claim and you do not add to it |
| F2 | "So you've never owned a roadmap. Why are you in this room?" | JD | [grounded] `acknowledge_gap` area: "Owning a roadmap and prioritization authority (R1 sub-claim)"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The same answer as B1, compressed. Pause, restate, give the sourced acknowledgment, then the adjacent evidence with its limit. Hold the same sentences through two follow-ups and concede nothing beyond the acknowledgment. Do not fold into a bigger claim to relieve the tension | B1's objection in a harsher register (F1, F2); the point is that the answer does not change with the delivery |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, what you said, how it landed, and the relationship afterward. Your material does not show such a time, and the pack will not supply one. If none comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | Standard values prompt; low weight because no values round is established |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same shape: choose a specific decision with a named stake and say what it cost. Your material does not show one. If none comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | Standard values prompt; low weight for the same reason |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | B1, B2, F2 |
| R2 Shipped API or platform products | A3 |
| R3 Technical fluency: API docs, schemas | A4 |
| R4 Stakeholder management across engineering, sales, customers | A5, E2 |
| R5 Agile delivery experience | B3 |
| Own the roadmap | A2, B1, E1 |
| Run discovery with integration partners | D3, C2 |
| Write specs and drive delivery with two squads | C3, B5, E1 |
| Define and track adoption metrics | A1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority as asserted in the JD but not evidenced; the answer tells you what you would be accepting, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier names adoption as a responsibility with no baseline stated; you need it before you could own the number |
| 3 | "What does a strong first ninety days look like, and who would I need to earn trust with first?" | It hands the interviewer your ramp plan from B1 and B5 and invites them to shape it |
| 4 | "Where does input to the roadmap come from today, and how does it reach the squads?" | It asks how partner and delivery evidence is used, which tells you whether your sessions experience maps onto anything real |
| 5 | "How are the two squads split, and how do the squad leads and the PM divide the week-to-week work?" | It tests the seam in E1 from your side and tells you what the day-to-day is |
| 6 | "Which part of this role would you most want a new PM to be strong at on day one?" | It lets the interviewer name the gap themselves, and you hear how heavily they weigh it |

## Prohibited claims

Built before the banks. The first three come from the dossier's `prohibited_claims`. The last three are built locally from the snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier `prohibited_claims` | The plain acknowledgment, sourced by that field: "I haven't held a product manager title or role." The limit is the quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" |
| "Having owned a product roadmap" | Dossier `prohibited_claims` and the `acknowledge_gap` area in `uncertain_or_weak_areas` | The plain acknowledgment: "I haven't owned a product roadmap." Nothing after it tries to close the gap; the roadmap-input sessions are a separate fact at their own scope (C2, D3), never offered as ownership. No slot |
| "Having set prioritization for an engineering squad" | Dossier `prohibited_claims` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Then the ramp plan as a plan. No slot |
| Shipped an API platform product | Inflated form of F3 | The F3 quote at its own scope. The limit is the pack's observation: the material says client integrations of the vendor's REST APIs. A3's slot stays inside that scope |
| Ran product discovery with integration partners | Inflated form of F7 | The F7 quote at its own scope: sessions with clients that fed evidence to product. The limit is the pack's observation, not words for you |
| Wrote product specs for the engineering squads | Inflated form of F8 | The F8 quote at its own scope: scoping and requirements were part of the integrations you led. C3's slot stays inside the integrations |

## Sources

**Provided:** `tuesday-dossier.md`, dossier version 1.1, dated 2026-08-14. Sections consumed: `handoff_to_mock_interview` (evidence, weak areas and strategies, the objection, risks, employer questions, prohibited claims), `role_profile` (requirement and responsibility lines), `decision` (context only). The dossier carried no `evidence_map`, `evidence_state` or `risk_register`. If the posting has changed since the dossier's date, the requirement lines here may differ. Its decision prose mentions a tenure that no verified entry carries, so no cell uses it. The session itself comes from your own description: one 45-minute conversation with the hiring manager.

**Searches sent, all refused (permission not granted):**

- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline partner API platform news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have supplied published value names for VAL questions and a values cheat sheet if a values round exists; G1 and G2 stay `[generic]` |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have shown whether this conversation is one of several rounds; persona weights rest on the hiring-manager prior and your own description of the session |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded D2 and the CASE rows A1, A2 and A5 in current strategy instead of `[generic]` patterns |
| 4. `interviewer name Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already supplies the requirement lines |

## Upgrade menu

- Web research on Quartzline (grant search, or paste its values page or careers page): turns the D2 company question and the A1, A2 and A5 cases from `[generic]` into strategy-grounded rows, and adds a values cheat sheet if a values round turns up
- A deeper research pass (offered once): up to 6 more searches and 2 more fetches, several more minutes, covering a strategy brief, role-family loop reports and recent org context
- The interviewer's name: adds an interviewer read, adjusts persona weights from their public footprint, and adds a reverse question tied to their own path
- Any recruiter or hiring-manager note on focus areas: adds coverage of whatever they said to expect; usually one email
- Your own words on the answer slots (F3, F6, F7, F8, F9, and how long you did the integration work): each becomes quoted material that upgrades its row and the questions drawing on it
- A record of what one of the roadmap-input sessions covered, such as an agenda or notes, or a note of what product took from them: the artifact that would raise F5 and F7 above medium
- The CV behind the confirmed claims: sharper verbatim quotes for the snapshot
