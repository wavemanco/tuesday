# Interview pack — Member Experience Lead, Ashgrove Credit Union

**For:** Dara · **Prepared:** 25 November 2026 · **Interviews:** 4 December 2026, three rounds (loop mode)

| Round | Length | Who | Relationship |
|---|---|---|---|
| 1 | 30 min | The recruiter | Recruiter screen |
| 2 | 45 min | Head of Member Services, mostly behavioural | Your future manager |
| 3 | 60 min | Panel of two branch managers; includes a 20-minute case on a complaint escalation; also the values round, scored against the four values | Panel, outside your reporting line |

No interviewer names or profiles exist yet, so there is no interviewer read. Persona weights rest on the recruiter's description of each round.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what is being scored.
- Type key: **VAL** behavioural or values alignment · **EXP** work-experience deep-dive · **JD** role or JD-driven · **CO** company and strategy knowledge · **CASE** live problem.
- Guidance is scaffolding, not a script. Where a row says **Answer slot**, it tells you what to say in the interview and asks nothing of you now: answer from what actually happened, or say plainly that the step was not yours or did not exist.
- Fit-snapshot rows are F1 to F9. Question IDs are A to E, then G, H, J, K, L, by persona within each round.
- **Highest-ROI prep in the whole pack: D2**, the contact-centre objection, in round 2. Do it first, out loud, until it is boring.

## Fit snapshot (shared by all three rounds)

Your evidence is the four sentences you gave me, quoted exactly. Nothing else about your past is used anywhere in this pack. No requirement here is a gate: "4+ years" is experience, not a legal or credential bar.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD, the branches half | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the log, not the process end to end, with nothing inspected behind it. The words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the rest of a complaint's path likely. If any other part of it was yours to run, say which part and what you did, in your own words; if the log was the extent of it, or the rest was not yours, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD, the contact-centre half | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote shows a monthly spreadsheet that your regional manager uses; it does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted. If it counted either, say how each was counted, what it is sensitive to, and which assumption behind it you would defend least; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with what it showed |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors. The words stay there: "I trained new tellers on our escalation script." Answer slot: if you ever helped a supervisor, yours or another branch's, through an escalation, say who and what you did; if you did not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital teams. Answer slot: if you have worked with a digital or product team, say who and on what; if you have not, say so plainly and say what you would ask them first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already carries the years and the sector. Say it in its own terms: "6 years in retail banking, the last 3 as a branch supervisor." Do not relabel the work in the JD's phrase for it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" is the quote's word; "regulated" is the JD's, and your material does not connect them. Answer slot: if the formal log fell under a regulator's rules, say which and what your part was in meeting them; if it was an internal log, or tracking the rules was not yours, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says a spreadsheet, not Excel. Answer slot: if you built it in Excel, say what you did in it, in your own words; if it was another tool, say which, and say what you have done in Excel if anything; if none of this was yours, say so plainly |

## Grounding brief — Ashgrove's July 2026 strategy

Source: the strategy brief the recruiter sent you, as you summarised it. I have your four points, not the document.

| Point from the brief | What it means for these interviews | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | Complaints and escalations will increasingly start in self-service journeys: material for G1, L2 and the JD's digital-teams line (F5) | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Likely live ground for the branch-manager panel in round 3, and it sits against the value "Neighbours, Not Numbers": see J3 and H3. Treat it as sensitive; do not guess which branches | [inferred] |
| Launch a small-business lending product in Q1 2027 | A new product is a new source of complaints; a first-90-days case can use it (G2) | [inferred] |
| Main competitive pressure is app-only banks | Frames L2 and the second half of H4: what does a member get from a well-handled complaint here that an app does not give | [grounded] |

## Round 1 — recruiter screen (30 minutes)

**Persona weights**

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational | Friendly walk-through of your background, why Ashgrove, logistics | high | Recruiter-screen prior; the recruiter describes this round as 30 minutes with them | Treat every casual question as scored; have the 90-second arc ready |
| Skeptic (light) | Quiet check on the two gaps you stated | medium | A recruiter screen carries a knockout check in a friendly register | Say the gap plainly and move to the plan |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc using only what the quotes state: six years in retail banking, the last three as a branch supervisor; the formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Same verbs, same scope. Close with why this role, in your own words | The opener of nearly every screen; F1, F3, F4 and F6 are the evidence. EXP because it tests what was actually yours; asked casually, so it is still scored |
| A2 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name two points from the July brief as the brief states them, for example the 40% digital target and the move from eight branches to five hubs, and say in your own words which one interests you and why. Do not add figures or timelines the brief did not give | A screen is where homework shows first. CO because it scores company knowledge; the brief is a provided document, so this is not guesswork |
| A3 | "What draws you to a member-owned credit union?" | CO | [grounded] | Your own reason, in your own words. If it helps, anchor it in a line from the published values you copied: "Members First, Always — we decide from the member's side of the counter." | JD names "member-owned"; the recruiter row also tests motivation consistency. CO and VAL both apply; CO leads |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, as your contract states it | The listed job's terms; one of the four logistics every screen asks |
| A5 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first, whichever you would actually do. If asked what you earn now: "I'd rather focus on the range for this role." | The JD states no pay, so expect this to be asked. Nothing here supplies a figure |
| A6 | "Is the location and working pattern workable for you?" | JD | [generic] | Logistics slot: state your own constraints on where and how often you can work. The JD's line covers branches and the contact centre, so expect the question to touch more than one site | The posting leaves location open and covers more than one kind of site; JD because it is the listed job's terms |
| A7 | "Why are you looking to move?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, in a sentence or two. Do not speak ill of your current employer | Motivation consistency is what a screen scores; the only safe answer is your own |
| A8 | "Tell me about your complaints experience." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it at its scope: you handled the branch's formal complaints log and trained new tellers on the escalation script. Answer slot: the JD's "regulated complaints" line makes a probe on which rules governed the log likely. If the formal log fell under a regulator's rules, say which and what your part was; if it was an internal log, or tracking rules was not yours, say so plainly and stay with the log | F1 and F7 are the evidence, and F7 is the thinnest. EXP because it tests what was actually yours |
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Pick the one you would rather lead with and say it plainly: "I've never worked in a contact centre" or "I've never presented to anyone above regional level." Then one sentence of plan, said as a plan. Do not soften it into a strength | F2 and F8 are the stated gaps; a screen is where they are first named, so say them first. JD because it scores the listed requirements |

**Reverse questions — round 1**

| Question | Why it lands |
|---|---|
| "What does the Head of Member Services most want solved in this role's first months?" | Its answer tells you what to lead with in round 2 |
| "Will the case in the panel round be given in advance or on the day, and what should I bring?" | Decides how you prepare J1 |
| "Do you know who will be on the panel?" | Names unlock persona weights and an interviewer read for round 3 |
| "Who would I work with day to day across the branches and the contact centre?" | Shows you are thinking about the two-site structure the JD describes |
| "What happens after the panel round, and when would you expect to decide?" | Sets the timeline so you can plan around notice |

## Round 2 — Head of Member Services (45 minutes, your future manager)

**Persona weights**

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Probes the two stated gaps and the thin rows | high | A hiring manager is buying capability and weighing gaps; F2, F5 and F8 are open | Rehearse the single most predictable objection until it is boring; plain acknowledgment, then a plan |
| Values / Behavioral | "Tell me about a time…" stories | high | The recruiter says this round is mostly behavioural | One story per prompt, "we" for context and "I" for contribution; where no story comes to mind, say so |
| Data-Driven Prober | Walks the spreadsheet and the reporting line by line | medium | The role reports monthly on volumes and resolution times and the JD asks for Excel | Know what the spreadsheet counted; say plainly where you do not |
| Case / Strategist | Live problem on the role's own roadmap | medium | Hiring-manager prior, tempered by "mostly behavioural" | Clarify, objective, segmentation, approach, metrics, risks; think aloud |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4, with only the beats the quote states: new tellers, the escalation script, you trained them. Tell it at that scope. Answer slot: the JD asks about coaching supervisors and the quote says tellers. If one of the tellers you trained brought you a difficult escalation, say what it was and what you did; if you taught the script without such a case, say so plainly and stay with the training | F4 is where coaching is closest to the evidence. JD because the coaching duty is the JD's; EXP in delivery |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not soften it, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for a manager's round. VAL because it scores whether the hard truth actually landed; no quote carries a story here, so it is a scaffold |
| C3 | "Tell me about a complaint you stayed with until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1, at the quote's scope: you handled the branch's formal complaints log. Answer slot: if one complaint stayed with you from the day it was raised to its resolution, tell it: what it was, what you did, and where your part ended; if the log was the extent of your part, or someone else resolved it, say so plainly and describe how you handled the log | Pre-rehearses "Own the Fix" for round 3 and tests F1's limit. The theme comes from the published value; VAL because it scores behaviour against it |
| D1 | "Why move from a branch role to one that spans branches and the contact centre?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Logistics slot for your reason: give your own, in your own words, kept short. The quote carries only the years and the supervisor role | Motivation consistency is what a manager scores; asked in a skeptical register. EXP because it tests the story of the move |
| D2 | "You've never worked in a contact centre, and this role owns the complaints process there as well. Why should I trust you with it?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI prep in the pack.** Hold-then-concede. First answer: "I've never worked in a contact centre." Then hold only what your quote carries: "I handled the branch's formal complaints log." Follow-up 1, "Why would branch experience carry over?": return to the log and the tellers' script and stop; do not add to them. Follow-up 2, "What would you do in your first 30 days?": a plan, said as a plan: "I haven't worked in a contact centre, so in my first weeks I'd want to learn how a complaint reaches it and how it leaves it before I changed anything." Never fold on the log, and never claim contact-centre knowledge. The limit, named before it is asked for: your material shows branch work only | The objection is aimed at F2, the widest gap against the JD's headline duty. JD because it scores a stated requirement; Skeptic delivery |
| D3 | "The role reports monthly to senior leaders, and you've not presented above regional level. How will you manage that?" | JD | [grounded] "I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Hold-then-concede. Concede in your own words: "I've never presented to anyone above regional level." Hold what the second quote carries: you built the monthly spreadsheet your regional manager uses. Plan, said as a plan: how you would prepare. Answer slot: if you have walked anyone through the spreadsheet's figures, say who and what; if it went out without you presenting it, say so plainly | The second stated gap, F8, and the one the manager has most reason to press on, since the role reports to senior leaders. JD for the requirement; the pressure register is the Skeptic's |
| D4 | "The role works with digital teams on self-service journeys. What have you worked on with digital teams?" | JD | [grounded] | Answer slot: the question comes from the JD and your material says nothing here. If you have worked with a digital or product team, say who and on what; if you have not, say so plainly and say what you would ask them first | F5; the strategy's 40% digital target makes this a live line. JD because it is a listed duty |
| E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Quote first: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD names volumes and resolution times. If it counted either, say how each was counted, what it is sensitive to, and which assumption behind it you would defend least; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with what it showed | F3 is premised on your own sentence. EXP because it tests precise attribution; the pack supplies no method or figure |
| E2 | "How comfortable are you in Excel?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you built the spreadsheet in Excel, say what you did in it, in your own words; if it was another tool, say which and what you have done in Excel if anything; if none of it was yours, say so plainly | F9. The JD names Excel and your quote names a spreadsheet; the link between them is the pack's inference, so the label is inferred |
| E3 | "The role handles regulated complaints. What do you know about what makes a complaint regulated?" | JD | [generic] | Say what you actually know, in your own words, and no more. If you applied particular rules at your branch, say which; if you did not, say so plainly. Do not recite rules you could not defend on a second question | F7. A knowledge probe on the JD's requirement; it presupposes nothing about your past |
| G1 | "Ashgrove wants 40% of member service on digital channels by 2028. How would you work with the digital teams so complaints are not lost in self-service journeys?" | CASE | [grounded] | Clarify first: what counts toward the 40%, and which complaint types start in self-service. Then objective, segmentation by channel and type, approach, metrics, risks. Challenge one premise respectfully, such as whether every complaint type should move. Makes no claim about your past | The strategy brief's headline target and the JD's digital-teams line. CASE because it is a live problem on the role's roadmap |
| G2 | "In your first 90 days, how would you get one picture of complaints across branches and the contact centre?" | CASE | [generic] | Think aloud: what you need to know first (what counts as a complaint, how resolution time starts and stops in each channel), the objective, segmenting by channel, type and severity, the approach, the metrics the JD names (volumes and resolution times), and the risks. Makes no claim about your past | The JD's duty, asked as a plan. CASE; a plan for a new product launching in Q1 2027 is a good place to test your structure |

**Reverse questions — round 2**

| Question | Why it lands |
|---|---|
| "What would you want to see from this role in its first three months?" | Turns D2 and G2 into the manager's own agenda |
| "Where do complaint figures come from today, and who reads them each month?" | Tells you how far F3 and F9 are from what the role needs |
| "What does a well-handled escalation look like to you, from a supervisor?" | Lets you tune C1 to what the manager values |
| "Which of the four values do staff find hardest to live day to day?" | Tunes the stories you pick for round 3 |
| "Who in the contact centre should I learn from first?" | Turns your D2 concession into a plan |
| "What is the biggest risk to the complaints process as digital grows toward the 40% target?" | Ties the strategy brief to your first 90 days |

## Round 3 — panel of two branch managers (60 minutes, 20 minutes of it a case, scored against the four values)

**Persona weights**

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | One scenario or "tell me about" per value, scored | high | The recruiter says the panel is also the values round and scores against the four values | Map a story to each value where one of your sentences carries it; use a scaffold with its honest branch where none does |
| Case / Strategist | The 20-minute complaint-escalation case | high | The recruiter names the case | Clarify, structure, think aloud, name the members' side first |
| Peer Evaluator | Seam between the lead and branches; credit and blame | medium | Branch managers work next to the supervisors the role would coach | Reciprocity: what you bring their branch, then seam principles rather than pretending to know the seam |
| Pressure / Skeptic | Time-boxed "why you" and a gap check | low | The gaps are real but the round's weight is values and the case | Hold-then-concede; no new claims |
| Conversational | Opening and closing chat | low | A panel opens warmly, but there is little time | Keep the opener short |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [generic] | Selection scaffold, for "Members First, Always": pick a decision where the member's interest and what was easiest for the branch pulled apart. It needs a named stake, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | The published value, turned into a prompt. VAL; none of your four sentences carries a decision of this kind, so it is a scaffold |
| H2 | "Tell me about a time something had to be explained twice, and what you did about the words." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | For "Plain Words": the quote carries a script and the training, and does not show the script's wording or whether anything had to be explained twice. Answer slot: if the script's wording was ever changed because it did not land, say what changed and who decided; if the script was fixed as given, or the wording was not yours to change, say so plainly and stay with the training | F4's evidence is the nearest to "words". VAL because it scores the value; the slot keeps the story inside the quote |
| H3 | "Tell me about a time you saw what a branch meant to its town." | VAL | [generic] | Selection scaffold, for "Neighbours, Not Numbers": pick a moment where something in a branch told you more than a figure did. It needs a specific place, what you noticed, and what you did with it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would find out | The value sits against F3, the numbers evidence, and against the hub plan. VAL; generic, since your material carries no such moment |
| H4 | "A member's complaint has gone from the branch to the contact centre and back. Whose is it now?" | VAL | [generic] | For "Own the Fix": whoever finds the problem keeps hold of it until it is solved, so say whose it is and how you would make sure it does not bounce again. This is a live problem and makes no claim about your past. If you have a real story, C3 is its place | Tests the value in the form branch managers will recognise. VAL in type, CASE in delivery |
| J1 | "Here is a complaint that has escalated. Walk us through what you would do." | CASE | [generic] | Practice shape for the 20-minute case: ask what you need to know first (who is the member, what happened, what has been promised, how long it has been open); set the objective from the member's side; segment the problem (this complaint, others like it, the process that let it slip); choose the approach for the first hour, week and month; name the measure; name the risks, including a member moving to an app-only bank. Think aloud and say which value you are using. The real case will differ; practise the shape | The recruiter's case, practised on a stand-in. CASE; the stand-in is a practice shape, not a claim about what the panel will give you |
| J2 | "One supervisor escalates everything to you and another never does. How do you coach each?" | CASE | [generic] | Clarify what each pattern costs the member; set one standard for when to escalate; coach each toward it. Make no claim about your past; if you want to refer to training tellers, use only your own sentence: "I trained new tellers on our escalation script." | JD's coaching duty (F4) as a live problem; the pack makes no claim here |
| J3 | "A branch will join a hub next year. Most of its complaints come from long-standing members. What do you do with the complaints process in that town?" | CASE | [grounded] | A practice case, not a fact about Ashgrove. Clarify who is affected and what they are raising, set the objective from the member's side, then segment, approach, measures and risks. Name the tension with "Neighbours, Not Numbers" without choosing a side for the panel. Make no assumption about which branches are affected | Built from the brief's eight-to-five consolidation; the panel are branch managers, so handle with care |
| K1 | "Where is the seam between you and a branch manager when a complaint escalates, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you cannot know: the branch keeps the member relationship; one person keeps hold of the fix until it is solved; disagreements are recorded and reviewed, not buried. Ask what they would want from you | A peer-style probe; JD because it tests the coaching and escalation duty, not your past |
| K2 | "How do you handle credit and blame when a branch's complaint numbers look poor in your monthly report?" | JD | [generic] | Principles: agree definitions with the branch before the report goes out; show the branch its figures first; report the measure and the context together. Makes no claim about your past | Credit and blame are the peer's usual probe; JD because the monthly report is the role's duty |
| L1 | "Sixty seconds: why you rather than someone who already works here?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre" | Hold, then concede. Hold: you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly spreadsheet your regional manager uses. Concede, when pressed: "I've never worked in a contact centre." Do not add to the quotes, and do not claim anything about what someone inside the credit union lacks | The pressure stem. EXP because it tests attribution under pressure |
| L2 | "App-only banks are our main competitive pressure. What does a member get from a complaint handled well here that an app doesn't give them?" | CO | [grounded] | Structure it: what the member needs at the moment of a complaint, what a branch or a person can do that a screen cannot, where self-service is better, and what to measure. Use the published values by name. Makes no claim about your past | Brief's competitive frame. CO because it scores company-level thinking |

**Reverse questions — round 3**

| Question | Why it lands |
|---|---|
| "What could a new person in this role do in their first month that would genuinely help your branch?" | Reciprocity: shows you are thinking of what you bring them |
| "What does a good escalation look like from your side, and what do you wish you had been told sooner?" | Gives you the branch manager's standard for K1 and J2 |
| "How would you want your branch's complaints reported back to you?" | Tests F3 and F9 against what branches would read |
| "How do you see the hub plan changing what members raise with you?" | Ties J3 to a real view, asked openly |
| "What would make you say, a year in, that this role had worked?" | A measure of success you can plan to |

## Values and principles cheat sheet (round 3)

A values-style round is detected: the recruiter says the panel scores against the four values. Names are as published on ashgrovecu.org/about/values.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, H1: no sentence of yours carries a decision of this kind. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide |
| Plain Words | If a member has to be told twice, the wording was at fault | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beats are the script and the training only; the answer slot in H2 covers the wording |
| Neighbours, Not Numbers | Each branch belongs to its town, not a line in a table | Scaffold, H3: none of your sentences carries a story of this kind. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would find out |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beat is the log only; the answer slot in C3 covers whether you kept hold of one complaint to the end |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| F1 own the complaints process end to end, branches | A8, C3, G2, J1, J3, H4 |
| F2 and the contact centre | B1, D2, G2, L1 |
| F3 report monthly on volumes and resolution times | E1, D3, K2, G2 |
| F4 coach branch supervisors on escalations | C1, J2, K1, H2 |
| F5 work with digital teams on self-service journeys | D4, G1, L2 |
| F6 4+ years in financial-services customer operations | A1, D1 |
| F7 regulated complaints | A8, E3 |
| F8 presenting to senior leaders | D3, B1 |
| F9 Excel reporting | E1, E2 |

## Prohibited claims

Not coached anywhere in this pack. No dossier was present, so the list is built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: you handled the branch's formal complaints log. The limit is the pack's observation: your material says the log, not the process |
| Coached or trained supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script. The material says tellers, not supervisors |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: you built the monthly spreadsheet your regional manager uses. The material does not show what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: the formal complaints log. The material says formal, not regulated |
| Built the spreadsheet in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. The material does not name the tool |

## Sources

**Provided documents:** the job description you pasted; the four values copied on 25 November 2026 from ashgrovecu.org/about/values; the recruiter's email describing the three rounds (the loop source); your account of the July 2026 strategy brief the recruiter sent (the brief itself was not supplied); your background summary. No `tuesday-dossier.md` was present. Pasted text is the source of every quoted line; nothing is quoted from anywhere else.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you pasted, in full, fix the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email names the three rounds, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your four points from the July 2026 brief supply the CO and CASE questions; the brief is under six months old |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been named, so there is no query to form; no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → its sentences would replace the four I quoted, and F1, F3, F4, F6 and F7 would gain evidence; an anonymised extract of the monthly complaints spreadsheet, with member details removed, is the artifact that would raise F3 and F9 from where they sit
- Your answers to the answer slots, said outside a drill → F1, F3, F4, F5, F7 and F9 regenerate with your own words in them
- Interviewers' names or LinkedIn-style public profiles, once assigned → an interviewer read, sharper persona weights per round, and a reverse question tied to their own path
- The case format or any briefing for the panel's 20-minute case → J1 and J3 rebuilt on the real format
- The full strategy brief → the grounding brief and the CO and CASE questions rest on your four points today
- Hours available before 4 December → a prep triage in priority order
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, offered once) → recent news on Ashgrove and its competitors for the CO bank
- A `tuesday-dossier.md` from an earlier run → verified evidence and any prohibited claims it holds would sharpen the fit snapshot
