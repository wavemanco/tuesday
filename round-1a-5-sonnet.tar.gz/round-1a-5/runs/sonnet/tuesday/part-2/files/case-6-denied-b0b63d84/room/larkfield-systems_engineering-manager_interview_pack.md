# Interview prep pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Loop mode, three scheduled rounds: Tuesday hiring manager (Director of Engineering, 45 min), Thursday panel (two staff engineers and a product manager, 60 min), the following Monday VP Engineering (30 min, described by the recruiter as "values and leadership philosophy"). Built from your message alone: no full JD, no CV, no interviewer names, and no web research (the searches were refused, see Sources).

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.
- Types: JD (the stated role requirements), EXP (whether your own claims survive scrutiny), CASE (a live problem), VAL (values and behavior), CO (company knowledge).
- Provenance labels: `[grounded]` rests on your own sentences, quoted in the row; `[inferred]` is a derivation, named; `[generic]` is a role-family pattern with no claim about you or Larkfield.
- An answer slot is an instruction for the interview, not a question for you. Fill it from your own experience, or take the second branch and say plainly that the practice was not yours or did not exist.
- Question IDs: T = Tuesday, P = Thursday panel, V = Monday VP; the letter is the persona within that round.

## Prep triage

Three rounds, two weeks. Do these in order; everything else is insurance.

1. Before Tuesday: T-A1 (named below as the highest-ROI prep), then T-A2, T-A3, T-C1, T-C2.
2. Before Thursday: P-B1, P-B2, P-B3, P-E1, then P-A1 and P-A3.
3. Before Monday: V-C1, V-A3, V-A1, then V-B1.
4. Drill T-A1 once out loud before Tuesday. It will be asked in some form in all three rounds.

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six at a payments company. It does not show two squads or device-management work, and the words stay at that scope: "I've been a team lead of six for three years." Answer slot: expect a probe on the step from one team to two squads. If any of your work touched fleet-style or device-management services, say what, in your own words; if none did, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Pushing a reliability quarter through is adjacent to owning delivery, not the same thing, and the words stay with the quote: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you were accountable for a roadmap's delivery beyond that quarter, say for what and how you tracked it; if you were not, say so plainly and stay with the quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe, above all on "about 40 interviews". Lead with the loop in the quote's own terms: "I run our hiring loop for backend roles." The figure raises the defend-the-number slots (P-B2) |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description in your message | none given | none | [grounded] | discovery | Your material does not show growing engineers, and you have stated no absence (your stated limit is about managing managers, which is a different thing). Answer slot: if, as a team lead, you developed engineers, say what you did, in your own words; if you did not, or it was not yours, say so plainly |
| F5 | "partner with hardware and product on roadmap" (the hardware part) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work |
| F6 | "partner with hardware and product on roadmap" (the product part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote names roadmap pressure and does not say it came from product or what you did with product. Inferred only as a lead. Answer slot: if product partners were on the other side of that pressure, say how you handled it; if the pressure came from elsewhere, or there was no product partner involved, say so plainly |

Gate check: the role description states no authorization, location, pay or schedule term, so there are no gate rows. Your message also does not establish any of those; if the JD names one, add it and the row will be surfaced.

### Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| Lead two squads building device-management services | T-A2, T-B3, V-B1 | JD-tagged: T-A2 |
| Own delivery | P-B1, T-B2, P-D2 | JD-tagged: P-B1 |
| Own hiring | P-B3, P-B2 | JD-tagged: P-B3 |
| Own growth | V-A3, T-A3 | JD-tagged: V-A3 |
| Partner with hardware on roadmap | T-A1, T-B1, T-B3, P-D1 | JD-tagged: T-A1 |
| Partner with product on roadmap | P-C1, T-B2, P-D2 | JD-tagged: P-C1 |

## Round 1: Tuesday, Director of Engineering (hiring manager, your would-be boss), 45 min

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the scope jump and the hardware gap | High. Hiring-manager prior is Case plus Skeptic, and you have stated two limits that map straight onto the role (F5, and F1's step to two squads), so this persona leads | Rehearse the one predictable objection until it is boring; say the limit first, then the plan |
| B. Case/Strategist | Live problems on the role's own territory: fleets, rollouts, two squads | High. The same hiring-manager prior; they are buying capability on their own roadmap | Clarify, structure, answer; think aloud; challenge one premise |
| C. Data-Driven Prober | Reads your lines for the numbers | Medium. You gave two figures (60%, about 40), and a Director who reads closely will test them | Know how each was counted; name the weakest assumption first |
| D. Conversational | The opener | Low-medium. It is the first five minutes and still scored | A short arc built only from your own words |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "This role partners with hardware on the roadmap. What in your background prepares you for that, and what doesn't?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI prep in this loop: this question will arrive in some form in every round. Say the limit first, in your own stated words: "I haven't owned a hardware-adjacent roadmap." Then a plan, stated as a plan in the future tense: whom you would sit with first and what you would ask about their release constraints. Never describe hardware work as a past. Answer slot: if any work of yours depended on a hardware team, say what, in your own words; if none did, say so plainly and stay with the plan. Hold through two follow-ups by returning to the limit and the plan, never by adding experience | F5 is a stated limit that maps onto a named requirement, so the objection is certain; JD because it scores that requirement directly |
| T-A2 | "You'd go from leading a team to two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the quote's scope: "I've been a team lead of six for three years." Answer slot: the JD's two squads and eleven engineers make a probe on what changes likely. If you know what you would do differently, say it in your own words; if you have not worked it out, say so plainly and say what you would find out in your first month. Do not describe running more than six people | F1 is the scope gap; JD because it tests the role's stated size |
| T-A3 | "As team lead, did you have people-management responsibility for the engineers, or was it mainly technical?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Keep to the quote: "3 as a team lead of 6." Answer slot: the role owns growth for eleven engineers, so expect a probe on this. If your team-lead role included reviews, development conversations or similar, say what, in your own words; if it did not, say so plainly and say where the people side was handled | F4 has no evidence either way; EXP because it tests what the title actually covered |
| T-A4 | "Why this move, and why now?" | EXP | [generic] | The reason is yours and the pack has none from your message, so it is an instruction: give your actual reason in two sentences, in your own words. If the honest answer is the step into managing, say that. Do not claim a pull toward industrial IoT you cannot explain | The motivation-consistency check every Skeptic runs; EXP because it is about your own story |
| T-B1 | "A device-management service you own is rolling out a firmware update, and it fails on part of the fleet. How do you diagnose it, and what do you tell hardware and product?" | CASE | [generic] | Structure aloud: clarify first (which devices, which versions, since when, is the rollout still running); stop the spread (pause or roll back); segment the failures (by device cohort, connectivity, version); decide who needs to know and when (hardware, product, support); say what you would measure and how you would prevent it. Say where you would defer to your engineers on the technical diagnosis. The question needs no claim about your past, so the guidance makes none | Role-family problem from F5's territory; CASE because it scores structure and reasoning |
| T-B2 | "You take over a squad with a noisy on-call and a committed roadmap. What do you do in the first thirty days?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: listen, read the on-call load, learn the commitments, find what is cheapest to relieve first, agree it with the product side. If you use your own reference, keep its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on what the pressure was and what you did about it. Say that in your own words; if there was no explicit conflict, say so plainly | F2 and F6 are where your material touches delivery; CASE because it is a live problem with a personal reference attached |
| T-B3 | "Your two squads both depend on one hardware release window that you do not control. How do you plan the quarter?" | CASE | [generic] | Clarify what is fixed and what is flexible; separate the work that depends on the window from the work that does not; sequence; name the decision owner; agree what you would drop if the date moves; tell product early. Challenge one premise respectfully, for example whether the window is really fixed. Makes no claim about your past | Tests F1 and F5 together with no claim on your history; CASE |
| T-C1 | "Your on-call burden fell 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number slots, each in your own words: what the 60% measured and over what period; what it is sensitive to; the assumption behind it you would defend least; which part was yours. The quote says "after", so claim no more than the sequence. If you do not know how it was counted, say so plainly. Name your weakest assumption before they do | The headline metric, so a defend-the-number question is certain; F2 is its evidence |
| T-C2 | "Walk me through the reliability quarter." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the beats the quote states: a reliability quarter, you pushed it through, against roadmap pressure. Answer slot: the follow-ups will be who the pressure came from, what you said, and what the quarter contained. If you can say, do so in your own words; if there was no one pushing back, or the contents were not yours to choose, say so plainly. Hold your position through two follow-ups | F2's quote is the strongest story in your material, so it gets the deepest follow-up rehearsal after T-A1 |
| T-D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc whose facts are the quote's: nine years in engineering, three as a team lead of six, currently at a payments company. The turn toward this role is yours to say; give it in your own words and keep it to what you can explain | F1; EXP because it is the CV walk-through |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "After six months, what would tell you these two squads were in a better place, and what would tell you I had it wrong?" | A direct request for the scoring sheet, from a would-be boss, so it shows you plan to be measured |
| T-R2 | "How do hardware release cycles constrain the device-management roadmap today, and where do they bite hardest?" | It owns your stated gap by going to learn it, which is the plan T-A1 asks you to state |
| T-R3 | "What would you want a new EM to learn about the hardware side in the first sixty days?" | It turns the objection into a ramp plan the Director gets to shape |
| T-R4 | "How do you expect an EM here to split time between delivery, hiring and growing the engineers?" | Tests the role's real shape against the job description, and shows you take all three seriously |
| T-R5 | "How is reliability work weighed against roadmap commitments here?" | It connects to your strongest story without making a claim about it |

## Round 2: Thursday, panel (two staff engineers and a product manager), 60 min

### Persona table

Names are not known, so personas are assigned by role. The panel rule blends the top two personas of each member's relationship.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seams, credit, disagreement, what a new EM costs them | High. Staff engineers are the people whose work you would depend on, and the PM is a roadmap partner named in the role | Reciprocity framing; seam principles rather than a pretended knowledge of the seam |
| B. Data-Driven Prober | Reads your claims and presses on counting, decisions and scope | High. Staff engineers read evidence closely and your two figures are both on the table | Know how each figure was counted; return to what the quote says |
| C. Values/Behavioral | Scenario probes in a product partner's collaborative register | Medium. A PM is outside engineering and tends to ask behavioral questions about disagreement and tradeoffs | Choose a story only if one of your sentences carries it; otherwise use the scaffold's honest branch |
| D. Case/Strategist | Live problems on fleets and priorities | Medium. Staff engineers test whether the EM can reason about the system | Clarify, structure, defer where it is the engineers' call |
| E. Pressure | Challenges attribution | Low-medium. One challenge on attribution is likely from a prober | Hold, then concede specifically |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-A1 | "A staff engineer and you disagree on the technical direction for a service. Where is the seam, and how does it get resolved?" | CASE | [generic] | Offer principles, not a pretended seam: the EM owns outcomes, priorities and people; the staff engineer owns the technical depth of the call; disagreements get a written trade-off and a named decider. Ask what they would want from you. Do not claim a past in which you resolved a disagreement unless you are using a story your own sentence carries (none in your message does) | Peer prior; CASE because it is hypothetical. Your material says nothing about managing staff-level engineers (F1 observation) |
| P-A2 | "What would you need from us in your first month, and what would you bring?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Reciprocity first: what you would bring that is in your quote, "I run our hiring loop for backend roles", then what you would ask them for, such as where the squads hurt most. Answer slot: if you would bring anything beyond the hiring loop, say what, in your own words; if not, keep to the hiring loop | F3 is your clearest contribution to a peer's load; JD because it tests the hire's fit to the team |
| P-A3 | "How do you handle credit when a fix spans teams?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Use "we" for context and "I" for contribution, and keep the "I" to the quote: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if others did parts of the work, say whose and what; if the work was mostly yours, say so plainly without enlarging it | Staff engineers test credit-sharing; F2 is the only quoted work to attach it to |
| P-B1 | "This role owns delivery for two squads. What delivery responsibility have you held?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Quote the scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you chose what the quarter covered, say how you decided; if you held accountability for a roadmap's delivery, say for what; if either was not yours, or there was no such step, say so plainly and stay with the quarter | F2 is adjacent evidence for the delivery requirement; JD because it scores it |
| P-B2 | "About 40 interviews last year. How was that counted, and how much was you?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Defend-the-number slots, in your own words: how it was counted (interviews you conducted, or loops you ran); what it is sensitive to; the assumption you would defend least; which part was yours. The quote says "I run" the loop, so keep to that. If you do not know how it was counted, say so plainly | Every headline figure gets a defend-the-number question; F3 |
| P-B3 | "This role owns hiring for the squads. What would your backend hiring loop bring to that?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Lead with "I run our hiring loop for backend roles." Answer slot: expect a probe on what the loop contains. If you set its stages or its scoring, say how, in your own words; if the loop's design was set by others and you run it, say so plainly. Do not describe the design of a process the quote does not state | F3 is a no-gap row, but it will be probed on design; JD |
| P-C1 | "Tell me about a time you and a product partner disagreed on priorities. How did it land?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | If the roadmap pressure in your sentence came from a product partner, tell the story with the beats the quote states, in your own words. Answer slot: what the disagreement was and how it ended are yours to say; if it did not involve a product partner, or there was no such disagreement, pick the nearest real case your experience carries, or say plainly that you have none and say how you would handle it | F6 is a lead, not evidence; the open prompt lets you choose an instance and the slot allows the premise to be false |
| P-C2 | "When have you put a long-term concern ahead of an internal deadline?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The reliability quarter is the candidate story only if the "roadmap pressure" was a deadline. If so, tell it as the quote states it. Answer slot: what the deadline was and what you traded are yours to say; if the pressure was not a deadline, pick another real instance, or say plainly that none comes to mind and say how you would weigh it | Persona-stem question for a cross-functional interviewer; VAL |
| P-D1 | "A firmware update from the hardware team must ship in six weeks, and your service's tests are not ready. What do you do?" | CASE | [generic] | Clarify what is fixed, what is flexible and what the risk of shipping unready is; choose between scope cuts, a staged rollout and a date negotiation; say who decides; tell hardware and product early. Defer to the staff engineers on technical risk, and say so | F5 territory; CASE; no claim about your past |
| P-D2 | "Product asks for a feature that would add on-call load to your squads. How do you respond?" | CASE | [generic] | Clarify the value and the date; quantify the load impact with the squads; offer options (reduce scope, add reliability work alongside, delay); agree the trade-off with product in writing. It makes no claim about your past | F2 and F6 territory, tested as a live decision; CASE |
| P-E1 | "That 60% drop. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. Hold: "I pushed a reliability quarter through against roadmap pressure." Concede specifically, once you know: what others did, and what else changed in that period. The quote says "after", not "because", so do not claim the cause. Answer slot: if you can separate your part, say how; if you cannot, say so plainly. Hold through two follow-ups, never by enlarging your part | Attribution challenge on your one headline result; EXP |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| P-R1 | "What is the most useful thing a new EM could do in their first month to help the staff engineers?" | Reciprocity question for the peer interviewers |
| P-R2 | "Where do staff engineers and EMs on these squads disagree most, and how does it usually resolve?" | Shows you expect friction and care about the mechanism |
| P-R3 | "How does hardware's roadmap input reach product today?" | A question for the PM that explores the seam you will sit on |
| P-R4 | "How do you want to hear about reliability risk, and how early?" | A working-agreement question the PM can answer concretely |
| P-R5 | "What is a recent product and engineering decision here that you thought went well?" | Invites a story and shows you look for how they decide |

## Round 3: Monday, VP Engineering (values and leadership philosophy), 30 min

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values/Behavioral | Your leadership philosophy, tested through specific decisions | High. The recruiter's own description is "values and leadership philosophy", which documents a values-style round; the skip-level prior of Case plus Pressure is adjusted toward this | Map a story only where one of your sentences carries it; otherwise a scaffold with the honest branch |
| B. Case/Strategist | Altitude: priorities across squads | Medium-high. Skip-level prior | State assumptions, set criteria, decide |
| C. Pressure | Time-boxed challenges on gaps and composure | Medium-high. Skip-level prior; the two stated limits are obvious targets | Pause, restate, hold the real claim, concede the real limit |
| D. Conversational | A short open question | Low | A genuine answer in your own words |

### Question bank

Larkfield's published values could not be fetched, so VAL questions here take their theme from the recruiter's "values and leadership philosophy" and the persona stems. If you can find the company's values page, send it and the VAL rows can be mapped by name.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-A1 | "What is your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The philosophy is yours and the pack supplies none. State it in two or three sentences in your own words, then support it only with what your quotes say: "I run our hiring loop for backend roles" and "I pushed a reliability quarter through against roadmap pressure". Answer slot: if a story other than these shows it better, use that one; if your philosophy is not yet one you can show from your past, say so plainly and say what you are working on | The recruiter named this round; VAL |
| V-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Your message carries no such story, so the pack supplies none | Persona stem for the values round; the scaffold case, not a story map |
| V-A3 | "How do you think about growing engineers, including those who may one day manage others?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Say the limit and keep it plain: "I haven't managed managers." Then what you can say about growing engineers, in your own words. Answer slot: if you have developed engineers as a team lead, say what you did; if not, say so plainly and say how you would approach it. Do not describe a growth process you have not run | F4 and the stated limit meet here; JD because growth is a stated requirement |
| V-B1 | "You have eleven engineers and three asks, from product, hardware and the platform itself. What do your two squads not do, and how do you decide?" | CASE | [generic] | State the criteria first (customer impact, dependency, risk, reversibility), then the decision, then how you tell the people who lose. Say what you would want to know before deciding. It makes no claim about your past | Altitude question for a skip-level; no research on Larkfield's priorities was possible, so it is generic |
| V-B2 | "What do you know about Larkfield and where we are heading?" | CO | [generic] | The pack holds no verified facts about Larkfield. Say what you have actually read, name its source, and stop where it ends. Do not fill from memory or from a competitor. If you have only the role description, say that and ask the VP where they want the company to be in two years | CO question left generic because research could not run; it becomes `[grounded]` once the upgrade menu items arrive |
| V-C1 | "Sixty seconds: why you, over a candidate who has run a hardware roadmap and managed managers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "I run our hiring loop for backend roles — about 40 interviews last year" and "I've never managed managers and never owned a hardware-adjacent roadmap" | Hold, then concede. Concede first, in your stated words: "I haven't managed managers and I haven't owned a hardware-adjacent roadmap." Then state what you have at its own scope: "3 as a team lead of 6" and "I run our hiring loop for backend roles". Do not say you are a better candidate; the VP draws that conclusion. Hold through two follow-ups by repeating the facts, not by adding to them | The objection built from F1 and F5, the other highest-ROI rehearsal; JD |
| V-C2 | "Where would you disagree with me in your first ninety days?" | VAL | [generic] | Pick an area where you will have formed a view only after listening; name how you would raise it (privately, with evidence, with an alternative). Do not invent a disagreement you cannot yet have. If you would not disagree before you have the facts, say so plainly | Tests spine and tact at skip-level; no claim about your past |
| V-D1 | "What do you want to be known for after a year here?" | VAL | [generic] | A short, honest answer in your own words. Keep it to what you intend to do, not to what you have already done | A casual-register question that is still scored |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| V-R1 | "What is the leadership behavior you most want to see more of in the engineering managers here?" | Directly tests your fit to the thing this round is about |
| V-R2 | "How does Larkfield grow its engineers into managers?" | Your stated limit is managing managers, so this signals ambition without claiming experience |
| V-R3 | "What is one thing a first-year EM here commonly gets wrong?" | Invites candor and shows you plan to avoid it |
| V-R4 | "Where does engineering culture here struggle most?" | Signals you look for what is hard, not only what is good |
| V-R5 | "How do the engineering and hardware leaders decide what to trade when their dates conflict?" | Shows you are thinking about the seam you will sit on |

## Prohibited claims (what this pack will not coach)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative the candidate stated, F5's quote | The plain acknowledgment: "I haven't managed managers." V-A3 and V-C1 use it |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." T-A1 and V-C1 use it |
| Led two squads, or an organisation of eleven | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a team lead of six |
| Owned delivery across a roadmap | Inflated form of F2 | F2's quote at its own scope. The material says a reliability quarter pushed through, not delivery ownership. P-B1's slot stays inside the quarter |
| The reliability quarter caused the 60% drop | Inflated form of F2 | The quote's own order: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The limit is the pack's observation: the material says after, not because. P-E1's slot asks only what part was yours |
| Designed the hiring loop | Inflated form of F3 | "I run our hiring loop for backend roles" at its own scope. The material says run, not designed. P-B3's slot stays inside the running |

## Sources

Provided documents: your message (the role description, the three round descriptions, and your four sentences about your background). No dossier was present.

Searches sent, all refused, none returned results:

- "Larkfield Systems industrial IoT values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT strategy news": refused
- "Engineering Manager device management platform IoT job description": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fed the values cheat sheet and VAL themes; the cheat sheet is dropped because no published values are in hand |
| 2. `{company} interview process {role family}` | unavailable | Would have confirmed the loop; the loop here rests on your own description of the three rounds, which establishes it, so persona weights follow your description |
| 3. `{company} strategy` / recent news | unavailable | Would have moved V-B1 and V-B2 off `[generic]`; no strategy-grounded CO or CASE question exists |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form; there is no interviewer read |
| 5. representative `{role title}` JD | unavailable | Would have turned the role-summary rows into rows against a full requirement list |

Values-style round: detected for Monday, on the recruiter's description in your message; no published values are in hand, so no cheat sheet.

## Upgrade menu

- The full JD text: the six requirement rows quote only the short role description, and a full list would add rows, `[grounded]` JD-tagged questions, and any gate (location, pay, schedule) the JD states
- Your CV: more quoted evidence for F1 to F6, which would replace several answer slots with story-mapped beats and could move F4 and F6 off `discovery`
- Your answers to the answer slots (for example, whether team lead included development conversations, and what the roadmap pressure was): each stated fact becomes quoted evidence and regenerates the rows that draw on it
- The artifacts that would raise confidence on your two figures: the on-call dashboard or page-count history behind the 60%, and your hiring-loop record behind the 40
- Larkfield's published values page: maps the Monday VAL questions to values by name and adds the values cheat sheet
- Interviewer names (or the recruiter's email on who is in each round): an interviewer read, tuned persona weights, and reverse questions tied to their paths
- Search permission, if you want it: the company values, loop, strategy and a representative JD, and a deeper pass of up to 6 further searches and 2 further fetches, several more minutes, for a strategy brief
- A `tuesday-dossier.md` from an earlier session: would add verified evidence and set which claims are prohibited, never required
