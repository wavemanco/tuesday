# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 4 December 2026, built from the recruiter's email.

| Round | Who | Length | Relationship | IDs |
|---|---|---|---|---|
| 1 | The recruiter | 30 min | Recruiter screen | A, B |
| 2 | Head of Member Services | 45 min, mostly behavioural | Your future manager | C to F |
| 3 | Panel of two branch managers | 60 min, including a 20-minute complaint-escalation case; also the values round, scored against the four values | Panel | G to K |

No interviewer names are assigned yet, so there is no interviewer read. Persona weights rest on the round types and the recruiter's own words.

## How to use this

- **Personas are how a question is asked; types are what it scores.** VAL is values and behaviour. EXP is a deep-dive on your own experience. JD is the stated role. CO is company and strategy knowledge. CASE is a live problem.
- **Guidance is scaffolding, not a script.** Every sentence about your past is one of your own, quoted. Where your material is silent, the guidance is an answer slot: say what is true, in your own words, or say plainly that it was not yours or did not exist.
- **The highest-ROI rehearsal is C1**, the contact-centre question. It will come in some form in all three rooms, so keep your wording identical each time.
- All proposed language is pending your approval. Change anything that is not true to you.

## Prep triage (9 days to 4 December)

1. **C1, then B1 and K1.** Say the contact-centre answer aloud until it is boring.
2. **The answer slots in F1, F3, F5, F6 and F7.** Decide your true answers and write them in your own words.
3. **The panel case, H1 to H3.** Practise thinking aloud for a timed 20 minutes.
4. **G1 to G4.** For each value, find one real story, or decide to say plainly that none comes to mind.
5. **A3 to A6.** Know your reason for moving, pay, notice and location in your own words.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the log, kept at your branch, not the process end to end, with nothing inspected behind it. The words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the log likely. If any part of how it was kept was yours to decide, say which and why, in your own words; if it was set for you, or there was no more to it than the log, say so plainly and describe how you handled it |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "Never worked in a contact centre." Then how you would learn it, said as a plan and never as a past |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" is your word and "regulated" is the JD's, and the log does not show whether they mean the same here. Answer slot: the JD's regulated-complaints line makes a probe on the rules the log was kept under likely. If a regulator's rules or deadlines governed it, say which and how you worked to them, in your own words; if none did, or you do not know, say so plainly and stay with the log you handled |
| F4 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap in years, but a statement with nothing inspected behind it, so expect it checked against dates. Lead with your own terms (six years in retail banking, the last three as a branch supervisor) rather than relabelling it as customer operations |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote reaches monthly complaints reporting and does not show what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it counted either, say what and how, in your own words; if it counted neither, say so plainly and stay with the spreadsheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your word is "spreadsheet" and the JD's is "Excel", and the quote does not say which tool. Answer slot: if it was Excel, say so and what you did in it; if it was another tool, say so plainly and stay with the spreadsheet you built |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and a script, not supervisors. The words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's supervisor line makes a probe on how that training would carry over likely. If anything in how you trained the tellers was yours to decide, say what and why, in your own words; if the script and the method were set for you, or there was no more to it, say so plainly and describe the training you gave |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material shows nothing either way. Answer slot: if you have worked with a digital or product team on anything members use themselves, say what it was and your part, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Your material does not say what you have presented at regional level, so nothing is claimed about it |

*Bridge language above: pending your approval.*

## Grounding brief

You have four lines from the July 2026 strategy brief, not the brief itself. That is the whole of what the pack rests on.

| Fact from your message | Provenance | Where it surfaces |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] | F8, A2, F1 |
| "consolidate eight branches into five hubs over 2027" | [grounded] | H3, G3, round 3 reverse questions |
| "launch a small-business lending product in Q1 2027" | [grounded] | No bank question rests on it; use it only as an optional third fact in A2 |
| "the main competitive pressure is app-only banks" | [grounded] | A2, F1 |

The brief is public, so other candidates can recite it. In A2, F1 and H3, bring one headline item to show you have read it, then one position of your own with a concession.

---

# Round 1: recruiter screen (30 minutes)

| Persona | How it shows up | Likelihood and reasoning |
|---|---|---|
| Conversational (A) | Friendly biography and motivation questions, plus the four logistics questions | High. A recruiter screen is a logistics-and-motivation round in a friendly register, and the risk is treating it as unscored. 6 questions |
| Skeptic, light (B) | Knock-out checks on the stated gaps | Medium. F2 and F8 are the gaps a JD check hits first. 2 questions |

## A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc using only what those sentences state: six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log you handled, the monthly complaints spreadsheet you built that your regional manager uses. Then say in your own words why this role; the pack does not write your motive | F4, F1 and F5 are the evidence the arc draws on. EXP because it tests whether your story holds together |
| A2 | "What do you know about Ashgrove, and why us?" | CO | [grounded] | Use two facts from what you were given, in your own words. Bring one headline item (for example the move of 40% of member service to digital channels by 2028, or the value "Plain Words"), then say why it matters for a complaints role. The link is yours to make and the pack does not write it. Do not recite all four strategy lines | CO because it scores homework at screen level. Grounded in the pasted values and the brief's four lines |
| A3 | "What's prompting you to look at a move?" | EXP | [generic] | Logistics slot: give your own reason, in your own words, in one or two sentences. The pack has none from you and supplies none | EXP because it checks motivation consistency; the reason for leaving is a standard recruiter-screen slot |
| A4 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | JD because it concerns the job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period as your contract states it | JD because it concerns the job's terms |
| A6 | "Where could you work from, and how often?" | JD | [generic] | Logistics slot: say where you can work and how often, as it really is. The role spans branches and a contact centre, so ask which sites it would involve | JD because it concerns the job's terms |

## B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. You haven't worked in one — how do you see that?" | JD | [grounded] "Never worked in a contact centre" | The short screening version of C1. Words: "Never worked in a contact centre." Then one sentence of plan, in your own words, and stop. Save the full rehearsal for C1 | F2 is where a JD check lands first. JD because it scores a stated requirement |
| B2 | "The role works with digital teams on self-service. What's your experience there?" | JD | [grounded] | Answer slot (F8): if you have worked with a digital or product team on anything members use themselves, say what it was and your part; if you have not, say so plainly and say what you would ask a digital team first | F8 is the one requirement with no evidence either way, and it ties to the brief's digital move |

*Guidance above: pending your approval.*

## Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is there anything to prepare for the 20-minute complaint-escalation case, such as its format or what it assesses?" | The case is the least knowable part of round 3, and the recruiter is the one person who can say |
| R1.2 | "Is this a new role, or does it replace someone?" | Shows you want to understand the mandate before taking it on |
| R1.3 | "Which parts of the role matter most in the first six months?" | Lets you aim your round 2 answers at what the manager will care about |
| R1.4 | "How do the panel's scores on the four values sit against the case in the final decision?" | Shows you know the panel is a scored values round and want to prepare for it properly |
| R1.5 | "What happens after 4 December, and when should I expect to hear?" | Practical, and closes the call cleanly |

*Questions above: pending your approval.*

---

# Round 2: Head of Member Services (45 minutes)

| Persona | How it shows up | Likelihood and reasoning |
|---|---|---|
| Skeptic (C) | Probing the stated gaps | High. The hiring-manager prior is Case plus Skeptic: they are buying capability and de-risking gaps, and you have stated three (F2, F9) and a thin one (F7). 4 questions |
| Values/Behavioral (D) | Behavioural scenarios | Medium-high. The recruiter's words are "mostly behavioural", which lifts this above the Case prior. 3 questions |
| Data-Driven Prober (E) | CV lines read closely | Medium. A manager reading closely will go to the spreadsheet and the log. 2 questions |
| Case/Strategist (F) | One live strategy question | Low. The recruiter put the case in round 3, so only one here. 1 question |

## C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked in a contact centre, and this role owns complaints across branches and the contact centre. How would you do that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **Highest-ROI prep in the pack.** The limit, named first: your material says a branch log, not the process end to end and not the contact centre. Open with the acknowledgment, "Never worked in a contact centre.", then what you did carry, "I handled the branch's formal complaints log." Then a plan, not a claim: what you would learn first about how the contact centre receives and hands on complaints, and from whom. **Follow-up 1** ("how do you own something you haven't done?"): hold; ownership starts with learning what they do. **Follow-up 2** ("what if the contact-centre team pushes back?"): concede specifically that they know things you do not yet, and say what you would ask them before changing anything. **Follow-up 3** ("so what would you do in week one?"): name two concrete steps you would actually take. Answer slot: if any part of how the branch log was kept was yours to decide, say which and why; if it was set for you, say so plainly and describe how you handled it | F2 is the biggest stated gap and F1 stops short of end to end, so this question arrives in some form in every round. JD because it scores the headline requirement |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one of the two gaps you stated, not a throwaway weakness, and say it in your own words: "Never worked in a contact centre." or "I've never presented to anyone above regional level." Then one concrete first-month step | F2 and F9 are the two gaps you stated. JD because it scores the requirement list |
| C3 | "You'd present monthly reporting to senior leaders. What experience do you have of presenting at that level?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment: "I've never presented to anyone above regional level." Then your preparation as a plan, such as agreeing with this manager what they want to see first. Answer slot: if you have presented the spreadsheet's figures to anyone, say to whom and what you did, in your own words; if you only handed it over, or someone else presented it, say so plainly and describe what you did with it | F9 is the stated gap and F5 is the nearest material. This interview is itself with a senior leader, so expect it |
| C4 | "Your escalation experience is with new tellers. The role coaches branch supervisors. What changes?" | JD | [grounded] "trained new tellers on our escalation script"; "6 years in retail banking, the last 3 as a branch supervisor" | Say what you did: "I trained new tellers on our escalation script." You were a branch supervisor for three years, so you know the seat. Then say how you would approach supervisors differently, as a plan: start by asking how they handle escalations today rather than teaching them a script. Answer slot: if anything in how you trained the tellers was yours to decide, say what and why; if the script and method were set for you, say so plainly and describe the training you gave | F7 is adjacent evidence with a limit, and the interviewer will find the tellers-versus-supervisors seam |

## D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior something they did not want to hear. It needs a named stake, what you said and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | VAL from the Values/Behavioral stem. Relevant because the role reports to senior leaders (F9) |
| D2 | "Tell me about a time you coached a colleague through a difficult escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold. Nearest material, in your own words: "trained new tellers on our escalation script." Pick a real case where you went beyond the script with one person, with a named situation and an outcome. If none comes to mind, say so plainly and stay with the training you gave, or say how you would coach | JD's coaching line raises it. F7 is the nearest evidence and does not carry a coaching story |
| D3 | "Tell me about a time you worked with a team outside your own branch to sort out a member's problem." | VAL | [grounded] | Selection scaffold. Pick a real instance with the team, what you needed from them and how it ended for the member. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would go about it | The JD's "across branches and the contact centre" raises it. F1 and F8 are the rows it tests |

## E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built — what did it report?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it was and who used it: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect probes on what yours counted and which tool it was in. If it counted either, say what and how, in your own words, and the assumption you would defend least. If it counted neither, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built | F5 and F6 rest on this one sentence, so it gets the defend-the-figure rehearsal |
| E2 | "Walk me through how the branch's formal complaints log worked." | EXP | [grounded] "I handled the branch's formal complaints log" | Describe the log in your own words. Answer slot: the JD says regulated complaints, so expect a probe on the rules. If a regulator's rules or deadlines governed it, say which and how you worked to them; if none did, or you do not know, say so plainly and stay with the log you handled | F3 is a discovery row; this is where the answer comes out |

## F: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Ashgrove plans to move 40% of member service to digital channels by 2028. Which complaints would you keep out of self-service, and why?" | CO | [grounded] | The question needs no claim about your past, so the guidance makes none. Clarify first (what counts as service today, what complaint types exist, what rules apply). Then objective, segments, approach, metrics, risks. Bring the headline fact to show you have read the brief, then one thesis of your own. Thesis option, pending your approval: the complaints that stay in branches and the contact centre may become the harder ones, so escalation coaching matters more as volume shifts. Concede that you cannot size the shift from the outside. Name the anti-pick: what you would not move into self-service first | The brief's digital target is the one strategy item that touches the JD (F8). CO because it scores company-altitude thinking |

*Guidance above for C to F: pending your approval.*

## Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would you most want changed in the member complaints process by the end of my first six months?" | Draws out their priority and ties to Own the Fix |
| R2.2 | "How do complaints move between branches and the contact centre today, and where do they get stuck?" | Shows you start by learning the seam, and answers a question your F2 plan depends on |
| R2.3 | "How will the move to more digital service change what reaches the complaints process, and who in digital would I work with first?" | Ties to F8 and the brief's 2028 target |
| R2.4 | "What would you want in front of you each month from complaint reporting?" | Reporting is the monthly deliverable, and learning the format first helps F9 |
| R2.5 | "What would make you say, a year in, that this hire had worked?" | Surfaces the success measure, and lets you test your first-quarter plan against it |

*Questions above: pending your approval.*

---

# Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

| Persona | How it shows up | Likelihood and reasoning |
|---|---|---|
| Values/Behavioral (G) | Scored scenarios against the four published values | High. The recruiter's words are that the panel "is also the values round" and scores against the four values, and the panel is outside the function you would lead. 4 questions |
| Case/Strategist (H) | The 20-minute complaint-escalation case, plus a strategy question | High. A scheduled case is in the recruiter's words. 3 questions |
| Peer Evaluator (I) | Seam and collaboration questions | Medium. Branch managers sit beside every escalation this role coaches, so expect "what would you need from me". This is the pack's reading, not a sourced fact. 2 questions |
| Skeptic (J) | Cross-examination of the one-branch background | Medium. The stated gaps recur. 2 questions |
| Pressure (K) | Time-boxed challenge | Low. A scored panel may test composure. 1 question |

## G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Value: Members First, Always. Selection scaffold. The log you handled is a place to look, but only if a specific entry comes to mind. It needs the decision, what pulled the other way and what the member got. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | VAL because it scores the first published value. F1 is the nearest material and carries no story |
| G2 | "Tell me about a time something you explained or wrote had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Value: Plain Words. Selection scaffold. The tellers' script is where to look, only if a real case comes to mind. It needs what was unclear, what you changed and whether it held. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it | VAL for the second value. F7 is the nearest material |
| G3 | "Tell me about a time you weighed a number against what a branch or its town needed." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Value: Neighbours, Not Numbers. Selection scaffold. It needs the number, what the branch or town needed, and what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would weigh it. A panel of branch managers will have a view on the hub plans, so stay with a real example | VAL for the third value. F4 is the nearest material |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Value: Own the Fix. Selection scaffold. It needs the problem as it first reached you, what you personally did to keep hold of it and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would do it | VAL for the fourth value. F1 is the nearest material |

## H: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member's complaint has bounced between a branch and the contact centre, and they are about to leave. You're the Member Experience Lead. What do you do?" | CASE | [generic] | A pattern for the recruiter's "complaint escalation" case, making no claim about your past. Think aloud. Clarify (what the member has been told and by whom, what rules and deadlines apply here, what the member wants). Objective: solved, in plain words. First action: name one person who holds the complaint until it is resolved. Then why it bounced, how you would measure it (resolution time, repeat contact) and the risk of blame between branch and contact centre. Challenge one premise politely: is the problem the complaint or the way it was handled? | The recruiter named this case; its content is unknown, so the pattern is generic. CASE because it scores structure |
| H2 | "Complaints at one branch have risen sharply this month. Diagnose it." | CASE | [generic] | Clarify: volume or rate, complaint types, new or repeat, resolution times, anything that changed last month. Segment, form two or three hypotheses, say what data you would pull and what you would take back to that branch's supervisor. Volumes and resolution times are what the JD says the role reports monthly | The Case/Strategist's metric-diagnosis stem, using the JD's own metrics |
| H3 | "Eight branches become five hubs over 2027. What happens to complaint escalation, and what should we do first?" | CO | [grounded] | The question needs no claim about your past. Clarify what a hub covers. Bring the headline fact, then one thesis of your own with a concession. Thesis option, pending your approval: escalation paths are most at risk while branches merge, so one named owner per complaint matters most then. Concede you cannot see the hub plans from outside. Anti-pick: what you would not change during the move. This panel runs branches, so ask what they are seeing | The strategy brief's second line, and the panel is the audience closest to it |

## I: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Where's the seam between your role and a branch manager's when a complaint escalates, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who the member hears from, who decides the remedy, who learns from it. Offer what you bring the branches, such as the monthly picture of what members complain about. On disagreement, hold your view and ask what they see | The Peer Evaluator's stem, tied to the JD's "across branches" scope |
| I2 | "A supervisor in one of our branches doesn't agree with how you want escalations handled. What do you do?" | JD | [grounded] "trained new tellers on our escalation script" | A plan, not a past: start by asking what they are seeing, work from their member cases, and agree one thing to try. Your own words on what you did stay at "I trained new tellers on our escalation script." | F7 is the evidence and the probe is the JD's coaching line |

## J: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Your complaints work is from your own branch. What's different when it's several branches and a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | The limit, as the pack's observation: your material says one branch's log. Words: "I handled the branch's formal complaints log." and "Never worked in a contact centre." Then what you would learn first as a plan | F1 and F2, asked by branch managers, who know the branch side well |
| J2 | "Which of our four values would be hardest for you to show from your own experience?" | VAL | [grounded] | Choose honestly: the value where you have least to say. Say so plainly, then the nearest thing your material carries or how you would act on it. Naming a weakness plainly scores better than a weak story | VAL because it scores honest self-assessment against the published values |

## K: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you, over a candidate who has worked in a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "Never worked in a contact centre" | Pause and restate. Hold only what the quotes carry: six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log you handled. Concede specifically: "Never worked in a contact centre." Hold through two follow-ups by returning to those quotes, never by adding to them | Hold-then-concede on F2. JD because it scores the requirement under pressure |

*Guidance above for G to K: pending your approval.*

## Values cheat sheet

| Value (official name) | Working meaning | Nearest material | Mapped story |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "I handled the branch's formal complaints log" | Selection scaffold (G1): pick a real decision; if none comes to mind, say so plainly |
| Plain Words | If a member needs it explained twice, it was written wrong | F7: "trained new tellers on our escalation script" | Selection scaffold (G2): pick a real case; if none comes to mind, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | F4: "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold (G3): pick a real case; if none comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log" | Selection scaffold (G4): pick a real case; if none comes to mind, say so plainly |

*Pending your approval.*

## Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question: it asks what they need, not just what you need |
| R3.2 | "When a complaint escalates from your branch today, what happens next, and what is hardest about it?" | Starts from their side of the counter, and teaches you the seam |
| R3.3 | "Which of the four values do you see staff living out most day to day, and where is it hardest?" | Shows you took the values seriously and invites a real story |
| R3.4 | "What would tell you, a quarter in, that the coaching was working in your branch?" | Ties to the JD's coaching line and gives you a measure to aim at |
| R3.5 | "Could you tell me about an escalation that went well here, and what made it work?" | Invites a story you can learn from |

*Questions above: pending your approval.*

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says the log, not the process end to end. C1's slot stays inside the log |
| Has contact-centre experience | Negative the candidate stated, F2 | The plain acknowledgment: "Never worked in a contact centre." No slot |
| Coached supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: new tellers and a script. C4's slot stays inside the training you gave |
| Presents to senior leaders | Negative the candidate stated, F9 | The plain acknowledgment: "I've never presented to anyone above regional level." |

## Sources

- **Provided documents:** the JD, the values text (copied on 25 November 2026 from ashgrovecu.org/about/values, not fetched), the recruiter's email, four lines from the July 2026 strategy brief, and your own background, all from your message.
- **Searches and fetches sent:** none. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the four value names, G1 to G4 and the cheat sheet |
| 2. `Ashgrove interview process member experience` | skipped | The recruiter's email fixes the three rounds, who runs each, and the panel's values scoring, so the loop and persona weights follow it |
| 3. `Ashgrove strategy` | skipped | The brief's four lines, from July 2026 and under six months old, fix A2, F1 and H3 |
| 4. `{interviewer name} Ashgrove` | n/a | No interviewer is assigned, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **The interviewers' names** once assigned (round 2 and the panel) → an interviewer read, reweighted personas, and a reverse question tied to a career path
- **The full July 2026 strategy brief** → CO questions A2, F1 and H3 currently rest on four lines; the full brief lets them go deeper
- **Your CV** → the fit snapshot draws only on what you wrote in your message; a CV could firm up F3, F5 and F6
- **Your own answers to the slots in F1, F3, F5, F6, F7 and F8**, stated in a message → those rows and the questions that draw on them are regenerated
- **The case format from the recruiter** (R1.1) → H1 to H3 stop being generic patterns
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes: the strategy brief, interviewer footprint once names exist, loop reports for this role family, recent organisation context) → offered once; say if you want it
- **A `tuesday-dossier.md` from an earlier role check** → verified evidence, a named top objection and prohibited claims, if you have one; this pack stands without it
