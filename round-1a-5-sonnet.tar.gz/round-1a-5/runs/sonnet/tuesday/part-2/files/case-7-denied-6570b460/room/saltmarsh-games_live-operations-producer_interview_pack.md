# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Format: one 60-minute conversation on Friday. Relationship assumed: hiring manager. I have not confirmed this, and if he is a skip-level or a peer, the persona weights below change.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values (no bank here: no values round is documented) |
| EXP | Work-experience deep-dive | Whether your CV claims survive scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth (none here: no company research ran) |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience in either branch.

## Prep triage

You have until Friday. In order:

1. Say B1 out loud until it is boring. It is the highest-ROI prep in this pack.
2. Say B2 and B5 out loud. They cover the other stated gap and the "weakest on day one" probe.
3. Walk A1, A2 and A4 through the case structure (clarify, objective, segments, approach, metrics, risks), once each, thinking aloud.
4. Work out C1 and E2 in your own words: how the retention numbers were counted, and which part was yours.
5. Time D1 to 90 seconds.
6. Pick three reverse questions from section 11.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not two titles. Keep the words at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ever ran or shared a second title's schedule, say how; if not, say so plainly and stay with the title you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | The sentence touches the requirement without showing which teams you worked with or how. Answer slot: expect a probe on who you coordinated with on a drop. If you worked with any of design, art, engineering or community, say which and how decisions got made, in your own words; if none, or it was not yours, say so plainly and describe how the calendar ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or chose its KPIs. Keep the words there: "I presented the monthly retention numbers to the studio head." Answer slot: if you also chose what went into those numbers or wrote the review around them, say which part and how, in your own words; if not, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the quote's terms, but a line with nothing inspected behind it, so expect a probe. Lead with it as written: you wrote it, and QA still uses it. Answer slot: the JD says manage, so expect a probe on running a release against it. If you did, say how; if that was someone else's, say so plainly and stay with the checklist |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The sentence gives the years and the title, and does not say whether the game was live-service. Answer slot: if the title ran as a live service for any of those years, say which years and what that meant day to day; if it did not, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The quote already reaches the requirement. Lead with it in its own terms: weekly, one title, two years, you ran it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Expect a defend-the-number probe on how the numbers were counted (C1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | A written artifact that another team still uses is the concrete form of this requirement. Lead with the artifact, not an adjective |
| F9 | Experience with in-app-purchase mobile games: not in the JD, a role-family expectation | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap your words state and wording cannot close. The words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F10 | Leading people: not asked by the JD, which says "coordinate design, art, engineering and community teams on each update" | "Never led a team" — your message | none | [grounded] | capability | A gap your words state. The words: "I haven't led a team." Then what you would do to coordinate across disciplines, said as a plan |

The JD has no hard-gate requirement, so no gate row. "3+ years" is graded in F5 like any other requirement.

## Persona table

No loop source establishes Saltmarsh's loop, so the loop falls back to the generic archetype (screen, hiring manager, panel) and its flat weights. The weights below come from the assumed hiring-manager relationship, since I could not research Tobias.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: scheduling two titles, diagnosing a drop, a late bug | High: a hiring manager buys capability, and the JD is planning-heavy | Clarify, objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps: in-app purchases, no team lead, associate title | High: hiring-manager prior, and two gaps are stated in your own words (F9, F10) | Rehearse the single most predictable objection (B1) until it is boring; limits said plainly; a concrete ramp plan |
| Data-Driven Prober | Reads the retention line closely; asks how it was counted | Medium: the JD names KPIs and retention metrics, and F7 is a metric line | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational / Rapport | "Walk me through the journey" opener | Medium: a 60-minute conversation usually opens this way, and it is still scored | A 90-second arc built from your own sentences |
| Pressure | Time-boxed "why you" and "how much was you" | Low to medium: no signal either way without a profile | Pause, restate, hold a position through two follow-ups, concede specifically |
| Peer Evaluator | Seam-splitting between teams | Low: the role coordinates four disciplines, so it may arrive collegially | Reciprocity framing; seam principles, not pretended knowledge of the seam |
| Values / Behavioral | Stories mapped to published values | Low: no source documents a values round, so no bank is written and none is assumed | Not rehearsed here; see the upgrade menu |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles each want a major event in the same week, and engineering can support only one. Walk me through how you decide." | CASE | [generic] | Clarify first: what each event is meant to move, how ready each is, and what QA needs before release. Then state the objective, compare the two on that objective, choose, and say what you would do for the one that waits. Name one premise you would challenge, for example whether the weeks really cannot move. The question asks for no claim about your past, so the guidance makes none | The JD's two-titles line (F1) makes scheduling trade-offs a natural live problem; CASE because it scores structure |
| A2 | "Retention on one of the titles dropped 20 percent after last week's event. Diagnose it." | CASE | [generic] | Clarify the metric and cohort first, then compare against earlier events, then segment (new versus returning players, platform, version) and check what shipped with the event. Say which finding would change your recommendation. Keep it as structure, with no numbers supplied for you | F7 and F3 are the retention and post-event requirements, and a diagnosis is how a hiring manager tests them; CASE with JD content |
| A3 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F1 and F6: the calendar, the weekly cadence, the main title and the two years are the beats the quote states, so tell them in your own words. Answer slot: the JD's coordination line makes a probe on who you worked with likely. If you worked with any of design, art, engineering or community, say which and how decisions got made; if there was no such coordination, or it was not yours, say so plainly and describe how the calendar ran | F6 is the strongest evidence in the pack and F2 sits right behind it, so this is where the probe lands first; EXP because it tests what was actually yours |
| A4 | "An update is due Thursday and QA flags a blocking bug on Wednesday night. What happens?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure first: severity, scope, whether a workaround exists, who decides, the options (delay, fix and ship, ship without the affected content), and what players are told. Anchor in the one thing the quote carries: you wrote the checklist QA still uses. Answer slot: if the checklist covered a late blocking bug, say what it said; if it did not, say so plainly and say what you would add | F4 is the release-checklist requirement, and a late bug is the stress test for it; CASE delivery, JD content |
| A5 | "You inherit the live-events calendar for both titles on day one. What do you do in your first 30 days?" | CASE | [generic] | Listen before changing anything: map the calendar and who is involved in each update, read the last few post-event reviews, then propose changes with owners. Say what you would need from Tobias in week one. This is a plan, so it makes no claim about your past | F1 and F2 meet here: the two-titles and the coordination requirements, as a plan rather than a history; CASE |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you get up to speed on that for this role?" | JD | [grounded] "never worked on a game with in-app purchases"; [grounded] "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say, as a plan, which reports you would ask for first, who you would ask to walk you through them, and what you intend to understand by day 30, in your own words. The quote about retention is the nearest thing you stated, and it sits at its own scope: you presented those numbers. Follow-up 1: "What would you look at first?" Say what you would ask to see, and "I don't yet know what this team tracks" is an honest answer. Follow-up 2: "How would you know an event was costing us?" Say how you would find out, and say plainly that you have not done it. Follow-up 3: "Are you comfortable owning those KPIs?" Concede the limit, then give the plan | F9 is your largest stated gap, and a hiring manager who owns the KPIs will probe it in some form; JD because the KPIs the role reports are the requirement it presses on |
| B2 | "You haven't led a team. The role coordinates design, art, engineering and community on each update. How will you get those teams moving together?" | JD | [grounded] "Never led a team"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Open with the plain acknowledgment: "I haven't led a team." Then describe how you would coordinate, as a plan: the agreements you would set up front, how you would handle a disagreement, and who decides what. Answer slot: if you coordinated work across disciplines on the content drops, say which and how; if you did not, or that was not yours, say so plainly and say how you would start | F10 is the second stated gap, and the JD's coordination line (F2) is where it presses; JD because it scores a listed responsibility |
| B3 | "You've spent four years as an associate producer at a puzzle-game studio. How does that map to live-service producing here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you held and for how long, in those words, then the calendar you ran, in its words. Answer slot: the JD asks for 3+ years producing live-service games or apps, so expect a probe on whether the title ran as a live service. If it did for any of the years, say which years; if it did not, say so plainly and stay with the calendar. Concede the associate title without apology | F5 is where the JD's years requirement meets the evidence; EXP because it tests what the four years actually contained |
| B4 | "Why this role, and why now?" | JD | [generic] | A selection scaffold, with no reasons supplied for you. Give three sentences, each yours: what you want to do more of, what about this role fits that, and why now. If part of the answer is stepping into a fuller producer role, say so plainly. If a reason does not come to mind, say so plainly, then give the nearest thing you do know about why you applied | Motivation is probed in every hiring-manager round and the pack cannot know yours; JD because it tests fit to the role; `[generic]` because it is a pattern |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases"; [grounded] "Never led a team" | Choose one of F9 or F10 and name it plainly, in the acknowledgment wording of its row. Then give the ramp plan for it and one sentence on what you do already have, in the quotes' own scope. Do not minimize it, and do not volunteer a third weakness | F9 and F10 are the likeliest answers, and naming one yourself converts a gotcha into candor; JD because it scores the listed responsibilities |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The defend-the-number rehearsal. Say what you presented, in the quote's words. Answer slot, four parts, each in your own words: how the numbers were counted, what they are most sensitive to, the assumption behind them you would defend least, and which part was yours. "I don't know how that part was produced" is an honest branch for any of the four | F7 is a metric line, and probers read metric lines first; EXP because it tests attribution |
| C2 | "Which retention metrics would you want in a post-event review, and what would tell you an event worked?" | JD | [generic] | Start from what the event was meant to do, then pick the metrics that match it, then say what you would compare against and over what window. Name one thing the numbers cannot tell you. The question asks for no claim about your past, so the guidance makes none | The JD's post-event review and KPI line (F3); JD content, CASE delivery |
| C3 | "Tell me about a time a monthly or post-event review changed what the team did next." | EXP | [generic]; nearest: "Presented the monthly retention numbers to the studio head" | A selection scaffold: pick a time where the numbers showed something, a decision followed, and someone agreed or disagreed with it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you presented those numbers to the studio head, or how you would run that review | The JD's review requirement (F3) raises the theme, and no sentence of yours carries a story for it, so this is the scaffold case |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "Presented the monthly retention numbers to the studio head" | A 90-second arc, one beat per sentence you wrote: the four years and the studio; the weekly calendar for the main title; the checklist QA still uses; the monthly retention presentation. Close with why this role, in your own words, using B4's three sentences | A casual opener is still scored on economy; F1 to F8 are the evidence the arc rests on; EXP because it is the CV in one pass |
| D2 | "What are you playing at the moment, and what do you notice about how it runs its events?" | JD | [generic] | Name a game you actually play and one thing you have actually noticed about its calendar. If nothing comes to mind, say what you play and how you would study it. A bluffed teardown of a game the interviewer knows is the miss | A live-ops hiring manager will ask this casually and score it; `[generic]` because it asks for your real observation |
| D3 | "The JD asks for clear written communication. What does a clear update note look like to you?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Describe what makes an update note usable by four teams in your own terms. Lead with the one artifact the quote carries: the checklist QA still uses. If your studio's confidentiality allows, offer to bring a version. Answer slot: if asked what was on the checklist, say what it covered in your own words; if you do not remember, say so | F8 is the written-communication requirement; a named artifact beats an adjective |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "never worked on a game with in-app purchases" | Hold-then-concede. Hold: the calendar you ran and the checklist QA still uses, in the quotes' own words. Concede, specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the quotes, never by adding to them | F9 is the gap this question presses on; JD because it scores fit to the role under time pressure |
| E2 | "You presented the monthly retention numbers. How much of what was in them was yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what the quote says: you presented them. Answer slot: if you also built, analysed or chose what went into them, say which part; if none of it was yours, say so plainly and stay with the presenting. Hold through two follow-ups, and concede the limit specifically instead of widening the claim | F3 and F7 rest on this one sentence, which is where attribution probes land |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where is the seam between live operations and design, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: who decides what, how a disagreement is escalated, and what each side needs from the other. Lead with what you would bring the other team, not only what you would need. A disagreement story is a selection scaffold: if no such time comes to mind, say so plainly, then say how you would handle it | F2 is the coordination requirement, and peers of live ops (design, engineering) press on the seam; JD because the role is cross-team |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say "I" for what the quote states, "we" for the rest. The checklist is the one artifact your material names, and it is yours at the quote's scope. A credit-sharing story is a scaffold: if no such time comes to mind, say so plainly, then give how you would do it | Credit questions probe attribution honesty in collegial packaging; F4's quote is the nearest evidence |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A3, A5, B3 |
| Coordinate design, art, engineering and community on each update | A3, A5, B2, F1, F2 |
| Own the post-event review and its KPIs | A2, C1, C2, C3, E2 |
| Manage the release checklist with QA | A4, D3 |
| 3+ years producing live-service games or apps | B3, D1 |
| Experience running a content calendar | A3, D1 |
| Comfortable with player-retention metrics | A2, C1, C2, E2 |
| Clear written communication | D3 |
| Stated gaps (in-app purchases, leading a team) | B1, B2, B5, E1 |

20 questions in total, within the roughly 18 to 26 range.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What is the one live-ops outcome you most want this role to move in the next two quarters?" | It shows you are scoping the job to a result, and the answer tells you which KPIs you will be reporting |
| R2 | "How do the two titles' calendars interact today: shared capacity, or separate?" | The JD names two titles, and the answer shows what you would inherit and echoes the A1 trade-off |
| R3 | "After an event ends, how is it reviewed: who is in the room, and which numbers decide whether it worked?" | The JD makes the post-event review the role's job, so this asks for the standard you will be held to |
| R4 | "Where does this role end and the design, art, engineering and community leads begin?" | It turns the F2 coordination requirement into a conversation about the seam |
| R5 | "Which of the purchase-side reports should a new producer read first?" | Optional, and your call. It turns B1 from an objection into a working conversation. Ask it only if you are comfortable having named the gap yourself |
| R6 | "What has changed in how you run live operations here in the last year, and what is next?" | A rapport interviewer weights this slot, and the answer is the closest thing to a strategy read this pack has |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F10 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or owned monetization KPIs | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the content-drop calendar for your main title. B1 to B3's slots stay inside the one title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers. C1 and E2 stay inside the presenting |
| Managed releases and QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist. A4's slot stays inside the checklist |
| Four years of live-service producing | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says four years as an associate producer, and does not say how many were live-service |

## Sources

Provided documents: the JD text, and your own description of your background in your message. No CV, no recruiter note, no dossier.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused (search permission was not granted), so nothing from the web is in this pack:

- "Saltmarsh Games mobile studio values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games news strategy mobile titles": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have fed the values cheat sheet if a values round is documented, and the value names |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Every call was refused. It would have established the loop, so persona weights fall back to the generic archetype |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call was refused. It would have fed a CO or CASE question grounded in the company's current strategy, and so none was written |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have fed the interviewer read and a reverse question tied to his path, and both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search, or Saltmarsh's published values and any interview-process note pasted in → a values cheat sheet if a values round exists, a company-strategy question for the CO slot, and persona weights tied to a documented loop
- Tobias's public talks or profile, or search permission → an interviewer read, persona weights tuned to his public footprint, and a reverse question tied to his own path
- The recruiter's note on format and who you meet → the round type confirmed, and coverage of any announced deliverable
- Your CV text → the fit-snapshot quotes come from your message, so a CV would add its own lines and any figures, and would upgrade C1 and E2
- Your answers to the slots in F1, F2, F3, F4 and F5, when you tell me (for example whether the main title ran as a live service, who you coordinated with, and which part of the retention numbers was yours) → those rows become grounded stories instead of slots, and A3, B2, B3, C1 and E2 are rewritten
- A tuesday-dossier.md, if you have one → verified evidence and a stricter prohibited-claims list; the pack does not need it
