# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

**Candidate:** Yusuf. **Mode:** loop (three scheduled rounds), built from your message alone: no CV, no full JD, and no research (see Sources).

| Round | When and length | Who | Relationship |
|---|---|---|---|
| 1 | Tuesday, 45 min | Director of Engineering | Hiring manager, your would-be boss |
| 2 | The Thursday after, 60 min | Two staff engineers and a product manager | Panel |
| 3 | The following Monday, 30 min | VP Engineering | Skip-level; the recruiter's description: "values and leadership philosophy" |

The loop itself rests on your own description of each round, not on anything Larkfield has documented. Persona weights below follow that description and the relationship priors.

**The single highest-ROI prep in this pack is A1**, the day-one weakness question. Its limit is stated in your own words, it is the likeliest question in round 1, and the same limit comes back in D4, H2 and three reverse questions.

## How to use this pack

- Personas describe how a question is asked; types describe what it scores. Types: **VAL** (behavioral and values alignment), **EXP** (work-experience deep-dive: does what you said survive scrutiny), **JD** (role-driven: can you do the listed job, gaps included), **CO** (company and strategy knowledge), **CASE** (a live problem set in the role).
- Provenance labels: `[grounded]` is traceable to your message; `[inferred]` is a derivation, named in the cell; `[generic]` is a role-family pattern with no claim about you or Larkfield.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview, not a question for you now: if you did the thing, say how in your own words; if there was no such step, or it was not yours, say so plainly and return to what you did say. That second branch is honest and is never a confession.
- Everything the pack says about your past is one of your own sentences, quoted. Where your material is silent, the pack gives a slot, not a story.

## Shared fit snapshot

The requirements are quoted from the role description you gave me. Your evidence is quoted from your message, word for word.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six, not two squads and not eleven engineers, and the words stay there: "I've spent three of my nine years in engineering as a team lead of six." Answer slot: the two-squads line makes a probe on leading more than one team likely. If you have coordinated work across teams, say how and what part was yours; if you have not, say so plainly and stay with the team of six |
| F2 | "building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | The quote names a payments company, not what was built there, so your material does not show whether any of it was close to device management. Answer slot: if any service you worked on was close to device management, say which and what part was yours, in your own words; if none was, say so plainly and say how you would get up to speed |
| F3 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence says you pushed a quarter through and that the burden dropped after; it does not say you set the delivery plan, and the words stay at that scope. The 60% raises the four defend-the-number slots. Answer slot: if you know how the 60% was counted, say it; if you do not know how it was counted, say so plainly. Name in your own words the assumption behind it you would defend least, and say which part of the work was yours |
| F4 | "hiring" — role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms, and keep "about 40" attached to interviews, because that is the noun it counts |
| F5 | "growth for 11 engineers" — role description | none given | none | [grounded] | discovery | Your material does not show anything on developing engineers. Answer slot: the growth line makes a probe likely. If you have helped an engineer grow in their role, say what the person needed, what you did and what changed, in your own words; if you have not, say so plainly and say how you would approach it |
| F6 | "partner with hardware" — role description | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan in your own words and never as a past. Nothing added to make the gap feel smaller |
| F7 | "product on roadmap" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The sentence shows roadmap pressure existed, not who applied it or how it was settled. Answer slot: if product was part of that conversation, say what each side wanted and how it landed, in your own words; if product was not, or it was settled elsewhere, say so plainly and stay with the quarter |
| F8 | "values and leadership philosophy" — the recruiter, via your message | none given | none | [grounded] | discovery | Your material states no leadership philosophy. This is a selection scaffold, not a story: write your own two sentences on how you lead, then choose which of your own sentences shows it (F1, F4 or F3), each at its stated scope; if none comes to mind, say so plainly and say how you would lead |

No row is a gate: the role description states no eligibility, location, schedule or pay term, so nothing here needed the gate question.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 lead two squads | A2, B3, H1 |
| F2 device-management services | B3, C2 |
| F3 own delivery | A4, B1, B2, E1, E2, F1, F2, H3 |
| F4 hiring | E3, G3 |
| F5 growth for 11 engineers | G3 |
| F6 partner with hardware | A1, D4, RQ1.2, RQ3.5 |
| F7 product on roadmap | A4, B1, F1, F2 |
| F8 values and leadership philosophy | G1, G2, G4, I2 |
| Not a requirement, but a stated limit ("never managed managers") | A3, H2 |

---

# Round 1 — Hiring manager (Director of Engineering), Tuesday, 45 min

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 4 questions) | Quiet, persistent probing of the gaps | Highest. A hiring manager buys capability and de-risks gaps, and your own material names two (F6 and the scale in F1) | Rehearse A1 until it is boring; bridges only from your own F-row sentences, with a plan said as a plan |
| Case / Strategist (bank B, 3 questions) | Live problems from the real roadmap | High. The relationship prior for a hiring manager pairs it with the Skeptic; second because your gaps pull the Skeptic first | Clarify, then objective, then options, then risks; think aloud; challenge one premise respectfully |
| Conversational (bank C, 2 questions) | Friendly opener, "walk me through the journey" | Lower weight, but present: every 45-minute round opens somewhere, and casual questions are still scored | A 90-second arc built only from your own sentences |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The deepest rehearsal in the pack. Say the limit before they press, in your own sentence: "I've never owned a hardware-adjacent roadmap." Stop there; the sentence says nothing about partnering with hardware either way, so add nothing to soften it. Follow-up one, how would you close it: give a plan in your own words, what you would learn first and whom you would ask, said as a plan and never as a past. Follow-up two, have you worked with hardware at all. Answer slot: the partner-with-hardware line makes this probe likely. If you have worked alongside a hardware team in any form, say how and what part was yours; if you have not, say so plainly, and do not stretch the roadmap sentence to cover it. Concede exactly that much and hold your plan, not a claim of experience | F6 is the widest gap against the role's partnership line, so this arrives in some form; JD because it scores a stated requirement, Skeptic because of delivery |
| A2 | "You've led a team of six; this role is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the scale as you stated it: "I've spent three of my nine years in engineering as a team lead of six." What changes is partly a plan, so say it as one. Answer slot: if you have coordinated work across teams, say how and what part was yours; if you have not, say so plainly and stay with the team of six. Never describe two squads as something you have led | F1 is the scale step the question presses on; the premise is F1's own quote plus the role description's numbers |
| A3 | "Have you managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | A plain acknowledgment, from your own sentence: "I've never managed managers." Then stop. The role description names engineers and squads, not managers, and the pack's observation is that it does not say whether any managers sit in the line; that is a reverse question (RQ1.3), not an answer to give | The stated negative is a likely check on level; JD because it tests the listed scope, and it is sourced from your message alone |
| A4 | "Tell me about a time you disagreed with the roadmap and held your position." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3 and F7 with only the beats the sentence states: a reliability quarter, roadmap pressure against it, the on-call burden down 60% after. Tell those in your own words. Answer slot: expect a probe on who pressed and how it was settled; if you made the case to someone, say who and what you said; if it was settled another way, or not by you, say so plainly and stay with the quarter. The 60% raises its four slots (F3): how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours | Your strongest sentence and the likeliest place to be probed; EXP because it tests what was yours; the theme comes from the role description's roadmap-partnership line |
| B1 | "Product wants a new feature this quarter and a hardware dependency slips by six weeks. Walk me through how you would plan the quarter for two squads." | CASE | [generic] | Clarify first: what is fixed, who committed what to whom, what the slip actually blocks. Then the objective, the options with what each trades away, who has to agree, and the risks you would watch. Challenge one premise respectfully, for example whether the six weeks is firm. The question asks about no past, so the guidance makes no claim about yours | A live problem from the role's delivery and partnership lines (F3, F7); `[generic]` because it is a pattern for the problem, not a fact about Larkfield |
| B2 | "You take over two squads and an on-call rota nobody likes. Where do you start?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: find out what is actually hurting before changing anything, agree what to measure, then sequence the fixes against the roadmap. If you reach for your own sentence, use it exactly and stop where it stops: your material does not say what the quarter contained. Answer slot: if you can say what the quarter changed, say it in your own words; if you cannot, say so plainly | Ties the role's delivery line to your one reliability sentence (F3) without extending it; CASE delivery, EXP-adjacent content |
| B3 | "What do you need to know first about the two squads before you commit to a roadmap with product and hardware?" | CASE | [generic] | A list of questions for them, not claims about you: what each squad owns, how hardware dependencies are tracked and by whom, what has been promised and to whom, what the on-call load looks like. Lead with the two you most need. Say the hypothesis you would start from, then ask | A clarify-before-structure test on the role's own scope (F1, F2); `[generic]` because it names no Larkfield facts |
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc whose beats are only those three sentences, each at its stated scope: nine years, three as a team lead of six, the hiring loop, the reliability quarter. Order and emphasis are yours. Close on why this role, in your own words; your material states no reason, so the pack supplies none | The opener is scored; F1, F4 and F3 are the sentences it can draw on |
| C2 | "What are you actually looking at in device management or industrial IoT these days?" | JD | [generic] | Your material is silent here, so this is a selection scaffold: name one thing you have actually read or tried, in your own words. If nothing comes to mind, say so plainly, then say what you would look at first and why. Do not borrow vocabulary you have not used | F2 is the thin row; `[generic]` because the question names a role-family area, and the honest answer is yours alone |

## Reverse questions (round 1)

| # | Question | Why it lands |
|---|---|---|
| RQ1.1 | "What does success look like for these two squads at six and twelve months, and which of those measures do hardware and product also sign up to?" | Surfaces who is accountable for roadmap alignment and gives you the yardstick for F3 and F7 |
| RQ1.2 | "Where does the hardware roadmap most constrain the software squads today, and who owns that seam?" | Turns your stated limit in F6 into curiosity about their real problem, which signals you will learn it |
| RQ1.3 | "How are the two squads set up, and is anyone else, a tech lead or a manager, in the reporting line?" | Answers the scale and managers questions (F1, A3) from their side |
| RQ1.4 | "What would you want a new manager to change in the first 90 days, and what to leave alone?" | A would-be boss's priorities decide how you spend the ramp the A1 plan describes |
| RQ1.5 | "When a roadmap commitment and a reliability need collide, who makes the call here?" | Shows how this Director weighs the trade F3 and F7 sit on, and tells you whether your quarter would be welcome |

---

# Round 2 — Panel (two staff engineers and a product manager), 60 min

## Persona table

No names are known, so personas follow the stated roles. Staff engineers read as peer and technical-specialist relationships (Peer Evaluator plus Prober); the product manager reads as a cross-functional partner (Peer Evaluator plus Case).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (bank D, 4 questions) | Seam-splitting, "what would you need from us", credit and disagreement | Highest. Three panelists all work beside the person you would become; the role puts you between them and hardware and product | Reciprocity framing: what you bring them, not only what you need; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober (bank E, 3 questions) | Line-by-line probing of your numbers, two follow-ups deep | High. Two staff engineers are the likeliest readers of a "60%" and an "about 40" to the assumption | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| Case / Strategist (bank F, 2 questions) | A live roadmap trade-off, probably from the PM | Medium. One panelist's native territory; the role description's product-partnership line makes it likely | Clarify, structure, one respectful premise challenge |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "When a staff engineer disagrees with your call on a technical direction, what happens?" | JD | [generic] | Offer principles, not a history: who decides what, how the disagreement is surfaced early and in the open, what you would want them to challenge, and how the decision gets recorded once made. The question needs no claim about your past, so the guidance makes none | Peer Evaluator stem for the person who will manage the engineers who work alongside them; `[generic]` because your material carries no disagreement story |
| D2 | "What would you need from us in your first month, and what would you bring to our work?" | JD | [generic] | Reciprocity: say what you would want to learn from them first, then what you would offer in return, as intentions and never as a past. Ask them what a manager could take off their plate. No claim about your history | Collegial packaging of the same objection; reciprocity is the Peer Evaluator's counter |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick the nearest instance in your material, with a named stake, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what you did | Peer Evaluator stem; nothing in your sentences carries a cross-team credit story, so the pack supplies none |
| D4 | "Hardware and product will both want your squads' time. Where is the seam between you and each of them, and what happens when they conflict?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Propose seam principles rather than claim to know the seam: who decides scope, who decides sequence, how conflicts are surfaced and who breaks a tie. Say the limit once, in your own words: "I've never owned a hardware-adjacent roadmap." Then what you would do to learn where the seam actually sits, as a plan | F6 returns in collegial packaging; JD because the role description names the partnership |
| E1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the sentence as it stands. Then the four slots F3 raises, in your own words and only from what you know. Answer slot: if you know how the figure was counted, say it; if you do not know how it was counted, say so plainly. What it is sensitive to: say it if you know. The assumption you would defend least: name it before they do, or say you cannot name one. Which part was yours | A headline metric on your own sentence is a magnet for probers; EXP because it tests what survives scrutiny |
| E2 | "How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold your own wording: "The on-call burden dropped 60% after I pushed a reliability quarter through." The sentence says after, not because, and does not say the work was yours alone, so claim neither. Answer slot: if others did parts of the work, say who did what, in your own words; if the work was yours throughout, say so plainly. Hold through two follow-ups by returning to the sentence, and concede the limit specifically rather than vaguely | The attribution probe on F3; EXP because it tests exactly what the candidate did |
| E3 | "You said you run the hiring loop for backend roles. What does running it involve?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Describe what you run, in your own words and at the scope the sentence gives. Keep "about 40" attached to interviews; do not say hires, and if asked how it was counted, say it plainly or say you are not sure. Answer slot: the role's hiring line makes a probe on the loop's design likely. If you set its stages or questions, say which; if the loop was set before you, say so plainly and describe what you ran | F4 is the clean row, and so the one a staff engineer is likeliest to check for depth; EXP because it tests the claim |
| F1 | "Product wants three features this quarter and your two squads can do two. What do you do?" | CASE | [generic] | Clarify first: what the estimate rests on, which feature is fixed and by whom. Then the objective, the options and what each trades away, who has to agree, how you would communicate the cut. Challenge one premise respectfully, for example how the capacity of two was reached. No claim about your past | The product manager's native territory (F7); `[generic]` because it is a problem pattern |
| F2 | "A reliability fix competes with a customer-facing feature for the same engineers. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure: what each costs if deferred, who bears it, what evidence would decide it, and who needs to agree. If you reach for your own sentence, use it exactly and stop there; it does not say what the trade was or what product said. Answer slot: if anyone argued the other side, say what they argued and how it was settled, in your own words; if nobody did, or it was settled elsewhere, say so plainly | The nearest live problem to F3 and F7; CASE delivery, EXP-adjacent |

## Reverse questions (round 2)

| # | Question | Why it lands |
|---|---|---|
| RQ2.1 | "What could a new manager do in their first month that would genuinely help your team?" | The reciprocity question for peers; it reverses the evaluation and gives you a real first-month agenda |
| RQ2.2 | "Where do hardware dependencies show up in your day to day, and what do you wish product understood about them?" | Gets the seam described by the people who live in it, which is the thing D4 asks you to propose principles about |
| RQ2.3 | "How does a roadmap decision get made today when engineering and product see the trade differently?" | Directed at the product manager; tells you the real decision process behind F7 |
| RQ2.4 | "How are on-call load and reliability work weighed against roadmap commitments at the moment?" | Connects to F3 and lets the staff engineers describe their experience of it |
| RQ2.5 | "What is something the squads changed their mind about recently, and how did that go?" | Shows how this group handles disagreement, answering what D1 and D3 probe from the other side |

---

# Round 3 — VP Engineering, the following Monday, 30 min

The recruiter's own words, "values and leadership philosophy", make this a values-style round, so Values / Behavioral leads. Larkfield's published values are not in hand (the searches were refused), so no values cheat sheet is built; the questions are themed on the recruiter's description, and a selection scaffold stands where one of your sentences does not carry a story. Case work is left out of the weights: at skip-level in 30 minutes the recruiter described a values conversation, not a problem-solving one.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (bank G, 4 questions) | Scenario probes on how you lead; STAR-shaped stories | Highest. The recruiter said this is the round's purpose | Tell a story only where one of your own sentences carries it; otherwise a selection scaffold ending in the honest branch; "we" for context, "I" for contribution |
| Pressure (bank H, 3 questions) | Time-boxed, interrupts, tests composure | High. The skip-level prior and a 30-minute slot both point to short, pointed challenges at your stated limits | Pause, restate, hold a challenged position through two follow-ups, concede specifically |
| Conversational (bank I, 2 questions) | Open, unstructured, "why this, why now" | Lower weight; the casual register is still scored | Short pre-scripted arc; never answer "I think you've covered everything" to the reverse-question slot |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What is your leadership philosophy, in a few sentences?" | VAL | [generic] | A selection scaffold. Write your own two sentences on how you lead; the pack does not supply the belief. Then choose which one of your own sentences shows it (F1, F4 or F3) at its stated scope. If none comes to mind, say so plainly, then say how you would lead | F8; the recruiter's own words raise it, and your material states no philosophy, so the pack writes none for you |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [inferred] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection criteria: a named stake, a moment you did not fold, and an intact relationship at the end. If the reliability quarter is the one that comes to mind, your sentence says you pushed it through against roadmap pressure and does not say whom you told. Answer slot: if you made the case to someone senior, say who and what you said, in your own words; if you did not, or it was not to leadership, say so plainly and stay with the quarter or choose another instance. If no such time comes to mind, say so plainly and say how you would handle it | Persona stem for the values bank; `[inferred]` because the link from the quarter to this question is the pack's derivation, not your sentence |
| G3 | "When have you helped an engineer grow in their role?" | VAL | [generic] "I run our hiring loop for backend roles — about 40 interviews last year" | Your material carries no growth story (F5), so pick an instance with a named stake: what the person needed, what you did, what changed; do not name them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, your hiring loop as you stated it, or how you would approach growing someone. Never present the loop as development work | The role description's growth line raises it (F5); the hiring loop is the nearest sentence and is offered only as the nearest, not as a growth story |
| G4 | "Tell me about a decision where doing the right thing for your team cost you something." | VAL | [generic] | A selection scaffold: a named cost, a moment you chose the team anyway, and what the relationship looked like afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide. The pack supplies no incident | Probes leadership philosophy through a trade-off; nothing in your sentences carries a cost story, so this is a scaffold only |
| H1 | "Sixty seconds: why should we trust you with two squads when you have led a team of six?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pause, restate, then hold only what the sentence carries: "I've spent three of my nine years in engineering as a team lead of six." Concede exactly that two squads is a larger scope than your material shows. Answer slot: if you have led or coordinated beyond that team, say how; if you have not, say so plainly. Hold through two follow-ups by returning to the sentence, and never claim the larger scope | The F1 gap in time-boxed form; JD because it presses on the stated requirement |
| H2 | "You have never managed managers. Why would I bet on you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Concede exactly what your own sentence concedes: "I've never managed managers." Do not soften it and do not claim readiness for it. Return to what the role asks, as the role description words it, and to the evidence you do have (F1, F4, F3 at their own scope). Hold through two follow-ups; the concession is the limit, not an opening to widen | The stated negative in time-boxed form; sourced from your own sentence, which makes the premise lawful |
| H3 | "That result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The same item as E2 at skip-level pace: "The on-call burden dropped 60% after I pushed a reliability quarter through." Say after, not because. Answer slot: say which part was yours in your own words; if the work was shared, say who did what. Reuse your E2 preparation; the time box is the only change | Persona stem for the Pressure bank; F3 is the sentence a skip-level reader is likeliest to test |
| I1 | "So, what draws you to this, and why now?" | EXP | [generic] | Say your reasons in your own words; the pack supplies none, because your material states none. If the pull is partly the step up in scope, say so plainly. Keep it to a minute | A casual question that is still scored; no sentence of yours carries a motive |
| I2 | "Is there anything about how you work that a CV would not show?" | VAL | [generic] | Selection scaffold ending in the honest branch: pick one thing about how you lead that you can back with one of your own sentences (F1, F4 or F3); if none comes to mind, say so plainly and say how you would want to be described by the people who work for you. The pack supplies no trait | Invites the leadership-philosophy conversation in a rapport register; F8 |

## Reverse questions (round 3)

| # | Question | Why it lands |
|---|---|---|
| RQ3.1 | "What do you most want engineering leaders here to be known for, and where do you see leaders fall short of it?" | In a values round, their answer is the philosophy G1 and G4 are really being scored against |
| RQ3.2 | "How does engineering leadership decide between a committed roadmap and an unplanned reliability need, and who has the last word?" | Hears the VP's view of the trade F3 sits on, from the person who sets it |
| RQ3.3 | "How do you develop engineering managers here, and what does the path look like from leading a team to leading several?" | Speaks directly to the scale step in F1 and to A3 without claiming anything |
| RQ3.4 | "What would make you say in a year that hiring this manager was a good decision?" | Gives you a yardstick and ends on the future rather than on your gaps |
| RQ3.5 | "How do hardware and software leadership work together here, and where does that tension show up?" | A company-level version of the F6 gap, asked at the altitude the VP can answer |

---

## Prohibited claims

What this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: a team lead of six. The limit is the pack's observation, not words for you: the material says one team, not two squads. A2 and H1 slots stay inside the team of six |
| Owned the delivery plan or the roadmap | Inflated form of F3 and F7 | F3's quote at its own scope: "pushed a reliability quarter through". The material does not say who set the plan |
| Cut on-call burden by 60% through your own program | Inflated form of F3 | F3's quote: the burden dropped 60% after you pushed the quarter through. After is not because, and the sentence does not say the work was yours alone. E1 and E2 slots ask which part was yours |
| Hired about 40 engineers | Inflated form of F4: the figure counts interviews | F4's quote at its own scope: you run the loop, and about 40 is a count of interviews |
| Has managed managers | Negative you stated, F6 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |

## Sources

Provided documents: your message, which supplied the role description, the three rounds and their interviewers' roles, your own background in four sentences, and the recruiter's description of the VP round. No CV, no full job description, no interviewer names, no dossier.

Searches sent, by query:

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Every call was refused. It would have supplied the official value names for a round 3 values cheat sheet; none is built, and the VAL questions are themed on the recruiter's words |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Every call was refused. It would have documented the loop and any case formats; the loop above rests on your own description of each round |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Every call was refused. It would have fed a company-strategy CO question and a grounding brief; none is included, so no question is tagged CO |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full job description → every row in the snapshot quotes the posting's own requirements rather than a one-line summary, and any mid-list item (a named tool, methodology or on-call expectation) gets its own row and question
- Your CV, or the project doc behind your reliability quarter → F2, F5 and F7 may gain quotes of your own; the on-call report or incident-trend chart behind the 60%, or the written quarterly plan, would raise F3 from medium toward high and settle E1
- Your hiring scorecards or loop document → raises F4 and gives E3 inspectable material
- The names of your five interviewers → an interviewer read, personas assigned per person, and a reverse question tied to each one's own path
- Larkfield's published values page, or its careers or interview page, pasted → a values cheat sheet for round 3 and a documented loop in place of your own description; or allow web search, which was refused in this session
- Anything the recruiter said about focus areas, or a presentation, case or take-home for any round → a build section for each declared deliverable
- How much time you have before each round → a prep triage in priority order
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a company strategy brief and CO questions for round 3, offered once and only possible if search access is granted
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and ready-made limits per weak area
