# Interview pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: the hiring manager, name not given. Built from your underwriting dossier (version 1.1); no company research ran (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Past behavior against the company's published values. None used here: no published values were read, and no values round is documented |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | A stated responsibility or requirement of the role |
| CO | Company and strategy knowledge. None used here: no company research ran |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. It names what the interviewer is likely to probe, then gives two honest branches: say how, in your own words, or say plainly it was not so, or not yours.

The highest-ROI prep in this pack is A1. The underwriter named that objection from evidence you confirmed, so it will arrive in some form. Rehearse it until it is boring.

## Fit snapshot

Requirements are quoted from the dossier's role_profile and stand as the JD's lines. No requirement here is a hard gate: the dossier lists none.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile (R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy is bridge: adjacent work, never PM experience. Your material shows integration leadership and roadmap input, not a PM role, and the words stay at those quotes' scope. Plain acknowledgment, sourced by prohibited_claims "Having held a product manager title or role": "I haven't held a product manager title." The roadmap-input quote is medium confidence with limited inspectable proof, so expect a probe on it and name its limit yourself |
| F2 | "Shipped API or platform products" — dossier role_profile (R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quote is integration of the vendor's REST APIs, not building them, and the words stay there. The dossier gives this row no strategy, so the pack routed it by the evidence. Answer slot: the second must-have makes a probe on your part in the API itself likely. If any of your integration work reached the vendor's own API, say what and what part was yours; if none did, or it was not yours, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — dossier role_profile (R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The quotes show REST integration architecture and a written playbook; they do not say whether docs or schemas were part of it. Answer slot: if reading API documentation or working from schemas was part of that work, say how, in your own words; if it was not, or not yours, say so plainly and stay with the architecture of the integrations you led |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile (R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes show client-facing delivery and a channel to product. They do not show work with sales or with engineering squads, and the words stay at the clients and product. Answer slot: if you worked with sales or an engineering team on any of it, say who and what was yours; if you did not, say so plainly and stay with the clients and product |
| F5 | "Agile delivery experience" — dossier role_profile (R5, preferred) | none given | low | [grounded] | discovery | The underwriter's strategy is clarify, and no confirmed entry speaks to this requirement. Answer slot: the requirement's own wording, agile delivery, makes a probe on how you worked likely. If you worked that way, say how, in your own words; if you never did, say so plainly, then say what you would want to confirm about how this team defines it |
| F6 | "Owning a roadmap and prioritization authority" — dossier acknowledge_gap area (R1 sub-claim) | none given | none | [grounded] | capability | The underwriter found no credible evidence, so the strategy is acknowledge_gap: no bridge. Words, sourced by prohibited_claims "Having owned a product roadmap": "I haven't owned a product roadmap." Then a ramp plan said as a plan, never a past: learn how prioritization is decided today with the two squad leads, and what the adoption baseline is |

## Persona table

The weights show their reasoning so you can recalibrate. Priors for a hiring-manager round are Case/Strategist and Skeptic. The underwriter's named objection puts the Skeptic first. The Prober rises because the roadmap-input quote is medium confidence and the 30+ figure invites a count. The Peer rises slightly because the role works beside two squad leads. No interviewer information was given, so there are no signal adjustments. The round is one 45-minute session you described, so no archetype fallback was used. No values-style round is documented, so there is no Values persona bank.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title and roadmap gaps | Highest, 5 questions: the dossier names the objection | Rehearse A1 until boring; concede the plain acknowledgment first, bridge only from the quotes, give a ramp plan |
| B. Case/Strategist | Live problems from the real roadmap: diagnose, define, decide | High, 4 questions: hiring-manager prior, and the role's unknowns are case material | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Reads claims line by line; asks how the 30+ was counted | Mid, 3 questions: one headline figure and one medium-confidence entry | Know what you can and cannot say about each figure; say plainly when you do not know |
| D. Conversational | Friendly opener, easy questions that are still scored | Mid, 3 questions: the opener is near certain | A 90-second arc built only from your quoted sentences |
| E. Peer Evaluator | Seam-splitting with the squad leads | Low, 2 questions: the interviewer is the manager, not a peer | Propose seam principles; do not pretend to know the seam |
| F. Pressure | Time-boxed, challenging, tests composure | Low, 2 questions: no signal of a stress style | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | The underwriter's objection, and the deepest rehearsal here. Pause and restate. Concede first, plainly: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the adjacent case at its quoted scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and you ran quarterly roadmap-input sessions that fed client evidence to product. Name the limit before they do: that is integration work beside product, not product management. Then the ramp plan, said as a plan: learn from the two squad leads how prioritization is decided today and what the adoption baseline is. Hold through two follow-ups by returning to the quotes, never adding to them. If pressed on prioritization, concede in those words: "I haven't set prioritization for an engineering squad." On the sessions, which carry limited inspectable proof, say what they were and stay there. Do not argue you are the stronger hire | F1 and F6 are where the role's roadmap mandate presses hardest, and the underwriter named this objection from confirmed evidence. JD because it scores the must-have requirement. Likely follow-ups are A2 and E1 |
| A2 | "Which part of this role would be hardest for you on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name the real one: the roadmap ownership and prioritization part, in the plain words "I haven't owned a product roadmap." Do not bridge it; the underwriter looked and found nothing to bridge with. Then the ramp plan as a plan: first weeks with each squad lead to learn how prioritization is decided and what adoption looks like today. Calibrated candor beats a bluff about the competency the interviewer owns | F6 is the acknowledge_gap area, so this is the question where a bridge would be inflation. JD because it tests honest self-assessment against the listed work |
| A3 | "Tell me about a time you worked on an API or platform product." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Story-map from the two sentences, at their scope: you led the integrations, scoping through go-live, and you wrote the playbook your team uses. Say the limit yourself: these are integrations of the vendor's REST APIs. Answer slot: the second must-have makes a probe on your part in the API itself likely. If any of your integration work reached the vendor's own API, say what and what part was yours; if none did, or it was not yours, say so plainly and stay with the integrations you led | F2 is the evidence for the second must-have and sits at the edge of its wording, so it is probed. JD because it scores a stated requirement |
| A4 | "Tell me about a time you worked within an agile delivery process." | JD | [grounded] | No confirmed entry speaks to this, so the answer is a clarify shape. Answer slot: the requirement's own wording, agile delivery, makes a probe on how you worked likely. If you worked that way, say how, in your own words; if you never did, say so plainly, then say what you would want to confirm about how this team defines it. Nothing about your past goes in beyond that | F5 is a discovery row with a clarify strategy; the honest form here is a question-shaped answer. JD because it is a stated requirement, though a preferred one |
| A5 | "Tell me about a time you disagreed with an engineering lead about scope." | EXP | [generic] | Selection scaffold: pick a time you pushed back on, or negotiated, scope with someone who built what you scoped; it needs a named disagreement, your own position, and the relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Offer no detail you cannot repeat under a second question | F4 shows no engineering-side evidence, and the role drives delivery with two squads. EXP because it tests what was actually yours |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partners tell us that integrating with our API takes too long. What do you need to know first, and how would you diagnose it?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify first: which partners, which stages, what too long means against what. Then structure out loud, using the quote's stage names as your frame: scoping, requirements, architecture, UAT, go-live. That is a way to organize the diagnosis, not a claim about where these partners get stuck. Then approach, metrics, risks. Challenge one premise respectfully, such as whether the time is the real complaint | F2's requirement area, set as a live problem on the partner platform. CASE because it scores structure, not a right answer |
| B2 | "We want to track partner API adoption. How would you define it and what would you track?" | CASE | [generic] | Ask first how adoption is measured today and what the baseline is; the posting leaves both open, and the answer changes your approach. Then propose a definition, separate early signals from lasting ones, and say which proxy you would trust least and why. Present it as how you would approach it, not as something you have done | The role lists adoption metrics as a responsibility with no stated baseline. CASE because it tests defining a measure live; `[generic]` because it is a pattern, not a fact about Quartzline |
| B3 | "Two squad leads each want your next quarter. You can back one. How do you decide?" | CASE | [generic] | Ask who holds the decision first and what each lead is optimizing; the decision rights are an open unknown. Then state the criteria you would use and how you would tell the loser. Say it as how you would decide, never as how you have decided | F6 is why this is the likeliest case: it tests the part you have not done, so a past-tense answer would be inflation. CASE because it scores reasoning |
| B4 | "Sketch the first page of a spec for a partner-facing webhooks feature. What do you need to know before you write it?" | CASE | [generic] | Clarify partners, use cases, today's pain and constraints. Then structure the page: problem, who it is for, requirements, what is out of scope, how you would measure success, open questions. Invite one correction from the interviewer mid-way | The role writes specs and drives two squads. CASE because it tests structure; JD content, CASE delivery |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you ran the quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence, so volunteer the limit before it is extracted. Beats the sentence states: the sessions, quarterly, client evidence fed to product. Answer slot: the role's discovery with integration partners makes a probe on how evidence was chosen and weighed likely. If you chose or weighed it, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the sessions you ran. If you do not know what product did with the evidence, say so | F1 and F4 both lean on this sentence, and it has limited inspectable proof, so a prober finds the seam. EXP because it tests whether the claim survives |
| C2 | "You say 30+ integrations. How was that counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say 30+ exactly as it is, attached to integrations. Answer slot: expect how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; if you do not know how it was counted, say so plainly. If others ran some alongside you, say how much was yours; if you led all of them, say so | The headline figure on the evidence is a probing target. EXP because it tests attribution and counting |
| C3 | "Tell me about a time you worked directly with API documentation or schemas." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Story-map at scope: REST integrations whose architecture you led, and a playbook you wrote. Answer slot: the technical-fluency line makes a probe on docs and schemas likely. If reading API documentation or working from schemas was part of that work, say how; if it was not, or not yours, say so plainly and stay with the architecture you led | F3 quotes touch the requirement without showing it. JD because it scores a stated requirement |

### D. Conversational/Rapport (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, one per sentence: you led the integrations, you wrote the playbook, you ran the roadmap-input sessions. Answer slot: your material says nothing about why you want the move to product. Give your own reason in your own words; none is supplied here. Do not say the path led naturally to this role | The opener is near certain and still scored. F1 is the row it frames. EXP because it tests whether the story hangs together |
| D2 | "What draws you to owning a partner-facing API platform?" | JD | [generic] | Selection scaffold: pick the one listed responsibility that pulls you most: the roadmap, partner discovery, specs with two squads, or adoption metrics, and say why in your own words. If none pulls you more than the others, say so plainly and say what you would want to learn first. Do not claim knowledge of Quartzline's strategy; none was researched | A casual motive question scored as interest. `[generic]` because no company research ran |
| D3 | "Tell me about the internal integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | High confidence and inspectable, so be ready to describe what is in it. Say it at scope: you wrote it, it is internal, your team uses it. Answer slot: if you know what it changed for the team, say so; if you do not, or it changed nothing you can name, say so plainly and say what the playbook covers | F3 and F1 both use this sentence. EXP because it is the best-evidenced claim and a good place to sound sure |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our squad leads are used to deciding what their squad builds. Where is the seam between you and them, and what happens when you disagree?" | JD | [generic] | Do not pretend to know the seam. Ask who decides what today, then propose principles for the seam and say how you would handle a disagreement. Say it as how you would work, not as how you have worked. Ask what the squad leads would need from you; your reverse question 1 is the same point | The decision-authority unknown is the dossier's open risk. JD because it scores the stakeholder requirement in F4 |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work crossed teams and the credit could have blurred; it needs the shared outcome, your part, and how the credit was named. If no such time comes to mind, say so plainly, then say how you would handle it | A standard peer probe at collaboration style. Low weight because the interviewer is the manager |

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role" | The time-boxed form of A1. Pause, restate, concede in one sentence: "I haven't held a product manager title." Hold on the two quotes: you led the integrations and you wrote the playbook. Stop there. Do not claim to be stronger | F1 under time pressure. JD because it scores the title requirement |
| F2 | "The roadmap-input sessions — how much of that was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold on "ran": that is yours as the sentence says it. Answer slot: if anyone shared running them, say who and what each of you did; if you ran them alone, say so plainly. Concede only what you do not know, such as what product did with the evidence. Do not fold on the core claim to ease the moment | A pressure probe on the medium-confidence entry. EXP because it tests attribution |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 3+ years product management experience | A1, A2, F1 |
| R1 sub-claim: owning a roadmap and prioritization authority | A1, A2, B3, E1 |
| R2 Shipped API or platform products | A3, B1 |
| R3 Technical fluency: API docs, schemas | C3, B4 |
| R4 Stakeholder management across engineering, sales, customers | A5, C1, E1, E2, F2 |
| R5 Agile delivery experience | A4 |
| Responsibility: run discovery with integration partners | C1, B1 |
| Responsibility: write specs and drive delivery with two squads | B4, A5 |
| Responsibility: define and track adoption metrics | B2 |

## Reverse questions

The first two come from the dossier's employer questions and validate its open risks. They also answer something you need to know before accepting.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The posting asserts decision authority without evidence; this reads as diligence and tells you whether the role is what it says |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The responsibility is named with no baseline; asking shows you think in measures and tells you what you would be judged on |
| 3 | "How do the two squads run delivery today, and where does product sit in that rhythm?" | Gets the interviewer's own definition of agile delivery, which the dossier left to clarify |
| 4 | "How does the team hear from integration partners today, and who owns that conversation?" | Ties to the discovery responsibility and shows you start from partner evidence |
| 5 | "What would success look like at ninety days, and what would worry you at that point?" | Invites the objections still open while you can still answer them |
| 6 | "Is there anything about coming from the integration side that would give you pause?" | Surfaces the A1 objection on your terms, with time to respond |

## Prohibited claims

Not coached anywhere in this pack. The first three come from the dossier's prohibited_claims and are absolute.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | prohibited_claims: "Having held a product manager title or role" | "I haven't held a product manager title." Then the integration and roadmap-input quotes at their own scope |
| Having owned a product roadmap | prohibited_claims: "Having owned a product roadmap", and the acknowledge_gap area | "I haven't owned a product roadmap." Then a ramp plan said as a plan, never a past |
| Having set prioritization for an engineering squad | prohibited_claims: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." Then how you would learn how it is decided here |
| Shipped an API or platform product | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: your material says client integrations of the vendor's REST APIs, not building them. A3's slot stays inside the integrations |

## Sources

Provided: your tuesday-dossier.md, version 1.1. It supplied handoff_to_mock_interview (verified evidence, weak areas and strategies, the named objection, risks, employer questions, prohibited claims) and role_profile (requirements, responsibilities, unknowns). The decision was read as context only. The dossier carries no evidence_map, risk_register or evidence_state, so the fit snapshot is graded from the handoff section alone.

Searches sent, all refused by the host, so nothing from them is used:

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline API platform strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have fed a values cheat sheet and VAL questions; none are in the pack |
| 2. Quartzline interview process, product manager | unavailable | Would have documented the loop; persona weights rest on the hiring-manager prior and your own description of the round |
| 3. Quartzline strategy and recent news | unavailable | Would have fed CO and strategy-grounded CASE questions; the CASE bank is `[generic]` where it needs company facts |
| 4. Interviewer name and company | n/a | No name was given, so there is no interviewer read and the upgrade menu says what a name unlocks |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The hiring manager's name → an interviewer read from their public footprint, persona weights adjusted to it, and a reverse question tied to their own path
- The recruiter's prep email, or any stated focus areas → coverage of anything pre-declared, such as an exercise or a presentation
- The full posting text → requirement lines now taken from the dossier become the posting's own words
- The raw CV behind the confirmed claims → fit-snapshot evidence cells can quote it directly
- A roadmap-input session deck, agenda or notes → the roadmap-input entry moves from medium toward high confidence, and C1 and F2 firm up
- Search access, or a pasted values page and strategy brief → a Quartzline values sheet, CO questions and a documented loop; a deeper pass would add up to 6 more searches and 2 more fetches, taking several more minutes
