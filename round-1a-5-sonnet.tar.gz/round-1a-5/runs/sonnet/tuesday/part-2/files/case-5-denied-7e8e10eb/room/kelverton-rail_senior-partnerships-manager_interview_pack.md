# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your spoken POV, no slides. The rest is Q&A, and the recruiter's email says Ross will push on commercials. Source: the recruiter's email as you quoted it in your message.

**Built on:** your message only. No job description was supplied and web research was not available, so company facts are absent and the company-specific questions are labelled generic.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. The guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it is scoring |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the behavior being asked about, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and you can say what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role, delivered live |

Where a cell says "Answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the step was not yours or never existed. Neither branch is a failure.

## Prep triage (about four hours)

1. **90 minutes: build and speak the POV** (section 5, then A1 to A3). Say it aloud at least twice, timed. Write only a skeleton, not a script.
2. **45 minutes: B1 aloud, three times**, with its follow-up ladder. This is the highest-ROI prep in the pack.
3. **45 minutes: commercials** (C1, D1, D3). Before drilling, find what you can honestly say about how the £4M and the 6 to 40 were counted. If you cannot find it, the honest branch is written into each card.
4. **30 minutes: the market report, once more.** Pick one point you would agree with, one you would depart from, and one thing you would deliberately not do (A4 and section 5).
5. **30 minutes: E1 (the 90-second arc) and three reverse questions.**

Everything else is insurance.

## 4. Fit snapshot

No JD was supplied, so the requirements below are the recruiter's own words and the facts you gave me. Evidence cells hold your sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Senior Partnerships Manager" — the role, in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | none | A statement with nothing inspected behind it, so expect a probe. Lead with it in its own terms: nine years in partnerships, the last four running the ISV channel at a payments company. Add no seniority word you did not say |
| F2 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says the ISV channel at a payments company, not operator partnerships, with nothing inspected behind it. The words stay at the quote: "I took the ISV channel from 6 partners to 40." Answer slot: the POV invites a probe on how that growth carries to operators. If any part of it was yours to decide, say which part and how, in your own words; if it was not yours, or little of it carries, say so plainly and stay with the number as you gave it |
| F3 | "Please land on what it means for the operators themselves" — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, from the consulting side. It does not say train operating companies. The words stay at the quote: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: expect a probe on how far that carries to train operating companies. Say what carries and what does not, in your own words; if the work did not involve train operators, say so plainly and stay with the bus and light rail work |
| F4 | "Ross will push on commercials" — recruiter's email, quoted in your message | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Hold the figure at its exact scope: roughly, and influenced. Answer slots, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F5 | A probe on revenue accountability, read from "Ross will push on commercials" — recruiter's email, quoted in your message | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would approach being accountable for a number, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "they sell scheduling software to train operating companies" — your description of Kelverton Rail, in your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then a ramp plan in your own terms, said as a plan, with nothing claimed about rail selling |

## 5. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded: "where you'd take our operator partnerships over the next 18 months", landing on "what it means for the operators themselves".

**Grounded facts you may build on** (any claim about you stays inside these quotes):

- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel"
- F2: "took it from 6 partners to 40"
- F3: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4: "roughly £4M of influenced revenue"

Use them as credentials in one sentence, not as the argument. The POV is a view about operators; your history is why it is worth hearing.

**Shape (aim to finish inside about 13 minutes so the panel can interrupt).** `[generic]`

- About 1 minute: say your assumption about what "operator partnerships" cover, aloud, and invite correction.
- About 8 minutes: two or three moves, each with its concession.
- About 3 minutes: land on operators (below).
- About 1 minute: what you would test first and how you would know.

**Theses to choose from.** Pick two or three that you actually believe. Each has a mandatory concession, and the concession is spoken, not hidden. `[generic]` These are positions, not facts about Kelverton.

| Thesis | Mandatory concession |
|---|---|
| Define each partnership by an outcome the operator itself would name, and measure it that way, rather than by how much of our product they adopt | Outcome commitments are harder to control than adoption, and they can make early reporting look slower |
| Go deeper before wider: concentrate effort on a few operator relationships and turn them into proof other operators would recognise, before broadening | It trades breadth and near-term volume for credibility, and it concentrates risk in a few relationships. Ross will ask what it does to revenue timing |
| Build a repeatable partnership motion so each quarter of the 18 months compounds on the last | A repeatable motion can flatten real differences between operators. Say how you would stop that, in your own terms |

**Differentiate from the report.** The strategy team's market report is equally available to both interviewers, so reciting it scores as homework. Bring one point from it that you agree with, to prove you read it, then one thesis-driven departure with your reasons. Where the job includes saying no, add the anti-pick: one thing you would deliberately not do in the 18 months, and why. The pack has not seen the report, so choosing the points is your work.

**The close the recruiter asked for: what it means for the operators themselves.** Spend the last three minutes here and make it concrete. For each move you chose, say what an operator would notice that it cannot do or see today, what it would ask of the operator in return, and what the operator would use to judge whether it was working. The pack does not supply these: they have to be yours, and they should be specific enough that Deepa could repeat them to an operator.

## 8. Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The POV itself, then live problems from Deepa on partnership choices | **Highest.** Hiring-manager prior is Case/Strategist plus Skeptic, and a no-slides POV invites open strategic follow-ups | Clarify, then structure, then answer. Say your assumptions aloud. Challenge one premise respectfully per case |
| B. Skeptic | Deepa probing the gaps: rail, quota, why this move | **Joint highest.** The same hiring-manager prior, and F5 and F6 are gaps you have named yourself, so the objection is certain | Rehearse the single most predictable objection until it is boring. Bridge only from what you have stated, and say the limit plainly |
| C. Data-Driven Prober | Ross taking each number apart | **High.** The executive prior would favour Case plus Pressure, but the recruiter's note that Ross will push on commercials tilts it toward the Prober | Know what you can and cannot say about how each figure was counted. Name the weakest assumption you know of before he does |
| D. Pressure / Stress | Ross time-boxing and playing devil's advocate on influenced revenue | **Medium.** Executive prior, plus the commercials signal | Pause, restate, hold a position through two follow-ups, then concede specifically without folding the core claim |
| E. Conversational | The opening "walk me through your journey" | **Low weight, but scored.** Panels often open casually | A pre-scripted 90-second arc built only from your stated sentences |
| G. Peer Evaluator | Ross on the seam between partnerships and commercial | **Low.** He is a cross-functional counterpart rather than a peer, so one or two collegial seam questions are plausible | Offer seam principles rather than pretending to know the seam. Frame what you bring his team |
| H. Values / Behavioral | An unpopular-truth or customer-first question | **Low.** The recruiter described no values round, so none is detected. Two questions are included so the style is not met cold | Pick stories you can stand behind in full. Where none comes to mind, say so plainly |

**Loop:** the recruiter's email establishes one 60-minute panel with named interviewers, so persona weights follow that and no archetype fallback applies. For a panel, each member's top two personas are blended. Deepa gets A and B, Ross gets C and D.

## 9. Question banks

Twenty-two questions. IDs run by persona; there is no F bank, so question IDs never collide with the fit rows.

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] "took it from 6 partners to 40" | Build from section 5. Say your assumption first, give your chosen moves with their concessions, then land on the operators. If you cite your own background, use only: "I took the ISV channel from 6 partners to 40." Answer slot: expect a probe on how that carries to operators. If any part of it was yours to decide, say which and how; if it was not yours, or little of it carries, say so plainly and stay with the number as you gave it | The announced deliverable and the likeliest opening to the Q&A. F2 is the evidence that will be probed; CASE because it is scored on structure and reasoning |
| A2 | "Two operators ask for different things from us. How do you decide where partnership effort goes first?" | CASE | [generic] | Structure it aloud: what you would want to know about each, how you would compare them, what you would give up by choosing, and how you would tell the one you did not choose. The question needs no claim about your past, so the guidance makes none | A live prioritisation problem tied to the 18-month POV; generic because it is a pattern, not a fact about this employer |
| A3 | "What would you need to know first, before you'd commit to an 18-month plan?" | CASE | [generic] | Clarify before structuring: name what you would ask, why each answer would change the plan, and what you would assume if nobody could tell you yet. State the assumption you made in your POV and why | A stem from the Case persona. Tests whether you clarify before you answer, which a no-slides POV makes visible |
| A4 | "What in the market report would you challenge?" | CO | [grounded] "which I've read" | You said you have read it, so choose in advance: one point you agree with, one you would depart from, and one thing you would not do. The pack has not seen the report and supplies none of these. Answer slot: if no point comes to mind that you would depart from, say so plainly and name the one you would test first | The report is equally available to both interviewers, so differentiate from it rather than reciting it. CO because it tests homework depth at the company's altitude |
| A5 | "An operator partner tells you our work isn't changing what their people do day to day. Diagnose it." | CASE | [generic] | Think aloud: who you would ask, what you would look at to separate adoption from fit, what you would not conclude yet, and what you would say back to the operator. No claim about your past | A diagnosis problem set in the role, aimed at the operator outcome the recruiter asked you to land on (F3's requirement) |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see rail selling anywhere in your background. Why would operators take your approach seriously?" | JD | [grounded] "Never sold into rail specifically", "5 years in transport consulting (bus and light rail network planning", "running the ISV channel", "took it from 6 partners to 40" | **The highest-ROI prep in the pack: this will be asked in some form.** Pause and restate. Say it first, plainly: "I haven't sold into rail specifically." Then hold on what you stated: "For the last four years I was running the ISV channel at a payments company, and I took it from 6 partners to 40. Before that I spent five years in transport consulting, on bus and light rail network planning." Then give a ramp plan as a plan: what you would learn first and from whom, in your own terms. **Follow-up ladder.** (1) "Bus and light rail aren't train operating companies; what carries over?" Answer slot: say what carries and what does not, in your own words; if nothing from that work carries, say so plainly and stay with the channel work. (2) "What would you get wrong in your first 90 days?" Name one real thing in your own judgment; the pack supplies none. (3) "What if our team tells you rail works differently?" Concede specifically: you have not sold into rail, and you would rely on their rail knowledge for what is rail-specific. Do not retreat from what the quotes carry | F6 is the biggest named gap and Deepa buys capability while derisking gaps. JD because it tests the stated job; the Skeptic delivery is why it sits here. Deepest rehearsal because the limit is stated before it is asked |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota, only influenced revenue", "Never sold into rail specifically" | Pick the one you genuinely think is weakest, and say it plainly. If it is quota: "I've never carried a direct quota, only influenced revenue." If it is rail: "I haven't sold into rail specifically." Then what you would do about it in the first weeks, as a plan. Do not pretend to a competency Ross or Deepa personally owns | A stem from the Skeptic persona. F5 and F6 are the two candidate answers; choosing one honestly beats choosing a safe third |
| B3 | "Why this move, and why now?" | EXP | [generic] | Answer slot: give your actual reasons, in your own words. The pack does not supply a reason and cannot guess yours. Check that it matches the story you tell in E1, because the panel will hear both | Motivation-consistency is what a Skeptic scores, and any move from payments to rail-tech draws it. The reason is yours alone |
| B4 | "Your background covers transport consulting and payments partnerships. What's the through-line?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning", "9 years in partnerships, last 4 at a payments company running the ISV channel" | Name the through-line in two or three sentences, using only those two facts in order. Answer slot: the connecting idea is yours to state. If no through-line comes to mind, say so plainly and give the sequence as it happened | Two sectors invite the question of whether this is a pivot or a pattern (F1, F3). EXP because it tests the story behind the CV |

### C. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the £4M of influenced revenue." | EXP | [grounded] "roughly £4M of influenced revenue" | Say it at its scope: "roughly £4M of influenced revenue", never sold, closed or generated. Answer slots, in your own words: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before he does | F4 is the headline number and Ross is the commercial probe. EXP because it tests whether the number survives scrutiny |
| C2 | "What counted as a partner when you went from 6 to 40?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slots, in your own words: how the count was made and what a partner was for it; what it is sensitive to; the assumption you would defend least; which part was yours. If you do not know exactly, say so and say what you do know | F2's figure is the second number a prober takes apart. EXP because it tests precise attribution |
| C3 | "Suppose I ask you to forecast what partnerships could contribute from one operator next year. What would you use?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | A hypothetical, so structure it: the inputs you would ask for, the assumptions you would state aloud, and the range and what would move it. If asked whether you have done it before, your words are: "I've never carried a direct quota, only influenced revenue." Do not claim forecasting experience | Commercials push (F4, F5). JD because it scores the commercial side of the job, with a CASE delivery |
| C4 | "How would you know a partnership is working, for us and for the operator?" | JD | [generic] | Name one measure for each side, say how you would collect it, and say what you would do if the two disagree. It makes no claim about your past | Ties the commercials push to the operator close the recruiter asked for (F3's requirement) |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue", "running the ISV channel" | Pause. Hold through two follow-ups on exactly what you stated: "roughly £4M of influenced revenue", from the channel you were running. Concede specifically: it is influenced, not a number you carried. Answer slot: say which part was yours, in your own words; if you cannot split it, say so plainly and stay with the figure as you gave it | The stem names the attribution probe directly (F4). EXP because it tests candor under pressure |
| D2 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically", "took it from 6 partners to 40", "5 years in transport consulting (bus and light rail network planning" | Time-box yourself. Concede first: "I haven't sold into rail specifically." Then what you offer, in the quotes' own scope: the channel taken from 6 partners to 40, and five years of bus and light rail network planning. Do not disparage the hypothetical candidate and do not claim to be better | A stem from the Pressure persona, aimed at the F6 gap |
| D3 | "Influenced revenue isn't revenue we can book. Why should we weigh it?" | EXP | [grounded] "roughly £4M of influenced revenue", "never carried a direct quota, only influenced revenue" | Hold, then concede: the quotes support "roughly £4M of influenced revenue" and "I've never carried a direct quota, only influenced revenue." Concede that it is not a direct quota. Answer slot: if you know how influence was determined, say so in your own words; if you do not, say so plainly. Then say what you would want to be measured on in this role, as a forward stance and not a past claim | The sharpest form of the commercials push (F4, F5). EXP because it tests whether you can hold a claim without inflating it |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel", "5 years in transport consulting (bus and light rail network planning" | A 90-second arc: five years in transport consulting on bus and light rail network planning, nine years in partnerships with the last four running the ISV channel at a payments company, then why this role. Answer slot: the reason for the move is yours; the pack supplies none | Casual openers are scored. F1 and F3 are the arc's two anchors |
| E2 | "What are you actually playing with in operator partnerships these days?" | JD | [grounded] "which I've read" | Answer slot: name one real thing you have read or looked at recently in this area, which can include a point from the report you said you read; if nothing comes to mind, say so plainly and say what you would look at first. Never invent a current project | A stem from the Conversational persona. Rapport-style questions about the role's hot topics are scored |

### G. Peer Evaluator (Ross, collegial)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Partnerships and commercial sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who owns which relationships, how a partnership's contribution is credited, and how disagreement gets resolved. Offer what you bring his team, not only what you need | A stem from the Peer persona, aimed at the commercial counterpart. The pack does not know this company's seam |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Describe your approach in principle. If you give an example, choose one you can stand behind in full; if none comes to mind, say so plainly and give how you would handle it | A stem from the Peer persona. Influenced revenue (F4) makes credit a natural follow-up |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften it, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stem from the Values persona. No values round was described, so this is for style, not content |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick one specific decision where the metric and the customer pulled apart, and say what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stem from the Values persona. It also rehearses the operator-first stance the POV close needs |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: Senior Partnerships Manager | E1, B4, D2 |
| F2: POV on operator partnerships over 18 months | A1, A2, A3, A5, C2, E2 |
| F3: land on what it means for the operators | A1, A5, C4, H2 |
| F4: Ross will push on commercials | C1, C2, D1, D3 |
| F5: revenue accountability | B2, C3, D1, D3 |
| F6: selling into rail | B1, B2, D2 |
| The strategy team's market report | A4, E2 |

## 11. Reverse questions

Use three or four; do not read the list. No interviewer profile was available, so none is tied to a career path.

| # | Reverse question | Why it lands |
|---|---|---|
| R1 | To Deepa: "If this role goes well, what will an operator be able to say in 18 months that they can't today?" | It makes you the person who lands on operators, which is what the recruiter asked for |
| R2 | To Ross: "How is partnership contribution counted alongside direct commercial numbers here, and what would you want to see from this role in its first two quarters?" | It shows you take the commercials seriously rather than avoiding them, and it surfaces the seam |
| R3 | To Deepa: "Which operator relationship should I learn the most from in the first 90 days, and who owns it today?" | It answers the F6 objection with a plan, and invites her to teach |
| R4 | To both: "What in the strategy report has already changed since it was circulated?" | It shows you read it and asks for the live view rather than the written one |
| R5 | To Deepa: "Where do you want this role to say no in the first year?" | It shows you are thinking about the anti-pick and about prioritisation |
| R6 | To Ross: "What commercial question would you most like partnerships to help answer?" | A reciprocity question: it asks what you can do for his team, not only what you need |

## 13. Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold, closed or generated roughly £4M | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says influenced revenue, not sold or closed revenue |
| Carried a quota or revenue target | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| Sold into rail, or closed deals with train operating companies | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I haven't sold into rail specifically." No slot |
| Knows how train operators plan, run or buy | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning, from the consulting side |
| Signed or recruited every partner added to the channel | Inflated form of F2 | F2's quote at its own scope. C2 and A1 hold slots on which part was yours |

## 14. Sources

**Provided documents:** your message, including the recruiter's email as you quoted it, your description of the role and company, and your background. **Not in hand:** the market report. You said you have read it, but it was not pasted, so the pack knows nothing of its content. No dossier was present.

**Searches sent (all refused, no results returned):**

1. "Kelverton Rail values": refused
2. "Kelverton Rail interview process partnerships manager": refused
3. "Kelverton Rail strategy scheduling software train operating companies": refused
4. "Deepa VP Partnerships Kelverton Rail": refused
5. "Ross Commercial Director Kelverton Rail": refused
6. "Senior Partnerships Manager job rail technology software train operators UK": refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Search refused. Would have supplied official values for VAL questions; a values cheat sheet needs a values-style round to be detected, which nothing in hand shows |
| 2. Kelverton Rail interview process, partnerships | unavailable | Search refused. Would have shown whether a candidate guide documents more of this loop than the recruiter's email; persona weights stand on the email alone |
| 3. Kelverton Rail strategy and recent news | unavailable | Search refused. Would have grounded the CO questions; A4 and E2 lean on your own reading of the report instead |
| 4. Interviewer public footprint | unavailable | Both searches refused. Would have added an interviewer read and a reverse question tied to a career path; both are absent |
| 5. Representative JD | unavailable | Search refused. Would have given requirement rows to quote beyond the recruiter's words |

## 15. Upgrade menu

- **The job description text** → the fit rows quote the JD rather than the recruiter's email, gap types are re-run, and JD-tagged questions gain raising sources
- **The market report's key points, as you would cite them** → A4 and E2 become grounded, and a grounding brief becomes possible
- **Web search permission** → the five research targets above run, giving company values, loop detail, strategy facts and an interviewer read with a reverse question tied to each interviewer's path. A deeper pass would add a strategy brief, deeper interviewer research, loop reports and recent organisational context, for up to 6 more searches and 2 more fetches over several more minutes
- **Deepa's and Ross's full names or profile links** → an interviewer read, and persona weights adjusted from their public footprint
- **Your own answers to the answer slots, stated in plain words** (how the £4M and the 6 to 40 were counted, which part was yours, and your reason for the move) → upgrades F2, F4 and the slots in A1, B3, C1, C2 and D1
- **The recruiter's answer on whether the report is expected to feature in your POV** → settles how heavily A4 and section 5 lean on it, usually one short email
- **A tuesday-dossier.md from an earlier fit check** → verified evidence and a pre-built prohibited-claims list, which would sharpen the guidance cells. It is not needed for this pack
