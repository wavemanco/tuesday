# Interview prep pack: Live Operations Producer, Saltmarsh Games

- Role: Live Operations Producer, Saltmarsh Games (mobile game studio)
- Interviewer: Tobias Wrenfield, Head of Live Operations. How he relates to the role was not stated, so this pack is built as a hiring-manager-style round. If that is wrong, the persona weights below are what changes.
- Format: one 60-minute interview, Friday.
- Highest-ROI prep in this pack: B1, the in-app-purchases question.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Behavior against the company's published values. This pack has no VAL questions, because no published values were in hand |
| EXP | Whether a claim about your past survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its titles |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Sized to the time before Friday. Do these in order.

1. B1, aloud, until it is boring. It is the most likely objection and the one the pack rehearses deepest.
2. B2, B3 and B4, aloud. Decide now, in your own words, which branch of each answer slot is true for you.
3. A4 and D2, once you can find which two titles the role covers: look at them before Friday and note what you see from the outside.
4. A1 and C1, once each, aloud.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer at a puzzle-game studio. It does not show whether that title was run as a live service. Words stay at the quote: "4 years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service line makes a probe on the studio's title likely. If it was run as a live service, say how, in your own words; if it was not, say so plainly and stay with the four years |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe on how the calendar ran. Lead with it in the quote's own terms: you ran the weekly content-drop calendar for your main title, over the last two years. A named cadence beats an adjective |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says weekly content drops for one main title. It does not say live events, and it does not say two titles. Words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ever ran another calendar alongside this one, say how, in your own words; if you did not, say so plainly and stay with the main title |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Your material says you have never led a team and is silent on working with design, art, engineering or community. Coordinating is not leading. Words available: "I've never led a team." Answer slot: if you coordinated with any of those four disciplines on a drop, say which and how, in your own words; if you did not, or that was someone else's job, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | medium | [grounded] | transferability | Your material has monthly retention numbers presented to the studio head. It does not say which measures a review reports, or that a review followed any drop, and it says you have not worked on a game with in-app purchases. Words stay at the quote: "Presented the monthly retention numbers to the studio head." Answer slot: if you reviewed a drop after it shipped, or owned any KPI, say what and how, in your own words; if the monthly retention presentation was the extent of it, say so plainly and stay with it |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it. It does not say you ran it release by release with QA. Words stay there: "Wrote the release checklist our QA team still uses." Answer slot: if you ran it with QA on each release, say how, in your own words; if QA took it from there, or you only wrote it, say so plainly and stay with the checklist you wrote |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in kind, but a one-line claim with nothing inspected behind it, so expect a probe. Lead in the quote's terms: you presented the monthly retention numbers to the studio head. The limit is the pack's observation: the quote says presented, not built or analysed |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | One written artifact is in your material and nothing else. Words stay at the quote: "Wrote the release checklist our QA team still uses." Answer slot: if there are other documents you wrote that others relied on, say which, in your own words; if there are none, say so plainly and stay with the checklist |

## Persona table

The relationship to Tobias is assumed, so these weights are the hiring-manager prior, shown so you can recalibrate. No loop source established the loop, so no archetype tilt is added. No published values were in hand, so no values-style round is detected and there is no values bank. A peer bank is left out because the round is assumed to be with the person who runs the function.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| A Case/Strategist | High, 5 questions | Live problems from the job: plan two calendars, handle a slipping date, diagnose a weak event | High: hiring-manager prior, and the JD's duty verbs (plan, run, coordinate, own, manage) are the kind a live problem can test | Clarify, objective, segments, approach, metrics, risks, aloud; challenge one premise politely |
| B Skeptic | High, 5 questions | Quiet probing of the gaps: in-app purchases, leading, two titles, live-service, why now | High: hiring-manager prior, and you named two gaps yourself, which F4 and F5 carry; F3 and F6 are transferability rows | Rehearse the single most predictable objection (B1) until boring; hold to your own sentences; concede only what you stated |
| C Data-Driven Prober | Mid, 3 questions | Line-by-line questions on the retention numbers and how a drop was judged | Medium: the JD names retention metrics and KPIs (F5, F7) and your one metric-flavored sentence is the retention one | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| D Conversational | Mid, 3 questions | Friendly openers: the journey, what you play, the checklist | Medium: relationship-neutral, and every interview has an opening stretch that is still scored | A 90-second arc built only from your sentences; treat casual questions as scored |
| E Pressure | Low, 2 questions | Time-boxed challenges: why you, how much was you | Low: the prior favors skip-level rounds, but the attribution probe in E2 arrives in any style | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you would plan a live-events calendar for two titles at once. What do you need to know first?" | CASE | [grounded] | Ask before you structure: what each title's events are meant to move, which design, art, engineering and community capacity the two titles share, and which dates are already fixed. Then objective, segments, approach, metrics and risks, thinking aloud, and challenge one premise politely. The question needs no claim about your past, so the guidance makes none | F3 is where the JD's first duty line presses. CASE because it is a live problem; the JD line is its raising source |
| A2 | "A week-one event for one title is going to slip, and the same engineer is needed for the other title's update. What do you do?" | CASE | [generic] | Ask first: what is slipping and why, which date cannot move, who decides trade-offs between titles. Then the options (move it, cut scope, split the release), who needs to hear it among the four teams the JD names and the community, and what you would record for the review afterwards. No claim about your past | F3 and F4 meet in this problem. CASE because it asks about no past; generic because it is a pattern for the problem, not a fact about this employer |
| A3 | "An event's retention numbers come in well below what the team expected. Diagnose it." | CASE | [generic] | Clarify which metric, over what window, for which players. Compare against what the team expected and where that expectation came from. Separate the event from anything else that shipped near it. Say what you would check first, and name the assumption you would defend least before they do. No claim about your past | F5 and F7 are the rows it tests. CASE with a JD source; generic because it is a pattern for the problem |
| A4 | "Which of our two titles have you looked at, and what do you notice about how their events run?" | CO | [generic] | Instruction for before Friday: the JD says two titles and names neither, so find which two they are, play each long enough to see its current events, and note what you saw from the outside. Say what you saw and what you cannot tell from outside, and claim no knowledge of how the studio runs them. If you could not look at them, say so plainly and ask which two the role covers | Research was refused, so the pack cannot ground the company's strategy and this CO question stays generic. F3 is the row it connects to |
| A5 | "Three days before an update, QA flags a blocker and the content team says it can wait. Talk me through what you do." | CASE | [generic] | Ask first: how severe, who is affected, who holds the go or no-go call, what date is fixed. Then the options (fix, cut scope, delay, ship with a known issue recorded), how you tell the four teams and the community, and what goes into the review afterwards. No claim about your past | F6 and F4 meet here. CASE because it is a live problem on the JD's release-checklist duty |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases in your background. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Pause, then concede first, in your own words: "I've never worked on a game with in-app purchases." Name the limit before they ask: what you have presented is "Presented the monthly retention numbers to the studio head." and the purchase side is the part that would be new. Then a plan, said as a plan and never as a past: in the first weeks, ask to read recent post-event reviews, ask which numbers the team reads after an event and who owns each, and ask what the team treats as a good event. Follow-up one: they press that the numbers you presented are not the whole picture; agree plainly and return to the quote. Follow-up two: they ask whether this is a big gap for the role; concede that it is a gap on your side and return to the plan. Follow-up three: they ask who you would lean on; answer in roles you would ask, naming no one. Never add experience to the quote, and never call anything you did similar | F5 carries the stated gap and the adjacent evidence. JD because it scores a stated duty, the KPIs the review reports; it is the objection you raised yourself, aimed where the material is thinnest |
| B2 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. How would you approach coordinating them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Concede first, in your own words: "I've never led a team." The JD's word is coordinate, so answer that: as a plan, what you would ask each of the four teams for and by when, and how you would keep one calendar as the shared reference. Hold your own sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD lists four disciplines, so expect a probe on working with them. If you coordinated with any of them on a drop, say which and how, in your own words; if you did not, or that was someone else's job, say so plainly and stay with the calendar you ran | F4 is a low-confidence discovery row, so the guidance leans on the stated negative and the plan, not on a story. JD because it scores the coordination duty |
| B3 | "Your calendar was weekly and for your main title. This role plans events across two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence as it is: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ever ran a second calendar alongside it, say how, in your own words; if you did not, say so plainly and stay with the main title. Then say what you would ask before two calendars share capacity: what the titles share and where their dates collide. Those are questions, not claims | F3 is the row the pack's observation limits: the quote says one main title and content drops. JD because it scores the stated two-title duty |
| B4 | "You were an associate producer for four years. The role asks for 3+ years producing live-service games or apps. Where do you land against that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Hold the sentence as it is: "4 years as an associate producer at a puzzle-game studio." Do not relabel the title. Answer slot: the JD's live-service line makes a probe on the studio's title likely. If it was run as a live service, say how, in your own words; if it was not, say so plainly and stay with the four years | F1 is a discovery row: the material is silent on live service, so the guidance is a slot. JD because it scores a stated requirement |
| B5 | "Why this role, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Selection scaffold: pick one specific thing from the JD's duty list that you actually want to do, such as the two-title calendar, the post-event review or the checklist with QA, and say why in your own words. Add only sentences you can stand behind. If no clear reason comes to mind, say so plainly, then give the nearest honest one. Never state a reason you do not hold | F1 sits behind it. EXP because it tests motivation consistency against your own history; the JD is its raising source |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the sentence states: monthly, to the studio head. Then the four defend-the-number slots, each in your own words: how the numbers were counted, what they are most sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you built the numbers, say how; if you presented figures someone else produced, or you do not know how one was counted, say so plainly and stay with what you did in the presentation | F7 is the evidence for the retention requirement. EXP because it tests what was actually yours |
| C2 | "Which retention measures would you want on a post-event review, and why those?" | JD | [grounded] | An opinion, not a history. Tie each measure you name to what the event was meant to change, say what it cannot tell you, name the assumption you would defend least, and say where you would ask the team how it defines the measure. The guidance makes no claim about your past | F5 and F7 meet in it. JD because it scores the review duty and the retention line |
| C3 | "After a weekly drop went out, how did you tell whether it had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Answer slot: the JD's post-event review line makes this probe likely. If drops were reviewed afterwards, say how, in your own words, and which part was yours; if there was no review of individual drops, or it was not yours, say so plainly and stay with the monthly retention numbers you presented | F5 is where the material is thinnest: weekly drops, monthly numbers. EXP because it tests whether a review existed and who ran it |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from your sentences, in order: the four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title over the last two years, the release checklist QA still uses, the monthly retention numbers presented to the studio head. Then one sentence on why this role, from the B5 scaffold. Add no turning point or reason the material does not carry; if a link between chapters is real, say it in your own words | F1, F2, F6 and F7 are the rows it draws on. EXP because it is the biography question; scored even when casual |
| D2 | "What are you actually playing in mobile games these days, and what do you notice about how their events run?" | JD | [generic] | Pick one or two titles you actually play and say what you notice about their calendar from the outside. If you do not play mobile titles, say so plainly and use one of Saltmarsh's two titles instead (see A4). The guidance makes no claim about your past | F3 is the duty it touches. Generic because it is a pattern for a rapport question, not a fact about this employer |
| D3 | "Tell me about the release checklist your QA team still uses." | JD | [grounded] "Wrote the release checklist our QA team still uses." | The beats the sentence states: you wrote it, and QA still uses it. Describe it aloud in plain sentences, as you would to someone who has never seen it; that rehearses clear writing. Answer slot: the JD's checklist-with-QA line makes a probe on how it was used likely. If you ran it with QA on each release, say how, in your own words; if QA took it from there, or you only wrote it, say so plainly. If there are other documents you wrote that others relied on, say which; if there are none, stay with the checklist | F6 and F8 are the rows it draws on. JD because it scores the checklist duty and the written-communication line |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events for two titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Anchor in your own four sentences, in your own words, and add nothing to them. Hold through two follow-ups by returning to those sentences, never by adding to them. If pressed on gaps, the concessions available in your own words are the two you stated: "I've never led a team" and "I've never worked on a game with in-app purchases". On anything else, use the B3 slot | F1, F3, F6 and F7 supply the anchors. JD because it scores fit against the duties; Pressure because it is time-boxed and tests composure |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which dates and decisions were yours and which were set by others, in your own words; if others set the content or the dates, say so plainly. Do not fold on the sentence to restore harmony | F2 is the row it presses on. EXP because attribution probes exist to catch inflation |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 "3+ years producing live-service games or apps" | B4, B5, E1 |
| F2 "experience running a content calendar" | B3, D1, E2 |
| F3 "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, A4, B3 |
| F4 "coordinate design, art, engineering and community teams on each update" | A2, A5, B2 |
| F5 "own the post-event review and the KPIs it reports" | A3, B1, C2, C3 |
| F6 "manage the release checklist with QA" | A5, D3 |
| F7 "comfortable with player-retention metrics" | A3, C1, C2 |
| F8 "clear written communication" | D3 |

## Reverse questions

No interviewer profile was available, so none of these is tied to Tobias's own path.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which two titles does this role cover, and how different are their event calendars today?" | The JD names two titles and neither; the answer shows what you would inherit and ties to A1 and A4 |
| 2 | "How is a post-event review run today, and which KPIs does it report?" | It uses the JD's own line and tells you the baseline for F5, including whether purchase figures are part of it |
| 3 | "When design, art, engineering and community disagree about priority, where does the producer sit in that call?" | It uses the JD's coordination line and tells you how much of F4 is influence and how much is decision |
| 4 | "How do QA and the producer share the release checklist today?" | It uses the JD's checklist line and tells you whether the duty is writing it, running it, or both |
| 5 | "What would you want a new producer to get up to speed on first?" | It lets Tobias name what matters on his terms, and turns B1 and B2 into a plan he has already framed |
| 6 | "What would make this hire a clear success by the end of their first three months?" | It gives you a measurable target to work toward, and it shows how the role reads the KPIs in the JD |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Producer of a live-service game for three or more years | Inflated form of F1 | "4 years as an associate producer at a puzzle-game studio." at its own scope. The limit is the pack's observation: the material says associate producer and does not show the title was live-service. B4's slot stays inside the four years |
| Ran the live-events calendar for two titles | Inflated form of F3 | "I ran the weekly content-drop calendar for our main title for the last two years." at its own scope. The limit is the pack's observation: the material says content drops for one main title, not live events and not two titles. B3's slot stays inside the main title |
| Managed the release checklist with QA on each release | Inflated form of F6 | "Wrote the release checklist our QA team still uses." at its own scope. The limit is the pack's observation: the material says wrote, not ran release by release. D3's slot stays inside the checklist |
| Owned the post-event review and the KPIs it reports | Inflated form of F5 | "Presented the monthly retention numbers to the studio head." at its own scope. The limit is the pack's observation: the material says presented, not owned or reviewed. C3's slot stays inside the monthly presentation |
| Led a team | Negative you stated, F4 | The plain acknowledgment: "I've never led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F5 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot; B1 gives the plan |

## Sources

Provided: the JD and the background paragraph in your message. No dossier was present.

Searches sent, each by query:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio strategy news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have moved a values cheat sheet and VAL questions, if the loop turned out to include a values-style round |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | The search was refused. It would have moved the persona weights, which now rest on the assumed hiring-manager relationship |
| 3. `Saltmarsh Games mobile studio strategy news` | unavailable | The search was refused. It would have grounded A4 and D2, which are now generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have moved the interviewer read and a reverse question tied to his path, both absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- How Tobias relates to the role (future manager, peer, senior in a panel) → reweights every bank and the persona table
- The recruiter's prep email, any stated focus areas, and whether a written or presentation exercise is part of the process → a graded-deliverable section, and coverage for F8, which a spoken round tests only through D3
- The names of the two titles the role covers → A4 and D2 become grounded questions, and reverse question 1 gets sharper
- Search access for the values page, the interview process, strategy news and Tobias's public footprint → the persona weights follow a documented loop, the generic CO and CASE items get grounded, and an interviewer read is added; a deeper pass would add a company strategy brief
- Your CV text → F1 to F8 now quote one paragraph in your message; a CV's own sentences would give the guidance more beats to stand on
- A tuesday-dossier.md from an earlier session → verified evidence and a recorded top objection in place of the one inferred here
- If your final is several sessions → send the schedule and the pack becomes per-session mini-packs
