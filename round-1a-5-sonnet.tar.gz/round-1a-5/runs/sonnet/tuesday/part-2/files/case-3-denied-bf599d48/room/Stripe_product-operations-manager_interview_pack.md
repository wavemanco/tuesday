# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer name and relationship: not given. Built with flat persona weights.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Nothing here describes your past, because no CV or background was supplied; where an answer needs your experience, the guidance tells you what to pick and how to say it honestly.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

## Fit snapshot (worksheet variant)

No CV, no background and no job description were supplied, so every evidence cell is empty. The requirements are role-family patterns, not quotes from a Stripe posting. Each one needs your own sentence before it becomes a story.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or changes across several product and go-to-market teams (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a named launch or change you coordinated, the teams involved, and what was yours to decide. Selection scaffold: pick one with a named stake, a date, and more than one team depending on you. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F2 | Designing or improving an operating process or cadence for product teams (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a process you built or changed and how you know it worked. Selection scaffold: pick a process other people actually followed and say how you could tell. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would design one |
| F3 | Using data to diagnose problems and track product or program health (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you used to make a decision and how it was counted. Selection scaffold: pick a figure you can explain end to end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F4 | Influencing product, engineering and business partners without direct authority (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a disagreement or a priority conflict and how it resolved. Selection scaffold: pick one where the other side had a real argument. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one |
| F5 | Working credibly with technical product detail (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a technical or product topic you learned well enough to make a call on. Selection scaffold: pick one and say how you learned it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or your plan for getting there |
| F6 | Communicating status, risks and decisions clearly to senior leaders (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a leadership update you wrote or delivered and what it changed. Selection scaffold: pick one with a clear ask. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would structure one |

## Persona table

Weights are flat. No loop source established Stripe's final round, and you did not say who you meet, so this follows no documented process and no relationship prior. A final round can be several sessions, so the weights blend the priors for a hiring manager, a peer and a skip-level.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Case / Strategist | Live problems about launches, metrics and process | Highest: a hiring manager or a skip-level is likely in a final round, and product operations is a role where live problems are easy to set | Clarify, set the objective, segment, approach, metrics, risks. Think aloud and challenge one premise politely |
| B Skeptic | Quiet probing of why this role, why here, why now, and day-one weaknesses | High: final rounds test whether your story survives cross-examination | Rehearse the most predictable objection until it is boring. Use only adjacent evidence you can state, and say limits plainly |
| D Peer Evaluator | Seam-splitting between product ops and product teams; credit and disagreement | Medium: product operations works beside peers, so a peer session is plausible | Reciprocity framing, seam principles over claimed knowledge, disagreement stories with spine and tact |
| C Values / Behavioral | Scenario probes, STAR-shaped stories | Medium-low here: no published values were in hand and no values round was documented | Pick stories where the hard truth actually landed. Use we for context and I for contribution |
| E Data-Driven Prober | Asks how a number was counted | Medium-low: you will meet it inside other answers whenever you cite a figure | Know how each figure was counted and say plainly when you do not |
| F Conversational | Friendly openers that are still scored | Medium-low: it opens most conversations | A 90-second arc in your own words, and never answer the closing slot with "I think you've covered everything" |
| G Pressure | Time-boxing, devil's advocate | Lower: a skip-level or bar-raiser style would raise it | Pause, restate, hold a position through two follow-ups, concede specifically |

## Question banks

Open prompts take their themes from the persona stems. None presupposes anything about your past.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team wants to ship a significant change to a core product in six weeks. Three other teams are affected. How do you run it?" | CASE | [generic] | Clarify first: what changes, who is affected, what must be true at launch, what can be rolled back. Then state the objective, owners and a readiness check, the risks and a rollback, communications, and a review after launch. Say each step aloud before doing it | Live problem of the kind the role's launch work (F1) invites; CASE because it scores structure |
| A2 | "Adoption of a recently launched feature is 20 percent below plan. Diagnose it." | CASE | [generic] | Clarify the metric's definition, the plan's basis, the timing and the segments. Check instrumentation before hypotheses. Then rank hypotheses and name the cheapest test for each | Tests the data-diagnosis requirement (F3); CASE because it is delivered live |
| A3 | "Several product teams plan and report differently. Design a lightweight cadence that makes work visible across them without slowing them down." | CASE | [generic] | Clarify what leaders need to see and what teams already do. Propose the minimum artifacts, a rhythm, owners, and how you would tell it is working after 90 days. Challenge one premise, such as whether visibility is the real problem | Process-design requirement (F2) |
| A4 | "Two product leads disagree about priorities and both ask you to back them. What do you do?" | CASE | [generic] | Separate the decision from the people. Ask what each is optimizing for, what the data says, and who decides. Name what you would escalate and what you would not. Say what you would do if neither yields | Influence without authority (F4) |
| A5 | "You introduce a new internal process and teams quietly route around it. What now?" | CASE | [generic] | Find out why before fixing anything: friction, unclear value, or a better existing path. Decide whether to change the process or the rollout. Say what evidence would make you drop it | Process adoption (F2); CASE because it is hypothetical |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick a real one from F1 to F6 and say why. Give a concrete ramp plan with a first step and a way to check progress. If you cannot name a weakness truthfully, say so plainly, then give the nearest thing your material does carry, or how you would find out | Skeptic stem; the answer is rehearsed because it will be asked in some form |
| B2 | "Why product operations, why Stripe, and why now?" | EXP | [generic] | The provisional deepest rehearsal. Write three sentences in your own words, one per part, each tied to something you actually did or read. Rehearse two follow-ups: what would make you leave, and what you would do if the role changed shape. If any part has no honest answer yet, say so plainly and work out what you do know | Without a CV the pack cannot identify your single likeliest objection, so this motivation question is the stand-in. Send a CV and it is replaced |
| B3 | "Walk me through your first 90 days here." | JD | [generic] | Learn, map, then ship one small thing. Name what you would ask in week one, whom you would meet, and how you would pick the first improvement. State only what you would do, never what you have already done | Standard probe on whether you can plan without overclaiming (F2) |
| B4 | "How do you earn credibility with a product team that doesn't report to you?" | JD | [generic] | Describe your method in your own words: how you learn their work, what you offer first, how you disagree. Pick a real example if one comes to mind; if none does, say so plainly, then give the nearest thing your material does carry, or how you would approach it | Influence without authority (F4) |

### C. Values / Behavioral

No published values were in hand, so these use persona stems and are not mapped to Stripe's own names.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, the message you gave, and what happened afterward. Use I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; leadership communication (F6) |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a real cost to the metric and say what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | Persona stem |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | JD | [generic] | Offer principles rather than a claimed map: who decides what, how disagreements escalate, what you would never do unilaterally. Ask what the seam looks like today | Peer stem; F4 |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say how you split credit in your own practice. Use a real example if one comes to mind; if none does, say so plainly, then give the nearest thing your material does carry, or the principle you would follow | Peer stem |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity: what you need and what you bring them. Keep the asks small and specific | Peer stem; also feeds your reverse questions |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you've used to make a decision, and walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick a figure you can explain end to end: what it counted, its denominator, what it is sensitive to, and which part of the work was yours. If no such metric comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | Prober stem; F3 |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it in your own words before they do. If you do not know how a figure was counted, say so plainly | Weakest-assumption move |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you started, what pulled you toward operations work, why this role. Each beat must be something you can back with your own material | Conversational stem |
| F2 | "What have you been reading or working on lately that's relevant to this role?" | JD | [generic] | Name one real thing and one view you hold about it. If nothing comes to mind, say so plainly and say what you would start with | Casual questions are still scored |
| F3 | "What do you understand about what Stripe does for its customers, and where would product operations matter most?" | CO | [generic] | No Stripe research ran for this pack, so nothing here is Stripe-specific. Say only what you have read from Stripe's own pages and can source, and give a view of where operations matters. Do not recite figures from memory | Company-knowledge probe; generic until researched |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate. Give two reasons you can back with your own material and say plainly what an internal candidate may have that you do not. Hold through two follow-ups, then concede one specific limit | Pressure stem; hold-then-concede |
| G2 | "Pick the story you're proudest of. How much of it was actually you?" | EXP | [generic] | Name your part precisely and the others' parts plainly. Use we for context and I for contribution. If part of it was not yours, say so and return to what was | Pressure stem; attribution probe |

## Requirement coverage

This is not coverage of a posting, because none was supplied. It maps the role-family requirements above to the question IDs.

| Requirement | Questions |
|---|---|
| F1 launches | A1, B3 |
| F2 process | A3, A5, B3 |
| F3 data | A2, E1, E2 |
| F4 influence | A4, B4, D1 |
| F5 technical fluency | F3, B1 |
| F6 leadership communication | C1, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like for this role at 6 and 12 months?" | Shows you plan against outcomes, and the answer shapes your 90-day plan |
| R2 | "Which product areas does this role touch most, and where is the work least defined?" | Signals you expect ambiguity and want to know where you would be most useful |
| R3 | "How do product teams and product operations decide who owns a problem when it sits between them?" | Raises the seam directly, which a peer or manager will want to discuss |
| R4 | "What is one process that has worked well here and one that hasn't?" | Invites a candid answer and tells you the culture's tolerance for change |
| R5 | "What would a new person do in their first month that would genuinely help your team?" | Reciprocity; useful whether the interviewer is a peer or a manager |
| R6 | "What has surprised you about working here?" | Rapport question that often yields a real answer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None | No candidate sentences were supplied, so nothing exists to inflate, and no negative was stated | Once you send material, this section is built from it. Until then, the guidance above makes no claim about your past |

## Sources

Provided documents: none.

Searches sent, all refused:

- "Stripe operating principles" — refused
- "Stripe interview process product operations" — refused
- "Stripe strategy 2026 news" — refused
- "Stripe Product Operations Manager job posting" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have moved a values cheat sheet; omitted because no published values were in hand |
| 2. `Stripe interview process product operations` | unavailable | Would have moved the loop structure and persona weights; weights are flat |
| 3. `Stripe strategy` / recent news | unavailable | Would have moved the CO bank; F3 is generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have moved the fit-snapshot requirements, which are generic |

## Upgrade menu

- Who you are meeting and your relationship to them → reweights every bank; a name adds an interviewer read and a reverse question tied to their path
- Your CV or a short background → turns the six `none given` rows into rows with your own quotes, builds the real prohibited list, and replaces B2 with your likeliest objection
- The job description text → replaces the generic requirements with quoted ones and adds JD-tagged questions
- Research on Stripe's published values, interview process and recent strategy → a values cheat sheet, named loop rounds, and company-specific CO and CASE questions; it needs search permission
- If your final is several sessions, the schedule → per-session mini-packs
- Your recruiter's prep email → coverage of any announced deliverable or focus areas
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and constraints to build on
