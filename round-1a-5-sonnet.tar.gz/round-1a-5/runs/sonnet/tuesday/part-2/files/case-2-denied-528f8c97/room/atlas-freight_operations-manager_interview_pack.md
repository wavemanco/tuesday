# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager (regional logistics, 800 employees, 4 sites)
**Interviewer:** not known. **Built on one assumption:** a hiring-manager round, because you did not know who you are meeting. Persona weights are therefore a prior, not a read, and are weaker than they would be with a name and round type.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none were in hand, so no VAL questions appear) |
| EXP | Whether your stated experience survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none appear: no research ran) |
| CASE | A live problem set in the role, scored on structure and reasoning |

Provenance labels: `[grounded]` rests on something you or the JD said, quoted beside it. `[inferred]` is a derivation, named. `[generic]` is a role-family pattern with no claim about you or Atlas Freight.

## Prep triage

In this order, each one sitting. Everything else in the pack is insurance.

1. **A1**: the scale question. Rehearse it aloud until the first sentence is boring.
2. **C1 and D1**: write down, in your own words, how the 40% figure was counted, which part was yours, and the assumption you would defend least. If you do not know how it was counted, practise saying so plainly.
3. **A3**: count your leadership years from your own record before the interview.
4. **A2 and C3**: settle your honest Power BI line. Only say you have started learning it if you have, so a hands-on hour beforehand is worth it if you can get one.
5. **E1**: the 90-second arc from your five facts plus your own reason for moving.
6. **B1, B2, B3**: one case each, aloud, using the structure in the persona table.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message; you gave no CV file, so nothing here was inspected.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift's supervisors and the site's surge plan, not terminal operations and not more than one site, and the words stay at that scope: "I'm a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's 4-site line makes a probe on reach likely. If any of your work spanned more than one site, say what and how, in your own words; if none did, say so plainly and stay with the site you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Adjacent, not the same measure: your material says mis-pick rate, not on-time performance. The words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if any of your work was measured on on-time performance, say which measure and how, in your own words; if none was, say so plainly, stay with the mis-pick result, and say what you would measure first |
| F3 | "cost-per-shipment down" — JD | none given | none | [grounded] | discovery | Your material does not establish this. Answer slot: the JD names cost per shipment, so expect a probe on cost. If any figure you owned or influenced was a cost, say which and how, in your own words; if none was, say so plainly and say what you would look at first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The count is 3 against the JD's 12, and the words stay at 3: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have led or coordinated supervisors beyond those three, say how many and in what role; if not, say so plainly and stay with the three you lead |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | medium | [grounded] | discovery | A self-rating with nothing inspected behind it, so expect a probe: "My Excel is solid." Your material does not show whether any of it was reporting others used. Answer slot: if you have built reports in Excel, say what they covered and who used them, in your own words; if you have not, say so plainly and say how you use Excel |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. The JD writes Excel/Power BI with a slash; whether both are required is not shown, which is reverse question R4 |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | The quote says operations years, not leadership years, so the words stay there: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's leadership line makes a probe on how many of those years were leading people likely. Give the count from your own record; if it is under five, say so plainly and stay with what you did |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | presentation | Say it as you said it: "I'm green belt certified." Nothing about the certificate is inspected, so expect a probe on it. Your quote says green belt, not which methodology |

## Persona table

No loop source was read, so the fallback is the generic archetype (screen, hiring manager, panel) with flat tilt, said plainly. The hiring-manager prior then sets the lead personas.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of scale, years and the move itself | High. The hiring-manager prior puts it first, and F1, F4 and F7 are where your material is thinnest against the JD | Rehearse the single most predictable objection (A1) until it is boring; bridge only from what you stated; calibrated candor over bluffing |
| B. Case/Strategist | Live operating problems: diagnose, plan, size | High. Same prior; the JD is outcome-driven (on-time, cost per shipment) so cases are natural | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| C. Data-Driven Prober | Walks your numbers and tools line by line | Medium. You have one quantified result, and the JD asks for reporting | Know how each figure was counted and say plainly when you do not; name your weakest assumption before they do |
| D. Pressure | Interrupts, time-boxes, tests attribution | Medium. Common in manager rounds and aimed at a single large figure like yours | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |
| E. Conversational | Friendly opener that is still scored | Medium-low. Almost every interview opens this way | A 90-second arc built only from your own facts; treat casual questions as scored |
| P. Peer Evaluator | Seam-splitting and credit-sharing questions | Low. Only if a peer sits on the panel; two questions so the style is not new live | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Values/Behavioral | Scenario probes against published values | Low and no bank: no values-style round was detected, since nothing documented one and the generic fallback does not assume one | Leadership behaviours are carried by the A and E banks |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over three supervisors today, and this role has twelve across four sites. What changes for you at that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I'm a senior shift manager over 3 supervisors." Say the difference yourself before they do: twelve is more than three. Then give a plan, as a plan: what you would want to learn at each site before changing anything, and how you would get to know the twelve supervisors, in your own order. Answer slot: if any of your work has involved supervisors beyond those three, say how many and in what role; if none has, say so plainly and stay with the three you lead. Hold through two follow-ups by returning to the three and the plan, never by stretching the count | F4 and F1 are where the JD's scale presses hardest on your material, so this objection arrives in some form; JD because it scores the stated team size |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Name the limit you would honestly name. One you have already stated: "I've never used Power BI." Say it plainly, then what you would do first, as a plan. If your honest answer is a different gap, say that instead; do not borrow a limit you do not hold to look humble, and do not fold on your strengths to seem modest. Concede specifically, once | F6 is the one gap you have stated yourself, so it is the cleanest honest answer available; JD because it scores the whole listing at once |
| A3 | "The role asks for five-plus years of operations leadership. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | The quote says operations years: "I have 7 years in warehouse and distribution ops." Answer slot: give the count of years you led people, from your own record; if it is under five, say so plainly and stay with what you did in those years. Do not convert operations years into leadership years | F7 is a stated requirement with a quote that does not reach it directly, so a literal-minded screen is likely; JD because it scores a written threshold |
| A4 | "Your background is warehouse and distribution; this role is terminal operations. What's different, and what carries over?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path" | If you can, ask first how they would describe a day at one of their terminals, then answer. Describe what you did, in the quotes' own words, and let them draw the link; do not tell them what your work proves. Answer slot: if you have worked in or alongside a terminal, say where and what; if not, say so plainly and stay with warehouse and distribution | F1 is the evidence for the terminal requirement; JD because the term is the JD's, and the guidance does not adopt that terminal and warehouse work differ in any particular way | 
| A5 | "Why leave a senior shift manager role for this one?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Give your actual reason in your own words. The pack has none from you and supplies none. Keep it about what the role offers, and do not offer a reason you do not hold | The motivation probe lands on anyone moving up; EXP because it tests whether your story holds together |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites has dropped by about a fifth over two months. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined and measured, since when, and whether the other sites moved. Then structure: split by site, shift, lane or customer; separate a volume change from a process change; name the first two data cuts you would ask for and the one you would check yourself. State the risk of acting before you know the cause. The question needs no claim about your past, so the guidance makes none | F2's requirement as a live problem; CASE because it scores structure; generic because it is a pattern for the problem |
| B2 | "You start Monday with four sites to run. What do you do in your first thirty days?" | CASE | [generic] | Clarify what is already measured at each site and what the daily report looks like, then a plan in phases: learn each site before changing anything, meet the supervisors, pick two measures to watch, then one change to test. Say what you would not change yet. Keep it a plan, not a history | F1 and F2 as a live problem; CASE because it scores sequencing |
| B3 | "Cost per shipment is higher at one site than at the others. How do you find out why?" | CASE | [generic] | Clarify the definition first: what is in the cost and what the denominator is. Then compare sites like for like before comparing totals, and separate mix from efficiency. Close with the first check and the risk of a misleading comparison. No claim about your past | F3 is a requirement with nothing in your material, so the case is where reasoning can show without a claim |
| B4 | "Peak season is six weeks out and volume forecasts just jumped. What's your surge plan across four sites?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Answer the live problem first, as a structure. If asked about your own experience, use your words: "I ran the site's peak-season surge plan two years running." Answer slot: if asked how that plan was built, answer from what you did; if a part was not yours, or the plan was set elsewhere, say so plainly and stay with what you ran. It was the site's plan, so do not present it as a network plan | F1 holds the quote; CASE because the interviewer scores the structure, with your quote available if they turn to your past |
| B5 | "You inherit twelve supervisors, and two sites run very differently from the rest. How do you decide what to standardise and what to leave?" | CASE | [generic] | Clarify what differs and what each difference is costing or protecting. Then: standardise what is measured and shared (definitions, reporting), leave what the local conditions justify, test one change at one site before copying it. Challenge one premise: that the differences are the problem. No claim about your past | F4 and F8 as a live problem; CASE because it scores a judgement about standardising |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you did in the quote's own terms: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption you would defend least, named before they ask; and which part was yours. If you do not know how it was counted, say that plainly, which is an honest branch. Never describe a method you did not use | F2's only evidence is this number, and a quantified claim is a magnet for probes; EXP because it tests attribution and counting |
| C2 | "The JD lists Lean and Six Sigma as a plus. Tell me about your green belt." | JD | [grounded] "green belt certified" | Start with the quote: "I'm green belt certified." Answer slot: expect a probe on where you have used what the belt covers; say what you actually did, in your own words. If the belt and your work were separate, or you did not use it at work, say so plainly and return to "green belt certified". If you can, say which methodology the belt was in, since the JD names two | F8 is a presentation row with nothing inspected; JD because it scores a named plus |
| C3 | "The role builds reporting in Excel and Power BI. Where are you on each?" | JD | [grounded] "solid Excel"; "never used Power BI" | Say it as it is: "My Excel is solid. I've never used Power BI." Expect a probe on the first half. Answer slot: if you have built reports in Excel, say what they covered and who used them; if you have not, say so plainly and say how you use Excel. Then your plan for Power BI, as a plan, not a past | F5 and F6 are the requirement's two halves with different strengths; JD because it scores the listed tools |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part of the redesign was yours and who else touched it, in your own words; if it was a shared effort, or the idea was not yours, say so plainly and stay with what you did. Concede only what is true and specific; if you do not know how it was counted, say so. Do not fold the core sentence to ease the room, and hold through two follow-ups | F2's number again, in its pressure form; EXP because it tests attribution |
| D2 | "Sixty seconds: why you for this job?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate, then three facts in the quotes' own words, in your order, and let them draw the inference. Include the limit in one clause, using your own words: "I'm a senior shift manager over 3 supervisors." Close with your plan for the part you have not done. Under sixty seconds aloud | F1, F7 and F8 are the strongest rows you hold; JD because it scores fit against the listing |
| D3 | "You ran the site's surge plan. Why would it work across four sites?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Hold what the quote carries: "I ran the site's peak-season surge plan two years running." Do not claim it would work across four; say what you would keep and what you would test at each site. Answer slot: if you coordinated with any other site, say how; if not, say so plainly and stay with the plan you ran. Hold through two follow-ups by returning to the plan | F1 holds the quote; CASE because the interviewer is testing whether you hold a position without overreaching |

### E. Conversational (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | A 90-second arc built from those five facts and nothing else. Add the steps of your own path and your reason for this role in your own words; the pack knows only these five | F1, F2, F7 and F8 are the facts the arc draws on; EXP because it is the CV in spoken form |
| E2 | "How do you work with your supervisors day to day?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Describe it in your own words; the pack holds nothing on your style, so no story is mapped. Answer slot: if asked for an example of a hard conversation with a supervisor, give one only if one comes to mind; if none does, say so plainly, then give the nearest thing your material carries, or how you would handle it | F4 holds the quote; JD because the role is leading supervisors, asked casually and still scored |

### P. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a time work crossed a team boundary and credit was shared: name who did what, use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The collegial form of the D1 attribution probe; EXP because it tests whether your account is precise |
| P2 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Ask which function they run, propose seam principles rather than pretending to know the seam, and give a disagreement process you would use, as a plan. Frame it as what you bring their team as well as what you need | A peer prices the cost of the hire to their own work; CASE because it is a live problem |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A4, B2, B4, D3 |
| "drive on-time performance" | B1, B2 |
| "cost-per-shipment down" | B3 |
| "lead a team of 12 supervisors" | A1, B5, D2, E2 |
| "build reporting in Excel/Power BI" | A2, C3 |
| "5+ years operations leadership required" | A3 |
| "Lean/Six Sigma a plus" | C2 |

No CO question appears: research that would ground one was refused (see Sources).

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and how is it measured?" | It gets the baseline you could not research, and it shows you think in measures before you change anything |
| R2 | "How is cost per shipment calculated here, and which parts of it does this role control?" | The JD names the measure; the answer tells you what you would actually be accountable for |
| R3 | "How are the twelve supervisors spread across the four sites, and what should a new manager learn about them first?" | It shows you are thinking about the team before the process, and gets the structure behind F4's number |
| R4 | "Where does reporting stand today: what's in Excel, what's in Power BI, and which would I build first?" | It tells you whether the JD's slash means either or both, which sizes the one capability gap you have stated |
| R5 | "What would a strong first ninety days look like, and a strong first year?" | It gives you a yardstick to answer against, and rapport-style interviewers weigh this slot as a preparation signal |
| R6 | "Which site is the hardest to run, and what makes it hard?" | It signals you expect to be tested and want the problem, not the brochure |

## Prohibited claims

What this pack will not coach, with the basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a shift's supervisors and the site's surge plan, not terminal operations or more than one site. A4's and D3's slots stay inside the site you ran |
| Led a team of twelve, or a large team | Inflated form of F4 | "I'm a senior shift manager over 3 supervisors." A1's slot asks only whether any supervision went beyond those three |
| Seven years of operations leadership | Inflated form of F7 | "I have 7 years in warehouse and distribution ops." A3's slot asks only for your own count |
| The pick-path redesign improved on-time performance or cost per shipment | Inflated form of F2 | "I cut mis-pick rate 40% by redesigning the pick path." The limit is the pack's observation: the material says mis-pick rate, not on-time or cost |
| Built Power BI reporting, or has used Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." Then a plan, never a past. No slot |
| Led Lean or Six Sigma improvement work as a certified belt | Inflated form of F8 | "I'm green belt certified." The limit is the pack's observation: the material says the belt, with no further detail. C2's slot stays inside the quote |

## Sources

- Provided: the JD text you pasted, and your background as you wrote it in your message. No CV file was provided. No `tuesday-dossier.md` was found.
- Persona weights rest on the generic archetype fallback (screen, hiring manager, panel) and the hiring-manager assumption, since no loop source was read.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Searched "Atlas Freight regional logistics company values": refused. Would have fed a values cheat sheet and VAL questions, if a values-style round was documented |
| 2. `Atlas Freight interview process operations manager` | unavailable | Searched "Atlas Freight interview process operations manager": refused. Would have set loop structure and persona weights |
| 3. `Atlas Freight strategy / recent news` | unavailable | Searched "Atlas Freight regional logistics terminals news strategy": refused. Would have grounded at least one CO or CASE question and a grounding brief |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and the round type → every persona weight recomputed, banks added or replaced, and an interviewer read with a reverse question tied to their path
- A note from the recruiter on format, focus areas or anything to bring or present (a site walkthrough, a presentation) → a build section for each announced deliverable, and coverage that no longer rests on round-type priors
- Your own answers to the slots in A1, A3, C1, C3 and D1, outside a drill → F1, F4, F5 and F7 gain quoted evidence, and their rows regenerate
- Inspectable artifacts: the green belt certificate (F8), the report or scorecard the mis-pick rate came from (F2, C1), a sample of your Excel reporting with sensitive data removed (F5) → confidence on those rows can rise from medium
- Company research: if you allow web search, the default pass (up to 6 searches and 2 fetches) would add Atlas Freight's published values, its documented loop and recent news, and could turn on a values cheat sheet and CO questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a grounding brief and any interviewer footprint
- Whether the JD's role involves travel between the four sites, and its pay and schedule terms (the JD text names none) → any gate rows the posting settles
- A `tuesday-dossier.md` from an earlier run → verified evidence and standing prohibited claims in place of the ones inferred here
