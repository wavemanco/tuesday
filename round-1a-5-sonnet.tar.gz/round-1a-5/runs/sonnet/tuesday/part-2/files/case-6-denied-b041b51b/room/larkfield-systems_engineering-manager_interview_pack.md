# Larkfield Systems — Engineering Manager — three-round interview pack (loop mode)

Candidate: Yusuf. Role: Engineering Manager, Larkfield Systems (industrial IoT, ~600 people).

| Round | When | Who | Length |
|---|---|---|---|
| Round 1 | Tuesday | Director of Engineering — the hiring manager, your would-be boss (name not given) | 45 min |
| Round 2 | The Thursday after | Panel: two staff engineers and a product manager (names not given) | 60 min |
| Round 3 | The following Monday | VP Engineering — recruiter's words: "values and leadership philosophy" (name not given) | 30 min |

Built on: the role description and background in your message only. No JD text, no CV, no interviewer names, and no company research (search permission was not granted), so everything about Larkfield itself is absent or labeled `[generic]`. The loop is established by your own words: three scheduled rounds, each with who runs it, so no archetype fallback is used.

## How to use this pack

- Personas are how a question is asked; types are what is being scored. Each round has its own persona weights and its own bank. The fit snapshot, prohibited claims, sources and upgrade menu are shared.
- Type key: VAL = behavioral or values alignment; EXP = work-experience deep-dive; JD = role and JD-driven; CO = company and strategy knowledge; CASE = hypothetical or live problem.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer either branch from your own experience, in your own words, and say plainly if a practice was not yours or never existed.
- Question IDs are round, persona letter, number: 1A1 is Round 1, persona A, question 1.

## Prep triage

1. Before Tuesday: rehearse 1A1 (hardware roadmap) and 1A3 (managers of managers) aloud until they are boring. This is the highest-ROI prep in the pack, because the same limit returns as 2E1 on Thursday and 3B1 on Monday: one answer, rehearsed once, serves three rounds. Then 1A2 and 1C1.
2. Before Thursday: 2B1 and 2B2, your 60% and your "about 40 interviews". Answer each of the four defend-the-number slots in your own words, and write down what you do not know about how each figure was counted.
3. Before Monday: 3B1 and 3B2. Then choose one real story from your own history for each of 3A1, 3A2 and 3A3, since this pack cannot choose them for you.

Everything else is insurance.

## The fit snapshot (shared)

Requirements are quoted from the role description in your message. Evidence is your own words from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description in your message | "9 years engineering, 3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material shows one team of 6, not two squads, and the role description does not say whether the squads have leads of their own. Words stay at the quote: "9 years engineering, 3 as a team lead of 6." And, sourced to your message: "I haven't managed managers." Answer slot: a probe on the step from one team to two squads is likely. If any of your lead role already involved coordinating beyond your own team, say what and which part was yours; if it did not, say so plainly and stay with the team of 6 |
| F2 | "building device-management services" — role description in your message | none given | none | [grounded] | discovery | Your message says nothing about devices. Answer slot: if any service you worked on managed or talked to physical devices, say which and what part was yours; if none did, say so plainly and say how you would get up to speed |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence says the burden dropped after you pushed the quarter, not that the quarter alone produced the drop, and it shows one reliability quarter rather than ownership of delivery generally. Words stay at the quote: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you did something about the roadmap pressure, say what and with whom; if you did not, or someone else did, say so plainly and return to the quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on which stages are yours and on the figure. Lead with the loop in the quote's terms: you run it, for backend roles. The figure's slots are in 2B2 |
| F5 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the growth part) | none given | none | [grounded] | discovery | Nothing in your message speaks to growing engineers. Answer slot: if you have helped someone grow, say whom and what you did, in your own words; if you have not, say so plainly and say how you would start |
| F6 | "partner with hardware and product on roadmap" — role description in your message (the hardware part) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work, and nothing added to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" — role description in your message (the product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The sentence touches a roadmap but does not show who you worked with or how. Answer slot: if product was part of that quarter, say how you worked it out and which part was yours; if you did not work with product on it, say so plainly and stay with the quarter |

No requirement in the role description is a gate (a term such as location, schedule, pay or authorization), so the snapshot has no gate rows. Location, travel and schedule are not in your material; see the upgrade menu.

## Requirement-coverage line

| Requirement | Questions covering it |
|---|---|
| F1 Lead two squads | 1A2, 1A3, 1B2, 3B1 |
| F2 Device-management services | 1A4, 1B3, 2B3 |
| F3 Own delivery | 1B1, 1B2, 1C2, 2C2, 2D2, 3A1, 3C2 |
| F4 Hiring | 1B2, 2B2 |
| F5 Growth | 1B2, 3A3 |
| F6 Partner with hardware | 1A1, 1B1, 2D1, 2E1, 3A4 |
| F7 Partner with product | 2C1, 2D1, 2D2 |
| Headline figures: the 60% and the "about 40 interviews" | 2B1, 3B2 and 2B2 |
| Industrial IoT context (company knowledge) | 1B3, 3C1 — `[generic]`, none and why: no research ran |

## Prohibited claims (shared)

Built before the banks from the snapshot above; no dossier was present. Every answer slot, hold and bridge in every round is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated, F1 | The plain acknowledgment your message gives: "I haven't managed managers." No slot |
| Led two squads, or led a team of more than 6 | Inflated form of F1 | F1's quote at its own scope: "9 years engineering, 3 as a team lead of 6." The limit is the pack's observation, not words for you: the material shows one team of 6 |
| Owned or shaped a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment your message gives: "I haven't owned a hardware-adjacent roadmap." No slot |
| Cut the team's on-call burden by 60% yourself, or that the quarter alone produced the drop | Inflated form of F3 | F3's quote at its own scope: the burden dropped after you pushed the quarter. The limit is the pack's observation: the sentence says after, not because. 2B1 and 3B2 slots stay inside the sentence |
| Owned hiring decisions, headcount or the whole hiring process | Inflated form of F4 | F4's quote at its own scope: you run the hiring loop for backend roles. The limit is the pack's observation: the material says the loop, not the decisions behind it |

## ROUND 1 — Director of Engineering, hiring manager (Tuesday, 45 min)

### Persona weights

Round-type priors only, since no interviewer profile exists: hiring manager = Case/Strategist plus Skeptic, with a conversational opening assumed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (4 questions) | Quiet, persistent probing of the gaps: hardware, scale, managers | High — the hiring-manager prior, and F1 and F6 are limits you stated yourself, so they are the obvious place to aim | Say the limit plainly first, then a plan. Rehearse 1A1 until boring |
| B. Case/Strategist (3 questions) | Live problems from the role's own work | High — the hiring-manager prior; the role is built on roadmap partnership | Clarify, objective, options, recommendation; think aloud; challenge one premise respectfully |
| C. Conversational (2 questions) | Friendly openers: the journey, the reliability quarter | Medium — likely at the start of a 45-minute conversation with a would-be boss; casual questions are still scored | A 90-second arc built from your own sentence |

### Question bank

**A. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "You've never owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. How will you handle that?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in the pack. Open with the plain acknowledgment your message gives: "I haven't owned a hardware-adjacent roadmap." Then say, as a plan and never as a past, who you would sit down with first and what you would ask them. The only roadmap material your quotes carry is the reliability quarter, which you describe as "I pushed a reliability quarter through against roadmap pressure"; offer it only in those words, and name its limit yourself: it is not a hardware roadmap. Hold through two more levels: what you would ask hardware first, and what you would do when hardware's dates and product's dates disagree. Answer both as plans. Do not describe hardware work you have not done | F6 is the gap you stated and the role's partnering line presses directly on it, so this objection arrives in some form in every round. JD because it scores the stated requirement; Skeptic delivery |
| 1A2 | "You've been a team lead of 6. This role is two squads and 11 engineers. What changes at that size?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Keep your words at their scope: "9 years engineering, 3 as a team lead of 6." Pack observation: your material shows one team, not two squads. Answer slot: if any of your lead role already involved coordinating beyond your own team, say what and which part was yours; if it did not, say so plainly and stay with the team of 6. Then, as a plan, say what you would find out first about the two squads | F1 is the evidence and the scale step is the likeliest second objection. JD because it scores the "two squads" line |
| 1A3 | "Have you managed managers?" | EXP | [grounded] "I've never managed managers" | The plain acknowledgment, sourced to your message: "I haven't managed managers." Then what your material does carry, at its scope: "9 years engineering, 3 as a team lead of 6." Pack observation: the role description does not say the squads have leads, so whether this limit bites is not established; reverse question 1 asks it. Then how you would learn it, said as a plan. No slot and no bridge to experience you did not state | F1 holds the stated negative. EXP because it tests what you actually did; asked bluntly because candidates tend to fudge it |
| 1A4 | "What's the closest thing you've worked on to device-management services?" | JD | [generic] | Selection scaffold: choose something real you can describe in your own words, with what it did and which part was yours. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would get up to speed. Say what you did, not what the service category usually involves | F2 has no evidence, so this question exposes it before the Director does. JD for the "device-management services" line; the guidance is a scaffold because nothing in your message carries it |

**B. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "Hardware tells you a firmware milestone is slipping six weeks and product won't move the customer date. You have two squads. What do you do this week?" | CASE | [generic] | Clarify first: what exactly slips, what depends on it, whether the customer date is a promise or a plan, what can ship without it. Then objective, options with their costs, one recommendation, and who you tell and in what order. Challenge one premise out loud, such as whether the six weeks is firm. The question needs no claim about your past, so the guidance makes none | A live problem from the role's own partnering line (F6, F3). `[generic]` because it is a pattern for the problem, not a fact about Larkfield |
| 1B2 | "It's your first 30 days with two squads. What do you do?" | JD | [generic] | Structure the plan on the role's own words: delivery, hiring, growth, partnering. Say what you would listen for before changing anything and whom you would ask. A plan, not a past: it needs no claim about what you have done | Covers the delivery, hiring and growth lines (F3, F4, F5) in one answer. JD because it scores the stated responsibilities, with CASE delivery |
| 1B3 | "What do you think makes building device-management services for industrial customers hard?" | CO | [generic] | No research ran, so this cannot be grounded in Larkfield's own strategy. Reason from first principles, say "I'd expect" wherever you are reasoning rather than remembering, say what you would want to learn, and ask. Answer only from what you have done | The role is industrial IoT and the company-knowledge slot is a differentiator. `[generic]` is the honest cost of no research; the upgrade menu says what research would change |

**C. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "So — walk me through the journey. How did you get here, and why this move?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc built on the beats the sentence states: 9 years engineering, 3 as a team lead of 6, currently at a payments company. Answer slot: the reason for the move is yours to give; say your actual reason in your own words. If part of it is what you are leaving rather than what you want, say so honestly and end on what draws you to this role. The pack supplies no reason | F1 holds the career line. The casual register is still scored for economy and consistency |
| 1C2 | "I'd love to hear about the reliability quarter. What happened?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Tell it at the sentence's own scope: a reliability quarter, roadmap pressure, and the on-call burden dropping afterwards, in your own words. Answer slot: if you did something about the roadmap pressure, say what and with whom; if you did not, or someone else did, say so plainly and return to the quarter. Do not say the quarter alone produced the drop; the sentence says after. Detailed defend-the-number slots for the 60% are in 2B1 | F3 is your strongest quote and the likeliest friendly entry point. EXP because it tests what was actually yours |

### Reverse questions (Round 1)

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "How are the 11 engineers split across the two squads today, and do the squads have leads?" | The role description leaves open whether there are leads; the answer shows how hard F1's limit presses on the actual seat |
| R1.2 | "Where does hardware's roadmap meet ours right now, and where does it hurt?" | Asks for the seam you have said you have not owned (F6), as someone gathering it rather than claiming it; also feeds Thursday's panel |
| R1.3 | "Ninety days after I start, what would you want to be different about how these squads work?" | Asks the Director to define the job, which tells you what "own delivery" means to your would-be boss |
| R1.4 | "How would you and I split decisions about hiring and growth for the squads?" | Tests the boundary of the role's "hiring and growth" lines (F4, F5) before it is tested on you |
| R1.5 | "What would make you hesitate about me for this seat?" | Invites the objection live, so the 1A1 answer is given where it counts instead of left unspoken |

## ROUND 2 — Panel: two staff engineers and a product manager (Thursday after, 60 min)

### Persona weights

Panel rule: blend the top two personas of each member's relationship. The staff engineers are treated as peers and technical evaluators; the product manager as a cross-functional interviewer. This is an assumption, and your answer to question 1 below could reweight it.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator (4 questions) | Seam-splitting, "what would you need from us", disagreement and credit | High — the peer prior applies to both staff engineers, and the PM's collaboration questions land here too | Reciprocity framing; propose seam principles, not a pretended seam; disagreement stories showing spine and tact |
| B. Data-Driven Prober (3 questions) | Reads your claims line by line; asks for the counting | Medium — a technical-peer prior; your two figures are the obvious targets | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| C. Values/Behavioral (2 questions) | Scenario probes, STAR-shaped stories | Medium — the cross-functional prior for the PM's seat | Choose a story whose hard truth actually landed; where your material shows none, say so |
| D. Case/Strategist (2 questions) | Roadmap trade-offs set in the role | Medium — a PM on a panel for a roadmap-partnering role | Clarify, structure, recommend; challenge one premise |
| E. Skeptic (1 question) | The hardware limit returning in collegial packaging | Low — the objection from other banks returns in collegial form | The same acknowledgment-then-plan as 1A1, word for word |

### Question bank

**A. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Where's the seam between an engineering manager and the staff engineers on a squad, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: say which kinds of decision you would want to make yourself, which you would want staff engineers to make, and which you would make together, and ask where they feel the seam today. The question needs no claim about your past, so the guidance makes none | Two of the three panelists work next to the seat you would take. JD because it scores partnering and delivery (F3); peer delivery |
| 2A2 | "Tell me about a time you disagreed with a senior engineer about technical direction." | VAL | [generic] | Selection scaffold: choose a time with a named stake, what you proposed, how it was decided, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem for disagreement with equals. `[generic]` because no quote of yours carries such a story |
| 2A3 | "What do you need from staff engineers to run two squads well, and what do we get from you?" | JD | [generic] | Reciprocity first: what you would bring them, then what you would ask of them. Say it as how you would work, not as what you have done. The question needs no claim about your past | Peer evaluators price what the hire costs them and gives them. JD for the two-squads line (F1) |
| 2A4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a real example where credit was shared across teams, say what you did with it, and name your part in your own words ("we" for context, "I" for contribution). If no example comes to mind, say so plainly and give the principle you would follow | The persona stem for credit-sharing. `[generic]` because it presupposes nothing about you |

**B. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "Walk us through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words and none filled by this pack. How it was counted: say what "on-call burden" measured; if you do not know how it was counted, say so plainly. What it is sensitive to: say what could move it. The assumption you would defend least: name it before they do. Which part was yours: say what you did; if others did parts, say which. Pack observation: the sentence says the burden dropped after you pushed the quarter, not because of it, so do not claim the quarter alone caused it | The headline figure on your material (F3) and the most probable prober target. EXP because it tests attribution honesty. The weakest-assumption move converts a gotcha into credibility |
| 2B2 | "You run the hiring loop for backend roles, about 40 interviews last year. Which parts of the loop do you run yourself?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say the loop in the quote's own terms: you run it, for backend roles. Defend-the-number slots, in your own words: what the "about 40" counts (interviews you conducted, or interviews the loop held, if you do not know, say so plainly); what it is sensitive to; the assumption you would defend least. Answer slot: if you set any stage of the loop, say which and how you decided; if no stage was yours to set, or there was no such step, say so plainly and describe how you take part. Pack observation: the material says the loop, not hiring decisions or headcount | F4 is the hiring evidence and its figure raises the defend-the-number slots. EXP because it checks which part was yours |
| 2B3 | "Walk us through the architecture of the system you know best. Where would it break if its clients were physical devices on unreliable networks?" | CASE | [generic] | Pick a system you can speak to in your own words and say what it did and what part was yours. Then reason about the question aloud, using "I'd expect" wherever you are reasoning rather than remembering. If you have not worked near devices, say so plainly and say what you would ask first. The guidance makes no claim about what you have built | Staff engineers will test the technical altitude of a manager for a device-management seat (F2). CASE delivery with JD content |

**C. Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Tell me about a time you pushed back on a request from product." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | If the reliability quarter is the story you choose, tell it at its own scope: a reliability quarter, roadmap pressure. Answer slot: who the pressure came from, and what you did about it, are yours to say; if it did not come from product, or you did not handle it, say so plainly and choose another story or return to the quarter. Say what you did and let them draw the inference | The role's product-partnering line (F7) is the raising source, and the quarter is the only roadmap story your quotes carry. VAL because it scores behavior under conflict |
| 2C2 | "Tell me about a time you told stakeholders a date was going to move." | VAL | [generic] | Selection scaffold: choose a real instance with a named stake, what you said and when, and how it was received. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Delivery ownership (F3) includes bad news about dates. `[generic]` because no quote carries this story |

**D. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "Product wants a fleet-wide feature next quarter and hardware says the device firmware can't support it yet. How do you plan the quarter?" | CASE | [generic] | Clarify what the feature needs from the firmware and what can ship without it; set the objective; give options with costs; recommend one; say who you would bring into the room. Challenge one premise respectfully. The question needs no claim about your past | The role's partnering line (F6, F7) set as a live problem the PM will care about. `[generic]` as a pattern, not a fact about Larkfield |
| 2D2 | "Two squads, one quarter, and everyone's priorities are urgent. How do you decide what to stop doing?" | CASE | [generic] | Say how you would ask for the constraints first, how you would make the trade-offs visible to product, and how you would tell the people affected. Think aloud and name your weakest assumption before they do. No claim about your past | Delivery ownership (F3) and product partnering (F7) in one problem |

**E. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2E1 | "You haven't owned a hardware-adjacent roadmap. From where we sit, how would that affect us?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The same acknowledgment as 1A1, word for word: "I haven't owned a hardware-adjacent roadmap." Then reciprocity: what you would ask this panel about where the seam with hardware hurts them, said as a plan. Add no hardware experience and soften nothing | F6 returning in collegial packaging; the rehearsed 1A1 answer should carry over unchanged |

### Reverse questions (Round 2)

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What could a new engineering manager do in the first month that would genuinely help you?" | The reciprocity question for peers: it asks what you can take off their plate |
| R2.2 | "Where do technical decisions get stuck on these squads today?" | Shows interest in the actual seam with staff engineers, not a generic one |
| R2.3 | "What's one thing you wish your manager did differently?" | Invites candor about the seat from the people who work next to it |
| R2.4 | "How do product and hardware requests reach the squads: through you, through the PM, or directly?" | Maps the roadmap seam you said you have not owned (F6, F7) |
| R2.5 | "Think of a recent disagreement between engineering and product here. How did it get resolved?" | Surfaces how conflict is really handled, and is a question for the PM that reads as diligence |

## ROUND 3 — VP Engineering, values and leadership philosophy (following Monday, 30 min)

### Persona weights

The recruiter's own words, "values and leadership philosophy", establish a values-style round. The VP is assumed to be the Director's superior, so a skip-level or executive prior applies as well: Case/Strategist plus Pressure. That is an assumption from the titles you gave me.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values/Behavioral (4 questions) | Scenario and story probes on how you lead | High — the recruiter's own description of the round | Choose real stories; "we" for context, "I" for contribution; choose ones where the hard truth landed, and where your material shows none, say so |
| B. Pressure/Stress (2 questions) | Time-boxed challenge on why you and how much was you | Medium — executive and skip-level prior; also where F1 and F3 get tested hardest | Pause, restate, hold the position your quotes carry through two follow-ups, concede specifically, never fold on the core |
| C. Case/Strategist (2 questions) | Altitude and company-level thinking | Medium — executive prior, strategy-heavy; no research ran so these stay `[generic]` | Clarify, state a hypothesis, say what you would need to know |

A values cheat sheet is omitted: it requires Larkfield's published values in hand, and none were fetched or pasted. See the upgrade menu.

### Question bank

**A. Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "What's your philosophy of leading engineers, and what's a decision that shows it?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Say the philosophy in your own words, separately from the story. If the reliability quarter is the decision you choose, tell it at its own scope and let the interviewer draw the inference rather than telling them what it proves. If no decision comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's own description of the round is the raising source. F3 is the only leadership decision your quotes carry. VAL because it scores behavior against principles |
| 3A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Selection scaffold: choose a time with a named stake, a moment you did not fold, and a relationship intact afterwards. If the reliability quarter is your story, who the roadmap pressure came from is yours to say; if it did not involve leadership, choose another or say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem for this round. A candidate for a leadership seat who cannot pick a real one is the finding |
| 3A3 | "Tell me about an engineer whose growth you invested in." | VAL | [generic] | Selection scaffold: choose a real person, say what you did and what changed, in your own words, and what part was theirs. If no such person comes to mind, say so plainly, then say how you would start with the engineers in these squads. The pack supplies no story | F5 has no evidence in your message, so this is a discovery gap rehearsed honestly. The role's "growth" line is the raising source |
| 3A4 | "If a hardware deadline and your team's priorities pulled opposite ways and you were told to pick the deadline, what would you do?" | VAL | [generic] | A decision you would make, said as a plan: what you would ask first, what you would say to the people affected, and what you would not do. Say what you would do, not what you did. The question needs no claim about your past | F6 and F3 meet here as a values test of candor under pressure |

**B. Pressure/Stress**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3B1 | "Sixty seconds: why you for a manager seat, over someone who has already managed managers?" | JD | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6"; "I run our hiring loop for backend roles — about 40 interviews last year" | Pause and restate the question. Hold what the quotes carry, at their scope: "9 years engineering, 3 as a team lead of 6" and "I run our hiring loop for backend roles." Through two follow-ups, return to those rather than adding to them. Concede plainly and specifically: "I haven't managed managers." Never fold on the core to restore harmony, and never add a claim to win the exchange | F1's stated negative under pressure; the hold is only what your quotes carry |
| 3B2 | "That reliability result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence at its scope: "I pushed a reliability quarter through." Answer slot: if others did parts of it, say which; if it was largely yours, say what you did, in your own words. Concede one thing specifically: the sentence says the burden dropped after the quarter, not because of it. Do not claim the whole 60% | The persona stem for attribution under pressure (F3). The honest branch is a strength, not a retreat |

**C. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Where do you think an industrial IoT company like ours wins and loses over the next three years?" | CO | [generic] | No research ran, so you cannot ground this in Larkfield's own strategy. State a hypothesis early, say what you would need to know to test it, and ask the VP where they see it. Say "I'd expect" wherever you are reasoning. Do not recite anything you have not read | The altitude question that separates candidates at VP level. `[generic]` is the honest cost of no research |
| 3C2 | "If you could change one thing about how the two squads work in your first 90 days, what would it be?" | CASE | [generic] | Say what you would look at first and why you would not decide before looking. Name your weakest assumption, then ask the VP what they would change. The guidance makes no claim about what the squads currently do | Delivery ownership (F3) at an executive's altitude: judgment and restraint |

### Reverse questions (Round 3)

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What have the best managers here done that others haven't?" | Shows you are studying the standard you would be held to, in a values round |
| R3.2 | "How does the company decide when reliability work wins against roadmap?" | Ties directly to your one leadership story (F3) without claiming more than it says |
| R3.3 | "Where is the biggest tension between engineering and hardware at the company level?" | Seeks the altitude of F6's seam rather than a team-level version |
| R3.4 | "How do you like to hear bad news?" | A leadership-philosophy question aimed at the VP's own practice |
| R3.5 | "What would make you say no to a candidate for this seat?" | Invites the objection at the highest level, so 3B1's answer is heard in context |

## Sources

Provided documents: your message (role description, round schedule, your background). No dossier was present and no other documents were supplied.

Searches sent, all refused (search permission was not granted), so nothing was returned:

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems engineering manager interview process" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have moved a values cheat sheet for Round 3 (named values with mapped stories) and VAL question themes; none were available, so section 10 is omitted |
| 2. `{company} interview process {role family}` | unavailable | Would have moved the loop detail inside each round; your own words establish the three rounds, so persona weights rest on round-type priors |
| 3. `{company} strategy` / recent news | unavailable | Would have moved the company-knowledge questions 1B3 and 3C1 from `[generic]` to grounded |
| 4. `{interviewer name} {company}` | n/a | No names were given, so there was no query to form; there is no interviewer read |
| 5. representative `{role title}` JD | skipped | The role description in your message supplies the requirements the fit snapshot and JD-tagged questions rest on |

## Upgrade menu

- Search permission → Larkfield's published values, its loop structure and recent strategy: a values cheat sheet for Round 3, and 1B3 and 3C1 move from `[generic]` to grounded
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; offered once, needs search permission) → a strategy brief that would sharpen the company-knowledge questions
- The full job description text → the quoted requirements replace the summary, and more JD-tagged rows become precise
- Your CV → evidence cells beyond your message; F2 and F5 may move from discovery toward grounded
- Your answers to the answer slots (coordination beyond your team in F1, device-adjacent work in F2, growth in F5, product partnering in F7) → those rows regenerate with your own words
- The interviewers' names → an interviewer read, persona weights tuned to each, and reverse questions tied to their paths
- The recruiter's guidance on format (an exercise, presentation or case inside the panel, or a pre-declared deliverable) → a build section for it
- A tuesday-dossier.md from an earlier assessment of this role, if you have one → underwriter-verified evidence and a named objection; not needed for this pack
