# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Format:** one 60-minute conversation (from your message).

Built on one assumption: the conversation is a single peer-to-peer session with no pre-declared deliverable, because none was mentioned. Web research did not run (see Sources), so Northwind's values, loop and strategy rest only on your research note.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script. Any line in quotation marks inside the Provenance column is a sentence from your message, and the guidance leans only on those.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the traits the company or interviewer cares about |
| EXP | Work-experience deep-dive | Whether the claims on the CV survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether she can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

**Highest-ROI prep: D1** (weakest-at-day-one, built from the stated gap in F7). Second: A1 and F2 (the ~$400M figure, counted and attributed).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message; "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | transferability | Your material says product strategy and ops and annual volume targets with cross-org consensus, with nothing inspected behind either. Words stay at that scope: "I spent nine years in product strategy and ops, and I set annual volume targets with cross-org consensus." Answer slot: the JD asks about owning go-to-market for new lines, so expect a probe on whether any of that work was go-to-market. If some was, say which and what part was yours, in your own words; if none was, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | low | [inferred] | discovery | The quote touches revenue growth but does not show whether it was about landing, adopting, expanding or renewing. Answer slot: if the change was aimed at one of those stages, say which and how you saw the opening, in your own words; if it was not framed that way, say so plainly and stay with what you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms and nothing more: "I'm skilled in SQL and Tableau." Answer slot: expect an ask to walk through one analysis end to end. If you ran one yourself, walk through it in your own words; if the work was done with or by others, say so plainly and describe your part |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations with carriers, not the design of how a company works through partners. The words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if the model shaped how partners were engaged or compensated, say how in your own words; if it supported negotiations only, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms: "I set annual volume targets with cross-org consensus." A CV-level claim with nothing inspected behind it, so expect a probe on it. Lead with the targets and the consensus in the quote's own terms |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | The quote says use of AI tools, and the words stay there: "I use AI tools daily." Your material does not show building, shipping or evaluating an AI product, and none is claimed. Answer slot: name the tools and one concrete use in your own words if asked; if you cannot name one, say so plainly |
| F7 | Sales-ops and quota-setting fluency, which a Sales Strategy peer works in daily (not a line in the JD highlights supplied) | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to quota work, and nothing added to make the gap feel smaller |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran go-to-market strategy | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says product strategy and ops, not go-to-market. Slots stay inside that scope |
| Set sales quotas, or that annual volume targets are quotas | Negative the candidate stated, F7, and inflated form of F5's quote | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." F5's quote at its own scope. No slot equates the two |
| Delivered, drove or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: she proposed the change, and it was credited with the uplift. Limit is the pack's observation: the material does not say how much of the figure was hers |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations |
| Built, shipped or led an AI product or copilot | Inflated form of F6 | F6's quote at its own scope: use of AI tools |
| Ran independent SQL or Tableau analyses as a stated practice | Inflated form of F3 | F3's quote at its own scope: skilled in SQL and Tableau. D-bank and A4 use a selection scaffold, not a story |

## Reading the interviewer

Public footprint here is only what your message says about Dan. Nothing was researched.

| Signal | Implication for this conversation | Provenance |
|---|---|---|
| Self-describes as "relentlessly data-driven" | Every metric you cite will be taken to its assumptions. Define a metric before quoting it, and say what you do not know about how a figure was counted | [grounded] your message |
| Career spine in pricing and monetization roles | His native language is packaging, pricing and unit economics. Cases land best when framed there, and the F4 revenue model is the natural bridge, at its own scope | [grounded] your message |
| One early-stage-startup chapter | Expect a probe on pace and scrappiness. Builder stories land well, but this pack finds none in F1 to F7, so none is offered | [grounded] your message |
| Peer reporting to the same VP | He is pricing what you cost and add to his work, so reciprocity framing beats a pure ask | [grounded] your message |

Mirror opportunities: none offered. No fit-snapshot row's evidence carries a candidate side of a shared career jump, and shared identity is never a strategy.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Takes every number and analysis to inputs and assumptions | Highest, 5 questions. Peer prior, raised by "relentlessly data-driven"; F2's ~$400M figure is the magnet | State what you do and do not know about how each figure was counted; name the weakest assumption before he does; offer an analysis walkthrough only if you ran one |
| B. Peer Evaluator | Seam-splitting, "what do you need from me", credit and disagreement | High, 4 questions. Peer prior for this relationship | Reciprocity first; propose seam principles, not a pretended seam; stories that show spine and tact together, only from F5's quote |
| C. Case / Strategist | Live problems on Northwind's own priorities, in pricing language | Medium, 3 questions. Peer round, tilted by his pricing spine and by your research note | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D. Skeptic | Quiet probing of the sales-ops gap and the partner-motion and B2B stretch | Medium, 3 questions. F7 is a stated gap and F4 is transferability | Rehearse D1 until boring; plain acknowledgment, ramp plan, no bluffing a competency he owns |
| E. Conversational | Friendly opener and an AI aside | Low, 2 questions. A peer chat starts warm, but the JD flags AI as a plus | A 90-second arc; treat the AI question as scored |
| F. Pressure | Time-boxed challenge on why you and how much was you | Low, 2 questions. Peers rarely stress-test, but a data-driven one may squeeze attribution | Pause, restate, hold two follow-ups, concede specifically |

Loop basis: your message establishes one 60-minute session with one peer, so no archetype fallback is used. No values-style round is documented, so there is no values cheat sheet.

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Tell it at the quote's scope: you proposed a change, and it was credited with the uplift. Answer slot: how the figure was counted, what it is sensitive to, and which part was yours. Give each in your own words; where you do not know, say plainly that you do not know how it was counted. Never supply a method you cannot repeat under a second question | F2 carries the headline figure and a data-driven peer will go to it first. EXP because it tests attribution and counting |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the weakest assumption you know of, in your own words, before he does. Answer slot: if you know of none, or never saw how the figure was built, say so plainly and say what you would ask first. Do not invent an assumption | The persona stem for a metric, and the credibility-gaining move. EXP because it scores self-knowledge about F2 |
| A3 | "Walk me through the partner-level revenue model that was used in carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: a revenue model, partner-level, used in carrier negotiations. Tell them in your own words. Answer slot: which parts were yours to build and which were handed to you; if it was built with others, or some inputs were given, say so plainly. Stay with the model, never a partner motion | F4's only evidence and the nearest thing to the partner-motion requirement. EXP because it tests what was actually built, and the JD tag follows in D2 |
| A4 | "Tell me about an analysis you ran in SQL or Tableau, from question to answer." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold, since no quoted sentence names an analysis: pick one where you can state the question, the data you pulled, what you found and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is that you are skilled in SQL and Tableau | The JD asks for independent analysis in these tools, and F3 holds one line. JD because it scores the stated requirement; EXP delivery |
| A5 | "Take land, adopt, expand and renew. Which metric would you look at first at each stage, and which would you trust least?" | JD | [grounded] JD line "identify whitespace across land/adopt/expand/renew" | Structure it: what each stage is meant to show, one leading and one lagging indicator, then name the metric you trust least and what data you would pull in SQL to check it. Ask what Northwind's own definitions are before assuming them. The question needs no claim about your past, so the guidance makes none | Covers F2's JD line as a live problem, in the metric language a data-driven peer scores. JD content, CASE delivery |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between Sales Strategy and GTM for new products, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a pretended seam: who owns which decision, what data settles a disagreement, how it escalates to the shared VP. Ask how it works today before proposing anything. Reciprocity framing: what your work gives his team, not only what you need. No claim about your past | The peer's native question. JD because cross-functional influence is a listed requirement (F5); generic because it is a pattern for the problem, not a fact about Northwind |
| B2 | "Tell me about a time credit for a result had to be shared across teams." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: annual volume targets, with consensus across orgs. Tell it in your own words. Answer slot: if credit was shared or contested, say what happened and what part was yours; if no such situation arose, or credit was not an issue, say so plainly and stay with the targets and the consensus | Credit-sharing is a listed peer stem, and F5 carries the only quoted cross-org work. VAL because it scores partnership behavior |
| B3 | "What would you need from my team in your first 90 days, and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau" | The reciprocity question. Needs: name what you would ask for first, in your own terms. Bring: only what you can stand behind, which the quote scopes as skill in SQL and Tableau. Add nothing about sales-ops fluency | Peers price what the hire costs and adds to their work. JD because it tests collaboration against the role, using F3 |
| B4 | "How would you win agreement on a go-to-market plan from a team that owns a quota and does not report to you?" | CASE | [grounded] "set annual volume targets with cross-org consensus" | Structure it: clarify what the team is measured on, find the shared objective, test the plan against their constraints, agree a metric and a review point. Where one of your own sentences fits, use it at its scope: you set annual volume targets with cross-org consensus. Answer slot: if you got that consensus by a particular route, say how in your own words; if it was not your route to choose, say so plainly | F5's requirement as a live problem, aimed at the seam with Dan's own team. CASE because it asks about a plan, not a past |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass, the AI copilot, is launching. How would you size the whitespace and sequence land versus expand?" | CASE | [grounded] your research note: Compass launch | Clarify first: which segment, what the pricing and packaging are, what the success metric is. Then objective, segments, sequencing logic, metrics, risks; challenge one premise, such as whether Compass lands as an add-on or a new line. Do not invent Compass facts you were not given. No claim about your past | One of Northwind's three stated priorities, from your note, and F2's whitespace requirement. CASE with CO content |
| C2 | "A much larger platform vendor is bundling a competing capability into its suite. How does that change our partner and pricing motion?" | CO | [grounded] your research note: bundling threat | Clarify which product line and customer segment first. Then where a bundle bites (standalone buyers versus suite buyers), the pricing and packaging levers, and what a partner can add that the bundle cannot. Challenge the premise: is the threat price, distribution, or both? Dan's pricing spine makes the pricing angle the one to sharpen | The main competitive threat in your note, in his native pricing language. CO because it tests altitude on the company's own strategy |
| C3 | "Profitability is a stated priority alongside enterprise expansion. How would you decide which of the two new lines gets go-to-market investment first?" | CASE | [grounded] your research note: profitability and enterprise expansion | Ask what you need first: the unit economics and stage of each line. Then a decision rule: payback, expansion potential, strategic fit, risk. Say which data you would pull and where the rule could fail. No claim about your past | Probes F1's requirement of owning go-to-market for two lines, against the profitability priority. CASE because it is a live allocation problem |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | The highest-ROI rehearsal in this pack. Level 1: plain acknowledgment, from the stated negative: "I haven't had classic sales-ops or quota-setting experience." Then a ramp plan said as a plan, never a past: what you would learn first and from whom. Level 2, if he says the volume targets sound like quotas: give your own quote at its scope, "I set annual volume targets with cross-org consensus", and answer slot: how those targets were set, in your own words; if you do not know how they compare to quotas, say so plainly and do not adopt the comparison. Level 3, if he asks how fast you would close the gap: a dated plan, no claim of closure. Hold the acknowledgment through all three; never fold on the core by overselling, and never concede more than the stated negative | F7 is the biggest stated gap and a Sales Strategy peer owns that function, so this arrives in some form. JD because it scores fit against the role; Skeptic because it probes the gap |
| D2 | "Tell me about a partner motion, a way a company reaches customers through partners, that you have shaped." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Selection scaffold, since the quote says a revenue model, not a motion: pick the nearest work, say what the model was for and who used it. Answer slot: if the model shaped how partners were engaged or paid, say how in your own words; if it supported negotiations only, or the motion was designed by others, say so plainly. Limit stated as the pack's observation: the material says a revenue model used in carrier negotiations. Never claim the motion | The JD says partner-motion design experience is required, and F4 is transferability, not a match. JD because it scores a stated requirement |
| D3 | "Why this move, why Northwind, why now?" | JD | [generic] | Selection scaffold: your material states no reason for the move, so none is supplied. Pick the reason you can actually defend and tie it to one of Northwind's stated priorities from your note, enterprise expansion, Compass or profitability, only if it is genuinely yours. If no specific pull comes to mind, say so plainly and give the nearest true reason | Motivation consistency is what a Skeptic scores, and the move from consumer tech to B2B data infrastructure will draw it. JD because it tests commitment to this role |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quote states: two years in strategy consulting, then nine in product strategy and ops. Answer slot: why each move, in your own words; if there was no single reason, say so. End on the part of the JD you most want to talk about | Almost every conversation opens here and it is scored. EXP because it checks the CV's spine |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at the quote's scope: you use AI tools daily. Answer slot: name the tools and one concrete use in your own words; if you cannot name one, say so plainly. Never imply you built or shipped an AI product | The JD lists AI experience as a plus and Compass is a stated priority, so it comes as a casual, scored question (F6) |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has run quota and territory planning?" | JD | [grounded] "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations"; "No classic sales-ops or quota-setting experience" | Pause and restate. Hold: lead with those two quotes at their own scope. Concede once, specifically: "I haven't had classic sales-ops or quota-setting experience." Do not fold on the core, and do not claim the comparison is equal | The persona stem for a peer weighing a quota-experienced alternative. Built from F7, F5 and F4 |
| F2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quote: you proposed the change, and it was credited with the uplift. Answer slot: who else contributed and which parts were theirs, in your own words; if you cannot separate the shares, say so plainly. Hold through two follow-ups by returning to what you proposed, never by adding to it | The classic attribution probe on F2's headline number, in a time-boxed register |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | D1, F1, C3, C1, D3 |
| identify whitespace across land/adopt/expand/renew | A5, C1 |
| run independent analysis in SQL and Tableau | A4, B3 |
| partner-motion design experience required | D2, A3, C2 |
| strong cross-functional influence | B1, B2, B4 |
| AI experience a plus | E2, C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization roles, with an early-stage chapter. What did that chapter change about how you build a go-to-market from a blank page?" | Ties to his own career as described in your message and turns the conversation toward his judgment, not your CV |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: shows you are thinking about his load |
| R3 | "Where do Sales Strategy and Emerging Products overlap today, and where would you like a clearer line?" | Puts the seam from B1 on the table in his words |
| R4 | "Which metric on the two new lines do you trust least today, and what data is missing?" | A data-driven peer will have a real answer, and it shows you went to the weakest assumption first |
| R5 | "How is the bundling pressure from the larger platform vendor showing up in the deals and pricing you see?" | Uses the competitive frame from your research note and invites his first-hand view |
| R6 | "What does a strong first six months look like in this seat, from where you sit?" | Gets his definition of success and a peer's honest expectation |

## Sources

Provided: your message (role, JD highlights, candidate summary, interviewer profile summary, research note on priorities and competitive threat). Dan's profile and the research note are your summaries; no document was pasted or linked. No dossier was present.

Searches sent, all refused (permission not granted), none returned a result:

- "Northwind Data company values" — refused
- "Northwind Data interview process strategy GTM" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The one call was refused. It would have named published values for VAL questions; none are used, and no values-style round is detected anyway |
| 2. Interview process and role-family loop | unavailable | The combined call was refused. Your message already establishes one session with one peer, so persona weights follow that and no archetype fallback is used |
| 3. Northwind strategy and recent news | unavailable | The same combined call was refused. The CO and CASE questions rest only on your research note, which is undated, so they are labeled grounded to it and nothing more |
| 4. Interviewer, Dan Kovac | unavailable | The call was refused. The interviewer read rests only on your summary of his profile |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions, though not the mid-list items a full text would add |

## Upgrade menu

- The full JD text → mid-list requirements get their own quoted rows and questions, and the six JD lines in F1 to F6 become exact quotes
- The CV sentences behind each claim, in the candidate's own words → F1 to F6 evidence cells become her sentences rather than your summary, and A1, A3, B2 and E1 become richer story maps
- Her answers to the slots, outside a drill → A1, A2, F2 (how the figure was counted and her share), D2 (how the model shaped partner work), F3 and A4 (an analysis she ran), and B4 (how consensus was reached)
- Anything the recruiter said about focus areas, a case or a pre-declared deliverable → a graded-deliverable section, or reweighted banks
- Search permission, so the L1 targets can run → a published-values check, any documented loop, current strategy and Dan's public footprint. A deeper research pass (L2, up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and Dan's talks and writing; offered once
- A `tuesday-dossier.md` from an earlier role check → graded evidence and absolute prohibited claims in place of the locally built list above
