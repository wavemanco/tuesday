# Interview pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara. Loop mode: three rounds on 4 December 2026.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 min | Conversation |
| 2 | The Head of Member Services, who would be your manager | 45 min | Mostly behavioural |
| 3 | A panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: rehearse it aloud, in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience survives scrutiny, and what was actually you |
| JD | The posting's stated responsibilities and requirements, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem |

Two kinds of cell to know. An answer slot is an instruction for the interview: say what happened in your own words, or say plainly that the practice was not yours or never existed. A selection scaffold is for a question none of your sentences carries: pick a real instance, and if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it.

## Prep triage

Nine days to 4 December, and all three rounds fall on the same day. Your hours per day are not known, so this is an order, not a timetable.

1. D1, the contact-centre objection. Say the first sentence until it is boring. It is the highest-ROI prep in this pack.
2. H1, the 20-minute case. Rehearse it aloud twice with a timer; it is a third of the panel round.
3. G1 to G4. Find one real instance per value. The panel scores against them, and a scaffold is not a story.
4. B3, B4, E1 and E2. Work out what the complaints log and the spreadsheet actually held; the answer slots turn on it.
5. A3 to A6. Write one line each for pay, notice, location and your reason for moving; round 1 asks all four.

Everything else is insurance.

## The fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD, branch side | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's complaints log, not the end-to-end process, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any later stage was yours, say which and what your part was, in your own words; if the log was the extent, or the later stages were not yours, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact-centre side | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: what you would find out first about how complaints reach and leave the contact centre before changing anything. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your sentence says a monthly complaints spreadsheet, not what it counted, so the bridge stays at the spreadsheet: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted volumes, resolution times or both, say so; if it counted something else, say what; if it counted neither, say so plainly and say what you would put in it first |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Training new tellers on a script is adjacent to coaching supervisors, and the bridge stays at that scope: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on working with people at supervisor level likely. If you coached a supervisor or colleague through a live escalation, say who, what, and what your part was, in your own words; if the training was the script and no more, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital team on any member-facing journey, say what and what your part was; if not, say so plainly and say what you would ask a digital team first about where members get stuck |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote already reaches the years in other terms: "I have six years in retail banking, the last three as a branch supervisor." Retail banking and customer operations are different words, so expect a probe on what the work covered. Answer slot: describe the work in your own words; if part of it was not customer-facing, say so plainly and stay with what was |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" does not say regulated, and the sentence does not say whose rules the log followed. Answer slot: if the log was kept under a regulator's rules or deadlines, say which and what they required of you, in your own words; if it was an internal log, or the regulated steps were someone else's, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A limit you have stated. Words: "I've never presented to anyone above regional level." Then a plan, never a past: how you would prepare for your first leadership audience. The pack's own observation: your material does not say whether regional level counts as senior leaders here, or that you have presented at regional level, so no claim is made about either |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your sentence says a spreadsheet, not Excel. Answer slot: if you built it in Excel, say so and what it did, in your own words; if it was another tool, say so plainly and stay with the spreadsheet you built |

## What Ashgrove's strategy brief gives you

The July 2026 brief is about four months old. The lines below are the ones you supplied. Use members, hubs and the values' own phrases in answers.

| Brief or values-page line | Where it touches this role | Provenance | Rehearsed in |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | The JD's self-service journeys line | [grounded] | L1, H4, D3 |
| Consolidate eight branches into five hubs over 2027 | The "Neighbours, Not Numbers" value, and the branch managers on your panel | [grounded] | H3, round 1 reverse question 3 |
| Launch a small-business lending product in Q1 2027 | Nothing in the JD ties to it; know it exists and do not speculate about its complaints | [grounded] | none |
| The main competitive pressure is app-only banks | What a credit union's complaints process can do that an app cannot | [grounded] | H4, A2 |

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; pay, notice, location, reason for moving | High: recruiter-screen prior, and the recruiter described this round as a conversation | A tight biography arc; treat casual questions as scored |
| Skeptic (light) | Quiet knockout checks against the posting's requirements | Medium: the recruiter-screen prior adds a light Skeptic, and F2, F6, F7, F9 are where a knockout check lands | Say the plain acknowledgment first, then the nearest thing your material carries |

## Question bank

### Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background and what brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in three beats, each only what its quote says: the six years in retail banking, the last three as a branch supervisor; the complaints log you handled and the new tellers you trained on the escalation script; the monthly complaints spreadsheet you built. Keep each beat at its own scope. Answer slot: why this role is yours to say, in one or two sentences in your own words; the pack does not know your reason | The opening biography is scored for economy. It draws on F6, F1, F4 and F3, so it is EXP: it tests whether the story is told without growth |
| A2 | "What do you know about Ashgrove, and why a member-owned credit union?" | CO | [grounded] | Use only what you have read: the four published values by name, and the strategy brief. The 40% digital move by 2028 is the line that touches this role most. Say what draws you in your own words; if no personal reason comes to mind, say so plainly and say what on the values page held your attention. Do not predict Ashgrove's plans, and do not describe app-only banks as weak | Motivation is scored at every screen; CO because it tests homework depth, and the brief is the research behind it |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot. Give your own figure or range in your own words, or ask for the role's band first and respond to it. The pack holds no figure of yours and supplies none. If asked what you earn now: "I'd rather focus on the range for this role." | A pay question is standard at a recruiter screen; JD because it concerns the listed job's terms |
| A4 | "What is your notice period, and when could you start?" | JD | [generic] | Logistics slot. Give your actual notice period and the earliest start date you can honestly commit to. The pack supplies neither | Notice is a standard screen item; JD because it concerns the job's start |
| A5 | "Does the location and working pattern work for you?" | JD | [generic] | Logistics slot. State where you can work and how often, in your own words. The JD names no location, so if you are unsure where the role sits across branches or hubs, ask the recruiter (round 1 reverse question 3) rather than guess | Location is a standard knockout; JD because it concerns the job's terms |
| A6 | "Why are you looking to move?" | EXP | [generic] | Logistics slot. Say your reason in your own words, in one sentence, with no criticism of anyone you work with. The pack supplies none | Recruiters score consistency between this answer and the one to A2; EXP because it tests the story's consistency |

### Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as the branches. Where does your experience sit on that side?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Start with the plain words: "I haven't worked in a contact centre." Then the side you do have, at its own scope: "I handled the branch's formal complaints log." Then a plan, never a past: say what you would learn first about how complaints reach and leave the contact centre before changing anything. Do not describe branch work as equivalent | F2 is the stated gap and F1 the nearest adjacent work; a screen checks the gap first. JD because it scores a stated requirement |
| B2 | "The posting asks for four or more years in financial-services customer operations. How does your background fit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it once, in those terms: "I have six years in retail banking, the last three as a branch supervisor." Answer slot: if asked how the branch work counts as customer operations, describe the work in your own words; if part of it was not customer-facing, say so plainly and stay with what was | F6 is the years requirement; a knockout check at a screen. JD because it scores a stated requirement |
| B3 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log" | Hold to the quote: "I handled the branch's formal complaints log." Answer slot: if the log was kept under a regulator's rules or deadlines, say which and what they required of you, in your own words; if it was an internal log, or the regulated steps were someone else's, say so plainly and stay with the log. Do not call your work regulated unless you can say which rules | F7 is where the probe lands; the label is `[inferred]` because the quote touches the requirement without showing it. JD because it scores a stated requirement |
| B4 | "How comfortable are you with Excel reporting?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Hold to the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it in Excel, say so and what it did, in your own words; if it was another tool, say so plainly and stay with the spreadsheet you built | F9 and F3 are the rows behind it; `[inferred]` because the quote does not name Excel. JD because it scores a stated requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What happens after the panel, and when would you expect decisions to be made?" | Closes the logistics loop and signals you are planning, not just attending |
| 2 | "Is the case material for the panel shared beforehand, and is there anything the panel would like me to bring?" | Tells you whether to prepare H1 cold or with material, and shows you are treating the case as a graded piece |
| 3 | "Where will the role be based, and how does that change as the 2027 hub changes happen?" | Ties to the brief's hub consolidation and settles A5's open point |
| 4 | "How does the Head of Member Services think about the behavioural round: which behaviours matter most?" | Uses the recruiter's own description of round 2 to aim round 2 prep |
| 5 | "Does the contact-centre team report into this role today, or would that be built over time?" | Shows you read the JD's contact-centre scope, and tells you how heavy F2 will be |

---

# Round 2: the Head of Member Services, your would-be manager (45 minutes)

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scenario prompts, STAR-shaped stories | High: the recruiter said this round is mostly behavioural, which lifts it above the hiring-manager prior | "We" for context and "I" for contribution; stories where the hard truth landed, and if your material shows none, say so rather than supplying the ending |
| Skeptic | Quiet, persistent probing of the gaps | High: hiring-manager prior, and this interviewer would be your manager, so they are pricing the risk of hiring someone with F2 and F8 | Rehearse the most predictable objection until it is boring; bridge only from adjacent evidence you stated; concede the rest plainly |
| Data-Driven Prober | Reads your claims line by line | Medium: reasoned from the recruiter's description of a behavioural round, which still tests what you did; no names or profile to adjust it | Know what each claim does and does not say; say plainly when you do not know |
| Case / Strategist | One live problem | Medium, lowered: the hiring-manager prior is case-heavy, but the recruiter said mostly behavioural | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Pressure | Time-boxes, challenges motives | Low: no signal for it; its register arrives only inside D1's follow-ups | Pause, restate, hold two follow-ups, then concede specifically |

## Question bank

### Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached a colleague through a difficult escalation." | EXP | [grounded] "trained new tellers on our escalation script" | Story-map on the quote: "I trained new tellers on our escalation script." Tell that in your own words. Answer slot: the JD's coaching line raises a probe on live escalations. If you coached someone through one, say who, what, and what your part was; if the training was the script and no more, say so plainly and stay with the tellers | F4 is the nearest evidence for the coaching requirement; EXP because it tests what was actually yours |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] "I've never presented to anyone above regional level" | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact afterwards. If your nearest example involved someone senior to you, say exactly how senior; you have said "I've never presented to anyone above regional level", so do not present it as a boardroom story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The monthly report goes to leaders, so unwelcome news upward is likely; F8 limits the scope. EXP because it tests attribution |
| C3 | "Tell me about a complaint that crossed more than one team before it was resolved." | EXP | [generic] | Selection scaffold: pick one real case; say who held it at each step, what you did and what happened to the member. The JD's end-to-end line is why it is asked. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | End-to-end ownership is the JD's headline requirement. EXP because it asks for a real instance |
| C4 | "When have you changed how something was done because of what complaints were telling you?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a real instance with a named change and its result. Answer slot: if what the spreadsheet showed changed anything, say what; if it did not, or you did not see it used that way, say so plainly and stay with the spreadsheet you built | The JD's monthly-reporting line implies reporting that drives action; F3 is the row behind it. `[inferred]` because the quote does not show any change |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre, and this role owns it alongside the branches. Why should the people there follow you?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Pause and restate the question. Hold, using only what the quotes carry: "I haven't worked in a contact centre. I handled the branch's formal complaints log." Return to those words through two follow-ups and never add to them. Concede exactly: the contact-centre side is something you would learn, not something you bring, and you would find out how it works before changing anything. State the limit before it is asked for: do not claim branch work gives equivalent standing. Likely follow-ups: what you would do in your first month (a plan in your own words: who you would sit with, what you would read first); what happens if the team does not accept you (what you would ask them and how you would listen); whether a branch-facing role would suit you better (answer honestly) | F2 is the largest stated gap against the JD's contact-centre scope; F1 holds the nearest adjacent work. This objection will arrive in some form, so it carries the deepest rehearsal. JD with a Pressure register |
| D2 | "You would report monthly to senior leaders. What is your experience presenting at that level?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain words first: "I've never presented to anyone above regional level." Then a plan, never a past: who you would rehearse with, and the one headline you would lead each month's report with. Do not say you are confident presenting to senior leaders; say what you would do to be ready | F8 is a stated limit against the JD's presenting line. JD because it scores a stated requirement |
| D3 | "This role works with digital teams on self-service journeys. What have you done with a digital team?" | JD | [grounded] | Answer slot: if you have worked with a digital team on any member-facing journey, say what and what your part was; if not, say so plainly, and say what you would ask a digital team first about where members get stuck. Leave out any claim about digital work you cannot back | F5 is silent in your material; the 40% digital target makes this likely. JD because it scores a stated requirement |
| D4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Choose the one that is true for you, say it plainly in the quote's words, and follow it with a plan rather than a defence: what you would do in the first weeks to close it. Concede specifically; do not bundle it with a strength to soften it | A standard Skeptic stem; F2 and F8 are the limits you have stated. JD because it scores the gaps in the posting |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What is in it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-map on the quote: you built it, it is monthly, it is about complaints, your regional manager uses it. Tell those beats in your own words. Answer slot: the JD asks for reporting on volumes and resolution times, so expect a probe on what the spreadsheet counted. Say what it counted; if it counted neither, say so plainly and say what you would add. Name the assumption behind any figure in it that you would defend least, if you know one; if you do not know how a figure was counted, say so plainly | F3 and F9 are the rows behind it; EXP because it tests what you actually built and how it was counted |
| E2 | "How did you handle the branch's formal complaints log? What happened to a complaint after it went in?" | EXP | [grounded] "I handled the branch's formal complaints log" | Hold to the quote: "I handled the branch's formal complaints log." Answer slot: if any step after the log entry was yours, say which and how you decided it; if there was no such step, or it was not yours, say so plainly and describe how you handled the log | F1 and F7 are the rows behind it; EXP because it tests the boundary of what was yours |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "The strategy moves 40% of member service to digital channels by 2028. Which complaints would you keep with a person, and why?" | CO | [grounded] | Clarify first: what counts toward the 40%, and which journeys move first; ask, do not assume. Objective: a member never has to explain twice. Segment by what the member needs: a simple status question, a complaint needing judgement, a formal complaint. Approach, then metrics: volumes and resolution times, the JD's own measures. Risks: a member stuck in a loop with no person to reach. Challenge one premise respectfully, such as whether 40% means contacts or members. The question needs no claim about your past | The brief's digital target meets the JD's self-service line; CO because it asks for strategy at the company's altitude |
| L2 | "In one month, complaint volumes in two branches rose by a fifth and resolution times lengthened. Where do you start?" | CASE | [generic] | Clarify what changed: definitions, intake, products, staffing, any single cause. Objective, then segment by branch, complaint type and stage. Approach: compare against earlier months before concluding anything. Metrics: volumes and resolution times. Risks: acting on one month. Think aloud and say what you would need and from whom. The question needs no claim about your past | The JD's reporting line implies this diagnosis. CASE because it is a live problem from the role |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "In the first ninety days, what would you most want the new lead to have learned or changed about complaints across the branches and the contact centre?" | Turns a vague success question into a priority list from your future manager |
| 2 | "How do complaints pass between the contact centre and the branches today, and who would I work with on each side?" | Shows learning-first intent on F2, and tells you what you will inherit |
| 3 | "What do the monthly complaints reports look like today, and who reads them?" | Finds out what "report on volumes and resolution times" means in practice, and lets you place your spreadsheet answer |
| 4 | "How will the move of 40% of member service to digital change what reaches the complaints process?" | Ties to the brief and shows you are thinking about the job in 2028 terms |
| 5 | "What is the best way for someone coming from branch work to earn credibility with the contact-centre team?" | Converts the highest-ROI objection into coaching from your future manager |

---

# Round 3: the panel of two branch managers (60 minutes, including a 20-minute case; also the values round)

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scenario probes mapped to the four values, STAR-shaped | High: the recruiter said the panel is the values round and scores against the four values | Map one real story per value; "we" for context, "I" for contribution |
| Case / Strategist | The 20-minute complaint-escalation case | High: the recruiter stated the case and its length | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting, "what would you need from us", collaboration | Medium: reasoned from the JD, where the role coaches branch supervisors and branch managers are the panel; the recruiter did not say what the panellists' brief is | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Conversational / Rapport Builder | Friendly openers about your branch | Low: no signal for it beyond the dedicated values round | Treat casual questions as scored |
| Skeptic | Probing the gaps | Low: round 2 carries the gap probing; this round reads values first | Plain acknowledgment, then the nearest thing your material carries |

## Values / principles cheat sheet

Ashgrove's four published values, named as on the page you copied. None of your quoted sentences carries a story for them yet, so each row is a selection scaffold. Each ends in the honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it.

| Value (official name) | Working meaning | Your story, or scaffold | Rehearsed in |
|---|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | Scaffold: pick a time you decided something from what the member needed rather than what the process said. It needs a named situation, what you decided, and what it cost you or the process | G1 |
| Plain Words | If a member needs it explained twice, the wording failed | Scaffold: pick a time you rewrote or re-explained something so a member understood it the first time. It needs the original wording, what was wrong with it, and how you knew it worked | G2, H2 |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: pick a time a figure said one thing and what you knew of the community said another. It needs what the figure said, what you knew, and what you did | G3, J1, H3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold: pick a time you found a problem and stayed with it to the end. It needs a point where it could have been passed on, and what you did instead | G4, H1 |

## Question bank

### Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold, per the cheat sheet: a named situation, what you decided, what it cost. The values page's own line is "we decide from the member's side of the counter". If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The panel scores against this value by name. VAL because it asks for behaviour that demonstrates it |
| G2 | "Tell me about a time you had to explain something to a member more than once." | VAL | [grounded] | Selection scaffold: what the first explanation was, why it did not work, and what you changed. The page's own line is "if a member needs it explained twice, we wrote it wrong", so own the first wording rather than blaming the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Scored against Plain Words. VAL because it tests behaviour, not familiarity with the phrase |
| G3 | "Tell me about a time a number told you one thing and the people you served told you another." | VAL | [grounded] | Selection scaffold: what the number said, what you knew from the community, what you did. The page's own line is "every branch is part of its town". If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Scored against Neighbours, Not Numbers. VAL because it needs a decision, not a slogan |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold: the problem, the point where it could have been handed on, and what you did instead. The page's own line is "whoever finds the problem keeps hold of it until it is solved". If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Scored against Own the Fix. VAL because the candidate's own persistence is the evidence |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Here is the case, twenty minutes. A member has escalated a complaint twice. The branch supervisor says the contact centre told the member one thing; the contact centre says the branch told them another. The member wants an answer today. What do you do, and what changes so it does not happen again?" | CASE | [generic] "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | Structure aloud: (1) Clarify: what the member was told and by whom, what they want, where the complaint sits in the process, and whether any deadline is running. (2) Objective: the member leaves with a clear answer in plain words and nobody restarts the story. (3) Today: name one owner who keeps hold of it until it is solved, and speak from the member's side of the counter. (4) Cause: segment where the handoff failed, between branch and contact centre, the record, the script or the timing. (5) Fix and metrics: repeat escalations and resolution times. (6) Risks: blame, and supervisors' confidence. Challenge one premise: check both accounts against the record before deciding who is right. Suggested time: about 3, 2, 4, 5, 4 and 2 minutes. If you reach for your own experience, stay at what the quotes say: the branch's complaints log you handled, and the new tellers you trained on the escalation script | The recruiter named this case. CASE because it is a live problem from the role. `[generic]` because the structure is a role-family pattern, not a fact about Ashgrove |
| H2 | "Here is a line from a complaint outcome letter: 'Following a review of the circumstances, we are unable to uphold your complaint at this time.' Rewrite it so a member would not need to read it twice." | CASE | [generic] | Say it aloud: the decision first, one sentence of reason, what the member can do next, and a named person to contact; no jargon. One shape: "We looked at your complaint again and we have not changed our answer. Here is why. If you want to take it further, here is how." The exercise needs no claim about your past | The Plain Words value on the page, tested live. CASE because it is a task set in the role |
| H3 | "The strategy brings eight branches into five hubs over 2027. How should complaints handling protect what members value about their own branch?" | CO | [grounded] | Clarify first: which members will travel further, and which services stay local; ask, do not assume. Lead with principles, not a plan: no member repeats a complaint because their branch changed; handoffs keep a named owner. Metrics: repeat contacts and resolution times by town. Risk: assuming digital replaces the counter. Do not criticise the strategy, and do not claim to know how it will be carried out. The question needs no claim about your past | The brief's hub line meets the Neighbours, Not Numbers value; CO because it asks for strategy at the company's altitude |
| H4 | "App-only banks are the main competitive pressure on Ashgrove. Where should a credit union's complaints process feel different from an app's?" | CO | [grounded] | Clarify what members use the app for today; ask, do not assume. Then answer from two of the published values: the member's side of the counter, and plain words. A person who keeps hold of the problem is the difference an app finds hard to copy, but say it as your view, not as a fact about Ashgrove. The question needs no claim about your past | The brief names app-only banks as the main pressure; CO because it tests competitive thinking |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You would coach our supervisors on escalations. Where does your job stop and ours start when a supervisor escalates something?" | JD | [generic] | Propose seam principles, not a map: the supervisor stays the member's point of contact even if you take the case on, because whoever finds the problem keeps hold of it; you step in when it crosses a team or a deadline; you report patterns back to branch managers so they see them. Then ask them where they would draw it. The question needs no claim about your past | The JD's coaching line puts the role on the branch managers' side of the seam. JD because it scores the stated requirement; Peer delivery |
| I2 | "You have been a branch supervisor yourself. What will our supervisors need from you?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "trained new tellers on our escalation script" | Answer slot: what you wanted when something escalated while you were a supervisor, in your own words; if nothing specific comes to mind, say so plainly and say what you would ask supervisors first in your first month. If you cite coaching, stay at what the quote says: "I trained new tellers on our escalation script." Frame it as what you bring them, not only what you need | F6 and F4 are the rows behind it; EXP because it tests what you actually saw from the supervisor's chair |

### Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell us about your branch. What do its members come to you for?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Describe the branch and its members in your own words; the pack knows nothing about the branch or its town. Answer slot: if a particular member or local detail shows the branch as part of its town, say it; if none comes to mind, say so plainly and describe what the branch did | Neighbours, Not Numbers asked casually; F6 is the row behind it. EXP because it tests whether the branch story is real and specific |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Which of our four values would be hardest for you to show in this role?" | VAL | [grounded] | Pick one honestly, say why in one sentence, and say how you would work on it. Do not claim all four come easily; a panel scoring four values reads a candidate who has no hardest one as one who has not looked | Closes the values scoring by testing self-assessment; VAL because it asks which value needs the most effort |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations today?" | Reciprocity: it opens the coaching conversation and shows you start from their needs |
| 2 | "As eight branches become five hubs over 2027, what do you most want complaints handling to protect for members in your town?" | Ties to the brief and to Neighbours, Not Numbers |
| 3 | "What would help your supervisors most from this role in its first month?" | A reciprocity question: what the new person can do that genuinely helps the branch |
| 4 | "Can you give me an example of Own the Fix that you have seen in your branch?" | Shows you treat the values as practice, and gives you a real example to learn from |
| 5 | "What would you want me never to change without asking the branches first?" | Signals respect for local knowledge and shows you will not rewrite the process from head office |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, C3, D1, E2, H1, I1 |
| "report monthly on complaint volumes and resolution times" | C4, D2, E1, L2 |
| "coach branch supervisors on escalations" | C1, I1, I2 |
| "work with digital teams on self-service journeys" | D3, L1, H4 |
| "4+ years in financial-services customer operations" | A1, B2 |
| "experience handling regulated complaints" | B3, E2 |
| "confident presenting to senior leaders" | C2, D2 |
| "comfortable with Excel reporting" | B4, E1 |

## Prohibited claims

Built from the fit snapshot before the banks were written. This pack will not coach these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process. E2's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders or executives | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot |
| Coached or led branch supervisors on escalations; wrote the escalation script | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the script. C1's slot stays inside that |
| Reported monthly on volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. E1's slot asks only what the spreadsheet counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. B3's slot asks only whose rules the log followed |
| Is an Excel reporting specialist | Inflated form of F9 | F9's quote at its own scope. B4's slot asks only whether it was Excel |

## Sources

Provided documents: the job description; the four values copied from ashgrovecu.org/about/values on 25 November 2026; the recruiter's email about the three rounds; the July 2026 strategy brief lines you supplied; your own description of your background (no CV was supplied). No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted fixes the cheat sheet and G1 to G4, and no search was sent to check it |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names each session, who runs it and what it holds, so it fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The brief lines you supplied, about four months old, fix the CO bank and the grounding table |
| 4. interviewer name and Ashgrove | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A CV or fuller career history → more fit-snapshot rows draw on your own quotes, and any figure on it earns a defend-the-number question
- A redacted copy or column list of the monthly complaints spreadsheet → F3 and F9 move from `discovery` toward `high` confidence, and E1 becomes a story-map instead of an answer slot
- Which rules or regulator the branch complaints log followed → F7 and B3 move from `discovery`
- One real example per Ashgrove value, in a sentence or two → G1 to G4 and the cheat sheet move from selection scaffolds to mapped stories
- Your pay, notice, location and reason for moving, in your own words → A3 to A6 move from instructions to quoted answers
- The interviewers' names when they are assigned → an interviewer read, persona weights adjusted to their public footprint, and reverse questions tied to their own paths
- Recruiter guidance on the 20-minute case: whether material comes in advance, and its format → H1 is tuned to the real case; usually one email
- Hours per day available for prep → the triage resizes from an order to a timetable
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering the competitive set, recent organisation context and role-family loop reports → H3 and H4 gain current context, and the CO bank moves from the brief alone
- A `tuesday-dossier.md`, if you have one → verified evidence and the prohibited list arrive pre-graded in place of the ones built here
