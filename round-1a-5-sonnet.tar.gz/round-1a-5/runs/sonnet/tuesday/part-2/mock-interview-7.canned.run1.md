I've run four searches and I'm now fetching two pages, the values page and the interviewing page, so the pack uses their exact wording.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-7-canned-dc8b2fa5/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions, a fit snapshot against the JD, a values cheat sheet, and six reverse questions.

I built it on the assumption that your Friday session is the "Outage Hour" and that Tobias is the hiring manager. Saltmarsh's interviewing page describes one 60-minute hiring-manager interview: a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home. So the pack weights Case questions and Values questions highest.

- **Values:** the three published values are Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. Your release-checklist sentence maps to the third. The other two have no sentence of yours behind them, so they get "pick a time" scaffolds, not stories.
- **Tobias:** his GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by whether its patch notes match what shipped. He was previously a QA lead. That makes your checklist your best bridge to him, and anything you say you shipped should match what was actually built.
- **Strategy:** a September 2026 announcement ("Project Larkspur") moves Tidepool Tactics and Lantern Row to a season pass with one shared events calendar. I only read the search snippet, not the full page. The pack uses it for one question and one reverse question.
- **Biggest objection:** you've never worked on a game with in-app purchases, and the titles are moving to a season pass. Question C1 rehearses it as the highest-value prep: acknowledge it in one plain sentence, then give a ramp plan, and don't claim your retention work carries over to spending. The pack also covers the "never led a team" negative the same way.
- **Gaps in your material:** I couldn't confirm that you coordinated design, art, engineering and community, or that your main title was live-service. The same goes for owning post-event reviews and KPIs. Those rows carry "if you did this, say how; if not, say so plainly" slots instead of answers I made up.
- **Research:** I used 4 of 6 searches and 2 of 2 fetches. The research table in Sources shows what each target moved.

Offers, none pushed:
- I can run C1 as the Skeptic, or the tabletop (A1) as the Case interviewer, as a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed.
- I can convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Session: the 60-minute interview. Saltmarsh's interviewing page describes each loop as a recruiter call, then one 60-minute session with the hiring manager (the "Outage Hour"): a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home. This pack assumes your Friday session is that one and that Tobias is the hiring manager.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours or did not exist.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the actual role |

## Fit snapshot

Your background reached me as a summary, not a CV, so every evidence cell is a sentence from your message. The JD has no gate requirement: "3+ years" is an experience requirement, so it is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar across two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on scope likely. If you planned across more than one title, or planned events and not only drops, say which and how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Derived from the calendar sentence: running a weekly calendar touches this requirement without showing who you coordinated with. Answer slot: if design, art, engineering or community teams worked to your calendar, say which and what you needed from each; if some did not, or none did, say so plainly and say what you did run |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly retention numbers is adjacent to owning an event review and does not reach it. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you reviewed any content drop or event afterward, say what the review covered and what you owned; if there was no such review, or it was not yours, say so plainly and say what you would report first |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in kind, but a sentence with nothing inspected behind it, and "manage" is wider than "wrote". Lead with the checklist in the quote's own terms: you wrote it, and QA still uses it. Answer slot: if you ran the checklist with QA on each release, say how; if others ran it, or you wrote it and stopped there, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Derived from the two sentences: four years of associate producer work with a weekly content drop touches the requirement without showing that the title was a live-service game or that associate work counts as producing. The words stay as written. Answer slot: if your main title was a live game you supported with regular releases, say that in your own words; if not, say so plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: the quote already says it. Lead with it in its own terms, with the cadence (weekly) and the span (two years), because a named cadence beats an adjective. Expect a probe on how a week actually ran; D1 rehearses it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement: retention numbers, presented monthly, to the studio head. Expect a probe on which numbers and whether you produced them or presented them. Answer slot: say which retention measures you presented and what was yours; if someone else produced them, or you do not know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [inferred] | presentation | Derived from the checklist sentence: a written document that another team still uses reaches this requirement in other terms. The bridge rewords only the quote: "I wrote the release checklist our QA team still uses." It adds no practice and no outcome |
| F9 | Experience with a paid-player economy such as in-app purchases (role-family expectation; the JD does not state it) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## Persona table

The loop source is Saltmarsh's interviewing page: one session, a tabletop and then a values conversation, with the hiring manager. Peer Evaluator is left out: the session has no peer.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event, with live decisions | Top. The interviewing page names the live-incident tabletop as the first half of the hour, and the hiring-manager prior is Case plus Skeptic | Clarify, then objective, then segmentation, then approach, then metrics, then risks. Think aloud. Challenge one premise politely |
| Values/Behavioral | The second half of the hour: a values conversation against Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener | Top. The interviewing page documents a values conversation inside this session, so a values-style round is detected | Map a story to each value where a quoted sentence carries one, and use a selection scaffold with an honest branch where none does. "We" for context, "I" for contribution |
| Skeptic | Quiet probing of the gaps: in-app purchases, no team leadership, associate title | Mid. The hiring-manager prior includes Skeptic, and F9 and the stated team-leadership negative are the predictable targets | Rehearse the single most predictable objection until it is boring. Acknowledge only what you have stated. Give a ramp plan as a plan |
| Data-Driven Prober | Line-by-line probing of the calendar and the retention numbers | Mid. Weighted on the interviewer's public self-description of a team being judged on what it actually shipped (Reading the interviewer), not on any inference about temperament | Know what you can and cannot say about how each number was counted and say plainly when you do not know |
| Pressure | Time-boxing and challenge inside the tabletop: who decided, what if they disagree | Low. A tabletop on a simulated outage carries time pressure, but nothing in the sources says the interviewer is a stress interviewer | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational | The opener ("walk me through the journey") and a casual question about what you play | Low. Short and early, and still scored | A pre-scripted 90-second arc built only from your own sentences |

## Reading the interviewer

Public professional footprint only.

| Public fact | Source | What it means for the session | Provenance |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | GDC 2026 talk listing, "Patch Notes Are a Promise" | Release-process and QA questions are likely to be asked from experience. Your checklist story is the natural bridge | [grounded] |
| His talk argues that a live team is judged by how often its patch notes describe what actually shipped | Same listing | It echoes the value Ship the Patch Not the Promise. Whatever you say you shipped or announced, say only what was built. A1 to A3 and B2 rehearse it | [grounded] |
| Mirror opportunity: a QA background on his side, and a checklist on yours | His path as above, with F4's quote: "Wrote the release checklist our QA team still uses." | A shared professional domain, release discipline. Offer it as your own sentence, once. Do not build on any shared identity or background | [grounded] |

## Question banks

### A. Case/Strategist (tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The Saturday event went live twenty minutes ago and engineering says reward claims are failing for some players. You have the live-ops channel open. Walk me through your first thirty minutes." | CASE | [generic] | Clarify first, out loud: what is failing, for whom, since when, whether it can be reversed, who is on call. State the objective: stop harm to players and keep one version of the facts. Split affected from unaffected players. Agree the action with engineering and name who decides. Say what you would watch: claim failures, support contacts. Name the risks: a fix worse than the fault, a promise to players nobody can keep. Challenge one premise, for example whether claims are failing or only delayed. The question needs no claim about your past, so the guidance makes none | The tabletop is the first half of the session, so a live-incident problem is the most likely opening; the values Players Before Plans and Ship the Patch Not the Promise set how it is scored. CASE because it asks for structure on a live problem |
| A2 | "Write me the three-sentence status post players see in the next ten minutes." | CASE | [generic] | Say what is affected, what is known, and when the next update comes. State no cause and no time that engineering has not confirmed. Announce nothing that is hoped for. Read it aloud before you hand it over, and keep each sentence one fact. The question needs no claim about your past, so the guidance makes none | F8's requirement, tested live, and the interviewer's public talk is about what announcements say. CASE delivery, JD content |
| A3 | "Engineering has a fix ready, QA has not finished its pass, and the event ends in two hours. Ship or hold?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Ask what QA has and has not covered. Weigh the fault's reach against the fix's risk. Agree a rollback before shipping. Name the decision owner. Say what players are told either way. To bring in your own experience, say only: "I wrote the release checklist our QA team still uses." Answer slot: the JD's checklist line makes a probe on running it with QA likely. If an unfinished QA pass ever came up on a release you ran, say what happened and what part was yours; if none did, or others ran the checklist, say so plainly and stay with the checklist you wrote | F4 is the evidence for the checklist requirement, and the interviewer's QA path makes this the likeliest seam to be tested. CASE because the answer is a live decision, JD because it scores the checklist line |
| A4 | "Two titles share one engineering on-call and one push-notification slot this weekend, and both want a big event. How do you plan the calendar?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify the shared constraints and the overlap in players. Objective: the players' experience first, which is the value Players Before Plans. Options: stagger, scale one event down, move one. State your decision rule and who arbitrates when two titles disagree. Name the risks. To bring in your own experience, say only: "I ran the weekly content-drop calendar for our main title for the last two years." If you have not planned across two titles, say so plainly, then give the structure above | The JD's two-title line is the raising source, and F1 is the gap it presses on. CASE because it is a planning problem set in the role |
| A5 | "Saltmarsh is moving Tidepool Tactics and Lantern Row to a season pass with one shared events calendar. What does that change about running events, and what worries you?" | CO | [grounded] Sources, search 3 (a September 2026 announcement of Project Larkspur) | Bring one fact to prove you did the reading: the announcement names a season-pass model, one shared events calendar from February 2027, and a single live-ops group in place of per-title event teams. Then diverge with a view of your own: where a shared calendar creates contention, and how weekly drops fit a season. Label it your view, not fact. Close by asking which titles the role covers. The question needs no claim about your past, so the guidance makes none. Everything here comes from the search result's text alone, not the full page | A current-strategy question, the differentiator most candidates cannot touch, built from research. A public announcement is equally available to rival candidates, so one fact is proof and the rest must be judgment |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Players Before Plans: when the calendar and the players disagree, the players win. No quoted sentence of yours states such a disagreement, so this is a selection scaffold. Pick a time you moved or delayed a drop because of what players were experiencing. It needs a named trade-off, who decided, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | The first published value, and the question the value's own wording sets. VAL because it scores past behavior against a named value |
| B2 | "Tell me about a time you had to correct what players had been told." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Ship the Patch Not the Promise: we announce what is built, not what is hoped. No quoted sentence of yours states a correction, so this is a selection scaffold. Pick a time what players were told and what shipped differed. It needs what was said, what you changed, and how players heard it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I wrote the release checklist our QA team still uses", or how you would handle it | The second published value, and the interviewer's public talk is built on it. VAL because it scores whether you correct announcements honestly |
| B3 | "Leave the Build Greener means every release leaves the checklist better than it found it. Tell me about the checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the checklist, and your QA team still uses it. Those are the beats the quote states, so tell them in your own words. Answer slot: the value's checklist wording makes a probe on whether it changed likely. If it changed after releases, say what changed and why; if it stayed as written, or others changed it, say so plainly and stay with the checklist you wrote and that QA still uses | The third published value, and the one value your own sentence carries. VAL because it tests the value, EXP-style attribution is inside the slot |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | A values stem. No quoted sentence of yours states an unwelcome result, so this is a selection scaffold. Pick a time you told someone senior something they did not want to hear. It needs the stake, what you said, and where it landed with the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Presented the monthly retention numbers to the studio head", or how you would handle it | A standard scored values question whose honest branch matters: the material shows the audience, not the unwelcome news |
| B5 | "Tell me about a time you got design, art, engineering and community onto the same update." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The JD's coordination line is the theme. No quoted sentence of yours names these teams, so this is a selection scaffold. Pick one update and say who needed what from whom, where they disagreed, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | F2 is a discovery row, so this question is where it gets tested. VAL with JD content |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see in-app purchases in your background, and our titles are moving to a season pass. What would you get wrong in your first month?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI prep in this pack. Acknowledge only what you have stated: "I haven't worked on a game with in-app purchases." Then give your ramp as a plan, never a past: name, in your own words, the first things you would ask for and from whom, and what you would treat as unknown until you had seen it. Hold what your quotes carry and no more: "I ran the weekly content-drop calendar for our main title for the last two years" and "Presented the monthly retention numbers to the studio head". Do not say that this experience carries over to spending. Hold through two follow-ups by returning to what you said, and concede the monetization limit specifically | F9 is the largest stated gap and the likeliest objection in some form; the announcement in A5 makes it current. JD because it scores a gap in the role's world |
| C2 | "You've never led a team. This role pulls design, art, engineering and community together on every update. Where does your authority come from when they disagree?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge only what you have stated: "I haven't led a team." The JD asks you to coordinate these teams, in its own words "coordinate design, art, engineering and community teams on each update", and that is the role you are answering for. Answer slot: if you have settled a disagreement between disciplines, say how and what part was yours; if none, say so plainly and say how you would go about it, as a plan: who decides, and what is agreed before the update starts | The second stated negative, aimed at F2. JD because it scores the coordination line |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name one part plainly and say what you would do in your first two weeks, as a plan. The pack's read is that F3 is where your material is thinnest against a JD line: the nearest sentence you have is "Presented the monthly retention numbers to the studio head." Say that, say it is adjacent, and keep one stronger quoted sentence as the counterweight | A persona stem, and the answer that costs least when it is rehearsed. JD because it is the interviewer's own scoring sheet |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F6: a weekly calendar, for your main title, over two years. Those are the beats the quote states, so tell them in your own words. Answer slot: the JD's coordination and checklist lines make a probe on who fed the calendar and who signed off likely. If you decided what went into a week's drop, say how; if others decided and you scheduled it, or there was no such step, say so plainly and describe how you ran the calendar | F6 is the evidence for the calendar requirement and the likeliest place to be probed on attribution |
| D2 | "You presented the monthly retention numbers to the studio head. Which numbers, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say which retention measures you presented, in your own words. Say what you know about how they were counted and what they were sensitive to. Name the assumption you would defend least if you know of one before he asks. Answer slot: if you produced the numbers, say what part was yours; if someone else produced them, or you do not know how they were counted, say so plainly and stay with what you presented | A probe on a headline claim, which the Prober persona always makes. F7 holds the evidence. EXP because it tests what was actually yours |
| D3 | "What should a post-event review report, and who should act on it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it: what the event was for, which players it reached, which measures you would report, what you would recommend, and who acts. The nearest thing your material carries is "Presented the monthly retention numbers to the studio head", so say that and say it is adjacent. Answer slot: if you reviewed any content drop or event afterward, say what the review covered and what you owned; if no such review existed, or it was not yours, say so plainly and say what you would report first | The JD's review-and-KPIs line, and F3 is the thinnest evidence against it. JD because it scores a stated responsibility |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has already run a monetized live game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Concede the monetization gap first, in the acknowledgment you have stated: "I haven't worked on a game with in-app purchases." Then hold on the three sentences above, in your own words, and no more. Do not claim you would ramp faster or deliver more. Hold through two follow-ups by returning to them, and concede only the specifics of monetization | A time-boxed comparison, the Pressure stem, aimed at F9. JD because it scores fit against the role |
| E2 | "You just said you'd roll back. Who made that call, and what happens if engineering disagrees?" | CASE | [generic] | Pause and restate. Name the decision owner by role. If it is not yours, say so and say how you would put your recommendation. Concede one thing specifically, for example that you would want engineering's read on risk first, and hold the rest. Do not fold on the core decision to restore harmony. The question needs no claim about your past, so the guidance makes none | The tabletop's time pressure, delivered as a challenge to your own answer. CASE delivery, Pressure persona |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from these four sentences, in this order: four years as an associate producer at a puzzle-game studio; for the last two years you ran the weekly content-drop calendar for your main title; you wrote the release checklist your QA team still uses; you presented the monthly retention numbers to the studio head. Answer slot: why live operations, and why Saltmarsh. Give your own reason in your own words; this pack does not supply one | The biography question is asked casually and scored. F5 is why the title and span stay as written |
| G2 | "What live-service games do you play, and what do you notice about how they run events?" | CO | [generic] | Pick one game you actually play and name one thing you notice about its events: cadence, what it tells players, how it handles a bad day. If you do not play live-service games, say so plainly and name the one you would study first. Play one of Saltmarsh's titles before Friday if you can, and say only what you saw. The question needs no claim about your past, so the guidance makes none | A casual question on a hot JD topic. Casual does not mean unscored |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, D1 |
| Coordinate design, art, engineering and community teams on each update | B5, C2, D1 |
| Own the post-event review and the KPIs it reports | D3, C3 |
| Manage the release checklist with QA | A3, B3 |
| 3+ years producing live-service games or apps | G1, E1 |
| Experience running a content calendar | D1, A4 |
| Comfortable with player-retention metrics | D2, D3 |
| Clear written communication | A2, B2 |

## Values cheat sheet

A values-style round is detected: the interviewing page documents a values conversation inside this session. Names are from Saltmarsh's published page.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries it. Selection scaffold in B1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries it. Selection scaffold in B2, ending in its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats as in B3, with its answer slot |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your GDC talk argues a live team is judged on how often its patch notes describe what actually shipped. How does your team measure that today, and who owns it?" | Ties to his own published argument and to the value Ship the Patch Not the Promise, and shows you read him rather than only the company | [grounded] |
| R2 | "You came to live operations from QA lead. What did you carry across that you would want a new producer to learn first?" | Tied to his own path. It turns the session into a peer conversation and invites him to say what he values in a producer | [grounded] |
| R3 | "Project Larkspur retires per-title event teams in favour of one live-ops group. Does this role sit in that group, and are the two titles in the JD Tidepool Tactics and Lantern Row?" | Resolves the biggest structural unknown in the role, and shows you read the announcement | [grounded] |
| R4 | "Who owns the release checklist today, and what is one thing you would change about it?" | Connects to the value Leave the Build Greener and to his QA background, and invites the conversation about your own checklist | [grounded] |
| R5 | "What does a good first ninety days look like for this producer, and what would tell you it was going wrong?" | Gets the real success measure out in the open, and tells you what the post-event review is meant to report | [generic] |
| R6 | "Which of the three values is hardest to hold during a live event?" | A values question asked back to the person who runs the incidents, which tells you what the tabletop is really scoring | [generic] |

## Prohibited claims

Built from the fit snapshot before the banks. None of these is coached anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative the candidate stated, F9: "Never led a team, and never worked on a game with in-app purchases." | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or on a season pass | Negative the candidate stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a content-drop calendar for your main title. A4's slot stays inside the calendar |
| Owned the post-event review or its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says presented, not owned. D3's slot asks only what a review covered |
| Four years of experience as a producer | Inflated form of F5 | F5's quote as written: "4 years as an associate producer at a puzzle-game studio." |

## Sources

Provided: the JD and your background, both in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or page | What came back |
|---|---|
| Search: Saltmarsh Games values | saltmarshgames.com/values |
| Search: Saltmarsh Games interview process live operations producer | saltmarshgames.com/careers/interviewing |
| Search: Saltmarsh Games mobile studio strategy news | saltmarshgames.com/news/project-larkspur (search-result text only; the page was not fetched) |
| Search: Tobias Wrenfield Saltmarsh Games Head of Live Operations | talks.gdconf.example/2026/patch-notes-are-a-promise (search-result text only) |
| Fetch: saltmarshgames.com/values | The three values and their one-line meanings |
| Fetch: saltmarshgames.com/careers/interviewing | The loop: recruiter call, then the Outage Hour, no take-home |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The values cheat sheet and B1 to B3: three values by name |
| 2. Saltmarsh Games interview process, live operations | yes | Establishes the loop for this session: tabletop then values conversation with the hiring manager. Persona weights follow it |
| 3. Saltmarsh Games strategy or recent news | yes | A5 and R3, from one September 2026 announcement. Only the snippet text was read, so nothing beyond it is used |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read, R1 and R2, from one talk listing. Nothing else about him is used |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your recruiter's note about the tabletop (scenario type, who else joins, anything pre-declared) → the tabletop bank gets rebuilt around the real scenario, and any announced deliverable gets its own build section
- Your CV text → F1 to F8 draw on fuller quotes, and more rows can move from `discovery` to a grounded bridge
- Your own words on whether design, art, engineering or community worked to your calendar (F2), on whether your main title was a live game with regular releases (F5), on which retention numbers you presented (F7), and on whether you ran the checklist release to release (F4) → those rows' answer slots become story-mapped answers
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, offered once → a grounding brief on Project Larkspur and Saltmarsh's recent moves, more of Tobias's public talks as likely questions, and sharper CO and CASE questions
- A `tuesday-dossier.md`, if you have one → verified evidence and a prohibited-claims list from an earlier review, in place of the ones this pack built locally
