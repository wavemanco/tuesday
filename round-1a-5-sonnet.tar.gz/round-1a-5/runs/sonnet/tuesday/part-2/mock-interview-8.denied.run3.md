Checking the pack for ID collisions before I hand it over. Bank "F" clashes with fit-snapshot rows F1–F9, so I'm renaming it.
Dara, your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-8-denied-80514380/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as three round-by-round mini-packs, because the recruiter's email fixes all three rounds on 4 December. It has a shared fit snapshot, a persona table and question bank per round (27 questions in all), reverse questions for each round, a values cheat sheet for the panel, and a list of claims the pack won't coach. I ran no searches. Your pasted JD, values text, email and strategy points already covered everything a search would have returned.

- **Highest-ROI prep:** question D1, in round 2. Half the role sits in the contact centre, and you said you've never worked in one. The pack rehearses a three-step answer: state it plainly, concede what you don't know, and name your first-weeks plan. You will probably get a version of it in all three rounds.
- **Second gap:** you've never presented above regional level. Rehearse the plain acknowledgment, and treat the first monthly report to senior leaders as a plan, not a past.
- **Your strongest material:** the complaints log, the escalation-script training and the monthly spreadsheet. Your spreadsheet line carries both the reporting and the Excel requirements, so expect it to be probed closely. The pack gives you slots to fill in your own words: what the spreadsheet counted, whether rules or timelines governed the log, and any work with a digital team.
- **Where the pack stops:** it only coaches claims your own sentences carry. It won't have you say you owned the process end to end, coached supervisors, worked in a contact centre or presented to senior leaders.

I can play the Skeptic on D1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word if you want that.

Did the recruiter say whether the 20-minute escalation case arrives in advance or cold? If in advance, I'll add a build section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Three scheduled rounds on 4 December 2026, built in loop mode: one shared fit snapshot, then a mini-pack per round.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | No focus stated |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values |

Interviewer names beyond their roles are not assigned yet, so there is no interviewer read.

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | A stated responsibility or qualification in the posting |
| CO | Knowledge of Ashgrove's strategy and competitive position |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now: it says what to say if something was true, and what to say plainly if it was not.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — the JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process, and the words stay there: "I handled the branch's formal complaints log." Answer slot: expect a probe on what handling the log involved; say which parts were yours, in your own words, and if the log followed a process set elsewhere, say so plainly and describe how you handled it |
| F2 | "across branches and the contact centre" — the JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — the JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The spreadsheet is monthly, about complaints, and used by your regional manager; your material does not show what it counted. Answer slot: if it counted how many complaints came in or how long they took to close, say so in your own words; if it tracked other things, or you do not know how a figure on it was counted, say so plainly and say what it did track |
| F4 | "experience handling regulated complaints" — the JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Formal is your word; whether rules or timelines governed the log is not in your material. Answer slot: if specific rules or timelines governed the log, say which, in your own words; if none did, or that part was handled by someone else, say so plainly and stay with the log you handled |
| F5 | "coach branch supervisors on escalations" — the JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, and the words stay there: you trained new tellers on our escalation script. Answer slot: expect the probe to widen beyond that training; say what you did in your own words, and where it stops, say so plainly |
| F6 | "confident presenting to senior leaders" — the JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "work with digital teams on self-service journeys" — the JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with a digital or app team on anything, say what, and what was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F8 | "comfortable with Excel reporting" — the JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Say it as you wrote it: you built it, it is monthly, your regional manager uses it. Your material says spreadsheet, not which tool; if it was Excel, say Excel, and if it was another tool, say that |
| F9 | "4+ years in financial-services customer operations" — the JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Lead with the years and the role in those words and let the interviewer do the mapping; do not relabel the work in the posting's terms |

## Grounding brief (shared)

Built from the four points you relayed from Ashgrove's July 2026 strategy brief; the document itself was not supplied, so nothing beyond these points is stated.

| Point, as you relayed it | Where it may come up | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | E3, reverse questions in rounds 1 and 2; the digital-teams requirement (F7) | [grounded] |
| "consolidate eight branches into five hubs over 2027" | F3 and the round 3 reverse questions; the branch managers on the panel may be affected | [grounded] |
| "launch a small-business lending product in Q1 2027" | Round 2 reverse questions; a new product line brings a new kind of member and complaint | [grounded] |
| "the main competitive pressure is app-only banks" | E3; why self-service matters to them | [grounded] |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, C1, D1, E2, K1, K2 |
| Report monthly on complaint volumes and resolution times | C3, E1, K3 |
| Coach branch supervisors on escalations | C2, E2, K2 |
| Work with digital teams on self-service journeys | E3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | C1 |
| Confident presenting to senior leaders | B2, D3, C4, E1 |
| Comfortable with Excel reporting | C3 |

## Round 1: recruiter screen, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, unstructured; biography, motivation, logistics | High: a recruiter screen's prior is Conversational plus a light Skeptic, and the email states no focus | Prepare a 90-second arc; treat the casual questions as scored |
| Skeptic, light (B) | Quick knockout checks on the two gaps in the posting | Medium: a recruiter checks the JD's headline gaps early, and your own message names two of them (F2, F6) | Short, plain, un-defensive answers; save the depth for round 2 |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your six years in retail banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A 90-second arc that has only the shape the quote states: six years in retail banking, the last three as a branch supervisor. Tell it in your own words. If the interviewer asks what a stage involved, say what the work was in your own words, and if some part was not yours, say so plainly. End on why this role | F9 is the experience requirement and the biography is how a recruiter screen opens; EXP because it scores economy and honesty about each stage |
| A2 | "What draws you to a member-owned credit union like Ashgrove?" | VAL | [grounded] | Choose one or two things you can speak to honestly, such as the member-owned model the posting names, or one of the four published values, in your own words. Do not recite all four. Make no claim about Ashgrove you have not read | A motivation check; VAL because the posting and the values page are the raising sources, and CO is light here |
| A3 | "What is prompting a move now?" | EXP | [generic] | Give your actual reason in your own words, framed around what you are moving toward, and say only what is true. If asked a follow-up on the reason, repeat your own words and add nothing | The reason for leaving is a logistics slot in every recruiter screen; EXP because it tests consistency of your story |
| A4 | "What are you looking for in salary terms?" | JD | [generic] | Either give your own figure for this role, or ask for the role's band first; both are normal. If asked what you earn now: "I'd rather focus on the range for this role" | Pay is a logistics slot; JD because it is a term of the listed job |
| A5 | "What is your notice period?" | JD | [generic] | Give your actual notice period. Add nothing the recruiter did not ask | Notice is a logistics slot; JD because it is a term of the listed job |
| A6 | "Where would you be working from, and is travel between sites a problem?" | JD | [generic] | Give your own constraints on where and how often you can work, in your own words. If you have none, say so | Location is a logistics slot; JD because the role spans branches and the contact centre |

### Bank B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. What is your experience there?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Say it plainly: "I haven't worked in a contact centre." Then the branch end, at its own scope: "I handled the branch's formal complaints log." Then a plan, said as a plan: the first things you would ask to see are how a complaint is captured when it arrives by phone, and how it reaches a branch. Stop there; the deeper version is rehearsed in D1 | F2 is the widest gap against the headline requirement, so a screener checks it first; JD because it scores a stated requirement |
| B2 | "The role asks for confidence presenting to senior leaders. Where are you on that?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Say it plainly: "I haven't presented to anyone above regional level." Then the nearest thing your material carries, at its own scope: you built the monthly complaints spreadsheet your regional manager uses. Then how you would prepare, as a plan, for example asking what the leaders want from the monthly report. Do not describe any presentation you did not give | F6 is a stated gap and F3 is the nearest evidence; JD because it scores a stated requirement |

### Reverse questions: recruiter

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is the weight of this role nearer the branches or the contact centre today?" | Shows you are thinking about both halves of the scope, and tells you which round 2 gap to rehearse harder |
| 2 | "Is there anything about the 20-minute escalation case I can prepare for, such as the format or whether it arrives in advance?" | A preparation signal, and it can unlock a deliverable build section |
| 3 | "Who reads the monthly complaints report today, and what do they ask of it?" | Ties the reporting requirement to a real reader, which is where your gap is |
| 4 | "How does the move to digital channels change who this role works with?" | Shows you read the brief and links to the digital-teams requirement |
| 5 | "In six months, would you rather see resolution times move first, or how supervisors handle escalations?" | Shows you think in outcomes and gets the manager's priority before round 2 |

## Round 2: Head of Member Services, 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (C) | Past-behaviour questions on complaints, coaching and reporting | High: the recruiter's email calls this round mostly behavioural, which lifts it above the hiring-manager prior | Story-map only from your quoted sentences; where none carries it, use the selection scaffold and its honest branch |
| Skeptic (D) | Persistent probing of the contact-centre and senior-presenting gaps | High: a hiring manager is derisking gaps, and F2 and F6 are the two they will see | Rehearse D1 until it is boring: hold, concede specifically, plan |
| Case / Strategist (E) | Live problems from the role, on reporting, escalations and self-service | Medium: the hiring-manager prior is Case, but the email says mostly behavioural, so it is lower here | Clarify, objective, segmentation, approach, metrics, risks; think aloud |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about the formal complaints log you handled." | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on the quote: the branch's log, formal, handled by you; tell it in your own words. Answer slot: the posting asks for experience handling regulated complaints, so expect a probe on what the log had to meet; if specific rules or timelines governed it, say which, in your own words; if none did, or that part was not yours, say so plainly and describe how you handled the log | F4 is the regulated-complaints requirement and F1 is the log; JD because it scores a stated requirement, EXP in delivery |
| C2 | "You trained new tellers on the escalation script. How did you go about it?" | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on the quote: new tellers, on "our escalation script". Tell what you did in your own words. If the interviewer pushes beyond that training, say plainly where your experience stops | F5 is the nearest evidence to the coaching requirement; EXP because the question is premised on a sentence you said |
| C3 | "Walk me through the monthly complaints spreadsheet your regional manager uses." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on the quote: you built it, it is monthly, your regional manager uses it. Answer slot: the posting asks for monthly reporting on complaint volumes and resolution times, so expect a probe on what the sheet tracked; if it counted how many complaints came in or how long they took to close, say so; if it tracked other things, say what; if you do not know how a figure on it was counted, say so plainly. Say which tool it was in | F3 and F8 are both resting on this one sentence, so it is the most probed line in the pack; EXP because it tests what was yours |
| C4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you took a result or a problem to someone senior to you that they did not want to hear; it needs a named stake, what you said, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role reports to leaders each month, and F6 shows no senior audience, so this tests candour at altitude; VAL because it is the values stem for honesty |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Half this role sits in the contact centre, and you have not worked in one. Why should I believe you can own complaints across both?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Pause and restate the question. Hold: "I haven't worked in a contact centre. What I handled was the branch's formal complaints log." The pack's observation is that your material covers the branch end only, so keep it there. Follow-up one, "what is different about a contact centre?": say plainly what you do not know, then the first things you would ask to see, as a plan: how a complaint is captured when it arrives by phone, and how it reaches a branch. Follow-up two, "why not hire someone from a contact centre?": concede specifically that someone from one would know that side better, and do not claim otherwise; state what you would do in your first weeks, as a plan, such as spending time with contact-centre team leaders. Never fold on the quote, and never add to it | F2 is the widest gap against the headline requirement and F1 is the nearest evidence; this question will arrive in some form in all three rounds, so a rehearsed non-defensive answer changes the interview |
| D2 | "Which part of this posting would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" "Never worked in a contact centre" | Name the one you honestly expect to be weakest, using your own plain acknowledgment: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Then the first step you would take, as a plan. Do not pick a strength disguised as a weakness | F2 and F6 are the two gaps your own words name; JD because it scores the posting's requirements as a list |
| D3 | "How comfortable are you presenting to senior leaders, and what is the highest level you have presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it plainly: "I haven't presented to anyone above regional level." Do not claim a level. Then a plan: ask what format the leaders want, and rehearse the first monthly report with your manager before it goes up | F6 is the stated gap, and your manager is the one who would see it first; JD because it scores a stated requirement |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how you would build your first monthly complaints report for senior leaders." | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Clarify first: who reads it, what decisions it informs, what they get today. Then structure: volumes, resolution times (the two the posting names), what changed, what needs a decision. Ask the Head of Member Services what format the leaders prefer. The only past claim is the quote, at its own scope | F3 and F6 together; CASE because it is a live problem, JD in content |
| E2 | "Branch supervisors are escalating complaints late. How would you find out why, and what would you do?" | CASE | [generic] | Clarify first: late against what, since when, in which branches. Objective, then segment by branch and by complaint type, look at the escalation script and what supervisors are told, then test the cause before choosing the fix. Make no claim about your past | F1 and F5, as the process-ownership and coaching requirements; `[generic]` because it is a pattern for the problem |
| E3 | "The brief says 40% of member service moves to digital channels by 2028. Which complaints would you move to self-service, and which never?" | CO | [grounded] | Clarify what counts as service and what a complaint is. Then segment: simple, clearly-wrong-fee style items could suit self-service; anything where a member is upset or a formal complaint clock runs needs a person. Anchor in Ashgrove's own value: "if a member needs it explained twice, we wrote it wrong". Make no claim about your past; F7 is silent | The strategy brief is the raising source, and the posting asks for work on self-service journeys; CO because it needs the company's strategy, CASE in delivery |

### Reverse questions: Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where do complaints get stuck today between a branch and the contact centre?" | Shows you think about the seam, and surfaces the first problem you would own |
| 2 | "What have the senior leaders who read the monthly report changed because of it?" | Turns your F6 gap into a question about what they need, not a confession |
| 3 | "How does the small-business lending launch in Q1 2027 change the complaints you expect?" | Uses the brief to show you think ahead about new member groups |
| 4 | "How much of this role is building self-service journeys with the digital team, and how much is advising them?" | Clarifies F7, where your material is silent |
| 5 | "What would you want me to have learned about the contact centre in my first 30 days?" | Turns the biggest gap into a plan the manager can shape |

## Round 3: panel of two branch managers, 60 minutes (values round, includes a 20-minute escalation case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (J) | One scenario per published value, scored | High: the recruiter's email says the panel scores against the four values | Map a story to each value where a quote carries one; use the scaffold and its honest branch where none does |
| Case / Strategist (K) | The 20-minute escalation case | High: the email names a 20-minute case on a complaint escalation | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator (L) | Seam-splitting between your role and their branches | Medium: branch managers would work with the role, and the panel is two of them; the pack's prior for an unnamed cross-functional panel is lower, so this is weighted below the other two | Reciprocity framing: what you bring to their branch, not only what you need |

### Bank J: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First, Always: pick a time where the easy route and the member's side differed; it needs a named member situation, what you decided and why, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of the four values the panel scores; no quote of yours carries a decision of this kind |
| J2 | "Tell me about a time you had to make something complicated clear to someone who was not an expert." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. The nearest thing your material carries is the quote, at its own scope: you trained new tellers on our escalation script. Answer slot: if any of that training was about the words a teller says to a member, say what you did, in your own words; if it was not, say so plainly and use a different time, or say how you would approach it | F5 is the nearest evidence; VAL because Plain Words is the published value |
| J3 | "What does 'every branch is part of its town' mean for how you handle a complaint?" | VAL | [grounded] | Neighbours, Not Numbers. Structure it as principles, not history: the member is a neighbour, the branch is where the complaint arrives, and the numbers describe the work and do not replace the person. If the panel raises the branch-to-hub change, listen first and say what you would want to know; do not assume which branches or when. Make no claim about your past | The panel members run branches, and the brief says eight become five hubs over 2027, so this value is live for them; VAL with CO |
| J4 | "Tell me about a time you found a problem and stayed with it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. The nearest thing your material carries is the log, at its own scope. Answer slot: if a complaint on that log stayed with you until it was resolved, say what it was and what you did, in your own words; if it passed to others, or you did not see it through, say so plainly and say how you would keep hold of one | F1 is the nearest evidence; VAL because Own the Fix is the published value |

### Bank K: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "A member has complained twice about the same fee error. The branch says it is fixed; the contact centre says it is still open. What do you do?" (a practice scenario, not the panel's actual case) | CASE | [generic] | Clarify first: what the member has been told, when, and who holds the record. Objective: solve the member's problem and handle the complaint properly. Then: contact the member from their side and say what happens next in plain words; ask the panel which complaint timelines apply rather than assuming; name one owner who keeps hold of it until it is solved; find the cause; report it. Make no claim about your past | The panel's case is a complaint escalation, and this practice scenario follows the four values the panel scores |
| K2 | "A supervisor says the complaint is not theirs because the contact centre logged it. How do you coach them?" | CASE | [generic] | Listen first; agree what is theirs, as a principle: whoever finds the problem keeps hold of it. Offer to take the first step with them, and say what you would check afterwards. The pack's observation is that your material shows training tellers, not coaching supervisors, so rehearse this as a plan and never as a past | F5; CASE because it is a live coaching problem from the role |
| K3 | "Resolution times are improving but member satisfaction is not. What do you do?" | CASE | [generic] | Clarify the measures and the period, then diagnose: which complaint types, which channels, what members are told when it is closed. Choose what to test first, and say what number would change your mind. Make no claim about your past | F3; CASE with a metric-diagnosis stem |

### Bank L: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Where would your role start and stop in my branch's complaints?" | JD | [generic] | Propose seam principles and do not pretend to know the seam: the branch keeps the member relationship, your role owns the process, the numbers and the coaching, and you agree it with the branch managers. Reciprocity: say what the branch gets, a monthly view of its own complaint pattern | F1 and F5 as the process and coaching mandates; JD because it is the working relationship the posting describes |
| L2 | "A complaint outcome makes my branch look bad. How do we handle that between us?" | VAL | [generic] | Show spine and tact together: you would tell them first, in plain words, what happened and what is being done, and you would not soften the report to leaders. Make no claim about your past | A disagreement-style probe from a peer; VAL because it tests Own the Fix and Members First together |

### Reverse questions: branch-manager panel

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good escalation from a supervisor look like from your side?" | Gets the standard you will be coaching toward from the people who live it |
| 2 | "As branches consolidate into hubs over 2027, what do you want complaints handling to protect for your town?" | Uses the brief and the value Neighbours, Not Numbers |
| 3 | "What could someone in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel |
| 4 | "Which of the four values is hardest to hold at the counter on a busy day?" | Shows you take the values as practice, not slogans |
| 5 | "When a complaint outcome is uncomfortable for a branch, how do you want to hear about it?" | Turns H2 into an agreement before it is a problem |

### Values cheat sheet (round 3)

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote of yours carries this; use J1's selection scaffold and its honest branch |
| Plain Words | If a member needs it explained twice, the wording was wrong | F5: "trained new tellers on our escalation script", with the slot in J2 |
| Neighbours, Not Numbers | Every branch is part of its town | No quote of yours carries this; use J3's principles and make no claim about your past |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log", with the slot in J4 |

## Prohibited claims

Built before the banks. These are claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process across branches and the contact centre. C1's slot stays inside the log |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says new tellers and the escalation script, not supervisors. C2 stays inside the training |
| Presented to senior leaders | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description; Ashgrove's four published values, as you copied them on 25 November 2026 from ashgrovecu.org/about/values (not fetched); the recruiter's email on the three rounds; the four points you relayed from Ashgrove's July 2026 strategy brief (the brief itself was not supplied); your background, as written in your message. No dossier was present.

No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | skipped | Could not have moved the values cheat sheet: the pasted values text already supplies the four names and definitions |
| 2. `{company} interview process {role family}` | skipped | Could not have moved the loop or persona weights: the recruiter's email already names each round, who runs it and what it holds, and says the panel is the values round |
| 3. `{company} strategy` / recent news | skipped | Could not have moved the CO bank: the July 2026 brief points you relayed already supply the priorities and moves, and they are under six months old |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the fit-snapshot evidence now rests on your message alone; a CV would add inspectable lines and could raise F3, F8 and F9 from `medium`
- A redacted sample or a screenshot of the monthly complaints spreadsheet, or the layout of the formal complaints log → F3, F4 and F8 move toward `high`, and the answer slots in C1 and C3 can become story maps
- Your answers to the slots in F1, F3, F4 and F7 (what the log involved, what the spreadsheet counted, whether any rules or timelines governed it, any work with a digital team) → those rows regenerate with your words quoted
- Whether the escalation case arrives in advance or cold → if in advance, a graded build section for it
- The Head of Member Services' and the two branch managers' names and roles → an interviewer read, persona weights tuned per person, and a reverse question tied to each one's path
- The full July 2026 brief text → CO questions become direct, and the pack can check whether any framing in your four points has gone stale
- Hours you have before 4 December → a prep triage in priority order
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes: recent organisation context, interviewer footprints, role-family loop reports) → say so and I will run it
- A `tuesday-dossier.md` from an earlier role check → verified evidence and prohibited claims would feed the rows above; the pack stands without it
