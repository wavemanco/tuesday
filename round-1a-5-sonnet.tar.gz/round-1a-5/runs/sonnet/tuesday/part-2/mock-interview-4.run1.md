I'm building your Thursday prep pack from the dossier. The three company-research searches were refused, so I'm treating company-specific content as generic. I'll write the pack file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-4-denied-1399e81c/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the 45-minute hiring-manager round from your dossier alone. The three company searches (values, interview process, strategy) were refused, so the company-specific and values questions are generic and labelled that way.

Rehearse B1 first. It's the objection the underwriter named: no PM title, no roadmap ownership. The answer is in this order:
1. Concede in the dossier's words.
2. Bridge at the scope of your three quoted sentences.
3. Name the limit before they ask.
4. Give a ramp plan.

Three lines are off-limits all the way through the pack: holding the PM title, owning a roadmap, and setting priorities for a squad. The pack also won't coach "influenced the roadmap" or "shipped an API product", which are stretched forms of your evidence.

Four of the six fit-snapshot rows, S3 to S6, rest on this pack's own derivation or on discovery, not on dossier-graded evidence. Each carries an answer slot, and answering them honestly in either direction is a good answer.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager (session mode). Interviewer name unknown. Built on your underwriting dossier (conditional go: adjacent fit, bridge positioned as adjacent, never as PM experience).

## How to use this pack

- Personas are how a question is asked. Types are what it scores: VAL (values alignment), EXP (work-experience deep-dive), JD (role requirements), CO (company and strategy knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Lines in quotation marks inside guidance are your own sentences from the dossier, or sentences the dossier authorises you to say. Say them in your own words.
- Fit-snapshot rows are numbered S1 to S6 so they cannot be confused with question IDs.
- An answer slot is an instruction for the interview, not a question for this conversation. If the honest answer is the second branch, that is a good answer.
- The single highest-ROI rehearsal is B1. The underwriter named that objection, and it will be asked in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| S1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's allowed strategy is bridge. The bridge is adjacent work, never PM experience, and its words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The plain acknowledgment is sourced by `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." |
| S2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile; the dossier's weak area is "Owning a roadmap and prioritization authority (R1 sub-claim)" | none given | none | [grounded] | capability | The dossier's allowed strategy is acknowledge_gap, so there is no bridge and no slot. Words, sourced by `uncertain_or_weak_areas` and by `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap. I haven't set prioritization for an engineering squad." Then a ramp plan said as a plan: learn how adoption is measured today and which decisions sit with the squad leads, then propose how you would prioritize |
| S3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | Derived by this pack: the dossier does not grade R2. Your material says client integrations of the vendor's REST APIs, which is work on the client side of an API product, and the words stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the R2 line makes a probe on which parts of those integrations were yours likely. Say which, in your own words; if you did not build the API itself, say so plainly and stay with the integrations you led |
| S4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | Both quotes sit near the requirement without showing API docs or schemas. Answer slot: the R3 line makes a probe on API docs and schemas likely. If you worked with them in those integrations, say how, in your own words; if you did not, say so plainly, and say what you would read first |
| S5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes reach clients and product; they do not show engineering or sales. The second quote is confirmed with limited inspectable proof, so expect a probe, and say what you can show and what you cannot before it is extracted. Answer slot: the R4 line makes a probe on engineering and sales likely. If you worked with either, say how, in your own words; if you did not, say so plainly and stay with the clients and product |
| S6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's allowed strategy is clarify and no verified entry speaks to this requirement. Answer slot: the R5 line makes a probe on how you have worked with sprints or iterations likely. If you worked that way, say how, in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how Quartzline defines it |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic dominant), adjusted by the dossier, which names a capability objection and two open questions about decision rights and adoption measurement. The loop rests on your own words: one 45-minute conversation with the hiring manager. No values-style round is detected, so the values sheet is dropped. Correct the weights if you know something I do not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the partner API role: stuck integration, roadmap trade-offs, flat adoption | highest, 5 questions: hiring-manager prior, and the role is a roadmap and adoption role | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of the missing title and roadmap ownership | highest, 5 questions: hiring-manager prior, and the dossier names this objection | Rehearse B1 until it is boring; bridge only from adjacent evidence with the limit said first |
| C. Data-Driven Prober | Reads your claims line by line and goes two levels deeper | mid, 3 questions: a "30+" figure and a medium-confidence line invite it | Know what you can and cannot say about how the 30+ was counted; name the assumption you would defend least |
| D. Conversational | Friendly walk-through of your journey and your technical comfort | mid, 3 questions: openers are scored too | A 90-second arc built only from your three quoted sentences |
| E. Pressure | Time-boxed challenge on attribution and "why you" | low, 2 questions: possible given the gap, not the hiring-manager default | Pause, restate, hold through two follow-ups, concede specifically |
| G. Peer Evaluator | Seam-splitting with the two squad leads, credit across teams | low, 2 questions: the dossier flags decision authority versus the squad leads as open | Propose seam principles instead of pretending to know the seam |
| H. Values/Behavioral | Scenario probes | low, 2 questions: no values-style round is detected and no published values were read | Selection scaffolds, each ending in its honest branch |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A partner says their integration has been stuck in testing for six weeks and they are weighing a competitor's API. What do you do in your first week?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure aloud: clarify what stuck means and what has been tried, state the objective, diagnose stage by stage, then week-one actions, one metric, one risk. The stages your quote names (scoping, requirements, architecture, UAT, go-live) are a ready checklist for the diagnosis. The problem is hypothetical, so the answer needs no claim about your past | S1 is the adjacent evidence for this role's partner side; CASE because it is a live problem, JD-flavoured because partner integrations are the platform's customers |
| A2 | "How would you decide what goes on the partner API roadmap next quarter when requests outnumber what two squads can build?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Open with the sourced plain acknowledgment: "I haven't owned a product roadmap." Then structure: clarify the objective and who decides, group requests, name criteria, and say what you would trade off. Name client evidence as one input type, at its scope: sessions you ran that fed client evidence to product. Volunteer the limit before it is extracted: the quote is confirmed with limited inspectable proof, and your material does not show what product did with it | S2 is an acknowledge_gap area, so this answer is a plan and never a past; CASE because it asks for a method, tied to the JD's roadmap line |
| A3 | "Adoption of the partner API has been flat. Diagnose it." | CASE | [generic] | Ask first how adoption is measured today and what the baseline is. The dossier lists both as open. Then segment partners and the path from signup to production, form hypotheses, choose the first data pull, and say what would change your mind. The problem needs no claim about your past, so the guidance makes none | The JD names adoption metrics as a responsibility with no stated baseline; generic pattern because nothing about Quartzline's funnel was available |
| A4 | "How would you run discovery with our integration partners in your first quarter?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A plan and not a past: who you would talk to first, what you would ask, how you would turn what you hear into a ranked list. You may start from the quote at its scope: sessions you ran that fed client evidence to product | S5 is where this probe lands; CASE because it is a forward plan, JD-tagged on discovery |
| A5 | "What would you want to learn in your first 30 days before committing to a roadmap?" | CASE | [generic] | Lead with decision rights and the adoption baseline, then partner pain points, then squad capacity. This answer rehearses the first two reverse questions below, so say it as curiosity, not as a condition | Turns the open risks in S2 into a visible strength; generic because it is a pattern |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] `likely_interviewer_objections` as the dossier gives it; `prohibited_claims: "Having held a product manager title or role"`; `uncertain_or_weak_areas` acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The highest-ROI rehearsal in this pack. In order: (1) concede first, in the sourced words: "I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) Bridge at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs. I wrote the integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product." (3) Name the limit before it is asked: this is adjacent work, not the job. (4) A ramp plan said as a plan: learn how adoption is measured and which decisions sit with the squad leads, then propose. Follow-up 1, "that is integration work, not product work": concede it is adjacent and return to the quotes. Follow-up 2, "so what do you bring that a PM does not": return to the quotes, add nothing. Follow-up 3, "what is your biggest risk to us": the acknowledged gap and the ramp plan. Never say you have held the role, owned a roadmap or set priorities for a squad | S1 and S2 are the evidence; the dossier supplied this objection, so it was derived from what you confirmed, not from a document read cold. JD because it scores R1 |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas` acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)" | Answer with the acknowledged gap in the sourced words, "I haven't owned a product roadmap," and the ramp plan from S2. Do not bridge here; the underwriter found no credible evidence, and inventing one live is how candidates get caught | S2 is the clearest limit; a persona stem rehearsed so the honest answer is ready |
| B3 | "Tell me about the API or platform work that is closest to this role." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on S3 at the quote's own scope: the 30+ integrations, and the stages the quote names. Tell them in your own words. Answer slot: the R2 line makes a probe on which parts were yours likely. Say which; if you did not build the API itself, say so plainly and stay with the integrations you led | S3 is a derived bridge, so the limit is named in the answer; the stem is open so it supplies no event |
| B4 | "What is your experience with agile delivery?" | JD | [grounded] | Clarify strategy. No quoted sentence speaks to this. Answer slot: the R5 line makes a probe on how you have worked with sprints or iterations likely. If you worked that way, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it | S6 is a discovery gap; the dossier says clarify |
| B5 | "Why this role, and why now?" | EXP | [generic] | Give your actual reason in your own words; this pack does not supply one. Say it without running down your current work | The Skeptic's motivation-consistency probe; S1 names the move as adjacent, so your reason should too |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your 30+ integrations — how were they counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, all in your own words. How the 30+ was counted: if you know, say how; if you do not, say so plainly. What the count is sensitive to. The assumption behind it you would defend least. Which part was yours. Say each before it is asked | S1 and S3 both rest on this number, so it will be probed |
| C2 | "You wrote an integration playbook your team uses — what is in it, and what shows it is used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Describe what is in it in your own words; the pack does not name its contents. The dossier records it as inspectable, so if you can share it, decide beforehand what you may show. On use: say what you actually know; if you do not know, say so plainly | S4 touches this quote; high-confidence evidence, so the probe is about depth |
| C3 | "Tell me about the roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell it with the beats the quote states: quarterly, sessions you ran, client evidence, fed to product. Beyond that, answer from what you actually remember, and if you do not know, say so plainly. This is the line with limited inspectable proof, so volunteer what you can show and what you cannot. An agenda, notes or a follow-up message from one session would help | S5 is medium confidence; the dossier says to expect a probe here |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in this order: the integrations, the playbook, the sessions, each at its quote's scope. Then your own reason for this move, in your own words. Frame the move as adjacent work, never as PM experience | S1, S4 and S5 hold the quotes; the biography opener is scored |
| D2 | "How comfortable are you reading API docs and schemas?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the R3 line asks about API docs and schemas. If you worked with them in those integrations, say how, in your own words; if you did not, say so plainly, and say what you would read first. The quote itself says REST APIs, nothing about docs | S4 is a discovery row, so this is a slot and not a story |
| D3 | "What do you make of our partner API platform from what you have seen?" | CO | [generic] | I could not research Quartzline (see Sources), so this pack supplies no facts about its platform. Spend 20 minutes on its public developer documentation and changelog if they exist, and say only what you actually read. If you have not looked, say so plainly and say what you would look at first | CO question; generic because company research was refused |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Of the 30+ integrations, how much was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate. Hold the quote's own verb through two follow-ups: "I led them." Concede specifically if true: name a stage where others carried more. If any stage was shared, say which, in your own words; if none was, say so plainly. Do not fold on "led" just to ease the room | S1 and C1 are attribution magnets; the pressure form tests composure |
| E2 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] `prohibited_claims: "Having held a product manager title or role"`; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Concede first in the sourced words: "I haven't held a product manager title or role." Then the quote at its scope. Then stop; do not add claims to fill the sixty seconds | Time-boxed version of B1 |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Two squad leads disagree with you about what ships next quarter. How do you handle it?" | CASE | [generic] | Propose seam principles instead of claiming to know the seam: who decides what, what evidence settles a disagreement, when it escalates. Ask which decisions the PM owns alone; the dossier lists this as unverified. The problem needs no claim about your past | The dossier flags decision authority against the squad leads as open |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a piece of work that several people contributed to, where you can say what was yours and what was theirs, and where the relationship was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer-style probe; no quoted sentence carries it |

### H. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Open prompt from a persona stem; no values-style round detected, so low weight |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, what it cost, who agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-facing background makes this plausible; no published values were read |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | B1, B2, E2, A2 |
| R1 sub-claim, roadmap and prioritization authority | B1, B2, A2, A5, G1 |
| R2 "Shipped API or platform products" | B3, C1 |
| R3 "Technical fluency: API docs, schemas" | D2, A1 |
| R4 "Stakeholder management across engineering, sales, customers" | A4, C3, G1 |
| R5 "Agile delivery experience" | B4 |
| Responsibility: define and track adoption metrics | A3 |
| Responsibility: write specs and drive delivery with two engineering squads | none, and why: responsibilities are not requirements, and the probe arrives through B4 and G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority, and the dossier found no evidence of it. The answer tells you whether the role is what it is advertised as |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption metrics as a responsibility with no baseline given. It reads as diligence and tells you what you would be judged on |
| 3 | "How do the two squads split ownership of the API platform today?" | It surfaces the seam the first question depends on, and lets you hear how disagreements get resolved |
| 4 | "Who talks to integration partners today, and how often?" | Discovery is a stated responsibility; the answer shows how much partner access the role really has |
| 5 | "What would you want someone coming from integration work to learn first?" | It invites the adjacency conversation on your terms and shows a ramp plan mindset |
| 6 | "What would a good first 90 days look like for this role?" | It shows what success means to this manager and what they would measure |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Dossier `prohibited_claims: "Having held a product manager title or role"` | S1's quote at its own scope, plus the sourced plain acknowledgment: "I haven't held a product manager title or role." |
| Owned a product roadmap | Dossier `prohibited_claims: "Having owned a product roadmap"` and the acknowledge_gap area | The sourced plain acknowledgment: "I haven't owned a product roadmap." No bridge, no slot |
| Set prioritization for an engineering squad | Dossier `prohibited_claims: "Having set prioritization for an engineering squad"` | The sourced plain acknowledgment: "I haven't set prioritization for an engineering squad." No bridge, no slot |
| Influenced or shaped the roadmap | Inflated form of S5 | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is this pack's observation: your material says sessions that fed client evidence to product, not what product did with it |
| Shipped an API or platform product | Inflated form of S3 | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is this pack's observation: your material says client integrations of the vendor's APIs, not an API or platform product |

## Sources

- Provided: tuesday-dossier.md, version 1.1, consumed. It supplied role_profile (requirement text standing as the JD's lines), handoff_to_mock_interview (all fields), and decision as context only (conditional go, no hard gates). It carries no evidence_map, evidence_state or risk_register, so the fit-snapshot grades come from the handoff's verified evidence and weak areas.
- Searches sent: "Quartzline company values" (refused); "Quartzline interview process product manager" (refused); "Quartzline partner API platform strategy news" (refused). Nothing was fetched and nothing from outside the dossier is used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have fed a values sheet and VAL questions; the VAL bank is generic scaffolds instead |
| 2. Quartzline interview process, product manager | unavailable | Would have documented the loop; the loop here rests on your own words, one conversation with the hiring manager |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded the CO and CASE questions; they are generic, and D3 says so |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirements the fit snapshot and JD questions use |

## Upgrade menu

- Permission to run web searches (or Quartzline's public developer docs and changelog pasted in) → CO and CASE rows A1, A3, D3 become grounded, and values questions can be checked against published values
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → strategy brief, interviewer footprint if you get a name, recent org context
- The interviewer's name → an interviewer read, tuned persona weights, and a reverse question tied to their path
- The recruiter's prep notes → any pre-declared focus areas or deliverables; none are assumed here
- Your answers to the answer slots in S3, S4, S5 and S6 → those rows upgrade from derived to grounded, and A1 to G2 tighten
- One agenda, set of notes or follow-up message from a roadmap-input session → S5 moves from medium toward high
