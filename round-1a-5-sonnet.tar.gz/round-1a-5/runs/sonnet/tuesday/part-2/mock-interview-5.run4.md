Web search was refused, so I'm building the pack from your message and the recruiter's email alone. I'll say so in the pack. Next I'm writing the file.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-5-denied-2d610475/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for the 60-minute panel with Deepa as your future manager and Ross pushing on commercials. Web search was refused here, so it runs on your message and the recruiter's email alone. The market report wasn't in front of me, so the company-strategy questions and the differentiation advice are generic until you paste it. The pack has 19 questions, and the section 5 talk track for the 15-minute POV has three thesis options, each with a concession. The four-hour triage schedule is in the pack.

The question to rehearse most is B1: "You haven't sold into rail. What makes you credible with train operators from day one." Your own limits ("never sold into rail specifically", "never carried a direct quota, only influenced revenue") will be probed, and Ross will probe the 6-to-40 and £4M figures. The pack coaches you to say those limits plainly and hold only what your own sentences carry.

Say the word and I'll play Deepa or Ross on B1 or C2, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the job description text? Pasting it would re-grade the five fit rows against the posting and add a question per requirement.
Can you paste the sections of the market report that you think everyone else will treat as the headline? That would make the consensus item, the divergence and the "what I'd not do" in section 5 specific.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second round, Tuesday, 60 minutes, panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your point of view on where you would take Kelverton's operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and the recruiter says Ross will push on commercials.

Built from your message and the recruiter's email as you quoted it. No job description was supplied, the strategy report was not in front of me, and web search was refused in this session, so nothing here rests on research.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Question IDs run by persona. The letter F is skipped for personas because F1 to F5 are the fit-snapshot rows.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none in this pack: no published values are in hand and no values round is named) |
| EXP | Whether what you say about your work survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage (about four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 60 min | Write the 15-minute talk track once, then say it aloud against a timer until it fits | Section 5, A1 to A4 |
| 2 | 45 min | Rehearse the objection that will be asked: no rail sales, no direct quota | B1, B4, C3, D1 |
| 3 | 45 min | Write down what you know and do not know about how 6 to 40 and the £4M were counted, and say each aloud | C1, C2, D2 |
| 4 | 30 min | Reread the market report for one consensus item, one divergence and one thing you would not do | Section 5 differentiation, A4, A5, G2 |
| 5 | 30 min | Pick four reverse questions and rehearse the first words of each | Section 11 |
| 6 | 30 min | Buffer, or a live drill on B1 | Offer in the message |

Everything else is insurance.

## The fit snapshot

No JD was supplied, so requirements are the recruiter's own words and the role title, quoted. With the JD, these rows would be re-graded against the posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material carries channel growth at a payments company, not operator partnerships in rail, and the words stay at your sentence: "I took the ISV channel from 6 partners to 40." Answer slot: expect a probe on which part of that growth was yours. Say it in your own words, and if it was shared or not yours, say so plainly and stay with the sentence |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | low | [inferred] | transferability | Derived from one clause of yours, so it is coached as a clarify note and not asserted. Your material says bus and light rail network planning, not train operating companies or scheduling, and the words stay there: "For five years I worked in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on what "the operator world from the other side" meant in practice. Say what the work was in your own words, and if it did not put you in front of operators' own staff, say so plainly and stay with network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Say the figure at its own scope, "roughly £4M of influenced revenue", and the limit in your own stated words: "I haven't carried a direct quota; my number was influenced revenue." Answer slot: expect probes on how the figure was counted, what it is sensitive to, the assumption you would defend least and which part was yours. Answer each in your own words, and if you do not know how it was counted, say so plainly |
| F4 | "our operator partnerships" — recruiter's email | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past. The recruiter's email does not say rail sales experience is required; this row exists because you named the absence and the panel can probe it |
| F5 | "Senior Partnerships Manager" — role title in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap on the core partnerships work, but a CV-style line with nothing inspected behind it, so expect a probe. Lead with your own terms: running the ISV channel, and the growth from 6 partners to 40 |

## 5. Graded deliverable: the 15-minute point of view

The recruiter announced this, so it is graded. Grounded facts you may build on, each from the fit row named:

| Fact | Row | Exact quote |
|---|---|---|
| Channel you ran and its growth | F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" |
| Operator-side background | F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |
| Your stated limits | F3 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" |

Pick one thesis as the spine and keep the others as one-line alternates. The theses are hypotheses to test against the market report, not claims about Kelverton.

| Thesis | Argument shape | Mandatory concession | Provenance |
|---|---|---|---|
| T1: fewer, deeper operator partnerships | Concentrate the 18 months on a small set of partner types that sit closest to the operators' own planning work, and sequence them by the operator outcome each one changes, not by partner count | Depth gives up reach and early volume, and depth depends on operator access you would have to earn, since you have said you haven't sold into rail specifically (F4) | [generic] |
| T2: operators choose the partners | The operators' own stated needs decide which partners the programme adds next, so the programme is pulled by operators and not pushed by the partner list | It slows partner growth, and your operator-side view is bus and light rail network planning, not train operating companies (F2) | [generic] |
| T3: measure partnerships on operator outcomes first, revenue second | Agree one operator-facing measure per partnership, then the commercial measure beside it | Your own record is influenced revenue with no direct quota (F3), so this is exactly where Ross will push; say what you would agree with him and when | [generic] |

| Element | What to do | Provenance |
|---|---|---|
| Consensus item | Bring exactly one item from the report's shortlist, to show you read it. The report is not in this pack, so which item is yours to pick | [generic] |
| Divergence | One place where your thesis departs from the report's consensus, with your reason. Reciting the shortlist scores as homework; departing from it with reasons scores as judgment | [generic] |
| Anti-pick | One thing a partnerships team could do in 18 months that you would not, and why. The role includes saying no, so name it | [generic] |
| Requested close | End on what it means for the operators themselves: one or two things an operator's planner would notice, in operator language and not partner language, with no numbers you cannot source | [grounded] "Please land on what it means for the operators themselves" — recruiter's email |

Suggested shape for the 15 minutes: 1 minute framing and your stated assumption about what operator partnerships covers; 2 minutes on the starting point; 6 minutes on the thesis; 3 minutes on concessions and risks; 3 minutes on what it means for the operators. Treat the minutes as a suggestion and time yourself.

## Persona table

Loop: the recruiter's email establishes this one session (60 minutes, panel, 15-minute point of view, then Q&A) and names no values round, so no values cheat sheet is built. A panel blends the top two personas of each member's relationship.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa on where you would take partnerships, and follow-ups on your point of view | Highest. Hiring-manager prior plus a pre-declared 15-minute point of view | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Deepa on the gaps | Co-highest. Hiring-manager prior, and the gaps you have stated yourself (F3, F4) | Rehearse the single predictable objection until it is boring; bridge only from what you have said; give a ramp plan |
| Data-Driven Prober | Ross on the figures | Mid. The recruiter says Ross will push on commercials, and the figures are the headline of your background | Know what you can and cannot say about how each number was counted; name the weakest assumption first |
| Pressure | Ross interrupting and time-boxing | Mid. The recruiter's word is "push"; the style is a reading, not a documented fact | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Peer Evaluator | Ross on where partnerships and commercial meet | Low. His relationship to the role is not stated | Offer seam principles and reciprocity, and do not pretend to know the seam |
| Conversational | Deepa's opener | Low, but the opener is scored | A 90-second arc, and never "I think you've covered everything" in the reverse-question slot |

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] | This is the 15-minute point of view; use the section 5 talk track. Open by saying aloud what you take operator partnerships to cover, so the panel can correct it. The question needs no claim about your past, so the guidance makes none | The recruiter pre-declared it, so it is the most certain item in the pack; CASE because it scores structure and reasoning on the role's own problem |
| A2 | "Which one operator outcome should partnerships move, and how would you know it moved." | CASE | [grounded] | Choose one outcome from your reading of the report, say how you would see it move, and say what you would not be able to see in the first six months. Keep it in operator terms. No claim about your past | Serves the recruiter's requested close; F2 is why this needs care, since the operator-side view is adjacent only |
| A3 | "A partner you've just signed wants a feature the operators haven't asked for. How do you decide whether to back it?" | CASE | [generic] | Structure it: what you would ask first, whom you would ask among the operators, what backing it costs and displaces, and what you would tell the partner either way. It needs no claim about your past, so the guidance makes none | A live problem of the kind a hiring manager sets; CASE because it asks for a decision under competing interests |
| A4 | "What would you choose not to do in your first 18 months." | CASE | [generic] | Name the anti-pick from section 5 and the reason, then the cost you accept by not doing it. No claim about your past | The report's shortlist is shared with other candidates, so the divergence is where judgment shows; CASE because it asks for a trade-off |
| A5 | "Where do you see our operator partnerships strong today, and where thin." | CO | [generic] | Answer only from the report you have read and anything you have checked yourself, and say which. Say what you can see from outside and what you would need Deepa's view on. Do not assert anything about Kelverton you cannot source. No claim about your past | This is the company-altitude question; `[generic]` because the report was not in this pack, so it becomes grounded once its content is added |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What makes you credible with train operators from day one." | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning" | The highest-ROI rehearsal in this pack, because it will be asked in some form. Hold on the quotes: "I haven't sold into rail specifically." Then the adjacent work at its own scope: "For five years I worked in transport consulting, in bus and light rail network planning." Answer slot: if that work put you in front of operators' own staff, say how, in your own words; if it did not, say so plainly and stay with network planning. Then a ramp plan, said as a plan and not a past: whom you would meet first and what you would ask. Hold through two follow-ups by returning to the quotes, never by adding to them | F4 is the stated gap and F2 is the adjacent evidence; JD because it scores whether you can do the listed job including its gap |
| B2 | "Your channel numbers come from payments. What carries over to a rail operator and what doesn't." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Say what you ran, at its own scope: "I ran the ISV channel at a payments company." Answer slot: if particular things you did there would carry over, name them in your own words; if the differences outweigh them, say so plainly. Say the limit before it is asked for | F1 and F5 are the evidence; EXP because it tests whether the claim survives scrutiny |
| B3 | "Why leave payments for rail-tech, and why now." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Your message gives no reason, so the pack supplies none. Your reason has to be your own, and it has to hold up against B2. If no reason comes to mind that you would say aloud, say so plainly, then give the nearest honest thing you do have, or how you are weighing it | A standard Skeptic probe on motivation consistency; EXP because it tests the story behind the move |
| B4 | "Which part of this role would you be weakest at on day one." | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Choose one limit and say it in your own stated words: "I haven't sold into rail specifically, and I haven't carried a direct quota; my number was influenced revenue." Then what you would do about it in the first months, said as a plan. Calibrated candor beats bluffing a skill a panel member owns | F3 and F4 hold both stated limits; JD because it scores honest self-assessment against the role |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You took the channel from 6 partners to 40. Walk me through how that was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the sentence at its own scope. Answer slot: how the 6 and the 40 were counted, what the count is sensitive to, the assumption you would defend least and which part of the growth was yours. Answer each in your own words; if you do not know how it was counted, say so plainly. Name the weakest assumption before the panel does | F1 holds the headline figure; EXP because probers test whether a number survives its own assumptions |
| C2 | "The £4M is influenced revenue. How much of it would you call yours." | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Keep the word influenced every time you say the figure. Answer slot: how it was counted, what it is sensitive to, and which part was yours, in your own words; if it was shared or not yours, say so plainly. Never move from influenced to closed or owned | F3 is where the commercial push lands; EXP because it tests attribution honesty |
| C3 | "Without a direct quota behind you, how do you think about commercial accountability for partnerships here." | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Hold the stated limit: "I haven't carried a direct quota; my number was influenced revenue." Then answer as a plan: which measure you would propose agreeing with Ross, and what you would want in place before being held to it. The plan makes no claim about your past | F3 is the row; JD because it scores whether you can carry the role's commercial side |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail." | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40"; "Never sold into rail specifically" | Hold only what the quotes carry: you ran the ISV channel and took it from 6 partners to 40. Concede the rail point plainly: "I haven't sold into rail specifically." Hold through two follow-ups by returning to the quotes, and concede uncertainty specifically without folding on what you did say | F4 against F5; JD because it asks you to defend fit under a time-box |
| D2 | "That £4M. How much of it was actually you." | EXP | [grounded] "roughly £4M of influenced revenue" | Pause and restate the figure as influenced revenue. Answer slot: say which part was yours in your own words; if it was shared or not yours, say so plainly and stay with the figure at its own scope. Do not defend a larger share to restore harmony | F3; EXP because attribution is what the question scores |
| D3 | "A partner wants a revenue share on operator contracts it introduced. Where do you hold and where do you give." | CASE | [generic] | Say what you would need from Ross before answering, then where you would hold and where you would give, and what you would put in writing. Hold your position through two follow-ups and concede specifically. No claim about your past | A commercial live problem of the kind the recruiter signalled; CASE because it asks for a position and its limits under pushback |

### E. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does partnerships stop and commercial start, and what happens when we disagree." | CASE | [generic] | Offer principles for the seam and do not claim to know where it sits today. Say what you would bring Ross's team as well as what you would need from it. Your material holds no disagreement story, so the pack supplies none | Ross's relationship to the role is not stated, so this stays low weight; CASE because it asks for a working method |
| E2 | "How do you handle credit when a deal needs both of us." | CASE | [generic] | Say the rule you would propose and why, and how you would raise it early. No claim about your past | The credit probe is a standard peer stem; CASE because it asks for a rule under shared work |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc in your order: the consulting years in bus and light rail network planning, then the partnerships years, the last four running the ISV channel, then your own reason for this role in your own words. End by pointing at the operators. Keep to what the quotes carry | F2 and F5; EXP because the opener is scored for economy and honesty about the path |
| G2 | "What stood out to you in what you've read about us." | CO | [generic] | Name one thing you would challenge or extend, not one you would recite. Say which source it came from. No claim about your past | A casual question about a document every candidate received; CO because it tests homework depth |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1: the 18-month point of view | A1, A2, A4, B2 |
| F2: land on what it means for operators | A2, B1, G1 |
| F3: commercials | C1, C2, C3, D1, D2, D3 |
| F4: operator partnerships, rail | B1, B4, D1 |
| F5: Senior Partnerships Manager | B2, C1, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which operators would you most want me to meet in my first 60 days, and what would you want me to learn from each." | Shows operator-first thinking and answers B1's ramp plan with the panel's own priorities |
| 2 | "When you say operator partnerships, which partner types and operator groups are in scope for the next 18 months." | Surfaces whether your point of view rested on the right assumption |
| 3 | "How does commercial want partnership results measured." | Turns Ross's push in C2 and C3 into a shared definition |
| 4 | "What would a strong first six months look like, and what would tell you it wasn't working." | Lets Deepa state her bar, which is the best preparation signal you can ask for |
| 5 | "Where do partnerships and commercial split the work on a deal today, and where do you want that line to move." | Opens the seam conversation from E1 on your terms |
| 6 | "What could a new person do in their first month that would genuinely help your team." | A reciprocity question for Ross |
| 7 | "Which idea in the strategy report do you expect to be hardest to land with operators." | Shows you read it and invites the panel to say where they think it is soft |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| Has carried a quota or closed the revenue | Negative you stated, F3 | "I haven't carried a direct quota; my number was influenced revenue." No slot |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is this pack's observation: the material says bus and light rail network planning, not train operating companies |
| Built or designed the ISV channel, or chose its partners | Inflated form of F1 | F1's quote at its own scope. The material says you ran the channel and it grew from 6 to 40, not how it was built or who chose the partners |
| The £4M was revenue you generated | Inflated form of F3 | The quote at its own scope: influenced revenue. The limit is this pack's observation |

## Sources

Provided: your message, including the recruiter's email as you quoted it. The market report the recruiter attached was not in front of me and nothing here draws on it.

Searches, each refused:

- `Kelverton Rail values`: refused
- `Kelverton Rail interview process partnerships manager`: refused
- `Kelverton Rail scheduling software train operating companies strategy`: refused
- `Deepa VP Partnerships Kelverton Rail`: refused
- `Senior Partnerships Manager rail technology job description train operating companies`: refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have moved any VAL questions; none are in the pack |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have checked the loop beyond the recruiter's description |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused and the report was not in hand. It would have moved A5 and G2 from generic to grounded |
| 4. `{interviewer name} {company}` | unavailable | Every call was refused. It would have moved the interviewer read, which is absent |
| 5. representative `{role title}` JD | unavailable | Every call was refused. It would have moved the JD-based rows |

## Upgrade menu

- The job description text → F1 to F5 are re-graded against the posting, and each JD requirement gets its own question
- The market report, pasted in part or whole → A4, A5, G2 and section 5's differentiation move from `[generic]` to `[grounded]`, and the consensus item and anti-pick become specific
- Your answers to the answer slots on F1 to F3 (which part of the 6 to 40 and the £4M was yours, how each was counted, what your consulting work put you in front of) → B1, B2, C1 and C2 become story-mapped
- The interviewers' full names or profiles → an interviewer read, tuned persona weights and a reverse question tied to their paths
- Web search permitted → the values, loop, strategy and interviewer targets run, plus a deeper pass offered once: up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from an earlier pass → verified evidence and a named highest-ROI objection, in place of the inferred one here
