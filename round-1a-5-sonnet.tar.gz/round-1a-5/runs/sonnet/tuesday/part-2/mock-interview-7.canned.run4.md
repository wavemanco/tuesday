Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-7-canned-fd59c834/saltmarsh-games_live-operations-producer_interview_pack.md`.

It has 19 questions across six interviewer styles. I built it for the format Saltmarsh's interviewing page describes: one 60-minute session, a live-outage tabletop followed by a values conversation. I assumed Tobias is the hiring manager running that session.

The highest-ROI prep is C2, the in-app-purchase question. You named that limit yourself. I read the values and interviewing pages in full. For the Project Larkspur news and Tobias's GDC talk I saw only search summaries. The talk's host site looks unusual, so check it before leaning on it.

Say the word and I'll play the Case interviewer through the outage tabletop (A1), or the Skeptic on C2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Would Tobias be your direct manager, or is the hiring manager someone else? If he's not, the persona weights change.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. I assumed he is the hiring manager, because Saltmarsh's interviewing page says its single 60-minute interview is run by the hiring manager. If he is not, the persona weights change.
**Round:** One 60-minute session. Per the interviewing page it is a live-incident tabletop on a simulated outage during a live event, then a values conversation.
**Mode:** Session. Research tier L1.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether your past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether your CV claims survive scrutiny and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, including where you have gaps |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview and asks nothing of you here. Answer it from your own experience, or say plainly that the practice was not yours.

Every claim about your own past rests on a sentence you wrote, quoted in the Provenance column. Where no sentence of yours carries a story, you get a selection scaffold that ends in an honest branch, not a story written for you.

## Prep triage

You have until Friday. In order:

1. Rehearse C2 aloud until it is boring. It is the highest-ROI prep in this pack. Then run D1.
2. Run the tabletop twice, out loud, against a timer: A1, A2, D3.
3. Prepare one story or one honest "nothing comes to mind" for each of B1, B2 and B3.
4. Read the full Project Larkspur post yourself before A4 and F2. I only saw a search summary of it.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "two of our mobile titles" makes a probe on scale likely. If any drops were timed events, or you worked across more than one title, say which and how, in your own words. If not, say so plainly and stay with the main title's calendar |
| R2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this requirement either way. Answer slot: the JD names four teams, so expect a probe on each. If you coordinated any of them on a drop, say which and what you did, in your own words. If you did not, or a drop was handled another way, say so plainly and stay with the calendar you ran |
| R3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or chose the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if any review followed a drop or event and any part of it was yours to set, say what and how you decided. If there was no such step, or it was not yours, say so plainly and stay with the presenting |
| R4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you ran it release by release, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage" makes a probe on release-time use likely. If you ran it with QA on releases, say how, in your own words. If QA ran it, or it was used another way, say so plainly and stay with the checklist you wrote |
| R5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The years are stated. Your material does not show whether the title was live-service, and a probe on "associate" is plausible. Answer slot: if the title was live-service, say so and what the role covered, in your own words. If it was not, say so plainly and stay with what the role was |
| R6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran it, weekly, for the main title, for two years |
| R7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect a probe on which measures and how they were counted. Lead with it in its own terms: monthly, retention numbers, to the studio head. You gave no figures, so the pack adds no defend-the-number rows |
| R8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is writing, but your material does not show whether it was clear to its readers. Answer slot: if a written piece of yours could be shown, such as a summary, a release note or a player message, say which. If none exists, say so plainly and say how you would draft one |
| R9 | "season-pass model" — Project Larkspur news, from a search summary and not in the JD | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A limit you stated, and the JD does not list it. The words you may say: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing that makes the gap sound smaller |

## Interviewer read

| Fact | Source | Provenance |
|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games | Your message, and the talk listing's own description | [grounded] |
| He gave a GDC 2026 talk titled "Patch Notes Are a Promise" | Search summary of the talk listing; I did not open the talk | [grounded] |
| His argument, per that summary: a live team is judged by how often its patch notes describe what actually shipped | Same summary | [grounded] |
| He was previously a QA lead at a console studio | Same summary | [grounded] |

What this suggests for the interview. These are the pack's own reading of the facts above:

- He frames "shipped versus promised" as the measure of a live team, and Saltmarsh's second value says the same thing. Be exact in every answer about what was built versus what was planned. A2 and B2 are where this shows.
- A former QA lead is likely to probe gating and go or no-go decisions. A5 and R4 are your ground there.
- Mirror opportunity, on a shared professional lane and not on identity. He moved from QA into running live operations, and your sentence is "Wrote the release checklist our QA team still uses." (R4). Reverse question 2 uses this. Do not claim more overlap than that sentence carries.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case / Strategist | A live outage tabletop: clarify, decide, communicate | High. The interviewing page documents a tabletop on a simulated outage during a live event, and the hiring-manager prior favours Case and Skeptic | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully | A, 5 questions |
| Values / Behavioral | The second half of the hour is a values conversation against three published values | High. The loop source documents the values conversation | Map a story to each value where one of your sentences carries one. Where none does, use the scaffold and its honest branch. Use "we" for context and "I" for contribution | B, 4 questions |
| Skeptic | Probes your stated limits and the JD's four-team coordination | Medium-high. The hiring-manager prior, and you named two limits yourself | Rehearse C2 until it is boring. Bridge only from adjacent evidence you stated | C, 3 questions |
| Pressure | Interrupts the tabletop and forces a decision | Medium. A simulated outage invites time pressure. That is the pack's inference from the loop source | Pause, restate, hold a decision through two follow-ups, concede specific uncertainty | D, 3 questions |
| Data-Driven Prober | Retention numbers and KPIs | Low-medium. The JD names retention metrics, but you gave no figures to probe | Know what you can and cannot say about how the numbers were counted. Say plainly when you do not know | E, 2 questions |
| Conversational | The opener, such as "walk me through the journey" | Low. It is not a hiring-manager prior, but the hour has to open somehow | Prepare a 90-second arc. Treat casual questions as scored | F, 2 questions |

No Peer Evaluator bank. If Tobias would be a peer and not your manager, tell me and I will add one. This loop's weights come from a documented loop source, not an archetype fallback.

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We are mid-event and the reward is not landing for part of the player base, and community is filling with reports. You have fifteen minutes. What do you do first?" | CASE | [inferred] | Say your structure aloud. First clarify: who is affected, since when, is it still happening, what changed in the last release. Then the objective: stop the harm and tell players the truth. Then who you need: the JD names design, art, engineering and community, so say what you need from each. Then what you would ask engineering for: cause, time to fix, rollback option. Close with what you would record for the post-event review. Challenge one premise politely, such as asking what "part of the player base" means before acting. The question asks about no past, so the guidance makes no claim about it | R2 is the requirement it scores. CASE because the interviewing page describes a tabletop on a simulated outage. [inferred] because the scenario is this pack's own, derived from that description |
| A2 | "Draft the first message to players about that outage. What do the three sentences say, and what stays out?" | CASE | [inferred] | Say what is known, what is not known yet, and when the next update comes. Saltmarsh's value reads "we announce what is built, not what is hoped", so leave out any fix time you cannot back and any guess at the cause. Say the three sentences aloud rather than describing them. The question asks about no past, so the guidance makes none | R8 is the requirement it scores, as a live exercise. CASE delivery on a written-communication requirement. [inferred] because it is derived from the JD line and the published value |
| A3 | "After the event, retention for that cohort is down against the previous event. What do you look at first?" | CASE | [inferred] "Presented the monthly retention numbers to the studio head." | Clarify before diagnosing: down by how much, for which cohort, over what window, against which event. Separate "the event changed" from "something else changed", such as an outage, a release, or a calendar collision. End with the decision the review should produce. Invent no numbers. The one thing your sentence carries here is the audience: you presented the numbers monthly to the studio head. Everything about how the numbers were built stays out of the answer unless you say it in your own words | R3 and R7 are the requirements it scores. CASE delivery on a JD requirement. [inferred] because the scenario is this pack's own |
| A4 | "From February 2027 two of our titles share one events calendar under one live-ops group. How would you sequence the first month?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "never worked on a game with in-app purchases" | Ask what is fixed first: when the season pass starts, which events must land, and who owns the calendar. Then the collisions: events on both titles the same weekend, shared art and engineering capacity, one release checklist or two. Propose one freeze rule and one review rhythm. The beat your sentence supports is that you ran a weekly calendar for a main title. Where monetization comes up, say it plainly: "I haven't worked on a game with in-app purchases." Then ask who owns that on the team. The Larkspur facts are from a search summary of the company's post, so read the full post first | R1 and R9 are the rows it draws on. CO because it needs the company's current strategy, and CASE delivery. Sourced to the Project Larkspur summary in Sources |
| A5 | "Walk me through the go or no-go for tonight's release with QA. What has to be true before it ships?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on R4: you wrote the checklist and QA still uses it, which are the only beats the quote states. Answer slot: the JD's "manage" makes a probe on release-time use likely. If you ran it with QA on releases, say how, in your own words. If QA ran it, or it was used another way, say so plainly and stay with the checklist you wrote. Then the live part as a plan: what blocks a release, who signs off, what happens when something fails late | R4 is the requirement. CASE delivery on a JD requirement. A former QA lead is likely to care about this one, per the interviewer read |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Pick a drop where what players needed and what the calendar said pulled apart. It needs a named decision, what it cost, and what the players got. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is that you ran the weekly content-drop calendar for your main title, or say how you would handle the clash | Value 1 on the published values page. R6 is the nearest row. VAL because it scores a specific published value, not generic virtue |
| B2 | "Ship the Patch Not the Promise: tell me about a time you had to choose between announcing something early and waiting until it was built." | VAL | [grounded] | Selection scaffold. Pick a time you held an announcement or a commitment until the thing existed. It needs a named stake, what you said in the meantime, and how it landed. If no such time comes to mind, say so plainly, then say how you would handle it: announce what is built, say what is not known yet, and give the next update time | Value 2 on the published values page. Your material carries no sentence on this, so the guidance is a scaffold and not a story map |
| B3 | "Leave the Build Greener: tell me about a process you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on R4. The beats the quote states are the checklist, that you wrote it, and that QA still uses it. Answer slot: the value's own line is "the checklist better than it found them", so expect a probe on whether it changed. If you revised it after a release, say what and why, in your own words. If it stayed as first written, or revisions were not yours, say so plainly and return to the checklist QA still uses | Value 3 on the published values page. R4 is the evidence row |
| B4 | "Tell me about a time you delivered a number or a call that people did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. It needs a fact leadership did not want, what you said, and how it landed with the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you presented the monthly retention numbers to the studio head. Your material does not say whether any were unwelcome, so do not say they were | A standard values-round probe, and it ties to value 2. R7 is the nearest row |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" and "Never led a team" | Name one, in your own words, before they do. Your material states two limits, and the JD lists neither, so choose the one that bears more on the work you expect. Say it plainly, then give a ramp plan as a plan: the first two things you would learn and who you would learn them from. Calibrated candor beats bluffing a competency the interviewer owns | R9 and R2 are the rows behind the two limits. JD because it scores honest self-assessment against the listed job |
| C2 | "You haven't worked on a game with in-app purchases. How would you plan a live-events calendar around a season pass?" | JD | [grounded] "never worked on a game with in-app purchases" and "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Concede first and plainly: "I haven't worked on a game with in-app purchases." Then hold only what the quote carries: you ran a weekly content-drop calendar for your main title. Then plan: what the season structure fixes, what has to be reserved for it, who owns monetization decisions, how you would learn the economy. Do not describe how monetization works. First follow-up, "So who decides whether an event is worth it?": return to the calendar you ran and say that call belongs to whoever owns the economy. Second follow-up, "What would you get wrong in your first season?": concede specifically that you would not yet judge the economics, and that you would pair with whoever owns them. Never fold on the calendar claim, and never extend it | R9 is the gap, and A4 shows why it matters here. It is the single most likely objection to this candidate: you stated the limit and the company's news points at the season pass. JD content, CASE delivery. Deepest rehearsal means the most follow-up levels and the limit named before it is asked for |
| C3 | "The JD has you coordinating design, art, engineering and community on every update. You have never led a team. How would you get four teams working to one calendar?" | JD | [grounded] "Never led a team" and "I ran the weekly content-drop calendar for our main title for the last two years." | Say it plainly: "I've never led a team." Coordinating is not leading, and the JD asks for coordination. Answer slot: the JD names four teams, so expect a probe on each. If you coordinated any of them on a drop, say which and what you did, in your own words. If you did not, say so plainly and stay with the calendar you ran. Then the first two weeks as a plan: meet each lead, ask each for the lead time they need, keep one visible calendar | R2 is the requirement and the least evidenced of the JD's responsibilities. JD because it scores the listed duty including its gap |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has already run live events on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses." and "never worked on a game with in-app purchases" | Pause, restate the question, then hold. The position held is what the quotes carry: you ran the weekly content-drop calendar for your main title, and you wrote the release checklist QA still uses. Concede specifically: you have not worked on a game with in-app purchases. Do not claim two-title or live-events scale. Hold through two follow-ups by returning to the quotes, not by adding to them | R1 and R9 are the rows the pressure lands on. JD because it scores fit against the listed job, delivered as a pressure question |
| D2 | "Those retention numbers you presented: how much of them was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold what the quote carries: you presented them, monthly, to the studio head. Answer slot: if you pulled, built or chose any part of them, say which. If someone else produced them, say so plainly and stay with the presenting. Do not fold on the presenting, and do not stretch it | R7 is the row. EXP because it tests attribution |
| D3 | "Stop. Engineering wants to roll back, community wants it left live, and the studio head wants a statement in ten minutes. Decide." | CASE | [inferred] | Pause. Restate the three asks. Ask the one fact that decides it, which is what a rollback costs players. Decide, and say why. Hold the decision through two follow-ups. Concede the specific thing you do not know, never the decision just to restore calm. The question asks about no past, so the guidance makes none | R2 is the requirement. CASE because it is a live problem. Pressure style because a simulated outage invites interruption, which is the pack's inference |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on R7: monthly, retention numbers, to the studio head, which are the beats the quote states. Answer slot: the JD says "comfortable with player-retention metrics", so expect a probe on which measures were in them and how each was counted. Say which and how, in your own words. If you do not know how one was counted, say so plainly. If you presented numbers someone else prepared, say so and stay with the presenting | R7 is the row. EXP because it tests whether the claim survives scrutiny. You gave no figures, so there is no defend-the-number question |
| E2 | "After an event, which KPIs would you put in front of me, and what would each one let us decide?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Choose a small set in your own words and tie each to a decision. Say what you would leave out and why. The only claim about your past this answer can carry is that you have presented retention numbers monthly to a studio head. Do not extend it to owning the review | R3 is the requirement. JD because the role owns the KPIs the review reports. The question asks about the future, so you choose the KPIs |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio.", "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order, each sentence in your own words at its own scope: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for the main title, the release checklist QA still uses, the monthly retention numbers to the studio head. Answer slot: close with why Saltmarsh and why live ops. Your material gives no reason, so say yours in your own words. Answer slot: if the puzzle title was live-service, say so, and if it was not, say so plainly | R5 and R6 are the rows. EXP because it is the biography question. Casual questions are still scored |
| F2 | "What have you seen of what we are changing next year?" | CO | [grounded] | Say only what the public post says, from the summary I saw: Project Larkspur moves two titles to a season-pass model with one shared events calendar from February 2027 and retires per-title event teams in favour of a single live-ops group. Read the full post first. Then ask one question back instead of offering an opinion on monetization | R1 and R9 are the rows it connects to. CO because it is a company-knowledge probe. Sourced to the Larkspur summary in Sources |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1 Plan and run the live-events calendar for two mobile titles | A4, C2, D1, F2 |
| R2 Coordinate design, art, engineering and community | A1, C3, D3 |
| R3 Own the post-event review and its KPIs | A3, E2 |
| R4 Manage the release checklist with QA | A5, B3 |
| R5 3+ years producing live-service games or apps | F1 |
| R6 Experience running a content calendar | B1, F1 |
| R7 Comfortable with player-retention metrics | A3, D2, E1 |
| R8 Clear written communication | A2 |
| R9 Season-pass familiarity (not in the JD) | A4, C1, C2 |

## Values cheat sheet

A values-style round is detected: Saltmarsh's interviewing page documents a values conversation.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, as in B1. If no story comes to mind, say so plainly, then use the nearest row, R6: "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, as in B2. No row of your material carries a story for this one. If none comes to mind, say so plainly and say how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | R4: "Wrote the release checklist our QA team still uses." Beats as stated in B3, with its answer slot on whether it changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. How do you measure that here, and where does the producer's post-event review fit in?" | Ties to his own published work and to R3, and shows you prepared on him specifically. I only saw a summary of the talk, so read or watch it before using this one |
| 2 | "You came up through QA before running live operations. What did that change about how you want producers and QA to work together?" | Ties to his own career path and invites him to talk about the release process you have the most evidence in (R4) |
| 3 | "From February the two titles share one calendar under one live-ops group. What does this role look like in the first season, and who does it report into?" | Shows you read the company's own announcement and asks the structural question the JD leaves open |
| 4 | "What would a strong first ninety days look like for someone who has not worked on in-app purchases?" | Puts your stated limit on the table as a plan and asks for the ramp he would give you, which turns C2 into a working conversation |
| 5 | "What did the last post-event review you ran here end with: what decision, or what change?" | Scores R3 from the employer's side and shows you think of a review as ending in a decision |
| 6 | "How do design, art, engineering and community hand an update to live ops today, and where does that hand-off break most often?" | Scores R2 from the employer's side and gets you the real shape of the coordination before you take the job |

## Prohibited claims

Built before the banks. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated: "Never led a team" | The plain acknowledgment: "I've never led a team." No slot. C3's slot covers coordination only, and says plainly if that was not yours either |
| Worked with in-app purchases, monetization or a season pass | Negative you stated: "never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. Never described as something you have seen |
| Ran live events across two titles | Inflated form of R1 | R1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for the main title |
| Owned the post-event review and the KPIs it reports | Inflated form of R3 | R3's quote at its own scope: you presented the numbers. The material does not show who set or built them |
| Managed the release checklist with QA on each release | Inflated form of R4 | R4's quote at its own scope: you wrote the checklist and QA still uses it |
| Produced or analysed the retention numbers | Inflated form of R7 | R7's quote at its own scope: you presented them |

## Sources

Provided: the JD as pasted; your background as written in your message; Tobias Wrenfield's name and title from your message. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | Returned |
|---|---|
| Search: "Saltmarsh Games values" | https://saltmarshgames.com/values |
| Search: "Saltmarsh Games interview process live operations producer" | https://saltmarshgames.com/careers/interviewing |
| Search: "Saltmarsh Games mobile studio strategy news" | https://saltmarshgames.com/news/project-larkspur, summary only, not opened |
| Search: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" | https://talks.gdconf.example/2026/patch-notes-are-a-promise, summary only, not opened. The host is not one I could confirm as the conference's own site, so treat the talk details as unverified until you have seen the page |
| Fetch: https://saltmarshgames.com/values | The page, read in full: three values and their one-line meanings |
| Fetch: https://saltmarshgames.com/careers/interviewing | The page, read in full: the recruiter call, then the Outage Hour |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1 to B3, with the three official names |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one 60-minute session of tabletop then values conversation. Persona weights follow it, and the archetype fallback was not used |
| 3. `Saltmarsh Games strategy / recent news` | yes | A4, F2 and reverse question 3. Read from the search summary only |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read and reverse questions 1 and 2. Read from the search summary only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's description of the Outage Hour (which game, what kind of event, what tools or runbook) → A1 to A3 and D3 become title-specific and can move from `[inferred]` to `[grounded]`. One email to the recruiter is enough
- Which two titles the role covers → A4 and F2 stop resting on the assumption that the JD's two titles are the ones in the Larkspur post
- Your own answers to the answer slots: whether the puzzle title was live-service, whether you coordinated any of the four teams, who produced the retention numbers, whether the checklist changed after releases → R2, R3, R4, R5 and R7 move from discovery or transferability toward grounded, and the matching bank cells get tighter
- A redacted copy of the release checklist → R4 can move from `medium` to `high`, since it is the inspectable artifact for a producer's process work
- A writing sample, such as a release note, a post-event summary or a player message → R8 moves from `low`
- Any figures from your work, such as a retention figure you reported or how many drops you shipped → adds defend-the-number rows to the EXP bank
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the season-pass change, Tobias's talk read in full, and loop reports for this role family. Say the word if you want it
- A `tuesday-dossier.md` from an earlier fit review → sharper gap handling and ready-made objections. Optional; this pack does not need one
