I'm running the company research for your pack: three searches on Quartzline's values, interview process and strategy. Then I'll build the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-4-denied-11357785/Quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a 45-minute hiring-manager round. It has 22 questions across seven personas, plus six reverse questions for you to ask.

The web searches I tried (Quartzline's values, interview process and strategy) were refused. Everything about the company itself in the pack comes from your dossier or is generic. No company-strategy question is written, and the pack says so.

The pack names your dossier's objection (A1: no PM title, no roadmap) as the question to rehearse first. It reuses your dossier's prohibited claims and its acknowledge-gap strategy for roadmap ownership.

Say the word and I'll play the Skeptic on A1, running a live drill with follow-ups.
I can also save an updated `tuesday-dossier.md` recording what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, 45 minutes, Thursday. Interviewer name not given. Built from your underwriting dossier (v1.1) and your note on the round; no web research ran (see Sources), so everything about Quartzline itself is `[generic]` or comes from the dossier.

## How to use this pack

- **Personas** are how a question arrives (who is asking, in what style). **Types** are what is being scored: VAL (values), EXP (work-experience deep-dive), JD (role and requirements), CO (company and strategy), CASE (live problem).
- Guidance is scaffolding, not a script. Where a line is in quotation marks it is your own verified sentence from the dossier, kept at its own scope. Say it in your own words.
- An **answer slot** is an instruction for the interview, not a question to you here: it names what an interviewer is likely to probe and gives two honest branches, including "that was not part of what I did".
- **Highest-ROI prep: A1.** The underwriter named that objection; rehearse it until it is boring, then run E1 as its sixty-second version.

## Fit snapshot

Requirement lines are quoted from the dossier's `role_profile`. Evidence is quoted from the dossier's `verified_candidate_evidence`. The confidence on F1, F5 and F6 is the underwriter's grade for that area; on F2 to F4 it is this pack's.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | Underwriter strategy: bridge, positioned as adjacent and never as PM experience. The plain acknowledgment has a source in `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." Then the bridge at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit, said before it is asked for: that is integration delivery, adjacent to the job and not the job. The band is low because the evidence is adjacent, not because the claim is weak |
| F2 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The pack's observation: your material shows integration work on the vendor's APIs and a playbook, and does not show whether any API or platform product shipped through your work; the dossier gives R2 no weak-area entry, so no strategy constrains it. Answer slot: R2 is a must-have, so a probe on what shipped is likely. If any API or platform product shipped through your work, say what it was and which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The quote shows REST API work including architecture; it does not show whether docs or schemas were yours. Answer slot: the JD names API docs and schemas, so expect a probe. If you read, wrote or reviewed either in those integrations, say which and what you did; if the work did not involve them, say so plainly and stay with the architecture stage the quote names |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | Lead with the sessions at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Limit to volunteer: the sessions are confirmed but have limited inspectable proof, so expect a probe, and say plainly what you know and do not know about what happened to the input. The quotes reach clients and product; engineering and sales are not shown. Answer slot: if you worked with engineering or sales in these integrations or sessions, say how and what you did; if you did not, say so plainly and stay with clients and product |
| F5 | "Agile delivery experience" — dossier R5, preferred | none given | low | [grounded] | discovery | Underwriter strategy: clarify; no verified sentence speaks to this requirement, so none is quoted. Answer slot: the JD's wording is "Agile delivery experience", so expect "have you worked that way". If you have, say how, in your own words; if you have not worked that way, say so plainly, and add what you would want to confirm: how the two squads define and run their delivery |
| F6 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | Underwriter strategy: acknowledge_gap, no bridge. The words have a source in the `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" and in `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past: what you would learn first. Nothing added to make the gap feel smaller, and the roadmap-input sessions in F4 are not offered here as a substitute |

## Persona weights

Relationship prior for a hiring manager: Case/Strategist and Skeptic. No loop source establishes Quartzline's loop, so the fallback archetype is Generic, and the weights below rest on the round-type prior and on the dossier, not on a documented Quartzline process. No values-style round is detected.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title and roadmap gap, why PM, why now | High, 5 questions. The dossier's named objection is a Skeptic item, and the hiring manager is buying capability and derisking gaps | Rehearse the one objection (A1) until it is boring; bridge only with the dossier's adjacent evidence and its limit; concede the acknowledge_gap area plainly, with a ramp plan |
| B. Case/Strategist | Live problems from the actual role: diagnose adoption, set priorities, plan discovery | High, 5 questions. Hiring-manager prior; the JD's responsibilities are the source of the cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud; ask the decision-rights question rather than assuming it |
| C. Data-Driven Prober | Reads the evidence line by line; asks how the 30+ was counted, what the playbook holds | Mid, 3 questions. A headline figure and an inspectable playbook invite it, and the JD makes adoption metrics a responsibility | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; offer to walk through the playbook |
| D. Conversational | Friendly opener, "walk me through the journey" | Mid, 3 questions. The first five minutes of a 45-minute call are usually this | A 90-second arc built only from your three verified sentences; treat casual questions about the JD's topics as scored |
| E. Pressure | Time-boxed "why you over a PM with three years of the job" | Low, 2 questions. It arrives as the pressure version of A1 | Pause, restate, hold the quoted claim through two follow-ups, concede specifically |
| F. Peer Evaluator | The seam between the PM and the two squad leads | Low, 2 questions. The squad leads are not the interviewer, but the hiring manager will test how you would work beside them | Propose seam principles rather than pretending to know the seam; reciprocity framing |
| G. Values/Behavioral | Scenario probes on unpopular truths and customer-first choices | Low, 2 questions. No published values were read and no values-style round is detected, so these use persona stems | Selection scaffolds with the honest branch; no invented stories |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"` | The underwriter named this objection, so it gets the deepest rehearsal. Open by agreeing, not defending: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the bridge at its scope: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Name the limit before they do: that is integration delivery, adjacent to this job and not this job. Then a ramp plan, said as a plan: the first things you would learn are how roadmap decisions are split with the squad leads and how adoption is measured today. Hold through two follow-ups by returning to what you did and what you would learn; on the second push, concede specifically that roadmap ownership is the part you would be learning. Do not call the work effectively product management, and do not say what it proves; let them draw that | F1 and F6 are where this objection presses hardest, so it will arrive in some form; JD because it scores R1, and Skeptic because it goes at the gap |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas` acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)"; `prohibited_claims: "Having owned a product roadmap"` | Answer with the plain acknowledgment, not a bridge: "Owning the roadmap and setting priorities across two squads is the part I'd be learning; I haven't owned a product roadmap." Then the ramp plan in your own words: learn how decisions are made today with each squad lead, learn the adoption baseline, sit in on partner discovery. The underwriter looked for a bridge here and found none, so do not reach for one live | F6 is the one acknowledge_gap area; this is the stem interviewers use to find it |
| A3 | "Tell me about a time you shipped an API or platform product." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold: pick an instance where something you worked on reached partners or clients as a product or platform capability; it needs what it was, your named part, and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", at that scope, or how you would handle it | F2 is a must-have with no verified shipping evidence, so this is where the probe lands; JD because it scores R2 |
| A4 | "What has your exposure to agile delivery looked like, if any?" | JD | [grounded] | Clarify strategy, so it is question-shaped. Answer slot: the JD says "Agile delivery experience", so this is the probe. If you have worked that way, say how, in your own words; if you have not, say so plainly, and add what you would want to confirm: how the two squads define and run their delivery. Nothing about your past goes in beyond that | F5 is a discovery gap the underwriter marked clarify; the "if any" keeps the question honest |
| A5 | "Why product management, and why now?" | EXP | [generic] | Your material says nothing about your motive, so none is supplied here. Answer in your own words: specific, forward-looking, consistent with the work you did. If a clear reason has not formed, say so plainly and give what draws you to this role | The standard Skeptic motivation probe; every transfer candidate gets it, and F1 makes it likelier |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has flattened over two quarters. Walk me through your diagnosis." | CASE | [generic] | Clarify first, and the first clarification is the real one: how adoption is defined and measured today and what the baseline is. Then objective, segmentation of partners, hypotheses, the data you would pull, risks. Think aloud and say the framework before using it. The question needs no claim about your past, so the guidance makes none | The JD makes adoption metrics a responsibility and the dossier lists the baseline as unknown; `[generic]` because the scenario is a pattern, not a Quartzline fact |
| B2 | "Two partners ask for conflicting changes, and both squads are at capacity. How do you decide what goes on the roadmap?" | CASE | [generic] | Speak in "I would", never "I have". Ask who decides first (which is the decision-rights question for the reverse bank), then criteria, the evidence you would gather from each partner, how you would involve the squad leads, and how you would communicate the trade-off. Make no claim about having prioritized for a squad | F6 is the capability gap; a hypothetical lets you show reasoning without claiming authority |
| B3 | "Sketch the discovery plan for a new endpoint partners are asking for. What do you need to know first?" | CASE | [generic] | Persona-stem case. Clarify the partner problem before the endpoint, then who to interview, what evidence would change the plan, and how the answer reaches the squads as a spec. No claim about your past | The JD lists partner discovery as a responsibility; F4's client side is where your real material is closest, but this case asks about no past |
| B4 | "A partner's go-live is slipping because the schema documentation is ambiguous. What do you do this week?" | CASE | [generic] | Triage first: what is blocked and for whom, then who owns the doc, a stopgap for the partner, the fix with the squad, and how you would stop the next one. Think aloud; no claim about your past | R3 names API docs and schemas; F3 is unresolved, so a live problem tests fluency without needing a story |
| B5 | "Which three adoption metrics would you put in front of the squads in your first month, and why those?" | CASE | [generic] | Clarify what is tracked today before proposing; then a small set, what decision each would change, and what you would not measure yet. Name your weakest assumption in the set | The JD's adoption-metrics line, with the baseline unknown |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You mention 30+ client integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the figure counts in the quote's own terms. Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Name no counting method or definition that is not yours | F1 and F2 both lean on this figure, and a headline figure is where probers go first |
| C2 | "Pick one of those integrations and take me through it end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Choose one you can tell fully. The quote states these beats: scoping, requirements, architecture, UAT, go-live; tell the one you chose through them. Answer slot: the quote says you led them; if a decision, problem or change on that integration was yours, say what it was and what you did; if there was none, or it was not yours, say so plainly and tell it through the stages. "We" for context, "I" for your contribution | F2 and F3 need a concrete case to stand on, and an end-to-end walk-through is the Prober's check on F1's quote |
| C3 | "You wrote the integration playbook your team uses. What does it cover, and how do you know it gets used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The underwriter inspected the playbook, so this is your strongest evidence; say it at that scope in your own words. Answer slots: what it covers, in your own words; if you know how it gets used, say how; if you do not, say so plainly. Offer to walk through it, after checking it is shareable | F3 and the fluency probe; the playbook is the most inspectable thing you carry |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each only what its sentence says: the integrations you led; the playbook you wrote; the roadmap-input sessions you ran. The third is confirmed with limited inspectable proof, so volunteer that limit and say plainly what you know of what happened to the input. Close with why this role, in your own words (see A5). No beat adds an outcome or a title | F1, F2 and F4 together are your whole verified story; the opener is where the interviewer first hears it |
| D2 | "Where do API docs and schemas show up in your work these days, if they do?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Casual register, still scored. Name something you actually use. If nothing comes to mind, say so plainly, then give the nearest thing your material carries: the REST API integrations you led, at that scope | F3 asks about docs and schemas; asked casually, it is the same probe |
| D3 | "How do you work with engineering, sales and customers when they want different things?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on the quote: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the limit: confirmed, limited inspectable proof. Answer slot: the JD names engineering and sales; if you worked with either, say how and what you did; if you did not, say so plainly and stay with clients and product | F4 is the R4 row; the question names all three groups, and your quotes reach two of them at most |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims: "Having held a product manager title or role"` | The time-boxed A1. Pause, restate, answer in order: concede first ("I haven't held a product manager title or role"), then the quote at its scope, then the ramp. Hold the quoted claim through two follow-ups; concede the roadmap point specifically if pushed. Do not argue that you are equivalent | F1 again, under time pressure; the pressure version is where candidates start defending |
| E2 | "Those 30+ integrations: how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Anchor in the quoted verbs: you led them; you wrote the playbook. Hold that through two follow-ups. Answer slot: which parts others did, and which parts were yours, in your own words; if you do not know a share, say so plainly rather than estimating | Attribution probes exist to catch inflation; F1 and F3 are the rows it tests |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our two squads sit side by side with you in the middle. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam, and ask who decides what, which is the dossier's open question. Reciprocity: what you would bring each squad lead, not only what you need. Make no claim about having set a squad's priorities | The dossier lists decision authority against the squad leads as unresolved; F6 is why you should ask rather than assert |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Open prompt. Pick a time you can tell with a named stake. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the playbook, at that scope, or how you would handle it. "We" for context, "I" for your contribution | Credit probes are the Peer Evaluator's standard; F3's playbook is the only team-facing artifact you carry |

### G. Values/Behavioral

No values-style round is detected and no published Quartzline values were read, so these use persona stems and no cheat sheet is built.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to a customer or a senior stakeholder." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem; R4 names stakeholders across three groups, so it is plausible even with no values round |
| G2 | "When did you put a customer ahead of an internal timeline?" | VAL | [generic] | Selection scaffold: pick a time where the trade-off was real and you can name what each side gave up. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem, and a customer-first story is the one that carries most for an API platform role; F4 is the nearest row |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, A5, E1, E2 |
| R2: Shipped API or platform products | A3, C1, C2 |
| R3: Technical fluency: API docs, schemas | B4, C3, D2 |
| R4: Stakeholder management across engineering, sales, customers | D3, F1, F2, G1 |
| R5: Agile delivery experience | A4 |
| Responsibility: own the roadmap | B2, F1 |
| Responsibility: run discovery with integration partners | B3 |
| Responsibility: write specs and drive delivery with two engineering squads | B2, F1 |
| Responsibility: define and track adoption metrics | B1, B5 |
| Company and strategy (CO) | none, because no research ran, so a Quartzline-specific CO question would be invented; see the upgrade menu |

## Reverse questions

At least five, none tied to an interviewer's path because no profile exists.

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts ownership but the dossier has no evidence of the real split; it reads as diligence and tells you what owning the roadmap means in practice | [grounded] dossier `opportunity_risks_to_validate`, `questions_for_employer` |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption metrics as a responsibility with no baseline; it shows you think in outcomes and tells you what you would be held to | [grounded] dossier `opportunity_risks_to_validate`, `questions_for_employer` |
| R-3 | "How do the two squads plan and run delivery today?" | F5 is a clarify area; the answer tells you whether "Agile delivery experience" means anything specific here | [grounded] dossier `uncertain_or_weak_areas` clarify area |
| R-4 | "Where does partner feedback come from today, and how does it reach the roadmap?" | It tests whether the input channel your verified experience resembles exists here | [inferred] from the role's discovery responsibility |
| R-5 | "What would a strong first 90 days look like for this seat?" | A concrete answer tells you the success measure, and it invites them to describe the ramp you would be on | [generic] |
| R-6 | "For someone joining from outside a product background, what would close the gap in your eyes?" | It turns A1 from an objection into a shared plan, and the answer tells you whether the bridge is credible here | [generic] |

## Prohibited claims

Built before the banks. The first three come from the dossier's `prohibited_claims`; the rest are inflated forms of your verified sentences.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims` | The plain acknowledgment: "I haven't held a product manager title or role." Then F1's quote at its scope |
| Having owned a product roadmap | `prohibited_claims` and the `acknowledge_gap` area | The plain acknowledgment: "I haven't owned a product roadmap." No slot, no bridge |
| Having set prioritization for an engineering squad | `prohibited_claims` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." B2 stays hypothetical |
| Shipped an API or platform product | Inflated form of F2 | F2's quote at its scope. The limit is the pack's observation: the material shows integrations of the vendor's REST APIs, not a shipped product. A3's slot stays inside the integrations |
| Shaped or influenced the product roadmap | Inflated form of F4 | F4's quote at its scope: the sessions fed client evidence to product. The material does not show what product did with it |
| Effectively a product manager, or PM-equivalent experience | Inflated form of F1 | F1's quote at its scope, with the limit that it is adjacent to the job |

## Sources

- **Provided:** your note on the round, and `tuesday-dossier.md` (dossier_version 1.1, generated by job-underwriter). The pack consumed `role_profile` (requirements and responsibilities), `handoff_to_mock_interview` (verified evidence, weak areas with strategies, objection, risks, employer questions, prohibited claims) and `decision` (context only). The dossier carried no `evidence_map`, `risk_register` or `evidence_state`, so F2 to F4 are graded by this pack, not the underwriter.
- **Searches sent:** `Quartzline company values` — refused. `Quartzline interview process product manager` — refused. `Quartzline strategy news partner API platform` — refused. No fetches.
- **Loop:** no loop source establishes Quartzline's loop, so the persona weights rest on the hiring-manager prior and the Generic archetype, and no values-style round is detected.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet and VAL questions; none built |
| 2. `Quartzline interview process product manager` | unavailable | Would have set the loop and persona weights from documented rounds; the Generic archetype stands in |
| 3. `Quartzline strategy` / recent news | unavailable | Would have made a CO question possible; none written |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` requirement lines fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Allow web search: Quartzline's values page, loop structure and current strategy → a CO question, a values bank and persona weights from documented rounds; three `unavailable` rows become `yes`. A deeper research pass is also available once: up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and the competitive set. It is offered once and runs only if you say yes
- The interviewer's name and role → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their path
- The recruiter's note on format and focus areas → coverage of any announced exercise and a reweighted bank
- Your answers to the slots on F2, F3, F4 and F5, stated here in chat → those rows move from slot to quoted evidence, and A3, A4, C2 and D3 get story maps
- The `evidence_map` section of the dossier, if you have it → underwriter grades for F2 to F4 in place of this pack's
- An agenda or output summary from one of the quarterly roadmap-input sessions → could lift the F4 sessions from medium to high confidence and thin out the probe D3 expects
- The raw CV behind the confirmed claims → the evidence column quotes your CV directly, and any further line may carry a story
- Hours available before Thursday → a prioritised schedule sized to it
