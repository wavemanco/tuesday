I'm finishing the interview prep pack. It's saved, and I'm fixing two small cells before I hand it over.
Dara, your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-8-canned-1ce24de0/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round pack, because the recruiter's email names every session. It has one shared fit snapshot, and each round has its own question bank and reverse questions. The values cheat sheet sits in round 3, since that panel scores the four values. I sent no web searches, because your pasted values, the recruiter's email and your four brief points covered everything.

Your biggest exposure is "Never worked in a contact centre". It sits against the JD's headline line, so expect it in all three rounds. D1 is the full rehearsal, with three follow-up levels.

None of your lines yet carries a story for any of the four values, so those rows are scaffolds. A real moment from you for even one value would turn that row into a mapped story.

Say the word and I'll play the Skeptic on D1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter say whether the 20-minute escalation case comes in advance or cold on the day? The answer decides whether round 3 gets a build section or stays a practice pattern.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

Prepared for Dara, 25 November 2026. Interview day: 4 December 2026. Interviewer names are not assigned yet, so rounds are described by role only.

| Round | Who | Length | Shape, per the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Conversation |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute complaint-escalation case; also the values round, scored against the four values |

Mode: loop. The recruiter's email names every session, so each round gets its own persona weights, bank and reverse questions, on one shared fit snapshot. Assumption this pack is built on: the format of the round 3 case is not known, so G1 is a practice pattern, not the real case.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script. Every line of wording here is proposed, pending your approval: nothing in it is yours until you can say it in your own words, about what you actually did.

Highest-ROI prep: D1, the contact-centre question. It comes in some form in all three rounds (B1, D1, I1), so rehearse one answer until it is boring.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the published values, not generic virtue |
| EXP | Whether the claims about your background survive scrutiny |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Knowledge of Ashgrove's strategy and competition |
| CASE | A live problem from the role, scored on structure |

Each question carries one type in its cell; the rationale says where a second type applies.

## Fit snapshot

Your evidence is quoted only from your message. Nothing was inspected behind any of it, so no row is above medium.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end across branches; that limit is the pack's observation, not words for you. The words stay at the quote: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what came before and after the log likely. If any stage beyond the log was yours, say which, in your own words; if there was no such stage, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (contact-centre half) — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet; it does not show what the spreadsheet counted. Words stay at the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's monthly-reporting line makes a probe on what it counted likely. If it counted anything, say what and how, in your own words; if it counted nothing the JD names, or you cannot say how, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says a spreadsheet, not which tool. Answer slot: the JD's Excel line makes a probe on the tool likely. Name the tool it was built in, in your own words; if it was Excel, say what you did in it; if it was another tool, or you cannot say, say so plainly and stay with the spreadsheet you built |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors and coaching, and the words stay there: "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who you have guided likely. If your training reached beyond new tellers, say who and how, in your own words; if it did not, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD's digital-teams line makes a probe likely. If you have worked with a digital team on anything members use, say what and which part was yours, in your own words; if you have not, say so plainly, then say how you would start, as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but one line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms and let the interviewer draw the inference: "6 years in retail banking, the last 3 as a branch supervisor." |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says formal; the JD says regulated; the material does not show whether the two meet. Words stay at "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on how the log was governed likely. If any rules from outside the branch applied to it, say which and what they meant for how you handled it, in your own words; if you do not know, or there were none, say so plainly and stay with the log you handled |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated gap. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first senior presentation, said as a plan and never as a past. Any confidence you state is yours to claim; the pack does not script it |

None of the nine rows is a gate in the sense of a term you either meet or do not (a licence, a right to work, a location or pay constraint), so no row is `hard_gate`, and the JD states no such term.

## Requirement coverage

| JD requirement | Rows | Questions |
|---|---|---|
| Own the complaints process end to end across branches | F1 | A1, C4, G1 |
| ...and the contact centre | F2 | B1, D1, I1 |
| Report monthly on complaint volumes and resolution times | F3 | C5, E2 |
| Coach branch supervisors on escalations | F5 | C3, G2, H1 |
| Work with digital teams on self-service journeys | F6 | E1 |
| 4+ years in financial-services customer operations | F7 | A1 |
| Experience handling regulated complaints | F8 | D3 |
| Confident presenting to senior leaders | F9 | B3, D2 |
| Comfortable with Excel reporting | F4 | B2, C5 |

## Grounding brief: Ashgrove's July 2026 strategy

Built from the four points you listed from the brief the recruiter sent; the full brief was not pasted.

| Point | Where it can surface | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | E1, reverse questions in round 2 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | G3, F3, reverse questions in round 3 | [grounded] |
| Launch a small-business lending product in Q1 2027 | A reverse question in round 2 | [grounded] |
| Main competitive pressure is app-only banks | E1 follow-ups | [grounded] |

Use the brief's own words, and do not correct it. The brief's hub plan sits beside the value "Neighbours, Not Numbers — every branch is part of its town"; the panel is branch managers, so expect that pairing to be on their minds (reading of the two documents, not a claim about any individual).

---

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, logistics, motivation | Highest. The recruiter-screen prior is Conversational plus a light Skeptic; the email gives this round no stated focus. Depth 5 | A 90-second arc built only from your quoted lines; treat casual questions as scored |
| Skeptic (light) | Knockout checks on the JD's contact-centre and senior-presenting lines | Mid. F2 and F9 are gaps you have stated, so they surface even in a friendly register. Depth 3 | Say the plain acknowledgment once, then the plan, and stop |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | A 90-second arc whose facts are these two lines: "6 years in retail banking, the last 3 as a branch supervisor", and "I handled the branch's formal complaints log". Add why this role, in your own words; the pack supplies no reason. Stop at 90 seconds | The persona stem for a rapport opener; F7 and F1 hold the facts. EXP because it checks the background story against what the CV-style lines say |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask what band the role carries first; either is yours to choose. If asked what you earn now: "I'd rather focus on the range for this role" | A recruiter screen always covers pay; the only safe answer is your own |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Same: a logistics question with a one-line answer that must be true |
| A4 | "Where would you want to be based, and does a role that spans branches and the contact centre work for you?" | JD | [generic] | Logistics slot: state your own constraints on where and when you can work; if you have none, say so | The JD's responsibilities span branches and the contact centre, so the pattern of the role is a fair screen question |
| A5 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your own reason, in your own words. The pack supplies none | The reason for leaving is scored for consistency with the rest of what you say, so it must be yours |
| B1 | "The role covers branches and the contact centre. Where does your background sit against that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Say "I haven't worked in a contact centre." Then the log, at its own scope: "I handled the branch's formal complaints log." Then a plan, in your own words, for how you would learn how complaints reach and leave a contact centre. Keep the plan a plan | F2 is the gap row, and the JD's headline line makes it a likely knockout check; JD because it scores a stated responsibility. The full rehearsal is D1 |
| B2 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say it in the quote's terms: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: name the tool it was built in; if it was Excel, say what you did in it; if it was another tool, or you cannot say, say so plainly and stay with the spreadsheet you built | F4 is a stated requirement and a likely quick check; the tool is the open point |
| B3 | "This role presents to senior leaders. How do you feel about that?" | JD | [grounded] "I've never presented to anyone above regional level" | Say "I've never presented to anyone above regional level." Then how you would prepare for a first senior presentation, as a plan. Do not state a confidence you cannot back; if you are nervous, you may say so plainly | F9 is a stated gap against a stated requirement; the recruiter will want it surfaced early. Full hold-then-concede is D2 |

Wording above is proposed, pending your approval.

## Reverse questions for the recruiter

| Question | Why it lands |
|---|---|
| "Is the 20-minute case in the panel round given in advance, or on the day?" | Shows you are preparing for a graded exercise; the answer changes how you prepare |
| "Once the two branch managers are assigned, could you tell me who they are?" | Lets you read their public professional background before the 4th |
| "Is the pay band for the role fixed, and where does it sit?" | A direct, normal question that keeps pay on the role's terms |
| "How does the Head of Member Services describe what success looks like in the first six months?" | Surfaces the manager's priorities before the behavioural round |
| "The brief mentions eight branches becoming five hubs over 2027. How does that shape the role's first year?" | Shows you read the brief and ties the role to Ashgrove's actual plan |

---

# Round 2: the Head of Member Services (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" probes | Highest. The hiring-manager prior is Case/Strategist plus Skeptic, but the recruiter calls this round mostly behavioural, so Values/Behavioral moves to the top. Depth 5 | Where one of your sentences carries a story, map it; otherwise pick a real time using the scaffold, ending honestly if none comes |
| Skeptic | Quiet probing of F2, F9, F8 | Mid. This is the person who would manage you, so they are pricing the gaps. Depth 3 | Rehearse the single most predictable objection until it is boring: D1 |
| Case / Strategist | One live problem tied to the brief | Low. The prior would put it higher; the recruiter's "mostly behavioural" lowers it. Depth 2 | Clarify, then structure, then answer; think aloud |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you actually said, and what happened next; use "we" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem; the manager is buying someone who will report complaint figures upward (F3, F9). No quoted line carries a story for it, so the pick is yours |
| C2 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | Selection scaffold: pick a time a member's interest and an internal target pulled apart, with what you chose and what it cost. Connect it to "Members First, Always" only if the story genuinely fits. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Maps to the first published value and is a standard stem; the manager's round may preview the panel's scoring |
| C3 | "You trained new tellers on your escalation script. How did you teach it?" | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5: the beats are the quote's own — new tellers, an escalation script — told in your own words. Answer slot: expect a probe on how you taught it. Say how, in your own words; if there was no set method, or it was not yours to design, say so plainly and stay with the script you trained them on | The JD's coaching line makes this likely; F5 is the evidence and the limit (tellers, not supervisors) stays in your answer |
| C4 | "Tell me about a time a complaint had to be escalated, and what you did." | JD | [generic] | Selection scaffold: pick a complaint that moved up, with the stake, what moved it, what you personally did and what happened for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD scopes the role around escalation; F1 and F5 are adjacent evidence, so the story must be picked, not assumed |
| C5 | "Walk me through the monthly complaints spreadsheet you built, the one your regional manager uses." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: the beats are the quote's — you built it, it is monthly, your regional manager uses it. Answer slot: the JD's reporting line makes a probe on what it counted likely. If it counted anything, say what and how, in your own words, and name the assumption you would defend least; if it counted nothing the JD names, or you cannot say how, say so plainly and stay with the spreadsheet you built | F3 and F4 hold your only reporting evidence; EXP because a prober will test what was counted and what was yours |
| D1 | "You've not worked in a contact centre. How would you own complaints across one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **Highest-ROI rehearsal.** Opening: "I haven't worked in a contact centre. I handled the branch's formal complaints log." Then your own plan for learning it. Follow-up 1, "what do you know about contact-centre complaints?": say only what you know first-hand; if nothing, say so plainly and say how you would find out. Follow-up 2, "why should we trust you with it?": hold on the quote; concede the gap in the same words; do not widen the log into the process. Follow-up 3, "what would you do first?": a plan, yours to choose. The limit, named before it is asked: your material shows the branch's log and nothing on contact-centre work, so the hold stays on the log and the plan stays a plan | F2 is the stated gap against the JD's headline line, so this is the most predictable objection, in some form, in every round. JD because it scores the stated responsibility; Skeptic delivery |
| D2 | "You've said you've never presented above regional level. This role presents to senior leaders. How would you approach it?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold, then concede: pause and restate the question; say "I've never presented to anyone above regional level." Hold through two follow-ups by returning to a plan you can stand behind; concede what you do not know in specific terms. Do not claim a presenting style you have not used | F9 is the stated gap against a stated requirement; hold-then-concede keeps you steady if the follow-ups press |
| D3 | "You handled the branch's formal complaints log. What rules did it work to?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if any rules from outside the branch applied to the log, say which and what they meant for how you handled it, in your own words; if you do not know, or there were none, say so plainly and return to the log you handled | The JD asks for regulated complaints experience; F8's quote says formal. The slot lets either truth stand |
| E1 | "We're aiming to move 40% of member service to digital channels by 2028. How would you want complaints to work in a self-service journey?" | CASE | [grounded] | Clarify first (which complaints, which members, what a member sees today); then objective, then approach, then metrics, then risks; use the test in "Plain Words": if a member needs it explained twice, the journey is wrong. Challenge one premise politely. Expect a follow-up on app-only banks. Answer slot for F6: the JD's digital-teams line makes a probe likely; if you have worked with a digital team on anything members use, say what and your part; if not, say so plainly and say how you would start | The brief's digital shift is the clearest strategy hook; CO and CASE both apply, and F6 has no evidence, so the slot is where it is covered |
| E2 | "Complaint volumes rose 20% in a month. How do you work out why?" | CASE | [generic] | Clarify (definition of a complaint, channels, any change in the period), segment (branch, contact centre, topic, product), form a hypothesis, say what you would check first, and what you would tell leadership before you know. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's reporting line (F3); it tests structure, not answers |

Wording above is proposed, pending your approval.

## Reverse questions for the Head of Member Services

| Question | Why it lands |
|---|---|
| "When a complaint passes between a branch and the contact centre, where does the hand-off hurt most today?" | Turns the contact-centre gap into a conversation about the problem you would own |
| "Which complaint measures does leadership look at each month, and what do they do with them?" | Shows the reporting line (F3) is something you want to be useful |
| "The brief moves 40% of service to digital by 2028. What does that mean for the complaints I would own?" | Shows the brief is read; a CO question reversed |
| "What would I need to have learned about the contact centre by month three for you to say the hire was working?" | Names the gap and turns it into a plan; very hard to score badly |
| "When the small-business lending product launches in Q1 2027, who will own its complaints?" | Shows you read the strategy brief's third point and think a launch ahead |

---

# Round 3: the panel of two branch managers (60 minutes, including a 20-minute case)

## Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four published values | Highest. The recruiter says this is the values round and the panel scores against the four values. Depth 5 | One real story per value, or a stated "nearest thing" where none comes |
| Case / Strategist | The 20-minute complaint-escalation case | Mid. Named by the recruiter; format unknown. Depth 3 | Clarify, structure, answer; think aloud; use the values' own words |
| Peer Evaluator | Where a Member Experience Lead meets a branch manager; whose supervisors, whose call | Low. You would coach their supervisors on escalations, so the seam matters to them. Depth 2 | Reciprocity: what you bring their branch; propose seam principles, not a seam you cannot know |
| Pressure | Short, time-boxed challenges | Low. No source says this panel presses; two items are included because the stems are standard and the gaps are stated. Depth 2 | Pause, restate, hold on what you said, concede only what is true |

Rapport at the start of the hour is covered by the A1 arc; it has no separate bank.

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a time a member's side and the branch's or the process's side differed, what you decided, and what happened. Map it to "Members First, Always" only where it truly fits. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Straight from the published value; the panel scores against it. No story is mapped yet, so the pick is yours |
| F2 | "Tell me about a time something you explained to a member needed explaining twice." | VAL | [grounded] | Selection scaffold: pick a real instance, say what you had said, why it needed repeating, and what you did differently the second time. "Plain Words": if a member needs it explained twice, the writing was wrong, so own the part that was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Straight from the value; own the failure rather than blaming the member |
| F3 | "Tell me about a time you treated your branch as part of its town." | VAL | [grounded] | Selection scaffold: pick a time you acted for the town or its members beyond what the process asked, with what you did and what it meant. "Neighbours, Not Numbers." If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value that sits beside the hub plan, so a branch-manager panel may press on it |
| F4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold: pick a problem you found, the point at which passing it on was possible, what you did, and the end state. "Own the Fix": whoever finds the problem keeps hold of it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value closest to the role's title, escalations and ownership |
| F5 | "Which of our four values is hardest to live by in a complaints role, and why?" | VAL | [grounded] | Pick one and give your honest view in your own words. Hold the position through two follow-ups; concede a limit specifically. The eight-to-five hub plan sits beside "Neighbours, Not Numbers"; if you name that tension, say it as a question you would want answered, not as a criticism | A reasoning question with no claim about your past; it tests whether you can speak about values without slogans |
| G1 | "A member's complaint has moved between a branch and the contact centre, and they have now come back a third time. Walk us through what you would do." | CASE | [generic] | A practice pattern for the real case, whose format is not yet known. Clarify first (what the complaint is, who holds it now, what the member has been told, whether it is a formal complaint and what the log shows); objective in the member's terms; what must happen today and what later; a single owner who keeps hold of it; plain words for the next contact; what you would measure; risks. Use the panel's own values as your vocabulary. The question needs no claim about your past, so the guidance makes none | The recruiter named this case; F1 and F2 are the evidence limits, so the answer stands on structure |
| G2 | "A branch supervisor escalates a complaint, and the member is still unhappy afterwards. How do you coach the supervisor?" | CASE | [generic] | What you would ask first; what you would say in plain words; how the supervisor keeps hold of the complaint. No claim about your past | The JD's coaching line (F5), asked as a decision by people who manage the supervisors |
| G3 | "Eight branches become five hubs over 2027. How should the complaints process work for members whose branch is now served from a hub?" | CO | [grounded] | Clarify first (which members, which channels, where complaints are lodged today); objective: no member loses a route to complain; approach, with plain words and a digital option; risks. Name the tension with "Neighbours, Not Numbers" as an open point to work through, without presuming any branch outcome. Challenge one premise politely | The one question tied to the brief's hub plan; branch managers have the most at stake in it |
| H1 | "Our teams sit side by side. Where is the seam between you and a branch manager, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Reciprocity first: what you bring a branch. Propose seam principles, not a seam you cannot know. You can speak from the supervisor's side of a branch in the quote's own words: "6 years in retail banking, the last 3 as a branch supervisor". Do not claim a past disagreement or a relationship the quote does not carry | The stem for a peer round; F5's coaching line puts the seam in the panel's hands |
| H2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work crossed teams, how credit was shared, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe; the answer must be a real instance or an honest "how I would" |
| I1 | "Sixty seconds: why you over a candidate who has worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "6 years in retail banking, the last 3 as a branch supervisor" | Pause; restate. Hold only on the quotes: "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log". Concede the gap in its own words: "I haven't worked in a contact centre." Do not compare yourself with another candidate, and do not widen the log into the process | The same gap as D1, in a time-boxed delivery; F2 is the limit |
| I2 | "That spreadsheet your regional manager uses: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold on the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if any part of it was someone else's, say which; if none was, say so plainly and stay with "I built". The weakest assumption behind it is yours to name, or say plainly you do not know how it was counted | An attribution probe on F3, F4's only evidence; pressure delivery, EXP content |

Wording above is proposed, pending your approval.

## Values and principles cheat sheet

Ashgrove's four published values, named as on ashgrovecu.org/about/values (your paste of 25 November 2026). None of your quoted lines yet carries a story for any of them, so every row is a selection scaffold. A real story for any value changes that row.

| Value | Working meaning, paraphrased | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, used by F1 and C2: a time a member's side and a process or metric differed, what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member had to hear it twice, the writing was wrong | Scaffold, used by F2: a real instance that needed repeating and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch belongs to its town | Scaffold, used by F3: a time you acted for the town beyond the process. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Scaffold, used by F4: a problem you found, the moment you could have passed it on, and the end state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Reverse questions for the panel

| Question | Why it lands |
|---|---|
| "What could a new Member Experience Lead do in their first month that would genuinely help a branch like yours?" | Reciprocity with branch managers; shows you think about what you bring them |
| "How do your supervisors experience escalations today, and where do they feel stuck?" | Puts the coaching line in their terms and shows you ask before you advise |
| "When a complaint leaves your branch, what do you want to hear back, and how soon?" | A practical question from the branch's side of the process |
| "How do you expect the move to hubs to change what your members expect from complaints handling?" | A CO question that reads as diligence |
| "Which of the four values is hardest to hold on a busy day in a branch?" | Invites an honest answer and shows you take the values seriously |

---

# Prohibited claims

What this pack will not coach, and the honest form of each. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one branch's log, not the process. C4's and G1's slots stay inside the log |
| Has worked in a contact centre, or knows how its complaints work first-hand | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Produced management reporting on complaint performance | Inflated form of F3 | F3's quote at its own scope: the material says a spreadsheet your regional manager uses, not what it counted or whom it reached |
| Advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: the material says a spreadsheet, not which tool or what features |
| Coached branch supervisors | Inflated form of F5 | F5's quote at its own scope: tellers and a script |
| Handled complaints under a regulator's rules | Inflated form of F8 | F8's quote at its own scope: a formal complaints log. D3's slot stays inside the log |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot |

# Sources

Provided documents: the JD you pasted; Ashgrove's four values, copied by you on 25 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; your summary of four points from the 2026 strategy brief Ashgrove published in July 2026; your background as written in your message. No dossier was present, so no section is drawn from one. No searches or fetches were sent, and nothing from model memory is used for Ashgrove's values, loop or strategy.

Loop: the recruiter's email establishes all three sessions and who runs each. It also says the panel is the values round, so a values-style round is detected and the values cheat sheet sits with round 3.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Your pasted values page is in hand and fixes the values cheat sheet and F1 to F4 |
| 2. Ashgrove interview process, member-services role family | skipped | The recruiter's email fixes the three sessions, who runs each and that the panel scores the values, which settles persona weights and the values-round call |
| 3. Ashgrove strategy and recent news | skipped | The four points you gave from a July 2026 brief fix the grounding brief, E1 and G3; only those four points are in hand |
| 4. Interviewer name and Ashgrove | n/a | No interviewer is named yet, so no query can be formed; there is no interviewer read |
| 5. Representative member experience lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

# Upgrade menu

- Whether the round 3 case is given in advance, with any materials → G1 becomes a build section for the real case instead of a practice pattern
- Hours you have before 4 December → a prep triage in priority order
- Your CV → F1 to F9 evidence cells quoted from your CV as well as your message, and any CV line that reaches F5, F6 or F8 more directly
- A sentence or two, in your own words, on a real moment for any of the four values → the matching cheat-sheet row becomes a mapped story, and C1, C2 and F1 to F4 become story-mapped instead of scaffolds
- What the monthly complaints spreadsheet counted and which tool it was built in, or an anonymised copy of it → F3 and F4 move from discovery toward a stronger band, and C5 and I2 sharpen
- Whether the formal complaints log worked to any outside rules → F8 and D3
- Interviewer names, once assigned → an interviewer read, persona weights tuned to their public professional backgrounds, and a reverse question tied to their own paths
- The full strategy brief text → a fuller grounding brief and CO questions tied to its own numbers
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) on recent Ashgrove news and organisation context → a stronger grounding brief; offered once
- A `tuesday-dossier.md` from an earlier assessment of this role would add confirmed evidence, graded gaps and a named top objection; it is not needed for this pack
