Web search was refused, so I'm building the loop pack from your role description and your four statements. Everything about Larkfield beyond your words stays unresearched and labeled `[generic]`.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-6-denied-d7102fbc/larkfield-systems_engineering-manager_interview_pack.md`.

It's a loop pack: one shared fit snapshot, then a bank for each round (12 questions Tuesday, 12 Thursday, 8 Monday). Each round also has its own persona weights and reverse questions. I built it from your role description and four statements. I had no full posting, no CV, no interviewer names and no company research. The web searches were refused, so anything about Larkfield beyond your words is labeled `[generic]`. I also dropped the values cheat sheet for Monday, because the company's published values aren't in hand.

- **Your most likely objection:** you've never owned a hardware-adjacent roadmap, and the role asks you to partner with hardware on it. Question 1A2 is the highest-ROI rehearsal, and the same objection returns in 2D2, 3B2 and 3C2.
- **Second most likely:** you've never managed managers. That depends on whether any of the 11 engineers sit under leads. The role description doesn't say, so it's a first reverse question for the Director (1R1).
- **Your two numbers:** the 60% on-call drop and the ~40 interviews each have probe questions (1D1, 1D2, 2A1–2A3). I kept your wording at its own scope. Your sentence says the drop came "after" you pushed the quarter through, so the pack never says you caused it.

If you'd like a live rehearsal, I can play the Skeptic on 1A2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two questions that would change the pack:
1. Can you paste the full posting and your CV, or say skip and I'll go on as is? Either would turn the thin rows into quoted evidence.
2. Did the recruiter give focus areas or ask for any deliverable, such as a presentation, for any of the three rounds?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role: lead two squads building device-management services at an industrial IoT company of about 600 people.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min | Hiring manager |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min | Panel, technical peers plus a cross-functional partner |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level, executive |

Built from your role description (not a full posting) and four statements of yours; no CV, no interviewer names, no company research (web search was refused). Where the pack knows nothing about Larkfield it says so or labels the row `[generic]`.

## How to use this pack

Personas describe how a question is asked. Types describe what is scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it tests |
|---|---|
| VAL | Whether past behavior shows values and leadership principles |
| EXP | Whether claims about your own work survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

An answer slot is an instruction for the interview, not a question for you here: it marks where an interviewer will probe and where only your own words will do. Both branches are honest answers.

## Prep triage

Sized to three rounds over about two weeks: do these in order, and treat the rest as insurance.

| When | Do | Where |
|---|---|---|
| Before Tuesday | Say the hardware-roadmap answer aloud until it is boring | 1A2, then 1A1 |
| Before Tuesday | Settle how you will talk about the 60% and the 40 interviews | 1D1, 1D2 |
| Before Thursday | Rehearse the number and attribution probes from technical peers | 2A1, 2A2, 2D1 |
| Before Monday | Hold the "never managed managers" position under pressure | 3C1, 3C2 |
| Before Monday | Prepare two or three principles in your own words, each tied to one thing you did | 3A1, 3A2 |

Everything else is insurance.

## Highest-ROI prep

The most predictable objection is the hardware-adjacent roadmap (1A2). The role description asks you to partner with hardware on the roadmap, and you said you have never owned one (F5). It will arrive in every round in some form: 1A1, 1A2, 2D2, 3B2, 3C2. The second most predictable is managing managers (1A4, 3C1), if any of the 11 sit under leads. No dossier named these; the pack inferred them from the fit snapshot below.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material says a team of six, with three of the nine years as its lead, and a stated gap in managing managers. It does not say whether the 11 engineers sit under leads, and the role description is silent on it; the Director can answer that. Words: "I've spent three years as a team lead of six." Plain acknowledgment, from your own statement: "I've never managed managers." Answer slot: the two-squads line makes a probe on scale likely. If you have led or coordinated beyond the team of six, say how, in your own words; if not, or it was not yours, say so plainly and stay with the team you led |
| F2 | "own delivery" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your words stay at their own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The sentence gives a sequence, not a cause, and says nothing about owning delivery across a roadmap. The figure raises four slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: owning delivery makes a probe on how you traded roadmap against other work likely. If you made trade-off calls on that quarter, say which and how you decided, in your own words; if the call was not yours, or there was no trade-off, say so plainly and stay with the quarter you pushed through |
| F3 | "hiring and growth for 11 engineers" — your message (hiring half) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap on the hiring half, but a line with nothing inspected behind it, so expect a probe. Lead in your own words: "I run our hiring loop for backend roles." The figure counts interviews, not candidates or hires, and raises the same four number slots. Your material says backend roles; whether the squads hire other profiles is not in it, and the Director can say |
| F4 | "hiring and growth for 11 engineers" — your message (growth half) | none given | none | [grounded] | discovery | Your material does not show whether you have developed engineers. Answer slot: growth for 11 engineers makes a probe on how you develop people likely. If you have developed engineers, say what you did and what came of it, in your own words; if you have not, or it was not your role, say so plainly and say what you would do first, as a plan and not as a past |
| F5 | "partner with hardware and product on roadmap" — your message (owning a hardware-adjacent roadmap) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The statement is about owning, not about every kind of contact with hardware teams; that is F6. Nothing is added to make the gap feel smaller |
| F6 | "partner with hardware and product on roadmap" — your message (working alongside hardware) | none given | none | [grounded] | discovery | Your material is silent on working alongside hardware teams. Answer slot: the role's partner line makes a probe on this likely. If you have worked with hardware teams in any way, say how, in your own words; if you have not, say so plainly and return to F5's acknowledgment |
| F7 | "partner with hardware and product on roadmap" — your message (product half) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The sentence touches roadmap pressure but does not say who applied it or whether product was part of it, so this is a lead and not a claim. Answer slot: if that quarter involved a conversation with product, say who said what and what you agreed, in your own words; if the pressure did not come from product, or you were not in that conversation, say so plainly and stay with the quarter |

### Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| Lead two squads building device-management services | 1A3, 1A4, 1B1, 2E1, 3C1 | F1 |
| own delivery | 1B3, 2A4, 2D1, 3A2 | F2 |
| hiring (half of hiring and growth) | 1D2, 2A3, 3A1 | F3 |
| growth (half of hiring and growth) | 1C3, 3A3 | F4 |
| partner with hardware and product on roadmap | 1A1, 1A2, 1B2, 2C1, 2D2, 3B2 | F5, F6, F7 |

## Round 1: Tuesday, Director of Engineering (45 min)

Hiring manager and your would-be boss: expect them to price your capability and derisk your gaps. Persona weights, with reasoning:

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the gaps | Highest: the hiring-manager prior is Skeptic plus Case, and you named two gaps yourself (F1, F5) | Rehearse the single most predictable objection until it is boring; acknowledge plainly, then give a plan |
| B. Case/Strategist | Live problems from the role | High: the hiring-manager prior; the role description gives the problem space | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Conversational | Friendly opener and open prompts | Medium: a 45-minute round usually starts here; casual questions are still scored | A 90-second arc built only from what you have said; treat casual questions as scored |
| D. Data-Driven Prober | Reads your claims line by line | Medium: both numbers you gave are probe targets | Know what you can and cannot say about how each number was counted; say plainly when you do not know |

### Round 1 bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap" | Pick the one that is most true and acknowledge it plainly in your own words: "I've never owned a hardware-adjacent roadmap" or "I've never managed managers." Then say how you would start, as a plan for the first weeks and not as a past. Do not offer adjacent experience beyond what you have said | F1 and F5 are your own stated gaps, and this is the Skeptic's opening stem; JD because it scores the listed job |
| 1A2 | "The role has you partnering with hardware on the roadmap, and you haven't owned a hardware-adjacent roadmap. Why should I believe you can do this?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Level one: "I've never owned a hardware-adjacent roadmap." Level two, after a follow-up: the statement is about owning. Answer slot: if you have worked alongside hardware teams in any way, say how, in your own words; if you have not, say so plainly. Level three: what you would do first, as a plan. Hold through two follow-ups by returning to the plain acknowledgment and the plan, never by adding a claim. Concede specifically what you do not yet know | F5 is the likeliest place to be probed, and the role description names the partnership; JD because it scores the stated requirement, Skeptic delivery |
| 1A3 | "You would lead two squads and 11 engineers, and you've led a team of six. What changes at that size?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say what you know from your own words: "I've spent three years as a team lead of six." Answer slot: if you have led or coordinated beyond that team, say how, in your own words; if not, say so plainly and stay with the team you led. Then what you would want to learn about the two squads first, as a plan | F1 is the scale gap; the premise is your own quote plus the JD's numbers |
| 1A4 | "If some of the 11 sit under tech leads, you'd be managing managers for the first time. How do you see that step?" | JD | [grounded] "I've never managed managers" | Acknowledge in your own statement's words: "I've never managed managers." Say you would want to know the reporting structure, then how you would approach it, as a plan. No story about managing leads exists in your material, so none is told | F1; the question is conditional because the role description does not say whether leads exist |
| 1B1 | "Imagine a firmware update to a fleet of field devices stalls partway, and a few percent stop reporting. Your squad owns the update service. What do you need to know first, and what do you do in the first hour?" | CASE | [generic] | Structure it aloud: clarify (how many devices, whether the rollout can be halted or rolled back, which cohorts, what customers can see), then the objective (stop further harm, restore reporting), then approach, metrics and risks. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem set in the role's device-management space; `[generic]` because it is a pattern, not a fact about Larkfield |
| 1B2 | "Hardware has a ship date for a new gateway and your squads' device-management work isn't ready. Product wants the date held. What do you do?" | CASE | [generic] | Clarify what is actually blocked and what the date is tied to, name the options and their costs, say who decides and how you would bring hardware and product into the same conversation. No claim about your past | JD's partner line (F5, F6, F7) as a live problem; `[generic]` |
| 1B3 | "How would you decide whether a squad's next quarter goes to reliability or to features?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure the decision first. Then, if the quarter you pushed through fits, tell it only at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: if you made the trade-off call on that quarter, say how you decided, in your own words; if it was not yours, or there was no trade-off, say so plainly and stay with the quarter | F2 supplies the one example your material carries; CASE delivery with EXP content |
| 1C1 | "So, walk me through the journey: how did you get here, and why this role now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the beats your sentence states: nine years in engineering, three as a team lead of six, currently at a payments company. Answer slot: your reason for this role is not in your material; give it in your own words, and if it is mostly that you want the step up, say that plainly | F1; the Conversational opener is scored; the reason is yours alone |
| 1C2 | "What are you actually curious about in industrial IoT?" | CO | [generic] | Say honestly what you do and do not know yet about industrial IoT. Your material states one relevant fact: "never owned a hardware-adjacent roadmap." Curiosity stated truthfully beats borrowed expertise; if you have not yet read Larkfield's own materials, say that and say what you would want to learn | The company's strategy is not researched (search refused), so this stays `[generic]`; F5 is the limit on any claim here |
| 1C3 | "Tell me about an engineer you helped grow." | VAL | [generic] | Selection scaffold: pick someone whose development you actually influenced; it needs a named starting point, what you did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | The role description's "growth" raises the theme (F4); nothing you have said carries a story, so no story is mapped |
| 1D1 | "That 60% drop in on-call burden: walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The sentence says "after", not "because"; do not say more than it does | F2's headline metric; probers go two levels deep |
| 1D2 | "You ran a hiring loop with about 40 interviews last year. What was yours to decide in it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Open with your own words: "I run our hiring loop for backend roles." The figure counts interviews: say how they were counted, what the figure is sensitive to, and which part was yours. Answer slot: if you set parts of the loop, say which and how; if not, say so plainly and describe what you ran | F3's headline figure, and the direct bridge to the role's hiring half |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1R1 | "How are the 11 engineers split across the two squads, and do any of them lead others?" | Settles whether managing managers applies, which you need before accepting |
| 1R2 | "What does the roadmap partnership with hardware look like in a normal month, and where does it strain?" | Shows you are thinking about the seam you have not owned, and surfaces what the role really holds |
| 1R3 | "Which of delivery, hiring and growth is under the most pressure right now?" | Tells you where the first 90 days go, and signals you take all three seriously |
| 1R4 | "What would make you say, three months in, that this hire was working?" | Turns a vague role into a success definition you can check |
| 1R5 | "What is your biggest concern about bringing someone in who hasn't owned a hardware-adjacent roadmap, and what would close it?" | Converts the Skeptic's silent concern into a conversation; it is candor, rehearsed |

## Round 2: Thursday panel, two staff engineers and a product manager (60 min)

Blend the top two personas of each panel member's relationship: the staff engineers read as technical peers (Prober plus Peer, with Pressure on attribution), the product manager as cross-functional (Values/Behavioral plus Conversational). Names are not known, so the personas are not assigned per person.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Two levels of follow-up on every number | Highest: two technical peers, and both of your numbers are probe targets | Know what you can and cannot say about how each number was counted; name your weakest assumption before they do |
| B. Peer Evaluator | Seam-splitting, "what would you need from us", credit | High: staff engineers and a product manager will work beside you | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| C. Values/Behavioral | Scenario probes from the product manager | Medium: the role's product-partnership line raises the theme | Pick a story only where your own sentence carries one; otherwise use the scaffold and its honest branch |
| D. Pressure | "How much of that was actually you" | Medium: attribution is the classic panel probe | Hold the position you can back through two follow-ups; concede specifically |
| E. Case/Strategist | One live problem | Low: panels often include one | Clarify first, structure aloud |

### Round 2 bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The same four slots as 1D1, with a technical audience: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours, each in your own words. If you do not know how it was counted, say so plainly. Do not name a method you did not use | F2 again: technical peers will go deeper than the Director; EXP |
| 2A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name it before they do, in your own words. Answer slot: if there is an assumption you would defend least, say what it is; if you do not know of one, or do not know how the figure was built, say so plainly. The pack does not supply one | The weakest-assumption move converts a gotcha into credibility; F2 |
| 2A3 | "About 40 interviews last year: how were those counted, and what was your part of the loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Your own words first: "I run our hiring loop for backend roles." The figure counts interviews, not hires. Four slots: how counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: if you set parts of the loop, say which; if not, say so plainly | F3; the staff engineers will have sat in loops and will probe the count |
| 2A4 | "What did that reliability quarter actually work on?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your sentence says there was a reliability quarter and that you pushed it through; it does not say what was in it. Answer slot: name the work in your own words; if you did not choose it, say who did, and stay with what you pushed through | Technical peers want the content behind the number; F2 |
| 2B1 | "Where is the seam between a manager's calls and a staff engineer's, and what happens when we disagree?" | JD | [generic] | Propose principles, not a claimed seam: who decides what, and how disagreements get raised. Selection scaffold for the story: pick a time you disagreed with a senior engineer and it needed a named stake, how you handled it, and the relationship intact after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Peer Evaluator; no quote carries a disagreement story, so none is mapped |
| 2B2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your principle in one sentence, then one example only if it is yours. Selection scaffold: pick a time work spanned teams and credit was shared; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; the role spans hardware, product and engineering |
| 2B3 | "What would you need from us in your first month?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Reciprocity framing: what you would ask for (context on what is in flight, where on-call hurts), then what you offer in return, at its own scope: "I run our hiring loop for backend roles." Do not claim more than the loop | Peer Evaluators price what the hire adds; the quote is the one concrete thing your material offers a team |
| 2C1 | "Tell me about a time you and a product partner disagreed about what a team should build next." | VAL | [inferred] derived from F7, which touches roadmap pressure without naming product: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Open prompt, scaffold with an honest branch. Answer slot: if that quarter involved a conversation with product, say who said what and what you agreed, in your own words; if the pressure did not come from product, or you were not in that conversation, say so plainly. If no such time comes to mind, say so, then give the nearest thing your material does carry, or how you would handle it | The role's product-partnership line raises the theme; F7 is only a lead |
| 2C2 | "Tell me about a time you delivered an unpopular truth to leadership or a partner team." | VAL | [generic] | Selection scaffold: it needs a named stake, the moment you did not fold, and an intact relationship after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. A hard truth that landed is the story; do not supply an ending | Persona stem; the roadmap-pressure line may be your nearest story, but its ending is yours to supply |
| 2D1 | "That result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold: "I pushed a reliability quarter through against roadmap pressure." Concede specifically what the sentence does not say: the sentence gives a sequence, not a cause. Answer slot: if you can say which parts were yours and which the team's, say so in your own words; if you cannot separate them, say so plainly. Hold through two follow-ups by returning to what you pushed through | The panel probe that exists to catch inflation; F2 |
| 2D2 | "Sixty seconds: why you rather than someone who has owned a hardware-adjacent roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "I run our hiring loop for backend roles — about 40 interviews last year" | Concede first, plainly: "I've never owned a hardware-adjacent roadmap." Then describe what you did, in your words from this pack's quotes, and let them draw the inference; do not say what it proves. Hold through two follow-ups; concede the limit when pressed, never a claim you cannot back | Pressure version of 1A2; the same objection in a time-box |
| 2E1 | "A device-management service pushes a config change overnight that leaves a subset of field devices unreachable. Walk us through the next 24 hours, including how you would work with hardware and product." | CASE | [generic] | Clarify first (scope, rollback, customer impact), then objective, approach, metrics, risks; say who you would pull in and why. Challenge one premise. No claim about your past | A live problem in the role's own space; `[generic]` |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 2R1 | "What could a new engineering manager do in their first month that would genuinely help your work?" | Reciprocity: a rapport signal for the peers, and your first-month plan gets data |
| 2R2 | "Where does on-call hurt most for the squads today?" | Connects to what you can talk about (a reliability quarter) without claiming it applies |
| 2R3 | "How do hardware roadmap changes reach the squads, and where does that handoff lose information?" | Probes the seam you have not owned; ask the product manager |
| 2R4 | "How are product asks weighed against reliability work today, and who makes the call?" | Surfaces the trade-off you described in a past quarter; also a diligence question |
| 2R5 | "What would you want a manager to stay out of?" | Signals you respect the staff engineers' ground; the answer shapes your seam principles |
| 2R6 | "What is one recent decision a new manager should understand the reasoning behind?" | Invites a story, and shows you care about context before action |

## Round 3: Monday, VP Engineering (30 min)

The recruiter's description, "values and leadership philosophy", detects a values-style round. Thirty minutes at skip-level means altitude and composure. Persona weights, with reasoning:

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values/Behavioral | Principles and stories | Highest: the recruiter's own words name the round | Pick a story only where your sentence carries one; otherwise the scaffold and its honest branch |
| B. Case/Strategist | Strategy and altitude | Medium: skip-level and executive prior | Hypothesis early, structure aloud, ask a good question back |
| C. Pressure | Time-boxed, devil's advocate | Medium: skip-level prior; your two stated gaps are natural targets | Pause, restate, hold what you can back, concede specifically |
| D. Conversational | Friendly register | Low: a 30-minute round leaves little room, but casual questions are scored | Short arcs; never leave the reverse-question slot empty |

### Round 3 bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The philosophy is yours and the pack does not write it. Give two or three principles in your own words, and tie each to one thing you did, at its own scope, only where your sentences carry one: the hiring loop, the reliability quarter. A principle with no example is stated as a belief, not a track record | The recruiter's words raise the theme; describe what you did and let the VP draw the inference |
| 3A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2 with only the beats the sentence states: a reliability quarter, roadmap pressure, pushed through, on-call burden dropped 60% after. Answer slot: if the hard truth was delivered to a person in leadership, say who and what was said, in your own words; if the pressure was impersonal or the conversation was not yours, say so plainly. Do not supply an ending the sentence does not state | A values round's classic stem; F2 is the only story your material carries |
| 3A3 | "What would you want the engineers who report to you to say about you in a year?" | VAL | [generic] | Answer in your own words: this is a statement of intent, not a record. Anchor it only where a quoted sentence carries a fact; otherwise keep it a belief and not a track record | Leadership philosophy in a different register; touches the growth half (F4) |
| 3B1 | "Where do you think device management for industrial customers is heading, and what should engineering at a company like ours prioritise?" | CO | [generic] | The pack has no research on Larkfield, so it supplies no claim about where the company is going. Give a hypothesis in your own words, say where you are speculating, and ask the VP where they would put the weight. If you have read Larkfield's own materials, say what you read | Strategy altitude; honestly degraded, since the research that would have grounded this was refused |
| 3B2 | "You'd partner with hardware and product on a roadmap you haven't owned before. How would you build your point of view in the first 60 days?" | CASE | [grounded] "never owned a hardware-adjacent roadmap" | Acknowledge plainly: "I've never owned a hardware-adjacent roadmap." Then a plan: what you would ask hardware and product for, what you would read, and what you would decide by day 60. A plan is not a past | F5 as a forward-looking question |
| 3C1 | "You've never managed managers. Why is this the right step for you, and for us?" | JD | [grounded] "I've never managed managers" | Pause and restate. Hold the acknowledgment: "I've never managed managers." Concede what you do not know about it, and say it once. Then your plan for the first 90 days, and what you would ask about the reporting structure. Hold through two follow-ups; do not claim a story about managing leads, because none exists in your material | The skip-level reads gaps directly; F1 |
| 3C2 | "Sixty seconds: what is the biggest risk in hiring you?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap" | Name the real risks plainly: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap." Then, for each, one sentence of plan. The stronger move is saying them before the VP does | The Pressure stem; F1 and F5 |
| 3D1 | "What is drawing you to this role at this point?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your reason is yours alone, and your material does not state one. Answer slot: give it in your own words, grounded in what you have said about your career: nine years, three as a team lead of six. If part of it is that you want a larger remit, say so plainly | The Conversational register at a values-style round; F1 |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 3R1 | "What does a strong engineering manager look like here after a year?" | Moves the conversation to what success looks like for the role you want |
| 3R2 | "How do you think about delivery pressure against reliability investment across the squads?" | Connects to the reliability quarter you described, in the VP's altitude |
| 3R3 | "What is a leadership principle you have had to defend, and what did it cost?" | Peer-to-peer, and signals you take principles as things that cost something |
| 3R4 | "How does the organisation develop managers who are stepping up in scope?" | Honest diligence on your own gap; the answer tells you how much support exists |
| 3R5 | "Where do hardware and software engineering disagree most, and how does leadership resolve it?" | Probes the seam in F5 and F6 at the level that sets it |
| 3R6 | "What would make you say, a year in, that this was the right hire?" | Closes on the success definition and gives you something to measure against |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or a team of 11 | Inflated form of F1 | F1's quote at its own scope; the limit is the pack's observation: your material says a team of six, not two squads |
| Managed managers | Negative the candidate stated, F1 | The plain acknowledgment F1 gives: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | "I've never owned a hardware-adjacent roadmap." No slot |
| Cut on-call burden by 60% | Inflated form of F2 | F2's quote at its own scope; the limit is the pack's observation: the sentence gives a sequence, not a cause. Slots stay inside the quarter you pushed through |
| Hired or interviewed about 40 candidates | Inflated form of F3 | F3's quote at its own scope: "about 40 interviews last year" counts interviews |

## Sources

Provided documents: your message (the role description and four statements about yourself). No full posting, no CV, no dossier, no interviewer names.

Searches sent, all refused:

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems engineering manager interview process": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet (dropped) and the VAL questions in round 3, which are now themed from the recruiter's words alone |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have added Larkfield's own loop detail; the loop here rests on your own description of the three rounds |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded 1C2 and 3B1; they stay `[generic]` |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full posting text → the fit snapshot's requirement rows move from your summary to the posting's own lines, and any must-haves on managing managers or hardware experience become visible
- Your CV → more of your own sentences to quote, which can upgrade F4, F6 and F7 and turn the scaffold questions (1C3, 2B1, 2B2, 2C2, 3A3) into story-mapped ones
- Your answers to the answer slots on F1, F2, F4, F6 and F7 → quoted evidence that upgrades those rows and the questions that draw on them
- The interviewers' names → an interviewer read, persona assignment per panel member, and a reverse question tied to each person's path
- The recruiter's prep notes for any round → coverage of stated focus areas and any announced deliverable
- Larkfield's values page and any strategy brief, pasted or via a search permission → the values cheat sheet for round 3, `[grounded]` CO questions, and the VAL stories mapped to named values
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, which would add a strategy brief and the interviewers' public footprint
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and allowed strategies per weak area, never a prerequisite
