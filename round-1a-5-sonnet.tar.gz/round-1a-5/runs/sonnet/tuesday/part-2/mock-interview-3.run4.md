Status: I've read the mock-interview playbook and its reference files. Next I'm loading search, running the default research pass on Stripe, then building the prep pack.
Searches were refused, so I'm building the pack from your message alone. Sources and the upgrade menu will say what that costs.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-3-denied-7aac07ad/stripe_product-operations-manager_interview_pack.md`. It's thinner than it should be, for two reasons:

- **Research:** All four web searches were refused. The pack has no Stripe facts: no values, interview loop or strategy. Those parts are labeled `[generic]`, and the Sources section lists each refused search.
- **Your background:** I had no job description or CV. The fit snapshot is a worksheet, and the answer guidance tells you how to build each answer from your own material. It says nothing about your past.

I built it for a final round where I don't know who you're meeting, so the persona weights are flat. It has 22 questions across seven interviewer styles, a requirement-coverage table, six reverse questions and an upgrade menu.

Say the word and I'll play the Skeptic on B1, "Which part of this job would you be weakest at on day one?" It's the pack's top rehearsal pick, chosen by default until I can see your CV.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round, and is each person your future manager, a peer, a skip-level or from another function? Did the recruiter name any focus areas or a take-home? Your answer would reweight every question bank.
2. Can you paste the job description and your CV, or say skip and I'll carry on without them? Both would turn the generic requirement rows into your own evidence.
3. Do the role's location and office-attendance terms, and your work authorization to work there, line up (row F7)? I can't tell from your message, and no answer wording can fix a mismatch.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Role: Product Operations Manager. Company: Stripe. Round: final round, structure unknown. Interviewer(s): not named. Relationship to you: not stated. This pack rests on your message alone: no job description, no CV, and no research (every search was refused). Everything below is labeled for how far it can be trusted.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding for a spoken answer, not a script: with no CV in hand, no guidance cell here says anything about your past, and each one tells you how to build the answer from your own material.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The stated job: can you do it, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

## Fit snapshot

No CV and no job description were provided, so this is the worksheet variant. Requirements are role-family patterns written as plain prose, not quotes from a posting. Every evidence cell reads `none given`. Each bridge cell says what strong evidence looks like, then gives a selection scaffold you complete from your own material.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating work across several teams toward a launch or program (role-family) | none given | none | [generic] | discovery | Strong evidence is one named launch or program, which teams were involved, and which parts were yours versus others. Selection scaffold: pick one such effort and state your role in it plainly; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Running a recurring operating process such as a planning, review or reporting cadence (role-family) | none given | none | [generic] | discovery | Strong evidence is a named process, how often it ran, who used it, and what you set up versus inherited. Selection scaffold: pick one recurring process you ran or took part in and state which it was; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using data or metrics to prioritize, diagnose or report on product work (role-family) | none given | none | [generic] | discovery | Strong evidence is a specific figure, how it was counted, and what you did with it. Selection scaffold: pick one figure you can explain end to end; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Communicating status, risks and decisions to senior stakeholders (role-family) | none given | none | [generic] | discovery | Strong evidence is a specific moment you reported a risk or a decision upward and what followed. Selection scaffold: pick one such moment and keep to what you said and did; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Turning ambiguous or conflicting inputs into a clear process or decision (role-family) | none given | none | [generic] | discovery | Strong evidence is a situation with competing inputs, how it was resolved, and your part in the resolution. Selection scaffold: pick one such situation and separate what you decided from what others decided; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Bringing customer or user feedback into product decisions (role-family) | none given | none | [generic] | discovery | Strong evidence is one instance where customer input changed a decision and you can say how. Selection scaffold: pick one such instance and state what the input was and what changed; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | The role's location, office-attendance and work-authorization terms (role-family) | none given | none | [generic] | hard_gate | Your material does not establish it. A gate is a term you meet or do not, and no wording of an answer changes that |

## Persona table

No loop source establishes Stripe's loop: the searches were refused, and you named only "final round". The weights rest on the Generic archetype and say so; they are flat apart from one tilt. If your final is several sessions, the blend below is the pack's best guess for all of them together.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems: plan this, diagnose that | Top (tied): the hiring-manager relationship prior sets Case and Skeptic highest, and a final round may include one; your relationship to the interviewers is unknown | Clarify, state the objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps and of why leave, why here, why now | Top (tied): same prior; also the persona that tests your story under cross-examination | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| C. Peer Evaluator | Seam-splitting between teams, credit-sharing | Mid: only if a peer is on your loop, which is unknown | Reciprocity framing; propose seam principles, not a pretended map of the seam |
| D. Values/Behavioral | Scenario probes on behavior | Low: no values-style round is detected, since no loop source documents one and the Generic archetype does not assume one; published values were not available | Pick a story per question from your own material, with an honest branch where none fits |
| E. Conversational | Friendly, unstructured openers; still scored | Mid: kept in the blend because the style is cheap to rehearse; nothing establishes it for this loop | Pre-script a 90-second arc; treat casual questions as scored |
| F. Pressure | Interrupts, time-boxes, tests composure | Mid: part of the hiring-manager and skip-level priors | Pause, restate, hold through two follow-ups, then concede specifically |
| G. Data-Driven Prober | Reads claims line by line, asks for denominators | Mid: kept in the blend because F3 is a requirement row, but your own figures are unknown | Know how each figure was counted; say plainly when you do not know |

## Question banks

Requirement coverage, in the pack's own rows:

| Requirement | Covered by |
|---|---|
| F1 cross-team coordination | A1, C1, C3 |
| F2 operating process | A3, G3 |
| F3 data and metrics | A2, G1, G2, G3 |
| F4 senior communication | D1, F3 |
| F5 ambiguity and conflicting inputs | A1, B4 |
| F6 customer input | D2 |
| F7 location and work authorization | none: a gate is surfaced, never rehearsed |
| Motivation and fit (not a requirement row) | A4, B2, B3, E1, E2, E3, F1, F2 |

### A. Case/Strategist (top, tied)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch involving four teams is slipping, and each team says the blocking dependency belongs to someone else. What do you want to know first, and what do you do in the first week?" | CASE | [generic] | Clarify before structuring: what the launch date is tied to, who owns each dependency on paper, what has already been tried. Then state an objective, sequence the dependencies, name who you would talk to first and why, and say what you would report upward. The question needs no claim about your past, so the guidance makes none | F1 and F5 in a live setting. CASE because it scores structure; JD secondarily because it mirrors the role family |
| A2 | "A key product metric dropped 20 percent week on week. Diagnose it." | CASE | [generic] | Ask what the metric measures and how it is counted, then check for a data or tracking change before assuming a real change. Segment by time, product, customer type and region; separate a real drop from an artifact; say what you would check first and why. State your hypotheses aloud before testing them. No claim about your past is made or needed | F3. CASE because the answer is a diagnostic structure, not a fact |
| A3 | "Sketch how you would set up a recurring cross-team product review. What do you need to know first?" | CASE | [generic] | Start with purpose: what decisions the review should enable and for whom. Then who attends, cadence, inputs and prework, how decisions and follow-ups are recorded, and how you would tell in a quarter whether it works. Name one premise of the setup you would test with the people involved before committing | F2. CASE with JD flavor: it is the process-building the role family centers on |
| A4 | "Why this company, and why product operations here?" | CO | [generic] | Research was refused, so this pack supplies no facts about Stripe. Build the answer from public material you read yourself: one thing about the company's products or direction, and one reason product operations fits you. Use only specifics you can name and stand behind. Selection scaffold: if no specific comes to mind yet, say so plainly, then give how you would find out | Motivation and company homework; CO because it tests whether you can think at the company's altitude, left generic because no research landed |

### B. Skeptic (top, tied)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | The pack's highest-ROI rehearsal, named by default because this probe fits any candidate; a CV would replace it with the objection your material actually raises. Hold-then-concede: name one real area in your own words, say what you would do in the first thirty days about it, and stay calm through two follow-ups. Selection scaffold: if no weakness comes to mind, say so plainly, then give the area of the role you have least seen done, and how you would close it. Never name a weakness you would not stand behind, and never claim none | Every F row is a candidate answer; JD because it scores the stated job, gaps included |
| B2 | "Why this role, and why now?" | EXP | [generic] | Give your actual reasons in your own words and keep them consistent with what you say in other answers. Selection scaffold: if no single reason comes to mind, say so plainly, then give the nearest reason your own situation supports | Motivation consistency is what the Skeptic scores; EXP because the answer must match your history |
| B3 | "Why are you looking to leave your current situation?" | EXP | [generic] | Give your own reason in your own words, stated once without elaboration; this pack supplies none. Do not criticize past employers. If a follow-up comes, return to your own words | Part of the standard why leave, why here, why now probe |
| B4 | "How would you explain the difference between product operations and program management, and where does your experience sit?" | JD | [generic] | Define each in your own words, briefly, then place your experience using only what you can describe: what you did, with whom, with what result. Selection scaffold: if your experience sits in only one, say so plainly, then say how you would build the other | Tests whether you understand the role and your fit against F1 and F5; JD because it scores role understanding |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Offer principles: who owns the decision, what gets escalated and when, how you keep each other informed. Then reciprocity: what you would bring to their team, not only what you would need | F1 from a collegial angle; CASE because it is a live scenario, JD secondarily |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say in your own words how you give credit and how you describe your own part. Use we for context and I for your contribution. Selection scaffold: pick one instance that shows it, and if none comes to mind, say so plainly, then give how you would handle it | A peer prices what you cost them in credit as well as work; VAL because it tests behavior, not knowledge |
| C3 | "Describe a disagreement with someone at your own level on another team. How did it end?" | VAL | [generic] | Pick one real instance, state your position and theirs fairly, and say what you did and what changed. Show spine and tact together; claim only the part that was yours. Selection scaffold: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 collegial; the pack's open prompt on the disagree-with-an-equal theme |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, what you actually said, how it landed, and the relationship afterward. Choose a story where the truth landed; where your material shows none, say so rather than supplying an ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4. VAL because it scores behavior; generic because Stripe's published values were not available |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick one decision and state the metric, the customer need and what you chose. Use I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6. A standard values probe; no company value is named because none could be fetched |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the one or two turns that matter, and why this role now. The content is yours; none is supplied here. Cut every sentence you could not expand if asked | Casual openers are scored on economy; EXP because the arc must match what you can defend |
| E2 | "What drew you to product operations?" | JD | [generic] | One concrete reason in your own words, tied to something you have done or want to do. Selection scaffold: if no reason comes to mind, say so plainly, then give how the role connects to your path | Motivation and role understanding, asked casually |
| E3 | "What are you looking for in your next role?" | EXP | [generic] | State what matters to you in your own words and keep it consistent with B2 and B3. Do not shape it to what you guess they want to hear | Consistency check across answers |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate the question. Give two points about your own fit that you can stand behind, then stop. Hold through two follow-ups and concede specifically if an internal candidate has an advantage you cannot dispute. This pack supplies no claim about your past | Tests composure; JD because it scores fit |
| F2 | "Pick the result you would claim most proudly. How much of it was actually you?" | EXP | [generic] | State your part in your own words, name what others did, and hold that position through two follow-ups. Concede exactly what was shared. Selection scaffold: if no result comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The attribution probe interviewers use to catch inflation; the rehearsal is precision |
| F3 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | It needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4; VAL because it tests behavior under pressure |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Choose one figure from your work and walk me through how it was counted." | EXP | [generic] | The slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Saying plainly that you do not know how part of it was counted is an honest branch. Selection scaffold: if no figure comes to mind, say so plainly, then say how you would track one | F3. A figure is the probe's usual target; the rehearsal is precision about it |
| G2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it in your own words before they do; this converts a gotcha into credibility. If you do not know which, say so plainly and say how you would find out | Follow-up to G1; the weakest-assumption move |
| G3 | "How would you decide whether a new internal process is actually working? What would you measure?" | JD | [generic] | Define what working means first (fewer escalations, faster decisions, adoption), choose two or three measures, say what baseline you would need, and name a way the measure could mislead. Keep it a plan and not a claim about your past | F2 and F3 in one case; JD because it scores a core duty of the role family |

## Reverse questions

At least five, each with why it lands. None asserts a fact about Stripe, since none could be researched.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a successful first ninety days look like in this role, and how would you tell?" | Shows you think about how the role is judged and lets you check your expectations against theirs |
| R2 | "Where does cross-team product work run most smoothly today, and where does it take the most effort?" | Invites a candid answer about the work itself and shows you think in terms of process, not only projects |
| R3 | "How does this team decide what it will and will not take on?" | Probes scope and prioritization, which a product operations role depends on |
| R4 | "How do you tell whether product operations is helping teams rather than adding process?" | Shows awareness of the role's main risk and gives you a metric to hold them to |
| R5 | "What would distinguish someone who does well in this role from someone who struggles?" | Surfaces the real scoring criteria and gives you a last chance to address them |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question, for any interviewer who turns out to be a peer; it shows what you would bring, not only what you need |

## Prohibited claims

No entries. This pack holds none of your sentences, so it has no wording to inflate and coaches no claim about your past. The fit snapshot's rows are all `none given`, and every guidance cell above is a selection scaffold or a structure for a live problem. Once you add a CV or answers, this section is rebuilt from them.

## Sources

Provided documents: your message (company, role, and the words "final round"). No job description, CV, interviewer information or research artifact was provided.

Searches sent, all refused, none returned anything:

- "Stripe operating principles values" — refused
- "Stripe interview process Product Operations Manager" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job description responsibilities qualifications" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have supplied official value names for the VAL bank and a values cheat sheet; VAL questions are themed from persona stems only, and the cheat sheet is dropped |
| 2. `Stripe interview process product operations` | unavailable | Would have supplied the documented loop and sharpened persona weights; the Generic archetype stands in |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current priorities; A4 is generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned the role-family rows F1 to F7 into quoted, labeled requirements |

## Upgrade menu

- The job description, pasted → role-family rows F1 to F7 become quoted requirements, JD questions gain raising sources, and the requirement-coverage table becomes a real check against the posting
- Your CV → every `none given` cell fills with your own quoted sentences, scaffolds become story-mapped guidance, and the highest-ROI objection is derived from your material instead of defaulted to B1
- Who you meet in each session and their relationship to you → persona weights stop being flat; if your final is several sessions, send the schedule and I can split the pack into per-session mini-packs
- Interviewer names → an interviewer read from their public professional footprint, and a reverse question tied to their path
- The recruiter's prep email → coverage for any named focus areas or a pre-declared presentation or take-home
- Search access → the official values page, the documented loop, and current strategy would replace the generic CO and VAL framing and add a values cheat sheet; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, on your say-so
- Time available before the interview → a prioritized prep schedule
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, per-gap strategy and a hard list of claims not to make, without needing to rebuild them here
