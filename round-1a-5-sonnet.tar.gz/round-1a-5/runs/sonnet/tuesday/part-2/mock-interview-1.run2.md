Searches were refused, so the pack is built from what you gave me, with no web research. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-1-denied-f5b1111f/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 22 questions, tagged by persona (A–G) and by type (VAL, EXP, JD, CO, CASE). Each question has a provenance label, answer guidance and a rationale.

Web search was refused, so all three searches (values, loop structure, Dan's public footprint) went unrun. The pack rests only on what you gave me: your JD highlights, Priya's summary, Dan's profile and your research note. Company values and Dan's public writing are not independently checked, and the weights assume a single 60-minute peer conversation as you described it.

- **Persona weights:** Peer Evaluator and Data-Driven Prober are tied for highest, because Dan is a peer and calls himself "relentlessly data-driven". Case/Strategist and Skeptic come next. Pressure and Values are low.
- **Highest-ROI rehearsal:** D1, the sales-ops and quota-setting objection. It has the most follow-up levels, and the plain concession is built from your note: "No classic sales-ops or quota-setting experience."
- **Where the evidence is thin:** the pack reports where Priya's material doesn't reach the JD, and doesn't bridge it with invented detail. F2 (whitespace across land/adopt/expand/renew) and F4 (partner-motion design) are the main gaps. The pack's answer slots there ask her to answer in her own words, or to say plainly that the practice wasn't hers.
- **What's dropped:** no values cheat sheet, because no values-style round is documented. There is no prep-triage section either, because you gave no prep time.

Say the word and I'll play the Skeptic on D1, the sales-ops question, as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Format:** one 60-minute conversation, as described in the coach's notes.
**Built on this assumption:** the session is a single peer conversation with Dan, and the JD is the highlights supplied, not the full posting. Web research was not permitted, so company values, loop structure and Dan's public footprint are not researched (see Sources).
**Highest-ROI prep:** D1, the sales-ops and quota-setting objection. Rehearse it until it is boring.

## How to use this pack and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words. An answer slot is an instruction for the interview, not a question for you now: answer whichever branch is true.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the stance the question probes, rather than generic virtue |
| EXP | Work-experience deep-dive | Whether the background claims survive scrutiny; what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market ownership, and the words stay there: "I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-product-lines wording makes a probe on launches likely. If any of that work was bringing a new product to market, say what part was yours; if there was no such work, or it was not yours, say so plainly and stay with the product strategy and ops role |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote shows a proposal credited with an uplift, not an analysis of customer stages, and the bridge should not be stretched. Answer slot: if any of your analysis looked at where customers stalled or grew between stages, say what you looked at, in your own words; if none did, say so plainly and say how you would start |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The tools match in the quote's own terms, so lead with them: "I'm skilled in SQL and Tableau." The quote says skilled, not what was run, with nothing inspected behind it, so expect a "walk me through one" probe. B4 rehearses it |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in carrier negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's required-experience wording makes a probe on how partners were engaged likely. If any part of that was yours to design, say which and how you decided; if there was no such step, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with it as written: "I set annual volume targets with cross-org consensus." A named record beats an adjective like "influential"; add nothing about who disagreed or how consensus was reached |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | discovery | Say what the quote says: "I use AI tools daily." It names no tools or tasks, and nothing in it shows building or launching AI. Answer slot: if asked what you use them for, say which tools and tasks, in your own words; if the use is not tied to your work, say so plainly |
| F7 | Sales-ops or quota-setting work — not a JD line; the gap Dan's function is most likely to probe | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The pack's own observation is that volume targets and sales quotas are different things, so the volume-target sentence is never offered as quota experience |

## Reading the interviewer

Public professional footprint only, from the coach's profile notes. Nothing was independently verified.

| Signal | Source | What it means for this conversation | Provenance |
|---|---|---|---|
| Describes himself as "relentlessly data-driven" | Profile, per the coach's notes | Every number you give will be probed to its inputs and assumptions. Speak in definitions, and say plainly when you do not know how something was counted (B1, B2, B3) | [grounded] |
| Career spine of pricing and monetization roles | Profile, per the coach's notes | Pricing, packaging and unit-economics framing is his native language. It raises the weight of the bundling and profitability cases (C1, C3) | [grounded] |
| One early-stage-startup chapter | Profile, per the coach's notes | Expect a probe on operating with less support than a large company (D3). Builder stories would land, but your material carries none, so none is offered | [grounded] |
| Peer reporting to the same VP | Coach's notes | He is pricing what the hire adds to or costs his own work. Reciprocity framing beats a list of needs (A1, A3) | [grounded] |

**Mirror opportunity:** shared vocabulary. His path runs through monetization, and F4's evidence reads "built a partner-level revenue model used in carrier negotiations". Describe that model in revenue terms and let him draw the connection. No shared career jump is offered: nothing in your material carries a startup or pricing-role sentence.

## Persona table

The weights rest on the coach's description of the session, not on a documented Northwind process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting, "what would you need from me", credit across teams | Highest. Peer prior is Peer Evaluator plus Data-Driven Prober, and you would report to the same VP | Reciprocity framing; propose seam principles rather than pretending to know the seam; disagreement shown with spine and tact |
| B. Data-Driven Prober | Inputs, denominators and assumptions behind each number | Highest. The peer prior plus his "relentlessly data-driven" self-description pushes this up | Know what you can and cannot say about how each figure was counted; name the weakest assumption first; offer to walk an analysis end to end |
| C. Case / Strategist | Live problems on bundling, adoption measurement and priority trade-offs | Medium. His pricing and monetization spine tilts cases toward packaging and unit economics, and your note gives a bundling threat and three priorities | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D. Skeptic | Quiet probing of F7, F4 and the one-employer history | Medium. He owns the sales-strategy function, so the quota gap is his home turf | Rehearse the sales-ops objection until it is boring; bridge only from your stated adjacent evidence; calibrated candor over bluffing |
| E. Conversational / Rapport | A friendly "walk me through the journey" opener | Low-medium. A 60-minute peer chat usually opens this way, and casual questions are still scored | A 90-second arc told only in the quote's terms; treat the AI question as scored |
| F. Pressure | Time-boxed "why you" and "how much was you" | Low. Nothing in your notes signals a stress style, but a data-driven peer may press on attribution | Pause, restate, hold the position the quotes carry through two follow-ups, then concede specifically |
| G. Values / Behavioral | Open "tell me about a time" prompts | Low. No values-style round is documented for this loop and no published values were read, so these questions are themed from the peer persona only | Choose stories where the hard truth landed; where none exists, say so plainly |

## Question banks

### A. Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where is the seam between GTM strategy for the new lines and sales strategy, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know the seam: for each shared question, who decides, who is consulted, who is informed. For a disagreement, say what data each of you would trust to settle it before you argue positions. Offer what you would bring his team, as a plan for the future, not a claim about the past | The JD's cross-functional line (F5's requirement) is scored hardest by the person whose turf it touches. JD because it tests the stated requirement, delivered in peer register |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Lead with your principle in your own words. If you offer an example, the nearest one your material carries is: "I set annual volume targets with cross-org consensus." Say what the work was and which part was yours, and add nothing about disputes or who disagreed. If no case of shared credit comes to mind, say so plainly, then give the principle you would follow | A standard peer probe for credit and turf. F5 is the only row with a cross-team quote, so it is the one example offered; EXP because it tests what was actually the candidate's |
| A3 | "What would you need from me in your first 90 days?" | JD | [generic] | Frame requests as questions you would ask him: how land, adopt, expand and renew are defined on his side, where his pipeline and target data lives, and which of his forecasts you should not duplicate. Pair each ask with what you would share back, such as early read-outs of your analysis, offered as a plan | The peer is pricing the load a new colleague adds, so reciprocity is what is scored. JD because it tests the cross-functional requirement and F2's requirement on definitions |
| A4 | "If a new line's early pipeline looks thin, do we change the target, the motion, or the positioning, and who decides?" | CASE | [generic] | Clarify first: thin by volume, quality or stage, and against what expectation. Then segment the funnel by stage, say which cut you would pull and from where, and separate decisions by owner. State the hypothesis you would test first and the data that would change your mind. The question asks nothing about your past, so this guidance claims nothing about it | A live collegial problem on the role's actual work, aimed at the seam. CASE because it scores structure under a collaboration lens; `[generic]` because it is a pattern, not a fact about Northwind |
| A5 | "How do you want to share analysis and definitions between us? Who owns the source of truth for funnel metrics?" | JD | [generic] | Propose one agreed metric dictionary before any dashboard is shared. Say you would run your own cut and reconcile it to his numbers before presenting, and that a disagreement gets traced to a definition first. This is a plan for working together, not a claim about how you have worked | F3's requirement says independent analysis, and a data-driven peer will test whether independence means a competing set of numbers. JD because it scores the stated SQL and Tableau line in peer register |

### B. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say exactly what the quote says: "I proposed a store-surface change credited with a ~$400M ARR uplift." Then the four slots a figure raises, each in your own words. How it was counted: say how, or say plainly you do not know. What it is sensitive to: say what, or say you do not know. The assumption you would defend least. Which part was yours. "I don't know how it was counted" is an honest branch; never describe a method you cannot repeat under a second question | F2's figure is the headline number and the likeliest probe from someone self-described as data-driven. EXP because it tests whether the claim survives scrutiny |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the assumption yourself, in your own words, before he does; it converts a gotcha into credibility. The pack does not name it for you. If none comes to mind, say plainly that you do not know what the figure rests on, then say what you would check to find out | Follows B1 in the same thread. The weakest-assumption move is the type-specific bar for any metric question; EXP because it tests candor about your own claim |
| B3 | "Walk me through how the annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Start from the sentence: "I set annual volume targets with cross-org consensus." Answer slot: his self-described data-driven style makes a probe on what the targets were built from likely. If you used a model or data to propose them before the consensus step, say what, in your own words; if there was no such step, or the inputs were not yours, say so plainly and return to the sentence. Call them volume targets, never quotas | F5's quote is the nearest to Dan's quota world and he will test where it stops. EXP because it tests what was actually done; D1 is where the quota gap is pressed directly |
| B4 | "Tell me about a time you ran an analysis end to end yourself." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one where you wrote or ran the query yourself, can name the tables and definitions behind it, and where a decision followed. The quote supports only "I'm skilled in SQL and Tableau", so name no analysis the quote does not give. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | F3 is the JD's tools line, and "independent" is the word he will test. JD because it scores the stated requirement; open prompt because no quote carries a specific analysis |
| B5 | "Walk me through how the partner-level revenue model was built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Start from the sentence: "I built a partner-level revenue model used in carrier negotiations." Answer slot: his own data-driven framing makes a probe on its inputs and assumptions likely. If you chose them, say which and why, in your own words; if they were set by others, or there was no such step, say so plainly and return to the model you built and where it was used. Do not describe how the negotiations went | F4 is your strongest monetization evidence and his native territory. EXP because it tests what was actually yours |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a competing capability at no extra charge. How would you shape GTM for one of the new lines in that world?" | CASE | [grounded] | Clarify first: which line, which customers already use the larger vendor's suite, and how comparable the bundled capability is. Then structure: objective, segments, how to position and package against a bundle, metrics, risks. Say aloud which premise you are challenging, such as whether comparability holds. Treat this as hypotheses to test with his team's data, not as facts about Northwind | The research note names bundling as the main threat and his pricing spine makes packaging the natural lens. CASE with CO flavor because it asks for strategy at the company's altitude |
| C2 | "Compass is launching. How would you decide what to measure in the first two quarters to know adoption, not just landing, is working?" | CASE | [grounded] | Define land versus adopt in plain terms first, then one or two leading indicators per stage, how you would segment them, and what you would ask his team about what is already tracked. State what would make you change the metric set. Your material does not show launches, so keep this a method you would run | The JD's land, adopt, expand and renew line (F2) and the note's AI copilot launch make this near-certain in some form. CASE because it scores clarify-then-structure on the role's actual problem |
| C3 | "Enterprise expansion and profitability are both stated priorities. Where do they pull against each other for a new product line, and which would you protect?" | CO | [grounded] | Name the tension concretely: investment in an enterprise motion versus near-term margin. Propose how you would decide, such as payback, cohort evidence and how early the evidence is. Give a view and label it a hypothesis you would test with his data. The pack does not supply Northwind's numbers; do not invent any | Tests whether you can hold the company's own priorities in tension at his altitude, in his unit-economics language. CO because it scores strategy knowledge from the supplied priorities; Pressure flavor in delivery |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. Where does that matter in this role, and where doesn't it?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." Then the adjacent sentence at its own scope: "I set annual volume targets with cross-org consensus." Then a plan, never a past: what you would ask his team and what you would verify with sales ops before proposing anything. Follow-up 1, "volume targets are not quotas": concede it, since you have said so yourself. Follow-up 2, "what would you get wrong first": name what you would check, not a claim of skill. Limit named before asked: you will not claim quota experience. Hold by returning to the quote, never by adding to it | F7 is where a sales-strategy director's concern lands hardest, so this objection arrives in some form. JD because it scores fit to the function; the deepest rehearsal because it is the one question he is most likely to ask |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Pick the honest answer. F4's row shows the JD requires partner-motion design and the material shows a revenue model, not a motion design: the pack's own observation, not words for you. Say: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how partners were engaged was yours to design, say which and how you decided; if there was no such step, say so plainly, and say what you would study first. Calibrated candor beats bluffing a competency he may know | The JD calls partner-motion experience required and F4 is the thinnest row against a required item. JD because it scores a stated requirement and its gap |
| D3 | "You spent nine years at one large consumer-tech company. How would you operate at a company of about three thousand people with a bundling competitor on its back?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Say what your material says: nine years at a large consumer-tech company, in product strategy and ops. Selection scaffold for the adaptability story: pick a time you worked with less support than you were used to, with a named constraint and what you changed; if no such time comes to mind, say so plainly, then give how you would approach working with fewer resources | His early-stage chapter makes a scrappiness probe plausible, and F1's history is large-company only. EXP because it tests whether the background transfers; the premise rests on the quoted tenure and the note's headcount |

### E. Conversational / Rapport Builder (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with only the beats the sentence states: two years of strategy consulting, then nine years in product strategy and ops at a large consumer-tech company. Add your own reason for moving to a B2B data-infrastructure company in your own words; the pack does not know it, and the arc fails without it. Do not add achievements the sentence does not carry | The opener is scored even when it feels casual, and F1's line is the only quote that covers the whole history. EXP because it checks the CV story |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say what the quote says: "I use AI tools daily." Answer slot: the JD's AI plus and a launch on the table make a probe on specifics likely. Say which tools and for what, in your own words; if the use is not tied to your work, say so plainly. Do not claim building or launching AI products | F6 is a plus on the JD, asked casually and still scored. JD because it tests a stated plus; Conversational because of the register |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has run quota and territory planning?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" and "No classic sales-ops or quota-setting experience." | Pause and restate the question. Hold only what the quotes carry: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus". Hold through two follow-ups by returning to those sentences. Then concede specifically: "I haven't had classic sales-ops or quota-setting experience." Never fold on the quotes just to restore harmony, and never claim more than they say | A time-boxed version of D1 for a stress read. JD because it scores the fit case; Pressure because it tests composure |
| F2 | "That ~$400M result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you also built, launched or measured anything after the proposal, say which part, in your own words; if not, say so plainly and return to the proposal. Concede specifically that you do not control how the uplift was credited, if that is true. Never fold on the proposal itself | Attribution probes exist to catch inflation, and F2 reads "credited with". EXP because it tests what was yours |

### G. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Where the hard truth did not land, say that rather than supplying an ending | Persona stem; no values round is documented, so this is insurance. VAL because it tests behavior, not a role requirement |
| G2 | "Tell me about a time you held a position against a peer team." | VAL | [generic] | Selection scaffold: pick a time with a clear disagreement, a position you kept and the reason, and a working relationship that survived. The nearest quoted sentence is "set annual volume targets with cross-org consensus"; say what it was and add nothing about disagreements. If no such time comes to mind, say so plainly, then give how you would handle it | The peer persona's disagreement probe in behavioral form, asked of someone who will sit beside him. VAL because it tests behavior |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | A4, C1, C2, C3 |
| identify whitespace across land/adopt/expand/renew | C2, A3 |
| run independent analysis in SQL and Tableau | B4, A5 |
| partner-motion design experience required | B5, D2 |
| strong cross-functional influence | A1, A2, A3 |
| AI experience a plus | E2 |
| sales-ops or quota-setting work (not a JD line) | D1, B3, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization roles and an early-stage startup. What did the startup chapter change about how you approach pricing a product with no history?" | Tied to his own path: it moves the conversation from interrogation to peer exchange and shows you researched him |
| R2 | "What could a new person on the team do in their first month that would genuinely help yours?" | The reciprocity question for a peer: it answers his real concern about what the hire costs him |
| R3 | "When your priorities and mine conflict, how does our VP usually decide?" | Shows you are thinking about the seam, not just the job, and surfaces how decisions really get made |
| R4 | "How are land, adopt, expand and renew defined and measured today, and where are the definitions least settled?" | Speaks to a data-driven peer's concern with definitions, and previews the first analysis you would run |
| R5 | "When the bundling competitor comes up in deals, what does your team see in how customers compare?" | Shows homework on the stated threat and invites him to share evidence rather than opinion |
| R6 | "What does Compass need from GTM in its first two quarters that you can't measure yet?" | Ties the launch to the measurement gap and signals you think in metrics first |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Treats annual volume targets as sales quotas | Contradicted by F7's stated negative | F5's quote at its own scope, with the limit as the pack's observation: the material says volume targets, not quotas |
| Owned, built, launched or drove the ARR uplift | Inflated form of F2 | F2's quote at its own scope: the material says proposed and credited, not built, launched or owned. B1, B2 and F2 stay inside it |
| Designed or ran a partner motion | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations. D2 and B5 slots stay inside the model |
| Conducted or led the carrier negotiations | Inflated form of F4 | F4's quote: the model was used in them; the material does not say who negotiated |
| Owned or launched GTM for a new product | Inflated form of F1 | F1's quote: product strategy and ops, not go-to-market ownership. F1's slot stays inside the role |
| Built or launched AI products | Inflated form of F6 | F6's quote: daily use of AI tools, nothing wider |

## Sources

Provided documents: the coach's message, which carried the JD highlights, the candidate summary for Priya, a profile summary of Dan Kovac, and a research note on Northwind Data's three priorities (enterprise expansion, the AI copilot launch Compass, reaching profitability) and its main competitive threat (bundling by a much larger platform vendor). The note and profile summary were not independently verified. No dossier was present.

Searches sent, all refused:

- "Northwind Data company values principles" — refused
- "Northwind Data interview process strategy GTM role" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

The loop is established by the coach's words: one 60-minute conversation run by Dan, a peer. No archetype fallback was used, and no values-style round is detected, so there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. Would have supplied official value names for the VAL bank; G1 and G2 rest on persona stems instead |
| 2. `Northwind Data interview process` | unavailable | Search refused. Would have documented the loop; persona weights rest on the coach's description of the session |
| 3. `Northwind Data strategy` / recent news | skipped | The research note in hand supplies the priorities and threat that feed C1 to C3 |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. Would have added his public talks and writing; the interviewer read uses the coach's profile summary only |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the seven fit-snapshot requirements become exact JD quotes, and mid-list requirements the highlights omit get their own rows and questions
- Which two product lines the role covers, and whether Compass is one → C1 to C3 become line-specific and the CO bank gets sharper
- Search permission, or a pasted values page and a recent strategy brief → the note's priorities get checked against Northwind's published material, and the values questions are rebuilt on official names. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can be run once if you want it
- Dan's talks, posts or a fuller profile → a tailored interviewer read and a reverse question built on his own writing
- Priya's own-words answers to the slots in F1, F2, F4 and F6 → those rows move from discovery or transferability toward quoted evidence, and B1, B3, B5 and E2 guidance becomes story-mapped
- An inspectable artifact, such as an anonymized copy of the revenue model workbook or a sample Tableau dashboard → F3 and F4 confidence can rise from medium toward high
- Priya's CV text → the coach's-note quotes become CV quotes, and any dropped line may add evidence
- The recruiter's prep note → stated focus areas and any pre-declared deliverable
- A `tuesday-dossier.md` from an earlier role evaluation → verified evidence and any prohibited claims would constrain the guidance
