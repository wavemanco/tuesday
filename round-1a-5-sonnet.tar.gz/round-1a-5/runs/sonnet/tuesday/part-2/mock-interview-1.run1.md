Priya's mock-interview pack is saved as `northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 21 questions across seven personas, built for a single 60-minute conversation with Dan as a peer.

Web search was refused all three times, so I couldn't check Northwind's values, the loop structure or Dan's public footprint. Everything about the company and Dan comes from your research note, and the pack says so. I used "your message" as the source for Priya's evidence because no CV text was supplied.

- **Top personas:** the Data-Driven Prober (5 questions) and the Peer Evaluator (4). Dan's "relentlessly data-driven" self-description pushes the Prober up.
- **Highest-ROI prep (C1):** the "no classic sales-ops or quota-setting experience" objection, which a Director of Sales Strategy is likely to raise. The pack gives a plain concession, then only what she quoted, then a ramp plan, with three follow-up levels.
- **The two figures:** the ~$400M ARR uplift (A1, E2) and the partner revenue model (A2) are set up for attribution and assumption probing.
- **Pricing tilt:** the case questions lean toward packaging and unit economics because of Dan's pricing and monetization background. They use your three priorities and the bundling threat.
- **Answer slots:** these appear wherever the material doesn't show a practice, such as GTM ownership, lifecycle whitespace work or partner-motion design. They tell Priya to answer from real experience or say plainly that it wasn't hers.
- **Dropped sections:** I left out the values cheat sheet, grounding brief, prep triage and delivery coaching, because no values were available and no prep time or assessment was given.

Say the word and I'll run a live drill, playing Dan as the Skeptic on C1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP). **Format:** one 60-minute conversation. Built on those facts as you stated them; there is no changelog because this is the first version.

## How to use this pack

- **Personas describe how a question arrives; types describe what it scores.** Rehearse both: the same question lands differently from a friendly peer, a prober and a skeptic.
- **Type key.** VAL: behavioral or values alignment. EXP: work-experience deep-dive, whether claims survive scrutiny. JD: role and JD-driven, can you do the listed job including its gaps. CO: company and strategy knowledge. CASE: a live problem from the role.
- **Guidance is scaffolding, not a script.** Every sentence about your past is a quote from your message, or an answer slot. An answer slot is an instruction for the interview: answer it from your real experience, or say plainly that the practice was not yours or never existed.
- **Provenance labels.** `[grounded]` traces to what you supplied. `[inferred]` is derived from adjacent material, with the derivation named. `[generic]` is a role-family pattern with no claim about you or Northwind.
- **Highest-ROI prep: C1.** The sales-ops and quota-setting objection will be asked in some form by a Director of Sales Strategy. Rehearse it until it is boring.

## Fit snapshot

Requirements are the JD highlights as you wrote them. The evidence column is your own words from your message about Priya; no CV text was supplied, so every row is `medium` at best until a CV or work artifact is inspected.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "then 9 at a large consumer-tech company in product strategy & ops" — your message; "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Your material says product strategy and ops work and a change you proposed, not ownership of a GTM strategy, and the words stay at that scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's ownership line makes a probe on whether any of that work was go-to-market for a new product likely. If any of it was, say what and which part was yours, in your own words; if none of it was, or it was someone else's, say so plainly and stay with the strategy and ops work and the change you proposed |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | low | [inferred] | discovery | The quote touches recurring revenue without showing work on any lifecycle stage, and the bridge should not be stretched from the ARR figure. Answer slot: the JD's land/adopt/expand/renew line makes a probe on which stage you have analysed likely. If you have analysed any of them, say which and what you found, in your own words; if none, say so plainly and say how you would start, as a plan and never as a past |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | The quote names both tools. Lead with it in its own terms: "I'm skilled in SQL and Tableau." Expect a probe for a specific analysis from a self-described data-driven interviewer; A4 rehearses it |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a model used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." The limit is the pack's observation, not words for you. Answer slot is in C3 |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Lead with the quote in its own terms, because a named outcome beats an adjective: "I set annual volume targets with cross-org consensus." The quote states the consensus, not how you reached it; B2 holds the slot |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | Say it as stated: "I use AI tools daily." The quote says use, not building or launching AI products, which is the pack's observation and not words for you. H2 holds the slot |
| F7 | Sales-ops and quota-setting familiarity, a likely probe area given his title (not a JD line in your highlights) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to quota work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Everything here comes from your description of Dan's profile; none of it was independently verified because research was refused this session.

| Signal (your note) | What it means for the conversation | Mirror opportunity |
|---|---|---|
| His profile self-describes as "relentlessly data-driven" | Every number you cite will be probed to its assumptions; the Prober is the top persona | F3: "skilled in SQL/Tableau" — your message. Offer to walk an analysis end to end (A4) |
| Career spine is pricing and monetization roles | Case questions will tilt to pricing, packaging and unit economics, his native language | F4: "built a partner-level revenue model used in carrier negotiations" — your message. Use revenue vocabulary |
| One early-stage-startup chapter | Possible probe on large-company pace; stories about building land better than stories about maintaining | No row carries a startup story on your side, so no shared-path mirror is offered |
| Peer, same VP | He is pricing what your hire costs and contributes to his work. Reciprocity beats self-promotion; propose seam principles rather than pretending to know the seam | B3 and reverse question R2 |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Reads every number to its inputs and goes two follow-ups deeper | Top. Peer prior names it, and the "relentlessly data-driven" self-description raises it further | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know; name your weakest assumption first | A1–A5 (5) |
| Peer Evaluator | Seam-splitting, "what would you need from me", credit and disagreement | Top. Peer relationship is the prior; he is deciding what you add to or take from his team | Reciprocity framing; propose seam principles, not a pretend seam | B1–B4 (4) |
| Skeptic | Quiet probing of the gaps | Mid. F7 is a stated gap sitting in his home domain, and F1 and F4 are thin | Rehearse the one predictable objection (C1) until it is boring; bridge only from what you quoted, and say the limit plainly | C1–C3 (3) |
| Case / Strategist | Live problems from the role, pricing-tilted | Mid. His pricing spine tilts cases toward packaging and unit economics; the three priorities in your note give the material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | D1–D3 (3) |
| Pressure | Time-boxed, "why you", "how much was you" | Low. Not a peer default, but one sharp moment is plausible | Pause, restate, hold through two follow-ups, concede specifically | E1–E2 (2) |
| Conversational | The opener and the "any AI?" aside | Low. Friendly in register, still scored | A rehearsed 90-second arc; treat casual questions about AI as scored | H1–H2 (2) |
| Values / Behavioral | Scenario probes | Low. No values-style round is established: your words describe one conversation with a peer, and no values page could be read | Selection scaffolds, ending in the honest branch | G1–G2 (2) |

Weights rest on your stated relationship and your note about Dan, not on an archetype; your words establish the loop as a single session.

## Question banks

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background credits a store-surface change with a ~$400M ARR uplift. Walk me through how that figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what you did in the quote's words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Then the four slots a figure raises. Answer slot: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; if you do not know how it was counted, or someone else counted it, say so plainly and stay with what you proposed. Name the weakest assumption yourself before he asks | F1 and F2 carry the headline figure, the first target of a prober. EXP because it tests whether the number survives its assumptions |
| A2 | "You built a partner-level revenue model that was used in carrier negotiations. Walk me through what went into it." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, and it was used in carrier negotiations. Answer slot: the JD's SQL and Tableau line makes a probe on how the model's numbers were produced likely. If you pulled or modelled the data yourself, say how, in your own words; if others supplied it or it lived elsewhere, say so plainly and stay with the model you built. Name the assumption in it you would defend least, or say plainly you cannot | F4 is the evidence he can monetize-test. EXP because it checks what was actually yours; he can compare it to his own pricing work |
| A3 | "Tell me about the annual volume targets you set." | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | The quote gives two beats: you set annual volume targets, with cross-org consensus. Tell them in your own words and no further; nothing raises a deeper probe here. If he asks beyond that and you do not know or it was not yours, say so plainly. He will hear targets next to quotas, so keep your word: volume targets, never quotas. The honest edge is the stated one: "I haven't had classic sales-ops or quota-setting experience." | F5 and F7 meet here. EXP because it tests precision about scope; the risk is a peer in sales strategy hearing a stretched comparison |
| A4 | "The role runs independent analysis in SQL and Tableau. Pick an analysis you ran yourself and take me through it end to end." | JD | [grounded] "skilled in SQL/Tableau" | Open with "I'm skilled in SQL and Tableau." Then a selection scaffold: choose an analysis you personally ran, with a question it answered, data you pulled, and a decision it fed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, or how you would run one. Name its weakest assumption before he does | F3 has no gap but nothing inspected behind it. JD because it scores the stated requirement; the prober format makes it an end-to-end walk |
| A5 | "Say we want whitespace across land, adopt, expand and renew for a new product. Where do you start?" | JD | [generic] | The question needs no claim about your past, so the guidance makes none. Structure: clarify the product and its buyers first, state the objective, segment by lifecycle stage and customer type, say which data you would pull and from where, name the metrics, then name risks. Challenge one premise respectfully, such as treating the four stages as equally weighted | F2's requirement as a live problem. JD tag because the stages are the JD's own; CASE delivery. `[generic]` because it is a pattern, not a fact about Northwind |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | JD | [generic] | No claim about your past. Do not pretend to know the seam. Propose principles and ask him how it works today: agree the metric before the debate, one named decision owner per call, disagree in the open and commit. Then ask what has gone wrong at the seam before | Persona stem for a peer. JD because F5's requirement is cross-functional influence; `[generic]` because it is a method, not a fact |
| B2 | "Tell me about a time work spanned teams and you had to get alignment." | JD | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: you set annual volume targets, with cross-org consensus. Answer slot: the JD's cross-functional influence line makes a probe on how consensus was reached likely. If the orgs disagreed and you moved the discussion, say what happened and what part was yours; if there was little disagreement, or the consensus came through someone else's work, say so plainly and stay with the targets you set. "We" for context, "I" for your contribution | F5 is the only evidence on influence, so this is where it is probed. JD for the requirement; the open prompt lets you choose the instance |
| B3 | "What would you need from my team in your first ninety days, and what could you give us?" | JD | [grounded] "skilled in SQL/Tableau" | Ask and offer in the same breath. Offer from the quote: "I'm skilled in SQL and Tableau, so I'd bring analysis to shared questions, not only requests." Ask for things you can name before you start: how his team defines the lifecycle stages, who owns which accounts, where the data sits. These are plans, not claims about your past | The peer prices what you add. Reciprocity is the peer counter-strategy; JD because it tests the cross-functional requirement |
| B4 | "How do you handle credit when work spans teams?" | JD | [generic] | A principle, and no claim about your past: say who did what in the open, name the owners of each piece, and share credit in the room, not afterwards. If he asks for an instance, a selection scaffold: pick a time credit was shared across teams, with a named stake and a relationship intact afterwards; if none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem. JD because it checks the cross-functional requirement; it also quietly tests the attribution honesty A1 and E2 probe |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background — how would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | **Highest-ROI rehearsal.** Concede first, plainly: "I haven't had classic sales-ops or quota-setting experience." Then name only what you did, in the quotes' words: "I set annual volume targets with cross-org consensus." Say it once and let him draw the comparison; do not call it equivalent. Then a ramp plan, in the future tense: ask his team to walk you through how quotas are set and where the data sits, and pull the data yourself in SQL. Follow-up 1: "Isn't that the core of GTM here?" Hold: agree it is a real gap, repeat the plan, do not minimise. Follow-up 2: "Why take that on over someone who has done it?" Hold: restate the quoted sentences and let him weigh them; the exact concession is "That's a fair concern: I haven't done it, and here is what I have done." Follow-up 3: "What would you get wrong first?" Answer slot: if you know what you would most likely misjudge, say it plainly in your own words; if you do not, say so and say who you would ask | F7 is the stated gap in his home domain, so this will be asked in some form. JD because it scores a requirement-adjacent gap; deepest means the most follow-up levels and the exact concession wording |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Pick the one that is true by your own account and say it first; the stated one is sales-ops and quota-setting. The pack's observation is that your material does not show GTM ownership for a product line (F1), lifecycle whitespace work (F2) or partner-motion design (F4). Answer slot: if you have done any of those, say so in your own words and choose a different weakest area; if you have not, say that plainly. Then how you would close it in your first thirty days, as a plan | Persona stem; the weakest-area question is almost certain. JD because it scores honest self-assessment against the listed requirements |
| C3 | "Partner-motion design is required here. What have you designed, as opposed to analysed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on how partners were engaged and structured likely. If any part of that was yours to design, say what and how you decided; if what you did was the model, or the motion was set by others, or there was none, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is `transferability`, the second-weakest row. JD because the requirement is marked required; the model is the only evidence, so the hold stays at its scope |

### D. Case / Strategist

Company facts in this bank come from your research note (three priorities: enterprise expansion, the "Compass" AI copilot launch and reaching profitability; main threat: bundling by a much larger platform vendor). The note is undated and unverified.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You'd own GTM strategy for two new product lines. What would your first thirty days look like?" | JD | [generic] | No claim about your past. Structure: who to learn from first, what data to pull, which hypotheses to test, then what you would agree with your peers before you propose anything, naming the seam with sales strategy. Say what you would not decide until you had seen it | F1's requirement as a live plan. JD for the stated responsibility; CASE delivery |
| D2 | "Compass launches into a market where a much larger platform vendor can bundle something similar. What do you need to know before choosing its GTM motion?" | CASE | [grounded] | Clarify first: who buys, how it would be packaged (standalone, bundled into existing tiers or priced on usage), what the bundle includes, who among existing customers can attach, how success is measured. Then objective, segments, approach, metrics, risks. Use his language: packaging, price realisation, attach. Challenge one premise, such as whether this is a feature fight at all. Say what you do not know about Compass rather than guessing | Grounded in your note's priorities and competitive threat. CASE with a CO angle; his pricing spine tilts it toward packaging |
| D3 | "Northwind is pushing enterprise expansion, Compass and profitability at once. Where does a new product line's GTM spend go when they collide?" | CO | [grounded] | Clarify whether they collide or are sequenced. Frame by unit economics: which motion pays back fastest, what to stage-gate, what to stop. Think aloud and say plainly that you do not know Northwind's numbers. Land with a decision rule and how you would test it | CO because it tests whether you can think at the company's altitude, from the three priorities in your note. The profitability priority turns any GTM answer into a trade-off |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience." | Pause, restate. Then three quoted sentences in first person, and name the stated gap yourself in its own words so he does not have to. Let him draw the inference. Hold through two follow-ups; the concession is specific, the gap you already named, and it never extends to the quoted sentences | Persona stem. JD because it scores fit; the pressure format tests composure. F7 means the "internal" comparison is likely to be sales-ops flavoured |
| E2 | "That uplift — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change, and the uplift was credited to it." Answer slot: which part of what followed the proposal was yours, in your own words; if none was, or others carried it, say so plainly and stay with the proposal. Hold through two follow-ups without adding to the quote; concede specifically what you cannot speak to | The "credited with" wording invites an attribution probe. EXP because it checks precise attribution; the pressure delivery tests whether you fold |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with two beats from the quotes: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Then the move: state your own reason for this role in your own words; the pack supplies none. End on one sentence from your quotes you want him to remember | Biography openers are scored. EXP because it checks the career story against F1; the move is where a skeptic will pick up |
| H2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | "I use AI tools daily." Answer slot: the JD's AI-plus line makes a probe on what for likely. If you use them in analysis or strategy work, name the tool and one task, in your own words; if your use is lighter than that, say so plainly and stay with daily use. Do not claim building or launching AI products | F6. JD because "AI experience a plus" is the stated requirement; casual register but still scored |

### G. Values / Behavioral

No published values were read this session, so these use persona stems and are not mapped to Northwind's values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem; low weight because no values round is established |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where the metric and the customer pulled apart, what you chose and why. If none comes to mind, say so plainly, then give the nearest thing or how you would handle it | Persona stem. Cheap insurance for a peer who may widen the conversation |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | D1, D2, D3, C2, E1 |
| "identify whitespace across land/adopt/expand/renew" | A5, D2 |
| "run independent analysis in SQL and Tableau" | A4, A2 |
| "partner-motion design experience required" | C3, A2 |
| "strong cross-functional influence" | B1, B2, B3, B4 |
| "AI experience a plus" | H2 |
| Sales-ops and quota-setting (not a JD line) | C1, A3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization. How has that shaped how you'd package a launch like Compass against a bundled competitor?" | Ties to his own path, converts the interview into a peer conversation and shows you read him, not only the company |
| R2 | "What could a new person on the strategy side do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you are pricing your hire the way he is |
| R3 | "Where does sales strategy's work end and this role's begin on the two new product lines, and who has the final call when we disagree?" | Tests the seam you proposed principles for in B1, and signals you want clarity, not turf |
| R4 | "Where do you trust the lifecycle data least today?" | Speaks to a data-driven interviewer and sets up the SQL work you would bring |
| R5 | "Of the three priorities — enterprise expansion, Compass, profitability — which is hardest on the GTM side right now?" | Uses the priorities in your note and gets his live read, which no document supplies |
| R6 | "You had an early-stage chapter. What did you carry from it into strategy at this scale?" | Ties to his path and invites a builder conversation, which suits a peer relationship |

## Prohibited claims

Built locally from the fit snapshot. None of these may appear in a guidance cell, a slot, a bridge or a drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran GTM strategy for a product line | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says product strategy and ops and a proposed change, not GTM ownership. C2's slot stays inside what you quoted |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F1 and F2 | "I proposed a store-surface change that was credited with a ~$400M ARR uplift." A1's and E2's slots ask only about counting and your part |
| Designed the partner motion | Inflated form of F4 | The model, used in carrier negotiations, at its own scope. The limit is the pack's observation, not words for you |
| Has quota or sales-ops experience, or treats volume targets as quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Has analysed lifecycle stages or expansion and renewal whitespace | Inflated form of F2 | F2's quote at its own scope. A5 is a live problem and claims nothing about your past |
| Builds or ships AI products | Inflated form of F6 | "I use AI tools daily." The limit is the pack's observation |

## Sources

- **Provided:** your message, which supplied the JD highlights, the candidate summary, the description of Dan's profile and your research note on Northwind's priorities and competitive threat. No full JD, CV text, recruiter guidance or `tuesday-dossier.md` was provided.
- **Searches sent, all refused (web search was not permitted this session):**
  - "Northwind Data company values principles" — refused
  - "Northwind Data interview process GTM strategy lead emerging products" — refused
  - "Dan Kovac Director of Sales Strategy Northwind Data" — refused
- **Not independently verified:** every fact about Northwind and Dan comes from your note. The note is undated.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. Would have supplied official value names for a values cheat sheet; none is built, and G1 and G2 are `[generic]` |
| 2. `Northwind Data interview process GTM strategy lead` | unavailable | Search refused. Would have documented the loop; your words already establish one 60-minute peer conversation, so persona weights are unaffected |
| 3. `Northwind Data strategy` / recent news | skipped | Your note already supplies the three priorities, Compass and the bundling threat that the D bank rests on; it is undated, so those rows stay labeled to your note |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. Would have added his talks and writing; the interviewer read rests on your description only |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the F rows quote the JD directly instead of your highlights, and any requirement the highlights left out gets a row and a question
- Priya's CV, pasted as text → the evidence cells quote her own lines, not your summary, and the F1, F2 and F5 slots can be answered against real sentences
- Her answers to the F1, F2, F4 and F5 slots → those rows move from `discovery` or `transferability` toward `presentation`, and the B2 and C3 stories can be mapped instead of scaffolded
- An inspectable artifact for the ARR figure and the carrier-negotiation model, such as the analysis behind them → `medium` can rise to `high` and A1 and A2 get real beats
- A recruiter or HR note on focus areas → coverage that is currently assumed from the peer prior
- Dan's public profile text or talks → a fuller interviewer read and more tailored reverse questions
- Deeper research (up to 6 further searches and 2 further fetches, several more minutes, and it needs web search to be permitted) → Northwind's strategy brief, Dan's public footprint and loop reports; offered once
- Prep time available → a prioritized prep schedule
- A `tuesday-dossier.md` from an earlier underwriting pass → verified evidence, a named highest-ROI objection and binding prohibited claims
