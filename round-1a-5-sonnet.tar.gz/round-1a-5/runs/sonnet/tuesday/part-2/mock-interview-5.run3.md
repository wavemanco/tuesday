I'm building your prep pack now. Web search was refused in this session, so it rests on your message and the recruiter's email, not on research about Kelverton.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-5-denied-eefdf7ec/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a panel round with Deepa as your future manager and Ross as a senior commercial voice. Your note gave titles, not backgrounds, so those weights are my assumption.

I couldn't run any web research, because the session refused all five searches. That means nothing in the pack is drawn from Kelverton's website, values, strategy news or the panel's public profiles. I also haven't seen the market report, so the POV section gives you three theses to test against your own reading of it. The pack lists each research gap and what filling it would change.

Say the word and I'll play the Skeptic on C1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, if there is one, and the market report's main recommendations or headline numbers? Either would let me rewrite A4 and the POV's consensus-versus-divergence choice against the actual report, or you can say skip and the pack stands as built.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes, Tuesday. **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). **Shape, in the recruiter's words:** the first 15 minutes are your POV on where you would take Kelverton's operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and Ross will push on commercials.

**Assumption this pack is built on:** only titles were given for Deepa and Ross, so Deepa is weighted as a hiring manager and Ross as a senior commercial voice on the panel. If you know more about either, the persona weights change.

## How to use this pack

- **Personas are how a question arrives. Types are what it scores.** Every question carries one persona (its bank letter) and one type tag.
- **Guidance is scaffolding, not a script.** Where a cell quotes you, it uses your words at their own scope. Where it says Answer slot, the answer has to come from you in the interview, and one honest branch is always "that was not mine" or "there was no such step".
- **Provenance labels:** `[grounded]` traces to what you or the recruiter wrote, `[inferred]` is a named derivation, `[generic]` is a role-family pattern with no claim about Kelverton or about you.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior demonstrates published values (none banked here, see the persona table) |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated job and its gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

## Prep triage (about four hours, spread over the weekend)

| Block | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV from section 5, say it aloud twice with a timer, and record the second run. The last three to four minutes must be about the operators | Section 5, A1, D2 |
| 2 | 60 min | Rehearse the single most likely objection until it is boring, then the sixty-second version | C1, C2, C3, D1 |
| 3 | 50 min | Decide in writing, before you rehearse, your own answers to the commercial slots: how the £4M was counted, what you would accept being measured on | B1, B2, B4 |
| 4 | 40 min | Read the reverse questions once, then run one full 60-minute simulation: POV, then five questions drawn from banks A to D | Reverse questions, A4 |

Everything else (A3, A5, E1, E2, F1, F2, B3) is insurance: read it once, rehearse it only if time is left.

## Fit snapshot

No job description was supplied, so the requirement column quotes the recruiter's email and your own message, and F6 is a role-family requirement written without a source.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says a payments ISV channel, not operator partnerships, with nothing inspected behind it, and the words stay there: "I was running the ISV channel, and I took it from 6 partners to 40." The transfer to operators is yours to argue and its limit is to be said. Answer slot: if asked how the count went from 6 to 40, say what you did and what was others, in your own words; if there was no such step, or it was not yours, say so plainly and return to running the channel |
| F2 | "land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning in transport consulting, nothing inspected behind it. The sentence does not say who the other side was, so say that only in words you have decided on. Answer slot: the ask to land on the operators makes a probe on which operators likely. If you worked with operators, say which and on what problem; if you did not, or not on this, say so plainly and stay with bus and light rail network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure stays at its own scope: roughly, and influenced. The material does not say closed or booked, and nothing is inspected behind it. Answer slot: in your own words, say how it was counted, what it is sensitive to, the assumption behind it you would defend least and which part was yours; if you do not know how it was counted, say so plainly |
| F4 | "Ross will push on commercials" — recruiter's email | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would want to be measured here, said as a plan and never as a past. The recruiter's words say commercials will be pushed, not that a quota is part of the role, and nothing here shows the role's commercial terms; reverse question R3 is how you find out |
| F5 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, as a plan for your first months and never as a past. F2's bus and light rail work is adjacent evidence and stays in its own row |
| F6 | Growing and managing a portfolio of partners (a role-family expectation, no source supplied) | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [generic] | none | No gap in the terms of your own quote, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: nine years in partnerships, the last four running the ISV channel at a payments company |

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. This pack has not seen the market report her strategy team circulated, so the theses below are built to be tested against your reading of it, and every claim about operators is a design intent, not a finding about Kelverton.

**Grounded facts to build on**

| Fit row | Sentence from that row's evidence | Use |
|---|---|---|
| F1 | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | One credibility line, at its own scope. It is a payments ISV channel, so argue the analogy to operators and name where it stops |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | One framing line on why you will talk about operators. Keep it to bus and light rail |
| F3 | "roughly £4M of influenced revenue" | Only inside a concession aimed at Ross, at its own scope |
| F5 | "Never sold into rail specifically" | One line of candor in your frame, before they raise it |

**Timing skeleton**

| Minutes | Beat | What it does | Provenance |
|---|---|---|---|
| 0:00 to 1:30 | Frame | Say what you take operator partnerships to mean, one stated assumption, and one line of candor: that you have not sold into rail (F5) and come at it from partnerships and from operator-side planning (F2) | [generic] |
| 1:30 to 4:00 | Where things stand | One point from the market report you agree with, to show you read it, then your own read of what it leaves out | [generic] |
| 4:00 to 11:00 | Your moves | Two or three theses from the table below, about two minutes each, each with its concession said aloud | [generic] |
| 11:00 to 14:00 | What it means for the operators | The requested close, per move: what is different for an operator and when, what you would ask of them, how they would know it is working | [generic] |
| 14:00 to 15:00 | What would change your mind | What you would test first, and an invitation to steer. Finish at 13:30 in rehearsal so the live run has slack | [generic] |

**Thesis options (use two or three, cut the rest)**

| Option | Argument | Mandatory concession | What it means for the operators (the close) | Provenance |
|---|---|---|---|---|
| T1 Depth before breadth | Spend the 18 months making a small number of operator relationships work properly before extending coverage | Depth costs coverage: some operators will be less served for a while, and you have not seen the portfolio, so this is a hypothesis to test in your first 90 days | A named counterpart at Kelverton and a clearer route for what they need, in exchange for their time and candor | [generic] |
| T2 Agree the operator outcome first | Make each partnership begin with an outcome the operator wants to move, measured in the operator's terms, not in Kelverton's activity counts | Outcomes an operator controls are slower to prove and attribution is contestable, and F4 says "never carried a direct quota, only influenced revenue", so say you would want the measure agreed with Ross before it is promised | The operator can hold Kelverton to something specific, and knows when it will be judged | [generic] |
| T3 Use the ecosystem | Extend what operators get by bringing in third parties around Kelverton, as an extension of the partnerships rather than a replacement. The one personal analogue you have is F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | The analogue is a payments channel, not operators, and third parties add coordination cost the operator may end up carrying. Check first with Deepa whether third parties are within the brief | More of what the operator needs reachable through one relationship, if the interfaces are right; more to manage if they are not | [generic] |

**Differentiation.** The market report is equally available to both of your interviewers, and their own strategy team wrote it, so reciting it scores as homework. Bring one point from it you agree with, then one thesis that departs from it, with your reasons. If your reading is that the report leans toward breadth, T1 is your divergence; if it leans toward depth, lead with T2 or T3. Anti-pick: name one thing the report's list suggests that you would deliberately not do in 18 months, and why; your own reading supplies it. The report is a quarter old by your note, so say what you would check has moved rather than correcting anyone.

**The requested close.** Spend the last three to four minutes on the operators themselves. For each move you kept: what an operator sees differently at month 6 and at month 18, what you would ask of them in return, and how they would know it is working. Use one operator outcome from the report that you can defend; do not invent one here.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (rehearsal method) |
|---|---|---|---|
| A Case/Strategist | The POV itself, then live problems on the roadmap | Highest. A hiring manager's prior is Case plus Skeptic, an executive's prior is Case plus Pressure, and the 15-minute POV is a case by the recruiter's own description | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B Data-Driven Prober | Your figures taken to their assumptions | High. The recruiter's words say Ross will push on commercials, which moves the Prober up from its prior, and the £4M and the 6 to 40 are the figures on the table | Know what you can and cannot say about how each number was counted; name the weakest assumption before they do |
| C Skeptic | The two stated gaps, rail and direct quota, in a quiet register | High. The hiring-manager prior includes Skeptic, and F4 and F5 are stated gaps | Rehearse the most predictable objection until it is boring; bridges only from what you stated |
| D Pressure | Interruptions, time-boxes, "why you over someone who has sold into rail" | Medium. It is the executive prior, and "push" suggests it, but only the titles are known | Pause, restate, anchor in what you actually stated, hold through two follow-ups before conceding anything real |
| E Peer Evaluator | The seam between partnerships and commercial | Low to medium. Ross sits on the commercial side of that seam, but nothing says it is a peer evaluation | Propose seam principles rather than pretending to know the seam; reciprocity framing |
| F Conversational | An opening "walk me through your journey" | Low. Likely brief, but the opener is still scored | A 90-second arc; treat casual questions as scored |
| Values/Behavioral | Not banked | No loop source documents a values round, and no published values were read, so no VAL questions are included | Not applicable this round |

Persona weights rest on the recruiter's description of this one session, which establishes the loop, plus relationship priors: hiring manager for Deepa, executive for Ross, adjusted for the recruiter's note on commercials.

## Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have fifteen minutes: where would you take our operator partnerships over the next 18 months, and what does that mean for the operators themselves?" | CASE | [grounded] | Build it from section 5, not from this cell. Order: clarify what operator partnerships means here, one stated assumption, two or three moves with their concessions, then the last three to four minutes on the operators because that is where you were asked to land. Say it aloud twice against a timer | The recruiter announced it, so it is graded; CASE because it is delivered live against the role's own problem |
| A2 | "What do you need to know about how operators work with us that you don't know yet?" | CASE | [grounded] "Never sold into rail specifically" | Clarify before you structure. Name three unknowns and what you would do first to learn each: what operator partnership covers commercially (customer, design partner or both), who on the operator side decides, and what has moved since the report was written. If rail comes up, use your own words: "I've never sold into rail specifically, so these are the first things I would test." | F5 is the stated gap; scoring is on whether the candidate clarifies before structuring |
| A3 | "Name an operator partnership you would not pursue in the next 18 months, and tell me why." | CASE | [generic] | You do not know the portfolio, so say so and give criteria, not names: what evidence would make a partnership one to pause or not start. Hold the answer through a challenge by returning to your criteria, and concede that you would need the data | The anti-pick: saying no scores as judgment; a pattern for the problem, not a fact about Kelverton |
| A4 | "The market report went to you as well as to us. Where do you disagree with it?" | CO | [grounded] | One point you agree with, to show you read it, then one point where you would diverge and why. Answer slot: name the points from your own reading, since this pack has not seen the report; if you found nothing to disagree with, say so plainly and say what you would test first | The report is equally available to the panel, so reciting it scores as homework; CO because it tests strategy fluency |
| A5 | "What should have changed at month 6, month 12 and month 18, and how will we know?" | CASE | [generic] | Three checkpoints, each with one measure an operator would recognise, not only a Kelverton activity count. State no numbers you cannot back, and concede that the checkpoints are a hypothesis until you have seen the portfolio | Turns the POV into something accountable, which is what Ross's commercial lens will test |

### B. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure at its own scope: roughly, and influenced. Answer slot: in your own words, say how it was counted, what it is sensitive to, the assumption you would defend least and which part was yours; if you do not know how it was counted, say so plainly. Never turn influenced into closed or booked | F3 is the headline figure, and quantified claims are what probers go to first; EXP because it tests attribution |
| B2 | "How should we measure you in your first twelve months?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Open with the plain fact in your own words: "I've never carried a direct quota, only influenced revenue." Then your proposal, which is yours to decide: what you would accept being held to in year one and what you would want agreed first. Decide before Tuesday and write it down; do not offer a number you have not decided | F4 is where the commercial push lands; JD because it scores the stated commercial scrutiny |
| B3 | "Sketch the commercial structure of a partnership with one operator: who pays whom, for what, and how does it end?" | CASE | [generic] | Clarify first whether the operator is a customer, a design partner or both, since your structure depends on it. Then principles, not terms: what each side puts in, what each takes out, how it is reviewed and how it ends. You do not know Kelverton's current terms, so say so and hold your principles through two follow-ups | Ross's commercial push, live; the question asks nothing about your past |
| B4 | "You say the channel went from 6 partners to 40. How much of that was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Say it at the quote's own scope: "I was running the ISV channel, and I took it from 6 partners to 40." Answer slot: say how the 40 was counted, what the count depends on and which part was yours; if any of it was someone else's, or came without your involvement, say so plainly and return to the channel you were running | F1 holds the other headline figure; EXP because it is the attribution probe |

### C. Skeptic (weight: high; C1 is the highest-ROI rehearsal in the pack)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail and you've never carried a direct quota. Why should we believe you can do this job?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "last 4 at a payments company running the ISV channel — took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Three moves. Concede in your own plain words: "I've never sold into rail specifically, and I've never carried a direct quota, only influenced revenue." Hold on what the quotes carry and add nothing: you were running the ISV channel and took it from 6 partners to 40, and you spent five years in transport consulting on bus and light rail network planning. Then say what you would do about the gap as a plan for your first months, never as a past. Limits to name before they are asked for: the second quote says bus and light rail, so expect a probe on train operating companies; and influenced will be pressed against carried. Hold through two follow-ups, C2 and C3, by returning to these quotes, never by adding to them | F4 and F5 are both stated gaps, and a hiring manager buying capability will go here first; this question will be asked in some form |
| C2 | "Your planning background is bus and light rail. What carries across to train operating companies?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say the quote at its own scope. Answer slot: the interviewer will probe which operators; if your planning work was for operators, say which and on what problem, in your own words; if you did not work with operators, or not on this, say so plainly and stay with bus and light rail network planning. Do not claim train operating company knowledge the sentence does not carry | F2 is the evidence the bridge rests on; the follow-up an interviewer asks next |
| C3 | "Influenced revenue isn't a number you've been held to. Convince me." | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | Do not argue the number up. Say it plainly: "I've never carried a direct quota, only influenced revenue." Hold the figure at its own scope, roughly £4M of influenced revenue, and concede what it is not. Then what you would propose to be held to, from B2: your decision, made before Tuesday | F3 and F4 together; the second follow-up in the objection ladder |
| C4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Pick the one that is honestly weaker. The material points at F5 and F4, which is the pack's observation, not your answer. Say it in your own words, then the plan for closing it. Answer slot: if there is a weaker part your material does not show, say so plainly in your own words | Persona stem for the Skeptic; calibrated candor beats bluffing |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Pause, restate the question, concede first: "I've never sold into rail specifically." Then hold the position the quotes carry: you were running the ISV channel and took it from 6 partners to 40. Hold through two follow-ups by returning to that, and concede only the specific thing. Do not claim you are faster, cheaper or more strategic than the other candidate; nothing you quoted says so | F5 and F1; Pressure scores composure, not content |
| D2 | "Stop there. 'Partnerships' is your word. What do operators actually buy, and from whom?" | CASE | [generic] | An interruption mid-POV. Pause, restate, and challenge the premise respectfully: "Before I answer, are we talking about operators as customers or as partners?" Then continue your plan. Hold through a second interruption | Tests holding a position mid-delivery; the question presupposes nothing about your past |
| D3 | "Your plan costs money and people we may not have. What do you cut first?" | CASE | [generic] | Pause. Give the criteria you would cut by, not names, and say you do not know the budget. Hold your criteria through two follow-ups and concede the budget as a limit | Ross's commercial lens on A1 and A5 |

### E. Peer Evaluator (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side here. Where's the seam on an operator deal, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not a pretended map: who holds the operator relationship, who holds price, and how a disagreement is escalated and recorded. Reciprocity: what you bring the commercial team, not only what you need | A collaboration scenario from a commercial director's side of the seam |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | A scaffold: pick a time credit for a result was shared and the relationship stayed intact; it needs named parties, what the split was and how it was settled. Answer slot: if credit was shared or contested, say how it was handled; if it was not, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is that your number was influenced revenue and never a direct quota, or how you would handle it | F4's influenced framing is where credit questions naturally arise |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey from transport planning to partnerships to here." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc whose beats are the ones the quotes state: nine years in partnerships, the last four at a payments company running the ISV channel, and five years in transport consulting on bus and light rail network planning. Tell them in the order it happened. Answer slot: why rail, why Kelverton, why now; give your own reason, in your own words, and if you do not have one that holds under a second question, say what you do have | F6 and F2; the biography question is the opener and is still scored |
| F2 | "What are you actually playing with in rail-tech these days?" | CO | [generic] | Answer slot: name something you have actually read, used or looked at; if nothing, say so plainly and name the first thing you would look at | A casual question on a hot topic is still scored |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A5, D2, D3 |
| "land on what it means for the operators themselves" | A1, A5, D2 |
| "Ross will push on commercials" | B1, B2, B3, B4, C1, C3 |
| "they sell scheduling software to train operating companies" | A2, C1, C2, C4, D1, F2 |
| Growing and managing a portfolio of partners (role-family) | B4, F1 |
| The market report the recruiter attached | A4 |
| Peer seam with the commercial side (no stated requirement) | E1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When we say operator partnerships here, are operators customers, design partners or both, and does it differ by operator?" | It tests whether your POV's frame matches theirs, and shows you checked before assuming |
| R2 | "What would you want to be true at month 18 for you to say this was the right hire?" | It turns the 18-month frame back on the person who owns it and gives you the scoring sheet |
| R3 | "How is a partnerships number set here, and how does it sit alongside the commercial team's?" | It answers what F4 leaves open, whether a direct quota is part of the role, so you leave knowing |
| R4 | "Since the strategy team wrote the market report, what has moved?" | It shows you treat a quarter-old report as a snapshot rather than gospel |
| R5 | "What could a new person in this seat do in the first month that would genuinely help your team?" | A reciprocity question for the commercial side of the panel |
| R6 | "What does a good operator partnership look like from the operator's side, and what would they say they got?" | It hands you the operators' own vocabulary for the close you were asked to land on |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a direct quota, or owned a revenue number | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never sold into rail specifically." No slot |
| Closed or booked the £4M | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: the material says influenced, not closed or booked. B1's slot stays inside how it was counted |
| Built the channel or recruited its 40 partners | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material does not say who brought in which partners. B4's slot asks only which part was yours |
| Planned or knows train operating company networks | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the sentence says bus and light rail, not train operating companies. C2's slot stays inside bus and light rail |

## Sources

**Provided documents:** your message, which quotes the recruiter's email and gives your background; no CV and no job description were supplied. The market report the recruiter attached was not visible in this conversation, so nothing in this pack is drawn from it. No dossier was present.

**Searches sent, each refused by the session's permissions, none returned a result:**

- "Kelverton Rail company values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail scheduling software train operating companies strategy news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Senior Partnerships Manager rail technology scheduling software train operating companies job": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have themed VAL questions; no values-style round is documented, so no cheat sheet in any case |
| 2. Kelverton Rail interview process, partnerships | unavailable | Would have checked the loop; persona weights rest on the recruiter's own description of this session instead |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have grounded the CO bank and a grounding brief; A4 and A2 are slots and generic instead |
| 4. Deepa and Ross, public professional footprint | unavailable | Would have added an interviewer read and a reverse question tied to each one's path; reverse questions are role-generic |
| 5. Representative Senior Partnerships Manager job description | unavailable | Would have given JD-quoted requirement rows; the requirement rows rest on the recruiter's words instead |

## Upgrade menu

- The job description, if there is one → the requirement rows now quoting the recruiter's words become JD-quoted, the coverage table is re-keyed to the posting's own list, and JD-tagged questions follow it
- The market report's main recommendations and headline numbers, pasted → A4, the consensus-and-divergence choice in section 5 and a grounding brief are written against the report instead of by rule
- Search access, or Kelverton's values page, interview process and recent strategy news pasted → the five unavailable research rows are filled, CO questions are grounded, and a values cheat sheet appears only if a values-style round is documented
- Deepa's and Ross's public professional profiles, if you have them → persona weights read from their career paths, an interviewer read, and a reverse question tied to each one's path
- The partner attribution report behind the £4M (sourced versus influenced), in a form you are able to share → F1 and F3 can move from medium toward high, and B1 can quote what it shows
- Your own answers to the answer slots (what part of the 6 to 40 was yours, how the £4M was counted, which operators you worked with) → F1, F2 and F3 regenerate, and the slotted stories become mapped ones
- A tuesday-dossier.md from an earlier check of this role, if you have one → verified evidence and a sourced objection list replace the objections this pack inferred
