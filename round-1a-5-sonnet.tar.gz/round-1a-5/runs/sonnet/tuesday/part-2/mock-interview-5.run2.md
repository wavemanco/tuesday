Searches were denied, so I'm building the pack from your message and the recruiter's email. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-2/rooms/case-5-denied-a78565bc/kelverton-rail_senior-partnerships-manager_interview_pack.md`. The web searches were denied, so nothing in it comes from research. I couldn't see the market report or the posting, so it rests only on your message and the recruiter's quoted email.

The most important prep is B1, "You haven't sold into rail. Why should we believe you can be credible with operators from day one?" I'd expect it in some form. It gets the deepest rehearsal, using only the sentences you gave me.

Say the word and I'll play Ross pushing on C1 to C3 and D3, or Deepa on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the market report's text or its headline recommendations, and the posting if you have it? Your POV theses and the questions about the report are the parts that would change most. I've built everything without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your POV on where you would take operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials.

Built from your message and the recruiter's email as you quoted it. No web research ran, and the market report and the posting were not available to me.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Answer slots are instructions for the interview: where one appears, answer from your own experience or say plainly it was not yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether claims on your background survive scrutiny |
| JD | The role's stated responsibilities and gaps |
| CO | Company and market knowledge |
| CASE | A live problem, structured aloud |

## Prep triage (about four hours)

1. About 90 minutes: build and rehearse the POV (section 5). Say it aloud twice with a timer, and cut it until it fits well inside the 15 minutes.
2. About 60 minutes: say B1, B4, D1 and D3 aloud until the plain acknowledgments feel boring.
3. About 45 minutes: write out, in your own words, how the £4M and the 6 to 40 were counted and what you do not know about either (C1 to C3, D2).
4. About 30 minutes: rehearse C4 and F1 as live structures, and choose three reverse questions (section 11).
5. About 15 minutes: the 90-second arc in E1.

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's own words as you quoted them, since no posting was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, and the words stay at that scope: "For my last four years I was running the ISV channel at a payments company, and I took it from 6 partners to 40." Answer slot: the recruiter's phrase, operator partnerships, makes a probe on what carries over likely. If any part of how you built the channel applies to operators, say which, in your own words; if none does, say so plainly and stay with the channel |
| F2 | "what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the quote's last clause is ambiguous about which side you stood on, so read it at its smallest scope. Words: "For five years I was in transport consulting, on bus and light rail network planning." Answer slot: expect a probe on what the phrase "the other side" means. Say who the work was for, in your own words; if the phrase claims more than the work did, drop it and keep the planning work |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message, "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue and you have said it was never a direct quota. Words: "I've never carried a direct quota, and the £4M was influenced revenue." Answer slot: the figure raises how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; if you do not know how it was counted, say so plainly |
| F4 | Rail-sector knowledge for a seller to train operators — role-family requirement, written from no source | "Never sold into rail specifically" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past |

No row is a gate: nothing in your material or the recruiter's words states an eligibility, location, pay or schedule term.

## 5. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. Build it from these facts, and only these, about you:

- F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4: "Never sold into rail specifically"

Shape (generic craft): one-sentence position, three beats, a close on operators. Speak to well under 15 minutes so there is room for follow-ups, and say your structure aloud before you use it.

Three defensible theses. They are positions to test against the report you read, not claims about Kelverton, which I could not research. Pick two or three the report leaves room for.

| Thesis | What it means for the operators themselves | Mandatory concession |
|---|---|---|
| T1. Fewer, deeper operator partnerships first, then widen | An operator gets sustained attention and a named result, not an occasional relationship | Depth costs reach: some operators wait, and which ones go first depends on Kelverton's own partnership data, which your material does not include |
| T2. Make an operator-side outcome the unit of success, agreed up front with each operator | An operator knows what the partnership is meant to change for them and can hold Kelverton to it | Outcomes are hard to attribute and can be contested; start with two or three, and agree with Ross what counts commercially |
| T3. Give operators a standing, structured voice into what Kelverton builds and prioritises | An operator can see what happened to what they asked for, including when the answer is no | It slows decisions, not every ask can be built, and it only works if something visibly comes back |

Differentiation. The report came from Kelverton's own strategy team, so both panelists know its shortlist and reciting it scores as homework. Bring one item from the report to show you read it, then one thesis-driven divergence with your reasons, then the anti-pick: one thing you would say no to over the 18 months, because the role includes saying no.
Answer slot: name the report item you will bring and the item you would deprioritise, from the report as you read it. If the report does not support a thesis above, drop that thesis rather than bend the report.

Requested close, as the recruiter named it: finish on what it means for the operators themselves. One sentence per thesis in operator terms: what an operator gets, stops having to do, or can decide that they could not before. Give Ross one commercial consequence per thesis in a single line, so C4 and C1 to C3 do not catch you cold.

Limit to say aloud if pressed: the ISV channel is channel experience, not operator-partnership experience, and the pack's observation is that your material shows the first and not the second.

## 8. Persona table

The recruiter's email establishes one 60-minute session with two named interviewers, so weights rest on it, not on an archetype loop.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The POV and live follow-ups on your plan | High: Deepa is your future manager, the hiring-manager prior, and the POV is a strategy exercise in the recruiter's words | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Probing the rail and operator gap | High: the hiring-manager prior, and your own message states the rail gap | Rehearse B1 until it is boring; bridge only from what you said, and name the limit plainly |
| Data-Driven Prober | "How was that counted" on £4M and 6 to 40 | High: the recruiter says Ross will push on commercials, and your two headline figures are influenced revenue and a partner count | Know what you can and cannot say about each count; name the assumption you would defend least first |
| Pressure | Time-boxed challenges, "how much was you" | Medium: commercial pushing tends to arrive with pace, and you have no direct quota to hide behind | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Opening journey question | Low: likely a short opener, but still scored | A 90-second arc from your own sentences |
| Peer Evaluator | The partnerships and commercial seam | Low: Ross and Deepa's functions sit side by side in the recruiter's description | Offer seam principles, not a pretended seam |
| Values/Behavioral | Scenario probes | Low: no values round is documented in the recruiter's email, and no company values were researched | Use the scaffolds in G1 and G2 |

## 9. Question banks

Total 21 questions. B1 is the highest-ROI prep in the pack: the rail gap is the most predictable objection, and it gets the most follow-up levels.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months?" | CASE | [grounded] | This is the POV in section 5. Open with one position, then your two or three theses, each with its concession, and finish on the operators | The recruiter's email names it as the first 15 minutes; CASE because it is a live plan |
| A2 | "Of everything in the report our strategy team circulated, what would you not do?" | CO | [grounded] | The anti-pick from section 5. Answer slot: name the item you would deprioritise from the report as you read it, and why. If nothing in it merits a no, say so plainly and say what you would sequence last | The report is the one document both panelists share; CO because it tests judgment against it |
| A3 | "An operator tells you the partnership is not delivering for them and wants to step back. What do you need to know first?" | CASE | [generic] | Clarify first: what they expected, what changed, who inside the operator is asking, and what stepping back would cost each side. Then the objective, the options, how you would measure it, and the risk of each. Think aloud, and say your structure before you use it | A live operator-facing problem of the kind a hiring manager sets; `[generic]` because it is a pattern, not a fact about Kelverton |
| A4 | "What does that plan mean for the operators themselves?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The recruiter asked you to land here, so give one sentence per thesis in operator terms. If you draw on your consulting, use it at its scope: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: expect a probe on what in that work informs your operator view. If any of it did, say how, in your own words; if none did, say so plainly and ground the close in what you would ask operators first | F2 is your only operator-side evidence, so this is where it gets used; CASE because the close is a design question |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. Why should we believe you can be credible with operators from day one?" | JD | [grounded] "Never sold into rail specifically", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI rehearsal in this pack. Words: "I've never sold into rail specifically." Then your quoted adjacent work at its scope: "For five years I was in transport consulting, on bus and light rail network planning." Then a ramp plan said as a plan: who you would listen to first and what you would read, with no past claim in it. Follow-up level one: they note bus and light rail is not heavy rail. Concede it in your own words: "My planning work was bus and light rail." Answer slot: if some of that work carries over, say what, in your own words; if little does, say so plainly. Follow-up level two: what you would not know on day one. Name it before they do. Hold by returning to your quoted words, never by adding to them | F4 is the gap and F2 the adjacent evidence; JD because it scores the role's fit, and it arrives in some form in every version of this loop |
| B2 | "Why this move, and why now?" | EXP | [generic] | Give your actual reason, in your own words. The pack supplies none. Keep it to what you can say consistently across both interviewers | The persona's stock motivation probe; `[generic]` because the pack holds no reason from you |
| B3 | "You've run an ISV channel. How is operator partnership different from that?" | JD | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Stay at the channel's scope: "I was running the ISV channel and took it from 6 partners to 40." Answer slot: the recruiter's phrase, operator partnerships, makes this probe likely. If you can say what differs in your own words, do; if you have not worked that out, say so plainly and say what you would ask first | F1 is the evidence and its limit; JD because it tests the transfer from channel to operators |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically", "never carried a direct quota, only influenced revenue" | Choose one, name it plainly and add the plan. Words for either: "I've never sold into rail specifically" or "I've never carried a direct quota." Then how you would close it, said as a plan. Do not name both unless pushed | F3 and F4 hold the two stated gaps; JD because the question is a persona stem aimed at the listed job |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot, four parts, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F3 holds the figure; EXP because probers test the number first |
| C2 | "What counted as a partner when you got to forty?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Answer slot: say what counted, in your own words, and which part of the growth was yours. If the count included partners you did not bring in, say so plainly. Name the assumption in the count you would defend least | F1 holds the figure; EXP because it tests attribution |
| C3 | "Influenced revenue isn't booked revenue. What did you actually carry?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Words: "I've never carried a direct quota, and the £4M was influenced revenue." Answer slot: if there was a way influence was attributed, say what, in your own words; if there was none, say so plainly. Hold the position through two follow-ups by returning to those words | F3 holds the stated limit; EXP because it is where a prober presses a commercial candidate |
| C4 | "How would you size and structure the commercials of an operator partnership?" | CASE | [generic] | Ask what the current commercial structure is before you structure anything. Then the unit of value for the operator and for Kelverton, who pays whom for what, the leading and lagging metrics, and the risk to each side. Think aloud, and tie it back to your theses | The recruiter says Ross will push on commercials; `[generic]` because I could not research Kelverton's model |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40", "Never sold into rail specifically" | Pause, restate, then the position that your quotes carry: "I was running an ISV channel and took it from 6 partners to 40." Concede in the same breath: "I've never sold into rail specifically." Hold through two follow-ups by returning to those words, never by adding to them | F1 and F4 are the position and the limit; JD because it is the same objection as B1 under pressure |
| D2 | "That £4M — how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say which part was yours, in your own words. If you cannot separate it, or none of it was yours alone, say so plainly and say what you can say. Do not move from influenced to owned | F3; EXP because it tests attribution under pace |
| D3 | "You've never carried a quota. Why would we trust you with commercial targets?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Words: "I've never carried a direct quota." Concede it specifically, then what you would do in your first months to be measured on something: a plan, with no past claim in it. Hold through two follow-ups by returning to the same words | F3 holds the stated gap; JD because Ross's commercial push lands here |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | A 90-second arc with the beats your quotes state: five years in transport consulting on bus and light rail network planning, then partnerships, the last four running the ISV channel and taking it from 6 partners to 40. End on your own reason for Kelverton, in your own words; the pack supplies none | F1 and F2 carry the arc; EXP because it is the first thing both interviewers hear |
| E2 | "What in the report stood out to you?" | CO | [grounded] | Answer slot: name one item, in your own words, and what you would do differently from it. If nothing stood out, say so plainly and say which part you would test first. Do not recite its shortlist | The recruiter attached the report, which raises this; `[grounded]` on that, and I have not seen its content |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Partnerships and commercial sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a pretended seam: who owns the operator relationship day to day, who owns the commercial terms, and how a disagreement gets decided and recorded. Ask how it works now before proposing | Ross and Deepa lead those two functions per the recruiter's email; `[generic]` because I could not research the structure |
| F2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: if there was a rule for credit, say what it was, in your own words; if there was none, say so plainly and say what you would propose. Reciprocity: what your side gives the commercial team | F3 holds the influenced-revenue figure that makes this natural; EXP because it tests credit-sharing |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship intact at the end; "we" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; low weight because no values round is documented |
| G2 | "When did you put a partner's interest ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a real cost to the internal number, a reason, and an outcome you can state without improving it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem aimed at partnership work |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, B3, E2, section 5 |
| "what it means for the operators themselves" | A4, section 5 |
| "Ross will push on commercials" | C1, C2, C3, C4, D2, D3, F2 |
| Rail-sector knowledge (role-family) | B1, B4, D1 |

## 11. Reverse questions

No interviewer profile was available, so these are role-generic. Choose three.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What do you want to be different about operator partnerships 18 months from now?" | Tests alignment with your POV and gives Deepa room to say what she really wants |
| R2 | "Which operator relationship would you hold up as what good looks like, and what makes it so?" | Puts a concrete example on the table that your first 90 days can be measured against |
| R3 | "How do you want partnership impact measured commercially, and where does credit sit between partnerships and your team?" | Opens the seam in F1 with Ross on his ground |
| R4 | "What would the first 90 days need to show for you to say this hire is working?" | Converts the quota gap into an agreed measure |
| R5 | "Where do operators say the partnership falls short today?" | Follows the operator close you were asked to land on |
| R6 | "Which part of the report is the team still debating?" | Shows you read it and invites an honest answer |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never sold into rail specifically." No slot |
| Has carried a quota or owned revenue | Negative you stated, F3 | The plain acknowledgment F3 gives: "I've never carried a direct quota." No slot |
| Has run operator partnerships | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the ISV channel, not operator partnerships. B3's slot stays inside the channel |
| Knows how train operating companies run | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning. A4's slot stays inside the planning work |
| Owned £4M of revenue | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says influenced revenue. C1's and D2's slots stay inside that figure |

## 14. Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report you mentioned was not available to me, so nothing in this pack comes from it.

Searches sent, all refused, none returned a result:

- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail strategy scheduling software train operating companies news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager job rail technology software train operating companies": refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have fed a values cheat sheet; none was built, and G1 and G2 are `[generic]` scaffolds |
| 2. Kelverton Rail interview process, partnerships | unavailable | Would have named further rounds; the persona weights rest on the recruiter's email alone |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have grounded A2, A3 and C4 in Kelverton's stated priorities; they are `[generic]` or rest on the recruiter's words |
| 4. Interviewer names with Kelverton Rail | unavailable | Would have built an interviewer read and a tailored reverse question; both are absent |
| 5. Representative posting for the role | unavailable | Would have supplied more JD rows; the fit snapshot rests on the recruiter's words and F4 is `[generic]` |

## 15. Upgrade menu

- The market report's text, or its headline recommendations → the theses in section 5 and A2, E2 and R6 become `[grounded]` on what it says, and the consensus and divergence in your POV can be named
- The posting's text → the fit snapshot's requirements become the posting's own words, and F4 becomes a quoted requirement
- Your CV → evidence cells beyond the sentences you typed to me
- Your answers to the slots in C1, C2, D2 and F2 (how the £4M and the 6 to 40 were counted, and who got the credit) → those rows become story-mapped on your own words
- Interviewer surnames or profile links → an interviewer read and per-person persona weights
- Permission to run web searches → Kelverton's published values, loop and recent strategy, which would lift A3, C4 and F1 off `[generic]`
- A `tuesday-dossier.md` → verified evidence and an evidence-derived objection in place of the one inferred here
