## Decision snapshot

**Yes, this is routine. Bank details, a PPS number and a passport scan are normal to ask for after a written offer that names the role and the pay, and yours did (RR2). Status: `conditional_go`.** Your rule against handing these over still holds for anyone who asks before an offer.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days in Limerick), R2 (Pay €40,000, ad range €38,000–€42,000)
- `must_have` — direct: R3, R5, R6, R8, R10 · adjacent: R7 (Monthly payroll for 240 staff) · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — unclear: R11 (Staff payroll queries) · absent: R9 (Pension changes)

R7 — a credible bridge, its limit named; R9 — not done before, with a closure path; R4 (`low`) — waiting on your answer.

**Opportunity ledger.** The ad and the offer agree and the process looks consistent (RR2). Contract terms are unstated (RR4) and pension-change support is unknown (RR3). The employer is unchecked against its own pages because research did not run (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Limerick), R2 (Pay €40,000 a year); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Marrowgate and the post confirmed on the employer's own website before you give notice (RR1); (2) the €40,000 and the two office days checked against your own terms (R1, R2); (3) the written contract terms seen (RR4); (4) pension-change handover asked about (R9, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick; not checked against its own website (RR1) | `[grounded]` ad and offer email |
| Mandate | Monthly payroll for 240 staff, starters, leavers and pension changes, monthly payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` ad |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Terms stated | Permanent, €40,000, hybrid with two days a week in Limerick, start after your notice period | `[grounded]` offer email |
| Contradictions | None between the ad and the offer on title, working pattern or pay (€40,000 sits inside €38,000–€42,000) | `[grounded]` ad against offer |
| Scope read | Your largest run was 90 staff on a fortnightly cycle; this post is 240 staff monthly, so the step up is in headcount and cycle | `[inferred]` from your background against the ad |
| Market calibration | Not run: the pay-band search was refused, so €40,000 is not set against role-family norms | `[grounded]` no research ran |
| Unknowns | Probation, notice, holiday and pension terms; who handles pension changes now; first-year outcomes | `[grounded]` absent from the ad and offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The terms are clear. You have not told me your own constraints, so nothing grades yet | `[grounded]` ad and offer; no constraint stated | G3 |
| R2 | Pay €40,000 a year (ad range €38,000–€42,000) | hard_gate | unclear | none | hard_gate | Same as R1: the figure is stated, your floor is not | `[grounded]` offer; no constraint stated | G3 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll, confirmed and specific, with no inspectable artifact yet | `[grounded]` your message | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You ran payroll and hold a payroll certificate, but your message doesn't say whether it ran under Irish PAYE, PRSI and USC | `[grounded]` your message is silent on this | G1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, confirmed and specific, nothing to inspect | `[grounded]` your message | none |
| R6 | Payroll qualification, or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, stated but not inspected. A copy would raise it to `high` | `[grounded]` your message | none |
| R7 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Bridge: you ran fortnightly payroll for 90 staff. Limit: neither a monthly cycle nor 240 staff has been exercised | `[grounded]` your message and the ad | Describe it as 90 staff, fortnightly, never as 240 monthly |
| R8 | Process starters and leavers | must_have | direct | medium | none | Starters and leavers at the hotel group, confirmed and specific | `[grounded]` your message | none |
| R9 | Process pension changes | important | absent | none | capability | You confirmed you have not done them; your manager handled them. A handover is a usable closure path | `[grounded]` your statement; `[inferred]` that a handover closes it | Ask about handover (RR3) |
| R10 | Reconcile payroll to the general ledger monthly | must_have | direct | medium | none | The monthly payroll-to-ledger reconciliation at the hotel group, confirmed and specific | `[grounded]` your message | none |
| R11 | Answer staff payroll queries | important | unclear | low | discovery | Your message doesn't mention handling queries. Payroll posts commonly include them | `[grounded]` your message is silent; `[generic]` role-family pattern | G4, not asked this turn |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R4, must_have) | discovery | Payroll experience and a certificate, but no statement of jurisdiction | A `must_have` row at `unclear`; one answer closes it | Applying PRSI classes to starters; USC and tax-credit set-up per employee; submitting pay runs to Revenue | A redacted payslip or pay-run summary showing PAYE, PRSI and USC lines | `[grounded]` your message is silent; `[generic]` that these are the usual evidence in Irish payroll |
| G2 | Pension changes (R9, important) | capability | Confirmed not done; your manager handled them | The ad lists them as a duty from the start | No evidence claimed; closure is a handover or training | Their answer to the RR3 question | `[grounded]` your statement; `[inferred]` closure path |
| G3 | Terms you can accept (R1, R2, hard_gate) | hard_gate | The terms are known and your limits are not | The two gates stay unconfirmed until you say | Your pay floor, office days you can do, earliest start | Your own statement | `[grounded]` no constraints given |
| G4 | Staff payroll queries (R11, important) | discovery | Silent in your message | Lower impact than G1 or G3, so not asked this turn | Answering payslip or tax queries from staff at the hotel group | A sanitised query log or example | `[grounded]` your message is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | Research did not run, so nothing here checks the employer against its own pages. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for employers of this kind, not a claim about this one | Can you point me to this post on your own careers page? | unresolved |
| RR2 | Written offer after two in-person interviews, consistent with the ad | positive_signal | — | "we are delighted to offer you the permanent post of Payroll Administrator at €40,000 a year" | The email names the role, pay, manager and working pattern, and they match the ad | `[grounded]` ad and offer as you pasted them | What would a good first 90 days look like in this post? | noted |
| RR3 | Pension-change support unknown | unknown | — | "process starters, leavers and pension changes" | The post may expect pension changes from the start with no one lined up to show you | `[inferred]` from the ad's duty list against your statement that you haven't done them | Who handles pension changes at the moment, and will there be a handover or training in my first month? | unresolved |
| RR4 | Contract terms not in the offer | unknown | — | "starting on a date we agree once your notice period ends" | The email gives title, pay, manager and pattern but not probation, notice, holiday or pension terms; a contract may follow it | `[generic]` offer emails are often a summary ahead of a contract | Will the written contract, with probation, notice, holiday and pension terms, reach me before the five working days are up? | unresolved |

RR1 does not put the onboarding request in doubt. Asking for bank details, PPS number and passport after a written offer is routine, and I've given it no register entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter your bank details, PPS number and passport scan only in Marrowgate's own onboarding portal, at the address the company's own website gives. If the link in an email doesn't match, ring the People Team on a number from its website | Routine onboarding, with one habit worth keeping | `[generic]` standard onboarding practice | pending your approval |
| A2 | Before giving notice to your current employer, check on Marrowgate's own website that the company and this post exist as described, and that its web domain matches the one in the offer email | See RR1 | `[inferred]` from RR1 | pending your approval |
| A3 | Ask for the written contract and terms before the five working days run out; if they won't arrive in time, ask for more time to accept | See RR4 | `[grounded]` the offer sets a five-working-day window | pending your approval |
| A4 | Ask the RR3 question about pension handover. If you speak to them about it, use only what you told me: you have not run pension changes yourself, and your manager handled them | See R9, RR3 | `[grounded]` your own statement | pending your approval |
| A5 | Describe your scale accurately: 90 staff, fortnightly | See R7 | `[grounded]` your message | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused, so the employer and the live post are unchecked. They would have fed RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | One search was refused. It would have fed market calibration and a pay check of €40,000 against the band (R2) |
| 3. Hiring manager's public footprint | unavailable | The Finance Manager was named, so a search was sent and refused. It would have fed role reality's scope read and the plan's positioning |

If you want this saved as a record, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your pay floor, office days and earliest start → R1 and R2 settle, and the hard-gates line loses its flag.
- Your answer to G1, or a redacted payslip or pay-run summary → R4 closes.
- A copy of your Payroll Technician certificate → R6 rises to `high`.
- The written contract and job description → RR4 closes.
- Permission to run web search → RR1, market calibration against the €38,000–€42,000 band, and the hiring manager's professional footprint. The four calls this time were refused.

**Questions**

G1 — Was the hotel group's payroll run under Irish PAYE, PRSI and USC, and which parts did you apply yourself?

G3 — Are €40,000, two office days a week in Limerick and a start after your notice period all within what you need, or is any of them a term you'd want changed before you accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.