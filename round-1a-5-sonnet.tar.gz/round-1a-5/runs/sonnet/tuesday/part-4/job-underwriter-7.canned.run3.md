I'm working through the job-underwriter playbook's reference files so the assessment follows its format. Next I'll read the research rules, then check the employer and the pay band.
Aoife, I read the posting against your CV and checked the employer and the pay band.

## Decision snapshot

**Yes, it's worth applying. R1 and R2 (the hard gates) are met as you've stated them, and R3 meets the stated experience. Status: `go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R6, R7, R9 · adjacent: R5 (Wound and leg-ulcer care), R10 (Small caseload of your own) · unclear: R8 (End-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R5: wound care is evidenced, leg-ulcer work isn't; R10: your discharge-to-assess visits are the bridge, with their limit named; R8: the CV is silent, and a recall question may close it.

**Opportunity ledger.** The role looks sound. The employer is attributable (RR1), the pay is stated and sits inside the surveyed range (RR2), and support is built in. Whether the vacancy is live is unconfirmed (RR3), and hours (RR4) and caseload size (RR5) are unstated.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a registration or licence that doesn't match what you've told me, the post turning out not to be live (RR3), or hours that clash with a constraint you haven't told me about (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company providing adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` company About page, fetched |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Structure | A small caseload of your own, supported by a senior community nurse; pool cars provided | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England (n=1,240) gives median basic pay £34,300 and an interquartile range of £32,400–£36,600. The posting's range spans that whole interquartile range. This is a market band, not this employer's offer for you | `[generic]` Wardround 2026 pay guide; `[grounded]` JD for the posted range |
| Scope read | An ordinary Band 5 community post; nothing in the wording suggests bundled or senior duties | `[inferred]` from the duty list against the grade |
| Team lead's footprint | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page. Reading: the Doppler gap may be trainable here (`[inferred]`) |
| Unknowns | Shift pattern and weekend rota; starting caseload size; induction and competency sign-off; whether the vacancy is live on the careers page | — |
| Contradictions | None between the JD and the About page. The careers address I tried returned no page, so I could not compare the live listing | `[grounded]` fetches |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Adult registration, active, revalidation due March 2028. Stated, not checked | `[grounded]` CV | You check your own NMC register entry (status and conditions) |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK category B licence. Stated, not checked | `[grounded]` CV | You check your licence record (status, endorsements) |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, per CV. The posting treats it as a requirement, not a legal bar | `[grounded]` CV | none |
| R4 | Clear, timely written records (on an electronic patient record) | must_have | unclear | none | discovery | The CV says nothing about documentation or electronic systems. Ward and discharge-team work almost certainly involved records, but that is not evidence | `[grounded]` CV silence; `[inferred]` that ward work involves records | Add one specific line on records/EPR systems you used, if true |
| R5 | Wound and leg-ulcer care | important | adjacent | medium | transferability | Wound care incl. pressure ulcers and surgical wounds is stated. Leg-ulcer care and compression are not mentioned. Limit: no evidence of venous or arterial ulcer management | `[grounded]` CV | G1 |
| R6 | Catheter and continence care | important | direct | medium | none | Catheter care is stated. Continence care is not named separately, so the claim is read as the catheter half | `[grounded]` CV | none |
| R7 | Insulin administration | important | direct | medium | none | Stated on the CV. Care planning, named alongside it in the posting, is not evidenced | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | none | discovery | The CV is silent. Acute medical wards often involve end-of-life care, but nothing here says you did | `[grounded]` CV silence; `[generic]` about acute medical wards | G2 |
| R9 | Caring for housebound adults in their own homes | important | direct | medium | none | 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge | `[grounded]` CV | none |
| R10 | A small caseload of your own, supported by a senior community nurse | important | adjacent | low | transferability | You say you've never held your own caseload. The discharge-to-assess visits are adjacent home practice. Limit: you haven't owned ongoing planning for a set of patients. The posting's built-in senior support narrows this | `[grounded]` your statement and JD | G3 |
| R11 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | Never done, per you. Desirable only, and the team lead has spoken on Doppler training for newcomers | `[grounded]` your statement; `[inferred]` trainability | Say plainly you haven't, and that you'd train |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5, important) | transferability | Wound care is stated, but nothing on venous leg ulcers or compression | Leg-ulcer care is named in the advert, and the desirable Doppler skill builds on it | Applying or changing compression bandaging; ward wound-care link-nurse duties; tissue viability sessions or study days | A training certificate, competency record or study-day record | `[grounded]` CV silence; `[generic]` that leg ulcers are a core community workload |
| G2 | End-of-life care (R8, important) | discovery | The CV is silent on end-of-life care | It is a named duty, and which way this goes affects how you present | Caring for dying patients on the ward; syringe-driver use; anticipatory medication; last-days care planning; supporting families; fast-track discharges home to die | A competency record or training certificate | `[grounded]` CV silence |
| G3 | Autonomy in your discharge-to-assess visits (R10, important) | transferability | The CV says you visited patients at home but not how much you decided alone | It is the nearest evidence for a caseload, and the posting's key new responsibility | Deciding visit frequency; escalating to GPs; adjusting care packages; reviewing patients without a senior present | A short note on your role in the secondment, or a reference from its lead | `[grounded]` CV and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer is attributable | positive_signal | — | "running adult community nursing, therapy and rehabilitation services across Calderdale under an NHS contract" | The employer exists as the posting describes | `[grounded]` About page | Who would be my senior community nurse, and how often would we make shared visits at the start? | noted |
| RR2 | Pay stated and in range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent pay inside the surveyed interquartile range | `[grounded]` JD; `[generic]` survey band | Where would my starting point sit in the range, given five years' post-registration experience? | noted |
| RR3 | Vacancy not confirmed live | unknown | — | "Current vacancies are listed on our careers page." | The address I tried returned nothing, so the listing could be elsewhere or closed | `[inferred]` from the failed fetch | What is the closing date, and where is the post listed? | unresolved |
| RR4 | Hours and weekend cover unstated | unknown | — | "end-of-life visits" | Community nursing rotas commonly include weekend cover, and the posting says nothing | `[generic]` role-family pattern, not a claim about this employer | What is the shift pattern, and what are the weekend and bank-holiday expectations? | unresolved |
| RR5 | Caseload size and induction unstated | unknown | — | "You will hold a small caseload of your own" | "Small" is undefined, so I can't tell how quickly you'd be expected to carry patients alone | `[inferred]` from the JD's wording | How many patients is a typical starting caseload, and what induction and competency sign-off is provided? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your own NMC register entry and licence record before applying | see R1, R2 | `[grounded]` rows | your call |
| A2 | Take up the informal chat with Rhiannon Mabbott and use the questions from RR1–RR5 | The posting invites it, and the register doubles as your question list | `[grounded]` JD | pending your approval |
| E1 | Lead the CV and statement with the 18-month discharge-to-assess secondment as home-based practice, and say plainly it was not your own caseload | see R9, R10 | `[grounded]` CV and your statement | pending your approval |
| E2 | State that you haven't done Doppler assessment, and that you'd welcome training. Don't imply any leg-ulcer skill beyond what you confirm in G1 | see R5, R11 | `[grounded]` rows | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment and I haven't used it.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and a role search naming the company. Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about) and tried calderbrookhealth.example/careers, which returned no page. Moved role reality's organization row and RR1 and RR3 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary 2026 Agenda for Change pay scale", returning "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched the team lead's name with her title and company, returning "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the team-lead row and the Doppler reading in R11 and E2 |

## Next steps

Want a `tuesday-dossier.md` saved from this assessment? I can emit it whenever you say.

**Upgrade menu**
- Your answers on constraints (pay floor, hours, no-weekend or no-nights limits) would let me check the role's terms against them. At the moment those checks are unknown.
- A compression, leg-ulcer or wound-care training certificate or study-day record would lift R5 to `high`.
- An end-of-life training or competency record would settle R8.
- A short reference or note from your discharge-to-assess lead on how independently you worked would strengthen R10.
- A sentence naming the record systems you've used would close R4.
- Deeper employer diligence (inspection reports, staff-turnover signals) would cost up to 5 more searches and 2 more fetches. I'll run it only if you say yes.

**Questions**
- G1: Have you applied or changed compression bandaging, or done any leg-ulcer training or study days, and what was your part in it?
- G2: Have you cared for patients in their last days of life, for example with syringe drivers, anticipatory medicines, or arranging a fast-track discharge home, and what did you do yourself?
- G3: In your discharge-to-assess visits, what did you decide on your own, such as visit frequency, escalation or care-package changes, and what went to a senior?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.