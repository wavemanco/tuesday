I'm checking whether Marrowgate Housing is a real, matching employer and what Irish payroll roles usually pay. I'll then write up the assessment.
## Decision snapshot

**Yes, that's normal. After a written offer, an employer asking for bank details, a PPS number and a passport check is routine onboarding, and the offer says they come after you accept (see A1). Taking the job is `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days a week in the Limerick office), R2 (Salary €38,000–€42,000)
- `must_have` — direct: R3, R5, R6 · adjacent: R7 (Run the monthly payroll for 240 staff) · unclear: R4 (Working knowledge of Irish PAYE, PRSI and USC)
- `important` — direct: R8, R9 · unclear: R11 (Answer staff payroll queries) · absent: R10 (Process pension changes)

R7 — a credible bridge, its limit named; R10 — not done before, on your own account; R4 — waiting on your answer.

**Opportunity ledger.** The terms offered match the ad (RR1). The email says nothing about contract terms beyond title, pay and location (RR2). The employer itself couldn't be checked from here (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in the Limerick office), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 sit within your own limits; (2) R4 confirmed as Irish PAYE, PRSI and USC work you did yourself; (3) a handover for pension changes is agreed (R10, A3); (4) you've seen the full contract before you sign (RR2, A2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` the ad's header; not checked outside what you sent |
| Mandate | Monthly payroll for 240 staff, starters, leavers and pension changes, monthly payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` the ad |
| Offer terms | Permanent, €40,000, hybrid with two days a week in Limerick, reporting to Declan Garvagh, Finance Manager, reply within five working days | `[grounded]` the offer email |
| Ad against offer | Title, pay (inside the stated band), location and hybrid pattern all agree | `[grounded]` ad and offer compared |
| Scope read | A step up from your 90 staff on a fortnightly cycle, with one duty (pension changes) you haven't done yourself | `[inferred]` from your background against the ad's headcount and duty list |
| Market calibration | Not done. The searches were refused, so there is no band to set €40,000 against | `[grounded]` search calls refused |
| Unknowns | Probation, hours, pension scheme, notice terms, who handles pension changes today, start date (agreed after your notice) | `[grounded]` the email is silent on these |
| Contradictions | None between the ad and the offer | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You haven't stated a limit on office days or location. Two in-person interviews at their office show you can get there, but that isn't a stated constraint | `[grounded]` your message, no constraint given | Question G1 |
| R2 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | The offer sits inside the ad's band. Whether it meets your own floor isn't known | `[grounded]` ad and offer; no floor given | Question G1 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | 3 years running fortnightly payroll for 90 staff at a hotel group. Self-reported, nothing inspected yet, so `medium` | `[grounded]` your background as typed | offer: a sanitized payroll-run summary or a reference would raise to high |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say which tax rules the hotel payroll ran under or what you applied yourself | `[inferred]` from silence in your background | Question G2 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated and specific, nothing inspected | `[grounded]` your background as typed | none |
| R6 | A payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself is the inspectable artifact and hasn't been seen | `[grounded]` your background as typed | the certificate would raise to high |
| R7 | Run the monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran payroll end to end. Limit: a fortnightly cycle for 90 staff exercised neither a monthly cycle nor more than twice the headcount | `[grounded]` your background; `[inferred]` that the cycle and scale are the differences | See G3 |
| R8 | Reconcile payroll to the general ledger each month | important | direct | medium | none | You did the monthly payroll-to-ledger reconciliation. Self-reported | `[grounded]` your background as typed | a sanitized reconciliation workbook would raise to high |
| R9 | Process starters and leavers | important | direct | medium | none | Starters and leavers stated as part of your hotel-group role | `[grounded]` your background as typed | none |
| R10 | Process pension changes | important | absent | none | capability | You said you've never done these yourself; your manager did | `[grounded]` your message | Closure path in G4 |
| R11 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention staff queries either way | `[grounded]` silence in your background | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Your own limits on office days and pay (R1, R2, hard_gate) | hard_gate | The offer's terms are known but your limits aren't | A gate that fails can't be fixed by wording, so it comes before accepting | Any limit on commute, days in the office, pay floor or notice period | None needed; your word is the evidence | `[grounded]` no constraints given |
| G2 | Irish PAYE, PRSI and USC (R4, must_have) | discovery | Hotel-group payroll is described without naming the tax rules | A must-have currently resting on silence | Applying tax credits and cut-offs, PRSI classes, USC rates, Revenue filings you ran or checked | Payslip layout with figures removed, a Revenue-filing checklist | `[grounded]` background silent; `[inferred]` that this is likely closable |
| G3 | Monthly cycle and 240-staff scale (R7, must_have) | transferability | You ran payroll end to end at 90 staff | The bridge holds, with its limit named | Any monthly runs, year-end work, or a larger or multi-site run | A process note or checklist, sanitized | `[inferred]` bridge from your account |
| G4 | Pension changes (R10, important) | capability | No own work in your account | Part of the job from day one | Nothing is stated; if you prepared pension data for your manager, say so | n/a | `[grounded]` your message |
| G5 | Staff payroll queries (R11, important) | discovery | Not mentioned | Part of the daily role | Payslip queries, tax-credit questions, leaver payments | A sanitized query log or process note | `[grounded]` background silent |

G4's closure path is to ask who handles pension changes now, to request a handover in your first weeks, and to ask what training the employer offers (A3).

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer matches the ad | positive_signal | — | "€40,000 a year ... hybrid with two days a week in our Limerick office" | The offered terms are consistent with the posting | `[grounded]` ad and offer compared | Can you send the contract with these same terms, so I can compare line by line? | noted |
| RR2 | Contract terms beyond title, pay and location not stated | unknown | — | "starting on a date we agree once your notice period ends" | Probation, hours, pension scheme, holiday and notice terms may sit in a contract not yet seen | `[inferred]` from the email's silence on them | Can I see the full contract, including probation, hours, pension scheme and notice terms, before I accept? | unresolved |
| RR3 | Employer not checked from here | unknown | — | "Marrowgate Housing, a housing association in Limerick" | The searches were refused, so nothing was established either way. This entry holds the gap open and doubts nothing; you hold two in-person interviews and an offer from a marrowgatehousing.ie address, as you report | `[grounded]` searches refused | Can you point me to this role on your careers page and tell me the address the onboarding portal will be on? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept first, as the email sequences it, then enter bank details, PPS number and passport scan only in the employer's own onboarding portal, at an address its own website gives or the People Team confirms through contact details found on that website. Bring the original passport on day one, as the email asks | Payroll and identity details after a written offer are ordinary onboarding. Your "never hand them over" instinct is right for requests before any offer | `[grounded]` the email's order and purposes; `[generic]` onboarding pattern | pending your approval |
| A2 | Ask for the full contract before you reply, then reply within the five working days | See RR2; the email sets the deadline | `[grounded]` the email, RR2 | pending your approval |
| A3 | Ask Declan Garvagh who handles pension changes now and what handover or training you'd get | See R10, G4 | `[grounded]` R10 row | pending your approval |
| A4 | Please don't paste your PPS number, passport details or bank details here. This assessment doesn't need them | Nothing in the analysis reads them | `[grounded]` the evidence map holds none | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have moved role reality's organization and contradictions rows and RR3 |
| 2. Role-family sweep | unavailable | The search was refused. It would have given a market band for the calibration line and a check of €40,000 against it |
| 3. Hiring manager's public footprint | unavailable | The search was refused. It would have moved the scope read and A3's positioning |

I'm happy to save this as a `tuesday-dossier.md` if you'd like a record to keep.

## Upgrade menu

- Your own limits on pay, office days and notice → R1 and R2 settle, and the status can move to `go` if R4 also closes.
- Which tax rules your hotel payroll ran under → R4 settles.
- The Payroll Technician certificate, or a sanitized reconciliation workbook or payroll-run summary → R6 or R8 and R3 can rise to `high`.
- The contract → RR2 closes.
- Allowing the refused searches (company check, role-family pay band, Declan Garvagh's public professional footprint) → RR3 resolves, the calibration line gets a band, and the plan gets a positioning read.

**Questions**

G1 — Are two days a week in the Limerick office and €40,000 within your own limits, and is there a pay, office-day or notice-period limit of yours that this offer doesn't meet?

G2 — Was your hotel-group payroll run under Irish PAYE, PRSI and USC, and which of those did you apply or check yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.