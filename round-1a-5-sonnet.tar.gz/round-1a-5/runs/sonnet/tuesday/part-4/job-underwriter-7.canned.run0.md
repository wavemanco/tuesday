Running the three L1 research targets now: the employer and its careers page, a band check for this role, and the team lead's public profile.
**Yes, this is worth applying for, on one condition: R4, written records. Status: `conditional_go`.**

You're already registered, licensed to drive and past the one-year mark. Five of the other requirements are open, and none of them is a gate.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R7, R9 · adjacent: R6 (Catheter and continence care), R10 (Own small caseload) · unclear: R5b (Leg-ulcer care), R8 (End-of-life visits)
- `preferred` — absent: R11 (Doppler assessment)

R4 — the CV is silent, and one answer settles it; R10 — a bridge with its limit named; R11 — absent, but only preferred.

**Opportunity ledger.** Pay is stated and sits inside the survey band (RR2). The team lead is publicly linked to Doppler training for staff new to community work (RR3). The support behind the caseload is promised but not detailed (RR1). I couldn't see the live posting on the careers page (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** the CV or your answer to G1 shows that you keep clear, timely records (R4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` its About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Support | A small own caseload, supported by a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Band 5 community staff nurse pay in England has a median basic of £34,300 and an interquartile range of £32,400–£36,600. The advert's range spans that. This is a survey pattern, not this employer's offer | `[generic]` Wardround 2026 survey (n=1,240); `[grounded]` advert for the range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. She has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` Community Nursing Forum speaker page |
| Scope read | A standard entry-level community post. The advert asks for one year of experience and lists Doppler as desirable, so the employer appears to expect some skills to be learned on the job | `[inferred]` from the essential/desirable split |
| Unknowns | Shift pattern and weekend work; permanent or fixed-term; training and preceptorship for community work; whether the care-planning duty is something your CV covers | — |
| Contradictions | None found between the advert and the About page. The careers page was not seen | `[grounded]` About page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states active registration, adult field, revalidation due March 2028. This is stated, not checked: only you can confirm it on the NMC register | `[grounded]` CV | You check your own entry on the NMC register |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | Your CV states a full UK licence, category B. This is stated, not checked: your DVLA driving record is the place to confirm status | `[grounded]` CV | You check your DVLA record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. The specifics are stated and not independently inspectable | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV says nothing about records or electronic systems. Ward work implies some record-keeping, but I won't assert it as your claim. The advert's electronic patient record makes this a real requirement | `[grounded]` CV silence; `[inferred]` that ward work involved records | G1 |
| R5a | Wound care | important | direct | medium | none | The CV states pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | Leg ulcers are not mentioned. Pressure-ulcer work is nearby context, not the same condition | `[grounded]` CV silence | G3 |
| R6 | Catheter and continence care | important | adjacent | medium | discovery | Catheter care is stated. Continence care is not mentioned, so the claim is only partly covered | `[grounded]` CV | none, fold into G1 if you wish |
| R7 | Insulin administration | important | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | low | discovery | The CV does not mention end-of-life care. An acute medical ward may have involved it, but that is a lead, not your claim | `[grounded]` CV silence; `[generic]` that acute medical wards often care for dying patients | G2 |
| R9 | Visiting patients in their own homes | important | direct | medium | none | Eighteen months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge | `[grounded]` CV | E1 |
| R10 | A small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You've never held a caseload. The adjacent work is first-week post-discharge visits. Its limit is that it was not ongoing care of the same patients. The advert says the post is supported | `[grounded]` your statement and CV; `[grounded]` advert for the support | G4 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've never done one. It is desirable, not essential | `[grounded]` your statement | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | No mention of records or electronic systems anywhere on the CV | R4 is the one `must_have` row not yet `direct`, and resolving it moves the status towards `go` | Documenting on an electronic patient record; writing discharge or handover notes; record audits | A line on your CV, or a description of the system you used | `[grounded]` CV silence; `[inferred]` that resolving it moves the status |
| G2 | End-of-life care (R8, important) | discovery | The CV does not say whether you cared for dying patients | The advert lists end-of-life visits as a core duty | Caring for patients on an end-of-life pathway; supporting families; anticipatory medicines or symptom control | A training record or a reflective note | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5b, important) | discovery | Pressure ulcers and surgical wounds are stated; leg ulcers are not | Leg ulcers are named in the advert, and the team lead is publicly tied to leg-ulcer work | Compression bandaging; leg-ulcer assessment or dressings; a tissue viability link role | A competency record or training certificate | `[grounded]` CV and speaker page |
| G4 | Own caseload (R10, important) | transferability | First-week home visits after discharge, but no continuing caseload | A supported caseload is the heart of the job | The adjacent work is real home visiting. The limit is no continuity of care. The strengthener is saying so plainly and asking about the support | none needed | `[grounded]` CV; `[grounded]` advert |
| G5 | Doppler (R11, preferred) | capability | No Doppler experience | Desirable only | A route to closing it is training after joining. The team lead is publicly tied to training for staff new to community work | none needed | `[grounded]` your statement; `[grounded]` speaker page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Support for a first caseload is promised but not detailed | unknown | — | "supported by a senior community nurse" | The support could be anything from shadowing to daily review | `[inferred]` from the advert naming support without its form | What does support look like in the first three months, and when would I carry my own caseload? | unresolved |
| RR2 | Stated pay sits inside the survey band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is transparent and consistent with the survey spread | `[grounded]` advert; `[generic]` band from the survey | Where in the range does a nurse with my experience start? | noted |
| RR3 | The team lead's public record includes training for staff new to community work | positive_signal | — | "Doppler training for staff new to community work" | The team may have a route for newcomers to build skills | `[grounded]` speaker page | What training would I get on Doppler and leg-ulcer care? | noted |
| RR4 | Posting not seen on the careers page | unknown | — | "Current vacancies are listed on our careers page" | The posting may have closed or may be filed elsewhere; the employer itself is attributable | `[grounded]` About page; `[inferred]` that the advert may be stale | Is this post still open, and what is the closing date? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the secondment to the top of the experience section, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | R9 | `[grounded]` CV | pending your approval |
| E2 | Add one line on records only once you've answered G1; I won't draft it before then | R4 | `[grounded]` row R4 | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott. Ask the RR1, RR2, RR3 and RR4 questions verbatim | The advert invites it; the register doubles as interview preparation | `[grounded]` advert | pending your approval |
| A2 | In the chat or the application, say plainly that you haven't held your own caseload or done Doppler assessment, and ask what training there is | R10, R11; it matches your own statement | `[grounded]` your statement | pending your approval |

If you decide to apply, resume-tailor can turn E1 and E2 into a tailored CV.

## Evidence status

Verified: none yet.

A National Insurance number was pasted. It isn't needed for this assessment, and I haven't used or repeated it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). It established the employer in role reality. The fetch repeated the search snippet and added nothing new. The careers page itself wasn't fetched, so RR4 stays open |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the Community Nursing Forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the role-reality contact row, RR3 and the plan's positioning |

## Upgrade menu

- A line from you on records and electronic systems → R4 closes, and the status likely moves to `go`.
- Answers on end-of-life and leg-ulcer work → R8 and R5b firm up.
- The link to the live posting or the careers page → RR4 closes.
- Your pay floor, preferred hours and any other non-negotiables → the hard-gates line can check them against the role.
- A deeper research pass on Calderbrook (public staff or candidate reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can save this as a `tuesday-dossier.md` if you want it for later steps.

G1 — Have you written patient records on an electronic system, and how did you keep them clear and timely? Say what the system was, if you remember.
G2 — Have you cared for patients at the end of life, and what was your part in it?
G3 — Have you done any leg-ulcer work, such as compression bandaging or assessment, or only pressure ulcers and surgical wounds?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.