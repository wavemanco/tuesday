## Decision snapshot

**Duinvaart Cold Chain (Operations Analyst): yes, worth your time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days in Rotterdam office)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5 · adjacent: R6 (Work with depot managers on route changes), R7 (Temperature compliance tracking)
- `preferred` — direct: R8

R7 (`low`) — a bridge from on-time to temperature data, its limit named; R6 (`medium`) — a review-to-route-change link, unconfirmed.

**Opportunity ledger.** Unverified but not worrying: the employer could not be checked from here (RR1) and pay is not stated (RR2). The duties are specific and match your tools (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Duinvaart's own careers page (RR1); (2) three days a week in Rotterdam works for you (R1); (3) temperature compliance is framed as adjacent to your on-time work, never as cold-chain experience (R7).

**Kroonhaven Foods (Supply Planner): no, not as written. Status: `no_go`.** R10 (3+ years of FMCG planning) and R12 (a planning system), both `must_have`, are `absent`, and R13 (fluent Dutch) falls short.

**Fit ledger.**

- `hard_gate` — unclear: R9 (On-site in Utrecht)
- `must_have` — adjacent: R13 (Fluent Dutch) · unclear: R11 (Advanced Excel) · absent: R10 (3+ years planning in FMCG), R12 (SAP IBP or similar)
- `important` — adjacent: R15 (Run weekly S&OP meeting) · absent: R14 (Own the 13-week supply plan)

R15 (`medium`) — a review-meeting bridge, its limit named; R10, R12, R14 — nothing adjacent found.

**Opportunity ledger.** The scope is clearly defined (RR6). The employer could not be checked from here (RR4) and pay is not stated (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** documented planning work in FMCG (R10), hands-on use of a planning system (R12), and Dutch assessed at fluent (R13).

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| Duinvaart | Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Duinvaart | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Duinvaart | Scope read | An analyst remit with two metrics and depot-facing work; no team, budget or decision rights stated | `[inferred]` from the JD's silence on authority |
| Duinvaart | Market calibration | Not established: research was unavailable, and the JD states no pay | `[grounded]` JD silent on pay |
| Duinvaart | Unknowns | Pay; reporting line; whether depot managers or the analyst decide route changes | — |
| Kroonhaven | Mandate | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Kroonhaven | Working pattern | On-site in Utrecht | `[grounded]` JD |
| Kroonhaven | Scope read | An ownership role: the plan and the meeting are the planner's own, not support work | `[inferred]` from "own" and "run" in the JD |
| Kroonhaven | Market calibration | Not established: research was unavailable, and the JD states no pay | `[grounded]` JD silent on pay |
| Kroonhaven | Unknowns | Pay; team size; which planning system is in use beyond "SAP IBP or a similar planning system" | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Duinvaart: hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You have not stated where you live or what commute you accept, so there is no constraint to grade and the gate is not established | `[grounded]` your message silent on location | Location question below |
| R2 | Duinvaart: 2+ years in logistics or operations analysis | must_have | direct | medium | none | You describe 4 years as an operations analyst at a parcel carrier. It is self-reported, with nothing inspectable yet | `[grounded]` your message | A sanitized dashboard screenshot would raise R2–R5 |
| R3 | Duinvaart: strong SQL | must_have | direct | medium | none | You use SQL daily. "Strong" is the posting's word, and you have not described depth | `[grounded]` your message | A sample query would raise to high |
| R4 | Duinvaart: Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use | `[grounded]` your message | Dashboard screenshot |
| R5 | Duinvaart: track on-time delivery | important | direct | medium | none | The dashboard you built measures on-time delivery | `[grounded]` your message | none |
| R6 | Duinvaart: work with depot managers on route changes | important | adjacent | medium | discovery | Depot managers use your dashboard and you ran the weekly route-performance review. Nothing says a route change came out of it or who decided | `[grounded]` your message; the route-change link is not stated | G1 |
| R7 | Duinvaart: temperature compliance across a refrigerated fleet | important | adjacent | low | transferability | Compliance-style delivery tracking is the credible bridge. No temperature or cold-chain data is stated, so the lower band applies | `[inferred]` from on-time tracking | G2 |
| R8 | Duinvaart: Dutch a plus | preferred | direct | medium | none | Conversational Dutch, which you stated. The posting sets no level, and fluency is not claimed | `[grounded]` your message | none |
| R9 | Kroonhaven: on-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or commute constraint stated, so the gate is not established | `[grounded]` your message silent on location | Location question below |
| R10 | Kroonhaven: 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, and your carrier work is not FMCG | `[grounded]` your message | G5 |
| R11 | Kroonhaven: advanced Excel | must_have | unclear | none | discovery | Excel is not mentioned in your background | `[grounded]` your message silent on Excel | G3 |
| R12 | Kroonhaven: SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analysis tools, not planning systems; no planning-system use is stated | `[grounded]` your message | G5 |
| R13 | Kroonhaven: fluent Dutch | must_have | adjacent | medium | transferability | Your Dutch is conversational, below the posting's "fluent". The limit is stated, not softened | `[grounded]` your message | G4 |
| R14 | Kroonhaven: own the 13-week supply plan, balancing capacity against forecast | important | absent | none | capability | No planning ownership stated | `[grounded]` your message | G5 |
| R15 | Kroonhaven: run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: a review looks back at performance, while S&OP sets a forward plan across functions, and you have no S&OP experience | `[grounded]` your message; `[generic]` on what S&OP involves | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Route changes with depot managers (R6, important) | discovery | Depot managers use your dashboard and you ran the weekly review; no route change or decision owner is stated | The posting names route changes as shared work with depot managers | A review that led to a re-sequenced route, a changed depot schedule, or a recommendation a depot manager acted on | A review pack, a before/after on-time chart, a sanitized note | `[grounded]` your message |
| G2 | Temperature compliance data (R7, important) | transferability | On-time tracking only; no temperature data | It is the posting's second headline metric, so the bridge and its limit are what an interviewer will test | SLA-breach or exception reporting, alert thresholds you set, or monitoring of time-critical or food or pharma parcels | A sanitized exception report or breach-count dashboard | `[inferred]` bridge from on-time tracking; `[grounded]` your message silent on temperature |
| G3 | Advanced Excel (R11, must_have) | discovery | Not mentioned | Matters only if Kroonhaven stays in play, since R10 and R12 decide it first | Models, pivots, forecasting sheets you built | A sanitized workbook | `[grounded]` your message silent on Excel |
| G4 | Dutch level (R13, must_have) | transferability | Conversational Dutch stated; fluency not claimed | The posting says fluent | Meetings or written work in Dutch | An assessed level or certificate | `[grounded]` your message |
| G5 | Planning experience and system (R10, R12, R14; must_have and important) | capability | You have never worked in planning | These are the core of the role; carry as a material risk. A realistic path is a planning-adjacent target role or a planning-system course, not this posting | — | — | `[grounded]` your message; `[generic]` that planning-adjacent analyst roles exist as a route in |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart not verified | unknown | — | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The posting could not be checked against an official page because research was unavailable | `[grounded]` search refused; no claim about the employer | Can you confirm this role is open and who the analyst reports to? | unresolved |
| RR2 | Duinvaart pay not stated | unknown | — | (the posting states no pay) | Pay may or may not meet your needs; there is nothing to compare yet | `[grounded]` JD silent on pay | What salary range is budgeted for this role? | unresolved |
| RR3 | Duinvaart duties are specific | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The scope is concrete and its tools match yours | `[grounded]` JD | Who decides a route change, the depot manager or this role? | noted |
| RR4 | Kroonhaven not verified | unknown | — | "Supply Planner — Kroonhaven Foods, Utrecht" | The posting could not be checked against an official page because research was unavailable | `[grounded]` search refused; no claim about the employer | Can you confirm this role is open and who the planner reports to? | unresolved |
| RR5 | Kroonhaven pay not stated | unknown | — | (the posting states no pay) | Nothing to compare yet | `[grounded]` JD silent on pay | What salary range is budgeted for this role? | unresolved |
| RR6 | Kroonhaven scope is defined | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The role's ownership is explicit | `[grounded]` JD | Which decisions on the plan does this role make alone? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the Duinvaart role on the company's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran, stated as you described them | see R4, R5, R6 | `[grounded]` your message | pending your approval |
| A3 | Say plainly that your compliance tracking is on-time delivery, not temperature data | see R7 | `[grounded]` your message | pending your approval |
| A4 | Ask RR2 and RR3 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| B1 | Skip Kroonhaven as written | see R10, R12, R14 | `[grounded]` the map | pending your approval |
| B2 | Consider planning-adjacent analyst roles as a way in | a pattern, not a claim about Kroonhaven | `[generic]` role-family pattern | pending your approval |

Tailoring your CV for Duinvaart is resume-tailor's job; I haven't touched your CV.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for each company's official presence were refused (permission not granted). They would have fed role reality's contradictions row, RR1 and RR4 |
| 2. Role-family sweep | unavailable | Two pay and scope searches, one per role, were refused. They would have fed the market calibration rows, RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Everything above rests on what you pasted. I did no research on either employer.

I can emit `tuesday-dossier.md` if you want to carry this into later turns.

## Upgrade menu

- Your CV, a sanitized dashboard screenshot or a sample query → R2, R3, R4 and R5 move from `medium` toward `high`.
- Where you live and what commute you accept → R1 and R9 settle.
- Any temperature, SLA or exception reporting → R7 strengthens.
- Pay figures from either recruiter → RR2 and RR5 close, set against your floor.
- Web search permission → the rest of the L1 budget (1 search, 2 fetches) could check Duinvaart's careers page. A deeper pass on both employers (up to 5 more searches and 2 more fetches) would need your say-so.
- A hiring manager's name → role reality's scope read.

Questions:

R1 and R9 — Where do you live, and is three days a week in Rotterdam (or five in Utrecht) workable?

G1 — In your weekly route-performance review, did a route change ever come out of it, and what was your part?

G2 — Have you worked with any temperature, SLA-breach or exception data, even outside cold chain?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.