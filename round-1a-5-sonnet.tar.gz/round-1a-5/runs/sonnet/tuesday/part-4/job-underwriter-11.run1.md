Web searches were declined, so this runs on the text you pasted only. Here is the assessment for both roles.

## Decision snapshot

**Duinvaart: yes, worth your time. Status: `conditional_go`. Kroonhaven: no, not worth your time. Status: `no_go`.**

**Duinvaart, fit ledger (R1–R7).**

- `hard_gate`: unclear: R1 (Three days a week in the Rotterdam office)
- `must_have`: direct: R2, R3, R4
- `important`: direct: R5a · adjacent: R5b (Temperature compliance), R6 (Route changes with depot managers)
- `preferred`: adjacent: R7 (Dutch a plus)

R5b: temperature compliance is a new kind of metric for you; R6: the review ran, but no route-change outcome is stated.

**Duinvaart, opportunity ledger.** The deliverables are concrete (RR3). The employer could not be checked (RR1) and the pay is not stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the three office days work for you (R1); (2) the employer and the live posting check out (RR1); (3) you present temperature compliance as a new metric, never as experience you have (R5b).

**Kroonhaven, fit ledger (R8–R14).**

- `hard_gate`: unclear: R8 (On-site in Utrecht)
- `must_have`: adjacent: R12 (Fluent Dutch) · unclear: R10 (Advanced Excel) · absent: R9 (3+ years supply or demand planning in FMCG), R11 (SAP IBP or a similar planning system), R13 (Own the 13-week supply plan)
- `important`: adjacent: R14 (Run the weekly S&OP meeting)

R9, R11, R13: no planning evidence at all; R12: conversational against fluent.

**Kroonhaven, opportunity ledger.** The scope is clearly stated, but the employer could not be checked (RR4) and the pay is not stated (RR5).

- **Hard gates:** none failed; unconfirmed: R8 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to differ for a different status:** a planning role you have held (R9, R13) and hands-on planning-system experience (R11). Neither is in what you wrote.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| A: Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| A: Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| A: Unknowns | Pay; whether temperature data already exists in a usable form; who the role reports to | `[grounded]` the JD is silent on all three |
| B: Mandate | Own the 13-week supply plan for a chilled ready-meals range, balance capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| B: Working pattern | On-site in Utrecht | `[grounded]` JD |
| B: Unknowns | Pay; planning system in use (SAP IBP "or similar"); team size | `[grounded]` the JD is silent on pay and team size |
| Scope read, B | This is a planning-owner role, not an analyst role. Its requirements start from planning experience you say you don't have | `[inferred]` from the JD's "own the 13-week supply plan" against your stated background |
| Market calibration | Not run: the role-family search was refused, so there is no pay or scope band for either role | `[grounded]` search refused |

## Evidence map

Your background is typed prose, so it counts as self-report: `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | A: three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | No constraint of yours was given, and your employer is in Amsterdam. Whether Rotterdam three days works is not settled | `[grounded]` JD term; your constraints not given | Question R1 below |
| R2 | A: 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported, no artifact inspected | `[grounded]` your background | none |
| R3 | A: strong SQL | must_have | direct | medium | none | "SQL daily" is specific. "Strong" is a level, and nothing has been inspected for it | `[grounded]` your background | none |
| R4 | A: Power BI or Tableau | must_have | direct | medium | none | Power BI daily, plus the on-time delivery dashboard depot managers use | `[grounded]` your background | none |
| R5a | A: track on-time delivery | important | direct | medium | none | Your dashboard measures exactly this. Parcel and chilled-fleet delivery windows differ, but the metric is the same kind | `[grounded]` your background | none |
| R5b | A: track temperature compliance on a refrigerated fleet | important | adjacent | low | transferability | You have the tracking and dashboard skill. Nothing says you have handled temperature or cold-chain data, so the limit is the metric itself | `[grounded]` your background is silent on temperature data; `[generic]` that cold-chain roles treat this as core | Question G1 below |
| R6 | A: work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether any route changed because of it is not stated | `[grounded]` your background | Question G2 below |
| R7 | A: Dutch (a plus) | preferred | adjacent | medium | none | Conversational Dutch is a plus-level fit. It is preferred, so the stated level is enough | `[grounded]` your stated Dutch | none |
| R8 | B: on-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraint of yours was given | `[grounded]` JD term; your constraints not given | Only worth settling if you choose to pursue this role |
| R9 | B: 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning, and a parcel carrier is not FMCG. This is a length-of-experience requirement, not a gate | `[grounded]` your background | Closure path in G4 |
| R10 | B: advanced Excel | must_have | unclear | low | discovery | You named SQL and Power BI as daily tools. Excel level is not stated | `[grounded]` your background is silent on Excel | Closes only if you want this role; see G3 |
| R11 | B: SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analytics tools, not planning systems | `[grounded]` your background | Closure path in G4 |
| R12 | B: fluent Dutch | must_have | adjacent | medium | transferability | Conversational is real but short of fluent. Limit: the role runs a weekly meeting and works with production and sales, presumably in Dutch | `[grounded]` your stated Dutch; `[inferred]` the working language from "fluent Dutch" | none |
| R13 | B: own the 13-week supply plan | must_have | absent | none | capability | No planning ownership in your background. Dashboards on delivery performance are not a supply plan | `[grounded]` your background | Closure path in G4 |
| R14 | B: run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review, so you have chaired a recurring operations meeting. Limit: S&OP balances demand, supply and finance, which your review did not | `[grounded]` your background; `[generic]` what S&OP covers | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b, important) | transferability | Delivery tracking is shown. Temperature or cold-chain data is not | It is half of the role's first sentence, so an interviewer will go there first | Pharma, food or chilled parcels; any excursion, damage or SLA-breach field you reported on; sensor or scan-event data | A sanitized dashboard screenshot or a metric definition | `[grounded]` CV-equivalent silence; `[generic]` that interviewers press the least-evidenced half of a title |
| G2 | Route changes with depot managers (R6, important) | discovery | A weekly route-performance review, but no stated change that followed | A named outcome turns an adjacent row into a direct one | A depot dropping a late-running route; re-timing a collection round; a manager acting on your dashboard | A review pack, a before and after metric, or an email thread | `[grounded]` background is silent on outcomes |
| G3 | Advanced Excel (R10, must_have) | discovery | Not mentioned either way | It matters only if you pursue Kroonhaven | Pivot or Power Query models, forecasting sheets, reconciliations | A sanitized workbook | `[grounded]` background is silent on Excel |
| G4 | Planning experience and system (R9, R11, R13) | capability | No credible direct or adjacent evidence | Three must-haves hold none, so the role is out of reach as written | Nothing you described counts. If something does, say so. | Nothing to request yet | `[grounded]` your background; `[generic]` that a planning-analyst or coordinator role is the usual entry point |

For G4, the closure path is a different target role, not a wording change: a planning-coordinator or planning-analyst role, or the logistics-planning side of an operations job. That path is `[generic]` and not tied to any employer.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | A: employer not established | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The company may be new or small, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for any company I could not check, not a claim about this one | Can you point me to this role on your own careers site, and who I would work with? | unresolved |
| RR2 | A: pay not stated | unknown | — | no figure in the posting you pasted | The salary may sit below what a four-year analyst expects, or the firm may not publish pay | `[inferred]` from the posting's silence | What is the salary range for this post? | unresolved |
| RR3 | A: deliverables and metrics named | positive_signal | — | "build weekly dashboards in Power BI" | The scope is concrete: named metrics, a named tool, a named partner group | `[grounded]` JD | Who owns the temperature data today? | noted |
| RR4 | B: employer not established | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The company may be new or small, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for any company I could not check, not a claim about this one | Can you point me to this role on your own careers site, and who I would work with? | unresolved |
| RR5 | B: pay not stated | unknown | — | no figure in the posting you pasted | The pay may or may not fit your floor | `[inferred]` from the posting's silence | What is the salary range for this post? | unresolved |

## Application plan

Every row below, and the advice around it, is proposed and pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart CV: lead with the on-time delivery dashboard your depot managers use, and the weekly route-performance review you ran. Use your own words and numbers. Add nothing about temperature or cold chain | See R4, R5a, R6 | `[grounded]` your background | pending your approval |
| E2 | In the cover note, say plainly that your Dutch is conversational. The posting asks for it only as a plus | See R7 | `[grounded]` JD and your stated Dutch | pending your approval |
| Q1 | Ask the questions of RR1, RR2 and RR3 verbatim when you speak to Duinvaart | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Don't apply to Kroonhaven for this posting. If planning interests you, look for an entry-level planning role | See R9, R11, R13 | `[grounded]` map rows | pending your approval |

Once you decide on Duinvaart, resume-tailor can turn E1 into a full edit ledger.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: one for the Rotterdam firm, one for the Utrecht firm. They would have settled RR1, RR4 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Two searches were refused: one on operations-analyst pay and scope in Rotterdam, one on planner pay and tooling in Dutch FMCG. They would have set the market calibration, RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want to carry this into other applications, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- **Your CV, or a few of its bullets** → confirms R2, R3, R4 and R5a, and gives E1 real wording to work from.
- **Your location, commute limit and pay floor** → R1 resolves, and RR2 can be set against your floor.
- **Right to work in the Netherlands** → neither posting states it, so no row exists yet. Telling me adds one.
- **Any temperature-sensitive or time-critical shipment work (G1)** → R5b could move from adjacent toward direct.
- **An example where your review changed a route (G2)** → R6 moves toward direct.
- **Permission to run web searches** → RR1, RR4 and the market calibration get checked.

## Questions

R1: Can you do three days a week in Rotterdam from where you live? Is there a commute limit, a fixed day or a pay floor that would rule it out?

G1: Have you handled temperature-sensitive or time-critical parcels, such as chilled, pharma or food, even as a field on a dashboard?

G2: Did your weekly route-performance review ever lead to a route change? What was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.