Web search was blocked, so everything below comes from your posting and your WhatsApp message only.

## Decision snapshot

**Yes, worth applying to, on conditions, and nothing you've shared looks like a red flag. I can't confirm the company exists as described, though. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5a, R7 · adjacent: R6 (Own the booking flow end to end)
- `important`: adjacent: R5b (Research calls with school owners), R8 (First and only designer)

R6 — a credible bridge from checkout to the whole flow, its limit named; R8 — the real stretch, never done solo; R2 — waiting on your pay floor.

**Opportunity ledger.** The terms are concrete: scope, salary and equity ranges, and the interview ask are all stated (RR4). The employer is not yet established from attributable sources (RR1), and the equity terms, runway and design support are open (RR2, RR3, RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company verifies as a live employer with this posting on its own site (RR1); (2) the pay range clears your floor (R2); (3) the equity terms are explained in writing (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools. This is the posting's own description and is not independently checked | `[grounded]` posting |
| Mandate | First designer; own the booking flow end to end; run research calls with school owners; ship alongside two engineers; work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week at the Galway office | `[grounded]` posting |
| Interview step | Ronan asks for a 45-minute video call with him and the CTO, Saoirse; the invite is by email | `[grounded]` your message |
| Scope read | A broad remit with no design peers, which is normal for a "first designer" post at six people | `[inferred]` from "first designer", "end to end" and the team size |
| Market calibration | Not run, because the role-family search was blocked; no salary band is claimed. Small-company first-designer posts usually combine design, research and some product work | `[generic]` |
| Unknowns | Funding and runway; equity mechanics; who gives design feedback; permanent or fixed-term contract | — |
| Contradictions | None between the posting and the WhatsApp message: the roles, names and the interest in your checkout case study are consistent | `[grounded]` posting and message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the term is met as stated. Self-report only | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The range is stated, but you haven't given a floor, so whether it clears your floor is unsettled | `[grounded]` posting; no stated floor | Ask your floor (G1) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. Self-report, no inspectable artifact yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily". A portfolio or file would be the inspectable proof for design | `[grounded]` your background | Offer: link to the case study or a Figma file would raise to `high` |
| R5a | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your background | none |
| R5b | Research calls with school owners | important | adjacent | low | transferability | Usability sessions carry over. The limit is that they were with consumers of a travel-booking product, not business owners, and weren't discovery-style calls (not stated either way) | `[inferred]` from the posting duty against your sessions | G3 |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign is a confirmed, specific stage of a booking flow. The limit is that owning every stage is not stated | `[grounded]` your background; `[inferred]` the limit | G2 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your background | none |
| R8 | Working as the first and only designer | important | adjacent | low | transferability | Squad work is adjacent, but you've said you've never been the only designer, so the lower band is taken. This is the real stretch | `[inferred]` from "first designer" against your history | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | The range is stated; your floor is not | A gate not yet settled: it decides whether going further is worthwhile | Your minimum base, whether equity is a plus or only a bonus, and any other hard limits | None needed | `[grounded]` posting, no stated floor |
| G2 | End-to-end flow ownership (R6, must_have) | transferability | You redesigned checkout; the scope of your ownership beyond it isn't stated | It is the posting's headline duty, so the bridge and its limit decide how you pitch | Choosing which stages to redesign; defining flow-wide metrics; deciding between flow options with engineers | Before/after flow diagram, case-study page | `[grounded]` checkout claim; `[generic]` that this duty gets probed |
| G3 | Research with business owners (R5b, important) | transferability | Monthly usability sessions with customers | The posting makes owner calls a core duty | Calls with partner businesses or suppliers; internal stakeholder interviews | Session plan, discussion guide, findings write-up | `[inferred]` from duty against your sessions |
| G4 | Solo-designer working (R8, important) | transferability | Squad work only; never the only designer | The posting makes you the first designer | Setting your own priorities; running design work without a lead; building a lightweight design system | Any small-scope project you drove alone | `[grounded]` your statement; `[inferred]` the gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | A percentage means little without share class, vesting, strike price and dilution | `[generic]` how equity offers usually work | What are the vesting schedule, cliff and strike price, and how many fully diluted shares are there? | unresolved |
| RR3 | Little design support | risk_signal | low | "You would be our first designer" | No design peer for critique, with decision rights shared among the co-founder, CTO and two engineers | `[inferred]` from "first designer" and the team size | Who gives design feedback today, and how are priorities set between product and engineering? | unresolved |
| RR4 | Concrete terms and a stated process | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" and "45-minute video call with me and Saoirse, our CTO" | Pay, scope and the interview step are stated rather than withheld | `[grounded]` posting and message | What does success look like at six months? | noted |
| RR5 | Funding and runway unknown | unknown | — | "We are six people" | Stage, funding and runway are unstated | `[generic]` | How are you funded, and what is your runway? | unresolved |

The WhatsApp invite is routine. The message asks for no money, ID or bank details, and arranging a video call by chat is normal. It needs no register entry.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the email calendar invite comes from an address on the company's own website domain, and enter any details only on their own site | Routine hygiene for RR1 | `[generic]` | pending your approval |
| A2 | Prepare one project walk-through, including what was messy and what was your work versus the squad's | The posting says it prefers one messy real project to a polished deck (R4, R6, R8) | `[grounded]` posting | pending your approval |
| A3 | Position as: a designer who ran regular usability sessions and redesigned checkout, with the solo-designer step as your stated stretch | Stays inside what you've told me (R5a, R6, R8) | `[grounded]` your background | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR5 on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

mock-interview can run a prep drill for the Ronan and Saoirse call whenever you want one.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for the company, its product and Galway was refused, so existence and a live posting are unverified; this feeds RR1 |
| 2. Role-family sweep | unavailable | A search for first-designer salaries in Ireland was refused. It would have fed the market calibration and R2 |
| 3. Hiring manager's public footprint | unavailable | A search for Ronan Kehoe's public professional footprint was refused. It would have fed the scope read and the positioning in A3 |

I'll offer the optional deeper pass once: up to 5 more searches and 2 more fetches on funding and recent news. It only works if search is allowed.

If useful, I can save this as `tuesday-dossier.md` for later steps.

## Upgrade menu

- Allow web search → company existence, the live posting, a salary band and Ronan's public work history.
- A link to the company's site or the posting → settles RR1.
- Your pay floor → settles R2.
- A portfolio or Figma link → R4 to `high`, and strengthens R6.
- The equity terms → settles RR2.

## Questions

G1 — What is the lowest base salary you'd accept, and is anything else (days in office, hours) a hard no?

G2 — In the checkout redesign, which other parts of the booking journey did you own, and which belonged to others?

RR1 — What did you find when you looked: any website or LinkedIn page, and does the invite's sender address match a company domain?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.