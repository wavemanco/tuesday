I've finished reading the playbook. Next I'll look up Fernquay, which is the L1 company check, and then write the assessment.
# Job Underwriting Assessment: Product Designer at Fernquay

## Decision snapshot

**Yes, take the call. The WhatsApp message is a routine way to schedule it, and the company matches its own About page. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5 · adjacent: R6 (Own the booking flow end to end)
- `important` — direct: R7 · adjacent: R8 (First designer)

R6 — checkout is one stage of booking, and whole-flow ownership isn't shown; R8 — no sole-designer history, in your own words.

**Opportunity ledger.** The employer matches the posting on its own About page (RR3), and neither the posting nor the message asks you for money, documents or personal details. The open points are support for a sole designer (RR1), unstated equity terms (RR2) and the role not yet seen on the company's own site (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the €52,000–€60,000 range clears your pay floor (R2); (2) the support around a first designer is concrete in the call (R8, RR1); (3) the equity terms are given in writing (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway. It makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle, and funded by its customers | `[grounded]` About page fetched; the posting agrees on size and city |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers; first designer | `[grounded]` JD |
| Working pattern | Hybrid: two days a week in the Galway office, the rest flexible | `[grounded]` JD |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Scope read | A broad solo remit (design, research and shipping) that is ordinary for a first designer at a six-person company | `[inferred]` from the JD's three duties against its team size |
| Market calibration | Ireland 2026, product designers with 3 to 5 years: median base €57,000, interquartile range €51,500–€62,000. The posted range sits inside it. The survey says nothing on equity, so the equity is unpriced | `[generic]` salary survey (n=520), not a claim about this employer |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and before Fernquay was a product lead at a Galway travel-software company for five years | `[grounded]` public professional profile |
| Unknowns | Equity terms; who reviews design work; whether the role is listed on the company's own site; the pay floor you'd accept | `[grounded]` absent from the JD and About page |
| Contradictions | None between the JD and the About page on size, city or product | `[grounded]` About page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, so the office days are met on your account. Self-reported | `[grounded]` your message; JD | none |
| R2 | Salary €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the pay. Your pay floor hasn't been given, so whether the role meets it can't be settled | `[grounded]` JD; floor not provided | Question 1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Self-reported, nothing inspected. A years requirement is graded on fit, not treated as a gate | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | presentation | "Figma daily" is a statement, not evidence. Your portfolio is the inspectable artifact for design, and I haven't seen it | `[grounded]` your message | Share the checkout case study |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, which is run research. The role's version is research calls with school owners, which is discovery work. Usability sessions are a different kind of research, so don't present one as the other | `[grounded]` your background; JD | Share session notes if you have them |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a checkout flow. Whether you owned the wider booking journey or one stage of it isn't stated | `[grounded]` your background; JD | Question 2 below |
| R7 | Happy working directly with engineers | important | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Work as the only designer | important | adjacent | low | transferability | Inferred from "our first designer". You've owned a redesign inside a squad, but you've never been the only designer, so setting direction and standards without a design peer is untested | `[inferred]` from the JD wording; `[grounded]` your statement | Question 3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership (R6, must_have) | discovery | You redesigned checkout. Search, selection, availability or post-booking changes aren't mentioned | The role is built around the whole booking flow, so which stage you owned shapes how to position the checkout work | Changes to availability or pricing display; confirmation and rebooking flows; a decision you made on a stage you didn't draw | A before/after of the checkout case study with your role stated | `[grounded]` your background silent on scope; `[inferred]` that the posting reads whole-flow ownership as central |
| G2 | Sole-designer readiness (R8, important) | transferability | Squad work with a clear redesign, but always with other designers around you | A first designer sets the standards. The bridge is the decisions you made without review | Choices you made when no one reviewed them; a pattern you set that others used; a trade-off you settled between design and engineering | One decision write-up from the checkout project | `[grounded]` your statement you were never the only designer; `[generic]` that first-designer roles hinge on this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Support for a first designer | unknown | — | "You would be our first designer" | You may carry design decisions with no design review, and Ronan is your closest working partner | `[inferred]` from the JD's wording against your history | Who reviews design work today, and who decides when design and engineering disagree? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The value depends on vesting, share class and dilution, none of which the posting gives | `[generic]` early-stage equity depends on terms not shown in a percentage | What are the vesting schedule, the share class, and the current share count behind that percentage? | unresolved |
| RR3 | Employer matches the posting | positive_signal | — | "Six people, based in Galway… funded by its customers" | The company exists as described, and a customer-funded team's hiring budget depends on revenue | `[grounded]` About page; `[generic]` that customer-funded budgets track revenue | How many schools are paying customers, and what hiring plan does current revenue support? | noted |
| RR4 | Role not yet seen on the company's own site | unknown | — | "Product Designer — Fernquay" | The About page doesn't list the role. The posting may sit on another site, or the page may simply not list roles | `[grounded]` About page silent on the role | Is this role listed on your own site, and who else will I meet besides Ronan and Saoirse? | unresolved |

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent the message. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the 45-minute call. Check that the calendar invite arrived by email from an address on the company's own domain, the one its About page sits on, before opening the link | The WhatsApp scheduling is routine. The check is just good practice | `[grounded]` About page; `[generic]` that scheduling by chat is common at small companies | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions, in your own words: what you changed, that you worked in a squad of four engineers, and which stage you owned. Don't describe it as owning the whole booking flow, or the sessions as discovery interviews with owners | Their posting asks for "one messy real project". Ronan's own background is in travel software, so your travel-booking history is directly relevant | `[grounded]` JD; public profile; your background | pending your approval |
| A3 | Ask RR1–RR4 verbatim in the call | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A4 | Decide your pay floor, including what equity is worth to you, before the call | Resolves R2 before any offer | `[grounded]` R2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway"; fetched "About Fernquay" (fernquay.example/about). It confirms the employer matches the posting (RR3). It doesn't list this role, so liveness is open (RR4) |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration in role reality |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved the scope read and the positioning in A2 |

I haven't verified that the message came from Ronan himself, or that the "CTO" role he mentioned exists. The About page names Saoirse Doyle as a co-founder but doesn't give a title.

If you want me to build the dossier file from this, say so.

**Upgrade menu**
- Your checkout case study link → R4, R5 and R6 can move toward `high`, and G1 gets answered from the artifact.
- Your pay floor → R2 resolves.
- Their answers to RR1, RR2 and RR4 → the conditions close and the decision likely simplifies to `go`.
- A deeper pass on Fernquay (customer and funding signals; up to 5 more searches and 2 more fetches) — say the word and it runs.
- Call preparation is a separate module (mock-interview) if you want it.

**Questions**

R2 — What is the lowest base salary you would accept, and does the equity change that number?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — In the checkout project, which stages of the booking journey did you decide on yourself, and which were handed to you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Can you describe a design decision where no senior designer reviewed it, what you chose, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.