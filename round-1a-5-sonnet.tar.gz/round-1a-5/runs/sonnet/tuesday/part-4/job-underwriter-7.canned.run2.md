I've run three searches and found the employer, a pay benchmark and the team lead's public profile. Next I'm fetching their careers page to check that the posting is live and matches your copy.
**Is it worth applying for? Yes. R1 and R2 are hard gates that you meet on your own statements, R3 is `direct`, and the open items can be fixed. Status: `conditional_go`.**

This is a first pass. Your CV is the only evidence so far, so nothing is above `medium` confidence yet.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R6 · adjacent: R5 (Wound and leg-ulcer care), R8 (Insulin administration and care planning), R10 (Housebound adults in their own homes), R11 (Hold a small caseload of your own) · unclear: R7 (Continence care), R9 (End-of-life visits)
- `preferred` — absent: R12 (Doppler assessment)

R11 — home visits yes, own caseload never held; R4 — the one `must_have` row your CV doesn't yet evidence; R12 — preferred, and you have no Doppler experience.

**Opportunity ledger.** Pay is stated and sits inside the survey range (RR5), the caseload comes with a senior nurse's support (RR3), and the employer checks out (RR1). Still to verify: that the posting is live (RR2), what first-caseload support looks like (RR4), and how pool cars and mileage fit together (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on the employer's own channels (RR2); (2) you confirm your records and electronic patient record experience (R4); (3) first-caseload support turns out to be concrete (RR4).

Your National Insurance number isn't needed for this. I haven't used it, and you shouldn't send it until there is a written offer. Your NMC PIN stayed out of every search.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page, calderbrookhealth.example/about |
| Role | Band 5 district nursing for housebound adults: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, all on an electronic patient record | `[grounded]` advert |
| Support model | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England (n=1,240) gives a median basic pay of £34,300 and an interquartile range of £32,400–£36,600, so the advertised range spans that band. It is a market pattern, not this employer's offer | `[generic]` survey result snippet; `[grounded]` advert for the posted range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | Leg-ulcer work and Doppler training for newcomers appear to matter to this team, so the desirable Doppler skill is probably something they train rather than expect on arrival | `[inferred]` from her talk topics; not a statement about this posting |
| Unknowns | Caseload size, length of supervised start, pay-point placement, shift and weekend pattern, which electronic record system is used | — |
| Contradictions | None between the advert and the About page. I couldn't reach a careers page, so whether the posting is live is unconfirmed (RR2) | `[grounded]` About page; fetch of the careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration as an Adult Nurse, with revalidation due March 2028. That is stated, not checked | `[grounded]` CV | Check your own entry on the NMC register shows as current |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full category B licence. Stated, not checked | `[grounded]` CV | Check your licence record on the DVLA site |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, against a one-year minimum | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about record-keeping or electronic systems. Silence isn't evidence of absence, but I can't assert it for you | `[grounded]` CV silence | Ask G1 |
| R5 | Wound and leg-ulcer care | important | adjacent | medium | transferability | You state pressure-ulcer and surgical-wound care. Leg ulcers aren't stated, and that is a different wound type with its own assessment | `[grounded]` CV for wound types; `[generic]` that leg ulcers are assessed and treated differently from pressure ulcers | Ask G3 |
| R6 | Catheter care | important | direct | medium | none | "Catheter care" is in your CV in those words | `[grounded]` CV | none |
| R7 | Continence care | important | unclear | low | discovery | The CV names catheter care only, not wider continence work | `[grounded]` CV silence | G4, not asked this turn |
| R8 | Insulin administration and care planning | important | adjacent | medium | discovery | Insulin administration is stated. Care planning isn't, so the row takes the lower reading | `[grounded]` CV for insulin; CV silent on care planning | G5, not asked this turn |
| R9 | End-of-life visits | important | unclear | low | discovery | Nothing in the CV addresses end-of-life care | `[grounded]` CV silence | Ask G2 |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | Your 18 months seconded to discharge-to-assess included home visits in the first week after discharge. That is the home setting, but it isn't ongoing care of long-term housebound adults | `[grounded]` CV | G6 |
| R11 | Hold a small caseload of your own | important | adjacent | medium | transferability | You told me you have never held your own caseload. Home visiting carries over; owning a caseload doesn't | `[grounded]` your statement and CV | G7 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have not done Doppler assessment | `[grounded]` your statement | G8: closure path, not a question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records and the electronic patient record (R4, must_have) | discovery | The CV doesn't mention records or systems | It is the only `must_have` row not yet evidenced, so it could move the status | Documenting at the point of care, discharge or handover documentation, using a hospital electronic record, audit of your notes | A reference line, an audit result, or a system name | `[grounded]` CV silence; `[inferred]` that this could move the status |
| G2 | End-of-life care (R9, important) | discovery | The CV is silent on end-of-life work | The advert lists end-of-life visits among its core duties | Caring for dying patients on the ward, anticipatory medicines, family conversations, last-days care plans | A training certificate or reference | `[grounded]` CV silence, advert duty |
| G3 | Leg-ulcer care (R5, important) | transferability | Pressure-ulcer and surgical-wound care are stated; leg ulcers aren't | It is the nearest match to the team's stated clinical focus | Compression bandaging, leg-ulcer dressings, wound-assessment charts | A training record or competency sign-off | `[grounded]` CV; `[inferred]` team focus from the speaker page |
| G4 | Continence care (R7, important) | discovery | Only catheter care is stated | The advert pairs the two | Bladder and bowel care, continence assessments, product selection | A competency record | `[grounded]` CV silence |
| G5 | Care planning (R8, important) | discovery | Insulin is stated; care planning isn't | Care planning is half of that row | Writing or updating care plans, discharge plans | A sanitised care-plan example | `[grounded]` CV silence |
| G6 | Housebound adult care (R10, important) | transferability | Home visits after discharge are stated | The population differs from post-discharge patients | Repeat visits to the same patients, follow-up on longer-term needs | A discharge-to-assess service description | `[grounded]` CV |
| G7 | Own caseload (R11, important) | transferability | Home visiting yes, ownership never held | It is the real step up in this role | Planning your own visit list, prioritising patients, escalating concerns | A team lead's reference on your autonomy | `[grounded]` your statement |
| G8 | Doppler assessment (R12, preferred) | capability | No Doppler experience | It is only desirable. The team lead has spoken on Doppler training for newcomers, which suggests it is taught here | A Doppler or leg-ulcer training course | A course certificate | `[grounded]` your statement; `[inferred]` from her talk topic |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer establishes as described | positive_signal | — | "district nursing team caring for housebound adults in their own homes" | The employer's own About page describes the same kind of service | `[grounded]` About page | Which locality hub would this post be based at? | noted |
| RR2 | Posting not confirmed on the employer's careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page wasn't reachable from here, so the post may be listed elsewhere, closed, or I used the wrong address | `[grounded]` fetch returned no page; `[generic]` that adverts often live on a separate jobs portal | Can you point me at this role on your own jobs page, and its closing date? | unresolved |
| RR3 | Small caseload with a senior nurse's support | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | The role is scoped with support rather than left unsupported | `[grounded]` advert | How is the senior nurse's support structured in the first months? | noted |
| RR4 | First-caseload support unspecified | unknown | — | "supported by a senior community nurse" | The posting doesn't say how long the supervised start lasts or how the caseload builds | `[inferred]` from the advert's silence | How long is the supported start, and how does the caseload grow? | unresolved |
| RR5 | Pay stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posted range sits across the survey's interquartile band | `[grounded]` advert; `[generic]` survey band | Which point on the range would five years' experience start at? | noted |
| RR6 | Pool cars and mileage both mentioned | unknown | — | "pool cars are provided … plus mileage" | It is unclear when mileage applies if pool cars cover the visits | `[inferred]` from the advert's wording | When is mileage paid, given that pool cars are provided? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott before applying, and ask RR2, RR4, RR5 and RR6 verbatim | The advert invites it, and it settles the open verification items | `[grounded]` advert, register | pending your approval |
| A2 | Lead the application with your own words: "Five years as a staff nurse on an acute medical ward, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." Describe your own-caseload experience as none | It is your strongest match, and every clause traces to your CV and your statement | `[grounded]` CV | pending your approval |
| A3 | Say plainly that you haven't done Doppler assessment. Ask whether the team trains for it | It is a preferred skill, and the team lead has spoken publicly on Doppler training for newcomers | `[grounded]` your statement; `[inferred]` from her talk | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). I then tried a careers address, which returned no page. Moved: RR1 (employer established) and RR2 (posting not confirmed live) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: role reality's scope read and A3 |

I read only the search snippets for these three results, not the full pages.

## Upgrade menu

- The employer's own link to this posting, or its closing date → RR2 closes, and the `conditional_go` condition on it lifts.
- Your answer to G1 (records and the electronic patient record) → R4 firms up and I can say whether the status moves toward `go`.
- Answers on end-of-life care and leg-ulcer care (G2, G3) → R9 and R5 get firmer.
- Anything on continence, care planning or repeat home visits (G4, G5, G6) → those rows firm up.
- Rhiannon Mabbott's answers on support, pay point and mileage → RR4, RR5 and RR6 close.
- A deeper research pass on Calderbrook Community Health (leadership changes, recent news, candidate and employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can also write all of this to `tuesday-dossier.md`, which would let a later session pick up from it.

G1 — Did your ward or discharge-to-assess work involve recording care on an electronic patient record, and what was your part in keeping notes clear and timely?
G2 — Have you cared for dying patients, and what did you own in their care (symptom control, family conversations, last-days plans)?
G3 — Have you done any leg-ulcer care, such as compression bandaging or dressings, and under whose supervision?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.