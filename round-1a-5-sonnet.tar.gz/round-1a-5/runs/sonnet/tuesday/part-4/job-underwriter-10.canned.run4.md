I've run three searches and the company checks out so far. Next I'll read their own site to see whether this posting is listed there.
**Yes, this is worth taking the call on, and the employer checks out against its own site (RR1). Nothing in the WhatsApp message asks for anything beyond a video call. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R9 (First designer, no design peer) · unclear: R7 (Research calls with school owners)

R6 — a credible bridge, its limit named; R9 — adjacent only, no solo-designer evidence; R7 — waiting on one answer; R2 — waiting on your pay floor.

**Opportunity ledger.** The employer and posting match their own site (RR1) and the stated pay sits inside the market band (RR2). The open items are the equity terms (RR3), the runway (RR4), and what success and design review look like for a sole designer (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for `conditional_go`:** (1) your pay floor fits the range, per R2 and RR2; (2) equity terms and runway get concrete answers, per RR3 and RR4; (3) you're comfortable being the only designer, per R9 and RR5. R6's limit (checkout is not the whole booking flow) must also be stated plainly, never claimed as full ownership.
- **What would turn this to `no_go`:** a pay floor above the range, per R2, with no flex.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, "funded by its customers" | `[grounded]` About Fernquay page |
| Posting is live | The same role, pay range and hybrid pattern appear on Fernquay's own careers page. Applications go to a Fernquay address, with "one real project" | `[grounded]` careers page result |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Closest colleague | Ronan Kehoe, co-founder and CEO, previously product lead at a Galway travel-software company for five years | `[grounded]` public profile result |
| Scope read | A broad first-designer remit (flow, research, shipping) with no design peer to review work | `[inferred]` from "first designer" and the responsibilities list |
| Market calibration | Stated €52,000–€60,000 sits inside the interquartile range of €51,500–€62,000 (median €57,000) for 3–5 years in Ireland. The band is a pattern, not this employer's offer | `[generic]` 2026 Ireland salary report, search snippet only; `[grounded]` posting for the stated range |
| Unknowns | Equity terms, runway, first-year outcomes, who reviews design work, and Saoirse's CTO title (the pages I read name her as co-founder, not CTO) | `[grounded]` absent from the pages read |
| Contradictions | None between posting and careers page. The About page adds sailing schools and Scotland, which isn't a conflict | `[grounded]` both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so two office days is within reach. It's unprobed prose, not a stated constraint | `[grounded]` your message and the posting | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so whether the range meets it is unknown | `[grounded]` no constraint given | G1 question |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated and specific but unprobed | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but nothing inspectable has been seen | `[grounded]` your background | a Figma case-study link would raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, stated. Usability testing is one kind of research; R7 covers the other | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned your company's checkout flow, a core part of a booking flow. Limit: checkout is not stated to cover the whole journey, and it was done in a squad | `[grounded]` your background; `[inferred]` the limit | G3 question |
| R7 | Run research calls with school owners | important | unclear | low | discovery | Your sessions were with customers. Whether any were discovery-style conversations with business operators is not stated | `[grounded]` your background; `[generic]` that usability testing and discovery calls are different work | G2 question |
| R8 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R9 | First designer, no design peer | important | adjacent | medium | transferability | Your checkout redesign and research are real elements of the work. Limit: you have never been the only designer, so working without peer review is untested | `[inferred]` requirement from "first designer"; `[grounded]` your statement | G4 framing |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | The range is stated, your floor is not | A floor above €60,000 would make this `no_go`; at or below €52,000 R2 closes | Your current salary, plus what you would need to move | none needed, your own statement | `[grounded]` no floor given |
| G2 | Research with business owners (R7, important) | discovery | Usability sessions are confirmed; discovery calls with operators are not | The role has you running research calls with school owners | Interviews before the checkout redesign; calls with partner or supplier staff; sessions with people who use the product for their job | An interview guide, a synthesis board, a research readout | `[grounded]` your background; `[generic]` that these differ from usability testing |
| G3 | Whole-flow ownership (R6, must_have) | transferability | Checkout redesign confirmed; wider journey unclear | "End to end" is the role's core; the limit decides how you describe it | Date and availability selection, payment, confirmation emails, changes and cancellations | Flow map, before/after Figma frames, a result you measured | `[grounded]` your background |
| G4 | Working as the only designer (R9, important) | transferability | Squad experience, no sole-designer evidence | Their team has no design peer to review your work | Times you set direction with nobody reviewing; decisions you defended to engineers | The checkout case study they already liked | `[grounded]` your statement; `[inferred]` the role has no peer |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting match their own site | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | Fernquay is a real small employer and the posting is live on its own careers page | `[grounded]` About page and careers page | Who else would I meet in the process, beyond you and Saoirse? | noted |
| RR2 | Stated pay inside the market band | positive_signal | — | "€52,000–€60,000" | The range is credible for this experience level | `[grounded]` posting figure; `[generic]` band from a 2026 Ireland report snippet | Is the range flexible within the band, and is there any bonus? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage is given but vesting, cliff, share class and dilution are not | `[grounded]` absent from the posting; `[generic]` those terms decide what a small-company grant is worth | What is the vesting schedule and cliff, and what class of shares is this? | unresolved |
| RR4 | Runway not stated | unknown | — | "funded by its customers" | With no outside investor named, pay depends on customer revenue | `[inferred]` from the About page wording | How much runway does current revenue give, and is this hire in that plan? | unresolved |
| RR5 | No first-year outcomes or design review | unknown | — | "own the booking flow end to end" | The posting gives responsibilities but no success measure or reviewer | `[inferred]` from the posting's silence | What does a good first six months look like, and who reviews design work? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Take the call and ask the RR3, RR4 and RR5 questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P2 | Walk through the checkout case study they said they loved, including what didn't work and what you personally did versus the squad | The posting says they'd rather see "one messy real project" than a polished deck | `[grounded]` posting and your message | pending your approval |
| P3 | Say plainly that you've worked in a squad with four engineers and have not been the only designer, then say what you did own in the checkout redesign | Ronan's own background is travel software, so your travel-booking checkout work is in his domain | `[grounded]` your statements and his public profile | pending your approval |
| P4 | Scheduling an interview by WhatsApp is routine for a small team. Before clicking, confirm the emailed calendar invite came from a Fernquay address and the video link is a mainstream video platform | A small habit worth keeping for any invite | `[generic]` general practice | pending your approval |
| P5 | Ask for pay and equity terms in writing before accepting any offer | Equity terms (RR3) are the open item | `[generic]` general practice | pending your approval |
| P6 | If you want to rehearse the 45-minute call, mock-interview covers that | Your call whether to use it | — | your call |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers product designer". Fetched "About Fernquay" (fernquay.example/about); the careers result was "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization and contradictions rows and RR1; no standing employer-not-established entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup 3 years experience", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), snippet only. Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. Moved the closest-colleague row and P3 |

If you'd like a `tuesday-dossier.md` of this assessment to carry forward, say so and I'll write it.

**Upgrade menu**

- Your pay floor → R2 and G1 close; the decision firms up to `go` or `no_go`.
- A link to the checkout case study or a Figma file → R4 to `high`, and R6's limit becomes concrete.
- An answer on discovery-style research → R7 closes or becomes a named gap.
- Their answers on equity, runway and design review → RR3, RR4 and RR5 close.
- A deeper research pass on Fernquay (customer reviews, leadership history, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — What base salary would you need for this to work, and does €52,000–€60,000 clear it?
G2 — Before or alongside your usability sessions, did you ever talk with customers about how they work, rather than testing a design? What did you own, and what changed?
G3 — In the checkout redesign, which steps of the booking journey did you personally own, from choosing a date to confirmation, and which belonged to others?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.