I'm reading the last two reference files for the response format. Then I'll write the assessment.
## Decision snapshot

**Yes, it's normal. Payroll and identity details requested after a written offer that names the role, pay and manager are routine onboarding, and I wouldn't treat them as a warning sign. I'd accept, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R3 · unclear: R1 (Hybrid, two days in Limerick), R2 (Pay €38,000–€42,000)
- `must_have`: direct: R4, R6, R8, R9 · adjacent: R7 (Monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: unclear: R11 (Answering staff payroll queries) · absent: R10 (Pension changes)

R10 is a learnable gap you've named yourself; R5 is probably fine but your message doesn't confirm it.

**Opportunity ledger.** The offer is concrete: role, pay inside the advertised band, manager and working pattern are all named after two in-person interviews (RR2). I couldn't check the employer online (RR1), and the contract's probation, pension and notice terms are not yet stated (RR3, RR4).

- **Hard gates:** none failed (R3 `direct`); unconfirmed: R1 (Hybrid, two days in Limerick), R2 (Pay €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role and employer check out on Marrowgate's own website, RR1; (2) you receive the written contract terms before your notice runs out, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` job ad |
| Mandate | Monthly payroll, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` job ad |
| Terms offered | Permanent, €40,000, hybrid with two office days, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Onboarding steps | Bank details, PPS number and a passport scan, entered in a portal after you accept; original passport on day one | `[grounded]` offer email |
| Market calibration | Not established: the search was refused, so I won't quote a market band | `[grounded]` search refused |
| Unknowns | Payroll system used, who handles pension changes now, probation and notice terms, start date | `[grounded]` none stated in the ad or offer |
| Contradictions | None between the ad and the offer: title, hybrid pattern and salary band agree | `[grounded]` ad against offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Limerick office | hard_gate | unclear | low | hard_gate | You haven't stated your location or schedule limits. The offer repeats the ad's terms. | `[grounded]` ad and offer | Answer question R1/R2 |
| R2 | Pay €38,000–€42,000 | hard_gate | unclear | low | hard_gate | The offer of €40,000 sits inside the band, but your pay floor wasn't given. | `[grounded]` ad and offer | Answer question R1/R2 |
| R3 | A payroll qualification or working towards one | hard_gate | direct | medium | none | Payroll Technician certificate, 2024, as you stated it. I haven't seen the document. | `[grounded]` your stated background | Keep the certificate to hand |
| R4 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll, stated and specific. No document seen. | `[grounded]` your stated background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say whether the hotel group's payroll was Irish. | `[grounded]` background silent on jurisdiction | Answer question G2 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, as you stated. | `[grounded]` your stated background | none |
| R7 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Same discipline, but you ran 90 staff on a fortnightly cycle. The limit is scale and cycle. | `[grounded]` your stated background | Ask which system they use (G3) |
| R8 | Process starters and leavers | must_have | direct | medium | none | Stated as part of your hotel group role. | `[grounded]` your stated background | none |
| R9 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | You did this monthly, as you stated. | `[grounded]` your stated background | none |
| R10 | Process pension changes | important | absent | none | capability | Confirmed that your manager handled these. Seeing them done isn't doing them. | `[grounded]` your statement | Ask who covers pensions at first (G1) |
| R11 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention queries. Running payroll for 90 staff likely involved some. | `[inferred]` from the scale of your hotel role | Cover in your first-week plan |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R10, important) | capability | Observed, never run | It's a stated duty of the job, so it's the likeliest early gap | Entering pension joiners or opt-outs, or sending contribution reports | None held; closure path is training or a handover in the first weeks | `[grounded]` your statement; `[generic]` that employers usually train this |
| G2 | Irish tax rules (R5, must_have) | discovery | Jurisdiction of your hotel payroll unstated | A must-have, and unconfirmed | Weekly or monthly Revenue submissions, USC and PRSI classes, P45s | Payslips or a Revenue submission screen, sanitised | `[grounded]` background silent |
| G3 | Scale and system (R7, must_have) | transferability | 90 staff fortnightly against 240 monthly | The step up is real, though modest | Any month-end run or multi-site payroll | The ad doesn't name their software | `[inferred]` from the two scales |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked online | unknown | — | "Marrowgate Housing, a housing association in Limerick" | I couldn't search, so I haven't confirmed the organisation or its live posting | `[grounded]` search refused | Is this post listed on your careers page, and who will meet me on day one? | unresolved |
| RR2 | Offer is specific and follows two in-person interviews | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year" | Terms match the ad and the band | `[grounded]` ad and offer | Who covers my queries in the first month? | noted |
| RR3 | Contract terms not stated | unknown | — | "starting on a date we agree once your notice period ends" | Probation, notice and pension terms may not yet be in writing | `[inferred]` from the offer's silence | Will a written contract with probation and notice terms come before I resign? | unresolved |
| RR4 | Systems and pension handling not named | unknown | — | "process starters, leavers and pension changes" | They may expect you to take on pensions from day one | `[inferred]` from the ad's silence on training | Which payroll system do you use, and who handles pension changes today? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the bank, PPS and passport requests as routine: they follow a written offer naming the role and pay, and payroll needs them to pay and register you | See RR2; the "never hand these over" caution is for requests made before an offer or by chat | `[generic]` normal Irish onboarding | pending your approval |
| A2 | Enter the details only in the employer's own portal, at the web address shown on Marrowgate's own website, rather than by email attachment or a link sent separately | The one check that matters for onboarding | `[generic]` onboarding practice | pending your approval |
| A3 | Ask RR3's question and get terms in writing before you resign | See RR3 | `[grounded]` register | pending your approval |
| A4 | Ask RR4's question to Declan Garvagh, framing pensions as something you'd like to learn | See R10, R5 | `[grounded]` R10 row | pending your approval |
| A5 | Reply to accept inside the five working days | The offer sets that window | `[grounded]` offer email | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have confirmed the employer and live posting (RR1) |
| 2. Role-family sweep | unavailable | The search was refused. It would have set a market pay band for role reality |
| 3. Hiring manager's public footprint | unavailable | The search on Declan Garvagh's public professional profile was refused. It would have informed the plan's positioning |

I can write up this assessment as `tuesday-dossier.md` if you want it kept.

## Upgrade menu

- Search access, so targets 1–3 can run → RR1 closes and role reality gets a market pay band.
- Your answer on pay floor and office days → R1 and R2 close.
- A sanitised payslip or Revenue submission screen → R5 moves toward `direct` at `high`.
- Their written contract → RR3 closes.

Questions:

R1/R2 — Are €40,000 and two office days a week in Limerick within what you need, and is there a floor or a commute limit that would change that?
G2 — Was your hotel group's payroll under Irish PAYE, PRSI and USC?
G1 — How would you feel about taking on pension changes with training, and is that something you'd ask for in writing?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.