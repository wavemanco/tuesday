I'm reading the rest of the assessment format rules. After that I'll write up the verdict.
## Decision snapshot

**No, don't go ahead. R1 (the pay floor) can't be confirmed, and four demands in these messages are marked `severity: high` (RR1, RR2, RR3, RR4). This job is very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

R1 — the posting gives only an "up to" rate; R5 — not yet asked.

**Opportunity ledger.** RR1, RR2, RR3 and RR4 are demands made of you, and each is quoted from the messages. RR5 and RR6 leave the employer unverified, and RR7 leaves the pay terms open.

- **Hard gates:** none failed; unconfirmed: R1 (at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** the demands for payment, a cheque deposit and pre-offer details would have to be withdrawn. The employer would also have to be established independently, and you would need a written offer from an address on its own website that states a rate meeting your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. I could not attribute it to a real employer from here | `[grounded]` my search for the name returned nothing |
| Mandate | Process orders remotely, paid hourly plus commission per order | `[grounded]` posting |
| Pay | "up to €26 an hour plus commission", 15–30 hours a week. At €26 an hour, €30,000 a year needs about 22 hours every week of the year (30,000 ÷ 26 ÷ 52). That is only reachable at the top rate | `[grounded]` posting; `[inferred]` arithmetic |
| Hiring process | Wholly on Telegram, "no calls or video interviews" | `[grounded]` posting |
| First 90 days and first year | Not stated | `[grounded]` posting silent |
| Market calibration | A 2026 Irish survey (n=1,140) puts salaried order-processing and customer-operations coordinators at a median of €31,200 (interquartile range €28,400 to €34,100). It excludes commission-only and freelance work, so it is a band to expect, not this employer's offer | `[generic]` Pennoral 2026 pay guide |
| Contradictions | "No experience needed" sits beside a top rate. At the posting's maximum of 30 hours, that rate comes to about €40,560 a year (26 × 30 × 52), above the survey's upper quartile | `[inferred]` arithmetic against `[generic]` band |
| Unknowns | Employment type, guaranteed rate, commission terms, who you would work for | `[grounded]` posting silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Earn at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your constraint, which you stated. Fit is `unclear` because "up to" gives no guaranteed rate and the commission is undefined (RR7) | `[grounded]` your statement; posting wording | Written rate and contract terms (RR7) |
| R2 | Strong attention to detail | must_have | direct | medium | none | Three years handling about 60 Zendesk tickets a day and keeping a weekly team tracker. This is self-reported and has no artifact yet | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You maintain the team's weekly Excel tracker. Depth of Excel skill is unstated | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling all day and training two starters | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` your account silent | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Quiet workspace (R5, important) | discovery | Nothing stated | Only matters if a verified role exists | Any current remote or hybrid setup | A one-line description | `[grounded]` no information given |
| G2 | Pay against your floor (R1, hard_gate) | hard_gate | An "up to" rate, hours of 15–30, commission undefined | The floor can't be tested against a ceiling | Not applicable | A written, guaranteed hourly rate and contract type from a verified employer address | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A payment is requested before any offer or wages. Requests like this are a known scam pattern. The sender's identity is unresolved | `[generic]` pattern; `[grounded]` quote | Can you confirm in writing, from an address on your company's website, that new hires pay €349 for equipment, and who the equipment partner is? | confirmed |
| RR2 | Cheque deposit, then onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can be credited and later returned unpaid, leaving you owing what you sent on. Requests like this are a known scam pattern | `[generic]` pattern; `[grounded]` quote | As RR1: same route, same hold | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details were asked for before any written offer naming the role and pay | `[grounded]` quote and sequence | As RR1: same route, same hold | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the offer both happened only in chat. This sign is checked by asking for a live interview through the employer's own site | `[grounded]` posting and messages | Can I have a video or phone interview with someone named on your company website? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this firm | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | HR contact on a mail-service address | risk_signal | low | "email velloway.hr@postmail.example" | The address appears to be on a general mail domain rather than one the firm owns. I haven't confirmed that, so I've taken the lower severity | `[inferred]` from the address against the firm's name | Can you write to me from an address on your company's own domain? | unresolved |
| RR7 | Pay terms open | unknown | — | "Earn up to €26 an hour plus commission on every order" | The "up to" rate may not be the rate paid, and the commission is undefined | `[inferred]` from "up to" against silence on the base rate | What is the guaranteed hourly rate, the commission rate and the contract type? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't pay the €349 and don't lodge the cheque. Don't send your IBAN, PPS number or passport photo, and don't paste your IBAN anywhere in the chat | RR1, RR2, RR3 | `[grounded]` register | recommended |
| A2 | If the cheque arrives, don't lodge it. If you ever lodge one and have sent money on, call your bank straight away | RR2 | `[generic]` pattern | recommended |
| A3 | Stop replying in the Telegram chat and keep the messages | RR4 | `[grounded]` register | recommended |
| A4 | Report the posting to the jobs site you found it on | RR1–RR4 | `[generic]` how job sites handle reports | recommended |
| A5 | Put your effort into other openings in customer operations or order processing. Look for ones with a stated annual salary and a live interview. Lead with your 60 tickets a day, training two starters and the Excel tracker | R2, R3, R4 against your €30,000 floor | `[grounded]` your CV; `[generic]` survey band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics", which returned no results. Role reality's organization row and RR5: employer not established |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Market calibration `[generic]` and the contradictions row |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named, only a chat handle, so there was no query to form |

One sentence on next steps: I can save all of this as a `tuesday-dossier.md` for you if you'd like to keep it.

## Upgrade menu

- A link to the posting on the jobs site, or a company registration number you find in an official register → RR5 and the employer row.
- A written offer from an address on the firm's own website, stating rate, hours and contract type → R1 and RR7.
- A deeper diligence and recent-news sweep (up to 5 more searches and 2 more fetches) → RR5. Say so if you want it run.

**Questions**

1. (RR2, RR3) Have you sent or paid anything so far (your details, a passport photo, the €349), or has the cheque arrived?
2. (RR5) Which jobs site was the posting on, and can you paste the link?

Answer in a line each, say "skip", or tell me to go on with what I have.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.