# Job Underwriting Assessment: Product Designer, Fernquay

## Decision snapshot

**Yes, worth pursuing. Nothing in the posting or the WhatsApp message asks you for money or personal details, but I can't establish Fernquay from here, so check it before you invest more. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (First designer on the team), R9 (Research calls with school owners)
- `preferred`: direct: R10

R7 — a credible bridge from your checkout redesign, its limit named; R8 — you have never been the only designer, the limit that matters most; R9 — usability sessions are not owner interviews.

**Opportunity ledger.** The employer is not established from here (RR1). Equity terms and what support a sole designer gets are still open (RR3, RR2). The posting states its pay and hybrid terms plainly (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and the live posting verify through its own site (RR1); (2) the pay clears your floor (R2); (3) the answer to RR2 shows how design work gets reviewed, and you present R8 honestly as a limit.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools; not corroborated by any page of its own | `[grounded]` JD as stated; no page of its own was read |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` JD |
| Working with | Co-founder Ronan Kehoe; the call also includes Saoirse, the CTO | `[grounded]` JD, WhatsApp message |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` JD |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; vesting and share terms not stated | `[grounded]` JD |
| Market calibration | Not calibrated: the role-family search was refused, and model memory is not a source for pay figures | — |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Your pay floor; equity terms; who reviews design work; how decisions are made when design and engineering disagree; stage and funding | `[grounded]` JD and message silent |
| Contradictions | None between the posting and the message, but both come from the company itself, so neither checks the other | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days work on the facts given. Intake prose, so `medium` | `[grounded]` your message, JD | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the range. You haven't given a floor, so whether it clears your constraint is not established. Confidence is `none` because there is no stated constraint of yours to grade | `[grounded]` JD states the range; your floor absent | Question G1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company clears the stated minimum. Self-reported, nothing inspected | `[grounded]` your background | A portfolio link would raise it to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. "Strong" is something a portfolio file shows | `[grounded]` your background | A portfolio link would raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers is research you ran. It is usability testing, which is why the owner-interview duty sits separately at R9 | `[grounded]` your background | A discussion guide or findings summary would raise it to `high` |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a checkout flow at a travel-booking company, which is adjacent to owning the whole flow. What you personally owned, and how much of the flow sat outside checkout, is not established | `[grounded]` your checkout redesign; `[inferred]` the `must_have` tier, from the JD's first duty | Question G2 below |
| R8 | First designer on the team (no design peers) | important | adjacent | medium | transferability | Four years in a squad and a redesign you led carry over. The limit is that you have never been the only designer, so your work has not run without design peers. First-designer posts also tend to mean setting up how design gets done | `[grounded]` your statement; `[generic]` the tendency | Question G3 below |
| R9 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were usability sessions with a travel-booking firm's customers. Talking with small-business owners about how they run their schools is different work | `[inferred]` from the JD's duty against your sessions | Gap queue G4 |
| R10 | Prefers one messy real project to a polished deck | preferred | direct | medium | none | Ronan's message says they liked your checkout case study. That is their statement as you relayed it, not something I inspected | `[grounded]` the WhatsApp message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R2, hard_gate) | hard_gate | The range is stated; your floor and other non-negotiables are not | An unmet pay term would end this regardless of fit | Your lowest acceptable base salary, and whether equity counts toward it | Your own figure | `[grounded]` JD range, floor absent |
| G2 | Booking flow ownership (R7, must_have) | discovery | A checkout redesign; scope of ownership unclear | It is the core mandate in the posting | Owning the steps before checkout (search, selection, basket); deciding scope rather than receiving a brief; taking the flow from research to shipped | Your case study, a before-and-after flow, a scope note | `[grounded]` your summary; `[inferred]` the weight, from the JD's first duty |
| G3 | Working as sole designer (R8, important) | transferability | Squad work only | Sole-designer work is the main limit on this application | Freelance or side projects; stretches covering for absent designers; setting up a component library or a review habit | A side-project link or a freelance brief | `[grounded]` your statement |
| G4 | Owner interviews (R9, important) | transferability | Usability sessions only | The posting names these calls as a duty | Customer-discovery calls with business users; speaking with operators or suppliers | A discussion guide or findings summary | `[inferred]` from the JD's duty |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. The searches I tried were refused, and you report finding little online | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Sole-designer support unstated | unknown | — | "You would be our first designer" | Design work may get no review, and design and engineering priorities may be settled informally | `[inferred]` from the posting's silence on review and decision rights | Who reviews design work here, and who decides when design and engineering priorities conflict? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may come without vesting, cliff or share-class terms | `[generic]` equity terms vary; `[grounded]` the posting gives no terms | What are the vesting schedule, cliff and share class behind the equity? | unresolved |
| RR4 | Pay, hybrid terms and scope stated plainly | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | The posting commits to figures and working pattern, and the message names two people and cites your case study | `[grounded]` JD and message | How is the offer within the range decided? | noted |

I'm going only on what you've shared, and I can get this wrong. Nothing in either message asks for payment, a cheque or personal details, so this is about the employer not yet being established, not about a request. Do the RR1 check yourself before you invest more. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp scheduling as routine. Find Fernquay's own site, then check that the emailed invite came from an address on that domain | see RR1 | `[generic]` arranging a video interview by chat is a common step | pending your approval |
| A2 | Before the call, read the company's own site and the public professional backgrounds of Ronan and Saoirse | see RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Ask the register's questions (RR1 to RR4) verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Lead with the checkout case study and say plainly what you owned and what the squad did. Present sole-designer work as a limit you haven't yet faced. Describe your research as usability sessions with customers, not owner interviews | see R7, R8, R9 | `[grounded]` your own sentences | pending your approval |
| A5 | Prepare for the 45-minute call with Ronan and Saoirse, which mock-interview covers | The call is already scheduled | `[grounded]` the WhatsApp message | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers"; both refused. It would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland first designer startup Galway 2026"; refused. It would have moved the market calibration row and the pay check on R2 |
| 3. Hiring manager's public footprint | unavailable | Searched for the co-founder named in the message; refused. It would have moved the scope read and A4's positioning |

I did not retry the refused searches.

I can save this as a `tuesday-dossier.md` for interview prep if you'd like.

## Upgrade menu

- A link to Fernquay's own careers page or the live posting would close RR1, lift the cap and likely move this to `go`.
- Your pay floor and any other non-negotiables would settle R2 and the hard-gate checks.
- Permission to run web searches would let me run the three research targets above.
- A portfolio link or the checkout case study would move R3, R4 and R5 toward `high`. A usability-session discussion guide or findings summary would help R5 most.
- The sender's address on the emailed invite would let you apply the check in A1.

G1 — What is the lowest base salary you would accept, and is anything else non-negotiable (days in the office, contract type)?
G2 — In the checkout redesign, what did you personally own, and did your work touch steps before checkout?
G3 — Have you ever been the only design voice on something, such as a freelance job or side project, where nobody reviewed your work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.