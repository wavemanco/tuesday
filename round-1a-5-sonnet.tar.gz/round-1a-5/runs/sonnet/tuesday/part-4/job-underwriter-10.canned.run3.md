Searches are back and the company checks out. I'm now fetching the careers page to compare it with your posting, then I'll write up the assessment.
## Decision snapshot

**Yes, it's worth taking the call, and I could establish the company from what I could check (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6, R7a · adjacent: R7b (Owning the flow as sole designer)

R7b — a credible bridge, its limit named; R2 — waiting on your pay floor.

**Opportunity ledger.** The company is established and its pages agree with the posting (RR1), and the posted pay sits inside the market range I found (RR5). Equity terms (RR2), the revenue behind six salaries (RR3) and design support for a first designer (RR4) are still open.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posted pay clears your own floor — R2; (2) the equity terms and the customer base check out on the call — RR2, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` "About Fernquay" page, seen as a search result |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` your posting |
| Working pattern | Hybrid, two days a week in Galway. The careers page says the same | `[grounded]` careers page, fetched |
| Pay | €52,000–€60,000 plus 0.5–1% equity. The careers page says "plus equity" and gives no percentage | `[grounded]` posting and careers page |
| Market calibration | A 2026 Irish salary report puts product designers with 3 to 5 years at a median base of €57,000, with an interquartile range of €51,500 to €62,000. The posted band sits inside that range. This is the market band, not Fernquay's offer | `[generic]` one search; I saw only the report's snippet and did not open it |
| Scope read | Three duties on one product area, with a first-design-hire framing, so the scope is narrow in surface and wide in discipline | `[inferred]` from the posting's duties against its team size |
| Your main contact | Ronan Kehoe's public profile reads co-founder and CEO, and before that five years as product lead at a Galway travel-software company. That is near your own booking-flow background | `[grounded]` profile seen as a search result; `[inferred]` that this makes the booking-flow work familiar to him |
| Unknowns | Equity terms, how many schools pay, who reviews your work, what Saoirse's part in the call is | — |
| Contradictions | None between the posting and the careers page. The page just doesn't state the equity percentage | `[grounded]` careers page, fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days fit where you live. You haven't stated a commute limit | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so the band can neither meet nor fail it yet. The band sits inside the range in the salary report | `[grounded]` posting band; `[generic]` market band | Ask G1: is the band at or above your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, which is self-reported with no portfolio inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. Daily use is confirmed; "strong" is not shown by anything I have inspected. Ronan says they liked your checkout case study, which I haven't seen | `[grounded]` your background and the WhatsApp message | none |
| R5 | You have run your own user research | must_have | direct | medium | discovery | You ran monthly usability sessions with customers. The role also names research calls with school owners, and I can't tell from this whether you've run discovery interviews as well as usability tests | `[grounded]` your background; `[inferred]` the usability-versus-discovery gap from the posting wording | Ask G2 |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7a | Own the booking flow: the design work | must_have | direct | medium | none | You redesigned your company's checkout flow in a travel-booking product | `[grounded]` your background | none |
| R7b | Own it end to end as the first and only designer | must_have | adjacent | medium | transferability | Your work was inside a squad, and you've never been the only designer. The limit is that no earlier role had you working without a design peer | `[grounded]` your background; `[inferred]` requirement from "You would be our first designer" | Ask G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | The band is posted; your floor isn't known | A gate nobody has checked can't be called met | Your own pay floor, and any other terms you won't trade | None needed beyond your statement | `[grounded]` posting; your floor is not in what you shared |
| G2 | Discovery research with school owners (R5, must_have) | discovery | Monthly usability sessions are confirmed. Open-ended interviews with customers about their needs are not mentioned | Research calls with school owners are a named duty, so the difference between usability testing and discovery will probably come up | Interviews before a design existed; calls to understand why customers booked or didn't; synthesis notes you shared with the squad | A research summary, a discussion guide, or a synthesis deck | `[grounded]` background silent on discovery; `[generic]` that this role family probes the difference |
| G3 | Working as the only designer (R7b, must_have) | transferability | Strong squad experience; no stretch as the sole designer | It is the one must-have row below `direct`, and the posting makes it the whole job | A project where no other designer reviewed your work; setting your own research plan or priorities; a period covering for another designer | A case study showing your decisions with no design peer, or a note on who reviewed it | `[grounded]` your statement; `[generic]` that first-designer roles hinge on this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer is established and matches its posting | positive_signal | — | "Six people, based in Galway" | A real small company whose own pages match your posting | `[grounded]` about page seen as a search result; careers page fetched | Who besides you and Saoirse will I meet in the process? | noted |
| RR2 | Equity percentage without terms | unknown | — | "plus 0.5–1% equity" | The range may come without vesting, grant type or share count, which decide what it is worth. The careers page says "plus equity" with no percentage | `[grounded]` careers page; `[generic]` that equity value depends on those terms | What is the vesting schedule, what type of grant is it, and how many shares are in issue today? | unresolved |
| RR3 | Revenue behind the payroll is unknown | unknown | — | "funded by its customers" | With no outside funding, the number of paying schools sets how secure the salaries are | `[inferred]` from the about page's funding line | How many schools pay for Kelproster today, and how many months of payroll does that cover? | unresolved |
| RR4 | First designer, no design lead | risk_signal | low | "You would be our first designer" | You may have no senior designer for feedback or for settling design-versus-engineering disputes | `[inferred]` from the first-designer wording | Who reviews my design work, and who decides when design and engineering disagree? | unresolved |
| RR5 | Posted pay inside the market range | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The band is in the usual range for 3–5 years, so it doesn't look low for the level | `[grounded]` posting; `[generic]` salary report seen as a snippet only | How is pay reviewed as the company grows? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call. Scheduling an interview over WhatsApp at a six-person company is routine, and this message asks for no money and no personal details. Before the call, confirm the invite email came from a fernquay.example address and the video link opens a normal meeting | The message asks only for a 45-minute video call; I can't see the email | `[grounded]` the message; `[generic]` that founders often schedule over chat at this size | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions, in your own words. They are the two things you've told me that match the posting most closely | See R7a, R5 | `[grounded]` your background | pending your approval |
| A3 | Say plainly that you've worked in a squad and never as the only designer, then speak to how you would work without a design peer. Don't claim sole ownership you haven't had | See R7b | `[grounded]` your statement | pending your approval |
| A4 | Ask the questions from RR2, RR3 and RR4 on the call, in the words shown in the register | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Settle your own pay floor before the call | See R2 | `[grounded]` R2 | pending your approval |

Prep for the call with Ronan and Saoirse is mock-interview's job. Ask and I'll run it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay careers product designer Galway". Fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization row and contradictions row, and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup first designer", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), seen as a snippet only. Moved the market calibration row, R2's reasoning and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), seen as a snippet only. Moved role reality's contact row and the plan's positioning in A2 |

If you'd like, I can save this as `tuesday-dossier.md` so a later step can pick it up.

## Upgrade menu

- Your pay floor and any other non-negotiables → R2 resolves and the hard-gates line stops flagging unchecked constraints.
- Your checkout case study as a Figma file or published page → R4 moves toward `high`.
- A research summary or discussion guide → R5 moves toward `high`.
- The equity terms and a customer count from Ronan → RR2 and RR3 close.
- A deeper research pass on Fernquay (customer reviews, funding and news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Is €52,000–€60,000 at or above your pay floor, and is there any other term you wouldn't trade?

G2 — Have you run interviews with customers before a design existed, not only usability tests? What did you own, and what changed because of it?

G3 — Was there a project where you were the only designer on the work, or where no other designer reviewed it? What did you decide on your own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.