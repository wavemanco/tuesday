Two searches done, and I've read the pay guide excerpt. Here is the assessment.

## Decision snapshot

**No, I wouldn't go ahead, and I can't establish the firm from here. Status: `no_go`.** RR1, RR2, RR3 and RR4 are confirmed severe red flags.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2 · adjacent: R3 (Good written English), R4 (Strong attention to detail)
- `important` — unclear: R5 (A quiet place to work)

R2 — her Excel tracker lines up; R1 (`high`) — her floor is confirmed, and the posting gives only a ceiling to check it against.

**Opportunity ledger.** The messages ask for equipment payment, a cheque to lodge and forward, and ID and bank details before any offer. The hiring is also run wholly in chat (RR1, RR2, RR3, RR4). The requests in these messages (RR1, RR2, RR3) are very likely a scam, so pay and send nothing yet. The sender's address (RR5) and the firm itself (RR6) can't be established from here, and the pay beyond "up to" is unstated (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the requests for money, the cheque and ID details withdrawn. The hiring and a written offer would also have to come from an address on the employer's own website, and the employer would have to be verifiable there.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. My search on the name returned no results, so the firm is not established | `[grounded]` search returned nothing attributable |
| Mandate | Remote order processing, with spreadsheets and written English | `[grounded]` posting |
| Pay and hours | "Up to €26 an hour plus commission", 15–30 hours a week. Over 52 weeks the ceiling is €20,280 at 15 hours and €40,560 at 30. Base rate and commission rate are not stated | `[grounded]` posting; `[inferred]` the annual figures by arithmetic |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | A 2026 Irish pay guide gives salaried order-processing and customer-operations coordinators a median base of €31,200 (interquartile range €28,400–€34,100). It leaves out commission-only and freelance work, so the posting isn't directly comparable. The median is roughly €15–€16 an hour at a 37.5–40 hour week | `[generic]` one search, guide excerpt only, not fetched; `[inferred]` the hourly figure |
| Unknowns | Employer identity, base rate, commission rate, contract type, who sent the messages | — |
| Contradictions | None checkable: no careers page or live posting could be found | `[grounded]` search returned nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because the posting gives only a ceiling, so reaching €30,000 depends on rate and hours it doesn't commit to | `[grounded]` your statement and the posting; `[inferred]` annualised figures | Employer states base rate and hours in writing (RR7) |
| R2 | "Confident with spreadsheets" | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. This is your own account, with nothing inspectable yet | `[grounded]` your background | none |
| R3 | "Good written English" | must_have | adjacent | medium | transferability | Zendesk work at about 60 tickets a day is plausibly written, but you didn't say which channels. Limit: ticket volume isn't evidence of writing quality | `[grounded]` your background; `[generic]` that ticket tools handle written contact | none |
| R4 | "Strong attention to detail" | must_have | adjacent | medium | transferability | Daily volume, training two starters and a tracker point the right way. Limit: no accuracy or error measures were given | `[grounded]` your background | A QA or accuracy report would raise it |
| R5 | "A quiet place to work" | important | unclear | none | discovery | Your message doesn't say | `[grounded]` silence in your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | Ceiling only: "up to €26 an hour", 15–30 hours | Until a guaranteed rate and hours are in writing from the employer, the gate stays unconfirmed | Not applicable; this is the employer's term to state | A written offer from the employer's own domain | `[inferred]` from the posting's ceiling |
| G2 | Attention to detail (R4, must_have) | transferability | Volume and training evidence, no accuracy figures | Only relevant to roles you'd actually pursue; it doesn't move this decision | Quality scores or audits on your tickets; error-checking on the tracker | A QA report or a sanitised tracker sample | `[grounded]` your background; no outside claim |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | This request is very likely a scam; don't send them. Who sent these messages, and whether the employer named is involved, is unresolved | `[grounded]` the message, asked before any offer | Do you ask candidates for bank, PPS and passport details over Telegram before a written offer? Ask the employer through contact details you find yourself on its own website, never the chat or address these messages came from | confirmed |
| RR2 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam; don't pay | `[grounded]` the message | Do you require candidates to pay for equipment? Route as RR1 | confirmed |
| RR3 | Cheque to deposit and forward | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam; don't deposit the cheque | `[grounded]` the message | Do you send new hires cheques to forward onward? Route as RR1 | confirmed |
| RR4 | Hiring run wholly in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | The interview and offer happened only in chat, so nothing can be checked independently; the messages may not come from who they name | `[grounded]` posting and messages; `[inferred]` the checkability point | Can the interview and written offer come from an address on your own website, with a call to a number listed there? Route as RR1 | confirmed |
| RR5 | Contact address | risk_signal | medium | "email velloway.hr@postmail.example" | The address may not belong to the employer named in the posting | `[inferred]` from the domain not being one named for the firm | Is this address yours? Route as RR1 | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Pay structure vague | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process." | The base rate and commission may be well below the ceiling | `[inferred]` from the ceiling against the `[generic]` band in role reality | What is the guaranteed hourly rate and the commission per order, in writing? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send the passport photo, PPS number or IBAN (keep yours unpasted); pay nothing; deposit no cheque | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Look the firm up yourself (company registers, its own site) and contact it only through details you find there | see RR6, RR5 | `[grounded]` register | pending your approval |
| A3 | If a cheque arrives anyway, don't lodge it | A cheque can be credited and later reversed, leaving you liable for what you forwarded | `[generic]` how cheque clearing works | pending your approval |
| A4 | Report the posting to the jobs site you found it on | see RR1–RR4 | `[generic]` common site practice | pending your approval |
| A5 | Aim at salaried customer-operations or order-processing roles, where your Zendesk volume, training two starters and the Excel tracker are the evidence and the median clears your €30,000 floor | see R2–R4, role reality | `[grounded]` R2–R4; `[generic]` pay band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official site careers"; no results, so the firm is not established. Moved RR6 and role reality's organization and contradictions rows |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), excerpt only. Moved market calibration, RR7 and A5 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a chat handle, so there was no query to form |

If you'd like, I can save this as `tuesday-dossier.md` for later use.

**Upgrade menu**

- The jobs site and the link to the posting, plus the firm's own website if you find one independently → RR6 and role reality's contradictions row.
- A written offer from an address on the employer's own website, with base rate and hours → R1 and RR7 close.
- A QA report or a sanitised sample of your weekly tracker → R3 and R4 move toward `high`.
- A named hiring contact → target 3 can run.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.