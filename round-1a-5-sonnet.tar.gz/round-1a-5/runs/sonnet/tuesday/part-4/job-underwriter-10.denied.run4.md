The web searches weren't permitted, so this assessment runs on what you pasted. Nothing below comes from outside research.

## Decision snapshot

**Yes, worth applying to, on conditions. R2 (pay against your floor) is unconfirmed and RR1 (Fernquay not yet established) is open. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52–60k plus equity)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer, no peer designer)

R6 — a credible bridge, its limit named; R8 (`low`) — adjacent, resting on your own statement that you've never been the only designer; R2 — waiting on your pay floor.

**Opportunity ledger.** The posting is specific about pay, scope and process (RR3). The posting and the message make no request for money, a cheque, or bank or ID details, and scheduling by WhatsApp is routine, so the register has no entry for it. What is open is that Fernquay can't be established from here (RR1), the equity terms are unstated (RR2), and funding and runway are unknown (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52–60k plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a live hiring employer — RR1; (2) pay and equity terms meet your floor — R2, RR2; (3) the step up to sole designer is framed honestly as adjacent, never as experience you have — R6, R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools. Your own search found little | `[grounded]` JD self-description and your message; not independently confirmed |
| Role | First product designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` JD |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Working pattern | Hybrid: two days a week at the Galway office, the rest flexible | `[grounded]` JD |
| Process | A 45-minute video call with Ronan and Saoirse (CTO), invite by email; the JD prefers "one messy real project" to a polished deck | `[grounded]` JD and WhatsApp message |
| Scope read | A sole-designer post with product, research and delivery in one seat, and no design lead above it | `[inferred]` from "first designer" and "own ... end to end" |
| Market calibration | Not run, so no pay band is given | — (research did not run) |
| Unknowns | Equity terms; funding and runway; what success looks like at 6 or 12 months; how many school owners are available for research calls | `[grounded]` JD silence |
| Contradictions | None between the JD and the message. Both refer to the checkout and booking flow, and the CTO is named only in the message | `[grounded]` JD and message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are within reach. You haven't stated a preference on office days, hence `medium` | `[grounded]` your background and the JD | none |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity, against your floor | hard_gate | unclear | none | hard_gate | The posting states the figures. You haven't given a floor, so whether the pay meets your terms isn't established, and the equity terms are unstated (RR2) | `[grounded]` JD figures, your floor absent | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. This is your own account, with no inspectable artifact yet | `[grounded]` your stated background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is your own account. "Strong" is judged from work, and none has been inspected | `[grounded]` your stated background | A Figma file or case study would raise it |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Their limit: the role's research calls are with school owners, a different audience and likely discovery rather than usability testing | `[grounded]` your statement; `[generic]` the usability-versus-discovery distinction | Notes or a write-up from a session would raise it |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow. Limit: checkout is one stage of a booking flow, so what came before it isn't established | `[inferred]` adjacency from the checkout redesign you described | G2 |
| R7 | Work directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your stated background | none |
| R8 | Be the first designer, with no peer designer | important | adjacent | low | transferability | You've never been the only designer. The adjacent work is a redesign and research sessions done inside a squad. Limit: nothing shows you setting up process without peers | `[grounded]` your statement; `[inferred]` adjacency | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R2, hard_gate) | hard_gate | The range and equity are stated, but I don't have your minimum or whether equity counts toward it | A gate the inputs don't settle caps the decision, and it is the cheapest one to settle | Not experience: your own number, and whether it is cash only | None needed | `[grounded]` floor not given |
| G2 | End-to-end booking flow (R6, must_have) | transferability | Checkout redesign confirmed. Steps before and after payment are not described | Owning the whole flow is the post's core remit | Search or availability, date and time picking, add-ons, confirmation and reminder emails, cancellation and rebooking, mobile | Your checkout case study, which Ronan says he has read, or a flow map | `[grounded]` your statement and his message; `[generic]` what a booking flow usually spans |
| G3 | First designer (R8, important) | transferability | Squad-based work only | A sole-designer seat has no peer review and no design lead. No question this turn, since this answer is less likely to move the decision than G1, G2 or RR1 | Setting a pattern library, running a design critique, or choosing what not to design | Any file you structured for others to reuse | `[inferred]` from the JD's "first designer" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The stake's worth depends on the instrument, vesting and share count, none of which the posting gives | `[grounded]` posting silent; `[generic]` these terms decide what equity is worth | Is the equity options or shares, on what vesting schedule, and what share count does the percentage refer to? | unresolved |
| RR3 | Pay and process stated plainly | positive_signal | — | "we would rather see one messy real project than a polished deck" | Hiring is transparent and low-friction, and success is probably judged on real work | `[grounded]` JD states pay, scope and process | What does success look like in this role at six months? | noted |
| RR4 | Funding and runway not stated | unknown | — | "We are six people in Galway" | A six-person team may have limited runway, which affects both salary and equity | `[generic]` small-company pattern, not a claim about this one | How is Fernquay funded, and how many months of runway does the current plan cover? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Fernquay's own website yourself. Check that the calendar invite came from an address on that website's domain and that the video link opens on a known service. A WhatsApp message plus an emailed invite is routine for small firms | RR1 | `[generic]` small-firm scheduling pattern | pending your approval |
| A2 | In the call, ask RR1, RR2 and RR4 verbatim, and put RR3's question to Ronan | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | Settle your pay floor before the call, and decide whether equity counts toward it | R2, G1 | `[grounded]` R2 | pending your approval |
| A4 | Proposed wording for the call: "I redesigned the checkout flow at a Dublin travel-booking company, ran monthly usability sessions with customers, and worked in a squad with four engineers. I haven't been the only designer before." Do not say "owned", "led" or "end to end", because your own sentences don't | R5, R6, R7, R8; audited clause by clause against your message | `[grounded]` your own sentences | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused because search permission wasn't granted here. They would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | One search was refused. It would have moved the market calibration row and the pay check against R2 |
| 3. Hiring manager's public footprint | unavailable | One search on Ronan Kehoe's public professional footprint was refused. It would have moved the scope read and what A4 leads with |

Fernquay is not established, and not disproved either: no search ran. A link to the live posting, the company's own careers page, or the invite's sender domain would settle it.

I can save this as a `tuesday-dossier.md` that the mock-interview module can use to prepare you for the call with Ronan and Saoirse.

**Upgrade menu**

- Search permission, or Fernquay's website and careers link: runs or replaces the three targets above, and settles RR1.
- Your pay floor and whether equity counts toward it: closes R2.
- Your checkout case study or a Figma file: could raise R4, R5 and R6, and narrows G2.
- Ronan's public profile link: informs the scope read and the call preparation.

**Questions**

G1 — What is the minimum salary you would accept, and would equity count toward it or only cash?

G2 — In the checkout redesign, which steps before payment (search, date picking, add-ons, confirmation emails) did you also work on, and what did you decide yourself versus the team?

RR1 — Where did you find the posting (a link, if you have one), and does the sender domain of Ronan's calendar invite match Fernquay's own website? Please don't paste the address itself, just whether it matches.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.