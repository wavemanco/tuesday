I've finished reading the job-underwriter playbook and its reference files. Next I'll check both employers and the role-family norms with a few web searches, then write the assessment.
**Femi, Duinvaart is worth your time and Kroonhaven isn't.** Here is the full assessment. The web searches I tried were refused, so I couldn't check either employer. That is accounted for under Evidence status.

## Decision snapshot

**Duinvaart Cold Chain, Operations Analyst: worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: A7 (Hybrid, three days in Rotterdam)
- `must_have`: direct: A1, A2, A3, A4a · adjacent: A4b (Temperature compliance on the refrigerated fleet)
- `important`: direct: A5
- `preferred`: adjacent: A6 (Dutch a plus)

A4b is a bridge with its limit named; A7 is unsettled until you confirm the commute.

**Opportunity ledger.** The scope is concrete (RA3). The employer is unchecked (RA1), the pay is not stated (RA2), and the office days are untested against your situation (RA4).

- **Hard gates:** none failed; unconfirmed: A7 (Hybrid, three days a week in Rotterdam); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) A7 and RA4 confirmed workable for you; (2) A4b framed as adjacent, never as cold-chain experience; (3) the employer and posting verified, per RA1.

**Kroonhaven Foods, Supply Planner: not worth applying to. B1, B2 and B5, all `must_have` rows, are absent. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: B7 (On-site in Utrecht)
- `must_have`: adjacent: B3 (Run the weekly S&OP meeting), B6 (Fluent Dutch) · unclear: B4 (Advanced Excel) · absent: B1 (3+ years FMCG supply or demand planning), B2 (Own the 13-week supply plan), B5 (SAP IBP or a similar planning system)

B1, B2 and B5 have no planning evidence behind them; B6 is conversational Dutch against a fluent bar.

**Opportunity ledger.** The role is clearly scoped (RB3). The employer is unchecked (RB1) and the pay is not stated (RB2).

- **Hard gates:** none failed; unconfirmed: B7 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would have to differ:** planning evidence for B1, B2 and B5, and Dutch at fluent level for B6. B7 is not what sinks this role.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart organization | A refrigerated-fleet logistics operator in Rotterdam, as the posting describes it; not verified | `[grounded]` posting text |
| Duinvaart mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Duinvaart working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Duinvaart scope read | An analyst post reporting on fleet performance, close to what you do now; it carries no stated authority over route decisions | `[inferred]` from the verbs "track", "build" and "work with" |
| Kroonhaven organization | A chilled ready-meals food business in Utrecht, as the posting describes it; not verified | `[grounded]` posting text |
| Kroonhaven mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Kroonhaven working pattern | On-site in Utrecht; Dutch fluency required | `[grounded]` posting |
| Kroonhaven scope read | A hands-on planning ownership role, not an analyst role | `[inferred]` from "own" and "run" against the stated requirements |
| Market calibration (both) | Not given. The pay search was refused, so I won't name a band | `[grounded]` search refused |
| Unknowns | Salary for both; Duinvaart's temperature-data source and how flexible its office days are; which Kroonhaven planning system is in use | none |
| Contradictions | None visible in the posting texts; the careers pages were not checked | `[grounded]` posting texts only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. Medium is the ceiling for self-reported background with nothing inspected | `[grounded]` your stated background | none |
| A2 | Strong SQL | must_have | direct | medium | none | You use SQL daily; no sample inspected | `[grounded]` your stated background | none |
| A3 | Power BI or Tableau, weekly dashboards | must_have | direct | medium | none | You use Power BI daily and built the on-time delivery dashboard that depot managers use. Nothing inspected yet | `[grounded]` your stated background | offer: a sanitized dashboard screenshot would raise this to `high` |
| A4a | Track on-time delivery | must_have | direct | medium | none | The same metric you already report on, in the same kind of operation | `[grounded]` your stated background | none |
| A4b | Track temperature compliance on a refrigerated fleet | must_have | adjacent | low | transferability | What carries over is compliance-style monitoring against a standard. The limit: you haven't said you handled temperature data or cold-chain standards. The strengthener is any temperature-controlled or time-critical parcel reporting | `[inferred]` bridge from your delivery-performance work; `[generic]` that cold-chain analyst roles expect some temperature-data familiarity | question Q2 |
| A5 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your dashboard. Limit: you haven't said whether reviews led to route changes | `[grounded]` your stated background | none |
| A6 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is partial credit for a "plus" | `[grounded]` your statement | none; minor |
| A7 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't given your location or limits, so I can't tell whether this term is met. Confidence is `none` because no constraint of yours is on record | `[grounded]` posting term; your constraint not stated | question Q1 |
| B1 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you've never worked in planning. Years of experience is graded as a requirement, not a gate | `[grounded]` your statement | closure path in GB1 |
| B2 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning work is stated, and none sits next to it | `[grounded]` your statement | closure path in GB1 |
| B3 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly cross-functional performance review. Limit: it was a performance review, not a planning cycle that commits supply | `[grounded]` your stated background; `[generic]` that S&OP is a planning forum | none |
| B4 | Advanced Excel | must_have | unclear | none | discovery | Your SQL and Power BI work is stated; Excel is not mentioned | `[grounded]` your stated background is silent on Excel | not pursued; the decision is already settled |
| B5 | SAP IBP or a similar planning system | must_have | absent | none | capability | You've never worked in planning, so no planning system is in your history. Power BI is a reporting tool, not a planning system | `[grounded]` your statement | closure path in GB1 |
| B6 | Fluent Dutch | must_have | adjacent | medium | transferability | You are conversational, not fluent. A meeting you chair in Dutch is a high bar | `[grounded]` your statement | none |
| B7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Same as A7: no constraint of yours on record | `[grounded]` posting term; your constraint not stated | question Q1 covers location |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (A4b, must_have) | transferability | Delivery-performance monitoring; nothing about temperature or cold-chain standards | It is the one part of the Duinvaart posting your background doesn't cover | Reporting on temperature-controlled or time-critical parcels; breach or exception reporting against a standard; telematics or sensor data in a dashboard | A sanitized dashboard screenshot or report excerpt | `[grounded]` CV-style background silent on temperature; `[generic]` that this is the likeliest probe |
| GB1 | Planning ownership and tooling (B1, B2, B5, must_have) | capability | No planning experience, by your own statement | These three absences are why Kroonhaven is `no_go`; no wording of your background closes them | A scoped-down target: a planning-adjacent analyst role at a food or FMCG business, or a short course in the planning system named in the posting | none to ask for now | `[grounded]` your statement; `[generic]` that analyst-to-planner moves usually go through such a role |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Duinvaart not verified; searches refused | unknown | — | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The posting is live and the employer is as described, but I could not check | `[grounded]` searches refused; nothing inferred about the employer | Can you point me to this role on your careers page, and say who I would work with? | unresolved |
| RA2 | Pay not stated | unknown | — | none; the posting gives no figure | The posting withholds pay, or the figure was left out of the text you pasted | `[grounded]` posting silent | What is the salary range for this post? | unresolved |
| RA3 | Concrete scope | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards in Power BI" | The role has defined, measurable deliverables | `[grounded]` posting | Where does temperature data come from today, and how often does it break? | noted |
| RA4 | Three fixed office days against your situation | unknown | — | "Hybrid, three days a week in our Rotterdam office" | Which days are fixed is unknown, and your commute is unknown (see A7) | `[grounded]` posting term | Which days are fixed, and is there any flexibility? | unresolved |
| RB1 | Kroonhaven not verified; searches refused | unknown | — | "Supply Planner — Kroonhaven Foods, Utrecht" | The posting is live and the employer is as described, but I could not check | `[grounded]` searches refused; nothing inferred about the employer | Can you point me to this role on your careers page? | unresolved |
| RB2 | Pay not stated | unknown | — | none; the posting gives no figure | The posting withholds pay, or the figure was left out of the pasted text | `[grounded]` posting silent | What is the salary range for this post? | unresolved |
| RB3 | Clear ownership | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | The role's decision rights are stated | `[grounded]` posting | Who signs off the plan when capacity and forecast disagree? | noted |

## Application plan

Every row is a proposal and waits for your approval, including any wording in the prose above.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | For Duinvaart, lead with: built and maintain the on-time delivery dashboard used by depot managers (SQL, Power BI) | See A3, A4a | `[grounded]` your stated background | pending your approval |
| E2 | For Duinvaart, add: ran the weekly route-performance review with depot managers | See A5 | `[grounded]` your stated background | pending your approval |
| E3 | For Duinvaart, describe temperature compliance only as adjacent: you monitored delivery compliance, and you haven't handled temperature data (unless Q2 changes that) | See A4b | `[grounded]` A4b row | pending your approval |
| A1 | Check Duinvaart's careers page for the live posting before you invest time; the search I tried was refused | See RA1 | `[grounded]` RA1 | pending your approval |
| Q1 | In any Duinvaart interview, ask the verification questions from RA2, RA3 and RA4 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| B-P1 | Kroonhaven: no application edits proposed. If you apply anyway, tell me and I'll build the plan; RB1 and RB2 become essential | See B1, B2, B5 | `[grounded]` B rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches, one per company, were refused. They would have settled RA1 and RB1 and the contradictions row |
| 2. Role-family sweep | unavailable | One pay and scope search was refused. It would have given a market calibration and settled RA2 and RB2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can save this as `tuesday-dossier.md` if you want to carry it into later turns.

**Upgrade menu**

- A sanitized dashboard screenshot or report excerpt → A3 to `high`; GA1 narrows if it shows any temperature or exception reporting.
- Your location and pay floor → A7 and B7 become `direct` or `hard_gate_fail`, and RA2 and RB2 can be set against your floor.
- Search access → the employer checks for both postings and a pay band (3 of 5 searches are spent; 2 remain).
- Links to the live postings or careers pages → RA1 and RB1 close without a search.
- The hiring manager's name for Duinvaart → the scope read and which of your stories to lead with.

**Questions**

- Q1 (A7): Where are you based, and is three days a week in Rotterdam workable for you?
- Q2 (GA1): Have you reported on temperature-controlled or time-critical parcels, or on breaches of any compliance standard?
- Q3 (RA2): Is there a pay floor I should measure Duinvaart's offer against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.