**Yes, it's worth continuing: `conditional_go`.** I couldn't verify Fernquay from here (RR1), and the WhatsApp message is ordinary scheduling. Your own background is a solid fit, with R7 and R8 as the two honest stretches.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have`: direct: R3, R4, R5a, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R5b (Research calls with school owners), R8 (First designer, no design peers)

R7: your checkout redesign is a close bridge, its limit named; R8: squad work is the nearest evidence, with no solo-designer evidence; R2: waiting on your pay floor.

**Opportunity ledger.** The employer isn't established from here (RR1), and the equity terms (RR3) and decision rights (RR4) are unstated. The pay range is stated up front (RR2), and the posting is specific and agrees with itself (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies through a source you find yourself (RR1); (2) the salary clears your floor (R2) and the equity terms are answered in writing (RR3); (3) R7 and R8 are described honestly as adjacent in the call; (4) no payment, equipment purchase, cheque deposit, or bank or ID details are requested before a written offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, described as six people in Galway making booking software for sea-kayak and surf schools. This is the posting's description of itself, not checked | `[grounded]` JD; existence not confirmed (research refused, see Evidence status) |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in the Galway office, the rest flexible | `[grounded]` JD |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Scope read | One flow owned by one designer in a six-person company is a plausible single-designer scope | `[inferred]` from team size against the stated mandate |
| Market calibration | Not done. The salary search was refused, and model memory isn't a source for market values, so €52–60k has no band to sit against | `[grounded]` search refused |
| Contact route | A video call set up by WhatsApp plus an emailed calendar invite is routine scheduling. The message asks for no money, bank or ID details, and no documents | `[grounded]` the message's own text; `[generic]` that scheduling this way is routine for small firms |
| Unknowns | Decision rights, equity terms, first-year outcomes, whether Saoirse (CTO) is one of the "two engineers", funding and runway | `[grounded]` JD and message are silent |
| Contradictions | None between the posting and the message, and your "can't find much online" is consistent with a very small company | `[grounded]` the two texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office is within reach. Committing to two fixed days isn't stated | `[grounded]` your message | none; just confirm the days suit you |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the figure. You haven't given a floor or how you value equity, so it can't be checked against you. Confidence is `none` because no constraint statement exists yet | `[grounded]` JD quote; your side not given | G3 question |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years at a Dublin travel-booking company. No CV or portfolio inspected yet, so expect a probe | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily", though the strength of the work can't be inspected without your portfolio | `[grounded]` your message | a Figma file or case study would raise to `high` |
| R5a | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, which you ran | `[grounded]` your message | none |
| R5b | Run research calls with school owners | important | adjacent | medium | transferability | The bridge is monthly customer sessions. The limit is that these were usability sessions with end customers, while owners are business operators and the calls may be interview-style, which nothing you shared exercises | `[grounded]` your sessions; `[inferred]` that the posting's "research calls" go beyond usability testing | G2 question |
| R6 | Works directly with engineers | must_have | direct | medium | none | A squad with four engineers. Fernquay has two, so the working mode is the same at smaller scale | `[grounded]` your message; `[inferred]` from the JD's "two engineers" | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned checkout at a travel-booking company, which is a close domain match. Checkout is one stage of a booking flow, and the scope you owned around it isn't stated | `[grounded]` your claim; `[inferred]` that checkout is one stage | G1 question |
| R8 | Be the first designer (from "You would be our first designer") | important | adjacent | low | transferability | Bridge: you led a redesign and a monthly research cadence inside a squad. Limit: you have never been the only designer, so there's no evidence of working without design peers or setting up practice from scratch. Strengthener: one small solo project where you made every call, which the posting invites ("one messy real project") | `[grounded]` your message and the JD line | none; see A3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Scope of booking-flow ownership (R7, must_have) | discovery | Checkout redesigned; nothing on the steps before and after it, decision rights, or outcomes | A `must_have` row at `adjacent`; it's the line the posting leads with | Search, date or slot selection, pricing, confirmation emails, changes and cancellations; shaping steps next to checkout; handoff specs to engineers; completion-rate or support-ticket changes | Your checkout case study (they've already seen it), before/after flows, metrics, research notes | `[grounded]` your message says checkout only; `[generic]` that booking roles probe whole-flow ownership |
| G2 | Owner-side research (R5b, important) | transferability | Usability sessions with customers; no business-side conversations | The role's research is with school owners, a different audience from consumers | Calls with operators, partners or suppliers; stakeholder interviews; any discovery-style research plan | A research plan or a synthesis deck, sanitised | `[grounded]` your message; `[inferred]` the audience gap |
| G3 | Pay floor (R2, hard_gate) | hard_gate | Range stated; your floor and view of equity not given | An unconfirmed gate stays visible until you answer; it decides whether the call is worth your time | Your base-salary minimum; whether equity counts toward it | None needed | `[grounded]` JD range; your constraint absent |
| G4 | First-designer experience (R8, important) | transferability | Squad work only, by your own account | The posting's whole premise is that you're the only designer | A solo project, a freelance or side project, a design-system or process you set up | A small real project, messy is fine | `[grounded]` your message and the JD; no question needed, the limit is already named |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools"; your note that you can't find much about them online | The firm may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own website, and who I'll be interviewing with? | unresolved |
| RR2 | Pay and equity stated up front | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The main economic terms are checkable instead of withheld | `[grounded]` JD | Is there room to negotiate within the range? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may rest on a different share base than you'd assume, with vesting, cliff and strike terms the posting doesn't give | `[inferred]` from the posting's silence on terms | What does 0.5–1% represent, and what are the vesting schedule, cliff and strike price? | unresolved |
| RR4 | Decision rights and success measures unstated | unknown | — | "own the booking flow end to end ... ship alongside our two engineers" | You may own the flow while product decisions sit with the co-founder, and year-one success isn't defined | `[inferred]` from the mandate against the posting's silence | Which decisions on the booking flow would I make alone, and what would success look like after a year? | unresolved |
| RR5 | Posting is specific and consistent | positive_signal | — | "run research calls with school owners, and ship alongside our two engineers" | Mandate, team shape, location and pay line up with one another | `[grounded]` JD text | Who owned design decisions before this hire? | noted |

## Application plan

Preparing for the video call itself is a separate job, which mock-interview covers; I haven't done it here.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own website or careers page yourself and check the role is listed there. Check that the emailed invite comes from an address on that same domain. Put nothing sensitive into the video link or the chat beforehand | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | On the call, ask RR1, RR3 and RR4's questions verbatim, and ask where the salary sits within the range | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Honest framing: "I redesigned our checkout flow and ran monthly usability sessions with customers; I've worked in a squad with four engineers and haven't been the only designer." Every clause is yours, and it doesn't claim whole-flow ownership | see R7, R8 | `[grounded]` your own sentences | pending your approval |
| A4 | Settle your salary floor and how much weight you give equity before the call | see R2 | `[grounded]` R2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (company and product; company and the designer role) were refused, so RR1 stays open and role reality's organization row rests on the posting alone |
| 2. Role-family sweep | unavailable | One search (product designer salary, Ireland) was refused. It would have given the market calibration for €52–60k |
| 3. Hiring manager's public footprint | unavailable | One search (the co-founder named in the WhatsApp message) was refused. It would have informed the scope read and which story to lead with |

## Dossier offer

If you'd like, I can write this up as a `tuesday-dossier.md` you can reuse later.

## Upgrade menu

- A link to Fernquay's own site or careers page, or permission to search: RR1 can close or firm up, and the role-reality rows get real sources.
- Your pay floor: R2 resolves, and the salary is set against a market band if search runs.
- Your checkout case study, before/after flows and any outcome numbers: R7 firms up and R3 and R4 can reach `high`.
- The co-founder's name, now that I have it, plus search access: the scope read and the lead story in A3 sharpen.
- A deeper pass on Fernquay (funding, leadership, public reports; up to 5 more searches and 2 more fetches) once search is allowed. Say the word and it runs.

## Questions

G1 — At your last company, which parts of the booking flow around checkout did you personally own, and what changed as a result?

G2 — Did your usability sessions ever include the business side, such as operators, partners or suppliers, rather than only end customers?

G3 — What's the lowest base salary you'd accept, and how do you weigh equity against it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.