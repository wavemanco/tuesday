I've run 4 of 5 searches. Next I'll fetch Calderbrook's careers page to check the posting is live.
# Job Underwriting: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC

## Decision snapshot

**Yes, Aoife, this is worth applying for. R1 and R2 (the gates) and R3 (the one-year minimum) are met on what you've stated, and R4 is the essential item your CV doesn't yet evidence. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R6, R8, R11 · adjacent: R5 (Home-based community nursing), R12 (Own small caseload and care planning) · unclear: R7 (Leg-ulcer care), R9 (Continence care), R10 (End-of-life visits)
- `preferred`: absent: R13 (Doppler assessment)

R5, R12 — credible bridges, limits named; R7, R9, R10 — the CV is silent, worth a line if true; R13 — you've said it's not done, and a closure path exists.

**Opportunity ledger.** No red flags. Two unknowns remain: whether the posting is still open (RR1), and the hours, rota and contract basis (RR3). Stated pay with pool cars, and a supported caseload with a named contact, read as positive signals (RR2, RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your record-keeping experience is confirmed and carried onto the CV (R4); (2) the posting is confirmed open (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` "About Calderbrook Community Health" (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, all on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Hiring contact | Rhiannon Mabbott, Community Nursing Team Lead, leads the Halifax district nursing team and was a district nurse for eleven years. She has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` JD names her; speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) |
| Scope read | A role built for someone moving into community work. The Doppler item is only "desirable", and the caseload is supported | `[inferred]` from "small caseload", "supported by a senior community nurse" and Doppler listed as desirable |
| Market calibration | Band 5 community staff nurse, England: median basic pay £34,300, interquartile range £32,400 to £36,600. 61% of respondents were paid mileage and 24% had a pool or lease car. The posting's £31,050–£37,800 spans that range; it's a pattern, not this employer's offer to you | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (search snippet), for the band; `[grounded]` JD, for the posting's figures |
| Unknowns | Whether the posting is still open; hours, rota, weekend and out-of-hours cover; contract basis; visits per day | `[inferred]` from the posting's silence |
| Contradictions | None between the JD and the about page. The posting itself was not located on Calderbrook's own site | `[grounded]` about page; careers address I tried returned no page |
| Stage | Assumed evaluating, since you didn't say | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states active Adult registration, revalidation due March 2028. Stated, not checked; your NMC register entry is the place to check it | `[grounded]` CV | none |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK category B licence. Stated, not checked; your driving record is the place to check it | `[grounded]` CV and JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, per the CV. This is an experience requirement, not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records (on the electronic patient record) | must_have | unclear | low | discovery | The CV says nothing about documentation or record systems. Silence is not absence, but nothing here evidences it yet | `[grounded]` CV silence | G1 |
| R5 | Nursing housebound adults in their own homes | important | adjacent | medium | transferability | Nearest evidence is 18 months on a discharge-to-assess secondment, visiting patients at home in their first week after discharge. Limit: short post-discharge visits, not an ongoing housebound caseload | `[grounded]` CV; limit `[inferred]` from the CV's wording | Bridge in E1 and E3 |
| R6 | Wound care | important | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds. Confirmed claim, no inspectable artifact yet, so expect a probe | `[grounded]` CV | Upgrade menu |
| R7 | Leg-ulcer care | important | unclear | low | discovery | The CV names pressure ulcers and surgical wounds but not leg ulcers or compression | `[grounded]` CV | G2 |
| R8 | Catheter care | important | direct | medium | none | CV states catheter care. Expect a probe | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | The CV covers catheter care only, and continence care is not stated | `[grounded]` CV | G2 |
| R10 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life or palliative care | `[grounded]` CV silence | G3 |
| R11 | Insulin administration | important | direct | medium | none | CV states insulin administration | `[grounded]` CV | none |
| R12 | Own small caseload, supported by a senior nurse, with care planning | important | adjacent | medium | transferability | You've confirmed you've never held your own caseload. Home visits on the secondment are the nearest work, and care planning isn't evidenced | `[grounded]` your statement and CV | Bridge in E3; limit named |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've confirmed you have not done one. Desirable only, so a minor risk | `[grounded]` your statement and JD | Ask about training (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | A five-year ward career and a home-visiting secondment, but no mention of documentation or a record system | R4 is the one essential item the CV doesn't evidence, and closing it likely firms up `conditional_go` | Ward notes and handover records; visit notes on the secondment; any electronic record system you used; a notes audit | A documentation audit result, or a competency sign-off for a record system | `[grounded]` CV silence; `[inferred]` that closing it removes a condition |
| G2 | Leg-ulcer and continence care (R7, R9, important) | discovery | The CV names pressure ulcers and catheters but not leg ulcers or continence | Both are named duties, and the leg-ulcer duty sits beside the Doppler item | Compression bandaging; leg-ulcer dressings on the ward; continence assessments or pad and toileting plans | A competency record, or a ward skills sign-off | `[grounded]` CV wording; `[inferred]` closeness of the two duties |
| G3 | End-of-life care (R10, important) | discovery | The CV is silent | End-of-life visits are a named duty | Last-days-of-life care on the ward; a syringe driver, anticipatory medication, family conversations | A competency record, or reflective accounts you've already written for revalidation | `[grounded]` CV silence |
| G4 | Caseload and home-based practice (R5, R12) | transferability | Bridge: 18 months of home visits after discharge. Limit: that work did not exercise an ongoing caseload or planned care over time | A supported caseload is built into the post | n/a, the bridge is stated; no question needed | Visit logs, or a reference from the discharge-to-assess lead | `[grounded]` CV and your statement |
| G5 | Doppler (R13, preferred) | capability | Not done, per you | Desirable only | Closure path: ask in the chat whether new starters are trained | Training offer from the employer | `[grounded]` your statement; the speaker page names Doppler training for staff new to community work, so training may be on offer, but that's unconfirmed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The post may be closed, or listed at an address other than the one I tried | `[grounded]` the careers address I guessed returned no page, and the about page says vacancies are on a careers page | Is this post still open, and where is it listed on your careers page? | unresolved |
| RR2 | Pay and mileage stated | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | Pay is disclosed and sits within the role-family band | `[grounded]` JD; `[generic]` band from the pay guide | Where on the range would my experience place me, and how is mileage set? | noted |
| RR3 | Hours, rota and contract basis unstated | unknown | — | "Join our district nursing team caring for housebound adults in their own homes" | Rota, weekend and out-of-hours cover, visits per day and contract basis are not given, and any of these could matter to you | `[inferred]` from the posting's silence | What hours and rota does this post work, including weekends and any out-of-hours cover? | unresolved |
| RR4 | Supported caseload and a named contact | positive_signal | — | "supported by a senior community nurse"; "contact Rhiannon Mabbott" | Support is part of the design, and the team lead offers an informal chat | `[grounded]` JD | How does the senior nurse's support work day to day for someone new to a caseload? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line, `resume_edits_pending_approval`: "Seconded for 18 months to the discharge-to-assess team of a district general hospital, visiting patients at home in their first week after discharge." Move it and your wound, catheter and insulin lines near the top | R5, R6, R8, R11; every clause is your CV's own | `[grounded]` CV | pending your approval |
| E2 | Records line for the CV | R4; no wording until you answer G1 | `[grounded]` R4 row | pending your answer to G1 |
| E3 | Cover-letter wording on the caseload, pending your approval: "I have not held a caseload of my own; for 18 months I visited patients at home on a discharge-to-assess secondment." | R5, R12; states the limit and nothing more | `[grounded]` your statement and CV | pending your approval |
| A1 | Take the informal chat with Rhiannon Mabbott before applying. Ask RR1 and RR3 verbatim, and whether new starters are trained in Doppler assessment | RR1, RR3, R13; the JD invites the chat | `[grounded]` JD; `[inferred]` that Doppler training may be offered, from the speaker page | pending your approval |
| A2 | Check your NMC register entry and driving record are current before you apply | R1, R2 are stated, not checked | `[grounded]` R1, R2 rows | pending your approval |

If you apply and reach interview, the mock-interview module can prepare you for it.

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment and I haven't used it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse district nursing vacancy"; both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers, an address I guessed, returned no page. Moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "district nurse Band 5 community staff nurse Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved role reality's hiring-contact and scope rows, and A1 |

I can turn all of this into a `tuesday-dossier.md` file if you'd like one, with no obligation.

## Upgrade menu

- The live posting link on Calderbrook's own careers page → RR1 closes.
- Your answers to G1–G3 → R4, R7, R9 and R10 move, and the conditions shrink.
- Competency sign-offs or a revalidation portfolio extract, for wound, catheter and insulin care → R6, R8 and R11 can rise from `medium` toward `high`.
- Hours, rota and contract basis from the chat with Rhiannon → RR3 closes.
- A deeper pass on Calderbrook (inspection reports, staff and service news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions** (tagged to their gap rows):

G1 — Where have you written patient records that others relied on (ward notes, handovers, or the visit notes from your secondment), and which record system did you use?

G2 — Have you cared for patients with leg ulcers or continence needs, and what part of it was yours?

G3 — Have you cared for patients at the end of life, on the ward or on a home visit, and what part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.