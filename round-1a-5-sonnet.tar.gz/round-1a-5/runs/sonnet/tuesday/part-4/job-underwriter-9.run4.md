Searches were declined, so this rests on what you pasted. Here's the full assessment.

## Decision snapshot

**Yes, that's normal. Bank details, a PPS number and a passport scan, requested after a written offer, are routine onboarding. Enter them only in Marrowgate's own portal. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R4 · unclear: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000), R3 (Right-to-work check)
- `must_have` — direct: R5, R7, R9, R10 · adjacent: R8 (Run monthly payroll for 240 staff) · unclear: R6 (Irish PAYE, PRSI and USC)
- `important` — unclear: R12 (Answer staff payroll queries) · absent: R11 (Process pension changes)

R6 — your background doesn't say which tax rules your payroll ran under; R8 — a credible bridge, its limit named; R11 — pension changes were your manager's, so there is no hands-on evidence.

**Opportunity ledger.** The offer matches the ad on role, pay and hybrid terms, and it follows two in-person interviews (RR1). Two things aren't stated yet: support for pension changes (RR2) and the written terms of employment (RR3). The onboarding request is routine and has no register entry.

- **Hard gates:** none failed (R4 `direct`); unconfirmed: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000), R3 (Right-to-work check); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R6 is true of your own experience; (2) RR2's handover answer covers R11; (3) you settle R1, R2 and R3 against your own limits.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad header |
| Mandate | Monthly payroll for 240 staff; starters, leavers, pension changes; monthly payroll-to-ledger reconciliation; staff queries | `[grounded]` ad |
| Terms offered | Permanent, €40,000, hybrid two days in Limerick, reporting to Declan Garvagh, Finance Manager. Title, pay (inside the ad's €38,000–€42,000) and hybrid terms match the ad | `[grounded]` ad and offer email |
| Process so far | Two in-person interviews at their office, then a written offer from people@marrowgatehousing.ie | `[grounded]` your account |
| Onboarding requests | Bank details, PPS number and a passport scan go into a portal after you accept; original passport on day one. The offer gives each one's purpose: salary, Revenue, right-to-work | `[grounded]` offer email |
| Why it's normal | Paying, registering and checking right to work for a new employee needs exactly these items. The "never hand those over" rule fits requests made before any offer, or to someone who isn't the employer | `[generic]` general onboarding pattern, not a claim about this employer |
| Market calibration | Not run, because the salary search was declined. The €38,000–€42,000 band is the ad's own, not a market figure | `[grounded]` ad; no `[generic]` band |
| Unknowns | Support or handover for pension changes; probation, pension scheme, leave and notice terms; start date | `[grounded]` offer is silent on these |
| Contradictions | None between the ad and the offer | `[grounded]` both texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | The terms are stated and you interviewed in person at the office. Your own limits on commute and days aren't given | `[grounded]` ad, offer, your account | You confirm it works for you |
| R2 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | The offer sits inside the band. No pay floor from you, so I can't call it met | `[grounded]` ad and offer | You compare it to your own floor |
| R3 | Right-to-work check (named in the offer) | hard_gate | unclear | none | hard_gate | The offer says it will check. Your status isn't stated and doesn't need to be to me | `[inferred]` from the offer's right-to-work line | You confirm you can pass it |
| R4 | A payroll qualification or working towards one | hard_gate | direct | medium | none | Payroll Technician certificate, 2024, stated by you. Medium until the certificate is inspected | `[grounded]` your account | A copy of the certificate would raise it to high |
| R5 | 2+ years running payroll | must_have | direct | medium | none | 3 years running fortnightly payroll for 90 staff at a hotel group, stated by you | `[grounded]` your account | none |
| R6 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Nothing you gave says which tax rules your payroll ran under, and I won't assume | `[grounded]` background silent on this | G1 |
| R7 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated by you | `[grounded]` your account | none |
| R8 | Run the monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff. Limit: a monthly cycle and roughly 2.7 times the headcount aren't in your history | `[grounded]` your account; the multiple is arithmetic on stated figures | G2 |
| R9 | Reconcile payroll to the general ledger each month | must_have | direct | medium | none | Monthly payroll-to-ledger reconciliation, stated by you | `[grounded]` your account | none |
| R10 | Process starters and leavers | must_have | direct | medium | none | Starters and leavers, stated by you | `[grounded]` your account | none |
| R11 | Process pension changes | important | absent | none | capability | You said your manager handled these and you haven't done them. The duty is in the ad's list, not its requirements list | `[grounded]` your account, ad | G3: ask what training comes with the post |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention staff queries either way | `[grounded]` background silent | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R6, must_have) | discovery | Hotel-group payroll, but not which tax rules or whether you applied them | A named requirement in the ad; it decides whether you can do the role from week one | Running Revenue payroll submissions; applying USC bands or PRSI classes; handling a Revenue notice or a year-end return | A payslip layout with your details removed, or a job description from that role | `[grounded]` background silent; `[generic]` that statutory knowledge is what a new payroll admin is tested on first |
| G2 | Monthly cycle, larger headcount (R8, must_have) | transferability | Fortnightly, 90 staff, plus a monthly reconciliation | The ad's core duty is a monthly run for 240 | Month-end runs, covering a monthly-paid group, any run over 90 staff | A run calendar or an anonymised run summary | `[grounded]` your stated figures |
| G3 | Pension changes (R11, important) | capability | Observed, not done | Named duty with no hands-on evidence; closes by training | Watching your manager process changes; any pension-related data entry | None to request | `[grounded]` your account |
| G4 | Your own limits (R1, R2, R3, hard_gate) | hard_gate | Terms are stated; your limits aren't | A gate you haven't confirmed can't be marked met | Your pay floor, commute, days in office, right to work | None | `[grounded]` inputs silent |
| G5 | Staff payroll queries (R12, important) | discovery | Not mentioned | Duty in the ad | Fielding pay or tax questions from staff | None | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer matches the ad after two in-person interviews | positive_signal | — | "delighted to offer you the permanent post of Payroll Administrator at €40,000 a year ... hybrid with two days a week in our Limerick office" | The terms were agreed and are consistent across the ad and the offer | `[grounded]` ad and offer compared | Can you confirm the contract will carry the same title, salary and hybrid terms? | noted |
| RR2 | Pension changes may arrive with no handover | unknown | — | "process starters, leavers and pension changes" | The post may carry pension changes with little cover or training for someone who hasn't run them | `[inferred]` ad's duty list against the offer's silence on handover | Who handles pension changes now, and what handover or training comes with the post? | unresolved |
| RR3 | Terms beyond title and pay not stated | unknown | — | "starting on a date we agree once your notice period ends" | The email is short and fuller terms may follow, or may not | `[grounded]` email silent on probation, pension scheme, leave; `[generic]` these usually sit in written terms of employment | Can you send the written terms of employment, including probation, pension scheme and leave, before I reply? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before accepting, ask for the written terms and raise RR2's question with Declan Garvagh. Suggested wording: "Pension changes were handled by my manager in my last role, so I haven't processed them myself. What handover or training is there?" | See RR2, RR3, R11 | `[grounded]` your own sentence about pension changes | pending your approval |
| A2 | When the portal link arrives, check it matches the address on Marrowgate's own website. Enter details only there, never by email. Same care as any portal | See the onboarding row in role reality | `[generic]` standard practice, not a doubt about this employer | pending your approval |
| A3 | Settle your own limits on pay, days in office and right to work before the five-working-day deadline | See R1, R2, R3 | `[grounded]` offer's deadline | pending your approval |

Extra, beyond the spec: I can draft an acceptance email that also asks for the written terms (RR3). It would be built only on your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search for the employer's own site and live posting was declined. It would have checked the employer exists as described. I haven't established or failed to establish it; your two in-person interviews are the evidence I have |
| 2. Role-family sweep | unavailable | Search for payroll administrator pay in Limerick was declined. It would have set the market calibration against the €40,000 offer |
| 3. Hiring manager's public footprint | unavailable | Search for Declan Garvagh's public professional role was declined. It would have informed how to approach RR2 |

If you'd like, I can save this as a `tuesday-dossier.md` for later use.

## Upgrade menu

- What your hotel-group payroll ran under, or a role description from it → R6 and G1 resolve.
- A copy of the Payroll Technician certificate → R4 rises to `high`.
- Your pay floor, commute limit and right-to-work status → R1, R2, R3 close.
- The written terms of employment → RR3 closes.
- Search permission → the three declined searches run first. A deeper pass (up to 5 more searches and 2 more fetches) can follow on request.

Questions:

G1 — Which tax rules did your hotel-group payroll run under, and did you apply PAYE, PRSI and USC yourself?
G2 — Have you run a monthly payroll cycle, or any run above 90 staff?
G4 — What are your limits on pay, days in the office and right to work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.