Searches are done, so I'm writing up the assessment now.

## Decision snapshot

**No, don't go ahead. These messages ask you to pay, to lodge a cheque and send part of it on, and to hand over bank and ID details before any offer (RR1, RR2, RR3 and RR4). Those requests are very likely a scam, and I can't establish the employer from here (RR5). Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R3 · adjacent: R2 (Strong attention to detail), R4 (Good written English)
- `important`: unclear: R5 (A quiet place to work)

R3 is confirmed and specific; R2 and R4 are adjacent, with accuracy and written-work evidence still thin.

**Opportunity ledger.** Four entries are severe: payment for equipment (RR1), a cheque to lodge and pass on (RR2), bank, tax and ID details requested before any offer (RR3), and a hiring process run wholly on Telegram (RR4). The employer could not be established (RR5), and the pay is a ceiling with no commission rate (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer from an employer you can verify independently, with no payment, cheque or ID request before it. It would also need a live call or video interview, and written pay terms that clear R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": my search for its site or careers page returned nothing, so I can't confirm it exists as described | `[grounded]` search returned no results |
| Mandate | Remote order processing, 15–30 hours a week, hours set by you | `[grounded]` posting |
| Stated pay | "up to €26 an hour plus commission", with no floor rate and no commission rate. At the top rate, 30 hours a week for 52 weeks is €40,560 and 15 hours is €20,280. Reaching €30,000 at the top rate needs about 22 hours a week, every week | `[grounded]` posting; `[inferred]` arithmetic on its figures |
| Market calibration | A 2026 Irish pay guide puts salaried order-processing and customer-operations coordinators at a median base of €31,200, with an interquartile range of €28,400 to €34,100. It excludes commission-only and freelance work, so it isn't like-for-like with an hourly, variable-hours post. €31,200 is about €15 an hour on a 40-hour week, so "up to €26" with "no experience needed" sits well above that | `[generic]` role-family sweep, one search; `[inferred]` hourly conversion at 40 hours |
| Process | The posting says there are no calls or video interviews. The messages ask for ID and bank details before the "chat interview" | `[grounded]` posting and messages |
| Unknowns | Who the employer is, the commission rate, the contract basis, and who the "equipment partner" is | `[grounded]` absent from the material |
| Contradictions | The posting says hiring runs on Telegram. The posting's pay is hourly, but the cheque and "bonus" sit outside any pay terms given | `[grounded]` posting and messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) against "up to €26 an hour plus commission" | hard_gate | unclear | high | hard_gate | The confidence grades your own stated floor. Fit is unclear because the posting gives only a ceiling, variable hours and an unstated commission | `[grounded]` your statement and the posting | Written pay terms from a verified employer |
| R2 | Strong attention to detail | must_have | adjacent | low | discovery | You describe about 60 tickets a day in Zendesk, which shows volume, not accuracy. Nothing stated yet on error rates or checks | `[grounded]` your background; no accuracy evidence given | An accuracy or quality figure, if you have one |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. It is specific and self-reported, with no inspectable artifact | `[grounded]` your background | A sanitized tracker screenshot would raise it |
| R4 | Good written English | must_have | adjacent | medium | discovery | Ticket handling is written work, but the written share of your role isn't stated. Your messages here are in clear English | `[grounded]` your background and messages | Say how much of your role was written |
| R5 | A quiet place to work | important | unclear | none | discovery | Not stated, and it doesn't affect the decision | `[grounded]` silence | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | A ceiling rate, a 15–30 hour range and an unstated commission | It decides whether any version of this role could meet €30,000 | A written offer with hourly rate, commission rate and contract basis | Written terms from an employer verified on its own site | `[grounded]` the posting's wording; `[inferred]` that these terms can't settle the gate |
| G2 | Attention to detail (R2, must_have) | discovery | Ticket volume, with no accuracy evidence | It matters only for other roles | A quality score, an audit result or a low error rate in your ticket work | A QA report or team metric | `[grounded]` background silence on accuracy |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A payment is requested before any paid work, which is a recognised sign in recruitment messages | `[generic]` a pattern, not a claim about any named party | Do you ask new staff to pay for equipment, and where is that written in your own published terms? Put this to the employer through contact details found on its own website, not through the chat | confirmed |
| RR2 | Cheque to lodge and pass on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can show in an account before it has cleared, which would leave you responsible for money sent on | `[generic]` how cheque deposits work; a pattern, not a claim about any named party | See RR1 | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" (asked "Before your chat interview") | Details requested before any written offer or interview, so this isn't routine onboarding | `[grounded]` the message's own sequence | See RR1 | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." Then: "you passed the interview and the job is yours!" | Interview and offer happened only in chat, with no live contact | `[grounded]` posting and messages | Can I speak to someone by phone or video before accepting anything? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay is a ceiling with no commission rate | unknown | — | "Earn up to €26 an hour plus commission on every order you process" | The usual rate may sit far below the ceiling, and the commission could be small. The ceiling is high against the market band in role reality | `[inferred]` posting's ceiling set against the `[generic]` band | What is the hourly rate, the commission rate and the contract basis? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. The payment, the cheque and the early ID request are very likely a scam, so don't deposit the cheque.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing from the chat: not the IBAN you have ready, not the PPS number, not the passport photo. I'm not repeating your IBAN, and it isn't needed for this | see RR3 | `[grounded]` the messages | pending your approval |
| A2 | Don't pay the €349 | see RR1 | `[grounded]` the messages | pending your approval |
| A3 | Don't lodge the cheque or send any of it on; if it arrives, leave it undeposited | see RR2 | `[grounded]` the messages | pending your approval |
| A4 | To check the employer, find its contact details on its own website, not from the chat, and ask RR5's question. If you can't find a site, treat the employer as unestablished and stop there | see RR5 | `[grounded]` register | pending your approval |
| A5 | Tell the jobs site where you found the posting, and consider reporting the messages to An Garda Síochána | Sites and police generally take such reports | `[generic]` general practice | pending your approval |
| A6 | Put your effort into salaried order or customer-operations openings that publish their pay. Your own lines to lead with are "about 60 tickets a day in Zendesk", "trained two new starters" and "keep our team's weekly tracker in Excel". Use them as you wrote them | see R2, R3, R4 and the market band in role reality | `[grounded]` your sentences; `[generic]` band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official website careers order processing coordinator"; no results, so the employer is not established. Moved role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland entry level"; read "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide) from the result. Moved role reality's market calibration, R1's reasoning and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A link to the live posting, or the name of the jobs site you found it on → RR5 and the organization row.
- The company's own website or registered address → RR5.
- A written hourly rate, commission rate and contract basis → R1 and RR6 close.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) → say the word and it runs.

If you'd like a record of this assessment, I can write it up as `tuesday-dossier.md` for later use.

RR5 — Which jobs site did you find this on, and does the posting link to a company website of its own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.