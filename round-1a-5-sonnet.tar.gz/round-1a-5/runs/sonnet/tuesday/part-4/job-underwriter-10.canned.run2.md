I've run three searches. Next I'll fetch Fernquay's own site to check that the company is real and the posting is live.
**Yes, apply, and nothing I could check looks illegitimate. I did find two things to confirm along the way.** The company is real and matches the posting. The WhatsApp-plus-emailed-invite scheduling is a routine way for a small team to set up a call, and nothing in it asks you for money or personal details.

## Decision snapshot

**Yes, worth applying. On what I could check, Fernquay is a real employer matching the posting (RR4), and R2, a hard gate, is not yet confirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer, no design peers)

R7 — a credible bridge, its limit named; R8 — sole-designer work is the one thing you told me you haven't done; R2 — waiting on your pay floor.

**Opportunity ledger.** Fernquay's own About page matches the posting (RR4), and the pay band is stated (RR5). Still open: I couldn't find the posting on the company's careers page (RR1), the equity terms are unstated (RR2), and the support a first designer would get is unknown (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay meets your floor — R2; (2) the posting is confirmed as Fernquay's own — RR1; (3) you get a clear picture of what support a first designer has — R8, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page, fetched |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` JD |
| Working pattern | Hybrid: two days a week at the Galway office, the rest flexible | `[grounded]` JD |
| Hiring contact | Ronan Kehoe is described as co-founder and CEO, and was previously product lead at a Galway travel-software company for five years | `[grounded]` search result for his profile, snippet only |
| Scope read | Design, research and shipping with engineers, owned by one person, is a plausible remit for a first designer. The posting says nothing about who reviews design decisions | `[inferred]` from the JD's own wording |
| Market calibration | €52,000–€60,000 sits inside the survey's middle range and close to its median of €57,000 for 3–5 years' experience. That is a market band, not Fernquay's offer | `[generic]` Tillerby 2026 Ireland survey, snippet only; `[grounded]` JD for the posted range |
| Unknowns | Equity terms; whether the posting is live on Fernquay's own site; Saoirse's title (the About page names her as co-founder, and the WhatsApp message calls her CTO); design support and roadmap | `[grounded]` About page and JD silence |
| Contradictions | None found. The About page adds sailing schools and Scotland, which widens the posting's description without contradicting it | `[grounded]` About page against JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, so the office days are workable. That is your own statement of where you live | `[grounded]` your message, JD | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so whether the range meets it is not established. Confidence is `none` because no constraint of yours is on record to check against | `[grounded]` JD figure; no constraint from you | Question G1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported and no artifact inspected | `[grounded]` your message | A portfolio link or dated CV would raise this to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily, self-reported. Strength can only be judged from the files themselves | `[grounded]` your message | A Figma file or prototype link would raise this to `high` |
| R5 | Has run your own user research | must_have | direct | medium | discovery | You ran monthly usability sessions with customers, which matches the requirement as written. The role also asks for research calls with school owners, which may be interviews rather than usability tests, and your message doesn't say | `[grounded]` your message; `[inferred]` the interview-versus-usability distinction from the JD's wording | Question G3 below |
| R6 | Works directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking checkout, which is a credible bridge. Limit: checkout is one stage of a booking flow, and your message doesn't say how far your ownership extended | `[grounded]` your message; the limit is `[inferred]` from the JD's "end to end" | Question G2 below |
| R8 | First designer, with no design peers (an inferred requirement) | important | adjacent | medium | transferability | The JD says "You would be our first designer". You have confirmed you have never been the only designer. The adjacent evidence is four years in a squad and a flow you redesigned | `[grounded]` JD quote, your message; the requirement itself is inferred from that quote | Plan row A2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay meeting your floor (R2, hard_gate) | hard_gate | The posting states a range and your floor is not on record | A gate that isn't confirmed caps how firm the decision can be | — | Your own figure, and anything you'd treat as a minimum | `[grounded]` JD range; no constraint from you |
| G2 | Reach of your checkout ownership (R7, must_have) | transferability | You redesigned the checkout flow, and the extent of what you owned is unstated | The posting asks for the flow "end to end", so this is where a reader will test the bridge | Owning search or selection steps, confirmation and post-booking emails; deciding what the team built, not only how it looked | A flow diagram or case study page showing the stages you covered | `[grounded]` your message; `[generic]` that "end to end" invites this probe |
| G3 | Kind of research you ran (R5, must_have) | discovery | Monthly usability sessions with customers, with no detail on who planned them, ran them or acted on the results | The role's research calls with owners may be discovery interviews, a different kind of work | Planning the sessions and recruiting participants; writing a discussion guide; turning findings into design changes | A session plan, findings summary or a decision it changed | `[grounded]` your message; `[inferred]` from the JD's research calls |
| G4 | First-designer scope (R8, important) | transferability | Squad experience with four engineers, never as the only designer | You would set your own priorities with no design peer to review them | Setting your own priorities in a squad; choosing which usability findings to act on | A note on a decision you made without design review | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the company's careers page | unknown | — | "Product Designer — Fernquay" | The page I tried (fernquay.example/careers) returned nothing. The posting may sit on a job board or another address, or the role may be advertised directly | `[grounded]` fetch returned no page at that address; `[generic]` small teams often recruit outside a careers page | Could you send me the link to the live posting? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage's value depends on vesting, share class and strike terms the posting doesn't give | `[inferred]` from the posting's silence on terms; `[generic]` that equity value depends on those terms | What are the vesting schedule, share class and strike price for the equity? | unresolved |
| RR3 | Support for a first designer unstated | unknown | — | "You would be our first designer" | No design peer is named, and the posting doesn't say who reviews decisions | `[inferred]` from the JD's silence on review and roadmap | Who reviews design decisions, and what are the next six months of roadmap priorities? | unresolved |
| RR4 | Company's own page matches the posting | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The employer exists as described and names its co-founders | `[grounded]` About page, fetched | What is the current customer base, so I understand the product's stage? | noted |
| RR5 | Pay band stated | positive_signal | — | "Salary €52,000–€60,000" | Stating pay upfront shows transparency and puts the posting inside the survey's middle range | `[grounded]` JD; `[generic]` survey band | What decides where in the band an offer lands? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp message plus emailed invite as routine scheduling. Before opening the video link, check the invite email's sender address matches the company's own domain from its About page | The check is advice, not a condition | `[generic]` small teams often schedule by chat; `[grounded]` About page domain | pending your approval |
| A2 | Open with the checkout redesign you already submitted, and say plainly that you've worked in a squad rather than as the only designer. The JD says it prefers "one messy real project" to a polished deck | Ronan was product lead at a travel-software company, so a booking-flow story is close to his own background. See R7, R8 | `[grounded]` JD, your message, search snippet; `[inferred]` that it lands with him | pending your approval |
| A3 | Ask the verification questions of RR1, RR2, RR3 and RR5 on the call, word for word | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A4 | Decide your pay floor before the call, against the posted range and the survey median of €57,000 | Closes R2 early | `[grounded]` JD; `[generic]` survey median | pending your approval |
| A5 | Rehearse the 45-minute call: mock-interview covers this | You asked about the invite, so prep may be useful | `[generic]` | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway"; fetched "About Fernquay" (fernquay.example/about); fetched fernquay.example/careers, which returned no page. Moved role reality's organization row, RR1 and RR4 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup first designer", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). I read the snippet only, because the fetches went to target 1. Moved market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). I read the snippet only. Moved the hiring-contact row and A2 |

I can turn this into a `tuesday-dossier.md` for later steps (say the word); it isn't needed for any of the above.

## Upgrade menu

- Your pay floor and any other non-negotiables → R2 closes and the hard-gates line stops flagging constraints not given.
- A portfolio or Figma link → R3, R4 and R7 can move toward `high`.
- A short account of how you ran your usability sessions → R5's discovery gap closes.
- The link to the live posting → RR1 closes.
- A deeper research pass on Fernquay (funding, leadership, customer reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — What's the minimum salary you'd accept, and is there any other term (office days, equity) you'd treat as a dealbreaker?
G2 — Which stages of the checkout flow did you personally own, and did you decide what got built or only how it looked?
G3 — Who planned and ran your monthly usability sessions, and did any finding change a design decision?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.