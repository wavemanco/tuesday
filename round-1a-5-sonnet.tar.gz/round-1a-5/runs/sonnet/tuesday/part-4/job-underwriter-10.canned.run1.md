**Yes, worth continuing, and nothing you've shared reads as off. Status: `conditional_go`.** The conditions are R9 (pay against your own floor), RR2 (equity terms) and RR3 (design support). The WhatsApp message is a routine step, so it gets no entry below.

**Fit ledger.**

- `hard_gate` — direct: R8 · unclear: R9 (Salary €52,000–€60,000)
- `must_have` — direct: R1, R2, R3 · adjacent: R4 (Own the booking flow end to end)
- `important` — direct: R5 · adjacent: R6 (First and only designer), R7 (Research calls with school owners)

R4 — your checkout redesign is a credible bridge, its limit named; R6 — never the sole designer, the real stretch; R9 — waiting on your floor.

**Opportunity ledger.** The posting and the company's own pages agree (RR1), and the stated pay sits inside the market band (RR4). Equity terms (RR2) and design support and success measures (RR3) are open.

- **Hard gates:** none failed (R8 `direct`); unconfirmed: R9 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay in R9 meets your floor; (2) the equity terms come back clear (RR2); (3) there is a named person who reviews design work and a stated first-year outcome (RR3), and you frame R6's limit honestly.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` "About Fernquay" page |
| Mandate | First design hire: own the booking flow, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Posting vs careers page | The careers page matches on role, hybrid two days in Galway, pay range and "one real project" as the application ask. It says only "plus equity", without the 0.5–1% | `[grounded]` careers page fetched |
| Hiring contact | Ronan Kehoe is listed as co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years | `[grounded]` his public profile page |
| Scope read | A first-designer post with research, flow ownership and shipping in one seat is normal for a six-person company, but it has no design peer to learn from | `[inferred]` from the posting's "first designer" and team size |
| Market calibration | €52,000–€60,000 sits around the middle of the Irish range for 3–5 years (median €57,000, interquartile range €51,500–€62,000). The Irish report is not Galway-specific and is never this employer's offer | `[generic]` salary search, read from the result snippet, page not fetched |
| Unknowns | Equity form and vesting; who reviews design work; first-year success measures; Saoirse's title (the About page snippet doesn't give one) | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated by you, with no document inspected | `[grounded]` your background statement | none |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily", stated. Your checkout case study would be the inspectable proof | `[grounded]` your statement | share the case study (upgrade menu) |
| R3 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, stated, specific and plausible, with no artifact yet | `[grounded]` your statement | none |
| R4 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a booking company's checkout, so the domain is close. Limit: checkout is one stage of a flow, and your ownership of the stages around it isn't stated | `[grounded]` your statement; `[inferred]` limit from the stated scope | G3 |
| R5 | Happy working directly with engineers | important | direct | medium | none | Squad with four engineers, stated | `[grounded]` your statement | none |
| R6 | First and only designer | important | adjacent | medium | transferability | Inferred from "first designer". You've worked in a squad but never alone, so the setup work and the lack of peer review are untested. Bridge and strengthener are in G4 | `[inferred]` requirement from the posting; `[grounded]` your "never the only designer" | G4 |
| R7 | Research calls with school owners | important | adjacent | low | discovery | You've run usability sessions, but who the participants were isn't stated, and small business owners differ from consumers | `[grounded]` your statement and its silence on audience; `[generic]` that the audiences differ | G2 |
| R8 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year, so the location term is met. That is your statement of fact, not a stated non-negotiable | `[grounded]` your statement | none |
| R9 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | No floor given, so whether the band meets it can't be settled | `[grounded]` posting; your floor not stated | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R9, hard_gate) | hard_gate | The band is posted; your floor isn't known | A gate that can't be settled stays open, and it is the one thing that could end the process | n/a, this is a term | Your own number | `[grounded]` posting; your floor not given |
| G2 | Research audience (R7, important) | discovery | Sessions with "customers" at a travel-booking company; participants not described | Talking to small business owners is a different skill from testing with consumers, and the interview will probe it | Sessions with partners or suppliers; calls with business customers, trade accounts or support escalations; any session where the participant ran a business | Session guide, synthesis doc or findings deck, sanitized | `[grounded]` statement silent on audience; `[generic]` that interviews probe the difference |
| G3 | Scope of flow ownership (R4, must_have) | transferability | Checkout redesign confirmed; stages before and after it not described | R4 is a `must_have` row at `adjacent`. A wider owned scope narrows the objection | Ownership of search or selection, confirmation, change and cancellation screens, or error states around checkout | The case study itself, with your role marked | `[inferred]` from the stated scope |
| G4 | Sole-designer setup (R6, important) | transferability | Squad work confirmed; no solo-designer period | Nobody will review your work, and you set your own standards | Bridge: you ran your own research and redesigned a flow with engineers. Limit: no experience without design peers. Strengthener: a short account of how you'd get critique, for example external reviewers or a design community | A description of your own working process | `[inferred]` limit from "never the only designer"; `[generic]` that sole-designer roles hinge on self-direction |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting matches the company's own pages | positive_signal | — | "Open now: Product Designer, our first design hire. Hybrid, two days a week in Galway. €52,000–€60,000 plus equity." | The role is live and consistently described | `[grounded]` careers page fetched | Who would I report to day to day, and who would I work with most closely? | noted |
| RR2 | Equity form and terms unstated | unknown | — | "0.5–1% equity" | It may be options with vesting, or shares, and the percentage may be diluted later | `[inferred]` from the posting's silence on vesting, class and basis | Is the 0.5–1% shares or options, what is the vesting schedule, and is it on a fully diluted basis? | unresolved |
| RR3 | Design support and success measures unstated | unknown | — | "You would be our first designer" | There may be no one to review your work and no stated first-year outcomes | `[inferred]` from the posting naming responsibilities but no outcomes or design reviewer | Who reviews design work, and what would a strong first year look like? | unresolved |
| RR4 | Pay inside the market band | positive_signal | — | "€52,000–€60,000" | The stated range is credible for the seniority | `[grounded]` posting; `[generic]` salary band, read from a search snippet | Is the range fixed, or does it move with experience? | noted |

## Application plan

Each row is proposed, pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the calendar invite arrived from a Fernquay address, matching the domain on its careers page (`jobs@fernquay.example`), and that the video link is a standard platform. Reply on WhatsApp only to confirm the time | The scheduling step is routine; this is a small habit, not a concern | `[grounded]` careers page domain | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions. Say what you owned and what the squad did | Ronan's note singled out the case study, and he spent five years as a product lead at a Galway travel-software company, so booking-flow work is probably familiar to him | `[grounded]` his message and public profile; `[inferred]` familiarity | pending your approval |
| A3 | Ask RR2 and RR3's questions verbatim, and ask where the pay sits in the range | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Be direct that you haven't been the only designer, and say how you'd cover the gap (R6, G4) | The limit is probed either way; naming it first reads as candour | `[inferred]` from R6 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay Galway careers product designer", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer); fetched that careers page. The company exists as described and the posting is live and consistent, feeding role reality and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup first designer", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Its band feeds the market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role and career pattern only; it feeds role reality's hiring contact row and A2 |

Say the word and I'll write this up as `tuesday-dossier.md`.

## Upgrade menu

- Your checkout case study, or a link to it, would let me read what Ronan saw and could move R2, R3 and R4 toward `high`.
- Your salary floor settles R9.
- Their answers on equity terms (RR2) and design support (RR3) would close both entries.
- A deeper research pass on Fernquay (customer-reported experience, recent news, product reviews; up to 5 more searches and 2 more fetches) runs if you ask.
- A prep pack for the 45-minute call with Ronan and Saoirse is mock-interview's job.

**G1** — Does the €52,000–€60,000 base sit at or above the lowest salary you'd accept, and is there any other term you wouldn't bend on?

**G2** — In your monthly usability sessions, who were the participants: consumers booking trips, or business customers and partners? What did you do with what you learned?

**G3** — On the checkout redesign, which parts did you personally own versus the squad, and did your remit reach the stages before and after checkout?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.