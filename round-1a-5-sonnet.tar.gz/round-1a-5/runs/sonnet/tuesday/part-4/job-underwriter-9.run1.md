I've read the vetting playbook. Next I'm checking whether Marrowgate Housing can be found publicly, then I'll give you the full assessment.
**Yes. Being asked for bank details, your PPS number and a passport scan after a written offer is routine onboarding. The rule you were taught is about not sending them before an offer, or to the wrong place. Status: `conditional_go`.** Marrowgate's request isn't one of those cases. Your offer names the role, pay and manager, comes from their own domain, and follows two in-person interviews. The conditions below are about the job and its terms, not this request.

My web searches were refused, so I haven't checked Marrowgate publicly. The assessment rests on what you pasted.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R10 (Right to work in Ireland), R11 (Hybrid, two days in Limerick), R12 (Pay €40,000)
- `must_have` — direct: R2, R3, R4, R5, R6 · unclear: R1 (Irish PAYE, PRSI and USC)
- `important` — adjacent: R7 (Monthly payroll, 240 staff) · unclear: R9 (Answer staff payroll queries) · absent: R8 (Pension changes)

R8 — a stated gap, closable by training; R1 — unconfirmed, one answer settles it; R7 — a scale step up.

**Opportunity ledger.** The ad and the offer agree on role, pay band and working pattern (RR1). Written terms beyond pay are not yet seen (RR2), and support for pension changes is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R10 (Right to work in Ireland), R11 (Hybrid, two days in Limerick), R12 (Pay €40,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 is confirmed on your side (G1).
  2. The written contract arrives before you give notice (RR2).
  3. Pension-change handover is agreed (R8, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick. I haven't checked its existence independently. You interviewed at its office twice | `[grounded]` ad, offer email and your account |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, monthly payroll-to-ledger reconciliation, staff queries | `[grounded]` ad |
| Offer terms | Permanent, €40,000, hybrid with two Limerick office days, reporting to Declan Garvagh, Finance Manager. Reply within five working days | `[grounded]` offer email |
| Ad versus offer | Same title, same hybrid pattern, and €40,000 sits inside the ad's €38,000–€42,000 | `[grounded]` ad and offer |
| Onboarding request | Bank details, PPS number and passport scan go in a portal link sent after you accept, with the original passport shown on day one. Payroll and identity details after a credible written offer are routine | `[generic]` standard hiring practice |
| Market calibration | Not done: the pay search was refused | `[generic]` none available |
| Unknowns | Probation, pension scheme and leave terms; start date; pension-change training | `[grounded]` the offer is silent on all four |
| Contradictions | None between the ad and the offer | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say whether the hotel payroll was Irish or what your certificate covered. The Limerick job and PPS number make it likely but not shown | `[grounded]` your background is silent on jurisdiction | See G1 |
| R2 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll, stated by you, not yet backed by an artifact | `[grounded]` your account | none |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated by you | `[grounded]` your account | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, as you describe it | `[grounded]` your account | none |
| R5 | Process starters and leavers | must_have | direct | medium | none | Done at the hotel group, per you | `[grounded]` your account | none |
| R6 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | You did this monthly while running fortnightly payrolls | `[grounded]` your account | none |
| R7 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | You ran 90 staff on a fortnightly cycle. Limit: you haven't run 240 staff or a monthly cycle. Strengthener: the reconciliation already done monthly | `[grounded]` your account; `[generic]` monthly cycles differ in pension and tax timing | Ask about the current payroll software and any bureau |
| R8 | Pension changes | important | absent | none | capability | You haven't done them; your manager did. Nothing adjacent beyond watching them done | `[grounded]` your account | See G2 |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence in your account | See G3 |
| R10 | Right to work in Ireland, evidenced by passport | hard_gate | unclear | none | hard_gate | The offer makes it a term. Your status isn't stated and I haven't asked for it | `[grounded]` offer email | Nothing needed from you in this chat |
| R11 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | Terms are stated. Your own limits on commute or days aren't | `[grounded]` offer email | See the constraints question |
| R12 | Pay €40,000, within the ad's €38,000–€42,000 | hard_gate | unclear | none | hard_gate | Stated and consistent. Your floor isn't given | `[grounded]` ad and offer | See the constraints question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R1, must_have) | discovery | A certificate and three years of payroll, but no statement that the work was under Irish rules | It is a must-have, and its confirmation is the first condition for go | Filing with Revenue through the payroll software; applying USC bands and PRSI classes; year-end returns | The certificate's module list; a redacted payslip layout | `[grounded]` background silent on jurisdiction |
| G2 | Pension changes (R8, important) | capability | Your manager handled them; you haven't | It is a named duty, so you would be learning it on the job | Not applicable now. Closure path: agree a handover with Declan Garvagh, or a short course on auto-enrolment and scheme contributions | A written handover plan or training date | `[grounded]` your account; `[generic]` such duties are usually learned with a handover |
| G3 | Staff payroll queries (R9, important) | discovery | Not mentioned | It is a daily duty in the ad | Explaining a payslip to a hotel employee; resolving an underpayment; handling tax-credit questions | A redacted query log, or a description | `[grounded]` silence in your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and terms consistent from ad to offer | positive_signal | — | "Salary €38,000–€42,000" and "€40,000 a year" | The post is defined and the employer is working to a set structure | `[grounded]` both texts | Who signs off the monthly payroll before it runs? | noted |
| RR2 | Terms beyond pay not yet in writing | unknown | — | "starting on a date we agree once your notice period ends" | Probation, pension scheme and leave terms may come in a separate contract | `[inferred]` from the email's silence on them | Can you send the written contract, with probation, pension scheme and leave, before I give notice? | unresolved |
| RR3 | Pension changes with no handover stated | unknown | — | "process starters, leavers and pension changes" | You may be doing a task new to you without a named person to learn from | `[inferred]` from your account set against the ad | Who will take me through pension changes in my first weeks? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept by email within five working days as asked. Send no details by email or in this reply | The offer says details come after acceptance, via the portal | `[grounded]` offer email | pending your approval |
| A2 | Before entering anything, check the portal's web address against the address on Marrowgate's own website. Reach that site by typing it in, not through the email. If they differ, ring the People Team on a number from that site | Details should go only into the employer's own portal | `[generic]` safe onboarding practice | pending your approval |
| A3 | Ask for the written contract before you give notice to your current employer | See RR2 | `[grounded]` RR2 | pending your approval |
| A4 | Ask the RR2 and RR3 questions verbatim, to Declan Garvagh or the People Team | They double as questions for your first week | `[grounded]` register | pending your approval |
| A5 | Bring the original passport on day one, as requested | The offer asks for it | `[grounded]` offer email | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused. It would have checked that the employer exists as described and that its careers page matches the ad. Role reality's organization row stays unchecked |
| 2. Role-family sweep | unavailable | Search refused. It would have given a market band for the €40,000 offer and the scope read |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh is named, but I didn't search after the refusal. It would have informed the plan's positioning |

I can offer a dossier file of this assessment, if you want to keep or reuse it.

**Upgrade menu**

- Search permission would settle rows 1–3 above.
- Whether the hotel payroll was Irish, plus your certificate's modules, would settle R1.
- Your own limits on pay and commute would settle R11 and R12.
- Any pension-change exposure would improve R8.
- An example of queries you've handled would settle R9.

**Questions**

G1 — Was the hotel group's payroll under Irish rules, and did your Payroll Technician certificate cover PAYE, PRSI and USC?

R11, R12 — Are €40,000 and two office days a week in Limerick within your limits, or is there a non-negotiable I should check the offer against?

G3 — Have you answered staff payroll queries, and what kinds?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.