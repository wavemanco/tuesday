Quick note: the web searches I tried were refused, so this assessment rests only on what you pasted.

## Decision snapshot

**Yes, worth applying to, and I can't establish Fernquay itself from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R8 (Own the booking flow end to end)
- `important`: adjacent: R7 (Research calls with school owners), R9 (Sole designer, no design lead)

R8 — checkout is one stage of a booking flow, not stated as the whole of it; R7, R9 — bridges with their limits named.

**Opportunity ledger.** Fernquay is not established off the page (RR1), and the equity terms (RR2) and runway (RR5) are unstated. Scope, reporting line and the pay band are stated (RR3, RR4). Nothing in the posting or the WhatsApp message asks you for payment, bank or ID details. Scheduling an interview by WhatsApp, with the video link sent separately, is routine `[generic]`.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a live employer with this role on its own site (RR1); (2) equity terms and runway get concrete answers (RR2, RR5); (3) the band clears your salary floor (R2); (4) the sole-designer step is framed honestly as a bridge (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; web presence not checked |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reporting | Works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | First designer, so research, flow design and shipping fall to one person | `[inferred]` from "first designer" and the three-part remit |
| Market calibration | Not done: the role-family sweep was refused, so the band is not set against this role | — |
| Unknowns | Equity terms, runway, whether the role is listed on Fernquay's own site | — |
| Contradictions | None between the posting and the WhatsApp message (names and roles agree) | `[grounded]` both texts as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days sit where you live. Confidence grades your own statement | `[grounded]` posting and your message | none |
| R2 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The band is stated, but you gave no floor, so the term cannot be checked. `none` because no statement of yours exists to grade | `[grounded]` posting; floor absent | Question below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, which exceeds 3+. Self-reported, nothing inspected yet | `[grounded]` your message | Portfolio link would raise it |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" shows frequency, not depth; a file or prototype would show depth | `[grounded]` your message | Share a Figma file or prototype |
| R5 | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, which you ran. Self-reported, nothing inspected | `[grounded]` your message | A sanitized session readout would raise it |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers of a booking company; whether they were individuals or business operators is not stated. Limit: owner interviews are a different audience | `[grounded]` posting and message; `[inferred]` the limit | Gap G3 |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow, one stage of a booking journey. Whether you also owned the stages before it is not stated | `[grounded]` your message; `[inferred]` that checkout is one stage | Gap G2 |
| R9 | Working as the first designer, with no design lead | important | adjacent | medium | transferability | Inferred from "You would be our first designer". You have never been the only designer. Bridge: the checkout redesign in a squad. Limit: you always had design peers | `[grounded]` posting and message; `[inferred]` the requirement | Gap G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R2, hard_gate) | hard_gate | A band of €52,000–€60,000 and no floor from you | A gate you haven't confirmed can't be marked met | Your lowest acceptable salary, and whether equity counts toward it | Your own figure | `[grounded]` posting and your message |
| G2 | Whole booking flow (R8, must_have) | discovery | The checkout redesign, with no word on earlier or later stages | Posting says "end to end"; showing what you drove beyond checkout narrows the gap | Search or selection screens, basket and confirmation emails, change-or-cancel flows, anything you shaped around checkout | The checkout case study they already saw, or a flow diagram | `[grounded]` your message; `[inferred]` the gap |
| G3 | Owner research (R7, important) | transferability | Monthly customer sessions; audience type unstated | The role's research is with business owners | Sessions with tour operators, agents, hosts or any business customer | A sanitized session readout | `[grounded]` your message; `[inferred]` the limit |
| G4 | First-designer step (R9, important) | transferability | Strong squad experience, always with design peers | You'd set process alone; the posting asks to see "one messy real project" | A flow you took from problem to ship with little design review | The checkout project, plus one real project of yours | `[grounded]` posting quote and message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. My searches were refused, so nothing here confirms or counts against any of these | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` searches refused | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Vesting, share class, strike price and dilution are not given, and the equity's value depends on all of them | `[grounded]` posting silent on terms; `[generic]` that value depends on them | What are the vesting schedule, share class and strike price behind the 0.5–1%, and what dilution is planned? | unresolved |
| RR3 | Scope and reporting line stated | positive_signal | — | "own the booking flow end to end"; "work most closely with our co-founder" | Scope and line are clear; decision rights are not | `[grounded]` posting | Which booking-flow decisions are mine, and which stay with you or the engineers? | noted |
| RR4 | Pay band stated up front | positive_signal | — | "€52,000–€60,000" | The posting is open about pay | `[grounded]` posting | Is the band fixed, or does it move with experience? | noted |
| RR5 | Runway and funding unstated | unknown | — | "We are small and informal" | Funding position is not given and bears on salary and equity | `[generic]` for a six-person company; `[grounded]` posting silent | How long is your current runway, and what is the funding position? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp scheduling as routine. Before the call, open the calendar invite and check its sender's address sits on the domain Fernquay's own website gives | See RR1; the invite and the message come from the same sender | `[generic]` small teams often schedule by chat | pending your approval |
| A2 | Open with the checkout redesign and the monthly usability sessions (R3, R5, R8). On R9, say plainly that you haven't been the only designer: you redesigned the checkout flow in a squad with four engineers and ran monthly usability sessions with customers | The posting says it would rather see one real project than a polished deck | `[grounded]` posting and your message | pending your approval |
| A3 | Put RR2, RR3 and RR5 to Ronan and Saoirse verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | For prep on the 45-minute call, the mock-interview module can run it with you | The call is already booked | `[grounded]` your message | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: one for the company's booking software and one for its careers page for this role. They would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search on first-designer salary and equity norms was refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | One search on the co-founder named in the posting was refused. It would have moved the scope read and what A2 leads with |

## Upgrade menu

- A link to the posting on Fernquay's own site, or its web address: RR1 resolves or firms up, and role reality gets its organization and contradictions rows.
- Permission for web search: the pay-band sweep sets R2 and RR2 against the market, and the co-founder's published work refines A2. A deeper pass on Fernquay (funding, leadership, recent news; up to 5 more searches and 2 more fetches) runs on your say-so.
- Your salary floor: R2 closes as met or failed.
- A portfolio link or Figma file for the checkout project: R3, R4 and R8 can rise toward `high`.
- A sanitized usability-session readout: R5 and R7 firm up.

If you'd like, I can save all of this as a `tuesday-dossier.md` for later steps.

R2 — What's the lowest salary you'd accept, and does €52,000–€60,000 clear it?

R8 — On the checkout redesign, which parts of the booking journey did you own, and who else set the direction?

RR1 — Where did you find and apply to the posting (a link or site name), and does it appear on Fernquay's own website?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.