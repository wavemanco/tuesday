Checked the company name and the pay band, and the full read is below.

**No, don't go ahead. Status: `no_go`.** RR1, RR2, RR3 and RR4 each quote a demand made of you, and each is a confirmed severe red flag. This job is very likely a scam. Don't paste the IBAN you have ready.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3 · adjacent: R4 (Strong attention to detail)
- `important` — adjacent: R5 (Order processing duties)

R1 — pay is never stated as a guaranteed figure; R4 — evidenced by ticket volume, not accuracy.

**Opportunity ledger.** The opportunity fails on its own terms, whatever your fit. RR1, RR2 and RR3 are payment, cheque and personal-details demands, and RR4 is a hiring process run wholly in chat. RR5 records that no employer could be found, RR6 sets the pay claim against the market band, and RR7 records the contact address.

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** the employer verified through contact details you find on its own website, nothing paid, deposited or disclosed before a written contract from that verified employer, and a live interview with someone from the company.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics"; no website, careers page or listing found | `[grounded]` search returned nothing attributable |
| Role | Remote Order Processing Coordinator, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Process | Hiring "runs on Telegram, so there are no calls or video interviews"; an offer arrived after chat only | `[grounded]` posting and your messages |
| Pay arithmetic | At the top rate, 15–30 hours is about €20,280 to €40,560 a year. €30,000 needs the top rate and about 22 hours every week | `[inferred]` 26 × 15 × 52 and 26 × 30 × 52; 30,000 ÷ 26 ÷ 52 |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, middle range €28,400–34,100. The survey excludes freelance and commission work, and this posting's pay basis is unstated | `[generic]` one search, Pennoral 2026 pay guide, never this employer's offer |
| Unknowns | Employer identity, employment or self-employment, commission terms, guaranteed hours | `[grounded]` posting silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because "up to €26" and 15–30 hours reach it only at the top rate and about 22 hours a week | `[grounded]` your constraint and the posting; `[inferred]` the arithmetic | Written terms with a guaranteed rate and hours, from a verified employer |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; confirmed and specific, nothing inspectable yet | `[grounded]` your background | none |
| R3 | Good written English | must_have | direct | medium | none | About 60 written Zendesk tickets a day for three years; nothing inspectable yet | `[grounded]` your background | none |
| R4 | Strong attention to detail | must_have | adjacent | medium | discovery | You gave volume and training others, not accuracy results | `[grounded]` your background | See G1 |
| R5 | Order processing duties (named basis: the job title) | important | adjacent | medium | transferability | Parcel customer-service tickets are not order entry and checking; that is the limit | `[inferred]` from the title against your background | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R4, must_have) | discovery | Volume and training others, but no accuracy figure | Matters only for a verified role | Quality scores or error rates on your tickets; checking the team tracker | A QA score sheet or manager feedback | `[grounded]` your background silent on accuracy |
| G2 | Order processing (R5, important) | transferability | Parcel tickets, not order entry | Same | Correcting wrong or missing order details; updating records after a customer contact | A process note or screenshot, sanitized | `[inferred]` from the title |
| G3 | Guaranteed pay (R1, hard_gate) | hard_gate | Only "up to" a rate | Your €30,000 floor | — | Written offer with rate, hours and employment basis | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | This request is very likely a scam; who sent it is unresolved | `[generic]` known pattern for this kind of request | Do you ask new starters to pay for equipment, and where is that in your written terms? Ask through contacts on the employer's own website, not this chat | confirmed |
| RR2 | Cheque to deposit, balance sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | This request is very likely a scam. A deposited cheque can be returned later, and the money sent on is gone | `[generic]` known pattern for this kind of request | See RR1's route: do you issue cheques to new starters and ask them to forward funds? | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "send your IBAN ..., your PPS number and a clear photo of your passport so payroll can set you up" | The request comes before any contract or interview, so it is not routine onboarding | `[grounded]` the message's timing | See RR1's route: what do you collect from applicants before a written offer? | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Interview and offer both happened only in chat | `[grounded]` posting and your messages | See RR1's route: will I meet someone from the company live? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay claim against market band | risk_signal | low | "Earn up to €26 an hour plus commission" | The figure may reflect self-employment or commission rather than a salary | `[generic]` role-family band against `[grounded]` posting | What guaranteed rate and weekly hours does this post carry, and is it employment? | unresolved |
| RR7 | Contact address | risk_signal | medium | "email velloway.hr@postmail.example" | The address is on a mail-service domain, not one named for the company | `[inferred]` from the address | Is this address one you use, shown on your own website? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number or passport photo, no transfer. If a cheque arrives, don't lodge it | See RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Look for the company's own website or registration from a source outside the chat, and use only contact details found there | See RR5 | `[grounded]` RR5 | pending your approval |
| A3 | Report the posting to the jobs site, and the Telegram account to Telegram | Platforms generally take reports | `[generic]` | pending your approval |
| A4 | Put the effort into salaried order-processing or customer-operations openings, whose band sits around your €30,000 floor; resume-tailor can tailor your CV to a real posting | See R1, RR6 | `[generic]` band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator"; no results, no page. Not established: RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland entry level hourly pay"; page "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle |

If you'd like a saved record of this assessment, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- The company's registered name, address or number from a source outside the chat → RR5 could resolve.
- A link to the live posting on the original jobs site → RR5 and the posting's consistency.
- A written contract stating rate, guaranteed hours and employment basis, from a verified employer → R1 and RR6.
- A hiring manager's name from the company's own site → role reality's scope read.

No questions this turn: no answer would change the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.