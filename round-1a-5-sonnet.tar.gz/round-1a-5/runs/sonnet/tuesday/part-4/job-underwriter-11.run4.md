Reading the playbook is done. Next I'm running a few quick employer checks on both companies, then I'll write up the assessment.
## Decision snapshot

**Duinvaart Cold Chain, Operations Analyst: yes, worth your time. Status: `conditional_go`.** DR2, DR3, DR4 and DR5a, all must-haves, are `direct`. The conditions are below.

**Fit ledger (Duinvaart).**

- `hard_gate` — unclear: DR1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: DR2, DR3, DR4, DR5a · unclear: DR5b (Temperature compliance tracking)
- `important` — adjacent: DR6 (Route changes with depot managers)
- `preferred` — adjacent: DR7 (Dutch a plus)

DR5b — the cold-chain-specific piece, unknown until you answer; DR6 — your route-review work is a bridge, its limit named; DR1 — turns on your Rotterdam days.

**Opportunity ledger.** Employer not yet checked (DRR1) and pay not stated (DRR2). The duties are concrete and measurable (DRR3).

- **Hard gates:** none failed; unconfirmed: DR1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the three Rotterdam days work for you — DR1; (2) the employer and posting verify — DRR1; (3) your temperature-data exposure is established honestly — DR5b.

**Kroonhaven Foods, Supply Planner: not worth applying to as posted. Status: `no_go`.** KR3 (3+ years of FMCG planning), KR4 (own the 13-week plan) and KR7 (SAP IBP or similar) are must-haves with no evidence behind them, and you've said you haven't worked in planning.

**Fit ledger (Kroonhaven).**

- `hard_gate` — unclear: KR1 (On-site in Utrecht)
- `must_have` — adjacent: KR2 (Fluent Dutch), KR5 (Run the weekly S&OP meeting) · unclear: KR6 (Advanced Excel) · absent: KR3 (3+ years supply or demand planning in FMCG), KR4 (Own the 13-week supply plan), KR7 (SAP IBP or similar)

KR3, KR4, KR7 — no planning evidence; KR5 (`medium`) — the closest bridge, its limit named; KR2 (`medium`) — conversational against fluent; KR6 — Excel unstated.

**Opportunity ledger.** Employer not yet checked (KRR1) and pay not stated (KRR2). Ownership of the plan is clearly defined (KRR3).

- **Hard gates:** none failed; unconfirmed: KR1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** planning experience matching KR3, KR4 and KR7, or a posting that drops them.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart: mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Duinvaart: working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Duinvaart: scope read | An analyst role reporting on a defined fleet and metric set | `[inferred]` from the duties list |
| Duinvaart: unknowns | Pay, team size, reporting line, temperature data source, whether the three office days are fixed | `[grounded]` posting is silent on each |
| Kroonhaven: mandate | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Kroonhaven: working pattern | On-site in Utrecht | `[grounded]` posting |
| Kroonhaven: unknowns | Pay, team size, sign-off authority on the plan, the language of the S&OP meeting | `[grounded]` posting is silent on each |
| Market calibration (both) | Not obtained. The pay-band search was refused, so there is no band to set the roles against | `[grounded]` search refused, see Evidence status |
| Contradictions | None between the two postings and your background as you described it | `[grounded]` inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| DR1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You have stated no location or commute limit, and your current role is in Amsterdam, so whether three Rotterdam days work is open | `[grounded]` posting; your Amsterdam role | Question in the closing block |
| DR2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, confirmed and specific; no CV or artifact inspected yet | `[grounded]` your background as stated | none |
| DR3 | Strong SQL | must_have | direct | medium | none | Daily SQL use, confirmed; nothing inspectable yet | `[grounded]` your background as stated | none |
| DR4 | Power BI or Tableau, weekly dashboards | must_have | direct | medium | none | Daily Power BI, including the on-time delivery dashboard depot managers use; a screenshot would raise it | `[grounded]` your background as stated | Offer: a sanitized screenshot or description of the dashboard |
| DR5a | Track on-time delivery | must_have | direct | medium | none | The dashboard you built is on-time delivery | `[grounded]` your background as stated | none |
| DR5b | Track temperature compliance | must_have | unclear | low | discovery | Nothing you've said touches temperature, chilled goods or sensor data. Tracking another service metric is a possible bridge, not evidence | `[grounded]` silence; `[inferred]` possible bridge | Question in the closing block |
| DR6 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review and depot managers use your dashboard. Limit: nothing says the review led to route changes you worked through | `[grounded]` your background as stated | If true, add an outcome from the review (a route or schedule change it prompted) |
| DR7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch. It is a plus, not a requirement, and the posting doesn't say where Dutch is used | `[grounded]` your background; posting wording | State your level plainly |
| KR1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraint stated; the posting offers no hybrid option | `[grounded]` posting | Not worth a question unless you reconsider |
| KR2 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational against fluent. Limit: the weekly S&OP meeting is probably the heaviest Dutch use, but the posting doesn't say | `[grounded]` your background; `[inferred]` from the S&OP duty | none |
| KR3 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning, and parcel-carrier analysis isn't FMCG planning | `[grounded]` your own statement | Closure path in the plan |
| KR4 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning ownership in your history | `[grounded]` your own statement | Closure path in the plan |
| KR5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: that reviewed past performance; S&OP negotiates a forward plan across functions | `[grounded]` your background; `[inferred]` S&OP scope from the posting | none |
| KR6 | Advanced Excel | must_have | unclear | low | discovery | Your daily tools are SQL and Power BI; Excel depth isn't stated | `[grounded]` silence | none, since the decision doesn't turn on it |
| KR7 | SAP IBP or similar planning system | must_have | absent | none | capability | No planning-system use, consistent with no planning work | `[grounded]` your own statement | Closure path in the plan |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| DG1 | Temperature compliance (DR5b, must_have) | discovery | Nothing in your background touches temperature or chilled goods | It is the one cold-chain-specific duty, and it is what Duinvaart's interviewers would most likely probe | Any chilled or temperature-sensitive shipments at the carrier; tracking a service-level breach metric against a threshold; exception reporting built from sensor or scan data | A dashboard screenshot or report that tracks compliance against a target | `[grounded]` silence; `[generic]` that employers probe the sector-specific duty |
| DG2 | Rotterdam office days (DR1, hard_gate) | hard_gate | No stated constraint against a three-day Rotterdam office pattern | A failed gate would end the application, so it comes before effort | Your commute or relocation plans | None needed; your own answer settles it | `[grounded]` posting and your Amsterdam role |
| KG1 | Planning experience and system (KR3, KR4, KR7) | capability | No planning work, by your account | These are must-haves, and wording cannot close them | Only real planning exposure counts | None | `[grounded]` your own statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DRR1 | Employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| DRR2 | Pay not stated | unknown | — | (no pay figure in the posting provided) | The figure may be at market or the employer may simply not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| DRR3 | Concrete, measurable duties | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Scope and success measures are defined | `[grounded]` posting | Which data source feeds temperature compliance today? | noted |
| KRR1 | Employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| KRR2 | Pay not stated | unknown | — | (no pay figure in the posting provided) | The figure may be at market or the employer may simply not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| KRR3 | Clear ownership of the plan | positive_signal | — | "Own the 13-week supply plan" | Responsibility is defined and the role is scoped | `[grounded]` posting | Who signs off the plan, and who attends the weekly S&OP? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart CV: lead with the on-time delivery dashboard depot managers use and the weekly route-performance review, in outcome terms, using only facts you confirm | See DR4, DR5a, DR6 | `[grounded]` your background | pending your approval |
| A1 | Settle DR1 before investing in applications | See DR1 | `[grounded]` DR1 | pending your approval |
| Q1 | In a Duinvaart interview, put DRR1–DRR3's questions verbatim, and describe your Dutch as conversational | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Don't apply to Kroonhaven as posted | See KR3, KR4, KR7 | `[grounded]` map | pending your approval |
| P2 | Closure path: look for planning-analyst or planning-support openings, where analysts moving toward planning are more often considered | A pattern about roles of this kind, not a fact about any employer | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches, one for each employer's own site and whether the role is live, were refused. They would have moved DRR1, KRR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search for the analyst role's pay band was refused. It would have moved the market calibration row, DRR2 and KRR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can save this as a `tuesday-dossier.md` if you'd like to keep or reuse it.

- Approving web search, so I can check both employers' careers pages and pay bands → DRR1 and KRR1 close or stay open, and the market calibration row fills.
- Your answer on temperature or chilled-goods data → DR5b moves, and the decision firms up.
- Your commute or relocation answer → DR1 settles.
- Your pay floor → DRR2 and KRR2 get checked against it.
- A dashboard screenshot or description → DR4 rises to `high`.
- The hiring manager's name → role reality's scope read.

## Questions

DG1 — Have you ever tracked anything temperature-related or tied to chilled or time-sensitive parcels, or built a compliance-against-a-threshold report? What did you own and what came of it?

DR1 — Would three days a week in Rotterdam work for you, by commuting or moving?

DRR2 — What's your minimum pay, and is there any other non-negotiable (hours, location, contract type)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.