**Duinvaart Cold Chain, Operations Analyst: yes, worth your time. Status `conditional_go`.**
**Kroonhaven Foods, Supply Planner: no, not as it stands. Status `no_go`, because R8 and R10 are must-haves with no evidence behind them.**

I couldn't check either employer online. The web searches weren't allowed, so everything below rests on your two postings and your background. The roles are numbered separately: Duinvaart is R1–R7 and Kroonhaven is R8–R13.

## Decision snapshot

**Duinvaart: fit ledger**

- `hard_gate`: unclear: R7 (Hybrid, three days a week in Rotterdam)
- `must_have`: direct: R1, R2, R3
- `important`: direct: R4a, R5 · unclear: R4b (Temperature compliance tracking)
- `preferred`: adjacent: R6 (Dutch a plus)

R4b (`low`): no cold-chain evidence yet; R6: conversational Dutch against "a plus".

**Duinvaart: opportunity ledger.** Sound on its face, with the work spelled out (RR3). Pay is not stated (RR2), and I have not checked the employer or whether the posting is live (RR1).

- **Hard gates:** none failed; unconfirmed: R7 (Hybrid, three days a week in Rotterdam); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the three Rotterdam days work for you (R7); (2) the employer and posting verify (RR1); (3) you claim no temperature or cold-chain experience unless G1 confirms it (R4b).

**Kroonhaven: fit ledger**

- `hard_gate`: unclear: R13 (On-site in Utrecht)
- `must_have`: adjacent: R11 (Fluent Dutch), R12 (13-week plan, run S&OP) · unclear: R9 (Advanced Excel) · absent: R8 (3+ years FMCG planning), R10 (SAP IBP or similar)

R8, R10: planning experience and a planning system are both missing; R12: your weekly route review is a bridge, with its limit named.

**Kroonhaven: opportunity ledger.** Pay is not stated (RR5), and the employer is not yet checked (RR4).

- **Hard gates:** none failed; unconfirmed: R13 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** you would need real planning experience (R8) and planning-system experience (R10). Neither can be closed for this posting.

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| Duinvaart | Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Duinvaart | Working pattern | Hybrid, three days a week in Rotterdam | `[grounded]` JD |
| Duinvaart | Scope read | An analyst post whose outputs are named. Your current job maps onto most of it | `[inferred]` from the JD's duties against your background |
| Duinvaart | Market calibration | Not run, because search was unavailable. No pay band offered | `[grounded]` search refused |
| Duinvaart | Unknowns | Salary; the employer's size and footprint; whether temperature data is a core or a side duty | `[grounded]` JD silent |
| Kroonhaven | Mandate | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Kroonhaven | Working pattern | On-site in Utrecht | `[grounded]` JD |
| Kroonhaven | Scope read | A planner who owns the plan outright, not an analyst supporting one | `[inferred]` from "own" and "run" in the JD |
| Kroonhaven | Market calibration | Not run, because search was unavailable | `[grounded]` search refused |
| Kroonhaven | Unknowns | Salary; team size; whether the planning system is SAP IBP specifically | `[grounded]` JD silent |
| Both | Contradictions | None inside either posting. Neither was compared with the employer's own careers page | `[grounded]` JD text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Duinvaart: 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. Self-reported, with no document inspected | `[grounded]` your background | none |
| R2 | Duinvaart: strong SQL | must_have | direct | medium | none | SQL used daily. Self-reported | `[grounded]` your background | none |
| R3 | Duinvaart: Power BI or Tableau | must_have | direct | medium | none | Power BI daily, and you built the on-time delivery dashboard depot managers use. A screenshot or sanitized view would raise it | `[grounded]` your background | offer: a sanitized screenshot of the dashboard |
| R4a | Duinvaart: track on-time delivery | important | direct | medium | none | The dashboard is on-time delivery tracking | `[grounded]` your background | none |
| R4b | Duinvaart: track temperature compliance for a refrigerated fleet | important | unclear | low | discovery | Nothing you described mentions temperature or cold-chain data. Parcel delivery monitoring is close in kind but not the same | `[grounded]` background silent; `[inferred]` the closeness | G1 |
| R5 | Duinvaart: work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your dashboard | `[grounded]` your background | none |
| R6 | Duinvaart: Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is a partial match. The limit is working Dutch in documents and meetings | `[grounded]` your statement | none; state it plainly as conversational |
| R7 | Duinvaart: hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You gave no location or schedule limits. Your job is in Amsterdam, which says nothing about where you live | `[grounded]` constraint not given | G2 |
| R8 | Kroonhaven: 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning. This is a length-of-experience requirement, not a gate | `[grounded]` your statement | closure path in G3 |
| R9 | Kroonhaven: advanced Excel | must_have | unclear | low | discovery | You named SQL and Power BI and said nothing of Excel | `[grounded]` background silent | none, since R8 and R10 decide the role |
| R10 | Kroonhaven: SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system work in what you described | `[grounded]` background | closure path in G3 |
| R11 | Kroonhaven: fluent Dutch | must_have | adjacent | medium | transferability | You are conversational, not fluent. The limit: running a weekly meeting in Dutch needs more | `[grounded]` your statement | none |
| R12 | Kroonhaven: own the 13-week plan, balance capacity against forecast, run weekly S&OP | must_have | adjacent | medium | transferability | You ran a weekly cross-team performance review. The limit: that reviewed past performance and set no forward plan | `[grounded]` your background; `[inferred]` the bridge | none |
| R13 | Kroonhaven: on-site in Utrecht | hard_gate | unclear | none | hard_gate | Constraint not given | `[grounded]` constraint not given | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R4b, important) | discovery | Delivery tracking is covered, but nothing on temperature or cold-chain data | It is half of the role's first duty. If you have anything close, R4b moves to adjacent | Handling dashboards or alerts for time-critical or sensitive parcels; breach or exception reporting against a service level; any data from sensors or telematics | A sanitized report or dashboard view | `[grounded]` background silent; `[generic]` that employers in this field screen for this |
| G2 | Location and schedule (R7, R13; hard_gate) | hard_gate | No constraints stated | A hard gate is decided by whether it is met | Your commute, your move plans, any days you cannot be in an office | None | `[grounded]` constraints not given |
| G3 | Planning experience and system (R8, R10; capability) | capability | No planning work and no planning system | No credible direct or adjacent evidence. For this posting it cannot be closed in a sensible time | A course in planning or a project only helps for a different, more junior target | None | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart: employer and live posting not checked | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The posting may be stale, the entity may be small or new, or it may not represent a real hiring employer. Search was refused, so none of these is ranked | `[generic]` pattern for unchecked postings, not a claim about this employer | Can you point me at this role on your own careers site, and who I would work with? | unresolved |
| RR2 | Duinvaart: pay not stated | unknown | — | "Hybrid, three days a week in our Rotterdam office." | The posting names no salary. It may sit below your floor or simply be unpublished | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Duinvaart: duties are concrete | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | Named outputs and named counterparts suggest a defined job | `[grounded]` JD | What would a good first quarter look like? | noted |
| RR4 | Kroonhaven: employer and live posting not checked | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | Same possibilities as RR1, none ranked | `[generic]` pattern for unchecked postings, not a claim about this employer | Can you point me at this role on your own careers site? | unresolved |
| RR5 | Kroonhaven: pay not stated | unknown | — | "On-site in Utrecht." | The posting names no salary | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Apply to Duinvaart. Lead with the on-time delivery dashboard depot managers use and the weekly route-performance review, in your existing wording and with no new claims | R3, R4a, R5 | `[grounded]` your background | pending your approval |
| A2 | Do not claim temperature or cold-chain experience unless G1 confirms it | R4b | `[grounded]` your background | pending your approval |
| A3 | Confirm the posting is live, the pay range and the Rotterdam days before spending time on a tailored application | RR1, RR2, R7 | `[grounded]` register | pending your approval |
| A4 | Skip Kroonhaven for now. Look instead for analyst roles near supply chain or planning teams in food firms, which use your analysis skills without the planning requirement | R8, R10 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four searches were sent and every one was refused: one each for Duinvaart Cold Chain and Kroonhaven Foods, and two for pay. Nothing was read. RR1 and RR4 stay open |
| 2. Role-family sweep | unavailable | The two pay searches were among those refused. No market calibration, and RR2 and RR5 stay without a band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Allowing web search would let me check both employers' own pages. That would close or sharpen RR1 and RR4, and add a pay band to role reality.
- An answer to G1 moves R4b.
- Your location and schedule limits settle R7 and R13.
- A sanitized dashboard screenshot raises R3 to `high`.
- The posting's pay range closes RR2 and RR5.

If useful, I can write this up as a `tuesday-dossier.md` for later steps.

G1: Have you ever worked with temperature, cold-chain or time-sensitive delivery data, or breach and exception reporting against a service level? What did you own, and what happened?

G2: Can you do three days a week in Rotterdam (R7), and do you have any other limits on location, days in the office or pay?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.