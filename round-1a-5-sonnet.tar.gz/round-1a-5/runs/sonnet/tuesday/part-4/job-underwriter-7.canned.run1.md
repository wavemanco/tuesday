I've checked the employer and the team lead. Next I'll fetch their careers page to see whether this posting is live.
**Yes, worth applying for, but conditionally.** No gate row fails, and the main gaps are ones you can be honest about. The status is `conditional_go`.

## Decision snapshot

**Worth applying for, with three conditions. Status: `conditional_go`.** R1, R2 and R3 are hard gates, and they come out `direct`. The posting's weak points are R7, wound and leg-ulcer care, and R15, Doppler assessment.

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3 · unclear: R4 (Pay £31,050–£37,800 plus mileage)
- `must_have` — direct: R5, R8, R9 · adjacent: R6 (Care for housebound adults in their own homes), R7 (Wound and leg-ulcer care) · unclear: R10 (End-of-life visits), R11 (Clear, timely written records)
- `important` — adjacent: R14 (Own small caseload) · unclear: R12 (Continence care), R13 (Care planning)
- `preferred` — absent: R15 (Doppler assessment)

R6, R7, R14 — credible bridges, each with its limit named; R10, R11, R12, R13 — your CV is silent, so these are questions; R15 — a desirable item, not an essential one.

**Opportunity ledger.** The employer is attributable (evidence status, target 1), but the posting itself is not confirmed live (RR1) and the visiting rota is unstated (RR2). Two entries run the other way: the supervised small caseload (RR3) and the team lead's public work on Doppler training for staff new to community nursing (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); unconfirmed: R4 (Pay £31,050–£37,800 plus mileage); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay in R4 meets your own floor; (2) the posting is confirmed live, as RR1 asks; (3) you tell the truth about the limits in R7 and R10, as G1 and G4 below ask.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health is a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. It was founded in 2015 and has 410 staff across four locality hubs. | `[grounded]` About page fetched via search result |
| Mandate | Home-based district nursing for housebound adults: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` speaker page found by search |
| Scope read | The one-year experience bar, the senior-nurse support and Doppler as desirable all point to a post that takes nurses new to community work | `[inferred]` from the JD's essential and desirable lists |
| Market calibration | Not calibrated. The role-family search returned nothing, so I make no claim about whether the pay is typical. | `[grounded]` search returned no results |
| Unknowns | Visiting hours and rota, caseload size, Doppler training provision, the posting's closing date | — |
| Contradictions | None between the JD and the About page. The careers page could not be fetched, so the posting is unconfirmed. | `[grounded]` About page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active adult registration with revalidation due March 2028. That is stated, not checked. | `[grounded]` CV | Check your own entry on the NMC register before applying |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full category B licence. That is stated, not checked. | `[grounded]` CV | Check your licence record with the DVLA |
| R3 | Role based in Halifax | hard_gate | direct | medium | none | The JD header says Halifax and you say you live there | `[grounded]` JD and CV | none |
| R4 | Pay £31,050–£37,800 a year plus mileage | hard_gate | unclear | none | hard_gate | You have given no pay floor, so I cannot say whether the band meets it. The JD states the figure. | `[grounded]` JD; no constraint given | G7 |
| R5 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward | `[grounded]` CV | none |
| R6 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: that work was short-term post-discharge visiting, not ongoing care of housebound patients. | `[grounded]` CV; `[inferred]` that the limit matters to a district nursing panel | E1 in the plan |
| R7 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Pressure ulcers and surgical wounds are confirmed. Leg-ulcer care is not mentioned. Limit: leg ulcers are managed differently from pressure ulcers, usually with compression and a Doppler check. | `[grounded]` CV; `[generic]` on the clinical difference | G4 |
| R8 | Catheter care | must_have | direct | medium | none | Catheter care is stated on your CV | `[grounded]` CV | none |
| R9 | Insulin administration | must_have | direct | medium | none | Insulin administration is stated on your CV | `[grounded]` CV | none |
| R10 | End-of-life visits | must_have | unclear | low | discovery | The CV is silent. An acute medical ward is a plausible setting for end-of-life care, but that is a lead, not evidence. | `[inferred]` from the ward setting | G1 |
| R11 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about records or any electronic system | `[grounded]` CV silence | G2 |
| R12 | Continence care | important | unclear | low | discovery | Catheter care is confirmed. Wider continence care is not mentioned. | `[grounded]` CV | G3 |
| R13 | Care planning | important | unclear | low | discovery | The CV does not mention care planning | `[grounded]` CV silence | G3 |
| R14 | Holding a small caseload of your own | important | adjacent | medium | transferability | You have never held a caseload, as you state. Limit: nothing you have done carried personal responsibility for a patient list. The JD says a senior community nurse supports the post. | `[grounded]` your statement and JD | G5 |
| R15 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have never done one. The team lead has spoken on Doppler training for staff new to community work. | `[grounded]` your statement; speaker page | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R10, must_have) | discovery | Nothing on the CV about end-of-life care | The JD lists it as a core duty | Anticipatory medicines, last-days care plans, family conversations, syringe-driver involvement, discharge of dying patients home | A reflective piece or a training certificate | `[grounded]` CV silence |
| G2 | Written records on an electronic record (R11, must_have) | discovery | No electronic record system is named | The JD asks for clear, timely records | The electronic record system on your ward or in discharge-to-assess, and any audit of your documentation | Audit result or training record | `[grounded]` CV silence |
| G3 | Continence care and care planning (R12, R13, important) | discovery | Catheter care is stated; the rest is not | Both are in the JD's list of duties | Bladder and bowel assessment, continence products, care plans written for discharge | A care plan with patient details removed | `[grounded]` CV |
| G4 | Leg-ulcer care (R7, must_have) | transferability | Pressure-ulcer and surgical-wound care, but no leg-ulcer work | It is the first duty the JD names | Compression bandaging, ankle-brachial assessment support, leg-ulcer clinic sessions, tissue viability link work | A competency record or training certificate | `[grounded]` CV; limit named in R7 |
| G5 | Holding a caseload (R14, important) | transferability | Home visiting in discharge-to-assess, but no personal caseload | The JD offers a small caseload with senior support | Following a group of patients across a week, planning your own visiting day, escalating without a senior present | A description of your discharge-to-assess visiting day | `[grounded]` your statement |
| G6 | Doppler assessment (R15, preferred) | capability | None, and you have said so | It is desirable, not essential | Closure path: ask whether training is provided on appointment, since the team lead has spoken on Doppler training for newcomers to community work | The employer's training offer | `[grounded]` speaker page |
| G7 | Pay against your floor (R4, hard_gate) | hard_gate | The JD states £31,050–£37,800 plus mileage, and your floor is not given | A gate I cannot check | — | — | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page fetch returned no page, which could mean a different address, a closed vacancy or an unlisted post | `[inferred]` from the failed fetch | Is this vacancy open, and where is it listed on your careers page? | unresolved |
| RR2 | Rota and caseload size unstated | unknown | — | "You will hold a small caseload of your own" | Weekend, evening or on-call duties and the caseload size are not in the posting | `[inferred]` from the JD's silence | What are the visiting hours and weekend expectations, and what caseload would a nurse new to community work start on? | unresolved |
| RR3 | Supervised small caseload | positive_signal | — | "supported by a senior community nurse" | A senior nurse's support is built into the post, which suits a first community role | `[grounded]` JD | How does the senior community nurse support a new post-holder in the first months? | noted |
| RR4 | Doppler training signal | positive_signal | — | "Doppler training for staff new to community work" (speaker page) | The team lead has spoken on training for newcomers, so training may be offered, but that is not a statement about this post | `[inferred]` from the speaker page | Is Doppler training provided to new staff on appointment? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: lead with your 18-month discharge-to-assess secondment, kept in your own words ("visiting patients at home in their first week after discharge"). Add no district nursing claim and no leg-ulcer claim. | R6, R14 | `[grounded]` CV | pending your approval |
| E2 | Say plainly in any chat or cover note: "I haven't done a Doppler assessment and I would want training." | R15 | `[grounded]` your statement | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott and ask the verification questions from RR1, RR2 and RR4 | The register doubles as interview preparation | `[grounded]` JD and register | pending your approval |
| A2 | Check your NMC entry and your DVLA licence record yourself before applying | R1, R2 | `[grounded]` the map rows | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment, so I haven't used it. Only give it to the employer through their own portal after a written offer.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing" and found "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. This established the employer and left the posting unconfirmed (RR1). |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 requirements experience Doppler leg ulcer", which returned no results. It moved nothing, so there is no market calibration. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook" and found "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved role reality's scope read, G6 and RR4. |

If you'd like a saved record of this assessment, I can emit it as `tuesday-dossier.md`.

## Upgrade menu

- A link to the live posting or the careers page → RR1 closes.
- Your pay floor and any other non-negotiables, such as hours → R4 and G7 close.
- A competency record, training certificate or reflective piece on end-of-life or leg-ulcer care → R7 and R10 can rise toward `high`.
- Your ward's electronic record system and any documentation audit → R11 closes.
- A deeper research pass on Calderbrook (staff reports, service changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions** (the first two matter most, because they could change R7 and R10 from adjacent or unclear):

G1 — Have you looked after dying patients on the ward, and what part did you personally have in it (for example, anticipatory medicines, syringe drivers, family conversations or the care plan)?

G4 — Have you applied compression bandaging, helped with leg-ulcer dressings or been involved with the tissue viability team, even occasionally?

G7 — What is the lowest salary you'd accept, and are there any other terms you won't move on, such as weekend or evening work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.