I've run two searches, one on the employer and one on pay, and I'm writing up the assessment now.

# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead. Send nothing, and don't pay or lodge anything. This job is very likely a scam, and RR1, RR2, RR3 and RR4 are the reasons. Status: `no_go`.** I can't establish the firm from here, so I can't say who is behind these messages.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R3 · adjacent: R2 (Process orders), R4 (Strong attention to detail), R5 (Good written English)

R2 is neighbouring work with its limit named; R3 (`medium`) is confirmed and waiting on an artifact.

**Opportunity ledger.** The messages ask for equipment payment (RR1), a cheque deposit with onward transfer (RR2), and bank, tax and passport details before any offer (RR3). They also run the whole hiring process by chat (RR4). The pay terms don't establish your floor (RR5), and I couldn't establish the employer (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the demands would have to be absent. That means no payment, cheque or ID details before an offer. It also means an interview on a call or video with someone at an employer you can find independently, plus a written offer from that employer's own address stating the base rate and contract basis.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". One search for its official site and careers page returned no results, so it is not established | `[grounded]` search returned nothing |
| Role | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed | `[grounded]` posting |
| Pay arithmetic | At the ceiling rate, 15 hours a week is about €20,280 a year and 30 hours is about €40,560. Reaching €30,000 takes about 22 hours a week at the ceiling rate, and "up to" means the base rate is unknown | `[inferred]` from the posting's figures, 52 weeks |
| Market calibration | A 2026 Irish pay guide puts salaried order-processing and customer-operations coordinators at a median of €31,200 a year (interquartile range €28,400–€34,100). It excludes commission-only and freelance work, so it is not like-for-like. At 40 hours a week that median is about €15 an hour | `[generic]` pay guide; `[inferred]` hourly conversion |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Unknowns | Employee or self-employed; base rate against commission; who the "equipment partner" is; the employer's own site | `[grounded]` absent from the material |
| Contradictions | First you were told to pay €349 to be refunded with first wages. Then you were told to lodge a €2,850 cheque, keep €350 and transfer the remainder | `[grounded]` the two messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | The confidence grades your own stated floor. Fit is `unclear` because the posting gives only a ceiling rate and a 15–30 hour range | `[grounded]` your statement and the posting; `[inferred]` arithmetic | RR5's question, only once an employer is verified |
| R2 | Process orders | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day at a parcel courier is neighbouring work. Limit: it is not order entry, and the posting doesn't define the work | `[grounded]` your background; `[inferred]` adjacency | see G1 |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep a weekly team tracker in Excel. It is specific and confirmed, but no artifact has been inspected, so expect a probe | `[grounded]` your statement | offer: a sanitized tracker screenshot would raise it to high |
| R4 | Strong attention to detail | must_have | adjacent | low | discovery | Ticket volume and tracker upkeep point toward accuracy, but you've given no accuracy evidence | `[inferred]` from your ticket and tracker work | none, since the decision doesn't turn on it |
| R5 | Good written English | must_have | adjacent | low | discovery | Ticket work usually involves writing, but you haven't described it, and training two starters is not writing evidence | `[inferred]` from your ticket work | none, since the decision doesn't turn on it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Order processing (R2, must_have) | transferability | Ticket handling at a courier, with no order-entry work described | Real order-processing roles would probe this line | Entering or amending customer orders in your ticketing system; reconciling parcel orders against records | A sanitized process note or tracker excerpt | `[inferred]` bridge from your ticket work |
| G2 | Pay of at least €30,000 (R1, hard_gate) | hard_gate | Only "up to €26 an hour plus commission" with no base rate | This gate decides whether any real version of this job works for you | Not applicable: wording cannot meet a pay gate | A written offer from a verified employer stating base rate, hours and contract basis | `[grounded]` posting terms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. Don't send the payment. Who sent the messages is unresolved | `[grounded]` the message asks for payment; `[generic]` requests like this are a known scam pattern | To the employer, through contact details you find yourself on its own website, never this chat: "Did your company ask me to pay for equipment, and who is the equipment partner?" | confirmed |
| RR2 | Cheque deposit with onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. Don't deposit the cheque or transfer anything | `[grounded]` the message; `[generic]` known pattern | Same route as RR1: "Did your company send a cheque, and why am I asked to transfer part of it onward?" | confirmed |
| RR3 | Bank, tax and ID details demanded before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details were asked for before any offer. A passport photo isn't needed for this stage | `[grounded]` the message asks before an offer | Same route as RR1: "Do you need these details at this stage, and where do I enter them on your own site?" | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The posting says interview and offer both happen only in chat, so nothing lets you check who is on the other end | `[grounded]` the posting, then "you passed the interview and the job is yours" after chat answers | Same route as RR1: "Will someone from the company interview me by call or video, and send a written offer from the company's own address?" | confirmed |
| RR5 | Pay stated only as a ceiling | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process" | The base rate is withheld, and the ceiling sits well above the pay guide's median for no stated experience. Your floor is met only toward the top of the hours range | `[inferred]` from the posting's figures; `[generic]` pay guide | What is the base hourly rate, how is commission paid, and is this employment or self-employment? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | It may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't paste your IBAN, and don't send the passport photo or your PPS number | see RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Don't pay the €349 and don't lodge the cheque | see RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |
| A3 | Look for the company's own website independently and use only contact details found there | see RR6 | `[grounded]` RR6 | pending your approval |
| A4 | Report the posting to the jobs site you found it on. If you ever send money or details, tell your bank straight away | Standard steps after a suspect request | `[generic]` general advice | pending your approval |
| A5 | Put your effort into other openings, led by your 60-tickets-a-day Zendesk work, training two new starters and the Excel weekly tracker | This role is `no_go`, and those three are your confirmed evidence | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official website careers", which returned nothing. Not established; it fed RR6 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland hourly pay", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It fed market calibration and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a chat handle, so there was no query to form |

If you'd like, I can write all of this up as a `tuesday-dossier.md`.

## Upgrade menu

- The posting's link or the jobs site's name → I can check whether the listing is live and what the site says about the employer (RR6).
- A written offer from an address on a verified employer's own domain → R1 and RR5 can close, and the decision could be re-run.
- A sanitized tracker screenshot → R3 to `high`.
- A deeper pass on the employer named in the posting (up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

RR6 — Which jobs site was the posting on, and could you paste its link? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.