I checked the live careers page and the About page. Here is the assessment.

## Decision snapshot

**Yes, this is worth applying to. R1 and R2 are still unchecked against your constraints. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R7, R8
- `important` — adjacent: R6 (BigQuery warehouse) · unclear: R9 (data contracts), R10 (ingestion from app and CRM)

R6 — a credible bridge from Snowflake, its limit named; R9 and R10 — the posting names them and your background doesn't yet speak to them; R1, R2 — terms waiting on your constraints.

**Opportunity ledger.** The pay and requirements are plainly stated and sit inside the market band you sent (RR3). The reporting line, the team's scope and the equity terms are open (RR1, RR2, RR4), and the employer's funding and size come only from its own pages (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 hold against your location, authorization and pay floor; (2) the scope question in RR2 comes back as one domain's pipelines, not the whole data function; (3) the BigQuery bridge is presented as Snowflake experience, never as BigQuery experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About page, fetched via search result |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, live careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Stated pay | $148,000–$166,000 base plus equity; equity terms not stated | `[grounded]` JD |
| Scope read | Three jobs in one posting: ingestion, warehouse modelling and contracts. It could be a sole-owner role or a team seat; the posting doesn't say | `[inferred]` from the mandate's breadth against its silence on team size |
| Market calibration | Your recruiter's report puts Senior Data Engineer at Series B–D companies at a $151,000 median base, interquartile range $139,000–$163,500, "senior" usually 5–8 years, and scope usually one domain's pipelines with no reports. The posted range starts just under that median and tops out above the interquartile range's upper end. Your 6 years sits inside the usual 5–8 | `[grounded]` Datawright 2026 report, n=2,310, as you pasted it; `[inferred]` the comparison to this posting |
| Unknowns | Hiring manager (none named), team size, equity amount and vesting, whether pay differs for remote versus Denver | `[grounded]` JD silence |
| Contradictions | None. The live careers page matches the text you pasted, and the About page matches the About text | `[grounded]` both pages fetched |

## Evidence map

Your background was typed into the conversation, so it counts as self-report at intake, and nothing here reaches `high` without an artifact to inspect.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or where you're authorized to work, so the term can't be checked | `[grounded]` JD; no statement from you yet | Answer closing question R1/R2 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so I can't say whether the range meets it. Equity terms are not stated | `[grounded]` JD; no statement from you yet | Answer closing question R1/R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, specific but not yet backed by an inspectable artifact. Years of experience is not a gate | `[grounded]` your stated background | A CV or LinkedIn history would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, stated by you. No artifact yet | `[grounded]` your stated background | A repo or sanitized model/code sample would raise it |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | A dbt project of about 180 models on Snowflake meets "dbt and a cloud warehouse" as the requirement is worded. BigQuery is carried separately in R6 | `[grounded]` your stated background | A sanitized project structure or lineage graph would raise it |
| R6 | Warehouse in BigQuery (named in the mandate) | important | adjacent | medium | transferability | Snowflake is the same kind of work, but you have never used BigQuery. Limit: you haven't run BigQuery's own cost, partitioning or access model | `[grounded]` your stated background and the JD; `[generic]` that warehouses differ in these operating details | See gap G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly, matching the requirement | `[grounded]` your stated background | A sanitized DAG would raise it |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite yourself, which is ownership of the work | `[grounded]` your stated background | A sanitized suite or coverage summary would raise it |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Your dbt and Great Expectations work is nearby, but you haven't described agreed schemas, freshness or breaking-change rules with consumers | `[grounded]` the JD and your silence on it; `[inferred]` that your tests may be adjacent | See gap G2 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your Airflow work shows pipelines, but not which source systems you ingested from | `[grounded]` the JD and your silence on source systems | See gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Bridge: six years on Snowflake with dbt, the same modelling and orchestration work. Limit: BigQuery itself has not been exercised. Strengthener: a small dbt project run on BigQuery | It is the one named tool you haven't used, so the screen will likely test it | A personal or sandbox BigQuery project; a migration or cost-tuning task on any warehouse | A repo with a README showing a dbt model built and tested on BigQuery | `[grounded]` the stated gap; `[inferred]` that a small project narrows it |
| G2 | Data contracts (R9, important) | discovery | Tests exist, but agreed expectations with downstream consumers aren't described | The role names contracts as a core duty, so evidence here could move R9 | Schema or freshness agreements with analysts; tests that blocked a bad load; a changelog process for breaking changes | A contract doc, a tests config, or a sanitized runbook | `[grounded]` the JD's wording and your silence on it |
| G3 | App and CRM ingestion (R10, important) | discovery | Pipelines are described, but not the source systems | The role starts at ingestion from two named kinds of source | Pulling from a product database, event stream, or CRM API such as Salesforce or HubSpot; handling API changes or backfills | A DAG diagram or source inventory | `[grounded]` the JD and your silence on sources |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager named | unknown | — | "The posting names no hiring manager" (your note) | The reporting line may sit with engineering, analytics or a head of data | `[inferred]` from the posting's silence | Who does this role report to, and what is their background? | unresolved |
| RR2 | Broad mandate, team size unstated | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | You may be the sole data engineer owning the stack end to end, wider than the one-domain scope in your recruiter's report | `[inferred]` from the mandate against your pay report's typical scope | How many data engineers are on the team, and which domains would this role own? | unresolved |
| RR3 | Pay stated and in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The employer shows a figure and it sits within the market band you sent | `[grounded]` JD and recruiter's report | Where in the range would a candidate with 6 years land? | noted |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and strike may be material to the total offer | `[inferred]` from the posting naming equity without a figure | What is the equity grant range for this level, and how does it vest? | unresolved |
| RR5 | Funding and size verified only on the employer's own pages | unknown | — | "Series C ($52M, February 2026)" | The funding and headcount claims have no second source here; this is a thin check, not a doubt about the company | `[grounded]` the one search returned only the company's own About page | Can you share the current team structure and runway for the data function? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Order your resume so the 180-model dbt project, Airflow orchestration and the Great Expectations suite come first, using your own wording | see R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| E2 | Name Snowflake plainly and add no BigQuery claim until a G1 project exists | see R6, G1 | `[grounded]` your stated background | pending your approval |
| W1 | A small public dbt-on-BigQuery project with tests, to turn the BigQuery gap into something inspectable | see G1 | `[inferred]` from R6's limit | pending your approval |
| Q1 | Ask the questions in RR1, RR2 and RR4 verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): the posting is live and matches your pasted text. Searched "Pellucid Learning Series C tutoring Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching the About text. Moved role reality's contradictions row and RR5, which stays an unknown because both pages are the employer's own |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the market calibration line and the pay comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Upgrade menu

- Your pay floor, location and work authorization → R1 and R2 move to `direct` or `hard_gate_fail`, and the decision firms up to `go` or `no_go`.
- Answers to G2 and G3 → R9 and R10 resolve.
- A sanitized dbt project, DAG or Great Expectations config → R3, R4, R5, R7 and R8 can rise toward `high`.
- A small BigQuery project → G1's limit narrows.
- The hiring manager's name, once you learn it → role reality's scope read, and which story to lead with for that reader.
- A deeper research pass on Pellucid Learning (funding, leadership churn, employee and candidate reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can write all of this into a `tuesday-dossier.md` for later steps if you'd like one.

R1/R2 — Where are you based and authorized to work, would you take remote or Denver, and what is the lowest base salary you'd accept?

G2 — Have you set explicit schema, freshness or breaking-change expectations with the analysts or teams who consumed your models, even informally, and who owned them?

G3 — Which source systems did your pipelines ingest from (product database, event stream, CRM or other APIs), and which of those did you build yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.