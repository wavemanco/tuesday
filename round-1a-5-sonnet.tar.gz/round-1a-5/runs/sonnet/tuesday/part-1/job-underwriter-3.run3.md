Web search wasn't available, so this runs on your posting and your own constraints only.

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in the Austin office 5 days a week), R2 (Compensation: $70–85k base)
- `must_have` — direct: R4 · unclear: R3 (8+ years growth leadership)
- `important` — direct: R5, R6 · adjacent: R10 (Team of one, thrive on ambiguity) · unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships and sales ops)

R1, R2 — pay and location fail your two constraints, and no framing changes that; R4, R5, R6 — the revenue ownership, paid and lifecycle work you describe matches; R3, R7, R8, R9 — what you've told me doesn't settle them.

**Opportunity ledger.** What feels off shows up in the register in three places. The terms collide with your constraints on location and pay (RR1, RR2). The posting puts a very wide scope on one person (RR3) beside always-on hours (RR4) and success measures that can move (RR5). The employer is also unchecked (RR7). Equity is unquantified (RR6), and the CEO reporting line is the one clear positive (RR8).

- **Hard gates:** failed: R1 (On-site in the Austin office 5 days a week), R2 (Compensation: $70–85k base).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** Novaline would have to offer a role you can do from Portland (R1) at a base of at least $150k (R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup at Series A, "profitable since day one", with an Austin office | `[grounded]` posting header; not checked against any outside source |
| Mandate | Own revenue growth end to end across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus equity with no figures given | `[grounded]` posting |
| Seniority required | 8+ years of growth leadership | `[grounded]` posting |
| First-year outcomes | Not stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | One person carries functions that usually have separate owners | `[inferred]` from the function list against "team of one"; `[generic]` that these functions usually have separate owners |
| Market calibration | Not run. The role-family sweep wasn't available, so $70–85k isn't placed against norms for this title and scope | — |
| Unknowns | Equity terms; headcount and budget; what success means; whether the employer and posting check out on Novaline's own site | — |
| Contradictions | None found, but only the posting was read | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in the Austin office 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own statement (remote-only, Portland, not relocating), which is specific and confirmed. Fit fails because the posting allows no remote day | `[grounded]` posting quote; your stated constraint | Only you or the employer changing terms resolves it |
| R2 | Compensation: $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k base floor, your own and specific. Fit fails because the top of the range sits $65k below it. Your floor is on base, so the unquantified equity can't close the gap | `[grounded]` posting figures; your stated floor | Same as R1 |
| R3 | 8+ years growth leadership | must_have | unclear | low | discovery | You state 9 years in growth, the later ones as Growth lead then Head of Growth. The posting asks for leadership years, and you haven't said how many of the 9 were in a lead or head role. I read it downward. Self-reported, nothing inspectable | `[grounded]` your stated background | Dated role history would settle it; see G1 |
| R4 | Own revenue growth end to end, with a budget | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. That is specific and plausible but self-reported. Limit: your note names paid, lifecycle and experimentation, not every function the posting lists | `[grounded]` your stated background | none; a channel P&L or board-deck excerpt would raise it to `high` |
| R5 | Paid acquisition | important | direct | medium | none | You state you owned paid. Specific, no artifact yet | `[grounded]` your stated background | none |
| R6 | Lifecycle/CRM | important | direct | medium | none | You state you owned lifecycle and name Braze as a deep skill. Specific, no artifact yet | `[grounded]` your stated background | none |
| R7 | SEO/content | important | unclear | none | discovery | Your note is silent on SEO and content. Silence isn't evidence either way | `[grounded]` the silence in your note | see G2 |
| R8 | Brand and PR | important | unclear | none | discovery | Same: your note doesn't mention brand or PR | `[grounded]` the silence in your note | see G2 |
| R9 | Partnerships and sales ops | important | unclear | none | discovery | Same: your note doesn't mention partnerships or sales ops | `[grounded]` the silence in your note | see G2 |
| R10 | Run growth as a team of one, thrive on ambiguity | important | adjacent | low | transferability | You built and managed teams of 3–7 and owned experimentation. Neither says you executed hands-on across channels without a team. Team-building is not solo execution | `[inferred]` adjacency derived from your team and experimentation work | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Years in a lead or head role (R3, must_have) | discovery | 9 years in growth, titles Growth lead then Head of Growth, no dates per title | A must_have I can't confirm. It would not move the status while R1 and R2 stand | Time as Head of Growth, plus time as Growth lead where you managed people or a budget | Dated role history, such as a resume or LinkedIn export | `[grounded]` your stated background |
| G2 | SEO/content, brand/PR, partnerships/sales ops (R7, R8, R9, important) | discovery | Your note lists paid, lifecycle, experimentation, SQL, GA4, Braze and team building, and nothing on these three areas | Each is a listed function of the role. It would not move the status while R1 and R2 stand | Landing-page or organic-traffic programmes; a launch with a press push; referral, affiliate or channel partnerships; reporting pipeline with a sales team | An organic-traffic report, a campaign brief, a partner dashboard | `[grounded]` the silence in your note |
| G3 | Hands-on execution without a team (R10, important) | transferability | Teams of 3–7 and owned experimentation | The role is a team of one. Limit: leading channel owners isn't the same as running the channels yourself | A period in your early growth roles when you ran a channel end to end | A dashboard or experiment log from that period | `[inferred]` bridge derived from your team and experimentation work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site term conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role is unavailable to you on its stated terms | `[grounded]` posting quote; your stated constraint | Is the five-day on-site term final for this role? | confirmed |
| RR2 | Posted base is below your floor (see R2) | red_flag | high | "Compensation: $70–85k base plus meaningful equity upside" | Even the top of the range is under your base floor, and equity doesn't count toward a base floor | `[grounded]` posting figures; your stated floor | Is $70–85k the final base band for this role? | confirmed |
| RR3 | Many specializations on one person | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | You may be accountable for every listed function with no headcount or agency budget, at a base that looks low for the scope | `[inferred]` from the function list against "team of one" and the base range; the market comparison was not run | What headcount and budget are committed to this role in its first year, and when does "to start" end? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine rather than occasional | `[inferred]` from the culture framing and the absence of any stated recognition of that time | In the last quarter, how many evenings or weekends did the team work, and how is that time recognised? | unresolved |
| RR5 | Success measures undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You would own revenue with no agreed target, so the yardstick could move after you start | `[inferred]` from the posting's silence on targets against "Own all revenue growth" | What revenue outcome would count as a good first 12 months, and who agreed it? | unresolved |
| RR6 | Equity unquantified | unknown | — | "meaningful equity upside" | The grant could be material or negligible; the posting doesn't say | `[grounded]` the posting names no figure | What percentage, vesting schedule and strike price does the grant carry, and at what valuation? | unresolved |
| RR7 | Employer not established from attributable sources (the check did not run) | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR8 | Reports to the CEO with a board dotted line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Direct access to the people who set priorities | `[grounded]` posting | Which spend and hiring decisions does this role make without CEO sign-off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply or tailor your CV while R1 and R2 stand | see R1, R2, RR1, RR2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Only if you want to test whether the terms move: send the employer RR1's and RR2's questions before spending any application effort. Use contact details from Novaline's own site | see RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | Confirm the posting is live on Novaline's own careers page before anything else | see RR7 | `[grounded]` RR7 | pending your approval |

## Evidence status

Verified: none yet. Stage assumed to be evaluating, since you haven't said you've applied or been contacted. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have moved role reality's organization and contradictions rows and RR7 |
| 2. Role-family sweep | unavailable | The search was refused. It would have moved the market calibration row and the pay-versus-scope comparison in RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you'd like this saved, I can emit it as `tuesday-dossier.md`.

## Upgrade menu

- A link to this role on Novaline's own careers page, or the recruiter's email domain: RR7 resolves.
- The employer's answers on headcount, budget and the on-site and base terms: RR1, RR2 and RR3 close, or the hold on them holds.
- The equity percentage, vesting and strike price: RR6 closes.
- Dated role history for your Growth lead and Head of Growth titles: R3 resolves.
- An organic-traffic report, a campaign brief or a partner dashboard: R7, R8 and R9 move off `unclear`.
- Web search enabled: targets 1 and 2 run, and RR7 and RR3's pay comparison get an outside check.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.