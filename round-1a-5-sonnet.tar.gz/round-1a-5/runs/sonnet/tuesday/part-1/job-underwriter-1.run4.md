Web searches weren't permitted, so this runs on your JD and background alone, with no research.

## Decision snapshot

**Yes, apply, and you are a fit on the must-haves: R1, R2, R3, R4 and R5, the must-have rows, are `direct`. Status: `conditional_go`, on the condition that the posting and employer verify (RR1).**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · adjacent: R6 (Define and maintain the metrics layer), R7b (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R6 — a credible bridge from governed Looker work, its limit named; R8 — your background is silent on mentoring; R9 — regulatory adjacency, not healthcare experience.

**Opportunity ledger.** The role is clearly scoped, with named duties and two junior analysts to mentor (RR4). The employer could not be checked from here (RR1), compensation is unstated (RR2), and whether the metrics layer already exists is unknown (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on the company's own careers page and the employer matches the description, per RR1; (2) pay and work arrangement are acceptable to you, per RR2 and the constraints question below; (3) the metrics-layer scope is "extend and own", not "build the warehouse semantics from nothing", per R6 and RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header, not independently verified |
| Mandate | Own product analytics: the metrics layer, A/B test design and analysis, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Stated requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; healthcare data (HIPAA) is a plus | `[grounded]` JD |
| Scope read | Senior individual contributor with light people leadership: two named mentees, no stated reports or budget | `[inferred]` from the mentoring clause against the JD's silence on management scope |
| First-year outcomes | Not stated; "turn analysis into roadmap decisions" is the closest thing to a success definition | `[grounded]` JD silence |
| Market calibration | Not run; no search was available, so no pay band is given | `[generic]` nothing asserted; the upgrade menu says what research would add |
| Unknowns | Compensation, location and remote policy, whether a metrics layer exists today, the size of the experimentation program | `[grounded]` JD silence |
| Contradictions | None found between the JD and your background; the JD was not checked against a careers page | `[grounded]` provided documents only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a meal-kit subscription company. Specific and confirmed, but background prose is the intake ceiling and no inspectable artifact has been seen | `[grounded]` your background, stated | none |
| R2 | Expert SQL | must_have | direct | medium | none | You say you write SQL daily on a Snowflake warehouse; "expert" is your claim and nothing here tests it, so expect a live SQL exercise | `[grounded]` your background; `[generic]` that analyst loops usually include a SQL screen | Offer: a sanitized query or model sample would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Limit: the 2M-subscriber base is the scale you evidenced, and this app's traffic is unknown | `[grounded]` your background | Offer: a sanitized experiment brief or readout would raise it to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, 40+ governed dashboards. Confirmed and specific; no screenshot or model seen | `[grounded]` your background | Offer: a dashboard screenshot or LookML excerpt would raise it to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. A memo sample would be the inspectable proof | `[grounded]` your background | Offer: a sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | Governed dashboards imply shared metric definitions, but you have not said you owned a semantic layer or a metric dictionary. Left unconfirmed rather than assumed | `[grounded]` your background says "governed"; `[inferred]` the definitions work behind it | See gap queue G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | You present monthly to the VP Product. The link from the pricing test to a roadmap decision is inferred, not stated, so the claim stays at `medium` | `[grounded]` monthly VP Product presentation; `[inferred]` decision link from the pricing test | Later: ask which roadmap decision a test changed |
| R7b | Partner with clinicians | important | adjacent | low | transferability | Your partnering with non-technical execs carries over. Limit: you have not worked alongside clinical experts, who judge evidence differently from commercial stakeholders | `[grounded]` exec partnering; `[inferred]` the bridge | See gap queue G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background is silent on mentoring. Not asked about before, so there is no answer to carry | `[grounded]` background silence | See gap queue G2 |
| R9 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | You have handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. Limit: you have not worked in healthcare or under HIPAA, and PHI handling is its own regime | `[grounded]` your background; `[generic]` that regimes differ in obligations | See gap queue G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | Governed Looker dashboards, but no confirmation you defined and maintained metric definitions | Metrics ownership is the first duty the JD lists, and it decides whether this reads as a stretch or a match | Writing a metric dictionary; LookML measures reused across dashboards; resolving a "which number is right" dispute; a metric changelog | A metric-definitions doc, a LookML excerpt, a governance note | `[grounded]` background silence on definitions; `[generic]` that this duty is usually probed |
| G2 | Mentoring (R8, important) | discovery | Nothing in your background about reviewing or coaching other analysts | The JD names two junior analysts; a blank here reads as unknown, not as a no | Reviewing analyses, onboarding a new analyst, running SQL or experiment-design sessions, an informal buddy | A review checklist, an onboarding doc | `[grounded]` background silence |
| G3 | Clinician partnership (R7b, important) | transferability | Exec partnering confirmed; no clinical stakeholders | The JD names clinicians as a partner group, and the app is a care product | Working with any subject-matter experts such as nutrition or food-safety staff, or translating findings for non-analyst experts | A write-up for a specialist audience | `[inferred]` bridge from exec partnering |
| G4 | Healthcare data (R9, preferred) | transferability | GDPR/CCPA PII and a consent-state model, no healthcare or HIPAA work | A plus, not a requirement, so it is a minor risk rather than a blocker | Consent and purpose-limitation modelling, access controls, de-identification or aggregation rules | A consent-model diagram or data-governance doc | `[grounded]` background; `[generic]` that regimes differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be real and simply not yet checked, the posting may be stale or aggregated, or it may not represent a hiring employer | `[generic]` pattern for any posting not yet verified, not a claim about this company | Can you point me to this role on your own careers site, and say who I would interview with? | unresolved |
| RR2 | Compensation, location and remote policy unstated | unknown | — | "Senior Product Analyst — Harborlight Health" | The JD may leave pay and location to the recruiter, or may withhold them | `[inferred]` from the JD's silence on both | What is the salary band for this role, and is it remote, hybrid or on-site? | unresolved |
| RR3 | Metrics-layer starting point unstated | unknown | — | "define and maintain the metrics layer" | The layer may already exist, or "define" may mean building it, which is a larger remit | `[inferred]` from "define and maintain" against the JD's silence on current state | Does a metrics layer exist today, and which tool holds it? | unresolved |
| RR4 | Scope is concrete, with mentees named | positive_signal | — | "mentor two junior analysts" | A defined team and duties suggest a scoped senior role | `[grounded]` JD | Who do the two analysts report to today, and who do I report to? | noted |

## Application plan

All of these are proposed language or actions for you to approve. The resume lines are `resume_edits_pending_approval`, and each wording traces to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Harborlight's own careers page before investing in the application | See RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the resume with: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | See R3; the clause is your own wording | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Pair it with: "Built the company's Looker instance from scratch: 40+ governed dashboards" | See R4 | `[grounded]` your background | resume_edits_pending_approval |
| E3 | Describe your PII work as "handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse". Do not write or imply HIPAA experience | See R9; the regime differs, and the claim is not yours | `[grounded]` your background | resume_edits_pending_approval |
| E4 | Keep the monthly metrics memo and VP Product presentations as the proof for written communication | See R5 | `[grounded]` your background | resume_edits_pending_approval |
| Q1 | Ask the RR1 to RR4 verification questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was not granted. It would have moved role reality's organization and contradictions rows and RR1, which stands as the unresolved employer entry |
| 2. Role-family sweep | unavailable | Search permission was not granted. It would have moved role reality's market calibration row and the pay check in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## The dossier offer

If you want a record of this assessment to carry into later steps, I can emit it as `tuesday-dossier.md`.

## Upgrade menu

- Permission to search the web → targets 1 and 2 run: RR1 resolves, a market pay band sets RR2, and the role-reality contradictions row gets checked against the careers page.
- A sanitized SQL sample, experiment readout, LookML excerpt or dashboard screenshot → R2, R3 or R4 to `high`.
- A sanitized monthly metrics memo → R5 to `high`.
- An answer to G1 or G2 → R6 or R8 moves off `low`.
- The hiring manager's name → role reality's scope read, and which story the application leads with for that reader.
- Your constraints (pay floor, location, remote policy) → the hard-gates line gets real checks in place of the flag.

**Questions**

G1 — Did you define and maintain shared metric definitions (a metric dictionary, LookML measures others reused, a changelog), and who owned them? Name a case where you settled a "which number is right" dispute.

G2 — Have you ever coached, reviewed or onboarded another analyst, formally or informally? What did you do for them, and how many people?

Constraints — What is your pay floor, and what location or remote arrangement do you need? These decide whether the role can fail a hard gate for you.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.