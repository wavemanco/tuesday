Search permission wasn't granted, so this assessment uses only your message and the posting.

## Decision snapshot

**No, this posting isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 (Base of $70–85k)
- `must_have`: direct: R4, R5 · unclear: R3 (8+ years growth leadership), R6 (SEO/content)
- `important`: unclear: R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one to start)

R1: on-site terms against your remote-only limit; R2: stated base against your $150k floor; R4 (`medium`): paid acquisition, stated and uninspected; R5 (`medium`): lifecycle in Braze, stated and uninspected.

**Opportunity ledger.** The role's terms conflict with your constraints (RR1, RR2). It folds seven functions into one person (RR3), with after-hours expectations (RR4) and undefined success (RR5). The employer is unverified (RR6). One entry runs the other way: CEO reporting (RR7).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week, no exceptions), R2 (Compensation: $70–85k base).
- **Severe red flags:** none found.
- **What would change this:** the posting would have to state remote work from Portland (R1) and a base of at least $150k (R2). How the role is framed doesn't change either term. Whether to revise a constraint is your call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; the claims are unchecked outside the posting |
| Mandate | Own all revenue growth: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | A team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside"; equity terms not stated | `[grounded]` JD |
| Success metrics | "Will evolve as we learn"; none stated | `[grounded]` JD |
| Scope read | Seven functions with no stated team, budget or tools | `[inferred]` from the JD's function list against its silence on resources |
| Market calibration | Not established: the role-family sweep did not run, so I won't place the title or pay against a band | `[grounded]` the search was refused |
| Unknowns | Equity size and vesting; budget controlled; who the board is; what success means at 90 days and 12 months | n/a |
| Contradictions | None found within the posting; not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | The confidence grades your stated limit, which is yours, specific and confirmed. The fit fails because the JD fixes five on-site days and you are remote-only in Portland. | `[grounded]` JD quote and your message | Only changed terms resolve it; see RR2 |
| R2 | Compensation: $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | The confidence grades your $150k floor, which is your own and confirmed. The posting's top figure is below it. | `[grounded]` JD quote and your message | Only changed terms resolve it; see RR1 |
| R3 | 8+ years growth leadership | must_have | unclear | low | discovery | You state 9 years in growth with lead, then Head titles. How many of those years were lead or head roles isn't stated, and I resolve that downward. | `[grounded]` your message is silent on leadership tenure | G1 |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at two B2C subscription companies, with budget control during the $8M to $40M ARR scale-up. It is specific, with no inspectable artifact yet, so expect a probe. | `[grounded]` your message | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Same limit: no artifact inspected yet. | `[grounded]` your message | none |
| R6 | SEO/content | must_have | unclear | none | discovery | Nothing in your message touches SEO or content. | `[grounded]` your message is silent | G2 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Your message is silent on all three. | `[grounded]` your message is silent | G3 |
| R8 | Sales ops | important | unclear | none | discovery | Your message is silent on sales ops. | `[grounded]` your message is silent | G4 |
| R9 | Team of one to start | important | unclear | low | discovery | You built and managed teams of 3–7 and owned experimentation. Solo hands-on execution across functions isn't stated. | `[grounded]` your message | G5 |

## Gap recovery queue

No answer here touches R1 or R2, so none of these rows moves the status.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Growth leadership tenure (R3, must_have) | discovery | 9 years in growth; years in lead or head titles not stated | Settles whether R3 is `direct`; moves nothing past R1 and R2 | Dates of the lead and Head titles at both companies | LinkedIn dates, offer letters, org charts | `[grounded]` your message |
| G2 | SEO/content (R6, must_have) | discovery | No SEO or content work stated | Only relevant if the terms changed | Owning organic traffic targets, briefing content, technical SEO fixes | A traffic dashboard or content calendar | `[grounded]` your message is silent |
| G3 | Brand, PR, partnerships (R7, important) | discovery | None stated | Only relevant if the terms changed | Launch PR, affiliate or channel partnerships, brand campaigns you ran | A campaign recap or partner list | `[grounded]` your message is silent |
| G4 | Sales ops (R8, important) | discovery | None stated | Only relevant if the terms changed | CRM and pipeline reporting, lead routing, handoffs to sales | A pipeline dashboard or routing spec | `[grounded]` your message is silent |
| G5 | Solo execution (R9, important) | discovery | Team-building shown; solo execution not | Only relevant if the terms changed | Periods you ran channels yourself before or between hires | A channel-level results summary | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base of $70–85k against your $150k floor (R2) | red_flag | medium | "Compensation: $70–85k base plus meaningful equity upside." | Pay may be set for a narrower or more junior mandate than seven functions and "Head" imply | `[inferred]` from the JD's scope against its stated base; the market band did not run | What is the full cash and equity package budgeted for this post, and how is the equity sized and vested? | unresolved |
| RR2 | Five on-site days against your remote-only limit (R1) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions." | The role cannot be done from Portland on these terms | `[grounded]` JD quote and your stated limit | Is the five-day Austin on-site term fixed for this post, as the posting says? | unresolved |
| RR3 | Several full roles bundled into one title with no resources named | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench." | You may be accountable for seven functions without headcount, budget or tools | `[inferred]` from the JD's function list against its silence on resources | What budget, tools and headcount are committed in year one, and who executes until a team exists? | unresolved |
| RR4 | After-hours work framed as culture | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine, not exceptional | `[inferred]` from the phrasing | In the last quarter, how many evenings or weekends did the team work, and for what? | unresolved |
| RR5 | Accountability without defined success | risk_signal | medium | "success metrics will evolve as we learn" | You could own all revenue growth with no agreed measure | `[inferred]` from the JD's silence on targets | What would count as a good result at 90 days and at 12 months, and who decides? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board." | The role may have real access and visibility | `[grounded]` JD states it; unverified | How often does this role present to the board, and on what? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the posted terms | See R1, R2 | `[grounded]` JD and your stated constraints | pending your approval |
| A2 | If you proceed against `no_go`, ask the questions in RR1, RR2, RR3, RR4, RR5 and RR6 verbatim before investing further | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Filter future postings on remote and a base of at least $150k before reading the rest | These are your stated gates | `[grounded]` your message | pending your approval |

Offer beyond this assessment: I can turn your two constraints into a short screening checklist for postings, so mismatches show up in the first read. Say yes and I'll build it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched for Novaline's careers and company presence, and the call was refused. It would have fed role reality's organization row and RR6. |
| 2. Role-family sweep | unavailable | I searched for Head of Growth pay at Series A companies, and the call was refused. It would have fed the market calibration line and RR1. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I'd offer a one-sentence version of this dossier as a saved `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Search access, so I can run the careers-page check, closing RR6 and the organization row.
- A role-family pay sweep, to set the market calibration line against $70–85k and sharpen RR1.
- The dates you held lead and head titles, to settle R3.
- Any SEO/content, brand/PR/partnership, sales-ops or solo-execution work, to move R6, R7, R8 and R9.
- The hiring manager's name, to ground the scope read.
- A deeper research pass on Novaline (up to 5 more searches and 2 more fetches), if search is allowed. It couldn't change R1 or R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.