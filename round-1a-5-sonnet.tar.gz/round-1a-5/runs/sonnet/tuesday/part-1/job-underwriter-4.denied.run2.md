Web research wasn't permitted, so I ran this on your JD and background alone.

## Decision snapshot

**Yes, go for it, once R1 is confirmed and the posting checks out (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important` — unclear: R8 (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R10 — a credible bridge from motor, its limit named; R5b — monitoring waits on your description; R8 — the product side has no evidence yet.

**Opportunity ledger.** Unremarkable so far, and unchecked. The employer has not been verified (RR1), and pay and team size are unstated (RR2, RR3). The JD does name concrete deliverables (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this (conditions for go):**
  1. You confirm R1.
  2. The posting is verified live on Brindlemoor's own careers page (RR1).
  3. Pay meets your floor, which you haven't given me yet (RR2).
  4. The pet-insurance bridge is framed as adjacent, never as pet-pricing experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product; not checked against any outside source | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, give recommendations to underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` as you gave it |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | One analyst owning a single product line's pricing analytics under a Director; whether anyone reports in, or sits beside the role, is unknown | `[inferred]` from "Own" against the JD's silence on team |
| Market calibration | Not calibrated: the role-family sweep did not run, so no pay band or title norm is offered | — |
| Unknowns | Salary, contract type, team size, whether the role manages anyone, first-year outcomes, employer verification | `[grounded]` JD silence |
| Contradictions | None between your account and the JD; there is no third source to compare against | `[grounded]` the two inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | You work at a UK insurer, which suggests UK residence but doesn't establish it or the right to work. You haven't stated any constraint. | `[grounded]` JD and your account; `[inferred]` UK-based from a UK employer | Ask G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. It is specific and yours, but nothing inspectable yet. A years requirement is graded as a must-have, not a gate. | `[grounded]` your account | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" is specific on frequency, but not on what you built or at what scale. A technical probe is the usual way this gets tested. | `[grounded]` your account; `[generic]` on the probe | A sanitized code sample or pipeline description would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific and in your own role, but no inspectable artifact yet. | `[grounded]` your account | Sanitized model documentation (factor selection, validation, relativities) would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM. | `[grounded]` your account | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is near monitoring but doesn't say what you tracked, how often or what triggered a refit, so monitoring stays unasserted. | `[grounded]` your wording | Ask G3 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with underwriting. "Ran" is carried as ran. Which parts of the design were yours, versus the readout, isn't stated. | `[grounded]` your account | A sanitized test brief or readout would raise to high and settle design versus read |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which is recurring and senior. | `[grounded]` your account | A data-free deck extract would raise to high |
| R8 | Turn results into recommendations for underwriting and product | important | unclear | low | discovery | The underwriting side is covered by R6 and R7. Nothing you've described reaches product (cover, limits, plan structure). | `[grounded]` JD quote against your account's silence | Ask G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer. The JD asks for insurance, not pet. | `[grounded]` JD and your account | none |
| R10 | Pet-insurance domain knowledge (inferred from the product named in the JD; the JD itself asks only for insurance) | preferred | adjacent | medium | transferability | Adjacent: personal-lines rating and price testing in motor. Limit: you've never worked on pet insurance, so none of its own rating factors or claims dynamics have been exercised. | `[inferred]` bridge from motor; `[generic]` that pet carries its own rating factors | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based remote working (R1, hard_gate) | hard_gate | Nothing states your location or right to work | Until it's settled the gate stays unconfirmed in the snapshot | Not applicable: a yes/no term | None needed; your statement settles it | `[grounded]` no statement given |
| G2 | Recommendations that reach product (R8, important) | discovery | Underwriting-facing recommendations are clear; product-facing ones are not | The JD names product as a recipient, and this is the one responsibility with no evidence | A test result that changed an excess, a cover limit or a plan tier; a pricing review that fed a product change; a proposal you wrote that product acted on | A review paper or a test readout showing the recommendation and its outcome | `[grounded]` your account's silence on product; `[generic]` that pricing roles commonly feed product |
| G3 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is stated; the monitoring practice isn't | The JD pairs "build and monitor", and I won't claim the second half unevidenced | Actual-versus-expected tracking by factor; drift or loss-ratio dashboards; refit triggers or governance sign-off | A monitoring pack or model-review note, sanitized | `[grounded]` your wording |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Motor GLM and price testing carry over; pet-specific factors don't | A preferred row, so a minor risk, but the probable interview angle | Any non-motor or multi-line pricing exposure; self-directed reading of pet rating | A short note in your own words on how pet differs from motor, as a work sample | `[inferred]` from your stated lack of pet experience; `[generic]` that pet is the likeliest probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified, because research did not run | unknown | — | "Brindlemoor (insurtech)" | Nothing yet says whether the posting is live and matches the company's own careers page | `[generic]` an unchecked employer is simply unchecked, not a finding about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | The JD as pasted gives no salary or band | The figure may sit on the original posting, or be withheld | `[grounded]` JD silence | What is the salary band for this role? | unresolved |
| RR3 | Team and reporting lines unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be a solo analyst or may carry reports; the JD doesn't say, and line management isn't listed as a requirement | `[inferred]` from "Own" against silence on team | Who else sits in pricing today, and does this role manage anyone? | unresolved |
| RR4 | Concrete deliverables listed | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate is specific rather than vague | `[grounded]` JD | What would a good first year look like in this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Brindlemoor's own careers page before drafting anything | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your own three facts: "built and maintained the GLM rating model for our young-driver book", "ran 14 price tests last year with the underwriting team", "present the quarterly pricing review to the head of underwriting". Don't write "designed" or "owned monitoring" until G3 and R6 are settled. | R4, R5a, R6, R7 | `[grounded]` your sentences | pending your approval |
| A3 | Say the pet gap plainly: "My pricing background is UK motor insurance; I have not worked on pet insurance." Then name the carry-over from R4 and R6. | R10 | `[grounded]` your sentence | pending your approval |
| A4 | Ask RR2 and RR3 verbatim when you speak to anyone at Brindlemoor | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched for Brindlemoor's careers and product pages; the call was refused. It would have fed role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | Searched for senior pricing analyst, pet insurance, UK pay and scope; the call was refused. It would have fed the market calibration row and the pay check on RR2. |
| 3. Hiring manager's public footprint | unavailable | Searched for Odile Varga's public professional footprint; the call was refused. It would have fed the scope read and A2's positioning. |

## Upgrade menu

- Your UK location and right to work (G1) would close R1 and the hard-gates line.
- Your pay floor and any other hard limits (contract type, hours) would run the hard-gate checks against them, which are currently unknown.
- A sanitized model document, test readout or review deck would lift R4, R6 and R7 from `medium` to `high`.
- Answers to G2 and G3 would settle R8 and R5b.
- Web research, if permitted, would verify the employer and posting (RR1), calibrate pay (RR2) and read Odile Varga's public professional footprint for A2.

If you'd like, I can write this up as a `tuesday-dossier.md` to carry forward.

G1 — Are you based in the UK, and able to work there without sponsorship?

G2 — Has any price-test result of yours changed something on the product side, such as an excess, a cover limit or a plan structure, and not only rates? What was your part in it?

G3 — After the young-driver GLM went live, what did you monitor, how often (for example actual versus expected by factor, drift, refit triggers), and what did you personally own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.