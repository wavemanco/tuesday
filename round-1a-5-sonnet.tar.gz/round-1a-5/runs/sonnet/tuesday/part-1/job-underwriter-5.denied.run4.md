The search and the careers-page fetch were both denied, so I'm working from your pasted material only. The full assessment follows.

# Job Underwriting Assessment — Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, it looks worth applying to. Your direct matches are R3, R4, R5, R6, R8 and R9, and the two hard gates, R1 and R2, aren't yet checked against your constraints. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R7 — a credible bridge from Snowflake, its limit named; R10, R11 — unconfirmed, waiting on your answers.

**Opportunity ledger.** The stated terms look sound: pay is posted and sits inside the report's range (RR3). The live posting is unchecked (RR1), and team scope (RR2), equity terms (RR4) and success measures (RR5) are all unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 against your own location, authorization and pay floor (G1); (2) the posting is confirmed live (RR1); (3) the BigQuery gap (R7) is framed honestly as adjacent, never as BigQuery experience.
- **What would flip it to `no_go`:** a pay floor above the posted range, or no ability to work remotely from the US or in Denver.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C of $52M, February 2026 | `[grounded]` the About text you pasted, not checked against the live site |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD you pasted |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Seniority fit | The JD's 5+ years and your 6 sit inside the report's typical "Senior" range of 5–8 years | `[grounded]` JD, your background and the report's figure as you relayed them |
| Market calibration | The report's Series B–D senior base median is $151,000 (interquartile range $139,000–$163,500). The posting runs from $148,000, just under that median, to $166,000, above the top of the interquartile range. The band is what to expect, never this employer's offer | `[grounded]` the recruiter's report as you relayed it, set against the JD's figures; I haven't seen the report itself |
| Scope read | Ingestion through to analyst-facing contracts is one reporting stack end to end. The report's typical scope is one domain's pipelines with no direct reports, and the JD names no reports | `[inferred]` from the JD's three named responsibilities against the report's scope note |
| Unknowns | Team size and who owns ingestion today; equity terms; first-year outcomes; the hiring manager (the posting names none) | `[grounded]` the posting's silence |
| Contradictions | None found between the JD, the About text and the report. The live site was not checked | `[grounded]` pasted material only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated your location, work authorization or location constraints, so the gate is unsettled. Nothing is confirmed on your side | `[grounded]` JD term; your constraint not given | G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Pay is a term you meet or don't, and your floor wasn't given. Fit stays unclear until you state it | `[grounded]` JD figure; your floor not given | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You describe 6 years at a B2B payroll company. It's self-reported with no inspectable artifact yet, so `medium`. Length of experience is graded as fit, not as a gate | `[grounded]` your background as stated | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Confirmed and plausible, but unprobed, so `medium`: expect a technical screen to test it | `[grounded]` your background as stated | none |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models, on Snowflake. Specific, but the model count is unverified | `[grounded]` your background as stated | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for dbt and a cloud warehouse. You've worked in Snowflake. This row grades the generic requirement, and BigQuery by name is R7 | `[grounded]` JD wording and your background | none |
| R7 | BigQuery as the warehouse | important | adjacent | medium | transferability | The requirements list asks for a cloud warehouse, not BigQuery by name, but the role description names BigQuery. You've never used it. Your dbt and warehouse SQL carry over. The limit is that none of BigQuery's own behaviour has been exercised, and warehouses differ in cost model and table design | `[grounded]` your statement that you've never used it; `[generic]` that warehouses differ on those points | see G4 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | You run Airflow at your current employer. Same `medium` ceiling | `[grounded]` your background as stated | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations suite. Confirmed and specific, with no artifact inspected | `[grounded]` your background as stated | none |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | The JD names these two source types. Your background doesn't say which sources you ingested or whether you owned ingestion | `[grounded]` the JD's responsibility and your silence on sources | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The JD names data contracts as a deliverable. Your tests and dbt work may amount to them, but you haven't said so | `[grounded]` the JD's responsibility; `[inferred]` that your tests could be evidence, unconfirmed | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, authorization and pay floor (R1, R2, hard_gate) | hard_gate | Nothing in the material settles either gate | A failed gate would end the application however strong the fit. A confirmed one lets this go straight to a plain `go` once the posting verifies | A US address or right to work remotely there, or a move to Denver; a base you would accept in the posted range | None needed; your own statement is the strongest evidence for a constraint | `[grounded]` the JD terms against your silence |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Your background doesn't say what your pipelines loaded from | The role starts with ingestion, and the answer decides whether this row is `direct` or a real gap | Loading product event data or a CRM export such as Salesforce or HubSpot; writing or configuring connectors; managing an ingestion tool; backfills and schema-change handling | A pipeline diagram, a DAG listing or a sanitized runbook | `[grounded]` your silence on sources |
| G3 | Data contracts (R11, important) | discovery | Great Expectations and about 180 dbt models are confirmed, with no mention of agreements with downstream analysts | The JD names contracts as something analysts rely on, and your existing work may already count | Agreed column definitions or freshness expectations with analysts; tests that blocked a bad load; a change process for models other teams used | A sanitized test config, a schema doc or a dbt model YAML | `[inferred]` from your dbt and Great Expectations work, unconfirmed |
| G4 | BigQuery (R7, important) | transferability | Snowflake and dbt carry over. BigQuery itself is unexercised | It's the stack named in the role description, and an interviewer could probe it | No question needed. The closure path is a small scoped project in BigQuery, in the application plan (A2) | A short repository or write-up of that project | `[grounded]` your never having used it; `[generic]` that stack-named gaps get probed in screens |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and company details unchecked against the live site | unknown | — | "Series C ($52M, February 2026)" | The live posting may differ from the pasted text, or may have closed. My check was refused, so nothing is established either way | `[grounded]` pasted text, not independently confirmed | Can you confirm this role is open and point me to it on your careers page? | unresolved |
| RR2 | Team size and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | One engineer may own ingestion, modelling and contracts end to end, which is wider than the report's one-domain norm | `[inferred]` from the JD's three responsibilities against its silence on team | How many engineers are on the data team, and who owns ingestion today? | unresolved |
| RR3 | Pay stated, in line with the report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is posted and straddles the report's median, so no seniority-pay mismatch shows | `[grounded]` JD figures against the report as you relayed it | Where in the range would someone with six years land? | noted |
| RR4 | Equity terms unspecified | unknown | — | "plus equity" | The grant, vesting and valuation are unknown, so the equity's worth can't be set against the cash | `[grounded]` the posting's silence | What is the equity grant, its vesting schedule and the current strike or valuation? | unresolved |
| RR5 | No stated success measures | unknown | — | "Build and run the pipelines" | Accountability is broad and the posting gives no first-year definition of done | `[inferred]` from the JD's silence on outcomes | What would success look like at six months and at twelve? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the careers page before spending effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Build a small BigQuery project: load a dataset and rebuild a few of your dbt models there, then describe it as a side project and not as work experience | see R7, G4 | `[generic]` how a stack gap is usually narrowed | pending your approval |
| A3 | Positioning: lead with your dbt project on Snowflake (about 180 models), the Great Expectations suite you set up and your Airflow orchestration, and name BigQuery as new to you. Each of these traces to a sentence you wrote | see R5, R8, R9, R7 | `[grounded]` your own statements | pending your approval |
| A4 | Ask the verification questions of RR2, RR3, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for the company's profile and a fetch of the live posting were both refused, so nothing was read. It would have settled RR1 and the contradictions row in role reality |
| 2. Role-family sweep | skipped | The recruiter's pay report is in hand, and it fixes the market calibration line and RR3. A search could not change either |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Upgrade menu

- Your location, authorization and pay floor (G1) → R1 and R2 settle, and the decision likely simplifies to `go` or `no_go`.
- Your answers on ingestion sources and contracts (G2, G3) → R10 and R11 move from `unclear` toward `direct`.
- A pipeline diagram, DAG listing or sanitized test config → R5, R8, R9 and R11 can rise toward `high`.
- Search and fetch access → the live-posting check runs and RR1 closes. After that, a deeper company pass (funding and leadership news; up to 5 more searches and 2 more fetches) is available on your say-so.
- The hiring manager's name, if the recruiter has it → the scope read and the positioning in A3 can be tuned to that reader.

If it would help, I can write this up as a `tuesday-dossier.md` you can reuse later.

**Questions**

G1 (R1, R2) — Can you work from the US as a remote hire (or in Denver), and does a base inside $148,000–$166,000 clear your floor?

G2 (R10) — Which sources did your pipelines load from, such as app event data, a CRM or billing systems, and did you build that ingestion yourself or receive it from a tool someone else ran?

G3 (R11) — Did you agree anything formal with the analysts who used your models, such as fixed schemas, freshness expectations or tests that blocked a bad load, and which parts were yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.