Checking that the posting and company are real and live, using one fetch and one search.
**Research tier: L1 — searches 1 of 5, fetches 1 of 2**

# Job underwriting: Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, worth applying, once you confirm two terms yourself (R1, R2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 — a credible bridge from Snowflake, its limit named; R10, R11 — the CV is silent, waiting on one answer.

**Opportunity ledger.** The role looks sound. The posted pay is stated (RR1), and the employer and live posting check out (RR2). The open items are scope breadth (RR3), no named hiring manager (RR4) and equity terms (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you can work remote from the US or from Denver (R1); (2) the range clears your own pay floor (R2); (3) BigQuery is presented as adjacent, never as experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About page, returned by search |
| Posting status | The careers page shows "Accepting applications", and its text matches what you pasted | `[grounded]` careers page fetched |
| Mandate | Pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Market calibration | The Datawright 2026 report puts Series B–D Senior Data Engineers at a base median of $151,000, interquartile range $139,000–$163,500. The posted $148,000–$166,000 starts just under the median and tops out above the 75th percentile. Assuming the posted figure is base, equity comes on top. | `[grounded]` JD and the recruiter's report (n=2,310); `[inferred]` that the posted salary is base |
| Seniority | The report says "Senior" typically means 5–8 years. The JD asks 5+, and you have 6. | `[grounded]` report and JD |
| Scope read | The report's typical scope is one domain's pipelines, no direct reports. This posting spans ingestion, warehouse modelling and contracts, and it never mentions reports (RR3). | `[inferred]` JD against the report |
| Unknowns | Team size, hiring manager, equity terms, on-call expectations | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you are based. Confidence is `none` because no constraint was stated, so there is nothing to grade. | `[grounded]` no constraint given | Question G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so the range cannot be checked against it. | `[grounded]` no constraint given | Question G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. Confirmed prose only, with no inspectable artifact yet, so `medium`. Expect a probe. | `[grounded]` your background as stated | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Specific, but no artifact inspected. | `[grounded]` your background as stated | Offer: a code sample or repo link would raise it to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models on Snowflake. | `[grounded]` your background as stated | Offer: a model-lineage screenshot, sanitized, would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse" and Snowflake is one. BigQuery specifically is R9. | `[grounded]` your background and the JD wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. Your ownership of it is not stated. | `[grounded]` your background as stated | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is your own ownership claim. | `[grounded]` your background as stated | Offer: a sanitized test list would raise it |
| R9 | BigQuery (named in the role description) | important | adjacent | medium | transferability | Snowflake plus dbt is a close analogue, and dbt carries over. The limit is that you have never used BigQuery, including its cost and partitioning model. | `[inferred]` requirement from the role description, not a stated requirement; `[grounded]` your no-BigQuery statement | Bridge case G3 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | The CV is silent on source types. Payroll pipelines may include app and vendor feeds, but that is unconfirmed. | `[inferred]` requirement from the role description; `[grounded]` CV silence | Question G4 |
| R11 | Data contracts for analysts | important | unclear | low | discovery | The Great Expectations suite is adjacent, but you have not said whether you agreed schema or freshness terms with consumers. | `[inferred]` requirement from the role description; `[grounded]` CV silence | Question G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | Nothing says where you are based. | A gate the inputs do not settle stays open. It is the one thing that could stop the application. | Not applicable; this is a fact about you. | None needed | `[grounded]` no constraint given |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The range is posted, and your floor is unknown. | The comparison decides whether the role is worth the effort. | Not applicable | None needed | `[grounded]` no constraint given |
| G3 | BigQuery (R9, important) | transferability | Snowflake and dbt carry over. BigQuery itself and its cost and partitioning model do not. | It is the most likely screening question. | A small public dbt project run on BigQuery's free tier | A repo link or a short write-up | `[inferred]` bridge from Snowflake; `[generic]` that this is the likeliest probe |
| G4 | App and CRM ingestion, data contracts (R10, R11, important) | discovery | The CV does not say what feeds you ingested or what you agreed with consumers. | Two `important` rows hang on it. | Loading from a product database, a CRM export or a vendor API; agreeing column or freshness rules with analysts; a schema-change process | A pipeline diagram or a test list | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range straddles the report median and its top is above the 75th percentile. | `[grounded]` JD against the recruiter's report | Is this base salary, and where would six years of experience land in the range? | noted |
| RR2 | Employer and live posting match the description | positive_signal | — | "Series C ($52M, February 2026)" | A funded employer with an open, consistent posting. | `[grounded]` About page and careers page | Is this role new or a backfill, and how large is the data team? | noted |
| RR3 | Scope may exceed the usual single domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One person may own three areas, where the report's typical scope is one domain. | `[inferred]` JD against `[grounded]` report | Which of these three areas would I own on day one, and who else is on the data team? | unresolved |
| RR4 | No hiring manager named | unknown | — | "Senior Data Engineer — Pellucid Learning" | Reporting line and interview panel are unknown. | `[grounded]` posting silence | Who would I report to, and who would I interview with? | unresolved |
| RR5 | Equity terms not stated | unknown | — | "plus equity" | The equity could be small or large relative to the base. | `[grounded]` posting silence | What is the equity grant for this level, and what is the vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with your dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up. Keep your own scope words, with no "led" or "owned" unless that is true. | See R5, R8 | `[grounded]` your background as stated | pending your approval |
| A2 | State BigQuery honestly as new to you, alongside dbt and warehouse experience on Snowflake. | See R9 | `[grounded]` your no-BigQuery statement | pending your approval |
| A3 | Optional work sample: a small dbt project on BigQuery's free tier. | See R9, G3 | `[inferred]` bridge | pending your approval |
| A4 | Ask the register's questions (RR1, RR3, RR4, RR5) verbatim in the loop. | The register doubles as interview preparation. | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Both calls checked your pasted material: the posting is live and consistent, which moved RR2 and the contradictions row. |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the market calibration and the pay-mismatch check, so a search could not change them. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## One-line dossier offer

I can write this up as `tuesday-dossier.md` for later use whenever you want.

## Upgrade menu

- Where you are based → R1 closes.
- Your pay floor → R2 closes and the comparison with RR1 becomes definite.
- A code sample or repo link, a sanitized model-lineage screenshot or a test list → R4, R5 and R8 can rise from `medium` to `high`.
- A pipeline diagram or an answer to G4 → R10 and R11 resolve.
- The hiring manager's name → the scope read and the plan's positioning can be tailored.
- A deeper research pass on Pellucid Learning (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — Where are you based: the US (remote), or near Denver?
G2 — What is the lowest base salary you would accept?
G4 — In your payroll work, did data come in from an app, a CRM or vendor feeds, and did you ever agree schema or freshness expectations with the analysts who used it? What was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.