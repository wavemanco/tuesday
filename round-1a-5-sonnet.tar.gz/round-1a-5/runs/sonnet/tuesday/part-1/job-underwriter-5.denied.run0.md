Status: I've read the underwriter playbook and its output rules. I'm now checking the research-tier rules, then I'll write the assessment.
# Job Underwriting Assessment: Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (US-remote or Denver), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery as the warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R6 — a credible bridge, its limit named; R9 and R10 — your background is silent on them, so they are open questions and not mismatches.

**Opportunity ledger.** The pay range is in line with the report you sent (RR4). Four items are unverified or unstated: the employer and live posting (RR1), the manager and team shape (RR2), and the equity terms (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (US-remote or Denver), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor fit R1 and R2; (2) the posting and employer verify (RR1); (3) the BigQuery gap is framed as adjacent and never as BigQuery experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C of $52M in February 2026 | `[grounded]` the about-page text you pasted; I couldn't check it (see Evidence status) |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow or similar, data-quality testing, Python and SQL | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity of unstated size; remote (US) or Denver | `[grounded]` JD |
| Scope read | Reads as one domain (reporting), which matches the "one domain's pipelines, no direct reports" scope in your pay report. The JD names no direct reports | `[inferred]` from the JD's mandate against the report's typical scope |
| Market calibration | Report band for Senior Data Engineer at Series B–D (n=2,310): median $151,000, IQR $139,000–$163,500. The posted low end is $3,000 below the median and the high end is $2,500 above the IQR's top. Your 6 years sits inside the report's 5–8 typical for "Senior". This is a role-family band, not this employer's offer | `[grounded]` the pay report you sent, for the figures; `[generic]` that a band is not an offer |
| Unknowns | Hiring manager, team size, whether you'd be the first or sole data engineer, equity terms | `[grounded]` JD names none |
| Contradictions | None between the JD and the about text, but both came from you and neither was fetched | `[grounded]` the two pasted texts |

## Evidence map

I haven't seen your CV, so the rows below rest on your prose summary. At intake that is self-report, which caps confidence at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US-remote or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated your location or any constraint, so there is no statement to grade | `[grounded]` JD; nothing from you | Ask where you are based (question R1/R2) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so I can't tell whether the range clears it | `[grounded]` JD; nothing from you | Ask your minimum (question R1/R2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You report 6 years at a B2B payroll company; specific but uninspected | `[grounded]` your summary | A dated CV or LinkedIn would raise to high |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You report daily use; no detail on scale or what you built | `[grounded]` your summary | Code sample or repo would raise to high |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | A dbt project of about 180 models on Snowflake, which is a cloud warehouse; confirmed and specific, nothing inspected | `[grounded]` your summary | Sanitized project docs or a lineage screenshot would raise to high |
| R6 | BigQuery as the warehouse | important | adjacent | medium | transferability | Snowflake dbt work carries over. Limit: you have never used BigQuery. BigQuery-specific habits such as cost control and SQL dialect quirks are the likely probe | `[grounded]` your summary; `[generic]` that warehouse-specific habits are what interviewers probe in a move between warehouses | Small dbt project run against BigQuery (G3) |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly; confirmed, no detail | `[grounded]` your summary | DAG description or screenshot would raise to high |
| R8 | Data-quality testing | must_have | direct | medium | none | You set up a Great Expectations suite; confirmed, ownership stated, nothing inspected | `[grounded]` your summary | Sanitized suite config would raise to high |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your sources at the payroll company aren't described, so nothing speaks to app-event or CRM ingestion | `[grounded]` summary silent | G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Great Expectations tests are adjacent: they check data and don't agree schemas with consumers. Whether you did the latter is unknown | `[inferred]` from your GE work | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | App and CRM ingestion (R9, important) | discovery | Pipelines and Airflow are confirmed, but not what they pulled from | The JD names app and CRM ingestion as the first thing you'd build | Loading a product database or event stream; syncing a CRM or another vendor API; handling schema drift or late data | A pipeline diagram or DAG list, sanitized | `[grounded]` summary silent; `[inferred]` that it matters because the JD leads with it |
| G2 | Data contracts (R10, important) | discovery | The GE suite is confirmed; agreed schemas with downstream consumers aren't | The JD names analysts' reliance on contracts as part of the role | Agreeing column definitions or freshness expectations with analysts; failing a pipeline on a breaking change; versioned schemas | A contract doc, schema-change policy, or test config | `[grounded]` summary silent; `[inferred]` from the JD |
| G3 | BigQuery (R6, important) | transferability | Snowflake and dbt carry over; BigQuery use is none | The warehouse is the stack's centre, so this is the likeliest objection | A small dbt project run against BigQuery; reading its query-cost behaviour | A repo link or short write-up | `[grounded]` your statement; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The company may be as described, but I couldn't confirm it, and the posting could be stale | `[generic]` pattern for any unchecked posting, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager, team size and reporting line unstated | unknown | — | "The posting names no hiring manager" | You may be the sole data engineer owning ingestion through contracts, or one of a team | `[inferred]` from the JD's silence | Who does this role report to, and how many data engineers and analysts are there? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "Salary $148,000–$166,000 plus equity" | The grant could be material or nominal | `[inferred]` from the JD naming equity with no terms | What is the grant size, vesting schedule, and latest valuation basis? | unresolved |
| RR4 | Pay in line with the market | positive_signal | — | "$148,000–$166,000" | The range spans the report's median ($151,000) and reaches past the IQR's top ($163,500) | `[grounded]` JD and the pay report | Is the range's top reachable at 6 years' experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the 180-model dbt project and the Great Expectations suite, with ownership stated as you gave it | see R5, R8 | `[grounded]` your summary | pending your approval |
| A2 | Say plainly that you've built on Snowflake and not BigQuery, and offer a small dbt-on-BigQuery project as the bridge | see R6, G3 | `[grounded]` your statement | pending your approval |
| A3 | Don't claim BigQuery, CRM-ingestion or data-contract experience until your answers to G1 and G2 confirm them | see R6, R9, R10 | `[grounded]` the map | pending your approval |
| A4 | Ask the questions in RR1 to RR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you go ahead, resume-tailor can reorder your CV for this posting once you share it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused for lack of permission: "Pellucid Learning senior data engineer careers Denver" and "Pellucid Learning Series C $52M online tutoring K-12". They would have checked the pasted pages and posting; this is why RR1 stays open and caps the status at `conditional_go` |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the market calibration and the RR4 comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

## Upgrade menu

- A link to the live posting on the careers page → RR1 can close.
- Your location and pay floor → R1 and R2 move to `direct` or `hard_gate_fail`; the decision either firms up or ends.
- Your CV, or sanitized artifacts (dbt project docs, a DAG list, the Great Expectations config) → R3, R4, R5, R7 and R8 can reach `high`.
- Answers to G1 and G2 → R9 and R10 resolve.
- The hiring manager's name → the scope read and the story to lead with.
- A deeper research pass (funding, leadership churn, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs, though search permission would need granting.

I can save this as `tuesday-dossier.md` if you want it for later steps.

**Questions**

R1/R2 — Are you US-based (or open to Denver), and does a base of $148,000–$166,000 plus equity clear your minimum?

G1 — What did your payroll company's pipelines ingest from (product database, event streams, a CRM or vendor API), and which did you personally build?

G2 — Did you ever agree schemas, definitions or freshness expectations with analysts or other teams, so that a breaking change failed a pipeline?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.