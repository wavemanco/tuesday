I'm checking Brindlemoor's own careers page. The search snippet says the role is in the Leeds office four days a week, but your JD says fully remote.
# Job Underwriting Assessment: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Should you go for it? Your substance fits: R2, R3, R4, R5, R6 and R7 are all `direct`. But hold off applying until you know the working pattern, because your JD and Brindlemoor's own careers page disagree on it (R1). Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · adjacent: R9 (Pet-insurance product knowledge) · unclear: R8b (Recommendations to product)
- `preferred` — direct: R10

R1 — two sources disagree, and it decides the status; R7 (`medium`) — confirmed "ran", design role not yet stated; R9 — a bridge, its limit named.

**Opportunity ledger.** The posting is live and its title, scope and reporting line match your JD (RR3). The working pattern conflicts between sources (RR1), pay is not stated (RR2), and the team and decision rights are not described (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a `go` or `conditional_go` once (1) Brindlemoor confirms the real working pattern (R1, RR1) and (2) you say whether that pattern works for you. If it is Leeds four days a week and you need remote, the status becomes `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, a pet-insurance insurtech; the role is live on its careers site | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | The Director of Pricing (Odile Varga per your JD) | `[grounded]` careers page; JD |
| Working pattern | JD says fully remote (UK); the careers page says "Leeds office four days a week" | `[grounded]` both sources, quoted |
| Compensation | Not stated in the JD. Expect roughly £52,100–£64,900 (median £58,400) for this title at UK insurers and insurtechs, not Brindlemoor's offer | `[generic]` one search returning the 2026 Pricewell pay survey (n=612), snippet only; `[grounded]` JD silent on pay |
| People management | No line management is asked for in the JD | `[grounded]` JD |
| Scope read | One product's pricing analytics with a named reporting line: a defined remit. Team size and decision rights are not stated | `[inferred]` from the mandate wording against the JD's silence |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint: a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years | `[grounded]` one search result, snippet only, page not fetched |
| Unknowns | Salary; team size; decision rights on rating changes; which working pattern is correct | — |
| Contradictions | Working pattern, JD against careers page (R1, RR1). The fetched page returned a single line, so I can't see whether it mentions any remote option | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Your own working-pattern constraint wasn't given, so there is nothing to grade; confidence stays `none` until you state it. Fit is `unclear` because the JD says remote and the careers page says Leeds four days a week | `[grounded]` JD and careers page disagree; no constraint stated | G1: ask the employer; tell me your constraint |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Self-reported, nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated; no artifact inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Specific and plausible, no inspectable proof yet | `[grounded]` your background | A sanitised model-documentation extract would raise it to `high` |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting; the JD's "or" means underwriting alone meets it | `[grounded]` your background; JD wording | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers both halves. Your monitoring routine isn't described | `[grounded]` your background | none |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You "ran 14 price tests last year with the underwriting team". "Ran" may mean designed, executed or both, and ambiguity resolves downward until you say | `[grounded]` your background, ambiguity named | G2 question |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | You work with the underwriting team on tests and present to its head | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | none | discovery | Nothing in your background mentions product teams | `[grounded]` background silent | G3 question |
| R9 | Pet-insurance product knowledge (implied by owning pricing for the pet product) | important | adjacent | medium | transferability | Bridge: confirmed GLM rating and price-test work in motor. Limit: no pet experience; pet pricing likely rests on different rating factors than motor, such as breed, age and pre-existing conditions | `[inferred]` requirement from the mandate wording; `[generic]` that pet rating factors differ from motor | G4 bridge case |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | JD says fully remote; careers page says Leeds four days a week; your constraint unknown | A gate decides the status whatever the fit elsewhere | — a gate is met or not; wording can't solve it | The live posting where you saw "fully remote"; the employer's answer | `[grounded]` both sources |
| G2 | Designing price tests (R7, must_have) | discovery | "Ran 14 price tests" doesn't say who set hypotheses, sample sizes or success metrics | The JD says "design and read"; the interview will probe which half was yours | Choosing test cells; sizing tests; defining the read-out metric; deciding to stop or roll out | A sanitised test read-out or test plan | `[grounded]` your wording; `[generic]` that this role family probes design ownership |
| G3 | Recommendations to product (R8b, important) | discovery | Nothing links your work to product teams | One of the two audiences the JD names | Pricing input to a product launch or rate change; a cover or feature change you costed | A recommendation memo or deck extract | `[grounded]` background silent |
| G4 | Pet-insurance knowledge (R9, important) | transferability | Motor pricing only; no pet experience | The likeliest objection to your application | Non-motor pricing; claims-cost inflation work; vet-fee or medical-cost analysis | Any written work on non-motor lines | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern conflicts between sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | Either copy may be out of date, or the role may allow some flexibility. I can't say which | `[inferred]` from two sources disagreeing; the cause is unknown | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pay not stated | unknown | — | JD gives no figure | The figure may sit anywhere in or around the market band above | `[inferred]` from the JD's silence against the `[generic]` band | What is the salary range for this post? | unresolved |
| RR3 | Posting live and consistent on title, scope and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The role appears real and defined | `[grounded]` careers page fetched | Who else sits in pricing today? | noted |
| RR4 | Team and decision rights not described | unknown | — | "Own pricing analytics" | You may own the analysis without owning rating-change decisions | `[inferred]` from the mandate wording against silence on authority | Which rating changes does this role decide, and which go to underwriting or the Director? | unresolved |

## Application plan

Full CV tailoring is resume-tailor's job once you've decided. These rows are proposals only.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing in the application, ask the recruiter or Odile's team the RR1 question word for word | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the GLM story in your own words: "built and maintained the GLM rating model for the young-driver book". Her published talk is on monitoring rating models, so the maintenance half is closest to her topic | see R4, R6 | `[grounded]` your wording; `[inferred]` closeness to her talk | pending your approval |
| A3 | Frame pet knowledge as adjacent: "I haven't worked on pet; I've built and maintained GLM rating and run price tests in motor." Add no claim beyond that | see R9 | `[grounded]` your wording | pending your approval |
| A4 | Ask the RR2 and RR4 questions in the loop | the register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background was typed in, so it counts as CV-equivalent self-report until you answer specific probes.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the posting is live and exists as described (RR3). Found the working-pattern contradiction (R1, RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Moved the hiring-manager row and A2 |

I can save this as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- The employer's answer on working pattern, or the live posting you saw "fully remote" on → R1 and RR1 close; the decision likely simplifies to `go`, `conditional_go` or `no_go`.
- Your own constraint on location, and your pay floor → the hard-gates line can check R1 against them, and RR2 against your floor.
- A sanitised price-test plan or read-out → R7 to `high`; a sanitised model-documentation extract → R4 to `high`.
- A recommendation memo that reached a product team → R8b.
- The salary range → RR2 closes against the band above.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Is working fully remote a must for you, or could you do four days a week in Leeds? If it's a must, is there any flex on that?

G2 — On your 14 price tests, which parts did you personally own: choosing test cells, sizing, defining the success metric, calling the result? Which did the underwriting team or someone else decide?

G3 — Have your pricing results ever gone to a product team, for example on a feature, cover or launch decision? What did you recommend, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.