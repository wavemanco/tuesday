**Yes, it's worth applying. R3, R4, R5, R7 and R8, the must-have rows, are all `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts)

R6 (`medium`) is a credible bridge with its limit named. R9 and R10 are experience I haven't asked you about yet.

**Opportunity ledger.** The employer checks out on its own site (RR5), and the posted pay lines up with the market report you were sent (RR1). Four things are open: equity terms (RR2), whether one title covers ingestion, warehouse and contracts (RR3), and first-year outcomes and team shape (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Location and pay work against your own limits (R1, R2).
  2. Your ingestion and data-contract experience holds up when you answer (R9, R10).
  3. The BigQuery gap is stated honestly as adjacent, never as BigQuery experience (R6).
  4. Scope and team shape verify in the recruiter screen (RR3, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched; these are the company's own statements |
| Mandate | Build and run the pipelines behind reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD and careers page |
| Posting status | Careers page reads "Accepting applications" and matches the text you pasted | `[grounded]` careers page, fetched |
| Compensation | $148,000–$166,000 plus equity (terms not stated) | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Seniority | "5+ years" asked for; you have 6, and the report puts "Senior" at 5–8 years | `[grounded]` JD, your background and the Datawright report |
| Scope read | Individual contributor on the reporting data platform; the posting mentions no direct reports | `[inferred]` from the JD's silence on reports, matching the report's typical scope |
| Market calibration | Report (US, n=2,310, Series B–D): base median $151,000, interquartile range $139,000–$163,500. The posted range starts $3,000 below that median and ends $2,500 above the range's top. The report is from your recruiter and I haven't checked it. | `[grounded]` the report's figures and the JD's; `[inferred]` the comparison |
| First-90-days / year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Equity terms; team size and who the role reports to; whether the warehouse already exists; who owns ingestion versus modelling | — |
| Contradictions | None between the pasted text and the live pages | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you'd work from, so there is no stated constraint to grade. Fit stays unclear until you answer. | `[grounded]` JD term; your location not given | G1 question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor wasn't given, so whether the range clears it is unknown. | `[grounded]` JD term; your floor not given | G1 question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It's confirmed and specific, but there's no CV or artifact to inspect yet. | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. It's a self-report with nothing inspectable yet, so expect a probe. | `[grounded]` your stated background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, and this row reads the requirement as the JD words it. | `[grounded]` your stated background; `[generic]` that Snowflake counts as a cloud warehouse | none |
| R6 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The dbt-on-a-warehouse work carries over, and you've never used BigQuery. The limit is that no BigQuery work is evidenced, and engine-specific details are untested. | `[grounded]` your statement of no BigQuery use; `[generic]` that engine specifics usually differ between warehouses | G4: bridge case and optional work sample |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. It's confirmed, with no artifact inspected yet. | `[grounded]` your stated background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. It's confirmed, and a sanitized suite config would be inspectable. | `[grounded]` your stated background | none |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | The JD names two source types. Your background doesn't say which sources you ingested at the payroll company. | `[grounded]` JD; your background silent | G2 question |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't mention agreements with data consumers, though the dbt and test work may touch them. | `[grounded]` JD; your background silent | G3 question |

R6 is tiered `important` because the JD names BigQuery only in its description of the warehouse. The listed requirements say "a cloud warehouse".

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay against your limits (R1, R2, hard_gate) | hard_gate | The JD states both terms. I don't know where you'd work from or what pay floor you hold. | A failed gate caps the decision however strong the fit, so these two settle whether the rest matters | Not a recall question. Both are facts about your situation. | Nothing to attach | `[grounded]` JD terms; your constraints not given |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Your pipeline and dbt work is confirmed, but not which source systems fed it | The JD's first named duty is ingestion, and the answer decides how much of it you can claim | Loading from an application database or event stream; syncing a CRM or another third-party SaaS into Snowflake; ingesting customer or partner files | A sanitized Airflow DAG, a source list, or an architecture diagram | `[grounded]` background silent on sources; `[inferred]` that this affects the decision |
| G3 | Data contracts (R10, important) | discovery | Your test suite is confirmed, but no agreement with analysts or upstream owners is mentioned | The JD names contracts as something analysts depend on, so this decides how you frame the Great Expectations work | Agreed column definitions or freshness expectations with analysts; alerts or review rules when an upstream change breaks a model; dbt tests or checks written with a consumer's needs in mind | A sanitized test config, a data dictionary or a schema-change note | `[grounded]` background silent; `[inferred]` that the testing work may bear on it |
| G4 | BigQuery (R6, important) | transferability | Dbt modelling on Snowflake carries over. BigQuery use is none by your own statement. | It's the one named technology you lack, and it will come up in a screen | Same dbt patterns on another warehouse; migration or cost work you did on Snowflake | A small dbt project run against BigQuery, a short and honest bridge statement | `[grounded]` your statement; `[generic]` that engine specifics differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay in line with the market report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The base range is stated and sits around the report's median and just above its top quartile edge, so it isn't an obvious mismatch for the seniority | `[grounded]` JD and the report; `[inferred]` the comparison | Where in the range would someone with six years of experience land? | noted |
| RR2 | Equity terms unspecified | unknown | — | "plus equity" | The grant type, size and vesting may be unspecified because they're set at offer | `[inferred]` from the JD naming equity with no terms | What form does the equity take, roughly how much, and how does it vest? | unresolved |
| RR3 | Three areas under one title | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may cover more than the one-domain scope the report calls typical. It may equally be one well-bounded platform. Low because the posting alone can't tell. | `[grounded]` JD's three areas and the report's typical scope; `[inferred]` that they may not match | How many data engineers are on the team, and which of ingestion, modelling and contracts would this role own end to end? | unresolved |
| RR4 | First-year outcomes and manager unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Success measures and reporting line aren't visible. "Build" may mean greenfield or extending an existing warehouse. | `[grounded]` JD names no manager or outcomes; `[inferred]` the greenfield reading | Who would I report to, what does the warehouse look like today, and what should be done in the first year? | unresolved |
| RR5 | Employer confirmed on its own site | positive_signal | — | "Accepting applications" | The posting is live, and the company page matches the description given | `[grounded]` careers and About pages, fetched | Would funding and headcount match what you'll be told in the screen? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt-on-Snowflake project (about 180 models), the Airflow orchestration and the Great Expectations suite you set up | see R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| P2 | Say the BigQuery limit first, in your own words: warehouse work was on Snowflake, no BigQuery use | see R6 | `[grounded]` your statement | pending your approval |
| P3 | Optional work sample: a small dbt project run against BigQuery. It narrows R6's limit but shows familiarity, not production experience. | see R6, G4 | `[grounded]` R6 row | pending your approval |
| P4 | Ask RR2, RR3 and RR4's questions verbatim in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P5 | Ask RR1's question before any pay discussion | see R2, RR1 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about) to check the pasted text. Both match and the posting reads "Accepting applications". This fed the contradictions row and RR5. Funding and headcount remain the company's own claims. |
| 2. Role-family sweep | skipped | The recruiter's Datawright report is in hand, with the median, interquartile range and scope. It already fixes the market calibration and the pay comparison, and a search would add nothing to those outputs. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I can turn this into a `tuesday-dossier.md` if you want one to carry forward.

**Upgrade menu**

- Your CV or a sanitized dbt lineage graph, Airflow DAG or Great Expectations suite config: R3, R4, R5, R7 and R8 can reach `high`.
- Your location and pay floor (G1): R1 and R2 close.
- An answer to G2 or G3: R9 or R10 closes.
- The recruiter's answers on RR2, RR3 and RR4: the open entries close.
- The hiring manager's name, once you have it: the scope read and the lead story in the plan.
- A deeper research pass on Pellucid Learning (funding, leadership churn, hiring patterns, news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1 — Do the role's location (Remote US or the Denver office) and pay ($148,000–$166,000) both work for you, and is either one a hard limit?

G2 — Which source systems fed your pipelines at the payroll company, and did you personally build any ingestion from an application database or an external system like a CRM?

G3 — Did you agree table definitions, freshness or quality rules with analysts or other consumers, and who decided them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.