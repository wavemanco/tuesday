**Decision snapshot**

**Yes, worth applying to, once two things check out. Status: `conditional_go`.** The two things you flagged, no pet-insurance work and no people management, aren't requirements in the posting (see Role reality).

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote)
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (monitor rating models)
- `important`: direct: R8a · unclear: R8b (recommendations for product)
- `preferred`: direct: R9

R6b: "maintained" is what you said, and monitoring isn't stated; R8b: your recommendations went to underwriting, and product isn't mentioned.

**Opportunity ledger.** I couldn't establish the employer from search (RR1), and the posting gives no pay (RR2). It says "own" without stating authority or team (RR3). One entry runs the other way: the posting names concrete outputs (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) you confirm UK-based eligibility (R1); (3) the pay, once known, clears your floor (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, pet-insurance product | `[grounded]` JD header; the company itself was not established (RR1) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. A public profile lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re | `[grounded]` search result snippet, one source, not fetched |
| People management | The JD states no direct reports or line-management duty | `[grounded]` JD silent |
| Pet-insurance experience | Not listed as a requirement; the JD says "insurance experience a plus" | `[grounded]` JD quote |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. This is the band to expect, never Brindlemoor's offer | `[generic]` one salary-survey result, 2026; `[grounded]` pasted posting shows no figure |
| Unknowns | Salary; team size and reporting line; who signs off rating changes; whether you must be UK-resident | `[grounded]` JD silent on each |
| Contradictions | None inside the JD; no company page found to compare it against | `[grounded]` JD; search found no company page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based, fully remote | hard_gate | unclear | low | hard_gate | The JD states the term. You haven't said where you live or your right to work. A UK employer is indirect context only | `[grounded]` JD; `[inferred]` UK location from your UK employer | Closing question on R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, stated and specific. It is self-report with no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated. Nothing inspectable yet | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but no inspectable artifact | `[grounded]` your background | A sanitised model summary would raise it to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "underwriting or actuarial", so this meets it | `[grounded]` your background, JD | A review deck excerpt would raise it |
| R6a | Build rating models | must_have | direct | medium | none | Built the young-driver GLM, in motor, not pet | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained"; I take the lower reading, since it doesn't say what monitoring covered | `[grounded]` your wording; `[inferred]` that monitoring is likely part of maintaining a live model | G1 |
| R7 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year, run with the underwriting team | `[grounded]` your background | A test design and readout would raise it |
| R8a | Recommendations for underwriting | important | direct | medium | none | Your tests and quarterly review both feed underwriting | `[grounded]` your background | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in your background mentions product | `[grounded]` background silent | G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. This is general insurance, not pet | `[grounded]` your background, JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, must_have) | discovery | You maintained the young-driver GLM. Nothing says what you tracked after release, how often, or what you did when it moved | A must-have, and it decides how strong the application reads | Actual-vs-expected checks on the live model; a segment dashboard; a drift signal that led to a refit or rate change | A sanitised monitoring report, a dashboard screenshot, a refit note | `[grounded]` background silent on monitoring; `[inferred]` that Odile's public talk topic makes it likely to be probed |
| G2 | Recommendations for product (R8b, important) | discovery | Your recommendations went to underwriting. Product isn't mentioned | The JD names product as a recipient | Pricing input to a cover, add-on or feature change; a review that went to product or commercial leads | A pricing review excerpt showing a product decision | `[grounded]` background silent |
| G3 | UK-based, fully remote (R1, hard_gate) | hard_gate | The term is stated and your location and right to work are not | If it isn't met, wording can't fix it | A term, not experience | None needed beyond your answer | `[grounded]` JD states the term; background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. A single profile result names the hiring manager there, which is not enough to establish the company | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` the company search returned nothing | Can you point me at the role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no figure in the posting as pasted) | The figure may fall inside or outside the survey band, or the company may not publish pay | `[inferred]` from the posting's silence against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | "Own" with authority and team unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The seat may carry ownership without stated decision rights over rating changes, or a team | `[inferred]` from "own" against the JD's silence on authority | Who signs off rating changes, and who else sits in the pricing team? | unresolved |
| RR4 | Concrete outputs named | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope can be defined and judged | `[grounded]` JD | What would a strong first six months look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on a Brindlemoor careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with three things you stated: the GLM rating model you built and maintained for the young-driver book, the 14 price tests you ran with underwriting last year, and the quarterly pricing review you present to the head of underwriting | see R4, R6a, R7, R5 | `[grounded]` your background | pending your approval |
| A3 | On pet insurance, say plainly: motor pricing experience, no pet book priced yet. The carry-over is the modelling, testing and presenting work. The limit is that pet-specific rating factors are new to you | see R9 | `[grounded]` your statement; `[generic]` that pet rating has its own factors | pending your approval |
| A4 | Don't describe anything as people management. Say what you did: you ran price tests with the underwriting team | The JD states no management duty | `[grounded]` JD, your statement | pending your approval |
| A5 | Prepare a real example of monitoring the young-driver GLM after release, using only what's true; leave it until G1 is answered | see R6b | `[inferred]` from Odile's public talk topic | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech"; no results, so the company is not established. This moved RR1 |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote"; it returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). This moved the market calibration and RR2. It gave no scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor"; it returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. This moved role reality and G1/A5 |

I can save this as `tuesday-dossier.md` if you'd like to keep the evidence map and register.

## Upgrade menu

- A link to the live posting or Brindlemoor's own careers page would close RR1 and lift the cap on `conditional_go`.
- Your location and right to work would settle R1.
- Your pay floor would let me test RR2 against it.
- A sanitised model-monitoring report, a price-test readout, or a pricing-review excerpt would move R4, R5, R7 and R6b toward `high`.
- An answer to G2 would settle R8b.
- A deeper research pass on Brindlemoor (funding, leadership, hiring patterns, news; up to 5 more searches and 2 more fetches) will run if you say the word.

**Questions**

R1 — Are you UK-based, with the right to work in the UK without sponsorship, and happy to work fully remote?

G1 — When you maintained the young-driver GLM, what did you monitor after release, how often, and what did you do when it drifted?

RR2 — What is the lowest base salary you'd take for this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.