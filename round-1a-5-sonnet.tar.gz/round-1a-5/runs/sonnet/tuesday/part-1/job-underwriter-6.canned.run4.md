Still working. I've read the posting and finished the research. The assessment is below.

## Decision snapshot

**Yes, it's worth applying, as a stretch with two real gaps (R6, owning a forecast, adjacent; R7a, billing data, absent) and two gates to confirm (R1, R2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 plus options)
- `must_have`: direct: R3a, R4, R5a · adjacent: R6 (owning a forecast) · unclear: R3b (at a B2B software company), R5b (spreadsheet modelling), R7b (finance on revenue data) · absent: R7a (billing data)
- `important`: direct: R8

R6: adjacent, limit named (pipeline review, not forecast ownership); R7a: absent, by your own statement; R3b, R5b, R7b: unclear, waiting on detail from you.

**Opportunity ledger.** Openly priced, with pay inside the pay-guide band (RR5). The open items are who owns the forecast (RR2), what "own billing data" covers (RR3), the team and reporting line (RR4), and that I couldn't find the posting on a Quillfield careers page (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 plus options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 hold against your own location and pay floor; (2) RR2 shows the forecast is shared with finance, or ramped, rather than yours alone from day one (R6); (3) RR3 shows billing-data learning is supported (R7a); (4) RR1 confirms the posting is live.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` "About Quillfield" page (search result) |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Location and pay | Bristol hybrid, two office days a week; £61,500–£67,000 plus share options (terms not stated) | `[grounded]` posting |
| Hiring manager | Tamsin Achebe (named by your recruiter). Her public profile shows Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter via you; `[grounded]` profile search result |
| Scope read | Four duties under one title: CRM, billing data, reporting, forecast. The role likely sits in her function | `[inferred]` from the posting's duty list and her title |
| Market calibration | UK B2B software revenue operations leads: median base £64,200, interquartile range £57,800–£70,400 (n=438, 2026 guide). The posting's band falls inside it. The guide is UK-wide, not Bristol-specific, and is not Quillfield's offer | `[generic]` pay guide; `[grounded]` posting figure |
| Unknowns | Forecast ownership split; billing system and what "own" covers; team size and reporting line; first-year outcomes; option terms | `[grounded]` posting silent |
| Contradictions | None found. The posting was not located on a Quillfield careers page by search (RR1) | `[grounded]` search results |

## Evidence map

Your background is typed prose, so it has the standing of a CV: `medium` is the ceiling until something inspectable is shared.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | Your location and willingness were not given, so the gate is not established | `[grounded]` posting; no constraint stated | G1 question |
| R2 | £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your pay floor was not given. The band sits inside the pay guide's range (RR5) | `[grounded]` posting; `[generic]` pay guide | G1 question |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You stated 5 years in sales operations, the last 2 running revenue operations for the UK team. No document inspected | `[grounded]` your stated background | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether its product reads as software isn't stated | `[grounded]` your background, posting quote | Say plainly what your employer's product is (upgrade menu) |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, as you state. The credential has not been inspected | `[grounded]` your statement | A credential verification link would raise to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. "Strong" is a depth claim that frequency doesn't establish, so expect a probe | `[grounded]` your statement | A sanitized query would raise it |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily. That is use, not a described model | `[grounded]` your statement | Describe one model you built (upgrade menu) |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | Confirmed: you run the monthly pipeline review with your sales director and rebuilt the pipeline and renewal dashboards. Finance owned the company forecast and you have never owned one. Limit: no forecast number, method or accountability was yours | `[grounded]` your statement | G2 question |
| R7a | Billing data (posting: "own our CRM and billing data") | must_have | absent | none | capability | You have never worked on billing data. The finance requirement reads "billing or revenue", so R7b can meet it alone, but the duty to own billing data stays | `[grounded]` your statement, posting quote | G4 closure path |
| R7b | Working with finance on revenue data | must_have | unclear | low | discovery | Your renewal dashboards likely carry revenue figures, but whether you worked with finance on them isn't stated | `[grounded]` dashboards stated; `[inferred]` that they carry revenue data | G3 question |
| R8 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Who used them, finance included, isn't stated | `[grounded]` your statement | Sanitized dashboard screenshots would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay (R1, R2, hard_gate) | hard_gate | The posting states both terms. Your constraints weren't given | A failed gate caps the decision however strong the fit | None needed; this is a fact about your circumstances | None | `[grounded]` posting terms; constraints not given |
| G2 | Owning a forecast (R6, must_have) | transferability | Pipeline review and dashboards are confirmed. A forecast number you produced or owned is not | The posting names forecasting with the CFO as a duty, so this is the likeliest objection | Producing a commit or best-case roll-up for the review; adjusting a number before it went to finance; a renewal forecast | A sanitized pipeline-review pack or forecast-input workbook | `[inferred]` bridge from the review work you described; `[generic]` that this is the likeliest objection |
| G3 | Finance on revenue data (R7b, must_have) | discovery | Renewal dashboards are confirmed. Finance involvement is not | It may satisfy the whole finance requirement without billing data | Finance reconciling renewal values to your dashboards; sharing ARR or renewal figures with a finance contact | A sanitized dashboard or reconciliation note | `[grounded]` dashboards stated, finance silent |
| G4 | Billing data (R7a, must_have) | capability | Never worked on billing data (your statement) | The role owns billing data, so this is a learning curve | None claimed | None | `[grounded]` your statement; `[generic]` closure path: learn a subscription-billing basics course, and ask RR3's question to find out what support exists |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not located on a Quillfield careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The careers page may not be indexed, or the role may be advertised only through the board. Tamsin Achebe's profile does show her at Quillfield, which supports the recruiter's account | `[inferred]` from an empty search against the posting's third-party host; `[grounded]` profile result | Is this role live on your own careers page, and is it still open? | unresolved |
| RR2 | Forecast ownership vs. the CFO unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may feed a finance-owned number or may own it. This matters because you haven't owned one (R6) | `[inferred]` from the posting's "with the CFO" against the "owning a forecast" requirement | Who owns the forecast number today, this role, the CFO or jointly? | unresolved |
| RR3 | Scope of "own billing data" | unknown | — | "own our CRM and billing data" | It may cover billing-system administration and reconciliation, not just reporting | `[inferred]` from the posting's single phrase | Which billing system is it, and does "own" mean reporting only or also data quality and reconciliation? | unresolved |
| RR4 | Team and reporting line unstated | unknown | — | "Revenue Operations Lead" | A "Lead" title with no reports named may be an individual-contributor lead role | `[inferred]` from the title against the posting's silence | Does this role have direct reports, and who does it report to? | unresolved |
| RR5 | Pay stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The figure sits inside the pay guide's range, so there is no pay mismatch to chase. The option terms are the open item | `[grounded]` posting; `[generic]` pay guide | How are the options structured: vesting, strike, and share of the company? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check R1 and R2 against your own location and pay floor before investing further | The two gates | `[grounded]` posting terms | pending your approval |
| A2 | Describe your monthly pipeline review as a pipeline review you run with the sales director, and say plainly that finance owned the company forecast. Don't call it forecasting | Keeps R6 honest as adjacent | `[grounded]` your statements | pending your approval |
| A3 | Say plainly that you haven't worked on billing data, and ask RR3's question | R7a | `[grounded]` your statement | pending your approval |
| A4 | Lead with the pipeline and renewal dashboard rebuild | R8 is your strongest `direct` match to a named duty | `[grounded]` R8 row | pending your approval |
| A5 | Ask the recruiter whether the role is on Quillfield's own careers page, and put RR2 and RR4 to Tamsin Achebe | RR1, RR2, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned "About Quillfield" (quillfield.co.uk/about), and "Quillfield careers Revenue Operations Lead Bristol", which returned no results. Moved: role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: role reality's hiring manager and scope rows, and plan row A5 |

If you'd like this saved for later steps, I can write it out as a `tuesday-dossier.md`.

## Upgrade menu

- Your location and pay floor: R1 and R2 resolve, and the decision may move to `go` or `no_go`.
- A Salesforce credential verification link: R4 moves to `high`.
- Sanitized dashboard screenshots: R8 moves to `high` and supports R7b.
- A sanitized pipeline-review pack or forecast-input workbook: R6's bridge strengthens.
- A sanitized SQL query and a description of a spreadsheet model you built: R5a and R5b firm up.
- One line on what your employer's product is: R3b resolves.
- Recruiter or Tamsin's answers on RR2 and RR3: R6 and R7a risk is sized.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**G1.** Does two days a week in a Bristol office work for you, and is £61,500–£67,000 plus options acceptable?

**G2.** In your monthly pipeline review, did you produce or adjust a forecast number (commit, best case or similar), or was it pipeline inspection only? Who set the number that went to finance?

**G3.** Have you worked with finance on revenue data, for example renewal values or ARR figures that finance used or reconciled? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.