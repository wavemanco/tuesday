Running the job-underwriter on this posting. Web search wasn't permitted this turn, so this rests on your two pasted texts.

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2 are hard gates and both fail. Status: `no_go`.** Your instinct was right, and the problem is the posting's terms, not your fit.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site Austin five days a week)
- `must_have` — direct: R3, R4a · unclear: R4b (SEO/content, brand, PR, partnerships, sales ops)
- `important` — unclear: R5 (Team of one, no bench)

R1 — the top of the band sits $65k under your floor; R2 — five on-site days in Austin against remote-only from Portland; R4b (`low`) — your stated work covers paid and lifecycle and is silent on the other functions.

**Opportunity ledger.** RR1 and RR2 — the pay and location conflicts, both confirmed; RR3, RR4, RR5 — a solo seven-function mandate, an after-hours expectation, and undefined success metrics; RR6 — employer unchecked; RR7 — the one positive signal.

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site Austin five days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would have to differ:** a base at $150k or above (R1) and a remote arrangement from Portland (R2). The posting says "no exceptions" on location, and nothing in it suggests either term bends.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not verified (searches unavailable) |
| Mandate | Own revenue growth across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | A team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin five days a week, no exceptions; evenings and weekends "when it matters" | `[grounded]` JD |
| Pay | $70–85k base plus equity, which is $65k to $80k below your $150k floor | `[grounded]` JD against your stated floor |
| Success metrics | Not defined: "will evolve as we learn" | `[grounded]` JD |
| Scope read | Seven functions at head-of-function seniority, priced at the level of a single-channel specialist | `[inferred]` from the function list and the stated pay; band unchecked |
| Market calibration | Not run, because search was unavailable. Roles that fold this many functions into one title with no team usually carry more scope than the pay implies | `[generic]` role-family pattern, not a claim about Novaline |
| Unknowns | Marketing budget, headcount plans, the equity percentage and terms, whether the product is sold to businesses or consumers | — |
| Contradictions | None found between sources. The posting is the only source. | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay $70–85k, against your floor of $150k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor. The fit fails because even the top of the posted band is $65k under it | `[grounded]` JD and your stated constraint | Surface only. A changed offer or a revised floor is the only resolution |
| R2 | On-site in Austin five days a week, "no exceptions", against your remote-only constraint from Portland | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The posting rules out any exception | `[grounded]` JD and your stated constraint | Surface only; no workaround to hunt |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, as growth lead and then Head of Growth. The years in lead or head titles aren't split out, and prose is the intake ceiling, so `medium`. Expect a probe on the dates | `[grounded]` your stated background | Have your lead and head start dates ready |
| R4a | Paid acquisition and lifecycle/CRM | must_have | direct | medium | none | You own paid and lifecycle, with Braze and GA4, and scaled $8M to $40M ARR on a budget you controlled. The B2C subscription context may differ from this employer's, whose customer type isn't stated | `[grounded]` your stated background; `[inferred]` that the contexts differ | Artifact that would raise it: a growth dashboard or an end-of-period report |
| R4b | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Nothing you've said covers these five functions. Silence is not absence, so this is a discovery gap, not a capability gap | `[grounded]` your background is silent on them | G1 |
| R5 | Run every function personally as a team of one | important | unclear | low | discovery | You've built and managed teams of 3 to 7. Solo execution across functions isn't stated either way | `[grounded]` your background is silent on solo work | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Five functions beyond paid and lifecycle (R4b, must_have) | discovery | Your stated work covers paid, lifecycle and experimentation, with no mention of SEO, brand, PR, partnerships or sales ops | Only matters if the terms change, since R1 and R2 decide the status first | Ran content or SEO programmes, negotiated co-marketing or distribution deals, led a launch with PR | A content calendar, a partnership agreement, a campaign recap | `[grounded]` background silence; `[inferred]` that this would not move the status while R1 and R2 stand |
| G2 | Working with no team (R5, important) | discovery | Team-building is evidenced and solo execution isn't | Same: it can't outweigh a hard-gate failure | Early-stage stints before a team existed; periods when headcount froze | Any scope or role description from those periods | `[grounded]` background silence; `[inferred]` as above |

No question is worth asking this turn, because no answer could change a status set by two failed gates.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The band is also low for the head-of-function seniority the posting asks for, which needs a market band to confirm | `[inferred]` from the posting's pay against its own seniority ask; band unchecked | Is the base fixed at $70–85k, and what is the equity percentage and vesting? | confirmed |
| RR2 | Location conflicts with remote-only (R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Nothing in the posting suggests flexibility for a Portland-based hire | `[grounded]` JD states "no exceptions" | Is the five-day on-site requirement firm for a candidate based in Portland? | confirmed |
| RR3 | Seven functions, no team, no stated resources | risk_signal | medium | "Own all revenue growth end to end … You will be a team of one to start" | The mandate may carry full revenue accountability with no budget or headcount | `[inferred]` from the function list against the posting's silence on resources | What marketing budget and headcount are committed for year one, and when is the first hire? | unresolved |
| RR4 | After-hours expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine rather than occasional | `[inferred]` from the phrase "just who we are" | In the past six months, how often were evenings or weekends needed, and is there time off in return? | unresolved |
| RR5 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for revenue with no agreed definition of success | `[inferred]` from the missing metrics beside a full revenue mandate | What revenue or pipeline outcome defines a good first year, and who sets it? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Search was unavailable, so nothing here confirms the company. Reasons could include a new or small company, a stale posting, or a posting that doesn't reflect a live hiring need | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would interview with? | unresolved |
| RR7 | Direct CEO access and a stated profitable business | positive_signal | — | "Report to the CEO with a dotted line to the board … profitable since day one" | If true, the role has real access and the company isn't burning runway | `[grounded]` JD states both; unverified | What does the board expect of this role in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this role as posted | See R1, R2, RR1, RR2 | `[grounded]` the two failed gates | pending your approval |
| Q1 | If you proceed against `no_go`, put RR1 to RR5 to the employer verbatim before investing further | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the call was refused because search permission wasn't granted. It would have moved role reality's organization row and RR6 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary range e-commerce startup Series A 2026"; refused for the same reason. It would have moved the market calibration row and RR1's hypothesis |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this as `tuesday-dossier.md` if you'd like a record to carry into later conversations.

## Upgrade menu

- Search permission, to check Novaline's site and a market pay band: RR6 closes and the market calibration row fills in. Neither changes the status.
- Dates for your lead and head titles, plus a growth dashboard or end-of-period report: R3 and R4a can rise to `high`.
- Evidence of SEO, brand, PR, partnerships or sales ops work: R4b moves, but only matters if the terms change.
- A written offer with a different base or a remote option: R1 and R2 get re-read and the status regenerated.
- The hiring manager's name: it would add a scope read to role reality.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.