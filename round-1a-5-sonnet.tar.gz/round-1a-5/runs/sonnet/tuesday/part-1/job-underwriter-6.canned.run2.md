Research is finished (four searches, two fetches, plus your posting link), so I'm writing up the assessment now.

# Underwriting: Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, worth applying to, as a stretch: R6 (forecast ownership) is adjacent and R8 (billing data) is absent, and both are must-haves. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (Pay £61,500–£67,000)
- `must_have`: direct: R3, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Owning a forecast) · unclear: R7 (Working with finance on billing or revenue data) · absent: R8 (Own billing data)
- `important`: direct: R9

R6 is a credible bridge with its limit named; R7 is waiting on one answer about finance; R8 is a confirmed gap with a closure path.

**Opportunity ledger.** Sound on what is visible: the pay sits inside the market range (RR2) and the employer matches its description (RR3). The team, reporting line and success measures are unstated (RR1), the posting is not confirmed on Quillfield's own site (RR4), and the share-option terms are unstated (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Pay £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days, and the pay band, fit your own limits — R1, R2; (2) you have a real example of working with finance on revenue data — R7; (3) the forecast and billing-data gaps are carried openly, not papered over — R6, R8, RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` "About Quillfield" page fetched |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Requirements stated | 4+ years in RevOps, sales ops or similar analytics at a B2B software company; HubSpot or Salesforce admin; strong SQL and spreadsheet modelling; experience owning a forecast; experience working with finance on billing or revenue data | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, as your recruiter said. Her public profile lists her as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` profile page fetched |
| Scope read | One "Lead" title carries CRM, billing data, reporting and a CFO-facing forecast, with no team or first-year outcomes named. The role likely sits inside her function | `[inferred]` from the duty list and the posting's silence, and from her title |
| Market calibration | UK revenue operations lead, B2B software: median base £64,200, interquartile range £57,800–£70,400 (Ledgerline 2026, n=438). The posted band sits inside that range, near the median. It is a market pattern, not Quillfield's offer | `[generic]` survey band; `[grounded]` posting figure |
| Contradictions | The posting is hosted on Tallyboard Jobs, and a search for Quillfield's own careers page returned nothing, so the role is not confirmed live on their site. The company description otherwise matches the posting (RR4) | `[grounded]` search result and about page |
| Unknowns | Team size and reporting line; which billing system sits under the role; how forecast ownership splits between finance and this role; option terms | `[grounded]` posting silence |

## Evidence map

Your background is typed prose, so it counts as self-report: confidence stops at `medium` until something inspectable is seen.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You gave no location or schedule limit, so nothing settles this term either way | `[grounded]` posting term; no candidate constraint supplied | G1's question |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor was given, so the posted band cannot be checked against it. The band sits inside the market range (RR2) | `[grounded]` posting figure; no candidate constraint supplied | G1's question |
| R3 | 4+ years in revenue operations, sales operations or similar analytics, at a B2B software company | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team, clears the years. Whether a B2B payments company counts as a "B2B software company" is untested | `[grounded]` your stated background; `[inferred]` on the sector wording | none; confirm the sector point in the screen |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified meets the "or". The certificate has not been inspected, so `medium` | `[grounded]` your stated certification | offer: the certificate would raise to high |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show regular use. They do not show depth or modelling, so it is read downward | `[grounded]` your stated usage; no evidence on modelling depth | G5 in the queue |
| R6 | Experience owning a forecast, and running the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You have not owned the company forecast; finance did. You run the monthly pipeline review with your sales director, which is adjacent work | `[grounded]` your own account | G3's question |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | The requirement allows "billing or revenue data". Your renewal dashboards touch revenue, but nothing says finance was involved | `[grounded]` your stated dashboard work; `[inferred]` that revenue data may qualify | G2's question |
| R8 | Own the billing data | must_have | absent | none | capability | You confirmed you have never worked on billing data, so there is no direct or adjacent evidence | `[grounded]` your own statement | closure path in G4 |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is not stated | `[grounded]` your stated work | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, schedule and pay limits (R1, R2, hard_gate) | hard_gate | No limits stated, so both terms stay unconfirmed | A failed gate would end the application however strong the fit is | Not applicable: this is a yes or no on your own limits | Not applicable | `[grounded]` no constraints supplied |
| G2 | Working with finance on revenue data (R7, must_have) | discovery | Renewal dashboards exist, but finance's part in them is not stated | A must-have; a confirmed example would move R7 up and strengthen the case | Reconciling bookings or renewals to the figures finance reported; building or checking a renewal view with a finance partner; month-end or quarter-end revenue checks | A reconciliation sheet, a dashboard spec naming finance as a user, a sanitized email thread | `[grounded]` the dashboards you described; `[generic]` that screens for this role probe it |
| G3 | Forecast ownership (R6, must_have) | transferability | Adjacent work: you run the monthly pipeline review with your sales director. Limit: finance owned the forecast, and nothing says you set or defended a number | The posting names the forecast with the CFO as a core duty | Preparing pipeline inputs finance used; tracking forecast against actuals; calling a quarter's number in the review | A sanitized pipeline review deck; a forecast-versus-actual tracker | `[grounded]` your account; `[generic]` that this is the likeliest objection |
| G4 | Billing data (R8, must_have) | capability | You confirmed no billing-data work. There is nothing adjacent to bridge from | It is a day-one ownership duty. A confirmed gap is not hidden, and a realistic path can narrow it | Closure path, not a recall prompt: learn the billing system's data model, practise SQL on invoice or subscription data, and ask in the screen which billing system sits under the role | A small self-built exercise on invoice data, once a work sample is approved | `[grounded]` your own statement; `[generic]` that billing data is learnable for an experienced SQL user |
| G5 | SQL and spreadsheet modelling depth (R5, must_have) | discovery | Use is stated; depth and modelling are not | Lower impact than G2 and G3, so no question is spent on it this turn | A forecast or revenue model you built; a SQL query set behind a dashboard | A model workbook or a query file, sanitized | `[grounded]` your stated usage |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team, reporting line and success measures unstated | unknown | — | "own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | One title may carry several jobs with no stated team, authority or first-year outcome | `[inferred]` from the duty list against the posting's silence | Who does this role report to, who else sits in revenue operations, and what does success look like in the first year? | unresolved |
| RR2 | Pay band against market | positive_signal | — | "£61,500–£67,000 plus share options" | The band is consistent with the seniority asked; it is a UK-wide market pattern, not Quillfield's offer | `[grounded]` posting figure; `[generic]` Ledgerline 2026 band | Does the band flex with experience? | noted |
| RR3 | Employer matches its description | positive_signal | — | "Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol; 96 employees." | Quillfield is a funded, mid-sized software firm, as the posting implies | `[grounded]` about page fetched | How is the revenue team structured now that the Series A has closed? | noted |
| RR4 | Role not seen on the employer's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed only on the job board, or the careers page may not be indexed | `[generic]` pattern, not a claim about this employer | Is this role listed on Quillfield's own careers page, and is it still open? | unresolved |
| RR5 | Share-option terms unstated | unknown | — | "plus share options" | The value depends on grant size, vesting and strike, none of which is given | `[generic]` pattern that option value turns on those terms | What is the grant size, vesting schedule and strike price? | unresolved |

## Application plan

Every row is proposed. Nothing here is final until you approve it, and that covers the prose in the rows as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with three facts you gave me: "Salesforce admin certified", "rebuilt our pipeline and renewal dashboards", and "run the monthly pipeline review with our sales director" | These carry R4, R9 and the adjacent half of R6 | `[grounded]` your own sentences | pending your approval |
| A2 | If asked about the forecast, say it plainly: "Finance owned our company forecast. I run the monthly pipeline review with our sales director, and I haven't owned the forecast itself." | Keeps R6's limit visible rather than letting the interviewer find it | `[grounded]` traces clause by clause to your two statements | pending your approval |
| A3 | Ask RR1, RR4 and RR5's questions verbatim with the recruiter or Tamsin | The register doubles as screen preparation | `[grounded]` register | pending your approval |
| A4 | Say the billing-data gap once, early, and ask which billing system sits under the role | See R8, G4 | `[grounded]` your own statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" and "Quillfield careers Revenue Operations Lead Bristol"; fetched "About Quillfield" (quillfield.co.uk/about). The company exists as described (RR3). The careers search returned nothing, so the live posting is unconfirmed on their own site (RR4) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide), read as a search result only. It supplied the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; fetched "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). It supplied role reality's hiring-manager and scope rows |

I can save all this as a `tuesday-dossier.md` so a later session can pick it up. Say the word and I will.

## Upgrade menu

- Your CV, so R3 to R6 can be checked line by line for presentation gaps.
- The Salesforce certificate or a sanitized dashboard screenshot, which would raise R4 and R9 to `high`.
- A sanitized pipeline review deck or a forecast-versus-actual tracker would firm up R6, and a reconciliation sheet would do the same for R7.
- A forecast or revenue model you built, or the SQL behind a dashboard, would settle R5.
- Your location and pay limits would close R1 and R2.
- The recruiter's answers on team, reporting line, billing system and careers-page listing would close RR1 and RR4.
- The option terms would close RR5.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1 — Does a Bristol-based role with two office days a week, at £61,500–£67,000, work for you, or is either one a limit?

G2 — Have you worked with finance on revenue numbers, and what did you own and what was finance's?

G3 — In the forecast process finance owned, what did you produce that finance used, and which part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.