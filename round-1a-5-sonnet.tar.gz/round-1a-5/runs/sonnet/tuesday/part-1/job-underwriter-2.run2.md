Quartzline's JD against your resume. The two web searches were refused by the host, so this runs on the pasted JD and resume alone.

## Decision snapshot

**No, you aren't wasting your time on this role. It is a real stretch, though: R1b (titled PM years) is a miss and R2 (shipped API products) is only adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1a (3+ years of PM work), R2 (shipped API or platform products) · absent: R1b (titled PM experience)
- `important` — direct: R4a, R6 · adjacent: R7 (specs and squad delivery), R9 (own the roadmap) · unclear: R4b (launches with sales and support), R5 (agile delivery), R8 (adoption metrics)

R1b — no titled PM years; R2 — integrated APIs, did not own one; R3 (`medium`) — stated, awaiting an artifact.

**Opportunity ledger.** The employer was not checked (RR1), pay and location are unstated (RR2), roadmap authority is unclear (RR3), and the "3+ years" wording is open to a titled-years reading (RR5). RR4 runs the other way: concrete users and two named squads.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the live posting verify (RR1); (2) you ask whether "3+ years" means titled PM years before investing heavily (R1b, RR5); (3) your application frames the API work as adjacent experience (integrating and documenting APIs), never as PM years or roadmap ownership (R1a, R2, R9).
- **What would change this:** a flat "titled PM years only" answer to RR5 reopens the status. A confirmed shipped-product story from G1 would strengthen R2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B; existence not independently checked | `[grounded]` JD header |
| Mandate | Own the roadmap of a partner-facing API platform; discovery with integration partners; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Stated bar | 3+ years PM experience marked must-have; shipped API or platform products; fluency with API docs and schemas; stakeholder management; agile | `[grounded]` JD |
| Scope read | An external-facing platform PM role where partners are the users | `[inferred]` from "partner-facing" and "integration partners" |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not run: the role-family search was refused, so no band is offered | `[grounded]` evidence status below |
| Unknowns | Pay, location or remote policy, success metrics, who decides priorities | `[grounded]` JD silent |
| Contradictions | None visible inside the JD; not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management work ("3+ years product management experience (must-have)") | must_have | adjacent | medium | transferability | You wrote requirements documents, ran quarterly roadmap-input sessions, and coordinated with product managers on custom builds. The limit is that all of it sat on the vendor's solutions side, with no stated accountability for a product decision. Confirmed at intake only, with no artifact. | `[grounded]` resume; limit `[inferred]` from the absence of ownership language | Apply P1 framing; G1 |
| R1b | Titled PM experience (same JD line, read literally) | must_have | absent | none | capability | You say you've never held a PM title, so titled years have nothing to match. This row grades the title only; the work is R1a. Employers sometimes screen titled years literally. | `[grounded]` your statement; `[generic]` literal-screening pattern, not a claim about Quartzline | Ask RR5's question; the closure path is a titled or hybrid product role |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your employer's REST APIs and wrote the playbook the team uses. The limit is that integrating and documenting an API is different from owning or shipping one, and nothing says you decided what it did. | `[grounded]` resume; limit `[inferred]` | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture match the JD's wording. `medium` because it is stated without an inspectable artifact. | `[grounded]` resume | A sanitized playbook excerpt would raise it to `high` |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran scoping workshops and UAT with clients. Sales is not mentioned (see R4b). | `[grounded]` resume | none |
| R4b | Launch coordination with sales and support | important | unclear | low | discovery | The resume is silent on sales or support at launch, and a client go-live is not a product launch. | `[grounded]` resume silence | Ranked below G1–G3; carried as a queue row |
| R5 | Agile delivery | important | unclear | low | discovery | The resume describes scoping, UAT and go-live but never sprints, backlogs or cadences. | `[grounded]` resume silence | G3 |
| R6 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops across 30+ client integrations, plus quarterly sessions collecting client feedback for product. The limit is that the feedback went to product, and you don't claim to have decided what got built. | `[grounded]` resume | none |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and integration architecture for client builds, with engineers coordinated. The limit is that these are client-specific scoping documents, not specs for a shared roadmap. | `[grounded]` resume; limit `[inferred]` | P4 work sample |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | SQL is named, but no metric you defined or tracked is. The one thread is a prior-context lead (an internal request-triage tool that support agents adopted), which is unconfirmed and is not evidence. | `[grounded]` resume silence; `memory_lead` | G2 |
| R9 | Own the roadmap for the partner-facing API platform | important | adjacent | medium | transferability | Roadmap-input sessions are input to a roadmap, not ownership of one. The limit is that no prioritisation or trade-off decisions are stated. | `[grounded]` resume; limit `[inferred]` | G1; P2 framing |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped or owned product (R2, must_have) | transferability | 30+ integrations and a team playbook, but nothing showing you decided what a product or API did | R2 is a `must_have` row at `adjacent`, and a confirmed owned-product story is the strongest way to narrow it | A feature or API change that began as your scoping and got built; a process, template or internal tool others adopted (a prior-context mention of a request-triage tool is unconfirmed); a playbook rule that changed how engineering shipped | A sanitized playbook excerpt, a requirements or change-request document, or a usage screenshot | `[grounded]` resume; `[inferred]` that this narrows R2 |
| G2 | Adoption metrics (R8, important) | discovery | SQL named; no metric defined or tracked | The JD asks you to define and track adoption, and this is the cheapest row to recover | Time-to-go-live across integrations; the share of clients using a given endpoint; the usage of a tool or playbook you built | A query, dashboard screenshot or summary table | `[grounded]` resume silence; `[inferred]` from the JD's metrics duty |
| G3 | Agile delivery (R5, important) | discovery | No cadence, backlog or sprint language | Listed as a requirement, and it is the cheapest to confirm | Sprint or standup participation on custom builds; prioritising a backlog with engineers; release planning with client deadlines | A ticket board export or release plan, sanitized | `[grounded]` resume silence |
| G4 | Sales and support launch work (R4b, important) | discovery | Silent | Part of the stated launch duty | Joint go-live plans with sales; training support on a new integration pattern | A launch checklist or enablement note | `[grounded]` resume silence |
| G5 | Titled PM years (R1b, must_have) | capability | None, by your own statement | No wording fixes this, so it is carried as a material risk | Not applicable: titled years either exist or they don't | None | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer; research did not run here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location unstated | unknown | — | JD header lists only title, company, size and stage | Terms may come later in the process, or the posting may withhold them | `[grounded]` JD silent | What is the salary band, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Roadmap authority unclear | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may be accountable for the roadmap while sales commitments or leadership set priorities | `[inferred]` from the JD's ownership language against its silence on decision rights | Who sets platform priorities when partner requests and sales commitments conflict, and which decisions does this role make alone? | unresolved |
| RR4 | Defined users, squads and duties | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The mandate is concrete: named users, named teams, and a measurable duty | `[grounded]` JD | What does success look like for this role at twelve months? | noted |
| RR5 | "3+ years" may be read as titled years | unknown | — | "3+ years product management experience (must-have)" | The screen may require titled PM years, or it may accept equivalent hands-on product work | `[generic]` titled-years pattern, not a claim about Quartzline | Is the 3+ years read as titled PM years, or would hands-on product work on an API platform count? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the 30+ integrations and the playbook as API-platform work from the solutions side, and do not describe them as PM years | See R1a, R2; a PM-years claim has no source in your resume | `[grounded]` resume | pending your approval |
| P2 | Describe the roadmap-input sessions as collecting client feedback for product, as your own sentence says, and never as owning a roadmap | See R9; ownership would widen your claim | `[grounded]` resume | pending your approval |
| P3 | Verify Quartzline and the live posting before any application effort, then ask RR5's question through a contact on the company's own site | See RR1, RR5, R1b | `[grounded]` register | pending your approval |
| P4 | Draft a one-page sanitized work sample, such as an integration pain-point brief written as a roadmap proposal, to test R2, R7 and R9 | A concrete artifact is what can raise `medium` rows | `[inferred]` from the rows it supports | pending your approval |
| P5 | Ask the RR3 and RR4 questions verbatim in any interview loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: an earlier-conversation mention of an internal request-triage tool adopted by support agents — unconfirmed, so it prompts a question and nothing more.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for "Quartzline logistics technology partner API platform careers" was refused by the host. It would have moved RR1, the Organization row, and the contradictions row |
| 2. Role-family sweep | unavailable | A search for "platform API product manager requirements transition from solutions engineer without PM title" was refused. It would have moved the market-calibration row and any pay mismatch entry. Nothing in this assessment rests on it |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Extra, offered not built: if you paste two or three other API-platform PM postings, I can map the same requirements across them to show whether the titled-years bar repeats. That bears directly on your wider pivot question, and this posting alone can't answer it.

I can also write this up as a `tuesday-dossier.md` whenever you like.

## Upgrade menu

- Permission to run web search, or a link or paste of Quartzline's careers page → RR1, the Organization row and a market band.
- A sanitized playbook excerpt or requirements document → R3 to `high`, and R2 and R7 strengthen.
- Answers to G1–G3 → R2, R8 and R5 move, and the decision firms up.
- A recruiter's answer on RR5 → R1b's practical weight settles.
- Salary band and location from the recruiter → RR2 closes, and your constraints can be checked.
- Your own non-negotiables (pay floor, location, schedule) → hard-gate checks that currently read as unknown.
- The hiring manager's name → the scope read and what to lead with.

## Questions

G1 — Has any product, API change, process or internal tool started from something you scoped and then shipped? What did you own, who used it, and what happened?

G2 — How has adoption or usage been measured for anything you built or ran (go-live times, endpoint usage, a tool's users)? Did you query it yourself?

G3 — On custom builds with your engineers, what cadence did you work in (sprints, standups, a backlog), and what did you personally set priorities on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.