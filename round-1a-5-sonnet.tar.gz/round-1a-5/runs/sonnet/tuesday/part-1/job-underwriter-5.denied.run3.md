I'm running one search to confirm Pellucid Learning exists as described and that the posting is live. Then I'll write the assessment.
## Decision snapshot

**Yes, this is worth applying to, on conditions. Status: `conditional_go`.** R3, R4, R5, R6 and R7 are `direct`. The open items are R1 and R2 (your location and pay floor were never stated), R8 (BigQuery), and RR1 (I couldn't check the employer).

**Fit ledger**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (Warehouse in BigQuery); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8: a credible bridge from Snowflake, its limit named; R9, R10: not evidenced either way, so one question covers both.

**Opportunity ledger.** The pay is stated and sits in the market band (RR4). The remaining entries are unknowns: the employer is unchecked (RR1), the manager is unnamed (RR2), the scope is broad (RR3), and the equity terms are missing (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the location and pay terms work for you (R1, R2); (3) the scope and reporting line are clarified (RR2, RR3); (4) BigQuery is framed as adjacent and never as experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently checked (RR1) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Seniority | Your six years fall inside the 5–8 years the pay report calls typical for "Senior" | `[grounded]` pay report and your background |
| Scope read | The posting spans ingestion, modelling and contracts. The report's typical scope is one domain's pipelines with no direct reports, so this may be broader | `[grounded]` report's typical scope; `[inferred]` the JD spans more than one domain (RR3) |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500. The posting's $148,000–$166,000 starts just under the median and ends above the upper quartile | `[grounded]` Datawright 2026 report (n=2,310) and JD; the band is a market pattern, never this employer's offer |
| Stage | Assumed evaluating | `[inferred]` from your question |
| Unknowns | Hiring manager, team size, equity terms, and your own location and pay floor | `[grounded]` JD silence and your message |
| Contradictions | None between the JD and the about text you pasted | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or whether you can work in the US, so the gate is neither met nor failed | `[grounded]` JD term; no statement from you | Q1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No floor from you, so I can't say whether the range meets it. The range itself is in the market band (RR4) | `[grounded]` JD figure; `[grounded]` pay report | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, your own account, no document inspected | `[grounded]` your background | Share your CV |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, per you; nothing inspectable yet | `[grounded]` your background | Share your CV |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | A dbt project of about 180 models on Snowflake, which is a cloud warehouse. The BigQuery part is R8 | `[grounded]` your background | A model-count or repo-structure artifact would raise this to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration | `[grounded]` your background | Share your CV |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so the ownership is yours as stated | `[grounded]` your background | A suite summary would raise this to `high` |
| R8 | Dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake and dbt carry over. Limit: you haven't used BigQuery's cost model, partitioning or clustering, or its permissions | `[grounded]` your background; the JD's wording names a cloud warehouse as the requirement and BigQuery in the mandate | G1 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your sources at the payroll company weren't described, so nothing is established | `[grounded]` no detail given | Q2 |
| R10 | Data contracts for analysts | important | unclear | none | discovery | Nothing in your background addresses contracts or analyst-facing agreements | `[grounded]` no detail given | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake and dbt at scale; no BigQuery use | The mandate names BigQuery, so it is the likeliest probe in a screen. A named limit reads better than a stretched claim | Snowflake cost or performance tuning; dbt materialization choices; warehouse migrations | A small dbt project on BigQuery's free tier, or a short note comparing the two warehouses | `[grounded]` you have never used BigQuery; `[generic]` that this is a common probe for the role family |
| G2 | Ingestion from product and CRM sources (R9, important) | discovery | No sources named | The posting makes it a first duty | Syncing a SaaS or CRM into the warehouse; event or API ingestion; handling schema changes in a source | An architecture diagram or an ingestion runbook | `[grounded]` background silent |
| G3 | Data contracts (R10, important) | discovery | Nothing described | Analysts' dependence on contracts is the posting's own phrase | Agreed schemas or SLAs with analysts; breaking-change processes; tests that enforce expectations | A contract doc, a changelog or a schema-change policy | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The text comes from the company's own pages as you supplied it. The search I tried was refused, so nothing independent has confirmed it. The posting may also be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager unnamed | unknown | — | "The posting names no hiring manager." | The reporting line and team shape are unknown | `[grounded]` your note on the posting | Who would this role report to, and what does that team look like today? | unresolved |
| RR3 | Scope may exceed one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | This could be a sole data engineer covering ingestion, modelling and contracts, which is wider than the typical one-domain ownership. Low severity because the pay sits in the band | `[grounded]` report's typical scope; `[inferred]` the JD spans more than one domain | How many data engineers are there today, and which of ingestion, modelling and contracts would I own from day one? | unresolved |
| RR4 | Pay stated and in the market band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is transparent. The low end is $3,000 under the report's $151,000 median and the top is $2,500 above its $163,500 upper quartile | `[grounded]` JD and pay report | Where in the range would someone with six years land? | noted |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | The type, size and vesting are all unknown, so the pay is only partly priced | `[grounded]` JD silence | What is the equity grant for this level: type, size and vesting? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the dbt project (about 180 models) and the Great Expectations suite, both as your own work | see R5, R7 | `[grounded]` your background | pending your approval |
| A2 | State BigQuery honestly as adjacent: you have used Snowflake, not BigQuery | see R8, G1 | `[grounded]` your background | pending your approval |
| A3 | Optionally build a small dbt-on-BigQuery sample to narrow the limit | see G1 | `[inferred]` from the gap | pending your approval |
| A4 | Confirm the live posting on the company's own careers page, and put RR2, RR3 and RR5 to the recruiter | see RR1, RR2, RR3, RR5 | `[grounded]` register | pending your approval |
| A5 | Read the posting's range against the report's band before any pay conversation | see RR4 | `[grounded]` pay report | pending your approval |

## Evidence status

Verified: none yet. Your background was typed in, so it is treated as CV-equivalent self-report.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent two searches (company and funding, and the careers posting). Both were refused for lack of permission and returned nothing. They would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | skipped | Your pay report is in hand and fixes the market calibration and the pay comparison in RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can write this up as `tuesday-dossier.md` whenever you like.

**Upgrade menu**

- Your CV or resume → R3 to R7 firm up, and the application plan's wording gets grounded in your actual lines.
- Permission to run web search → RR1 may close, and the employer check runs; a deeper pass later (up to 5 more searches and 2 more fetches) is optional.
- A BigQuery sample or a warehouse-comparison note → R8's limit narrows.
- A pipeline or contract artifact → R9 and R10 firm up.
- The hiring manager's name → the application plan can lead with the story that suits that reader.

**Questions**

- Q1 (R1, R2): Where are you based and are you authorized to work in the US, and what pay floor would you need?
- Q2 (G2, R9): What sources did your payroll pipelines ingest, and did you own the ingestion yourself?
- Q3 (G3, R10): Did you have any agreed schemas, SLAs or change processes with the analysts who used your data?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.