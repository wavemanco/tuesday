## Decision snapshot

**Yes, worth applying to as a stretch, not a safe fit. It depends on Bristol two days a week (R1) and £61,500–£67,000 (R2) working for you, and the forecast and billing gaps (R6, R7, R8) will be the sticking points. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Owning a forecast), R7 (Working with finance on billing or revenue data)
- `important`: direct: R9 · adjacent: R10 (Quarterly forecast with the CFO) · absent: R8 (Owning billing data)

R6, R10 — the forecast is a bridge with its limit named, never owned; R7, R8 — billing data is outside your history by your own account; R5 (`low`) — usage frequency stated, modelling not shown.

**Opportunity ledger.** Sound on what the posting shows: pay is stated and sits inside the surveyed range (RR3). The open items are who owns the forecast (RR1), which CRM and billing stack the role inherits (RR2), the option terms (RR4) and whether the role appears on Quillfield's own site (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay range work for you — R1, R2; (2) the forecast scope is clarified with the hiring side — RR1; (3) the forecast and billing gaps are stated plainly, never presented as owned experience — R6, R7, R8, R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. It was founded in 2018 in Bristol, has 96 employees, and closed a £11M Series A in April 2025. The posting's "invoicing software company" matches | `[grounded]` search result from quillfield.co.uk/about (page not opened) |
| Mandate | Own CRM and billing data, build pipeline and renewal reporting for sales and finance, and run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, per your recruiter. A public profile lists her as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` your recruiter's statement; `[grounded]` search-result snippet of her profile (page not opened) |
| Scope read | The role likely sits inside a revenue-operations function led by a Head of RevOps, not under finance. The posting does not say whether a team reports to the role | `[inferred]` from her listed title against the posting's silence on team |
| Market calibration | A 2026 UK survey puts the revenue operations lead in B2B software at a median base of £64,200 (interquartile range £57,800–£70,400, n=438). The posted range sits inside that band. The band is a pattern, not Quillfield's offer | `[generic]` search-result snippet from ledgerline.example (page not opened) |
| First-year outcomes | Not stated in the posting | `[grounded]` posting silent |
| Unknowns | Who owns the forecast today; which CRM and billing system are in use; option terms; team size; your stage (assumed evaluating) | — |
| Contradictions | None found between the posting and Quillfield's about page; the posting does not appear on a careers address I tried (see RR5) | `[grounded]` about page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states the terms. You have not told me where you are based or what attendance you can do, so nothing confirms or fails the gate | `[grounded]` posting; no candidate constraint given | Closing question on R1 and R2 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the range. Your pay floor was not given, so the gate is not established | `[grounded]` posting; no candidate constraint given | Closing question on R1 and R2 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running RevOps for the UK team, which exceeds 4. Limit: you call the employer a B2B payments company, and whether that reads as "software" is the employer's call. Your own account, not yet probed | `[grounded]` your message; `[inferred]` that a payments company will be read as software | Role dates on your CV would back this claim |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate has not been inspected, and which CRM Quillfield runs is unstated (RR2) | `[grounded]` your message | A certification record would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | SQL weekly and Excel daily show use. They do not show modelling, and "strong" is unproven | `[grounded]` your message | See G3 |
| R6 | Experience owning a forecast | must_have | adjacent | low | discovery | You say finance owned the company forecast. Adjacent work is the monthly pipeline review with your sales director and the pipeline dashboards you rebuilt. Whether you produced any forecast figure of your own, even team-level, is not established, so this stays at the lower band | `[grounded]` your message | G1 |
| R7 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | You have not worked on billing data. The revenue side is adjacent through your renewal dashboards, but working with finance on them is not stated | `[grounded]` your message | G2 |
| R8 | Owning billing data (the posting: "own our CRM and billing data") | important | absent | none | capability | By your own account there is no billing-data work to point to. It is carried as a material risk, not asked about again | `[grounded]` your message | G4 |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt pipeline and renewal dashboards. Finance as a user of them is not stated, so the claim is held at `medium` | `[grounded]` your message | A sanitised dashboard screenshot would raise this to `high` |
| R10 | Run the quarterly revenue forecast with the CFO | important | adjacent | low | transferability | Bridge: you run the monthly pipeline review with your sales director. Limit: no forecast ownership and no CFO-level cadence stated. Strengthener: a sanitised review pack showing what you present | `[grounded]` your message | See the upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | discovery | You never owned the company forecast. Nothing says whether you produced any forecast number of your own | A `must_have` row at `adjacent`; the answer sets how the forecast bridge (R10) is framed | A renewal or pipeline projection for the UK team that you presented; a commit-versus-closed call in the monthly review; a number finance took from your pipeline view | A sanitised pipeline-review deck or forecast tab | `[grounded]` your message; `[inferred]` that the answer moves the framing, not the status |
| G2 | Working with finance on billing or revenue data (R7, must_have) | discovery | You have not worked on billing data. Renewal dashboards touch revenue, but finance's role in them is not stated | A `must_have` row at `adjacent`; any shared revenue work with finance closes the "or revenue data" half of the requirement | Reconciling closed-won against invoiced revenue with finance; supplying month-end renewal numbers to finance; agreeing contract-value fields with them | A sanitised reconciliation sheet, a renewals report finance used | `[grounded]` your message; `[inferred]` from the posting's "billing or revenue" wording |
| G3 | SQL and spreadsheet modelling (R5, must_have) | discovery | Usage frequency is stated, with no description of models built | The posting asks for "strong" modelling | A quota or commission model; scenario tabs; SQL joining CRM and payments tables | A workbook or query you can share in sanitised form | `[grounded]` your message |
| G4 | Owning billing data (R8, important) | capability | No billing-data work in your history, by your own account | The posting makes billing data part of the job's ownership | Not applicable. This is carried as a risk | Not applicable | `[grounded]` your message. Closure path: say plainly you would be learning it, and ask in the loop for a walkthrough of the billing system |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear beside an existing Head of RevOps | unknown | — | "run the quarterly revenue forecast with the CFO" | The forecast may be shared with, or still led by, the head of the function, so "run" may be narrower than it reads | `[inferred]` from her listed title against the posting's wording | Who owns the forecast today, and what part passes to this role in year one? | unresolved |
| RR2 | CRM and billing stack not named | unknown | — | "HubSpot or Salesforce administration" | The stack may be HubSpot, where your Salesforce certification carries over only in part | `[inferred]` from the posting's "or" against its silence on which is in use | Which CRM and which billing system hold the data this role would own? | unresolved |
| RR3 | Pay stated and inside the surveyed band | positive_signal | — | "£61,500–£67,000 plus share options" | The range is concrete and sits within the interquartile range for the title | `[grounded]` posting figure; `[generic]` survey band, snippet only | Where in the range would an offer for my background land? | noted |
| RR4 | Share option terms not given | unknown | — | "plus share options" | Value depends on grant size, vesting and strike price, none of which are stated | `[inferred]` from the posting's silence | What is the option grant, vesting schedule and strike price? | unresolved |
| RR5 | Role not seen on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield" (Tallyboard listing) | The role may be advertised only through the job board, or the careers address I tried was wrong. The posting is third-party listed, and the company itself checks out on its about page | `[grounded]` the address I tried returned no page; `[inferred]` the reasons | Can you point me at this role on your own careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Bristol attendance and your pay floor against the range before investing more | See R1, R2, RR3 | `[grounded]` posting | pending your approval |
| A2 | Lead with the pipeline and renewal dashboards you rebuilt and the monthly pipeline review you run with your sales director | See R9, R10 | `[grounded]` your own statements | pending your approval |
| A3 | Say plainly that finance owned the company forecast in your current role and that you have not worked on billing data | See R6, R8. Saying it first leaves nothing for them to uncover | `[grounded]` your own statements | pending your approval |
| A4 | Lead with your payments-sector operations experience when you speak to Tamsin; her listed earlier career is in sales operations at a payments company | See the hiring manager row | `[inferred]` from her profile snippet | pending your approval |
| Q1 | Ask the verification questions in RR1, RR2, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about); tried quillfield.co.uk/careers, which returned no page. Moved the organization row and RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), a snippet only. Moved the scope read, RR1 and A4 |

The posting itself was read from the link you gave: "Revenue Operations Lead — Quillfield | Tallyboard Jobs".

If it's useful, I can save this as a `tuesday-dossier.md` so later steps build on it.

## Upgrade menu

- A certification record for your Salesforce admin credential would raise R4 to `high`.
- A sanitised pipeline or renewal dashboard screenshot would raise R9 to `high`.
- A sanitised pipeline-review pack would strengthen the R10 bridge and show what you present to your sales director.
- An answer to G1 settles how R6 and R10 are framed.
- An answer to G2 could move R7 from `adjacent` toward `direct`.
- A shareable workbook or query would test R5 (G3).
- Quillfield's answer on the forecast owner and the CRM and billing stack closes RR1 and RR2.
- A link to the role on Quillfield's own careers page closes RR5.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) runs on your word.
- If you decide to apply, resume-tailor can rework your CV against this posting.

**Questions**

R1, R2 — Does a Bristol office two days a week work for you, and is £61,500 the bottom of what you would accept?

G1 — Have you ever produced a forecast figure of your own, even for the UK team? What did you own, who used it, and how did it turn out?

G2 — Have you worked with finance on revenue or renewal numbers, for example reconciling or supplying them? What did you do, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.