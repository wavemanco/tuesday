I found something worth checking: Brindlemoor's careers page says the role is in the Leeds office four days a week, but your JD says fully remote. I'm fetching that page to confirm.
**Probably yes, but not until the working pattern is settled. The JD says fully remote, and Brindlemoor's own careers page says Leeds office four days a week (R1). Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important` — unclear: R8 (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R1 — the two sources disagree and your own constraint isn't known; R5b (`low`) — "maintained" isn't the same as "monitored"; R10 — a credible bridge, its limit named.

**Opportunity ledger.** The posting is live on the employer's own site and matches the JD's title, product and reporting line (RR3). Against that, the working pattern is contradicted (RR1) and the salary is withheld (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on one answer, your working-pattern need (G1). If Leeds four days works for you, or the post is confirmed remote, the status can move to `conditional_go`, with the salary check (RR2) and G2 and G3 as the remaining conditions. If you need remote and the post is Leeds-based, R1 becomes `hard_gate_fail` and the status `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the role is live on its careers page | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product. Reports to the Director of Pricing | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both sources, in conflict |
| Line management | The JD lists no line-management requirement and no direct reports | `[grounded]` JD silence |
| Scope read | A single-product analytics ownership role, advisory in form ("recommendations"), not a people-leadership post | `[inferred]` from the JD's verbs against its silence on a team |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900, from a 2026 survey result. The JD states no salary, so this is the band to expect, never Brindlemoor's offer, and your pay floor wasn't given | `[generic]` survey snippet; `[grounded]` JD silence |
| Hiring manager | Odile Varga, Director of Pricing: spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books ("Small Books, Loud Errors"); previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result snippet; the page itself was not fetched |
| Unknowns | Salary; contract basis; team size around the role; the actual working pattern | — |
| Contradictions | Working pattern, as above | `[grounded]` JD against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a location or working-pattern constraint, so there is nothing to grade. Fit is `unclear` because the JD and the careers page disagree | `[grounded]` JD and careers page | G1: say what pattern you need |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Your account: 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific, but self-reported with no artifact yet | `[grounded]` your background as stated | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily, by your account; no code sample inspected | `[grounded]` your background as stated | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific and plausible; expect a probe on the details | `[grounded]` your background as stated | a sanitized model-documentation extract would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM model as R4, built by you | `[grounded]` your background as stated | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which may include monitoring but doesn't establish it. Low, not none, because there is a concrete thread to pull | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year, run with the underwriting team | `[grounded]` your background as stated | a sanitized test readout would raise to high |
| R7 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The actuarial audience isn't evidenced; the requirement says "or" | `[grounded]` your background as stated | none |
| R8 | Turn results into recommendations for product (from the JD's "underwriting and product") | important | unclear | low | discovery | Underwriting-facing work is evidenced, and nothing in your account mentions a product team | `[grounded]` your account's silence on product; `[inferred]` requirement from the JD's responsibilities | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance, 5 years | `[grounded]` your background as stated | none |
| R10 | Pet-insurance domain knowledge (inferred from the product) | preferred | adjacent | medium | transferability | Personal-lines GLM rating and price testing carry over. The limit: you have no pet-specific rating work, and the JD doesn't require it. Pet pricing often turns on factors such as breed, age and claims inflation, which motor work doesn't touch | `[grounded]` your motor work; `[generic]` what pet pricing involves | the bridge is framed honestly as adjacent in E2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says remote and the careers page says Leeds four days a week; your constraint isn't stated | It is the one item that can turn this into `no_go` | Any fixed need, such as location, caring duties or a relocation you'd consider | The recruiter's or Odile's written confirmation of the pattern | `[grounded]` the two sources; `[inferred]` that it decides the status |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is the only wording; no monitoring work is described | Odile's published talk is on monitoring rating models, so this is the part of the role she has put her name to | Tracking actual-versus-expected on the young-driver model; drift or stability checks; triggering a refit; a dashboard others used | A monitoring report or dashboard screenshot, sanitized | `[grounded]` her talk's subject; `[generic]` that a hiring manager tends to probe the area they speak on |
| G3 | Recommendations to product (R8, important) | discovery | Underwriting-facing recommendations only | The role names product as a second audience | A price-test result taken to a product, commercial or distribution team; a pricing change you proposed that affected product design | A deck extract or meeting note, sanitized | `[grounded]` the JD's wording and your account's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between JD and careers page | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the post may have changed from remote to office-based | `[inferred]` from two sources in conflict | Is this post fully remote, or based in Leeds four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | The JD states no salary | The figure may sit anywhere in or around the market band, or Brindlemoor may not publish it | `[inferred]` from the JD's silence, set against the `[generic]` survey band | What base salary range is budgeted for this post? | unresolved |
| RR3 | Posting live on the employer's own site and consistent on title, product and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The role is real and its remit is clear | `[grounded]` careers page fetched | What does a good first year look like in this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: lead with the GLM rating model you built and maintained for the young-driver book, the 14 price tests you ran with the underwriting team last year, and the quarterly pricing review you present to the head of underwriting | R4, R5a, R6, R7 | `[grounded]` your own sentences | `resume_edits_pending_approval`; pending your approval |
| E2 | CV or cover note: state plainly that your rating work is motor insurance, and that you haven't worked on pet products | R10; honest adjacency, no pet claim | `[grounded]` R10 row | pending your approval |
| E3 | If G2 confirms monitoring work, give it its own bullet, since the hiring manager's published talk is on that subject | R5b, G2 | `[grounded]` search result on her talk; depends on your answer | pending your approval |
| A1 | Confirm the working pattern with the recruiter or Odile before investing in the application | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2 and RR3 questions verbatim in a first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your account is self-reported and every row stays at `medium` or below until you share an artifact.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the role is live and consistent on title and reporting line, and it moved R1 and RR1 by contradicting the working pattern |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It supplied the market calibration row and RR2's band; only the result snippet was read |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It moved the hiring-manager row, G2 and E3; only the snippet was read |

If you'd like a portable record of this assessment, I can emit it as `tuesday-dossier.md`.

**Upgrade menu**

- Your working-pattern need, and your pay floor → R1 settles, and RR2 can be checked against your floor.
- A sanitized model-documentation extract, a code or notebook sample, or a price-test readout → R3, R4 and R6 can rise from `medium` to `high`.
- A monitoring report or dashboard screenshot (G2) → R5b resolves and E3 can be drafted.
- A deck extract or note showing a result taken to a product team (G3) → R8 resolves.
- The recruiter's written answer on pattern and salary → RR1 and RR2 close.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — The JD says fully remote, but Brindlemoor's careers page says Leeds office four days a week. What working pattern do you need: would Leeds four days work for you, or is remote a must?

G2 — On the young-driver GLM model you maintained, what did you personally do to monitor it after launch (which checks, how often, who saw them), and did any of it ever lead to a refit?

G3 — Have you ever taken a price-test result to a product or commercial team rather than underwriting, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.