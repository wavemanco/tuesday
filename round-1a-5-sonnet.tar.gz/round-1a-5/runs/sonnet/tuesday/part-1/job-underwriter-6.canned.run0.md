Research is done: four searches and two page reads, plus the posting itself. Here's the full assessment.

## Decision snapshot

**Yes, go for it, Joss, as a stretch application. R3, R4 and R5 land `direct`, and R6a and R7a, the forecast and billing-data requirements you flagged, are gaps you'd apply with. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol office, two days a week), R2 (Pay £61,500–£67,000)
- `must_have`: direct: R3, R4, R5 · adjacent: R6b (Forecast-supporting pipeline work) · unclear: R7b (Working with finance on revenue data) · absent: R6a (Owning a forecast), R7a (Billing data)
- `important`: direct: R8

R6a, R7a: your own stated gaps; R6b: a credible bridge, its limit named; R7b: open until you say whether finance touched your numbers; R1, R2: waiting on your location and pay floor.

**Opportunity ledger.** The employer checks out against its own site (RR6) and the stated pay sits inside the market band (RR5). The posting is thin on team, authority and who owns what in the forecast (RR2, RR3). The share-option terms (RR4) and the role's presence on Quillfield's own careers page (RR1) are unconfirmed.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol office, two days a week), R2 (Pay £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 and R2 are terms you can accept (G1).
  2. The forecast split in RR3 turns out to be "run with the CFO" in a way R6b can grow into, rather than owning the number alone from the first quarter (R6a).
  3. The first conversation shows the billing-data ramp is workable (R7a, RR2).
  - It moves to `no_go` if R1 or R2 fails for you.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 employees; £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about, fetched |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; earlier, sales operations manager at a payments company for four years. The profile matches the recruiter's naming | `[grounded]` profile page, fetched |
| First-year outcomes | None stated. The first quarterly forecast cycle with the CFO is the nearest milestone the duties imply | `[inferred]` from the posting's duties |
| Scope read | A function head already exists, so the post probably sits inside an existing RevOps team rather than founding one. Team size, reports and decision rights are not stated (RR2) | `[inferred]` from the hiring manager's title |
| Market calibration | £61.5–67k sits inside the guide's £57.8–70.4k range, near its £64,200 median. The band is UK-wide, not Bristol-specific, and is never this employer's offer. The sweep returned pay only, so scope norms are not established | `[generic]` Ledgerline 2026 pay guide, n=438, via search snippet; `[grounded]` posting figure |
| Unknowns | Team and reports; forecast split with the CFO; who owns the billing system; option terms; whether the post is new or a backfill | `[grounded]` posting silence |
| Contradictions | None between the posting and Quillfield's about page. The posting did not surface on Quillfield's own careers page (RR1) | `[grounded]` about page; careers search empty |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol office, hybrid, two days a week | hard_gate | unclear | none | hard_gate | The posting states the term. Your location and any limit on office days weren't given, so it is neither met nor failed. There is no stated constraint to grade yet | `[grounded]` posting term; your side silent | G1 question |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the pay. Your floor wasn't given, so it can't be checked | `[grounded]` posting figure; your side silent | G1 question |
| R3 | 4+ years in revenue ops, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales ops, the last 2 running revenue operations for the UK team, is specific and plausible but typed, not inspected. Whether a B2B payments company reads as "B2B software" is the one clause the posting leaves open | `[grounded]` your account; `[inferred]` on the sector clause | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified is a specific claim, but no certificate record was inspected. Running RevOps for the UK team supports the "own our CRM" duty, with the size of that instance unstated | `[grounded]` your account | certification record would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly and Excel daily is stated usage. Depth ("strong") and modelling are not stated, so expect a probe on modelling | `[grounded]` your account; `[generic]` that interviews for this role probe modelling depth | a sanitized query or model would raise to `high` |
| R6a | Experience owning a forecast | must_have | absent | none | capability | You say finance owned the company forecast, so no ownership claim exists. After your own direct statement, this is a capability gap, not a discovery one | `[grounded]` your statement | closure path G4; carried as material risk |
| R6b | Forecast-supporting pipeline work (requirement inferred from the posting's duty to "run the quarterly revenue forecast with the CFO") | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards. Limit: nothing shows how those figures fed finance's forecast, or what part was yours | `[grounded]` your account; `[inferred]` that this bridges toward forecasting | G2 question |
| R7a | Billing data, which the role owns ("own our CRM and billing data") | must_have | absent | none | capability | You haven't worked on billing data. The posting makes it a duty, not just a preference | `[grounded]` your statement and the posting | closure path G5; carried as material risk |
| R7b | Working with finance on revenue data (the posting says "billing or revenue") | must_have | unclear | low | discovery | Your renewal dashboards are revenue-facing, but nothing says finance used or checked them. If that exists, this row can be met on the posting's own "or" | `[grounded]` your renewal dashboards; finance involvement unstated | G3 question |
| R8 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Limit: whether finance ran on them is the same open point as R7b | `[grounded]` your account | settled alongside G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Office pattern and pay floor (R1, R2, hard_gate) | hard_gate | The posting states both terms. Your location and floor aren't given | A failed gate decides the outcome whatever the fit elsewhere | Not applicable: only whether the terms are met matters | None needed | `[grounded]` posting terms |
| G2 | Forecast-supporting work (R6b, must_have) | transferability | A monthly pipeline review you run and rebuilt dashboards. Not shown: which figures fed finance's forecast, or what you owned | R6a is absent, so this is the bridge that narrows the objection a forecast-owning role is most likely to raise | A coverage or conversion view the sales director or finance used to judge a quarter; a commit or best-case roll-up you prepared; a note explaining why a quarter landed away from the earlier call | A sanitized pipeline-review pack or a forecast-versus-actual note | `[grounded]` your account; `[generic]` that forecast ownership is the likeliest objection |
| G3 | Finance and revenue data (R7b, must_have) | discovery | Renewal dashboards exist. Finance's involvement is not stated | The posting's "billing or revenue" may let R7b close the finance requirement even with R7a open | Reconciling dashboard totals to finance's figures; agreeing metric definitions such as renewal date or ARR with finance; extracts you supplied for finance's month-end or board packs | A definitions note, a reconciliation sheet, or a sanitized email thread | `[grounded]` your dashboards; `[inferred]` that this could close R7b |
| G4 | Owning a forecast (R6a, must_have) | capability | No ownership, by your own account | It is the posting's headline duty | Closure path: get the forecast-split answer (RR3) before investing in the loop, and show G2's bridge honestly rather than as ownership | A scoped first-quarter plan, if the split allows | `[grounded]` your statement |
| G5 | Billing data (R7a, must_have) | capability | None, by your own account | The role owns billing data | Closure path: ask who owns the billing system today (RR2) and how much ramp is expected | Not applicable | `[grounded]` your statement and the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed only on the job board, or the one careers search missed it | `[inferred]` from an empty careers search | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Team, authority and outcomes not stated | unknown | — | "You will own our CRM and billing data" | The role may be a one-person function carrying systems, reporting and forecast | `[inferred]` from the posting's silence on team and decision rights | Who is on the team around this role, and who owns the billing system today? | unresolved |
| RR3 | Forecast split with the CFO not stated | unknown | — | "run the quarterly revenue forecast with the CFO" | "With the CFO" may mean preparing inputs for the CFO's number or co-owning it | `[inferred]` from the wording | In the quarterly forecast, which parts does this role own and which does the CFO own? | unresolved |
| RR4 | Share-option terms not stated | unknown | — | "plus share options" | Grant size, vesting and strike may be undefined | `[grounded]` posting silence | What is the option grant, and how does it vest? | unresolved |
| RR5 | Pay stated and inside the market band | positive_signal | — | "£61,500–£67,000" | Compensation is transparent and in line with the band | `[grounded]` posting figure; `[generic]` band | Is the range fixed for this level? | noted |
| RR6 | Employer exists as described and is funded | positive_signal | — | "Founded 2018 in Bristol; 96 employees. Series A (£11M) closed in April 2025" | The employer is a real, funded company | `[grounded]` about page, fetched | Is this a new post funded from the Series A, or a backfill? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the office pattern and your pay floor before investing in the loop | R1, R2 | `[grounded]` posting terms | pending your approval |
| A2 | Ask RR1, RR2, RR3 and RR4 verbatim in the recruiter and hiring-manager conversations | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Positioning draft for when forecast or billing comes up: "I run the monthly pipeline review with our sales director, and I rebuilt our pipeline and renewal dashboards. Finance owned our company forecast, and I haven't worked on billing data." | R6b, R6a, R7a: each clause is your own sentence, and none claims forecast ownership | `[grounded]` your account | pending your approval |
| P2 | Lead with your payments sales-ops background. It is the verified story closest to the hiring manager's listed history | R3, role reality | `[grounded]` profile page and your account | pending your approval |
| W1 | A one-page sanitized view of how your pipeline-review figures could roll up toward a forecast, using only your own real work | G2, R6b | `[grounded]` your account | pending your approval |

## Evidence status

Verified: none yet. Your background came in as typed text, which counts as CV-equivalent self-report, so rows top out at `medium` until something inspectable arrives. I've taken your stage as evaluating, since a recruiter has been in touch.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" and "Quillfield careers Revenue Operations Lead Bristol", and fetched "About Quillfield" (quillfield.co.uk/about). It moved role reality's organization and contradictions rows and RR6. The careers search returned nothing, so RR1 stays open |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide), read from the search snippet with the page not opened. It moved the market calibration row and RR5, and raised no pay-mismatch entry |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and fetched "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). It moved role reality's hiring-manager and scope rows and P2 |

If you'd like a saved record of this assessment to carry forward, I can emit it as `tuesday-dossier.md` whenever you say.

## Upgrade menu

- Your CV, attached or pasted: rows would then rest on the document rather than your typed summary, and any presentation gaps would show up.
- A Salesforce certification record or Trailhead link: R4 to `high`.
- A sanitized SQL query or Excel model: R5 to `high`.
- A sanitized pipeline-review pack or dashboard screenshot: R8 and R6b firm up.
- Your office-days limit and pay floor: R1 and R2 resolve and the hard-gates line closes.
- Quillfield's answers on RR2 and RR3: they settle conditions 2 and 3 and may move the decision to `go` or `no_go`.
- A deeper research pass on Quillfield (funding and leadership churn, hiring patterns, public candidate and employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

G1 (R1, R2): Do the Bristol office pattern, two days a week, and the £61,500–£67,000 range work for you?

G2 (R6b): Did the numbers from your pipeline review feed the forecast finance built, and if so, which figures did you produce or adjust, and what did you personally own?

G3 (R7b): Did finance ever use, check or reconcile your pipeline or renewal figures, and what did you do with them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.