Web search wasn't permitted in this session, so this runs on your JD and background alone.

## Decision snapshot

**Yes, worth applying to. Your direct evidence covers R2, R3, R4, R5, R6, R7 and R8a. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Based in the UK, fully remote)
- `must_have` — direct: R2, R3, R4, R5, R6, R7, R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9

R8b — product-side recommendations, nothing confirmed yet; R1 — UK base inferred from a UK employer, not stated.

**Opportunity ledger.** The role's scope is concrete (RR4). The employer is unchecked (RR2), the pay is unstated (RR1) and the team around the post is unknown (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Based in the UK, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Brindlemoor's own careers page and the company matches the description, RR2; (2) a UK base is confirmed, R1; (3) the pay meets your floor, RR1; (4) the motor-to-pet bridge is stated as adjacent, never as pet expertise, R8b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header as you pasted it |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Pet-insurance knowledge | The JD asks for "insurance experience a plus" and does not ask for pet experience | `[grounded]` JD wording |
| Pet versus motor | Pet rating tends to run on different factors from driver rating, such as breed, age and condition. Expect questions on how your GLM work would carry over | `[generic]` role-family pattern, not a claim about this employer |
| People management | The JD lists no line-management requirement, so having never managed anyone is not a mismatch with its text. Whether the post has reports is not stated | `[grounded]` JD silence; `[inferred]` that this makes the gap low-risk |
| Market calibration | Not run, because search was unavailable. No salary band is offered | `[grounded]` search calls refused |
| Unknowns | Salary; team size and reporting line; how product teams use the output; employer status | `[grounded]` JD as pasted |
| Contradictions | None visible within the JD. No second source was read | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the UK, fully remote | hard_gate | unclear | low | hard_gate | You have not stated where you live or your right to work. A UK motor insurer suggests it, but that does not establish it | `[grounded]` your background; `[inferred]` UK base from a UK employer | Question Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years at a UK motor insurer, 2 as senior analyst. Confirmed and specific, but nothing inspectable yet | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. A stated claim, with no artifact inspected | `[grounded]` your stated background | offer: a code sample or repo would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your stated background | offer: a sanitized model-spec document would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting is covered. No actuarial audience was stated | `[grounded]` your stated background | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Build and maintain are both in your stated history. Monitoring is covered only if "maintained" included it | `[grounded]` your stated background; `[inferred]` monitoring from "maintained" | confirm that monitoring was part of the maintenance |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team | `[grounded]` your stated background | offer: one sanitized test write-up would raise to high |
| R8a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You work with underwriting on the tests and present the quarterly review to its head | `[grounded]` your stated background | none |
| R8b | Turn results into recommendations for product | must_have | unclear | low | discovery | Nothing in what you gave touches a product function. Underwriting evidence does not stand in for it | `[grounded]` silence in your background | G1 and Q2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance is insurance. This is direct on the JD's wording. The pet product is a separate matter, covered in role reality | `[grounded]` your stated background and JD wording | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R8b, must_have) | discovery | Your tests and reviews go to underwriting. Nothing says who else used them | It is the one must-have row below `direct`, so settling it firms up the decision | A test result that changed a pricing or product decision beyond underwriting; a pricing change you took through a product, distribution or marketing owner; a pricing or loss-ratio read-out for a product lead | A review deck, a sign-off email, or a test summary | `[grounded]` silence in your background; `[inferred]` that this is the likeliest probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary not stated | unknown | — | (the posting as pasted gives no figure) | The figure may be unpublished, or the post may be priced below your level | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Team and support around the "own" mandate unknown | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be the only pricing analyst on the product, with limited data and engineering support | `[inferred]` from "own" set against silence on team size | How big is the pricing team, and who does this role report to and work with? | unresolved |
| RR4 | Responsibilities named concretely | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The day-to-day work is defined and maps to your history | `[grounded]` JD | What does success look like in the first twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Brindlemoor's own careers page before spending effort | see RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Lead with three of your own statements: the GLM rating model you built and maintained for the young-driver book, the 14 price tests you ran last year with the underwriting team, and the quarterly pricing review you present to the head of underwriting | see R4, R7, R5 | `[grounded]` your stated background | pending your approval |
| A3 | State plainly that your pricing work is in motor insurance and that you haven't worked on pet insurance | see R9 and the pet-versus-motor row | `[grounded]` your statement | pending your approval |
| A4 | If people management comes up, say you haven't managed anyone. It needn't be raised unprompted, since the JD does not ask for it | see the People management row | `[grounded]` your statement and JD silence | pending your approval |
| A5 | Ask RR1, RR3 and RR4's questions of Odile Varga verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: Brindlemoor's company presence and its careers listing for this role. It would have moved the employer row and RR2 |
| 2. Role-family sweep | unavailable | One search was refused, on UK senior pricing analyst pay and remit. It would have moved the market-calibration row and RR1 |
| 3. Hiring manager's public footprint | unavailable | One search was refused, on Odile Varga's public professional background. It would have moved the scope read and which story the plan leads with |

## Upgrade menu

- Allowing web search lets me rerun targets 1 to 3, which would clear or confirm RR2 and give a pay band for RR1.
- Your CV, a sanitized model-spec note or a test write-up would take R4, R7 and R3 from `medium` toward `high`.
- An answer on G1 would settle R8b.
- Your location and right to work would settle R1.
- Your pay floor and any other non-negotiables would let me check them against the role.

If you'd like this carried forward, say so and I'll write it as a `tuesday-dossier.md`.

**Questions**

- **R1:** Are you based in the UK with the right to work there?
- **G1:** Have you taken a price-test result or pricing change to someone in a product role, or only to underwriting? What was yours and what happened?
- **Constraints:** What is your pay floor, and is anything else non-negotiable?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.