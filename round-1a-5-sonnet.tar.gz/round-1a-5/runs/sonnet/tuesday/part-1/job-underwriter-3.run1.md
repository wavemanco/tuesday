Web search wasn't permitted, so this runs only on your posting and your own words.

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 (Base pay of $70–85k against your $150k floor)
- `must_have`: direct: R3, R4a
- `important`: unclear: R4b (SEO/content), R4c (Brand, PR, partnerships, sales ops), R5 (Team-of-one operation)

R3, R4a: your experience matches the core ask; R4b, R4c, R5: not yet evidenced, and they don't change the call; R1, R2: the rows that decide it.

**Opportunity ledger.** Your sense that something is off has specific sources:
- The posting's terms conflict with your two constraints (RR1, RR2).
- It bundles seven functions into a team of one, with no stated budget or success measure (RR3, RR4).
- It expects after-hours work as a norm (RR5).
- The pay sits oddly against an 8+ year mandate (RR6).
- The employer is unverified (RR7).
- One entry runs the other way: the pay and location are stated plainly, so the mismatch shows at once (RR8).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 (Base pay of $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** only the employer changing its terms, with R1 becoming remote-eligible and R2's base reaching your $150k floor. The posting says "no exceptions" on R1, so no wording on your side moves it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup, Series A, "profitable since day one"; not verified | `[grounded]` JD header; existence and claims unchecked, see RR7 |
| Mandate | Own revenue growth end to end across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Team | "A team of one to start" | `[grounded]` JD |
| Working pattern | Austin office 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside"; equity terms not stated | `[grounded]` JD |
| Scope read | A head-of title whose scope is seven functions with no team, budget or success measure | `[inferred]` from the function list against the JD's silence on budget and metrics |
| Market calibration | Unavailable: no search ran, so no market band for this title and pay | `[generic]` no sweep; see Evidence status |
| Unknowns | Budget, decision rights, success metrics, equity terms, hiring plan after "to start" | `[grounded]` JD silence |
| Contradictions | None between the materials you gave me; the posting wasn't checked against Novaline's own careers page | `[grounded]` inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "On-site in our Austin office 5 days a week — no exceptions" (your constraint: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the constraint, which is specific and your own. The fit fails because the posting rules out remote work in terms. | `[grounded]` JD quote and your stated constraint | Surface in the snapshot; only the employer changing terms resolves it |
| R2 | "$70–85k base" (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the posted band is $65k under it, and equity doesn't count toward a base floor. | `[grounded]` JD figure and your stated constraint | Surface in the snapshot; only the employer changing terms resolves it |
| R3 | "8+ years growth leadership" | must_have | direct | medium | none | You state 9 years, as growth lead then Head of Growth at two B2C subscription companies. Specific and plausible, with no inspectable artifact yet, so `medium`; expect a probe. | `[grounded]` your background as stated | none |
| R4a | Own paid acquisition and lifecycle/CRM growth | must_have | direct | medium | none | You state owning paid, lifecycle and experimentation, and scaling one company from $8M to $40M ARR over three years with a budget you controlled. Confirmed and specific, with no artifact inspected. | `[grounded]` your background as stated | An ARR or channel-performance summary would raise it to `high` |
| R4b | SEO/content growth | important | unclear | none | discovery | Nothing in what you've described covers it. Not carried as capability yet because nothing has been asked. | `[grounded]` silence in your background | See G1 |
| R4c | Brand, PR, partnerships and sales ops | important | unclear | none | discovery | Nothing described covers these. Seven functions in one title is itself a scope signal (RR3). | `[grounded]` silence in your background | See G2 |
| R5 | Run growth alone ("a team of one to start") | important | unclear | low | discovery | You built and managed teams of 3–7, which is the opposite shape; solo execution isn't described. Low because it's an absence, not a contradiction. | `[grounded]` your team sizes as stated | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R4b, important) | discovery | No SEO or content ownership stated | Wouldn't change the decision while R1 and R2 stand | Owning an organic channel, a content calendar or a search-traffic target | A channel report or traffic dashboard | `[grounded]` silence; `[inferred]` that it can't move the decision |
| G2 | Brand, PR, partnerships, sales ops (R4c, important) | discovery | None stated | Same: resolving it can't override the failed gates | Partner launches, press-driven campaigns, CRM-to-sales handoffs | A partner brief or launch recap | `[grounded]` silence; `[inferred]` that it can't move the decision |
| G3 | Solo operation (R5, important) | discovery | Teams of 3–7, no solo stretch described | Shows how the role would feel in practice, not whether to pursue it | A period of hands-on execution with no reports | A before/after of a channel you ran yourself | `[grounded]` your team sizes as stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site requirement conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role can't be done from Portland on these terms | `[grounded]` JD against your stated constraint | Is the five-day Austin on-site requirement fixed for this role, as the posting says? | confirmed |
| RR2 | Pay band sits below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base can't reach $150k within the posted band | `[grounded]` JD figure against your stated floor | Is $70–85k the full base budget for this role? | confirmed |
| RR3 | Several specializations bundled into one title, with no team | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… team of one to start" | Several full roles folded into one position at junior-level pay | `[inferred]` from the function list against the team-of-one line | Which of these functions does the role own on day one, and when does the team get built? | unresolved |
| RR4 | Accountability without stated resources or success measures | risk_signal | medium | "Own all revenue growth end to end… success metrics will evolve as we learn" | The role may carry revenue accountability without budget, decision rights or a defined target | `[inferred]` from the JD's silence on budget and metrics | What budget and decision rights come with this role, and what counts as success at 12 months? | unresolved |
| RR5 | After-hours expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be the norm rather than the exception | `[generic]` pattern for phrasing of this kind | How often did evening and weekend work happen in the last quarter? | unresolved |
| RR6 | Seniority and pay mismatch | risk_signal | medium | "8+ years growth leadership required… $70–85k base" | The figure may sit below what a head-level, 8+ year mandate usually pays | `[generic]` pattern; no market band was checked, so no figure is claimed | What level is this role benchmarked at internally? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who the hire would report to day to day? | unresolved |
| RR8 | Pay and location stated up front | positive_signal | — | "Compensation: $70–85k base… On-site in our Austin office 5 days a week" | The terms are transparent, so the mismatch is visible before you spend effort | `[grounded]` JD states both | What does the equity grant look like, and over what vesting schedule? | noted |

I'm going only on what you've shared, and I can get this wrong. RR7 in particular is unchecked, because search wasn't available.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | R1 and R2 fail on its own stated terms | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Screen future postings for remote eligibility and a base at or above your floor before reading further | Both of your constraints can be read from a posting's terms | `[grounded]` your stated constraints | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the call was refused. It would have moved role reality's organization row and RR7 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base salary range"; the call was refused. It would have moved role reality's market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

I can save this as `tuesday-dossier.md` if you'd like to keep or reuse it.

## Upgrade menu

- Permission for web search, or a link to Novaline's careers page: RR7 closes, and role reality's organization and market calibration rows fill in.
- The employer's answer on budget, decision rights and success measures: RR3 and RR4 move.
- A channel-performance summary of your $8M to $40M scale-up: R4a goes to `high`.
- The hiring manager's name: role reality's scope read sharpens.

## Questions

None this turn. The decision rests on terms you've already stated, and no answer I could ask for would change it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.