Web search wasn't permitted, so this uses only your JD and background, with no outside research.

## Decision snapshot

**Yes, apply, on conditions. You match the core requirements: R1, R2, R3, R4 and R5 are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — adjacent: R7 (Partner with product managers on roadmap decisions) · unclear: R8 (Partner with clinicians), R9 (Mentor two junior analysts)
- `preferred` — adjacent: R10 (Healthcare data experience, HIPAA)

R10 — a credible bridge, its limit named; R6 — adjacent, awaiting a metric-definition example; R8, R9 — nothing in your background yet.

**Opportunity ledger.** The employer could not be established from here (RR1). Pay, work arrangement and success measures are not stated (RR2, RR3, RR5). One entry runs the other way: the duties are concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify as live and real, see RR1; (2) pay and work arrangement meet your terms, see RR2 and RR3; (3) you can show a metrics-layer example and mentoring experience, see R6 and R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not independently verified |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, Looker self-serve dashboards, roadmap partnership with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor role with light mentoring. It reads as a build-and-maintain role rather than a pure reporting one. | `[inferred]` from the duties list, which names ownership of the metrics layer and no direct reports |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not calibrated: the role-family sweep did not run, so no pay or scope band is given | — |
| Unknowns | Pay, location or remote terms, reporting line, whether a metrics layer already exists, the size of the Looker estate, what the clinician partnership involves | `[grounded]` JD silent on each |
| Contradictions | None visible inside the JD; the careers page was not checked | `[grounded]` JD text only |

## Evidence map

Your background is typed prose, which counts as self-report like a CV. That caps confidence at `medium` on a first pass, until you attach something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics. That is specific, but nothing inspectable has been attached yet. | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse. "Expert" is the JD's word; you state daily use, and a query sample or a probe in interview would test it. | `[grounded]` your background | offer: a sanitized query or model would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD does not define "at scale", so the match on volume is read, not measured. | `[grounded]` your background | offer: a sanitized test brief or readout would raise to high |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. | `[grounded]` your background | offer: a dashboard screenshot or an architecture note would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. | `[grounded]` your background | offer: a sanitized memo would raise to high |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | Governed dashboards and a monthly metrics memo are credible adjacent work. Nothing you've said covers owning shared metric definitions or a semantic layer, so that limit stays open. | `[grounded]` your background; `[inferred]` that governed dashboards imply some metric-definition work, which is unconfirmed | see G1 |
| R7 | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | The pricing test led to a result and you present monthly to the VP Product. You have not described working with product managers on the roadmap. | `[grounded]` your background | none this turn; see upgrade menu |
| R8 | Partner with clinicians | important | unclear | none | discovery | Nothing in your background touches clinician or domain-expert partnership. | `[grounded]` background silent | see G3 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Your background is silent on mentoring or reviewing others' work. | `[grounded]` background silent | see G2 |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You have handled GDPR and CCPA consumer PII and built the warehouse's consent-state model. You have not handled health data or worked under HIPAA. | `[grounded]` your background | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed dashboards and a metrics memo, but nothing about owning shared metric definitions | The first duty in the JD, and a `must_have` row at `adjacent`; an example could move it to `direct` | Writing LookML or dbt metric definitions; agreeing a single definition of retention or churn across teams; retiring conflicting metrics | LookML excerpt, a metric dictionary, a definitions doc | `[grounded]` background silent on definitions; `[inferred]` that this is the duty an interviewer will probe first |
| G2 | Mentoring (R9, important) | discovery | No mention of mentoring or reviewing others' work | The JD names two junior analysts, so it will come up | Reviewing analysts' queries or readouts; onboarding a new analyst; running an analytics office hour | A mentoring plan or onboarding doc, or simply who you helped and how | `[grounded]` background silent |
| G3 | Clinician partnership (R8, important) | discovery | Nothing touching clinicians or other domain experts | The role pairs analysis with clinicians; how you work with non-analyst experts is the closest bridge | Working with culinary, nutrition or operations specialists on a metric or test; translating domain constraints into test design | An example of a test shaped by domain-expert input | `[grounded]` background silent; `[generic]` that domain-expert partnership is a standard interview theme for this kind of role |
| G4 | Healthcare data (R10, preferred) | transferability | Consumer PII and consent-state work; no health data | Preferred only, so a minor risk; the bridge must name its limit | The consent-state model, access controls, data-retention rules, privacy reviews you took part in | A sanitized data-handling or consent design doc | `[grounded]` background; `[inferred]` that consent modelling is the closest transferable work |

Only G1 and G2 are asked as questions this turn, to keep within the three-question limit.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and level not stated | unknown | — | "Senior Product Analyst — Harborlight Health", with no figure given | The figure may sit below what the title usually pays, or the company may simply not publish it. | `[inferred]` from the posting's silence | What salary band is budgeted for this post? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | The JD ends "healthcare data experience (HIPAA) a plus" with no location or hours terms | The role could be onsite, hybrid or remote, which matters against constraints you haven't given me. | `[inferred]` from the posting's silence | Is this role remote, hybrid or onsite, and where is the team based? | unresolved |
| RR4 | Duties are concrete and bounded | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The scope is specific enough to judge. | `[grounded]` JD | Does a metrics layer exist today, or is this one to build? | noted |
| RR5 | No success measures stated | unknown | — | "turn analysis into roadmap decisions" with no first-year outcomes | The role may be accountable for outcomes with no definition of success. | `[inferred]` from the JD's silence on outcomes | What would success look like at six and twelve months? | unresolved |

RR1 caps the decision at `conditional_go` until the posting verifies. Small or new companies often have a thin footprint, and that alone is not a finding about this one.

## Application plan

These are proposals, each `pending your approval`. Every clause traces to your own sentences, and none claims healthcare or HIPAA experience.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the experimentation program: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | see R3 | `[grounded]` your background, restated without added scope | `resume_edits_pending_approval` |
| E2 | Next, the BI build: "Built the company's Looker instance from scratch: 40+ governed dashboards" | see R4 | `[grounded]` your background | `resume_edits_pending_approval` |
| E3 | Frame the privacy bridge as it is: "Handled GDPR/CCPA consumer PII; built the consent-state model for our warehouse." Say plainly you have not worked with health data. | see R10 | `[grounded]` your background | `resume_edits_pending_approval` |
| A1 | Confirm the posting is live on Harborlight's own careers site before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the questions in RR2, RR3, RR4 and RR5 verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app careers" was refused (no search permission). It would have fed role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | The search on senior product analyst pay and scope in digital health was refused. It would have fed the market calibration row and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Upgrade menu

- A link to the live posting or Harborlight's careers page → RR1 and the role reality rows can be checked against it.
- Allowing search → the market calibration row and RR1 can be filled, and the role-family band set against RR2.
- Your constraints (pay floor, location, authorization, schedule) → the hard-gates line becomes a real check, and RR2 and RR3 can be judged against your terms.
- A sanitized query, test brief, dashboard screenshot or metrics memo → R2, R3, R4 or R5 moves from `medium` toward `high`.
- An answer to G1 or G2 → R6 or R9 can move.

I can emit this as `tuesday-dossier.md` if you'd like to keep it.

C — What are your non-negotiables for a move, such as pay floor, location or remote, work authorization and schedule?
G1 — Have you personally defined or owned shared metric definitions, such as one agreed definition of retention across teams, in LookML or elsewhere? What did you own, and who adopted it?
G2 — Have you mentored or reviewed other analysts' work? If so, who, how, and what changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.