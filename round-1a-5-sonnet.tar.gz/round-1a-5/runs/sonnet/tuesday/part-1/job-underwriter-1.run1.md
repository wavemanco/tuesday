Web search was refused in this session, so I'm assessing from the posting and your background alone.

## Decision snapshot

**Yes, apply. You're a fit on the core of the role: R1, R2, R3, R4 and R5, which are every `must_have` row, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R7a · unclear: R6 (metrics layer), R7b (clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA/regulated-data handling) · absent: R9a (Healthcare data experience)

R6 — likely but unstated; R8 — no trace in what you gave; R9a — preferred, the domain gap named.

**Opportunity ledger.** The role is clearly scoped, with a defined stack and a team to mentor (RR4). The employer could not be checked here (RR1), and pay, location and success measures are all unstated (RR2, RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify on Harborlight's own careers page, see RR1; (2) your pay floor, location and authorization needs are checked against terms the posting doesn't state, see RR2; (3) HIPAA is framed as a limit and never as experience, see R9a and R9b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header, not checked against any outside source |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A senior individual-contributor post with light team-lead duties (two mentees) | `[inferred]` from the mentoring line against the absence of any reports or budget language |
| Market calibration | Not run, because both searches were refused, so there is no pay band to set against the posting | `[grounded]` search refused |
| Unknowns | Pay, location and remote terms; success measures; who the clinicians are and how often analysts work with them | `[grounded]` JD silent |
| Contradictions | None visible within the JD | `[grounded]` JD read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a ~2M-subscriber consumer company, self-reported with no document inspected yet | `[grounded]` your background, stated | none |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on Snowflake. "Expert" is a level you haven't evidenced beyond daily use | `[grounded]` your background, stated | Optional: a sanitized query or model you wrote lifts this to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year that you designed and ran, including the pricing test behind an 11% retention lift. Roles asking for "at scale" usually probe traffic volume, power and guardrail metrics, so expect those questions | `[grounded]` your background; `[generic]` what such roles probe | Optional: a sanitized experiment readout lifts this to `high` |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. This matches the JD's named tool | `[grounded]` your background | Optional: a dashboard screenshot or LookML excerpt lifts this to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. Clinicians are a different audience, covered in R7b | `[grounded]` your background | Optional: a sanitized memo lifts this to `high` |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | Governed dashboards suggest metric definitions existed, but who defined them and whether a shared definitions layer existed isn't stated | `[grounded]` your background silent on ownership; `[inferred]` that governed dashboards imply some shared definitions | Question G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product and a pricing test that produced a result. Day-to-day PM partnership isn't described, so the claim stays at `medium` | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | low | discovery | No evidence either way of working with domain experts outside product and analytics | `[grounded]` your background silent | Queued as G2, not asked this turn |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing | `[grounded]` your background silent | Question G3 |
| R9a | Healthcare data experience (a plus) | preferred | absent | none | capability | No healthcare work in your background, as you said yourself | `[grounded]` your statement | Closure path in G4 |
| R9b | HIPAA / regulated-data handling (a plus) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and a consent-state model you built for the warehouse. Neither is HIPAA, and the limit is named in G5 | `[grounded]` your background; `[inferred]` adjacency | G5 bridge |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed Looker dashboards, but not who defined the metrics or whether a shared layer sat underneath them | The JD lists this first among the responsibilities, and a clear answer lets R6 become `direct` | Writing the agreed definition of retention or an active subscriber that several teams used; Looker measures and explores others built on; reconciling two dashboards that disagreed; keeping a metric dictionary or change log | A sanitized metric dictionary, a LookML excerpt, a definitions doc | `[grounded]` background silent on ownership; `[inferred]` that this is a prime interview topic given the JD's ordering |
| G2 | Clinician partnership (R7b, important) | discovery | Partnership shown with the VP Product only | The JD names clinicians as a stakeholder group, and the evidence doesn't address them | Defining a metric with an operations or supply team; reading a test result with a domain expert who owned the outcome; changing an analysis after a specialist corrected your assumptions | A project brief or readout naming the domain partner | `[grounded]` background silent |
| G3 | Mentoring (R8, important) | discovery | No mention of mentoring | The role includes two juniors, and silence reads as none | Onboarding an analyst; reviewing others' SQL or dashboards; running a team standard or office hours, formal or not | A review checklist or onboarding doc you wrote | `[grounded]` background silent |
| G4 | Healthcare data (R9a, preferred) | capability | No credible direct or adjacent healthcare evidence | Preferred only, so a minor risk rather than a blocker | Closure path: a short HIPAA fundamentals course, mentioned only once actually done; or position it as a stated learning plan | A course completion record, once it exists | `[grounded]` your statement |
| G5 | HIPAA-adjacent handling (R9b, preferred) | transferability | GDPR/CCPA PII handling and the consent-state model, which carry over in kind | A truthful bridge is worth stating | Adjacent evidence: consent tracking and access to personal data. Limit: you haven't exercised health-data rules such as de-identification or vendor agreements for health data. Strengthener: a one-page description of the consent-state model and access controls | A sanitized design note | `[grounded]` your background; `[generic]` which HIPAA concepts the work did not touch |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, it may not represent a real hiring employer, or nothing may be wrong and no check could run in this session | `[generic]` pattern, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and work arrangement unstated | unknown | — | "(none: the pasted posting gives no salary, location or remote terms)" | Terms may not meet your floor or location needs, and no hard-gate check against them is possible yet | `[grounded]` JD silent; `[inferred]` that the gap matters because your constraints weren't given | What is the salary range, and where is this role based or is it remote? | unresolved |
| RR3 | Success measures not stated | unknown | — | "Own product analytics for our care-navigation app" | Ownership is broad and no outcome is named | `[inferred]` from the scope language against the JD's silence on outcomes | What would success look like at 90 days and at one year? | unresolved |
| RR4 | Scope, tooling and team are concrete | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The role has a defined stack and a team, and the stack matches your tooling | `[grounded]` JD states both | Who do the two junior analysts report to today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role is live on Harborlight's own careers page before you invest time | see RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the experimentation program (30+ tests a year, including the pricing test behind the 11% retention lift) and the Looker build (40+ governed dashboards) | see R3, R4 | `[grounded]` your sentences | pending your approval |
| P2 | Describe the consent-state model as GDPR/CCPA-adjacent work and never as HIPAA or healthcare experience | see R9a, R9b | `[grounded]` your background | pending your approval |
| P3 | Ask the register's questions RR2 and RR3 verbatim early | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Prepare a sanitized monthly metrics memo as a work sample | see R5 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused. It would have fed RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range"; the call was refused. It would have fed role reality's market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

I'd be glad to emit this assessment as `tuesday-dossier.md` whenever you want a saved copy.

## Upgrade menu

- Web search permission → RR1 can be checked and market calibration and RR2 gain a pay band.
- Your answer on G1 → R6 moves toward `direct`.
- Your answer on G3 → R8 moves off `none`.
- Your pay floor, location and work-authorization needs → hard-gate rows are created and checked, and the snapshot's hard-gates line changes.
- A sanitized memo, LookML excerpt, experiment readout or SQL sample → R2, R3, R4 or R5 can rise to `high`.
- The hiring manager's name → the scope read and which story to lead with.

G1 — Who wrote the metric definitions behind your Looker dashboards (retention, active subscriber, churn)? Did you own them, and did other teams rely on them?

G3 — Have you onboarded, mentored or reviewed the work of other analysts, formally or informally? What did you do, and for whom?

Constraints (RR2) — What must a role meet for you to take it: a pay floor, a location or remote requirement, and your work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.