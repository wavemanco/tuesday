Web search was declined, so this is built from your message and the JD alone.

## Decision snapshot

**Yes, go for it, with two checks first. R2, R3, R4, R5, R6a and R7 (the `must_have` rows that look like your CV) are `direct`. The checks are R1 and the employer verification in RR1. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Designing price tests)
- `important` — direct: R8a · unclear: R8b (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R10 — a credible bridge, its limit named; R6b — probably yours, not yet confirmed; R8b — nothing yet reaches product.

**Opportunity ledger.** The scope is concrete (RR3), but the employer is unverified from here (RR1), the pay is withheld (RR2), and the team shape and decision rights are unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1, which is UK-based remote work; (2) the posting verifies on Brindlemoor's own careers site (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product | `[grounded]` JD |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Scope read | A senior individual-contributor post. The JD asks for no line management, so "never managed anyone" is not a gap against this posting | `[grounded]` JD silent on managing; `[inferred]` that the post is individual-contributor |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not run, because research was unavailable, so no pay band is given | `[grounded]` no search ran |
| Unknowns | Salary, team size, who decides whether a recommendation ships, product stage and data and tooling maturity | `[grounded]` JD silent on each |
| Contradictions | None visible in the posting text you gave me; no second source was checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You gave no location or constraint statement, so the gate is not established. Nothing you said conflicts with it | `[grounded]` no statement given | Question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics, the last 2 as senior analyst. It is a stated claim, with no inspectable artifact yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Stated as daily use. Nothing inspectable yet, so expect a practical probe | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book, which is specific. No artifact has been inspected | `[grounded]` your message | Offer: a sanitized model-documentation extract would raise it to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building. Monitoring is the reasonable reading of maintaining, and I take the lower reading until you say what the monitoring involved | `[grounded]` your message; `[inferred]` that maintaining included monitoring | Mention monitoring practice when confirming R4 |
| R6a | Run and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team, which is specific and recent | `[grounded]` your message | none |
| R6b | Design price tests | must_have | unclear | low | discovery | "Ran" with underwriting does not say who set the test design, sample or success measure. It may well have been you, but I won't assume it | `[grounded]` your wording; no inference made about design ownership | Question G2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting leads are named in the JD | `[grounded]` your message and JD | none |
| R8a | Recommendations for underwriting | important | direct | medium | none | The tests ran with underwriting and the review goes to its head, which is the route recommendations take | `[grounded]` your message | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing you gave reaches a product team | `[grounded]` your message silent on product | Question G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your message | none |
| R10 | Pet-insurance domain knowledge, inferred from "our pet-insurance product" | preferred | adjacent | medium | transferability | Motor rating, GLM and price-testing work is the same discipline. The limit is that you have no pet exposure. Pet pricing has its own rating factors and claims patterns, such as breed, age and vet-cost trends | `[inferred]` requirement derived from the JD's product description; `[generic]` that pet differs from motor in those factors | Prepare a bridge case. See the gap queue |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based remote working (R1, hard_gate) | hard_gate | No location or constraints stated | A gate the inputs do not settle stays open until you confirm it | Not applicable: a yes-or-no fact | None needed | `[grounded]` no statement given |
| G2 | Designing price tests (R6b, must_have) | discovery | You ran 14 tests with underwriting. Design ownership is not stated | The JD lists design first, so which parts were yours decides how strongly to lead with it | Choosing the test split or control group; setting the sample size or run length; defining the success measure; agreeing the readout with underwriting | A sanitized test plan or readout, or the pricing-review slide | `[grounded]` your wording; `[generic]` that this role family probes design ownership |
| G3 | Recommendations to product (R8b, important) | discovery | Nothing links your work to a product or commercial team | The JD names product as a second audience | A pricing proposal for a new product or feature; a pricing change that went to a commercial or product lead; a recommendation that changed a rate or a product rule | A recommendation paper or deck extract | `[grounded]` your message silent on product |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Strong motor GLM and testing work, no pet exposure | It is the likeliest objection on a first screen | Rating-factor work on a niche or low-volume segment; a young-driver book is a small, high-variance one | A short pet-rating-factor memo you could write as a work sample | `[inferred]` bridge from the young-driver work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | no pay figure in the posting as you pasted it | The salary may sit below what you expect for a senior post, or the employer may not publish it | `[grounded]` JD silent; no band to compare against | What salary range is budgeted for this post? | unresolved |
| RR3 | Scope is concrete | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The role's work is defined, and the hiring manager is named | `[grounded]` JD | Which of these three would take most of my first quarter? | noted |
| RR4 | Authority and team shape unknown | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be the only pricing analyst, and decision rights over whether a recommendation ships are not stated | `[inferred]` from "own" against the JD's silence on team and decision rights | Who else sits in pricing, and who decides whether a recommendation ships? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find this role on Brindlemoor's own careers site, and apply there if it is live. If you can't find it, ask RR1's question before investing more effort | See RR1, the condition for go | `[grounded]` RR1 | pending your approval |
| A2 | Positioning: lead with three facts in your own words. You built and maintained the GLM rating model for the young-driver book (R4, R5); you ran 14 price tests with the underwriting team last year (R6a); you present the quarterly pricing review to the head of underwriting (R7). Make no claim about designing the tests until G2 is answered | Each clause traces to your sentences; the design claim is held back | `[grounded]` your message | pending your approval |
| A3 | Pet bridge: say plainly that your pricing work is motor, with no pet-insurance exposure yet, and that GLM and price-test work is what you bring. Do not claim pet knowledge | See R10; the limit stays visible | `[grounded]` your message | pending your approval |
| A4 | Management: state that you have not line-managed. The posting asks for none | The JD lists no people-management requirement | `[grounded]` JD | pending your approval |
| A5 | Ask RR2, RR3 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused, so RR1 stays unresolved. It would have checked that Brindlemoor exists as described and that the posting is live |
| 2. Role-family sweep | unavailable | The search was refused, so there is no market calibration. It would have given the pay band for RR2 and normal scope for this title |
| 3. Hiring manager's public footprint | unavailable | The search was refused. It would have fed the scope read and which of your stories to lead with in A2 |

## Dossier offer and upgrade menu

I can save this as a `tuesday-dossier.md` if you want to carry it into later steps. No pressure.

- Web search access, which would run the three targets above: employer and live-posting check (RR1), pay band (RR2) and the hiring manager's published professional footprint (A2).
- Your answer to G1 → R1 and your constraints are checked, and the hard-gates line firms up.
- Your answer to G2 → R6b moves from `unclear` toward `direct`.
- Your answer to G3 → R8b closes or stays a minor risk.
- A sanitized model-documentation extract, test readout or pricing-review slide → R4, R6a or R7 can reach `high`.
- Your pay floor → RR2 can be checked against it.

## Questions

G1 — Are you UK-based and happy to work fully remote from the UK? Are there hard constraints, such as a pay floor or contract type, I should check this role against?

G2 — On last year's 14 price tests, who designed them (split, sample size, success measure), and which parts were yours?

G3 — Has any of your pricing analysis gone to a product or commercial team rather than underwriting, and what did you recommend?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.