I've read the underwriter playbook and I'm running its two research targets: Quartzline's own site, then a salary and scope check for API platform PM roles. After that I'll write the assessment.
Search permission was refused, so the research below didn't run and everything about Quartzline is unchecked. I also haven't seen your full resume, only your summary of it.

## Decision snapshot

**No, you're not wasting your time on this role. It is a stretch application, not a safe one. R3 and R4a are `direct` and R1b and R2 are credible bridges. But R1a, the titled "3+ years product management experience" must-have, is `absent`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work without the title), R2 (shipped API or platform products) · absent: R1a (3+ years PM experience, titled)
- `important` — direct: R6 · adjacent: R7 (specs, delivery with two squads) · unclear: R4b (sales and support launches), R5 (agile delivery), R8 (adoption metrics)

R1a — a titled-years gap carried as a risk, which no wording closes; R1b, R2 — bridges with their limits named; R3 (`medium`) — confirmed, waiting on an artifact.

**Opportunity ledger.** The posting asks for a titled-years must-have that may be applied literally (RR1). The employer could not be checked (RR2) and pay and location are unstated (RR3). The mandate itself is concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer confirms it counts non-titled product-facing work toward R1a, see RR1 and R1b; (2) the employer and the live posting verify, see RR2; (3) your bridge is framed as adjacent, never as PM years or API-product ownership, see R1b and R2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not checked against any outside source. | `[grounded]` JD header; research refused |
| Mandate | Own the roadmap of a partner-facing API platform, run discovery with integration partners, write specs and drive two engineering squads, define and track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | Must-have: 3+ years PM experience. Also asked: shipped API or platform products, technical fluency, stakeholder management across engineering, sales and customers, agile delivery | `[grounded]` JD |
| Scope read | One platform and two squads is a bounded product remit, not a portfolio role | `[inferred]` from the squad count and company size |
| First-year outcomes | Not stated. Adoption metrics are named but no targets | `[grounded]` JD silent |
| Market calibration | Not available. The role-family sweep was refused and the JD states no pay | `[grounded]` research tier line below |
| Unknowns | Pay, location, adoption targets, whether "PM experience" is read by title or by substance, whether "shipped API products" means owning an API or integrating it | `[grounded]` JD silent on each |
| Contradictions | None within the JD or between the JD and your summary. The JD was not checked against a careers page | `[grounded]` documents provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, titled | must_have | absent | none | capability | You've said you've never held a PM title. A length-of-experience requirement is graded like any other, not a gate, so it keeps its tier. Work near it is graded in R1b | `[grounded]` your statement; JD | Carry as a material risk. Closure path is R1b, G1 and RR1 |
| R1b | PM-type work within that must-have: requirements, roadmap input, cross-functional delivery | must_have | adjacent | medium | transferability | Specific claims: requirements documents, quarterly roadmap-input sessions collecting client feedback for product, coordinating engineers and PMs on custom builds. Limit: you fed other people's roadmaps and worked beside PMs. Nothing yet shows you owning prioritization. No inspectable artifact | `[grounded]` your summary | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the integration playbook the team uses. Limit: that is integrating and enabling someone else's API. Nothing shows you owning an API's design, versioning, release or deprecation | `[grounded]` your summary | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture across 30+ integrations match the requirement directly. Confirmed and specific, but no artifact inspected | `[grounded]` your summary | Offer: a sanitized playbook excerpt would raise to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, clients' engineers and PMs, and ran client workshops through go-live. No artifact inspected | `[grounded]` your summary | none |
| R4b | Working with sales and support; coordinating launches | important | unclear | none | discovery | Your summary is silent on sales, support and launches. Client go-lives are nearby but not the same | `[grounded]` your summary silent | G4 |
| R5 | Agile delivery | important | unclear | none | discovery | Your summary doesn't say how the custom builds were run | `[grounded]` your summary silent | Not asked this turn. Revisit if G1 to G4 leave it open |
| R6 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and roadmap-input sessions are discovery with the people who integrate your APIs. Limit: those were your employer's clients, not third-party partners. The resume reads as solutions work | `[grounded]` your summary; `[inferred]` that clients-as-integrators map to partners | E1 |
| R7 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and engineer coordination carry over. Limit: no evidence of owning a backlog or trading off competing asks across two squads | `[grounded]` your summary | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Your summary is silent. An unconfirmed earlier-conversation lead (an internal triage tool adopted by support agents) is the only thread, so it is a question and not evidence | `[inferred]` from a `memory_lead`, unconfirmed | G3, Question 1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM-type work without the title (R1b, R7; R1a absent) | transferability | Requirements documents, roadmap-input sessions, engineer and PM coordination. Limit: input to others' roadmaps, ownership of prioritization not shown. Strengthener: a concrete decision you drove | R1a is the must-have the posting names, and its weight depends on how the employer reads R1b | Choosing which client requests were worth taking to product; a requirements document engineering built from; tracking a feature's release after your input | A sanitized requirements document, a roadmap-input session summary, a release note citing your input | `[grounded]` your summary; `[inferred]` that RR1 decides R1a's weight |
| G2 | Shipped API or platform products (R2) | transferability | Integration enablement and an internal playbook. Limit: not owning an API's lifecycle. Strengthener: any change to the API, its docs or onboarding that you pushed through | A must-have at `adjacent`. A shipped change narrows the objection | An endpoint, doc or error-handling change you proposed that shipped; a developer-onboarding improvement you drove | Release notes or a changelog naming the change, a ticket trail | `[grounded]` your summary |
| G3 | Adoption metrics (R8) | discovery | Silent in your summary. One unconfirmed lead about an adopted internal tool | Adoption is the stated success measure of the role | A tool or process others took up, with usage you tracked | A usage screenshot or rollout note | `[grounded]` summary silent; `[inferred]` lead from earlier conversation, unconfirmed |
| G4 | Sales and support collaboration (R4b) | discovery | Silent in your summary | The role includes launch coordination with both | Handing a won deal to implementation; rolling out an API change to support; writing enablement for sales or support | A launch or rollout plan, an enablement doc | `[grounded]` summary silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Titled-years must-have may be applied literally | risk_signal | medium | "3+ years product management experience (must-have)" | A literal read would leave R1b out of account. The posting doesn't show whether a human reads it by substance | `[generic]` pattern for titled-years requirements, not a claim about Quartzline | Would you count 3+ years of product-facing work done under a solutions-engineering title (requirements, roadmap input, coordinating engineers and product) toward this requirement? | unresolved |
| RR2 | Employer not established from attributable sources; no search ran | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Pay and location unstated | unknown | — | The posting header gives title, company, size and stage only | The figure or the work location may fall outside what you'd accept, or the posting may simply not publish them | `[grounded]` JD silent; no market band available to compare | What is the salary range for this role, and where is it based? | unresolved |
| RR4 | Concrete mandate | positive_signal | — | "Own the roadmap for our partner-facing API platform … drive delivery with two engineering squads; define and track adoption metrics" | A named platform, two squads and adoption as the measure make the scope concrete | `[grounded]` JD states each | What adoption targets would mark a good first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your roadmap-input sessions and the integration playbook toward the top of the resume, keeping your own sentences: "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses". Reorder only, no new wording | see R1b, R6, R3 | `[grounded]` your summary | `resume_edits_pending_approval` |
| E2 | State your title as it was, "solutions engineer / implementation lead". Let the product-facing work sit under it. Don't write "product manager" or a years-of-PM figure | see R1a, R1b | `[grounded]` your summary | pending your approval |
| E3 | Ask the RR1 question of the recruiter before building a tailored application | see RR1 | `[grounded]` register | pending your approval |
| W1 | A sanitized excerpt of the integration playbook as an inspectable artifact, with no client data | see R3 | `[grounded]` R3 row | pending your approval |

Offer (beyond this assessment): I can run the same underwriting on two or three other PM postings, to see whether R1a recurs as the blocker and whether that changes what to apply for. Say so and I'll build it.

## Evidence status

Verified: none yet. Stage assumed: evaluating, since you didn't say. Unverified lead: a prior-context mention of an internal request-triage tool that support agents adopted. It is unconfirmed and used only as the basis for Question 1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for Quartzline's careers page and API platform was refused, so no result came back. It would have fed role reality's organization and contradictions rows and RR2 |
| 2. Role-family sweep | unavailable | A search on platform API PM pay and requirements was refused. It would have fed the market calibration row and the pay check in RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` whenever you want.

**Upgrade menu**

- Search permission → targets 1 and 2 run (up to 5 searches and 2 fetches in all): employer and live posting checked (RR2), a pay band for RR3. A deeper company pass, with up to 5 more searches and 2 more fetches, is available after that.
- Your full resume, with titles, dates and quantified outcomes → R1b, R2, R4a and R6 checked against the real wording.
- A sanitized playbook excerpt → R3 to `high`.
- The Question 1 answer plus any usage evidence → R8 and G1 move.
- Salary range and location → RR3 closes.
- The hiring manager's name → target 3 runs and E1's lead story is chosen for that reader.

**Questions**

1. G3 — Something from an earlier conversation suggests you built an internal request-triage tool that support agents adopted. I haven't confirmed that, so I'm asking rather than assuming. Is it right? If so, what did you own, roughly how many people used it, and how did you know it was adopted?
2. G4 — Have you worked with sales or support to launch or roll out something, such as an API change, a feature or a process? What did you do, and who else was involved?
3. Do you have any non-negotiables on location or remote work, pay floor or work authorization that this role could touch?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.