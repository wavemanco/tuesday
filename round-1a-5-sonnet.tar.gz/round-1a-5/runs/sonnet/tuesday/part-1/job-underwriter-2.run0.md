**Decision snapshot**

**No, the pivot isn't a waste of your time, but this posting is a stretch. R1b, R3, R4 and R6 are real bridges, and R1a (titled PM years) is the part you can't write around. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: adjacent: R1b (PM-type work in practice) · absent: R1a (3+ years PM experience, titled)
- `important`: direct: R3, R4, R6 · adjacent: R2 (Shipped API or platform products), R8 (Launches with sales and support) · unclear: R5 (Agile delivery), R7 (Adoption metrics)

R1a: titled years can't be recovered by wording; R1b: real adjacent work, its limit named (input, not ownership); R2: the implementer's side of the API, not the builder's.

**Opportunity ledger.** The scope is concrete (RR3), but pay and work terms are unstated (RR1, RR4), and the employer has not been checked (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. A hiring contact confirms the 3+ years is not screened by title alone (R1a).
  2. Any product decision you personally owned is confirmed (R1b, R7, G1, G2).
  3. The employer verifies on its own careers page (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B (as stated in the posting; not checked) | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs; drive two engineering squads; define adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | One person carries roadmap, discovery, delivery, metrics and launch coordination, which is broad for a single post | `[inferred]` from the length of the responsibility list |
| Market calibration | Not available. The role-family search did not run, and the posting states no pay | `[grounded]` JD silent; research unavailable |
| Unknowns | Pay, location or remote terms, reporting line, whether the 3+ years is screened by title | — |
| Contradictions | None visible inside the posting; it was not compared with a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience (titled) | must_have | absent | none | transferability | Your resume says you have never held a PM title, and the JD marks this must-have. Wording cannot add the title. The adjacent work is carried in R1b. Strict title screens are common | `[grounded]` your statement and the JD; `[generic]` that such requirements are often screened literally | Ask the hiring contact whether non-titled product work counts (A1); G2 |
| R1b | PM-type work: roadmap input, requirements, cross-team delivery | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions, wrote requirements documents and coordinated engineers, client engineers and PMs. Limit: that is input to product, and nothing here shows you owned a roadmap, a prioritisation call or a product outcome | `[grounded]` your resume, unprobed so capped at `medium` | G1, G2 |
| R2 | Shipped API or platform products | important | adjacent | medium | transferability | You led 30+ end-to-end integrations of your employer's REST APIs. That is the integrator's side. Limit: no evidence you shaped or shipped the API itself. The JD lists this without marking it must-have, so it is tiered `important` | `[grounded]` your resume; `[inferred]` tier from the JD's wording | G3 |
| R3 | Technical fluency: API docs, schemas | important | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture are stated; no artifact has been inspected | `[grounded]` your resume | An integration playbook excerpt would raise it to `high` |
| R4 | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and PMs. Sales is not evidenced and sits in R8 | `[grounded]` your resume | none |
| R5 | Agile delivery | important | unclear | low | discovery | The resume describes UAT and go-live but never names agile ceremonies or squads | `[grounded]` resume silence | Optional: say which cadence your custom builds ran on |
| R6 | Discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly client-feedback sessions are the same activity as partner discovery. Limit: your clients were customers, not partners | `[grounded]` your resume | none |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | Nothing on the resume sets or tracks adoption. A prior-conversation mention of a triage tool support agents adopted is an unconfirmed lead | `[grounded]` resume silence; `[inferred]` that the lead may bear on it | G1 |
| R8 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches of a kind. Limit: they were customer deployments, not product releases, and sales and support are not named | `[grounded]` your resume | Name any sales or support hand-offs you ran |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owned product decisions and adoption (R1b, R7) | discovery | A recalled but unconfirmed internal request-triage tool that support agents adopted; nothing about who decided what or how adoption was measured | It is the only visible route to ownership and metrics evidence, and it could move R1b and R7 | Deciding what the tool did; tracking who used it; iterating after feedback | A short brief, a usage screenshot, a message from the support lead | `[grounded]` the unconfirmed lead; `[inferred]` its relevance |
| G2 | Formal or acting product responsibility (R1a, R1b) | discovery | No PM title, but you sat close to PMs on custom builds | A period of acting PM or owner duties changes how R1a is argued | Acting as product owner on a custom build; owning a client-specific roadmap; deciding scope trade-offs | A project charter or roadmap you wrote | `[grounded]` resume silence |
| G3 | Influence on the API product itself (R2) | discovery | 30+ integrations, with feedback sent to product, but no shipped change traced to you | Separates "integrator" from "contributor to the product" | A client-driven change to an endpoint or the docs that shipped; a spec you wrote that engineering built | The ticket, spec or release note | `[grounded]` resume; `[generic]` that this distinction is what a platform PM screen probes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Compensation not stated | unknown | — | the posting as pasted gives no pay figure | The figure may fall outside your floor, which has not been given | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR2 | Employer not checked | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a hiring employer; no search ran | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR3 | Concrete, scoped mandate | positive_signal | — | "partner-facing API platform … two engineering squads" | Scope and delivery partners are named, so the role is defined | `[grounded]` JD | Which partners use the API today, and how do they integrate? | noted |
| RR4 | Work terms unstated | unknown | — | no location, level or reporting line in the posting | The post may be on-site or sit under engineering; not stated | `[inferred]` from the JD's silence | Where is the role based, and who does it report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reach a person at Quartzline first and ask whether non-titled product work counts toward the 3+ years | see R1a, RR2 | `[generic]` small companies often flex on stated years when a person vouches | pending your approval |
| E1 | Move two resume lines to the top, wording unchanged: "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses" | see R1b, R6 | `[grounded]` your resume | resume_edits_pending_approval |
| A2 | Cover note: "I have not held a PM title; for seven years I led API integrations beside product managers and ran quarterly roadmap-input sessions." Do not write "owned the roadmap" or "product management experience" | see R1a, R1b | `[grounded]` your own sentences | pending your approval |
| A3 | Hold the triage-tool story until G1 is confirmed, then add it to E1 | see R1b, R7 | `[grounded]` lead unconfirmed | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: the request-triage tool from prior conversation, which only prompts G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused, so the employer is unchecked (RR2) and the JD could not be compared with a careers page |
| 2. Role-family sweep | unavailable | The search was refused, so there is no pay band or title norm in role reality |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Search permission, so L1 can run → clears or confirms RR2 and gives a pay band for RR1.
- An answer to G1, G2 or G3 → can raise R1b, R2 or R7.
- Your pay floor, location limits and whether you would take a lower-title role → hard-gate checks against the role, now unknown.
- The hiring manager's name → positioning for that reader.

I can also write this up as a `tuesday-dossier.md` if you want a file to carry forward.

**Questions**

- **G1:** Did you build the request-triage tool? What did you personally decide, did support agents use it, and how did you know?
- **G2:** Was there a project where you acted as product owner or owned scope and priorities, even without the title?
- **G3:** Did any change to the API or its docs ship because of something you raised or wrote up? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.