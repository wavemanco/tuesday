Search permission wasn't granted, so I'm underwriting from your message alone and have labelled it that way below.

## Decision snapshot

**Yes, go for it, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6, R7, R8a
- `important`: adjacent: R10 (Pet-insurance domain knowledge) · unclear: R8b (Recommendations for product)
- `preferred`: direct: R9

R10: a transferable bridge, its limit named; R8b: product-side recommending not yet evidenced; R1: a gate your message does not settle.

**Opportunity ledger.** Concrete on what the job does (RR4). Unverified on three points: the employer could not be checked in this run (RR3), the pay is not stated (RR1), and the team and support around "own pricing analytics" are unspecified (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and the live posting verify (RR3).
  2. You confirm you can work remotely from the UK (R1).
  3. Scope and support turn out concrete when you ask (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Its existence was not checked. | `[grounded]` your pasted JD |
| Mandate | Build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| People management | The JD lists no line-management requirement and names no direct reports. Whether the role carries any is unknown. | `[grounded]` JD silence |
| Scope read | Reads as a senior individual-contributor post under a Director, because the title says senior and the JD names no team | `[inferred]` from the title against the JD's silence on reports |
| Success measures | None stated | `[grounded]` JD silence |
| Compensation | Not stated. No market band was calibrated because the role-family sweep did not run. | `[grounded]` JD silence |
| Contradictions | None visible within the JD. It was not cross-checked against a careers page. | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You haven't said where you live or that you can work remotely from the UK. Five years at a UK insurer is indirect context and doesn't settle it. | `[grounded]` JD; `[inferred]` UK base from your UK employment | Ask G3 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, the last two as senior analyst. It is self-reported and nothing has been inspected. | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is confirmed use. How strong you are is not shown by any artifact. | `[grounded]` your message | A sanitized notebook or query set would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. | `[grounded]` your message | Be ready to name factors, link function and validation |
| R5 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained a rating model. The monitoring side (performance tracking, drift) isn't described, so it is read at the lower reading of "maintained". | `[grounded]` your message | Be ready to describe how you monitored it |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Which parts you designed yourself isn't stated. | `[grounded]` your message | Be ready to say what you personally designed |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` your message | A sanitized review deck would raise it to `high` |
| R8a | Recommendations for underwriting | must_have | direct | medium | none | The tests ran with underwriting and the quarterly review goes to their head. That you framed the recommendations is implied, not stated. | `[grounded]` your message; `[inferred]` recommendation role from the review you present | Confirm in interview prep what you recommended and what was adopted |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in your message touches a product team. | `[grounded]` your message silent | Ask G2 |
| R9 | Insurance experience, a plus | preferred | direct | medium | none | Five years at a motor insurer. | `[grounded]` your message | none |
| R10 | Pet-insurance domain knowledge (not listed as a requirement) | important | adjacent | medium | transferability | You state none. Your young-driver GLM work is the bridge. Its limit is that pet pricing has its own rating factors and claims drivers that motor work didn't exercise. | `[inferred]` requirement from the JD naming the pet product; `[generic]` pet and motor differ in rating factors; `[grounded]` your statement | Ask G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R10, important) | transferability | A young-driver GLM and 14 price tests, nothing on pet | It is the one domain this role is named for, so the bridge you can draw sets how the application reads | Age-curve rating in the young-driver book; claims-cost trend or inflation work; renewal or tenure pricing; any health or repair-cost line you've touched | A sanitized rating-factor summary, a price-test readout, a trend note | `[grounded]` your message; `[generic]` that interviewers probe the product-domain gap |
| G2 | Product-side recommendations (R8b, important) | discovery | Underwriting audiences are evidenced, product audiences aren't | The JD names product as a recommendation audience | Test results that shaped cover levels, tiers, add-ons or renewal journeys; work with a product or proposition team | A test readout addressed to product, or a decision note | `[grounded]` your message silent; `[inferred]` that the JD treats product as a real audience |
| G3 | UK remote working (R1, hard_gate) | hard_gate | Location and right to work aren't stated | A gate you can pass quickly or fail outright | n/a | n/a | `[grounded]` JD term; your message silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | No compensation appears in the posting as provided | The figure may sit anywhere against the market, or Brindlemoor may simply not publish it | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RR2 | Ownership without stated team or support | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only analyst on the product, or inherit an existing model, with data and sign-off arrangements unknown | `[inferred]` from "own" against the JD's silence on team | Who else is on the pricing team, what data and tooling exist, and who signs off rating changes? | unresolved |
| RR3 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. In this run the check did not run, so none of these is ranked as likely. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Concrete mandate | positive_signal | — | "build and monitor rating models, design and read price tests… recommendations for underwriting and product" | The responsibilities are specific and sit squarely in your recent work | `[grounded]` JD | What would a successful first year look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role on Brindlemoor's own careers site before spending effort | see RR3 | `[grounded]` RR3 | pending your approval |
| E1 | Lead the CV with your own facts: the young-driver GLM you built and maintained, and the 14 price tests run with underwriting | see R4, R6 | `[grounded]` your message | pending your approval |
| E2 | Keep your own wording for the review ("present the quarterly pricing review to the head of underwriting") | see R7 | `[grounded]` your message | pending your approval |
| P1 | Say plainly that you haven't worked on pet insurance, then give the G1 bridge once you've answered it. Don't present motor work as pet experience. | see R10 | `[grounded]` your statement | pending your approval |
| P2 | If asked about management: you haven't managed anyone, and the JD lists no such requirement. Say that and move on. | see R-set above; the JD lists none | `[grounded]` your statement and JD silence | pending your approval |
| Q1 | Ask the RR1, RR2 and RR4 questions verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was sent and refused for lack of permission. It would have moved RR3 and the contradictions row. |
| 2. Role-family sweep | unavailable | Refused likewise. It would have moved market calibration and the RR1 comparison. |
| 3. Hiring manager's public footprint | unavailable | The name was given and the search was refused. It would have moved the scope read and which story the plan leads with for Odile Varga. |

I can write this up as a `tuesday-dossier.md` to carry forward if you'd like.

## Upgrade menu

- Search permission would let me run targets 1–3: it closes RR3, sets pay against a market band, and adds Odile Varga's public professional footprint.
- Answers to G1, G2 and G3 would move R10, R8b and R1.
- A sanitized price-test readout, review deck or code sample would raise R3, R6 and R7 toward `high`.
- Your CV, which would add a source beyond your summary.
- Your pay floor and any other non-negotiables, so the hard-gate line can check them.

**Questions**

- G1: Which parts of your young-driver work (age curves, claims trend, renewal pricing) did you personally own, and what did the results show?
- G2: Have your price-test results ever gone to a product or proposition team rather than underwriting? What did you recommend, and what happened?
- G3: Are you UK-based and able to work remotely from the UK?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.