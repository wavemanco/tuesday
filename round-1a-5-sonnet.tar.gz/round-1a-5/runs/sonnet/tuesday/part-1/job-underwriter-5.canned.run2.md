I'm reading the rest of the underwriting rules, which cover output format, question ranking and evidence rows. Then I'll write the assessment.
**Yes, it's worth applying. Status: `conditional_go`.** The condition is that the role's location and pay terms fit your own limits, which you haven't told me yet.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Pay $148k–$166k plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9 is a credible bridge, and its limit is that you have never used BigQuery. R10 and R11 are open because your payroll-company background doesn't say either way.

**Opportunity ledger.** A well-scoped role with a stated salary (RR3) at a company whose own pages match the posting (RR5). The open points are the unnamed hiring manager and team shape (RR1), the unspecified equity (RR2) and what "run" means for on-call (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay $148k–$166k plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 fit your own non-negotiables; (2) the team and reporting structure verify as real in the loop (RR1); (3) the BigQuery gap is framed honestly as adjacent, never as BigQuery experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About page, fetched |
| Mandate | Build and run the reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, fetched |
| Posting status | Live ("Accepting applications") and word-for-word consistent with what you pasted | `[grounded]` careers page, fetched |
| Scope read | Looks like ownership of one reporting domain's pipelines, with no reports mentioned. That is the typical senior scope, though "build and run" across ingestion, warehouse and contracts leans broad | `[inferred]` from the JD's three named workstreams against the pay report's typical scope |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500, "senior" typically 5–8 years. The posting's $148k–$166k starts just under the median and tops out above the 75th percentile. Your 6 years sit inside the usual range | `[generic]` Datawright 2026 report, as pasted (n=2,310); `[grounded]` JD for the posted range |
| Unknowns | Hiring manager, team size, equity terms, on-call expectations, how mature the data contracts are today | — |
| Contradictions | None between the JD and the About page | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | low | hard_gate | The role's terms are clear. You haven't said whether they meet your constraints | `[grounded]` JD; your constraints not given | Question Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | low | hard_gate | The pay is stated. Your floor is unknown, and the equity terms are unstated | `[grounded]` JD; your floor not given | Question Q1; RR2 for equity |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It's a prose claim with no document yet, so `medium` | `[grounded]` your stated background | A CV would let me check it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" rests on your own account | `[grounded]` your stated background | A sanitized code or query sample would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models on Snowflake | `[grounded]` your stated background | Project docs or a lineage screenshot would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The JD's requirement line says "a cloud warehouse", not BigQuery (R9 covers that) | `[grounded]` JD requirement line and your stated background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and you used it for orchestration | `[grounded]` your stated background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is ownership of the testing, not just use of it | `[grounded]` your stated background | A sanitized suite summary would raise it |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: dbt modelling and warehouse design on Snowflake. The limit is that you have never used BigQuery, so its cost model, partitioning and access setup are untested by you. That is a posting responsibility, not a stated requirement | `[inferred]` adjacency; `[grounded]` your "never used BigQuery" | Gap G1 |
| R10 | Ingestion from the app and the CRM | important | unclear | low | discovery | You haven't described your sources or ingestion methods, so the fit is unknown either way | `[grounded]` silence in your account | Question Q2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your account doesn't mention contracts or similar agreements with analysts | `[grounded]` silence in your account | Question Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake plus dbt, no BigQuery. The bridge is the shared dbt and warehouse practice. The limit is no hands-on BigQuery. A small BigQuery project would narrow it | The warehouse is named in the mandate, so it is the most likely probe in a screen | A personal or sandbox dbt-bigquery project; any GCP exposure at work; a Snowflake-to-BigQuery comparison you can talk through | A small repo or write-up | `[inferred]` bridge; `[generic]` that a named warehouse is a common screen topic |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Unknown sources | Ingestion is the first item in the mandate | Pulling from a product database, event stream or CRM API; building or owning connectors; handling schema changes upstream | An architecture sketch or runbook | `[grounded]` silence in your account |
| G3 | Data contracts (R11, important) | discovery | No mention | The mandate names contracts explicitly | Agreeing schemas or SLAs with analysts or upstream teams; schema-change alerts; Great Expectations checks used as agreements | A contract doc, test config or incident write-up | `[grounded]` silence in your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and team shape unknown | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the first or only data engineer on the platform, or one of several | `[inferred]` from "build and run" with no manager or team named | Who does this role report to, and how many data engineers and analysts are on the team? | unresolved |
| RR2 | Equity unspecified | unknown | — | "plus equity" | The grant type, vesting and valuation basis may not be set yet | `[inferred]` from the posting's silence | What form does the equity take, and what are the vesting terms and the latest valuation basis? | unresolved |
| RR3 | Salary stated and in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The pay appears transparent and in line with the seniority | `[grounded]` JD against your pasted pay report, with the band `[generic]` | Where in the range would you expect someone with my background to land? | noted |
| RR4 | "Build and run" may carry on-call duty | unknown | — | "Build and run the pipelines" | Running production pipelines can include after-hours support | `[generic]` pattern for roles that own pipelines in production | Is there an on-call rotation, and how is it covered? | unresolved |
| RR5 | Employer verified and recently funded | positive_signal | — | "Series C ($52M, February 2026)" | The company is real, funded, and the posting is live | `[grounded]` About and careers pages, fetched | Is this a new role or a backfill? | noted |

## Application plan

Every row is proposed and pending your approval; none of this is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the 180-model dbt project, the Airflow orchestration and the Great Expectations suite you set up, since they match the stated requirements | see R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| E2 | Name Snowflake accurately as your warehouse. Do not describe it as BigQuery experience | see R6, R9 | `[grounded]` R9 | pending your approval |
| W1 | Optionally build a small dbt-bigquery project to narrow the BigQuery gap before screens | see G1 | `[inferred]` from R9 | pending your approval |
| Q1 | Ask the register's verification questions in the loop, especially RR1 and RR4 | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: all of your background claims, which come from your own account and not a document.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" and "About Pellucid Learning". Both match your paste and the posting is live |
| 2 | Role-family sweep | skipped | The Datawright pay report you pasted already fixes the market calibration and the pay comparison |
| 3 | Hiring manager's public footprint | n/a | The posting names no hiring manager |

I can write a `tuesday-dossier.md` of this assessment if you'd like to keep it.

**Upgrade menu.**

- **Your constraints** (location, pay floor, work authorization): this would settle R1 and R2, which are the only things that could move the status.
- **Your CV, or sanitized samples** (a dbt docs page, a Great Expectations suite summary): this would raise R3 through R8 from `medium`.
- **Deeper research** (L2): up to 5 more searches and 2 more fetches on funding history, hiring patterns and public employee reports, feeding the register.

**Questions**

Q1 (R1, R2) — Do you have non-negotiables on location, pay floor or work authorization that this role's Remote (US) or Denver terms and $148k–$166k range would touch?
Q2 (R10) — At the payroll company, what data sources did you ingest from, and did you own the connectors or only model downstream of them?
Q3 (R11) — Did you ever set up formal expectations or checks with analysts or upstream teams, such as schemas, SLAs or alerts on breaking changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.