Both company searches were refused, so this assessment rests on the posting and your background alone.

## Decision snapshot

**Yes, apply: you fit the posting. R1, R2, R3, R4 and R5, all the `must_have` rows, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (metrics layer), R7 (partner with PMs and clinicians) · unclear: R8 (mentor two junior analysts)
- `preferred` — adjacent: R9b (regulated personal data) · absent: R9a (healthcare data experience)

R6 — governed dashboards point toward definitions work, ownership unconfirmed; R8 — silence, not a no; R9a — a domain gap with a privacy bridge in R9b.

**Opportunity ledger.** The role is concretely scoped (RR4), but the employer is unverified because the searches were refused (RR2). Pay and work arrangement are absent from the posting (RR1), and the supporting team is unknown (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR2; (2) pay and work arrangement suit you, see RR1; (3) the healthcare gap is framed honestly and never as HIPAA experience, see R9a and R9b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, work with PMs and clinicians, mentor two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor role with light people leadership | `[inferred]` from the two mentees against the absence of any stated reports beyond them |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Pay, location or remote policy, reporting line, data-engineering support, whether the role touches patient data, experiment traffic volumes | `[grounded]` JD silent on each |
| Market calibration | Not run; the role-family search was refused, so no pay band is offered | `[grounded]` search refused |
| Contradictions | None visible inside the posting | `[grounded]` JD read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. It is specific, but nothing has been inspected. Years of experience is not a gate. | `[grounded]` your message | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake. "Expert" is your word, and an interviewer will likely probe it with a live exercise. | `[grounded]` your message; `[generic]` that analyst loops commonly include SQL exercises | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state that you designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Harborlight's traffic is unknown, so "at scale" is read against your cadence. | `[grounded]` your message | Offer: a sanitized test brief or readout would raise it to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You state you built the company's Looker instance from scratch, with 40+ governed dashboards. | `[grounded]` your message | Offer: a dashboard screenshot or governance doc would raise it to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. | `[grounded]` your message | Offer: a sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | discovery | "Governed dashboards" suggests shared metric definitions, but you have not said you owned the definitions, so the lower reading is taken. | `[grounded]` your message; `[inferred]` that governance implies definitions work | Ask G1 |
| R7 | Partner with PMs and clinicians to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Monthly presentations to the VP Product are confirmed. Influence on roadmap decisions and any work with clinicians are not stated. | `[grounded]` your message | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your message is silent on mentoring. That is absence of evidence, not a no. | `[grounded]` silence in your message | Ask G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | You state you have never worked in healthcare. It is a preferred item, so a minor risk. | `[grounded]` your message | Closure path: a short HIPAA primer before interviews |
| R9b | Regulated personal-data handling (HIPAA a plus) | preferred | adjacent | medium | transferability | You state GDPR/CCPA consumer PII handling and a consent-state model you built for the warehouse. The limit is that these are consumer-privacy regimes, which differ from HIPAA's rules on patient health information. | `[grounded]` your message; `[generic]` that the two regimes differ in what they protect | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | Governed dashboards are stated; ownership of metric definitions is not | The JD lists it first among duties | Owning a metric dictionary; LookML measures and dimensions others reused; settling a retention or churn definition across teams | A metric-definition doc or a LookML excerpt | `[grounded]` your message silent on definitions; `[generic]` that metrics layers are central to roles like this |
| G2 | Mentoring (R8, important) | discovery | Nothing stated | The role includes two junior analysts | Onboarding an analyst; reviewing others' queries or tests; running a team analytics clinic | None required | `[grounded]` your message silent |
| G3 | PM and clinician partnership (R7, important) | discovery | VP Product presentations are stated; no PM-level or clinical partnership | The role turns analysis into roadmap decisions | A test result that changed a roadmap; work with a medical, legal or compliance stakeholder | A decision log or memo excerpt | `[grounded]` your message |
| G4 | Healthcare bridge (R9a, R9b, preferred) | transferability | Consumer-privacy work is the adjacent evidence; no health data. The limit is that it did not exercise HIPAA rules. The strengthener is a short HIPAA primer | A preferred item, but likely a probe in the loop | PII minimization, access controls, de-identification, consent logic | Your consent-state model design doc | `[inferred]` bridge from your stated work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and work arrangement absent | unknown | — | No pay, location or remote language in the pasted posting | It may be in the full listing or withheld | `[inferred]` from the pasted text's silence | What is the pay band, and is the role remote, hybrid or on-site? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The searches were refused, so this is unverified, not disproven. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Supporting team and data stack unstated | unknown | — | "define and maintain the metrics layer … mentor two junior analysts" | The metrics layer, experiments, dashboards and mentoring may land on one person without engineering support | `[inferred]` from the JD's scope list against its silence on support | Who builds the models under the metrics layer, and what engineering support does analytics have? | unresolved |
| RR4 | Scope concretely stated | positive_signal | — | "Own product analytics for our care-navigation app" | The mandate, the tool (Looker) and the mentoring scope are specific | `[grounded]` JD | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Harborlight's own careers page, and ask the RR1 and RR2 questions before investing effort | RR1, RR2 | `[grounded]` register | pending your approval |
| P1 | Lead with R3 and R4, in your own words: you designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift; you built the company's Looker instance from scratch, with 40+ governed dashboards | R3, R4 | `[grounded]` your message | pending your approval |
| P2 | Say about healthcare: "I haven't worked with health data; I've handled GDPR/CCPA consumer PII and built our warehouse's consent-state model." Do not claim HIPAA experience | R9a, R9b | `[grounded]` your message | pending your approval |
| P3 | Do not describe yourself as owning a metrics layer or as having mentored anyone until G1 and G2 are answered | R6, R8 | `[grounded]` map | pending your approval |
| Q1 | Ask RR1 to RR4 verbatim in the loop | Doubles as interview prep | `[grounded]` register | pending your approval |

I have not edited your resume; that is the resume-tailor module's job.

## Evidence status

Verified: none yet. Every row rests on your message alone.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; both calls were refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app careers Senior Product Analyst" was refused. It would have fed the role reality organization row and RR2 |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary range experimentation Looker" was refused. It would have fed market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

If you grant search permission, I can run targets 1 and 2 and update RR1 and RR2.

I can write this up as `tuesday-dossier.md` if you want to carry it into later steps.

**Upgrade menu**
- Your CV, or a sanitized memo, test readout or dashboard screenshot would take R3, R4 and R5 toward `high`.
- An answer to G1 would settle R6; an answer to G2 would settle R8.
- Your pay floor and location needs would let me check RR1 against hard constraints.
- Search permission would settle RR2 and add a market pay band.
- A hiring manager's name would shape what to lead with.

**Questions**
G1 — Did you personally own the metric definitions behind your dashboards, for example in LookML or a metric dictionary, and did other teams reuse them? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you onboarded, reviewed the work of, or coached other analysts, formally or informally? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

RR1 — What are your non-negotiables on pay, location or remote work, and work authorization? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.