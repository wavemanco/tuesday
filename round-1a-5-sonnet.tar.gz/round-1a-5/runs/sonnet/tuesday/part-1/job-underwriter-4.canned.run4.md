I'm checking Brindlemoor's own careers page. The search snippet says "Leeds office four days a week", which contradicts the "fully remote" in your JD. I'll read the page itself before I rely on that.
# Job Underwriting Assessment — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes on fit, since R2, R3, R4, R6 and R8 are all `direct`. But don't apply until R1, remote versus office, is settled. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R6, R8 · adjacent: R5 (Build and monitor rating models), R7 (Recommendations to underwriting and product)
- `important` — adjacent: R9 (Pet-insurance product knowledge)
- `preferred` — direct: R10

R1 — the posting and the careers page disagree on location; R5 — monitoring not yet stated; R7 — product-side work unconfirmed; R9 — a credible bridge, its limit named.

**Opportunity ledger.** The role looks live and clearly scoped, with a named reporting line (RR4). Three things are open: the working pattern contradicts itself (RR1), no salary is stated (RR2), and nothing says whether the role has reports (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the awaited answer is R1, whether the role is fully remote or Leeds four days a week, and whether that works for you. If the role is remote or the Leeds pattern works, the status moves to `conditional_go`, with RR2 and RR3 as the conditions. If you need fully remote and the role is office-based, it becomes `no_go` with R1 as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, a pet-insurance insurtech with a live careers page for this role | `[grounded]` JD header; careers page fetched |
| Working pattern | Your JD says "Fully remote (UK)". The careers page says "Leeds office four days a week". These contradict each other, and I have not resolved which is current | `[grounded]` JD as you pasted it; careers page fetched |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. She spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books). Before Brindlemoor she was head of pricing analytics at Calloway Re for six years | `[grounded]` search result for her profile page (snippet only, page not fetched) |
| Scope read | "Own" is stated, but no team, budget or decision rights are. The JD lists no line-management requirement | `[inferred]` from the JD's wording against its silence |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. This is a market band, not Brindlemoor's offer, and the posting as you gave it states no figure | `[generic]` Pricewell 2026 survey (n=612), seen as a search snippet only |
| Unknowns | Salary; direct reports and team size; what success looks like in the first year | — |
| Contradictions | Remote versus Leeds (see Working pattern) | `[grounded]` as above |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location constraint, so there is nothing to grade. The careers page contradicts the JD, so even the role's terms are unsettled | `[grounded]` JD and careers page | Question 1; RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, two of them senior. Self-reported with nothing inspected, so `medium` | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated and specific, with no artifact yet | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but no inspectable artifact | `[grounded]` your background | none |
| R5 | Build and monitor rating models | must_have | adjacent | medium | discovery | "Built and maintained" covers the build. Monitoring is not stated, and I won't assume what maintenance involved | `[grounded]` your background; `[generic]` that monitoring is a distinct skill from building | Question 2 |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with the underwriting team. Specific, no artifact yet | `[grounded]` your background | none |
| R7 | Recommendations to underwriting and product | must_have | adjacent | medium | discovery | Underwriting is covered by your tests and the quarterly review. A product audience is not mentioned | `[grounded]` your background | Question 3 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | The JD names the pet product but sets no pet-experience requirement, so this row is my reading of it. Motor rating build and price-test method carry over. The limit is that pet-specific rating factors are unexercised | `[inferred]` from the JD's product reference; `[grounded]` you have no pet experience | Bridge case in the plan (P1) |
| R10 | Insurance experience a plus | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5, must_have) | discovery | You built and maintained the model. Nothing says how its performance was tracked after launch | The role says "build and monitor", and the hiring manager has spoken publicly on monitoring models | Tracking actual against expected claims or loss ratios; periodic model refreshes; flagging drift to underwriting; a monitoring pack someone else relied on | A sanitized monitoring report or dashboard screenshot | `[grounded]` background silent on monitoring; `[inferred]` from her talk title that it is a live topic for her |
| G2 | Product-side recommendations (R7, must_have) | discovery | Your recommendations go to underwriting. The product audience is unconfirmed | The JD names both audiences | A price-test result you took to a product owner or proposition team; a pricing change that altered a product feature | A recommendation paper or a test read-out deck | `[grounded]` background silent on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The careers page may be current and the JD you hold older, the role may be hybrid with remote described loosely, or one source may be wrong | `[grounded]` both quotes; the three explanations are `[generic]` possibilities, none ranked as likely | Is this role fully remote, or based in the Leeds office four days a week, and which will my contract say? | unresolved |
| RR2 | Salary not stated in the posting you gave | unknown | — | JD as pasted names no figure | The budget may sit inside the market band or outside it | `[grounded]` JD silence; `[generic]` band in role reality | What salary range is budgeted for this post? | unresolved |
| RR3 | Reports and team size unstated | unknown | — | "Own pricing analytics" | The role may be an individual-contributor post or may carry reports, which matters because you haven't managed anyone | `[inferred]` from the JD's "own" against its silence on team | Does this role have direct reports, and how big is the pricing team? | unresolved |
| RR4 | Live posting, named reporting line | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The role is real and reports to the named hiring manager | `[grounded]` careers page fetched | What would success look like in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter before spending effort on the application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Positioning advice: lead with the young-driver GLM you built and maintained, the 14 price tests run with the underwriting team, and the quarterly pricing review you present to the head of underwriting, each in your own words. Say plainly that you haven't worked on pet insurance, then name what carries over (rating-model build, price-test method) and the limit (pet-specific rating factors) | see R4, R6, R8, R9 | `[grounded]` your background; `[grounded]` R9 row | pending your approval |
| P2 | For Odile Varga: her published talk is on monitoring rating models, so be ready to describe concretely how you tracked yours. Say only what you confirm in G1 | see R5, G1 | `[inferred]` from her talk title | pending your approval |
| Q1 | Ask the verification questions in RR1, RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The role is live, but the page says Leeds four days a week, which contradicts the JD. That moved R1, RR1 and the contradictions row |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Snippet only, not fetched. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Snippet only, not fetched. It moved the hiring-manager row, G1 and P2 |

I can save this as `tuesday-dossier.md` if you'd like to keep it or feed it into later steps.

**Upgrade menu**

- Your location and working-pattern constraint → R1 settles, and the decision moves off `hold_pending_answers`.
- Your salary floor → RR2 can be checked against the band in role reality.
- A sanitized monitoring report or dashboard screenshot → R5 and G1 strengthen, and R4 can rise toward `high`.
- A product-facing recommendation paper → R7 and G2 close.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. R1 — Is working from the Leeds office four days a week workable for you, or is fully remote a must? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G1 — How did you track the young-driver GLM model after it went live, and what did you do when it drifted? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. G2 — Have you taken a price-test result or recommendation to a product owner or proposition team, as opposed to underwriting? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.