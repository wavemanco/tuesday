The web search wasn't permitted, so this runs on your JD and your background alone.

## Decision snapshot

**Yes, apply, and you fit: R1, R2, R3, R4 and R5, every `must_have` row, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R7a (Partner with product managers on roadmap decisions) · unclear: R6 (Define and maintain the metrics layer), R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R3 (`medium`) — confirmed, but "at scale" is not yet measured; R6, R7b, R8 — nothing in the material yet; R9 — a credible bridge, its limit named.

**Opportunity ledger.** Plausible but unverified: the employer could not be checked from here (RR1), and pay is not stated (RR2). Five responsibilities sit in one title with no stated decision rights (RR3), though a team of two juniors is named (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) you hold real decision rights over metric definitions, not just the job of maintaining them — R6, RR3; (3) the healthcare bridge is framed as adjacent, never as HIPAA experience — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority | Senior individual contributor with light people leadership: "mentor", not "manage" | `[inferred]` from the JD's verb and the two-person mentee group |
| Pay, location, work pattern | None stated | `[grounded]` JD silent |
| First-90-days outcomes | None stated | `[grounded]` JD silent |
| Market calibration | Not run, because search was unavailable. Title, scope and pay are uncalibrated | — |
| Unknowns | Pay; location and remote policy; who owns metric definitions today; whether the juniors report to this role; how clinicians are involved | — |
| Contradictions | None inside the JD. It could not be cross-checked against a careers page | `[grounded]` JD read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a ~2M-subscriber meal-kit company, stated in your own words and specific. No document inspected yet | `[grounded]` your intake message | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake is confirmed. "Expert" is a level judgement that nothing here shows. Expect a live SQL screen | `[grounded]` your intake message; `[generic]` that roles of this kind commonly screen SQL live | Offer: a sanitized query or model you wrote would raise to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | Specific: you designed and ran the program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD never defines "at scale", and the claim has no inspectable readout yet | `[grounded]` your intake message | Offer: a sanitized test readout or program summary would raise to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. The JD says "self-serve", which "governed" does not by itself show | `[grounded]` your intake message | Offer: a dashboard screenshot or the instance's usage stats would raise to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. Specific and confirmed, with no artifact inspected | `[grounded]` your intake message | Offer: a sanitized memo would raise to `high` |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | Governed Looker dashboards are indirect context. Nothing you've said shows you owned shared metric definitions | `[grounded]` your intake message silent on metric-definition work | See G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | low | discovery | Monthly presentations to the VP Product and an experimentation program imply decision-facing work. Direct work with PMs on roadmap choices is not stated. Taking the lower band | `[inferred]` from the presentation and test-program claims | See G3 |
| R7b | Partner with clinicians | important | unclear | none | discovery | No clinician or other domain-expert partnership is mentioned | `[grounded]` your intake message silent | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring or onboarding is not mentioned | `[grounded]` your intake message silent | See G2 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse. Limit: no health data and no HIPAA work. HIPAA's rules differ from consumer privacy law, for example around who may hold the data and how much of it may be used | `[grounded]` your intake message; `[generic]` on how HIPAA differs from consumer privacy law | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards, but no stated ownership of metric definitions | It's the first duty in the JD, and your answer could settle condition 2 | Defining "active subscriber" or "retention" once and getting teams to adopt it; Looker models or Snowflake views behind the dashboards; retiring conflicting definitions | A metric dictionary, a Looker model excerpt, a governance doc | `[grounded]` silence on metric-definition work; `[inferred]` that resolving it could firm up the decision |
| G2 | Mentoring (R8, important) | discovery | Nothing on mentoring or onboarding | The JD names two junior analysts to mentor | Onboarding a new analyst; regular query or analysis reviews; coaching an intern | A mentoring plan or onboarding doc | `[grounded]` silence |
| G3 | Partnering (R7a, R7b, important) | discovery | Presentations to the VP Product, but no PM-level or domain-expert partnership shown | The role turns analysis into roadmap decisions with PMs and clinicians | A test result that changed a product decision, with a named PM; a domain specialist, such as a nutritionist or culinary lead, whose judgment shaped a metric or test | A decision memo or test readout | `[grounded]` silence; `[generic]` that partnership scope is typically probed in interviews |
| G4 | Healthcare data (R9, preferred) | transferability | A consent-state model under GDPR/CCPA; no health data | A nice-to-have, but the likeliest objection to your candidacy | Any dietary, allergy or other sensitive-category data you handled | A one-page note on the consent model's design | `[inferred]` bridge from the consent-state model; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The search was not permitted, so nothing was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | None given in the pasted JD | The pay may sit above or below what a senior analyst post usually pays. It could not be calibrated here | `[inferred]` from the posting's silence | What salary band is budgeted for this role? | unresolved |
| RR3 | Several specialisms in one title, no stated decision rights | risk_signal | low | "Own product analytics… define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards…" | The role may carry accountability for metrics, experiments and BI without authority over definitions or engineering support | `[inferred]` from the JD's responsibility list against its silence on authority | What decisions does this role make on metric definitions, and what data-engineering support exists? | unresolved |
| RR4 | Team and remit named | positive_signal | — | "mentor two junior analysts" | An existing analytics function with defined junior roles suggests the team is established | `[inferred]` from the named mentee group | Do the two juniors report to this role, or is it mentoring without line management? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer and the live posting on Harborlight's own careers page before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the experimentation program: the pricing test behind the 11% retention lift, and 30+ A/B tests a year | See R3 | `[grounded]` your intake message | pending your approval |
| A3 | Frame the healthcare bridge exactly as stated: "I built our warehouse's consent-state model under GDPR/CCPA; I haven't worked with HIPAA data" | See R9; it keeps the claim to what you told me | `[grounded]` your intake message | pending your approval |
| A4 | Ask the register's verification questions, RR1 to RR4, verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app careers" was refused. It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary experimentation Looker" was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No hiring-manager name was given, so there was no query to form |

I can run the analysis again at the full research budget if search is allowed. Otherwise it stays as above.

If you want a `tuesday-dossier.md` to carry this forward, say so and I'll write it.

## Upgrade menu

- Permission to search → targets 1 and 2 run, which could clear or confirm RR1 and calibrate pay for RR2.
- Your CV → presentation gaps could surface, and edits would be proposed for your approval.
- A sanitized experiment readout, query, dashboard or memo → R2, R3, R4 or R5 rises to `high`.
- Your answers to G1 to G3 → R6, R7a, R7b and R8 firm up, which could move the decision from `conditional_go` to `go`.
- Your pay floor, location and other non-negotiables → hard-gate checks run instead of showing "unknown".
- The hiring manager's name → role reality's scope read, and which story to lead with for that reader.

**Questions**

G1 — Have you personally owned how a core metric, such as retention or active subscriber, is defined and maintained? That could be in Looker models, Snowflake views or a metric dictionary. What did you own, and how did other teams adopt it?

G2 — Have you mentored or onboarded other analysts, such as a new hire, an intern or a peer you reviewed? What did that involve?

G3 — Describe one decision where your analysis changed a product roadmap. Who was the PM, and did you work with a domain expert who wasn't an analyst, such as a nutritionist or culinary lead?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.