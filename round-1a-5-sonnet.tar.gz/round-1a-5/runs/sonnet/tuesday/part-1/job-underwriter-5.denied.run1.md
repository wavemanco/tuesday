Search was declined, so everything below rests on what you pasted.

## Decision snapshot

**Yes, this is worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (dbt-modelled warehouse in BigQuery) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9 — a credible bridge, its limit named; R10, R11 — nothing stated either way yet.

**Opportunity ledger.** The pay sits well against the report you sent (RR5), and the stage matches the report's cohort. The open items are the live posting and company details, which I could not check here (RR1), and the missing hiring manager (RR2). The scope reads wider than the report's one-domain norm (RR3), and the equity is unquantified (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you can work from the US (or Denver) and that the pay clears your floor — R1, R2; (2) the posting and funding details check out against the live site — RR1; (3) BigQuery is presented as the adjacent skill it is, never as experience you have — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C of $52M in February 2026 | `[grounded]` About page, as you pasted it |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years of data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | Three areas are named (ingestion, warehouse modelling, contracts). That is wider on its face than the report's "one domain's pipelines". No direct reports are mentioned | `[inferred]` JD's three areas against the report's typical scope |
| Market calibration | Report figures for Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500, and "Senior" typically means 5–8 years. The posting's $148,000 floor sits just under the median and its $166,000 top sits above the interquartile range's upper end | `[grounded]` Datawright report as provided (n=2,310); `[generic]` that these are market norms, not this employer's offer |
| Unknowns | Hiring manager and team size; equity terms; whether the data team is new or established | `[grounded]` posting names no manager and gives no equity detail |
| Contradictions | None between the pasted JD and About text. Neither was checked against the live site | `[grounded]` the two pasted texts only |

## Evidence map

Your background came as prose. That is self-report, so I capped the claims at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization were not given, so the role's term is unsettled. Confidence is `none` because there is no statement of yours to grade | `[grounded]` JD term; no candidate statement | Q1 below |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor from you, so the term is unsettled | `[grounded]` JD figure; no candidate statement | Q1 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, which sits inside the report's 5–8 year "Senior" range. Self-reported with nothing inspectable yet | `[grounded]` your background; `[grounded]` report range | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is confirmed in your words, with no artifact yet | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Confirmed and specific, with no inspectable proof yet | `[grounded]` your background | A redacted model-lineage screenshot would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement is met as written | `[grounded]` your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and in your background | `[grounded]` JD and your background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. The JD asks only for "experience", which this meets | `[grounded]` your background | A redacted suite overview would raise it to `high` |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You have not used BigQuery, but dbt plus Snowflake is close work. Limit: none of the BigQuery-specific work is exercised. Warehouse-specific details are the usual place an interview probes | `[grounded]` your statement that you have not used BigQuery; `[generic]` where interviews probe | G1 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | You did not mention ingestion work, so nothing is claimed. Airflow use may touch it, but I won't assume that | `[grounded]` background silent on ingestion; `[inferred]` the Airflow link | Q2 below |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Your tests and Great Expectations work sit near this, but no agreements with analysts were mentioned | `[grounded]` background silent; `[inferred]` adjacency | Q3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Dbt and Snowflake work, and no BigQuery use | The JD names it as the warehouse, so it is the likeliest objection to a strong profile | A small dbt project run against BigQuery on a public dataset, or any exposure at work you haven't mentioned | A repo or README of that project | `[inferred]` bridge from dbt plus Snowflake; `[generic]` that this is the likeliest objection |
| G2 | App and CRM ingestion (R10, important) | discovery | Nothing stated on ingestion | The role's first named duty | Loading product events or a CRM (Salesforce, HubSpot) into the warehouse; building or owning Airflow ingestion DAGs; handling schema drift from a source system | A DAG outline or architecture sketch | `[grounded]` background silent |
| G3 | Data contracts (R11, important) | discovery | Tests exist, and no analyst-facing agreements are stated | The JD says analysts depend on these | Agreeing column definitions or freshness expectations with analysts; dbt contracts or tests that blocked a bad release | A contract doc or tests config | `[grounded]` background silent |
| G4 | Location and pay terms (R1, R2, hard_gate) | hard_gate | No constraints from you | A failed gate would end the decision whatever the fit | Not applicable; this is a yes or no | Not applicable | `[grounded]` no candidate statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting details not checked against live sources | unknown | — | "Series C ($52M, February 2026)" | The pasted figures may be current, or the page may be dated | `[grounded]` search unavailable here; `[generic]` that pages go stale | Is this role still open, and which team would it sit in? | unresolved |
| RR2 | No hiring manager named | unknown | — | "The posting names no hiring manager" | The reporting line and team size are open | `[grounded]` your note on the posting | Who would I report to, and how many data engineers are on the team? | unresolved |
| RR3 | Scope wider than the report's norm | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One person could be carrying the whole stack | `[inferred]` three named areas against the report's "one domain's pipelines" | Which of these areas does the role own alone, and which are shared? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | The grant could be material or nominal | `[grounded]` JD gives no terms | What is the grant size, vesting schedule and latest valuation basis? | unresolved |
| RR5 | Pay sits well against market | positive_signal | — | "$148,000–$166,000" | The range brackets the report's median of $151,000 and tops its upper quartile | `[grounded]` JD against the Datawright figures you supplied | What is the band's placement for this level within the range? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the dbt project in your own terms: "built the dbt project, about 180 models, on Snowflake" | see R5 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Name the Great Expectations suite you set up, under data quality testing | see R8 | `[grounded]` your background | resume_edits_pending_approval |
| C1 | Cover-note line: "I haven't used BigQuery; I run dbt on Snowflake daily." Edit the claim to what is true before sending | see R9 | `[grounded]` your statement | pending your approval |
| Q1 | Put the verification questions of RR1–RR4 to the recruiter or interviewers, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for the company's tutoring business and funding was refused. It would have checked the posting and About text, feeding RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | The search for market pay and scope was refused. Market calibration uses the report you provided instead |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was nothing to search |

## Dossier offer

I can write this up as a `tuesday-dossier.md` if you want to keep it, and there's no pressure either way.

## Upgrade menu

- Your CV, or a redacted dbt lineage or Great Expectations screenshot → R5 and R8 move to `high`, and the edits quote your actual lines.
- A BigQuery sample project → G1's bridge narrows.
- Search access → the live-posting check (RR1), a role-family sweep, and a deeper pass (up to 5 more searches and 2 more fetches).
- The hiring manager's name → the scope read and which story to lead with.

## Questions

- **G4:** Are you US-based (or able to work from Denver), and does $148,000–$166,000 base clear your pay floor?
- **G2:** Have you owned ingesting data from an app or a CRM into the warehouse, and what was yours versus the team's?
- **G3:** Have you ever agreed definitions or freshness expectations with analysts, or enforced them with tests?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.