I've run four searches: the company, its careers page, the salary band and Tamsin Achebe. I'm now checking Quillfield's own site for the posting, then I'll write up the assessment.
**Short answer: yes, apply, but as a stretch role and on conditions. Status: `conditional_go`.**

The two things the posting leads with are the ones you haven't done. Those are the forecast (R6, `adjacent`) and billing data (R7a, `absent`). Your tooling fits well and the pay looks market-consistent. R1 and R2, the location and pay terms, are untested against your own limits.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5a · adjacent: R5b (spreadsheet modelling), R6 (Owning a forecast) · unclear: R7b (Revenue data with finance) · absent: R7a (Billing data with finance)
- `important` — direct: R8

R6 — adjacent through your monthly pipeline review, its limit named; R7a — no billing-data work to bridge from.

**Opportunity ledger.** Sound on what is visible and thin on structure. The posting did not resolve on Quillfield's own site (RR1). The post bundles CRM, billing data, reporting and forecasting with no team or success measures stated (RR2). The hiring manager's public profile is a sales-operations path (RR3). The salary is stated and sits inside the market band (RR4), but the options terms are not (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol hybrid and the pay range checked against your own limits (R1, R2); (2) the role confirmed on Quillfield's own site (RR1); (3) interview answers on who owns the forecast today and what support the post gets make the R6 and R7a stretch workable (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` Quillfield's own "About" page (self-description) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days; £61,500–£67,000 plus share options | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Scope read | CRM, billing data, reporting and forecasting folded into one "Lead" post, with no team, budget or success measures named | `[inferred]` from the posting's list of duties against its silence on resourcing |
| Market calibration | One pay guide puts UK B2B-software revenue operations leads at median £64,200 (interquartile range £57,800–£70,400, n=438). The posted range brackets that median. The guide is UK-wide, not Bristol-specific, and is a band, not this employer's offer | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting for the range |
| Hiring manager | You were told Tamsin Achebe. Her public profile lists Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The posting does not name her, and the reporting line is unconfirmed | `[grounded]` her profile page; recruiter attribution is your report |
| Unknowns | Team size; reporting line; who owns the forecast today; billing system; new post or backfill; options terms | — |
| Contradictions | The posting is on Tallyboard only. Quillfield's careers address returned no page, and a search for the role on its site returned nothing | `[grounded]` one failed fetch, one empty search |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You stated no location or schedule constraint, so there is nothing to grade the role against | `[grounded]` posting terms; no candidate constraint given | Ask G1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated, so the range cannot be checked against one | `[grounded]` posting; no candidate constraint given | Ask G1 |
| R3 | 4+ years in revenue ops, sales ops or similar analytics at a B2B software company | must_have | direct | medium | discovery | Five years in sales operations, two of them running revenue operations, is stated and specific. "Payments company" does not itself say software, so the sector wording is unconfirmed. Self-reported, nothing inspected | `[grounded]` your background; `[inferred]` that the sector wording needs confirming | G5: confirm the product was software |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, stated. No credential record inspected | `[grounded]` your statement | A Trailhead credential link would raise it |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly, stated. "Strong" is not evidenced beyond that | `[grounded]` your statement | A sanitized query or dashboard source would raise it |
| R5b | Spreadsheet modelling | must_have | adjacent | medium | transferability | Excel daily is stated. Building models, as opposed to using spreadsheets, is not. Limit: modelling not shown | `[grounded]` your statement | Ask for one example of a model you built; not in the three questions below |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and finance owned the company forecast. Limit: you have not owned the forecast or been accountable for its number | `[grounded]` your statement | G2 |
| R7a | Experience working with finance on billing data | must_have | absent | none | capability | You have never worked on billing data. This is the posting's own "own our CRM and billing data" duty | `[grounded]` your statement | G4 closure path |
| R7b | Experience working with finance on revenue data | must_have | unclear | low | discovery | Your renewal dashboards touch revenue. Whether finance used them, or you reconciled them to finance's figures, is unknown | `[grounded]` your statement; `[inferred]` that renewals are revenue-adjacent | Ask G3 |
| R8 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt "our" pipeline and renewal dashboards. Whether finance used them is not stated (see R7b) | `[grounded]` your statement | Sanitized screenshot would raise it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | No constraints stated, so both terms are unchecked | A term that fails would end the decision, whatever the fit | Any commute, relocation, office-day or pay-floor limit you hold | None; only your word | `[grounded]` no constraints given |
| G2 | Owning the forecast (R6, must_have) | transferability | Monthly pipeline review with the sales director; finance owned the company forecast | This duty is named in the posting's opening list, so the interviewer is likely to probe it | A forecast-vs-actual view; a pipeline-coverage or commit/best-case call you made; numbers you gave finance or the director for their forecast | A sanitized pipeline-review pack, a forecast-vs-actual sheet | `[grounded]` your statement; `[generic]` that a forecast-ownership requirement is usually probed |
| G3 | Revenue data with finance (R7b, must_have) | discovery | Renewal dashboards exist; finance's use of them is unstated | A yes would move R7b toward `adjacent`, a real narrowing of R7a's gap | Reconciling renewal figures to finance's numbers; month-end or quarter-end support; commission or targets built on finance's revenue figures; payments or settlement data in your own product | A dashboard screenshot, a reconciliation sheet, a note from finance | `[inferred]` from the dashboards you described; `[generic]` that this narrows the gap |
| G4 | Billing data (R7a, must_have) | capability | No billing-data work stated | The duty sits in the posting's first sentence | A closure path, not a recall: learn how subscription invoicing, credit notes and revenue recognition differ from CRM closed-won; build a small reconciliation of CRM deals to invoices | A reconciliation write-up, once built | `[generic]` closure path; `[grounded]` the gap |
| G5 | Sector wording (R3, must_have) | discovery | "B2B payments company" does not say whether the product was software | Posting asks for a B2B software company | What your employer sold and whether it was a platform or software product | Company product page, your CV wording | `[grounded]` your phrase; `[inferred]` that it needs confirming |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" (Tallyboard listing) | The role may be listed elsewhere on the site, hosted through another system, or not yet published there | `[grounded]` careers fetch returned no page; search returned nothing for the role | Can you point me to this role on Quillfield's own site? | unresolved |
| RR2 | Four duties, no team or success measures stated | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast with the CFO" | The post may be a one-person function carrying systems, data and finance reporting | `[inferred]` from the posting's duties against its silence on resourcing | Who works in this function today, who owns the forecast now, and what does success look like at 90 days and a year? | unresolved |
| RR3 | Hiring manager has a sales-operations background | positive_signal | — | You were told "the hiring manager is Tamsin Achebe" | Her path may mean she knows the jump from sales ops to a finance-facing role | `[inferred]` from her public profile; reporting line unconfirmed | Does the role report to you, and how would you see the first quarter going? | noted |
| RR4 | Salary stated and market-consistent | positive_signal | — | "£61,500–£67,000" | The range is not withheld and brackets the guide median | `[grounded]` posting; `[generic]` Ledgerline band | Is the range fixed or does the top depend on experience? | noted |
| RR5 | Share option terms unstated | unknown | — | "plus share options" | Quantity, vesting and strike terms may differ widely | `[grounded]` posting silent | What are the grant size, vesting schedule and strike price? | unresolved |

## Application plan

`resume_edits_pending_approval` — everything below is proposed; nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with two lines in your own words: "Rebuilt our pipeline and renewal dashboards" and "Run the monthly pipeline review with our sales director" | R8 and R6 are your strongest traceable evidence | `[grounded]` your statements, unchanged | pending your approval |
| E2 | Do not write or say you owned the forecast. If asked: "Finance owned the company forecast; I run the monthly pipeline review with our sales director" | Keeps R6 `adjacent` with its limit visible | `[grounded]` your statement | pending your approval |
| W1 | Optional: build a small forecast from your own sanitized pipeline data and a CRM-to-invoice reconciliation | Narrows R6 and R7a with an artifact you can show | `[inferred]` from the limits in R6 and R7a | pending your approval |
| Q1 | Ask the RR1, RR2, RR3 and RR5 questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Ask the recruiter to point you to the role on Quillfield's own site | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about), and "Quillfield careers Revenue Operations Lead", which returned nothing; fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B SaaS Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring manager row, RR3 and the positioning in the application plan |

If you'd like, I can emit this as a `tuesday-dossier.md`.

## Upgrade menu

- Your location and pay-floor limits → R1 and R2 resolve, and the decision firms up.
- Answers to G2 and G3 → R6 and R7b strengthen or hold.
- Your CV, or a Trailhead credential link, → R3 and R4 move toward `high`, and I can propose edits against it.
- A sanitized dashboard screenshot or pipeline-review pack → R8 and R6 gain an inspectable artifact.
- The recruiter's pointer to the role on Quillfield's own site → RR1 closes.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Do the Bristol hybrid terms (two office days) and the £61,500–£67,000 range work for you?
G3 — Did finance ever use your renewal dashboards, or did you reconcile them to finance's figures? What did you own?
G2 — Have you ever made or defended a forecast number, even a team-level one, and who relied on it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.