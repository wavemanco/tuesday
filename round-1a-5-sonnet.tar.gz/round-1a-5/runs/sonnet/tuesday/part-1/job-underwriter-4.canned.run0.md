I'm checking Brindlemoor's careers page. The search snippet says the role is in the Leeds office four days a week, but your JD says fully remote. That conflict could decide this.
# Job Underwriting — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Probably yes on substance, but not yet. The working-pattern term (R1) conflicts between your JD and the employer's own careers page. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · adjacent: R6b (monitor rating models)
- `preferred` — direct: R8 · adjacent: R9 (pet-insurance product)

R1 — remote versus Leeds four days a week is unresolved; R6b — you said "maintained", the JD says "monitor"; R9 — a credible bridge, its limit named.

**Opportunity ledger.** The role is live on the employer's own site and has a concrete scope (RR4). The working-pattern conflict (RR1), the unstated pay (RR2) and the unstated line-management scope (RR3) are open.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on your answer to G1 and the employer's answer to RR1.
  - If remote is a must for you and the role is Leeds-based, R1 becomes `hard_gate_fail` and the status `no_go`.
  - If you can do Leeds, or the role is remote, it becomes `conditional_go`. The conditions would be that G2 and G3 confirm R6b and R7 as you describe them, and that the pet-insurance bridge (R9) is framed as adjacent.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the posting is live on its own careers site | `[grounded]` JD header; careers page fetched |
| Mandate | "Own pricing analytics for our pet-insurance product"; reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | The JD you pasted says "Fully remote (UK)". The careers page says "Leeds office four days a week". These contradict each other and I have not resolved it (RR1) | `[grounded]` both sources quoted |
| Pay | No figure in the JD as pasted. Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612). This is the market band, not Brindlemoor's offer (RR2) | `[generic]` 2026 pay survey, read from a search snippet only; `[grounded]` JD silence on pay |
| Scope read | An individual-contributor analytics post owning one product; no reports are named | `[inferred]` from "Own pricing analytics" with no team mentioned |
| Hiring manager | Odile Varga, Director of Pricing. She spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. She was previously head of pricing analytics at Calloway Re for six years | `[grounded]` public professional profile, search snippet |
| Unknowns | Which working pattern is current; pay; whether the role has reports | — |
| Contradictions | JD versus careers page on working pattern (above) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You stated no location or working-pattern constraint, so there is no claim to grade. The two sources disagree on the term itself | `[grounded]` JD and careers page quoted; no candidate statement | G1 and RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer. Self-reported, no artifact inspected, so `medium` | `[grounded]` your background summary | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use. Specific, but no inspectable artifact | `[grounded]` your background summary | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but unprobed | `[grounded]` your background summary | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD names underwriting or actuarial leads, and this is underwriting | `[grounded]` your background summary | none |
| R6a | Build rating models | must_have | direct | medium | none | "Built" the young-driver GLM rating model, as you stated | `[grounded]` your background summary | none |
| R6b | Monitor rating models | must_have | adjacent | low | discovery | You said "maintained". That may include monitoring, but I take the lower reading until you say what the maintenance involved | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | G2 |
| R7 | Design and read price tests, and turn results into recommendations for underwriting and product | must_have | direct | medium | discovery | You ran 14 price tests with underwriting last year. "Ran" does not say whether you designed and read them. Recommendations to underwriting are covered; recommendations to product are not stated | `[grounded]` your wording; the unstated parts are open questions, not claims | G3 |
| R8 | Insurance experience (the JD says "a plus") | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background summary | none |
| R9 | Pet-insurance product knowledge (inferred from the role's product; the JD does not list it as a requirement) | preferred | adjacent | low | transferability | You have no pet work. Rating-model, test and underwriting-presentation skills carry over. Pet-specific rating factors and claims patterns would be new to you, and I would expect this to come up in interview | `[inferred]` from the product named in the JD against your stated history; `[generic]` that rating factors differ by product line | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says fully remote and the careers page says Leeds four days a week. Your own constraint is unstated | It decides between `no_go` and a go. Wording cannot solve a term you cannot meet | Not applicable: this is a term you meet or do not | None; your own answer, then the employer's | `[grounded]` the two sources; `[inferred]` that your answer decides the status |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" is stated, but not what was checked, how often, or what happened when something moved | A must-have at `adjacent`, and the hiring manager's published talk topic is monitoring | Actual-versus-expected tracking by rating factor; a recurring model performance pack; drift or loss-ratio alerts; a refit or factor change triggered by monitoring | A sanitized monitoring pack, an actual-versus-expected report, a change log | `[grounded]` your wording; `[grounded]` the public talk topic |
| G3 | Designing and reading price tests (R7, must_have) | discovery | "Ran 14 tests" does not show design, analysis, or who received the recommendations | It separates running tests from owning them, and the JD says "design and read" | Writing the test hypothesis and split; choosing sample size or holdout; reading results; a recommendation that changed a rate | A sanitized test design note or results readout | `[grounded]` your wording against the JD's wording |
| G4 | Pet-insurance knowledge (R9, preferred) | transferability | Carries over: GLM rating, price testing and underwriting presentation. The limit: none of it has touched pet products. Strengthener: a short note showing how you would adapt your young-driver rating approach to a pet book | A preferred row, but it is the product you would price | See "Carries over" and "limit" in the previous column | A one-page approach note, only if you want to write one | `[inferred]` bridge from your stated work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern conflict (see R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD copy may predate a change to office-based, the careers page may be out of date, or remote may be allowed for some candidates. None is more likely than the others on what I have | `[inferred]` from the two sources disagreeing | Is this post fully remote, or based in Leeds four days a week, and which is current? | unresolved |
| RR2 | Pay not stated | unknown | — | No salary figure in the JD as pasted | The pay may sit inside, above or below the market band in role reality | `[inferred]` from the missing figure, set against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Line-management scope unstated | unknown | — | "Senior Pricing Analyst … Own pricing analytics" | The title reads as an individual-contributor post, but whether it carries or grows into reports is unstated, and you have not managed | `[inferred]` from the title and mandate wording | Does this post have direct reports now, or is it expected to? | unresolved |
| RR4 | Live posting, named reporting line, concrete scope | positive_signal | — | "Accepting applications … reports to the Director of Pricing" | The role exists as advertised and has a defined owner | `[grounded]` careers page | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern before spending effort on the application: ask the RR1 question of the employer | See R1, RR1 | `[grounded]` the two conflicting sources | pending your approval |
| A2 | When positioning, lead with R4, R7 and R5, in your own wording: "built and maintained" the GLM, "ran 14 price tests with underwriting", "present the quarterly pricing review". Do not write "designed" or "monitored" until G2 and G3 confirm them | See R4, R5, R6b, R7 | `[grounded]` your wording | pending your approval |
| A3 | Prepare a plain account of what your model maintenance involved. The hiring manager's published talk is on monitoring rating models, which is the row R6b | See R6b, G2 | `[grounded]` public talk topic | pending your approval |
| A4 | Present the pet bridge as adjacent: skills that carry over, with the limit stated, not as pet experience | See R9, G4 | `[inferred]` from your history | pending your approval |
| A5 | Ask the RR2 and RR3 questions in the first conversation, not after an offer | See RR2, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the employer and a live posting, and surfaced the working-pattern contradiction (R1, RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). I read the snippet only. It set the market band in role reality and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). I read the snippet only. It moved the scope read and plan row A3 |

I can turn this into a `tuesday-dossier.md` if you want one to carry into later steps.

## Upgrade menu

- Your location constraint (must it be remote, or is Leeds workable?) → R1 resolves and the status moves off `hold_pending_answers`.
- The employer's answer on working pattern → RR1 closes.
- A sanitized monitoring pack or actual-versus-expected report → R6b and G2 firm up, and the confidence band can rise.
- A sanitized price-test design note or results readout → R7 and G3 firm up.
- Your pay floor and the budgeted range → RR2 closes against your floor.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Is working from home a requirement for you, and could you do Leeds four days a week if that turns out to be the real setup?

G2 — When you maintained the young-driver GLM, what did you check on a regular basis, and what happened when something moved?

G3 — For the 14 price tests, did you design them and read the results yourself, or run tests someone else designed? Did recommendations go to underwriting only, or to product as well?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.