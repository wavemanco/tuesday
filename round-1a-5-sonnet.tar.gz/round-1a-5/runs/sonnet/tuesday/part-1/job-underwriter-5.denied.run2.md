Both web searches were declined, so this runs on what you pasted (research tier L0 in effect). I'm assuming you're still evaluating, not yet applying.

## Decision snapshot

**Yes, this is worth applying to. Every must-have lands `direct` (R3, R4, R5, R6, R7, R8), the pay band is competitive, and the one real gap is BigQuery (R9). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery as the warehouse) · unclear: R10 (Data contracts), R11 (Ingestion from app and CRM)

R9 (`medium`) — a Snowflake bridge, its limit named; R10, R11 — nothing stated about them yet.

**Opportunity ledger.** The posted band straddles the report's median and runs past its upper quartile (RR2). Team size, reporting line and success measures are unstated (RR3), equity terms are unstated (RR4), and the employer and live posting were not checked against outside sources (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 work for you; (2) the posting is confirmed live on the company's own careers page, RR1; (3) the BigQuery gap is framed as adjacent Snowflake experience, never as BigQuery experience, R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About text you pasted; not checked against the live page |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years, SQL and Python, dbt and a cloud warehouse, Airflow or similar, data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; remote (US) or Denver office | `[grounded]` JD |
| Scope read | Ingestion, modelling, contracts and quality in one mandate, which may mean a platform-wide remit rather than one domain's pipelines | `[inferred]` from the JD's scope list against its silence on team size, set against the report's typical scope of one domain, no direct reports |
| Market calibration | Report (n=2,310, Senior Data Engineer, Series B–D): base median $151,000, IQR $139,000–$163,500, "Senior" typically 5–8 years. The posted low end is $3,000 under the median and the top is $2,500 over the upper quartile. The 5+ year ask fits the report's range. | `[grounded]` posting and the report you supplied; `[generic]` that these are role-family norms, not this employer's offer |
| Unknowns | Hiring manager (none named), team size, equity terms, first-year outcomes | `[grounded]` JD silent |
| Contradictions | None between the JD and the About text you pasted | `[grounded]` the two texts you pasted; live pages not checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization were not given, so the gate is not established. Confidence is `none` because no constraint of yours is on file. | `[grounded]` JD; candidate constraints not given | Q1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so the gate is not established. The band's position against the market is in RR2. | `[grounded]` JD and your report | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is self-report with no document inspected, so expect a dates probe. | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. No artifact inspected. | `[grounded]` your stated background | offer: a sanitized query or script sample would raise to `high` |
| R5 | dbt | must_have | direct | medium | none | You state building your company's dbt project, about 180 models, on Snowflake. No repository inspected. | `[grounded]` your stated background | offer: a sanitized project structure or model list would raise to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | The requirement line says "a cloud warehouse", and Snowflake is one. BigQuery is named only in the role description (R9). | `[grounded]` JD and your stated background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration, which is the tool named. No artifact inspected. | `[grounded]` your stated background | offer: a sanitized DAG would raise to `high` |
| R8 | Data quality testing | must_have | direct | medium | none | You state setting up your Great Expectations test suite. No artifact inspected. | `[grounded]` your stated background | offer: a sanitized suite excerpt would raise to `high` |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt modelling on a cloud warehouse carries over. The limit is that you have not used BigQuery, and warehouse-specific cost and tuning habits do not transfer automatically. | `[grounded]` your statement and JD; `[generic]` for the limit | see G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | A test suite is indirect context. Nothing you stated covers agreed schemas or freshness with analysts. | `[inferred]` from the Great Expectations work | see G2 |
| R11 | Ingestion from the app and CRM | important | unclear | low | discovery | Airflow implies pipelines, but your sources were not stated. | `[inferred]` from the Airflow work | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R9, important) | transferability | dbt on Snowflake, about 180 models; BigQuery never used | The posting names BigQuery as the warehouse, and a named stack is a likely screening topic | A dbt project run on a free BigQuery sandbox; reading or porting models between warehouses; querying BigQuery as a consumer | A small repo of dbt models running on BigQuery | `[grounded]` your statement; `[generic]` that a named stack gets probed |
| G2 | Data contracts (R10, important) | discovery | A test suite exists; no agreed expectations with analysts are stated | It is a named deliverable in the mandate, and an unanswered row stays at `low` | Agreeing a schema or freshness expectation with analysts; a test that blocks a breaking change; a dbt model contract | A schema file with tests, a freshness agreement, a sanitized suite excerpt | `[grounded]` JD; `[inferred]` from the stated tests |
| G3 | App and CRM ingestion (R11, important) | discovery | Airflow orchestration stated; the data sources are not | Ingestion is the first item in the mandate | Pulling from an application database, event data or a CRM export or API; custom Python loaders or a managed connector | A sanitized DAG or an architecture sketch | `[grounded]` JD; `[inferred]` from the stated Airflow work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not checked against outside sources | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The searches were declined, so nothing is confirmed or contradicted. Possible reasons for any mismatch include a stale posting, a changed role, or a posting that does not match a live hiring process. | `[generic]` pattern for any employer not yet checked, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated and competitive against the report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band straddles the report's $151,000 median and runs past its $163,500 upper quartile, so the pay is stated rather than withheld. | `[grounded]` posting and the report you supplied | What is the equity grant and vesting schedule at this level? | noted |
| RR3 | Team size, reporting line and success measures unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the main data engineer across ingestion, modelling, contracts and quality, not one domain's owner. | `[inferred]` from the JD's scope list against its silence, set against the report's typical scope | How many data engineers are on the team, who does this role report to, and what does success look like at 12 months? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The grant could be material or nominal; the posting says nothing either way. | `[grounded]` JD states no terms | What is the equity grant at this level, and what are the vesting terms? | unresolved |

## Application plan

Every row below, and any advice in it, is proposed and `pending your approval`. Rewording your resume for this role is resume-tailor's job, not done here.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the application with your own stated work: "built our dbt project on Snowflake, about 180 models", Airflow orchestration, and the Great Expectations suite you set up | R3, R5, R7, R8 are your strongest rows | `[grounded]` your statements | pending your approval |
| A2 | State the BigQuery limit plainly (six years on Snowflake, BigQuery not yet used) instead of letting a screen find it | R9, G1 | `[grounded]` your statement | pending your approval |
| W1 | A small dbt project run on a BigQuery sandbox, as a work sample | G1; narrows R9's limit without claiming experience you do not have | `[grounded]` R9 row | pending your approval |
| A3 | Confirm the posting is live on pellucidlearning.com/careers, and note the recruiter's email domain when they reach out | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1, RR3 and RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (the company, tutoring, Denver and Series C; the company's senior data engineer careers page) were both refused, so no page was read. They would have moved RR1 and role reality's contradictions row, and the upgrade menu offers the check. |
| 2. Role-family sweep | skipped | The report you supplied already holds the median, IQR, seniority range and typical scope, which fix the market calibration and RR2. |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form. |

## Dossier offer and upgrade menu

I can write this up as `tuesday-dossier.md` to carry into later steps, if you want it.

- Your CV → R3 to R8 can be checked against dated claims, and any buried evidence becomes a repositioning proposal.
- Your location, work authorization and pay floor → R1 and R2 close, and the status simplifies to `go` or `no_go`.
- A sanitized dbt, DAG or test-suite excerpt → R4, R5, R7 or R8 can rise to `high`.
- An answer to G2 or G3 → R10 or R11 firms up.
- Permission for web search → RR1 resolves, and the company and live posting are checked.
- The hiring manager's name, once known → role reality's scope read and which story the plan leads with.
- A deeper research pass (company funding and leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs, once search is allowed.

## Questions

Q1 (R1, R2) — Does the posting's location and pay work for you: US-based with US work authorization or able to be in Denver, and $148,000–$166,000 above your floor?

Q2 (G2, R10) — Have you agreed expectations with analysts for a table's schema or freshness, such as a written agreement, a dbt contract or a test that blocks changes, and what did you own?

Q3 (G3, R11) — What systems fed your pipelines (app database, event data, a CRM), and who built the extracts?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.