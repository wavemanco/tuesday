Search permission was refused, so I'm working from the posting and your background alone and labeling what that costs.

## Decision snapshot

**No, this one isn't worth pursuing. R1 and R2 are hard gates and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site Austin office five days a week), R2 (Base $70–85k against a $150k floor)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important`: unclear: R7 (Brand, PR, partnerships), R8 (Sales ops)

R3 (`medium`), R4 (`medium`) and R5 (`medium`) — direct, self-reported, no artifact inspected yet; R6, R7, R8 — your background says nothing either way.

**Opportunity ledger.** The role conflicts with both of your stated terms (RR1, RR2). It also prices a senior mandate low (RR3), folds seven functions into a team of one (RR4), expects after-hours work (RR5), leaves success undefined (RR6) and leaves equity unquantified (RR7). The employer isn't established from here (RR8). One entry runs the other way: the reporting line (RR9).

- **Hard gates:** failed: R1 (On-site Austin office five days a week), R2 (Base $70–85k against a $150k floor); met: none.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1 would have to allow remote work, and R2's base would have to reach $150k or more. Either change alone leaves the other gate failing. I'm asking no questions this turn, because no answer from you could move R1 or R2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; not checked against any outside source (see Evidence status) |
| Mandate | Own revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | Austin office, five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Pay | $70–85k base plus "meaningful equity upside"; equity not quantified | `[grounded]` posting |
| Success measures | "Success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | Seven functions with no named team or budget is a wide mandate for one person | `[inferred]` from the function list set against "team of one" and the absence of any budget language |
| Market calibration | Not available. The role-family sweep did not run, so there is no band to set the $70–85k against | `[grounded]` posting figure only; no `[generic]` band claimed |
| Unknowns | Budget, hiring plan, equity terms, decision rights, what the board line means in practice | `[inferred]` from the posting's silence |
| Contradictions | None inside the posting. It was not compared with a careers page | `[grounded]` posting read; comparison not run |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the limit, which is specific and your own. The fit fails because the posting rules out remote work in terms and you rule out relocating | `[grounded]` posting quote and your stated constraint | Only the employer changing terms or you changing the constraint resolves it |
| R2 | Base $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The fit fails because the top of the posted range sits below it. Equity is unquantified and is not base | `[grounded]` posting figure and your stated floor | Only the employer changing the band or you changing the floor resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, including growth lead and Head of Growth roles. The split of those years between leadership and individual-contributor work wasn't given. A years requirement is not a gate | `[grounded]` your background, self-reported, no artifact | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid and controlled a budget while scaling one company from $8M to $40M ARR over three years. Self-reported; no artifact inspected | `[grounded]` your background, self-reported | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Self-reported; no artifact inspected | `[grounded]` your background, self-reported | none |
| R6 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention SEO or content | `[grounded]` silence in what you gave me | Not worth a question while R1 and R2 stand |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Your background doesn't mention these | `[grounded]` silence in what you gave me | Same |
| R8 | Sales ops | important | unclear | none | discovery | Your background doesn't mention this | `[grounded]` silence in what you gave me | Same |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Silent on SEO or content | A must-have, but it cannot move the decision while R1 and R2 fail | Owning an organic channel, a content calendar or a technical SEO audit alongside paid | A traffic report or channel mix dashboard | `[grounded]` background silent |
| G2 | Brand, PR, partnerships (R7, important) | discovery | Silent on all three | Same | Co-marketing deals, affiliate or partner programs, press coverage you drove | A partner deal summary or coverage list | `[grounded]` background silent |
| G3 | Sales ops (R8, important) | discovery | Silent | Same | CRM and pipeline reporting work, lead routing, handoff rules with sales | A routing diagram or pipeline report | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site five days against a remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Incompatible with your stated non-negotiable, and the posting rules out flexing it | `[grounded]` posting quote against your stated constraint | Is any remote arrangement possible for this role? | confirmed |
| RR2 | Base below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted range cannot meet your floor | `[grounded]` posting figure against your stated floor | Is the base range fixed for this mandate? | confirmed |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | The pay may sit below what this mandate and seniority command. I can't confirm that without a market band | `[inferred]` from the posting's seniority and scope against its stated pay | How was this base range set for a seven-function mandate? | unresolved |
| RR4 | Bundled specializations with no resourcing | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles are folded into one title with no stated budget or headcount | `[inferred]` from the function list against the posting's silence on resources | What budget and headcount are committed for the first year, and which functions does an agency or contractor already cover? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than exceptional | `[inferred]` from the phrasing, which gives no limit or compensation | How often did evenings and weekends come up last quarter, and how is that time recognised? | unresolved |
| RR6 | Success undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a stated measure | `[inferred]` from the quote against the mandate's breadth | What would you want to see from this role at 90 days and at twelve months? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The grant size and terms may be small or unstated | `[inferred]` from the posting giving no figure | What is the offer as a percentage of fully diluted shares, with vesting and strike price? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Access to the top of the company is stated. Decision rights over spend are not | `[grounded]` posting states the line | Which decisions does this role make without CEO sign-off, spend included? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the posted terms | See R1, R2, RR1, RR2 | `[grounded]` map and register rows | pending your approval |
| A2 | Only if you want to test whether either term is open: a short note to the recruiter or CEO stating plainly that you need remote and a base of at least $150k, then end it if neither moves. The posting says "no exceptions" on location, so I'd expect no | See R1, R2 | `[inferred]` from the posting's wording | pending your approval |
| A3 | If you proceed anyway, put RR3 to RR7 to them verbatim before investing further | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (for the company as described, and for a live Head of Growth listing) were refused. It would have settled RR8 and checked the posting against a careers page |
| 2. Role-family sweep | unavailable | One search (for typical pay for this title and stage) was refused. It would have set the posted $70–85k against a market band in role reality and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, only "the CEO", so there was no query to form |

## Upgrade menu

- Search permission would run targets 1 and 2. That could clear or confirm RR8 and give RR3 a market band.
- A link to the live posting or the company's careers page, or the recruiter's email domain, would settle RR8 without any search.
- The CEO's name would unlock target 3 and sharpen the plan.
- The employer's written answers on remote work, base pay and equity would settle R1, R2 and RR7. Given the posting's own wording, I'd expect R1 and R2 to stay failed.

If you'd like this saved as `tuesday-dossier.md` for later, say so.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.