Web search was refused, so this assessment uses only the JD and your resume.

# Job Underwriting Assessment: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, this role isn't a waste of your time, but it's a stretch application and not a safe one. Status: `conditional_go`. R1b, the titled 3+ years of PM experience, is the real obstacle.**

**Fit ledger.**

- `must_have`: direct: R3 · adjacent: R1a (PM work without the title), R2 (shipped API or platform products) · absent: R1b (3+ years PM experience)
- `important`: direct: R4a · unclear: R4b (launches with sales and support), R5 (Agile delivery), R6 (Adoption metrics)

R1b — a literal titled-years requirement your work can only bridge through R1a; R2 — adjacent, delivery of integrations and not ownership of a product; R3 (`medium`) — confirmed on your resume, waiting on an artifact.

**Opportunity ledger.** The scope is clearly written and names a success measure (RR4). The post itself is unverified (RR1), pay and location are not stated (RR2), and the reporting line, decision rights and whether the seat is new are unknown (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the hiring side accepts your integration, discovery and roadmap-input work in place of titled PM years — R1b, action A1; (2) the employer and posting verify as described — RR1; (3) the R2 bridge is framed as adjacent and never as a shipped product — R2, R1a.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently checked |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Success measure | Adoption metrics, which the JD names but does not define | `[grounded]` JD |
| Seniority read | A mid-level, single-surface PM seat | `[inferred]` from the "3+ years" floor and one platform surface |
| Market calibration | Platform and API PM postings often value integration-side experience, and a Series B at this size may weigh titles less strictly than a larger company would. This is a pattern, and no search ran to measure it | `[generic]` role-family pattern, not a claim about Quartzline |
| Unknowns | Salary, location or remote policy, reporting line, decision rights, new seat or backfill | `[grounded]` absent from the JD as pasted |
| Contradictions | None within the JD and your resume | `[grounded]` the two documents only; no careers page was checked |

## Evidence map

Your prose background is treated as resume-equivalent, so `medium` is the ceiling on this first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | PM work: discovery with partners, specs, roadmap input | must_have | adjacent | medium | transferability | You ran scoping workshops, wrote requirements documents and ran quarterly roadmap-input sessions for product. Those are the same activities. The limit is that nothing says you owned prioritization or the roadmap, and your work ran through client engagements and not a standing product squad | `[grounded]` your resume lines | G1 |
| R1b | 3+ years product management experience (JD label: must-have) | must_have | absent | none | transferability | You confirmed you have never held a PM title. This is a length-of-experience requirement, not a gate, so it is graded on fit and gap like any other row. Whether equivalent work counts is the employer's call, and the JD doesn't say. R1a is the bridge, with its limit. Titled-years requirements are commonly read literally, which is a pattern and not a fact about Quartzline | `[grounded]` your statement and the JD quote; `[generic]` on literal screening | A1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the integration playbook. That is delivery and enablement of an API product, and your resume doesn't say you designed, versioned or launched one. An unconfirmed lead from an earlier conversation prompts G2 and supports nothing here | `[grounded]` your resume lines | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture across 30+ engagements. The claim is specific but self-reported, with no artifact yet | `[grounded]` your resume lines | Offer a sanitized playbook excerpt to raise it to `high` |
| R4a | Stakeholder management with engineering and customers | important | direct | medium | none | You coordinated your engineers, the client's engineers and product managers on custom builds | `[grounded]` your resume line | none |
| R4b | Coordinating launches with sales and support | important | unclear | low | discovery | The resume is silent on sales and support. Go-lives are adjacent but not evidence of this | `[grounded]` resume silence | G3, G4 |
| R5 | Agile delivery | important | unclear | low | discovery | You coordinated engineers on builds, but no cadence, sprints or backlog work is stated | `[grounded]` resume silence | G3, G4 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | The resume states no metrics work. The earlier-conversation note is an unconfirmed lead, so it is a question and not evidence | `[grounded]` resume silence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ownership of prioritization (R1a, R1b) | transferability | Roadmap-input sessions and requirements documents, with no statement of who decided what was built | It is the strongest honest bridge across the titled-years gap | Choosing which client requests went to product first; writing the business case for a custom build; saying no to a client request; phasing a build | A requirements document or roadmap-input summary, sanitized | `[grounded]` resume silence on decisions; `[generic]` that titled-years requirements are commonly screened first |
| G2 | Shipped-product and adoption evidence (R2, R6) | discovery | An unconfirmed note about an internal request-triage tool | A confirmed, owned, adopted tool is the nearest thing to a shipped product with adoption metrics, and it would move R2 and R6 | Building or specifying a tool, workflow or integration template others adopted; tracking its usage | A one-pager, screenshot, README or usage numbers | `[grounded]` memory lead, unconfirmed |
| G3 | Agile delivery (R5) | discovery | No method or cadence stated | The JD names agile delivery with two squads | Sprint planning, backlog refinement, writing tickets or acceptance criteria for engineers | A sample ticket or a sprint-board screenshot, sanitized | `[grounded]` resume silence |
| G4 | Launch coordination with sales and support (R4b) | discovery | Go-lives are stated, and the sales and support side is not | The JD lists launches with sales and support as a responsibility | Handoffs to support at go-live; joint calls with sales on client scope | A go-live checklist from the playbook | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Nothing is known against it. The check could not run | `[grounded]` search was refused | Can you point me to this role on your careers page and tell me who the hiring manager is? | unresolved |
| RR2 | Pay and location not stated | unknown | — | The JD as pasted gives no salary or location | The band and any remote policy are unknown | `[grounded]` the JD as pasted | What is the salary band, and where is the role based or is it remote? | unresolved |
| RR3 | Authority and seat unclear | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may or may not carry decision rights over what the two squads build | `[inferred]` from the scope language against the JD's silence on reporting and authority | Who does this role report to, which roadmap decisions does it make alone, and is the seat new or a backfill? | unresolved |
| RR4 | Success measure named | positive_signal | — | "define and track adoption metrics" | Success has at least a stated direction | `[grounded]` JD | Which adoption metric does the team treat as the headline today? | noted |

## Application plan

Positioning only is covered here; a full tailoring pass for the posting is resume-tailor's job.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before a full application, ask the recruiter or a referrer whether integration-side delivery and roadmap input count toward the 3+ years | See R1b | `[grounded]` R1b; the JD is silent on equivalents | pending your approval |
| A2 | Seek a warm introduction before applying cold | Small companies often route hires through referrals, which is a pattern and not a fact about Quartzline | `[generic]` role-family pattern | pending your approval |
| P1 | Say it in your own words: "I led 30+ client integrations of our REST APIs end to end," and add plainly that this was delivery of integrations. Don't say you shipped, owned or launched a product | See R2, R1a | `[grounded]` your resume line | pending your approval |
| E1 | Move the roadmap-input sessions bullet to the top of your experience section, wording unchanged | See R1a | `[grounded]` your resume line | `resume_edits_pending_approval` |
| P2 | Don't write or say "product manager", "owned the roadmap", "shipped an API product" or "defined adoption metrics" unless G1 or G2 confirms it | See R1b, R2, R6 | `[grounded]` these rows | standing guardrail |

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation mention of an internal request-triage tool that support agents adopted. It is unconfirmed and prompts G2 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for the company and its careers page was refused. It would have checked that Quartzline and the posting exist as described (RR1) |
| 2. Role-family sweep | unavailable | The search for platform PM pay and scope was refused. It would have set the market calibration and checked pay (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- Search access (the official-site check and a pay sweep) → RR1 closes, RR2 gets a pay band, and the market calibration becomes measured.
- An answer to G1 → R1a's bridge narrows, or its limit is confirmed.
- The triage tool confirmed, plus one artifact such as a one-pager, screenshot or usage numbers → R2 and R6 can move.
- A sanitized playbook excerpt or table of contents → R3 to `high`.
- Your full resume text, not a summary → every edit row traces to your exact words.
- A salary floor, location and remote constraints, and notice period → the hard-gates line can run real checks.
- The hiring manager's name → the scope read and which story to lead with.

I can also write this up as `tuesday-dossier.md` if you want to carry it into later rounds.

G1 — When client feedback went to product, which decisions about what to build or prioritize did you make yourself, which did you recommend, and which did the product managers make?

G2 — I have an unconfirmed note from an earlier conversation that you built an internal request-triage tool that support agents adopted. Did you build or own it, what did you personally do, how did you know it was adopted, and is there anything inspectable?

G3, G4 — In your integration work, did you take part in sprint planning or backlog refinement, write tickets or acceptance criteria for engineers, or coordinate go-lives with sales or support teams?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.