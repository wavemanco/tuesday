I fetched the live posting to check it against what you pasted. The full assessment is below.

## Decision snapshot

**Yes, this is worth applying to: R3, R4, R5, R6 and R7, the must-haves, are all `direct`. It comes with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148k–$166k)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (Data contracts), R10 (App and CRM ingestion)

R8: a credible bridge, its limit named; R9, R10: where your background is silent, so I can't tell yet.

**Opportunity ledger.** The employer and posting check out (RR4). The stated pay is in range of the market report you sent (RR1). Team scope and how mature the data stack is are unknown (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148k–$166k); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 against your own location and pay floor; (2) RR2 and RR3 are answered satisfactorily in the interview loop; (3) BigQuery is described honestly as adjacent to your Snowflake work, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring, 31 US states, Denver, founded 2016, 264 employees, Series C ($52M, February 2026) | `[grounded]` the careers page confirms the company and posting; the other facts are from the about-page text you pasted, which I did not fetch |
| Mandate | Pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` posting, fetched |
| Posting status | Live ("Accepting applications") and word-for-word the same as your paste | `[grounded]` careers page fetched |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` posting |
| Scope read | The posting names no hiring manager, team size, reports or owned domain | `[grounded]` posting silence |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" typically 5–8 years; typical scope is one domain's pipelines, no direct reports. The posted range brackets that median and its top sits above the IQR's upper bound. This is a market band, not this employer's offer | `[generic]` Datawright 2026 report (n=2,310), supplied by your recruiter and not independently checked; `[grounded]` posting figures |
| Unknowns | Who you'd report to; team size; whether the dbt project and data contracts already exist; what the equity is | — |
| Contradictions | None between the posting and your paste | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are or what you'd accept. The confidence band grades your statement of the constraint, and there isn't one yet | `[grounded]` posting; no constraint given | G1's question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't stated, so I can't say whether the range meets it | `[grounded]` posting; no constraint given | G1's question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It's confirmed prose with no inspectable artifact yet, so expect a probe on scope | `[grounded]` your background as pasted | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Limited inspectable proof | `[grounded]` your background as pasted | offer: a sanitized query or pipeline sample would raise this to `high` |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models, and Snowflake is a cloud warehouse. A model count has no inspectable artifact yet | `[grounded]` your background as pasted | offer: a sanitized project structure or lineage graph |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. Your exact role in it isn't stated, so I assert only use of it, not ownership | `[grounded]` your background as pasted | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Confirmed and specific, with no artifact yet | `[grounded]` your background as pasted | offer: a sanitized suite config or coverage summary |
| R8 | BigQuery warehouse (inferred from the role description) | important | adjacent | medium | transferability | Snowflake plus dbt is a credible bridge. Limit: you've never used BigQuery, so nothing you've done exercises it directly. Strengthener: a small dbt-on-BigQuery project | `[inferred]` requirement from "a dbt-modelled warehouse in BigQuery"; `[grounded]` your Snowflake and dbt work | G3 bridge; W1 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Your background is silent on contracts. Great Expectations tests are related but are not contracts, and I won't treat them as such | `[grounded]` background silence; `[inferred]` that the tests are only related | G2's question |
| R10 | Ingestion from the app and from CRM | important | unclear | low | discovery | Your pasted background doesn't say what sources your pipelines ingested | `[inferred]` requirement from "ingestion from our app and CRM"; `[grounded]` background silence | G2's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | Neither your location nor your pay floor is stated | A failed term would end the case whatever the fit | n/a | Your own statement | `[grounded]` no constraints given |
| G2 | Data contracts and app/CRM ingestion (R9, R10; important) | discovery | Tests and dbt are confirmed. Contracts with upstream producers or downstream analysts, and CRM or product-app sources, are not mentioned | They are two of the three things the posting says the role is for, so silence here is the likeliest interview probe | Agreeing a schema or SLA with a source-system team; ingesting Salesforce or HubSpot data; analyst-facing documented models with tests acting as the agreement | Contract docs, a source-onboarding runbook, a dbt exposures or schema file | `[grounded]` background silence; `[generic]` that roles like this probe these areas |
| G3 | BigQuery (R8; important) | transferability | Snowflake and dbt carry over. BigQuery use does not exist | It is the one named technology you haven't touched | Any dbt-on-another-warehouse work | A small dbt-bigquery project on a free sandbox | `[inferred]` bridge from your Snowflake and dbt work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated pay against market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is disclosed and brackets the report's median, though whether it is base salary, and what the equity is, are not stated | `[grounded]` posting; `[generic]` band from the supplied report | What are the equity's type, size and vesting? | noted |
| RR2 | Scope and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role could be sole owner of reporting pipelines, or one domain within a team. The posting is silent | `[inferred]` from the posting's silence; `[generic]` the report's typical-scope norm | Who does this role report to, how big is the data team, and which domains would I own? | unresolved |
| RR3 | Stack maturity unclear | unknown | — | "the data contracts our analysts depend on" | The contracts and dbt project may already exist or may need building. The phrasing suggests some exist | `[inferred]` from the posting's wording | Are the dbt project and data contracts in place today, or would I be building them? | unresolved |
| RR4 | Employer and posting verified | positive_signal | — | "Accepting applications. Senior Data Engineer — Pellucid Learning." | The posting is live on the company's own site and matches your paste. Funding and headcount are not independently verified | `[grounded]` careers page fetched | What are the interview stages and timeline? | noted |

## Application plan

**Proposed resume edits (`resume_edits_pending_approval`)**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with a dbt line in your own terms: "Built the dbt project on Snowflake, about 180 models" | see R5 | `[grounded]` your sentence, unchanged | resume_edits_pending_approval |
| E2 | Next line: "Set up the Great Expectations test suite" | see R7 | `[grounded]` your sentence, unchanged | resume_edits_pending_approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| W1 | A small dbt project on BigQuery (free sandbox) as a visible bridge | see R8, G3 | `[inferred]` strengthener | pending your approval |
| P1 | Interview framing: "My warehouse experience is Snowflake with dbt; I haven't used BigQuery yet." Say it plainly rather than minimizing it | see R8 | `[grounded]` your own statement | pending your approval |
| Q1 | Ask RR2 and RR3's questions verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live and matches your paste. Role reality's contradictions row is clear and the employer-not-established entry is not triggered. The about page was not fetched |
| 2. Role-family sweep | skipped | The pay report you pasted fixes the market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no one |

I'd like to offer the dossier file (`tuesday-dossier.md`) if you want to carry this into later steps.

## Upgrade menu

- A sanitized SQL, dbt or test-suite sample → R4, R5 and R7 to `high`.
- Your answer to G2 → R9 and R10 resolve, and the likeliest interview probe becomes a prepared answer.
- Your location and pay floor → R1 and R2 close, and the status can move to `go`.
- The hiring manager's name → role reality's scope read, and which story to lead with.
- A deeper research pass on Pellucid (leadership changes, funding news, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1 — Are you in the US and fine with remote or Denver, and is a base of $148,000–$166,000 above your floor?

G2 — Have you agreed schemas or SLAs with source-system owners or analysts (data contracts, in practice), or ingested from CRM or product-app sources? What did you own, and how did you know it worked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.