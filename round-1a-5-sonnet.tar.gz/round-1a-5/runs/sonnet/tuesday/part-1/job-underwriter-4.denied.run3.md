Web search was blocked here, so this assessment runs on your pasted JD and background alone.

## Decision snapshot

**Yes, this is worth applying to. R2, R3, R4, R6 and R7 are `direct`, and R5 is `adjacent`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (UK-based, fully remote)
- `must_have` — direct: R2, R3, R4, R6, R7 · adjacent: R5 (Monitor rating models)
- `important` — direct: R8a · unclear: R8b (Recommendations to product)
- `preferred` — direct: R9

R5 — build is evidenced, monitoring only implied by "maintained"; R8b — no product audience evidenced; R1 — location not stated.

**Opportunity ledger.** The employer could not be checked from here (RR1), pay is unstated (RR2), and decision rights over rating changes are unstated (RR3). The remit is concrete and a named manager is given (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1; (2) the employer and live posting verify (RR1); (3) R5 is either confirmed with specifics or framed as adjacent.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD does not ask for it, so never having managed anyone is not a stated gap | `[grounded]` JD silent on line management |
| Pet-insurance experience | The JD says "insurance experience a plus", not pet-specific, so motor is the same kind of experience | `[grounded]` JD wording |
| Scope read | A hands-on senior individual-contributor post. No team, budget or decision rights are stated | `[inferred]` from "Own pricing analytics" against the JD's silence on reports and authority |
| Market calibration | Not established: the salary search was refused, so no band is given | — |
| Unknowns | Salary; who signs off rating changes; team size; contract type | — |
| Contradictions | None visible within the JD; it was not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the UK (fully remote, UK) | hard_gate | unclear | low | hard_gate | Your location and right to work are not stated. A UK motor insurer employer points to the UK but does not settle it | `[grounded]` JD term; `[inferred]` from your UK employer | Confirm (question 3) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics, the last 2 as senior analyst. Self-reported, so `medium` until inspected | `[grounded]` your background | Offer: a CV with dates would firm it up |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated. The strength claim has no inspectable artifact yet, so expect a probe | `[grounded]` your background | Offer: a sanitized query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Specific, confirmed, no artifact yet | `[grounded]` your background | Offer: a sanitized model summary or factor table |
| R5 | Monitor rating models | must_have | adjacent | low | discovery | "Maintained" suggests upkeep, but monitoring of performance is not stated. Taken at the lower reading | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | Ask (question 1) |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with the underwriting team. Whether you designed or read them is not split out | `[grounded]` your background | Offer: a test write-up |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review presented to the head of underwriting. The JD's "or" is met by underwriting | `[grounded]` your background and JD wording | none |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | Tests were run with underwriting and reviewed quarterly with their head | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background names a product audience | `[grounded]` silence in your background | Ask (question 2) |
| R9 | Insurance experience (plus) | preferred | direct | medium | none | 5 years at a UK motor insurer. Pet is a different line, which the JD does not require | `[grounded]` your background and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5, must_have) | discovery | You maintained the GLM model. Nothing says how its performance was tracked | A must_have at `adjacent`; the JD names "monitor" beside "build" | Tracking actual versus expected, loss ratio or lapse by rating factor; spotting drift and triggering a refit; a regular model-health pack | A monitoring dashboard, a refit note, or a model-health slide | `[grounded]` the gap in your wording; `[generic]` that monitoring is a core part of this role family |
| G2 | Recommendations to product (R8b, important) | discovery | Underwriting is evidenced; product is not | Half of the JD's stated audience for your recommendations | A pricing proposal that went to a product or proposition team; a test result that changed a feature or a bundle | A recommendation paper or slide | `[grounded]` silence in your background |
| G3 | UK location and right to work (R1, hard_gate) | hard_gate | Not stated | A gate the inputs do not settle stays `unclear` until answered | — | — | `[grounded]` JD term; background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | JD gives no figure | The figure may sit below what a senior analyst expects, or the firm may not publish salaries | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership asserted, decision rights unstated | unknown | — | "Own pricing analytics" | The role may be accountable for analytics while rating changes are signed off elsewhere | `[inferred]` from the JD's scope language against its silence on authority | Who signs off a rating change, and what staff or tooling support does this role have? | unresolved |
| RR4 | Remit and manager clearly named | positive_signal | — | "build and monitor rating models, design and read price tests" | The remit is concrete and matches your recent work | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the young-driver GLM rating model, in your own words: built and maintained | R4 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Make the 14 price tests, run last year with the underwriting team, a standalone line | R6 | `[grounded]` your background | resume_edits_pending_approval |
| E3 | State the quarterly pricing review you present to the head of underwriting | R7 | `[grounded]` your background | resume_edits_pending_approval |
| A1 | Say plainly that you have not worked on pet insurance, and name motor GLM and test work as the bridge. Do not claim pet-specific rating knowledge | R9 | `[grounded]` your statement | pending your approval |
| A2 | If asked about line management, say you have not managed anyone. The JD does not ask for it | People management row | `[grounded]` your statement and JD | pending your approval |
| Q1 | Ask RR1 to RR4 verbatim with Odile Varga or the recruiter | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have fed role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | The search was refused. It would have fed market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | The search was refused. It would have fed the scope read and which story to lead with for Odile Varga |

I can put your results into a `tuesday-dossier.md` if you want one.

## Upgrade menu

- Allow web search (up to 5 searches and 2 fetches) → RR1 and the contradictions row resolve, a salary band fills market calibration, and the application plan is tuned to Odile Varga's public work.
- A sanitized model summary, query or notebook, or test write-up → R3, R4 and R6 can rise toward `high`.
- A monitoring pack or refit note → R5 firms up.
- A recommendation that went to a product team → R8b closes.
- Your location and right-to-work status → R1 closes.

**Questions**

1. G1 — Which parts of monitoring the young-driver GLM were yours? For example, tracking actual versus expected by factor, spotting drift, or deciding when to refit.
2. G2 — Did any test result or pricing recommendation go to a product or proposition team? What did you own, and what changed?
3. G3 — Are you based in the UK with the right to work there, with no sponsorship needed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.