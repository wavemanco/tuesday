I'm reading the prep playbook, and the invite looks like a known scam pattern, so I'll lead with that. Next I'm running a few quick company searches before I write the pack.
Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says "you deposit the cheque and send the balance on to the vendor". A fee before an interview, passport and bank details before any offer, and a cheque you deposit and then pay part of onward are known scam patterns, and this invite is very likely a scam. Hold all three (paying, sending the passport photo and bank details, and depositing the cheque) until you've checked the invite with the employer. Use contact details you find yourself on its own website or careers page, not the email address, number or replies in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md` in your working folder. It has 19 questions, five reverse questions plus one on next steps, and a section on claims it won't coach. I built it for a single 30-minute call with the office manager, since the invite doesn't say whether they'd be your manager or a peer. Expect practical scenarios (calendar clashes, travel plans, mismatched invoices) and probing on the parts of the ad your background doesn't show yet. Those are travel booking and supplier invoices: you've chased unpaid invoices, which isn't the same as processing them. I couldn't run web searches (permission was refused), so nothing in the pack is researched about the company.

Say the word and I'll play the Skeptic on B1 (the invoices question), which the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager your future manager, or a peer on the team? The answer reweights every bank.
Can you paste the ad's text? It would replace my paraphrase in the fit snapshot with the ad's own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager. Format: one 30-minute video call. Built for Aoife. Built on one assumption: the office manager's relationship to you is unknown, so the weights below use a hiring-manager prior.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether your past behaviour shows the company's published values |
| EXP | Whether your CV and message claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | A live problem from the role, scored on structure and reasoning |

No VAL or CO questions appear: no values round is documented in your material, and company research could not run (see Sources).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message, describing the ad | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Words: "I ran the appointment book for four physios." It is your own line with nothing inspected behind it, so expect a probe on it. Lead with it in those terms and add nothing about how it was run |
| F2 | "booking travel" — your message, describing the ad | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad lists it, so expect a probe. If you have booked travel for anyone, in any setting, say what you booked and for whom, in your own words; if you have not, or it was not yours, say so plainly and stay with the appointment book |
| F3 | "preparing documents in Word and Excel" — your message, describing the ad | "I'm good with Word" — your message | medium | [grounded] | discovery | Words: "I'm good with Word." The line names the tool, not the documents. Answer slot: expect a probe on which documents. If you have prepared particular kinds of document in Word, say which, in your own words; if none comes to mind, say so plainly and say what you are comfortable doing in it |
| F4 | "preparing documents in Word and Excel" — your message, describing the ad | "okay with Excel" — your message | low | [inferred] | discovery | Words: "I'm okay with Excel." Keep your own hedge. Answer slot: if you have used Excel for particular work, say what; if little, say so plainly, then say, as a plan and never as a past, what you would practise first |
| F5 | "processing supplier invoices" — your message, describing the ad | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Words: "I chased unpaid invoices." Your material says chasing unpaid invoices, not processing supplier invoices, and that gap is the pack's observation, not words for you. Answer slot: if any of the invoices you dealt with were ones the clinic owed to others, say what you did with them, in your own words; if none were, or it was not yours, say so plainly and stay with the unpaid invoices you chased |

Also from your message: "two years as a receptionist at a physiotherapy clinic" — your message.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A practical scenario on calendars, travel, documents or invoices | Highest. The ad is a list of tasks and the call is run by an office manager, so the hiring-manager prior applies; if the office manager is a peer, this drops and the Peer Evaluator comes in | Clarify, then priorities, then approach, then check, then record; think aloud; no claim about your past is needed |
| Skeptic | Quiet probing of the items your material does not reach: travel and invoices | Second. F2 and F5 are where the ad and your material meet least | Rehearse B1 until it is boring; hold what your quotes carry; say plainly what they do not |
| Conversational/Rapport | An opening "walk me through the journey" and casual questions about Word | Third. A video call of 30 minutes opens with rapport, and casual questions are still scored | Prepare a 90-second arc from your quoted lines; treat easy questions as scored |
| Data-Driven Prober | Which part was yours, what was involved, what you used | Fourth. The ad names Excel and invoices, and your lines are short enough to be probed line by line | Know what you can and cannot say about each line; say plainly when you do not know |
| Pressure/Stress | Time-boxed "why you" questions | Lowest. Nothing in your material points to a stress-style interviewer, and the call is short | Pause, restate the question, hold through two follow-ups, then concede specifically |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two colleagues each ask you to book the same slot in the same week, one for a client meeting and one for a team review. What do you do?" | CASE | [generic] | Clarify first: which meeting can move, who decides priority, how much notice each has. Then act: hold the slot for neither until you know, offer each person alternatives, tell both what you did and why, and record the decision. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the calendar requirement in F1; CASE because it asks for a decision, not a record |
| A2 | "A director must be in Dublin on Tuesday morning and back for a Wednesday afternoon meeting. How do you plan the travel booking, and what do you need to know first?" | CASE | [generic] | Ask first: which times are fixed, who approves spend, any fare or hotel policy, preferred route, and the name on the traveller's ID. Then structure it: options with trade-offs, a recommendation, confirm and send the itinerary, and a fallback if a leg changes. No claim about your past | F2 has no evidence, so a scenario is the likeliest form this requirement takes; CASE because it sets a live problem |
| A3 | "A supplier invoice arrives that does not match the order. What do you do?" | CASE | [generic] | Ask what it should match and who placed the order. Then state your steps as a plan: do not treat it as settled, check it, query it with the person who ordered and with the supplier, record what you found, and pass it to whoever approves payments. Say the principle, not a past practice | F5 is the thinnest row against a stated requirement, so expect a scenario here; CASE because it is a problem, not a history |
| A4 | "You get rough notes and are asked for a clean one-page document by end of day. How do you go about it?" | CASE | [generic] | Clarify the reader and the format. Then headings first, a draft, a check of names and figures, consistent formatting, and a line sent with it saying what you assumed. No claim about your past | F3 and F4 cover documents; a task is the usual way an interviewer tests them; CASE because it is a live problem |
| A5 | "Working remotely, how would you keep me informed during a busy week?" | CASE | [generic] | Say what you would set up as a plan: a short regular update, a list of what is done and what is waiting, and early flags on anything stuck. No claim about your past | The role is titled remote in the invite, so working arrangements are likely to come up; JD content, CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The ad says processing supplier invoices. What have you actually done with invoices?" | EXP | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I chased unpaid invoices." Say it in those words and let the interviewer ask the next question. Answer slot: if any of the invoices you dealt with were ones the clinic owed to others, say what you did with them, in your own words; if none were, or it was not yours, say so plainly and return to the unpaid invoices you chased. Hold through two follow-ups by returning to that, never by adding to it | F5 is where the ad and your material are furthest apart, so this objection arrives in some form; EXP because it tests what was actually yours, though it scores a JD requirement |
| B2 | "You have run appointments. Have you booked travel for anyone?" | JD | [grounded] "I ran the appointment book for four physios" | Answer slot: if you have booked travel for anyone, in any setting, say what and for whom, in your own words; if you have not, or it was not yours, say so plainly, and return to what your line carries: "I ran the appointment book for four physios." Then say, as a plan, how you would approach a first booking | F2 has no evidence, so the probe is likely; JD because it scores the stated requirement |
| B3 | "The ad needs Excel. How would you describe yours, and what could you do with it on day one?" | JD | [grounded] "okay with Excel" | Use your own word, which was "okay": "I'm okay with Excel." Do not upgrade it. Name, before they do, the part you would be least sure of. Answer slot: if there is particular work you have done in Excel, say what; if little, say so plainly, then say as a plan what you would practise first | F4 is the lowest-confidence row, and the ad names the tool; JD because it scores a listed skill |
| B4 | "You have been at a physiotherapy clinic. Why this move?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Selection scaffold: give the one reason for the move that you can say aloud and stand behind, tied to the work you want more of. If no clear reason comes to mind, say so plainly, then say what in the ad's list appeals to you | Motivation consistency is what a Skeptic scores, and the move is visible from the quoted line; EXP because it tests whether your story holds together |
| B5 | "Have you worked remotely before?" | JD | [generic] | Answer slot: if you have, say how it worked, in your own words; if you have not, say so plainly, then say as a plan how you would set up your working day at home | The remote title raises it; JD because it scores a term of the job |

### C. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: what you have been doing and why this job." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc in your own words, using only the beats these lines state: the two years as receptionist at the clinic, the appointment book for four physios, the unpaid invoices you chased. Close with your own reason for this role; if you do not have one you can say aloud, say so plainly and name what in the ad's list appeals to you | The usual opener of a short video call; EXP because it scores whether the story is consistent |
| C2 | "Tell me about the kinds of documents you are comfortable preparing in Word." | JD | [grounded] "I'm good with Word" | Start from your own words: "I'm good with Word." Answer slot: if you have prepared particular kinds of document, say which, in your own words; if none comes to mind, say so plainly and say what you are comfortable doing in it | F3 names the tool and not the documents, so this casual question is where it gets tested; JD because it scores a listed skill |
| C3 | "Tell me about the appointment book. How did you keep it going for four physios?" | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1 with only the beats the line states: you ran the appointment book, and it was for four physios. Tell those in your own words. Answer slot: if any part of keeping the book in order was yours to decide, say which part and how you decided; if none was, or it was not yours, say so plainly and describe how you ran it | F1 is your strongest line against the calendar requirement, so it is likeliest to be explored; EXP because it tests what was yours |
| C4 | "What was involved in chasing the unpaid invoices?" | EXP | [grounded] "chased unpaid invoices" | Say what you did in your own words, starting from "I chased unpaid invoices." Keep to what you remember doing; where you do not remember, or a part was not yours, say so plainly | F5 is the row the ad's invoice line leans on, so a friendly follow-up is likely; EXP because it tests what was yours |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Four physios: which part of that appointment book was actually yours?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the line at its own scope: "I ran the appointment book for four physios." Answer slot: if others also booked into it, say which part was yours; if all of it was yours, say so plainly. Say in your own words the part of that line you would defend least, or say you do not know how it was counted | F1 holds the one figure in your material, and a figure is a magnet for a Prober; EXP because it tests attribution |
| D2 | "What did you use to keep track of those unpaid invoices?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you kept a record or used a system for them, say what and how, in your own words; if you did not, or it was not yours, say so plainly and stay with "I chased unpaid invoices." | F5 is where an invoice question goes next; EXP because it asks for what was actually done |
| D3 | "Here is a spreadsheet of supplier invoices with amounts, dates and payment status. What do you do with it first?" | CASE | [generic] | Ask what each column means. Then check for totals that do not add up and missing dates, sort by due date and status, flag anything overdue or unmatched, and report back what you found and what you need decided. A plan, not a claim about your past | F4 and F5 meet here, so this tests both at once; CASE because it is a live problem |

### E. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with more office experience?" | EXP | [grounded] "I ran the appointment book for four physios" "I'm good with Word" "chased unpaid invoices" | Pause and restate the question. Hold what your quotes carry: "I ran the appointment book for four physios," "I'm good with Word," "I chased unpaid invoices." Hold through two follow-ups by returning to them, never by adding. Then concede specifically: say plainly whichever parts of the ad's list you have not done, and that you would learn them. Answer slot: if a follow-up asks about a part of the list, answer from what you did, or say it was not yours | The gaps in F2 and F5 are where a pressure question lands; EXP because it tests honest self-assessment under pressure |
| E2 | "We only have thirty minutes. What is the one thing you want me to remember about you?" | EXP | [grounded] "I ran the appointment book for four physios" "I'm good with Word" | Pick the one line your own words carry best, the appointment book or Word, and say it in those words. Do not use the question to claim something new | A short call invites a closing summary request; EXP because it tests precision about what you can stand behind |

## Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | A1, C3, D1 |
| booking travel | A2, B2 |
| preparing documents in Word and Excel | A4, B3, C2, D3 |
| processing supplier invoices | A3, B1, C4, D2, D3 |
| remote working (from the title) | A5, B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In a typical week, which takes most time in this role: calendars, travel, documents or invoices?" | The answer tells you which of your examples to lead with |
| R2 | "Which tools does the team use for calendars and for booking travel?" | Shows you are thinking about doing the job from the first week, and tells you what to practise |
| R3 | "How are supplier invoices handled today, and who approves them before payment?" | Shows you understand an invoice has an approval step, and shows where the role sits in it |
| R4 | "What would a good first month look like?" | Lets the interviewer say what success means and gives you something to aim at |
| R5 | "How does the team stay in touch with someone working remotely day to day?" | Shows you have thought about how remote work runs |
| R6 | "What happens after this call, and is there a further stage?" | The process question: it lets you plan the next step of your preparation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars as the ad uses the word | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says an appointment book, not calendar management as the ad words it |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: your material says chasing, not processing supplier invoices |
| Advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "I'm okay with Excel." |

## Sources

Provided documents: your message, including the email text and your description of the ad. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent:
- "Brennock Facilities Ltd company values": refused
- "Brennock Facilities Ltd interview process administrative assistant": refused
- "Brennock Facilities Ltd news": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Every call was refused. It would have fed VAL questions and a values cheat sheet, which this pack does not have |
| 2. `Brennock Facilities Ltd interview process` | unavailable | Every call was refused. It would have checked the loop; the loop here comes from the email's own words: one 30-minute video call with the office manager |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | Every call was refused. It would have fed CO questions, which this pack does not have |
| 4. interviewer name | n/a | No name was given, so there was no query to form |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad lines in your message fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the five requirement quotes become the ad's own words rather than your description of it
- The office manager's name and whether they would be your manager or a peer → persona weights reread from a public footprint, one reverse question tied to their path, and the Peer Evaluator bank if a peer
- Your answers to the slots in F2, F3, F4 and F5 → those rows move from discovery to rows with your own quoted evidence, and the matching banks regenerate
- Company values and strategy from the employer's own website or careers page, pasted in → CO and VAL questions grounded in what it publishes
- A tuesday-dossier.md from earlier work → verified evidence and prohibited claims arrive ready-made
