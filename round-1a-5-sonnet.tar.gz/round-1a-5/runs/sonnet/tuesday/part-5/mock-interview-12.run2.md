Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says successful candidates "receive a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor". A fee, passport and bank details before any offer, and a cheque you pay on from are known scam patterns, and these requests are very likely a scam. Hold all of them. Don't pay, send documents or bank details, or deposit a cheque until you've checked the invite with the employer, using contact details you find yourself on its own website or careers page. Don't use any email, number or answer from the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-5/rooms/case-12-denied-d54c6150/brennock-facilities_remote-administrative-assistant_interview_pack.md`. I built it for a single 30-minute video call with the office manager, read as a hiring-manager-style round.

- **What to expect:** The pack has 19 questions across six interviewer styles. The Skeptic and Case styles are weighted highest. Expect small live problems, such as a diary clash, a travel booking that falls through, or an invoice that doesn't match the order. Expect probing of the thinner spots in your background.
- **Biggest prep item:** Question A2, on supplier invoices. You chased unpaid invoices, which is not the same work as processing supplier invoices. Hold exactly what you said and don't stretch it.
- **Other thin spots:** The pack also covers travel booking (no experience stated) and Excel ("okay"). Say Excel at that level, and don't upgrade it.
- **Your strongest ground:** The pack coaches you to say that you ran the appointment book for four physios, and that you're good with Word. Say both in your own words.
- **Research:** My three web searches on the company were refused for lack of permission, so nothing came back. The pack uses only your invite and your description, and the Sources section lists each refused search. The company-knowledge question (C3) gives a method instead of facts.

Say the word and I'll play the Skeptic on A2, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to day to day, and did the email or ad say anything about what the call will cover? That would reweight the question banks.
Do you have the full ad text to paste? Without it, the requirement rows rest on your summary.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: one 30-minute video call, as the invite describes it. Relationship assumed: the person who runs the office day to day, read as a hiring-manager-style round.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: VAL is values alignment. EXP is a deep-dive on your own experience. JD is a stated requirement of the role. CO is knowledge of the company. CASE is a live problem.
- Provenance labels: `[grounded]` rests on your words or the ad as you described it. `[inferred]` is a derivation, named. `[generic]` is a pattern for the role with no claim about you or the employer.
- Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for you now: answer the branch that is true, in your own words.
- Highest-ROI prep: A2, the supplier-invoice question.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | presentation | Your quote already reaches the requirement in other terms: appointment book, not calendar. Words: "I ran the appointment book for four physios." Say it in your own term and let them make the link. Nothing is added about how the book was run |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the ad names travel booking, so expect a probe on it. If you have booked travel or similar bookings for anyone, say what and for whom, in your own words; if you have not, say so plainly and say how you would go about it |
| F3 | "preparing documents in Word" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | none | The quote reaches the requirement at its own scope, and it is a self-description with nothing inspected behind it, so expect a probe on which documents. Words: "I'm good with Word." Answer slot: if you prepared documents in Word at the clinic, say which; if you did not, or only outside work, say so plainly |
| F4 | "preparing documents in Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | The quote touches Excel without showing what it was used for, and its word is "okay". Words: "I'm okay with Excel." Answer slot: if you have used Excel for something specific, say what, in your own words; if the use was light, or not at work, say so plainly |
| F5 | "processing supplier invoices" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, which is not the same work as processing supplier invoices, and the words stay at chasing: "I chased unpaid invoices." Answer slot: if any invoices you dealt with were ones the clinic received from suppliers, say what you did with them; if none, or not yours, say so plainly and stay with the invoices you chased |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the thin spots: travel, Excel, supplier invoices, why leave a clinic | Highest. The relationship prior for a hiring-manager-style round is Skeptic plus Case, and F2, F4 and F5 are the thin rows | Rehearse the single most predictable objection (A2) until it is boring; bridge only from what you stated; calibrated candor over bluffing |
| Case / Strategist | Small live problems from the actual job: a diary clash, a travel booking, an invoice that looks wrong | High. Same prior; an office manager scores how you would handle the week, and a 30-minute call has room for two or three | Clarify first, then structure, then say what you would confirm and with whom; think aloud |
| Conversational | Friendly opener, journey question, casual question about Excel | Medium. Video calls open this way and 30 minutes is short, but the prior for this round does not put it first | Prepare a 90-second arc built only from your own sentences; treat casual questions about the ad's topics as scored |
| Peer Evaluator | How the two of you would work together remotely, what you need from them, disagreement | Medium. A remote assistant works closely with whoever runs the office, and the invite says the interviewer is the office manager | Propose working principles instead of pretending to know their set-up; reciprocity framing |
| Data-Driven Prober | Checking of your own work, how many bookings the book held | Low. Your material gives no headline figure, so there is little to probe | Say plainly what you do and do not know; never offer a number you did not count |
| Pressure | A time-boxed why-you challenge | Low. Nothing in the invite points to a stress format | Hold your position through two follow-ups, concede specifically, never fold on what you stated |

Loop: one 30-minute video call with the office manager, from the invite's own words. No archetype fallback is needed, and no values-style round is detected, so there is no values cheat sheet.

## Question banks

### A. Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "I'm good with Word, okay with Excel" | Pick the weakest from the ad's own list, honestly, in your own words, and say it at its scope: "I'm okay with Excel." Then a ramp plan, said as a plan and never as something already done. Answer slot: if travel booking or invoice processing is where your own experience is thinnest, say that plainly | The persona's standard stem aimed at F2, F4 and F5; JD because it scores the ad's list |
| A2 | "The role involves processing supplier invoices. What have you done on that side?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if any invoices you dealt with were ones the clinic received from suppliers, say what you did with them; if none, or not yours, say so plainly and stay with the invoices you chased. Hold through two follow-ups by returning to the chasing, never by adding to it. Then how you would learn the supplier side, said as a plan | F5 is the biggest distance between the ad and your material, so this objection will arrive in some form; JD because it scores a stated requirement |
| A3 | "Tell me about a time you arranged travel or a booking for someone else." | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Selection scaffold: pick an occasion where you arranged something for another person, with who it was for and what you arranged named exactly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or how you would handle a travel booking | F2 has no evidence, so the guidance is a scaffold with an honest branch; the theme comes from the ad's travel line |
| A4 | "How would you rate your Excel, honestly?" | JD | [inferred] "I'm good with Word, okay with Excel" | Use your own word: "I'm okay with Excel." Answer slot: if you have used it for something specific, say what; if the use was light, or not at work, say so plainly. Never upgrade okay to good or advanced | F4 is low confidence; asking you to rate yourself is how an interviewer tests a self-description; JD because Excel is in the ad |
| A5 | "Why move from a physiotherapy clinic into a remote admin role" | EXP | [generic] | Give your actual reason in one or two sentences and tie it to something in the ad that you want to do. Answer slot: say the reason that is true; nothing in this pack supplies one | A motivation-consistency probe every candidate changing setting meets; `[generic]` because it makes no claim about you |

### B. Case / Strategist (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people ask you to hold the same 10am slot for different meetings. What do you do." | CASE | [generic] | Structure it: find out which request came first and how fixed each time is, offer alternative times to the one who can move, confirm the outcome in writing to both, and keep a note of what you decided. No claim about your past is needed | A live problem from the ad's calendar line (F1) |
| B2 | "A traveller needs to be in another city on Thursday and the preferred flight is full. What do you do." | CASE | [generic] | Clarify what is fixed (the day, the meeting time, the budget, who approves), list two or three options, say which you would pick and why, and confirm with the traveller before booking. Think aloud | A live problem from the ad's travel line (F2), which your material does not cover, so the answer is a method |
| B3 | "A supplier invoice arrives and the amount does not match what was ordered. What do you do first." | CASE | [generic] | Do not pay or pass it on yet. Check it against what was ordered, ask the person who ordered it, query the difference with the supplier, record what you found, and say who approves payment. No claim about your past is needed | A live problem from the ad's invoice line (F5), set so that it asks for a method, not for experience |
| B4 | "You need a one-page summary in Word from a long Excel sheet by end of day. How do you start." | JD | [inferred] "I'm good with Word, okay with Excel" | Clarify who reads it and what they need from it, pick the figures that matter, check the totals against the sheet, then draft. Answer slot: if you have done something like this, say what; if not, say so plainly and describe your approach | Tests F3 and F4 together as one task; CASE delivery, JD content |

### C. Conversational (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc with only the beats the sentence states: two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, the unpaid invoices you chased. End on why this role, in your own reason | The biography question is scored however casual it sounds; F1 and F5 supply the beats |
| C2 | "What are you actually playing with in Excel these days" | JD | [inferred] "I'm good with Word, okay with Excel" | Answer slot: if you use Excel for something now, say what, in your own words; if you do not, say so plainly and say what you would practise first | A casual probe on a JD plus-skill, aimed at F4 |
| C3 | "What do you know about the work we do here" | CO | [generic] | Nothing in this pack can tell you what the company does. Before the call, read what it says about itself on its own website, and say in your own words what you found. Do not recite anything you cannot source | Homework depth is scored; no research ran, so the pack supplies a method only |

### D. Peer Evaluator (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You will be remote. How would you keep me across what you are working on" | JD | [generic] | Offer principles: agree a rhythm with them, short written updates, flag a blocker early. Ask which they prefer instead of assuming | The remote setting is the ad's; this tests how you would work with the person running the office |
| D2 | "Where would you want my say-so, and where would you just get on with it" | JD | [generic] | Propose a principle (check before anything that spends money or commits someone else's time, get on with routine tasks), and ask where they would draw the line | Seam-splitting, with a principle in place of a claim to know their set-up |
| D3 | "If we disagreed about how something should be done, what would happen" | VAL | [generic] | Say what you would do in a disagreement: state your view once, listen, follow their decision, and say what you saw if it mattered. Spine and tact together | The peer persona's disagreement probe; no claim about your past |

### E. Data-Driven Prober (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How do you check your own work before it goes out" | JD | [generic] | Describe your actual habit in your own words. Answer slot: if you have a routine for checking, say what it is; if you do not have a fixed one, say so plainly and say what you would put in place | A probe on care with detail, relevant to the ad's invoice and document lines |
| E2 | "Roughly how many bookings was that appointment book handling" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Answer slot: if you know roughly, give it and say it is rough; if you never counted, say so plainly and say what you do know, "I ran the appointment book for four physios". Never offer a figure you cannot repeat under a second question | F1 holds no figure, so the probe is about the book's size; the honest branch is not knowing |

### F. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you for this role" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" and "I'm good with Word, okay with Excel" | Hold what the quotes carry: two years as a receptionist, the appointment book for four physios, the unpaid invoices you chased, good with Word. If pushed on Excel, concede at its scope: "I'm okay with Excel." Do not concede or claim anything about travel or supplier invoices beyond the answer slots in A2 and A3 | Hold-then-concede on the rows the ad leans on (F1, F3, F4) |
| F2 | "How much of that clinic work was actually you" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Answer slot: say which part was yours alone and which was shared, in your own words; if it was shared with the physios or others, say so plainly. Your sentence says you ran the book and chased the invoices, and it stays there | The attribution probe; F1 and F5 are the claims it tests |

### Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars (F1) | B1, C1, E2, F1, F2 |
| booking travel (F2) | A3, B2 |
| preparing documents in Word (F3) | B4, F1 |
| preparing documents in Excel (F4) | A1, A4, B4, C2 |
| processing supplier invoices (F5) | A2, B3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like for someone in this role" | Shows you are thinking about results, and the answer tells you where to put your prep |
| R2 | "Which of the four areas, calendars, travel, documents or invoices, takes most of the week" | Tells you which of your thinner rows will matter most in practice |
| R3 | "How do supplier invoices move through the office today, and who approves them" | Shows you think about control, and gives you the process you would be learning |
| R4 | "What do you use for calendars and for the spreadsheets, and how much of that would be new to me" | Names the tools and signals you are planning your ramp-up |
| R5 | "How do you like to be updated when your assistant works remotely" | Turns D1 into a working agreement and shows you ask rather than assume |
| R6 | "What are the next steps after this call, and roughly when" | A process question that tells you how to plan your week |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says chasing unpaid invoices, not processing supplier invoices. A2's slot stays inside the chasing |
| Advanced or confident in Excel | Inflated form of F4 | F4's quote at its own scope: "I'm okay with Excel." A4's slot asks only what you have used it for |

## Sources

- Provided: the interview invitation as you pasted it, your description of the ad's duties, and your description of your background.
- Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was sent and refused (permission not granted), so nothing came back. It would have fed a values cheat sheet only if a values round were detected, and none is |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Sent and refused. The loop here rests on the invite's own words (one 30-minute video call with the office manager), so persona weights are unchanged, but documented loop detail is missing |
| 3. `Brennock Facilities Ltd strategy recent news` | unavailable | Sent and refused. It would have fed C3 and any strategy-grounded CO question; C3 is a method instead |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Administrative Assistant` JD | skipped | The ad's duties as you described them fix the fit snapshot and the JD-tagged questions |

Searches sent, with what came back:

- `Brennock Facilities Ltd values` — refused
- `Brennock Facilities Ltd interview process administrative assistant` — refused
- `Brennock Facilities Ltd strategy recent news` — refused

## Upgrade menu

- The full ad text → the five requirement rows now quoted from your description become word-for-word `[grounded]` rows, and any mid-list requirement gets a question
- Your answers to the slots in F2 to F5 → those rows get upgraded evidence and A2, A3, A4 become story-mapped instead of slot-based
- The interviewer's name → a tailored reverse question and persona weights read from their public footprint
- The company's own published pages, pasted, or search permission granted → C3 and a values or strategy section built from sources
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → strategy and organisation context for the CO questions
- Anything the office manager or the invite says about what the call will cover → coverage tuned to it
- A `tuesday-dossier.md` → verified evidence and claims to avoid carried in, so the pack is built from confirmed material
