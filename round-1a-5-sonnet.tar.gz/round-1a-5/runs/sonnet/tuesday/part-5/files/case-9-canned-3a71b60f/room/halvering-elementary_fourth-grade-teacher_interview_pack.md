# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** 45-minute panel, Thursday. Principal Dolores Vantongeren and two members of the fourth-grade team (their names were not given).
**Built as:** a building panel. No posting text was supplied, so requirements beyond the invite come from the district's own careers page and one representative fourth-grade listing, and those rows are labeled `[inferred]`.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether the claims on your CV hold up when probed |
| JD | The listed job: what it asks and whether you can do it, gaps included |
| CO | How well you know the school and district |
| CASE | A live classroom problem: structure and reasoning |

Question IDs run by persona: A Skeptic, B Peer Evaluator, C Case/Strategist, D Data-Driven Prober, E Conversational, G Values/Behavioral. The letter F is skipped so question IDs never clash with fit-snapshot rows (F1 to F9). An answer slot is an instruction for the interview, not a question for you: it asks you to say the true thing in either branch.

The single highest-ROI rehearsal in this pack is **A1**. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap on your own statement: the quote already gives the license, the endorsement, its grades and its status. Say it in those terms. Nothing was inspected here, so the status stands as your own statement, and confirming it is yours to do. The license number is left out of this pack on purpose |
| F2 | "the Fourth Grade Teacher position at Halvering Elementary School" — HR invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | Third grade is adjacent work, not fourth grade, and the words stay at that scope: "For six years I've taught third grade at a public elementary school in Joliet." Answer slot: the posting's title makes a probe on the move from third to fourth likely. If you know what changes between the grades, say it in your own words; if you do not yet, say so plainly and stay with the third-grade years you have taught |
| F3 | "the Fourth Grade Teacher position at Halvering Elementary School" — HR invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then what you would do first to learn the grade, said as a plan and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |
| F4 | "work with the grade-level team" — representative listing, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | none | Lead with the move in the quote's own terms: it was your grade level's, and you led it. The second quote sets its limit: leading a move is not a team-lead role, so the words stay "I led our grade level's move to a new reading curriculum in 2024." Your material does not say what the work involved or how it was shared, so expect a probe on it and hold at the quote |
| F5 | "plan and teach reading, writing, math, science and social studies" — representative listing, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The quote touches the requirement without showing which subjects it covered. Answer slot: the listing's five subjects make a probe on which you have taught likely. If you taught them, say which and in what setting; if some were taught by others, or not at all, say so plainly and stay with the ones you did teach |
| F6 | "differentiate instruction using assessment data" — representative listing, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent here, which is not a gap you have stated. Answer slot: the district's published belief that assessments inform teaching makes a probe likely. If you have used assessment results to change how you taught, say what you used and what you changed; if you have not, say so plainly and say what you would look at first |
| F7 | "classroom routines" — Orrinsford careers page, "How we hire teachers" | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: the careers page names routines as a panel topic. If you can name the routines you use and what each is for, say so in your own words; if your school set them, say so plainly and say which parts were yours |
| F8 | "reading instruction" — Orrinsford careers page, "How we hire teachers" | "I've run the after-school reading club for the last two years." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Your material carries a reading club and a curriculum move, not what daily reading teaching looks like, and the words stay at those scopes: "I've run the after-school reading club for the last two years." Answer slot: if you can say how you teach reading in a typical week, say it in your own words; if the club and the move are what you can speak to, say so plainly and stay with them |
| F9 | "how you work with families" and "each teacher speaks with every family each term" — Orrinsford careers page and Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The quote is email, and the belief is speaking with families, so the words stay at the email: "I write a weekly email to families." Answer slot: if any of your contact with families goes beyond the email, say what it is; if none does, say so plainly and stay with the email |

## Reading the interviewer

Only Principal Vantongeren has a public professional footprint here. The two fourth-grade team members were not named, so nothing is read about them.

| Item | What the source says | Provenance | What it suggests for prep |
|---|---|---|---|
| Career path | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] | Reading instruction is her home ground, so the reading rows (F8, F6) are where depth is most likely tested |
| Published talk | Her 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | [grounded] | Reading in grades 3 to 5 is a recurring theme of hers and may show up as questions; C2 and D1 rehearse the ground |
| Mirror opportunity | Her talk is about reading in grades 3 to 5; your F8 evidence reads "I've run the after-school reading club for the last two years." | [inferred] | Let reading be the shared ground and say your own work in its own words. Nothing in your material says you hold weekly reading conferences, so do not borrow her phrase for your own practice |

Public professional footprint only. Nothing here infers her personality.

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | The principal probing the move from third to fourth grade and the lead-role line | High. A principal on a panel carries the hiring-manager prior (Case/Strategist plus Skeptic), and F3 and F4 hold two limits you stated yourself | Rehearse A1 until it is boring; concede the limit in your own words (F3) and return to what your quotes carry; add a first-weeks plan, said as a plan |
| B. Peer Evaluator | The two fourth-grade teachers asking what you would bring to their team and need from it | High. The invite puts two team members on the panel, the peer prior is Peer Evaluator plus Prober, and the representative listing names the grade-level team (F4) | Reciprocity first: what you bring at the quote's scope (F4), then what you need; propose how planning could be shared rather than guessing how this team works |
| C. Case/Strategist | Live classroom problems built on the district's beliefs and literacy plan | Medium. The principal's hiring-manager prior includes it, and the careers page says panels ask about reading instruction, routines and families | Clarify first, then objective, approach, how you would tell it is working; think aloud |
| D. Data-Driven Prober | Close questions on the reading club, the weekly email and the subjects you have taught | Medium. The peer prior includes it, and your CV lines are short enough to be probed line by line (F5, F8, F9); no signal puts it higher | Know exactly what each of your lines does and does not say; say plainly where you did not track something |
| E. Conversational | Opening biography, a license check, a casual question about a good morning | Medium. Panels meet a candidate cold, and the careers page topics (routines, reading, families) can arrive in casual register | Pre-script a 90-second arc from E1; treat casual questions on routines as scored |
| G. Values/Behavioral | Behavioral questions mapped to the district's three published beliefs | Low. The beliefs page says they guide every hire, but no source documents a values-style round, so none is detected | Pick stories that fit the belief; where none comes to mind, say so plainly and use the nearest thing your material carries |
| Pressure | Not included | Not plausible. The invite and the research give no signal of a stress format | None needed |

The loop is one 45-minute building panel of the principal and two grade-level teachers, which matches the invite. The weights above rest on that and on the persona priors, not on a fallback archetype.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What makes you ready to teach fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" | The highest-ROI rehearsal in this pack: both stated limits meet here. Say what is true first: "For six years I've taught third grade at a public elementary school in Joliet." Concede plainly: "I've never taught fourth grade." Answer slot: if you know what changes between the two grades, say it in your own words; if you do not yet, say so plainly and say what you would do first to find out, as a plan and never as a past. Hold through two follow-ups by returning to the third-grade years, never by adding to them | F2 and F3 are where the panel is likeliest to press, and the invite's title makes the move itself the requirement; JD because it scores fit for the listed job |
| A2 | "Which part of this job would be hardest for you on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick the true answer and say it in a sentence, then give your first step. Your material carries one limit you can say in its own words: "I've never taught fourth grade." If a different part is truer for you, say that part instead, plainly. Answer slot: the first step is yours to give, as a plan; nothing here supplies it | F3 is the limit the pack can source; JD because the question scores fit including its gaps |
| A3 | "I notice you haven't been a team lead. Does that matter here?" | EXP | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Say it plainly first: "I've never been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Stop there, because leading a move is not a team-lead role and the two should not blur. Answer slot: the representative listing asks for work with the grade-level team, so a probe on how colleagues were involved is likely. If you can say how the work was shared, say it in your own words; if you cannot, or it was not shared, say so plainly and stay with the move | F4 is where the two quotes meet; EXP because it tests what was actually the candidate's role |
| A4 | "What draws you to fourth grade, and to Halvering?" | CO | [grounded] | No reason is supplied here, because the reason has to be yours. Answer slot: give your actual reasons in your own words. To show homework you may point to what the district publishes, its three beliefs (Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test) or the board's 2026–2029 literacy plan, but only one that genuinely matters to you | Motivation consistency is what the Skeptic scores; CO because the strongest answers rest on published district material |
| A5 | "Why you, over someone who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." "I've run the after-school reading club for the last two years." "I write a weekly email to families." | Sixty seconds. Concede first and briefly: "I've never taught fourth grade." Then what your material carries, in its own terms and only these: six years teaching third grade, the reading club you have run for two years, the weekly email to families. Let the panel draw the inference; do not tell them it proves readiness. Hold through two follow-ups by repeating those, not adding to them | The comparative form of F2 and F3, asked as a challenge; JD because it scores the stated requirement against other candidates |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team plans together. Where would you fit, and what would you need from us?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity framing: what you bring, then what you need. What you bring stays at the quote's scope: "I led our grade level's move to a new reading curriculum in 2024." What you need is yours to say; offer principles for how planning could be shared rather than guessing how this team works. Answer slot: if you can say how you worked with colleagues on that move, say it in your own words; if you cannot, say so plainly and stay with the line | F4 against the team requirement; JD because the representative listing names the grade-level team |
| B2 | "Tell us about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | Pick a disagreement with a named stake, what each side wanted, what you did, and how the working relationship stood afterwards; it should show spine and tact together. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers price how a hire disagrees with equals; EXP because it tests a real past; generic because no sentence of yours carries a disagreement |
| B3 | "Walk us through the move to the new reading curriculum on your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell it in the beats the sentence states: your grade level, a move to a new reading curriculum, 2024, and that you led it. Answer slot: a probe on who did what and what changed for the team is likely. If you can say how the work was shared and what you were responsible for, say it in your own words; if you did not set how it was shared, or you do not recall, say so plainly and stay with the line. Add no steps or results you have not told me | F4 and F8 are the evidence; EXP because it tests what was actually the candidate's |
| B4 | "What would you want to learn from our team in your first month?" | JD | [generic] | Name two or three things you would genuinely want to learn, each with the reason it matters to the children. Nothing here supplies them; they have to be yours | The other half of B1's reciprocity; JD because the team requirement is the listing's; generic because it asks for no past |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Every Child a Reader means no student leaves third grade without a reading plan. A fourth grader arrives in September without one. What do you do first?" | CASE | [grounded] | Clarify before structuring: say aloud what you would need to know first, such as what the child's records show and what the child can do now. Then the objective, one approach, how you would tell it is working, and what you would tell the family. The question asks about no past, so the guidance makes no claim about yours | A live problem built on the district's own published belief; CASE because it scores structure; grounded on the Mission and Beliefs page |
| C2 | "It's October. Reading levels in your class range widely. How do you run reading time?" | CASE | [inferred] | Think aloud: what information you would want first, how you would group, how you would check in, how you would change the plan. Answer slot: if you have done this, say what you used and what you changed; if you have not used assessment results this way, say so plainly and say what you would look at first | F6 and F8; CASE with a JD-derived requirement from the representative listing and the belief that assessments inform teaching |
| C3 | "The board's literacy plan brings a new grades 3–5 reading curriculum in fall 2027. What would you want to know about it, and how would you prepare?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Open with what you would ask, since you have not seen it. Answer slot: if anything from your own curriculum move applies, say what, in your own words; if nothing carries over, say so plainly and stay with your questions | F4 and F8; CO because it rests on current district strategy, grounded on the board's August 2026 plan |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about the reading club — what do you look at to see how it's going?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Start in the quote's terms: "I've run the after-school reading club for the last two years." Answer slot: the district's belief that assessments inform teaching makes a probe on what you watch for likely. If you look at anything, say what and what you changed, in your own words; if you have not tracked anything, say so plainly and say what you would look at first | F8 and F6; EXP because it tests what the candidate actually did |
| D2 | "Tell us about your weekly email to families." | EXP | [grounded] "I write a weekly email to families." | Say it at the quote's scope: "I write a weekly email to families." The district's belief is about speaking with families, and your quote says email, so expect that distinction. Answer slot: if you can say what a typical one holds and what you hear back, say it in your own words; if you have not tracked replies, say so plainly. If any contact with families goes beyond the email, say what it is; if none does, stay with the email | F9; EXP because it tests a CV line |
| D3 | "The listing covers reading, writing, math, science and social studies. Which of those have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: say which subjects you taught across the six years and in what setting, in your own words; if some were taught by others, or you did not teach them, say so plainly and stay with the ones you did. Nothing here names them for you | F5; JD because it scores a listed responsibility; the five subjects come from a representative listing, not Halvering's own |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk us through how you got here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc built only from your lines: six years teaching third grade, the reading club you have run for two years, the weekly email to families. Answer slot: why you teach, and why now, are yours; nothing here supplies them. Close on why fourth grade, in your own words | F2, F8 and F9 supply the beats; EXP because the biography question is a CV walk-through in a friendly register |
| E2 | "Remind us of your license and endorsement." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's terms: an Illinois Professional Educator License, Elementary Education endorsement for grades 1–6, active through June 30, 2029. One sentence, and treat the casual register as scored | F1; JD because it is the one requirement the invite itself states |
| E3 | "What does a good morning look like in your classroom?" | JD | [grounded] | A casual question on a topic the careers page names, so treat it as scored. Describe the routines you actually use and what each is for. Answer slot: nothing here names your routines; if some were set by your school rather than by you, say so plainly and say which parts were yours | F7; JD because the careers page lists routines as a panel topic |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Families Are Partners is one of our three beliefs. Tell us about a time you worked with a family to help a child." | VAL | [grounded] "I write a weekly email to families." | Pick a time with a child's need (no names), what you did with the family, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I write a weekly email to families.", or how you would handle it | F9; VAL because it scores a published belief |
| G2 | "Teach for Tomorrow, Not for the Test says assessments inform teaching and never replace it. Tell us about a time what you saw in a student's work changed what you taught next." | VAL | [grounded] | Pick a time with a specific observation, the change you made, and what you saw after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6; VAL because it scores a published belief |

### Requirement coverage

| Requirement or belief | Questions |
|---|---|
| License and elementary endorsement (F1) | E2 |
| The fourth-grade position (F2, F3) | A1, A2, A4, A5, B4 |
| Work with the grade-level team (F4) | A3, B1, B3 |
| The five subjects (F5) | D3 |
| Differentiate using assessment data (F6) | C2, D1, G2 |
| Classroom routines (F7) | E3 |
| Reading instruction (F8) | C1, C2, C3, D1 |
| Work with families (F9) | D2, G1 |
| Every Child a Reader | C1 |
| Families Are Partners | D2, G1 |
| Teach for Tomorrow, Not for the Test | C2, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You were a reading specialist before you became principal. What do you still carry from those years into how you run the building?" | Tied to the principal's own public path; it turns the panel from interrogation into conversation |
| R2 | "Your 2025 talk was on weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here?" | Shows you read her published work, and puts reading instruction on shared ground |
| R3 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | Reciprocity question for the two team members: it asks what helps them, not only what you need |
| R4 | "The board's literacy plan has a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team involved in getting ready?" | Shows you read the district's current plan; the answer tells you what the team will be doing |
| R5 | "Who supports a teacher who is new to fourth grade during the first term?" | Raises your stated limit as a practical question rather than an apology, and tells you what support exists |
| R6 | "How do the district's three beliefs show up in a fourth-grade classroom day to day?" | Uses the published beliefs by name; their answer shows what the school means by each |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F3 | The plain acknowledgment: "I've never taught fourth grade." With F2's quote at its own scope. No slot |
| Has been a team lead | A negative you stated, F4 | The plain acknowledgment: "I've never been a team lead." With "I led our grade level's move to a new reading curriculum in 2024" at its own scope |
| Chose, designed or rolled out the new reading curriculum | Inflated form of F4 and F8 | F4's quote at its own scope. The limit is the pack's observation, not words for you: your material says you led the move, not who chose the curriculum or what the move involved |
| Speaks with every family each term | Inflated form of F9 | F9's quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says email, not conversations |

## Sources

Provided documents: the Orrinsford Community School District HR invite, and your resume as pasted in your message. No `tuesday-dossier.md` was present.

| Search or fetch | What came back |
|---|---|
| Search: "Orrinsford Community School District mission values" | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: "Orrinsford Community School District teacher interview process panel" | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Search: "Orrinsford Community School District strategic plan news" | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: "Dolores Vantongeren principal Halvering Elementary School" | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: "fourth grade teacher job posting Illinois elementary school requirements" | https://k12jobsboard.example/listings/fourth-grade-teacher |
| Fetch: Mission and Beliefs page | The three beliefs by name, with a one-line meaning for each |
| Fetch: K12 Jobs Board fourth-grade listing | A representative listing, not Halvering's own; its responsibilities and qualifications are quoted in F4 to F6 |

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District` values | yes | The three published beliefs by name, used as raising sources for C1, C2, D2, G1 and G2. No values cheat sheet, because no source documents a values-style round |
| 2. `Orrinsford Community School District` interview process, teachers | yes | One 45-minute building panel of the principal and two grade-level teachers, topics of reading instruction, classroom routines and families; references are taken up after the panel. Fixed persona weights and F7 to F9 |
| 3. `Orrinsford Community School District` strategy and recent news | yes | The board's August 2026 literacy plan, which grounds C3 and R4 |
| 4. `Dolores Vantongeren` Halvering Elementary School | yes | Her path and 2025 talk, in Reading the interviewer, R1 and R2 |
| 5. representative `Fourth Grade Teacher` listing | yes | No posting was supplied, so the listing supplies F4 to F6 and D3, labeled `[inferred]` |

## Upgrade menu

- The posting text from Halvering or Orrinsford → F4, F5 and F6 move from `[inferred]` to `[grounded]`, and the coverage table is checked against the real list
- The names or roles of the two fourth-grade team members → a read of each and persona weights per member, plus a tailored reverse question
- Your answers to the answer slots (which subjects you taught, what you track in the reading club, how colleagues were involved in the curriculum move) → discovery rows become `[grounded]` and the guidance becomes story-mapped
- Anything HR said about what the panel will cover or a lesson to demonstrate → a build section if a deliverable was announced
- How many hours you have before Thursday → a prep schedule sized to it
- A record you can inspect for the license's status → F1 moves from `medium` toward `high`
- A `tuesday-dossier.md`, if you have one → verified evidence and ranked objections in place of the ones this pack infers
