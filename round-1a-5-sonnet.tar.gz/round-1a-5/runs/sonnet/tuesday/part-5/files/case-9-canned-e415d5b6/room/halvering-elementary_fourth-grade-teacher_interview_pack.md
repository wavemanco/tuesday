# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Orrinsford Community School District.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether what you wrote survives scrutiny, and what was actually you |
| JD | The listed job, including its gaps |
| CO | Knowledge of the district's current direction |
| CASE | A live problem set in the role |

Highest-ROI prep in this pack: A1, the fourth-grade question. It will be asked in some form, and a calm, plain answer changes the interview.

An answer slot is an instruction for the interview, not a question for you now. Where you fill one in outside the interview, the pack can be rebuilt on your answer.

## Fit snapshot

Requirements come from your invite, the district's own pages, or a typical posting for this title (labeled inferred). Evidence is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material states the kind, issuer, endorsement, status and expiry, and they match the requirement as written. Say it in those terms. This pack did not check the license record and used no license number anywhere; confirming the status and expiry read as you stated is yours to do |
| F2 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past |
| F3 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, a typical posting for this title | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The sentence does not say which subjects you taught. Answer slot: if you taught any of the five, say which and how much, in your own words; if some were taught by someone else, or not at all, say so plainly and stay with the third-grade sentence |
| F4 | "reading instruction" — Orrinsford "How we hire teachers" page | "I led our grade level's move to a new reading curriculum in 2024" — your CV, "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material shows a curriculum move you led and a club you run, with nothing inspected behind either. Words stay at those scopes: "In 2024 I led our grade level's move to a new reading curriculum." "For the last two years I've run the after-school reading club." Answer slot: reading instruction in your own classroom is not in your material. If you taught reading daily, say how, in your own words; if it was not yours to teach, say so plainly and stay with the two sentences |
| F5 | "communicate regularly with families" — K12 Jobs Board listing, a typical posting for this title | "I write a weekly email to families" — your CV | medium | [inferred] | none | The quote reaches the requirement in its own terms: you write it, weekly, to families. Lead with it as stated, because a named routine beats an adjective. Expect a probe on it, since nothing is inspected behind the line |
| F6 | "Families Are Partners: each teacher speaks with every family each term" — Orrinsford "Mission and Beliefs" page | "I write a weekly email to families" — your CV | low | [grounded] | discovery | An email is not speaking with a family, and the bridge should not be stretched. Answer slot: if you speak with families beyond the email, say how often and where, in your own words; if the email is the whole of it, say so plainly and stay with the email |
| F7 | "classroom routines" — Orrinsford "How we hire teachers" page | none given | none | [grounded] | discovery | Nothing in your material speaks to routines. Answer slot: the district names routines as a panel topic, so expect a probe. Say which routines you run and why, in your own words; if you have none to name, say so plainly and say how you would set them up |
| F8 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — Orrinsford "Mission and Beliefs" page | none given | none | [grounded] | discovery | Nothing in your material speaks to assessment. Answer slot: if assessment results have changed what you taught, say what, in your own words; if they have not, say so plainly and say how you would use them |
| F9 | "work with the grade-level team" — K12 Jobs Board listing, a typical posting for this title | "I led our grade level's move to a new reading curriculum in 2024" — your CV, "I've never been a team lead" — your message | medium | [inferred] | transferability | Your material shows a grade-level move you led, and a team lead role you have not held. Words: "In 2024 I led our grade level's move to a new reading curriculum." and "I've never been a team lead." The two are different things, and the pack keeps them apart. Answer slot: if leading the move meant working through colleagues, say how, in your own words; if it did not, say so plainly and stay with the sentence |
| F10 | "differentiate instruction using assessment data" — K12 Jobs Board listing, a typical posting for this title | none given | none | [inferred] | discovery | Nothing in your material speaks to differentiation. Answer slot: if you have adjusted instruction for different students, say what and why, in your own words; if not, say so plainly and say how you would start |

## Reading the interviewer

Only the principal is named. The two teammates are unnamed, so nothing is read for them.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022 | Illinois Principals Forum speaker page | [grounded] | She leads the building, so the A and C banks are weighted to her |
| Nine years as a reading specialist before that | Illinois Principals Forum speaker page | [grounded] | Reading is her home ground, so expect depth on reading in C4, D1 and D3 |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | Illinois Principals Forum speaker page | [grounded] | Small-group reading is a published theme of hers, so C4 rehearses it as a live problem and reverse question 2 asks about it |
| Shared professional path with you | none | [generic] | Your material carries no sentence that matches her path, so none is offered as a shared jump, and no shared background is used |

## Persona table

The panel is blended: the principal reads as a hiring manager, and the two teammates as peers.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | The principal probes the fourth-grade and team gaps | High. The hiring-manager prior is Case/Strategist plus Skeptic, and you have stated two gaps yourself (F2, F9) | Rehearse the single most predictable objection until it is boring (A1); plain acknowledgment, then a plan |
| B. Peer Evaluator | The teammates ask how you would work with them | High. Two panelists are fourth-grade teammates, the peer prior | Offer principles, not a pretended knowledge of their seam; say what you bring, not only what you need |
| C. Case/Strategist | Live problems from the role | Medium. Hiring-manager prior; the district's hiring page names reading, routines and families as panel topics | Clarify, then objective, approach, metrics, risks; think aloud |
| D. Data-Driven Prober | Teammates press on the curriculum move and the club | Medium. Peer prior, and your CV makes two specific claims | Know exactly what was yours; say plainly when you do not know |
| E. Values/Behavioral | Scenario prompts themed on the district's three beliefs | Medium. The district says the beliefs guide every hire, but no source names a values round, so none is detected | Pick a real instance; "we" for context, "I" for your part |
| G. Conversational | Opening biography and why-here | Medium. Every panel opens somewhere, and casual questions are still scored | A 90-second arc made only of sentences you wrote |

The Pressure persona is omitted: nothing in the loop sources points to a stress style for a building panel.

## Question banks

Loop: one 45-minute panel (your invite and the district's hiring page), so session mode. IDs run A to E and G, so they do not collide with fit rows.

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. How would you handle that in this role?" | JD | [grounded] "I've never taught fourth grade", "Six years teaching third grade at a public elementary school in Joliet" | The deepest rehearsal in the pack, and it stands only on these two sentences. Open with your own words: "I've never taught fourth grade." Then what you have taught, at its scope: "Six years teaching third grade at a public elementary school in Joliet." Then your plan, said as a plan and never as a past: what you will find out first, and from whom. Follow-up one is what you expect to be hardest; name it yourself, and if you do not know yet, say so plainly. Follow-up two is why a first-time fourth-grade teacher; hold by returning to the two sentences and the plan, concede the gap in the same plain words, and never widen the third-grade sentence into fourth-grade work | F2 is the stated gap and the most predictable objection, so it arrives in some form. JD because it scores whether you can do the listed job including its gap; Skeptic because it probes the mismatch |
| A2 | "A typical posting for this title lists reading, writing, math, science and social studies. Which have you taught the most, and which the least?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Say the sentence as written: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: the sentence does not say which subjects you taught, and the typical posting lists five, so expect the probe. Say which you taught and how much, in your own words; if any were taught by someone else, or not at all, say so plainly and stay with the third-grade sentence | F3 leaves subject coverage open. JD because it scores listed responsibilities; the five subjects come from a typical posting, not this school's |
| A3 | "The district says each teacher speaks with every family each term. What does that look like for you?" | VAL | [grounded] "I write a weekly email to families" | Say what you do in your own words: "I write a weekly email to families." Answer slot: the district's published belief is about speaking with families, so expect a probe past the email. If you speak with families in other ways, say how often and where; if the email is the whole of it, or no such conversations happened, say so plainly and return to the email | F6 is a thin bridge between an email and a conversation. VAL because it maps to the published belief Families Are Partners |
| A4 | "Why Halvering, and why now?" | EXP | [generic] | Your material states no reason for the move and none for Halvering, so this pack supplies none. Give your actual reason in your own words, one sentence for each part. Keep it consistent with everything else you say in the room | The Skeptic stem for motivation consistency; F2 means the move to fourth grade is itself part of "why now". EXP because it tests whether your story holds together |
| A5 | "Have you been a team lead?" | JD | [grounded] "I've never been a team lead", "I led our grade level's move to a new reading curriculum in 2024" | The plain acknowledgment is your own words: "I've never been a team lead." Then the one nearby sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." Do not let the second stand in for the first. Answer slot: if leading the move meant working through colleagues, say how, in your own words; if it did not, say so plainly and stay with the sentence | F9 is a gap you flagged yourself, and two of the panelists are the team you would join. JD because it scores the team-work requirement from a typical posting |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be working with the grade-level team. Where's the seam between your classroom and the rest of ours, and what happens when we disagree?" | JD | [inferred] "I've never taught fourth grade" | Offer principles for the seam, not a pretended knowledge of it: you have said "I've never taught fourth grade", so the honest move is to ask what the team already does before proposing anything. Say how you handle a disagreement with a colleague as a way of working. Answer slot: if you have a disagreement story from your own grade level, tell it in your own words; if you have none, say so plainly and say how you would handle one | F9, asked collegially. The seam is a Peer Evaluator stem, and JD because it scores the team-work line |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for the context and "I" only for your own part, and the sentence supports "I led" the move and nothing past it. Answer slot: if others carried parts of the move, say who did what, in your own words; if the move was yours alone, or had no shared parts, say so plainly and stay with the sentence | F4 and F9 draw on the same move. EXP because it tests attribution honesty with peers who may ask the same thing twice |
| B3 | "What would you bring to our team?" | JD | [grounded] "I've run the after-school reading club for the last two years", "I write a weekly email to families" | Say the two sentences at their scope: "I've run the after-school reading club for the last two years." "I write a weekly email to families." Add nothing about what the club does or how the email is received unless you can say it in your own words. If it fits, offer to share an example of the email | F4 and F5 are your most specific assets. JD because it scores whether the hire adds to the team |
| B4 | "What would you need from us in your first weeks?" | JD | [grounded] "I've never taught fourth grade" | Name what you need from this team as asks that make fourth-grade planning easier, in your own words, and pair each with something you offer back. The sentence "I've never taught fourth grade" is the honest reason for the asks | F2, framed as reciprocity so the gap reads as a plan. JD because it scores partnership fit for the listed role |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "In October a student in your class is reading well below grade level. Walk me through your first month." | CASE | [grounded] | Structure it: what you would ask first, the objective, your approach, how you would tell it is working, and the risks. Name the district's published belief by its name, Every Child a Reader. The question needs no claim about your past, so the guidance makes none | The live problem comes from the reading focus on the district's hiring page; it covers F4 and F10 as a decision, not a record |
| C2 | "Our board has adopted a plan for a new grades 3 to 5 reading curriculum from fall 2027. What would you want to know before fourth grade starts on it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Ask your questions first: what the curriculum is, the timeline, and what fourth grade's part is. Then one sentence of your own history, at its scope: "In 2024 I led our grade level's move to a new reading curriculum." Do not claim what you learned from it or how it went unless you can say so in your own words. The plan was adopted in August 2026, so check with the panel that it still stands as you describe it | F4 meets the district's current direction. CO because it needs the board's plan; the question and its premise come from the district's own news item |
| C3 | "How would you set up classroom routines in the first week?" | CASE | [inferred] | Name the two or three routines you would start with and why, in your own words, and how you would see whether they hold. The typical posting lists clear classroom routines, and the district's hiring page names routines as a panel topic; your material names none, so this pack names none | F7 is a gap with no evidence, so this is the live-problem form of it. The routines line comes from a typical posting, so it is labeled inferred |
| C4 | "A full class, and you want every student in a small-group reading conference each week. How do you plan the week?" | CASE | [grounded] "I've run the after-school reading club for the last two years" | Clarify first: group sizes, time blocks, what the conferences are for, how you record them. Think aloud and challenge one premise respectfully. The only past sentence you may use is the club one, at its scope, and only if it fits. The principal's published talk was on weekly reading conferences in grades 3 to 5, so expect this theme | F4, tuned to the principal's published footprint. CASE because it is a planning problem, not a record |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you led your grade level's move to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats are the ones the sentence states: your grade level, a new reading curriculum, 2024, and that you led it. Tell them in your own words. Answer slot: if leading the move meant bringing colleagues along or deciding something about the rollout, say what, in your own words; if you did not choose it, or it was decided above you, say so plainly and return to the sentence | F4 and F9 rest on this one sentence, so it gets the closest read. EXP because it tests what was actually yours |
| D2 | "What did you look at to judge how the new curriculum was going?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: the district's published belief is that assessments inform teaching, so expect a probe on how you judged the curriculum. If you looked at anything, say what, in your own words, and which part of the judging was yours; if you looked at nothing, or it was not yours to judge, say so plainly and return to the sentence. Name, before they do, the weakest assumption in whatever you describe | F8 is a gap with no evidence, and this is where an assessment probe lands. EXP because it tests what you can show for a claim |
| D3 | "Tell me about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats are the sentence's: it is after school, it is a reading club, you run it, and it has been two years. Tell them in your own words. If the panel asks for numbers or results, give your actual figure if you track one, and say plainly if you do not; this pack supplies none | F4 draws on the club. EXP because a club line is a magnet for follow-up on what it consisted of and what it produced |

### E. Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you worked with a family to support a child." | VAL | [grounded] "I write a weekly email to families" | Selection criteria: a named child or family, with no identifying details; what you did; what changed afterwards, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I write a weekly email to families." | F5 and F6 under the belief Families Are Partners. VAL because it scores behavior against a published belief |
| E2 | "Tell me about a time an assessment told you something that changed how you taught." | VAL | [grounded] | Selection criteria: a specific result, what it told you, and what you changed afterwards. If no such time comes to mind, say so plainly, then say how you would handle it. Your material has no sentence for this question, so the pack supplies none | F8 and F10 under the belief Teach for Tomorrow, Not for the Test. VAL because it scores behavior, not slogan familiarity |
| E3 | "Tell me about a time you helped a child who was behind in reading." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection criteria: one child, what you saw, what you did, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I've run the after-school reading club for the last two years." Do not describe the club as an intervention unless you can say so in your own words | F4 under the belief Every Child a Reader. VAL because it asks for a specific decision, not the value name |

### G. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey, and what brings you to Halvering." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet", "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years" | A 90-second arc of three beats, each a sentence you wrote: the six years of third grade in Joliet, the 2024 curriculum move, and the club. How you came to teaching is not in your material, so say it in one sentence of your own or leave it out. Why Halvering is your actual reason, in your own words | F2 and F4 gathered into one story. EXP because it sets the facts the panel will test later |
| G2 | "The role requires a valid Illinois Professional Educator License with an elementary endorsement. Can you tell us about yours?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as stated: kind, endorsement, status and expiry, in your own words. Have your license record to hand in case they ask for it in person; this pack never used the number | F1 is the one hard requirement in your invite, so it gets its own JD question. The answer is short because the material is specific |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 valid Illinois PEL with an elementary endorsement | G2 |
| F2 Fourth Grade Teacher position | A1, A4, B1, B4, G1 |
| F3 plan and teach five subjects | A2 |
| F4 reading instruction | C1, C2, C4, D1, D3, E3, G1 |
| F5 communicate regularly with families | B3, E1 |
| F6 speaks with every family each term | A3, E1 |
| F7 classroom routines | C3 |
| F8 assessments inform teaching | D2, E2 |
| F9 work with the grade-level team | A5, B1, B2, B3, D1 |
| F10 differentiate instruction using assessment data | C1, E2 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How has that shaped what reading looks like in a Halvering fourth-grade classroom?" | Ties to her own path and invites her to describe her work, which turns an interrogation into a conversation | [grounded] |
| R2 | "Your 2025 forum talk was on weekly reading conferences in grades 3 to 5. What does that look like day to day in fourth grade here?" | Shows you read her published work, and it puts the reading focus on her ground | [grounded] |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two teammates, and it answers B4 from their side | [generic] |
| R4 | "How does the fourth-grade team plan together, and where would a new teacher fit in?" | Shows you want to learn the team's way before proposing your own, which matches F2 | [generic] |
| R5 | "The board's plan names a new grades 3 to 5 reading curriculum from fall 2027. What would fourth-grade teachers be doing to prepare this year?" | Shows current awareness of the district without claiming to know the answer | [grounded] |
| R6 | "The district says each teacher speaks with every family each term. What does that look like in fourth grade?" | Shows you took the belief seriously, and it lets you hear what the expectation really is before F6 is tested | [grounded] |
| R7 | "What happens after the panel, and when would I hear?" | A sensible close that never leaves the reverse-question slot empty | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F2 | The plain acknowledgment: "I've never taught fourth grade." No slot |
| Has been a team lead | Negative the candidate stated, F9 | The plain acknowledgment: "I've never been a team lead." No slot |
| Led the team, or was the team lead, on the 2024 curriculum move | Inflated form of F9 | F9's quote at its own scope. The limit is the pack's observation, not words for you: your material says "led our grade level's move", not that you led the team. A5's slot stays inside the move |
| Speaks with every family each term | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says a weekly email, not conversations. A3's slot stays inside the email |

## Sources

Provided documents: your invite and the resume text you pasted. No `tuesday-dossier.md` was present. Your license number was used nowhere in this pack or in any search.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three beliefs by name; VAL themes and the E bank. No values-style round is detected, so no cheat sheet |
| 2. `{company} interview process {role family}` | yes | Confirms the single 45-minute panel and its named topics; persona weights follow the panel |
| 3. `{company} strategy` / recent news | yes | The 2026–2029 literacy plan; C2 and reverse question R5 |
| 4. `{interviewer name} {company}` | yes | The interviewer read for the principal; C4 and reverse questions R1 and R2. The two teammates are unnamed, so no query could be formed for them |
| 5. representative `{role title}` JD | yes | The inferred rows F3, F5, F9 and F10, and the typical-posting wording in A2 and C3. Only the whole sentences of the listing's responsibilities were used; its qualifications text came back cut short and is not used |

Searches sent:

- "Halvering Elementary School Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford Community School District interview process teacher panel" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan improvement priorities" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Fourth Grade Teacher elementary job description Illinois responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched:

- https://orrinsfordschools.example/about/mission-and-beliefs, read in full
- https://ilprincipalsforum.example/speakers/dolores-vantongeren, read in full

The board's plan is dated August 2026, which is within the six-month freshness window for strategy.

## Upgrade menu

- The full posting text → the inferred rows F3, F5, F9 and F10 and their questions become grounded
- Your answers to the answer slots in rows F3, F4, F6, F7, F8, F9 and F10 → those rows and the banks that draw on them are rebuilt on your own words
- The names of the two fourth-grade teammates → an interviewer read for each, and persona weights tuned to them
- Your actual reasons for moving and for Halvering → A4 and G1 stop being slots
- A recruiter or HR email about the panel → coverage of any focus area or deliverable they name
- A tuesday-dossier.md from an earlier fit review → verified evidence and risks would sharpen the prohibited list and the reverse questions
