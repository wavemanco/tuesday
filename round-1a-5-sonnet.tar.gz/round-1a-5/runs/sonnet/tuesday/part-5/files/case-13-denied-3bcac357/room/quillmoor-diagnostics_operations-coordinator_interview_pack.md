# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer and round:** Hannah Lowther, Talent Partner. Recruiter screen, 30-minute phone call, Thursday at 2pm. She rings the mobile number on your application.

**Her stated agenda (her LinkedIn message):** your salary expectations, your notice period, how the hybrid pattern would work for you and what is prompting a move. Then she tells you about the team and the next steps.

**Built on this assumption:** the advert you pasted is the JD, you gave no CV, and the company research was not available (see Sources). Everything about your past below rests on your own sentences from your message.

## How to use this pack

- Personas describe how a question arrives. Types describe what is being scored.
- Type key: VAL = behavioral or values alignment. EXP = work-experience deep-dive. JD = role or advert-driven. CO = company and strategy knowledge. CASE = hypothetical or live problem.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: it asks nothing of you here. Meet it with whichever branch is true for you.
- For a recruiter screen, the four logistics items (pay, notice, location, reason for leaving) are in bank A. Say your own words on each.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | The words stay at the quote: "I schedule deliveries for our three depots." Your material says delivery scheduling across depots, not production schedules, planning or QA. Answer slot: the advert names planning, the warehouse and QA, so expect a probe on who you coordinate with. If you worked with any of them, say which and how, in your own words; if there was no such contact, or it was not yours, say so plainly and stay with the depots |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [inferred] | discovery | The quote touches deliveries but does not say how supplier deliveries are tracked. Answer slot: the advert's tracking line makes a probe likely. If you follow supplier deliveries after an order is placed, say how, in your own words; if tracking is not part of what you do, say so plainly and stay with scheduling the depots and chasing suppliers |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | Say it at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The sentence does not say one caused the other, so the words do not either. The figure raises four slots, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Where you do not know, "I don't know how it was counted" is an honest answer |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the advert's weekly reporting line makes a probe likely. If you report on deliveries or dispatch today, say what and how often, in your own words; if you do not, say so plainly and stay with the depot scheduling you do |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | An experience-length requirement, graded like any other, and the quote reaches it. Lead with it in those words |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel. Answer slot: the advert asks for Excel confidence, so expect a probe on what the spreadsheet does. If it was Excel, say what it does, in your own words; if it was something else, or you used little of it, say so plainly and say what it was |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | The advert marks this a plus, not a requirement (the pack's observation). Words, at the quote's scope: "I've never used SAP, and we run our own in-house stock system." Answer slot: "or similar" makes a probe on the in-house system likely. If you do day-to-day work in it, say what you do, in your own words; if you do not, or it is not an ERP, say so plainly and stay with never having used SAP |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Pay is a term, and your material shows it met: your figure sits inside the advertised band (the pack's observation). Words: "I'm hoping for £42,000." Nothing added |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Location and schedule are terms, and your material shows this one met. Words: your sentence, whole, including the limit of three |

## Persona table

Loop: one 30-minute phone call with Hannah, per her own message. No other round is named, so there is no loop adjustment and no archetype fallback.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, unstructured; Hannah's four agenda items arrive as chat | High. The recruiter-screen prior is Conversational plus a light Skeptic, and her message lists four logistics topics in a friendly format. 5 questions | Treat casual questions as scored. Use your own words for pay, notice, hybrid and why you are leaving; build the biography only from the sentences quoted in A1 |
| B. Skeptic | Quiet probing of the SAP and production-schedule gaps and of why you are moving | Medium. The advert's SAP and production-schedule lines meet material with a stated SAP negative (F8) and delivery scheduling (F1). 3 questions | Rehearse B1 until it is boring: concede only what you stated, hold there |
| C. Data-Driven Prober | Probes the one figure you gave and the Excel and reporting lines | Medium. The advert asks for Excel, accurate stock records and weekly reporting, and your material has one number (F4). A recruiter may only tick these off, which keeps it from high. 3 questions | Know, and say, how the figure was counted, or say plainly that you do not know |
| D. Pressure | Time-boxes you or pushes back on SAP | Low. Nothing in Hannah's agenda suggests stress testing; it would come only if she presses on the SAP gap. 2 questions | Pause, restate the question, hold your position through two follow-ups, concede only what you stated |
| E. Case | A live problem from the role | Low. Her agenda lists no problem-solving; two generic questions are kept so the style is not new live. 2 questions | Clarify, then structure, then answer, thinking aloud |
| V. Values / Behavioral | Scenario prompts about behaviour | Low. No published values are in hand and her agenda names none. 2 questions | Pick a real instance with a named stake; if none comes to mind, say so plainly |
| P. Peer Evaluator | Seam and credit questions between teams | Low. A recruiter is not a peer, but the advert's coordinate-between-teams line is the reason to keep two. 2 questions | Propose principles for the seam rather than pretending to know it |

## Question banks

### A. Conversational (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler", "I schedule deliveries for our three depots and chase suppliers when orders slip", "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 60 to 90 second arc with only these beats: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Say the last one with "and", as your sentence does. Then give your reason for looking, in A2's words, and stop. Add no team sizes, tools or titles | The opening question of most screens, and the one where the F6, F2 and F4 evidence first gets heard. EXP because it tests whether the story survives a follow-up |
| A2 | "And what's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, kept whole. Say it in your own words as you stated it: your Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. If she follows up on it, give those words again and add nothing | Hannah's message lists it as her fourth agenda item. EXP because it scores whether your reason holds together |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot. Say "I'm hoping for £42,000." and stop. F9 notes it sits inside the advertised band. If asked what you earn now, a line you can use is: "I'd rather focus on the range for this role." Give no figure | Hannah's first agenda item. JD because pay is a listed term of the role (F9) |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot. You have not told me your notice period, so this is an instruction: give your actual notice period, in your own words, as your contract states it | Hannah's second agenda item. JD because it is a term of starting the listed job |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot. Say your sentence as you gave it: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. If she follows up, give the same words again and add nothing | Hannah's third agenda item. JD because the pattern is stated in the advert (F10) |

### B. Skeptic (weight: medium)

The highest-ROI rehearsal in this pack is B1. The advert's ERP line meets the one gap you stated in your own words, so it is the objection most likely to arrive in some form, and a boring, non-defensive answer changes the call.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "ERP experience, SAP or similar, is a plus here, and you've told me you've never used SAP. How would you handle that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | The hold is only what the quote carries: "I've never used SAP, and we run our own in-house stock system." Concede it plainly. Answer slot: "or similar" makes a probe on the in-house system likely. If you do day-to-day work in it, say what you do, in your own words; if you do not, or it is not an ERP, say so plainly and stay with never having used SAP. Then say how you would learn a new system, as a plan and never as past experience. Hold through two follow-ups by returning to the quote, never by adding to it | F8 is the one gap you stated yourself. JD because it scores a listed requirement, delivered as a Skeptic probe |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. Your day-to-day is scheduling deliveries. How does that carry across?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Say what you do in the quote's words: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinate with likely. If any of them were part of your scheduling, say which and how, in your own words; if none were, or it was not yours, say so plainly and stay with the depots | F1 is a transferability row, and this is where it gets pressed. JD because it scores the advert's headline duty |
| B3 | "Why Quillmoor, and why this role?" | JD | [generic] | A scaffold, because I have nothing from you on why this company or this sector, and the company research was not available. Say in your own words what in the advert you can speak to, picking one line you can say something real about. If nothing about the company specifically stands out yet, say so plainly, then name what in the advert you can speak to | A motivation-consistency check that sits next to A2. JD because it scores fit to the posted role; generic because it is a pattern, not a fact about this employer |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "That stock-count figure. Walk me through how it was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | State the figure as you said it: discrepancies fell by about a third over a year. Then the four slots, in your own words: how it was counted, with "I don't know how it was counted" as an honest answer; what it is sensitive to; the assumption behind it you would defend least, named before they do; which part was yours. Name no baseline, method or model you did not give | F4 holds your one headline figure, so a defend-the-number question is likely. EXP because it tests whether the number survives |
| C2 | "How do you measure whether deliveries are landing on time at the moment?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Answer slot: the advert's weekly on-time dispatch line makes this a likely probe. If you measure or report deliveries today, say what and how often, in your own words; if you do not, or it is not yours, say so plainly and stay with "I schedule deliveries for our three depots and chase suppliers when orders slip." | F5 is a discovery row with no evidence, so this is where it surfaces |
| C3 | "How confident are you in Excel, and what do you use it for?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Start from the sentence: you rebuilt your stock-count spreadsheet. Answer slot: the advert asks for Excel confidence, so expect a probe on what the spreadsheet does. If it was Excel, say what it does, in your own words; if it was something else, or you used little of it, say so plainly and say what it was. Name no feature you have not used | F7 is a discovery row, and the advert lists Excel as a requirement |

### D. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we move you forward over someone who has used SAP?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip", "Never used SAP — we run our own in-house stock system" | Pause and restate the question. Hold on what you do, in the quote's words: you schedule deliveries for three depots and chase suppliers when orders slip. Concede only what you stated: you have never used SAP. Hold through two follow-ups by returning to scheduling and chasing, and do not compare yourself to other candidates or call your in-house system equivalent unless B1's slot lets you say what you do in it | Pressure version of B1 (F8, with F2 as the held ground). JD because it scores a listed requirement |
| D2 | "That stock result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the position your sentence carries: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Do not turn "and" into "because". Answer slot: if you can say which part of the fall followed from your rebuild and which did not, say so in your own words; if you cannot separate them, or others contributed, say so plainly and return to the rebuild. Concede that specifically if pressed | F4's figure under pressure. EXP because it is an attribution probe |

### E. Case (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A key supplier tells you on Monday that a delivery will land a week late, and planning, the warehouse and QA all have work scheduled around it. What do you do first?" | CASE | [generic] | Think aloud: what you need to know first (what is affected, how firm the new date is), who hears and in what order, what the options for the schedule are, and what you record. The question needs no claim about your past, so the guidance makes none | The advert's schedule-coordination and late-order lines (F1, F2) as a live problem; generic because it is a pattern for the problem |
| E2 | "The system says 150 units of an item and the shelf count says 120. Walk me through what you'd check." | CASE | [generic] | Think aloud: separate a counting error from a recording error, work out what moved since the last count, who needs to know, and how the record gets corrected and kept right. It makes no claim about your past | The advert's stock-records line (F4) as a live problem; generic for the same reason |

### V. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a choice you made and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt on a standard values theme; no company values were available, so generic |
| V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the hard message actually landed and the relationship was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Same: a standard values theme, generic |

### P. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam between planning and the warehouse, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than claiming to know theirs: who owns the schedule, who owns a date change, how a disagreement surfaces early. Frame what each side needs from the coordinator, not only what you need | The advert's coordinate-between-teams duty (F1) asked collegially |
| P2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say "we" for context and "I" for your part. Pick a real instance if one comes to mind; if none does, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe; generic |

### Requirement coverage

| Advert requirement | Question IDs |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, E1, P1 |
| Track supplier deliveries | B2, E1 |
| Chase late orders | B2, D1, E1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | C2 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B1, D1 |
| £38,000–£44,000 | A3 |
| Hybrid: two days a week at Avonmouth | A5 |

## Reverse questions

Hannah said she will cover the team and next steps, so ask these only where she has not. If she cannot answer one, ask who can.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which system does the team use day to day for stock and scheduling, and what does onboarding look like for it?" | The advert calls SAP or similar a plus; this asks what the plus means in practice and shows you read it |
| 2 | "How are production schedules agreed today between planning, the warehouse and QA, and where would this role sit in that?" | It is the advert's headline duty, and her answer tells you how much of F1 is the job |
| 3 | "What does the weekly on-time dispatch report look like now, and who reads it?" | It shows you read the reporting line and tells you what you would be producing |
| 4 | "Is this a new post or a replacement, and who would I work most closely with?" | It shapes the day-to-day and is a natural way into the team she said she would describe |
| 5 | "What would the first month look like for the person who starts?" | It is concrete, and a rapport-style recruiter reads a specific question here as preparation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says deliveries for three depots, not production schedules. B2's slot stays inside the depots |
| Has used SAP | Negative you stated, F8 | The plain acknowledgment your sentence gives: "I've never used SAP." No slot on SAP itself |
| Cut discrepancies by a third | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the sentence gives the rebuild and the fall, and does not say one caused the other |
| Advanced Excel skills | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the sentence says spreadsheet, not Excel |
| Willing to relocate to Reading | Claim one of your quotes contradicts, A2 | Your own sentence: "the only offer is relocating to Reading, which I don't want" |

## Sources

Provided documents: the Operations Coordinator advert you pasted; Hannah Lowther's LinkedIn message; your own account of your background and plans in your message. No CV and no `tuesday-dossier.md` were provided.

Searches sent, all refused (nothing came back):

- "Quillmoor Diagnostics company values" — refused
- "Quillmoor Diagnostics Avonmouth Bristol news strategy" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

No fetches were sent. Nothing in this pack about Quillmoor comes from research: company facts are limited to what the advert says.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have named published values for the VAL questions and made B3 specific |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message already fixes the loop: one 30-minute call with her, with her agenda stated. It fixes persona weights and the loop line |
| 3. `Quillmoor Diagnostics strategy` and recent news | unavailable | The search was refused. It would have allowed a company-strategy question and a more specific B3 |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have added an interviewer read and a reverse question tied to her path |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or its bullets for this job → F3, F5 and F7 may move from discovery toward your own quoted lines, and A1's arc gets firmer
- Your actual notice period → A4 becomes a quoted logistics answer instead of an instruction
- Your answers to the slots in F1 (who you coordinate with), F3 (how deliveries are tracked), F5 (what you report), F7 (what the spreadsheet does) and F8 (what you do in the in-house system) → those rows and their bank cells regenerate on your own words
- Permission to run the company searches (values, recent news) → grounded VAL questions, a company-strategy question and a specific B3
- Permission to search Hannah's public professional footprint → an interviewer read and a reverse question tied to her path
- A `tuesday-dossier.md` from an earlier role check, if you have one → verified evidence and a named top objection; the pack does not need one
