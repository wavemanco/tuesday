# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Halvering Elementary School, Orrinsford Community School District
**Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built on:** the principal weighted as a hiring manager, the two teachers as peers. The district's own hiring page describes the process as one 45-minute building panel of the principal and two grade-level teachers, which matches your invite.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: where it quotes you, those are your own words from your CV or your message, kept at their own scope. Where your material says nothing, the pack says so and leaves an answer slot for you to fill truthfully, or a selection scaffold for you to choose from.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether what you have said about your work survives follow-up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the district and its plans |
| CASE | A live problem set in the role, scored on structure |

Labels: `[grounded]` traces to your documents or to research named in Sources; `[inferred]` is derived from a typical posting or an adjacent source; `[generic]` is a role-family pattern with no claim about Halvering or about you.

## Fit snapshot

The requirements below come from three places: your invite, the district's own pages, and one representative fourth-grade posting from a jobs board, which is not Halvering's posting. Rows built on that representative posting are `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your stated record names the license, the endorsement with its grades, and an active registration, and the invite asks for exactly those. Nothing was inspected: this pack did not check the registry, and confirming your own entry is yours to do before the panel. Say it in the quote's own terms. The license number is left out of this pack on purpose |
| F2 | "Fourth Grade Teacher" — your invite, the role title | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Nothing is added to make the gap feel smaller; the pack's own observation is that your sentence about third grade is adjacent evidence, handled in F3 |
| F3 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | transferability | The sentence carries six years of adjacent work and names no subject, so the words stay at its scope: six years teaching third grade at a public elementary school in Joliet. Answer slot: a typical posting lists five subjects, so expect a probe on which you taught. If you taught them, say which in your own words; if some were taught by someone else, or you did not teach them, say so plainly and stay with third grade |
| F4 | "Panels ask about reading instruction, classroom routines and how you work with families." — district hiring page | "I've run the after-school reading club for the last two years."; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Neither sentence says how reading is taught in your own classroom day to day: one is an after-school club, the other a curriculum move. Words stay at that scope: "I've run the after-school reading club for the last two years." Answer slot: if asked how you teach reading in class, say what you do in your own words; if there is no fixed structure, or it was set by someone else, say so plainly and stay with the two sentences |
| F5 | "no student leaves third grade without a reading plan" — district beliefs page, Every Child a Reader | none given | none | [grounded] | discovery | Your material does not show whether your students had reading plans. Answer slot: if your students left with reading plans, say how each was made and who made it, in your own words; if there was no such step, or it was not yours, say so plainly and say what you would do |
| F6 | "each teacher speaks with every family each term" — district beliefs page, Families Are Partners | "I write a weekly email to families." — your CV | medium | [grounded] | discovery | The sentence shows a weekly email and does not show conversations with each family. Words: "I write a weekly email to families." Answer slot: say how the emails reach families and what you do beyond sending them, in your own words; if the email is the whole of it, say so plainly and stay with the email |
| F7 | "assessments inform teaching and never replace it" — district beliefs page, Teach for Tomorrow, Not for the Test | none given | none | [grounded] | discovery | Your material does not show how you use assessments. Answer slot: if you have changed what you taught after seeing assessment results, say what and why, in your own words; if you have not, say so plainly and say how you would decide what to teach next |
| F8 | "keep clear classroom routines" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material does not show routines. Answer slot: if you set routines in your own classroom, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and say what you would put in place |
| F9 | "work with the grade-level team" — representative posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | The sentence already reaches team work in other terms, so the words reword only it: "Our grade level moved to a new reading curriculum in 2024, and I led that move." It says the move, not the team, and your message says you have never been a team lead, so the two stay apart. Answer slot: expect a probe on what the move involved; say what your part was and what colleagues did, in your own words |
| F10 | "a new grades 3–5 reading curriculum from fall 2027" — Orrinsford board literacy plan, search-result text | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | presentation | The district is about to do something your sentence describes in other terms, so the words reword only it: you led your grade level's move to a new reading curriculum in 2024. The pack does not say what the move achieved, because the sentence does not. The plan's wording comes from a search-result snippet, so check it on the district's site before you cite it |

## Reading the interviewer

Public professional footprint only, from one search result (a principals' forum speaker page); the page was not fetched. The two teachers on the panel are unnamed, so there is no read on them.

| Item | What the public record says | What it means for you |
|---|---|---|
| Career pattern | Dolores Vantongeren "has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist" | Reading questions are likely to go below the surface. Be exact about what you did and say plainly where you do not know |
| Published talk | Her 2025 forum talk, "Small Groups, Big Readers", "covered weekly reading conferences in grades 3 to 5" | Reading is her subject, and her talk covers grades that include fourth. Do not claim a practice you have not run; use RQ1 to ask about her view instead |
| Mirror opportunity | A shared domain, not a shared career jump: her path runs through reading, and F4 holds your sentence "I've run the after-school reading club for the last two years." | Say that sentence in its own terms when reading comes up, and let her draw any connection. Shared background beyond the profession is never a strategy |

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gap between third and fourth grade and of the team question | High, 5 questions. The principal row of the weighting starts at Case/Strategist plus Skeptic, and your own message states both gaps (F2, and the team-lead sentence behind F9) | Rehearse A1 until it is boring; bridge only from sentences you wrote; calibrated candor |
| Case / Strategist | Live problems from the classroom: a student behind in reading, how you would run reading, how you would prepare for the new curriculum | High, 4 questions. The principal row, and the district's hiring page names reading instruction and routines as panel topics | Ask one clarifying question aloud, then structure; think aloud |
| Peer Evaluator | The two teachers asking how you would work beside them and how you handle credit | Medium, 3 questions. Two grade-level teachers sit on the panel and the peer row adds collaboration probes | Reciprocity: what you bring and what you need; seam principles, not claims about their team |
| Values / Behavioral | Scenario probes themed on the district's three beliefs | Medium, 3 questions. The district says the beliefs "guide every hire", but its hiring page documents no values round, so this is themed questions, not a detected round | Choose stories your own sentences carry; where none does, say so plainly and give the plan |
| Conversational | A friendly opener such as the biography question, and a question on why this school | Medium, 3 questions. Panels open warmly and casual questions are still scored | A 90-second arc built only from your own sentences |
| Data-Driven Prober | Follow-ups on the curriculum move and the weekly email | Low, 2 questions. Your material gives no figures, so there is little to probe beyond attribution | Say what you know and what you do not |
| Pressure | One challenge on the two gaps taken together | Low, 2 questions. Nothing in the district's published process suggests a stress style | Pause, restate, concede what is true, hold the rest |

The loop is documented, not assumed: the district's hiring page establishes one 45-minute panel, so no archetype fallback applies.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your experience is in third grade. What would be the hardest part of moving up to fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Start with the plain statement, in your own words from your message: "I've never taught fourth grade." Then say what you would do first to learn the grade, as a plan and not a past: what you would find out, from whom, and in what order. Then say what you bring, in the quote's terms: six years teaching third grade at a public elementary school in Joliet. If a follow-up asks what differs about fourth grade, say what you know; if you do not know, say so plainly. Hold through two follow-ups by returning to the plan and the quote, never by describing fourth-grade teaching you have not done | F2 is the objection this panel will raise in some form, and F3 is the adjacent evidence. JD because it scores the stated role; the Skeptic delivery is quiet and persistent |
| A2 | "You haven't been a team lead. How do you see yourself fitting into a team that already has its own way of working?" | JD | [grounded] "I've never been a team lead."; "I led our grade level's move to a new reading curriculum in 2024" | Open with the plain acknowledgment from your message: "I've never been a team lead." Then your sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: expect a probe on what the move involved day to day; say what your part was and what colleagues did, in your own words; if a stage was not yours, say so plainly and return to the sentence. Then say how you would learn how this team works before proposing anything, as a plan | F9 covers the team requirement and holds the stated limit. JD because the requirement is team work; the Skeptic returns to the gap in a different wording |
| A3 | "Why fourth grade, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Selection scaffold: your material carries no reason for the move, and the pack will not write one. Pick the true reason, name one specific thing about the grade or this school that draws you, and say it in your own words in under a minute. If no clear reason comes to mind, say so plainly, then give the nearest thing your material does carry, in the quote's terms, and what you want to do next, in your own words | A motivation-consistency probe that follows from F2. EXP because it tests whether your story holds together |
| A4 | "Suppose you disagreed with how the team already teaches reading. What would you do?" | CASE | [generic] | Structure it: what you would ask first, what you would listen for, how and to whom you would raise it, and when you would let it go. The question needs no claim about your past, so the guidance makes none | A live problem on the district's named topic (F4), set against the team requirement (F9). `[generic]` because it is a pattern for the problem, not a fact about this team |
| A5 | "Which of our three beliefs would you find hardest to put into practice, and why?" | VAL | [grounded] | Selection scaffold from the district's own names: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Pick the one where you would have most to learn, name one specific thing, and say what you would do about it as a plan. If none seems hard, say so plainly and say which you would watch most closely and why. Nothing here says you have already done any of it | An honest self-assessment probe. F5, F6 and F7 are where your material is thinnest, so rehearse a candid answer. VAL because the theme is a published belief |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student in your class is well behind the rest in reading at the start of the year. Walk me through what you would do first." | CASE | [generic] | Ask one clarifying question aloud, then structure: what you want to know first, what you would try first and how you would tell whether it is helping, and how you would bring the family in. Think aloud. The question needs no claim about your past, so the guidance makes none | Reading instruction is the district's named panel topic (F4), and Every Child a Reader is its first belief (F5). `[generic]` because it is a pattern for the problem |
| B2 | "How would you organize reading in a fourth-grade classroom across a typical week?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years." | Say it as a plan, "I would", not a past. Where the 2024 move informs it, tie it to the sentence at its scope and say what your part was in your own words. Where the club informs it, say what the club is in the sentence's terms: after school, two years. Answer slot: reading instruction is a named panel topic, so expect a probe on how reading time is organized in your class today; if you have a structure, say it in your own words; if there is none, or it was set by someone else, say so plainly and say what you would put in place | F4 is thin on day-to-day reading instruction and this question finds that. JD for the stated topic, CASE for the delivery |
| B3 | "Our board has adopted a literacy plan that brings a new reading curriculum to grades 3 to 5 from fall 2027. How would you get ready to teach it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The plan is public, so do not recite it. Say what you have read of it, if you have, then what you would want to learn first, as a plan. Tie your 2024 sentence to it at its scope and say what your part was in your own words; do not say what the new curriculum contains. Answer slot: if asked what you would carry over from the 2024 move, say it in your own words; if the move taught you nothing you can name yet, say so plainly and return to the sentence | F10; the plan's wording comes from a search-result snippet, so check it on the district's site first. CO because it tests homework at the district's altitude |
| B4 | "Tell me about the routines you would put in place in your first weeks with a new class." | JD | [inferred] | Answer slot: a typical posting lists clear classroom routines and the district names routines as a panel topic, so expect a probe on which routines and why. If you have set routines in your own classroom, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and say what you would put in place. Your material carries no routine, so this pack names none | F8; `[inferred]` because the requirement comes from a typical posting and not from Halvering's own |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you want to work with the fourth-grade team week to week, and what could you bring us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity: what you bring and what you would need. What you bring: the sentence at its scope, with what your part was said in your own words. What you need: principles, not claims about how this team works, which you do not know. Say that you would ask how they plan before proposing anything, as a plan | F9; peers are pricing what a hire costs and adds. JD because it scores the team requirement |
| C2 | "Where do you draw the line between following the team's plan and doing it your way?" | CASE | [generic] | Offer seam principles, not claims about this team's seam: what you would follow without debate, what you would raise and how, and what you would do if overruled. The question needs no claim about your past, so the guidance makes none | A peer seam question on F9's requirement. `[generic]` because it is a pattern |
| C3 | "On the 2024 reading curriculum move you led, how much of it was you and how much was the team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead." | Say what you did and what colleagues did, in your own words: "we" for context, "I" for your part. The sentence says you led the move; it does not say you led the team, and your message says you have never been a team lead, so keep the two apart. Answer slot: if a part of the move was not yours, say which part and who had it; if all of it was yours, say that plainly and say what the others' part was | F9; the credit-sharing probe, premised on your own sentence. EXP because it tests attribution |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you built a relationship with a family that was hard to reach." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: pick a time with a named family situation, what you tried, and where the relationship stood at the end. Your material carries only the weekly email, so the pack supplies no family, no event and no outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, in the sentence's terms: you write a weekly email to families, and say what you would try with a family you could not reach, as a plan | Themed on Families Are Partners; F6 |
| D2 | "Families Are Partners says each teacher speaks with every family each term. How would you make that happen in your classroom?" | VAL | [grounded] "I write a weekly email to families." | A plan, "I would", not a past. The sentence you can stand on is "I write a weekly email to families." Answer slot: say how the emails reach families and what you do beyond sending them, in your own words; if the email is the whole of it, say so plainly and stay with the email, then say what you would add | F6; the premise is the district's published belief, and the guidance does not adopt it as your practice |
| D3 | "Tell me about a time an assessment told you something about a student that changed what you did next." | VAL | [grounded] | Selection scaffold: pick a time with a named assessment, what it showed and what you changed, and say it in your own words. Your material carries no assessment story, so the pack supplies none. If no such time comes to mind, say so plainly, then say how you would use assessment results to decide what to teach next, as a plan | Themed on Teach for Tomorrow, Not for the Test; F7 |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get to this point?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc built only from these four sentences, in this order and in your own words: six years in third grade in Joliet; the 2024 move at its scope; the reading club; the weekly email. Close with your own reason for fourth grade and for Halvering; the pack supplies none. Add no outcomes or numbers you did not give | The panel's likely opener; F3, F4, F6 and F9 supply the sentences |
| E2 | "Tell me about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | The beats the sentence states: a reading club, after school, run by you, for two years. Tell them in your own words. Answer slot: Every Child a Reader is a district belief, so expect a probe on who the club is for and what happens in it; say it in your own words; if a part was not yours, or the club works differently from what the probe assumes, say so plainly and stay with the sentence | F4; EXP because it tests what you did and what was yours |
| E3 | "What drew you to Halvering Elementary?" | CO | [grounded] | Use only what is published and true for you: the district's three beliefs by name and, if you have read it, the board's literacy plan. Pick the one that is real for you and say why, in your own words. Do not claim to know the school's day-to-day, which you do not. If nothing specific draws you yet, say so plainly and say what you hope to learn from the panel | CO homework from F10 and the beliefs rows; casual questions are still scored |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about the weekly email to families." | EXP | [grounded] "I write a weekly email to families." | The beats the sentence states: weekly, an email, to families. Tell them in your own words. Answer slot: expect a probe on whether families read or reply; say what you know, in your own words; if you do not know, say so plainly | F6; no figure is given, so the probe lands on attribution and knowledge, not a number |
| G2 | "What would you point to for how the 2024 reading curriculum move went?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: assessments informing teaching is a district belief and a typical posting line, so expect a probe on what you looked at afterwards. If you looked at anything, say what and what you saw, in your own words, and name the assumption you would defend least before they do. If there was no such step, or it was not yours, say so plainly and return to the sentence. No figure is supplied | F10; the weakest-assumption move is built into the slot because the premise may be false |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024" | Hold, then concede. Pause and restate the question. Concede what is true: "I've never taught fourth grade." Then say what your material carries, in its own terms: six years in third grade in Joliet, and the move at its scope. You cannot know the other candidates, so make no comparison; say what you would bring and what you would learn. Hold through two follow-ups by returning to those sentences, never by adding to them | F2; the pressure stem tests composure on the pack's biggest gap |
| H2 | "You've never taught this grade and never been a team lead. Why should the team trust your judgment?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead."; "I led our grade level's move to a new reading curriculum in 2024" | Concede both plainly, once, in the sentences above, without apology. Then answer the trust question with what you would do: how you would earn it, as a plan, and the one sentence you can stand on at its scope. Hold through two follow-ups; the concession is the strength. Never claim to lead or to know the grade | F2 and F9 together; JD because both are stated requirements |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Valid Illinois license with an elementary endorsement | none, and why: a stated record your material shows met, and a record to confirm rather than an answer to rehearse |
| F2 Fourth Grade Teacher | A1, A3, H1, H2 |
| F3 Plan and teach the core subjects | none, and why: the district's hiring page names reading instruction, routines and families as panel topics, so the other subjects rank below them; the posting text would settle it |
| F4 Reading instruction | B1, B2, E2 |
| F5 Every Child a Reader | A5, B1 |
| F6 Families Are Partners | D1, D2, G1 |
| F7 Teach for Tomorrow, Not for the Test | A5, D3, G2 |
| F8 Classroom routines | B4 |
| F9 Work with the grade-level team | A2, A4, C1, C2, C3, H2 |
| F10 New grades 3–5 reading curriculum | B3, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "You spent nine years as a reading specialist before becoming principal. What does that background make you look for in a fourth-grade reading classroom?" | Ties to the principal's own public path, shows you researched her and not only the district, and invites her to name her bar |
| RQ2 | "What would you want a new fourth-grade teacher to have figured out by the end of the first term?" | Tells you how success is judged and lets you talk about growth without a claim about the past |
| RQ3 | "How does the fourth-grade team work together on reading week to week?" | Shows partnership instinct and tells you the seam you would be working in |
| RQ4 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two teachers: it says you are thinking about their load, not only yours |
| RQ5 | "The board's plan brings a new reading curriculum to grades 3 to 5 from fall 2027. What is the fourth-grade team's part in that, and how should I prepare?" | Shows you read the district's plan and turns a CO probe into a shared preparation conversation |
| RQ6 | "What support does the school give a teacher who is new to a grade?" | Raises your biggest gap yourself, in a collegial register, and shows you plan to learn |
| RQ7 | "What happens after the panel, and when should I expect to hear?" | A real process question; the district's hiring page says references are taken up after the panel, so you can have them ready |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade, or knowing the fourth-grade year from the inside | A negative you stated, F2 | The sentence you gave: "I've never taught fourth grade." Then a plan to learn it, said as a plan. No answer slot |
| Having been a team lead | A negative you stated, F9 | The sentence you gave: "I've never been a team lead." F9's sentence at its own scope sits beside it |
| Leading the grade-level team, or choosing or designing the new reading curriculum | Inflated form of F9 | F9's quote at its own scope. The limit is the pack's observation, not words for you: your sentence says the move, not the team and not the curriculum choice. C3's slot stays inside the move |
| Speaking with every family each term | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your sentence says a weekly email. D2's slot asks only what you do beyond sending the emails |
| The reading club having raised students' reading | Inflated form of F4 | F4's quote at its own scope: "I've run the after-school reading club for the last two years." The pack's observation is that your sentence gives no result. E2's slot asks only who the club is for and what happens in it |

## Sources

**Provided documents:** your message, containing the invite text and your resume text. No tuesday-dossier.md was present.

**Searches and fetches sent**

| Call | Query or page | What came back |
|---|---|---|
| Search 1 | Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search 2 | Orrinsford Community School District teacher interview process | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Search 3 | Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet only; page not fetched) |
| Search 4 | Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren (snippet only; page not fetched) |
| Search 5 | fourth grade teacher job posting Illinois elementary school qualifications | https://k12jobsboard.example/listings/fourth-grade-teacher (snippet only, cut off before its qualifications) |
| Fetch 1 | https://orrinsfordschools.example/about/mission-and-beliefs | The three beliefs and their definitions |
| Fetch 2 | https://orrinsfordschools.example/careers/how-we-hire-teachers | The panel format and the topics panels ask about |

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Belief names and definitions for F5, F6, F7 and the VAL questions; no values cheat sheet, because no loop source documents a values round |
| 2. `{company} interview process {role family}` | yes | Established the loop as one 45-minute panel, so persona weights follow it and no archetype fallback applies |
| 3. `{company} strategy` / recent news | yes | F10 and B3, from the board's literacy plan; read from the search result only |
| 4. `{interviewer name} {company}` | yes | The interviewer read and RQ1; the two teachers are unnamed, so nothing was searched for them |
| 5. representative `{role title}` JD | yes | F3, F8 and F9 requirements, all `[inferred]`; the snippet stopped before the posting's qualifications |

## Upgrade menu

- The full posting for this role → F3, F8 and F9 move from `[inferred]` to `[grounded]`, and the coverage table checks against Halvering's own list
- The names of the two fourth-grade teachers → a tailored interviewer read and reverse questions for each
- Anything HR said about the panel, such as a sample lesson or something to bring → a graded-deliverable section
- Your answers to the slots in F3, F4, F5, F6, F7, F8 and F9 → those rows move from discovery toward grounded, and the matching guidance becomes story-mapped
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for the CO bank, more on the principal's talks, loop reports and recent district context
- How many days you have before the panel → a prioritized prep schedule
- A tuesday-dossier.md from an earlier fit check → verified evidence and prohibited-claim constraints carried into this pack
