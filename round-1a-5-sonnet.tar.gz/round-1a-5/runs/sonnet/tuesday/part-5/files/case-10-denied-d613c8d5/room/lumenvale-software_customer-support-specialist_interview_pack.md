# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote). **Company:** Lumenvale Software. **Interviewer:** the support team lead, name not given. **Relationship assumed:** hiring manager, since the invite does not say whether they would be your manager. **Format:** a typed text chat.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Because the interview is typed, "speakable in two minutes" here means an answer you can send in two or three short messages.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (none were available to this pack, so no VAL questions) |
| EXP | Whether the claims in your background survive follow-up: what was actually you |
| JD | Whether you can do the job as the ad describes it, gaps included |
| CO | How much you know about the company and its current position |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

The requirements are the four lines you relayed from the ad. Rows F5 and F6 are role-family points that were not in the ad as you gave it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you relayed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a line in a message with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: three years, a customer service advisor at an energy supplier, around 60 calls and emails a day. Keep the figure attached to calls and emails together, as you said it |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad allows a similar ticketing tool, and your quote names the one you use, so lead with it by name: "I use Freshdesk every day." Your material does not say whether you have used Zendesk. Answer slot: expect a probe on Zendesk. If you have used it, say where, in your own words; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — the ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Derived from the emails in your sentence: your sentence shows emails, not how clear they were. Answer slot: the ad's line makes a probe on how you keep a written reply clear likely. If you do something particular, say what, in your own words; if you have no set method, say so plainly and stay with the emails you answered. In a typed interview, the replies you send are what the interviewer reads |
| F4 | "confidence handling escalations" — the ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not mention escalations: that is silence, not a stated gap. Answer slot: the ad's line makes a probe on an escalation you handled likely. If you handled one, say what it was and what part was yours, in your own words; if escalations went elsewhere or none reached you, say so plainly and return to the calls and emails in F1 |
| F5 | Support experience inside a software company — a role-family point, not in the ad as you relayed it | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-support work |
| F6 | Showing colleagues how the work is done — a role-family point, not in the ad as you relayed it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | An extra, not an ad requirement. Use it at its own scope: four new starters, the refunds process, last year. The material does not say you designed the training or led a team |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "2+ years in customer support" (F1) | D1, D3, E2 |
| "experience with Zendesk or a similar ticketing tool" (F2) | B2, A2 |
| "clear written communication" (F3) | A3, A4 |
| "confidence handling escalations" (F4) | A1, B3, B4 |
| Software-company experience (F5, not in the ad) | B1, B5, A5, E1 |
| Training colleagues (F6, not in the ad) | D2, C3 |

## Persona table

The invite describes one session: a text chat with the support team lead. That is one conversation with one interviewer, so no loop beyond it is documented and no values-style round is detected. The weights below rest on the hiring-manager prior from this skill's persona model, which is a pattern, not a fact about Lumenvale. No interviewer profile exists to adjust them.

| Persona | How it shows up in a typed chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Short live scenarios: an upset customer, a spike in the queue, a reply you must write on the spot | High. The hiring-manager prior puts it first, and the role is judged on how you handle live situations | Clarify first, then structure, then answer; type the reply you would actually send |
| B. Skeptic | Quiet, repeated probing of the gaps: software background, Zendesk, escalations, why move | High. Same prior, and your own message names the software gap (F5) | Rehearse the single most likely objection until it is boring; calibrated candor over bluffing |
| C. Conversational | Friendly openers such as "walk me through the journey", still scored | Medium. A first chat tends to open casually, and casual questions are scored | Short arc built only from what you have said; treat casual questions about the ad as scored |
| D. Data-Driven Prober | Takes the numbers in your message and asks how they were counted and what part was yours | Medium. Your message gives two figures, around 60 a day and four new starters, and any figure invites this | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| E. Pressure | Time-boxed, devil's-advocate lines in the chat | Low. Nothing in the invite signals it; two questions keep the style from being met cold | Pause, restate, hold through two follow-ups, then concede specifically |

## Question banks

Highest-ROI prep in this pack: **B1**, the software-company objection. It is the one question most likely to arrive in some form, and the rehearsal is a plain acknowledgment followed by a plan.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes that a feature has stopped working just before their deadline, and asks for a manager. What do you do in the first five minutes?" | CASE | [generic] | Structure it in the order you would act: acknowledge in plain words; find out what you need (which feature, since when, what is at stake for them); say what you can do and by when only if it is in your control; say what you cannot promise; decide whether it needs passing on and to whom; note what you did on the ticket. Type the first reply as you would send it. The question needs no claim about your past, so the guidance makes none | The ad's escalation line (F4) asked as a decision rather than a record. CASE because it is a live problem; generic because it is a pattern, not a fact about Lumenvale |
| A2 | "Your queue is far deeper than usual on a Monday morning, and most of it looks like the same problem. What do you do first?" | CASE | [generic] | Clarify before acting: what changed, how many people are affected, what is blocked. Then group like with like, answer the blocked customers first, post one honest holding line to the rest, tell your lead what you are seeing, and say what you would check again later. The question needs no claim about your past, so the guidance makes none | Tests how you think inside a ticket queue, the working setting behind F1 and F2. CASE because it is a live problem |
| A3 | "Write me two sentences telling a customer we cannot do what they have asked, without sounding like we are brushing them off." | JD | [grounded] | Type the two sentences into the chat; they are the answer. Say plainly what cannot be done, in words a non-specialist uses, then what can be done instead or what happens next. Avoid stacked apologies and jargon, and read it once before sending. The question needs no claim about your past, so the guidance makes none | The ad's written-communication line (F3), tested directly: in a typed interview the answer is itself the sample. JD because it scores a stated requirement, CASE in delivery |
| A4 | "A customer has written in three times about the same problem and got a different answer each time. What does your fourth reply look like?" | CASE | [generic] | Read the whole thread first; say back what has been said so far; give one clear answer; own the inconsistency in a single sentence without blaming colleagues; say what you will note on the ticket so it does not repeat. The question needs no claim about your past, so the guidance makes none | A written-reply problem that also presses on the ad's escalation and clarity lines (F3, F4). CASE because it is a live problem |
| A5 | "What would you do in your first two weeks to get up to speed on a product you have not used?" | JD | [generic] | Say it as a plan, never as a past: what you would read, who you would ask, how you would check you had understood, and how you would keep notes for yourself. Use your own steps, the ones you would actually take. The question needs no claim about your past, so the guidance makes none | The answer to F5's gap, delivered as a forward plan. JD because it scores whether you can do the listed job despite the gap |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked for a software company. What makes you think you will pick up our product quickly?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment, in your own words: "I've never worked for a software company." Then say what you did do, at its own scope: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk daily. Describe it and let the interviewer draw the inference; do not draw it for them. Then give the plan, as a plan and not a past: how you would learn the product in your first weeks. Rehearse three follow-ups, each answered by returning to those same beats: they press on why you think so (return to the quotes, add nothing), they ask what you would do in week one (the plan), they ask what you would do when a customer asks something you cannot yet answer (say plainly that you would tell the customer, find out and come back to them, but only if that is how you would act). Concede one thing specifically: the product itself will be new to you | F5 is the stated gap and the likeliest place to be probed; the premise is F5's own quote. JD because it tests whether you can do the listed job despite the gap; the deepest rehearsal because the objection is certain to arrive in some form |
| B2 | "You use Freshdesk. Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Lead with the quote, in your own words: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so this probe is likely. If you have used Zendesk, say where and for what, in your own words; if you have not, say so plainly and stay with Freshdesk. Do not describe features you have not used | F2 covers the ad's ticketing-tool line, and the ad names Zendesk where the quote names Freshdesk. JD because it scores a stated requirement |
| B3 | "Tell me about a time a customer's problem went beyond what you could resolve yourself." | EXP | [grounded] | No sentence in your material carries an escalation story, so this is a selection scaffold. Pick a case that needed passing on or a decision above you. It needs: what made it more than you could settle, who it went to, what the customer was told, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the calls and emails in F1, or how you would handle it | F4 has no evidence, and the ad's escalation line raises this prompt. EXP because it tests what was actually yours |
| B4 | "How confident are you handling a customer who is angry and wants a manager?" | JD | [grounded] "answering around 60 calls and emails a day" | Say your honest level of confidence and nothing larger. Structure: stay calm and acknowledge, say what you can and cannot do, hand on cleanly when it is beyond you. Answer slot: if you have handled customers like this, give one example briefly and say what part was yours; if not, or if those cases went to someone else, say so plainly and return to the calls and emails of your own quote | Presses the ad's confidence line (F4). JD because it scores a stated requirement; the guidance stays inside F1's quote |
| B5 | "Why move into software support, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Your reason is yours: your material states none, so give your actual reason in two or three short messages. Start from where you are, the three years as a customer service advisor at an energy supplier, then your reason for the move. Do not borrow a reason that sounds good | The motivation probe; F1 and F5 together make it near certain. EXP because it tests consistency of your story |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Build a short arc from what you have said: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day. Anything beyond that, such as why you chose support or what comes next, is in your own words; your material states none of it. Keep it to two or three short messages | The standard opener for a first chat; casual in register but scored. F1 is the only background sentence available, so the arc stays inside it |
| C2 | "What do you know about Lumenvale, and what made you apply?" | CO | [generic] | I could not read anything about Lumenvale for this pack, so nothing here is a fact about the company. Before the chat, read Lumenvale's own website and note two things you can say in your own words; say only what you actually read. If you read nothing, say so plainly and say what in the ad appealed to you | The one company-knowledge question a casual interviewer asks. Generic because research did not run, and the upgrade menu says what would change that |
| C3 | "How did you find training the new starters?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say what you honestly found, in your own words, and stay at the quote's scope: four new starters, the refunds process, last year. Add nothing about how the sessions were run unless you did it. Keep it to a couple of messages | F6 is an extra in your material, and a casual question about it is easy to over-answer. EXP because it tests what was actually yours |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where does the figure of around 60 calls and emails a day come from, and how was it counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say the figure in the words you used: around 60 calls and emails a day, together. Four slots, each in your own words: how it was counted; what it is most sensitive to; which assumption behind it you would defend least; which part was yours. Answer slot: if you know how it was counted, say so; if you do not, say so plainly and stay with "around 60" | F1's headline number, the one a prober goes to first. EXP because it tests whether the figure survives scrutiny |
| D2 | "Four new starters, you said. Which part of that training was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Open with the quote, in your own words: you trained four new starters on your refunds process last year. Answer slot: which part was yours. Say in your own words what you did yourself; if some of it was set or done by someone else, say so plainly and stay with the quote | F6's figure raises the attribution probe. EXP because it tests what was actually yours |
| D3 | "Walk me through a typical day in the role you held for those three years." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Story-map it on the quote's own beats: the role, a customer service advisor at an energy supplier; the three years; the calls and emails, around 60 a day. Tell them in your own words and add no detail you cannot repeat under a second question | F1 is the evidence for the ad's years requirement, and a prober reads it line by line. EXP because it checks the claim in your own words |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Short answer: why you over someone who already works in software support?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | Hold, then concede. Hold on what the quotes carry: three years, around 60 calls and emails a day, Freshdesk daily. Concede specifically: "I've never worked for a software company." Do not claim you are better; keep to three or four short lines and do not fold on what you did say | The B1 objection, delivered under time pressure. JD because it scores fit against the listed job |
| E2 | "Around 60 calls and emails a day. How much of that was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Hold, then concede. Hold on the quote: you answered around 60 calls and emails a day. Answer slot: which part was yours. Say in your own words what was yours; if you do not know how the figure was counted or how much depended on others, say so plainly and stay with "around 60 calls and emails a day" | F1's figure under pressure; the stem tests whether you hold a claim without inflating or folding |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first month look like for someone new to the product?" | Puts the ramp-up on the table in your own terms and shows you are planning for it |
| R2 | "Which kinds of cases reach you as escalations, and what did a well-handled one look like recently?" | Gives you a concrete picture of the standard behind the ad's escalation line |
| R3 | "How does the team keep written replies consistent, and are they reviewed?" | Shows you take written quality seriously, and tells you how the ad's writing line is judged day to day |
| R4 | "Beyond the ticketing tool, what does the team work in day to day?" | Shows interest in the real working setting and tells you what to start reading |
| R5 | "After this chat, is there a next step on your side, or does the chat complete the interview stage?" | Tells you what to prepare next and what the interviewer will weigh from this conversation |
| R6 | "How do you measure whether support is going well for the team?" | Shows you think about outcomes, and tells you what a good first quarter is judged on |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| About 60 tickets a day, or 60 emails a day | Inflated form of F1: the quote counts calls and emails together | F1's quote at its own scope: "answering around 60 calls and emails a day". The limit is the pack's observation: the figure covers calls and emails together, not tickets or emails alone |
| Freshdesk expert or administrator | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: the material says daily use, not setup or administration |
| Has worked in software or software support | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Designed or led the refunds training, or managed the new starters | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". The limit is the pack's observation: the material says you trained four new starters, not that you designed the training or led them |

## Sources

Provided: your message, containing the invite, the ad's four requirements as you gave them, and your background. No dossier was present.

Searches sent: "Lumenvale Software values" (refused); "Lumenvale Software interview process customer support" (refused); "Lumenvale Software strategy news" (refused).

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The call was refused. It would have fed C2 and any values-themed questions, and shown whether a values round exists |
| 2. `Lumenvale Software interview process customer support` | unavailable | The call was refused. It would have checked the loop; the invite's own words fix this session as one text chat with the support team lead, so the weights rest on the hiring-manager prior |
| 3. `Lumenvale Software strategy` / recent news | unavailable | The call was refused. It would have fed a grounded CO question; C2 stays generic |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | unavailable | No search was sent because search was declined. It would have added responsibilities beyond the four relayed requirements to the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F4 take the ad's exact words instead of your paraphrase, and the JD-tagged questions pick up its stated responsibilities
- Search access, or Lumenvale's own website pages pasted in → C2 goes from generic to grounded, and a values round would be detected if their pages document one
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; offered once) → a strategy brief for company-level questions
- The support team lead's name and role → an interviewer read, tuned persona weights, and a reverse question tied to their path
- One case you handled that went beyond what you could settle, in your own words → F4 moves from none given to a quote, and B3 and B4 become story-mapped
- Whether you have used Zendesk → B2's slot is answered rather than rehearsed
- Anything particular you do to keep a written reply clear → F3 moves toward a quote
- A `tuesday-dossier.md` from an earlier session → verified evidence, prohibited claims and the biggest objection arrive pre-graded, so this pack can be sharper; never required
