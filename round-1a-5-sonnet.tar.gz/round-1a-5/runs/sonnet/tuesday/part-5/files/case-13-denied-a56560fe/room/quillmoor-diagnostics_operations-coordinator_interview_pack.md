# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday at 2pm
**Interviewer:** Hannah Lowther, Talent Partner. She will ring the mobile number on your application
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move. After that she tells you about the team and the next steps.

Built from your message and the advert only. No research could run (see Sources), so nothing here about Quillmoor beyond the advert.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's published values. None were in hand, so no row uses it |
| EXP | Whether what you say about your own work holds up, and what was actually yours |
| JD | The advert's stated duties, requirements and terms, including the gaps |
| CO | What you know about the company and its strategy. None in this pack, because no research ran |
| CASE | A live problem set in the role |

Guidance is scaffolding, not a script. Every line of proposed wording is pending your approval: change anything that is not how you would say it.

## Fit snapshot (proposed bridge wording, pending your approval)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries and suppliers, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who your scheduling touches likely. If any of it involved planning or QA, say how, in your own words; if none did, or it was not yours, say so plainly and stay with the deliveries |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Lead with it as you said it: you chase suppliers when orders slip. A confirmed line with nothing inspected behind it, so expect a probe on a specific occasion |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Scheduling deliveries is not the same as tracking supplier deliveries, and the bridge should not be stretched. Answer slot: if you follow supplier deliveries after an order is placed, say how, in your own words; if you do not, or that is someone else's, say so plainly and stay with what the quote carries |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. The figure raises the four slots a figure raises: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Each is answered in your own words, or with "I don't know how it was counted" where that is true |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Nothing in your material shows or rules this out. Answer slot: the advert's weekly dispatch line makes a probe on regular reporting likely. If you report on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and say what you would want to learn first |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet, not which tool. Answer slot: if the spreadsheet was in Excel, say so and describe what you rebuilt, in your own words; if it was in another tool, say which |
| F7 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: four years, logistics coordinator. A number of years is a fit row, not a gate |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." The advert lists the item as a plus. Then how you would learn it, said as a plan and never as a past |
| F9 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your sentence says an in-house stock system, and it does not say what it does for you. Answer slot: if you record or look up stock or orders in it, say what for, in your own words; if you do not, or it is not something you would call an ERP, say so plainly |
| F10 | "£38,000–£44,000" — advert; "your salary expectations" — Hannah's message | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your own figure, kept whole: "I'm hoping for £42,000." It raises no slot |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert; "how the hybrid pattern would work for you" — Hannah's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your own words, kept whole at their scope. It raises no slot |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it. It is a term, so it is surfaced and not bridged. A3 below carries it as an instruction to give your actual notice period |
| F13 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Your own words, kept whole. It raises no slot |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly phone call: biography, then Hannah's four logistics items | High. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah's own agenda is the logistics set. The risk is treating a friendly call as unscored | A short arc from your own sentences (A1); on each logistics item, your own words and then stop (A2 to A5) |
| Skeptic | Knock-out checks on the advert's items your material does not carry: production scheduling across planning, warehouse and QA, and SAP | Medium. The prior says light. I raised it above that because the advert's headline duty and its ERP line both press on thin spots in F1, F8 and F9. No interviewer signals were available to adjust further | Rehearse B1 until it is boring; hold what the quotes carry, and where they stop use the answer slot |
| Data-Driven Prober | A light probe on the figure and on the tools | Medium. A recruiter will not dig deep, but F4's figure and F6's tool are the lines most easily tested | Know how the figure was counted, or say plainly that you do not (C1) |
| Pressure / Stress | A time-boxed "why you" | Low. Unusual on a first phone screen, so two questions only | Pause, restate, anchor in what you stated, hold through two follow-ups |
| Case / Strategist | A short live problem from the role | Low. A recruiter rarely sets a case, but the advert names the planning, warehouse and QA seam | Clarify first, then structure, think aloud |
| Values / Behavioral | A behavioral prompt on chasing suppliers or working across teams | Low. No values-style round was detected and no published values were in hand | A selection scaffold with its honest branch |

Peer Evaluator is left out: Hannah is the only interviewer on this call, and a peer round is not part of what you have told me.

## Question banks

Total 18 questions. The one most likely to be asked, and the highest-ROI rehearsal in this pack, is B1.

### A. Conversational / Rapport Builder, weight high (proposed wording, pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: what you do now and what got you here." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats, each a clause the quotes state: the role and the four years; the deliveries for three depots and chasing suppliers when orders slip; the stock-count spreadsheet rebuild. Tell them in your own words, in about 90 seconds, and stop after the third. If you include the figure, the C1 slots follow | The standard opener of a recruiter screen, and it is scored for economy. F1, F2, F4 and F7 are the rows it draws on. EXP because it tests what you say about your own work |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Your own words, kept whole: "I'm hoping for £42,000." Then stop. If asked what you earn now, a decline with no figure: "I'd rather focus on the range for this role." The advert's own band is "£38,000–£44,000" | Hannah named it on her agenda, so it will be asked. JD because it concerns the listed job's terms; F10 holds the evidence |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, as your contract states it. Check the exact wording in your contract before Thursday so the answer is yours and exact | Hannah named it on her agenda. F12 is a term the material does not establish, so the guidance supplies no figure |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words, kept whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the journey or on more days, say those same words again, with nothing added | Hannah named the hybrid pattern on her agenda. F11 holds the evidence. JD because the pattern is the listed job's term |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words, kept whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up on any part of it, say the same words again | Hannah named it on her agenda, and she is scoring whether it stays consistent. F13 holds the evidence. EXP because it concerns your own situation |

### B. Skeptic, weight medium (proposed wording, pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. How does the scheduling you do now compare?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Expect three levels: how it compares; what in your work was closest to the planning or QA side; how you would get up to speed. Answer slot: if any of your scheduling involved planning or QA, say how, in your own words; if none did, or it was not yours, say so plainly and return to the deliveries. Hold through two follow-ups by returning to the deliveries, never by adding to them | F1 is the gap the advert's headline duty presses on hardest, so this objection will arrive in some form. JD because it scores the stated requirement |
| B2 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold only what the sentence carries: "I've never used SAP." The advert lists ERP experience as a plus. Answer slot: the advert's "or similar" makes a probe on the in-house stock system likely. If you record or look up stock or orders in it, say what for, in your own words; if you do not, or it is not something you would call an ERP, say so plainly. Then say, as a plan and not a past, what you would do first to learn a new system | F8 and F9 are where the ERP line presses. JD because it scores the stated plus |
| B3 | "What drew you to this role?" | JD | [generic] | Say your own reason, in your own words. Pick one duty in the advert that you would actually want to do and say why. If none stands out, say so plainly and say what you were looking for. Your reason for looking at all stays as your A5 words | A recruiter screen checks motivation as well as logistics. Nothing in your material speaks to why this role, so the guidance supplies no reason |
| B4 | "How comfortable are you with weekly reporting on on-time dispatch?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what you do now, in your own words, at the scope of that sentence. Answer slot: if you report on deliveries or dispatch, say what and how often; if you do not, say so plainly and say what you would want to learn first | F5 is a duty the material does not speak to. JD because it scores the stated requirement |

### C. Data-Driven Prober, weight medium (proposed wording, pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Weakest-assumption move, in your own words. If you know how it was counted, say it; if you do not, say plainly that you do not know how it was counted. Name the assumption behind the figure you would defend least before they do, or say you cannot name one. Say which part was yours; the sentence says you rebuilt the spreadsheet | F4 holds the one figure in your material, and quantified claims are what a prober tests. EXP because it tests attribution |
| C2 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the spreadsheet was in Excel, say so and describe what you rebuilt, in your own words; if it was in another tool, say which. Stay with what you did, at the scope of the sentence | F6 is a stated requirement and the quote does not name the tool. JD because it scores the requirement |
| C3 | "How do you keep track of supplier deliveries?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what you do now, in your own words, at the scope of the sentence. Answer slot: if you follow supplier deliveries after an order is placed, say how; if you do not, or that is someone else's, say so plainly and return to the scheduling and the chasing | F3 is a stated duty the quote touches without reaching. JD because it scores the requirement |

### D. Pressure / Stress, weight low (proposed wording, pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause, restate the question, anchor in the first sentence, and hold through two follow-ups by returning to it. Concede one thing specifically: "I've never used SAP." On the production-scheduling side, the concession is the B1 slot, in your own words | A stock pressure stem. F1 and F8 are the two places it can bite. JD because it scores fit against the advert |
| D2 | "That result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the sentence carries: "I rebuilt our stock-count spreadsheet." Then the C1 slot on which part of the fall was yours, in your own words, including "I don't know" where that is true | The attribution probe, delivered under pressure. F4 is the row |

### E. Case / Strategist, weight low (proposed wording, pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you at 10am that a delivery needed for tomorrow's production run will arrive two days late, and QA must clear the materials before the run. What do you do?" | CASE | [generic] | Clarify first: what is late, who needs it, what the run can move. Then say whom you would tell and in what order across planning, the warehouse and QA, what you would ask the supplier, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's planning, warehouse and QA line. Generic because it is a pattern for the problem, not a fact about this employer |
| E2 | "On-time dispatch dropped this week. How would you start finding out why?" | CASE | [generic] | Clarify what counts as on time and what changed, split by what could cause it, say what you would check first and what you would report. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's weekly dispatch line. Generic for the same reason as E1 |

### F. Values / Behavioral, weight low (proposed wording, pending your approval)

No published values were in hand and no values-style round was detected, so these use the advert as their theme, not VAL.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to chase a supplier who kept missing dates." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: pick one occasion that has a named order, a moment you pushed, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I chase suppliers when orders slip." | The advert's "chase late orders" line raises the theme. F2 holds your sentence, which carries no occasion, so the guidance does not supply one |
| F2 | "Tell me about a time you worked with a team outside your own to get something done." | JD | [generic] | Selection scaffold: pick an occasion with a named other team, what each side needed, and how it ended. If no such time comes to mind, say so plainly, then say how you would approach it | The advert's planning, warehouse and QA line raises the theme. Generic because no sentence of yours carries a cross-team story |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B1, D1, E1, F2 |
| "track supplier deliveries" | C3 |
| "chase late orders" | F1 |
| "keep stock records accurate" | A1, C1, D2 |
| "report weekly on on-time dispatch" | B4, E2 |
| "2+ years in operations or logistics coordination" | A1 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B2, D1 |
| "£38,000–£44,000" | A2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A4 |
| "your notice period" | A3 |
| "what's prompting a move" | A5 |

## Reverse questions (proposed wording, pending your approval)

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does the handover between planning, the warehouse and QA work day to day, and where does this role sit in it?" | It shows you read the advert's headline duty as a seam between teams, and it tells you what B1 is really testing |
| R2 | "Which system does the team record stock and orders in today, and is there training on it?" | The advert lists ERP experience as a plus, so it turns your B2 answer into a practical question about ramp-up |
| R3 | "Who reads the weekly on-time dispatch report, and what do they do with it?" | It shows you care what the report is for, not only that it exists |
| R4 | "Who would I meet next, and what would that conversation focus on?" | Hannah will cover next steps, so ask for the substance of the next round, not the timing she has already given |
| R5 | "How are the two Avonmouth days usually set: fixed days, or agreed with the team?" | It treats the hybrid pattern as a working detail and not as a negotiation, which keeps A4 where you left it |
| R6 | "What would a good first three months look like for the person in this role?" | It invites her to describe success in her own terms, and a rapport-style interviewer weights this slot heavily |

## Prohibited claims

Not coached in any cell of this pack. Each is built from the fit snapshot and carries its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation, not words for you: your material says deliveries and suppliers, not production schedules. B1's slot stays inside the deliveries |
| Has used SAP | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never used SAP." No slot |
| Has ERP experience through the in-house stock system | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." B2's slot asks only what it is used for |
| Cut stock discrepancies by a third by rebuilding the spreadsheet | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence puts the rebuild and the fall side by side and says nothing of how the fall was counted. C1's slots stay inside the sentence |
| Open to more than three days at Avonmouth | Claim F11's quote contradicts | The quote alone: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| Would consider the relocation to Reading | Claim F13's quote contradicts | The quote alone: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

## Sources

Provided documents: your message, which held Hannah Lowther's LinkedIn message, the advert text, and your own notes about yourself and your plans. No `tuesday-dossier.md` was present.

Searches sent, all refused:

- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics Avonmouth Bristol news strategy": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have supplied published values for question themes. No values cheat sheet is in this pack either way, since no values-style round was detected |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Your own words fix the loop: one 30-minute phone call with the recruiter, with her agenda stated |
| 3. `Quillmoor Diagnostics strategy` or recent news | unavailable | The search was refused. It would have moved a CO question grounded in current priorities, which this pack does not have |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have moved the interviewer read and a reverse question tied to her path, both absent here |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV text → F1, F2, F4, F6 and F7 now rest on your message alone, and a CV could add quotes or regrade them
- Your own answers to the answer slots in F1, F3, F5, F6 and F9 → each row regraded from your own words, and B1, B2, B4, C2 and C3 sharpened
- Your actual notice period → F12 resolved from your own words
- Permission for web search → published values and recent company strategy for a CO question, and Hannah's public professional footprint for an interviewer read and a tailored reverse question
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, which needs search to be allowed
- How much time you have before Thursday → a prioritized prep schedule
- A `tuesday-dossier.md`, if you have one → verified evidence, a named top objection and prohibited claims carried in, in place of the ones inferred here
