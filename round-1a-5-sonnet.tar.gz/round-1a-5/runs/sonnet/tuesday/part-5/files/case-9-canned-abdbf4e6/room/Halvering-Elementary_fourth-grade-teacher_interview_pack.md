# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** One 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren (hiring-manager relationship) and two members of the fourth-grade team (peer relationship; names not given)

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your own account of your experience holds up to follow-ups |
| JD | The listed responsibilities and qualifications of the job |
| CO | Whether you know the district's current direction |
| CASE | A live classroom problem, answered with structure |

Provenance labels: `[grounded]` traces to a document you gave me or to research cited in Sources; `[inferred]` rests on a representative listing or a derivation named in the row; `[generic]` is a pattern for the problem and claims nothing about this district or about you.

An answer slot is an instruction for the interview, not a question for you now. It names what a panel is likely to probe and gives two honest branches. Answer it from your own experience, or say plainly it was not yours.

**Highest-ROI prep: A1.** The panel is hiring for fourth grade and you have said you have never taught it. A rehearsed, non-defensive answer to A1 will matter more than anything else here.

## Fit snapshot

The posting text was not supplied. Rows sourced to "K12 Jobs Board listing" use a representative fourth-grade listing found in research, so they are `[inferred]`. Rows sourced to the district page use the district's published beliefs.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material states the kind (Professional Educator License), the issuer (Illinois), the endorsement (Elementary Education, grades 1–6) and the status and expiry (registered and active through June 30, 2029). Say it in exactly those terms. Nothing has been inspected behind the CV line, so expect HR to verify it. Checking it is yours, and this pack carries no license number |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past. Never a claim to fourth-grade work, and nothing added to make the gap feel smaller |
| F3 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | The sentence says six years teaching third grade, not which subjects. Answer slot: the listing names five subjects, so expect a probe on which were yours to plan and teach. Say which, in your own words; if some were taught by someone else, or not at all, say so plainly and stay with the third-grade years |
| F4 | "differentiate instruction using assessment data" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material does not show this either way. Answer slot: if you adjusted teaching from assessment results, say what you changed and from what, in your own words; if you did not, or it was not yours to do, say so plainly and say what you would look at first |
| F5 | "keep clear classroom routines" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material does not show this either way. Answer slot: if you set or kept routines in your classroom, name one in your own words; if the routines were set by others or there were none, say so plainly and say how you would set them up with a new class |
| F6 | "communicate regularly with families" — K12 Jobs Board listing | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: weekly, written, to families. A named routine beats an adjective |
| F7 | "each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The belief says speaks with, and your sentence says a weekly email; the words stay at the email. Answer slot: if you also speak with families by phone or in person, say how and how often, in your own words; if the email is the whole of it, say so plainly and stay with the email |
| F8 | "no student leaves third grade without a reading plan" — district Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | The sentences carry a curriculum move and a club, neither of which is a reading plan for each student. Answer slot: if students in your class had reading plans, say how that worked and what part was yours; if not, or it was not yours, say so plainly and stay with the move and the club |
| F9 | "work with the grade-level team" — K12 Jobs Board listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | The sentence already reaches the requirement in other terms. Say it as written: "we" for the grade level, "I" for the move you led, nothing more. Your message also says "I've never been a team lead", so describe the move and never a lead role |
| F10 | "assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if assessment results ever changed what you taught, say what showed up and what you changed; if none did, or it was not yours to change, say so plainly and say how you would use results as a new fourth-grade teacher |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Valid Illinois license with elementary endorsement | E1 |
| Fourth Grade Teacher position | A1, A2, A3 |
| Plan and teach reading, writing, math, science and social studies | A4 |
| Differentiate instruction using assessment data | C2, D3, F2 |
| Keep clear classroom routines | C3 |
| Communicate regularly with families | D2, E2 |
| Work with the grade-level team | A5, B1, B2, B3, B4 |
| Every Child a Reader | C1, C2, D1, E3 |
| Families Are Partners | D2 |
| Teach for Tomorrow, Not for the Test | D3, F2 |

## Reading the interviewer

Only the principal is named. Nothing is established about the two team members, so their rows are absent. Public professional footprint only.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| "Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist." | Illinois principals forum speaker page (search result, page not fetched) | [grounded] | Reading is her home ground. Expect reading questions to go deeper than a generalist's, and treat casual reading questions as scored |
| "Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5." | Same page | [grounded] | Her recurring theme overlaps the grades you know and the grades you would teach. Use her vocabulary (reading, small groups, conferences) only for what you actually do |

Mirror opportunity: the shared vocabulary is reading. Your side of it is "I've run the after-school reading club for the last two years" (F8) and "I led our grade level's move to a new reading curriculum in 2024" (F8, F9). Say them as written. Neither sentence says the club uses small groups or conferences, so do not say it does.

## Persona table

The loop rests on the district's own hiring page, which describes one 45-minute building panel of the principal and two grade-level teachers and says panels ask about reading instruction, classroom routines and how you work with families (Sources). Your invite agrees. A panel blends the top two personas of each member's relationship.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | The quiet probe at the gaps: fourth grade, the subjects, team lead | High. You have stated two gaps, the principal is the hiring-manager relationship, and the role is for a grade you have not taught | Rehearse A1 until it is boring. Plain acknowledgment, then only what your sentences carry, then a plan said as a plan |
| Peer Evaluator (bank B, 4 questions) | The two fourth-grade teachers asking about the seam, what you would need, and credit | High. They are the peers you would plan beside, and the listing names working with the grade-level team | Reciprocity first: what you bring, then what you would need. Offer seam principles rather than pretending to know the seam |
| Case / Strategist (bank C, 3 questions) | Live classroom problems and the district's literacy plan | Medium. The principal's relationship points here, but the hiring page describes topic areas, not case formats | Clarify, then structure, then approach, then how you would know; think aloud |
| Values / Behavioral (bank D, 3 questions) | The three published beliefs as prompts | Medium. The beliefs are published and the hiring page's topics match them, but no source documents a dedicated values round, so there is no values cheat sheet | Where one of your sentences carries a story, use it at its own scope; where none does, use the selection scaffold and its honest branch |
| Conversational (bank E, 3 questions) | License confirmation, the walk-through of your path, reading talk | Medium. Panels open this way and these questions are still scored | Pre-script a 90-second arc built only from your own sentences |
| Data-Driven Prober (bank F, 2 questions) | Which part was yours, and how you know the club works | Low. You have given no figures, but the curriculum move invites an attribution probe | Say plainly which part was yours and what you do not know |

Pressure is not weighted: no source or interviewer signal points to time-boxed stress.

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have taught third grade. What changes for you in fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Highest-ROI rehearsal. Open with the plain acknowledgment: "I've never taught fourth grade." Then the quote at its own scope: six years teaching third grade at a public elementary school in Joliet. Then a plan, said as a plan: name the first things you would find out about fourth grade and who you would ask. Answer slot: if any of your work has touched fourth grade, say what and how, in your own words; if none has, say so plainly and stay with the plan. Hold through two follow-ups by returning to the same three beats, and concede only what is true: you have not done it yet | F2 is the likeliest objection in a fourth-grade panel; F3 is the adjacent evidence. JD because it scores the stated role |
| A2 | "Why fourth grade, and why now?" | EXP | [generic] | The reason is yours and this pack has none from you, so supply it in your own words: say your actual reason and nothing you would not repeat under a second question. Keep it short, then return to what the role asks. Add no motive you did not give | A Skeptic probes motivation consistency. EXP because it tests whether your own account holds together; no claim about your past is coached |
| A3 | "What would you want to learn first about fourth grade, and from whom?" | JD | [generic] | A structure, not a claim: what you would ask the two team members, what you would read or watch first, what you would hold off deciding until you had seen it. Said as a plan for the first weeks, with no past tense about fourth grade | The ramp plan is the half of A1 that makes the acknowledgment safe; F2 |
| A4 | "The role plans and teaches reading, writing, math, science and social studies. Which of those have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Say the quote in its own terms. Answer slot: the listing names five subjects, so expect a probe on each. Say which were yours to plan and teach, in your own words; if some were taught by someone else, or not at all, say so plainly and stay with the third-grade years. The premise comes from the representative listing, so the guidance does not adopt it | F3 is where the listing presses on a one-line CV entry. `[inferred]` because the five subjects come from a representative listing, not this school's posting |
| A5 | "You led your grade level's move to a new reading curriculum. Were you the team lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Plain answer first: "I've never been a team lead." Then the quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say what part of the move was yours, in your own words; if the decision or the pace was set elsewhere, say so plainly and stay with the part you led. Hold both sentences apart through two follow-ups; concede nothing about a lead role you did not hold | F9 holds the quote and the limit; the panel will test where "led the move" ends. EXP because it tests attribution |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans together. What would you bring us, and what would you need from us?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024"; "I write a weekly email to families."; "I've never taught fourth grade" | Reciprocity first: what you bring, said as the two quoted sentences at their own scope. Then the need, stated plainly: "I've never taught fourth grade", and what you would ask of them as a plan. Say nothing about how a team plans together that your sentences do not state | F9 and F2. The listing's team line is the raising source and is `[inferred]` |
| B2 | "Tell us about the reading curriculum move you led." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell only the beats the sentence states: your grade level, a new reading curriculum, 2024, the move you led. Answer slot: say what part of it was yours, in your own words; if parts were decided by others, say so plainly. Use "we" for the grade level and "I" for what you led | F9. The peers are checking whether the move was a shared effort, and EXP because it tests what was actually yours |
| B3 | "Where is the seam between what you would do and what the team already does, and what happens when we disagree?" | JD | [generic] | Offer seam principles instead of pretending to know the seam: ask what the team already owns, say what you would raise before acting, and say you would bring a disagreement to the person it affects. For the disagreement story none of your sentences carries one, so pick a time you disagreed with a colleague: it needs a stated stake, how you handled it, and a working relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer stem; F9. `[generic]` because it claims nothing about your past |
| B4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for context and "I" for contribution. The contribution you can state is the quoted sentence at its own scope; anything beyond it is the answer slot in B2. Say that you share credit for what others did | Credit-sharing is where "led" gets tested again; ties to the A5 limit |

### Bank C: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our board adopted a literacy plan this year. What do you know about it, and where would you fit in it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Read the board's news item before Thursday; the pack saw only a search snippet. As published, the plan has three parts: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term (Sources). Say what you have read, then connect it to your sentence at its own scope. Answer slot: if your 2024 move touched anything the plan describes, say what, in your own words; if it did not, say so plainly | The one CO question grounded in current direction. It names the plan's three elements as published; F8 holds the quote |
| C2 | "A student in your class is reading well below grade level. It is October. What do you do?" | CASE | [generic] | A structure, not a claim: ask what you need to know first (what the assessment shows, what has been tried, what the family sees), set the objective, choose an approach and say how you would know it is working, and name one risk. Tie it to the published belief "Every Child a Reader" without claiming a past | Live problem from the F4 and F8 requirements; presupposes nothing about your past |
| C3 | "It is the first week with a new fourth-grade class. Walk us through setting up your routines." | CASE | [inferred] | Structure it as a plan: what the class needs to know on day one, what you would model, what you would check at the end of the week. Answer slot: if you would carry a routine over from your own classroom, name it in your own words; if you would start from scratch, say so plainly | F5. The routines line comes from the representative listing and the district's hiring page |

### Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader: no student leaves third grade without a reading plan. Tell us about a time that belief shaped what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Two candidate stories, each at its own scope: the club and the curriculum move. Pick the one you can tell with the most stated detail and tell it in your own words. Answer slot: if students in your class had reading plans, say how that worked and what part was yours; if not, say so plainly and stay with the club or the move | F8. The belief is a published value; open prompt |
| D2 | "Families Are Partners: each teacher speaks with every family each term. How do you partner with families?" | VAL | [grounded] "I write a weekly email to families." | Say the sentence as written, then stop adding. Answer slot: if you also speak with families by phone or in person, say how and how often, in your own words; if the weekly email is the whole of it, say so plainly and say what you would add as a new teacher here | F6 and F7. The belief says speaks with, so the probe is on the email |
| D3 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. When did assessment results change what you taught?" | VAL | [grounded] | None of your sentences carries this story, so pick a time when results changed a plan: it needs what the results showed, what you changed, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would use results as a new fourth-grade teacher | F4 and F10. Scaffold, not a story map |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Before we start, can you confirm your licensure?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in those terms and stop. Keep your license record where you can read it, since the pack does not carry the number. Do not add to the endorsement or the dates | F1, the gate in the invite. It is shown met on your CV, and the panel may still ask |
| E2 | "So, walk me through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | A 90-second arc built from these four sentences and nothing else: the years, the move, the club, the email. End on where you are heading, in your own words, with no reason added that you did not give | The rapport question is scored. F3, F6, F8, F9 |
| E3 | "What is going on in your reading club these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe what you actually do there, in your own words, adding nothing a student or colleague could not confirm. The principal came to the job after nine years as a reading specialist (Reading the interviewer), so this casual question is scored | F8. A casual question on a hot topic |

### Bank F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Which part of the curriculum move was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say which part was yours and which part was not. Answer slot: if you can walk through your part end to end, offer to; if you cannot, say plainly what you do not know about how it was decided or measured | F9. No figure was given, so the probe is on attribution |
| F2 | "How do you know the reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you track anything, say what and who counted it; if nothing is tracked, say so plainly and say what you would look for first. Never describe a measure you did not use | F4 and F10. The belief that assessments inform teaching is the raising source |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "What does a strong first term look like for a new fourth-grade teacher here?" | It turns the A1 gap into a shared plan and shows you are already thinking about the ramp | [generic] |
| R2 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you look for in reading instruction in fourth grade?" | It is tied to her own path (Reading the interviewer) and signals you researched her, not just the school | [grounded] |
| R3 | "What could a new fourth-grade teacher do in the first month that would genuinely help the team?" | Reciprocity with the two peers: it asks what you can add before what you need | [generic] |
| R4 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. How is the grade level preparing for it?" | It shows current knowledge of the district's direction (C1) and asks about the team's work | [grounded] |
| R5 | "How do teachers here usually set up the each-term conversations with families?" | It follows the published belief and tells you whether the weekly email is a start or a gap (F7) | [grounded] |
| R6 | "What happens after the panel, and what is the timeline?" | Your hiring page says references are taken up after the panel; this clarifies what follows without pressing | [grounded] |

## Prohibited claims

Not coached in any answer, slot or drill. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I've never taught fourth grade." No slot |
| Has been a team lead | Negative you stated, F9 | "I've never been a team lead." Then your quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." |
| Led the grade-level team through the curriculum change | Inflated form of F9 | The F9 quote at its own scope. The limit is the pack's observation: your material says the move, not the team |
| Speaks with every family each term | Inflated form of F7 | The F7 quote at its own scope: "I write a weekly email to families." D2's slot stays inside the email |
| Gave every student a reading plan | Inflated form of F8 | The F8 quotes at their own scope: the club and the move. The pack's observation is that your material shows neither a plan nor a student-level practice |

## Sources

**Provided documents:** your invite and your resume text, both in your message. No dossier.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District mission values` | yes | The three published beliefs by name; bank D and the F7, F8 and F10 requirements |
| 2. `Orrinsford Community School District teacher interview process` | yes | The loop: one 45-minute building panel, principal plus two grade-level teachers; persona weights |
| 3. `Orrinsford Community School District news strategic plan` | yes | The literacy plan; C1 and R4 |
| 4. `Dolores Vantongeren principal Halvering Elementary School` | yes | The interviewer read, R2, and the reading weighting. The two team members were not named, so they were not searched |
| 5. `fourth grade teacher job description Illinois elementary school` | yes | The representative listing behind F3, F4, F5, F6, F9 and their `[inferred]` labels, because no posting was supplied |

Searches and what came back:

- `Orrinsford Community School District mission values` — https://orrinsfordschools.example/about/mission-and-beliefs
- `Orrinsford Community School District teacher interview process` — https://orrinsfordschools.example/careers/how-we-hire-teachers
- `Dolores Vantongeren principal Halvering Elementary School` — https://ilprincipalsforum.example/speakers/dolores-vantongeren
- `Orrinsford Community School District news strategic plan` — https://orrinsfordschools.example/news/board-adopts-literacy-plan (item dated August 2026)
- `fourth grade teacher job description Illinois elementary school` — https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/careers/how-we-hire-teachers, both returned the full page. The principal's page and the board's news item were read as search results only, not fetched, so read them in full before Thursday.

## Upgrade menu

- The full posting text → rows F3, F4, F5, F6 and F9 move from `[inferred]` to `[grounded]`, and any requirement the listing does not show is added
- What HR told you about the panel, such as focus areas or something to prepare or bring → coverage of anything pre-announced, and a build section for a demo lesson or writing sample
- The names and roles of the two team members → a real interviewer read for each, persona weights per member, and a reverse question tied to each path
- Your answers to the answer slots in A1, A4, A5, B2, D1, D2, D3 and F2 → rows F3, F4, F5, F7, F8 and F10 move from slots to quoted evidence
- A copy of your license record, a sample of a weekly family email, or the 2024 curriculum materials → F1, F6 and F9 from `medium` toward `high`
- How much prep time you have before Thursday → a prioritized schedule
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and prohibited claims in place of the list built here
