# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the district's published beliefs |
| EXP | Work-experience deep-dive | Whether your résumé's claims hold up; what was actually you |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth on the district's current plans |
| CASE | Live problem | Structure and reasoning on a classroom situation |

Built on one assumption: a single panel session (the invite names one 45-minute panel), with a typical fourth-grade posting standing in for the real one, which was not supplied. Rows built from that stand-in are labeled `[inferred]`.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met: the kind of license, the state, the elementary endorsement, active status and the 2029 expiry are all in your own line, and the grades 1–6 range you wrote includes grade 4. It is a CV line with nothing inspected behind it, and I have not looked the registration up; checking it on the state's license lookup before the interview is yours to do. Say it as written: registered and active through June 30, 2029 |
| F2 | "the Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past. The third-grade work sits in F3 and is not claimed here as fourth-grade experience |
| F3 | "plan and teach reading, writing, math, science and social studies" — a typical fourth-grade posting (K12 Jobs Board listing, not this district's) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | The quote shows the grade, the years and the setting, not which subjects were yours. Answer slot: the typical posting's list makes a probe on subject coverage likely. If you planned and taught some of these subjects, say which, in your own words; if you did not, or others taught some, say so plainly and stay with the six years |
| F4 | "differentiate instruction using assessment data" — a typical fourth-grade posting (K12 Jobs Board listing, not this district's) | none given | none | [inferred] | discovery | Nothing in your material speaks to this, and the district's page says "assessments inform teaching and never replace it", so a probe is likely. Answer slot: if you adjusted instruction for different students using assessment results, say how, in your own words; if you did not, or it was not yours, say so plainly |
| F5 | "communicate regularly with families" — a typical fourth-grade posting (K12 Jobs Board listing, not this district's) | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap in wording, but a CV line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: a weekly email to families, because a named routine beats an adjective |
| F6 | "each teacher speaks with every family each term" — the district's Families Are Partners belief, Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | An email is adjacent to speaking with families, and the words stay at the email. Answer slot: the belief's wording makes a probe on direct conversations likely. If you have spoken with families directly, say when and how, in your own words; if you have not, or that was not part of your role, say so plainly and stay with the weekly email |
| F7 | "work with the grade-level team" — a typical fourth-grade posting (K12 Jobs Board listing, not this district's) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | none | No gap on the requirement itself, but the two quotes sit side by side and a panel member will notice both. Keep each at its own scope: "I led our grade level's move to a new reading curriculum in 2024," and, if the title comes up, "I've never been a team lead." This pack's own observation: your material says the move, not the role |
| F8 | "no student leaves third grade without a reading plan" — the district's Every Child a Reader belief, Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Reading work adjacent to the belief's reading plans, and the words stay at the two quotes. Answer slot: the belief's wording makes a probe on reading plans likely. If you made or kept reading plans for students, say how, in your own words; if you did not, or that was someone else's job, say so plainly and stay with the curriculum move and the club |

## Reading the interviewer

Public professional footprint only, from one speaker page; the two team members are unnamed, so there is no read on them.

| Item | What the public page says | Practical implication |
|---|---|---|
| Career pattern | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] Reading is her home ground; expect reading questions to go deeper than the usual surface pass (C1, C2, F2) |
| Published talk | A 2025 forum talk, Small Groups, Big Readers, on weekly reading conferences in grades 3 to 5 | [grounded] Grades 3 to 5 spans your current grade and the one you are applying for, so a reading question can arrive framed across both. Look at the talk's summary before the interview; do not claim to have attended it |
| Mirror opportunity | A reading-centred domain in common, not a shared path | [grounded] Pair her reading background with F8's sentence, at its own scope: "I led our grade level's move to a new reading curriculum in 2024". Do not build on anything beyond that sentence |

## Persona table

The invite's panel blends the top two personas of each member's relationship: the principal reads as hiring manager (Case/Strategist plus Skeptic) and the two team members as peers (Peer Evaluator plus Data-Driven Prober). The loop is one session, established by the invite, so no archetype fallback applies.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the gaps: fourth grade, team leadership, why this move | High: you named both gaps yourself (F2, F7), and the principal is buying capability and de-risking | Rehearse the most predictable objection until it is boring; plain acknowledgment plus a plan; no bluffing |
| B. Peer Evaluator | Two grade-level colleagues pricing what you add to their week: seams, credit, what you would need from them | High: two of three panelists are teammates | Reciprocity framing; propose seam principles, not a made-up seam; disagreement stories with spine and tact |
| C. Case/Strategist | Live classroom problems, and the district's literacy plan | Medium: hiring-manager prior, raised by her reading-specialist background and the board's August 2026 plan | Clarify, structure, think aloud; challenge one premise respectfully |
| D. Data-Driven Prober | Line-by-line questions on your résumé lines and assessment practice | Medium: the peers' second persona, and F3, F4 give it room | Know what you can and cannot say about each line; say plainly when you do not know |
| E. Values/Behavioral | Scenario probes keyed to the district's three published beliefs | Medium-low: no values round is documented, but the district's page says the beliefs "guide every hire" | Stories mapped where your sentences carry one; otherwise a scaffold and its honest branch |
| F. Conversational | Friendly opener and casual questions that are still scored | Low: a panel opener is likely, but it is brief | A 90-second arc built only from your own sentences |
| G. Pressure | Time-boxed or devil's-advocate lines | Low: nothing in the invite signals a stress format | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Name the limit before it is asked for, in your own words: "I've never taught fourth grade." Then what you did teach, as written: "For six years I taught third grade at a public elementary school in Joliet." Then a plan, said as a plan and never as a past, in three parts, each in your own words: what you would learn first, who on this team you would ask, and how you would check your own progress. Expect two follow-ups, what you expect to differ and what you would do if a routine you rely on did not fit; answer each as a plan, returning to those two sentences, never reaching for fourth-grade work you have not done | F2 is the gap you named yourself and the first thing a panel for this role reads; F3 holds the adjacent years. JD because it scores the position's own grade level |
| A2 | "You led your grade level's move to a new reading curriculum, and you've never been a team lead. How do you square the two?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Keep each sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." "I've never been a team lead." Do not reconcile them by promoting one; saying plainly that one is about a move and the other about a role is the answer. Answer slot: which parts of the move were yours to decide and which were set by others, in your own words; if the choice was not yours, or the move was shared, say so plainly and stay with the sentence you can stand behind | F7 holds both quotes side by side; EXP because it tests what was actually yours |
| A3 | "Which part of fourth grade would be newest to you on day one?" | JD | [inferred] | Name one area plainly and pair it with how you would close it. Choose only from the subjects the typical posting lists in F3 (reading, writing, math, science, social studies) an area you can honestly call newest; if several are, pick the one you can say most about. Never present a strength as the weakness | F2 and F3: the grade-level change makes this question near-certain from a hiring manager. `[inferred]` because the subject list comes from a typical posting, not this district's |
| A4 | "Why this move, why Halvering, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Your reasons are yours, and your material states none, so the pack supplies none. Answer slot: say your actual reasons for moving from third grade to fourth and for choosing this school, in your own words; if one of the three has no answer yet, say so plainly rather than inventing it. If you have read the district's own words you may name them once: its page says "Three beliefs guide every hire at Orrinsford" and lists Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. Use one only if it genuinely speaks to you | F2 raises motivation; EXP because a consistent reason survives cross-examination |
| A5 | "Can you confirm which license and endorsement you hold?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms: kind, state, endorsement, status, expiry. Check the registration on the state's license lookup before the interview so your words match what the panel could see; I have not checked it. Add nothing that is not in your line | F1 is the invite's one hard requirement, so it earns a rehearsed one-sentence answer; JD because it scores the stated qualification |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We'd plan side by side. What would you want from us in your first month, and what would you bring?" | JD | [grounded] "I've never taught fourth grade"; "I led our grade level's move to a new reading curriculum in 2024"; "I write a weekly email to families" | Reciprocity framing. Ask for what your own limit calls for: "I've never taught fourth grade," so ask how the team plans together and what to read first. What you bring, each at its own scope: "I led our grade level's move to a new reading curriculum in 2024" and "I write a weekly email to families." Offer them as things you have done, not as things you would run here | F2 and F7: peers price what a hire adds to their week; JD because it scores working with the grade-level team |
| B2 | "Where is the seam between your classroom and ours, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: how plans and information get shared, who decides what, how a disagreement is raised. For the disagreement half, pick a time you disagreed with a colleague and the work still moved: a named issue, what you said, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7's requirement, asked collegially; `[generic]` because it is a pattern, not a fact about this team |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for context, "I" for contribution. The one sentence you can stand behind for "I" is "I led our grade level's move to a new reading curriculum in 2024," at that scope. For credit, pick a time work was shared and you named others' parts; if none comes to mind, say so plainly, then say how you would handle it | F7: the move is the only shared work your material shows, and peers test whether credit-sharing is real |
| B4 | "You've taught third grade. What do you expect to be different about our fourth graders?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Give an expectation and label it one: you have not taught fourth grade, so say what you would expect and invite them to correct you. Draw on what you have taught: "Six years teaching third grade at a public elementary school in Joliet." Do not describe fourth graders as though you have taught them | F2 and F3, from the colleagues who would know; JD because it tests grade-level readiness |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's two weeks into the year and a fourth grader is reading well below grade level. Walk us through your first steps." | CASE | [inferred] | Derived from the district's published sentence "no student leaves third grade without a reading plan". Clarify first: what the assessment data shows, what reading plan already exists for this child, what the family already knows. Then the objective for the next few weeks, the approach, how you would check it is working, and when you would speak with the family. Think aloud and challenge one premise respectfully, such as whether "well below" is one measure or several. The question asks for no past, so the guidance makes none | F8's reading theme and the principal's reading background make a live reading problem likely |
| C2 | "The board adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027. How would you want to be part of that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Mention the plan once, in its published terms, "a new grades 3–5 reading curriculum from fall 2027", to show you did your homework, then speak from your own experience instead of reciting it: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: what from your 2024 move would help this team and what would not carry over, in your own words; if you do not know whether any of it would carry over, say so plainly. Then ask the team what they hope to keep | F8, and the board's August 2026 plan is a public page any prepared candidate has read, so differentiate by speaking from your own sentence |
| C3 | "A parent writes that their fourth grader feels behind in reading. What do you do in the next week?" | CASE | [grounded] "I write a weekly email to families" | Structure it: acknowledge the concern, look at what the child's data and plan already show, decide the next step, and set a date to check. The district's page says "each teacher speaks with every family each term", so put a conversation into the plan, not only an email; your weekly email stays at its own scope, "I write a weekly email to families." Say the conversation as a plan, not a past | F5 and F6: the email is your evidence, the belief asks for conversation |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your résumé lists six years in third grade. What did a typical week of planning look like?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Start from the sentence: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: if you planned and taught reading, writing, math, science and social studies, say which, in your own words; if you did not, or others taught some, say so plainly and stay with the six years | F3: the typical posting lists five subjects and your line names none |
| D2 | "How do you use assessment data to differentiate instruction?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: if you adjusted instruction for different students using assessment results, say what you looked at and what you changed, in your own words; if there was no such step, or it was not yours, say so plainly and return to "Six years teaching third grade at a public elementary school in Joliet." The district's own line, "assessments inform teaching and never replace it", is the frame the panel will use | F4 is the thinnest row in the snapshot, and a prober goes where the material is thin |
| D3 | "What goes in the weekly email to families?" | EXP | [grounded] "I write a weekly email to families" | Describe it in your own words, starting from "I write a weekly email to families." Add nothing you do not do, and say plainly what the email is not, for example if it goes one way | F5: a named routine is concrete, so a prober tests it |

### E. Values/Behavioral

Themed on the district's three published beliefs (Mission and Beliefs page). No values-style round is documented for this loop, so these are probable themes, not a scheduled round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about a time a student's reading plan had to change." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection criteria: a named student need, what you changed, what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I've run the after-school reading club for the last two years," at that scope, or how you would handle it | F8 and the Every Child a Reader belief |
| E2 | "Tell us about a time you had a hard conversation with a family." | VAL | [grounded] "I write a weekly email to families" | Selection criteria: something hard that was said, how it landed, a relationship intact at the end. If no such time comes to mind, say so plainly; your weekly email is not a conversation, so do not offer it as one. Say how you would handle it | F6 and the Families Are Partners belief |
| E3 | "Tell us about a time assessment results changed what you taught." | VAL | [grounded] | Selection criteria: a named result, what you changed, what happened. Your material carries nothing for this question, so if no such time comes to mind, say so plainly and say how you would handle it | F4 and the Teach for Tomorrow, Not for the Test belief |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk us through your journey to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc built only from your sentences, in this order: the six years, the curriculum move, the club, the weekly email. Then the turn to fourth grade, as an answer slot: say your actual reason, in your own words; if you do not have one yet, say so plainly. Tell the beats in your own words and add nothing between them | F3, F5, F7, F8: the opener is scored even though it feels casual |
| F2 | "What are you reading with your club right now?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Start from the sentence: "I've run the after-school reading club for the last two years." Answer slot: name one thing you can point to from the club, in your own words; if you cannot, say plainly what the club does and stay there | F8: a casual question on a topic the principal knows well is still scored |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade" | Pause and restate the question. Hold on what the quotes carry: "Six years teaching third grade at a public elementary school in Joliet" and "I led our grade level's move to a new reading curriculum in 2024." Concede specifically and early: "I've never taught fourth grade." Hold through two follow-ups by returning to those sentences, never by adding to them, and do not argue the comparison, since you cannot know what another candidate has done | F2 under pressure; JD because it scores the grade-level requirement |
| G2 | "I'm not sure you can lead a grade-level team." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Pause before answering. Hold on "I led our grade level's move to a new reading curriculum in 2024." Concede specifically: "I've never been a team lead." Do not reconcile the two by promoting either; hold through two follow-ups by returning to the move. Say what you would want to learn, as a plan | F7 and the team-lead entry in the prohibited list |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 valid Illinois license with elementary endorsement | A5 |
| F2 the Fourth Grade Teacher position | A1, A3, B1, B4, G1 |
| F3 plan and teach the five subjects | A3, D1 |
| F4 differentiate instruction using assessment data | D2, E3 |
| F5 communicate regularly with families | C3, D3 |
| F6 speaks with every family each term | C3, E2 |
| F7 work with the grade-level team | A2, B1, B2, B3, G2 |
| F8 Every Child a Reader | C1, C2, E1, F2 |
| Figures on your résumé | none, and why: it gives durations only (six years, two years, 2024), which raise no defend-the-number question |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "You were a reading specialist for nine years before becoming principal. How does that show up in how reading runs in fourth grade here?" | Ties to the principal's own public path and shows you researched her, not just the district. Ask it only in your own voice and only if it is a real interest |
| R2 | "I read the summary of your forum talk on weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade room here?" | Asks about her published theme. Ask it only if you have read the summary yourself; do not imply you attended |
| R3 | "What could a new person on this team do in their first month that would genuinely help you?" | The reciprocity question for the two peers; it shows you are thinking about their load, not only your ramp |
| R4 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. What does the fourth-grade team hope that transition looks like?" | Uses a public plan to ask about the team's view, which a recited fact would not |
| R5 | "The Families Are Partners belief says each teacher speaks with every family each term. What does that look like on this team in practice?" | Shows you read the district's own words and want the practice behind them |
| R6 | "What does a strong first term look like for a new fourth-grade teacher here?" | Converts your stated gap, never having taught fourth grade, into a question about success, and answers what you need to know before accepting |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F2 | The plain acknowledgment: "I've never taught fourth grade." No slot |
| Has been a team lead | Negative the candidate stated, F7 | The plain acknowledgment: "I've never been a team lead." Alongside "I led our grade level's move to a new reading curriculum in 2024," at its own scope |
| Chose or designed the new reading curriculum | Inflated form of F7 and F8 | The quote at its own scope. The limit is the pack's observation: your material says the move, not the choice. A2's slot stays inside the move |
| Speaks with every family each term | Inflated form of F5 and F6 | "I write a weekly email to families," at its own scope. The limit is the pack's observation: the material says the email, not conversations. C3 and E2 keep conversation as a plan or an answer slot |
| Has improved students' reading results through the club | Inflated form of F8 | "I've run the after-school reading club for the last two years," at its own scope. The material says you ran it, not what it produced |

## Sources

Provided documents: the interview invite (Orrinsford Community School District Human Resources) and the résumé text you pasted. The license and personal-identifier numbers in your message were not used in any search or in this pack.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The district's three published beliefs, by name, from the official Mission and Beliefs page: they theme bank E and rows F4, F6, F8. No values cheat sheet, since no values-style round is documented |
| 2. `{company} interview process {role family}` | skipped | The invite already fixes the session count and who is in it (one 45-minute panel, the principal and two team members), which is everything this target feeds: persona weights and the loop |
| 3. `{company} strategy` / recent news | yes | The board's August 2026 literacy plan: questions C2 and R4 |
| 4. `{interviewer name} {company}` | yes | Section Reading the interviewer, R1 and R2; one speaker page, from its search snippet only |
| 5. representative `{role title}` JD | yes | Rows F3, F4, F5, F7, labeled `[inferred]`; the listing's text came back truncated, so only its quoted lines are used |

Searches sent: "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs. "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan. "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren. "Fourth Grade Teacher Illinois elementary job description responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher. Fetches: the Mission and Beliefs page and the literacy-plan page, both read.

## Upgrade menu

- The posting's full text → F3, F4, F5 and F7 move from `[inferred]` to `[grounded]`, and the JD-tagged questions are tightened to its own words
- The two team members' names and roles → persona weights per panelist and a reverse question tied to each one's path
- Any note from HR on what the panel will focus on, or whether a demo lesson or writing sample is expected → a graded-deliverable section if one is announced; usually one email to HR
- Your answers to the answer slots in F3, F4, F6, F8 and questions A2, A4, D1, D2, F1, F2 → those rows and questions upgrade from slots to story-mapped guidance
- How much prep time you have → a prioritized schedule sized to it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the district, a deeper read on the principal's published themes, and role-family loop reports
- A tuesday-dossier.md from an earlier role check → an evidence-derived top objection and prohibited-claims list in place of the ones this pack inferred
