# Interview prep pack: Customer Support Specialist, Lumenvale Software

- **Role:** Customer Support Specialist (remote), Lumenvale Software
- **Interviewer:** the support team lead, unnamed. Your message says the interview is a text chat with them.
- **Relationship assumed:** treated as a hiring-manager round, because your message does not say whether this person would be your manager.
- **Mode:** session, one round.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: it holds the beats your own sentences carry, and anything past them is an answer slot for you to fill truthfully or decline plainly. Your round is a typed chat, so rehearse by typing short answers; each guidance cell is sized to be typed or said in about two minutes.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values: whether past behavior shows what the employer says it values |
| EXP | Work-experience deep-dive: whether the CV's claims survive scrutiny, and what was actually yours |
| JD | Role-driven: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge. No CO questions are in this pack, because company research was not permitted |
| CASE | A live problem from the role, scored on structure and reasoning |

The highest-ROI prep is A1. It targets the gap this interview is most likely to press, and a rehearsed, calm answer changes the whole conversation.

## Fit snapshot

The ad's requirements are quoted from your message, where you listed them. Paste the full ad and I will replace them with its exact lines.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you listed it in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but one line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: three years, advisor, energy supplier. Do not retitle the job |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you listed it in your message | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your sentence names the tool and how often, and it answers the ad's "or a similar ticketing tool" line in other terms. Say it as you said it: "I use Freshdesk every day." Your material names Freshdesk and not the ad's named tool, and the words stay there. Answer slot: if asked about other tools, say plainly which you have used and which you have not |
| F3 | "clear written communication" — the job ad, as you listed it in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | A count of calls and emails is not a sample of your writing, and the bridge should not be stretched into a claim about how well you write. Answer slot: the ad's line makes a probe on your writing likely. If you have a set way of writing a reply, say what it is; if you do not, say so plainly and describe how you write one |
| F4 | "confidence handling escalations" — the job ad, as you listed it in your message | none given | none | [grounded] | discovery | Your material says nothing on escalations either way, so the words are an answer slot. The ad's line makes a probe likely. If you handled escalated cases, say what the case was and what part you took, in your own words; if escalating was not part of your role, or not yours, say so plainly and describe how you would handle one |
| F5 | Familiarity with supporting a software product: a role-family expectation, not a line in the ad as you listed it | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-support work, and nothing added to make the gap feel smaller |
| F6 | Helping colleagues learn a process: a role-family expectation, not a line in the ad as you listed it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap in what the sentence says, and it stays at its own scope: four new starters, the refunds process, last year. Say it as you said it |

## Persona table

Weights follow three passes. The relationship prior for a hiring-manager round puts the Case/Strategist and the Skeptic first. Nothing is known about this interviewer, so there are no signal adjustments. The loop is one text chat per your message, and it names no values round.

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the gaps: the software background, escalations, why this role | 5 | The prior puts it first for a hiring-manager round, and F5 and F4 are the two rows it would press | Rehearse A1 until it is boring. Build bridges only from your quoted sentences and say plainly where they stop |
| B. Case/Strategist | Live support problems: an angry customer, an escalation, a batch of tickets | 4 | The prior pairs it with the Skeptic, and the ad names escalations and written communication, both easy to test live | Clarify first, then structure, then answer. Think aloud in your typing, and challenge one premise politely |
| C. Conversational | Friendly, loose questions: your journey, what you do in Freshdesk | 3 | A chat opens with it in almost any loop, and its questions are still scored | Have a short arc ready and treat the casual questions as scored |
| D. Data-Driven Prober | Digs into the one headline figure: around 60 calls and emails a day | 2 | F3 holds a figure, so it earns a bank, but nothing signals a data-heavy interviewer | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| E. Pressure | Time-boxed, challenging: why you, how much was actually you | 2 | A "why you" push can come from any manager, but the prior does not put it first | Pause, restate, hold the position through two follow-ups, then concede only what is true |
| G. Values/Behavioral | Customer-first and honesty scenarios | 2 | Your invite names no values round and I could not look for one, so this stays light | Use the selection scaffolds and the plain-branch ending when no story comes to mind |

The Peer Evaluator has no bank: the invite names a team lead, not a peer. If the lead turns out to be a peer, say so and a bank is added. The letter F is skipped for personas so question IDs do not collide with fit rows.

## Question banks

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | A3, A5, C1, E1 |
| "experience with Zendesk or a similar ticketing tool" | C3, B4 |
| "clear written communication" | A4, B3 |
| "confidence handling escalations" | A2, B1, B2 |
| Software context (F5, not in the ad as you listed it) | A1, A5, E1 |
| Helping colleagues learn a process (F6, not in the ad as you listed it) | C1, C2 |

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" — your message | The highest-ROI rehearsal in this pack. Name the part honestly, in your own words. Your thinnest software ground is F5, so say it plainly: "I've never worked for a software company." Then say how you would learn the product, as a plan for your first weeks and never as something already done. Do not offer software exposure your material does not state, and hold the rest of what you told me at its own scope | F5 is the largest gap in the snapshot, so this probe arrives in some form. JD because it scores fit against the listed role |
| A2 | "Tell me about a time you handled an escalation." | JD | [grounded] | No sentence in your material carries this story (F4 has none given), so this is a selection scaffold. Pick a case that needed more than the first reply, with a named stake, the choice you made and how it ended, and only a case you were in. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is the ad's own line and your material is silent on it, so a probe is likely. JD because it scores a stated requirement |
| A3 | "You've been an advisor at an energy supplier. Why this role, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" — your message | Start from the sentence: three years as an advisor at an energy supplier. Your reasons for this role are not in your material, so this is an answer slot. Give your real reason, in your own words, one that is true and about this role, and not a general reason that could fit any job | The Skeptic's motivation probe, built on F1. EXP because it tests the story behind the CV line |
| A4 | "How do you make sure a written reply is clear before you send it?" | JD | [inferred] "answering around 60 calls and emails a day" — your message | Describe your own habit, in your own words. Your sentence carries the volume, "answering around 60 calls and emails a day", and nothing about how you check a reply. Answer slot: if you check or structure replies in a set way, say how; if you have no set way, say so plainly and describe how you write a reply | F3 is the thinnest requirement row, and the ad's line asks for clear written communication. JD because it scores that stated line |
| A5 | "What from your energy supplier job would carry over here, and what wouldn't?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" — your message | Carry over, in your own words: the three years as an advisor, answering around 60 calls and emails a day, and using Freshdesk every day. Those are what your sentences carry. What wouldn't: "I've never worked for a software company." Say it that plainly and stop. Do not list skills your sentences do not mention | The question presses F1, F2, F3 and F5 together. JD content, EXP delivery |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry: the product stopped working, and they have already emailed twice without an answer. You pick up the third email. What do you do first?" | CASE | [generic] | This asks about no past, so the guidance makes no claim about yours. Clarify first: what stopped, since when, what they already tried. Then structure: own the delay before the fix, give the fix or the handover, say when they will hear from you next, and note what the next person needs. Pick a first move and say why | A live problem from the ad's escalations line (F4), asked as a decision. CASE because it scores structure. [generic] because it is a pattern for the problem, not a fact about this employer |
| B2 | "When do you escalate a ticket instead of working it yourself, and what goes in the handover?" | CASE | [generic] | Structure it: what tells you it is beyond your access or knowledge, what time or risk is involved, how long the customer has already waited. The handover holds what the customer said, what was tried, what you need from the next person, and what the customer was told. The question needs no claim about your past, so the guidance makes none | F4's requirement turned into a decision rather than a record |
| B3 | "I'll paste a customer's complaint into this chat. Write the reply you would send." | CASE | [generic] | Short and in order: acknowledge what happened in their words, say what you will do, say what they need to do if anything, say when they will hear from you. No jargon. Ask one clarifying question first if the complaint leaves a gap. This is the same skill F3 names, shown instead of described | F3's line asks for clear written communication, and a typed chat is the format your message describes |
| B4 | "Three tickets land at once: a customer who cannot log in, a bug report many users could hit, and a question about an invoice. In what order do you take them, and what do you need to know first?" | CASE | [generic] | Clarify before ranking: how many people are affected, what is blocked, what has a deadline. Then rank by reach and by what is blocked, say what you would tell the two customers waiting, and accept that you might re-rank when you learn more. Think aloud | A triage problem that sits inside a ticketing tool (F2) without claiming any history |

### C. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey to here." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I trained four new starters on our refunds process last year" — your message | A 90-second arc in your own words: three years as an advisor at an energy supplier, then training four new starters on your refunds process last year, then why this role. Your reason for this role is an answer slot because your material states none, so give your own. Keep to those beats | F1 and F6 give the beats. EXP because the biography question tests the CV's story |
| C2 | "Tell me about training the new starters on refunds. How did you go about it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Tell what the sentence carries: four new starters, the refunds process, last year, in your own words. Say what you actually did, and if you are asked for more than you remember, say so plainly rather than filling the gap | F6 is the only row about helping colleagues. EXP because it tests what was actually yours |
| C3 | "What do you actually use Freshdesk for these days?" | JD | [grounded] "I use Freshdesk every day" — your message | Open with it: "I use Freshdesk every day." Then say which parts of it you use, in your own words. Answer slot: the ad's "or a similar ticketing tool" line makes a probe on other tools likely. If you have used others, say which; if you have not, say so plainly and stay with Freshdesk | F2 is the requirement row. JD because it scores the tool line |

### D. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how 'around 60 calls and emails a day' was counted." | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Say what you know about how the figure was counted, in your own words, and say plainly where you do not know. Keep "around", and keep calls and emails together. Do not turn it into a daily total of one kind. Answer slot: if you know how calls and emails were counted, say how; if the count was an estimate or not yours to know, say so plainly | F3 holds the one headline figure in your material, and a figure is where a Prober starts. EXP because it tests how the number is known |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Name it yourself before they do, in your own words. Your material states no assumption, so this is an answer slot: if you know of one, say what it is; if you do not, say so plainly and say you would not claim the figure beyond what your sentence says | The Prober's second-level follow-up on F3. Naming it first turns a gotcha into credibility |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already supports software?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" — your message | Hold then concede. Pause, restate the question, and hold on what your sentences carry: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day." Hold through two follow-ups. Concede the software gap specifically with "I've never worked for a software company," and do not fold on the three years. Do not claim to be better than someone you have not met | F1 and F5 are the two rows this question presses. JD because it scores fit against the listed role |
| E2 | "That volume — how much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Answer from the sentence: you were answering them. If some were handled with others or passed on, say so plainly; if none were, say that, and add no detail. Hold through two follow-ups | The attribution probe on F3's figure. EXP because it tests what was yours |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold, since no sentence in your material carries this story. Pick a time with a named customer situation, the target or rule pulling the other way, the choice you made and what happened after, and only a time you were in. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Values/Behavioral stem. VAL because it scores behavior. [generic] because company values were not researched |
| G2 | "Tell me about a time you delivered an unpopular truth, to a customer, a colleague or a manager." | VAL | [generic] | The same scaffold: a named situation, what the truth was, who did not want it, what you did and how it landed. Choose a time where the hard truth actually landed, and only a time you were in. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Values/Behavioral stem. VAL because it scores behavior |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What does a first week look like for a new Customer Support Specialist, and which tools would I be using?" | It shows you are planning to learn the stack, and it speaks directly to F2 and F5 |
| 2 | "Which kinds of tickets does the team escalate most often, and who picks them up?" | It gets you the shape of escalation on this team, which is the thing F4 asks about |
| 3 | "How does the team handle a product question that isn't covered in the help material?" | It turns the software gap into a question about how the team learns, which is where you would start |
| 4 | "How is the quality of written replies reviewed here?" | It ties to F3 and tells you the standard you will be held to |
| 5 | "What would make someone clearly good at this job after three months?" | It tells you what to aim at and shows you think in outcomes |
| 6 | "Is there a step after this chat, such as a call or a video conversation, and what should I prepare for it?" | It lets you prepare for the next round's format |

## Prohibited claims

What this pack will not coach, with the basis and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2: it borrows the ad's tool name for a sentence that names Freshdesk | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk and not the ad's named tool |
| Resolved around 60 tickets a day | Inflated form of F3: it swaps "answering" for "resolved" and "calls and emails" for "tickets" | F3's quote at its own scope: "answering around 60 calls and emails a day." The limit is the pack's observation: your material gives an approximate count of calls and emails together |
| Ran the training programme for new starters | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says four new starters and the refunds process |
| Has worked for a software company | A negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |

Escalations (F4) and the way you write replies (F3) are not listed because your material is silent on them. They are answer slots, not prohibited wording.

## Sources

**Provided documents:** your message, which holds the invite text, the ad's requirements as you described them, and your background. No `tuesday-dossier.md` was present. Your own words establish the loop for this pack: one text chat with the support team lead. They name no values round, so there is no values cheat sheet.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| Lumenvale Software company values | refused |
| Lumenvale Software interview process customer support specialist | refused |
| Lumenvale Software strategy news | refused |
| a search for reports of recruitment scams that use this company's name | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The search was refused. It would have supplied the official value names and a values cheat sheet if a values round exists. Nothing from memory stands in for it |
| 2. `{company} interview process {role family}` | unavailable | The search was refused. It would have supplied loop structure beyond your invite and sharpened the persona weights |
| 3. `{company} strategy` / recent news | unavailable | The search was refused. It would have supplied the current-strategy facts a CO bank needs, so this pack has none |
| 4. `{interviewer name} {company}` | n/a | The invite names no interviewer, only a support team lead, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The requirements you listed from the ad fix the fit snapshot and the JD-tagged questions |
| Un-numbered: scam-report search | unavailable | The search was refused. It was outside the declared targets, and it moved nothing |

## Upgrade menu

- The full text of the job ad → rows F1 to F4 become exact quotes instead of your summary, and any requirement you did not mention gets a question
- The ad's terms on hours, time zone and pay → gate rows are added to the snapshot, which has none now because your summary names none
- Anything said about what the chat will cover or how long it runs → persona weights are recomputed, and any announced task gets its own build section
- Your answers to the answer slots in F3 and F4 → those rows are regenerated from your own words, and the guidance for A2 and A4 becomes story-mapped
- Permission for the company searches that were refused → rows 1 to 3 above become established, and the pack gains a CO bank on the company's current strategy and a values cheat sheet if a values round exists
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, once searches are allowed → a strategy brief and the company's recent organisational context
- The interviewer's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- A `tuesday-dossier.md`, if you have one → verified evidence and any prohibited claims arrive pre-graded, and the highest-ROI objection comes from evidence rather than inference
