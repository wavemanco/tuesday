# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Round: one 30-minute video call with the office manager, per the invite as you gave it to me. Interviewer: office manager, name not given. Relationship assumed: hiring-manager style, since the office manager is the one session named. Prep time: not stated.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. An answer slot is an instruction for the interview, not a question for me: answer whichever branch is true for you.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the employer's published values |
| EXP | Whether your own background survives scrutiny |
| JD | Whether you can do the listed duties, gaps included |
| CO | What you know about the company |
| CASE | How you structure a live problem from the job |

The highest-ROI prep in this pack is A1, the invoice question: it is the duty where your material is furthest from the ad's wording, so it will be probed in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | presentation | Your sentence reaches calendar work in other terms. Words, at their own scope: "As a receptionist for two years I ran the appointment book for four physios." Nothing inspected stands behind the line, so expect a probe on how the book was kept; add no step to it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad's travel line makes a probe on what you have booked likely. If you have booked any travel or events, say what, in your own words; if you have not, say so plainly and say how you would learn the employer's booking process, as a plan |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | A self-rating with nothing inspected behind it, and it does not yet show which documents. The words stay: "I'm good with Word, okay with Excel." Answer slot: the ad's Word-and-Excel line makes a probe on what you have prepared likely. If you have prepared particular documents or sheets, name them in your own words; if you have not, say so plainly and name what you would learn first |
| F4 | "processing supplier invoices" — the ad, as you described it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | Your sentence says chasing unpaid invoices; it does not show which invoices, or whether any step beyond chasing was yours. The words stay at that scope: "I chased unpaid invoices." Answer slot: if any step of chasing them was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you chased them |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A4, B1, C3, D1, D2, G2 |
| "booking travel" | A2, B2, G1 |
| "preparing documents in Word and Excel" | A5, B4 |
| "processing supplier invoices" | A1, B3, D3 |
| Remote working (title of the role) | A3 |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of where your background sits furthest from the ad | Highest. Your one named interviewer is an office manager, a hiring-manager-style role, and the Skeptic is that row's prior; F2 and F4 are the thinnest rows | Rehearse A1 until it is boring: say what your sentence says, hold it at that scope, then a plan said as a plan |
| Case (B) | Small live problems from the four listed duties | High. The same hiring-manager prior, and a 30-minute call has room for two or three quick scenarios | Clarify first, then structure, then say how you would confirm; no claim about your past needed |
| Conversational (C) | Friendly opener, "walk me through your journey" | Medium. A short video call usually opens this way, and casual questions are still scored | A 90-second arc built only from your own sentences |
| Prober (D) | Detail on the appointment book and the invoices | Medium. Your sentence carries a figure, four physios, and two named duties | Know what you can and cannot say about each; say plainly when you do not know |
| Peer (E) | "What would you need from me" collaboration questions | Low. The office manager is not described as a peer; if they are, say so and I will reweight | Principles, not pretended knowledge of their setup |
| Pressure (G) | Time-boxed or "how much was you" challenges | Low. Nothing in the invite signals a stress style | Hold for two follow-ups, then concede only what is true |

Weights rest on the invite's own description of one 30-minute session; no archetype was assumed.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role includes supplier invoices. What have you done on the invoice side?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the sentence carries: "I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe on your part in them likely. If any step of chasing them was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you chased them. Then a plan, said as a plan: what you would ask first about how invoices are logged and approved here. Never describe handling you did not do | F4 is the row furthest from the ad's wording, so this objection arrives in some form; JD because it scores a stated duty |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Selection scaffold: pick the listed duty you have done least; say so plainly; then give the nearest thing your material does carry, or how you would learn it in the first month, said as a plan and not as a past. If no duty stands out, say so plainly and name the one you would want a walkthrough of first | F2 and F4 are the rows with least behind them, and this is the standard Skeptic stem; JD because it scores the listed duties |
| A3 | "Why a remote administrative role?" | JD | [generic] | Selection scaffold: give your own real reason, in two parts: what draws you to administrative work, and what draws you to working remotely. If no clear reason comes to mind, say so plainly and say what you want from the work. Claim nothing about your past here | The title says remote, so the question is likely; JD because it tests fit with the role as posted, and it needs no row |
| A4 | "Your background is a physiotherapy clinic. What will be different for you here?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Say what your sentence says, in its beats: receptionist, physiotherapy clinic, the appointment book for four physios. For the differences, say only what you have read on the company's own site or in the ad, and then ask the interviewer what a typical week holds. Add nothing about how a facilities company works that you have not read | F1 is the evidence the interviewer is weighing against the ad; JD because it scores fit for the listed job |
| A5 | "You've described your Excel as okay. What would you be doing in Excel here?" | JD | [grounded] "I'm good with Word, okay with Excel" | In your own words: "I'm good with Word, okay with Excel." Answer slot: the ad's Word-and-Excel line makes a probe on what you have built or used likely. If any Excel work was yours, name the task in your own words; if none was, say so plainly and say what you would learn first. Never name a function or feature you have not used | F3 is a low-confidence self-rating, so a specific probe is likely; JD because it scores a stated tool requirement |

### B. Case (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A manager asks you to move a meeting that clashes with two others, and one attendee is in another time zone. Talk me through it." | CASE | [generic] | Structure it aloud: ask who or what can move and by when; list the options; propose one; confirm it in writing with everyone affected; update the calendar; note the change. The question needs no claim about your past, so the guidance makes none | A live problem from the "managing calendars" duty; CASE because it scores structure, not history |
| B2 | "You need to book a two-day trip for a colleague, with a 10 am meeting on day two. What do you ask first, and what do you do?" | CASE | [generic] | Clarify before structuring: dates, who approves the spend, any travel policy, the colleague's preferences. Then options, a confirmed itinerary written down, and what you would do if a leg changed. Claim nothing about trips you have booked | A live problem from the "booking travel" duty, where F2 has no evidence; CASE because it tests reasoning you can show without past experience |
| B3 | "Three supplier invoices arrive: one for an amount you don't recognise, one with no order reference, one that looks already paid. What do you do?" | CASE | [generic] | Say you would check each against the order or approval record you are given, hold anything you cannot match rather than pass it on, tell the person who approves, and log what you did. Ask how this team handles mismatches. Claim nothing about invoices you have handled | A live problem from the "processing supplier invoices" duty, the thinnest row, F4; CASE so the answer rests on method |
| B4 | "How would you lay out a one-page summary of a manager's week in Word or Excel?" | CASE | [generic] | Describe the layout you would propose: date, time, place, contact, notes; say you would check it with the person it is for before settling it. Which tool you would pick is your own call; say why. No claim about templates you have made | The "preparing documents" duty as a live task; CASE because F3 gives no document to talk about |

### C. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc in the beats the sentence states: two years as a receptionist, a physiotherapy clinic, the appointment book for four physios, chasing unpaid invoices. Close with your own reason for this role. Answer slot: if you want to add what drew you to administrative work, say it in your own words; if nothing specific did, say so plainly and stop at the beats | The standard opener on a short call; EXP because it scores your own account of your background, F1 and F4 |
| C2 | "What do you know about us?" | CO | [generic] | Say only what you have read yourself on the company's own website or careers page, and the duties in the ad as you described them: "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices." If you found nothing beyond the ad, say so plainly and ask what the interviewer would most like you to know | CO because it scores homework; labelled generic because research was refused in this run, so the pack holds no fact about the company |
| C3 | "Tell me about a time several people wanted the same slot in a calendar." | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Selection scaffold: pick an occasion where bookings competed; say what your part was and what you did, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I ran the appointment book for four physios", or how you would handle it | The theme comes from the ad's calendar duty; JD because it scores the listed duty, and F1 is its only evidence |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Walk me through how that worked day to day." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Beats from the sentence: the appointment book, four physios, your two years as receptionist. Answer slot: the ad's calendar line makes a probe on how you kept the book likely, such as which tool and how changes were handled. If you did something specific, say what, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you ran the book | F1 is the likeliest place to be probed in detail; EXP because it tests what was actually yours |
| D2 | "Roughly how many appointments a day did the book handle?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Defend-the-number slots, in your own words: how any figure you give was counted, what it is sensitive to, which assumption behind it you would defend least. If you do not know the figure, say so plainly and say what you do know: "four physios." Do not estimate to fill the gap | The only figure in F1 is four physios, and probers go to numbers; EXP because it scores precision about your own work |
| D3 | "Tell me about the unpaid invoices you chased. What happened when you did?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Say what the sentence says: "I chased unpaid invoices." Answer slot: if you know what followed from chasing any of them, say it as you know it, in your own words; if you do not know, or it was not yours to see, say so plainly. No figure and no outcome that is not yours | F4 holds the one invoice-related sentence you have; EXP because it scores whether the claim survives a follow-up |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "When a manager's priorities and a colleague's request pull in different directions, what do you do?" | CASE | [generic] | Principles, not a pretended past: find out whose deadline is fixed, tell both people what you are doing and why, escalate to the person who sets priorities only when you cannot resolve it. No claim about a past occasion | A seam question in a collegial register; CASE because it asks for reasoning on a live situation |
| E2 | "What would you need from me to do this job well?" | JD | [generic] | A short list: who sets priorities, what you may approve and what needs sign-off, which systems you can access, whom to ask when stuck. Offer one thing you would bring in return, from what your sentences carry, in your own words | The peer stem on reciprocity; JD because it tests how you would work inside the listed duties |

### G. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why should we choose you?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Hold what the sentence carries: two years as a receptionist, the appointment book for four physios, chasing unpaid invoices. Hold it through two follow-ups. Concession slot: name, in your own words, which listed duty you have done least; if you cannot say which, say so plainly; then give your first-month plan for it | Time-boxed and composure-testing; JD because it scores fit against the ad, with F1 and F4 as the quotes it rests on |
| G2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Hold the sentence: "I ran the appointment book for four physios." Answer slot: if others also kept or changed the book, say who and what was yours; if it was yours alone, say so plainly. Never widen it to cover work the sentence does not state | The standard attribution challenge on F1; EXP because it scores honesty about your own part |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like in this role: which of the calendar, travel, document and invoice work takes most of it?" | It shows you are sizing the job against its listed duties, and it tells you where to aim your examples |
| R2 | "Which calendar and booking tools does the team use, and what would I learn first?" | It signals you plan to ramp on their tools, and it gives you something concrete to prepare |
| R3 | "How do supplier invoices move through the team today, from arrival to approval?" | It turns your thinnest area into a conversation about process, in the interviewer's own terms |
| R4 | "What would a good first month look like?" | It shows you think about results early, and the answer tells you what to rehearse |
| R5 | "What happens after this call, and roughly when?" | It shows interest in next steps and lets you plan your own timeline |
| R6 | "What could a new person do in their first month that would genuinely help you?" | The reciprocity question: it frames you as someone who lightens their load |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive or senior-staff calendars | Inflated form of F1 | F1's sentence at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: your material says an appointment book for four physios. D1's slot stays inside the book |
| Processed or approved supplier invoices | Inflated form of F4 | F4's sentence at its own scope: "I chased unpaid invoices." The limit is the pack's observation: your material says chasing, not the processing the ad lists. A1's slot stays inside the chasing |
| Strong or advanced Excel skills | Inflated form of F3 | F3's sentence at its own scope: "I'm good with Word, okay with Excel." A5's slot asks only what Excel work was yours |

## Sources

Provided documents: your message, containing the interview invite as you pasted it, the ad's duties as you described them, and your background. No tuesday-dossier.md was present.

Searches sent:

- `Brennock Facilities Ltd values` — refused
- `Brennock Facilities Ltd interview process administrative assistant` — refused
- `Brennock Facilities Ltd strategy recent news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | All calls were refused. It would have fed a values cheat sheet and C2; neither is in this pack, and C2 is labelled generic |
| 2. `{company} interview process {role family}` | unavailable | All calls were refused. It would have documented the loop; the invite's own words already fix one 30-minute video call with the office manager, so persona weights rest on that |
| 3. `{company} strategy` / recent news | unavailable | All calls were refused. It would have fed a strategy-grounded CO or CASE question; none is in this pack |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The duties you quoted from the ad fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → F1 to F4's requirement cells quote the ad itself rather than your description of it, and any further duties in it get rows and questions
- Your CV, pasted → the evidence cells quote it, and rows now resting on one sentence could move up or down
- A sentence or two on any travel or event booking, any Excel task, and the kind of invoices you handled → F2, F3 and F4 evidence cells, and the answer slots in A1, A5, B2, D3 become story maps
- The office manager's name → an interviewer read, persona weights tuned to their public professional footprint, and a reverse question tied to their path
- Prep time available → a prioritized schedule sized to it
- The company's own careers or values page, pasted → the CO row and C2 become grounded, and any values-style round it documents adds a cheat sheet
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for CO and CASE questions, if you want it
- A tuesday-dossier.md from an earlier session → verified evidence and strategy limits for weak areas; the pack stands without it
