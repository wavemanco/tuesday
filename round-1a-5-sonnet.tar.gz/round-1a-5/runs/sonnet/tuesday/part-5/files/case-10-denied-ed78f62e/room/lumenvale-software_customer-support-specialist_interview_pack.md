# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote), Lumenvale Software
**Interviewer:** the support team lead, name not given
**Format:** one written chat with the support team lead, per your message
**Built on this assumption:** the team lead is your likely line manager, so the pack uses the hiring-manager weighting. If they are a peer or something else, the persona weights change.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows what the company says it values |
| EXP | Work-experience deep-dive: whether your claims survive a follow-up |
| JD | Role-driven: the stated requirements, including your gaps |
| CO | Company knowledge: what you know about what they make and who uses it |
| CASE | A live problem from the role, answered on the spot |

Because the interview is written, your replies are themselves samples of the written communication the ad asks for. Rehearse typing the answers, not only thinking them.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: three years, customer service advisor, energy supplier. Keep your own job title and do not relabel it as support work |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap, with a limit: your material names Freshdesk, not Zendesk, and says use, not set-up or administration. Say it in the quote's terms: you use Freshdesk every day. Expect a probe on what you do in the tool |
| F3 | "clear written communication" — job ad, as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails touch written work, but the quote does not show whether replies were clear or what share of the 60 were emails. Your words stay "answering around 60 calls and emails a day". Answer slot: the ad's written-communication line makes a probe on your replies likely, and this chat is itself a sample. If you have a way of keeping a reply clear, say what it is in your own words; if there is none you can name, say so plainly and stay with the volume you answered |
| F4 | "confidence handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material does not mention escalations either way. Answer slot: expect a probe on escalations. If you handled any, say what one looked like and what part of it was yours, in your own words; if your work had no escalation step, or it was not yours, say so plainly and stay with the work you have described |
| F5 | supporting customers of a software product (role-family requirement, no source supplied) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn their product, said as a plan and never as a past. The nearest adjacent evidence stays at its own scope: "I use Freshdesk every day". Never a claim to software support work, and nothing added to make the gap feel smaller |
| F6 | no ad line asks for it; included because a team lead may ask about it | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap against any requirement, but a message line with nothing inspected behind it. Keep the quote's scope: four new starters, the refunds process, last year. Nothing about how the training went is in your material, so it stays your words |

No requirement you listed is a gate (a licence, location, schedule or similar term), so the snapshot carries no gate row.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of the biggest gap, then the move itself | High. A hiring-manager round is weighted toward Case and Skeptic, and F5 is a gap you stated yourself | Rehearse the software-company objection until it is boring. Your honest limit is your own sentence: "I've never worked for a software company". Add a plan for learning the product, said as a plan |
| Case / Strategist (bank B) | Live problems from the role, answered in writing | High. Same hiring-manager prior, and a written chat suits typed cases | Ask what you need first, structure the reply, say the structure before you use it |
| Conversational (bank C) | Friendly openers such as "walk me through your journey" | Medium. A chat tends to open informally, and those answers are still scored | A 90-second arc built only from your own quoted lines |
| Data-Driven Prober (bank D) | Goes line by line through your numbers | Medium. "around 60 calls and emails a day" is a figure a lead can press | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure (bank E) | Short, challenging, time-boxed | Lower. The ad's escalation line is where composure would be tested | Hold your position through two follow-ups, concede specifically, never fold on what your own sentences carry |
| Values / Behavioral (bank G) | Scenario probes about customers and honesty | Lower. No company values page was available to this pack, so the prompts are generic | Pick stories from your own work; if none comes to mind, say so plainly |
| Peer Evaluator | Seam-splitting between teams | Unlikely. Your interviewer is the team lead, not a peer, so there is no bank | None needed |

The loop is established by your own words: one written chat with the support team lead. No archetype fallback is used.

## Question banks

Question IDs run by persona, ordered by weight. The letter F is kept for fit-snapshot rows, so the values bank is G.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've come from an energy supplier. Support at a software company is a different world. What makes you think you can make the jump?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Say the limit first, in your own sentence: "I've never worked for a software company." Then the adjacent work at its own scope: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Then a plan: name the first two or three things you would learn about their product and how you would learn them. Hold through two follow-ups by returning to those quotes, never by adding to them | F5 is the gap you stated and the one most likely to be raised in some form. JD because it tests the role's fit; the candor is the rehearsal |
| A2 | "Tell me about a time you handled an escalation." | JD | [grounded] | The ad's escalation line raises this, and no sentence of yours carries a story for it, so this is a selection scaffold. Pick a time a case needed someone else's decision or a more senior person; it needs a named situation, what you did, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is where your material is silent. Asked as an open prompt so it assumes nothing about your past |
| A3 | "Which part of this job would you be weakest at on day one?" | EXP | [grounded] "I've never worked for a software company" | Pick the weakest area honestly. The one limit your material states is your own sentence, "I've never worked for a software company", and you can use it. Pair it with a concrete first-month plan. Do not name a weakness you do not have in order to sound modest, and do not hide the one you have | F5 and F4 are the two thin rows. The stem is a standard Skeptic probe |
| A4 | "The ad mentions Zendesk or a similar tool. Which tool have you used, and how would you pick up ours?" | JD | [grounded] "I use Freshdesk every day" | Say what the quote says: you use Freshdesk every day. Answer slot: if you have used Zendesk, say where and for how long; if you have not, say so plainly and stay with Freshdesk. Then say how you would learn a new tool, as a plan | F2 reaches the requirement through "or a similar ticketing tool", and this probe tests whether you stay inside it |
| A5 | "Why this move, and why now?" | EXP | [generic] | Your material does not state a reason for moving, so the pack supplies none. Give your actual reason in your own words, and keep it to what is true. If one of the ad's four requirements is what drew you, say which; if something else did, say that. Read the company's own site before the chat so what you say about them is what you read | Motivation consistency is the Skeptic's other target. No part of this answer rests on a quoted sentence of yours |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes: 'I was charged twice this month and nobody has answered my last two messages.' Type your first reply." | JD | [generic] | A live problem that assumes nothing about your past. Structure it: acknowledge the double charge and the silence, say what you will check, say what happens next and when they will hear back. If you would need account details first, ask for exactly those. Keep it short and plain, since the reply is the sample | F3's requirement tested directly. JD content, CASE delivery |
| B2 | "A customer demands a manager and says they will cancel. You cannot give them what they are asking for. What do you do?" | CASE | [generic] | Structure: find out what they actually want, say what you can do, say plainly what you cannot, and if it goes to someone with more authority, say what you would pass on so the customer does not have to repeat themselves, and what you would record. The question needs no claim about your past, so the guidance makes none | The ad's escalation line as a live decision rather than a story |
| B3 | "Three tickets arrive at once: a customer locked out of their account, a billing question, and a bug report. What order, and why?" | CASE | [generic] | Say the structure aloud first: ask what you would need to know about urgency, state your order, give the reason for it, say what you would tell the other two customers. Name one assumption your order depends on | Prioritization is a standard live problem for a queue-based role |
| B4 | "A customer asks how a feature works and you have not used it yet. Walk me through the next ten minutes." | CASE | [generic] | Structure: say honestly to the customer that you are checking, find the answer from a source you would trust, confirm it before you send it, and tell the customer what you found. Make no claim to a process you have used in the past | This is F5 as a live problem: how you behave when the product is new to you |
| B5 | "What do you know about what we make and who uses it?" | CO | [generic] | No research on Lumenvale was available to this pack, so it supplies nothing about the company. Before the chat, read the company's own site and product pages, then say only what you read. If you find little, say so plainly and ask them | A homework check. Generic because the research calls were refused |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | A 90-second arc with four beats, one per quote: the three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day, Freshdesk every day, and training four new starters on your refunds process last year. Tell each in your own words and add nothing the quote does not say. Close with where you want to go next, in your own words | F1, F2, F3 and F6 are the whole of your quoted material, so this arc is the base the other answers return to. EXP because it is the CV walk-through |
| C2 | "Tell me about training the new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats the quote states: four new starters, the refunds process, last year. Tell them in your own words, and describe only what you did yourself; if you are unsure of a detail, say you are not sure | F6 is a strength to rehearse and not to enlarge. EXP because it tests what was actually yours |
| C3 | "What does a good written reply look like to you?" | JD | [grounded] | A casual question that scores the ad's written-communication line. No sentence of yours carries a story for it, so this is a selection scaffold: pick a real reply you were proud of, say what made it clear, and keep it to what you actually wrote. If none comes to mind, say so plainly, then describe how you aim to write a reply | F3 is thin, and a friendly register is where it is asked casually. JD content, asked in a conversational style |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted, and what would change it?" | EXP | [grounded] "answering around 60 calls and emails a day" | Defend-the-number slots, each in your own words. How the figure was counted, if you know; if you do not know, say so plainly. What it is sensitive to. The assumption behind it you would defend least. Which part of it was yours. The quote says "around" and does not split calls from emails, so give your actual split or say you do not know it | F3's figure is the likeliest number to be pressed |
| D2 | "Walk me through how you use Freshdesk in a normal day." | JD | [grounded] "I use Freshdesk every day" | The quote carries Freshdesk and every day, and nothing more. Answer slot: the ad's ticketing-tool line makes a probe on what you do in the tool likely. Say what you actually do in it, in your own words; if there is a part of the tool you have not used, say so plainly and stay with what you do | F2 is the evidence for the tool requirement, and a daily-use claim invites a "what exactly" follow-up |
| D3 | "Which of your figures would you be least able to back up: the three years, the 60 a day, or the four new starters?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "answering around 60 calls and emails a day" "I trained four new starters on our refunds process last year" | The weakest-assumption move: choose, in your own words, the one you could back up least, and say what you do know about it. The pack names none. A plain "I know the year and not the count" is a good answer if it is true | F1, F3 and F6 together are all the figures you gave. Naming the weak one before a prober does converts a gotcha into credibility |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I've never worked for a software company" | Hold-then-concede. Hold what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Concede specifically and early: "I've never worked for a software company." Hold through two follow-ups without adding to the first answer | F1, F2 and F5 are all of the evidence for and against this challenge |
| E2 | "You trained four new starters. How much of how they work is down to you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the quote: you trained four new starters on your refunds process last year. Then concede uncertainty specifically: say what you can and cannot say about how they have done since, in your own words. Do not claim their results | F6 invites an attribution challenge, which is a Pressure staple |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | No sentence of yours carries a story for this, so this is a selection scaffold. Pick a time with a named customer situation, the metric or rule it cut against, what you decided, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard support-role behavioral probe. No company values page was available, so it is generic |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold, with no claim made for you. Pick a time the hard message landed, with the stake and the outcome named; if the material you have shows none, say so plainly rather than supplying an ending, then say how you would handle it | The stem is a standard Values prompt. The honest branch matters because no sentence of yours shows a case |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "2+ years in customer support" | E1, C1, D3 |
| "experience with Zendesk or a similar ticketing tool" | A4, D2 |
| "clear written communication" | B1, C3 |
| "confidence handling escalations" | A2, B2 |
| supporting customers of a software product (role-family) | A1, A3, B4, B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first month look like for someone in this role?" | It shows you are planning to contribute, and the answer shapes the ramp plan you give for A1 |
| 2 | "Which kinds of cases does the team find hardest, and how do they get handed on?" | It connects to the escalation requirement and shows you think about handoffs |
| 3 | "How does the team review written replies, and how do new people get feedback?" | Written communication is scored, and asking shows you want feedback on it |
| 4 | "Which ticketing tool does the team use, and how are new people trained on it?" | It ties to A4, and the answer tells you what to practise before day one |
| 5 | "Is there a further step after this chat, such as a call or a video conversation, and is there anything I should prepare for it?" | It lets you plan your preparation for any later round |
| 6 | "What separates the people who do well on this team from the people who struggle?" | A rapport interviewer weighs this slot heavily as a sign of preparation, and the answer is the team's own view of the job |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for, or supported customers of, a software company or product | Negative you stated, F5 | The plain acknowledgment: "I've never worked for a software company." Then a plan for learning the product, said as a plan |
| Ran onboarding, or led a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". The limit is the pack's observation: your material says four new starters and the refunds process, not a programme |
| Resolved around 60 tickets a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day". The pack's observation: the quote says answering and calls and emails, not resolving or tickets |
| Configured or administered the ticketing tool | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The pack's observation: your material says use, not set-up or administration |

## Sources

Provided documents: your message, with the invite's text, the ad's four requirements as you listed them, and your background. No dossier was present.

Searches sent (all refused, no results returned):

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Every call was refused. It would have fed the values prompts in bank G and the CO question; both are labelled generic |
| 2. Interview process | unavailable | Every call was refused. The loop rests on your own words (one written chat with the support team lead), so persona weights did not change |
| 3. Company strategy and recent news | unavailable | Every call was refused. It would have grounded B5; that question is labelled generic |
| 4. Interviewer name | n/a | No name was given for the interviewer, so there was no query to form |
| 5. Representative job description | skipped | The four requirements you listed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad → F1 to F4 would quote the ad's own wording, and any requirement not in your summary (hours, location, working pattern) would be checked and added as a row
- Your CV → more of your own sentences for F3 and F4, and story maps in place of the selection scaffolds in A2, C3, G1 and G2
- A report from your current job that shows your numbers, such as a quality or customer-satisfaction report → F1, F3 and F6 confidence moves from medium or low towards high
- Your answers to the slots in F3 and F4, said outside a drill → both rows move from discovery to graded rows with your own words
- Lumenvale's own values page and interview details, once research is available → bank G, B5 and the A5 guidance become grounded, and a values cheat sheet is added if a values-style round is documented
- The interviewer's name → an interviewer read, retuned persona weights and a reverse question tied to their own path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a strategy brief for B5
- A tuesday-dossier.md from an earlier session → verified evidence and any claims already ruled out, which would sharpen F1 to F6 and the prohibited list
