# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday at 2pm, with Hannah Lowther (Talent Partner). She will ring the mobile number on your application.
**Her stated agenda (her words, LinkedIn):** your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, then the team and the next steps.
**Built on one assumption:** the call follows her agenda, so the logistics questions (A2 to A5) come first and the role questions after. Company research was not available (see Sources), so nothing here says anything about Quillmoor beyond the advert you pasted.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: where it quotes you, those are your own words from your message, and anything past them is an answer slot, an instruction for the call that you meet truthfully either way.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none used here: no values material in hand) |
| EXP | Whether your experience survives scrutiny, and what was actually you |
| JD | The advert's stated requirements and terms, including the gaps |
| CO | Company and strategy knowledge (none used here: no research ran) |
| CASE | A live problem set in the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on whether you worked with any of them on schedules. If you did, say who and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it. The sentence says you rebuilt the spreadsheet and that discrepancies fell by about a third over a year; it does not say one caused the other, so say it at that scope. The probe is rehearsed in C1 and D2 |
| F4 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you tracked or reported on deliveries or dispatch, say what and how often, in your own words; if you did not, or it was not yours, say so plainly and stay with the deliveries you scheduled |
| F5 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, and not what you did in it. Answer slot: if it was an Excel spreadsheet and you used particular functions or features, say which, in your own words; if it was not, or you did not, say so plainly and say what you did use |
| F6 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. The quote is longer than the requirement, in role-relevant terms; say it as written |
| F7 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. This is a plus, not a requirement |
| F8 | "ERP experience (SAP or similar) a plus" — the advert | "we run our own in-house stock system" — your message | low | [inferred] | discovery | The sentence says an in-house stock system, not that it is an ERP or what you did in it. Answer slot: if you worked in it on stock records or orders, say what you did there, in your own words; if you did not, or it was not yours, say so plainly and stay with what you said |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your own constraint, met by the advert's two days. It stays whole: two days is fine, and not more than three. It is never reworded into flexibility |
| F10 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your own figure, and it sits inside the advert's band. It stays as you said it, with no range, floor or flexibility added |
| F11 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish it. Surfaced, not bridged: on the call you give your actual notice period, as it stands |
| F12 | "what's prompting a move" — Hannah Lowther's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. The reason stays whole, in your words, and nothing is added to it |

## Persona table

| Persona | How it shows up on this call | Likelihood and reasoning | Counter-strategy | Qs |
|---|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, unstructured; her four agenda items arrive as chat | Highest. The recruiter-screen prior is Conversational plus a light Skeptic, and her message sets the agenda. No interviewer profile was available, so there is no signal adjustment | Treat every casual question as scored; keep your logistics answers in your own words and short | 5 |
| Skeptic (B) | Quiet probing of the gaps: SAP, delivery versus production scheduling | High. F7 and F1 are the visible gaps against the advert, and a recruiter screens for them | Rehearse B2 until it is boring; bridge only from what you said, and give a plan where there is no past | 3 |
| Data-Driven Prober (C) | Pulls on the third-fewer-discrepancies figure, Excel and dispatch reporting | Medium. You have one headline number (F3), and the advert asks for Excel and weekly reporting | Know how the number was counted and say plainly if you do not | 3 |
| Pressure (D) | A time-boxed "why you" and "how much was you" | Low to medium. Most screens are not adversarial, but the attribution probe is cheap for a recruiter to ask | Pause, restate, hold the sentence you said, concede only what is true | 2 |
| Case / Strategist (E) | A live scenario from the role's own tasks | Low on this call, higher in the next round. Your message establishes this one session only; the advert's tasks (late orders, stock records, three teams) are what a later team conversation would test, so this bank is weighted for prep value | Clarify, then structure, then answer; think aloud | 3 |
| Peer Evaluator (G) | Collaboration with planning, the warehouse and QA | Low on this call; the advert's cross-team wording makes it likely later | Reciprocity framing; propose principles instead of pretending to know the seams | 2 |

No loop source beyond this call was available, so later-round weights rest on the advert's wording alone.

## Question banks

Highest-ROI prep in the pack: **B2**, the question on how delivery scheduling relates to coordinating production schedules between planning, the warehouse and QA. It will arrive in some form, and the honest answer is rehearsed below.

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: what do you do now?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc in three beats, each one a quote's own: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for the three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down about a third over a year. Say "I" only for what those sentences say you did. Stop there and leave the move for A5 | F6, F2 and F3 supply the beats. EXP because it tests whether the story is told economically and survives a follow-up |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Your own words, whole: "I'm hoping for £42,000." Say it once and stop. If asked what you earn now, you can decline: "I'd rather focus on the range for this role." Nothing else is coached on pay | F10 is your figure and sits inside the advert's band. JD because pay is the listed job's term, and it is first on her agenda |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, as it stands. This pack supplies no figure: your message does not state one | F11 is the one logistics item your material does not cover. JD because it is a term of the role |
| A4 | "How would the hybrid pattern, two days a week at Avonmouth, work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the pattern or the journey, say those words again, with nothing added | F9 is your constraint, met by the advert. JD because the pattern is the listed job's term |
| A5 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Your own words, whole: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it plainly, once. If she follows up, the same words again | F12 is the reason and needs no embellishment. EXP because it tests motivation-consistency against your history |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "ERP experience, SAP or similar, is a plus for this role. What have you worked with?" | JD | [grounded] "Never used SAP"; "we run our own in-house stock system" | Words: "I haven't used SAP." Then, in your own words: "we run our own in-house stock system." Answer slot: if you worked in that system on stock records or orders, say what you did there; if you did not, or it was not yours, say so plainly and stay with what you said. Then give how you would get up to speed on SAP, as a plan, never as a past | F7 is the stated gap and F8 the adjacent item. JD because the advert lists it, as a plus |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. How does your delivery scheduling relate to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The highest-ROI rehearsal here. Hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Hold through two follow-ups by returning to that sentence, never by adding to it. Follow-up one, on planning, the warehouse or QA: answer slot. If you worked with any of them on schedules, say who and how; if you did not, or it was not yours, say so plainly and stay with the depots and suppliers. Follow-up two, on the step up: if she says yours is delivery rather than production scheduling, agree with what your sentence says, then give a plan, the questions you would ask on day one, never a past | F1 is the advert's headline requirement and the widest gap, so this objection will arrive in some form. JD because it scores a stated responsibility |
| B3 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP" | Selection scaffold: pick the advert line your own material is thinnest on and name it in your own words. If it is SAP, say "I haven't used SAP," then the plan from B1. If you judge another line weaker, say that line and what you have done near it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7 is the one gap you have named yourself, which makes it the safest to rehearse. JD because the question reads the advert as the scoring sheet |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. Walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say it at its scope: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. "I don't know how it was counted" is an honest answer. Name the weakest assumption before she does | F3 is your one headline number and the likeliest thing to be probed. EXP because it tests whether the claim survives scrutiny |
| C2 | "The role needs confidence with Excel. What do you use it for?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Start from the sentence: you rebuilt the stock-count spreadsheet. Answer slot: if it was an Excel spreadsheet and you used particular functions or features, say which, in your own words; if it was not Excel, or you did not use any, say so plainly and say what you did use | F5 is thin: the quote says spreadsheet and nothing more. JD because Excel is a stated requirement |
| C3 | "The role reports weekly on on-time dispatch. Have you reported on dispatch or delivery performance?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Answer slot: if you tracked or reported on deliveries or dispatch, say what and how often, in your own words; if you did not, or it was not yours, say so plainly and return to the deliveries you scheduled for the three depots | F4 is a requirement your material is silent on, so the honest answer is rehearsed before the probe. JD because the advert lists it |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP" | Pause and restate the question. Hold: the four years as a logistics coordinator at a building-supplies wholesaler, and scheduling deliveries for the three depots and chasing suppliers when orders slip. If pushed on SAP, concede it in your words: "I haven't used SAP," then the plan from B1. Hold through two follow-ups without adding to the sentences | F6 and F2 are the held position and F7 the concession. JD because it scores fit against the listed job |
| D2 | "That drop in discrepancies: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Pause first. Hold what the sentence says: you rebuilt the stock-count spreadsheet. Answer slot: if other people or other changes contributed to the fall, say what they were and which part was yours; if none did, say so plainly; if you cannot say how much of it came from the rebuild, say that. Hold through two follow-ups by returning to the sentence | F3 holds the figure, and attribution probes are how a number gets tested. EXP because it scores precise attribution |

### E. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a key delivery will arrive a week late and a production run is due to start. What do you do first?" | CASE | [generic] | Structure it aloud: what you need to know first (what the delivery feeds, what the run can start without, how firm the new date is); who must hear early (planning, the warehouse and QA are the advert's three); what you ask the supplier; what you record and when you chase again. The question needs no claim about your past, so the guidance makes none | F2 is the requirement behind it. CASE because it is a live decision from the advert's chase-late-orders line; `[generic]` because it is a pattern for the problem, not a fact about Quillmoor |
| E2 | "The system says a batch is in stock but the warehouse cannot find it. How do you approach it?" | CASE | [generic] | Structure it aloud: confirm what the record says and when it last moved; check with the warehouse before changing anything; find where the record and the shelf diverge; correct the record and note the cause. No claim about your past | F3's requirement, asked as a decision. CASE because it scores structure on stock accuracy |
| E3 | "Planning wants a run moved forward, but QA has not yet released the previous batch. How do you handle it?" | CASE | [generic] | Structure it aloud: clarify what is blocked and why; what each team needs and by when; the options and what each costs; who decides and what you record. Ask what you would need to know before recommending anything. No claim about your past | F1's three-team seam as a live problem; this is where B2's plan gets used. CASE because it scores clarifying before answering |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What would you need from the warehouse and QA to do this job well, and what would you give them?" | JD | [generic] | Reciprocity framing: say what you would bring each team (timely, accurate records and early notice of slips) before what you need from them. Propose how you would agree who tells whom when a schedule changes; do not claim to know the seam. No claim about your past | F1 names three teams, so the seams are the job. JD because it scores a stated responsibility |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work crossed teams and the credit was shared; it needs a named piece you did and a relationship left intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's own stem, asked of a role that sits between teams. EXP because it tests attribution when work is shared |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, E3, G1 |
| Track supplier deliveries and chase late orders | A1, E1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A1, D1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) | B1, B3 |
| Hybrid, two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |
| Notice period (Hannah's agenda) | A3 |
| What's prompting a move (Hannah's agenda) | A5 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "Which teams would I work with most day to day, and how do planning, the warehouse and QA split the scheduling between them?" | Shows you read the advert's three-team line, and the answer tells you where B2's step up actually sits |
| R2 | "How is the Avonmouth pattern set: fixed days each week, or agreed with the team?" | Gets the concrete pattern to set against what you told her, in your own words, "I wouldn't want more than three" |
| R3 | "What ERP or stock system does the team use today, and how is a new starter trained on it?" | SAP is a plus, not a requirement; a named system turns your plan from B1 into something specific |
| R4 | "What would a good first three months look like, including the weekly on-time dispatch report?" | Ties to C3 and shows you think in outputs, not just tasks |
| R5 | "After today, what are the next steps and the timeline?" | She said she would cover next steps; asking for a timeline signals interest and lets you plan around your notice |
| R6 | "Is this a new post or a replacement, and how big is the team around it?" | Calibrates the scope of the role, and keeps your answer to "any questions for me?" specific rather than "I think you've covered everything" |

## Prohibited claims (not coached)

| Not coached | Basis | Honest form |
|---|---|---|
| Scheduled production, or coordinated planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says deliveries for three depots, not production. B2's slot stays inside the depots |
| Has used SAP, or has ERP experience equal to SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't used SAP." Then a plan, never a past |
| The in-house stock system is an ERP | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material says an in-house stock system, not that it is an ERP |
| The spreadsheet rebuild alone cut discrepancies by a third | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the sentence gives the rebuild and the fall, not that one caused the other. C1 and D2 slots stay inside it |
| Flexible on pay, or willing to do more than the office days you stated | Your stated limits, F9 and F10 | Your own words, whole: "I'm hoping for £42,000" and "I wouldn't want more than three." Nothing added, no range or floor |
| Redundancy, or that your role is being cut | Inflated form of F12 | F12's quote at its own scope: the office is closing and the only offer is relocating to Reading, which you don't want |

## Sources

**Provided documents:** your message (your background and what you would tell her); the advert as pasted; Hannah Lowther's LinkedIn message as pasted.

**Searches sent (every one refused, none returned results):**
- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics Avonmouth strategy news` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

**Fetches:** none. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call refused. Would have named Quillmoor's published values for VAL framing; no values-style round is documented, so no cheat sheet is built either way |
| 2. `{company} interview process {role family}` | unavailable | Every call refused. Would have documented the rounds after this call and tuned the later-round weights (E, G) |
| 3. `{company} strategy` / recent news | unavailable | Every call refused. Would have grounded a CO question, so none is in the pack |
| 4. `{interviewer name} {company}` | unavailable | Every call refused. Would have supplied an interviewer read and a reverse question tied to her path |
| 5. representative `{role title}` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period, as it stands → A3 and F11 get your own words
- Your CV, or a few lines on what you did day to day on scheduling, stock records and reporting → F1, F4, F5 and F8 can be met from your own words, which upgrades B1, B2, C2 and C3 from answer slots to mapped stories
- Web search permission → the standard research pass (up to 6 searches and 2 fetches) for Quillmoor's values, interview process and recent news, which would add a company-grounded CO question and Quillmoor-specific reverse questions. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow if you want it
- Hannah's public professional profile → an interviewer read and a reverse question tied to her path
- A `tuesday-dossier.md`, if you ever have one → verified evidence and sourced prohibited claims, replacing the ones built locally here; never required
