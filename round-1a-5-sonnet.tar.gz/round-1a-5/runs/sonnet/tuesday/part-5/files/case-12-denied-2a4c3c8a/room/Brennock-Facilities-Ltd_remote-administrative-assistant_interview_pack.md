# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager (no name given). Format: a 30-minute video call, per the invite. Relationship assumed: hiring manager, because the invite does not say whether the office manager would be your manager or a peer.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- VAL: whether past behaviour shows the employer's published values. No values-style round is detected, so this pack has no VAL rows.
- EXP: whether what you say about your work survives follow-up questions.
- JD: whether you can do the listed job, gaps included.
- CO: how much you know about the employer.
- CASE: a live problem from the job, answered out loud.
- Guidance is scaffolding, not a script. Say only what you did, in your own words. An answer slot is an instruction for the interview. It asks nothing of you now.
- Highest-ROI rehearsal: B2. It is the objection most likely to be put to you in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your word is appointment book and the ad's is calendars. Say yours at its own scope: "I ran the appointment book for four physios." It is a line with nothing inspected behind it, so expect follow-ups on it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: the ad names it, so expect a probe. If you have booked travel for anyone, say what and for whom, in your own words. If you have not, say so plainly, then say how you would approach a first booking, as a plan and not as a past |
| F3 | "preparing documents in Word and Excel" (Word) — the ad, as you described it | "I'm good with Word" — your message | low | [inferred] | discovery | A self-rating with nothing named behind it. Answer slot: if you can name documents you prepared in Word, say which and who they were for. If none comes to mind, say so plainly and say how you use Word day to day |
| F4 | "preparing documents in Word and Excel" (Excel) — the ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | Your own rating is "okay", and it is the honest starting point. Answer slot: if you can name what you have done in Excel, say it in your own words. If it is little, say so plainly and say where your skill stops |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chased, not processed. It also does not show whether those were invoices the clinic issued or received. Words at their own scope: "I chased unpaid invoices." Answer slot: expect a probe on invoices coming in from suppliers. If you handled any, say what you did with them. If not, or it was not yours, say so plainly and stay with the chasing |
| F6 | "Administrative Assistant" — the invite (the role title) | "two years as a receptionist at a physiotherapy clinic" — your message | medium | [grounded] | transferability | Your quote carries clinic reception. Whether that reaches an administrative assistant role is the interviewer's call. Say it at its own scope: two years as a receptionist at a physiotherapy clinic |
| F7 | "Remote" — the invite (the role title) | none given | none | [grounded] | hard_gate | Your material does not establish that you can work remotely as the title says |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live problem from the job: a double booking, a mismatched invoice, a travel request | High. Hiring-manager prior, and the ad's task list (calendars, travel, documents, invoices) is a list of live problems | Clarify first, then structure, then say what you would record. Think aloud. Make no claim about your past |
| Skeptic | Quiet probing of the thin rows: travel, supplier invoices, Excel, and reception versus remote admin | High. Hiring-manager prior, and F2, F4, F5 and F7 are where the material is thin | Rehearse B2 until it is boring. Return to your own quoted sentences and name the limit plainly |
| Conversational/Rapport | An easy opener such as the journey so far; casual questions about Word and Excel | Medium. A 30-minute video call usually opens this way, but the invite does not say | Prepare a 90-second arc from your quotes only. Treat casual questions about the ad's topics as scored |
| Data-Driven Prober | Line-by-line questions on the one figure you gave, four physios, and on the chasing | Medium. F1 and F5 are the claims with a figure or a process behind them | Say which part was yours and which was not. Say plainly if you do not know how something was counted |
| Peer Evaluator | How work would be split and how you would stay in touch while remote | Low. The invite does not say whether the office manager is a peer. This rises if you tell me they are | Propose working principles. Do not pretend to know the seam |
| Pressure | Interruptions, time-boxed answers | Low. Nothing in the invite signals it, and the hiring-manager prior does not carry it | Pause, restate the question, hold your position through two follow-ups, then concede specifically |

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people ask for the same slot in your manager's calendar, for different meetings, and your manager can't be reached for an hour. What do you do?" | CASE | [generic] | Structure it: what you would check first (which request came first, which is more urgent, whether either can move), what you can decide yourself and what waits for your manager, how you tell both people, what you would record. The question needs no claim about your past, so the guidance makes none | Tests the calendar requirement of F1 as a decision, not a record. CASE because it is a live problem |
| A2 | "A supplier invoice arrives and the amount doesn't match the order. Walk me through what you do." | CASE | [generic] | Structure it: hold it unpaid for now, say what you would compare it against, who you would ask, how you would record the query. Name any step where you would check a process rather than guess. No claim about your past | F5 is the thinnest requirement of the ad, so a live version of it is likely. CASE because it asks for reasoning, not history |
| A3 | "I need a two-day trip booked for three colleagues next week, on a limited budget. What do you ask first?" | CASE | [generic] | Clarify before structuring: dates, who is travelling, the budget limit, preferences, who approves. Then say how you would compare options and what you would confirm back before booking. If you would need to learn their booking tool, say so | F2 is where your material is silent, so a case lets you show method without a claim. CASE with JD content |
| A4 | "I send you rough notes from a meeting. I need a clean one-page summary by tomorrow morning. How do you start, and what do you check before sending it?" | CASE | [generic] | Clarify the reader and purpose first, then structure, then checks (names, dates, figures against the notes). Say what you would send back to ask if the notes were unclear. No claim about your past | F3 asks for document preparation. CASE with JD content |
| A5 | "I want a simple Excel sheet that tracks supplier invoices: amount, due date, paid or not. How would you set it up?" | CASE | [generic] | Ask what the reader needs to see, propose the columns, say how you would make overdue items stand out, and name any step where you would look up a method rather than guess | F4 is a self-rating of okay, so a small, concrete build is the likeliest test. CASE with JD content |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Choose from your own material, honestly: the ad's travel, supplier invoices and Excel are the rows where it is thin. Say which, then say how you would ramp, as a plan: who you would ask, what you would read first. Do not claim to have done any of them. Your own words on Excel were: "okay with Excel" | F2, F4 and F5 are the rows a skeptic aims at. JD because it scores the listed job including its gaps |
| B2 | "Your background is clinic reception. What makes you ready for remote admin work, where nobody is at the next desk?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" | The highest-ROI rehearsal in this pack. The hold is only what the quotes carry: "two years as a receptionist at a physiotherapy clinic", and "I ran the appointment book for four physios". Hold it through two follow-ups by returning to them, never by adding to them. Likely follow-ups: how you would structure a day when nobody hands you tasks, and what would worry you. Concede specifically: your material shows clinic reception, not remote work. Answer slot: if you have worked without others nearby, say when and how it went. If not, say so plainly, then describe how you would set up your day, as a plan | F6 and F7 together are the most predictable objection. JD because it scores fit for the listed role, asked in Skeptic register |
| B3 | "You chased unpaid invoices. Did you also deal with invoices coming in from suppliers?" | EXP | [grounded] "chased unpaid invoices" | Say it at its own scope: "I chased unpaid invoices." Answer slot: the ad names processing supplier invoices, so this probe is likely. If you handled any invoices from suppliers, say what you did with them, in your own words. If not, or it was not yours, say so plainly and return to the chasing | F5 is the row where the ad's wording goes past your quote. EXP because it tests what was actually yours |
| B4 | "Have you booked travel before?" | JD | [generic] | Answer slot: if you have booked travel for anyone, say what and for whom, in your own words. If you have not, say so plainly, then say what you would ask before a first booking: dates, budget, traveller preferences, who approves | F2 is silent in your material, so the honest answer is the one to have ready. JD because the ad names travel booking |

### C. Conversational/Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey to this point." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc with only the beats your quotes state: two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, chasing unpaid invoices. Tell them in your own words. Say in your own words why this role next. Nothing in the pack supplies that reason | F1, F5 and F6 are your whole story on paper, so the opener should use all three and nothing more |
| C2 | "What are you actually using Word for these days?" | JD | [grounded] "I'm good with Word" | Your own words were "I'm good with Word". Answer slot: if you can name documents you prepared, say which and who they were for. If none comes to mind, say so plainly and say how you use it day to day | F3 is a self-rating, and a casual question about it is still scored |
| C3 | "How would you describe your Excel?" | JD | [grounded] "okay with Excel" | Your own words were "okay with Excel". Say that. Answer slot: if you can name what you have done in it, say it in your own words. If it is little, say so plainly and say where your skill stops | F4 is stated modestly, and a plain answer scores better than a stretched one |
| C4 | "What do you know about what we do?" | CO | [generic] | Say only what you have actually read, and say where you read it. If you found little, say so plainly, then ask them to tell you. Research was not available when this pack was built, so it holds nothing about the employer | Homework depth is scored in a friendly register. CO because it tests knowledge of the employer |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the appointment book worked day to day." | EXP | [grounded] "I ran the appointment book for four physios" | Beats the quote states: you ran the appointment book, for four physios. Tell them in your own words. Answer slot: the ad's calendar line makes a probe on which parts of managing the book were yours likely. If any were yours, say which. If the physios or someone else decided them, say so plainly and describe how you ran the book | F1 is the evidence for the calendar requirement and the likeliest place to be probed |
| D2 | "How would you keep a record of supplier invoices so none gets missed?" | JD | [generic] | Structure it: one place for every invoice, the date received, the amount, the due date, the status, who approves. Say how you would check the record at a set time. No claim about your past | F5 asks for processing. JD with CASE delivery, because it asks for a method, not a history |
| D3 | "Four physios: which part of that book was yours, and which part was theirs?" | EXP | [grounded] "I ran the appointment book for four physios" | The figure you gave is "four physios". Answer slot: say which parts were yours and which were not, in your own words. If you do not know how something was decided, say so plainly. Return to "I ran the appointment book for four physios" | F1 holds the one figure in your material, and probers go straight to attribution |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has worked in an office?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" | Pause and restate the question. Hold: "two years as a receptionist at a physiotherapy clinic", and "I ran the appointment book for four physios". Hold through two follow-ups. Concede specifically: your material shows clinic reception, and does not show an office like theirs. Answer slot: if you have worked in an office setting, say where and what you did. If not, say so plainly and return to the book | F6 is the objection in time-boxed form |
| E2 | "You call your Excel okay. Okay isn't enough for invoices, is it?" | JD | [grounded] "okay with Excel" | Hold what you said: "okay with Excel". Do not upgrade it under pressure. Concede that invoices need care. Say how you would close the gap, as a plan: name the first thing you would practise and how you would check your work. Do not name a skill you do not have | F4 and F5 meet here. The pressure is on whether you inflate when pushed |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How would you like to hand work over and check in, if we're working at different times?" | CASE | [generic] | Propose principles, not a pretended routine: one place where requests are written down, an agreed time for questions, a short end-of-day note. Your material does not show remote work, so describe the set-up as a plan, not as something you have done | F7 is not established by your material, so the remote routine is rehearsed as method |
| F2 | "How would we split the work between us, and what happens if we disagree?" | CASE | [generic] | Propose principles: who owns which task, how you raise a conflict early, who decides when you cannot agree. Say what you would offer them, not only what you would need. No claim about your past | The Peer stem. It matters if the office manager turns out to be a peer, and it costs little to have ready |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "managing calendars" | A1, D1, D3, F1 |
| "booking travel" | A3, B4 |
| "preparing documents in Word and Excel" | A4, A5, C2, C3, E2 |
| "processing supplier invoices" | A2, B3, D2 |
| "Administrative Assistant" | B2, C1, E1 |
| "Remote" | B2, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you are thinking about delivering, and the answer tells you what is weighted most |
| R2 | "Which of the tasks (calendars, travel, documents, invoices) takes most of the week?" | It shows you read the ad closely and tells you where to practise first |
| R3 | "How do you and the person in this seat usually stay in touch during the day?" | The role is remote, so working rhythm is the real day-to-day question |
| R4 | "How are supplier invoices approved and recorded here, and who signs them off?" | It shows care about the invoice work, where your material is thinnest |
| R5 | "What do you use for calendars and for booking travel?" | It shows you are already thinking about the tools you would need to learn |
| R6 | "What could a new person do in the first month that would genuinely help you?" | A reciprocity question. It is useful whether the office manager is your manager or a peer |
| R7 | "What are the next steps after this call, and when should I expect to hear?" | It is a process question. It lets you plan around the next step |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for a team or for executives | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says an appointment book for four physios |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The slots stay inside the chasing |
| Advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel" |

## Sources

- Provided: your message, covering the invite email as you pasted it, the ad as you described it, and your background. No `tuesday-dossier.md` was present.
- Searches sent: "Brennock Facilities Ltd company values" (refused). "Brennock Facilities Ltd interview process administrative assistant" (refused). No pages were fetched.
- Nothing in this pack about the employer's values, interview loop or strategy is established. The loop rests on the invite's own words: one 30-minute video call with the office manager.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Both calls were refused. It would have fed a values cheat sheet, but no values-style round is detected, so the sheet is absent either way |
| 2. company interview process for this role family | unavailable | The call was refused. It would have checked the loop structure and persona weights. The invite's words fix one session, so the weights rest on that and the hiring-manager prior |
| 3. company strategy and recent news | unavailable | No search was sent because the two searches already sent were refused. It would have fed a strategy-grounded CO question; C4 is generic as a result |
| 4. interviewer name | n/a | No name was given, so there was no query to form |
| 5. representative job description | skipped | The ad as you described it fixes the fit rows and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read and a reverse question tied to their own path
- Confirmation of whether the office manager is your manager or a peer → persona weights recomputed, with Peer raised if a peer
- The ad's full text → any requirement your description left out gets its own row and question
- Any documents you prepared in Word or Excel, or any travel you have booked → F2, F3 and F4 upgraded from slots to story-mapped rows
- Whether the invoices you chased were ones the clinic issued or received → F5 upgraded
- Any time you worked without others nearby → F7, B2 and F1 upgraded
- A deeper research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes, and only if search is permitted) → a strategy-grounded CO question
- A `tuesday-dossier.md`, if you already have one → verified evidence and prohibited claims carried straight into this pack
