I'm writing the prep pack file now. The web searches were refused, so the pack runs on what you've told me and says so.
Before the prep, one thing in the invite: it says the process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Until you've checked the invite, hold off sending money, documents or bank details through that chat. Check with Lumenvale through contact details you find yourself on its own website or careers page, not through the chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-5/rooms/case-10-denied-39f1a1f7/lumenvale-software_customer-support-specialist_interview_pack.md`. It has 19 practice questions, a fit table built from your own words, and reverse questions for you to ask.

I built it as a hiring-manager-style round, since you haven't said whether the team lead would be your manager. My web searches were refused, so nothing in it is researched. Company values, process and strategy are missing, and the question types are marked generic where that matters.

- **Strongest areas:** your 3 years in customer service, using Freshdesk every day, and the four new starters you trained.
- **Biggest prep item:** question B1, about never having worked for a software company. Say the gap plainly, hold what you've done, then give a plan for learning the product.
- **Thin spots:** your material doesn't show whether you've handled escalations or how your written replies were judged. The pack gives you honest answer slots for both.

Say the word and I'll play the skeptical team lead on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document if you'd like.

Is the team lead likely to be your direct manager, and has Marcus said anything about the chat's format, length or topics? Can you also paste the full ad text, or say skip?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead (no name given). Format: a text chat. Relationship: not stated whether the lead would be your manager, so the pack is built as a hiring-manager-style round. Loop: one text chat, from your message; no other loop source, so nothing is assumed about later rounds.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: in a text chat, answer in your own words, in three to five short lines, and keep to what you can stand behind if the lead asks a second question.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows good judgment about customers and colleagues |
| EXP | Whether your experience survives a follow-up question; what was actually you |
| JD | The ad's stated requirements, including the gaps |
| CO | Whether you understand the company and its customers |
| CASE | A live problem from the actual job, answered in structure |

Question IDs run by persona: A to E, then G for values. F1 to F6 are fit-snapshot rows.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you listed it | "3 years as a customer service advisor at an energy supplier" — your message, "answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap on length, but your message alone, with nothing inspected behind it, so expect a probe. Lead with it in your own terms: three years, customer service advisor, energy supplier. Say your own title, not the ad's wording. Keep the figure as you gave it: around 60, calls and emails together |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is the tool your material names; it does not mention Zendesk, so say Freshdesk and let the lead judge the match. Expect a probe on how you use it (D2) |
| F3 | "clear written communication" — the ad, as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails touch the requirement, but the quote does not show whether anyone judged your writing. Answer slot: if any of your replies were reviewed, scored or templated, say what; if none were, say so plainly and describe how you write a reply. This chat is itself a writing sample |
| F4 | "confidence handling escalations" — the ad, as you listed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: if you took over or passed on a difficult case, say what happened and what part was yours; if you did not, or it was not yours, say so plainly and stay with the volume you described in F1 |
| F5 | Software-company experience (not in the ad as you listed it; the gap you named yourself) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Not asked for in the ad as you listed it; extra evidence the pack can use | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Use it at its own scope: four new starters, the refunds process, last year. Your sentence does not say you designed the training or led a team, so neither does the pack |

## Persona table

Loop: one text chat with the support team lead, from your message. No archetype is assumed, and weights are relationship priors adjusted by what you told me.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live ticket scenarios typed into the chat: an angry customer, an escalation, an outage | Highest. The hiring-manager prior is Case plus Skeptic, and the ad asks about escalations (F4) | Clarify, then structure: what you need to know, what you can do now, what you hand over and when the customer hears back, what you record |
| Skeptic | The software gap, the escalation gap, why leave energy for software | High. You named the software gap yourself (F5), and F4 is silent | Rehearse B1 until it is boring: say the gap plainly, hold what your quotes carry, give a plan |
| Conversational | Opening biography, tools, proudest moment | Medium. The format is a chat and openers are scored | Short arcs built only from your quoted sentences |
| Data-Driven Prober | The 60-a-day figure, how you use Freshdesk, how you write replies | Medium. Your message gives one figure and one tool claim (F1, F2) | Know what you can and cannot say about how the figure was counted; say plainly where you do not know |
| Pressure | Why you over someone with software experience; how much was actually you | Low to medium. No source says this lead runs pressure rounds; the gaps in F5 give it material | Hold the position through two follow-ups, concede specifically, never fold on what your quotes carry |
| Values/Behavioral | Customer-over-rule and unwelcome-truth stories | Low. No values source was reachable and no loop source names a values round | Selection scaffolds with an honest branch |

The Peer Evaluator is left out: nothing in your message makes the lead a peer.

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and says they are cancelling today. What do you reply, and what do you do next?" | CASE | [generic] | Structure: one or two sentences that show you read the history so they need not repeat it; what you can do now; what you must hand over and when they will hear back; what you record. The question needs no claim about your past, so the guidance makes none | The ad's escalation line (F4) asked as a live decision; CASE because it scores structure |
| A2 | "A customer demands a refund that policy does not allow, and is getting angrier in the chat. What do you do?" | CASE | [generic] | Ask what exactly they are asking for; say what you can do within policy; if it needs a decision above you, say who you are passing it to and what you will send them so the customer does not repeat the story. Keep the tone plain in text: short sentences, no blame | F4's requirement as a live problem; CASE with a JD flavor |
| A3 | "A bug has taken a customer's account offline and engineering says two days. The customer is in the chat now. What do you write?" | CASE | [generic] | Say what you know and what you do not; promise no fix time you cannot confirm; say when you will next update them; ask the lead or engineering for a status line you can pass on. The question presupposes nothing about your past | Software incidents are where F5's gap would show first; CASE because it scores honest communication under uncertainty |
| A4 | "How do you decide whether a ticket gets escalated or answered yourself?" | CASE | [generic] | Offer criteria, not a story: what you can fix within your permissions, what puts money, data or a customer's account at risk, repeat contacts, what the customer says is at stake, and what the hand-off note must contain. Ask what this team's escalation rules are | F4 is silent in your material, so this gives a way to answer without a claim; CASE with JD content |
| A5 | "You have forty open tickets, three are urgent and one is from a large customer. How do you order the next hour?" | CASE | [generic] | Clarify first what rules the team uses for priority; then order by impact and deadline, say which customers you will tell their ticket will wait, and flag overload to the lead rather than quietly dropping work | Tests structure and communication; the ticketing-tool requirement (F2) is the setting |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked for a software company. What will be hardest in your first month?" | JD | [grounded] "I've never worked for a software company", "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Say it first: "I haven't worked for a software company." Hold what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Then a plan, not a past: how you would learn the product and its common customer questions in the first weeks. Follow-up 1, how fast you learn tools: answer slot, if you can name a system you picked up at work, say which and how; if none comes to mind, say so plainly and return to the plan. Follow-up 2, what if questions are technical: say you would use the team's documentation and escalate what you cannot answer, and concede plainly that you will not know the product on day one. Never claim product knowledge | F5 is the objection you named yourself, so it is the most predictable; JD because it scores a stated gap |
| B2 | "Tell me about a time you had to escalate or take over a difficult case." | EXP | [grounded] "answering around 60 calls and emails a day" | Selection scaffold: pick a case with a named customer need, the moment you judged it was beyond what you could resolve, who took it and what you passed on, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the volume you described, or how you would handle it | The ad's escalation line (F4); the open prompt supplies no event, since your material shows none |
| B3 | "Why customer support at a software company, and why now?" | EXP | [generic] | Give your actual reason, in your own words. The pack does not supply one. If the reason is mixed, say the true part; do not claim familiarity with the product that you do not have | F5 is why this arrives; a motivation probe is scored for consistency |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Answer slot: name the one of the ad's four requirements you could evidence least today. If it is escalations, say whether you have handled any: if you did, say what part was yours; if none, say so plainly and say how you would learn. If it is the software setting, use the sentence "I haven't worked for a software company." and then your plan from B1 | F4 and F5 are the two rows with the least evidence; JD because it scores honest self-assessment |

### C. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself and how you got into support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "answering around 60 calls and emails a day" | Four lines: three years as a customer service advisor at an energy supplier; answering around 60 calls and emails a day; then why this role, in your own words. The last line is yours to write; the pack does not supply it | F1 is the evidence for the experience requirement; casual openers are scored |
| C2 | "Which tools do you use day to day, and how do you find them?" | JD | [grounded] "I use Freshdesk every day" | Say it as you said it: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so expect a question on it; if you have used Zendesk, say how; if not, say so plainly and stay with Freshdesk | F2 is the evidence for the ticketing-tool requirement |
| C3 | "What are you proudest of from your time in support?" | VAL | [grounded] "I trained four new starters on our refunds process last year" | Tell it in your own words with only what the sentence states: four new starters, the refunds process, last year. Add nothing about how it went unless you can say it from memory if asked | F6 is your strongest extra evidence; VAL because pride stories show what you value |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around sixty calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say "around 60", calls and emails together, as you said it. Answer slot: if it came from a report or a tally, say which; if it is your own estimate, say so plainly. Name, in your own words, the part of the figure you would defend least. "I don't know how it was counted" is an honest answer | F1 carries the only figure in your material, and a figure is where probes land; EXP because it scores attribution |
| D2 | "Walk me through how a ticket moves through the tool you use." | JD | [grounded] "I use Freshdesk every day" | Describe it as you actually use it, in the tool's own terms. Answer slot: if some steps, such as routing or rules, are set by someone else, say so and stay with the parts you do. If asked how Freshdesk compares with Zendesk, say plainly what you have and have not used | F2 is a one-line claim, so a prober will ask for the detail behind it |
| D3 | "How do you keep a written reply clear when the customer is confused or upset?" | JD | [grounded] "answering around 60 calls and emails a day" | Describe your own method in your own words. Answer slot: the ad asks for clear written communication, and this chat is itself a sample. If any of your emails were reviewed, scored or templated, say what; if none were, say so plainly and describe how you write one | F3 is thin on evidence, so the honest answer is rehearsed before the probe |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Why should we hire you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day", "I've never worked for a software company" | Hold-then-concede. Hold what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Concede specifically: "I haven't worked for a software company." Hold through two follow-ups by returning to those facts, never by adding to them | F1 and F2 are the holds; F5 is the concession; a pressure question scores composure |
| E2 | "Sixty a day. How much of that was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Hold: your sentence says you were answering them. Answer slot: if some contacts were passed on or finished by someone else, say so plainly; if you answered them yourself, say that. Do not turn answering into resolving or closing | F1's figure under attribution pressure; EXP because it scores what was yours |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you put a customer's real need ahead of a rule or a target." | VAL | [generic] | Selection scaffold: pick a time with a named customer need, the rule or target in the way, what you did, and what the relationship looked like after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values stem; no published values were reachable, so this is a pattern and not the company's wording |
| G2 | "Tell me about a time you had to give a customer or a colleague news they did not want." | VAL | [generic] | Selection scaffold: a named stake, what you said and how you worded it, and whether the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values stem; support work involves refusals and delays |

### Requirement coverage

| Ad requirement | Covered by |
|---|---|
| "2+ years in customer support" | C1, D1, E1, E2 |
| "experience with Zendesk or a similar ticketing tool" | C2, D2, A5 |
| "clear written communication" | D3, A1, A2, A3 |
| "confidence handling escalations" | A1, A2, A4, B2, B4 |
| Software-company context (your own flagged gap) | B1, B3, B4, A3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first month look like for someone new to your product?" | It turns the software gap (F5) into a plan the lead describes for you |
| R2 | "How does the team decide when something is escalated, and who picks it up?" | Shows you treat escalation as a judgment with rules, and gives you the team's own criteria for A4 |
| R3 | "What do customers most often write in about?" | Gives you real vocabulary and shows you want to learn the product from its customers |
| R4 | "Is this conversation text only, and roughly how long should I plan for?" | Lets you pace written answers, since a long typed answer costs more time than a spoken one |
| R5 | "Which ticketing tool does the team use, and how are tickets routed?" | Connects to F2 and lets you say plainly what carries over from Freshdesk |
| R6 | "How is the quality of written replies reviewed on the team?" | Shows you care about the written-communication line (F3) and want feedback |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has software-company or product experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." Then the plan from B1, said as a plan |
| Resolved or closed around 60 tickets a day | Inflated form of F1 | F1's quote at its own scope: "answering around 60 calls and emails a day". The limit is the pack's observation: your sentence says answering, not resolving, and calls and emails together, not tickets |
| Led or designed the training of new starters | Inflated form of F6 | F6's quote at its own scope: four new starters, the refunds process, last year. Your sentence does not say you designed or led it |

## Sources

Provided: your message, containing the invite text, your experience summary and the ad's four listed requirements. No full ad text, CV or dossier was provided.

Searches sent, each refused (no results came back):

- "Lumenvale Software values": refused
- "Lumenvale Software interview process customer support specialist": refused
- "Lumenvale Software strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | All three calls were refused. It would have fed a values cheat sheet if a values round were detected, and the VAL questions' wording; G1 and G2 are labeled generic instead |
| 2. Interview process, support roles | unavailable | Refused. It would have shown loop structure and persona weights; weights rest on your message alone |
| 3. Company strategy and recent news | unavailable | Refused. It would have grounded a CO question; none is in this pack because nothing about the company could be established |
| 4. Interviewer name and company | n/a | No name was given for the support team lead, so there was no query to form |
| 5. Representative job ad | skipped | The four requirements you listed fix the fit snapshot and the JD questions |

## Upgrade menu

- The full text of the ad → the four listed requirements become quoted lines, any further requirements get rows and JD questions, and rows built on your summary of the ad firm up
- Web search allowed → the company's values, its interview process and its product context; a CO question and, if a values round turns up, a values cheat sheet; one deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, is available on request
- Your answers to F3, F4 and the basis of the 60-a-day figure → those rows move out of discovery and A1, B2, D1 and D3 become story-mapped
- Anything the recruiter or team lead has said about format, length or topics → persona weights and the answer pacing in R4
- The support team lead's name → an interviewer read and a reverse question tied to their career path
- A tuesday-dossier.md, if you have one → verified evidence and a prohibited-claims list that would replace the locally built one, and a sharper highest-ROI objection
