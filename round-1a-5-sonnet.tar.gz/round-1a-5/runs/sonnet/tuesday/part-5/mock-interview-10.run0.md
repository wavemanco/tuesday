I'm writing the prep pack now. The three company searches were refused, so it rests on what you've told me, and the Sources section says so.
Before the prep, one thing in the invite. It says the hiring process is "carried out entirely on Telegram", that "your interview will be a text chat here", and that "your offer and onboarding will be completed in this chat as well". A process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. The invite may not come from who it names. Until you know who sent it, send no money, documents or bank details through the chat, and don't deposit any cheque. To check, find Lumenvale's careers page or contact details yourself on its own website. Ask them there whether this invite is theirs, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-5/rooms/case-10-denied-315a85e5/lumenvale-software_customer-support-specialist_interview_pack.md`. It's built for a hiring-manager-style text chat with the support team lead. That's my assumption, since the invite doesn't say more. It has 22 questions across seven interviewer styles, a fit snapshot against the four requirements you gave me, and six reverse questions. The three company searches I tried were refused, so it uses only what you told me. It has no company research, and it lists the searches and says so.

The question I'd rehearse most is B1: "You haven't worked for a software company before." You said that yourself, so you can concede it plainly, then hold on your three years and daily Freshdesk use, and give a plan for learning the product.

Two other points:
- **Escalations:** your message doesn't mention any, so the pack leaves you an answer slot, not a story. Fill it only with what really happened.
- **Zendesk:** the pack keeps your experience at Freshdesk and doesn't claim Zendesk.

Say the word and I'll run a live drill as the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

Can you paste the full text of the job ad? It would replace my reading of four requirements with the ad's own wording, and may add rows and questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Relationship assumed: hiring-manager style, since a team lead interviewing for a support role is the nearest prior. Format per the invite: one text chat. Built from your message and your account of the ad; no company research was available (see Sources).

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Because the interview is a text chat, your writing is being scored as you type, so short, plain, well-ordered replies are part of every answer.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows what the employer says it values |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny |
| JD | Role-driven: the ad's stated requirements, gaps included |
| CO | Company and strategy knowledge (none in this pack: no company research was available) |
| CASE | A live problem from the role, with structure and reasoning scored |

Question IDs are lettered by persona. The letter F is skipped so that question IDs never collide with the fit-snapshot rows F1 to F6.

## Fit snapshot

Requirements are the ones you gave me from the ad, quoted from your message. No row here is a hard gate: none of the four stated requirements is a legal, credential or location term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: three years, customer service advisor, energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say it as the quote says it, "I use Freshdesk every day", and add nothing about what you do in it. The ad names Zendesk and your material names Freshdesk, so the words stay at Freshdesk. Answer slot: if asked about Zendesk, and you have used it, say where and for how long, in your own words; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are in the quote, but it does not show how your writing was judged. Answer slot: if any of your written replies were reviewed, scored or given feedback on, say what happened; if none were, say so plainly and stay with the emails you answered. This chat is itself a writing sample |
| F4 | "confident handling escalations" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not establish this either way. Answer slot: if any calls or emails reached you that you could not settle yourself, or that you passed on, say which and what you did; if escalations were not part of your role, say so plainly and stay with the calls and emails you answered |
| F5 | Working in a software company's support team (role-family expectation, not from your account of the ad) | "I've never worked for a software company" — your message | none | [grounded] | capability | You stated this, so the words are yours: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Helping colleagues and new starters get up to speed (role-family expectation, not from your account of the ad) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Tell it with the beats the sentence states: you trained, four new starters, the refunds process, last year. Expect a probe on how, and answer with what you did, not what the training usually involves |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 2+ years in customer support | C1, D3, G1 |
| F2 Zendesk or a similar ticketing tool | B4, C2 |
| F3 clear written communication | A1, A2, A5, B5 |
| F4 confident handling escalations | A2, B3, H1 |
| F5 software-company background | A3, B1, B2, G1 |
| F6 supporting colleagues and new starters | C3, D2, G2 |

## Highest-ROI prep

B1. A support team lead hiring for a software company will almost certainly ask about moving from a non-software background, and F5 is a gap you have stated yourself. A calm, short, non-defensive answer, rehearsed through two follow-ups, changes the interview.

## Persona table

Loop basis: your invite describes one text chat with the support team lead and no other round, so this pack is session mode. No loop source documents a values-style round, so no values cheat sheet is built and the VAL questions rest on persona stems, not on published values.

| Persona | How it shows up in a text chat | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live support scenarios you answer by typing the reply | High (5 questions). A team lead hiring a support specialist is buying the ability to handle live customer situations, and the format makes a typed reply easy to score | Clarify first, structure the reply, say the order you chose |
| Skeptic (B) | Quiet probing of the software-company gap, the Zendesk-versus-Freshdesk gap and escalations | High (5 questions). F5 is a stated gap and F4 is a requirement your material is silent on | Rehearse B1 until it is boring; state the limit before it is asked for; stay with what your own sentences carry |
| Conversational (C) | Friendly opener, "walk me through the journey" | Medium (3 questions). Common opener in a chat interview, and it is still scored | A short arc built from your own sentences; treat casual questions as scored |
| Data-Driven Prober (D) | Asks how your numbers were counted | Medium (3 questions). F1 and F6 both carry a figure | Say how a figure was counted, or say plainly that you do not know |
| Values / Behavioral (E) | "Tell me about a time" prompts | Low (2 questions). No values-style round is documented | Pick a real instance; if none comes to mind, say so |
| Pressure (G) | Short, challenging follow-ups on attribution | Low (2 questions). Less typical in chat, but a team lead may test composure | Hold your position through two follow-ups, concede specifically |
| Peer Evaluator (H) | Collaboration with other teams | Low (2 questions). Support roles work with product and engineering, but the interviewer is not a peer | Offer what you bring the other team, not only what you need |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in: the product they pay for has stopped syncing and they say they will cancel today. Type the first reply you would send." | CASE | [generic] | Order it before you type: name the problem in the customer's own words, ask the one thing you need to know, say what happens next and when they will hear from you. Keep it short; if asked, say why you chose that order. The question needs no claim about your past, so the guidance makes none | F3 is the requirement this scores, and the invite's text-chat format makes a typed reply a natural live test; CASE because it is a live problem |
| A2 | "In the middle of a chat, a customer asks for something you cannot approve yourself. What do you do, and what do you write to them?" | CASE | [generic] | Structure it: what you can do now, what you cannot, who decides, what you pass on so the customer is not asked twice, and what you tell the customer about next steps and timing. It asks about no past, so the guidance makes no claim about one | F4 is the requirement behind it; CASE because it is asked as a live decision rather than as a past story |
| A3 | "A customer asks how a feature works that you have not seen before. You have a couple of minutes. What do you do?" | CASE | [generic] | Clarify what they are trying to do, say plainly what you do not yet know, say where you would look and whom you would ask, confirm before you answer, and give them a time. Honest uncertainty with a next step scores better than a guess | F5 is why this is likely: the interviewer can test product learning without asking about your past; CASE |
| A4 | "Three customers write in at once: one cannot log in, one is asking about an invoice, one is upset about a delayed fix. Whom do you answer first, and what do the other two get meanwhile?" | CASE | [generic] | Ask what you would want to know first (impact, urgency, who has waited longest), state your order and why, and say what you would send the other two in the meantime. Say what you would check with the team lead about priorities | F1 is the evidence for the experience requirement, and volume handling is a natural live angle; CASE |
| A5 | "A customer writes back to say the fix you gave them did not work and they have lost a day. Write the reply." | CASE | [generic] | Own it plainly without excuses, restate the problem in their terms, give the next step and a time, and say what you need from them. No past is claimed | F3 again, under pressure and in writing; CASE |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company before. Why should I think you'll cope here?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Hold-then-concede. Concede first, in your own words: "I've never worked for a software company." Then hold on what your sentences carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Then give a plan, said as a plan: how you would learn the product in your first weeks. Follow-up one, if pressed on how software customers differ: say plainly you cannot say from experience, and say how you would find out. Follow-up two, if asked why you over someone with software experience: hold on the same two sentences and concede that someone with software experience would start ahead on the product. Never add experience to close the gap | F5 is a gap you stated, so the acknowledgment is yours to say; JD because it scores the role's fit including its gaps |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Choose the item from the ad that you can say least about from your own work, name it in one plain sentence, and say how you would close it in the first weeks, as a plan. If none comes to mind, say so plainly and name what you would most want to learn first about the product. Pick one item and stay with it | F4 and F5 are where your material is thinnest, so this question is likely to arrive in some form; JD |
| B3 | "The ad asks for confidence handling escalations. Tell me about a time you handled one." | EXP | [grounded] "answering around 60 calls and emails a day" | Pick a time that has a named customer need, what was yours to decide, who else you involved and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is "answering around 60 calls and emails a day", or how you would handle it. Do not describe an escalation you cannot walk through step by step | F4 is where the interviewer is most likely to probe and where your material is silent; EXP because it tests what was actually yours |
| B4 | "The ad mentions Zendesk or a similar tool. What have you worked in?" | JD | [grounded] "I use Freshdesk every day" | Say it as it is: "I use Freshdesk every day." Answer slot: if you have also used Zendesk, say where and for how long, in your own words; if you have not, say so plainly and stay with Freshdesk. Then say how you would get up to speed on a different tool, as a plan | F2 is the evidence; JD because it scores a stated requirement |
| B5 | "You mention answering around 60 calls and emails a day. How do you keep your replies good at that pace?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the figure as stated: around 60, calls and emails together, per day. Answer slot: if you have a way of checking your replies before they go, say what it is in your own words; if you have none, say so plainly and say what you would start with. Do not describe a checking process you do not follow | F1 and F3 both press here: the volume is the evidence, and the writing requirement makes quality at volume the likely probe; EXP |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey. How did you get here, and why this job?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Build a short arc in three parts: where you are now, in the quote's own words, where you are heading (this role), and in between, your own reason for the move. Answer slot: say your actual reason in your own words; if you do not yet have a settled one, say so plainly and say what draws you to this role. Do not borrow a motivation from the ad | F1 is the evidence behind the arc; EXP because it tests whether your story is consistent |
| C2 | "What are you actually playing with in support tools these days?" | JD | [grounded] "I use Freshdesk every day" | Start from the quote: "I use Freshdesk every day." Answer slot: if you have tried other tools or features outside work, say what; if not, say so plainly and stay with Freshdesk. Casual-register questions about the JD's hot topics are still scored | F2 again, in a casual register; JD |
| C3 | "Tell me about something you've helped a colleague learn." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence states: you trained them, four new starters, the refunds process, last year. Say it in your own words, and do not add results, materials or timelines that you did not give me. If asked for more, say what you did and stop there | F6 is the evidence; EXP because it tests what was actually yours |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted, and was that a typical day?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the scope of the sentence: around 60, calls and emails together, per day. Answer slot, four parts, each in your own words: how the figure was counted (a report, your own tally, an estimate), what it varies with, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F1 carries the headline figure, so a defend-the-number question is likely; EXP |
| D2 | "You trained four new starters on the refunds process. What happened with them afterwards?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold to the sentence: you trained four new starters on the refunds process last year. Answer slot: if you know what happened afterwards, say what, in your own words; if you do not, say so plainly and return to the training you gave. Do not claim outcomes you cannot back up | F6 carries a figure, and probers ask where it leads; EXP |
| D3 | "Walk me through the three years: what did the job look like at the start and at the end?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Answer slot: if the job changed over the three years, say how and which part of the change was yours; if it did not change, say so plainly and describe the role as it was. Keep to the quote's own terms: customer service advisor, energy supplier | F1 is the headline experience claim, and a prober tests it for depth; EXP |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you put a customer's interest ahead of an internal rule or target." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what the rule or target was, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. Do not stretch a smaller situation into this one | No published values were read, so this is a stem-based behavioral question, not a mapped value; VAL because it tests behavior |
| E2 | "Tell me about a time you had to tell a customer something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time with a clear message, how you phrased it, how the customer reacted and what you did next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. Choose a time when the hard truth actually landed; do not supply an ending | Common behavioral stem for support roles; VAL |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" and "I've never worked for a software company" | Hold-then-concede. Pause, restate the question, and hold on what your sentences carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Hold through two follow-ups by returning to those sentences, never by adding to them. Concede plainly and specifically: "I've never worked for a software company." Do not claim to match someone who has | F5 and F1 together make this the pressure version of B1; JD because it scores fit including the gap |
| G2 | "You trained four new starters. How much of that training was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold on the sentence: "I trained four new starters on our refunds process last year." Answer slot: if others contributed (materials, shadowing, a manager), say what was theirs; if you did it alone, say so plainly. Concede only what is true, and do not fold on the core claim to ease the moment | F6 is the evidence; EXP because it is a direct attribution probe |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "How would you work with the product or engineering team when a customer's problem sits with them?" | CASE | [generic] | Principles, not history: what you would bring them (a clear, complete report so they do not need to ask the customer again), who keeps the customer informed, how you respect their priorities, and how you follow up. It asks about no past, so the guidance makes none | F4 sits behind it: handing a problem on well is part of handling escalations; CASE |
| H2 | "Tell me about a time you disagreed with a colleague about how to handle a customer." | VAL | [generic] | Selection scaffold: pick a time with a real difference of view, what you said, how it was settled and how the working relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle a disagreement | Standard peer-fit stem; VAL |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone who hasn't worked at a software company before?" | Turns the B1 gap into a planning conversation and shows you expect to learn the product |
| R2 | "How does the team handle escalations: what is the specialist expected to resolve, and when does it go to someone else?" | Shows you think about boundaries and handoffs, which is what handling escalations well turns on |
| R3 | "Which ticketing tool does the team use, and how is it set up day to day?" | Answers the F2 question about your starting point and shows practical interest |
| R4 | "How is the quality of written replies reviewed here?" | Shows you care about the writing requirement and tells you what the bar is |
| R5 | "What happens after this chat, and is there anything I should prepare for the next step?" | A process question with a prep reason: it tells you what to prepare and whether any call or other conversation follows |
| R6 | "What does training on the product look like in the first weeks?" | Signals you plan to learn the product and gives you something to prepare |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk. B4's slot stays inside what you have used |
| Handled around 60 tickets a day in Freshdesk | Inflated form of F1 and F2 joined | Each quote at its own scope, kept separate. Your material says calls and emails, and it says Freshdesk, but not that the 60 were handled in it |
| Led or designed a training programme | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on the refunds process last year |
| Has software-industry experience | A negative you stated, F5 | The plain acknowledgment: "I've never worked for a software company." No slot |

## Sources

Provided documents: the invite message as you pasted it; your description of the ad's requirements; your description of your background. No dossier was present.

Searches sent (all refused, nothing came back):

- "Lumenvale Software company values" — refused
- "Lumenvale Software customer support specialist interview process" — refused
- "Lumenvale Software company news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have moved a values cheat sheet only if a values-style round were documented, and none is, so the VAL questions rest on persona stems |
| 2. `Lumenvale Software interview process {role family}` | unavailable | The search was refused. It would have moved the loop structure and persona weights; they rest on the invite's own words, which describe one text chat with the support team lead |
| 3. `Lumenvale Software strategy` / recent news | unavailable | The search was refused. It would have moved the CO questions; this pack has none |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full text of the job ad → the quoted requirements in F1 to F4 become the ad's own words, and any further requirement it lists gets a row and a question
- The recruiter's guidance on the chat's length, focus or format → persona weights built on a documented loop, and any pre-declared task gets its own build section
- The support team lead's name → an interviewer read, persona weights tuned to their public career path, and a reverse question tied to it
- Company search access, or the company's own values and careers pages pasted in → CO questions grounded in current strategy and a values cheat sheet if a values round is documented
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → strategy brief, interviewer footprint, role-family loop reports and recent organisation context
- Your answers to the slots in F2, F3 and F4 → those rows move from `discovery` and `presentation` toward `none`, and B3, B4 and B5 become story-mapped
- How much prep time you have → a prioritized schedule
- A `tuesday-dossier.md` from an earlier session → verified evidence and prohibited claims arrive ready-made, so the highest-ROI objection comes from evidence, not inference
