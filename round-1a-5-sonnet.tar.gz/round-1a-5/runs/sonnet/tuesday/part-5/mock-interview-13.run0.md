Next I'll write your prep pack as a file. The research searches were all refused, so it uses only what you pasted.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-5/rooms/case-13-denied-44cbb021/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It's built for Thursday's recruiter screen with Hannah, using the advert and what you told me. I had no CV, so your background comes from your message.

- **Research:** all four web searches were refused, so there's no research on Quillmoor or on Hannah. The "Why Quillmoor?" question (B3) is labelled generic for that reason.
- **Pay, hybrid and why you're moving:** these are covered in your own words. Your £42,000 sits inside the £38,000–£44,000 band, and your two-days-fine, no-more-than-three position is quoted as you stated it.
- **Notice period:** I didn't have it, so A2 just tells you to give your actual notice period.
- **Biggest prep item:** B1, the SAP gap. The pack has you say "I haven't used SAP," point to your in-house stock system without calling it the same thing, and give a plan for learning the team's system.
- **Production scheduling:** your experience is delivery scheduling, not scheduling production. The pack keeps your wording at "I schedule deliveries for our three depots" and doesn't stretch it.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm with Hannah Lowther, Talent Partner. She will ring the mobile number on your application.
**Candidate:** Sam
**Her agenda, in her own words:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: does what you said survive scrutiny, and what was actually you |
| JD | Role or advert driven: can you do the listed job, including its gaps and its terms |
| CO | Company and strategy knowledge: how well you know the employer |
| CASE | Hypothetical or live problem: structure and reasoning on a problem from the role |

Run A1 to A4 first. Hannah named those four topics herself, so they will be asked. B1 is the highest-ROI prep in the pack: it rehearses the one gap you have stated yourself, before anyone asks.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert puts planning, the warehouse and QA in the picture, so a probe on who your scheduling involves is likely. If any of it involved production or quality teams, say who and how, in your own words; if it did not, say so plainly and stay with the depots |
| F2 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you chase suppliers when orders slip, because a named action beats an adjective |
| F3 | "track supplier deliveries" — advert | none given | none | [grounded] | discovery | Your material is silent on how deliveries are tracked, so the words are an answer slot. The advert names it, so expect a probe on how. If you track deliveries, say how, in your own words; if you do not, or it is someone else's job, say so plainly and stay with chasing suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a probe on it. Hold the sentence at its own scope. Answer slots, each in your own words: how a discrepancy was counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you report on deliveries or dispatch today, say what and how often, in your own words; if you do not, say so plainly and say what you would want to measure first, as a plan and not a past |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | Your sentence says a spreadsheet, not which tool. Answer slot: if it was Excel, say what it did, in your own words; if it was another tool, or you have not worked in Excel, say so plainly and stay with the spreadsheet you rebuilt |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. The advert lists ERP experience as "a plus" |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "we run our own in-house stock system" — your message | low | [inferred] | transferability | Your material says your company runs its own in-house stock system, with nothing showing what you did in it, and the words stay at the quote: "we run our own in-house stock system." Any wider step is an answer slot inside that: if you worked in it, say what you did, in your own words; if you did not, say so plainly |
| F9 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Lead with the years and the role in the quote's own terms. Your employer is a wholesaler and Quillmoor is a manufacturer, which is where B2 presses |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | medium | [grounded] | none | Your words stand as they are: "I'm hoping for £42,000." The figure sits inside the advertised band, an observation about the advert's terms |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The pattern is met on your own statement. Your words stand: two days is fine, and you would not want more than three |
| F12 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. Your own words, at their own scope, are the whole answer |

Notice period has no row: Hannah named it as a topic, but the advert sets no notice requirement and your material states none. A2 holds it as an instruction.

## Persona table

The loop is established by Hannah's own message: one 30-minute phone call with her, in a conversational register, with the team and next steps described afterwards. No values-style round is documented, so none is assumed.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder (5 questions) | Friendly, list-driven: pay, notice, hybrid pattern, reason for moving, background | Highest. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah's message names these topics herself | Treat every casual question as scored. Use your own words, kept whole, for A1 to A4, and a short arc built from your own sentences for A5 |
| B. Skeptic (4 questions) | Quiet checks of your background against the advert | Second. The prior is a light Skeptic, and the advert's ERP line and its production-schedules line are where your material is thinnest (F1, F7, F8) | Rehearse B1 until it is boring. Hold what your sentences carry, concede the limits specifically, and give a plan for what you would learn |
| C. Data-Driven Prober (3 questions) | Asks how the figure on your background was counted | Lower. Recruiters rarely probe numbers, but F4 carries a figure that invites it | Know what you can and cannot say about how it was counted, and say plainly when you do not know |
| D. Case / Strategist (3 questions) | A short live scenario from the role | Low. Hannah's list has none. Kept at 3 so the advert's tracking, stock and reporting lines each have a rehearsed answer | Clarify first, then structure, then think aloud |
| E. Pressure (3 questions) | A time-boxed "why you" or a challenge to a claim | Low. The call's register is friendly, but a recruiter may test a gap quickly | Pause, restate the question, anchor in what you actually said, hold through two follow-ups, concede specifically |

## Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Your own words, kept whole: "I'm hoping for £42,000." Say it plainly and stop. If asked what you earn now: "I'd rather focus on the range for this role." | Hannah named salary expectations first; F10 is your figure. JD because it scores the advert's stated terms |
| A2 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, in your own words, as your contract states it. If you do not know it offhand, say you will confirm it | Hannah named it. No row in the snapshot carries it, so the guidance is an instruction and claims nothing about you. JD because it fits the role's start |
| A3 | "How would the two-days-a-week hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the pattern, your own words again | F11 is your stated position against the advert's pattern. JD because it scores a term of the job |
| A4 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it at its own scope: you are looking because your Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. If she follows up, your own words again | F12 is the whole answer. EXP because it tests whether your story is consistent and your own |
| A5 | "So — walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots" "chase suppliers when orders slip" "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with the beats your sentences state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet. Tell them in your own words, in that order. If you include the figure, C1 is the likely follow-up | F9, F1, F2 and F4 are the evidence. EXP because it tests what you say you did against your background |

### B. Skeptic (weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert mentions SAP or something similar. Where do you stand on that?" | JD | [grounded] "Never used SAP" "we run our own in-house stock system" | The highest-ROI rehearsal in this pack. Say it plainly: "I haven't used SAP." Then your own sentence: "we run our own in-house stock system." Hold through two follow-ups by returning to those two sentences, never by treating the in-house system as the same thing as SAP. Concede specifically that you cannot speak to SAP itself. Then say, as a plan and not a past, how you would get up to speed on the team's system in your first weeks. The advert calls ERP experience "a plus" | F7 is the gap you stated and F8 its only adjacent evidence; this is the objection most likely to arrive against this background. JD because it scores the advert's ERP line, and the skeptic register is where candor is tested |
| B2 | "Our scheduling sits between planning, the warehouse and QA. Yours has been deliveries — how do you see the difference?" | JD | [grounded] "I schedule deliveries for our three depots" | Hold only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling involved production or quality teams, say who and how, in your own words; if it did not, say so plainly and stay with the depots. Hold through two follow-ups by returning to the depots, never by adding to them | F1 is where the advert's central line presses hardest on your material. JD because it scores the stated responsibility |
| B3 | "Why Quillmoor?" | CO | [generic] | Build it from the advert's own lines, which are what you have. Pick the one or two you find most interesting and say why, in your own words. If nothing stands out yet, say so plainly and ask her to tell you about the team, as she has said she will | No company research was available, so this is a pattern for the question and not a fact about Quillmoor. CO because it tests homework depth |
| B4 | "How confident are you with Excel — what's the most involved thing you've built?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Start from your own sentence: "I rebuilt our stock-count spreadsheet." Answer slot: if it was Excel, say what it did, in your own words; if it was another tool, or you have not worked in Excel, say so plainly and stay with the spreadsheet you rebuilt | F6 is the only evidence for the advert's Excel line, and it does not name the tool. JD because the advert lists Excel |

### C. Data-Driven Prober (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third — walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the sentence: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Answer slots, in your own words: how a discrepancy was counted; what the figure is most sensitive to; the assumption behind it you would defend least; which part was yours. For any of the four you cannot answer, say plainly that you do not know | F4 is the one headline figure. EXP because it tests whether the number survives scrutiny |
| C2 | "Tell me about a time a supplier order slipped and you had to chase it." | EXP | [grounded] "chase suppliers when orders slip" | The sentence carries one beat: "chase suppliers when orders slip." Answer slot: the advert's "chase late orders" line makes a specific story likely. If a particular order comes to mind, say what you did and what happened, in your own words; if none does, say so plainly and give the nearest thing your sentence carries | F2 is the evidence. EXP because it asks for a real instance, and the open prompt leaves room for none |
| C3 | "The role tracks supplier deliveries. What does that look like for you today?" | JD | [grounded] "chase suppliers when orders slip" | Answer slot: if you keep track of deliveries, say how, in your own words; if you do not, or it is someone else's job, say so plainly and return to "chase suppliers when orders slip" | F3 is silent, and the advert raises it. JD because it scores the stated responsibility |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a key delivery will be a week late, and a production schedule depends on it. What do you do first?" | CASE | [generic] | Structure it aloud: ask what is affected and by when; who needs to know, such as planning, the warehouse and QA; the options, such as an alternative source, a partial delivery or a reschedule; what you would record; and when you would follow up. The question asks about no past, so the guidance makes no claim about yours | The advert's chasing and scheduling lines, asked as a live decision. CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about Quillmoor |
| D2 | "The records show forty units of an item, but a shelf count finds thirty. What do you do?" | CASE | [generic] | Structure it: confirm the count before changing anything; check recent movements; tell whoever is affected; look for the cause; record what you found; say what would stop it recurring. No claim about your past | The advert's stock-records line as a decision. CASE because it scores reasoning |
| D3 | "The role reports weekly on on-time dispatch. How would you approach that?" | CASE | [grounded] | Answer slot: if you report on deliveries or dispatch today, say what and how often, in your own words; if you do not, say so plainly and set out what you would want to measure first, as a plan and not a past | F5 is silent on reporting, and the advert raises it. CASE because it asks for an approach |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who has used SAP?" | JD | [grounded] "Never used SAP" "4 years as a logistics coordinator at a building-supplies wholesaler" "chase suppliers when orders slip" | Pause and restate the question. Anchor in your own sentences: four years as a logistics coordinator at a building-supplies wholesaler, and chasing suppliers when orders slip. Concede specifically: "I haven't used SAP." Hold through two follow-ups by returning to those sentences, never by adding experience | F7, F9 and F2. JD because it scores the ERP line under time pressure; the structure is hold-then-concede |
| E2 | "That figure — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on the sentence's own attribution: "I rebuilt our stock-count spreadsheet." Answer slot: which part of the fall in discrepancies was yours, in your own words; if you cannot separate it, or others contributed, say so plainly and return to the spreadsheet you rebuilt | F4 again, as an attribution probe. EXP because it tests precision about your own part |
| E3 | "Planning wants one date and QA needs another. You're the new person. What do you do?" | CASE | [generic] | Pause. Ask what is fixed and what is flexible for each side; get both constraints in front of both teams; agree a date and record it. Concede that you would not yet know their process, and say you would not pick a side before knowing the constraints. No claim about your past | The advert's three-team coordination line, under pressure. CASE because it scores composure and structure |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B2, D1, E3 |
| "track supplier deliveries" | C3 |
| "chase late orders" | C2, D1 |
| "keep stock records accurate" | C1, D2, E2 |
| "report weekly on on-time dispatch" | D3 |
| "2+ years in operations or logistics coordination" | A5 |
| "confident with Excel" | B4 |
| "ERP experience (SAP or similar) a plus" | B1, E1 |
| "£38,000–£44,000" | A1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A3 |
| Notice period and reason for moving (Hannah's topics) | A2, A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first month look like in this role, and who would I be working with across planning, the warehouse and QA?" | It uses the advert's own three teams and shows you read the role closely |
| R2 | "Which system does the team use for stock and schedules, and how is people's onboarding on it handled?" | It meets the ERP line directly, and the answer tells you how much that gap would matter |
| R3 | "How is on-time dispatch measured today, and what does the weekly report look like?" | It shows interest in the reporting line and gives you the detail for D3 |
| R4 | "How are the two Avonmouth days usually set: fixed days for the team, or agreed individually?" | It is a practical question about the pattern, and it asks about the employer's practice, not yours |
| R5 | "What would make someone clearly successful in this role by six months?" | It gives you the scoring sheet in her words |
| R6 | "What are the next steps and the rough timescale after today?" | Hannah has said she will cover this; if she does not give timescales, this closes that gap |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has coordinated production schedules across planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation, not words for you: your material says delivery scheduling, not production scheduling. B2's slot stays with the depots |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the sentence names a system your company runs, not work you did in it |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't used SAP." No slot |
| Cut stock discrepancies by a third across the business | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your sentence names the stock-count spreadsheet and the fall in discrepancies, not what the fall covered. C1's slots stay with how it was counted and which part was yours |

## Sources

Provided documents: the advert you pasted, your message (your background, pay, hybrid pattern and reason for moving), and Hannah's LinkedIn message, quoted as the recruiter's own words. No dossier was present.

Searches sent, each refused:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics news strategy Avonmouth" — refused
- "Hannah Lowther Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have fed a values cheat sheet, but no values-style round is documented, so it would have moved only the CO question B3 |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. Hannah's own message establishes this session, so it would have moved only what follows the call |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have moved B3 and given the pack a grounded CO question; B3 is `[generic]` for that reason |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have moved the interviewer read, which is absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the stock-count spreadsheet or its discrepancy figures → F4 moves from `medium` toward `high`, and the answer slots on F1, F3, F5 and F6 can become your quoted words
- Whether the spreadsheet was in Excel, whether you track deliveries, and whether you report on dispatch → F3, F5 and F6 become `[grounded]` evidence instead of answer slots
- Your notice period, in your own words → A2 becomes your words instead of an instruction
- Search access for the research rows above → values, loop details, current strategy and Hannah's public footprint, which would turn B3 from `[generic]` to grounded and add an interviewer read
- A deeper research pass, once search is allowed — up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and recent organisation context for the CO questions
- Any prep notes Hannah sends before the call → coverage of anything she flags beyond her four topics
- A `tuesday-dossier.md` from an earlier session → verified evidence and a prohibited-claims list carried in, never required
