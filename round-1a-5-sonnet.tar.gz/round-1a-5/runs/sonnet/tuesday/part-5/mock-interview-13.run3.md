Searches were declined, so I'll write the pack from your message and the advert and label what that leaves generic.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-5/rooms/case-13-denied-b07d14aa/Quillmoor_operations-coordinator_interview_pack.md`. I built it for the recruiter screen with Hannah on Thursday at 2pm. Its main parts are:

- **Fit snapshot:** how your background lines up against the advert and Hannah's agenda.
- **Question banks:** 18 questions in six banks, with answer guidance for each.
- **Reverse questions:** six to ask her.
- **Prohibited claims:** things the pack won't coach you to say.

Three of its calls matter most:
- **Pay, hybrid and reason for leaving:** your own words are quoted whole for these, with nothing added. That covers "I'm hoping for £42,000", "two days at Avonmouth is fine, but I wouldn't want more than three", and the Reading relocation.
- **Highest-ROI prep (B1):** this is the production-scheduling gap. Your material says deliveries for three depots, not production schedules with planning and QA. The pack coaches stating that limit plainly before she asks. SAP and Excel are the next likeliest probes (B2, B3).
- **Notice period:** you didn't give one, so A2 is an instruction to state your actual notice period. The pack supplies no figure.

My three web searches (company values, recent news, and Hannah's public profile) were declined, so I couldn't research any of them. Company knowledge in B4 rests on the advert alone, and there is no interviewer read for Hannah.

Say the word and I'll play Hannah on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner (recruiter). Recruiter screen: Thursday 2pm, 30-minute phone call. She rings the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, how the hybrid pattern would work for you, what's prompting a move; then the team and next steps.

## How to use this pack

- Personas are how a question is asked. Types are what it scores. Tags: JD (the listed job and its terms), EXP (what you actually did), CO (what you know about the company), CASE (a live problem), VAL (behavior against published values; none read for this pack).
- Guidance is scaffolding, not a script. Everything worded for you here is proposed language, pending your approval: change anything that is not how you would say it.
- Where a row says answer slot, it is an instruction for the interview, not a question for you now. Either honest branch is a good answer.
- B1 is the highest-ROI prep in this pack. Start there.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | No gap on the words, which stay whole: "I'm hoping for £42,000." The figure sits inside the advert's band. The pack adds no range, floor or flexibility |
| F2 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | No gap on the words, which stay whole and unsoftened. Nothing added about how you would travel or what you would trade |
| F3 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, with nothing inspected behind it, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of that scheduling involved any of those functions, say which and how, in your own words; if none did, say so plainly and stay with the three depots |
| F4 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | discovery | Scheduling deliveries is not shown to be tracking supplier deliveries. Answer slot: if you followed deliveries after they were booked, or any of them came from suppliers, say how, in your own words; if you did not, say so plainly and stay with the scheduling |
| F5 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on an occasion. Lead with it in its own terms: you chase suppliers when orders slip |
| F6 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, and a headline number, so expect a probe on it (C1, C2, E2). The sentence says you rebuilt the spreadsheet and what happened over the year |
| F7 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: the advert's weekly reporting line makes a probe on reporting likely. If you report on deliveries or dispatch regularly, say what and how often, in your own words; if you do not, or it was not yours, say so plainly and return to the stock-count spreadsheet |
| F8 | "Confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel. Answer slot: if the spreadsheet was in Excel, say what you did in it when you rebuilt it, in your own words; if it was another tool, say so plainly and say which |
| F9 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it in the quote's own terms: four years, logistics coordinator, a building-supplies wholesaler |
| F10 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." The advert calls it a plus. Then how you would learn it, said as a plan and never as a past |
| F11 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | low | [inferred] | discovery | Your material does not show whether the in-house stock system counts as similar. Answer slot: say what you used it for, in your own words; if you used it little, or it was not like an ERP system, say so plainly and stay with the in-house stock system |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Your material does not state it. Logistics slot: give your actual notice period, as your contract states it, in your own words. The pack supplies no figure |
| F13 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap on the words, which stay whole. If she follows up, give the same words again, with nothing added |

## Persona table

Weights start from the recruiter-screen prior (conversational, with a light skeptic). Hannah's message establishes the one session, so no archetype fallback is used. No interviewer profile exists beyond a name and title, so no signal adjustments apply.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, unstructured; pay, notice, hybrid and reason for leaving arrive as chat | High: her four-item agenda is this persona's territory, and casual questions are still scored | Treat each logistics question as scored; answer in your own words, whole, and stop |
| B. Skeptic | Quiet probing of the gaps between the advert and your background | Medium: the advert asks for production scheduling, Excel and an ERP, and your material has gaps at F3, F8 and F10 | Rehearse the most predictable objection (B1) until it is boring; say the limit plainly |
| C. Data-Driven Prober | Goes line by line on a number | Low: only if she reads your application closely; the stock-count figure is the one target | Know how the figure was counted, or say plainly you do not |
| D. Case / Strategist | Live problem from the role | Low: a recruiter screen rarely runs one, but the advert's job is coordination under pressure | Clarify, then structure, then answer; think aloud |
| E. Pressure | Time-boxes, tests whether you hold a position | Low: a 30-minute call leaves little room, but a sixty-second pitch is common | Pause, restate, hold through two follow-ups, concede specifically |
| F. Values / Behavioral | Asks for a specific occasion | Low: no values-style round is documented for this loop | Pick a real occasion or say plainly none comes to mind |
| G. Peer Evaluator | Seam-splitting with equals | Not expected: the call is with the recruiter alone, so no bank | None needed |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot: your own words, whole: "I'm hoping for £42,000." Nothing added. If asked what you earn now, you can decline: "I'd rather focus on the range for this role." | Hannah named salary expectations as the first agenda item; F1 holds the words. JD because it scores the listed job's terms |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, as your contract states it, in your own words. Nothing in your material states it, so the pack supplies no figure and no start-date wording | Named on her agenda; F12 has no quote yet. JD because it is a term of taking the job |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot: your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up, the same words again, with nothing added | Named on her agenda; F2 holds the words. JD because the advert states the pattern |
| A4 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot: your own words, whole. If she follows up on it, give the same words again, with nothing added | Named on her agenda; F13 holds the words. EXP because it is about your own situation |
| A5 | "So, walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc of three beats, each a clause the quotes state, in your own words: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Then stop and let her ask | The biography question is the standard opener of a screen; F9, F5 and F6 supply the beats. EXP because it tests what you did |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What's the closest work you've done to that?" | JD | [grounded] "I schedule deliveries for our three depots" | The highest-ROI rehearsal in this pack. Level 1: "I schedule deliveries for our three depots." Level 2, if she asks whether that involved planning or QA: answer slot: if any of it did, say which and how, in your own words; if none did, say so plainly and stay with the three depots. Level 3, if she asks how you would get up to speed: say what you would ask and learn first, as a plan, never as a past. The limit goes first, before she asks: your material says deliveries, not production schedules. Hold by returning to the three depots, never by adding to them | F3 is where the advert's headline duty presses hardest on your background, so some form of this question is likely. JD because it scores a stated requirement |
| B2 | "Have you used SAP or a similar ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | The plain acknowledgment, from your own words: "I've never used SAP." Answer slot: say what you used the in-house stock system for, in your own words; if you used it little, or it was not like an ERP system, say so plainly and stay with the in-house stock system. Never call it an ERP unless you can say what it did | F10 and F11 carry the gap and the open part of "or similar". JD because the advert lists it as a plus |
| B3 | "How confident are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: if the spreadsheet was in Excel, say what you did in it when you rebuilt it, in your own words; if it was another tool, say so plainly and say which. Do not claim a level you cannot back with the next follow-up | F8: the quote says spreadsheet, so the probe is whether it was Excel. JD because the advert lists Excel; `[inferred]` because the derivation from spreadsheet to Excel is the open part |
| B4 | "What do you know about Quillmoor?" | CO | [grounded] | Say what the advert says, in its own terms: a diagnostic-test manufacturer of about 400 staff, with a job that coordinates scheduling, deliveries, stock records and dispatch reporting. Anything beyond that is for you to read on the company's own website before Thursday and say as what you read | Asked casually and still scored. Company-specific research was declined, so this row rests on the advert alone and is generic beyond it. CO because it scores homework |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that number was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Four slots, each in your own words: how discrepancies were counted; what the figure is sensitive to; the assumption behind it you would defend least; which part was yours. Where you do not know how it was counted, say so plainly. The pack names no method | F6 is your one headline figure, and a prober's first target. EXP because it tests attribution |
| C2 | "A third lower than what — what were you comparing against?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: say what the fall was measured against, if you know; if you do not, say so plainly and return to what you rebuilt | The second-level follow-up a prober asks of a percentage; F6. EXP because it tests whether the figure survives scrutiny |
| C3 | "The role reports weekly on on-time dispatch. What reporting have you done?" | JD | [grounded] | Answer slot: if you report on deliveries or dispatch regularly, say what and how often, in your own words; if you do not, or it was not yours, say so plainly and return to the stock-count spreadsheet | F7 has no evidence in your material, so this is where a probe lands. JD because the advert states the duty |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery the warehouse is waiting on will be two days late. Talk me through what you do." | CASE | [generic] | Structure it: what you would ask first (what is waiting on it, what the delay moves), what you want to protect, your options, who you would tell, what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's chase-late-orders line (F5's requirement); `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "Planning wants a job moved up, QA needs longer, and the warehouse is waiting. How do you work out what to do?" | CASE | [generic] | Ask what is fixed and what can move, who decides, and what each side needs; say how you would keep all three informed. Say you would learn how this site decides rather than assume it. No claim about your past | From the advert's planning, warehouse and QA line (F3's requirement); `[generic]` for the same reason |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we put you through?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Pause and restate the question. Build the answer only from those two sentences, in your own words. If she presses on production scheduling or SAP, hold by returning to the same beats, and concede the limit specifically: "I've never used SAP." For production scheduling, the slot in B1 applies | A time-boxed pitch is the standard pressure move in a screen; F9 and F5 supply the beats. JD because it scores fit against the role |
| E2 | "That stock-count result — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on what the sentence says you did: "I rebuilt our stock-count spreadsheet." Answer slot: say which part of the fall you would credit to the rebuild, in your own words; if you do not know how much of it was the rebuild's, say so plainly and return to what you rebuilt. Hold through two follow-ups by returning to the rebuild, never by adding to it | The attribution probe aimed at F6, your one number. EXP because it tests what was yours |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time a supplier order slipped and what you did." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Selection scaffold: pick one real occasion. It needs the order, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the practice in your own words, or how you would handle it | The advert's chase-late-orders line (F5) invites a specific occasion. EXP because it scores what you did |
| F2 | "Tell me about a time you put getting a record right ahead of getting something done quickly." | EXP | [grounded] | Selection scaffold: pick one real occasion. It needs the record, what was at stake, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The advert's keep-stock-records-accurate line (F6's requirement). EXP because it scores what you did |

### Requirement coverage

| Requirement or agenda item | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, D2 |
| Track supplier deliveries and chase late orders | A5, D1, F1 |
| Keep stock records accurate | C1, C2, E2, F2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A5, E1 |
| Confident with Excel | B3 |
| ERP experience (SAP or similar) a plus | B2 |
| £38,000–£44,000 | A1 |
| Hybrid: two days a week at Avonmouth | A3 |
| Notice period (Hannah's agenda) | A2 |
| What's prompting a move (Hannah's agenda) | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work most closely with across planning, the warehouse and QA?" | The advert's job is the seam between those three, so the answer shows how the seam works day to day |
| R2 | "Which system does the team work in day to day, and how do new starters learn it?" | It puts the ERP line on the table on your terms and asks for the ramp plan |
| R3 | "Are the two days at Avonmouth fixed days, and is the pattern expected to change?" | It surfaces the team's pattern from their side before any later conversation |
| R4 | "What would the first few months look like in this role?" | It signals you are thinking about the work, and gives you the team's priorities |
| R5 | "What are the next steps, and who would I speak to next?" | She has said she will cover next steps; this confirms the format and who is in the next conversation |
| R6 | "What makes someone stand out in this role after the first six months?" | Recruiters weigh the closing slot as a preparation signal, and the answer tells you what the team scores |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran production scheduling, or coordinated planning and QA | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says deliveries for three depots, not production schedules. B1's slot stays inside the deliveries |
| Has ERP experience, or knows SAP | Negative the candidate stated, F10; inflated form of F11 | The plain acknowledgment F10 gives: "I've never used SAP." B2's slot asks only what the in-house stock system was used for |
| Confident, advanced or expert in Excel | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: the material says spreadsheet, not Excel |
| Cut stock discrepancies by a third | Inflated form of F6 | F6's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence says what happened over the year, not what share was the rebuild's |
| Flexible on office days, or happy with whatever pattern is needed | Inflated form of F2 | F2's quote whole. The limit is the pack's observation: the sentence says what you would not want beyond three days and nothing about flexing it |
| A pay floor, a range, or flexibility on salary | Inflated form of F1 | F1's quote whole. The limit is the pack's observation: your words give one figure and nothing about a floor, a range or flexibility |

## Sources

**Provided:** Hannah Lowther's LinkedIn message as pasted; the advert as pasted; your background as you described it in your message. No tuesday-dossier.md was present.

**Searches sent, all refused (permission not granted), nothing returned:**

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics Avonmouth Bristol news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The call was refused. It would have given published values to theme behavioral questions; no values-style round is documented for this loop, so no cheat sheet either way |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message fixes the loop: one 30-minute phone call with her, with her stated agenda, so persona weights follow it |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The call was refused. It would have moved B4 from advert-only to grounded in current priorities |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The call was refused. It would have given an interviewer read and a reverse question tied to her path |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A2 and F12 take your own words instead of an instruction
- Your CV as submitted → the evidence cells and the beats in A5 rest on your CV's own lines, and the F8 and F11 rows can move from `[inferred]` toward `[grounded]`
- Your answers to the slots in B1, B2, B3, C1, C2 and C3, typed here → they enter the fit snapshot and regenerate F3, F7, F8, F11 and F6
- Search permission → B4 can rest on the company's own pages and recent news, an interviewer read can be added for Hannah, and R-questions can be tied to her path; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is offered once, and only once searching is allowed
- What Hannah tells you about the team and next steps, after the call → a pack for the next round, with persona weights set from who runs it
- A tuesday-dossier.md from an earlier session → verified evidence and prohibited claims, which sharpen the guidance but are never required
