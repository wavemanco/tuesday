The web searches were refused, so I'll build the pack from what you gave me and label it that way. I'm writing the pack file now.
Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says successful candidates get "a cheque for €1,850" and that "you deposit the cheque and send the balance on to the vendor". Asking for money, ID and bank details before any offer, and a cheque where you send part of the money on, are a known scam pattern. The fee, the passport and bank details, and the cheque request are very likely a scam. Please hold all of them until you've checked the invite with the employer it names. Use contact details you find yourself on its own website or careers page, not the email address, numbers or replies in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/tuesday/part-5/rooms/case-12-denied-703a4fb9/Brennock-Facilities_remote-administrative-assistant_interview_pack.md`. I assumed the office manager would be your day-to-day boss, so I weighted it like a hiring-manager round. The web searches on the company's values, interview process and strategy were refused. So the pack uses only what you pasted and has no company-specific values or strategy content. The Sources section lists what was refused.

**What to expect, from the ad and the invite:**
- **Scenario questions.** For example two people wanting the same diary slot, a trip to book on a budget, a supplier invoice that doesn't match an order, and a Word edit deadline.
- **Probing of the gaps.** Supplier invoices are the biggest: you chased unpaid invoices, but the ad says processing supplier invoices. Travel booking and your "okay" Excel are next.
- **Your own history.** Expect "walk me through the journey" and "which part of the appointment book was actually yours?"

**How to prepare:**
- Rehearse B2 first, the invoice question. Stay at "I chased unpaid invoices", say plainly if you didn't process any, and add how you'd learn the rest as a plan.
- Don't upgrade "okay with Excel" or claim travel booking you haven't done. The pack lists these as claims it won't coach.
- Practise the scenario answers aloud (bank A): clarify first, then structure, then answer.

I can play the Skeptic on B2 as a live drill if you'd like. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two questions that would reshape the pack:
1. Can you paste the full text of the ad? That would replace my paraphrase of the duties.
2. Would the office manager be the person you'd report to day to day?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager (name not given). Format: a 30-minute video call, as the invite describes it. Built on one assumption: the office manager is the person you would work for day to day, so the pack uses hiring-manager weights. If that is wrong, the persona weights change (see the upgrade menu).

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the employer's published values (none were available to this pack) |
| EXP | Whether what you say you did holds up under questions |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its strategy |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

Requirements are the ad's lines as you described them in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you ran the appointment book, for four physios, because a named record beats an adjective |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad's travel line makes a probe likely. If you booked travel for anyone, say what and for whom, in your own words; if you did not, say so plainly and say how you would go about it |
| F3 | "preparing documents in Word" — the ad, as you described it | "I'm good with Word" — your message | low | [grounded] | discovery | Your own word is good, and the words stay there. Answer slot: if you prepared documents in Word, say which kinds, in your own words; if your use was light, say so plainly and stay with what you did use it for |
| F4 | "preparing documents in ... Excel" — the ad, as you described it | "okay with Excel" — your message | low | [grounded] | discovery | Your own word is okay, and the pack keeps it at that. Answer slot: if you used Excel for anything, say what, in your own words; if it was little, say so plainly and say how you would build it up |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | low | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and the words stay there: "I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe on processing likely. If any part of handling invoices beyond chasing was yours, say which part, in your own words; if none was, or it was not yours, say so plainly and stay with the chasing |

## Persona table

Weights are a shown judgment: relationship prior first, then the loop. The only loop source is the invite's own words (one 30-minute video call with the office manager), which does not say what the call holds, so the pack falls back to the generic archetype and says so: these weights rest on a pattern, not on this employer's documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live mini-problems from the job: a diary clash, a trip to book, a mismatched invoice | Highest. Hiring-manager prior, and the ad's four duties are all easy to turn into small scenarios | Clarify first, then structure, then answer; think aloud. The scenarios claim nothing about your past |
| Skeptic (bank B) | Quiet probing of what your background does not show: travel, supplier invoices, Excel | High. The ad's duties and your material differ most on F2, F4 and F5, and a hiring manager is derisking those | Rehearse B2 until it is boring: your own words at their own scope, then how you would learn the rest |
| Conversational (bank C) | A friendly "walk me through your journey" on a video call | Mid. A 30-minute call usually opens this way, and casual questions are still scored | A 90-second arc built only from what you have said about your own history |
| Data-Driven Prober (bank D) | Asks which part was yours and how a thing was done | Mid. Your material holds a figure (four physios) and an invoice task, and both can be probed | Say plainly what was yours and what was shared; say plainly when you do not know |
| Peer Evaluator (bank E) | Collaboration scenarios with colleagues | Low. The interviewer is assumed to be your manager, not a peer, though a remote assistant serves several colleagues | Say whose request goes first and how you tell people, without inventing a past case |
| Pressure (bank G) | A short, blunt challenge to your weakest spots | Low. A 30-minute call by an office manager is rarely a stress format, but the challenge may arrive in friendly form | Pause, restate, hold the part your own words carry, concede only what is true |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people whose diaries you manage ask for the same slot on the same morning. Walk me through what you'd do." | CASE | [generic] | Think aloud: ask what each meeting is for and whether either person has priority, offer each of them alternatives, confirm the outcome with both in writing, and update the diary. It is a plan for the future and claims nothing about your past | The ad's calendar line (F1's requirement) turned into a decision. CASE because it scores reasoning, not a record |
| A2 | "Your manager needs a two-night trip to Cork booked for next Thursday, on a set budget. What do you ask first, and what do you do?" | CASE | [generic] | Clarify first: dates, who is travelling, budget, preferences and who approves. Then options, approval, booking, and sending the itinerary. Say you would check any step you are unsure of rather than guess. It claims nothing about your past | The ad's travel line (F2's requirement) as a live problem, which is the safest way to meet it while F2 has no evidence |
| A3 | "A supplier invoice arrives that doesn't match what was ordered. What do you do?" | CASE | [generic] | Hold it, compare it with the order, say what you would check, tell whoever approved the order, and record what happened. It is a plan, not a claim about past work | F5's requirement as a decision. CASE because it tests process thinking where the evidence is thinnest |
| A4 | "Three people send you different edits to one Word document an hour before it goes out. How do you handle it?" | CASE | [generic] | Find out who has the final say, collect the edits in one version, flag any that conflict, and confirm the final text before it goes. It claims nothing about your past | F3's requirement as a live problem, scoring judgment more than software skill |
| A5 | "You're handed a spreadsheet of this month's supplier invoices and asked which are overdue. How would you set about it?" | CASE | [generic] | Ask what each column holds and what overdue means here, then say how you would sort or mark the late ones and double-check the result. If you would need to look up how to do a step, say so plainly. It claims nothing about your past | F4 and F5 together as a task. CASE because the answer is a method, with the honest limit in view |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role is remote and nobody sits beside you. Why this move from the clinic desk?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Your material gives the clinic and the two years, and nothing about your reasons, so the reasons are yours to state. Answer slot: say what draws you to this role, in your own words; if the honest answer is mixed, say so plainly | Motivation consistency is the Skeptic's standing probe. F1 and F5 are what your history offers, and the reasons come from you |
| B2 | "You've chased unpaid invoices. This role is processing supplier invoices. What part of that have you done?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if any part of handling invoices beyond chasing was yours, say which part and what you did, in your own words; if none was, or it was not yours, say so plainly and stay with the chasing. Add how you would learn the rest as a plan, never as a past. Hold through two follow-ups by returning to the chasing, never by adding to it | F5 is where the ad presses hardest and your material is thinnest, so this objection arrives in some form. JD because it scores a stated duty |
| B3 | "How comfortable are you in Excel, honestly?" | EXP | [grounded] "okay with Excel" | Use your own word: "I'm okay with Excel." Answer slot: say what you have used it for, in your own words; if it was little, say so plainly. Then, as a plan, say what you would do to get faster | F4 is a low-confidence self-rating, and the word honestly signals a probe. EXP because it tests whether your description holds up |
| B4 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: if you have, say what you booked and for whom, in your own words; if you have not, say so plainly and say how you would approach it, as a plan. Do not describe booking you did not do | F2 has no evidence either way, and the ad's travel line makes this a direct question. JD because it scores a stated duty |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc in this order: the two years at the clinic, running the appointment book for four physios, chasing unpaid invoices. Then, answer slot: say in your own words why you want this role; if you are unsure, say so plainly. Add nothing the three statements do not carry | Opening arcs are scored for economy. F1 and F5 supply the beats, and the reason is yours |
| C2 | "Tell me about the appointment book." | EXP | [grounded] "I ran the appointment book for four physios" | Beats: you ran it, and it was for four physios. Answer slot: the ad's calendar line makes a probe on changes or clashes likely. If any came up and you dealt with them, say what happened and what part was yours; if none did, or it was not yours, say so plainly and stay with the book you ran | F1 is your strongest row, and a friendly register hides a probe. EXP because it tests what was yours |
| C3 | "What are you actually playing with in Word and Excel these days?" | JD | [grounded] "I'm good with Word" "okay with Excel" | Use your own words for each: good with Word, okay with Excel. Answer slot: say what you use each for, in your own words; if you use them little at the moment, say so plainly and say what you would like to learn | F3 and F4. A casual question about a skill the ad lists is still scored |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of that appointment book was actually yours?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the quote: "I ran the appointment book for four physios." Answer slot: if anyone shared it with you, say so plainly and say what was yours; say what the four counts, in your own words. If you are unsure how something was set up, say so | F1's quote is the defend-the-number target: four physios. EXP because it tests attribution |
| D2 | "Walk me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | Tell it as you did it, in your own words, at the scope of the quote. Answer slot: if you kept any list or record to keep track, say what it was; if you kept none, say so plainly and tell it as it happened | F5, probed on its own detail. EXP because it tests what you actually did |
| D3 | "You have a list of invoices and suspect one has been paid twice. How would you check?" | CASE | [generic] | State what you would compare, what you would ask the person who approved it, and what you would hold until it is clear. It is a plan, not a claim about past work | F5's requirement, framed as accuracy. The Prober asks for method |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Colleagues keep sending you last-minute requests at the same time. How do you decide whose goes first?" | CASE | [generic] | Say what you would ask each person, how you would check urgency with whoever sets priorities, and how you would tell the others where they stand. It claims nothing about your past | A remote assistant serves several people, so prioritising is part of F1's requirement |
| E2 | "A colleague's invoice query is holding up a payment and you think they've made a mistake. How do you raise it?" | CASE | [generic] | Say how you would check your facts first, then raise it privately and neutrally, and confirm what was agreed. It claims nothing about your past | Collegial tact on a task in F5's area. CASE because it is a live problem |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why should we choose you over someone who has done this job before?" | EXP | [grounded] "I ran the appointment book for four physios" "chased unpaid invoices" | Pause and restate the question. Hold on the two sentences you have said: "I ran the appointment book for four physios" and "chased unpaid invoices." Through two follow-ups, return to them rather than adding to them. Answer slot: if a part of the ad's list is new to you, say so plainly and say how you would learn it | Composure under a blunt question. F1 and F5 are the held ground, and the concession stays specific |
| G2 | "Okay with Excel isn't much for a role that runs on spreadsheets, is it?" | JD | [grounded] "okay with Excel" | Hold your own word, "okay with Excel", and do not upgrade it under pressure. Concede that it is not your strongest skill, then say how you would build it, as a plan. Answer slot: say what you have used it for; if it was little, say so plainly | F4 is the row a pressure interviewer will lean on. JD because it scores a stated duty |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| managing calendars | A1, C2, D1, E1 |
| booking travel | A2, B4 |
| preparing documents in Word | A4, C3 |
| preparing documents in Excel | A5, B3, C3, G2 |
| processing supplier invoices | A3, A5, B2, D2, D3, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first month look like for this role?" | Shows you are planning to contribute from the start, and gives you a target to prepare for |
| 2 | "How are calendars and travel handled today, and which tools does the team use?" | Shows practical interest in the work and tells you what to learn first (F2, F3) |
| 3 | "How do supplier invoices come in and get approved, and where would I fit in that?" | Turns the biggest gap (F5) into a working question and shows you want the process right |
| 4 | "How do you like to work with a remote assistant day to day: check-ins, channels, response times?" | A remote role depends on this, and it shows you are thinking about how to work well at a distance |
| 5 | "What would make this hire a success after three months?" | Lets the interviewer state their own scoring sheet and gives you something to aim at |
| 6 | "What are the next steps after this call, and roughly how long do they take?" | Shows you want to plan around the process, and avoids ending the call with nothing to go on |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation, not words for you: the material says chasing unpaid invoices, not processing supplier invoices. B2's slot stays inside the chasing |
| Advanced or expert Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". B3 and G2 keep your own word |
| Managed calendars across a team or for executives | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios" |

## Sources

Provided documents: the invite as you pasted it, and your description of the ad and of your background, both in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused:

- `Brennock Facilities Ltd company values` — refused
- `Brennock Facilities Ltd interview process administrative assistant` — refused
- `Brennock Facilities Ltd strategy recent news` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have moved a values cheat sheet and VAL questions. None are included, and nothing about the employer's values is stated |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have moved the loop structure and persona weights, which now rest on the generic fallback |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have moved CO questions. The pack has none, and nothing about the employer's strategy is stated |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your description of the ad's duties fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → F1 to F5 take the ad's own wording, and any further duties become rows with questions
- The office manager's name and role → an interviewer read, retuned persona weights, and a reverse question tied to their path
- Your answers to the answer slots (travel, Excel, invoice handling) → F2 to F5 are rewritten from your own words, and the matching bank rows become story-mapped
- Whether the office manager would be your day-to-day manager → persona weights change if they would not
- A pasted values page or strategy brief from the employer → a values cheat sheet and CO questions
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → strategy brief, interviewer footprint and role-family loop reports, if search is allowed
- `tuesday-dossier.md` → verified evidence and prohibited claims would carry across later sessions
