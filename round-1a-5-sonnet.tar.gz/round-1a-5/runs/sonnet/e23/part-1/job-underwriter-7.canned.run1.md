I'll read the reference files first.
I've finished reading the skill's reference files. Next I'll load the web search tool so I can check that Calderbrook exists and the posting is live. Then I'll write the assessment.
**Yes, it's worth applying: `conditional_go`.** R1 and R2, the hard gates, are met on your CV. The gaps are R4, R6b, R7b, R9 and R10 (unclear), R5 and R11 (adjacent) and R12 (absent). Calderbrook exists and matches the advert, but I couldn't confirm the posting is live.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (clear, timely written records on the electronic patient record)
- `important` — direct: R6a, R7a, R8 · adjacent: R5 (care for housebound adults in their own homes), R11 (a small caseload of your own) · unclear: R6b (leg-ulcer care), R7b (continence care beyond catheters), R9 (end-of-life visits), R10 (care planning)
- `preferred` — absent: R12 (Doppler assessment)

What matters: R4 — the one essential criterion your CV doesn't evidence; R6b, R9 — core duties the CV is silent on; R5, R11 — bridged through your discharge-to-assess work, with limits; R12 — a gap you've confirmed, and the posting lists it as desirable.

**Opportunity ledger.** The role looks sound on what's stated: a senior nurse supports the caseload and the pay range is given (RR2, RR3). The posting's live status and the rota and contract basis are unconfirmed (RR1, RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed live and open (RR1); (2) your answers on R4, R9 and R6b show real experience, or you present them honestly as things you'd learn on the job; (3) R11 and R12 are presented as adjacent and absent, never as caseload or Doppler experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the company's About page, fetched |
| Role | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Essential vs desirable | Essential: NMC Adult registration, full UK licence, one year post-registration, clear timely records. Desirable: Doppler assessment | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | A 2026 survey of community staff nurses, Band 5, England (n=1,240) gives median basic pay £34,300, interquartile range £32,400–£36,600. This posting's range spans that interquartile range. In the survey 61% were paid mileage and 24% had a pool or lease car, so a pool car is a plus. The band is national, not Halifax, and is not Calderbrook's offer | `[generic]` Wardround 2026 pay guide; `[grounded]` JD for the posting's figures |
| Scope read | Entry-friendly for a first community post: one year's experience is essential, Doppler is desirable only, and a senior nurse supports the caseload | `[inferred]` from the JD's essential and desirable lists |
| Named contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Unknowns | Rota and weekend or out-of-hours work; contract basis; caseload size; which record system; whether the post is live | — |
| Contradictions | None between the JD and the About page. The careers page I tried returned no page, so I couldn't confirm the listing | `[grounded]` About page and failed careers fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. I haven't checked the register, so medium | `[grounded]` CV | none; the employer will check the register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. I haven't seen the licence | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on documentation and on any electronic record. Ward nurses keep records as a matter of course, but that is a pattern, not your claim | `[grounded]` CV silence; `[generic]` ward practice | G1 |
| R5 | Care for housebound adults in their own homes | important | adjacent | medium | transferability | 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge. The limit: that was short-term post-discharge visiting, not ongoing district nursing for housebound patients | `[grounded]` CV; `[inferred]` adjacency | Frame as home-visiting experience with the limit named |
| R6a | Wound care | important | direct | medium | none | CV lists wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6b | Leg-ulcer care | important | unclear | low | discovery | CV names pressure ulcers and surgical wounds, not leg ulcers or compression | `[grounded]` CV silence | G3 |
| R7a | Catheter care | important | direct | medium | none | CV lists catheter care | `[grounded]` CV | none |
| R7b | Continence care beyond catheters | important | unclear | low | discovery | CV does not mention it | `[grounded]` CV silence | G4, not asked this turn |
| R8 | Insulin administration | important | direct | medium | none | CV lists insulin administration | `[grounded]` CV | none |
| R9 | End-of-life visits | important | unclear | low | discovery | CV is silent. Acute medical wards often care for dying patients, but that is not your claim | `[grounded]` CV silence; `[generic]` ward case mix | G2 |
| R10 | Care planning | important | unclear | low | discovery | The discharge-to-assess role may have involved planning, but the CV doesn't say | `[grounded]` CV silence; `[inferred]` possibility | G5, not asked this turn |
| R11 | A small caseload of your own | important | adjacent | medium | transferability | You confirmed you've never held your own caseload. The adjacent work is organising home visits in the discharge team. The limit: no ongoing responsibility for a named list of patients | `[grounded]` your statement and CV | Say plainly you'd be new to this; the JD offers senior support |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You confirmed you've never done one. The JD lists it as desirable, and the named contact has spoken on Doppler training for staff new to community work | `[grounded]` your statement, JD and speaker page | Ask whether training is given (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records on an electronic patient record (R4, must_have) | discovery | Nothing in the CV about documentation or a record system | It is the one essential criterion not yet evidenced | Documenting on a trust electronic record; discharge-to-assess visit notes; completing records in the time allowed; audit or feedback on your notes | A ward documentation audit result, a competency sign-off or a reference | `[grounded]` CV silence; `[inferred]` that it is the one essential item still open |
| G2 | End-of-life care (R9, important) | discovery | Silent on dying patients | It is a named duty of the role | Caring for dying patients on the ward; anticipatory medicines; supporting families; discussing preferences for care | A reflective account, thank-you letter or training record | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R6b, important) | discovery | Pressure ulcers and surgical wounds are named, leg ulcers are not | It's a named duty, and the posting pairs it with a desirable skill | Applying compression bandaging; assessing leg wounds; leg-ulcer training or clinic time | A competency record or training certificate | `[grounded]` CV and JD |
| G4 | Continence care (R7b, important) | discovery | Catheters yes, other continence care not mentioned | A named duty | Bladder and bowel care, continence assessments, pad and product reviews | A competency record | `[grounded]` CV silence |
| G5 | Care planning (R10, important) | discovery | The discharge team role may have included it | A named duty | Writing or reviewing care plans after discharge; planning visits or equipment | A sample plan, anonymised | `[grounded]` CV; `[inferred]` from the discharge-to-assess remit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Listing not confirmed on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers address I tried may simply not be the right one, or the post may have closed | `[inferred]` from the failed careers fetch against an About page that says vacancies are listed there | Is this post currently open, and where is it listed on your site? | unresolved |
| RR2 | Structured support for a new caseload-holder | positive_signal | — | "supported by a senior community nurse" | A nurse new to community work would not carry the caseload alone | `[grounded]` JD | How is the caseload built up for a nurse new to community, and for how long is supervision close? | noted |
| RR3 | Pay and car provision are stated | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | The range is in line with the national survey band, not a finding about this employer | `[grounded]` JD; `[generic]` survey band | Where in the range would someone with my experience start? | noted |
| RR4 | Rota, weekend or out-of-hours work, and contract basis unstated | unknown | — | "end-of-life visits" | End-of-life visits may need evening or weekend cover | `[generic]` pattern for community nursing; the posting is silent | What is the working pattern, including weekends and any out-of-hours, and is the post permanent? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the discharge-to-assess secondment first in your experience, described as 18 months of home visits in the first week after discharge. No caseload wording | R5 | `[grounded]` CV | pending your approval |
| E2 | Add a documentation or records line only if your answer to G1 supports it | R4 | `[grounded]` R4 row | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott before applying. Ask RR1, RR2 and RR4's questions, and whether Doppler training is provided | RR1, RR2, RR4, R12 | `[grounded]` JD and speaker page | pending your approval |
| A2 | In your supporting statement, say plainly that you have no caseload or Doppler experience yet. Point to the senior support and the desirable-only Doppler | R11, R12 | `[grounded]` JD | pending your approval |

Nothing here, in the table or in the advice around it, is final until you approve it. If you apply and want interview rehearsal, that's mock-interview's job, not this one's.

## Evidence status

Verified: none yet. Unverified leads: none.

I've also not used the National Insurance number you included. It isn't needed to assess a role.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched that page and the careers address calderbrookhealth.example/careers, which returned no page. Role reality: the employer exists as described, and the posting's live status isn't confirmed (RR1) |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change 2026 Calderbrook", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the named-contact row and A1. The page names her as team lead, not as the hiring manager |

If you'd like this kept, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your answers on G1, G2 and G3 → R4, R9 and R6b move from `unclear`, which could firm up the must-have row.
- Competency sign-offs for wound care, catheterisation and insulin from your trust → R6a, R7a and R8 toward `high`.
- A pay floor, shift limits or any other non-negotiables → the hard-gate checks against them, which are unknown now.
- Mabbott's answers on RR1 and RR4 → the posting's live status, rota and contract basis.
- A deeper research pass on Calderbrook (contract and inspection history, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — On the ward or in the discharge team, what did you record visits and care on (which electronic record, if any), and is there an audit, feedback or sign-off that shows your notes were clear and on time?

G2 — Have you personally cared for dying patients, on the ward or during discharge visits? What did you do yourself, such as symptom control, anticipatory medicines or supporting family, and what was a senior's?

G3 — Have you dressed or managed leg ulcers, including compression bandaging? Who assessed the patient, and do you have any competency sign-off?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.