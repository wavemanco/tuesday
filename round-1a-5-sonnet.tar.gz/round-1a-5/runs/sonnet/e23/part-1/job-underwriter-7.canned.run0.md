I'll read the reference files the skill points to before building the assessment.
I've read the skill's rules and I'm now checking that the employer and posting are real, before I write the assessment.
**Job Underwriting Assessment: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC, Halifax**

## Decision snapshot

**Yes, worth applying for, on the conditions below. Status: `conditional_go`.** R5 and R9 are still unconfirmed, and the posting isn't yet confirmed live (RR1).

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4, R6a, R7a, R8 · adjacent: R6b (leg-ulcer care), R11 (housebound adults in their own homes) · unclear: R5 (clear, timely written records), R9 (end-of-life visits)
- `important`: unclear: R7b (continence care), R10 (care planning) · absent: R12 (own small caseload)
- `preferred`: absent: R13 (Doppler assessment)

R12 and R13: absent on your own account; R6b and R11: adjacent bridges with named limits; R5, R9, R7b and R10: unclear because the CV is silent, not shown absent.

**Opportunity ledger.** The role states its supervision and pay (RR2, RR3), and the hiring lead publicly speaks on training staff new to community work (RR5). The posting isn't confirmed live on the employer's site (RR1), and the rota, hours and contract basis aren't stated (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed live and open (RR1); (2) R5 and R9 are confirmed from your own account (G1, G2); (3) the CV and letter claim no caseload, Doppler, leg-ulcer, continence or care-planning experience you haven't confirmed (R12, R13, R6b, R7b, R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health: a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record; small own caseload, supported by a senior community nurse | `[grounded]` JD |
| Posting status | Not confirmed on the employer's site: the careers address I tried returned no page. The closing date isn't stated | `[grounded]` fetch result; `[grounded]` JD silent on closing date |
| Scope read | A supervised entry into caseload-holding: the caseload is "small" and the post sits under a senior nurse | `[inferred]` from the JD's "small caseload… supported by a senior community nurse" |
| Market calibration | Stated pay £31,050–£37,800 brackets a survey's interquartile range for community staff nurses (£32,400–£36,600; median £34,300; n=1,240). The same survey has 61% paid mileage and 24% with a pool or lease car, so a pool car is on the better side of that pattern. This is a secondary survey and not an official pay table, and it is a pattern, never this employer's offer | `[generic]` Wardround 2026 pay guide; `[grounded]` JD for the stated figure and pool cars |
| Hiring lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Unknowns | Closing date; rota and weekend working; permanent or fixed-term; which hub; when mileage is paid given pool cars; whether Doppler training is provided | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the About page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states active Adult registration, revalidation due March 2028. Self-reported; the NMC register entry is the inspectable artifact | `[grounded]` CV | offer: register entry would raise to high |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B; the posting provides pool cars | `[grounded]` CV and JD | none |
| R3 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax. The JD names only the town, not the hub | `[grounded]` your message and JD title | RR4 asks which hub |
| R4 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward | `[grounded]` CV | none |
| R5 | Clear, timely written records (electronic patient record) | must_have | unclear | none | discovery | CV is silent on record-keeping and on any electronic system | `[grounded]` CV silence | G2 |
| R6a | Wound care | must_have | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care is real; leg ulcers aren't mentioned. Limit: no stated exposure to leg-ulcer assessment or compression | `[grounded]` CV; `[inferred]` adjacency | G4 |
| R7a | Catheter care | must_have | direct | medium | none | CV states catheter care | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | none | discovery | CV mentions catheter care only | `[grounded]` CV silence | G5 |
| R8 | Insulin administration | must_have | direct | medium | none | CV states insulin administration | `[grounded]` CV | none |
| R9 | End-of-life visits | must_have | unclear | none | discovery | CV is silent on end-of-life care | `[grounded]` CV silence | G1 |
| R10 | Care planning | important | unclear | none | discovery | CV is silent on care planning | `[grounded]` CV silence | G5 |
| R11 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: post-discharge patients aren't described as housebound, and district nursing isn't claimed | `[grounded]` CV; `[inferred]` adjacency | G3 |
| R12 | Own small caseload, supported by a senior community nurse | important | absent | none | capability | You've never held your own caseload. Support is built into the role | `[grounded]` your statement; `[grounded]` JD | G3 may show how independent the visits were; carried as a risk |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've never done one, and the JD lists it as desirable | `[grounded]` your statement and JD | closure path in G6; carried as a minor risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R9, must_have) | discovery | CV silent | A `must_have` duty at `unclear`; an answer could close it | Comfort or symptom care for dying patients on the ward; a rapid discharge home to die; supporting families | Anonymised reflective note, training record | `[grounded]` CV silence |
| G2 | Written records (R5, must_have) | discovery | No record system or recording duty named | An essential criterion the CV doesn't address | Entries after each home visit; ward electronic notes; audited documentation | A record template with no patient data; audit feedback | `[grounded]` CV silence |
| G3 | Home-based care (R11, must_have) | transferability | Post-discharge home visits for 18 months | The strongest bridge to the role; its limit decides how far to lean on it | Visiting alone; planning your own visit list; escalating to a GP or community team | Secondment description or service leaflet | `[grounded]` CV; `[inferred]` bridge |
| G4 | Leg-ulcer care (R6b, must_have) | transferability | Wound care without leg ulcers | The posting names leg-ulcer care first among its duties | Compression bandaging; assessing a venous leg wound on the ward or at home | Anonymised wound-care note, training record | `[grounded]` CV; `[inferred]` bridge |
| G5 | Continence care and care planning (R7b, R10) | discovery | CV silent on both | Both are duties; neither is essential | Bladder and bowel care plans; discharge care plans in the discharge-to-assess role | A care-plan template with no patient data | `[grounded]` CV silence |
| G6 | Doppler and own caseload (R13, R12) | capability | You've stated neither | A desirable criterion and a supported caseload | n/a: no credible evidence after looking | Closure path: ask whether Doppler training is provided on joining (RR5); carry both as risks | `[grounded]` your statement; `[inferred]` training available (RR5) |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's site | unknown | — | "Current vacancies are listed on our careers page" (About page) | The careers page may sit at another address or the post may be on a job board; it may also be closed, with no closing date in the advert | `[inferred]` from the failed fetch and the advert's silence on a date | Is this post still open, where is it listed, and what is the closing date? | unresolved |
| RR2 | Supervision is stated | positive_signal | — | "supported by a senior community nurse" | A first caseload is supervised, which reduces the R12 risk | `[grounded]` JD | Who supervises the caseload, and how often do you review it together? | noted |
| RR3 | Pay is stated and brackets the survey's middle range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | No mismatch with the pattern for this role family | `[grounded]` JD; `[generic]` survey band | Where on the range would an offer sit, and when is mileage paid given pool cars? | noted |
| RR4 | Rota, hours, contract basis and hub unstated | unknown | — | "district nursing team caring for housebound adults" | Visits may run beyond weekdays and the post may be fixed-term | `[generic]` pattern for community nursing roles, not a claim about this employer | What are the working pattern, weekend and evening rota, contract basis and base hub? | unresolved |
| RR5 | Doppler training may be available | positive_signal | — | "Desirable: Doppler assessment for leg ulcers" | The team lead has spoken on Doppler training for staff new to community work, so the R13 gap may be trainable | `[grounded]` speaker page; `[inferred]` that this team offers it | Is Doppler training offered on joining, and how soon? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the secondment to the top of the CV, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | see R11 | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | Put "Wound care (pressure ulcers, surgical wounds), catheter care, insulin administration" in a skills line near the top | see R6a, R7a, R8 | `[grounded]` CV | `resume_edits_pending_approval` |
| E3 | In the cover letter, say plainly you haven't yet done a Doppler assessment | see R13, RR5 | `[grounded]` your statement | `resume_edits_pending_approval` |
| Q1 | Ask the register questions of RR1 to RR5 in the informal chat with Rhiannon Mabbott, which the advert invites | register as interview preparation | `[grounded]` JD | pending your approval |
| A1 | Confirm the post is open before you invest in the application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Hold any claim on caseload, Doppler, leg-ulcer, continence, care-planning or end-of-life work until your answers confirm it | see R5, R6b, R7b, R9, R10, R12, R13 | `[grounded]` map | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Not used: the National Insurance number in your message, which isn't needed to evaluate a role.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 district nursing vacancy", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page. Role reality's organization row, and RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nursing Agenda for Change pay scale 2026/27 Doppler leg ulcer", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration, RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's hiring-lead row, RR5, Q1 |

I can build a full dossier file (`tuesday-dossier.md`) from this assessment if you want it.

**Upgrade menu**
- Your NMC register entry (public) takes R1 to `high`.
- A link to the live posting or the employer's careers page closes RR1.
- Answers to G1 to G3 move R9, R5 and R11, and may move the status to `go`.
- A record or care-plan template with no patient data raises R5 and R10.
- The hiring lead's answers on rota, contract and Doppler training close RR4 and RR5.
- Deeper research on Calderbrook (staff and leadership changes, public staff and candidate reports, recent news) would use up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

G1: Have you personally cared for patients in their last days or weeks, on the ward or through discharge-to-assess? What did you do, and where?

G2: Which record system did you use on the ward and on discharge-to-assess, and what did you personally write into it after each patient contact?

G3: On discharge-to-assess, did you visit patients on your own, and did you keep a list of patients you were responsible for between visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.