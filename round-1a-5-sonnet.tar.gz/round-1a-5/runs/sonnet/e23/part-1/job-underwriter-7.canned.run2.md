I'll read the reference files the skill points to before building the assessment.
Reading is done. Next I'll run the L1 research: three searches on Calderbrook, the Band 5 pay and the team lead.
**Is it worth applying? Yes, this one is. Status: `go`.**

I've read the advert against your CV and run the research. I haven't used your National Insurance number, because you don't need it to assess a role.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R6a, R7 · adjacent: R9 (Housebound adults in their own homes) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R8 (End-of-life visits), R10 (Small caseload of your own, care planning)
- `preferred` — absent: R11 (Doppler assessment for leg ulcers)

R4, R8 and R10 are unclear because the CV is silent or the question hasn't been asked yet. R11 is a named gap at the preferred tier.

**Opportunity ledger.** The role is sound, with unknowns rather than flags. The posting couldn't be confirmed on the employer's careers page (RR1), your pay placement within the range is open (RR2), and hours aren't stated (RR6). On the positive side, the advert names pool cars (RR3) and senior support (RR4), and your hiring contact has spoken publicly on Doppler training for new community staff (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** a vacancy that doesn't verify (RR1), a pay placement below your floor (RR2), or hours that don't suit you (RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs. | `[grounded]` "About Calderbrook Community Health" search result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` JD |
| Structure | A small caseload of your own, supported by a senior community nurse; pool cars and mileage | `[grounded]` JD |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. She spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` forum speaker page, public professional footprint only |
| Scope read | Doppler is only "desirable", and the team lead has spoken on training staff new to community work, so a candidate without it is not obviously out of scope | `[inferred]` from the JD's desirable tier plus the speaker page |
| Market calibration | The advert's £31,050–£37,800 spans the whole interquartile range (£32,400–£36,600) that one pay survey gives for community staff nurses at this band. The survey's median is £34,300 (n=1,240). That is a pattern for the role family, not this employer's offer. | `[generic]` Wardround 2026 pay guide; `[grounded]` JD for the advertised figure |
| Unknowns | Where the vacancy is listed and its closing date; pay placement; hours, weekend and on-call pattern; what Doppler training is offered | — |
| Contradictions | None found between the advert and the employer page. The posting itself couldn't be checked against a careers page (RR1). | `[grounded]` about page read; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. Nothing inspected, so medium. | `[grounded]` CV | Have the register entry to hand; it is the artifact that would raise this to high |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided, so no vehicle is needed. | `[grounded]` CV, JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is not a gate. | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | The CV is silent on records and on any electronic patient record system. Ward nursing plausibly involved records, but I won't assert it as your history. | `[grounded]` CV silence; `[generic]` that community roles lean on record-keeping | Question G2 |
| R5a | Wound care | important | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | The CV names pressure ulcers and surgical wounds, not leg ulcers or compression therapy. Nothing is confirmed either way. | `[grounded]` CV | Question G3 |
| R6a | Catheter care | important | direct | medium | none | CV: catheter care | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | The CV names catheter care only. | `[grounded]` CV | Carried; ask next turn if wanted |
| R7 | Insulin administration | important | direct | medium | none | CV: insulin administration. Care planning sits in R10. | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care. | `[grounded]` CV silence | Carried (G4) |
| R9 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | Eighteen months on the discharge-to-assess team, visiting patients at home in their first week after discharge, is real home-visiting experience. Limit: it is a short post-discharge window, not an ongoing district caseload of housebound patients. | `[grounded]` CV; `[inferred]` that the limit applies | Name the limit honestly in the application |
| R10 | A small caseload of your own, with care planning | important | unclear | low | discovery | You say you have never held your own caseload. Whether you planned your own visits or care plans on the discharge-to-assess team is unasked, so nothing is confirmed. | `[grounded]` your statement; CV silence on visit planning | Question G1 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. Closure path: ask whether the employer trains new starters. | `[grounded]` your statement | Ask in the informal chat (RR5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload and care planning (R10, important) | discovery | The discharge-to-assess secondment involved home visits. Who set your visit list, and who wrote or updated care plans, is unknown. | The advert gives you your own caseload from the start, so this is the closest bridge to the role's central duty. | Planning and prioritising your own daily visit list; writing or reviewing discharge or home care plans; deciding when to escalate to a GP or senior nurse | A rota or visit-list example (anonymised), a service description, a line in a reference | `[grounded]` CV and your statement; `[generic]` that this is the usual hinge for ward-to-community moves |
| G2 | Written records and the electronic patient record (R4, must_have) | discovery | No record-keeping detail in the CV | It is an essential requirement, and a CV that never mentions records leaves it unanswered. | Which electronic record system your ward and secondment used; same-visit or same-shift documentation; any records audit | A named system, an audit result | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5b, important) | discovery | Pressure ulcers and surgical wounds are named, leg ulcers are not | It is the first-named duty, and it is the gap Doppler would sit on | Applying compression or other bandaging to leg ulcers; leg-ulcer dressings and monitoring | A competency record or sign-off | `[grounded]` CV |
| G4 | End-of-life visits (R8, important) | discovery | The CV is silent on end-of-life care | It is a named duty. Unasked this turn to stay within the question budget. | Caring for dying patients on the ward; anticipatory medication; supporting families | A competency or training record | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not confirmed on the employer's careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The vacancy may be listed on another page or site, or my one guessed careers address was wrong | `[grounded]` the fetch of one address returned no page; `[inferred]` the cause | Where is this vacancy listed on your own site, and what is the closing date? | unresolved |
| RR2 | Pay placement within a wide range | unknown | — | "£31,050–£37,800 a year plus mileage" | A candidate with five years may be placed anywhere in the range | `[grounded]` JD figure; `[generic]` one survey's median and interquartile range sit inside it | Where in the range would an applicant with five years' post-registration experience be placed? | unresolved |
| RR3 | Pool cars provided | positive_signal | — | "pool cars are provided" | A car is not needed to take the post | `[grounded]` JD; `[generic]` in the same survey, under a quarter of respondents had a pool or lease car | Are pool cars allocated to you or booked per shift? | noted |
| RR4 | Named senior support and an offered chat | positive_signal | — | "supported by a senior community nurse… informal chat about the role" | New starters are supported and the team is open to questions | `[grounded]` JD | What does the support look like in the first weeks, such as joint visits or a caseload cap? | noted |
| RR5 | Doppler is desirable, and the hiring contact has spoken on training new community staff | positive_signal | — | "Desirable: Doppler assessment for leg ulcers" | The team may train new starters in Doppler | `[grounded]` JD and speaker page; `[inferred]` that training applies to this vacancy | Is Doppler training offered to new starters, and how soon after joining? | unresolved |
| RR6 | Hours and out-of-hours pattern unstated | unknown | — | "end-of-life visits" | Weekend or on-call work may sit behind end-of-life care | `[inferred]` from the duty list against the advert's silence on hours | What is the shift pattern, and is weekend or on-call work expected? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the secondment first in your experience, in your own wording: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | R9, the strongest bridge to home-based care | `[grounded]` CV sentence, unchanged | `resume_edits_pending_approval` |
| E2 | Keep wound care (pressure ulcers, surgical wounds), catheter care and insulin administration visible near the top, in your CV's own terms | R5a, R6a, R7 | `[grounded]` CV | `resume_edits_pending_approval` |
| A1 | Take up the informal chat with Rhiannon Mabbott. Say plainly that you have not held your own caseload or done a Doppler assessment, then ask about support and training. | R10, R11, RR4, RR5 | `[grounded]` JD offer; your statements | pending your approval |
| Q1 | Ask the register questions of RR1, RR2, RR5 and RR6 verbatim in the chat or interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. The CV claims are leads for verification, not proof. Not used: the National Insurance number, which isn't needed to assess a role. I didn't look up your NMC entry.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved role reality's organization row, and RR1 because the posting is unconfirmed. |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration line and RR2, RR3. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead" and fetched "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the hiring contact and scope rows, R11, RR5, and A1. |

I can save all this as a `tuesday-dossier.md` file if you'd like. It's optional.

## Upgrade menu

- Your NMC register entry, or signed competency records for wound care, catheterisation and insulin: R1, R5a, R6a and R7 could go to `high`.
- Answers to G1–G3: R10, R4 and R5b would firm up.
- A pay floor, preferred hours and travel limits: the hard-gates line could then check them, since it currently reads "candidate constraints not given".
- An earlier CV version: it may carry leg-ulcer or end-of-life evidence this one dropped.
- The vacancy's listing address and closing date: RR1 closes.
- A deeper research pass on Calderbrook (staff and candidate reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

1. **G1:** On the discharge-to-assess team, who decided your daily visit list and who wrote or updated the care plans? What did you own, and what did you hand to a senior? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G2:** Which electronic patient record system did your ward and the secondment use, and how soon after a visit or shift did you write up? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **G3:** Have you applied compression bandaging or managed leg ulcers, even occasionally? What did you do yourself, and was it signed off? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.