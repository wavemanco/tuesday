I'll read the reference files the skill requires before building the assessment.
**Yes, it's worth applying for. R1 and R2, the hard gates, are met, and R3 is `direct`. Status: `conditional_go`.** I'd confirm the post is still open first.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · adjacent: R5 (Care of housebound adults at home) · unclear: R4 (Clear, timely written records)
- `important`: direct: R6, R8, R9 · adjacent: R7 (Leg-ulcer care), R12 (Own small caseload) · unclear: R10 (Care planning), R11 (End-of-life visits)
- `preferred`: absent: R13 (Doppler assessment)

R12 and R7: adjacent, with limits named; R4, R10, R11: the CV is silent, which is different from absent; R13: absent, but a preferred item.

**Opportunity ledger.** The employer is established (RR2). The pay range brackets the survey median (RR4), and the first caseload comes with senior support (RR3). The post's live status (RR1) and the working pattern (RR5) are unconfirmed.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open (RR1); (2) your records and electronic-record experience is established for R4 (G1); (3) the first-caseload and Doppler gaps are stated plainly (R12, R13), never as caseload or Doppler experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` employer's About page |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, electronic records | `[grounded]` advert |
| Scope read | A first-caseload post: a "small caseload of your own" with a senior community nurse behind it, not an autonomous senior role | `[inferred]` from the advert's "supported by a senior community nurse" |
| Named contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, public professional footprint only |
| Market calibration | A community staff nurse (Band 5, England) survey: median basic pay £34,300, interquartile range £32,400–£36,600, 61% paid mileage, 24% with a pool or lease car (n=1,240). The advert's £31,050–£37,800 spans that range. This is a survey pattern, not this employer's offer | `[generic]` one survey; `[grounded]` the advert's figures |
| Unknowns | Hours, weekend and rota cover; the electronic record system; contract basis; closing date | `[grounded]` advert is silent on each |
| Contradictions | None found between the advert, the About page and the speaker page. The careers page could not be reached (see Evidence status) | `[grounded]` three pages compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), PIN given, active, revalidation due March 2028. Self-reported; the register entry is the inspectable artifact | `[grounded]` CV | none; the NMC register entry for your PIN would raise this to high |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided, so a car of your own isn't implied | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is graded on fit, not treated as a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV says nothing on record-keeping or any electronic patient record. Ward nursing involves records, but nothing in the CV evidences clarity or timeliness | `[grounded]` CV silence | G1 |
| R5 | Care of housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: a short post-discharge episode, not an ongoing housebound caseload | `[grounded]` CV; `[inferred]` that housebound ongoing care differs from a first-week visit | G4 |
| R6 | Wound care | important | direct | medium | none | CV lists wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | adjacent | medium | transferability | Wound care is evidenced, but leg ulcers are not named in the CV. Limit: nothing stated on leg-ulcer assessment or compression | `[grounded]` CV; `[inferred]` adjacency from the stated wound types | G5 |
| R8 | Catheter care (the advert pairs it with continence care) | important | direct | medium | none | CV states catheter care. Continence care is not stated, so only the catheter half is claimed | `[grounded]` CV | none |
| R9 | Insulin administration | important | direct | medium | none | CV states insulin administration | `[grounded]` CV | none |
| R10 | Care planning | important | unclear | low | discovery | CV is silent on writing or reviewing care plans, including in the discharge-to-assess secondment | `[grounded]` CV silence | G3 |
| R11 | End-of-life visits | important | unclear | low | discovery | CV is silent on palliative or end-of-life care | `[grounded]` CV silence | G2 |
| R12 | A small caseload of your own, with senior support | important | adjacent | medium | transferability | You've told me you have never held your own caseload. Adjacent work is the home visiting in R5. Limit: no own-caseload experience | `[grounded]` your statement and CV | G3 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've told me you've never done one. A preferred item, so a minor risk. Closure path: the named contact has spoken on Doppler training for staff new to community work, so the employer may train; ask rather than assume | `[grounded]` your statement; `[inferred]` training may be offered | ask about training (A2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clear, timely written records (R4, must_have) | discovery | No mention of records or an electronic record system | A must-have; evidence here could move the decision from `conditional_go` toward `go` | Documenting on an electronic patient record; discharge notes or handover summaries you wrote; audit feedback on your documentation | A sanitized audit result, a documentation competency sign-off, a reference line | `[grounded]` CV silence; `[inferred]` that this resolves a condition |
| G2 | End-of-life visits (R11, important) | discovery | CV does not mention palliative care | End-of-life visits are named in the advert's duties | Caring for dying patients on the ward; anticipatory medicines or a care-of-the-dying pathway; supporting families; a palliative-care study day | A training certificate or a reference line | `[grounded]` CV silence |
| G3 | Own visit list and care plans in the secondment (R10, R12) | discovery | Unclear who set the visit list or wrote the plans | Decides how close R12 and R10 sit to the post's first-caseload demands | Planning your own day's visits; deciding who to see first; writing or updating a patient's plan on your own judgment | A secondment job description or a reference line | `[grounded]` CV silence on ownership |
| G4 | Ongoing housebound care (R5, must_have) | transferability | First-week post-discharge visits only | R5 is a must_have at `adjacent`; the limit is the one an interviewer is most likely to raise | Repeat visits to the same patient; patients you handed to district nurses and what you learned from them | A secondment summary or a reference line | `[inferred]` bridge; `[generic]` that interviews probe this |
| G5 | Leg-ulcer care (R7, important) | transferability | Wound types named, leg ulcers not | Leg-ulcer care is a headline duty | Compression bandaging; ankle-brachial pressure index (ABPI) exposure; venous-ulcer patients on the ward | A competency record or a study-day certificate | `[inferred]` adjacency from stated wound types |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live on the employer's own site | unknown | — | "Current vacancies are listed on our careers page." (About page) | The vacancy may sit at a careers address I could not reach, on a job board, or may have closed | `[inferred]` from a failed fetch of a guessed address | Is this post open, and what is the closing date? | unresolved |
| RR2 | Employer exists as described | positive_signal | — | "adult community nursing... across Calderdale under an NHS contract" | The advert's employer is a real, operating service | `[grounded]` About page and speaker page both name it | Who would I be interviewed by? | noted |
| RR3 | Supported first caseload | positive_signal | — | "supported by a senior community nurse" | A caseload with named support suits someone who has not held one | `[inferred]` from the advert's wording | How is the caseload built up, and how long is the supported period? | noted |
| RR4 | Pay range stated and consistent with the survey | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range spans the survey's interquartile range; the starting point within it is unstated | `[generic]` survey pattern; `[grounded]` the advert's figures | Where in the range would five years' post-registration experience start? | unresolved |
| RR5 | Working pattern and mileage rules unstated | unknown | — | "pool cars are provided"; "plus mileage" | The advert does not say when pool cars are used, or whether mileage applies on a pool car; hours and weekend cover are not mentioned | `[grounded]` advert silence | What are the hours and weekend rota, and when is mileage paid? | unresolved |

## Application plan

Every row and every sentence in this section is a proposal, pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: move the home-visiting clause to the top, wording unchanged: "Visiting patients at home in their first week after discharge, 18 months seconded to a discharge-to-assess team; five years as a staff nurse on an acute medical ward at a district general hospital." Every clause traces to your sentence; nothing is added | R5, R12 | `[grounded]` your CV | resume_edits_pending_approval |
| E2 | In the application, say plainly that you have not held your own caseload and have not done a Doppler assessment | R12, R13 | `[grounded]` your statement | pending your approval |
| A1 | Take up the advert's invitation to an informal chat with Rhiannon Mabbott before applying; it also settles RR1 | RR1 | `[grounded]` advert | pending your approval |
| A2 | In that chat, ask about Doppler and leg-ulcer training for new staff, since she has spoken on it publicly | R7, R13 | `[inferred]` from her published talk topic | pending your approval |
| Q1 | Put RR1, RR3, RR4 and RR5's verification questions to her verbatim | The register doubles as preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed to evaluate a role, so I haven't used it; I'd keep it off anything you send until an employer asks.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 district nursing Halifax Calderbrook Community Health CIC vacancy"; both returned "About Calderbrook Community Health" (calderbrookhealth.example/about), which I fetched. A fetch of calderbrookhealth.example/careers, an address I guessed, returned no page. Moved: the organization row, RR1, RR2. The posting itself is not confirmed live |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change 2026/27 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration, RR4. Only the snippet was read, and no scope or title search ran |
| 3. Named contact's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the named-contact row, A2. Only the snippet was read |

I'm offering a Tuesday dossier (`tuesday-dossier.md`) that saves this assessment so you can build on it later, if you'd like one.

## Upgrade menu

- The NMC register entry for your PIN → R1 to `high`.
- A sanitized competency record, such as documentation, wound, catheter or insulin sign-offs → R4, R6, R8, R9 to `high`.
- A reference line or secondment job description → G3 and G4 close, and R5 and R12 firm up.
- The recruiter's answer on hours, closing date and mileage → RR1 and RR5 close.
- A deeper research pass on Calderbrook (public staff and patient reports, recent news, contract changes; up to 5 more searches and 2 more fetches) — say the word and it runs.
- Offer, beyond this assessment: a one-page set of honest answers to "tell me about your first-caseload readiness", built from your replies below. It would suit this post because R12 and R13 are the gaps an interview would probe. I'll only build it if you approve.

## Questions

G1 — Have you written or maintained patient records on an electronic system, and has anyone ever commented on your documentation, through an audit, a sign-off or feedback?

G2 — Have you cared for patients at the end of life on the ward or in the secondment, and what was your part?

G3 and G4 — In the secondment, did you plan your own visit list and write or update care plans, and did you see any patient more than once?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.