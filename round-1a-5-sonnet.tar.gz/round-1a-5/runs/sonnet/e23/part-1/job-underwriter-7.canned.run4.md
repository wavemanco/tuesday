I'm reading the skill's remaining rules, on the decision format and research accounting, before I write the assessment.
## Decision snapshot

**Yes, this is worth applying for: `go`.** R1 and R2 (both hard gates) are `direct` on your own account, and so is the must-have R3. The thin spots are R4, R7b, R8, R9b, R10 and R11. None of those is a gate.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (clear, timely written records)
- `important` — direct: R6a, R7a, R9a · adjacent: R5 (care of housebound adults at home), R6b (leg-ulcer care), R10 (small caseload of your own) · unclear: R7b (continence care), R8 (end-of-life visits), R9b (care planning)
- `preferred` — absent: R11 (Doppler assessment)

R3, R6a, R7a, R9a — your ward and discharge-to-assess work carries these; R5, R6b, R10 — bridges with limits named; R4, R7b, R8, R9b — the CV is silent; R11 — the Doppler gap you named, and the advert lists it as desirable only.

**Opportunity ledger.** The role looks sound. The caseload is small and supported (RR2), the salary is stated and sits within the survey range (RR3), and the team lead has a public record of Doppler training for newcomers (RR6). Still unconfirmed are whether the vacancy is live (RR1), how the pool-car and mileage arrangement works (RR4) and the hours and rota (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a `no_go` would need R1 or R2 to fail on checking (a lapsed registration or a licence restriction), or RR1 to show the vacancy closed. Hours or a rota you can't work, learned at RR5, would also change it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, which runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract, with 410 staff in four locality hubs | `[grounded]` "About Calderbrook Community Health" page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Travel | Pool cars provided, plus mileage; which applies when is not stated | `[grounded]` JD |
| Scope read | A broad, ordinary district nursing post for a new community nurse, with a supervised caseload and no management duties | `[inferred]` from the JD's task list and its "supported by a senior" wording |
| Market calibration | £31,050–£37,800 sits around the middle of a community staff nurse Band 5 survey (median £34,300, interquartile range £32,400–£36,600, England, n=1,240). The posting's figure is the employer's; the survey is only the norm | `[grounded]` JD for the range; `[generic]` Wardround 2026 pay guide for the norm |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. She has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, not an employer page |
| Unknowns | Whether the vacancy is live and its closing date; hours and rota; which EPR system; pool car versus own car; the training offered | `[grounded]` JD silence |
| Contradictions | None between the JD and the about page on service, place or employer type. The careers page could not be read, so the listing was not cross-checked | `[grounded]` about page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV gives registration as an Adult Nurse, a PIN, active status and revalidation due March 2028. Nothing inspected yet, so `medium` | `[grounded]` CV | NMC register entry would raise to high; see upgrade menu |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided, so a car of your own is not required on the posting's wording | `[grounded]` CV and JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a ward staff nurse on an acute medical ward; the CV does not state the dates | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | none | discovery | The CV says nothing about documentation or record systems. Ward nursing normally involves heavy documentation, but that is a pattern, not your evidence | `[grounded]` CV silence; `[generic]` ward documentation norm | G3 |
| R5 | Care of housebound adults in their own homes | important | adjacent | medium | transferability | Eighteen months in a discharge-to-assess team visiting patients at home in their first week after discharge. Limit: first-week post-discharge visits, not an ongoing housebound caseload | `[grounded]` CV | G2 |
| R6a | Wound care | important | direct | medium | none | CV names wound care, including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6b | Leg-ulcer care | important | adjacent | low | transferability | Pressure-ulcer and surgical wound experience carries over, but the CV shows nothing on leg ulcers or compression therapy. Closure is a conversation with the employer about training | `[grounded]` CV; `[inferred]` bridge from the wound-care claim | G4 |
| R7a | Catheter care | important | direct | medium | none | CV names catheter care | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | none | discovery | The CV does not mention continence care beyond catheters | `[grounded]` CV silence | G1 |
| R8 | End-of-life visits | important | unclear | none | discovery | The CV does not mention end-of-life care. An acute medical ward may well have given you some, but the CV doesn't say | `[grounded]` CV silence; `[generic]` acute medical ward pattern | G1 |
| R9a | Insulin administration | important | direct | medium | none | CV names insulin administration | `[grounded]` CV | none |
| R9b | Care planning | important | unclear | none | discovery | The CV does not mention care planning | `[grounded]` CV silence | G1 |
| R10 | A small caseload of your own, supported by a senior community nurse | important | adjacent | low | transferability | You have told me you have never held your own caseload. The nearest evidence is home visits in the discharge-to-assess team. Limit: unknown how much you decided alone. The support offered is built for newcomers to caseload work | `[grounded]` your statement and CV; `[inferred]` fit of the support to a first caseload | G2 |
| R11 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have confirmed you have never done one. The advert marks it desirable, not essential | `[grounded]` your statement and JD | Ask about training in the informal chat |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life, continence and care planning (R8, R7b, R9b, all important) | discovery | The CV names wound, catheter and insulin work and nothing on these three areas | They are three of the posting's listed day-to-day tasks, and a short answer could move all three rows | Anticipatory medicines or last-days care on the ward; supporting a family at end of life; bladder and bowel care or continence assessments; writing or updating a care plan on discharge | Competency sign-offs, a discharge care plan template you used, or a reference | `[grounded]` CV silence; `[generic]` that community posts of this kind probe these areas |
| G2 | Working alone and owning decisions (R5, R10, both important) | transferability | Eighteen months of home visits in discharge-to-assess; no caseload of your own | The role gives you a caseload early, so how independently you already worked is the nearest evidence | Visiting alone and deciding when to escalate; managing your own daily visit list; handing over to district nurses or GPs | Your secondment job description, a rota extract, or a reference from its lead | `[grounded]` CV and your statement; `[inferred]` that this is the nearest bridge |
| G3 | Written records (R4, must_have) | discovery | The CV is silent on record-keeping and on electronic patient records | It is the one must-have row not at `direct` | Using an electronic patient record daily; discharge summaries; a documentation audit result or a record-keeping competency | An audit summary, a reference mentioning your records, or the system's name | `[grounded]` CV silence |
| G4 | Leg ulcers and Doppler (R6b, R11) | capability | Nothing on leg-ulcer care or Doppler | R11 is desirable only; R6b is important | Applying compression bandaging; attending a leg-ulcer study day or training | A training certificate, if any | `[grounded]` CV silence and your statement. The closure path is a training conversation with the hiring contact, not a claim on your application |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting liveness and closing date unconfirmed | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer exists as described and lists vacancies, but the careers page could not be read from here, so the live listing is unseen | `[grounded]` about page says vacancies are on a careers page; careers fetch returned no page | Is this vacancy still open, and what is the closing date? | unresolved |
| RR2 | A supervised small caseload | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | The post is built to take someone new to caseload work and has named support | `[inferred]` from the JD's wording | How is the support structured: supervision frequency, shadowing, how the caseload builds? | noted |
| RR3 | Salary stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is open and in line with the norm in role reality | `[grounded]` JD; `[generic]` survey for the norm | Where in the range would my experience be placed? | noted |
| RR4 | Pool car and mileage both mentioned | unknown | — | "pool cars are provided"; "plus mileage" | Mileage may apply to personal-car use outside the pool or to pool-car trips, and availability at shift start is unstated | `[inferred]` from the JD's two statements | When is a pool car used and when is mileage paid? | unresolved |
| RR5 | Hours, rota and lone working unstated | unknown | — | "caring for housebound adults in their own homes" | A community role may include weekends or lone visits, but the posting gives no pattern | `[generic]` pattern for community nursing posts; `[grounded]` JD silence | What are the working hours, weekend or on-call expectations, and lone-working arrangements? | unresolved |
| RR6 | A hiring contact with relevant public expertise | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | Someone who has publicly spoken on Doppler training for newcomers may value willingness to train over existing skill | `[grounded]` speaker page; `[inferred]` that she cares about training for newcomers | What leg-ulcer and Doppler training would I get, and how soon after starting? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott before applying. Ask the RR1, RR4, RR5 and RR6 questions | The posting invites it, and it answers the unknowns | `[grounded]` JD | pending your approval |
| E1 | Make the discharge-to-assess home visits the lead of the CV, in the posting's own terms (home visits, wound care, catheter care, insulin) | See R5, R6a, R7a, R9a | `[grounded]` CV | pending your approval |
| E2 | Add record-keeping and caseload wording only once G3 and G2 are confirmed | Not yet evidenced; see R4, R10 | `[grounded]` R4 and R10 rows | pending your approval |
| A2 | Do not claim a caseload of your own, leg-ulcer experience, or Doppler skills. State plainly that you have not done Doppler assessment and ask about training | R10, R6b and R11 are not evidenced | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Your CV and your statements are self-reported leads until you confirm specifics or share an inspectable item. Your National Insurance number isn't needed to assess a role, and I haven't used it. Share it only on a formal job offer or onboarding form.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. It moved the organization row, and it left RR1 open because the live listing is unseen |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026/27 community staff nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the hiring contact row, RR6 and A1 |

I can also write this up as a `tuesday-dossier.md` file you can keep, if you'd like one.

## Upgrade menu

- The NMC online register entry for your PIN, or a screenshot of it, would take R1 to `high`.
- A copy of your discharge-to-assess secondment job description, or a reference from its lead, would strengthen R5 and R10.
- Competency sign-offs for wound, catheter and insulin work would take R6a, R7a and R9a toward `high`.
- A link to the live posting on Calderbrook's careers page, with its closing date, would close RR1.
- Answers to G1, G2 and G3 would move rows R8, R7b, R9b, R5, R10 and R4.
- A deeper research pass on Calderbrook (staff reports, leadership changes, recent news) can run on request, using up to 5 more searches and 2 more fetches.

**G1** — On the ward or in the discharge team, did you personally give end-of-life care, continence care or write care plans? Give me one example of each that applies, saying what part was yours.

**G2** — In the discharge-to-assess visits, did you work alone, keep your own visit list and decide when to escalate? Who did you hand over to?

**G3** — Which electronic record system did you use, and has anyone audited or commented on your documentation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.