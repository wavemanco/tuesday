## Decision snapshot

**Decision: `no_go`. Don't go ahead, and don't send anything.**

- **Opportunity ledger:** This matches the standard fake-job and cheque-overpayment scam. Several red flags are decisive on their own, and I found no positive signals that offset them.
- **Fit ledger (you against the stated requirements):** You're a strong match on paper: attention to detail, spreadsheets and written English. That strength doesn't make the role real. Scammers write postings like this to attract people with your background.
- **Hard gates:** Pay is the only one, and it's unverified. Your floor is €30,000 a year. At €26 an hour and 15–30 hours a week, "up to" pay works out to roughly €20,300–€40,600 a year if you work all 52 weeks [inferred, my arithmetic from the posting]. You'd reach €30,000 only at about 22 hours a week or more at the top rate. The role is moot anyway.

## Do these now

1. **Don't send your IBAN, PPS number or passport photo.** Together they're enough for identity theft and for opening accounts in your name. A real payroll team collects these only after a signed contract, through an HR system, not in a Telegram chat. Don't paste the IBAN anywhere else either.
2. **Don't pay the €349.** A real employer never asks you to pay for equipment, and it will never be "refunded".
3. **Don't lodge the cheque, and don't transfer anything from it.** This is the core of the scam. The cheque will look as though it has cleared, and your bank may credit the money within days. It can still bounce weeks later, and the bank will take the full €2,850 back from you. The €2,500 you'd have sent to the "equipment partner" is already gone by then. If a cheque turns up in the post, don't lodge it.
4. **Stop replying.** Block @VellowayHiring and keep the chat. Screenshots of the Telegram thread are your evidence.
5. **Report it:** to the jobs site where you found the posting, to Telegram (report the account), and to An Garda Síochána. If you've shared anything beyond what you've told me, tell your bank straight away. Your bank's fraud team can also tell you whether anything else needs doing.

## Role reality

| Item | Finding | Provenance |
|---|---|---|
| Role | "Order Processing Coordinator", remote, flexible hours, "up to €26/hr plus commission" | [grounded] posting |
| Employer | Velloway Logistics: no website, address, registration or named person given, only a Telegram handle | [grounded] posting |
| Pay | €26/hr is high for no-experience remote data entry. The "plus commission" is vague. | [inferred] |
| Process | Hiring runs entirely on Telegram, with no calls or video. A "passed interview" came after a chat, with no assessment of your skills. | [grounded] messages |
| Contact | Replies come from a Telegram handle, and "HR" is a `postmail.example` address, not a company domain. | [grounded] messages |
| Market calibration | Genuine order-processing and customer-support jobs in Ireland are run by named employers through company email and video interviews, and they pay for equipment. | [generic] |

## Evidence map

| # | Priority | Requirement / claim | Fit | Evidence | Confidence |
|---|---|---|---|---|---|
| 1 | must-have | Attention to detail | strong | Daily 60-ticket queue in Zendesk | medium (self-reported) |
| 2 | must-have | Spreadsheets | strong | Team's weekly tracker in Excel | medium |
| 3 | must-have | Written English | strong | Customer-facing written support | medium |
| 4 | must-have | Quiet workspace | unknown | Not yet stated | low |
| 5 | hard gate | Your €30,000 floor | **at risk** | €20.3k–€40.6k range, hours-dependent and unverifiable | low |
| 6 | implied | "Standard kit": pay €349, deposit cheque, forward funds | **fail** | These are payments by you, not job duties. No legitimate role asks for them. | high |

## Gap recovery queue

| Gap | Type | What closes it |
|---|---|---|
| Velloway's identity can't be verified | discovery | A registered address, company number and an email on the company's own domain. Everything else points the other way, so I'd treat this as closed. |
| Your quiet workspace | presentation | Moot. |

No CV changes are proposed, and nothing here needs your approval.

## Opportunity risk register

| Class | Severity | Signal | Provenance |
|---|---|---|---|
| Red flag | critical | The job is "yours" with no real interview | [grounded] |
| Red flag | critical | Passport, IBAN and PPS requested before any contract | [grounded] |
| Red flag | critical | You're asked to pay €349 up front for equipment, with a promised refund | [grounded] |
| Red flag | critical | Cheque for €2,850, keep €350, send the rest on (classic overpayment fraud) | [grounded] |
| Red flag | high | Telegram-only process, a placeholder-style email domain, no named people | [grounded] |
| Red flag | medium | Very high pay for no experience, "plus commission" | [inferred] |
| Positive signal | none | | |

Failed attribution: I can't tie "Velloway Logistics" to any verifiable entity from what you've given me [inferred]. That counts against the employer. It isn't evidence that the real Velloway, if one exists, is behind this. Scammers often borrow company names.

## Application plan

I'd withdraw rather than apply. For a real search, your background (courier customer service, Zendesk, training new starters, Excel tracking) fits customer support, logistics operations and order-processing roles at named employers. Roles like that can plausibly reach €30,000 or more in Ireland [generic]. Use roles where you can confirm the employer exists and where interviews run by video or phone.

## Evidence status

Research tier: L0 — no searches; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | The red flags in your messages decide this. A search can't make a cheque-for-transfer request safe. |
| 2 | Role-family pay sweep | skipped | Not needed for the decision. The market calibration above is labeled [generic]. |
| 3 | Hiring manager's public footprint | n/a | No named person was given. |

I can run L1 research on "Velloway Logistics" if you want to confirm there's no real company behind this. It wouldn't change the decision.

If you'd like, I can write up `tuesday-dossier.md` with this assessment, so you have a record to hand to the Gardaí or your bank.

**Upgrade menu**
- A link to the original posting would let me check whether it's still live and whether other candidates have flagged it.
- A copy of the cheque's front, with account numbers hidden, or the envelope would help your bank to trace it.
- Your job criteria beyond pay would let me screen real roles against them.

**Questions**
1. (Row 5) Besides the IBAN, did you send any other personal details to this account, or did anything already arrive in the post?
2. (Row 4) Would you like me to help you screen a few real listings against your €30,000 floor?
3. Do you want a short, polite message to send to the jobs site reporting this posting?

You can answer briefly, say "skip", or ignore any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.