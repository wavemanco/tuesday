Searches for the company came back empty, so I've finished checking. Here is the assessment.

# Underwriting: "Remote Order Processing Coordinator", Velloway Logistics

## Decision snapshot

**No. This looks like a scam, and you shouldn't go ahead. Status: `no_go`.** The reason is in the register: RR1, RR2, RR3 and RR4 all fire.

**Fit ledger.**

- `hard_gate`: unclear: R1 (income of at least €30,000 a year)
- `must_have`: direct: R2, R3
- `important`: adjacent: R4 (order processing); unclear: R5 (quiet place to work)

R1 can't be confirmed on the posting's wording. Your fit for the duties is fine, but a real fit doesn't make a fake offer worth taking.

**Opportunity ledger.** The employer isn't established (RR4). The messages match the standard fake-cheque and identity-harvesting pattern: ID and bank details up front (RR3), a fee to pay (RR2), and a cheque to lodge with the surplus sent on (RR1). The contact details are also off-domain (RR5).

- **Hard gates:** none failed (the posting's terms never contradict R1 outright); unconfirmed: R1 (income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a verifiable company with its own domain, a live video or phone interview, and no payment or ID requests before a signed contract. Nothing in the chat so far meets any of those.

**Do this now:**

1. **Don't send anything.** Not the IBAN, PPS number, passport photo or €349.
2. **Don't lodge the cheque if it arrives.** Cheques like this can look cleared, then bounce days or weeks later. You'd owe the bank the full amount, including the money you sent on.
3. **Stop replying and block the account.** Report it to the jobs site, to Telegram, and to An Garda Síochána if you want it on record. If you ever sent a passport photo or PPS number anywhere, tell your bank and check the relevant Irish identity-fraud guidance.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: no attributable web presence found | `[grounded]` search returned no results; employer not established |
| Mandate | Process orders remotely, 15–30 hours a week, "no experience needed" | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission", commission terms unstated. At 15 hours and €26 that is about €20,280 a year; €30,000 would take about 22 hours a week at the top rate | `[grounded]` posting figures, `[inferred]` arithmetic |
| Process | Telegram only, "no calls or video interviews", ID and bank details requested before any interview | `[grounded]` posting and messages |
| Contact | Hiring email is `velloway.hr@postmail.example`, not a company domain | `[grounded]` message |
| Market calibration | Not run (target 2 skipped); the decision doesn't depend on it | — |
| Unknowns | Who the employer is, who the "equipment partner" is, any contract | — |
| Contradictions | The interview was "passed" after answering questions in a chat, with no assessment of your answers described. The "refund" and "welcome bonus" both rest on a cheque you'd deposit | `[grounded]` messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | low | hard_gate | The posting gives "up to" rates, variable hours and unstated commission, so €30k isn't assured. The constraint is yours | `[grounded]` posting and your statement | none; moot given RR1–RR4 |
| R2 | Attention to detail, confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. This is your own statement, with no artifact seen | `[grounded]` your statement | none |
| R3 | Good written English | must_have | direct | medium | none | About 60 written Zendesk tickets a day for three years | `[grounded]` your statement | none |
| R4 | Order processing, "no experience needed" | important | adjacent | medium | transferability | Parcel-courier ticket handling is close to order handling, but you haven't described order-entry work | `[inferred]` from your background | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` not stated | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Income of at least €30,000 (R1) | hard_gate | The posting's maximum doesn't reliably reach your floor | You'd be taking on risk for pay that may never reach €30k | Not applicable to this posting | A written contract stating hours and rate (not offered) | `[grounded]` posting arithmetic |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque to lodge, keep a bonus, send the rest on | red_flag | high | "We are posting you a cheque for €2,850… keep €350… transfer the rest" | A counterfeit or fraudulent cheque is credited provisionally, then reversed; you'd be left owing the money you sent | `[generic]` well-documented fake-cheque pattern | Why would a company overpay a new hire and ask for a refund to a third party? | unresolved |
| RR2 | Fee demanded before work | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | An upfront payment is the scam's direct take | `[generic]` advance-fee pattern | Would a real employer ask a new hire to pay for equipment? | unresolved |
| RR3 | ID and bank details requested before an interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | These enable identity fraud and use of your account for laundering | `[generic]` pattern | Would real payroll need these before an offer? | unresolved |
| RR4 | Employer not established, Telegram-only process | red_flag | high | "Our whole hiring process runs on Telegram" | The company may not exist, or isn't what it claims | `[grounded]` no results; `[generic]` that real employers use contracts and company email | Is there a company registration, website and video interview? | unresolved |
| RR5 | Off-domain contact | risk_signal | medium | "velloway.hr@postmail.example" | A free or generic email rather than a company domain | `[inferred]` from the address | Does the email match a real company domain? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply further; stop contact and report it | see RR1–RR4 | `[grounded]` register | pending your approval |
| A2 | Look for real support-operations, order-processing or logistics-coordinator roles, led by your Zendesk volume, your two trainees and your Excel tracker | see R2–R4. These claims are yours, unverified, and I'd phrase them exactly that way | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and got no results. This moved role reality's Organization row and RR4: employer not established |
| 2. Role-family sweep | skipped | The decision doesn't depend on a pay band, since the red flags decide it |
| 3. Hiring manager's footprint | n/a | No name was given |
| Outside the declared targets | yes | Searched "remote job Telegram cheque overpayment equipment fee passport PPS number scam Ireland" and got no results, so it moved nothing |

## Upgrade menu

- The job site's name or a link to the live posting would let me check whether it's still listed.
- A deeper company check (up to 5 more searches and 2 more fetches) is available, but it's unlikely to change the call.

If you'd like a record of this, I can write it up as a `tuesday-dossier.md`.

Questions:

1. (RR3) Have you sent anything to this contact, such as documents, photos or money, in any chat or email?
2. (RR4) Which jobs site was the posting on?
3. (A2) Would you like help finding real roles around €30k+, and in which area or commute range?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.