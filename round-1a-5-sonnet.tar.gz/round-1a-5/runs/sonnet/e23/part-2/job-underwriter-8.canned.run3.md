**No. Don't send your IBAN, PPS number or passport photo, and don't pay anything. This follows the standard fake-job scam pattern, and the cheque step is a known fake-cheque fraud (RR1, RR2 and RR3 are all `severity: high`). Status: `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year)
- `must_have`: direct: R3, R4 · adjacent: R2 (Strong attention to detail)
- `important`: unclear: R5 (A quiet place to work)

The fit rows don't matter much here: R2, R3 and R4 show you could do the work, but the role itself isn't credible (RR1, RR2, RR3); R1 can't be met as posted, since the pay is "up to" and the hours float.

**Opportunity ledger.** The employer isn't established (RR6). It asks for payment (RR1), runs a cheque-and-transfer scheme (RR2), and collects identity documents before any interview (RR3). Its contact details and process also look wrong (RR4, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR6 (`severity: high`).
- **What would change this:** only verifiable facts, such as the role on a real company's own careers site and a hiring contact on a company email domain. Even then, RR1 and RR2 would need to disappear, because a real employer doesn't ask for them.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no address, size, or product given; hiring only via a Telegram handle | `[grounded]` posting and messages |
| Mandate | Order processing, 15–30 hours a week, flexible hours | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission". At 15–30 hours that is about €20,300–€40,600 a year at the ceiling. You'd need roughly 22 hours a week at the full €26 to reach €30,000 | `[inferred]` arithmetic on the posting's ceiling |
| Process | No calls or video, "interview" by chat, job offered after answering questions | `[grounded]` messages |
| Market calibration | Not run (no research). Real order-processing jobs normally have a named employer, a contract, and an interview you can verify, and the employer buys the equipment | `[generic]` pattern, not a finding about this firm |
| Unknowns | Whether Velloway exists, who runs it, what the "commission" is, who the "equipment partner" is | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | medium | hard_gate | The posting gives only a ceiling and variable hours, so €30,000 isn't promised. Confidence grades your stated constraint | `[grounded]` your constraint; `[inferred]` arithmetic | none; moot given RR1–RR3 |
| R2 | Strong attention to detail | must_have | adjacent | medium | discovery | About 60 Zendesk tickets a day and training two starters suggest accuracy, but you've given no error-rate or quality evidence | `[grounded]` your account; `[inferred]` adjacency | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; this is self-reported, with no artifact seen | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | high | none | Your messages in this chat show it, and ticket work is written support | `[grounded]` this conversation | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Not stated by you | `[grounded]` silence | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay vs. €30,000 (R1) | hard_gate | Ceiling only, hours variable | A real offer would state a base rate and a minimum | None; this is the employer's to state | A written offer from a verifiable employer | `[grounded]` posting |
| G2 | Detail evidence (R2) | discovery | Volume and training, no accuracy metric | Matters for real roles, not this one | Ticket QA scores, resolution accuracy | Any QA or CSAT figures | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Candidate pays for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it" | Advance-fee scam: you pay, the refund never comes. Legitimate employers supply equipment or reimburse through payroll | `[generic]` well-known pattern | Why can't Velloway ship the equipment or pay it through payroll after I start? | unresolved |
| RR2 | Cheque, keep a bonus, forward the rest | red_flag | high | "posting you a cheque for €2,850... keep €350... transfer the rest to our equipment partner" | Fake-cheque scheme: the cheque is later returned as invalid or recalled, and the money you forwarded is yours to repay. Banks may show funds before a cheque has cleared | `[generic]` well-known pattern | Why would an employer send me a cheque and ask me to forward most of it to a third party? | unresolved |
| RR3 | IBAN, PPS number and passport requested before any real interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | Identity-data harvesting. A real employer needs these only after a signed offer, and certainly not over Telegram | `[generic]` pattern | Which company entity employs me, and can I send documents through its HR system after signing a contract? | unresolved |
| RR4 | Telegram-only process, no calls or video | risk_signal | medium | "no calls or video interviews" | Avoids verifiable identity and leaves little trail | `[generic]` | Who is the named hiring manager, and can I have a video call? | unresolved |
| RR5 | HR contact on a generic mail domain; "interview" is a chat | risk_signal | medium | "velloway.hr@postmail.example" | A real company would normally use its own domain. Treat the address as unverified; I haven't checked it | `[inferred]` from the address | Can you write to me from a company domain that matches your website? | unresolved |
| RR6 | Employer not established | risk_signal | high | "Velloway Logistics"; no address or registration details given | May not exist as described. Severity is high because it comes with payment demands, ID requests and an off-domain contact | `[generic]` pattern; no search run | Where is Velloway registered, and can I see the role on your own careers site? | unresolved |
| RR7 | "Passed" with no assessment; "earn up to €26 plus commission, no experience" | risk_signal | medium | "you passed the interview and the job is yours" | High pay for no experience, with a fast offer, is a common lure | `[generic]` | What did the interview assess, and who decided? | unresolved |

## Application plan

Don't apply. Protective steps `[generic]`:

- Send nothing: no IBAN, no PPS number, no passport photo. The IBAN is the least sensitive of the three, but there's no reason to send it either.
- Pay nothing, and don't lodge or forward any cheque if one arrives.
- Stop replying. Block the handle, and keep screenshots of the messages.
- Report the posting to the jobs site, report the Telegram account in the app, and consider telling An Garda Síochána.
- If you've already shared anything beyond what you've told me, contact your bank's fraud team now.

Your real profile is credible for customer-service-operations and order-handling roles at couriers and logistics firms, where you can verify the employer. I haven't searched for any, so I'm not making a claim about pay or openings at your €30,000 floor.

## Evidence status

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Official site and careers page | skipped | You haven't consented to research yet; this is the first search I'd run |
| 2 | Role-family sweep | skipped | Not run; the market calibration above is `[generic]` |
| 3 | Hiring manager footprint | n/a | No name was given, only a Telegram handle |

I'm offering to build `tuesday-dossier.md`, a saved record of this assessment, if you'd like one. It would be most useful if you plan to report the posting.

**Upgrade menu.**

- Research would show whether Velloway exists as described.
- An email header or the cheque's issuer details would show where the mail really comes from.
- Your CV would let me map your real fit to better-matched roles.

**Questions.**

1. (RR3) Have you already sent them anything beyond answering interview questions, such as documents, an address for the cheque, or a payment?
2. (RR6) Shall I run up to 5 searches and 2 page fetches to see whether Velloway exists and whether the posting is genuine?
3. (G1) Would you like me to look for better-matched, verifiable roles at your €30,000 floor once that's done?

Reply in a few words, say "skip" to pass on any of them, or ask me to take it further.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.