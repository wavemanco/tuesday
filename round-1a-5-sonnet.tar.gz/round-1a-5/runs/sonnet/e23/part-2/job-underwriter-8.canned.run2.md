**No, don't go ahead, and don't send anything: not the IBAN, the PPS number, the passport photo or any money.** `no_go`. This is a fake-cheque / advance-fee scam with an identity-theft step added. It isn't a weak employer. I haven't searched the web, so this rests on the messages and posting you pasted, plus well-known scam patterns.

## Decision snapshot

**Not worth applying to. Two severe red flags, RR1 and RR2, are the classic payment-for-job and fake-cheque patterns. Status: `no_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R1 (Earn at least €30,000 a year)
- `must_have`: direct: R2, R3, R4
- `important`: unclear: R5 (Quiet place to work)

R2–R4 (`medium`) rest on your own account with no document read.

**Opportunity ledger.** The role is fake on its own terms, whatever your fit. It asks for identity documents before an interview (RR1), asks you to pay for equipment (RR2), and sends a cheque for you to forward on (RR3). Hiring happens only on Telegram (RR4), and the posting's pay is too low and vague (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Earn at least €30,000 a year).
- **Severe red flags:** RR1, RR2, RR3.
- **Conditions for go:** none. No reply from this account could change the status.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no website, address, company number or named person given; contact is a Telegram handle and an HR email on a generic `postmail` domain, not a company domain | `[grounded]` the posting and messages you pasted |
| Role | Order Processing Coordinator, "no experience needed", own hours, 15–30 hrs/week | `[grounded]` posting |
| Pay | "Up to €26/hr" plus unspecified commission. At €26 you'd need about 22 hrs/week to reach €30k a year. At 15 hrs/week the maximum is about €20k | `[grounded]` posting figures; arithmetic is mine |
| Scope read | Real order-processing roles are employee or contractor posts with a named employer, a video or phone interview and a signed contract. Hiring that is Telegram-only, with an instant "pass", is not how those run | `[generic]` role-family pattern |
| Contradictions | The posting asks for "strong attention to detail" and a "first screening", but you were passed with no questions about your work | `[grounded]` your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Earn ≥ €30,000/year (your constraint) | hard_gate | unclear | high | hard_gate | The constraint is yours. The posting gives only "up to €26/hr" and a 15–30 hr range, so the ceiling clears €30k only at the top rate with about 22+ hrs/week. Moot given RR1–RR3 | `[grounded]` your constraint; posting terms | none |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day for three years, and you trained two starters | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; no sample seen | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling daily | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` silence | none |

You're qualified for real versions of this work. That is how the scam works: the posting is built to match people like you.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay vs €30k floor (R1) | hard_gate | Pay is a ceiling, not an offer | Real roles must state base pay | Your 3 years of courier support, plus ticket volume and tracker ownership | A real posting with a stated salary | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Identity documents requested before any interview | red_flag | severe | "send your IBAN, your PPS number and a clear photo of your passport" | Collecting what's needed for identity fraud or opening accounts in your name. Genuine employers ask for PPS and bank details only after a signed offer, through an HR system | `[generic]` standard hiring and fraud pattern | Would they accept these only after a contract signed with a verifiable company? (Expect a refusal or deflection.) | resolved by your decision not to send |
| RR2 | Employee told to pay for equipment | red_flag | severe | "Please pay €349 ... to our equipment partner and we will refund it" | Advance-fee scam. The "refund" never comes | `[generic]` advance-fee pattern | Would they ship the laptop directly or deduct from wages? (Real employers supply equipment.) | unresolved |
| RR3 | Cheque sent, you forward the balance | red_flag | severe | "cheque for €2,850 ... keep €350 ... transfer the rest" | Overpayment/fake-cheque scam. The cheque is forged or fraudulent and bounces days or weeks after it looks cleared. The bank claws it back and the money you sent is gone, so you owe the loss. It may also use your account to move stolen money | `[generic]` fake-cheque pattern | none worth asking | unresolved |
| RR4 | Telegram-only hiring, instant "pass", no calls or video | red_flag | high | "no calls or video interviews" | Designed to avoid being identified or recorded | `[generic]` | Would they do a video call with a named person? | unresolved |
| RR5 | Vague employer and pay | unknown | — | "up to €26 an hour plus commission" | Bait pay with no verifiable company behind it | `[inferred]` from the missing company details | What is the registered company number? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing further. Don't lodge the cheque, don't pay the €349, don't reply to velloway.hr@postmail.example | RR1–RR3 | `[grounded]` register | pending your decision |
| A2 | Block and report the Telegram account and the posting on the jobs site | Protects other applicants | `[generic]` | pending your decision |
| A3 | Report it to Gardaí and tell your bank. If the cheque arrives, don't lodge it | Cheque fraud is a crime and banks log it. If you ever lodged a cheque and sent money, call the bank at once | `[generic]` | pending your decision |
| A4 | Aim at real roles: customer operations, order processing, or courier support with a named employer, a stated salary and a live interview. Your background fits, and €30k+ is plausible for these | R2–R4 | `[inferred]` from your CV account; `[generic]` market | pending your decision |

You haven't sent anything, so you are in a good position. If you've already shared your passport photo or PPS number, tell your bank, watch your accounts and credit file, and consider contacting the Data Protection Commission and Gardaí about identity misuse.

Research tier: L0 — no searches

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site/careers page | skipped | I didn't search without your consent. The red flags don't depend on it, and a result can't clear them |
| 2 | Role-family pay sweep | skipped | Same reason. Pay calibration here is `[generic]` |
| 3 | Hiring-manager footprint | n/a | No named person, only a handle |

I can run L1 research on request: up to 5 searches and 2 page fetches. That would only confirm whether "Velloway Logistics" exists.

I can write this up as `tuesday-dossier.md` if you want a record. If you're keeping any of this to show your bank or Gardaí, I'd save the chat screenshots instead.

**Upgrade menu.** Your CV would let me tune real-role positioning and draft an outcome-led summary line for your approval. A salary-floor and location list would let me check real postings against your €30k. The live posting URL and the employer's email domain would let me check the "company exists" claim.

**Questions**
1. (R1, A4) What kind of role do you want next: stay in courier/parcel customer ops, move to order processing or operations, or open to either? And is fully remote essential?
2. (RR1) Have you already sent anything, such as documents, money or your IBAN, to this account?
3. Do you want me to run the L1 company check?

Reply in your own words, say "skip" to pass on any question, or ask for something different.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.