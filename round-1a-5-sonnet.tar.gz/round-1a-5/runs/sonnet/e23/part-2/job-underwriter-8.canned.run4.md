Checking this against the posting and the three messages, and building the full assessment now.

## Decision snapshot

**No. This is not a legitimate job, and you shouldn't go ahead. Don't send your IBAN, PPS number or passport photo, and don't pay anything. Status: `no_go`, on RR1, RR2 and RR3 (all `severity: high`).**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

R2, R3 and R4 are strong matches on paper, and they are why this scheme targets someone like you. R1 — pay depends on hours and on the "up to" rate; R5 — you haven't said.

**Opportunity ledger.** It is a pattern of payment and identity requests, with no real employer behind it: RR1 (money from you first), RR2 (identity documents before any interview), RR3 (the cheque), RR4 and RR5 (process and identity cannot be checked). RR6 (the pay terms) is a smaller signal.

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** a verified company, a contract in your name, no payments from you, and a real interview. The messages so far show none of these.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". Nothing in what you pasted ties it to a real, checkable company: no website, registration number or named person. Contact is a Telegram handle and an email at a generic mail domain, not a company domain. | `[grounded]` posting and messages; `[inferred]` that the company is unverified, until research runs |
| Mandate | "Remote Order Processing Coordinator". The posting never says what an order is, for which customers, or on what system. | `[grounded]` posting |
| Pay and hours | "Up to €26 an hour plus commission", 15–30 hours a week, "set your own hours". No contract type is stated. | `[grounded]` posting |
| Arithmetic against your floor | €30,000 a year needs about 22 hours a week all year at the top rate. At 15 hours it is about €20,300 a year, and at 30 hours about €40,600. | `[grounded]` posting's figures, arithmetic mine |
| Market calibration | Genuine remote admin and operations roles typically involve a named employer, a written contract and a live interview. The employer pays for the equipment, and nobody is asked to front money or lodge a cheque. | `[generic]` role-family pattern, not researched this turn |
| Unknowns | Who employs you, who pays you, which customers, what "commission" is, and whether this is employment or contracting. | `[grounded]` absent from posting and messages |
| Contradictions | The posting says "no experience needed, full training provided", yet you "passed screening" before any assessment. "Payroll" wants your passport before you have had an interview. The posting says you set your own hours but never mentions a contract. The kit comes from an "equipment partner", not the employer. | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. Fit is unclear because the pay is "up to" and the hours are a 15–30 range. The floor is met only near the top rate and at roughly 22 or more hours a week, and commission is unquantified. | `[grounded]` user-stated floor, posting's figures | G2 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day plus a maintained weekly tracker is relevant. Medium because it rests on your account, with no artifact. | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Written customer replies at volume in Zendesk. | `[grounded]` your background | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said. It is a trivial requirement that doesn't change the decision. | `[grounded]` silence in your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Quiet workspace (R5) | discovery | Not stated | Low stakes; matters only for a genuine role | Your current home or work set-up | A sentence from you | `[grounded]` absent from your message |
| G2 | Reaching €30,000 (R1) | hard_gate | Reachable only at the top rate and 22+ hours a week, and the pay terms can't be relied on | For genuine roles, whether part-time can ever meet your floor | Your hours and flexibility | Your answer on full-time versus part-time | `[grounded]` posting figures and your floor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Applicant asked to pay up front | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A real employer supplies equipment at its own cost. A fee paid to a third party is the usual route for taking money from applicants. | `[generic]` known recruitment-scam pattern; `[grounded]` quote | Which legal entity is the equipment partner, and why can't Velloway supply or reimburse equipment directly under a written contract? | unresolved |
| RR2 | IBAN, PPS number and passport requested before any interview | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | These are the documents needed for identity theft and account takeover. A genuine employer collects them after a signed offer, not before an interview. | `[generic]` hiring practice and scam pattern; `[grounded]` quote | Under which signed contract, and with which named payroll provider, do you need these documents at this stage? | unresolved |
| RR3 | Cheque overpayment | red_flag | high | "We are posting you a cheque for €2,850. Lodge it… keep €350… transfer the rest to our equipment partner." | A cheque can be credited and later returned. The money you send out is real and yours, and the bank can reclaim the cheque amount from you. The structure is a fake-cheque scam. | `[generic]` fake-cheque pattern; `[grounded]` quote | What is the legal name and registered address of the company issuing this cheque, and why is a new hire asked to forward part of it? | unresolved |
| RR4 | No live interview, "passed" almost instantly | risk_signal | medium | "no calls or video interviews"; "you passed the interview and the job is yours!" | The "interview" was text answers only, so there was no way to verify anyone, and the offer arrived with no assessment of fit. | `[inferred]` from the messages' sequence | Can I speak to the hiring manager on a video call, and can I see a written contract first? | unresolved |
| RR5 | Employer and contact not verifiable | risk_signal | medium | "@VellowayHiring"; "velloway.hr@postmail.example" | Telegram and a generic mail domain give no way to confirm who these people are. | `[grounded]` the handles and domain as given; `[inferred]` unverifiable | Which email address at the company's own website domain can confirm this offer? | unresolved |
| RR6 | Vague pay terms | risk_signal | low | "up to €26 an hour plus commission on every order you process" | "Up to" and unquantified commission can hide a much lower real rate, but this is minor next to RR1 to RR3. | `[inferred]` from the posting's wording; low severity because the other entries dominate | What is the guaranteed hourly rate, and how is commission calculated? | unresolved |

## Application plan

These are recommendations. Whether to act on them is your decision.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying and block the handle. Don't send the IBAN, PPS number or passport photo. | See RR2 | `[grounded]` RR2 | proposed, yours to decide |
| A2 | Don't transfer the €349 or any other sum to anyone. | See RR1 | `[grounded]` RR1 | proposed, yours to decide |
| A3 | If a cheque arrives, don't lodge it. If you have already lodged one, ring your bank today and say it may be fraudulent. | See RR3 | `[generic]` fake-cheque pattern | proposed, yours to decide |
| A4 | Keep screenshots of the posting and chat. Report the ad to the jobs site, report the handle on Telegram, and consider reporting to the Gardaí. | Evidence for a report; protects other applicants | `[generic]` standard reporting steps | proposed, yours to decide |
| A5 | If you answered their questions with personal details, tell me what you gave. For example, an address or date of birth is worth flagging to your bank. | See RR2 | `[inferred]` from "I answered their questions" | proposed, yours to decide |
| A6 | Redirect your search to roles with a named employer, a written contract, a live interview and no payments from you. Your Zendesk, tracking and trainer experience fit customer operations and order-support roles. | Your background is genuinely marketable | `[generic]` role-family pattern; `[grounded]` your background | proposed, yours to decide |

## Evidence status

Verified: none yet.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | No search has been run, because research consent rides with the questions below. A search would test whether "Velloway Logistics" exists as described, and would move RR5 and the standing employer-not-established entry. |
| 2. Role-family sweep | unavailable | Same reason. It would put real market pay and scope for this title behind the `[generic]` calibration line and RR6. |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle, so no query could be formed. |

I can save this as `tuesday-dossier.md` if you want a file to keep or share with your bank or the Gardaí.

**Upgrade menu.**

- Research consent: confirms whether the company exists as described, and firms up RR4 and RR5.
- The jobs-site name and a link to the original posting: confirms the ad is still live and says where to report it.
- A copy of the cheque, if it arrives: would help your bank and the Gardaí. Don't lodge it.
- The targets you'd like instead (titles, location, hours): would let me vet real postings against your floor.

**Questions.**

1. (Research) May I run a short check of Velloway Logistics: up to 5 searches and 2 page fetches, covering their site, scam reports and the ad? Optional, since the decision stands without it.
2. (A5) What did your answers in the chat include beyond what you've mentioned here, such as address, date of birth or employer details?
3. (G2, R1) Do you need full-time hours to reach €30,000, or would a genuine part-time role plus other income work?

Short answers are fine, or say "skip" to pass on any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.