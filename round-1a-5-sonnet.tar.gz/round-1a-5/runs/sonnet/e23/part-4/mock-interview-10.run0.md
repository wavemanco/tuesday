Before you prep, I'd check whether this invite is real. It has several signs of a recruitment scam.

**What worries me**
- **Everything happens on Telegram.** The interview, the offer and the onboarding are all in one chat. Real companies run interviews on video or phone, or on platforms like Teams, Zoom or Google Meet. They send offers from a company email address, and onboarding goes through HR systems. A text-only chat for all of it is the most common scam pattern for remote support jobs.
- **A text interview with the "team lead".** That is how these scams usually run. The chat then moves to "onboarding", which means paying for equipment or software, sharing ID, bank details or a National Insurance/SSN number, or receiving a cheque to deposit.
- **Contact came to your personal Telegram.** Telegram is where scammers often move conversations after scraping job boards.

I can't tell you it's fake. Some small startups really do use chat tools. But the whole process being Telegram-only is a strong warning sign.

**What to do before replying with a time**
1. **Check on Lumenvale's official site.** Look for a real careers page listing this role, and find the real talent team contacts. Don't use any link Marcus sent.
2. **Email the company directly.** Use an address from their website to ask whether Marcus Hale works there and whether this role is open.
3. **Ask Marcus to move the process.** Ask for a video call and for an email from a company domain. A real recruiter will say yes. A scammer will push back, rush you or go quiet.
4. **Check your application.** Did you actually apply on Lumenvale's own site? Look for a confirmation email.

**Until it's verified, don't:**
- send ID, bank details or a National Insurance/SSN number
- pay for anything (equipment, training, software)
- accept a cheque or any transfer
- click links or install apps Marcus sends

**Your background is a good fit for this type of role**, so the prep is worth doing once the role checks out:
- **3 years at an energy supplier, around 60 contacts a day.** This covers the "2+ years" and the written communication requirements. Customer service at that volume counts.
- **Freshdesk every day.** This is the "Zendesk or similar" requirement. Be ready to say you've handled queues, tags, macros and SLAs, if that's true.
- **Training four new starters on refunds.** This shows you can handle escalations and explain a process clearly.
- **Gap: no software company experience.** Prepare a short answer about how you'd learn the product quickly.

If the role is real, I'll build you a full prep pack. It would have likely questions, answers based on your own experience, and questions to ask them. We could also run a live practice interview. Just tell me what the verification shows. If you have the full job ad, paste it in so I can tailor the pack to it.