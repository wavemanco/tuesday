# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead (name not given), by text chat on Telegram. Your message names Marcus Hale as the talent contact who invited you. Built as a first pack from your message alone.

## How to use this pack

Personas are how a question is asked. Types are what it is scored on.

- VAL: whether past behaviour shows the company's published values
- EXP: whether what you say you did holds up under follow-ups
- JD: whether you can do the listed job, gaps included
- CO: how well you know the company and its strategy (none in this pack, because no company research could run)
- CASE: a live problem from the role

Guidance is scaffolding, not a script. This interview is a text chat, so rehearse by typing your answers, not only by saying them. Anything marked "Answer slot" is for you to fill from your own experience, or to answer with a plain "that wasn't part of my job".

Loop: one text-chat session with the support team lead, from your message. Nothing else about the loop is established, so the persona weights below rest on that relationship and on your fit snapshot.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message, relaying the job ad | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: three years, customer service advisor, an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message, relaying the job ad | "I use Freshdesk every day" — your message | medium | [inferred] | presentation | The ad accepts a similar ticketing tool, and naming Freshdesk plainly is the whole bridge: "I use Freshdesk every day." The derivation that Freshdesk counts as similar is this pack's, so say the tool's name and let them judge. Do not say you have used Zendesk |
| F3 | "clear written communication" — your message, relaying the job ad | "answering around 60 calls and emails a day" — your message | low | [inferred] | transferability | Your material carries emails answered in volume, and says nothing about how clear they were or whether anyone reviewed them. Answer slot: the ad's written-communication line makes a probe likely. If any of your written replies were reviewed, scored or praised, say how, in your own words; if none were, say so plainly and describe how you write a reply |
| F4 | "confidence handling escalations" — your message, relaying the job ad | none given | none | [grounded] | discovery | Your material does not show escalation work either way. Answer slot: the ad's escalations line makes a probe near-certain. If escalations came to you or went up from you, say what the situation was and which part was yours; if there was no escalation step in your job, or none reached you, say so plainly and say how you would handle one |
| F5 | Familiarity with a software company's product and customers (role-family expectation, no quoted source) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Your words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past |
| F6 | Passing process knowledge on to colleagues (role-family expectation, no quoted source) | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap. Tell it at its own scope: you trained four new starters, on the refunds process, last year |

No row is a gate: nothing in your message states a location, hours, pay or work-authorisation term. If the full ad has one, send it and the snapshot gains a gate row.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live support scenarios typed into the chat: a customer message to answer, a ticket to triage, a reply to rewrite | Highest (5 questions). A support team lead is a hiring-manager-style interviewer, and a text chat lets them test your writing directly | Clarify, then acknowledge, then act, then set expectations. Write the actual message, not a description of it |
| B. Skeptic | Probes on the software-company gap and on escalations | Highest (5). F5 is a gap you stated and F4 is a silent row, so both are predictable | Rehearse the F5 question until it is boring. Concede what you don't know, hold what your quotes carry |
| C. Conversational | Opening chat, motivation, working remotely | Medium (3). Chat openers feel casual and are still scored | Pre-write a short arc from your own quotes. Treat the casual questions as scored |
| D. Data-Driven Prober | Your two figures: around 60 a day, and four new starters | Medium (3). Both numbers are on the page for them to pick at | Know what you can and cannot say about how each was counted, and say plainly when you do not know |
| E. Pressure | Short, challenging "why you" lines | Low (2). A text chat makes interrupting harder, and the other four personas cover the likelier probes | Pause, restate, hold the position, concede only what is true |

No Values persona: no values-style round is established by your message, and no company values were read.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: they were charged twice and want it fixed today. You're live in the chat. What's your first message?" | CASE | [generic] | Type the actual message. Beats: acknowledge the problem in one plain sentence, say what you are checking, say what you can and cannot promise today, say when they will hear from you next. No claim about your past is needed | A live problem set in the role. CASE because it scores structure and tone in writing; generic because it is a pattern, not a fact about this employer |
| A2 | "A customer has reported the same bug three times and says nobody has replied properly. How do you decide whether to escalate?" | JD | [generic] | Structure it: read the history first, say what you would check before handing on, what a good handover note contains, and how you tell the customer what happens next. Answer slot: if you have handled something like this, say what happened and which part was yours; if you have not, say so plainly and answer as a plan | The escalations requirement (F4) as a decision. JD content with CASE delivery |
| A3 | "We use Zendesk. What ticketing tools have you worked in?" | JD | [grounded] "I use Freshdesk every day" | Say it in those words. Answer slot: if you have used Zendesk, say where; if not, say so plainly and return to Freshdesk, then say how you would learn the difference. Name no feature you did not use | F2 is a CV-line claim with nothing inspected behind it. JD because it scores the stated tool requirement |
| A4 | "Here's a draft reply: 'Hi, ur refund is being processed it takes time, thanks'. Rewrite it so it's clear." | JD | [generic] | Rewrite it live. Keep it short, state what is happening, give the timescale only if you know it, say what the customer needs to do, if anything. No claim about your past | The written-communication requirement (F3) tested directly, which a text interview can do and a call cannot |
| A5 | "A ticket arrives about a feature you've never seen. The customer is waiting. What do you do in the first ten minutes?" | CASE | [generic] | Structure it: what you would look up and where, what you would ask the customer, what you would not promise yet, and when you would ask a colleague. Said as a plan, not a past | Turns F5, the software gap, into a method question you can answer well |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we expect you to pick up our product?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked for a software company." Then hold only what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Then a plan for the product, said as a plan. Hold through two follow-ups by returning to those quotes, never by adding to them. Concede what you do not know about their product and customers, specifically | F5 is the biggest stated gap and F1 and F2 are what you can set beside it. JD because it scores the stated tool and experience requirements against the gap |
| B2 | "Tell me about a time a customer's problem went beyond what you could resolve yourself." | EXP | [generic] | Selection scaffold: pick an occasion with a named situation, a point where you decided it was not yours to fix, and what happened next, and say which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is silent, so the pack cannot map a story. EXP because it checks what was actually yours |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the weakness your material shows: the product. Say it in your own words, then what you would do in the first weeks, as a plan. Do not pick a fake weakness | The stem every Skeptic uses. Answering it with F5 is honest and rehearsable |
| B4 | "You've come from an energy supplier. Why a software support job, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" and "I've never worked for a software company" | Your material does not say why you applied, so the reason is yours to give. Answer slot: say your real reason in your own words and tie it to something from the quote above. If part of the reason is practical, such as working remotely, say that plainly too | Motivation consistency is what Skeptics score. EXP because the story must survive cross-examination |
| B5 | "What does clear written communication mean to you, and how do you know yours is clear?" | JD | [inferred] "answering around 60 calls and emails a day" | Say what clear means to you in two or three plain points. Answer slot: if any of your written replies were reviewed, scored or praised, say how; if none were, say so plainly and describe how you check a reply before sending it | F3 is a low-confidence transferability row, and the ad names the requirement outright |

### C. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about your journey so far." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | A short written arc using only those beats, in your own words: three years as a customer service advisor at an energy supplier, Freshdesk every day, and training four new starters on the refunds process last year. Close with why this role, which is yours to supply | The usual opener, and the place the 2+ years requirement (F1) is answered. JD content, EXP delivery |
| C2 | "How do you stay on top of your work when you're remote?" | JD | [generic] | Structure: how you plan a shift, how you tell the team what you are on, and what you do when you are stuck. Answer slot: if you have worked remotely before, say so; if not, say so plainly and describe how you would set it up | The role is remote, per your message. Your material is silent on remote work, so this is a slot |
| C3 | "You mentioned training new starters. Tell me about that." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it at the sentence's scope: four new starters, the refunds process, last year. Tell it in your own words. Do not call it a programme you designed or led | F6. The question uses only what you have said |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that figure counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say "around 60", not "60 tickets". Answer slot: how it was counted; what it was sensitive to; the assumption you would defend least; which part was yours. If you do not know how the figure was counted, say so plainly | Headline figure on the page, so a defend-the-number question. The word "around" is yours; keep it |
| D2 | "How much of that training of the four new starters was you, and how much was set by someone else?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: say which parts were yours, in your own words. If the plan, materials or sign-off came from someone else, say so plainly and stay with what you did | The attribution probe. Quantified claim F6, tested for what was actually yours |
| D3 | "Roughly how did that 60 split between calls and emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you know the split, give it as the roughly figure it is; if you do not know, say so plainly and say what you do know | A natural follow-up to D1. A figure you cannot split is fine to say you cannot split |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already done this job at a software company?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I've never worked for a software company" | Pause, then hold: three years as a customer service advisor at an energy supplier. Concede the gap in the same message: "I haven't worked for a software company." Then say what you will do about it. Do not claim equivalence | The Skeptic's B1 under time pressure. JD because it scores the same requirements |
| E2 | "How do you keep quality up when you're answering that volume?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you had a check or routine that kept replies accurate, say what it was; if you had none, say so plainly and say what you would do. Hold your position through a second push | Hold-then-concede on the figure. The question asks about practice, so the guidance cannot supply one |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, B1, E1 |
| "experience with Zendesk or a similar ticketing tool" | A3 |
| "clear written communication" | A4, B5 |
| "confidence handling escalations" | A2, B2 |
| Software company gap (F5) | B1, B3, A5, E1 |
| Training others (F6) | C3, D2 |

## Reverse questions

1. "What does a new person's first month on the support team look like?" Why it lands: it shows you are thinking about ramp-up, which is your F5 gap.
2. "When something has to be escalated, who does it go to and what should a handover contain?" Why it lands: it shows you take escalations (F4) seriously as a process.
3. "Which ticketing tool does the team use, and how is onboarding on it done?" Why it lands: it answers F2 openly instead of leaving it as a gap.
4. "How is the quality of written replies reviewed or coached?" Why it lands: it signals you want feedback on your writing (F3).
5. "Can you confirm the next steps, including any call or video conversation with the team and who sends the contract, in an email from your company address?" Why it lands: a genuine employer can answer this easily, and it lets you check the process matches what Marcus described.
6. "What does the team find hardest about this job right now?" Why it lands: it invites an honest answer and shows interest in the work, not only the offer.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The pack's observation is that your material names Freshdesk, not Zendesk. A3's slot allows either answer |
| Resolved 60 tickets a day | Inflated form of F3: your quote counts calls and emails | "Around 60 calls and emails a day", with the same noun and the same "around". D1 and D3 stay inside it |
| Designed or led a training programme | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on the refunds process last year. C3 and D2 stay inside it |
| Software-company or SaaS support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |

## Sources

Provided documents: your message, with the Telegram text and your background. No dossier was supplied.

Searches sent, all refused: "Lumenvale Software company values" (refused); "Lumenvale Software interview process customer support specialist" (refused); "Lumenvale Software strategy news" (refused); "Marcus Hale Lumenvale Software talent" (refused). No fetches. No result from any search was used.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software company values` | unavailable | Every call was refused. It would have supplied the official value names; no values-style round is established by your message, so section 10 is absent either way |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Every call was refused. It would have checked the loop and tuned persona weights; the one-session text-chat loop here comes from your message |
| 3. `Lumenvale Software strategy news` | unavailable | Every call was refused. It would have fed a CO bank and a grounding brief, both absent |
| 4. `Marcus Hale Lumenvale Software talent` | unavailable | Every call was refused. It would have checked the talent contact's public footprint. The interviewer read is absent, and the interviewer is the unnamed team lead |
| 5. representative `Customer Support Specialist` JD | skipped | Your message supplies the ad's four requirements, which fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text, pasted: the requirement quotes become the ad's own words, and any location, hours or work-authorisation terms become gate rows
- The team lead's name and anything Marcus said about format, focus areas or time limit: persona weights get reweighted and the interviewer read opens
- Company research (search permission granted): official value names, documented loop structure and a strategy brief, so a CO bank and a grounding section can be added. A deeper research pass is also available: up to 6 more searches and 2 more fetches, several more minutes
- A sentence on any escalation you handled, or on any written reply of yours that was reviewed: F4 and F3 move out of discovery and transferability, and B2 and B5 become story-mapped
- Whether you have used Zendesk, and whether you have worked remotely: A3 and C2 firm up
- A saved `tuesday-dossier.md` from an earlier evidence review would add verified evidence and objections the pack could build on
