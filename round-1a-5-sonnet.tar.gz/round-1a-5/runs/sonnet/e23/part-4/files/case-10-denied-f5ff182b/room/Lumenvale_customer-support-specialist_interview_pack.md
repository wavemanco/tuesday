# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: not named. Your message calls them the "support team lead", so this pack treats the round as a hiring-manager conversation, held as a text chat.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for your own words, not a script. Because the interview is typed, each guidance cell is sized for a reply of about 150 to 200 words rather than a two-minute spoken answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether what you claim survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned through |

Labels: `[grounded]` rests on something you or the ad gave me. `[inferred]` is my derivation, named. `[generic]` is a pattern with no claim about you or this employer. An answer slot is an instruction for the interview, not a question for you now.

## Fit snapshot

The requirements are the ones you listed from the ad. I have not seen the ad's full text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you listed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: 3 years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Name the tool you use in the quote's own terms. Your material says Freshdesk, not Zendesk, so Zendesk is not claimed. Answer slot: if you have used any other ticketing tool, say which; if not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — the ad, as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails touch this requirement, but the quote does not show how clear the writing was, and the bridge should not be stretched. Answer slot: the typed interview is itself a writing sample, so expect a probe on your written replies. If you can say in your own words what the emails were like, do; if the emails were a small part of the day, say so plainly and describe the writing you do have |
| F4 | "confidence handling escalations" — the ad, as you listed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: if escalations reached you, say what happened and what part was yours, in your own words; if none did, or they were not yours to handle, say so plainly and say how you would handle one |
| F5 | sharing process know-how with new colleagues — role-family pattern, not in your list | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Say it at its own scope: four new starters, your refunds process, last year. Your material says training, not that you designed the process |
| F6 | familiarity with software products and software customers — role-family pattern, not in your list | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so yourself. Words: "I've never worked for a software company." Then how you would learn it, said as a plan and never as a past |

## Persona table

Assumption: the support team lead is the person who would manage the hire, so hiring-manager priors apply. If that is wrong, tell me and I will reweight.

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| A Case / Strategist | Live ticket-style scenarios in the chat, including a reply written on the spot | 5 questions | A typed support interview naturally uses written scenarios; F3 and F4 are the rows with the least evidence | Clarify what you would check first, then structure the reply; think in the chat |
| B Skeptic | The software-company gap, motivation, escalations | 4 questions | F6 is a gap you stated yourself, so it will be raised in some form | Rehearse B2 until it is boring: one sentence of what you have, one plain concession, a learning plan |
| C Conversational | "Walk me through your background" | 3 questions | Chat interviews often open this way, and it is still scored | Prepare a short arc built only from your own quoted sentences |
| D Data-Driven Prober | Reads your lines closely: the daily volume, the tool | 3 questions | Both are specific claims in your material | Know what you can say about how the number was counted, and say plainly where you do not know |
| E Pressure | Short, challenging versions of earlier questions | 2 questions | A lower prior for a support role, but the software gap invites a "why you" challenge | Hold your position through two follow-ups, concede only what is true |
| F Values / Behavioural | "Tell me about a time" stories | 2 questions | No published values were available to me, so these use stems only | Choose a real instance, or use the honest branch |

## Question banks

### A Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem and is clearly angry. Walk me through your reply." | CASE | [generic] | Say what you would check first in the ticket history, acknowledge the repeat in plain words, say what you will do and by when, and say who you would bring in if you cannot fix it. The question needs no claim about your past, so the guidance makes none | F3 is the row with the least evidence, so a written scenario is the likeliest test; CASE because it is a live problem |
| A2 | "A customer demands a manager and says they will cancel. When do you escalate, and what do you put in the handoff?" | CASE | [generic] | Structure it: what you try first, the point at which it is no longer yours to resolve, and what the next person needs so the customer does not repeat themselves. Ask whom you would hand it to. No claim about your past | The ad's escalation line is F4's requirement, asked as a decision rather than a history; CASE delivery |
| A3 | "You have thirty open tickets and three are urgent. How do you decide what to answer first?" | CASE | [generic] | Name your criteria aloud in the order you would apply them, say what you would tell the customers who wait, and say what you would ask the team lead. Offer your reasoning, not a rule you claim to have used | Tests structure under load without needing any history; CASE |
| A4 | "Our team works in a ticketing tool you may not have used. How would you get up to speed in your first two weeks?" | JD | [grounded] "I use Freshdesk every day" | Say what you use, in those words. Answer slot: if you have used any other ticketing tool, say which; if not, say so plainly. Then give a plan for learning a new tool, said as a plan | F2 is the evidence for the tool requirement and the likeliest place the gap shows; JD because it scores the stated requirement |
| A5 | "Write the first reply to this customer: 'My refund has not arrived and nobody has told me anything.'" | CASE | [generic] | Write it live and keep it short. Apologise once, say what you will check, say when you will come back, and make no promise about a refund date you cannot know. Read it once before sending | The most direct test of F3's requirement; CASE delivery with a JD theme |

### B Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the gap in your own words: "I've never worked for a software company." Then say how you would close it, as a plan: what you would learn first and whom you would ask. Do not add a claim about how transferable your experience is | F6 is the stated gap, and this is its most direct form; JD because it scores the role's demands |
| B2 | "You have never worked for a software company. Why should we think you can support software customers?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I've never worked for a software company" | The highest-ROI rehearsal in this pack, and the hold is only what your quotes carry: 3 years as a customer service advisor at an energy supplier, and Freshdesk every day. Concede plainly: "I've never worked for a software company." Hold through two follow-ups by returning to those facts, never by adding to them, and let the interviewer draw the inference | F6 is the gap you stated, so some form of this question is likely; JD because it scores fit against the role, with Skeptic delivery |
| B3 | "Why move from energy into software?" | JD | [generic] | Answer in your own words and give your real reason. The pack cannot supply it. If the remote working is part of the reason, say so, and pair it with something true about the work itself | Motivation consistency is what the Skeptic scores; the question presupposes only a move you have told me you want |
| B4 | "Tell me about a time you handled an escalation." | EXP | [grounded] | Selection scaffold: pick an occasion where a customer's problem could not be settled at your level, with a named customer need, a clear point where it left your hands or stayed with you, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle one | F4 has no evidence in your material, so the scaffold selects an instance instead of supplying one; EXP because it tests what was actually yours |

### C Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey and why this role." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | Build the arc from those three sentences and no further beats: the three years, the tool you use, the four new starters. Answer slot: the why-this-role part is yours to give in your own words; if the real reason is simply that you want a change, say so plainly | F1, F2 and F5 carry the arc; EXP because it is how a CV line becomes a story |
| C2 | "Tell me a bit about the training you did on refunds." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it at the quote's scope: four new starters, your refunds process, last year, in your own words. If asked how it went, answer from what you remember, and if a part was informal or shared, say so | F5 is the only sentence about teaching others, and a casual register invites more detail than the quote carries |
| C3 | "Have you done live chat support, or mostly phone and email?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you have done live chat, say how much; if not, say so plainly and return to what you did: "answering around 60 calls and emails a day." Do not claim chat experience | This interview is a text chat, so the ad's written-communication line makes live chat a likely probe; F3 covers it |

### D Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: say how the figure was counted; if you do not know, say so plainly. Say what it is sensitive to, such as the split between calls and emails or busy days. Name the assumption you would defend least before they do, and say which part of the work was yours | A headline figure on your account, so a defend-the-number question applies; F3 and F1 sit behind it |
| D2 | "What do you actually use Freshdesk for day to day?" | EXP | [grounded] "I use Freshdesk every day" | Say what you use it for, in your own words. Answer slot: if there are parts of the tool you have not used, say so plainly. Do not name features you have not touched | F2 is the evidence for the tool requirement; a prober tests the depth behind "every day" |
| D3 | "What makes a written support reply clear, in your view?" | JD | [generic] | Give your own view in two or three points and offer a short example of how you would write one. This question asks for a view rather than a history, so the guidance makes no claim about your past | The ad's written-communication line; F3 is thin, so a view is the safe, honest answer |

### E Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has worked in SaaS support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I've never worked for a software company" | Pause, restate the question, then hold: 3 years as a customer service advisor at an energy supplier, Freshdesk every day. Concede in one line that you have not worked for a software company, and stop there. Hold through two follow-ups without adding to the quotes | F1, F2 and F6 are the whole position; Pressure delivery of the B2 objection |
| E2 | "That training you mention. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the quote says: you trained four new starters on your refunds process last year. Answer slot: if any part was shared or set by someone else, say which, plainly; if all of it was yours to deliver, say so. Never move from "trained" to "built" or "owned" | F5 is where attribution probes land; Pressure delivery |

### F Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you put a customer ahead of getting through your queue." | VAL | [generic] | Selection scaffold: pick an occasion with a named customer need, a moment where you chose the customer and it cost you something, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt from the Values stem in the persona model; no published Lumenvale values were available to me, so it stays generic |
| F2 | "Tell me about a time you had to tell a customer something they did not want to hear." | VAL | [generic] | Selection scaffold: pick an occasion where the answer was no or not yet, with the words you used and how the customer took it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would say it | An open prompt adapted from the Values stem; generic for the same reason as F1 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | B2, C1, E1 |
| "experience with Zendesk or a similar ticketing tool" | A4, D2 |
| "clear written communication" | A1, A5, C3, D3 |
| "confidence handling escalations" | A2, A3, B4 |
| software-company experience, not in your list | B1, B2, B3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like for someone new to software support?" | It shows you have already thought about the gap in F6 and want to close it |
| R2 | "How does an escalation work on your team: who picks it up and what do they need from me?" | It signals that you care about the handoff, which is the part of F4 you can speak to without a claim |
| R3 | "How is quality measured on written replies?" | It turns the ad's written-communication line into a conversation about standards |
| R4 | "Which ticketing tool does the team use, and how long does onboarding on it usually take?" | It answers A4 for you and shows you plan to ramp quickly |
| R5 | "Will the contract and onboarding paperwork come through a company email or HR system, and who would I report to?" | It is a normal question for a remote hire, and the answer tells you whether the process is what it claims to be |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk |
| Has software-company or software-customer experience | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never worked for a software company." No slot |
| Designed or owned the refunds process | Inflated form of F5 | F5's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says training, not the process's design |

## Sources

Provided: your message, including the Telegram message and the ad's requirements as you listed them. I have not seen the ad's full text or your CV.

Searches sent:

- "Lumenvale Software company customer support careers": refused
- "fake recruiter Telegram job interview scam remote customer support warning signs": refused

Research tier: L0 — searches 0 of 6 returned (2 sent, both refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | A search was sent and refused. It would have fed a values cheat sheet and the CO bank, both absent |
| 2. `Lumenvale Software interview process customer support` | unavailable | No call was sent, because the host refused search. It would have shown the loop structure and reweighted the personas |
| 3. `Lumenvale Software strategy` / recent news | unavailable | No call was sent, because the host refused search. It would have supplied a CO question grounded in current strategy |
| 4. `{interviewer name} Lumenvale Software` | n/a | The interviewer is unnamed, so there was no query to form. The interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | unavailable | No call was sent, because the host refused search. It would have filled in requirements beyond the four you listed |
| Un-numbered: scam-pattern search | unavailable | Sent and refused. It was outside every declared target |

## Upgrade menu

- The ad's full text → the four requirement rows become quoted lines, and any location, hours or right-to-work terms would appear as gate rows
- Your CV → F1 to F5 gain confidence where it backs up your message, and the banks gain more story-mapped answers
- The interviewer's name and role → an interviewer read and a reverse question tied to their path
- Any note from the recruiter on focus areas or a take-home → coverage of anything pre-declared
- Search access → values, loop structure and strategy, which would add a values cheat sheet and a company question
- A `tuesday-dossier.md` from an earlier session → a stronger objection rehearsal and sourced prohibited claims
