# Customer Support Specialist, Lumenvale Software: interview prep pack

Round: one text chat on Telegram with the support team lead (name not given). Built as a hiring-manager-style round, since your note does not say whether the lead would be your future manager. Remote role.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (no bank here: no values page was in hand) |
| EXP | Whether what you say about your work survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (no bank here: web search was not available, so nothing about Lumenvale beyond your messages is in this pack) |
| CASE | A live problem set in the role |

Labels: `[grounded]` traces to something you gave me, `[inferred]` is my derivation from it, `[generic]` is a role-family pattern with no claim about you or Lumenvale. Because the interview is itself written, every reply you type is also a sample of "clear written communication": short messages, plain words.

## Fit snapshot

The requirements are the four you quoted from the ad, as you described them in your message. Your evidence is your own sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message; "answering around 60 calls and emails a day" — your message | medium | [grounded] | none | Tenure and volume are in your own words, with nothing inspected behind them, so expect a probe on both. Say it as written: "3 years as a customer service advisor at an energy supplier." The ad says customer support and your title says customer service; use your title and let the interviewer map it |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Lead with the quote's own terms: Freshdesk, every day. The ad names Zendesk and your material says Freshdesk, so expect a probe on the difference. Answer slot: if you have used Zendesk, say where and for how long, in your own words; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails answered shows volume, not clarity, and the bridge does not stretch it. Answer slot: expect a probe on how you know your written replies were clear. If you have any evidence of that, say what it was in your own words; if there is none, say so plainly and stay with the emails you answered. The chat itself is the live sample |
| F4 | "confidence handling escalations" — job ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: if any contact of yours was passed up or taken over by someone else, say what happened and what part you handled, in your own words; if none was, or the handling was not yours, say so plainly and say what you would do first when one reaches you |
| F5 | Helping colleagues learn the work — role-family expectation, not in the ad as you described it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Keep it at its own scope: four new starters, the refunds process, last year. Your material does not say a programme or a team, so the words stay where the quote is |
| F6 | Supporting the users of a software product — role-family expectation, not in the ad as you described it | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-company work, and nothing added to make the gap feel smaller |

## Persona table

Weights start from the relationship prior (hiring-manager round: Case and Skeptic first), adjusted by what your message says: the interviewer is the support team lead, and the format is a text chat. Recalibrate if you know more.

| Persona | Questions | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 | A ticket scenario you answer by typing the reply | Highest: the hiring-manager prior, and a scenario can be answered directly in a text chat | Clarify what you would check, structure, then write the reply in short messages |
| Skeptic | 5 | Quiet probing of the software-company gap and the escalation line | Highest: F6 is a gap you stated, and F4 is a gap your material is silent on | Rehearse B1 until it is boring: say the limit first, then the plan |
| Conversational | 3 | Friendly opener, then casual questions about tools and training | Medium: the recruiter message is warm in tone and a chat is informal, but casual questions are still scored | A 90-second arc in three or four short messages |
| Data-Driven Prober | 3 | "How was that counted" on your two figures | Medium: two figures in your message invite attribution probes | Say how each was counted if you know, and plainly say if you do not |
| Pressure | 2 | Time-boxed scenarios and "why you" | Lower: typing slows interruption, but a time limit is still easy to impose | Pause, restate, hold your position through two follow-ups |
| Values / Behavioral | 0 | No bank | No published values were in hand and no values round is established | Section dropped |
| Peer Evaluator | 0 | No bank | The interviewer is described as the team lead, not a peer | Section dropped |

Loop: one session, a text chat with the support team lead, per the recruiter's message as you pasted it. Later stages, if any, are not covered here.

## Question banks

Highest-ROI prep in this pack: B1. It is the question most likely to arrive in some form, and it is aimed at F6, where your own words already name the limit.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in saying they were charged twice and wants the money back today. What are your first three messages?" | CASE | [generic] | Think aloud in order: what you would check before promising anything, what you tell the customer now, what happens next and by when. Type the three messages as you would send them: short, plain, one next step each. Say you would check Lumenvale's refund rules, not what they are. The question asks about no past, so the guidance makes none | A live version of F3's requirement; CASE because it is a problem to work, with JD delivery |
| A2 | "A customer says the product has lost their work, wants a manager, and says they will cancel. Talk me through it." | CASE | [generic] | Clarify first (what they were doing, when it happened, what they can still see), acknowledge in one plain sentence, say what you will do and when they will hear back, and say at what point you would pass it up and what you would hand over so the customer does not repeat themselves. Do not promise a fix or a refund you cannot control | F4's requirement set as a decision rather than a record; CASE |
| A3 | "Fifteen customers write in within an hour reporting the same error. What do you do?" | CASE | [generic] | Spot the pattern, tell the team lead early with examples, send a holding reply that says what is known and when the next update comes, and update customers when it is resolved. Do not guess at a cause in writing to customers | Software-support situation that needs no software history, which makes it the fairest test around F6; CASE |
| A4 | "A customer asks how a feature works and you have never seen it. What do you type?" | CASE | [generic] | Say what you do not know, what you will check, and when you will come back. Never guess in writing | Rehearses the honest handling of the F6 gap in the moment it would show up; CASE |
| A5 | "A colleague drafted this: 'Unfortunately we are unable to process your request at this time due to an issue with your account settings.' Rewrite it so a customer knows what to do next." | JD | [generic] | Type the rewrite straight into the chat: what is wrong in plain words, what happens next, and when; keep it short. Do not invent the details of the account issue; refer to it in words, such as "the setting you changed". Then offer one line on why you changed it | Scores F3 directly in the medium the interview is held in; JD because it tests the stated requirement, CASE in delivery |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is at an energy supplier. How would you get up to speed on a software product?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I've never worked for a software company"; "I use Freshdesk every day" | The deepest rehearsal in the pack. Hold: say the limit first, before it is dug out of you: "I've never worked for a software company." Then one adjacent fact at its own scope: "I use Freshdesk every day." Then a plan, in the future tense: what you would learn first, how you would learn it, who you would ask, how you would check yourself, each in your own words and each something you would really do. Follow-ups to rehearse: "What if you are still slow after a month?" and "Why should we take that risk?" Concede specifically (you have not done this yet) and hold the core: three years of customer service and daily ticketing-tool use. Do not claim any software work | F6 is the gap you stated and the likeliest first objection; JD content, Skeptic delivery |
| B2 | "Tell me about a time a customer's problem was beyond what you could fix yourself." | EXP | [generic] | Selection scaffold, since no quoted sentence carries this story: pick a contact you could not resolve alone. It needs a named stake, what you did yourself, who took it on and what you handed over, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is silent and the ad's escalation line raises this probe; EXP because it tests what was actually yours |
| B3 | "The ad asks for confidence handling escalations. What gives you that confidence?" | JD | [grounded] | Answer slot: if any contact of yours was passed up or taken over by someone else, say what happened and what part you handled, in your own words; if none was, or the handling was not yours, say so plainly and say what you would do first when one reaches you. Confidence is shown by a specific, not an adjective | The ad line is quoted in F4; JD because it scores a stated requirement |
| B4 | "The ad mentions Zendesk and you use Freshdesk. What would be different for you?" | JD | [grounded] "I use Freshdesk every day" | Start from the quote and nothing wider. Answer slot: if you have used Zendesk, say where and for how long; if you have not, say so plainly and say what you would check first. Do not describe features of a tool you have not used | F2's probe, asked the way the ad's wording invites; JD |
| B5 | "Why this role, at a software company?" | JD | [generic] | Selection scaffold: your true reason in one or two sentences, and one thing about Lumenvale's product or the ad that you have actually read and can name. If you have not looked yet, look before the chat and say what you saw. If no particular reason comes to mind, say so plainly and say what you are looking for in the role. Do not borrow company language you cannot back | Motivation is where the F6 gap gets cross-examined a second way; JD because it scores fit with the role |

### C. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A 90-second arc in three or four short messages, one beat per quote: the role and the three years, the volume, the tool, the training. Say each at its own scope, in your own words, and stop; do not add to the quotes | F1, F2 and F5 carry the opener; EXP because it is where the CV is first tested |
| C2 | "Which tools do you use all day, and what do you like about them?" | EXP | [grounded] "I use Freshdesk every day" | Name the tool as the quote does. What you like about it is yours to say in your own words; name no other tool unless you really use it | F2 in a casual register; EXP |
| C3 | "You trained new starters. What did you cover with them?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats are the quote's: four new starters, the refunds process, last year. Describe what you covered in your own words | F5 asked casually; EXP |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Four slots, each in your own words: how it was counted, what it moves with, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly: "around" is your word, and an honest estimate holds up better than a made-up method | F1's headline figure; EXP because it tests attribution and counting |
| D2 | "You trained four new starters. Which part of that was actually yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the quote carries: you trained them, on the refunds process. Slots: which part was yours, and the assumption behind "four" you would defend least. If part of it was not yours, say so plainly and return to the training you gave | F5's figure; EXP, the attribution probe |
| D3 | "Which parts of Freshdesk do you use, and which do you not touch?" | JD | [grounded] "I use Freshdesk every day" | Say in your own words what you use. For the rest, say plainly what you have not used. "Every day" describes how often you use it, so it carries no claim about how deeply | F2's depth probe; JD |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone with software support experience?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Hold-then-concede. Pause, restate the question, then hold on what your quotes carry: three years as a customer service advisor and daily ticketing-tool use. Hold it through two follow-ups. Concede specifically and early: "I've never worked for a software company." Do not claim to beat the other candidate; you do not know them | B1 under time pressure; F1, F2 and F6; EXP because it tests whether the limit survives interruption |
| E2 | "Three tickets are open: an angry customer, a simple question, and one that could affect many people. Thirty seconds: which first, and why?" | CASE | [generic] | Pause, restate, commit to an order and give the reason. Say what you would want to know that you do not, such as Lumenvale's own priority rules. Hold your order through one challenge and change it only if you are given a new fact | F4's requirement under a clock; CASE with Pressure delivery |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| "2+ years in customer support" | C1, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" | B4, C2, D3 |
| "clear written communication" | A1, A5, C1 |
| "confidence handling escalations" | A2, A3, B2, B3, E2 |
| Supporting a software product (F6, not in the ad as described) | A3, A4, B1, B5, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone coming from outside software?" | Turns B1's gap into a forward-looking conversation and shows you are already planning the ramp |
| R2 | "Which ticketing tool does the team work in day to day?" | The ad names Zendesk or a similar tool; asking shows you are thinking about the practical switch from your own tool |
| R3 | "How does the team handle escalations: who takes it next, and what does a good handover look like?" | Shows you think of an escalation as a handover with a standard, which is the part of F4 you can speak to |
| R4 | "How does the team check the quality of written replies?" | Written clarity is a stated requirement; the answer tells you how you will be judged |
| R5 | "Could you confirm the next steps in writing from a Lumenvale email address, including what documents you would need from me and when?" | A reasonable diligence question for any employer, and the answer gives you something to check independently |
| R6 | "What would make someone clearly successful in this role by six months?" | Closes on the standard you will be held to, and gives you a thing to ask about at any later stage |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Handled around 60 tickets a day in Freshdesk | Inflated form of F1 and F2: the quotes keep the volume and the tool in separate sentences | The two quotes at their own scope: "answering around 60 calls and emails a day" and "I use Freshdesk every day". The limit is the pack's observation: your material does not say how many of the 60 went through Freshdesk. D1 asks how the figure was counted without naming a tool |
| Owned the refunds process, or ran a training programme or team | Inflated form of F5 | F5's quote at its own scope: "I trained four new starters on our refunds process last year". The limit is the pack's observation: your material says four new starters and the process, not a programme or a team |
| Has worked for a software company | Negative you stated, F6 | The plain acknowledgment: "I've never worked for a software company." No slot |

## Sources

Provided: the Telegram message as pasted, your description of the ad's requirements, and your "About me" paragraph. No dossier was present. No full ad text and no CV were provided, so the requirement rows rest on your summary of the ad, and the evidence is the sentences in your message.

Searches sent, all refused (permission to use web search was not granted):

- "Lumenvale Software values": refused
- "Lumenvale Software interview process Customer Support Specialist": refused
- "Lumenvale Software Telegram recruiter scam": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have fed a values cheat sheet and VAL questions if a values round is documented; both are absent from this pack |
| 2. `Lumenvale Software interview process Customer Support Specialist` | unavailable | Would have checked the loop against Lumenvale's own pages; persona weights rest on the recruiter's message and the hiring-manager prior instead |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current strategy; the CASE bank is `[generic]` instead |
| 4. interviewer name and company | n/a | The interviewer is unnamed ("our support team lead"), so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | unavailable | Would have added mid-list requirements to the fit snapshot; the four requirements you quoted are all there is |
| Outside the declared targets: a check on the Telegram process | refused | Moved nothing; the call returned no result |

## Upgrade menu

- The full job ad text → the four requirement rows rest on your summary today; the full text would add any mid-list requirement and turn `[inferred]` rows into `[grounded]`
- Your answers to the answer slots (Zendesk use, any contact that went above your level, any evidence your written replies were clear) → F2, F3 and F4 regenerate with your own words, and the bridges, B3 and B4 firm up
- A QA score, customer-satisfaction report, review or the refunds training notes, if you have any → raises F1, F3 and F5 from `medium` or `low` toward `high`
- What the recruiter says about the chat (length, topics, live or slow replies) → reweights the banks; Marcus is the person to ask, through a contact you find on Lumenvale's own careers page
- The support lead's name → interviewer read, persona weights read from their public footprint, and a reverse question tied to their path
- Allowing web search → values, documented interview process and recent strategy, which would turn the CASE bank partly grounded and could add a values cheat sheet; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief
- A tuesday-dossier.md from an earlier opportunity review, if you have one → verified evidence and a named top objection in place of the inferred one
