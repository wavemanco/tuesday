**Please don't prepare for this interview yet. The email has the hallmarks of a recruitment scam, and I wouldn't send anything it asks for.**

**What gives it away**
- **A fee to get an interview.** Real employers never charge candidates, whether it's called an "equipment registration fee" or anything else. The payment goes to a "supplier's" account, not the company's.
- **The cheque.** A cheque for €1,850 that you deposit and then send "the balance" on to a vendor is the classic overpayment scam. The cheque eventually bounces, the bank takes the money back, and the money you sent is gone.
- **Passport photo and bank details before any interview.** Real employers ask for these after a signed offer, through a proper HR process. Asking now points to identity theft.
- **The wrong order.** They want payment and documents before the interview, and they've sent a "successful candidate" cheque description before anyone has met you.
- **A placeholder-looking contact.** The reply address is `hr@brennock.example`. A real firm would use its own company domain.

**What to do**
1. **Don't pay, and don't send the passport or bank details.** If you've already sent anything, call your bank now. For the passport, contact the Gardaí and the Passport Office about replacing it.
2. **Check the company independently.** Look up Brennock Facilities Ltd in the CRO (Companies Registration Office) register. Find its website and phone number yourself, not from the email, and ask whether the role exists.
3. **Report it.** In Ireland, report it to the Gardaí, and tell your bank or the platform where you applied. The Competition and Consumer Protection Commission and Banking & Payments Federation Ireland (BPFI) also publish scam guidance.

I haven't built the full prep pack, because rehearsing for this "interview" would only help the scam. If it turns out to be genuine, you'd expect a normal process: no payment, no cheque, and documents only after an offer.

**Real admin interviews**
Your background fits well. Calendar management, travel booking, Word and Excel, and invoice processing map closely to your two years running a four-physio appointment book and chasing unpaid invoices. Real interviewers would probably probe these areas:
- **Excel.** You're "okay" with it, so expect practical questions or a short test on formulas, filtering and pivot tables. Brushing up now is the best use of your time.
- **Conflicting priorities.** For example, four people wanting the same slot. Your clinic experience is a strong example here.
- **Invoice work.** Accuracy, how you handled disputes, and how you chased late payers.
- **Working remotely.** How you stay organised and communicate without an office.

I'm happy to build the full pack for a genuine interview, with question banks, answer guidance drawn from your clinic experience, and questions for you to ask them. To do that, I'd need:
1. A different role or employer you've verified, or the original one once you've confirmed it's real.
2. Your CV or a short list of your clinic duties, if you'd like the answers grounded in specifics.
3. The interview format, if you know it, such as who's interviewing and whether there's a Excel test.