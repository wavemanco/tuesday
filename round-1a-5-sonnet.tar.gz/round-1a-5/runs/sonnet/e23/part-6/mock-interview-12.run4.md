**Don't pay, send anything or deposit anything yet. This email has the hallmarks of a fake-cheque scam.** The "interview" is probably bait.

**Why it looks like a scam**
- **A fee to get an interview.** Real employers don't charge candidates, and a "registration fee" for equipment you haven't been hired to use makes no sense.
- **A cheque with instructions to send the balance on.** This is the classic overpayment scam. The cheque looks real, your bank may credit it, and you send real money to the "vendor". Days or weeks later the cheque bounces, and you owe the bank the full amount plus whatever you sent.
- **Passport photo and bank details before any interview.** That is identity theft material. Legitimate employers ask for right-to-work documents after an offer, in person or through a secure HR system.
- **The sequence.** Everything is rushed ("to speed up onboarding") and runs through a payment you must make first. No real HR process works this way.

**What to do**
1. Don't transfer the €95, don't reply with your passport or bank details, and don't deposit any cheque you're sent.
2. If you've already sent anything, contact your bank now. Also report it to An Garda Síochána, since the IBAN is Irish.
3. Check whether the company exists independently. Look it up in the CRO (Companies Registration Office) register and find its real website and phone number. Contact it through those, not through the email's details. The `.example` domain on that address isn't a real, working one.
4. Ask for the interview in writing with no payment attached. A real employer will just schedule it. A scammer will push back or go quiet.
5. Report the email as phishing and keep it as evidence.

**Prep for a genuine version of this interview**

Your background fits the ad well, so the prep is worth doing for real admin interviews. I can't tailor it to Brennock, because I can't verify it exists. This is a generic outline based on the ad you described.

*What to expect.* A 30-minute video call, usually 5 minutes of intro, 20 of questions and 5 for yours. Expect competency questions with some scenario ones ("two managers need you at once…").

*Your strengths, in your own words.*
- **Calendars.** You ran the appointment book for four physios, which is multi-person scheduling with clashes, cancellations and priorities.
- **Invoices.** You chased unpaid invoices, so you have real accounts-receivable experience. The ad's work is supplier invoices (payables), which is a related skill but the opposite direction.
- **Word.** You're good with it.

*Your gaps, and how to handle them.*
- **Excel.** You're "okay", and this will probably get tested. Don't oversell it. Say what you do use, such as formulas and sorting, and spend a few evenings on VLOOKUP/XLOOKUP, pivot tables and basic formatting before the call.
- **Travel booking.** You have none on record, so you need an honest answer ready. Don't claim experience you lack. Say how you'd learn it, and point to the logistics you do handle, like scheduling around people's availability.
- **Remote work.** Be ready to say how you'd stay organised and reachable without an office.

*Likely questions to rehearse.*
1. Walk me through how you managed four people's diaries. What did you do when they clashed?
2. Tell me about a time you dealt with an unpaid invoice. What was your process, and what happened?
3. How would you prioritise if three urgent requests landed at once?
4. How comfortable are you in Excel? Give an example of something you built or fixed.
5. How would you handle a booking error that cost money?
6. Why remote, and how do you stay productive on your own?

*Questions to ask them.* What does a typical week look like? Who would I support? How are supplier invoices approved? What tools do you use for travel and calendars?

I can build the full prep pack and run a mock-interview drill whenever you have a verified interview. If you'd like, send me the real company name or the original ad. I can also check whether the company or its details match known scam patterns.