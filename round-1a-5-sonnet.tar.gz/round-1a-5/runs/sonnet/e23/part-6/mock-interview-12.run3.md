Aoife, this email has the hallmarks of a scam, so I wouldn't prepare for this interview. Please don't do any of what it asks.

**Red flags**
- **A fee before the interview.** Real employers don't charge candidates to be interviewed, and an "equipment registration fee" isn't a real thing.
- **A passport photo and bank details before any interview.** That is what identity theft and account takeover need. Nobody legitimate needs either before making an offer, and then only through a proper HR process.
- **The cheque for €1,850 where you send the balance on.** This is the classic overpayment scam. The cheque will look genuine and may even show as credited. It later bounces, and the bank takes the money back from you, including whatever you sent to the "vendor". Irish banks can reclaim these funds weeks later.
- **Payment to a "supplier's" account, and an email to a generic `.example` address.** Both are untraceable and unconnected to the company.
- **A job offered and a cheque promised before any interview happened.**

**What to do**
1. Don't pay, don't send the passport or bank details, and don't deposit any cheque.
2. Check whether Brennock Facilities Ltd exists on the CRO register (cro.ie). Contact it only through a phone number or website you find yourself, not the details in the email. Even if the company is real, scammers often impersonate real firms.
3. Report it to An Garda Síochána. You can also forward the email to your bank's fraud team, which is useful if you've replied to it at all.
4. If you've already sent a passport photo or bank details, tell your bank today. Consider asking about a fraud flag on your account, and watch for identity misuse.
5. Check the job ad's source. If it came from a job board, report the listing there.

**For real admin interviews**
The ad's duties are ordinary admin work, and your background fits them well. You've run a four-person appointment book and chased unpaid invoices. That maps directly to calendars and supplier invoices. Your likely weak spots are Excel, which you rated "okay", and travel booking, which you haven't mentioned. I can build a full prep pack for a genuine interview, with likely questions, answer guidance grounded in your actual experience, and a plan for the Excel gap.

If you share a real employer's job description, or the ad itself if it came from a legitimate source, I can start there. A few things would help me tailor it:
1. Who will interview you (a manager, HR, or a panel)?
2. Do you have a CV you'd like me to work from?
3. Is it fine for me to do light company research, or should I use only what you provide?

Don't send a passport to anyone for this. I don't need one, or any ID, for interview prep.