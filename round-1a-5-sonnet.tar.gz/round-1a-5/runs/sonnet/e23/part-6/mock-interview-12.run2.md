I haven't built a prep pack, because this email isn't a real interview invitation. It matches a well-known fake-cheque scam, and preparing you for the "interview" could lead you into it.

**Red flags in the email**
- **A fee before the interview.** Legitimate employers never ask candidates to pay anything, whether it's called an "equipment registration fee" or something else.
- **A request for your passport and bank details.** Real employers ask for these only after a signed offer, through a proper HR system. They are exactly what's needed for identity theft and account takeover.
- **The cheque for €1,850.** You'd deposit it and send "the balance" to a "vendor". The cheque will bounce days or weeks later, after the bank has let you send real money. You'd owe the bank that money.
- **Other signs.** There's no named interviewer, and the "interview" is a 30-minute video call. The pay-the-supplier step is the usual way the scammer gets your money. The `hr@brennock.example` address is also a placeholder-style domain, not a real company one.

**What to do now**
1. Don't pay anything, don't send the passport photo or bank details, and don't deposit any cheque.
2. Don't argue with them. Stop replying and keep the email as evidence.
3. If you've already sent a passport photo or bank details, call your bank today and tell them. Ask about securing your accounts, and watch for identity-fraud attempts.
4. Report it to An Garda Síochána, and to the job board where you found the ad so they can remove the listing.
5. Check any employer before engaging with them. Look for a real website, a Companies Registration Office entry, and contact details you can verify independently.

The skill I'm using also tells me not to work with ID documents. Your passport isn't needed for interview prep, and no genuine employer needs it before an offer.

**Preparing for real admin interviews**
The ad's duties are calendars, travel booking, Word and Excel, and supplier invoices. Your background fits those well:
- You ran the appointment book for four physios, which is calendar management.
- You chased unpaid invoices, which links to invoice processing.
- You'd need to be ready for the "okay with Excel" gap. Expect a practical test such as formulas, a pivot table or a tidy spreadsheet.

If you send me a real job ad (or tell me the company and role) and your CV, I'll build you a full prep pack. It would cover likely questions, how to answer them from your actual experience, a plan for the Excel gap, and questions to ask the employer.

Do you have a genuine role in mind, or should I build a general pack for remote admin assistant roles from what you've told me?