**Don't pay anything or send anything yet. This email has the classic marks of a cheque-overpayment scam, and I wouldn't treat it as a real interview invitation.**

**Red flags in the email**
- **Fee to the candidate.** Real employers never charge a "registration fee" to get an interview slot. The €95 goes to an account the sender picks, and that is the first loss.
- **Passport photo and bank details before any interview.** Real employers ask for these only after a signed offer, and only through an HR system. Sending them risks identity theft and account takeover.
- **The €1,850 cheque.** This is the core of the scam. You deposit the cheque and send "the balance" to a "vendor". Days later the cheque bounces, but your transfer has already gone out. The bank takes the money back from you, not from them.
- **Smaller signs.** The contact is a `.example` address and the email contains no real contact details. Remote admin jobs that pay for your laptop up front are a common bait. The interview is only a 30-minute video call with an "office manager", and the money steps come before it.

**What to do**
1. Don't pay, don't reply with documents, and don't deposit any cheque.
2. If you already sent anything, call your bank now and ask them to stop or recall the transfer. Report it to An Garda Síochána (the fraud unit) and also to the Irish banking fraud line.
3. Check the company independently. Look it up in the CRO register (cro.ie), find its official website yourself rather than through the email, and phone a number you found there.
4. Report the email to your email provider as phishing. If you found the ad on a job board, report it there too.

If the company turns out to be real, a legitimate employer won't object to you checking. They would also drop the fee and the cheque, and interview you first.

**Interview prep for a genuine version of this role**

The duties in the ad are real admin work, so this prep applies to any similar interview. I've kept it short. I'd build the full pack only once there's a verified employer.

*What to expect:* a short video call covering your experience, a few scenario questions, and a check on your Excel level and how organised you are. A remote role will also test how well you work without supervision.

*Your strongest material:* you ran the appointment book for four physios, and you chased unpaid invoices. That covers calendar management and a good part of supplier invoicing. Prepare two or three specific stories from it, such as:
- **Scheduling conflicts.** How you handled clashes, double bookings or last-minute cancellations across four people's diaries.
- **Chasing invoices.** What you did, how you stayed polite but persistent, and any result you can state honestly.
- **Prioritising under pressure.** A busy day when several things needed you at once.

*Your gaps, and how to handle them:*
- **Excel.** Be honest that you're "okay". Say what you can already do, such as formulas, filters or tracking sheets. Then name one thing you're actively improving, like pivot tables or lookups. Brush up on those before the call.
- **Travel booking.** The clinic role probably didn't cover it. Say so plainly and bridge from related skills like itineraries, timing and detail checking. Don't claim experience you don't have.
- **Remote work.** Prepare an honest answer on how you'd stay organised and communicate when working alone.

*Questions to ask them (these also test whether the employer is real):* Who would I report to? What systems do you use for invoices and calendars? How is the role paid, and through what payroll process? Is there a written contract before I start?

I have two questions that would let me build the full pack when you're ready:
1. Did you find the ad on a job board, and did it name a real company website you can verify?
2. Have you sent anything yet, such as money, a passport photo or bank details?