# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Interviewers: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built for a panel blending a principal and two grade-level peers, as the invite states.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Rehearse aloud, in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: does past behavior show the published beliefs |
| EXP | Work-experience deep-dive: do the claims on your CV survive follow-ups |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: how current is your homework |
| CASE | A live problem from the role, answered by structuring it aloud |

Highest-ROI prep in this pack: question A1, the move from third grade to fourth. It is the likeliest objection, it will arrive in some form, and your own material states the gap plainly, so a calm, specific answer is worth more than any other rehearsal.

## Fit snapshot

No full job description was supplied. Requirements below are quoted from the invite, from the district's published beliefs (fetched, see Sources), or written as plain prose labeled generic. Evidence is your own words only. Your résumé also holds a Social Security number and a license number; neither is used anywhere in this pack.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your CV states the license, the endorsement and the active-through date in the invite's own terms. It is a CV line with nothing inspected behind it, so expect the school to verify it. Say it as written; the endorsement range in your own quote includes fourth grade |
| F2 | "Fourth Grade Teacher position" — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Third grade is adjacent to the role, and the words stay at their scope: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: the job title makes a probe on what differs between the two grades likely. If any of your third-grade work looked ahead to fourth, say what, in your own words; if none did, say so plainly and return to the six years |
| F3 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | Both sentences touch reading and neither says whether any student had a reading plan. Answer slot: the district belief makes a probe on reading plans likely. If any students you taught or worked with had one, say what it was and what part was yours; if none did, or it was not yours, say so plainly and return to the curriculum move and the reading club as you described them |
| F5 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | A weekly email is adjacent to speaking with every family, and the words stay at the email: "I write a weekly email to families." Answer slot: the belief says speaks, so a probe on conversations is likely. If any family contact went beyond the email, say what and how often, in your own words; if the email was the main channel, say so plainly and return to it |
| F6 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Your material does not show how assessment results fed your teaching. Answer slot: the belief makes a probe on assessment use likely. If results ever changed what you taught next, say what and how, in your own words; if they did not, or you did not have that role, say so plainly and say how you would use them |
| F7 | Work with a grade-level team (role-family expectation, no source) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [generic] | none | Both sentences stand together at their own scope: you led the grade level's move, and you have not been a team lead. Say each as written and do not reconcile them by adding a title |

## Reading the interviewer

Only the principal has public information. The two fourth-grade team members are unnamed, so nothing is read for them. Public professional footprint only.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page | [grounded] | Expect reading-instruction questions pitched at specialist depth, not just general ones; A1 and C3 matter most |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | Illinois principals forum speaker page | [grounded] | Small groups and conferences are likely themes; C3 rehearses a structure, and reverse question R2 asks about it |
| Mirror opportunity: her reading focus and your reading work | Your quote at F4: "I've run the after-school reading club for the last two years" | [grounded] | A shared professional theme, not a shared background. Describe the club in its own words and let her ask the next question |

## Persona table

Weights start from relationship priors (principal reads like a hiring manager: Case and Skeptic; two grade-team members read like peers: Peer Evaluator and Prober), adjusted by her reading-specialist background. The loop is one 45-minute panel, per the invite, which names who sits on it; no values-style round is documented, so the Values persona is weighted from the district's published beliefs, not from a named round.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | The principal or a teammate probes the move from third grade to fourth and the absence of a team-lead role | High: your own material states both gaps (F3, F7) and the panel includes a principal buying capability | Rehearse A1 until it is boring: hold what your quotes say, concede the gap in one plain sentence, then give a plan |
| Peer Evaluator (bank B) | Teammates ask what you need from them and what you bring them, and how you handle disagreement | High: two of three panelists are fourth-grade teachers, who will price the load a new colleague adds | Ask-then-offer; propose principles for the seam rather than pretending to know it |
| Case/Strategist (bank C) | The principal sets a live reading problem or asks about the district literacy plan | Medium-high: her reading-specialist background and conferences talk tilt cases toward reading | Clarify, then objective, then approach, then how you would know; think aloud |
| Values/Behavioral (bank D) | Questions themed on the three district beliefs | Medium: the district states three beliefs that guide every hire, but no separate values round is documented | Use the selection scaffolds; where no story comes to mind, say so plainly |
| Prober (bank E) | A teammate asks you to walk through the curriculum move and the reading club in detail | Medium: both are your headline claims and follow-ups go two levels deep | Say only what the sentence says; say plainly what you do not know |
| Conversational (bank F) | Opening biography question and a friendly craft question | Medium: panels usually open this way; it is still scored | A 90-second arc built from your own sentences |
| Pressure (bank G) | A time-boxed challenge on why you, and on how much of the move was yours | Low: nothing in the invite or her public profile signals it | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### Bank A: Skeptic (deepest rehearsal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your experience is in third grade. Why are you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade"; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | The highest-ROI rehearsal. Hold only what the quotes carry: "For six years I taught third grade at a public elementary school in Joliet," and the endorsement on your license is grades 1–6. Concede early and plainly: "I've never taught fourth grade." Then give a plan, not a past: the first things you would ask the team, and what you would look at before day one, in your own words. Follow-up 1, what will be hardest: name one real thing. Follow-up 2, why not someone who has taught it: return to the six years and the plan. Follow-up 3, what if the plan is not enough: say who you would ask and when. Answer slot: if any of your third-grade work looked ahead to fourth, say what; if none did, say so plainly and return to the six years. Never claim crossover work you did not do | F2 and F3 are the evidence and the gap; JD because the title is the requirement, Skeptic because it targets the gap |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick the true answer, not a safe one. Criteria: it is a real gap, it has one concrete first step, and there is a person or resource you would use. The gap your own material states is "I've never taught fourth grade"; you may say it in those words. If no other gap comes to mind, say so plainly and give that one | F3 is the stated gap; this is the stem a Skeptic uses to see whether you know your own |
| A3 | "You haven't been a team lead. How do you contribute to a team when you aren't the lead?" | EXP | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Hold both sentences at their own scope and do not merge them: "I've never been a team lead," and "I led our grade level's move to a new reading curriculum in 2024." For the contribution itself, pick a time you worked with colleagues without a title; it needs a named task, who you worked with, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would work with a team | F7 holds both quotes; EXP because it tests whether the curriculum claim and the no-lead claim survive together |
| A4 | "Why this school, and why now?" | JD | [grounded] "I've run the after-school reading club for the last two years" | One true reason in a sentence, in your own words; the pack does not supply your motive. If you point to the district's published belief, "Every Child a Reader", quote it as theirs. You may name the reading club in its own words as your connection; do not say what it proves | F4 is the nearest evidence; motivation-consistency is the Skeptic's score |
| A5 | "What would you do in your first month to learn fourth grade?" | CASE | [generic] | A plan, in order: who you would ask, what materials you would review, what you would watch in the team's classrooms, and how you would check your own progress. It asks about no past and claims none | The natural follow-up to A1; CASE because it is a live planning problem |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from our team in your first month, and what could you offer it?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Ask first, then offer. For the offer, pick one or two of your own sentences and say them at their scope, for example "I led our grade level's move to a new reading curriculum in 2024", and say what that would mean for this team in your own words. State no results the quotes do not carry | F4, F5 and F7 are the offers; reciprocity is what a peer scores |
| B2 | "When you disagree with a teammate about how to teach something, what do you do?" | VAL | [generic] | State your principle first, then a story only if a true one comes to mind: it needs a real disagreement, a moment you held your view, and a working relationship intact afterward. If no such time comes to mind, say so plainly and describe how you would handle it | Peers weigh disagreement style; generic because it asks for a pattern, not a fact about you |
| B3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name whose work was whose, precisely. For your own case the sentence says "I led our grade level's move". Answer slot: if colleagues did parts of the move, say who and what; if the move was not shared in that way, say so plainly and return to the sentence | F7; the stem tests attribution honesty |
| B4 | "Where is the line between what is yours to decide in your classroom and what the team decides together?" | CASE | [generic] | Offer principles, not a map you cannot know: what you would bring to the team, what you would ask before changing a shared plan, how you would raise a disagreement. Claim no past | You cannot know their seam yet; proposing principles shows you know that |

### Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your class is reading well below grade level in October. What do you do in the first two weeks?" | CASE | [generic] | Clarify first (what you would look at to understand the problem), then your objective, your approach, how you would know it is working, and the risk you would watch. Think aloud; challenge one premise politely. It claims no past | A principal who was a reading specialist is likely to set a reading problem |
| C2 | "The board adopted a literacy plan that includes a new grades 3–5 reading curriculum from fall 2027. How would you want to be part of that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what you know and how: you saw a public summary, not the plan. Then say what you would ask first. You may say your own sentence at its scope, "I led our grade level's move to a new reading curriculum in 2024", and what you would want to learn from it here, in your own words | F4 and F7 with the researched literacy plan; the CO question that most candidates will not touch |
| C3 | "How would you organize weekly reading conferences and small groups for readers at very different levels?" | CASE | [grounded] | A structure, aloud: what you need to know about the readers first, how groups form and change, what a conference holds, and how you would know it is helping. Claim no past; where you are unsure, say so | The principal's public talk covered this theme; the pack makes no claim about her views beyond that |

### Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you made sure a struggling reader had a plan." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection criteria: one student, a named stake, what you did, and what came of it. The reading club is a place to look, said as written. Answer slot: if any child in the club or your class had a reading plan, say what it was and what part was yours; if none did, say so plainly and give the nearest true thing, or how you would build one | F4; theme comes from the district's first published belief |
| D2 | "How do you keep families partners in a child's learning?" | VAL | [grounded] "I write a weekly email to families" | Start with the email in its own words. Answer slot: the district belief says each teacher speaks with every family each term; if any contact went beyond the email, say what and how often; if it was mainly the email, say so plainly, then say what you would add here | F5; the second published belief |
| D3 | "Tell me about a time assessment results changed what you taught next." | VAL | [grounded] | Selection criteria: a specific result, a change you made, and what you saw afterward. If no such time comes to mind, say so plainly, then say how you would use assessments so they inform teaching and never replace it | F6; the third published belief, with no evidence in your material |

### Bank E: Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the move to a new reading curriculum that you led." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats the sentence states: you led, it was the grade level's move, to a new reading curriculum, in 2024. Tell them in your own words and add none. Answer slot: the district belief that assessments inform teaching makes a probe on how anyone knew the move worked likely; if you tracked anything, say what and how it was counted; if nothing was tracked, or it was not yours, say so plainly and return to the move you led. Name the weakest part of anything you say before they do | F7 is your headline claim; EXP because it tests what was yours |
| E2 | "Tell me about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats the sentence states: after school, a reading club, run by you, for two years. Answer slot: the belief that every child is a reader makes a probe on how readers were chosen or followed likely; if you did either, say how; if not, say so plainly and return to the club as described | F4; EXP because a teammate will test the claim |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc in your own words, using these sentences in order: the six years, the curriculum move, the club, the email. Close with why this role, in your own words; the pack does not supply your reason | Biography questions are scored; F2, F4, F5 and F7 supply the beats |
| F2 | "What does a good reading block look like to you?" | CASE | [generic] | Say what you believe, in a few concrete details, and one trade-off you accept. It claims no past | A casual craft question that checks genuine interest |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why should we hire you for fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Pause, restate the question, then two beats: your license and endorsement as written, and the six years in third grade. Concede in one clause that fourth grade is new to you, then say your plan. Do not fill the time with claims | F1 and F2; time-boxed composure is what is scored |
| G2 | "That curriculum move — how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold: "I led our grade level's move." Hold through two follow-ups by returning to the sentence, never by adding to it. Concede specifically: it was the grade level's move, and you have not been a team lead. Answer slot: if particular decisions were yours, say which; if they were shared, or not yours, say so plainly | F7; the standard attribution probe |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 License and endorsement | G1; none beyond it, because the material shows the gate met and a probe is unlikely |
| F2 and F3 Fourth Grade Teacher | A1, A2, A5, G1 |
| F4 Every Child a Reader | D1, E2, C1, C3 |
| F5 Families Are Partners | D2, B1 |
| F6 Teach for Tomorrow | D3, E1 |
| F7 Grade-level team | A3, B1, B2, B3, B4, E1, G2 |

## Reverse questions

| # | Question to ask | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you want reading to look like in fourth grade here?" | Ties to her own path and signals you researched her, not only the school | [grounded] |
| R2 | "Your talk covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade day at Halvering, and what support would a new teacher have?" | Shows you read her work and asks about the real job | [grounded] |
| R3 | "The board's literacy plan includes a new grades 3–5 reading curriculum from fall 2027. How will fourth-grade teachers be involved before then?" | Current, specific, and about the team's work | [grounded] |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two peers on the panel | [generic] |
| R5 | "The plan includes a family reading night each term. Who runs it at Halvering, and where would a new teacher fit?" | Connects to the district's family belief and to what you would do | [grounded] |
| R6 | "What would a strong end of the first semester look like for this role?" | Shows you are thinking about results and lets you hear how they define them | [generic] |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade | Negative you stated, F3 | "I've never taught fourth grade." Then a plan, no past |
| Having been a team lead | Negative you stated, F7 | "I've never been a team lead." Say it beside your other sentence, never merged with it |
| Leading the curriculum move as a team lead with authority over colleagues | Inflated form of F7 | F7's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024". Your material says the grade level's move, and separately that you have not been a team lead |
| Every student you taught or worked with had a reading plan | Inflated form of F4 | F4's quotes at their own scope: the curriculum move and the reading club as you described them. Your material does not show reading plans |
| Speaking with every family each term | Inflated form of F5 | F5's quote: "I write a weekly email to families". Your material says the email, not conversations |

## Sources

Provided documents: the interview invite; your résumé text as pasted (an SSN in it was not used).

Searches and fetches sent, with what came back:

- Search: "Orrinsford Community School District mission values" — returned https://orrinsfordschools.example/about/mission-and-beliefs
- Fetch: https://orrinsfordschools.example/about/mission-and-beliefs — the three published beliefs, quoted in F4 to F6
- Search: "Halvering Elementary School Orrinsford fourth grade teacher" — no results
- Search: "Dolores Vantongeren principal Halvering Elementary" — returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- Fetch: https://ilprincipalsforum.example/speakers/dolores-vantongeren — her role since 2022, nine years as a reading specialist, the 2025 talk
- Search: "Orrinsford Community School District strategic plan reading initiative news" — returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (search snippet only; the page itself was not fetched)

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | Fit rows F4 to F6 and the VAL questions D1 to D3, named by the district's own wording |
| 2. `Orrinsford interview process teacher` | skipped | The invite names one 45-minute panel and who sits on it, which fixes the persona weights and the session |
| 3. `Orrinsford strategy / recent news` | yes | Question C2 and reverse questions R3 and R5; from a search snippet, not the full page |
| 4. `Dolores Vantongeren Halvering` | yes | The interviewer read, C3, R1 and R2 |
| 5. representative `Fourth Grade Teacher` JD | yes | One search for the school's posting returned no results; it moved nothing, so the fit snapshot rests on the invite and the district's published beliefs |

## Upgrade menu

- The full job posting → the generic row F7 and the role-family parts of the banks become grounded on the posting's own lines, and the requirement coverage table can be checked against its list
- Whatever the school said about what the panel will cover, or anything they asked you to prepare → coverage of any graded task
- The names and roles of the two fourth-grade team members → a per-member interviewer read and sharper persona weights
- Your own answers to the answer slots (what changed between third and fourth grade, reading plans, family conversations, how assessment results fed your teaching) → rows F2 and F4 to F6 upgrade from slots to quoted evidence
- A document that backs your claims, such as a performance evaluation or the curriculum adoption memo from your school → confidence on F4 and F7 can rise from medium
- An earlier `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims you have already settled
