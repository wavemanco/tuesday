# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Thursday, 45-minute panel: Principal Dolores Vantongeren and two members of the fourth-grade team. Round type: panel; the principal is read as a hiring-manager relationship and the two teachers as peers.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding for your own words, not a script. An "Answer slot" is an instruction for the interview: say what you did if you did it, or say plainly that you did not, and nothing in this pack supplies the answer.

Highest-ROI prep: **A1**, "You've never taught fourth grade." It is the question your own material makes most likely, and the one a rehearsed, non-defensive answer changes most.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your resume lines hold up when probed |
| JD | The stated requirements of the role, gaps included |
| CO | Knowledge of the district and its current plans |
| CASE | A live problem from the actual job, reasoned aloud |

## Fit snapshot

Requirement sources: the invite from Human Resources, the district's published pages, and one representative posting from a jobs board (a search summary only, so those rows are labeled inferred). No posting for this specific role was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, so it routes like any other row. Say it in the quote's own terms: an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. It is a CV line with nothing inspected behind it, so keep your license record to hand |
| F2 | "Fourth Grade Teacher position" — your invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | low | [grounded] | transferability | Your material shows third grade, not fourth, and the words do not close that. Say it plainly: "I've never taught fourth grade." Then the other sentence at its own scope: six years teaching third grade at a public elementary school in Joliet. Anything about how you would ramp up is a plan, said as a plan, never as a past |
| F3 | "reading instruction" — district hiring page (panel topics) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | low | [inferred] | discovery | Your material says a curriculum move and a club, not how reading is taught in your own room each day. Answer slot: the district's first belief, Every Child a Reader, makes a probe on your daily reading instruction likely. If you taught reading to your own class, say how you structured it, in your own words; if reading was taught another way, or not by you, say so plainly and stay with the curriculum move and the club |
| F4 | "classroom routines" — district hiring page (panel topics) | none given | none | [inferred] | discovery | Your material is silent on routines. Answer slot: the hiring page lists routines among the panel's topics. If you set routines in your own class, say which and what they were for, in your own words; if you did not, or they were set for you, say so plainly and describe how your class ran |
| F5 | "how you work with families" — district hiring page (panel topics) | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap. Lead with the email in the quote's own terms: you write a weekly email to families. Expect a probe on what it covers; the quote says only that it is weekly and goes to families |
| F6 | "each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families" — your CV | low | [grounded] | transferability | The belief is speaking with families; your quote is an email. The words stay at "I write a weekly email to families." Answer slot: if you are in touch with families in other ways too, say how, in your own words; if the email is the main channel, say so plainly |
| F7 | "assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [inferred] | discovery | Your material is silent on assessment. Answer slot: expect a probe on a time results changed what you taught. If results changed your plans, say what you saw and what you changed; if they did not, or the plans were not yours to change, say so plainly and say how you would use them |
| F8 | "work with the grade-level team" — representative posting, jobs board search summary | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | Keep the two sentences side by side, because one says you led a move and the other says you have not held a lead role. Words: "I led our grade level's move to a new reading curriculum in 2024." The quote does not say who worked with you or how the move went, so nothing is added |

## Reading the interviewer

Public professional footprint only. The two teachers on the panel are unnamed, so no read exists for them.

| # | Finding | Provenance | What it means for you |
|---|---|---|---|
| R1 | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] Illinois principals forum speaker page, search summary | Expect reading to be asked about with depth, from someone whose earlier career was reading |
| R2 | A 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | [grounded] same page, search summary | Small-group and one-to-one reading time is a likely theme; B1 is built around it |
| R3 | Mirror opportunity: shared vocabulary of reading. Pair her reading focus with F3's sentence "I've run the after-school reading club for the last two years" — your CV | [grounded] R1 and F3 | Say the sentence as written; do not add what happens in the club unless it is yours to say |

## Persona table

The loop is one 45-minute building panel of the principal and two grade-level teachers (district hiring page), so no archetype fallback is used.

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | "You've never taught fourth grade"; why leave third, why now | Highest, 5 questions. Your material states two negatives (F2, F8), and the principal's relationship prior is Case plus Skeptic | Rehearse A1 until it is boring: acknowledge plainly, state the third-grade sentence at its own scope, then a ramp plan said as a plan; hold through two follow-ups |
| Case/Strategist (B) | Live reading and routines problems; a question on the district's literacy plan | Medium, 3 questions. Hiring-manager prior; the hiring page lists reading and routines as panel topics; R2 | Clarify first, then objective, grouping, approach, how you would check progress, how the family hears about it |
| Peer Evaluator (C) | Two teammates asking about fit, disagreement and credit | Medium, 3 questions. Peer prior; the invite names two team members; no footprint for them | Offer what you would bring, not only what you need; credit with "we" for context and "I" for your part |
| Values/Behavioral (D) | Questions built on the three published beliefs | Medium, 3 questions. The district says the beliefs guide every hire; no source documents a separate values round | A story where one of your sentences carries it; a selection scaffold where none does |
| Conversational (E) | The opening "walk me through your journey"; a license check | Low, 2 questions. Easy to prepare, but scored | A 90-second arc built only from your quoted sentences |
| Data-Driven Prober (F) | Line-by-line questions on the curriculum move and the club | Low, 2 questions. Your material has no figures to probe | Know where your part ends and say so plainly |
| Pressure (G) | A time-boxed "why you" and a "how much was you" | Low, 2 questions. No source describes a stress format | Pause, restate, hold the position, concede only what is true |

## Question banks

20 questions. The three beliefs theme bank D; no values-style round is documented by any loop source, so there is no separate values cheat sheet.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What will be hardest for you in your first month?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Highest-ROI. Acknowledge first: "I've never taught fourth grade." Then the sentence at its own scope: six years teaching third grade at a public elementary school in Joliet. Then a plan, said as a plan: name two things you would want to learn from the team in your first weeks, in your own words. Follow-up one, "What do you know about the grade?": say what you actually know and, if it is little, say so and say what you would ask. Follow-up two, "Why not someone who has taught it?": concede specifically, "I don't yet know fourth grade from the inside, and that is a real difference," then hold the third-grade sentence without adding to it | F2 is where the invite's own title presses against your stated negative, so this arrives in some form. JD because it scores the role as posted |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead" | Choose one weakness that is true for you. Your two stated negatives are available in their own words if one is the honest answer. Say it, then one concrete step you would take, as a plan. Do not pick a weakness only because it sounds safe | F2 and F8 are the places your material says no, so this stem lands there. JD because it scores honest self-assessment against the role |
| A3 | "Why leave third grade after six years, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Say your real reason in your own words; the pack supplies none. Keep the six years as written, and keep it free of criticism of your current school. If your reason is about this district or this grade, say what draws you in terms you can stand behind | F2: a switch of grade after six years invites a motivation probe. EXP because it tests the story behind a resume line |
| A4 | "What drew you to Orrinsford, and to Halvering specifically?" | CO | [grounded] "I write a weekly email to families" | Name the one belief that matters to you of the three the district publishes: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Say what you do, at its own scope: "I write a weekly email to families." That is an email, not the belief's every-family conversation each term, so do not claim the belief as met. Add one thing about the August literacy plan only if you have read it | F5 and F6. CO because it scores homework on the district's own published words |
| A5 | "You haven't been a team lead. How do you step into a team that already has its own ways of working?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Acknowledge: "I've never been a team lead." Then the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not stretch either. Then a plan, as a plan: what you would ask the team for in your first weeks and what you would leave as it is | F8 holds both sentences, and an interviewer may press the gap between them. JD because the posting-style requirement is working with the grade-level team |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A fourth grader reads well below the rest of the class and does not say so. Walk me through your first two weeks of reading time with that child." | CASE | [generic] | Clarify before you structure: what the assessments show, what is already in place, who else works with the child, what the family knows. Then the objective, how you would group or confer with the child, how you would check progress, and how the family hears about it. The district's third belief says assessments inform teaching and never replace it, so show your own judgment alongside any data. Think aloud | The principal's public talk covered small groups and reading conferences (R2), so a reading case is likely. CASE because it asks about no past |
| B2 | "It is the first week of school. What routines do you set up, and why those?" | CASE | [generic] | Pick routines you would actually run and say why in your own words; the pack names none. Say what each is for, and what you would watch for in week one. If you would ask the team how they run it, say that too | F4. The hiring page lists classroom routines as a panel topic. CASE because it is a live problem with no claim about your past |
| B3 | "Our board adopted a literacy plan this August. What stood out to you?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say the plan in the district's terms: a three-year literacy plan with structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Fourth grade sits inside grades 3–5, so ask what the team's part is between now and then. Connect your sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Read the full page before Thursday; this pack saw only its summary | The plan is the district's newest published strategy. CO because it scores whether you can talk at the district's altitude |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about a time you and a teammate disagreed about how to teach something." | VAL | [generic] | Selection scaffold: pick a real disagreement with a named point of difference, what you did, and how the working relationship stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's stem on disagreement between equals; two teammates sit on the panel. VAL because it scores partnership behavior rather than a requirement |
| C2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for the context and "I" for your part, and let the sentence carry your part: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if pressed on which parts were yours and which were colleagues', say what was yours and what was theirs in your own words; if you cannot separate it, say so plainly | F8. EXP because the credit stem is an attribution probe in collegial dress |
| C3 | "What would you bring our team?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Offer, then ask. Name what you have done, at its own scope: you have run the after-school reading club for the last two years, and you write a weekly email to families. Then ask what the team would find useful. Do not describe what happens in either unless it is yours to say | F3 and F5. The peer persona prices what the hire adds to the team's work. JD because it scores fit with the grade-level team |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our first belief is Every Child a Reader: no student leaves third grade without a reading plan. Tell us about a time a student was not reading where they needed to be." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: a time with a student described without identifying details, what you saw, what you did, what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I've run the after-school reading club for the last two years." Answer slot: if a reading plan was written for a student, say what it held and who wrote it; if your school had no such plan, or it was not yours, say so plainly | F3. The belief and the principal's reading background make this the most likely values question. VAL because it scores a published belief |
| D2 | "Families Are Partners: each teacher speaks with every family each term. How do you keep families in the loop?" | VAL | [grounded] "I write a weekly email to families" | Start with the sentence: "I write a weekly email to families." Answer slot: expect a probe on how else you are in touch with families; say what other contact there is, in your own words, if any, and if the email is the main channel, say so plainly. Do not claim the belief's wording as your practice | F5 and F6. VAL because it scores a published belief |
| D3 | "Teach for Tomorrow, Not for the Test: tell us about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: a specific result, what you decided because of it, what you taught differently. If no such time comes to mind, say so plainly, then say how you would use results to inform a plan | F7. VAL because it scores a published belief; the label stands alone because no sentence of yours speaks to it |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey: how did you get here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc in this order, each sentence as written: six years teaching third grade at a public elementary school in Joliet; leading your grade level's move to a new reading curriculum in 2024; running the after-school reading club for the last two years; the weekly email to families. End with why fourth grade and why Halvering, in your own words; the pack supplies no reason | The biography question is near-certain and casual in tone but scored. F2, F3, F5 and F8 supply the sentences |
| E2 | "We see you hold an Illinois license with an elementary endorsement. Can you tell us the grades it covers?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as written: an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. Keep it short, and have your license record where you can find it | F1, the invite's stated requirement. JD because it scores the posted qualification |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through what you did to move your grade level to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell it with the beats the sentence states: your grade level, a new reading curriculum, 2024, and that you led the move. Use your own words for anything you can stand behind. If a follow-up goes past what you did, say so plainly and return to the part you led | F8 and F3. EXP because it checks what was actually yours |
| F2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Beats the sentence states: after school, a reading club, the last two years, and you run it. Say what a meeting is like only in your own words and only what is true. If asked about numbers or outcomes you do not have, say so plainly | F3. EXP because it tests a resume line a prober can read aloud |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade"; "I've run the after-school reading club for the last two years" | Pause and restate. Hold: six years teaching third grade at a public elementary school in Joliet, and you have run the after-school reading club for the last two years. Concede one true thing: "I've never taught fourth grade." Do not fold on the core, and do not claim what the quotes do not carry | F2 under time pressure. JD because it scores the same requirement as A1 |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence: "I led our grade level's move to a new reading curriculum in 2024." If pressed twice, say what was yours and what was colleagues' in your own words; if you cannot separate it, say so plainly. Conceding a specific limit is stronger than a claim you cannot repeat | F8. The attribution stem from the pressure persona. EXP because it checks what was yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Illinois license with elementary endorsement (F1) | E2 |
| Fourth Grade Teacher position (F2) | A1, A2, A3, G1 |
| Reading instruction (F3) | B1, B3, D1, F1, F2 |
| Classroom routines (F4) | B2 |
| Working with families (F5, F6) | D2, A4 |
| Assessment informing teaching (F7) | D3, B1 |
| Working with the grade-level team (F8) | A5, C1, C2, C3 |
| Teaching math, science and social studies (representative posting only) | none, and why: only the posting summary names it, and neither the invite nor the district pages do; the full posting would turn this into a row |
| Team-lead experience | none, and why: no source asks for it; A2 and A5 cover it only because your own material raises it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to the principalship after years as a reading specialist. How does that show up in how fourth grade teaches reading here?" | Ties to the principal's own path (R1) and shows you read about her |
| 2 | "The new grades 3–5 reading curriculum starts in fall 2027. What does the fourth-grade team's part look like between now and then?" | Shows you read the board's plan and asks about the team's real work |
| 3 | "What could a new teacher on the team do in the first month that would really help you?" | Reciprocity question for the two teachers on the panel |
| 4 | "What does a strong first quarter look like for someone new to fourth grade?" | Turns your stated gap into a question about support, not a defence |
| 5 | "How does family reading night fit into a fourth-grade teacher's year?" | Grounded in the plan's family reading night each term |
| 6 | "What are the next steps, and when should I expect to hear?" | The hiring page says references come after the panel, so it is a natural close |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | A negative you stated: "I've never taught fourth grade" — your message | The plain acknowledgment, "I've never taught fourth grade," plus "Six years teaching third grade at a public elementary school in Joliet" at its own scope. No slot |
| Has been a team lead | A negative you stated: "I've never been a team lead" — your message | The plain acknowledgment, "I've never been a team lead," beside "I led our grade level's move to a new reading curriculum in 2024" at its own scope. No slot |
| Chose, designed or rolled out the new reading curriculum, or trained colleagues on it | Inflated form of F8 and F3's "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope. The limit is the pack's observation: your material says you led the move, not what the move involved |
| Founded or built the reading club | Inflated form of F3's "I've run the after-school reading club for the last two years" | The quote at its own scope: you run it, and it has been the last two years |
| Speaks with every family each term | Inflated form of F5 and F6's "I write a weekly email to families" | The quote at its own scope. The limit is the pack's observation: your material says an email, not a conversation with every family |

## Sources

Provided: the invite from Human Resources and the resume text you pasted (it contained an identification number, which was not used and is not in this pack). No `tuesday-dossier.md` was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{district} values` | yes | The three published beliefs by name; themes bank D and fit rows F6 and F7 |
| 2. `{district} interview process {role family}` | yes | Loop structure: one 45-minute building panel; persona weights and F3 to F5 |
| 3. `{district} strategy` / recent news | yes | The August 2026 literacy plan; B3 and reverse questions 2 and 5. Search summary only; the page itself was not opened |
| 4. `{interviewer name} {district}` | yes | The interviewer read, R1 to R3. Search summary only |
| 5. representative `{role title}` posting | yes | F8 and the coverage table's last two rows. The summary was cut off before the qualifications, so none from it are used |

Queries and results:

- "Orrinsford Community School District values mission": https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process": https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news": https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary School": https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "fourth grade teacher job posting Illinois elementary school responsibilities qualifications": https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/careers/how-we-hire-teachers. The hiring page is treated as the district's own statement of what its panel asks; it carries no date.

## Upgrade menu

- The full posting text → the inferred requirement rows (F3, F4, F8) become grounded, and the teaching-subjects row gets questions
- Anything HR said about what to bring or prepare, such as a sample lesson → a build section for that deliverable
- The names of the two fourth-grade teachers → persona weights and a tailored reverse question for each
- Your license record as the state shows it → F1 moves from medium toward high
- Your own answers to the slots in F3, F4, F6 and F7 → those rows move from discovery to grounded evidence, and the matching bank answers become story-mapped
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → the district's strategy and the principal's talks read from the pages themselves, not search summaries
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence and a worked list of objections; never a prerequisite
