I'll read the skill's reference files before building the pack.
I've finished the research (4 searches, 2 page fetches) and am now writing the prep pack to a file.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has a fit snapshot, a persona table, 21 questions with answer guidance, six reverse questions and a sources section.

Your resume text included an SSN. Interview prep doesn't need it, so I didn't use it and it isn't in the pack. I'd keep it off anything you send the school unless they ask for it through an application system.

You didn't send a job description, so I built the pack on a few assumptions:
- **Panel roles:** I treated Principal Vantongeren as the decision-maker and the two team members as peers, because the invite doesn't say.
- **Requirements:** I used a typical fourth-grade posting I found online, not Halvering's own. Rows built on it are marked `[inferred]`.
- **Research:** I found the district's three published beliefs, its August 2026 literacy plan, and the principal's background. She was a reading specialist for nine years. Her 2025 talk covered weekly reading conferences in grades 3 to 5.

The question most worth rehearsing is A1: you're coming from third grade, so what would be weakest on day one. The pack builds that answer from your own sentences, "I've never taught fourth grade" and your six years in third grade. A2 is next, on how much of the 2024 curriculum move was actually you, given that you've never been a team lead.

Several answers in the pack are fill-in slots, not scripts. Where your resume doesn't say what you did, such as assessment data, classroom routines or reading plans, the pack asks you to answer in your own words or say plainly that it wasn't part of your work.

Say the word and I'll play the Skeptic on A1 so you can practice out loud.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the full job posting? Pasting it would turn the `[inferred]` rows into rows grounded in the posting itself.
2. Did HR say anything else about Thursday, such as a demo lesson, a portfolio, or the names of the two team members?
3. Want a deeper research pass on the district and the principal? It's up to 6 more searches and 2 more fetches, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team. Prepared for Grace. Built on one assumption: the principal is the hiring authority and the two team members are peers, because the invite does not say. Persona weights follow it.

## How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Does past behavior show the district's published beliefs |
| EXP | Do the claims in your CV survive a follow-up; what was actually you |
| JD | Can you do the listed job, gaps included |
| CO | Do you know the district's current direction |
| CASE | A live problem from the role, reasoned out loud |

Provenance labels: `[grounded]` traces to your documents or to research cited in Sources; `[inferred]` is derived from a representative posting or an adjacent source; `[generic]` is a role-family pattern with no claim about you or this school. Where guidance rests on something you said about yourself, the quote sits beside the label.

The single highest-ROI prep in this pack is **A1**, the question about moving to fourth grade from third. It will be asked in some form. A2 is second.

## Fit snapshot

No job description was supplied. Rows F1 to F3 use the invite's own words. Rows F4 to F8 use a representative fourth-grade posting (K12 Jobs Board, not this school's) and are `[inferred]`. Rows F9 to F11 use the district's published beliefs.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap, but a CV line with nothing inspected behind it, so expect it to be verified. Lead with it in the quote's own terms: the Illinois Professional Educator License with the Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. The grade range in the quote includes fourth grade |
| F2 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |
| F3 | "Fourth Grade Teacher position" — the invite (adjacent evidence) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Keep it at its scope: six years teaching third grade at a public elementary school in Joliet. Your material says third grade, not fourth, so the step to fourth is an answer slot: if you have worked with fourth graders in any setting, say where and what you saw; if not, say so plainly and stay with the third-grade years |
| F4 | "differentiate instruction using assessment data" — K12 Jobs Board representative listing | none given | none | [inferred] | discovery | Your material is silent on how assessment results shaped your teaching, so this is a question and not a bridge. Answer slot: expect a probe on assessment data and differentiation. If results ever changed what you taught a group next, say what they showed and what you changed, in your own words; if that was not part of your practice, or was set by others, say so plainly and describe what you did instead |
| F5 | "communicate regularly with families" — K12 Jobs Board representative listing | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you write a weekly email to families. A named, regular practice beats an adjective |
| F6 | "work with the grade-level team" — K12 Jobs Board representative listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | none | The quote is the move, and the words stay there: "I led our grade level's move to a new reading curriculum in 2024." You have also said you have never been a team lead, so expect A2. Hold the sentence and add nothing to it |
| F7 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board representative listing | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | The quote gives grade and years, not subjects. Answer slot: expect a probe on which subjects you planned and taught. Say which, in your own words; if any were taught by someone else, or you did not plan them, say so plainly and stay with the third-grade years |
| F8 | "keep clear classroom routines" — K12 Jobs Board representative listing | none given | none | [inferred] | discovery | Your material is silent on routines. Answer slot: the posting names them, so expect a probe. If you set routines in your room, say how, in your own words; if the school or team set them, or you did not use them, say so plainly and describe how you ran the room |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford Mission and Beliefs page | "I've run the after-school reading club for the last two years" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | The club and the curriculum move touch reading but do not show reading plans. Words: "I've run the after-school reading club for the last two years" and "I led our grade level's move to a new reading curriculum in 2024", each at its own scope. Answer slot: the belief puts reading plans on third-grade teachers, so expect a probe on them. If any of your students had a reading plan, say whose it was and what part was yours; if your school did not use them, or they were not yours, say so plainly and stay with the club and the curriculum move |
| F10 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The belief says speaks with every family, and the quote is an email. Words: "I write a weekly email to families." Answer slot: expect a probe on conversations. If you spoke with families directly, say how often and about what; if all contact was the email, say so plainly and stay with the email |
| F11 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you ever set a score aside, or used a result to decide your next step, say what and why; if not, say so plainly and say what you would use a result for |

## Reading the interviewer

Only the principal has a public footprint I could attribute. The two team members were not named, so nothing is read about them.

| Fact (source) | Provenance | What it means for you |
|---|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist (ilprincipalsforum.example speaker page) | [grounded] | Expect reading instruction to be examined closely and in specifics. See C1 and A3 in the banks below |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 (same page) | [grounded] | Small-group reading and one-to-one conferences are her vocabulary. Use the words when they describe what you would really do, and do not claim a conference practice you did not run |
| Shared ground with your own path | [grounded] | No shared career jump. The shared ground is reading work only: "I've run the after-school reading club for the last two years" (F9), offered as is |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | The principal probing the move from third to fourth and your team role | High. The invite is for a fourth-grade role and you stated both gaps (F2, and the team-lead negative in the prohibited list). A hiring-authority prior pairs Skeptic with Case | Rehearse A1 until it is boring. Bridge only from what your sentences say, and say the limit plainly |
| Peer Evaluator (bank B) | The two fourth-grade team members asking how you would fit | High. Two of three panelists are on the team you would join, and the peer prior is Peer Evaluator plus Prober | Offer reciprocity: what you would bring and what you would ask. Propose seam principles, not a pretended knowledge of their seam |
| Case/Strategist (bank C) | The principal setting a live reading or classroom problem | Medium. Hiring-authority prior, tilted toward reading by her reading-specialist background and talk (see the interviewer read) | Clarify, then structure, then answer, thinking aloud; challenge one premise politely |
| Values/Behavioral (bank D) | Questions themed on the district's three published beliefs | Medium. The district page says the beliefs guide every hire, so they will theme questions. No loop source names a dedicated values round, so no values cheat sheet is included | Pick a real instance per belief if one comes to mind; use the honest branch if none does |
| Conversational (bank E) | The opener and warm, casual questions | Medium. Panels open with a biography question, and casual questions are still scored | A 90-second arc built only from your own sentences |
| Data-Driven Prober (bank F) | A team member asking you to walk a CV line step by step | Medium-low. Your CV holds no figures to probe, so the probing falls on process claims | Know which parts of each line were yours and say plainly what you do not recall |
| Pressure | Time-boxed, adversarial challenges | Low. No signal in the invite or the interviewer's public material points to a stress style, so it has no bank | Not needed beyond the hold-then-concede moves in bank A |

## Question banks

Requirement coverage first.

| Requirement | Questions |
|---|---|
| F1 licence | none, because it is a document check and not an interview probe; the licence line is part of the E1 arc |
| F2, F3 fourth grade | A1, A5 |
| F4 assessment data | A3, D3 |
| F5, F10 families | B4, D2, F5 |
| F6 grade-level team | A2, B1, B2, B3, F1 |
| F7 subjects | F3 |
| F8 routines | C4 |
| F9 reading plans | A4, D1, C1 |
| F11 not for the test | D3 |
| District literacy plan (research) | C2, C3, B4 |

### A. Skeptic (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're coming from third grade. Which part of fourth grade would you be weakest at on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Say it in this order. First the plain statement: "I've never taught fourth grade." Then what you carry, at its scope: six years teaching third grade at a public elementary school in Joliet. Then a plan, said as a plan: two things you would ask the fourth-grade team in your first week, in your own words. Follow-up one: "What's different about fourth graders?" Answer slot: if you have worked with fourth graders in any setting, say where and what you saw; if not, say so plainly and say what you would ask the team. Follow-up two: "Why not hire someone who's taught it?" Hold by returning to the sentence above and add no proof. Concede the specific limit: the team knows the grade firsthand and you do not | F2 is the capability gap, and F3 is the only adjacent evidence, so this is the objection the panel is most likely to open on. JD because it scores the stated role |
| A2 | "Your grade level moved to a new reading curriculum in 2024. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold this sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say in your own words what leading it involved and which parts were shared or someone else's; if you did not set or choose parts of it, say so plainly and stay with the sentence. If asked about a title, the plain answer is "I've never been a team lead." Hold through two follow-ups by returning to the sentence, never by adding to it. Concede specifically the part you would not claim | F6 is where the sentence and the team-lead negative meet, so the principal can test the gap between "led the move" and a title. EXP because it tests attribution |
| A3 | "Tell me about a time assessment results changed what you did next with a group of students." | JD | [grounded] | Open prompt, so pick the instance. Criteria for a good one: a named group, what the results showed, what you changed, what happened after. Nothing in your material carries one, so none is supplied here. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 and F11 are silent in your material, and the district's third belief makes this a likely question. JD because it scores the posting-style requirement, with a VAL edge |
| A4 | "Our first belief is that no student leaves third grade without a reading plan. You taught third grade. What did a reading plan look like in your room?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if any of your students had a reading plan, say whose it was and what part was yours, in your own words; if your school did not use them, or they were not yours, say so plainly and return to the club and the curriculum move, each at its own scope | F9 is a transferability row, and the premise comes from the district's published belief, so the slot lets it be false. VAL because it is the first belief by name |
| A5 | "Why fourth grade, and why Halvering, and why now?" | JD | [generic] | A motivation question, so the pack supplies no reason. Say your own reason for fourth grade in one sentence. Then point to one thing that is published about Halvering or the district, only if you have read it. If the reason is mostly that you want a change, say so plainly | F2 makes the motivation question likely. JD because it scores role fit, and the Skeptic persona asks it by stem |

### B. Peer Evaluator (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans together. What would you need from us in your first month, and what would you bring?" | JD | [grounded] "I've never taught fourth grade"; "I led our grade level's move to a new reading curriculum in 2024"; "I write a weekly email to families" | A reciprocity answer. What you need: say it as questions, such as what the team already shares and what is left to each teacher. What you bring, at their scope: "I led our grade level's move to a new reading curriculum in 2024" and "I write a weekly email to families", offered as things you could talk through if useful. Do not say what either would prove | F2 and F6 are what a peer is pricing. JD because the team is judging the day-to-day fit |
| B2 | "Tell me about a time you disagreed with a colleague on your grade-level team." | VAL | [generic] | Open prompt. Nothing in your material carries a disagreement, so none is supplied. Pick an instance with a named disagreement, what you said, and an intact working relationship after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 is the team-work row, and disagreement style with equals is what a peer scores. VAL because it tests behavior, not a published belief by name |
| B3 | "Where's the seam between your classroom and the team's shared plan, and what happens when you disagree with the team?" | JD | [generic] | Offer principles, not a pretended knowledge of their seam: what you would expect to share, what you would keep as yours, and how you would raise a disagreement. Ask them where their seam is. You have never held a lead role, so do not describe one | F6 and the prohibited list cover this ground. JD because it scores how you work inside a team's plan |
| B4 | "Every school now holds a family reading night each term. What would you bring to that at fourth grade?" | CO | [grounded] "I write a weekly email to families" | The premise is the board's August 2026 literacy plan (see Sources), not your history. Say what you would want to know first, such as who runs the night and what fourth grade owns. What you bring, at its scope: "I write a weekly email to families." Answer slot: if you have taken part in a family event at school, say what your part was, in your own words; if you have not, say so plainly and stay with the email | F5 and F10 are the family rows, and the plan makes this a current question. CO because it uses the district's own direction |

### C. Case/Strategist (weight: medium, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student joins your fourth-grade class in October reading well below grade level. Walk me through your first four weeks." | CASE | [generic] | Clarify first: what the student's assessment history shows, whether a reading plan came from third grade, what the family already knows. Then the objective, the approach in plain terms (small-group time, short check-ins with the student), how you would know it is working, and who you would involve. Use the principal's own words only where they describe what you would really do. Make no claim about your past, because the question needs none | F9 is the reading-plan row, and the principal's reading background tilts cases toward reading. CASE because it is a live problem |
| C2 | "The board adopted a three-year literacy plan in August 2026. What do you take from it for a fourth-grade classroom?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The plan, per the district's news page (see Sources): structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Say what you would ask first, such as what changes for fourth grade in 2027 and what the team's part is. Answer slot: if you want to draw on your 2024 move, say in your own words what it taught you; if it did not teach you anything you can apply here, do not stretch it | F6 is the closest evidence to the 2027 change. CO because it tests current strategy, which most candidates cannot touch |
| C3 | "Your team is adopting a new curriculum and some members dislike it. How do you help it land?" | CASE | [generic] | Structure it: what you would ask first, what you would do in your own classroom, how you would raise concerns with the team, and what you would record. Answer slot: if your 2024 move had a comparable moment, say what happened and what part was yours; if it did not, say so plainly and answer as a plan | F6 and the 2027 curriculum change make this plausible. CASE because it is a live problem |
| C4 | "It's the second week of school and transitions are chaotic. What do you do?" | CASE | [inferred] | The posting names routines, so expect a probe on them. Structure: what you would watch, what you would change first, how students learn the new routine, and how you would check it holds. Nothing in your material carries a routine, so none is supplied. Answer slot: if you have a routine you would reuse, name it in your own words; if not, say so plainly and answer as a plan | F8 is silent in your material. CASE because it is a live problem, `[inferred]` because the requirement comes from a representative posting |

### D. Values/Behavioral (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader. Tell me about a time you made sure a struggling reader did not fall behind." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Open prompt. Criteria for a good instance: a named student without identifying details, what you noticed, what you did, what changed. Nothing in your material carries one, so none is supplied. The nearest thing your material carries is the club, at its scope: "I've run the after-school reading club for the last two years." If no such time comes to mind, say so plainly, then give that or how you would handle it | F9 is the transferability row for this belief. VAL because it maps to the first published belief by name |
| D2 | "Families Are Partners. Tell me about a time a conversation with a family changed what you did." | VAL | [grounded] "I write a weekly email to families" | Open prompt. Nothing in your material carries a conversation, so none is supplied. Criteria: what the family said, what you changed, what followed. At its scope: "I write a weekly email to families." If no such time comes to mind, say so plainly, then give the email or how you would handle it | F10 is the transferability row for this belief. VAL because it maps to the second belief by name |
| D3 | "Teach for Tomorrow, Not for the Test. Tell me about a time you set a score aside to do what a student needed." | VAL | [grounded] | Open prompt. Nothing in your material carries one, so none is supplied. Criteria: the score, what it said, what you did instead, and what you would tell a colleague. If no such time comes to mind, say so plainly, then say what you would use a result for | F11 and F4 are silent in your material. VAL because it maps to the third belief by name |

### E. Conversational (weight: low-medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey to this point." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc made of those sentences, in order: the licence and endorsement; six years teaching third grade at a public elementary school in Joliet; leading your grade level's 2024 move to a new reading curriculum; the after-school reading club; the weekly family email. End on why fourth grade, in your own words. Add nothing the sentences do not say | F1 to F6 are the arc. EXP because it tests whether the story matches the CV |
| E2 | "What's going on in your after-school reading club these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Casual, but scored. Describe the club in your own words. Answer slot: say which parts of it were yours to decide; if the programme was set for you, say so plainly and describe how you ran it. Keep it to what you ran | F9 is the evidence, and the question tests whether you can talk about it unprompted. EXP because it checks the CV line |

### F. Data-Driven Prober (weight: low-medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through how your grade level's 2024 move to a new reading curriculum went, start to finish." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Walk it in the order it happened, using "we" for the grade level and "I" for what you led, as your sentence does. Answer slot: say which steps were yours; if you do not recall a step, or it was someone else's, say so plainly. There is no figure on your CV, so no number to defend; do not offer one | F6 is the row, and a prober reads CV lines step by step. EXP because it tests what was actually yours |
| F2 | "What goes into your weekly email to families?" | EXP | [grounded] "I write a weekly email to families" | Describe what goes in it from memory, in your own words. Answer slot: if families replied or responded, say what happened; if the email is one-way, say so plainly and stay with the email | F5 is the row, and a named routine gets probed. EXP because it checks a CV line |
| F3 | "Which subjects did you teach in your third-grade classroom, and which would be new at fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: say which subjects you planned and taught, in your own words; if any were taught by someone else, say so plainly. For the new ones, say what you would ask the team, as a plan | F7 is silent on subjects, so a team member will ask. JD because it scores the posting's subject list |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the fourth-grade team already share, and what is left to each teacher?" | It shows you want to find the seam rather than guess it, which peers value |
| R2 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. How is the team preparing, and where would a new teacher fit?" | It uses the district's own news page (see Sources) and frames you as help |
| R3 | "Principal Vantongeren, you spent nine years as a reading specialist before becoming principal. How did that shape how reading runs at Halvering?" | It ties to her public path, so the interview becomes a conversation about her work |
| R4 | "What could a new fourth-grade teacher do in the first month that would help the team most?" | The reciprocity question for the peers: it asks what helps them |
| R5 | "How do families hear from teachers now, and how does the family reading night work at fourth grade?" | It maps to the second published belief |
| R6 | "What support do you give a teacher who is new to the grade?" | You have said you have never taught fourth grade, so this turns the gap into a plan |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | The plain acknowledgment F2 gives: "I've never taught fourth grade." Any step to fourth grade is the answer slot in F3 |
| Has been a team lead | A negative you stated | The plain acknowledgment: "I've never been a team lead." The move you led is the sentence in F6 at its scope |
| Chose or built the new reading curriculum | Inflated form of F6 | The quote at its own scope. The limit is the pack's observation: your material says you led the grade level's move, not that you chose or built the curriculum. A2's slot stays inside the move |
| Founded the reading club | Inflated form of F9 | The quote at its own scope: "I've run the after-school reading club for the last two years." The limit is the pack's observation: your material says you run it, not that you started it |
| Speaks with every family each term | Inflated form of F10 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says the email, not conversations. D2's slot stays inside the email |

## Sources

Provided: the invitation from Orrinsford Community School District HR, and your resume text. The SSN in your message was not used and is not in this pack.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | F9 to F11 and the VAL bank: the three beliefs by name, from the fetched page orrinsfordschools.example/about/mission-and-beliefs |
| 2. Interview process | skipped | The invite fixes the session (one 45-minute panel) and who is on it, so persona weights follow the panel prior |
| 3. Strategy and recent news | yes | C2, C3 and B4: the August 2026 literacy plan, from the search result for orrinsfordschools.example/news/board-adopts-literacy-plan; only the search snippet was read, not the full page |
| 4. Interviewer footprint | yes | The interviewer read and R3: ilprincipalsforum.example/speakers/dolores-vantongeren, fetched; it names the principal only |
| 5. Representative fourth-grade JD | yes | F4 to F8 and C4: k12jobsboard.example/listings/fourth-grade-teacher, snippet only; the qualifications text was cut off, so none of it is used. These rows are `[inferred]` |

Queries sent: "Orrinsford Community School District mission values" (1 result: the beliefs page); "Dolores Vantongeren principal Halvering Elementary School" (1 result: the forum speaker page); "Orrinsford Community School District strategic plan news" (1 result: the literacy plan article); "fourth grade teacher job posting Illinois elementary school requirements" (1 result: the K12 Jobs Board listing). Fetches: the beliefs page and the speaker page.

## Upgrade menu

- The posting for this job → F4 to F8 move from `[inferred]` to `[grounded]`, and any requirement the posting adds gets its own row and question
- Your answers to the slots in A1, A2, F3, F4, F7, F8, F9 and F10 → those quotes enter the snapshot and the rows regenerate with stronger bridges
- A copy of your licence record from the Illinois State Board of Education → F1 confidence rises from medium to high
- The names of the two team members → an interviewer read for each, and persona weights adjusted per person
- A line from HR on whether a demo lesson, portfolio or writing sample is expected → a build section for it, and a reweighted bank
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a named top objection, instead of the one this pack infers
