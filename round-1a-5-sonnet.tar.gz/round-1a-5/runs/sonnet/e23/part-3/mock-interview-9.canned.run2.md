I've read the skill's rules, and I'm now running a short round of public research on the district, the school, and the principal before I write the pack.
I've saved your prep pack at `/var/tmp/tuesday-measure/1a5/runs/sonnet/e23/part-3/rooms/case-9-canned-dace9319/halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 23 practice questions, a table matching your résumé lines to the role, and reverse questions for you to ask.

The invite names one panel, so I treated Principal Vantongeren as the hiring-manager voice and the two fourth-grade teachers as peers. I didn't have Orrinsford's own posting. I used a representative fourth-grade listing instead, and every row built on it is labeled `[inferred]`.

The question to rehearse most is A1, with A2 and A3 as its follow-ups. It's the "you've never taught fourth grade" objection, and your own words stay accurate under it: "I haven't taught fourth grade," then your six third-grade years, then how you'd get up to speed.

Your message included a Social Security number. Interview prep doesn't need it, so I didn't use it and it isn't in the file. Take it off any copy of your résumé you send out.

Say the word and I'll play the Skeptic on A1. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the actual Orrinsford posting for this role? Pasting it would turn six `[inferred]` rows into `[grounded]` and re-pin the job-related questions to this team's own wording.
2. Did HR mention anything beyond the interview itself, such as a sample lesson or something to bring? That would add a build section.
3. Do you want a deeper research pass on the district and school? It's up to 6 more searches and 2 more fetches, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Candidate:** Grace
**Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Treated as one hiring-manager voice (the principal) and two peer voices (the teammates).
**Highest-ROI prep in this pack:** A1, with A2 and A3 as its follow-up levels. The objection it rehearses is the one fit-snapshot row F4 states.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether your own résumé lines survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the district and the school |
| CASE | A live problem from the role, scored on structure |

- **Provenance labels.** `[grounded]` traces to a document you gave me or to research listed in Sources. `[inferred]` is derived from a representative source or an adjacent fact, and the derivation is named. `[generic]` is a pattern for the role with no claim about this employer or about you.
- **Answer slot.** An instruction for the interview, not a question for me. Where the pack cannot know something, it tells you what the panel is likely to probe and gives two honest branches: say how it was, in your own words, or say plainly that there was no such step or it was not yours, and return to the sentence you wrote.
- **Quotes.** Every sentence of yours that a cell rests on is quoted exactly. A claim about you with no quote beside it is a defect; tell me and I will fix it.

## Fit snapshot

Requirements come from three places: the invitation, a representative fourth-grade listing I fetched (typical for the role, not this team's list, so those rows are `[inferred]`), and the district's published beliefs. Evidence is quoted from what you gave me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invitation | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap on the page: your sentence states the license, and the endorsement range it names runs through grade 6, which includes grade 4. It is a CV line with nothing inspected behind it, and the invitation makes it a stated requirement, so expect a request to confirm it. Say it in the sentence's own terms |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your sentence says third grade, not which subjects you planned and taught. Answer slot: the listing's subject line makes a probe on which subjects were yours likely. Say which were yours and how you planned them, in your own words; if some were taught by others, or you did not plan them, say so plainly and stay with the third-grade years you wrote |
| F3 | "experience in grades 3 to 5 preferred" — K12 Jobs Board listing | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Third grade sits inside the listing's grades 3 to 5, so lead with the sentence in its own terms: six years, third grade. The listing is a representative one, not this team's, so do not present the preference as theirs |
| F4 | "Fourth Grade Teacher position" — invitation | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then the ramp, said as a plan and never as a past. The invitation names the position and states no years requirement, and the listing calls grades 3 to 5 a preference. Nothing is added to make the gap feel smaller |
| F5 | "work with the grade-level team" — K12 Jobs Board listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with it as you wrote it: you led your grade level's move to a new reading curriculum in 2024, and say no more than that sentence until asked |
| F6 | Not stated in the invitation or the listing; on this table because you raised it | "I've never been a team lead" — your message | none | [grounded] | capability | Words: "I haven't been a team lead." Keep it apart from F5: your CV sentence says you led a move, and your material does not say you held a team-lead role. Never a claim to that role |
| F7 | "differentiate instruction using assessment data" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material is silent on how you used assessment results. Answer slot: the listing's line and the district's belief on assessments (F12) make a probe likely. If results changed what you taught, say what they were and what you changed, in your own words; if not, or it was not yours to do, say so plainly and say what you would look at first |
| F8 | "keep clear classroom routines" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material is silent on classroom routines. Answer slot: if you set routines in your own classroom, say which and why, in your own words; if someone else set them, or there is nothing to speak of, say so plainly and say what you would set first |
| F9 | "communicate regularly with families" — K12 Jobs Board listing | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap: a weekly email reaches the listing's regular communication in role-relevant terms. Lead with it as you wrote it. What goes in it is answered at B4, in your own words |
| F10 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The district's line is about speaking with families; your sentence is a weekly email, which is writing. Say the sentence at that scope. Answer slot: the belief makes a probe on direct conversations likely. If you spoke with families directly, say how often and how, in your own words; if you did not, or not with every family, say so plainly and stay with the email |
| F11 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford beliefs page | "I've run the after-school reading club for the last two years." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Your sentences are a reading club you run and a curriculum move you led, and neither says what happened for any child. Keep both at their own scope. Answer slot: the belief makes a probe on supporting a reader who has stalled likely. If a student or group comes to mind, say what you did and what followed, in your own words; if none does, say so plainly and stay with the club and the move |
| F12 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford beliefs page | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the belief is the district's own, so expect a probe. If results changed what you taught, say what they were and what you changed, in your own words; if no such time comes to mind, say so plainly and say how you would use results |

## Reading the interviewer

The principal is the only panelist with public information. The two fourth-grade team members have no names or profiles in what I have, so their rows rest on the relationship prior alone. Public professional footprint only.

| Public item (source) | Provenance |
|---|---|
| Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist (ilprincipalsforum.example speaker page) | [grounded] |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 (same page) | [grounded] |
| The two fourth-grade team members: no names, no profiles given | [generic] |

| What it means for this panel | Derived from | Provenance |
|---|---|---|
| Expect reading to run through the principal's questions: C1 and D1 are built for that. Be ready to talk about small-group reading as a plan in your own words, and about what you have actually done in the reading club only at the scope of your sentence | Her reading-specialist tenure and the talk's topic | [inferred] |
| Shared vocabulary, not a shared career jump: her public subject is reading in grades 3 to 5, and F11 holds your sentence "I've run the after-school reading club for the last two years." Use the sentence as written and let her draw the link. No shared jump is offered, because no row's evidence carries your side of one | F11 and the speaker page | [inferred] |
| Her facts come from one third-party speaker page; check them against the school's own page before you refer to them aloud | The single source | [generic] |

## Persona table

The invitation fixes the loop as one 45-minute panel session with named roles, so no archetype fallback is used. It names no values round, so none is detected and the pack has no values cheat sheet. The district's published beliefs still theme bank D.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of F4 and F6 by the principal, echoed by teammates | **Highest.** The hiring-manager prior pairs Case/Strategist with Skeptic, and two gaps are ones you stated yourself | Rehearse A1 until it is boring. Plain acknowledgment first, then only the sentences quoted in the row, then the ramp as a plan |
| B. Peer Evaluator | The two teammates asking what you would need from them, how you disagree, how credit is shared | **High.** Two of three panelists are peers-to-be, and the peer prior pairs Peer Evaluator with Prober | Reciprocity: what you need and what you bring at the scope of your sentences. Propose principles for working together; do not claim to know their seam |
| E. Data-Driven Prober | Reading your résumé lines one by one: the club, the curriculum move, the subjects | **High.** The peer prior includes it, and a short résumé means every line gets read | Know what each sentence does and does not say; where you do not know, say so plainly |
| C. Case/Strategist | Live problems from the role, from the principal | **Medium.** First in the hiring-manager prior, and her public subject is reading | Clarify, then objective, then steps, then how you would check progress; say a plan as a plan |
| D. Values/Behavioral | "Tell me about a time…" themed on the district's three beliefs | **Medium.** No values round is documented, but the district's page says its beliefs guide every hire | Where a sentence of yours carries a story, tell its beats and no more; where none does, use the selection scaffold and its honest branch |
| G. Conversational | The opener and the logistics check | **Low to medium.** Panels open with an easy question, and it is still scored | A 90-second arc from your own sentences only |
| H. Pressure | Time-boxing and "how much of that was you" | **Low.** No signal points to it, but 45 minutes with three panelists forces short answers | Pause, restate, hold the sentence, concede only what is specific and true |

No bank F: the letter is skipped so question IDs do not collide with fit-snapshot rows F1 to F12.

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What do you expect to be different about teaching fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Say the plain version first: "I haven't taught fourth grade." Then what your material carries, at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then the ramp as a plan, never a past: name, in your own words, the first things you would want to learn about this grade in this building and who you would ask. If you do not know what differs, say so plainly and say you would ask the two teachers on this panel. Hold through A2 and A3 by returning to these sentences, never by adding to them | F4 is the stated gap and F3 is the nearest evidence, so this objection arrives in some form, which makes A1 the deepest rehearsal here. JD because it scores whether you can do the posted job including this gap; Skeptic is how it will be asked |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name the weakness your material actually shows, in plain words: "I haven't taught fourth grade." Concede that and no more, and do not volunteer weaknesses your material does not show. Then say what you would do about it as a plan. Answer slot: if there is another area you know would be weaker on day one, say so plainly in your own words; if there is none you can name, say that and return to the fourth-grade ramp | Level two of the A1 chain, the stem a Skeptic uses on any gap in F4. JD because it scores the listed job |
| A3 | "It's October, and a fourth-grade unit isn't landing with your class. What do you do?" | CASE | [generic] | No claim about your past is needed, and the guidance makes none. Ask what "isn't landing" means before answering: what you have seen, from whom. Then your next step, who on the team you would ask, how you would tell whether the change worked, and what you would tell families. Think aloud and name one premise you would test | Level three of the A1 chain: it turns the gap into a live problem, which is how a hiring manager probes whether a stated gap has a plan behind it. CASE because it is a decision, not a record |
| A4 | "You haven't been a team lead, and this role works closely with a grade-level team. How do you see your place on it?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment first: "I haven't been a team lead." Then the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not call it a team-lead role and do not say it proves readiness for one; let them draw the inference. Answer slot: expect a follow-up on what leading the move involved. Say which parts were yours and which were others', in your own words; if it was shared, or you do not recall the split, say so plainly and return to the sentence. Then answer the question asked, your place on a team, as a plan for how you want to work with these two colleagues | F6 is a stated gap and F5 the nearest evidence; the listing's team line raises this probe. JD because it scores the listed requirement |
| A5 | "Why Halvering, and why now?" | CO | [grounded] "I've run the after-school reading club for the last two years." | Anchor "why here" on published things: the district's page names three beliefs, Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. Say which is closest to how you want to teach and why, in your own words. If you point to your own work, point to a sentence you wrote, such as "I've run the after-school reading club for the last two years.", at its scope, and let them draw the link. Answer slot: why now is yours alone; say your real reason in your own words, and if part of it is not for an interview, say the part that is. Do not criticize your current school | "Why leave, why here, why now" is the standing Skeptic motivation probe. CO because the strong answer uses what the district has published, and F11 holds the sentence it leans on |

### B. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans together. What happens when you disagree with the plan?" | JD | [generic] | A principles answer; it makes no claim about your past. Say what you would ask first, what you would defer on as the newest member, where you would hold your view and how you would put it, and how you would leave the relationship afterward. If a real disagreement comes to mind, tell it in your own words at its own scope; if none does, say so plainly and stay with the approach | The peer stem on disagreement between equals. JD because the listing raises working with the grade-level team (F5) |
| B2 | "What would you need from our team in your first month?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Give both halves: what you need and what you bring. What you need is a plan: two or three things you would ask for, in your own words. What you bring stays at the sentence: six years teaching third grade at a public elementary school in Joliet, said as a fact and not as a claim about what it will do for their students. Propose how you would ask; do not claim to know their seam yet | Reciprocity framing for peers who are pricing what the hire costs them. F3 holds the sentence; F4 is why "need" matters |
| B3 | "How do you handle credit when work spans a whole team?" | VAL | [generic] | A principles answer with no claim about your past: share credit by name, say what was yours in plain words, and do not take a shared result. If a real example comes to mind, tell it at its own scope in your own words; if none does, say so plainly and stay with the principle | The peer stem on credit-sharing. VAL because it scores behavior toward colleagues rather than a listed skill |
| B4 | "How do you keep families informed, and how would you fit with the way our team already does it?" | JD | [inferred] "I write a weekly email to families." | Say what you do at its scope: "I write a weekly email to families." Answer slot: expect "what goes in it"; say what actually goes in, in your own words, and if you do not recall, say so plainly. For the second half, do not claim to know the team's practice: ask how they do it and say you would fit with it. Do not call the email a conversation with families | F9 is the evidence and F10 shows where it stops. JD because the listing raises family communication; the peer register asks about fit with the team |

### C. Case/Strategist (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student joins your fourth-grade class in September reading well below the rest of the class. Walk me through your first four weeks." | CASE | [generic] | No claim about your past is needed. Clarify first: what "well below" rests on and who has seen it. Then the objective, the steps, how you would check progress and when you would change course, and how you would involve the family and the team. Say it as a plan in your own words and name one premise you would test. If a real student comes to mind you may say so at its own scope; if none does, stay with the plan | A reading problem from the role, aimed at the principal's public subject, and the district's first belief is about every child reading. CASE because it is scored on structure; F11 and F7 are the rows it exercises |
| C2 | "The board has adopted a literacy plan with a new reading curriculum for grades 3 to 5 from fall 2027. How would you get ready for it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Know the plan as a headline only: it comes from a search summary, so read the district's page before Thursday. Answer as a plan: what you would want to know first, who you would ask, how you would prepare. Your sentence is available at its scope: "I led our grade level's move to a new reading curriculum in 2024". Answer slot: if asked what you would carry from that move, say what you would do again or differently, in your own words; if nothing comes to mind, say so plainly and return to the sentence | The one question grounded in the district's current strategy. F5 holds the sentence; CO because it scores whether you can think at the district's altitude |
| C3 | "It's the first week of school. Which routines would you set up, and why?" | CASE | [inferred] | A plan, not a past: pick the few routines you would set first and say why each helps learning, in your own words; do not recite a list. Answer slot: if you used routines in your own classroom, you may say which, at your own scope; if someone else set them, or there is nothing to speak of, say so plainly and stay with what you would do | The listing's routines line (F8) has no evidence behind it, so this question exists to find it first. CASE because it is asked as a decision |

### D. Values/Behavioral (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Orrinsford's first belief is Every Child a Reader. Tell me about a time a student's reading stalled and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years." | The sentence carries these beats and no more: a reading club, after school, two years; tell those in your own words. The story itself is an answer slot: choose one student or small group from your own experience and say what you noticed, what you did and what followed. If no such student comes to mind, say so plainly, then say how you would approach a reader who has stalled, as a plan, or give the nearest thing your material carries, the club at its scope. Do not say the club worked unless you can say how you know | The district's own first belief raises the theme. F11 is the row; VAL because it scores behavior against a published value |
| D2 | "Orrinsford expects each teacher to speak with every family each term. Tell me about a time a conversation with a family changed how you taught." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: pick a time with a named conversation, what the family said or what you learned, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly email at its own scope, or how you would handle it. Do not describe the email as a conversation | The second belief raises the theme, and F10 shows the email is writing where the belief says speaking. VAL because it scores a published value |
| D3 | "Tell me about a time assessment results changed what you did in the classroom." | VAL | [grounded] | Selection scaffold: pick a time that has the results, what they showed, what you changed and how you checked. If no such time comes to mind, say so plainly, then say how you would use results to adjust teaching, as a plan. Tie to the district's belief only if it is true of how you work: assessments inform teaching and never replace it | The third belief raises it and F12 has no evidence behind it; F7 is the listing's version. VAL because the belief is the published value |

### E. Data-Driven Prober (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the reading club you run after school." | EXP | [grounded] "I've run the after-school reading club for the last two years." | The sentence states three beats: you run it, it is after school, it has been two years; tell them in your own words and stop. Answer slot: expect probes on who comes, what a session looks like and how you tell whether it helps. Answer from what actually happens; if you have not measured whether it helps, say so plainly and say what you would look at first; if a part was not yours, say so plainly and return to the sentence | F11 holds the sentence and the club is the line a reader will pick up first. EXP because it tests what was actually yours |
| E2 | "You led your grade level's move to a new reading curriculum in 2024. What did leading it involve?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The sentence is the whole claim; do not widen it. Answer slot: say what leading it involved and which parts were yours, in your own words; if others set the timing or the choices, or you led only part of the move, say so plainly and return to the sentence | F5 is the row, and this is the line where attribution probes land. EXP because it tests attribution |
| E3 | "Which subjects did you plan and teach across those six years?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Start at the sentence's scope: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: the listing for this kind of role names reading, writing, math, science and social studies; say which of those were yours, subject by subject if the answers differ, in your own words. If some were taught by someone else, or you did not plan them, say so plainly and return to the sentence | F2 is silent on subjects, and the listing raises them. JD because it scores the listed duty |
| E4 | "How should assessment results shape the way you plan for different learners?" | JD | [inferred] | Selection scaffold: pick one time results changed what you taught; it needs the results, what they showed, what you changed and how you checked. If no such time comes to mind, say so plainly, then say what you would look at first and how you would adjust, as a plan | F7 and F12 hold the listing's line and the district's belief, with nothing yet behind them. JD because the listing raises differentiation; the Prober asks for the denominator behind it |

### G. Conversational (lower weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey so far." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc built only from those sentences, each told in your own words and no longer than the sentence. Answer slot: why you became a teacher and why fourth grade are yours alone; say your real reasons, and if you have no reason for fourth grade specifically, say so plainly and say what draws you to this school | The standard opener, still scored; it is where F1 to F11 are first heard together. EXP because it is your own record, told |
| G2 | "Before we go on, can you confirm your Illinois license and its endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the sentence's own terms and no further. Have your license record where you can show it if asked, since your CV line has nothing inspected behind it | The invitation makes the license a stated requirement, so this check is likely at the door. F1 is the row; JD because it scores a listed requirement |

### H. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why should we hire you for fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade" | Pause and restate the question in a clause. Three short beats, each a sentence of yours at its scope: six years teaching third grade at a public elementary school in Joliet, and that you led your grade level's move to a new reading curriculum in 2024. If interrupted on fourth grade, hold the beats through two interruptions, then concede specifically: "I haven't taught fourth grade." Do not fold on the sentences to restore harmony | The time-boxed form of A1. F3 and F5 are the rows; JD because it scores the posted job |
| H2 | "That reading curriculum move you led: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pause and restate: "You are asking how much of the move was mine." The held position is only the sentence. Answer slot: say which parts were yours and which were others', in your own words; if it was largely shared, or you cannot separate it, say so plainly. Hold through two follow-ups by returning to the sentence, never adding to it, and concede only what is specific and true | The standard attribution stem under pressure; F5 is the row. EXP because it tests attribution |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Illinois PEL with elementary endorsement (F1) | G2 |
| plan and teach reading, writing, math, science and social studies (F2) | E3 |
| experience in grades 3 to 5 preferred (F3) | A1, E3 |
| Fourth Grade Teacher position (F4) | A1, A2, A3, H1 |
| work with the grade-level team (F5) | A4, B1, B2, E2 |
| team lead, raised by you and in no source (F6) | A4 |
| differentiate instruction using assessment data (F7) | E4, C1 |
| keep clear classroom routines (F8) | C3 |
| communicate regularly with families (F9) | B4 |
| Families Are Partners (F10) | D2 |
| Every Child a Reader (F11) | D1, C1 |
| assessments inform teaching (F12) | D3, E4 |

## Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| R1 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. How does that show up in a fourth-grade reading block here?" | Tied to the principal's own public work, which turns a questioning into a conversation and shows you read her footprint. Check the talk's details on a second page first |
| R2 | "The board's literacy plan brings a new grades 3 to 5 reading curriculum from fall 2027. What do you hope the fourth-grade team has in place before it arrives?" | Shows you read the district's current direction and asks where a new teammate would be useful |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two teammates: it flips the interview from what you need to what they need |
| R4 | "What does a strong first year look like for a teacher who is new to fourth grade?" | Invites them to describe the ramp, which is the answer A1 depends on, and shows you are planning for it |
| R5 | "The district's page says each teacher speaks with every family each term. What does that look like in practice at Halvering?" | Shows you read the published beliefs and asks for the concrete practice |
| R6 | "How does the fourth-grade team plan together, and where does each teacher decide for themselves?" | Asks for the seam rather than assuming it, which is the peer persona's own question |
| R7 | "What is the next step in the process, and when do you expect to decide?" | A generic closer that keeps the end of the interview concrete |

## Prohibited claims

Built before the banks. Silence is not listed here: where your material says nothing (subjects taught, use of assessment data, results of the club or the move), the pack gives answer slots, not prohibitions.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F4: "I've never taught fourth grade" | The plain acknowledgment "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative you stated, F6: "I've never been a team lead" | The plain acknowledgment "I haven't been a team lead." No slot on the role; the slot on the move stays inside the sentence in F5 |
| Chose, built or rolled out the new reading curriculum | Inflated form of F5's sentence | F5's sentence at its own scope. The limit is the pack's observation, not words for you: the material says you led your grade level's move, and nothing in it says who chose or built the curriculum. E2's and H2's slots stay inside which parts were yours |
| Spoke with every family each term | Inflated form of F10's sentence | F10's sentence at its own scope. The limit is the pack's observation: the material says a weekly email, and nothing in it describes conversations. B4's and D2's slots stay inside how you spoke with families directly, if you did |

## Sources

Provided documents: the invitation text and the résumé text you pasted into your message. No identifier numbers from your message were used.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent and what came back:

- "Orrinsford Community School District mission vision values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District strategic plan" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (search summary only; the page was not fetched)
- "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren (search summary only; the page was not fetched)
- "fourth grade teacher job description Illinois elementary school responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: the district's beliefs page and the K12 Jobs Board listing.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three beliefs by their names; F10 to F12 and banks D, A5, R5 |
| 2. Interview process, role family | skipped | Your invitation fixes the loop: one 45-minute panel and who sits on it. It moved nothing further |
| 3. District strategy and recent news | yes | The August 2026 literacy plan from a search summary: C2, R2 and A5. Read the full page before Thursday |
| 4. Interviewer, public footprint | yes | The principal only, from one third-party speaker page: the interviewer read, C1, R1. The two teammates have no names, so nothing was searched for them |
| 5. Representative fourth-grade listing | yes | F2, F3, F5, F7, F8, F9; banks B4, C3, E3, E4 |

## Upgrade menu

- The actual Orrinsford posting for this role → the six `[inferred]` rows (F2, F3, F5, F7, F8, F9) become `[grounded]`, and the JD-tagged questions are re-pinned to this team's own lines
- Anything HR said about format, such as a sample lesson or something to bring → a build section for any announced deliverable
- The two team members' names and roles → a public-footprint read for each, tuned peer weights and a tailored reverse question
- Your answers to the answer slots in F2, F7, F8, F10, F11 and F12 → new quoted evidence, and those rows regenerate from discovery or transferability toward `none` where your answer reaches the requirement
- Your license record as the state registry shows it → F1 can rise from medium to high
- How many hours you have before Thursday → a prioritized prep schedule sized to that time
- A tuesday-dossier.md, if you have one → verified evidence and prohibited-claim guardrails from an earlier review, in place of the locally built list
