I'm reading the last few reference files for the prep-pack skill. After that I'll research the district and write the pack.
Next I'm writing the prep pack file.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for a panel with Principal Vantongeren and two fourth-grade team members. Your SSN and license number are left out of it.

- **Your license:** it matches the invite's one stated requirement, so I treated it as met.
- **Your two gaps:** "never taught fourth grade" and "never been a team lead" are where the panel will press. A1 and A2 are the questions to rehearse first.
- **The district:** I pulled its three published beliefs, its 2026–2029 literacy plan, and a short profile of the principal. The principal was a reading specialist for nine years.
- **The job description:** you didn't send one, so four of the requirements come from a representative fourth-grade posting and are labeled `[inferred]`.

The pack has 20 questions across six interviewer styles, plus reverse questions and a list of claims it won't coach.

Say the word and I'll play the Skeptic on A1 so you can practice it out loud. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. I can convert the pack to Word too, if you'd like.

1. Can you paste the full posting, or tell me to go ahead without it? It would turn the inferred requirement rows into grounded ones.
2. Do you know the two team members' names or roles, and is either of them the team lead? That would change how I plan for each panelist.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built on this assumption:** the invite is the only description of the job. No full posting was supplied, so requirements beyond the invite's license line come from a representative posting and are labeled `[inferred]`.

## How to use this pack

Personas describe how a question will be asked. Types describe what it is scoring. Guidance is scaffolding for your own words, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior fits the district's published beliefs |
| EXP | Whether your CV lines hold up when asked about closely |
| JD | The stated job and its gaps |
| CO | Whether you know the district's current direction |
| CASE | How you reason through a live classroom problem |

Question IDs run by persona: A is the Skeptic, B the Peer Evaluator, C the Case/Strategist, D the Values/Behavioral, E the Conversational, F the Data-Driven Prober. Highest-ROI prep: **A1**, then **A2**.

The pack leaves out your license number and your SSN. Neither is needed to prepare, and you should not put either in a document like this.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is shown met in your own terms. Say it plainly and bring your license record, since nothing has been inspected behind the CV line. The pack's observation: fourth grade falls inside the grades 1–6 range your sentence states |
| F2 | "the Fourth Grade Teacher position at Halvering Elementary School" — HR invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've run the after-school reading club for the last two years." — your CV | low | [inferred] | discovery | These sentences touch the subjects without showing which you taught. Answer slot: the representative posting lists five subjects, so expect a probe on which you taught in third grade. Name the ones you taught, in your own words; if you taught only some, or the others were not yours, say so plainly and stay with the ones you did |
| F4 | "differentiate instruction using assessment data" — K12 Jobs Board representative posting | none given | none | [inferred] | discovery | Your material is silent here and the district's third belief raises the same theme. Answer slot: if assessment results have changed what you taught next, say what you looked at and what changed, in your own words; if that was not part of your teaching, or was set by someone else, say so plainly and say how you would start |
| F5 | "communicate regularly with families" — K12 Jobs Board representative posting | "I write a weekly email to families." — your CV | medium | [inferred] | none | The quote reaches the requirement. Lead with it in its own terms: you write a weekly email to families. A named routine beats an adjective |
| F6 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The quote carries the email, which is one kind of family contact. The pack's observation: your material says the email, not conversations. Words stay at "I write a weekly email to families." Answer slot: expect a probe on family contact beyond the email. If you reach families another way, say how, in your own words; if the email is the whole of it, say so plainly and say what you would add here |
| F7 | "work with the grade-level team" — K12 Jobs Board representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | none | Two sentences, each kept at its own scope: the grade level's move, and no lead role. Say both plainly and never merge them. Expect a probe on what leading the move involved. Answer slot: say which parts were yours, in your own words; if parts were set by the school, the district or colleagues, or there was no step you would call yours, say so plainly and stay with the move |
| F8 | "Every Child a Reader: no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | The club is adjacent work and the quote does not say it involved reading plans. Words stay at the club and the two years. Answer slot: if you made or contributed to a reading plan for a particular child, say what it was and what part was yours; if not, or no such plan existed where you taught, say so plainly and say what you would do |

## Reading the interviewer

| Item | What the source says | Practical implication | Provenance |
|---|---|---|---|
| Career path | Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Reading instruction is her native vocabulary, so expect reading questions with some depth | [grounded] |
| Published talk | A 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | Expect the panel to care how reading is taught in small groups, and ask her rather than assume what a conference looks like here | [grounded] |
| Mirror opportunity | Her talk covers grades 3 to 5 and her work was in reading. Your F7 quote reads "I led our grade level's move to a new reading curriculum in 2024" | Shared vocabulary is reading curriculum and grades 3 to 5. Offer the quote at its own scope and let her ask. It is not a shared career jump, and the pack does not offer one | [grounded] |
| Two team members | No names or roles were given | Persona assignment for them rests on the peer prior only. If one is the grade-level team lead, say so in your reply and the pack will retune | [generic] |

Public professional footprint only.

## Persona table

| Persona | Who and how it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Skeptic | The principal, probing the gaps | High. F2 and F7 are gaps you stated, and a hiring-manager relationship tilts toward Skeptic and Case | Rehearse A1 until the plain acknowledgment is unremarkable; a plan, said as a plan | [generic] |
| Peer Evaluator | The two fourth-grade team members | High. The invite puts two team members on a 45-minute panel, and the peer prior is Peer Evaluator plus Prober | Reciprocity: what you bring first, what you need second; seam principles, not claims | [grounded] |
| Case/Strategist | The principal, with live classroom problems | Medium. Hiring-manager prior, and her public work is reading instruction | Clarify, objective, approach, family communication, check; think aloud | [generic] |
| Values/Behavioral | Any panelist, themed on the district's beliefs | Medium. No values round is named in the invite, so none is assumed; the district's page says three beliefs guide every hire, which themes bank D | Map a story to each belief only where your sentence carries one; otherwise a selection scaffold and the honest branch | [grounded] |
| Conversational | Opening and closing minutes, and the license check | Medium. A panel opens warm and closes with logistics | A 90-second arc built only from your own sentences; never answer "I think you've covered everything" to the reverse-question slot | [generic] |
| Data-Driven Prober | A team member reading your CV line by line | Low to medium. Peer prior; your CV has few figures to probe | Know exactly which parts of your two leadership-type sentences were yours | [generic] |
| Pressure | No standalone bank | Low. Nothing in the invite signals a stress format. A2 is rehearsed with the delivery anyway | Pause, restate, hold, concede only what is true | [generic] |

The loop is the one session the invite describes, so persona weights rest on that and on relationship priors, not on a documented district process.

## Question banks

### A. Skeptic (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. Why should we believe you're ready for fourth?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never taught fourth grade." Then say what your sentence carries: "Six years teaching third grade at a public elementary school in Joliet." Then a plan, said as a plan: the first things you would ask the team and look at before day one, naming only what you would actually do. Follow-up 1, "So we'd be training you?": hold on the plan, in your words. Follow-up 2, "What if the plan isn't enough?": say what you would ask for, and promise no result. Follow-up 3, "Someone with fourth-grade experience applied": concede that this is a difference you cannot close, then return to the plan and your six years. Do not say you know fourth-grade expectations unless you do | F2 is a gap you stated and is the likeliest opening objection; JD because it scores the role as titled, with the deepest follow-up chain in the pack |
| A2 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | Pause, restate the question, then hold. Concede the one thing you cannot change: "I've never taught fourth grade." Offer only what your sentences carry, at their own scope, in your own words, and let the panel draw the comparison. Do not say you are the stronger candidate. Hold through two follow-ups by returning to those sentences, never by adding to them | F2 and F7 are the material the question presses on; JD content with a Pressure delivery |
| A3 | "Which part of this job would be hardest for you in your first month?" | JD | [grounded] "I've never taught fourth grade" | Name a true answer before they do. Your stated gap is a candidate: "I've never taught fourth grade", followed at once by what you would do about it. Name what is hardest in your own terms and say the plan, not a claim of readiness. If nothing comes to mind as hardest, say so plainly and give the nearest true concern | F2 again, asked as self-assessment; scores calibrated candor, and JD because it tests the role's gaps |
| A4 | "How do you see your place on a team where you wouldn't be the lead?" | JD | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Say the first plainly: "I've never been a team lead." Then the second at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not blur them into one claim. Answer slot: expect "what did leading the move involve". Say which parts were yours; if parts were set by others, or there was no step you would call yours, say so plainly and stay with the move. Then what you would offer the team, said as an offer | F7 holds both sentences and a panel that includes team members will press on the seam between them; JD for the team requirement |
| A5 | "Why fourth grade, and why Halvering?" | JD | [grounded] Orrinsford Mission and Beliefs page; Board literacy plan (Sources) | No claim about your past is needed. Selection scaffold: give two or three reasons that are true, one about the grade level, one about the school or district. The three published beliefs and the adopted literacy plan are things you can cite accurately. If no reason about fourth grade comes to mind beyond wanting the position, say so plainly and give the nearest true reason | Motivation consistency, and a district-specific answer shows homework; JD because it scores fit with the posted role |

### B. Peer Evaluator (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade teachers plan together. What would you bring us, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | Reciprocity: lead with what you bring. Offer the three sentences at their own scope, in your own words, as things you have done rather than things you will do. Then what you need, which is true and specific. Do not describe how the team works; ask | F7, F5 and F3 carry the three things; JD because it scores the team requirement from the peer side |
| B2 | "Tell me about a time you disagreed with a colleague on your grade-level team." | VAL | [generic] | Selection scaffold: pick a disagreement about a decision rather than a person. It needs what each side wanted, what you did, and how the working relationship stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona's stem; VAL because it scores how you disagree with equals |
| B3 | "How do you handle credit when a piece of work spans several teachers?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for context and "I" for your part. The sentence says the move was the grade level's, so the credit is shared by its own terms. Answer slot: say what your part was, and name others' parts in your own words; if you cannot separate them, say so plainly | Peer credit probes land on exactly the sentence in F7; EXP because it tests attribution |
| B4 | "What would you do in your first week to learn how our team works?" | CASE | [generic] | Structure it: whom you would ask, what you would read, what you would watch, and how you would offer help. It asks about a plan, so the answer makes no claim about your past | A live problem from F2's gap, asked as a plan; the peer panel is pricing what you will cost them |

### C. Case/Strategist (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader arrives well below the class in reading. Where do you start?" | CASE | [grounded] Orrinsford Mission and Beliefs page (Sources) | Clarify first: what is already recorded about the child, and whether a reading plan came with them, since the district's page says no student leaves third grade without one. Then the objective, your approach, how you would talk with the family, and how you would check it is working. Ask what a weekly reading conference looks like here rather than assuming. Think aloud and challenge one premise respectfully | The principal's public work is reading instruction (Reading the interviewer); CASE because it scores structure |
| C2 | "The board adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027. What would help a fourth-grade team get ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | State what the page says and nothing more: the plan, the grades, the start date. Then your sentence, at its own scope. Answer slot: if there are things from your 2024 move you would carry into this one, name them, in your own words; if the two are different enough that none carry, say so plainly. Do not claim to know this curriculum | The one CO question grounded in current district strategy; F7 is the only row that touches it |
| C3 | "The plan puts a family reading night in every school each term. How would you run one?" | CASE | [grounded] "I've run the after-school reading club for the last two years." "I write a weekly email to families." | Plan it aloud: purpose, who comes, how families hear about it, what the evening holds, how you would tell it went well, and what you would ask the team first. The email is a channel you have used: "I write a weekly email to families." Do not say you have run such an evening | CO from the literacy plan; F5 and F8 are the adjacent rows |

### D. Values/Behavioral (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader: tell us about a time you made sure a child had a plan to grow as a reader." | VAL | [grounded] "I've run the after-school reading club for the last two years." | The club sentence carries only the club and the two years. Answer slot: if you made or contributed to a plan for a particular child, say what it was and what part was yours, in your own words; if not, or no such plan existed where you taught, say so plainly and say what you would do | F8 holds the first published belief against your closest sentence |
| D2 | "Families Are Partners: each teacher speaks with every family each term. How do you stay in touch with families?" | VAL | [grounded] "I write a weekly email to families." | Lead with the sentence: "I write a weekly email to families." Answer slot: expect a probe on family contact beyond the email. If you reach families another way, say how, in your own words; if the email is the whole of it, say so plainly and say what you would add here | F6 is a transferability row; the second belief is the one your material reaches least |
| D3 | "Teach for Tomorrow, Not for the Test: when has assessment data changed what you taught next?" | VAL | [grounded] Orrinsford Mission and Beliefs page (Sources) | Selection scaffold: pick one instance with a named group, what the data showed, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 has no quote to map, so this is a scaffold; VAL because the question comes from the published belief and JD for differentiation |

### E. Conversational/Rapport Builder (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about yourself and what brought you to Halvering." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc in this order: license and endorsement, six years of third grade, the move, the club, the email, then one true reason for fourth grade and Halvering. Each beat is one sentence at its own scope. No beat beyond these | The biography question is scored however casual it sounds |
| E2 | "What's a book you love sharing with a class?" | JD | [generic] | Pick a book you have actually shared and say why in a sentence or two. If none comes to mind, say so plainly and name one you would want to share and why. Keep it short; the principal's background is reading | A casual question on the JD's hot topic, asked as rapport |
| E3 | "Can you confirm your license and endorsement for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the sentence's own terms and stop. Have your license record with you | F1 is the invite's one stated requirement and a gate; an easy question that must be flawless |

### F. Data-Driven Prober (weight: lower, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk us through how your grade level's move to the new reading curriculum went." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats the sentence states: the grade level, the move to a new reading curriculum, 2024, led by you. Answer slot: the representative posting asks for working with the grade-level team, so expect a probe on which parts were yours. Say which, in your own words; if parts were set by others, say so plainly and stay with the move | F7's second sentence is the most checkable line on your CV |
| F2 | "Which subjects did you teach in third grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: the representative posting lists reading, writing, math, science and social studies, so expect this. Name the subjects you taught. If you taught only some, or others were taught by colleagues, say so plainly and stay with the ones you did | F3 is a discovery row: the sentence does not say which subjects; JD for the posted duties |

### Requirement-coverage line

| Requirement | Questions |
|---|---|
| F1: license and elementary endorsement | E1, E3 |
| F2: Fourth Grade Teacher | A1, A2, A3, A5 |
| F3: plan and teach the subjects | F2, C1 |
| F4: differentiate with assessment data | D3, C1 |
| F5: communicate with families | D2, C3 |
| F6: Families Are Partners | D2 |
| F7: work with the grade-level team | A4, B1, B2, B3, B4, F1 |
| F8: Every Child a Reader | D1, C1 |

## Reverse questions

| # | Question | Why it lands | Source |
|---|---|---|---|
| R1 | "You were a reading specialist for nine years before becoming principal. How does that shape what you look for in how fourth grade teaches reading?" | Ties to her own path and signals you researched her | [grounded] |
| R2 | "Your talk covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade day here?" | Asks about her stated theme without assuming the answer | [grounded] |
| R3 | "The literacy plan brings a new reading curriculum to grades 3–5 from fall 2027. How is the fourth-grade team preparing, and where could a new person help?" | Shows you read the plan, and offers help | [grounded] |
| R4 | "What could a new person on the fourth-grade team do in the first month that would genuinely help you?" | Reciprocity question for the two peers | [generic] |
| R5 | "How does the team plan together week to week, and what would you want a new member to learn first?" | Turns your biggest stated gap into a working question | [generic] |
| R6 | "What does a strong first year look like on this team?" | Lets the panel describe the bar in their own words | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I've never taught fourth grade." No slot |
| Has been a team lead | Negative you stated, F7 | The plain acknowledgment: "I've never been a team lead." No slot |
| Led the school's or the district's reading curriculum change | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your sentence says your grade level's move. Slots stay inside the move |
| Speaks with every family each term | Inflated form of F5 and F6 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says the email, not conversations |

## Sources

Provided documents: the HR invitation and the CV text you pasted.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three published beliefs by name; they theme bank D and fit rows F6 and F8 |
| 2. Orrinsford interview process, teaching roles | skipped | The invite already fixes the loop: one 45-minute panel, three panelists |
| 3. Orrinsford strategy and recent news | yes | The 2026–2029 literacy plan; it fixes C2 and C3 and reverse question R3 |
| 4. Interviewer: Dolores Vantongeren | yes | The interviewer read, the Skeptic and Case weights, R1 and R2 |
| 5. Representative fourth-grade teacher posting | yes | F3, F4, F5 and F7 requirements, labeled `[inferred]`; the result's qualifications text was cut off and is not used |
| Outside the declared targets: Halvering Elementary School | yes | Returned no results; it moved nothing |

Searches sent:

1. "Orrinsford Community School District mission values" — https://orrinsfordschools.example/about/mission-and-beliefs
2. "Halvering Elementary School Orrinsford Community School District" — no results
3. "Dolores Vantongeren principal Halvering Elementary" — https://ilprincipalsforum.example/speakers/dolores-vantongeren
4. "Orrinsford Community School District strategic plan" — https://orrinsfordschools.example/news/board-adopts-literacy-plan
5. "fourth grade teacher job description Illinois elementary school responsibilities qualifications" — https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: the Mission and Beliefs page, and the Board literacy plan page.

## Upgrade menu

- The full job posting → F3, F4, F5 and F7 move from `[inferred]` to `[grounded]`, and the JD-tagged questions are rebuilt on the posting's own lines
- The two team members' names and roles, and whether either is the team lead → persona assignment per panelist, a fuller interviewer read, and a reverse question tied to each
- Your license record as the state shows it → F1 confidence can rise from medium to high
- Your own answers to the answer slots in F3, F4, F6, F7 and F8 → those rows regenerate on what you say, in your words
- The recruiter's reply on panel format or focus areas → replaces the assumption that coverage follows the persona priors
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the district, and the principal's other public talks and writing
- A `tuesday-dossier.md` from the job-underwriter → verified evidence and prohibited claims arrive ready-made; it is never a prerequisite
