I'll read the reference files the skill points to before writing the pack.
Searches were refused, so I'm building the pack from your advert, Hannah's message and what you told me. Writing the pack file now.
Your prep pack is saved as `Quillmoor_operations-coordinator_interview_pack.md` in the working directory. It's built for Hannah's four topics, plus the questions a recruiter screen can drift into. It has 18 questions, a fit snapshot against the advert, six reverse questions, and a list of claims the pack won't coach.

- **Research didn't run.** All four searches (values, interview process, strategy and Hannah's public profile) were refused. Nothing in the pack says anything about Quillmoor beyond your advert. The "why Quillmoor" question (B3) is generic, and there's no interviewer read.
- **Your notice period is a gap.** You didn't give it, so A5 is an answer slot. Check your contract before Thursday.
- **Most important rehearsal (B2).** The advert's core duty is coordinating production schedules between planning, the warehouse and QA. Your material says delivery scheduling for three depots. Practise saying what you did without stretching it, then explaining plainly how you'd get up to speed.
- **Salary.** The pack has you say £42,000 once, then stop. It sits inside the £38,000–£44,000 range. You said "hoping for", so the pack doesn't turn it into a minimum.

Say the word and I'll play Hannah on B2, with follow-ups that react to what you actually say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, a 30-minute phone call. Hannah Lowther (Talent Partner) will ring the mobile number on your application.
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.
**Built on:** the advert you pasted, Hannah's message, and your description of yourself. Research could not run (see Sources), so nothing here says anything about Quillmoor beyond the advert.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Where guidance says "answer slot", it is an instruction for the interview, addressed to your answer on the day. Fill it from what really happened. If the practice it names was not yours, or never existed, the honest answer says so plainly and returns to what you did do.

The highest-ROI prep in this pack is **B2**, the production-scheduling question. Do that one aloud until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, with nothing on production, planning or QA, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning and QA, so expect a probe on which of those you have worked with. If any of your scheduling put you in contact with either, say which and what was yours, in your own words; if it did not, or production scheduling was never part of your work, say so plainly and stay with the three depots |
| F2 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [grounded] | discovery | Your sentence says chasing when orders slip, not how you know an order has slipped. Answer slot: the advert asks you to track supplier deliveries, so expect a probe on how. If you follow deliveries in a system or sheet, say which and how often you look; if there is no tracking step of your own, say so plainly and stay with the chasing |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but the figure is a magnet for a probe. Say it as you said it: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The defend-the-number slots are in C1 and E2 |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: the advert names a weekly on-time dispatch report, so expect a probe. If you produce any regular report on deliveries, say what it covers, how often, and who reads it; if you do not, say so plainly and say how you would set one up, as a plan |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [grounded] | discovery | Your sentence says spreadsheet, not which tool. Answer slot: if it was Excel, say so and say what you did in it, in your own words; if it was another tool, or you cannot speak to a particular feature, say so plainly and stay with what the rebuild covered |
| F7 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | The negative is yours, and the words are yours: "Never used SAP". The in-house system stays at its own scope: "we run our own in-house stock system". Answer slot: if you work in that system yourself, say what for; if you do not, say so plainly. Never present it as SAP-equivalent experience |
| F8 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. State the four years and the title in those terms |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | medium | [grounded] | none | The pack's own observation: £42,000 sits inside the advertised range. Your word is "hoping", not a floor, and the bridge keeps it. Say the figure |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Met on your own statement. Keep the two parts at their strength: two days is fine, and more than three is something you would not want |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Your material does not state it. Answer slot: say your contractual notice period exactly as your contract gives it; if you do not know it offhand, check before Thursday |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | The reason is a plain fact and needs no dressing. Keep to its words: the office closes next year, the only offer is relocating to Reading, and you do not want that |

## Persona table

The only loop source is Hannah's message. It establishes this one call and its agenda, and says nothing about later rounds, so the weights below are for this call only.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | A friendly run through the journey, then the four items she listed | Highest. A recruiter screen prior is conversational plus a light skeptic, and her four topics are logistics and knockout checks asked in a friendly register. Risk: treating it as unscored | A 90-second arc (A1); the figures and the facts ready before Thursday (A4, A5) |
| Skeptic (B) | Quiet probing of the gaps: SAP, production scheduling, why leave, why here, why now | High. The advert asks for production coordination and ERP, and F1 and F7 are where your material is thinnest. "What is prompting a move" is her own agenda item | Rehearse B2 until it is boring; bridge only from your stated words, and say the limit plainly |
| Data-Driven Prober (C) | Checks of the advert's named requirements: Excel, reporting, the stock-count figure | Medium. A Talent Partner is more likely to tick off named requirements than to dig into a number, but the one figure you gave is the easiest thing to probe | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Case / Strategist (D) | A live problem from the role: a late supplier, a stock mismatch, a scheduling clash | Lower on this call. Her message says she will tell you about the team and the next steps, so live problems more likely belong to a later conversation, which the material does not describe | Clarify first, structure second, think aloud |
| Pressure (E) | A time-boxed challenge: why you rather than someone from manufacturing | Lowest. Nothing in her message suggests a stress style | Pause, restate, hold through two follow-ups, then concede specifically |

No values-style round is detected, because her message names none, so there is no values cheat sheet. The Peer persona is left out because nothing in the material puts a peer on this call.

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on three beats the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words in about 90 seconds, then stop and let her pick what to follow | F8, F2 and F4 carry the three beats. EXP because it is the biography question asked casually and scored on economy |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the facts the sentence states, in your own words: the office closes next year, the only offer is relocating to Reading, and you do not want that. Keep to "closing" and "relocating". Answer slot: if something in the advert draws you to this role, say what; if the move is driven by the office closing, say so plainly and do not invent a draw | F12 is her own agenda item and the first thing she will weigh for consistency. EXP because it tests whether your account is the same on every telling |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Lead with the two days: it is fine, and you live in north Bristol. If the conversation moves to more than two days, say what the sentence says, that you would not want more than three, as a preference and no stronger. Add no commute detail and no reason you have not stated | F10 is a stated term she listed. JD because it scores a term the advert fixes |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure once, plainly, and stop: "I'm hoping for £42,000." The advert's range is £38,000–£44,000, so it sits inside it. Answer slot: if she asks whether the figure is firm, decide before Thursday what you will say; your message says "hoping" and the pack does not turn it into a floor. If she asks your current salary, decide beforehand whether you will share it; the pack has no figure and supplies none | F9 is the first item on her list and the one where wording cannot be repaired after the call. JD because the advert prices the role |
| A5 | "What's your notice period, and is there any flexibility on it?" | JD | [grounded] | Answer slot: give your contractual notice period exactly as your contract states it. If you do not know it offhand, check before Thursday. If she asks about flexibility, say what you know, and say plainly if you have not asked your employer. Do not guess a number | F11 is on her list and your material is silent on it. JD because it is a term of the hire |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name the gap first and plainly: "Never used SAP." Then the in-house system at its own scope: "we run our own in-house stock system." Answer slot: if you work in that system yourself, say what for; if you do not, say so plainly. Then how you would learn SAP, said as a plan and never as something already done. The advert calls ERP "a plus", so say it as a gap you will close | F7 is where the advert's plus meets your stated negative. JD because it scores a listed qualification |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that's closest to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling put you in contact with a planning or quality function, say which and what was yours, in your own words; if it did not, or production scheduling was never part of your work, say so plainly and stay with the three depots. Follow-up one, "so that's deliveries, not production?": answer from whichever branch is true, then return to the quote. Follow-up two, "how would you get up to speed?": a plan, said as a plan, such as what you would ask to see in your first weeks. Concede the limit explicitly and specifically, and do not fold on the part the quote does carry, the scheduling and the chasing | F1 is the advert's core duty and the thinnest row in the snapshot, so this objection arrives in some form. JD because it scores the stated responsibility |
| B3 | "Why Quillmoor, and why this role?" | CO | [generic] | Selection scaffold: pick one or two things in the advert that you actually care about. It describes a diagnostic-test manufacturer of about 400 staff, with work across planning, the warehouse and QA. Say why, in your own words. If nothing draws you beyond the location and the office closing, say so plainly and do not invent an interest in diagnostics. Then ask her to tell you more about the team (reverse question 1) | Research could not run, so this question carries no knowledge of Quillmoor beyond the advert. CO because it scores homework depth, and `[generic]` because the pack has nothing to ground it |
| B4 | "Your office closes next year. Why move now rather than wait?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | The sentence gives the closure date and the Reading offer, not why you are moving before it closes. Answer slot: if there is a reason you want to move before it closes, say it in your own words; if not, say so plainly and stay with what the sentence states | F12 gives the facts but not the timing, so "why now" is the natural follow-up. EXP because it tests consistency of your own story |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the figure as you said it: about a third, over a year. Answer slot: say how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly. Do not tidy "about a third" into a precise percentage and do not add a baseline | F4 holds the only figure you gave. EXP because probers test whether a number survives its second question |
| C2 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: the sentence says spreadsheet, not Excel. If it was Excel, say so and say what you did in it, in your own words; if it was another tool, or you cannot speak to a particular feature, say so plainly and stay with what the rebuild covered | F6 is a named requirement and a likely tick-box. JD because it scores a listed skill |
| C3 | "When have you reported on delivery performance, and what was the report?" | JD | [grounded] | Open prompt, no event supplied. If a report comes to mind, say what it covered, how often it went out, and who read it, in your own words. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach a weekly on-time dispatch report, as a plan | F5 has no evidence in your material, and the advert names the weekly report. JD because it scores a stated duty |
| C4 | "Tell me about a time a supplier order slipped and you chased it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The sentence supports one beat: you chase suppliers when orders slip. Answer slot: choose one real instance and say what slipped, whom you chased, and what happened, in your own words. If no single instance comes to mind, say so plainly, then describe how you usually handle a slipped order | F2 is the advert's second duty, and an instance is how it gets tested. EXP because it scores what was actually yours |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that a delivery QA is waiting on will be four days late. What do you do?" | CASE | [generic] | Structure it aloud: what you need to know first (what is late, what depends on it, whether a partial delivery is possible); who must hear today (planning, the warehouse and QA, the three teams the advert names); the options and what each costs; what you would record and when you would chase again. The question needs no claim about your past, so the guidance makes none | A live problem from F2 and F3's requirements. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "The system says a component is in stock and the warehouse can't find it. Walk me through the next hour." | CASE | [generic] | Clarify first: is it one item or a pattern, when was it last booked, is anything waiting on it. Then the physical check, who needs telling, how the record gets corrected, and when a repeat would deserve a closer look. No claim about your own past | F4's requirement set as a decision rather than a record. `[generic]` for the same reason as D1 |
| D3 | "Planning wants a batch run on Tuesday, the warehouse says the stock won't be ready, and QA hasn't released the last lot. How do you decide what happens?" | CASE | [generic] | Ask what each team needs and by when. Separate facts from preferences. Offer options rather than a verdict, say what you would escalate and with what, and record the decision. If you are unsure where your remit ends, say that you would check it rather than assume. No claim about your past | The seam between planning, the warehouse and QA is the advert's core coordination task (F1). `[generic]` because the problem is set in the role, not in your history |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who has worked in manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause, restate the question, then hold what the quotes carry: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip, and rebuilding the stock-count spreadsheet. Hold through two follow-ups by returning to those facts, never by adding to them. Answer slot: if you have worked alongside a manufacturing function, say so; if not, say so plainly and return to the facts. Concede the limit specifically and do not fold on what the quotes do carry | F1 and F8 together make this the Pressure version of B2. JD because it scores fit against the stated requirements |
| E2 | "How much of that drop in discrepancies was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what is yours: "I rebuilt our stock-count spreadsheet." What fell was discrepancies, by about a third over a year. Answer slot: if anything else changed over that year, say what; if you do not know what else changed, or the rebuild was the main change, say which plainly. Do not claim the rebuild alone caused the fall unless that is what you can say. Hold through two follow-ups, then concede what you do not know | F4 is the figure a pressure interviewer attacks on attribution. EXP because it tests what was actually yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA (F1) | B2, D3, E1 |
| Track supplier deliveries and chase late orders (F2, F3) | C4, D1, A1 |
| Keep stock records accurate (F4) | C1, D2, E2 |
| Report weekly on on-time dispatch (F5) | C3 |
| Confident with Excel (F6) | C2 |
| ERP experience, a plus (F7) | B1 |
| 2+ years in operations or logistics coordination (F8) | A1, E1 |
| Salary (F9) | A4 |
| Hybrid pattern (F10) | A3 |
| Notice period (F11) | A5 |
| What is prompting a move (F12) | A2, B4 |
| Why Quillmoor, no advert requirement | B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I be working alongside day to day across planning, the warehouse and QA?" | She has offered to describe the team, and the advert names those three functions, so it shows you read the role |
| R2 | "What does on-time dispatch look like today, and what is the weekly report used for?" | It picks up the advert's own reporting duty and asks what the number is for |
| R3 | "Which system does the site run for stock and orders, and how is training handled for someone arriving from an in-house system?" | It raises the ERP point on your terms, as a question about ramp-up, before she does |
| R4 | "How are the two days at Avonmouth usually arranged, fixed days or agreed with the team?" | It turns the hybrid item from a check into a practical conversation |
| R5 | "What does the rest of the process look like, and what would the next conversation focus on?" | You find out what to prepare next, and it signals you are planning ahead |
| R6 | "Is the range fixed, and where would you expect an offer to sit for the right profile?" | It is a direct salary question that follows from A4 and shows you take the range seriously |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having SAP or ERP experience | Negative you stated, F7 | Your sentence: "Never used SAP — we run our own in-house stock system." The plain acknowledgment is "Never used SAP", and the in-house system stays at its own scope |
| Coordinating production schedules, or working with planning or QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says delivery scheduling, not production. B2's slot stays inside the three depots |
| That your rebuild cut discrepancies by a third, or by an exact percentage | Inflated form of F4 | F4's quote as you gave it: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence says the discrepancies fell, not why |
| That you were made redundant or that your role is ending | Inflated form of F12 | F12's quote at its own scope: the office closes next year and the only offer is relocating to Reading. The limit is the pack's observation: your material says an offer to relocate, nothing about your role ending |
| That £42,000 is your minimum | Inflated form of F9 | F9's quote: "I'm hoping for £42,000." The limit is the pack's observation: your word is "hoping", not a floor |
| That three days a week is a hard limit, or that more days would be fine | Inflated form of F10 | F10's quote at its own strength: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

## Sources

Provided: the advert you pasted, Hannah Lowther's LinkedIn message, and your description of your background and reasons.

Searches sent, all refused, none returned anything:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news strategy" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Every call was refused. It would have named published values; no values-style round is detected, so no cheat sheet is missing, but B3 stays generic |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Every call was refused. It would have shown the rounds after this call; the persona weights cover this call only |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Every call was refused. It would have grounded B3 and a CO question in current priorities; those cells are generic |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Every call was refused. It would have supported an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative operations coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your contractual notice period → F11 becomes a quoted row, and A5's answer slot becomes a story-mapped answer
- Which tool the stock-count spreadsheet was built in, and what you changed in it → F6 and F4 gain evidence, and C1, C2 and E2's answer slots become story-mapped
- Any regular report you produce on deliveries or dispatch → F5 moves from a gap to a row with evidence, and C3 becomes story-mapped
- Whether you use the in-house stock system yourself, and for what → F7 becomes a firmer row and B1's answer slot becomes story-mapped
- Any contact you have had with a planning or quality function → F1 and B2's answer slot become story-mapped
- Why you want to move before the Bristol office closes, and what in the advert draws you → B3 and B4's answer slots become story-mapped
- A pasted values page, strategy note or loop description for Quillmoor, or search permission → B3 and the CASE bank gain grounding, an interviewer read becomes possible, and later rounds can be weighted
- Deep research (L2), up to 6 further searches and 2 further fetches and several more minutes → a strategy brief for CO questions, if search permission is granted
- A tuesday-dossier.md from job-underwriter → verified evidence rows and a prohibited-claims list from a separate evaluation of the role
- Hannah's recruiter notes, if she sends any → any further focus areas for the call
