I've read the pack rules and I'm now running the company research: values, hiring process, recent news and Hannah's public professional profile.
Web search wasn't permitted, so the pack is built from the advert, Hannah's message and what you told me. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/e23/part-7/rooms/case-13-denied-9e4d2de2/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It has 18 questions, a fit snapshot of the advert against what you told me, and six questions to ask Hannah. It also lists the claims the pack won't coach.

- **No company research:** web search wasn't permitted, so none ran. The pack rests on the advert, Hannah's message and your notes. The "what do you know about us?" answer is limited to what the advert says.
- **Hardest question to rehearse:** B1. A manufacturer will ask how scheduling deliveries at a wholesaler links to coordinating production schedules. Your material covers the deliveries and not the production side.
- **Salary, hybrid and reason for leaving:** these are straightforward. £42,000 sits inside the £38,000–£44,000 band. Your two-day comfort and three-day ceiling match what you told me. Your Reading answer works if you stay with the facts you gave me.
- **Gaps with no wording to cover them:** weekly dispatch reporting, Excel specifics and the in-house stock system. The pack has no words for these, so it leaves slots for you to answer from your own experience.

Say the word and I'll play Hannah on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What's your notice period? Your material doesn't say, and Hannah has it on her list, so I've left that row open until you tell me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen with Hannah Lowther, Talent Partner. Thursday 2pm, 30 minutes, by phone (she rings the mobile number on your application).
**Her stated agenda:** "salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.
**Built on:** the advert, Hannah's message and your notes only. No company research ran (see Sources), so nothing here is a claim about Quillmoor beyond what the advert says.

## How to use this pack

- Personas describe how a question is asked. Types describe what it is scored on.
- Type key:
  - VAL: past behaviour against a company's published values. None appear in this pack, because no values page was read.
  - EXP: whether what you say about your work survives follow-up.
  - JD: a stated requirement or term of the role.
  - CO: what you know about the company.
  - CASE: a live problem set in the role.
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "Answer slot", it describes what an interviewer may probe. Answer from your own experience, and if the practice was not yours or did not exist, say so plainly.
- The highest-ROI rehearsal is **B1**: the link between scheduling deliveries at a wholesaler and coordinating production schedules at a manufacturer. Rehearse it until it is boring.
- Persona Peer is included because later rounds may use it. It is unlikely on Thursday's call.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and the words stay at the depots: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on who you coordinated with is likely. If you worked with any of those functions, or others, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you chase suppliers when orders slip, because a named action beats an adjective |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The sentence says you rebuilt the spreadsheet and that discrepancies fell. It does not say one caused the other, so the words stay as written. The figure raises the defend-the-number slots, rehearsed in C1 and D2 |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material says nothing on reporting. Answer slot: the advert's weekly line makes a probe likely. If you produce or contribute to any regular report, say what it covers and how often, in your own words; if you do not, say so plainly and say what you would want to count first |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap: the quote gives the years and the title in the advert's terms. Say it as written and expect follow-ups on its detail |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Derived from a spreadsheet to Excel; the sentence does not name the tool. Answer slot: the advert's Excel line makes a probe on what you do in it likely. If it was Excel, say what you did in it, in your own words; if it was another tool, or you cannot name specifics, say so plainly and say which tool |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | The advert marks this as a plus, not a requirement. Words: "I haven't used SAP; we run our own in-house stock system." Answer slot: if you recorded or looked up stock in the in-house system, say what, in your own words; if you did not, say so plainly. The pack does not call the in-house system an ERP |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | £42,000 sits inside the advertised range. Your words: "I'm hoping for £42,000." |
| F9 | "two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your stated two days match the advert; your stated ceiling is three. Say both in your own words |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a fact from your contract, and no wording changes it |
| F11 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. The words are the quote's own facts: the office closing next year, the only offer being Reading, and that you don't want it. Add no reasons the quote does not carry |

## Persona table

The loop is not documented: no source says what rounds follow this call. Weights for later rounds rest on a generic pattern of screen, then hiring manager, then panel, not on Quillmoor's process. This call's weights come from the recruiter-screen prior.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational (5 questions) | Friendly walk through the four agenda items, then the journey | Highest. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah listed her agenda in advance. The risk is treating the casual register as unscored | A short arc built only from your quoted sentences (A5); one plain sentence for each agenda item |
| B. Skeptic (3) | Quiet probing of the gaps: production versus delivery scheduling, no SAP, weakest area | Medium. The prior says light Skeptic, and F1 and F7 are the two rows where the advert asks for more than your material shows | Rehearse B1 until boring; bridge only from your quotes; where there is no quote, say the limit plainly and give a plan |
| C. Data-Driven Prober (3) | Asks how the one figure on your list was counted, and what you do in Excel | Medium. Your only figure is the stock-count result in F3, and the advert asks for Excel confidence | Know what you can and cannot say about how it was counted; say plainly if you do not know |
| E. Case or Strategist (3) | Live problems from the advert's own lines | Medium. Later rounds are more likely to use these than a recruiter call, but a short scenario is possible | Clarify, then structure, then answer, thinking aloud |
| D. Pressure (2) | Time-boxed challenge on why you over someone with SAP | Low for a recruiter call | Hold your position through two follow-ups, then concede only what is true |
| F. Peer Evaluator (2) | Collaboration and seam questions between planning, warehouse and QA | Low for Thursday; plausible in a team round | Describe how you work with people outside your reporting line, without inventing a seam |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B1, B3, D1, E2, F1, F2 |
| "track supplier deliveries and chase late orders" | A5, E2 |
| "keep stock records accurate" | C1, D2, E3 |
| "report weekly on on-time dispatch" | C3 |
| "2+ years in operations or logistics coordination" | A5 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B2, B3 |
| "£38,000–£44,000" | A1 |
| "two days a week at our Avonmouth site in Bristol" | A3 |
| Notice period | A2 |
| What is prompting a move | A4 |

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations for this role?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure in one sentence, in your own words: you are hoping for £42,000. Then stop. Answer slot: if she asks how you reached it, or what you earn now, decide beforehand what you will say. The pack has nothing on current pay and supplies no market comparison. If you cannot say why that figure, say plainly it is what you are hoping for | F8 is a stated term and her first agenda item; JD because it is a term of the advertised role |
| A2 | "What's your notice period?" | JD | [grounded] | State the figure from your contract plainly. Your material does not establish it, so check your contract before Thursday and say what it says. Do not promise an earlier date you cannot confirm | F10 is a gate: it is surfaced, never bridged. JD because it is a term of the role, not a story |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say the quote's two facts in your own words: two days at Avonmouth is fine, and three is your ceiling. Answer slot: if she asks which days, say your preference only if you have one; if you have none, say so plainly | F9 is a stated term and her third agenda item |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the quote's facts: the office is closing next year, the only offer is relocation to Reading, and you don't want it. Stay inside them. Answer slot: if she asks why not Reading, give your own reason in your own words; the pack has none for you. If you have no reason beyond preferring to stay in Bristol, say that plainly | F11 is the motivation check; EXP because the story is tested for consistency against the rest of your answers |
| A5 | "Tell me about your background and what draws you to this role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | A short arc of the beats the quotes state: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers when orders slip. Answer slot: what draws you is yours to say. The advert names tracking supplier deliveries and chasing late orders; if one of its lines draws you, say which and why; if the main draw is a Bristol role that uses what you do now, say that plainly | F2 and F5 carry the arc; EXP because it is the biography question, and casual openers are still scored |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role is production scheduling at a manufacturer, and your background is scheduling deliveries at a wholesaler. Help me see the link." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." "4 years as a logistics coordinator at a building-supplies wholesaler." | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip. First follow-up, who you worked with: answer slot as in F1. If you worked with planning, warehouse or QA-type teams, say who and how; if none, or it was not yours, say so plainly and stay with the depots. Second follow-up, how you would close the difference: say it as a plan, such as what you would ask to be shown in the first weeks, never as a past. Your concession wording is the slot's second branch, because the pack cannot write your negatives for you | F1 is the row where the advert asks for more than your material shows. JD because it scores the stated requirement; the Skeptic delivery is why it is rehearsed hardest |
| B2 | "SAP or similar is a plus. What's your ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it as written: "I haven't used SAP; we run our own in-house stock system." Answer slot: if you recorded or looked up stock in that system, say what, in your own words; if you did not, say so plainly. Add a plan for learning a new system, said as a future. Do not call the in-house system an ERP | F7 is a stated gap on a plus, not a requirement; JD because it is a listed qualification |
| B3 | "Which part of this would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pick one limit your material shows, F1 or F7, and name it before she does, in the quotes' terms. Then give a plan for closing it. Answer slot: if neither is your real answer, say what is, in your own words | F1 and F7 are the two largest gaps; JD because it asks about the advert's own requirements |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot, the four a figure raises: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; "I don't know how it was counted" is an honest branch. The pack supplies no baseline, method or cause | F3 holds your only figure, and a figure draws probes; EXP because it tests attribution |
| C2 | "How confident are you in Excel? What do you actually do in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from the quote: you rebuilt a stock-count spreadsheet. Answer slot: if it was Excel, say what you did in it; if it was another tool, or you cannot name specifics, say so plainly and say which tool | F6 is derived from a spreadsheet, not shown to be Excel; JD because the advert states it |
| C3 | "The role reports weekly on on-time dispatch. What reporting do you do today?" | JD | [grounded] | Answer slot: if you produce or contribute to a regular report, say what it covers and how often, in your own words. If there is none, say so plainly, then say what you would want to count first and why | F4 has no evidence either way; JD because the advert lists it |

### E. Case or Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What do you know about Quillmoor?" | CO | [grounded] advert: "diagnostic-test manufacturer, about 400 staff" | Company research did not run, so say only what the advert says: a diagnostic-test manufacturer of about 400 staff, with a site at Avonmouth and a role that links planning, the warehouse and QA. Then say what you would like to learn. Before Thursday, read Quillmoor's own site and note two things you would say, in your own words. Add nothing about products or customers you have not read | A homework check with no research behind the pack; CO because it tests preparation, and the `[grounded]` label covers the advert's words only |
| E2 | "A supplier tells you on Friday that a delivery needed Monday morning will arrive three days late. What do you do first?" | CASE | [generic] | Structure it: ask what the delivery is for and what is waiting on it; list options such as a partial delivery, an alternative source or a reschedule; say who you would tell, with planning, the warehouse and QA as the advert's three functions; say what you would record. The question needs no claim about your past, so the guidance makes none | The advert's "chase late orders" line as a live decision; `[generic]` because it is a pattern, not a fact about Quillmoor |
| E3 | "The stock record says 120 units and the shelf has 112. What do you do?" | CASE | [generic] | Structure it: confirm the count, check recent movements, find the source of the difference, correct the record, and say what you would do to stop it recurring. Think aloud and ask a clarifying question first. No claim about your past | The advert's "keep stock records accurate" line as a live problem; `[generic]` for the same reason |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we pick you over a candidate with SAP and production experience?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause and restate the question. Hold on what you do, in the quotes' words, and make no comparison with other candidates. Hold through two follow-ups. Concede what is true: "I haven't used SAP; we run our own in-house stock system." Do not claim production experience | F1 and F7 under time pressure; JD because the content is the advert's requirements |
| D2 | "That result. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold: "I rebuilt our stock-count spreadsheet" is yours as written. Answer slot: if anything else contributed to the fall, say what, in your own words; if nothing did, or you do not know, say so plainly. Never claim the fall as yours alone unless that is true | F3 is where attribution is probed; EXP because it tests exactly what was yours |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Planning wants a rush order, the warehouse says it can't be done, and QA hasn't released the batch. Where does that land with you?" | CASE | [generic] | Structure it: clarify what each function needs and by when, set out the trade-off to each, propose a decision rule rather than pretending to know the seam, and say who you would escalate to. No claim about your past | The advert's three functions as a seam problem; `[generic]` because it carries no Quillmoor fact |
| F2 | "Tell me about a time you had to get two teams who wanted different things to agree." | EXP | [generic] | Selection scaffold: pick a time with a named disagreement, a decision you helped reach, and an intact working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The advert's coordination across planning, the warehouse and QA raises the theme; no quote carries a story for it, so it is a scaffold |

## Reverse questions

| # | Ask Hannah | Why it lands |
|---|---|---|
| R1 | "After this call, who would I meet, in what order, and roughly when?" | She said she will cover next steps, and it tells you what the later rounds are |
| R2 | "How does the team split work between planning, the warehouse and QA, and where does this role sit between them?" | It uses the advert's own three functions and shows you read it |
| R3 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It turns the advert's reporting line into a conversation about the job |
| R4 | "Which system does the team run stock and orders on, and what would training look like for a new starter?" | It faces the SAP gap as a question about learning, not a claim |
| R5 | "On the two days at Avonmouth, are they fixed days or agreed with the team?" | You have already said two is fine and three is your ceiling; this checks how the pattern is set |
| R6 | "What would a good first three months look like? If you can't say, who could?" | It signals you are already thinking about contributing, and finds the person who knows |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: you schedule deliveries for three depots. The limit is the pack's observation: the material says deliveries, not production schedules. B1's slot stays inside the depots |
| The rebuilt spreadsheet reduced discrepancies by a third | Inflated form of F3 | F3's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The pack's observation is that the sentence does not link the two. C1 and D2 ask only what was counted and what was yours |
| Advanced Excel skills, or any named Excel feature | Inflated form of F6 | F6's quote at its own scope: you rebuilt a stock-count spreadsheet. C2's slot asks only what you did in it |
| Used an ERP, or the in-house stock system is an ERP | Inflated form of F7 | F7's quote at its own scope: "Never used SAP — we run our own in-house stock system." The plain acknowledgment F7 gives: "I haven't used SAP." |

## Sources

**Provided documents:** your message, which contained the advert as pasted, Hannah's LinkedIn message as pasted, and your own background and constraints. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics company values` | unavailable | Call refused (search permission not granted). Would have moved a values cheat sheet; none is built, so section is dropped |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Call refused. Would have moved loop structure and persona weights for later rounds; those rest on a generic pattern instead |
| 3. `Quillmoor Diagnostics Avonmouth Bristol news` | unavailable | Call refused. Would have moved the CO bank; E1 is limited to the advert's own words |
| 4. `Hannah Lowther Talent Partner Quillmoor Diagnostics` | unavailable | Call refused. Would have moved an interviewer read; the section is dropped and reverse questions are role-generic |
| 5. representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission for company research → a values cheat sheet if Quillmoor publishes values, a documented loop for later rounds, and a CO bank grounded in current news instead of the advert alone
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy and org context for CO and CASE questions; offered once
- Your notice period, stated outside this pack → F10 becomes a settled term and A2 is answered from your contract
- Your CV → F1, F2, F3, F5 and F7 rows can be graded against more than one message, and some `medium` rows may rise
- Your answers to the slots in F1, F4, F6 and F7, stated outside this pack → those rows regenerate from your own words
- Hannah's public profile or career path → an interviewer read and a reverse question tied to her path
- An email to Hannah asking what rounds follow this call → persona weights for later rounds move from a pattern to a documented loop
- A tuesday-dossier.md from job-underwriter → verified evidence, absolute prohibited claims and an evidence-based top objection in place of the one inferred here
