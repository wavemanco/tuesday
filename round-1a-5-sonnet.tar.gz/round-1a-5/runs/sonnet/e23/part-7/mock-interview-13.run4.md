I'll read the reference files the skill points to before writing the pack.
Your prep pack for the Thursday 2pm call with Hannah is saved as `/var/tmp/tuesday-measure/1a5/runs/sonnet/e23/part-7/rooms/case-13-denied-1049297c/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for a recruiter screen and covered her four topics: salary, notice period, hybrid pattern and why you're moving.

- **Search:** My three company searches were refused, because search permission wasn't granted. The company-knowledge question (A5) rests only on the advert's wording, and there's no interviewer read for Hannah. The pack's Sources section records the refusals, and the upgrade menu lists what each missing piece would add.
- **Notice period:** You didn't give one, so A4 has a slot for it. Check your contract before Thursday.
- **Weakest spot:** Your delivery scheduling doesn't obviously match "coordinate production schedules between planning, the warehouse and QA". B2 is the highest-ROI rehearsal, with a three-step follow-up ladder.
- **SAP:** B3 has a plain "I've never used SAP", plus a slot for whether you use your in-house stock system yourself.
- **Salary and hybrid:** Your £42,000 sits inside the £38,000–£44,000 range, and your hybrid limit matches the advert. A2 and A3 keep both as you phrased them: "hoping for" and "wouldn't want more than three".

Say the word and I'll play Hannah on B2, the production-scheduling question, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Round: recruiter screen, a 30-minute phone call, Thursday at 2pm. Interviewer: Hannah Lowther, Talent Partner, who will ring the mobile number on your application. Her stated agenda, in her words: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.

Built from: the advert you pasted, your background notes, and Hannah's message. No company research could run (see Sources), so company-level material is labeled accordingly.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims about your work survive follow-up, and what was actually yours |
| JD | Whether you fit the advert's stated duties, requirements and terms |
| CO | How well you know the company and its strategy |
| CASE | How you structure a live problem from the role |

An answer slot is an instruction for the call, not a question for this conversation. Answer it from your own experience: either branch is fine, and "that was not mine" or "there was no such step" is a complete answer.

The highest-ROI rehearsal in this pack is B2, the production-scheduling question. It is the advert's first duty and the place your material is thinnest.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries and suppliers, and says nothing about production schedules, planning or QA. The words stay at that scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of your scheduling involved a planning team or quality checks, say which and what part was yours; if none did, or it was not yours, say so plainly and stay with the depots and the suppliers |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a stated line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Chasing suppliers is not the same as tracking their deliveries, and the bridge should not be stretched. Answer slot: if you kept track of what suppliers had delivered or were due to deliver, say what you tracked it in, in your own words; if you did not, or it was not yours, say so plainly and stay with chasing when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, with a figure that will be probed. The sentence says you rebuilt the spreadsheet and that discrepancies fell by about a third over a year; it states no link between the two, so the pack makes none. The defend-the-number slots are in C1 and E2 |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: the advert's weekly-report line makes a probe on what you report likely. If you produce any regular report, say what is in it and who reads it, in your own words; if you do not, say so plainly and say what you would put in a first weekly report |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap: the sentence says four years as a logistics coordinator, against the advert's two-plus. Say it in the quote's own terms |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, and says nothing about confidence. Answer slot: say what the spreadsheet was built in. If it was Excel, say what you did in it, in your own words; if it was another tool, or the work was not yours, say so plainly and stay with the stock-count spreadsheet |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | The words for SAP are the ones you gave: "I've never used SAP." Whether the in-house stock system counts as similar is the one open piece. Answer slot: the advert's "or similar" makes a probe on it likely. If you work in that system yourself, say what you do in it, in your own words; if you do not, or it is not a system you work in, say so plainly. Never a claim to ERP experience |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Inside the advertised range. The quote is a hope, and the words stay a hope: "I'm hoping for £42,000." The pack makes no claim that it is a floor |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The terms match. Say both halves as the quote does: two days is fine, and you wouldn't want more than three |
| F11 | "your notice period" — Hannah Lowther's LinkedIn message | none given | none | [grounded] | discovery | Your material does not give a notice period. Answer slot: state it as your contract gives it, in your own words; if you are unsure, say so plainly and say when you can confirm |
| F12 | "what's prompting a move" — Hannah Lowther's LinkedIn message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. The reason is stated and the words stay as stated: the Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want |

## Persona table

Weights start from the recruiter-screen prior (Conversational plus a light Skeptic) and are adjusted by Hannah's own agenda. Her message names one session, so no loop beyond this call is assumed; what comes after it is not established.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly walk-through, then her four agenda items asked casually | Highest: her message lists salary, notice, hybrid and motivation, and all four are casual-register questions that are still scored | Rehearse a 90-second arc and a one-line answer to each agenda item; treat the casual ones as scored |
| B. Skeptic | Quiet probing of why you are leaving and where the advert outruns your background | Second: "what's prompting a move" is on her agenda, and F1, F3 and F8 are where the advert asks for more than your material shows | Rehearse B2 until it is boring; build every bridge from your own sentences, and say the limit plainly where there is none |
| C. Data-Driven Prober | Asks how the stock-count figure was counted, or what the spreadsheet was | Third: not on her stated agenda, but F4 carries a figure and a recruiter reading your application may ask about it | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| D. Case / Strategist | A live problem from the role | Low for this call: nothing in her agenda asks for one; kept as insurance for a later round, whose shape is not established | Clarify, then structure, then answer; think aloud |
| E. Pressure | Time-boxed challenge, "why you over someone with manufacturing experience" | Low: a recruiter screen can contain one challenge, and F1 is where it would land | Pause, restate, hold through two follow-ups, concede only what the quotes do not carry |
| F. Values / Behavioral | "Tell me about a time…" prompts themed from the advert's duties | Low: no values-style round is detected, and the company's published values could not be read, so these are themed from the advert only | Pick an instance you can tell with its outcome, or say plainly none comes to mind |

## Question banks

### A. Conversational (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: where you are now and what's led you to Quillmoor." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three beats, each a clause the quotes state, in your own words: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for the three depots and chasing suppliers when orders slip; and why you are looking, which is the Bristol office closing next year with Reading the only offer. Stay with the facts as you gave them. Answer slot: say what in the advert drew you to this role at Quillmoor; if nothing beyond the fit comes to mind, say so plainly and name the line of the advert that matches the work you described | F6 and F12 are the evidence; EXP because the opening question checks that your account of your own work is consistent from the first minute |
| A2 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say both halves as you gave them: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. Do not turn the second half into "flexible" or into a hard limit; it is neither in your sentence. Answer slot: if she asks about getting to site or fixed days, answer from your own situation; if you do not know yet, say so plainly | F10 is a stated term and one of her four agenda items; JD because it scores fit against the advert's own hybrid line |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say it as a hope and stop: "I'm hoping for £42,000." Do not add a justification you cannot back. Answer slot: if she asks whether there is room either side, say whether there is, in your own words; if there is not, say so plainly. Decide before Thursday which it is | F9 is her first agenda item and sits inside the advert's range; JD because the range is the advert's own |
| A4 | "What's your notice period?" | JD | [grounded] | Give it as your contract states it, in a sentence. Answer slot: if you are not sure of the exact terms, say so plainly and say when you can confirm | F11 is her second agenda item and your material does not give it; JD because it scores the posting's practical terms, not experience |
| A5 | "What do you know about us, and what made you apply?" | CO | [grounded] | Use only what the advert says: a diagnostic-test manufacturer, about 400 staff, and the Avonmouth site. No further company research could run, so claim nothing beyond that; if you read more before Thursday, say where you read it. Answer slot: say what made you apply, in your own words; if the honest answer is mostly the fit and the location, say so plainly | The advert is the only company source in hand; CO because it scores homework, and the pack can only coach the part that is grounded |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have a job. Why leave now?" | JD | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as you gave it: the Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. Keep it factual and short. If she asks whether you would consider Reading, answer from the sentence: you don't want it. Answer slot: if she asks why Quillmoor in particular, say what draws you to this role in your own words; if Bristol is a large part of it, say so plainly | F12 is on her agenda and F10 is the posting's Bristol-based term; JD because it scores whether the stated reason fits the role's own terms |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that's closest to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Let her draw any link to production; do not assert one. Answer slot: if any of your scheduling involved a planning team or quality checks, say which and what part was yours; if none did, or it was not yours, say so plainly and return to the depots and the suppliers. Ladder below | F1 is the advert's first duty and where the material is thinnest, so this objection arrives in some form; JD because it scores the stated requirement |
| B3 | "The advert mentions SAP or similar. What have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say "I've never used SAP." Then the one open piece. Answer slot: if you work in your company's in-house stock system yourself, say what you do in it, in your own words; if you do not, say so plainly. Do not call it an ERP | F8 is a stated gap on a requirement the advert marks as a plus; JD because it scores the listed qualification |
| B4 | "Which part of this advert would be hardest on day one?" | JD | [generic] | The pack's reading of the advert against your material: F1, F5 and F8 are where the material is thinnest. Answer slot: name the line you would find hardest, in your own words, and say how you would close it; if none comes to mind, say so plainly and name the line you have least to show for. Say the plan as a plan, never as a past | The stem is a standard Skeptic probe, so it carries no claim about you; JD because it scores honest self-assessment against the listed duties |

B2 rehearsal ladder:

| Level | Likely line from her | Holding move |
|---|---|---|
| 1 | "That's delivery scheduling. How does it connect to production?" | Return to the quote at its own scope; let her draw the link |
| 2 | "Have you worked directly with a planning team or QA?" | The B2 answer slot, either branch, said plainly |
| 3 | "What would you want to learn first if you started?" | A plan in your own words, said as a plan and never as a past claim |

The limit the pack names before she asks: your material says deliveries and suppliers, and does not say production, planning or QA.

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence as you gave it. Then four slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; and which part was yours. For any of the four you do not know, "I don't know how that was counted" is a complete answer | F4 carries the CV-style figure, and quantified claims are where probes land; EXP because it tests attribution |
| C2 | "Tell me about the spreadsheet you rebuilt. What was it built in?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the spreadsheet was. Answer slot: the advert's Excel line makes a probe likely. If it was Excel, say what you did in it, in your own words; if it was another tool, or the work was not yours, say so plainly and stay with the stock-count spreadsheet | F7 is a discovery row, so the answer is yours to give; JD because it scores the advert's Excel requirement |
| C3 | "What would you put in a weekly on-time dispatch report?" | JD | [grounded] | Answer slot: if you produce any regular report, say what is in it and who reads it; if you do not, say so plainly, then describe how you would start from the advert's own measure, on-time dispatch, without inventing a definition | F5 is a discovery row on the advert's reporting duty; JD because it scores the stated requirement |

### D. Case / Strategist (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier says a delivery production needs on Monday will be five days late. What do you do first?" | CASE | [generic] | Structure it aloud: what is affected and what stock is on hand; who needs to know (the advert names planning, the warehouse and QA); the options and their trade-offs; what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's track-and-chase duty (F2 and F3); CASE because it scores structure, not history |
| D2 | "The system says 40 units and the shelf has 32. What do you do?" | CASE | [generic] | Structure it aloud: recount first; check recent movements; look for the cause; correct the record by the proper process; note what you changed. No claim about your past | A live problem from the advert's stock-records duty (F4); CASE because it scores the order of your reasoning |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we move you forward over someone who has worked in a manufacturing site?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate. Hold what the quotes carry: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip. Hold through two follow-ups without adding to it. Answer slot: the advert says Quillmoor is a manufacturer; if you have worked at or alongside one, say so; if not, say so plainly and return to the quotes | F1 and F6 are where a challenge on background would land; JD because it scores the advert's experience requirement under pressure |
| E2 | "That stock-count result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold "I rebuilt our stock-count spreadsheet": that part is yours as written. Concede the limit exactly: the sentence says you rebuilt it and that discrepancies fell, and whether one drove the other is yours to say only if you know. Answer slot: say which part of the result was yours, in your own words; "I don't know" is a complete answer where you do not | F4's figure is the likeliest target of an attribution challenge; EXP because it tests what was actually yours |

### F. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time an order slipped and you had to chase it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The sentence gives two beats: an order slipped and you chased the supplier. Everything beyond that is an answer slot: choose an instance you can tell with its outcome, and say what happened and what part was yours; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry | Themed from the advert's chase-late-orders duty (F2); EXP because it tests whether the stated work survives a specific instance |
| F2 | "Tell me about a time you found a mistake in stock records." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Selection scaffold: pick an instance with a named mistake, what you did about it, and how the record was put right. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Themed from the advert's stock-records duty (F4); EXP because it tests accuracy habits through an instance |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, B4, D1, E1 |
| Track supplier deliveries and chase late orders | D1, F1 |
| Keep stock records accurate | C1, D2, E2, F2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B3 |
| £38,000–£44,000 | A3 |
| Hybrid: two days a week at Avonmouth | A2 |
| Notice period (Hannah's agenda) | A4 |
| What's prompting a move (Hannah's agenda) | A1, B1 |

No values-style round is detected, so there is no values cheat sheet. The F-bank is themed from the advert's duties only.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with most day to day across planning, the warehouse and QA?" | The advert names all three, so it shows you read the role as it is written |
| R2 | "How are the two days at Avonmouth usually set: fixed days, or agreed with the team?" | Hybrid is on her agenda, and the answer turns your stated limit into something concrete |
| R3 | "Which system do the planning, warehouse and stock teams work in day to day?" | The advert mentions SAP or similar as a plus; her answer lets you say what you would need to learn |
| R4 | "What would a good first three months look like in this role?" | It asks what success is, and the weekly on-time dispatch report is one place the answer may land |
| R5 | "Is this a new role or a replacement?" | It gives you context on the vacancy without asking about anyone's circumstances |
| R6 | "Is there anything in my background you'd want me to say more about before you take this forward?" | It invites a concern while you can still answer it |

## Prohibited claims

Built from the fit snapshot before the banks. Each entry names its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says deliveries and suppliers. B2's slot stays inside the depots and suppliers |
| Has ERP experience, or used something equivalent to SAP | Negative you stated, F8, and the inflated form of the in-house system | "I've never used SAP." The in-house system stays at your sentence's scope, and B3's slot asks only what you do in it |
| Advanced or confident Excel skills | Inflated form of F7 | F7's quote at its own scope: a stock-count spreadsheet. C2's slot asks only what it was built in |
| My rebuild cut discrepancies by a third | Inflated form of F4: the sentence joins the rebuild and the fall with "and" | F4's quote as written. C1 and E2 ask only how it was counted, what it is sensitive to, the weakest assumption, and which part was yours |
| £42,000 is my minimum | Contradicted by F9: "hoping for" | "I'm hoping for £42,000." |
| Open to any number of office days | Contradicted by F10: "I wouldn't want more than three" | F10's quote, both halves |
| A reason for leaving other than the office closing | Contradicted by F12 | F12's quote as stated |

## Sources

Provided documents: the advert and background notes in your message, and Hannah Lowther's LinkedIn message. No dossier was present.

Searches sent, all refused because search permission was not granted:

- "Quillmoor Diagnostics company values": refused
- "Quillmoor Diagnostics Avonmouth Bristol news": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have themed the F-bank on named values and could have detected a values-style round; the F-bank is themed from the advert instead |
| 2. `{company} interview process {role family}` | skipped | Hannah's own message fixes the one session and its agenda, so persona weights and the loop need nothing more |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have moved A5, which is grounded in the advert alone, and the reverse questions |
| 4. `{interviewer name} {company}` | unavailable | The call was refused. It would have supported an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `{role title}` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your answers to the open slots: your notice period, what the spreadsheet was built in, whether you produce any regular report, whether you work in the in-house stock system yourself, and whether any of your scheduling touched a planning team or quality checks. These would upgrade F1, F3, F5, F7, F8 and F11 and turn the answer slots in A4, B2, B3, C2 and C3 into quoted answers
- A CV: its lines would join your message as evidence, and some rows now at low could move to medium
- The before and after stock-count variance figures, or any report from that work: the inspectable artifact that could move F4 from medium to high
- Permission to search: Quillmoor's published values, strategy and news would ground A5 and the reverse questions, and Hannah's public professional footprint would allow an interviewer read
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, which also needs search permission
- The next round's details once Hannah gives them: a hiring-manager round would reweight toward the Case and Skeptic banks
- A tuesday-dossier.md would add verified evidence and any claims to rule out; the pack does not depend on one
