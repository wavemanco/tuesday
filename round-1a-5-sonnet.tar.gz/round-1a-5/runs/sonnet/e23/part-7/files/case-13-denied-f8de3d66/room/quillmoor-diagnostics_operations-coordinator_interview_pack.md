# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen with Hannah Lowther (Talent Partner): Thursday 2pm, a 30-minute phone call. She rings the mobile number on your application. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work for you, and what's prompting a move; then she tells you about the team and the next steps. Built from the advert, her LinkedIn message and your own description; no company research ran (see Sources).

## How to use this pack

- Personas describe how a question arrives (friendly, sceptical, time-boxed). Types describe what is being scored. Rehearse both: the same question lands differently in each register.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- Type key:
  - VAL: whether past behaviour shows the company's published values (none banked here; see persona table)
  - EXP: whether your experience survives a follow-up, and how much of it was you
  - JD: whether you can do the listed job, gaps included
  - CO: how well you know the company and its strategy
  - CASE: a live problem from the role, answered aloud
- "Answer slot" lines are instructions for the interview, not questions for me. Fill them with what is true for you, or take the honest second branch.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries and suppliers, not production schedules, and the words stay at that scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on who you worked with. If your scheduling involved any of those teams, say which and how, in your own words; if it did not, say so plainly and stay with the depots and the suppliers |
| F2 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote reaches the chasing in role-relevant terms: lead with it as written. It says chasing, not how you knew an order had slipped, so expect a probe on tracking. Answer slot: if you kept track of orders, say how, in your own words; if you learned of slipped orders some other way, or there was no tracking, say so plainly and stay with the chasing |
| F3 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Lead with the sentence in its own terms: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The words stay at "rebuilt" and "fell". A figure with nothing inspected behind it draws the four slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: say each in your own words; "I don't know how it was counted" is an honest answer if it is true |
| F4 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: the advert asks for weekly reporting, so expect a probe. If you reported on deliveries to anyone, say what you reported and how often; if you did not, or it was not yours, say so plainly and stay with the scheduling you do |
| F5 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not which tool, and the pack does not assume it was Excel. Answer slot: the advert names Excel, so expect a probe. If the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, say so plainly and say which |
| F6 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | The advert marks this a plus, not a requirement. The words you have: "I haven't used SAP", from "Never used SAP". Then the system at its own scope: "we run our own in-house stock system." Your material does not say that system is an ERP, and the words do not call it one. Answer slot: "or similar" invites a probe on the in-house system. If you worked in it, say what you did in it; if you did not work in it directly, say so plainly |
| F7 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | Reaches the requirement in its own terms: the years and the title as written. A line with nothing inspected behind it, so expect a probe; say it in the sentence's own words and no wider |
| F8 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Say the figure as you said it: "I'm hoping for £42,000." Your material says hoping, not minimum, and the words stay there. The figure sits inside the advert's range, and nothing in your material says whether you would move within it. Answer slot: decide before Thursday how firm the figure is; if asked, say what is true for you, in your own words |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Say it in your own terms: two days at Avonmouth is fine. Your ceiling is a stated preference, "I wouldn't want more than three", and it stays a preference: not "can't", and not a number above three. No commute figure is in your material, so none is offered |
| F10 | "your notice period" — Hannah's LinkedIn message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term, not a story, so no wording is offered here; A5 holds the rehearsal, and the upgrade menu says what fills this row |
| F11 | "what's prompting a move" — Hannah's LinkedIn message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | A stated reason that already answers. Say it in its own terms: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Your material does not say redundancy, a closing date or any terms, and the words stay there |

## Persona table

Recruiter screen priors (Conversational plus a light Skeptic), adjusted by Hannah's own agenda. The loop is established for this one session only: her message names a single 30-minute call with her, so no later rounds are weighted here.

| Persona | How it shows up in this call | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, her four agenda items, then she sells the team | Highest. The relationship prior for a recruiter screen is Conversational first, and her message promises a friendly shape: four logistics-style items, then information for you. Every one of her four items is a Bank A question | Pre-script the 90-second arc (A1) from the quoted sentences in its row; treat each casual question as scored; use the reverse-question slot |
| Skeptic | Knockout-style checks: does the pay, pattern and reason hold up; is the background close enough | Second. Her items are the checks a screen runs, and F1, F6 and F4 are where the advert outruns your material, so they are where she is most likely to press | Rehearse B1 until it is boring; bridges only from the quotes; concede limits plainly; B1 is the highest-ROI prep in the pack |
| Data-Driven Prober | A quick check on the figure and on Excel | Low-medium. A 30-minute call leaves little time to go line by line, but the figure on your application and the advert's Excel line are cheap to check | Say what you can and cannot say about how the figure was counted; name the assumption you would defend least; say plainly when you do not know |
| Pressure | One time-boxed or push-back moment, most likely on pay or days at Avonmouth | Low. Not a prior for this round; kept because pay and pattern are where a screen can push | Pause, restate, hold the position through two follow-ups, concede only what is true |
| Case / Strategist | A quick situational question, if any | Low. Her agenda names no case, so these are insurance | Clarify, then structure, then answer |
| Values / Peer | Not expected | Not banked. No loop source names a values-style round, and no peer is on this call | None needed |

## Question banks

### Bank A: Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: where are you now, and what do you do day to day?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | A 90-second arc with four beats, each a clause its quote states: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; the stock-count spreadsheet you rebuilt, with discrepancies falling by about a third over a year; then why you are looking: the Bristol office closes next year and the only offer is relocating to Reading. Tell the beats in your own words and stop. The arc claims nothing beyond those four sentences | Near-certain as an opener. It carries F7, F1, F3 and F11. EXP because it tests whether the story you tell matches the application |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the reason in its own terms: the office is closing next year, the only offer is relocating to Reading, and you don't want that. Keep it to the reason; the sentence says nothing on redundancy, a closing date or terms, so none go into your answer. Answer slot: if she asks what you have been told about the closure, say what you know and say plainly what you do not. If she asks what you want from the next role, say it in your own words; your material carries no sentence of yours on that | On Hannah's own list, so certain; F11 is the row. EXP is the closest tag: it scores whether the reason you give is stable and checkable |
| A3 | "How would the hybrid pattern work for you: two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it in your own terms: you live in north Bristol and two days at Avonmouth is fine. Keep the ceiling as the preference it is: "I wouldn't want more than three", offered if she asks about flexibility or a changing pattern. Answer slot: if she asks about getting there, say what you know of the journey; if you have not worked it out, say so plainly | On Hannah's own list; F9. JD because the advert states the pattern, and the material shows the term met |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure plainly: "I'm hoping for £42,000." Then stop. The advert's range is £38,000 to £44,000 and the figure sits inside it. Your material says hoping, not minimum, so no wording here calls it a floor or says it is negotiable. Answer slot: if she asks how firm it is, say what is true for you, decided before Thursday. If she asks what you earn now, your material does not carry it, so decide in advance what you will say and say only what is true | First on Hannah's list; F8. JD because the advert states the range |
| A5 | "What's your notice period, and how soon could you start?" | JD | [grounded] | Your material does not carry your notice period, so there is no sentence to map. Answer slot: say what your contract states, as a figure with its unit; if you know it can be shortened or you have leave still to take, say exactly that; if you do not know, say you will check and say by when | On Hannah's own list; F10 is a gate row the material does not establish. JD is the closest tag: it is a term the role is hired against |

### Bank B: Skeptic (second weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Here the scheduling sits between planning, the warehouse and QA on a manufacturing site. How does what you do now map across?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI prep in this pack. Level 1, the hold: say what the sentence says and no more: you schedule deliveries for three depots and chase suppliers when orders slip. Then stop and let her ask. Level 2, if she says that is deliveries, not production scheduling: the limit is your material's, which says deliveries and suppliers, not production schedules, so concede nothing you have not checked against the truth. Answer slot: if any of your scheduling involved planning, a warehouse or QA, say which and how; if it did not, say so plainly and return to the depots and the suppliers. Level 3, if she asks what you would need to learn first: that is a plan, not a past. Say what you would want to find out, such as how the production schedule is set and what planning and QA need from it. Level 4, if she asks whether this is a dealbreaker: do not argue; ask what she is weighing and answer that. Hold through two follow-ups before conceding anything real | F1 is the widest gap between the advert and your material, and a screen is where it first narrows the field. JD because it scores the stated requirement; it is built deepest because it will arrive in some form |
| B2 | "You haven't used SAP. How would you get up to speed on our system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The plain acknowledgment is sourced to your sentence: "I haven't used SAP." Then the system at its own scope: "we run our own in-house stock system." Then a plan, said as a plan: what you would do in the first weeks to learn their system, in your own words. Answer slot: if you worked in the in-house system, say what you did in it; if you did not work in it directly, say so plainly. Do not call it an ERP | F6. The advert marks ERP "a plus", so this is a smaller objection than B1. JD because it scores a listed qualification |
| B3 | "What's attracted you to Quillmoor?" | CO | [generic] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Selection scaffold: pick one thing in the advert that is true for you, such as one of the tasks it lists or the Bristol site, and say it plainly. The pack holds no research on the company, so it supplies none. If nothing specific comes to mind, say so plainly, then give the nearest thing your material does carry: you live in north Bristol and the advert's site is in Bristol | No company research ran, so the pack cannot ground this one. CO because a recruiter checks quickly whether you have looked at the company |
| B4 | "Are you talking to other companies at the moment?" | EXP | [generic] | Answer slot: say what is true. If you have other applications or interviews, say so at the level you are comfortable with; if you have none, say so plainly. Never imply an interview or an offer you do not have | Recruiters ask this to gauge timeline and the consistency of A2. EXP is the closest tag; no tag fits a process check well |
| B5 | "Which part of the advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name one thing plainly, from your own material. The one it states is SAP: "I haven't used SAP." Then a ramp plan, said as a plan, in your own words. Do not answer "nothing"; calibrated candour reads better than a bluff | Stem from the Skeptic persona; F6 gives the cleanest honest answer. JD because it scores self-assessment against the advert |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. Walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the sentence states: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Then the four slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption you would defend least; which part was yours. "I don't know how it was counted" is honest if true. Do not supply a baseline or a method you did not state | F3. The headline figure on your material is where a prober starts. EXP because it tests attribution |
| C2 | "How confident are you with Excel, and what do you do in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The sentence you have is about a spreadsheet you rebuilt. Answer slot: if it was in Excel, say what you did in it, in your own words; if it was another tool, say so plainly and say which. Name only what you used, and do not rate yourself on a scale you cannot back | F5. The advert names Excel, so this is a quick, cheap check. JD because it scores a stated requirement |
| C3 | "The role reports weekly on on-time dispatch. What's your experience of reporting on that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your material does not show reporting (the pack's observation). Answer slot: if you reported on deliveries to anyone, say what you reported and how often; if you did not, or it was not yours, say so plainly and return to the sentence: you schedule deliveries for three depots. Add no figures | F4. The advert raises it and your material is silent, so the honest second branch needs to be ready. JD because it scores a stated responsibility |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we pick you over someone who already knows SAP and manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause and restate the question. Hold: the four years as a logistics coordinator, and scheduling deliveries for three depots and chasing suppliers when orders slip. Concede in one sentence: "I haven't used SAP." Close with how you would learn their system, as a plan. Make no claim to manufacturing; your material does not show it. Hold through two follow-ups before conceding anything more | F7 holds, F6 and F1 are the limits. JD because it scores fit against the advert, delivered as pressure |
| D2 | "How much of that stock-count result was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold at the sentence's scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Your material does not say the rebuild alone caused the fall. Answer slot: if other things changed that year, such as people, process or volume, say what, plainly; if nothing else did, say so; if you do not know how much was down to the rebuild, say that plainly | F3. This is the attribution probe a pressure interviewer uses on a headline figure |
| D3 | "If we needed you at Avonmouth three or four days, would that be a problem?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hold your stated position: "I wouldn't want more than three." It is a preference, so do not say "can't". If she pushes, restate it and ask what is driving the question on her side. Answer slot: say what is true for you on three days, and on four; your material covers only that you would not want more than three | F9. Pattern is on her list, and a push-back on days is the likeliest pressure moment in a screen |

### Bank E: Case / Strategist (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Two suppliers' deliveries are late the same morning. The warehouse is waiting on both and QA needs one for a release. How do you decide what to chase first?" | CASE | [generic] | Structure it aloud: what you would ask first (what each order feeds, when it is due, who is waiting); how you would rank them by what is blocked downstream; what you would ask each supplier for (a specific date, not "as soon as possible"); who you would tell on the waiting teams; what you would record. The question needs no claim about your past, so the guidance makes none | Built from the advert's supplier-chasing line (F2) as a live problem. CASE because it asks for reasoning, not history; kept short because her agenda names no case |
| E2 | "The system says 40 units and the shelf has 32. What do you do?" | CASE | [generic] | Structure it aloud: recount first; check recent movements for the cause; correct the record with a note of why; look for a pattern before treating it as a one-off. The question needs no claim about your past, so the guidance makes none | Built from the advert's stock-records line (F3). CASE for the same reason as E1 |

### Requirement-coverage line

| Requirement | Covered by |
|---|---|
| Coordinate production schedules (F1) | B1, D1, E1 |
| Track supplier deliveries and chase late orders (F2) | A1, E1 |
| Keep stock records accurate (F3) | A1, C1, D2, E2 |
| Weekly on-time dispatch report (F4) | C3 |
| Confident with Excel (F5) | C2 |
| ERP experience, a plus (F6) | B2, B5, D1 |
| 2+ years (F7) | A1, D1 |
| £38,000–£44,000 (F8) | A4 |
| Hybrid, two days at Avonmouth (F9) | A3, D3 |
| Notice period, Hannah's list (F10) | A5 |
| What's prompting a move, Hannah's list (F11) | A1, A2, B3, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the day-to-day split between planning, the warehouse and QA, and who would I work with most?" | Shows you read the advert closely, and gets the answer to F1's scope question from her side |
| R2 | "What does the first month look like, and what would learning your stock system involve?" | Turns the SAP objection (F6) into a ramp conversation before she raises it |
| R3 | "What does the weekly on-time dispatch report look like today, and who reads it?" | Goes straight at F4 and shows you take the reporting line seriously |
| R4 | "How are the two days at Avonmouth usually set: fixed days, or agreed with the team?" | Shows you are working out how to make the pattern work; you named your ceiling in A3 |
| R5 | "Is the range fixed, or does it move with experience?" | Surfaces how the £38,000–£44,000 is set after you have named a figure |
| R6 | "What are the next steps after this call, and who would I meet?" | She said she would cover next steps; asking who you would meet gives you the shape of the later rounds, which this pack could not weight |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Scheduled production with planning and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says deliveries and suppliers, not production schedules. B1's slot stays inside the depots and suppliers |
| Used SAP | A negative you stated, F6 | The plain acknowledgment: "I haven't used SAP", sourced to "Never used SAP" |
| Has ERP experience | Inflated form of F6 | F6's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material does not say that system is an ERP |
| Cut stock discrepancies by a third | Inflated form of F3 | F3's quote at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. D2's slot asks only what else changed |
| Confident or advanced in Excel | Inflated form of F5 | F5's quote at its own scope: a spreadsheet you rebuilt. The limit is the pack's observation: the sentence names a spreadsheet, not Excel |
| £42,000 is my minimum | Inflated form of F8 | F8's quote at its own scope: "I'm hoping for £42,000." |
| I'm being made redundant | Inflated form of F11 | F11's quote at its own scope: the office closes next year and the only offer is relocating to Reading. The limit is the pack's observation: your material says neither redundancy nor terms |
| Flexible on days at Avonmouth beyond three | A claim your quote contradicts, F9 | The contradicting quote: "I wouldn't want more than three." Nothing more |

## Sources

Provided documents: the advert text; Hannah Lowther's LinkedIn message; your own description of your background and what you would tell her. No dossier was provided.

Searches sent, each refused (the host did not grant permission), so none returned a result:

- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics Avonmouth news strategy": refused
- "Hannah Lowther Quillmoor Diagnostics": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Search refused. Would have given B3 the company's published values by name; B3 stays a scaffold |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Hannah's message fixes this session: one 30-minute call with her. Later rounds are not in this pack |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Search refused. Would have given B3 a grounded CO answer; no grounding brief was written |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Search refused. Would have supported an interviewer read; the section is absent and the upgrade menu says what unlocks it |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period, as your contract states it → F10 gets your own words, and A5 becomes a worked answer instead of a slot
- Whether the stock-count spreadsheet was in Excel, and whether you ever reported on deliveries to anyone → F5 and F4 move from `discovery` rows to quoted evidence, and C2 and C3 become story-mapped
- What you did in your in-house stock system → F6 gets a quoted sentence and B2's slot closes
- How firm £42,000 is → A4 and D3 get a position you chose, in your own words
- The later rounds, once Hannah tells you on Thursday who you meet next and in what format → per-round mini-packs with their own persona weights
- Web search permission → B3 becomes a grounded CO answer, a values and strategy read is added, and an interviewer read becomes possible
- A tuesday-dossier.md, if you ever have one → verified evidence and a sharper highest-ROI objection, never a prerequisite
