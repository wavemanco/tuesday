# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call with Hannah Lowther (Talent Partner), Thursday at 2pm. She rings the mobile number on your application.
**Her stated agenda, in her words:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.
**Built from:** the advert and your message only. No CV was supplied, and the web searches I sent were refused, so nothing here is company-specific beyond the advert (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none read this session, so no question carries this tag) |
| EXP | Whether what you say you did holds up, and what was actually yours |
| JD | Whether you can do the listed job, gaps included, and whether the terms (pay, days, notice) fit |
| CO | Company and strategy knowledge (none this session: research was refused, so a CO question would be generic) |
| CASE | A live problem set in the role, answered by structure |

Guidance is scaffolding, not a script. It is written to be said aloud in 90 to 120 seconds, in your own words. On a phone call nothing is on screen, so rehearse out loud. An "Answer slot" is an instruction for the call: answer whichever branch is true for you. If the practice it names was not yours, saying so plainly is a correct answer.

**Highest-ROI prep: B2.** It is the question most likely to be asked in some form, because it sits where the advert's core work and your material differ most (F1). Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for depots. It says nothing about production schedules, planning or QA, and the words stay at the quote: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on who you worked with. If any of those were part of your scheduling work, say which and how, in your own words; if none were, say so plainly and stay with the deliveries you schedule |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Say it in the quote's own terms: you chase suppliers when orders slip. It is a message line with nothing inspected behind it, so expect a follow-up asking for an occasion (F1 of bank F) |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Derived from a quote that touches the requirement without saying how deliveries are tracked. Answer slot: if you keep any record of supplier deliveries, say what it is, in your own words; if you do not, say so plainly and stay with scheduling and chasing |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote already speaks to this in role-relevant terms. Keep its hedges: "about a third", "over a year". The counting method is not in your material, so the defend-the-number slots in C1 apply |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: the advert makes a probe on reporting likely. If you produce regular reports on deliveries or dispatch, say what they cover and how often; if you do not, say so plainly and stay with the deliveries you schedule |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | Say it as quoted. Four years against a stated two plus |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Derived from a quote that names a spreadsheet and never names the tool. Answer slot: if it was an Excel workbook, say so and what you built in it; if it was another tool, say so plainly and stay with the spreadsheet you rebuilt |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | The absence is yours and stated: "I've never used SAP." Your sentence says the company runs an in-house stock system; it does not say you use it or that it is an ERP. Answer slot: if you work in that system day to day, say what you do in it; if you do not, say so plainly. Then a plan for learning a new system, said as a plan and never as a past |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert; "how the hybrid pattern would work for you" — Hannah's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The term is shown met at two days. Your ceiling is stated as a preference, so say it as one, in the sentence's own words |
| F10 | "£38,000–£44,000" — advert; "your salary expectations" — Hannah's message | "I'm hoping for £42,000." — your message | high | [grounded] | none | The figure sits inside the advertised band. It is stated as a hope, so do not call it a minimum. Whether it moves is a decision for you before the call (A4) |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it. Nothing in this pack states it for you |
| F12 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it as quoted: the office closing, the only offer being Reading, and that you don't want it. Nothing is added to it |

## Persona table

Weights start from the recruiter-screen prior (Conversational plus a light Skeptic). The loop is established by Hannah's own words: one 30-minute phone call with her and the agenda above. No source names a values round, so none is assumed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, then her four agenda items in a casual register | Top. Her message sets the agenda and the register is a screen's prior; the risk is treating a chatty question as unscored | A 90-second arc built from the sentences in A1; treat every casual question as scored |
| Skeptic | Quiet knockout checks on the advert's gaps: systems, production scheduling, reporting | Top, light. F1, F5 and F8 are the rows where the advert asks and your material is thin or silent | Rehearse B2 until it is boring; hold only what the quotes carry |
| Data-Driven Prober | One check on the stock-count figure or on your three-depot scheduling | Mid. A screen rarely goes deep, but F4 holds the one figure in your material | C1 to C3: know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure | A blunt "what if it were four days" or a time-boxed comparison | Low. The screen is described as a conversation, and the two terms she will test are F9 and F10 | D1 and D2: pause, restate, hold the quoted position, concede only what is specific |
| Case / Strategist | A quick live scenario about a late order or a stock mismatch | Low. Recruiter screens seldom run cases and no source says this one will | E1 and E2: structure aloud |
| Values / Behavioral | An open "tell me about a time" prompt | Low. No values round is documented for this loop | F1 and F2: selection scaffolds with an honest branch |
| Peer Evaluator | Seam-splitting with a colleague | Not in this session: the only interviewer is a Talent Partner. No bank; add one if she names a team member for a later round | none this session |

## Question banks

### A. Conversational (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me a bit about what you do now and how you got here." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A three-beat arc, each beat a sentence you wrote: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Keep "about". Answer slot: "how you got here" may reach back before this job, which your material does not cover. If earlier steps deserve a sentence, say them in your own words; if the coordinator role is where the story starts, say so plainly and begin there | The opener frames F2, F4 and F6 before she probes any of them; EXP because it tests what you did, in a register where a casual opener is still scored |
| A2 | "What's prompting the move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as you wrote it, in your own words: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Three facts, then stop. Answer slot: if something about this role draws you beyond staying in Bristol, say what, in your own words; if the honest answer is that you want to stay in Bristol, say so plainly | It is the last item on her stated agenda and F12 is the whole of your material on it; EXP because it tests whether your account of your own situation is consistent |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Lead with the yes and the reason, both from the sentence: two days at Avonmouth is fine, and you live in north Bristol. Say the ceiling once, as you wrote it, only if she asks how far you could go: you wouldn't want more than three. Then ask how the team sets its days (R1). Answer slot: if you have a view on which days or how you would travel, say it in your own words; if you haven't settled it, say so plainly | Her message asks this in nearly these words; F9 is a term shown met, and JD because it checks fit with a stated term |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure as you stated it, "I'm hoping for £42,000", and stop; the advertised band is £38,000–£44,000 (F10). Answer slot: decide before the call whether £42,000 is a figure you would move from, and say that only if it is true; if she asks whether it can move, answer in your own words, and if it cannot, say so plainly. If she asks what you earn now, your material does not say, so decide beforehand what you will share | Her agenda names it first; F10 is a stated hope inside the band, and JD because pay is a term of the role |
| A5 | "What's your notice period?" | JD | [generic] | Your material does not establish it (F11), so this guidance makes no claim about you. Answer slot: give the notice period as your contract states it, in your own words, and say whether any of it could be shortened only if you know that to be true; if you do not know, say so plainly and say you will confirm | Her agenda names it; F11 is a term the material is silent on, and `[generic]` because the guidance is a pattern for the question, not a fact about you |

### B. Skeptic (weight: top, light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We mention SAP or similar. What systems have you worked in?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Start plain: "I've never used SAP." Your sentence then names an in-house stock system the company runs; stay at that scope. Answer slot: if you work in that system day to day, say what you do in it, in your own words; if you do not, or it is not one you would call similar, say so plainly. Then say, as a plan, how you would go about learning a new system, in your own words: a plan, not a past. Keep it short; the advert lists it as a plus | F8 is the advert's one stated gap in your material and the likeliest knockout check; JD because it scores a listed requirement |
| B2 | "Your work is scheduling deliveries for depots, and this role coordinates production schedules between planning, the warehouse and QA. How do you see the step across?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The deepest rehearsal in the pack. Hold only what the quote carries: "I schedule deliveries for our three depots and I chase suppliers when orders slip." Concede the quote's own scope: that is the work you describe, and she can judge the step. Answer slot: if any of planning, the warehouse or QA were people you worked with in that scheduling, say who and how, in your own words; if none were, or it was only deliveries, say so plainly and stay with the deliveries you schedule. Follow-up 1, "which of those teams have you dealt with?": the same slot, same words. Follow-up 2, "what would you need to learn first?": answer as a plan in your own words, and ask what the team's pattern is (R2). Follow-up 3, "how long to be productive?": give a duration only if you have a basis for it; "I'd want to see how the work is set up before I put a number on it" is a true branch if that is how you feel | F1 is where the advert's core work and your material differ most, so this objection arrives in some form; JD because it scores the stated requirement |
| B3 | "It says confident with Excel. What do you do in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Derived: the quote names a spreadsheet and not the tool | Describe the spreadsheet in the quote's terms: you rebuilt the stock-count spreadsheet. Answer slot: if it was an Excel workbook, say so and say what you built in it, in your own words; if it was another tool, say so plainly and stay with the spreadsheet you rebuilt. Do not name a feature you could not demonstrate if asked | F7 is a low-confidence row and the advert's tool requirement; JD because it checks a listed skill |
| B4 | "We want weekly reporting on on-time dispatch. What reporting have you done on deliveries, if any?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you produce regular reports on deliveries or dispatch of any kind, say what the report covers and how often, in your own words; if you do not, say so plainly and stay with the deliveries you schedule and the suppliers you chase. Your material says nothing on reporting (F5), so the pack supplies no report | F5 is a requirement with no quote behind it, which is a free miss if not rehearsed; JD because it checks a listed duty |
| B5 | "Why this role, and why Quillmoor?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three."; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if something specific about the role or the company draws you, say what, in your own words. This pack holds nothing about Quillmoor beyond the advert, so do not borrow a reason you have not read. If the honest reason is that the work and the pattern suit you, say so plainly with the nearest things your material carries: you schedule deliveries and chase suppliers, and two days at Avonmouth is fine for you | A standard screen question whose answer is yours alone; F9 and F2 are the nearest rows. JD because the role is what is being asked about |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How were they counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the sentence as written: you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Keep "about" and "over a year". Four slots, each in your own words: how the discrepancies were counted, and if you do not know, say so plainly; what the figure is sensitive to; the assumption behind it you would defend least, named before she names it; and which part was yours. Do not turn "about a third" into a precise figure | F4's figure is the one number in your material, so a defend-the-number question is expected; EXP because it tests attribution |
| C2 | "How much of that fall was down to the spreadsheet itself?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if other things changed over that year, say what they were and how you would divide the credit, in your own words; if nothing else changed that you know of, say so plainly and stay with the sentence. "I can't separate it" is an honest answer if it is true | The attribution follow-up to C1, on the same F4 figure; EXP because it tests what was actually yours |
| C3 | "Walk me through how you schedule deliveries across your three depots." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The beats the sentence states: you schedule the deliveries, for three depots, and you chase suppliers when orders slip. Tell them in that order, in your own words. Answer slot: if you schedule all three depots yourself, say so; if the scheduling is shared, say which part is yours. Any step-by-step detail beyond the quote, such as how you decide order or what you use, is yours to give only if true; the pack supplies none | F2 and F3 are the rows a prober reads closely; EXP because it tests what you did day to day |

### D. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role is two days on site. What if that became four?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Pause and restate: two days at Avonmouth is fine. Hold the stated ceiling in the same words through two follow-ups: you wouldn't want more than three; do not add reasons the sentence does not give. Concede only what is specific and true: you cannot speak to how the team's pattern might change. Do not trade the ceiling away to restore the mood | F9 holds a stated ceiling that a screen may test with a deliberately larger number; JD because it checks a term of the role |
| D2 | "Sixty seconds: why should we move you forward over someone with SAP behind them?" | JD | [grounded] "Never used SAP — we run our own in-house stock system."; "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate. Concede first, in one clause: "I've never used SAP." Then hold on what you wrote: four years as a logistics coordinator at a building-supplies wholesaler, and you schedule deliveries for three depots and chase suppliers when orders slip. Say those and stop; let her draw the inference. Hold through two follow-ups by returning to those sentences, never by adding to them. Do not compare yourself to people you have not met | F8 is a stated gap and F6 a stated strength; JD because it weighs a listed requirement against the rest |

### E. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a key delivery will arrive three days late. What do you do first?" | CASE | [generic] | A structure for the problem, with no claim about your past: what is affected and by when; who needs to know (the advert names planning, the warehouse and QA); what the options are and what each costs; what you ask the supplier; what you record. Think aloud and say your assumptions | A live problem drawn from the advert's "chase late orders" line (F2's requirement); `[generic]` because it is a pattern for the problem, not a fact about this employer |
| E2 | "A counted item doesn't match the stock record. Where do you start?" | CASE | [generic] | A structure, with no claim about your past: is it one item or a pattern; check recent movements against the record; recount; correct the record; look for the cause; note what you changed. Think aloud | A live problem drawn from the advert's "keep stock records accurate" line (F4's requirement); `[generic]` for the same reason |

### F. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time an order slipped and what you did." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your sentence carries only that you chase suppliers when orders slip; it supplies no occasion. Pick one yourself. It needs the order, what you did, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you chase suppliers when orders slip, or how you would handle it | The advert's "chase late orders" is the raising source (F2); EXP because it asks you to choose an instance |
| F2 | "Tell me about a time you had to give someone difficult news at work." | EXP | [generic] | Pick an occasion yourself: who needed to hear it, what you said, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your material holds no occasion of this kind, so the pack supplies none | A common conversational stem; `[generic]`, and low weight because no values round is documented for this loop |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, D2, E1 |
| Track supplier deliveries and chase late orders | A1, C3, E1, F1 |
| Keep stock records accurate | C1, C2, E2 |
| Report weekly on on-time dispatch | B4 |
| 2+ years in operations or logistics coordination | A1, D2 |
| Confident with Excel | B3 |
| ERP experience (SAP or similar) a plus | B1, D2 |
| Hybrid: two days a week at Avonmouth | A3, D1 |
| Salary expectations | A4 |
| Notice period | A5 |
| What's prompting a move | A2, B5 |
| Company and strategy knowledge | none, and why: research was refused, so a CO question would be generic |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is the Avonmouth pattern set: are the two days fixed for the team, or agreed individually?" | She raised the hybrid pattern herself, and the answer tells you whether your stated ceiling (F9) is ever likely to be tested |
| R2 | "Which teams would I work with most day to day: planning, the warehouse, QA? Where does this role sit between them?" | It takes the advert's three groups seriously and gives you the real shape of the work behind F1 |
| R3 | "What systems does the team use for stock and supplier tracking, and how is training handled?" | It turns F8 into a practical question about onboarding rather than a defence |
| R4 | "Who reads the weekly on-time dispatch report, and what does it feed into?" | It shows you read the advert's reporting line closely, and tells you what F5's duty is for |
| R5 | "What are the biggest challenges on supplier deliveries right now?" | It invites her to describe the team's live problem, which gives you something concrete to listen for |
| R6 | "What would the first three months look like in this role?" | A standard question that signals you are thinking about how to start; its answer is theirs, not yours |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, F8 | The plain acknowledgment: "I've never used SAP." Your sentence: "Never used SAP — we run our own in-house stock system." No slot |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: your material says the company runs an in-house stock system, not that it is an ERP or that you use it. B1's slot stays inside what you do day to day |
| Coordinated production schedules | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says delivery scheduling, not production scheduling. B2's slot asks only who you worked with |
| Confident with Excel | Inflated form of F7 | F7's quote at its own scope: you rebuilt a stock-count spreadsheet. The pack's observation: the material does not name the tool. B3's slot asks only which tool it was |
| Cut stock discrepancies by a third | Inflated form of F4 | F4's quote at its own scope: "discrepancies fell by about a third over a year". The pack's observation: the material does not say how the figure was counted or how much of it was down to the rebuild. C1 and C2 slots stay inside the quote |
| Was made redundant | Inflated form of F12 | F12's quote at its own scope: the office is closing and the only offer is relocating to Reading. The pack's observation: the material does not describe the situation in any other terms |

## Sources

Provided documents: your message, containing the advert text, your background and Hannah's LinkedIn message. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Queries sent, every one refused (the host declined search permission), so nothing returned and nothing from any search is used in this pack:

- `Quillmoor Diagnostics company values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics Avonmouth Bristol news strategy` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have given official value names for a values sheet. None is built: no source names a values round, so section 10 is dropped either way |
| 2. `{company} interview process {role family}` | unavailable | Would have shown whether later rounds exist and who runs them. The persona weights rest on Hannah's own description of this call, not on any documented loop |
| 3. `{company} strategy` / recent news | unavailable | Would have supported one CO question and a grounding brief. Neither is in this pack |
| 4. `{interviewer name} {company}` | unavailable | Would have fed an interviewer read and a reverse question tied to her path. Neither is in this pack |
| 5. representative `{role title}` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → resolves F11 and replaces A5's slot with your own words
- Permission to search the web → the four L1 targets above run, and a CO question and a grounding brief become possible. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add recent company context; offered once
- Your CV → F1 to F7 evidence cells quoted in your CV's own wording, which may upgrade F3 and F7 from `low`
- Your answers to the answer slots on F1, F3, F5, F7 and F8 → those rows and the guidance that draws on them regenerate in your own words
- The stock-count spreadsheet itself, or a before-and-after discrepancy log → F4 from `medium` to `high`
- How much prep time you have before Thursday at 2pm → a prioritised triage of this pack
- Hannah's public professional background, if you want it researched → a reverse question tied to her path
- A `tuesday-dossier.md` from an earlier pass, if you have one → verified evidence and any prohibited claims carried in; the pack does not need one
