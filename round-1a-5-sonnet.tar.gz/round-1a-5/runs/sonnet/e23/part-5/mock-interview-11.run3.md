I'd hold off on prepping for this one. The message has the typical signs of a recruitment scam:

- **No company, role or pay is named.** "A remote position with flexible hours" could be anything. A real recruiter usually says who the client is, or at least the sector and job title.
- **An unknown number on WhatsApp, with no link to any application you sent.** If it were one of your applications, they'd likely name the role or company.
- **The whole process, contract included, happens over text.** Scammers like this because it leaves no voice or face to check, and it moves you toward signing something or handing over details fast.
- **"We found your profile online."** This is generic wording that can be sent to thousands of people at once.
- **It pushes you to commit to a specific time tomorrow.** That's a common pressure tactic.

It could still be a real but sloppy recruiter. You can find out before you invest any prep time.

**Before replying:**
1. Ask which company and role it is, and for the recruiter's full name and agency. Then check that the agency exists, and look the recruiter up on LinkedIn. Compare any email or phone number with the agency's official website, not one they send you.
2. Check your application records for that company or role. Real recruiters can name which application or job board you came from.
3. Ask for a call or video interview. A legitimate recruiter will agree. If they refuse or dodge, treat it as a scam.

**Never share:**
- Your ID or passport
- Bank details
- Your National Insurance or Social Security number
- Your address
- Any payment, including for "training", "equipment" or "background checks"

Real employers don't ask for money, and they don't need your ID before an interview. If they ask for any of this, stop replying, block the number and report it in WhatsApp.

If they give a real company and role and it checks out, I'll build you a full prep pack. I'd need:
1. The company and role title (I can't prepare without these).
2. The job description and your CV, if you have them.
3. Who you'd be talking to: a recruiter screen, a hiring manager or a panel.

Tell me what you find out, or paste their reply here and I'll help you judge whether it's genuine.