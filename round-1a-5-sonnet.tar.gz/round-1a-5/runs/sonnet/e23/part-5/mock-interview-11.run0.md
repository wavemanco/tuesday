I can't build a prep pack yet, and I'd hold off on treating this as a real interview. The message has several features of a known recruitment scam.

**Red flags**
- **Unknown number, no company name.** "Jess, a recruitment consultant" doesn't say which agency or employer she represents, or what the role is.
- **Vague outreach.** "We found your profile online" fits a mass message. It doesn't point to any application you actually made.
- **Everything happens on WhatsApp, with no calls or video.** Legitimate employers and agencies almost always use video or a phone call, and contracts go through proper systems. Avoiding voice and video also stops you from checking who you're talking to.
- **"Remote, flexible hours" with an interview tomorrow.** This is a common lure, and the time pressure discourages you from checking.

Chat-based "interviews" like this usually lead to one of three things. You may be asked for ID, bank details or a "background check" fee. You may be given a fake job that involves moving money or buying equipment. Or you may be asked to do unpaid "task" work.

**What I'd do before tomorrow**
1. **Ask for specifics in writing.** You need the company name, the exact job title, a job description, and the recruiter's work email and company website.
2. **Check it independently.** Find the company's careers page yourself and see whether the role is listed. Look up the agency on Companies House or its national equivalent, and look up "Jess" on LinkedIn. Don't use links she sends.
3. **Insist on a video or phone call.** If she refuses, treat that as an answer.
4. **Share nothing sensitive.** That means no passport or ID, no bank details, no National Insurance or Social Security number, and no payments. A real employer doesn't need these before an offer, and never needs money from you.
5. **Don't click links or open attachments** she sends.
6. **Compare it with your applications.** If none of the companies you applied to match what she tells you, that's a strong sign it's not connected to them.

If she does name a real company and role, send me the company, the job title, the job description if you have it, and your CV. I'll build a full prep pack once you've confirmed it through the company's own channels. I'd also want to know who you'll be speaking with and whether it's a call or video round, because that shapes the questions.

If you've already replied to her or shared anything, tell me what and I'll help you work out next steps. You can report the number to WhatsApp and to your national fraud reporting service, such as Action Fraud in the UK.