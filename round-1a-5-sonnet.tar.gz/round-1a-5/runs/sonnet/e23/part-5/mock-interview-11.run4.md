I'd hold off on prepping for this one. The message has the usual signs of a recruitment scam, and it also doesn't give me what I'd need to build a prep pack.

**Why it looks like a scam**
- **It came from an unknown number on WhatsApp.** Real recruiters usually start with an email, LinkedIn or a job board message.
- **It names no company, role, salary or location.** "A remote position with flexible hours" could be anything.
- **The whole process stays in WhatsApp text.** Fake recruiters avoid calls and video because a live conversation would expose them. Real hiring almost always involves at least a call.
- **The interview is tomorrow at 11am.** The short deadline stops you from checking anything.
- **"We found your profile online" is generic.** Scammers often use it. Your applications may be the source, because scammers sometimes scrape job boards, but that doesn't make the message genuine.

Scams like this usually move on to an "interview" that is really a form-filling exercise. After that comes a job offer, then requests for ID documents or bank details. Other versions ask you to pay for equipment, training or "software", or to move money for the employer.

**What I'd do before replying**
1. **Don't send personal documents or financial details.** That means ID, a passport, bank details or an address.
2. **Ask for specifics.** Ask for the company's name, the exact role, the recruiter's work email and the company website. A genuine recruiter will answer easily. A scammer will dodge or push you to hurry.
3. **Check the answers yourself.** Look the company up independently and find the recruiter on LinkedIn. Compare your recent applications to see whether this role matches one of them. Contact the company through its official website to confirm the recruiter works there.
4. **Ask for a call or video interview.** If they refuse, treat that as a red flag.
5. **Never pay anything** to get the job.
6. **If it turns out to be a scam,** block and report the number in WhatsApp. You can also report it to Action Fraud (UK) or the FTC (US).

**Once it's verified**
The prep pack needs a real company and role, and I don't have either yet. If the recruiter replies with those details, send them to me. A job description, your CV and the interviewer's name would help too. I'll then build a full mock-interview pack for it, including practice questions and a live drill.

If you're not sure about a reply, paste it here and I'll tell you what I think.