I can't build a prep pack yet, and I'd hold off on the interview. This message has the hallmarks of a recruitment scam.

**Red flags in the message**
- It comes from an unknown number and names no company, role, salary or location. The skill I'd use needs a company and role title, and the message gives neither.
- It says "we found your profile online" and doesn't mention any application you made.
- The whole process, "from the interview through to your contract", happens on WhatsApp, with no calls or video. Real employers almost never do this. The no-calls rule also stops you from checking who you're talking to.
- It promises remote work with flexible hours, which is the standard bait.
- It opens with a time-pressured invitation for tomorrow.

Applying to a lot of jobs makes you a bigger target. Scammers scrape job boards and CV sites, then message people who look like they're searching.

**What these scams usually do next**
- The "interview" is a text chat that ends in an instant job offer.
- You're asked for ID, bank details or a "right to work" document for onboarding paperwork.
- You're asked to pay for equipment, training or a background check. Sometimes they send a cheque and ask you to forward part of it.
- You're asked to do "tasks", like rating products or boosting listings, with a promised payout. These are advance-fee or crypto scams.

**How to check before tomorrow**
1. Ask Jess for the company name, the role title, the job posting link, and a work email address. Then ask for a video call. A genuine recruiter will say yes.
2. Search for the agency and the recruiter on LinkedIn. Contact the agency through the phone number or website you find yourself, not the one Jess gave you.
3. Check whether the role exists on the company's own careers page.
4. Don't share ID, your address, bank details or any payment until you've verified the employer. A real employer never charges you to be hired.
5. If she dodges these questions or pushes you to hurry, stop replying, block the number, and report it in WhatsApp.

**If it turns out to be real**
Send me the company, the role, the job description and your CV. I'll build the full prep pack with likely questions, answer guidance based on your own experience, and questions for you to ask. It's worth doing even for a chat-based interview. I can also run a live practice session where I play the interviewer.

Can you ask Jess for the company, role and a video call, and let me know what she says?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.