I'll load the skill. First, though, this message has several classic job-scam signs, and I'll cover them after the skill loads.
I'd hold off on prepping for this one. The message has the pattern of a recruitment scam, and the skill also needs a company and role title, which Jess didn't give you.

**Red flags in the message**
- **No company or role.** Real recruiters name the employer or agency, and usually the job.
- **Everything over WhatsApp.** Interview, contract and "no calls or video" is the biggest warning sign. Scammers avoid live contact so you can't check who they are.
- **Vague flattery with urgency.** "Found your profile online", "great match" and "tomorrow at 11am" give you little time to check anything.
- **Remote work with flexible hours, from an unknown number.** This is the standard lure.

Your guess that it came from one of your applications could still be right, since scammers scrape job boards and CV sites. That doesn't make this message genuine.

**Checks before you reply**
1. Ask Jess for the company name, the role title, the job ad link and her agency's website. Then confirm independently that the role exists on the company's official careers page, and that Jess is listed on the agency's site or LinkedIn. Use contact details you find yourself, not ones she sends.
2. Ask for a video call or a call from a company email address. A real recruiter will agree. A scammer will make excuses or push back.

**While you check**
- Don't send your ID, passport, bank details, National Insurance or SSN number, or address.
- Don't pay anything, such as for equipment, training or "software". Don't accept a cheque or transfer and forward money on.
- Don't click links she sends or install anything.
- If it turns out to be fake, block the number, report it in WhatsApp, and report it to your national fraud service (Action Fraud in the UK, the FTC in the US).

**If it checks out**
Send me the company, role title and job description, and ideally your CV. I'll build the full prep pack from them. It would include likely questions, answer guidance based on your own experience, and questions to ask them. I can also run a live practice interview. For a text-based interview it would help to know whether it's one chat with a recruiter or a hiring manager, or several rounds.

Was the message tied to a specific application you remember, or did it come out of nowhere?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.