I'd hold off on prepping for this one, because the message has several hallmarks of a recruitment scam. The prep pack needs a company and a role to work from, and the message gives neither, so I can't build a real one anyway.

**Warning signs**
- **No company or role is named.** "A remote position with flexible hours" could be anything. Real recruiters say who the client is, or at least the job title and sector.
- **Unsolicited contact from an unknown number.** The "we found your profile online" opener is standard scam wording.
- **Everything happens over WhatsApp.** The interview, the contract and "no calls or video" all stay in chat, which means nobody can verify who you're talking to. Genuine employers want to speak to you at some point.
- **The interview is tomorrow at 11am.** The short notice pushes you to respond before you've checked anything.
- **It fits many of the job applications you've sent.** Scammers count on that, because it makes you assume it's a reply to one of them.

Chat-only "interviews" like this usually lead to requests for ID, bank details, "equipment" payments or "training fees". Some are also used to recruit people as money mules.

**What I'd do**
1. **Don't share personal details.** That means ID, address, bank information or a National Insurance or Social Security number.
2. **Ask for specifics.** Ask for the company name, the job title, the job description, a company email address and the interviewer's full name. Real recruiters answer these easily. Scammers tend to dodge or go vague.
3. **Verify independently.** Look the company up yourself, find "Jess" on LinkedIn, and check that the agency has a real website and phone number. Then contact the agency through those details, not through anything the sender gives you.
4. **Don't click links or open attachments** from this number.
5. **If it's a scam, block and report it** in WhatsApp. You can also report it to your national fraud service, such as Action Fraud in the UK or the FTC in the US.

If "Jess" replies with a named company, a real role and a willingness to do a call or video interview, send me those details and your CV and I'll build the full prep pack. If you'd like to practise anyway, the same applies to the genuine interviews from your other applications. Tell me the company and role for one of those and we can start.