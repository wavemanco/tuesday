I'd hold off on prepping for this one, because the message has the usual signs of a recruitment scam.

**Warning signs**
- **Nothing specific.** There's no company name, no role title and no named job. "Found your profile online" fits any of your applications, so it doesn't show this is linked to one of them.
- **The channel.** It came from an unknown WhatsApp number. Real recruiters usually write from a company email, LinkedIn, or a job board you applied through.
- **No voice or video.** "Interview and contract all by text, no calls" is a classic pattern. It avoids anything that could identify the sender, and it leads to the usual next steps: a "task" job, a fee for equipment or training, or a request for ID and bank details.
- **The pressure.** An interview "tomorrow at 11am" gives you little time to check anything.
- **The offer.** Remote work with flexible hours is the typical bait.

**Before you reply**
1. Check your sent applications and inbox for any company that might have passed your details on. Look for a named recruiter called Jess.
2. Ask her for the company name, the exact role, a company email address and a video call. A genuine recruiter will agree. A scammer will dodge or push you to move faster.
3. Search the company and the recruiter's name on LinkedIn, and confirm the agency exists. Don't use any link or number she sends you.
4. Don't share your ID, bank details, address, or National Insurance or Social Security number. Never pay for anything, and don't accept a "cheque" or purchase task.
5. If it looks fake, block and report the number on WhatsApp.

**Prep once it checks out**
I can't build a real mock-interview pack without a company and a role. That's the one hard requirement, and right now there's neither. Once she's verified, send me:
- the company and role title,
- the job description, if you have it,
- your CV, or the key points of it,
- who is interviewing you, and what kind of round it is.

I'll then build the full prep pack and can run a live practice round with you.

Until then, if you'd like, I can draft a short, polite reply that asks Jess for those details without committing to anything.