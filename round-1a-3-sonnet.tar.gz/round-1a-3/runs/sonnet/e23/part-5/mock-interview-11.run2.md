I haven't built a prep pack, for two reasons.

**1. The skill needs a company and a role title, and this message has neither.** "Jess" gives no agency name, no employer and no job. I'd have to invent the role, and that would be rehearsing for something that may not exist.

**2. This message matches a well-known recruitment scam.** Several things stand out:
- It comes from an unknown number, with a vague "we found your profile online" and no mention of which application it relates to.
- The job is remote with flexible hours and no calls or video. That is the usual bait.
- The interview, the contract and everything else happen only on WhatsApp. Real recruiters use email, a company domain, calls or video, and a named employer.
- It pushes a fast time slot ("tomorrow at 11am").

Many people send lots of applications, so a genuine reply is possible. But nothing in this message distinguishes it from a scam.

**Before you reply:**
- Ask Jess for the agency name, the employer, the job title and a link to the advert, plus a work email and a LinkedIn profile you can check. A real recruiter will answer easily. A scammer will dodge or push you to move fast.
- Check that the agency exists and that the person works there. Contact the agency through its official website, not through any link or number Jess gives you.
- Search the exact wording of the message online alongside "scam".
- Don't share your CV, ID, bank details, National Insurance or Social Security number, or a "right to work" document over WhatsApp. Don't pay for equipment, training or background checks. Don't click links or install apps.
- Be wary of "tasks", crypto, or being asked to handle payments. Those are how these scams usually pay off.
- If it looks fake, block and report the number in WhatsApp. You can also report it to your national fraud service (Action Fraud in the UK, the FTC in the US).

**If it turns out to be real**, send me the company, the role title and the job description if you have it. Your CV and who you'll be speaking to would help too. I'll then build a full prep pack, and we can run a live practice interview if you like.

Two quick questions would help me:
1. Which of your applications might this be from? Do you remember any company or job title?
2. Has Jess replied with any more detail, such as an agency name or a link?