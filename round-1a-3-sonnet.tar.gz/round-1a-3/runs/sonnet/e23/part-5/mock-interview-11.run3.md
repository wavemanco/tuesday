I haven't built a prep pack, because I don't think this is a real interview. The skill also needs a company and role title before it can run, and the message gives neither.

**Why it looks like a scam**
- **No company or role.** "Jess, a recruitment consultant" names no agency, employer or job, and a real recruiter would lead with at least one of those.
- **Everything happens on WhatsApp.** The interview, the contract and "no calls or video" are all there. That keeps you off a verifiable platform and away from anyone you could check.
- **It's vague and unsolicited.** "We found your profile online", "remote" and "flexible hours" fit any job, and the number is unknown.
- **The timing is pushy.** An interview tomorrow at 11am leaves you little time to check anything.

You've sent lots of applications, so it's easy to assume this came from one. A scammer is counting on that. Scrapers pull profiles from job boards, so a real application of yours could be how they found you.

**What to do now**
1. Don't share ID, a passport, bank details, your address or an "onboarding fee". Don't click any links or install anything. These scams usually end in a request for one of those, or in "tasks" you're asked to pay into first.
2. Reply once, asking for the company's name, the exact job title, a link to the posting on their own site, and an email from a company domain. A genuine recruiter will send these. A scammer will dodge or push you to move faster.
3. Check any company she names yourself. Use its official careers page or a phone number you found independently, not one from the chat. Also check whether you applied there.
4. If she can't or won't answer, block and report the number in WhatsApp. If you shared anything sensitive, tell me and I'll walk you through what to do next.

If she does give a real company and role, send me those along with the job description and your CV if you have them. I'll then build a full mock-interview pack and can run a live drill. I can also prep you for any of your other applications that move to interview stage.