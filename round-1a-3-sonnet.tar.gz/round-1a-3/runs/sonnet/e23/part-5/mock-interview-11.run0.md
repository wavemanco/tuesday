I'd hold off on prepping. This message has the hallmarks of a job scam, and the interview setup is the main one.

**Red flags**
- **Unknown number, no company name.** A real recruiter says who they work for and which role it is. "Jess" gives neither.
- **The whole process happens on WhatsApp.** That includes the interview and the contract, with no calls or video. Legitimate employers almost always want to hear from and see a candidate, and they don't sign contracts in chat messages.
- **Vague, appealing offer.** "Found your profile online", "remote", "flexible hours" is the standard opening of a task scam or an identity-harvesting scam.
- **Pressure to move fast.** The interview is "tomorrow at 11am", which doesn't give you time to check anything.

Having sent lots of applications makes it feel plausible. That's also why scammers target people who are actively job hunting, since they scrape job boards and CV sites. If you had applied to a real company that contacted you, they'd name the role and the company, and you could match it to an application you remember.

**What I'd do**
1. **Don't answer yet.** If you reply at all, ask: "Which company is the role with, what's the job title, and can you send the job ad and your agency's website?" A real recruiter answers that easily. A scammer dodges it, or sends a vague reply and pushes you to hurry.
2. **Check the agency independently.** Look up the agency yourself, not through any link she sends. Call the main number on its official site and ask whether Jess works there.
3. **Check it against your applications.** See if any company or recruiter you applied to matches, using the confirmations in your email.
4. **Share nothing sensitive.** That means ID or passport, bank details, address, National Insurance or Social Security number, or a "background check" fee. Real employers don't ask for money or for sensitive documents before an offer. Don't take on any "tasks" or purchases either.
5. **Block and report if it turns out to be fake.** Report the number in WhatsApp and to your national fraud service (Action Fraud in the UK, the FTC in the US).

I haven't built an interview pack, because there's no company or role to prepare for. If Jess comes back with a named employer, a job description, and a way to verify her, send those over. I'll build a full mock-interview pack and run practice questions with you. If you can tell me which applications might have led to this, I can also help you work out which one it might be.