Checking the posting and messages against the usual markers of a job scam, plus two quick web searches. Here's the write-up.

## Decision snapshot

**No, don't go ahead. Don't send your IBAN, PPS number or passport, and don't pay or lodge anything. Status: `no_go`.** This is a confirmed severe red-flag pattern (RR1, RR2, RR3), not a gate failure.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

R2, R3 and R4 — your background matches what the posting asks; R1 — the posted pay doesn't guarantee your €30,000.

**Opportunity ledger.** The role fails on its own terms. The messages ask for identity documents before any interview (RR1), an upfront payment (RR2) and a cheque to forward on (RR3). The employer also can't be found (RR6), and the contact route is off-domain (RR5). No positive signals found.

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR6 (`severity: high`).
- **What would change this:** a real, verifiable employer on its own domain. It would also need a signed contract before any ID or money, and nothing asked of you financially. Nothing in what you've shown me points that way.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no web presence found | `[grounded]` search returned no results |
| Role | Remote order processing, 15–30 h/week, "up to €26/h plus commission", no experience needed | `[grounded]` posting |
| Pay arithmetic | At the maximum rate, 15 h/week is €20,280/yr and 30 h/week is €40,560/yr. Reaching €30,000 needs about 22.2 h every week at the top rate, and the commission is unstated | `[grounded]` posting figures, arithmetic mine |
| Process | Telegram only, no calls or video. "Passed" the screening and the interview without anyone speaking to you | `[grounded]` posting and messages |
| Market calibration | Not established: no source returned a pay band for this title, so I'm giving none | `[grounded]` searches empty |
| Unknowns | Legal entity, address, who "payroll" and the "equipment partner" are, commission terms, contract type | — |
| Contradictions | The posting says "no experience needed", yet the messages say you passed an interview | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year | hard_gate | unclear | high | hard_gate | Confidence grades your stated constraint. Fit is `unclear` because "up to €26/h" over a flexible 15–30 h does not commit to the floor | `[grounded]` your constraint; posting | Moot: the role is `no_go` for RR1–RR3 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day plus training two starters is specific, but CV-level only | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You maintain your team's weekly tracker in Excel | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written Zendesk ticket handling at volume | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` not stated | none: moot |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay reaching €30,000 (R1) | hard_gate | "Up to" rate, flexible hours, unstated commission | A ceiling isn't a floor | Not applicable | A written contract stating a guaranteed rate and hours | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | ID and bank details demanded before any interview | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Data harvesting for identity fraud or for using your account. Real employers collect these after a signed offer, through an HR system | `[generic]` common scam pattern | Which signed contract and secure HR system will hold my passport and PPS number, and why are they needed before an offer? | confirmed present |
| RR2 | Applicant asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | An advance fee that is never refunded. Legitimate employers supply or reimburse equipment through payroll | `[generic]` advance-fee pattern | Why can't the company ship equipment itself or reimburse me after I start? | confirmed present |
| RR3 | Cheque to lodge, keep a slice, forward the rest | red_flag | high | "Lodge it… keep €350… transfer the rest to our equipment partner" | The cheque is counterfeit or will bounce after your transfer clears, leaving you liable to the bank. It can also make you a conduit for laundering | `[generic]` fake-cheque pattern | Why does onboarding involve me forwarding part of a cheque to a third party? | confirmed present |
| RR4 | Hired with no call or video, Telegram only | risk_signal | medium | "no calls or video interviews" | Avoids identification and leaves no traceable process | `[generic]` | Who is my named hiring manager, and can we speak by phone? | unresolved |
| RR5 | Contact on a webmail-style domain | risk_signal | medium | "velloway.hr@postmail.example" | A real company would normally use its own domain | `[inferred]` from the address, against the company's absent web presence | Can you write from your company domain? | unresolved |
| RR6 | Employer not established | risk_signal | high | "Velloway Logistics" | Severity is raised to high because it combines with RR1–RR3. The entity may not exist as described | `[generic]` pattern; `[grounded]` the search found nothing | Where is this role on your own careers site, and who would I interview with? | unresolved |
| RR7 | €26/h with no experience, set your own hours | risk_signal | medium | "Earn up to €26 an hour… No experience needed" | Pay pitched high to attract applicants | `[inferred]` from the posting; no band source | What is the guaranteed hourly rate and commission formula? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying. Don't send your IBAN, PPS number or passport photo, and don't paste your IBAN into that chat | RR1 | `[grounded]` register | pending your approval |
| A2 | Pay nothing. If a cheque arrives, don't lodge it or forward money | RR2, RR3 | `[grounded]` register | pending your approval |
| A3 | Report and block: the jobs site (so they remove the listing), Telegram, and the Gardaí. If anything beyond your chat answers was shared, tell your bank's fraud team | RR1–RR6 | `[generic]` standard response | pending your approval |
| A4 | Your background fits many real customer-service and operations roles at €30,000+. I can vet any posting the same way | R2–R4 | `[inferred]` from your CV claims | pending your approval |

No CV edits proposed. A passport, if one is ever uploaded, isn't needed to evaluate a role, so I'd not use it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics": no results, so the employer is not established (RR6) |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Telegram hiring cheque overpayment equipment fee job scam": no results, so no market band stated |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- The jobs site's name or link to the original posting → the listing can be checked and reported (RR6).
- A deeper research pass (up to 5 more searches and 2 more fetches) → public scam reports on this name, if any exist (RR6).
- A hiring manager's name from any real employer → role reality's scope read.

I can also save this as `tuesday-dossier.md` if you'd like a record.

Questions:

1. (RR6) Which jobs site was the posting on, and can you paste its link?
2. (RR1) Besides your interview answers, did you share anything personal in the chat, such as your full name, address, date of birth or phone number?
3. (R1) What kind of role should I look at instead (customer service, operations, remote or on-site)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.