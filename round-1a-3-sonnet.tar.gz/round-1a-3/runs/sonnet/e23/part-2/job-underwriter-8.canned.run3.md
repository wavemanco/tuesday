Checking whether Velloway Logistics exists as described, then I'll give you the full assessment.
**Short answer: no, this isn't a legitimate job, and please don't send anything. It follows the pattern of a cheque or advance-fee scam that also harvests identity documents. Status: `no_go`.** The reasons are RR1, RR2, RR3 and RR4 below, all `severity: high`. Your fit for the posted duties is real, but it doesn't matter because the role isn't.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (a quiet place to work)

R2, R3 and R4 — your courier background matches the stated duties, but each rests on your account alone (`medium`); R1 — the pay can't be pinned down.

**Opportunity ledger.** Every payment and document request is one-way, from you to them (RR1, RR2, RR3), the employer can't be found (RR4), and the pay is vague (RR5).

- **Hard gates:** none failed (nothing in the posting contradicts your constraint); unconfirmed: R1 (at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a verifiable company with its own careers page and a company email domain, an offer with no payment or cheque step, and identity documents requested only after a signed contract. The messages so far make this very unlikely.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". I found no attributable web presence for it. | `[grounded]` search returned no results |
| Role | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video, and the "interview" was chat questions | `[grounded]` posting and messages |
| Pay arithmetic | €26 × 15–30 hours × 52 weeks is about €20,300–€40,600 a year at the top rate. €30,000 needs about 22 hours a week at that full rate, all year. The commission is unquantified. | `[inferred]` computed from the posting's own figures |
| Market calibration | None given. My one search returned nothing, and I won't use memory for market figures. | `[generic]` not established |
| Unknowns | Real company name, registration, the "equipment partner", who "payroll" is | `[grounded]` absent from every message |
| Contradictions | The posting says "no experience needed, full training", but the messages say you must buy a laptop and headset first. The "interview" took one chat. | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your constraint, which you stated. Fit is `unclear` because "up to €26" with a 15–30 hour range doesn't guarantee it. | `[grounded]` your constraint and the posting's figures | Moot given RR1 to RR4 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day and a weekly tracker. Your account only, with no artifact. | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Daily written Zendesk work. | `[grounded]` your background | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said, and nothing here depends on it. | `[grounded]` silence | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | €30,000 floor (R1) | hard_gate | "Up to €26" with no guaranteed hours and no commission figure | A ceiling is not a floor | Not applicable | A written contract stating the base rate and minimum hours, from a verifiable employer | `[grounded]` posting wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque sent to you, with an instruction to forward most of it | red_flag | high | "We are posting you a cheque for €2,850… keep €350… transfer the rest to our equipment partner" | The cheque is likely fraudulent. It may clear provisionally and bounce later, and you would owe the bank the money you forwarded. Forwarding funds can also draw you into money laundering. | `[generic]` well-documented overpayment-cheque pattern, not a claim about this sender | Why would an employer pay a new hire in advance to send money on to a third party? | confirmed pattern |
| RR2 | Upfront payment to start work | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | Genuine employers don't charge new hires for equipment, and a promised refund is the standard lure. | `[generic]` advance-fee pattern | Will you ship the equipment to me directly, with no payment from me? | confirmed pattern |
| RR3 | IBAN, PPS number and passport photo requested before any contract | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | These could be used for identity theft or for opening accounts in your name. Employers collect them after a signed contract. | `[generic]` identity-harvesting pattern | Can I see a signed contract before I provide identity documents? | confirmed pattern |
| RR4 | Employer not established, with a Telegram-only process and a free-mail style contact | red_flag | high | "Our whole hiring process runs on Telegram"; "velloway.hr@postmail.example" | The company may not exist as described. I found no attributable presence, and the stated contact isn't on a company domain. Combined with RR1 to RR3, this is `high`. | `[inferred]` from the failed search plus the quotes | Can you give me the company's registered number and a video call with a named manager? | unresolved |
| RR5 | Pay is a ceiling, not a rate | risk_signal | medium | "Earn up to €26 an hour plus commission" | The real pay may be well below the headline. | `[inferred]` from the posting's wording | What is the guaranteed base hourly rate and minimum weekly hours? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo. Don't pay anything. | See RR2 and RR3. | `[grounded]` register | recommended; your decision |
| A2 | If a cheque or parcel arrives, don't lodge it or forward money. Show it to your bank. | See RR1. | `[generic]` overpayment-cheque pattern | recommended; your decision |
| A3 | Stop replying, and report the Telegram account and the posting to the platform. Consider telling An Garda Síochána, and your bank if you've shared bank details. | Reports can help protect other applicants. | `[generic]` standard reporting routes | recommended; your decision |
| A4 | Ignore any "payroll" or "HR" follow-ups, including the email address. | Pressure often follows a refusal. | `[generic]` common scam behaviour | recommended |
| A5 | Check any future role for a company-domain email, a live careers page, a video interview and no payments before you apply. | Your actual background is marketable. | `[generic]` hiring norms | optional |

## Evidence status

Verified: none yet. Claims about your background are your own account.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics", which returned no results. The employer is not established (RR4). |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Telegram cheque equipment fee job scam", which returned no results. No market band is given. |
| 3. Hiring manager's public footprint | n/a | No manager name was given, only a Telegram handle, so no query could be formed. |

## Closing

I can put this into `tuesday-dossier.md` if you'd like a saved record.

**Upgrade menu**
- The URL of the original posting would tell me whether the listing is still live and whether it appears elsewhere.
- The cheque's bank name and any sender details would let you check it with your bank.
- A deeper research pass (up to 5 more searches and 2 more fetches) could look for reports about this handle. Say the word and it runs.
- A real posting from a verifiable employer would get a proper fit assessment of your Zendesk, Excel and training experience against the €30,000 floor.

**Questions** (answer in a sentence, or skip)
1. Have you sent the interviewers anything yet, such as answers containing personal details, or any money? (RR3)
2. Do you want me to draft a short message to end contact, or a report for the platform? (A3)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.