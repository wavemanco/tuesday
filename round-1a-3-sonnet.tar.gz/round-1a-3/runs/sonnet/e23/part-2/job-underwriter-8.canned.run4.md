Quick status: I've read the underwriting skill's rules and I'm now running its employer check, searching for Velloway Logistics, before I write the assessment.
**No. I can't support this as a real job, and you shouldn't go ahead. Don't send the IBAN, the PPS number or the passport photo, and don't pay anyone. RR1, RR2 and RR3 are red flags, each `severity: high`. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Earn at least €30,000 a year)
- `must_have`: direct: R2, R3, R4
- `important`: unclear: R5 (A quiet place to work)

Your fit isn't the problem: R2, R3 and R4 line up with your courier and Zendesk work. What decides this is the opportunity side, where RR1, RR2, RR3 and RR5 are the entries that matter.

**Opportunity ledger.** It has three separate demands on you: money up front (RR1), a cheque you would have to forward on (RR2), and your ID and bank details before any contract (RR3). The employer couldn't be established (RR5), and the "interview" was a chat that ended in an offer (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Earn at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR5 (`severity: high`).
- **What would change this:** a registered company with a live listing on its own careers site, a signed contract before you send any ID or bank details, and no payment or cheque-forwarding of any kind. The messages you've shown me contain the opposite of each.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" could not be found. Two searches returned nothing, and no careers page was found | `[grounded]` searches returned no results; see Evidence status |
| Mandate | "Order Processing Coordinator", remote, no duties described beyond "process orders" | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission", 15–30 hours a week. At €26 that is €20,280 a year at 15 hours and €40,560 at 30 hours. Reaching your €30,000 would take about 22 hours a week at the full top rate, which "up to" does not promise | `[grounded]` posting, arithmetic on its figures |
| Hiring process | Telegram only, "no calls or video interviews". The offer came after a chat, with no named manager and no contract | `[grounded]` posting and messages |
| Market calibration | Not run. No market band offered | `[generic]` |
| Unknowns | Legal employer, contract, who you would report to, guaranteed hours | `[grounded]` none of these appear in the posting or messages |
| Contradictions | "Set your own hours" sits beside a required 15–30 hours. "No experience needed" sits beside a €26 an hour rate | `[inferred]` from the posting's own wording |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Earn at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades the constraint, which is yours. Fit is unclear because "up to €26" with variable hours does not guarantee it | `[grounded]` your stated floor; posting figures | Moot given RR1–RR3; a contract stating guaranteed pay would be needed |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day in Zendesk is a credible match. It is self-reported with no artifact | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-reported | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written tickets are daily work for you. Self-reported | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Only you know this, and nothing has been asked | `[grounded]` posting; no answer from you | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay vs your floor (R1, hard_gate) | hard_gate | Only "up to €26 an hour", with hours set by the employer | A hard gate can't be met by a ceiling | Nothing from your side would close it | A signed contract stating the hourly rate and minimum weekly hours, from a verifiable employer | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Applicant asked to pay up front | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | A real employer supplies equipment at its own cost. A promised refund after the money has left your account is a standard way to take payment | `[generic]` pattern of employment scams, not a finding about this sender | Will you issue the equipment under a signed contract with nothing paid by me? | unresolved |
| RR2 | Cheque to lodge, balance to forward | red_flag | high | "We are posting you a cheque for €2,850. Lodge it ... keep €350 ... transfer the rest to our equipment partner" | The cheque may be counterfeit or later recalled. Your transfer of about €2,500 would be real money and the bank can claim it back from you. The scheme can also pass stolen funds through your account | `[generic]` pattern, not a finding about this sender | Why would an employer pay me money that I then send to a third party? | unresolved |
| RR3 | ID and bank details requested before any contract | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Those three items together are enough for identity fraud, and a real payroll needs them only after a signed contract | `[generic]` pattern, not a finding about this sender | Will you send a signed contract naming your registered company before I share any ID? | unresolved |
| RR4 | Chat-only hiring with an instant offer | risk_signal | medium | "no calls or video interviews" … "you passed the interview and the job is yours!" | It lacks a named manager, a contract and any real screening. Severity is medium alone, and it adds weight beside RR1 to RR3 | `[inferred]` from the posting and messages | Can I speak by video to a named manager before accepting? | unresolved |
| RR5 | Employer not established | risk_signal | high | "Velloway Logistics" and `velloway.hr@postmail.example` | No web presence was found for the company. The contact email is on a generic mail domain rather than a company one. Taken alone this would be medium, and it is high beside RR1 to RR3 | `[grounded]` two empty searches; `[generic]` pattern for unverifiable employers | Which registered company employs me, and where is this role on your own careers site? | unresolved |
| RR6 | Pay is a ceiling, and the work needs no experience | risk_signal | low | "up to €26 an hour plus commission", "No experience needed" | A high rate with no experience required can be a lure. No market sweep was run, so this stays low | `[inferred]`, not market-checked | What is the contracted hourly rate and the guaranteed weekly minimum? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying. Send no IBAN, no PPS number, no passport photo, and no payment | RR1, RR3. Your IBAN would also be the route for a cheque payment through your account (RR2) | `[grounded]` register | recommended |
| A2 | If a cheque arrives, don't lodge it. Show it to your bank's fraud team instead | RR2. A cheque that clears at first can be reversed later, and the bank can then claim back what you forwarded | `[generic]` cheque-recall pattern | recommended |
| A3 | Report the @VellowayHiring account to Telegram and the posting to the jobs site. Reporting to the Gardaí is also open to you | Protects other applicants | `[generic]` | recommended |
| A4 | Keep the messages, the posting text and the email address | Evidence if you need it later | `[grounded]` messages | recommended |
| A5 | Redirect the search to employers you can verify. Your Zendesk, tracker and training experience fits customer-operations roles at logistics and courier firms | R2, R3, R4 | `[inferred]` from your background | optional |

## Evidence status

Verified: none yet. Your background claims (60 tickets a day, training two starters, the Excel tracker) are self-reported and stay at `medium`.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers order processing coordinator". No results. Employer not established, which feeds RR5 and the Organization row |
| 2. Role-family sweep | skipped | The decision rests on RR1 to RR3, which no salary band could change. It would only have fed the market calibration line and RR6 |
| 3. Hiring manager's public footprint | n/a | No manager's name was given |
| Outside the declared targets | yes | Searched "fake job Telegram cheque lodge transfer remainder equipment partner scam Ireland". No results, so it moved nothing. The scam-pattern labels above are `[generic]`, not sourced from this search |

I can write up this assessment as `tuesday-dossier.md` if you'd like it saved.

**Upgrade menu**
- A link to the live posting on the jobs site would confirm whether it is still listed, and under what company name.
- A deeper check of Velloway (up to 5 more searches and 2 more fetches) would look for reports about the name. Say the word and it runs.
- Your hard constraints beyond pay (hours, location, contract type) would let me set the hard-gate checks for real roles.

**Questions**
1. (RR5) Which jobs site was it, and did the profile or CV you uploaded there include your address, phone number or date of birth?
2. (R1, R5) Do you want me to underwrite a real role next? If so, paste a posting or tell me what you're looking for, and your minimum hours and location.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.