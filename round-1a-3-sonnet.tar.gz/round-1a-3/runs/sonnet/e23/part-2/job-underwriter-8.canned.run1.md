# Job Underwriting: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**Do not go ahead. Status: `no_go`.** Don't send your IBAN, PPS number or passport photo. Don't pay the €349. Don't lodge the cheque.

**Fit ledger.**

- `hard_gate`: unclear: R1 (income of at least €30,000 a year)
- `must_have`: direct: R2, R3, R4
- `important`: unclear: R5 (Quiet place to work)
- `preferred`: adjacent: R6 (Order or parcel processing knowledge)

**Hard gates.** R1, your €30,000 floor, is `unclear`. The posting says "up to €26 an hour" for 15–30 hours a week, so it states no guaranteed pay. Even at the top rate, 15 hours a week is about €20k a year. You would need roughly 22 or more hours a week at the maximum rate to reach €30k.

**Opportunity ledger.** You fit the posting well, but that doesn't matter here. The messages from @VellowayHiring match an advance-fee and fake-cheque scam, and they also harvest identity documents (RR1–RR3). The employer is unverified (RR4). Everything below is read off those messages and the posting.

## Role reality

- **Posting.** Remote, flexible hours, "up to €26/h plus commission", no experience needed. `[grounded]` from the posting.
- **Hiring process.** Telegram only, with no calls or video. You were told you "passed" a screening and an interview that was just a chat, with no one from a named company. `[grounded]`
- **Contradiction.** The messages first ask you to pay €349, refunded from "first wages". Then they send you a cheque of €2,850 to lodge and forward. A real payroll would not need your money for either. `[inferred]`
- **Market calibration.** Pay for genuine order-processing or customer-operations coordinators is normally a fixed hourly rate or salary. It isn't "up to" plus commission, and the employer doesn't ask for money. `[generic]`

## Evidence map

| # | Requirement | Priority | Fit | Evidence | Gap | Confidence |
|---|---|---|---|---|---|---|
| R1 | Income ≥ €30,000/yr (your constraint) | `hard_gate` | `unclear` | Posting gives only "up to €26/h", 15–30 h/wk, with no guaranteed rate | `hard-gate` | `low` |
| R2 | Attention to detail | `must_have` | `direct` | About 60 Zendesk tickets a day, 3 years at a courier | none | `medium` |
| R3 | Confident with spreadsheets | `must_have` | `direct` | You keep the team's weekly tracker in Excel | none | `medium` |
| R4 | Good written English | `must_have` | `direct` | Written ticket work is daily; the posting's own English is poor `[inferred]` | none | `medium` |
| R5 | Quiet place to work | `important` | `unclear` | Not stated by you | `discovery` | `low` |
| R6 | Order/parcel processing | `preferred` | `adjacent` | Courier customer service, so you know parcel flows from the support side | `transferability` | `medium` |

All of this is your own account and is not independently verified. It is more than enough for the posting's stated requirements. The posting asks for no experience, which is itself a mild flag.

## Gap recovery queue

| Row | Gap | What would close it |
|---|---|---|
| R1 | Pay is "up to" and unguaranteed | A written contract with a fixed rate from a verifiable employer. Nothing here suggests you'll get one. |
| R5 | Working environment unknown | Your confirmation, only if a real role needs it. |

## Opportunity risk register

| ID | Class | Severity | Finding | Provenance |
|---|---|---|---|---|
| RR1 | red flag | critical | **Fake-cheque / overpayment pattern.** You receive a cheque, "keep €350", and send the rest on. The cheque can bounce days or weeks later after the bank has credited it. The bank then reclaims the full amount from you, and you've lost the money you forwarded. This is the standard form of the scam. | `[inferred]`, from the messages |
| RR2 | red flag | critical | **Advance fee.** You're asked to pay €349 for a laptop and headset, with a refund promised and the "partner's" details to follow. Legitimate employers don't charge candidates for equipment. | `[grounded]` from the message |
| RR3 | red flag | critical | **Identity harvesting.** IBAN, PPS number and a passport photo were requested before any contract or interview, which is more than payroll needs at this stage. Together these allow identity fraud. | `[grounded]` |
| RR4 | failed attribution | high | The employer is unverified. I haven't confirmed that Velloway Logistics exists as described, and the contact is a Telegram handle and a generic mail address (`postmail.example`), not a company domain. A live careers page or a company email would resolve this. | `[inferred]` |
| RR5 | red flag | high | **Process.** Telegram only, no calls, and an instant "passed" after a chat. Fast acceptance with no real assessment is how these scams work. | `[inferred]` |
| RR6 | mismatch | medium | Pay: "up to €26/h", 15–30 h/wk, against your €30k floor. The ceiling is roughly €20k–€40k, and the posting gives no guaranteed rate. | `[grounded]` posting; band calculated from it |

**Extra risk if you lodge the cheque:** moving money for strangers can draw you into a money-mule situation, which carries legal risk for you personally, not just a financial loss.

## Application plan

Don't apply. If you've already replied on Telegram:

1. Stop replying and block the handle. Don't open the "equipment partner" link or bank details.
2. If you've given them anything beyond your IBAN, contact your bank's fraud team. If a cheque has already arrived, don't lodge it. Keep the envelope and the cheque.
3. Report the posting to the jobs site. Report the Telegram account within Telegram. You can also report to the Gardaí.
4. Your IBAN on its own is low risk, but don't send it together with your PPS number or passport.

For real roles, you match well. Three years in courier customer service, about 60 tickets a day in Zendesk, training two new starters and running a weekly Excel tracker is a strong base for customer operations, order management or support-team-lead roles. The €30k floor is realistic for those. Signs of a real employer are a company email domain, at least one live video or phone interview, a written contract, and no payment asked of you.

CV wording for those roles would be proposed as `resume_edits_pending_approval`. I haven't proposed any yet.

## Evidence status

Research tier: L0, no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | `skipped` | Not searched. The decision rests on the messages themselves, and a company site wouldn't change the red flags. |
| 2 | Role-family pay sweep | `skipped` | Not needed for the decision. The market calibration above is `[generic]`. |
| 3 | Hiring manager footprint | `n/a` | No named person, only a Telegram handle. |

I used no passport or ID content, and none is needed to evaluate a role.

I can offer a dossier of this assessment as `tuesday-dossier.md` if you want it saved.

**Upgrade menu.**
- A link to the live posting would let me check it against the jobs site's listing.
- The sender's email headers would show whether the address matches any real company.
- A 5-search L1 check would show whether Velloway Logistics exists, though the decision wouldn't change.
- A CV would let me tailor real applications.

**Questions.**
1. [RR1–RR3] Have you sent or paid anything yet, to this account or any other contact, and has a cheque arrived? You said nothing has gone, so this is only to confirm.
2. [RR4] Which jobs site was the posting on, so you know where to report it?
3. [R1] Do you want me to look for real remote or hybrid customer-operations roles at €30k and above and check them against the same red flags?

You can answer briefly, say "skip", or answer only the one that matters.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.