Two searches for Velloway Logistics returned nothing. I'm running one pay-benchmark search for this kind of role, then I'll give you the full assessment.
**No. Don't go ahead, and don't send anything else. This is almost certainly a scam, and the offer has no genuine job behind it. Status: `no_go`. RR1, RR2, RR3 and RR5 are all `severity: high`.**

You haven't sent anything yet, so you've lost nothing. Please don't paste your IBAN anywhere in that chat.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Annual income of at least €30,000)
- `must_have` — direct: R2, R3
- `important` — direct: R4; unclear: R5 (A quiet place to work)

R2, R3, R4 — your background matches the skills the posting names; R1 — the posting never guarantees pay that reaches your floor; R5 — nobody has asked and it can't move the decision.

**Opportunity ledger.** The employer isn't established (RR5), and the messages ask you for money, a cheque transfer, and your identity documents before any contract exists (RR1, RR2, RR3). The pay claim is well above market for a no-experience role (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Annual income of at least €30,000).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR5 (`severity: high`).
- **What would change this:** the employer verified on its own careers site and company registry, a written contract with a guaranteed rate and hours that reach €30,000, and no request to pay out or forward money. The messages already contradict that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics; two searches returned nothing attributable, so the entity is not established | `[grounded]` searches "Velloway Logistics" and a scam-pattern search on "Velloway", both empty |
| Mandate | Remote order processing, 15–30 hours a week, hours set by you | `[grounded]` posting |
| Pay as posted | "Up to €26 an hour plus commission"; no guaranteed rate or minimum hours | `[grounded]` posting |
| Pay against your floor | €30,000 at €26 an hour needs about 22 hours a week, all year, at the top rate. "Up to" means that rate isn't promised | `[inferred]` arithmetic on the posting's own figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, middle half €28,400–€34,100. That is about €15 an hour on a 40-hour week, so €26 for "no experience" is roughly 1.7 times that. The survey excludes commission-only and freelance work, so the comparison is rough | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide (n=1,140); `[grounded]` posting for the €26 |
| Hiring process | Telegram only, no calls or video; "interview" was a chat | `[grounded]` posting and your messages |
| Contradictions | The equipment fee flips: first you pay €349 of your own money, then they send you €2,850 to forward to the "equipment partner" | `[grounded]` your two messages |
| Unknowns | Who the legal employer is, the contract basis, who the "equipment partner" is | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Annual income of at least €30,000 (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. Fit is `unclear` because pay is "up to" and hours are 15–30 | `[grounded]` your constraint; posting pay terms | G1 |
| R2 | Strong attention to detail | must_have | direct | medium | none | Roughly 60 tickets a day in Zendesk is steady accuracy work. It rests on your account only, so no higher band | `[grounded]` your stated background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Stated by you, not yet inspected | `[grounded]` your stated background | none |
| R4 | Good written English | important | direct | medium | none | Written ticket replies are your daily work, and your messages here are clear | `[inferred]` from your described role | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Nothing stated | `[grounded]` silence in your message | none; it can't move the decision |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay that reaches €30,000 (R1, hard_gate) | hard_gate | Only "up to €26" for 15–30 hours, with commission unquantified | Without a guaranteed rate and hours the floor can't be shown to be met | Not a gap in your experience; the posting's terms are the gap | A signed contract from a verified employer stating rate and minimum hours | `[grounded]` posting terms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Upfront payment demanded from you | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Advance-fee fraud: the money goes to a third party and the refund never comes | `[grounded]` your message; `[generic]` that real employers supply equipment or reimburse receipts, not take payment first | Why must a new hire pay a third party before starting, rather than you shipping the equipment or reimbursing a receipt? | unresolved |
| RR2 | Cheque you lodge, then forward most of it | red_flag | high | "We are posting you a cheque for €2,850. Lodge it… keep €350… transfer the rest" | Fake-cheque scheme: the bank may credit the cheque, then reverse it after you've sent about €2,500 of your own money, and the account may also have been used to move someone else's funds | `[grounded]` your message; `[generic]` known pattern for fake cheques | Why would an employer pay a new hire to forward money to a supplier it could pay directly? | unresolved |
| RR3 | Identity and bank details requested before any contract | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Identity theft, or use of your account to move funds | `[grounded]` your message; `[generic]` that genuine employers collect these only after a signed offer, through HR systems | Under which signed contract, and through which HR system, do you collect a passport and PPS number? | unresolved |
| RR4 | Telegram-only hiring; "interview" was a chat | risk_signal | medium | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | The channel hides who is behind it. Medium on its own, because some small firms do use messaging apps; the other flags carry the weight | `[generic]` pattern | Who is the named person I'd report to, and can I speak to them on a call? | unresolved |
| RR5 | Employer not established from attributable sources | risk_signal | high | "Velloway Logistics" | The firm may not exist or may not be the one hiring. High because it combines with RR1–RR3 and RR6 | `[grounded]` two empty searches; `[generic]` pattern | Can you point me at this role on your own careers site, and give your company's registered name and number? | unresolved |
| RR6 | Contact email not on an employer domain | risk_signal | medium | "velloway.hr@postmail.example" | The address looks like a generic mail service rather than a company's own domain | `[inferred]` from the posting naming Velloway while the address uses a different domain | Can you write to me from an address on your company's own domain? | unresolved |
| RR7 | Pay well above market for "no experience" | risk_signal | medium | "Earn up to €26 an hour plus commission… No experience needed" | Pay is set high as bait. Medium because the survey covers salaried roles only | `[generic]` Pennoral guide; `[grounded]` posting | What is the guaranteed hourly rate, the minimum weekly hours, and how is commission calculated? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying. Send no IBAN, PPS number, passport photo or payment, and lodge no cheque | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Screenshot the chat and the posting, then block and report @VellowayHiring in Telegram and report the posting to the jobs site | Evidence for any report | `[generic]` standard practice | pending your approval |
| A3 | Report it to the Gardaí and tell your bank's fraud team. If a cheque arrives anyway, don't lodge it | Cheques can be reversed after the bank shows the money | `[generic]` known pattern | pending your approval |
| A4 | Count real roles at the €31,200 salaried median or above for customer operations, using your Zendesk volume, two people trained, and Excel tracker | see R2, R3, market calibration | `[inferred]` from your background against `[generic]` median | pending your approval |

No CV or outreach wording is proposed here. Every row is a suggestion for you to decide on.

Offer beyond this assessment: I can screen genuine remote customer-operations postings against your €30,000 floor. It would use the same checks as above, and I'd build it only if you say yes.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway" with scam terms; both returned nothing attributable, so the employer is not established. This moved RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly rate"; it returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This moved the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No person was named, only a Telegram handle |

I can write this up as `tuesday-dossier.md` if you want a record to keep.

**Upgrade menu**

- The employer's registered company name and number, or the role on its own careers site → RR5 could close, though RR1–RR3 stand regardless.
- A signed contract stating hourly rate and minimum hours → R1 and G1 close.
- A named hiring manager → the hiring-manager footprint target could run.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.