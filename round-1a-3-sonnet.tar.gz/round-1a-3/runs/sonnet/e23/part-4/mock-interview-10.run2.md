I'll load the interview-prep skill. First, though, there's something in that Telegram message I want to look at.
Before we prep, I'd check that this message is real. Several things in it match a known fake-recruiter scam pattern.

**Red flags**
- **Everything happens on Telegram.** The interview, the offer and the onboarding all happen in one chat, with no company email, video call or HR system. Real companies rarely do this, because offers and contracts need a paper trail.
- **The contact was unexpected.** A careers-page application normally gets a reply from the company's own email or applicant system. Did you give a Telegram handle on the application? If not, they got it from somewhere else.
- **Onboarding in the chat is where these scams pay off.** The usual next steps are asking for ID or bank details "for payroll", asking you to buy equipment or software, or sending "training tasks" that need money up front.

I can't tell from here whether it's fake. It could be a small company with an unusual process. These checks will settle it:
1. Find Lumenvale's careers page yourself, without using any link from the chat. Check that the job is listed, and look for a named recruiter or a contact email.
2. Email the company's official address, or reply through the application portal. Ask them to confirm that Marcus Hale messaged you and that the process runs on Telegram.
3. Search LinkedIn for Marcus Hale at Lumenvale. Check that the Telegram account matches, and look at how old it is and whether it has a profile history.
4. Ask for a video interview and a written offer from a company-domain email. A real recruiter will agree. A scammer will push back or stall.

**Until you've verified it**
- Don't send your ID, passport, bank details, National Insurance or Social Security number, or an address.
- Don't pay for anything, and don't click links or install anything they send.
- Don't go along with a request to move to another app.

**If it is real, your fit is good.**

| Requirement | Your evidence |
|---|---|
| 2+ years in support | 3 years as a customer service advisor at an energy supplier |
| Zendesk or similar | You use Freshdesk every day, which is a direct equivalent |
| Clear written communication | About 60 calls and emails a day |
| Confident with escalations | This is the one to prepare for. Think of a specific escalation you handled, and what you did and what happened. |

Your one real gap is that you haven't worked at a software company. Be upfront about it, and point to the transferable parts: high volume, ticket-based work, and training four new starters on refunds, which shows you can explain a process to someone else.

Likely questions:
- Tell me about a difficult escalation.
- How would you pick up a new product quickly?
- How do you prioritise a busy queue?
- Why move from energy to software?

Once you've confirmed the process is genuine, I can build the full prep pack. It would include a question bank, answer guidance drawn from your own experience, and a live mock interview where I play the support team lead. It would help to have the full job ad and to know whether you have a video or phone round as well.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.