Before the prep, one thing to check: parts of this message match a common recruitment-scam pattern. I'll load the interview-prep skill now and cover that below.
Your prep pack is built, and here's the one thing to check before you rehearse. I couldn't confirm Lumenvale or Marcus Hale, because my web search was declined. A process run entirely in Telegram, with the offer and onboarding in the same chat, is worth verifying before you share anything personal. Find the posting on Lumenvale's own site or the careers page you applied through, and confirm Marcus using an address listed there, not one he gives you in chat. Ask for a video call or a company-email step. Don't send ID, bank details or money, or install anything, until that's confirmed.

The pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/e23/part-4/rooms/case-10-denied-7fd743ef/Lumenvale_customer-support-specialist_interview_pack.md`. It has 18 questions across five interview styles, a fit table built from your own words, and reverse questions. Because the search was declined, nothing in it comes from research on Lumenvale, and I assumed the team lead interviews like a hiring manager. The one to rehearse hardest is A1, "you haven't worked for a software company", because it rests on a gap you stated yourself.

I can play the team lead on A1 as a live text-chat drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word, if you'd like either.

1. Can you paste the full job ad text from the page you applied through? It would replace the paraphrased requirements and sharpen the questions.
2. Did Marcus say anything about format, length, topics or a test, and is the team lead the person you'd report to? That would reweight the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, name not given. Format, in the invitation's own words: "your interview will be a text chat here with our support team lead". Built on one assumption: a team-lead text chat behaves like a hiring-manager round, so persona weights start from that prior. If the lead is not your future manager, the weights move.

## How to use this pack

- Personas are how a question is asked. Types are what it scores: EXP (does your background survive scrutiny), JD (can you do the listed job, gaps included), CASE (a live problem from the role), VAL (published values), CO (company knowledge). No VAL or CO questions appear because no company values or strategy were available to build them from.
- Guidance is scaffolding, not a script. Each cell is sized to be spoken in 90 to 120 seconds; in a text chat that is roughly three to five short messages.
- Quotes in the fit snapshot are your own words. Where the pack says "answer slot", it is giving you an instruction for the interview, not asking you anything now: answer from what you really did, or say plainly it was not yours.
- Highest-ROI rehearsal: A1, the software-company question. It will be asked in some form, and it rests on a sentence you wrote yourself.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — JD, as relayed in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length, but a self-reported line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: three years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — JD, as relayed in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad's "or a similar ticketing tool" leaves room for a tool other than Zendesk, and your quote names Freshdesk, so a probe on how the two compare is likely (A3). Say it as you wrote it: "I use Freshdesk every day." |
| F3 | "clear written communication" — JD, as relayed in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are part of that volume, but the quote does not show whether your written replies were ever reviewed or judged clear. Answer slot: the JD asks for clear written communication, so expect a probe on it. If anyone reviewed or commented on your emails, say what and who, in your own words; if nobody did, say so plainly and let this chat itself be the sample |
| F4 | "confidence handling escalations" — JD, as relayed in your message | none given | none | [grounded] | discovery | Your material does not show whether escalations were part of your work. Answer slot: the JD asks about escalations, so expect a probe. If contacts were escalated to you or by you, say which kind and what you did, in your own words; if none were, or it was not your job, say so plainly and describe how you would handle one (B2) |
| F5 | Familiarity with software products or a software employer: not in the ad, a likely probe because the employer is a software company | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Strengths beyond the four listed requirements: not in the ad | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Use it in the quote's own terms: trained, four new starters, refunds process, last year. Expect a probe on which part was yours (C3) |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "2+ years in customer support" | A4, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" | A3, C2 |
| "clear written communication" | A5, B4, E3 |
| "confidence handling escalations" | B1, B2, E2 |
| Not in the ad: software-company gap (F5) | A1, A2, B3, E1 |

## Persona table

Round type assumed from your message: a text chat with the support team lead, treated as a hiring-manager-type round. Loop: one session, established by the invitation's own wording; no values round is mentioned, so none is assumed.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the software-company gap, the Zendesk-versus-Freshdesk gap and escalation experience | High: hiring-manager prior, and F5 is a gap you stated yourself | Rehearse A1 until it is boring; bridge only from what you wrote; say the limit plainly |
| Case / Strategist | Live ticket scenarios, possibly typed on the spot | High: hiring-manager prior, and the format rewards a written reply on the spot | Clarify, then structure, then write the reply; think aloud in short messages |
| Data-Driven Prober | Pressing on "around 60 calls and emails a day" and on the training claim | Medium: two concrete claims in your background invite it | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Conversational | Friendly opener, "tell me about yourself", motivation | Medium: chat openers are common, and a casual register is still scored | A short arc built from your quoted lines; treat casual questions as scored |
| Pressure | Time-boxed or blunt challenges on software experience and escalations | Medium-low: a text chat limits interruption, but terse challenges are possible | Hold through two follow-ups, then concede specifically |
| Values and Peer | Not built | Low: one session with a team lead, no values round documented, no peer named | Revisit if you learn otherwise |

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company. Why should we expect you to do well in software support?" | JD | [grounded] "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked for a software company." Then what your material does carry, at its own scope: "3 years as a customer service advisor at an energy supplier", and "I use Freshdesk every day". Close with a plan in the future tense for learning the product, in your own words. Follow-up levels to rehearse: (1) "What would you struggle with most in the first month?" (2) "How would you cope with a technical question you can't answer?" (3) "What if you can't reproduce the customer's problem?" Hold the position that your support work is real by returning to the quotes; concede the product gap specifically each time, and never add experience to cover it. Answer slot: why software support appeals to you is yours to state, in your own words; if the reason is mainly practical, say so plainly | F5 is the one gap you stated yourself and the likeliest first challenge; JD because it scores fitness for the listed role | 
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick one real weakness and name it first, then the step you would take. The material points at product knowledge: "I haven't worked for a software company." Say what you would do in week one to close it, as a plan. Answer slot: if another area is truly your weakest, name that one instead, in your own words | A direct invitation to concede honestly; JD because it scores the stated requirements; calibrated candor beats a rehearsed non-weakness (F5) |
| A3 | "The ad mentions Zendesk or a similar tool, and you've used Freshdesk. How comparable are they?" | JD | [grounded] "I use Freshdesk every day" | Start with the sentence you wrote: "I use Freshdesk every day." Compare only what you have used yourself, in your own words. Answer slot: if you have seen other ticketing tools, say which and how; if you have not, say so plainly and return to Freshdesk, then say how you would pick up a new tool | F2 is a requirement the ad words by tool name, so the comparison probe is likely; JD because it scores the ticketing-tool requirement |
| A4 | "Why move from energy to software support, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Two beats the quote carries: three years as a customer service advisor, at an energy supplier. The reason for moving and the timing are yours to state, in your own words. Answer slot: if there was a trigger, say what it was; if it was a gradual decision, say so plainly. Keep it forward-looking and avoid criticising the energy supplier | The standard motivation-consistency check for a sector change (F1, F5); EXP because it tests whether the story hangs together |
| A5 | "This role is remote and text-first. How does your background fit that?" | JD | [grounded] "answering around 60 calls and emails a day" | The quote says calls and emails, so the written part is the emails and no more than that. Answer slot: if you have worked from home, say how it went; if you have not, say so plainly and say how you would set up your working day. If you can say how much of the volume was written rather than spoken, say it in your own words; if you do not know, say so | F3 and the remote setup in your message make this a natural probe; JD because it scores the written-communication requirement |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in for the third time about the same unresolved problem and is angry. How do you reply?" | CASE | [generic] | Structure: acknowledge the repeat contact and the frustration; look at the earlier history before replying; state who owns the next step and by when; ask for anything missing in one short list; say when you would involve someone else. The question needs no claim about your past, so the guidance makes none | A live problem straight from the role's escalation line (F4), asked as a decision; generic because it is a pattern, not a fact about this employer |
| B2 | "A customer demands a refund outside policy and asks for a manager. What do you do?" | CASE | [grounded] "I trained four new starters on our refunds process last year" | Structure first: listen, confirm what the policy allows, offer what you can do now, explain the limit plainly, and say what an escalation would involve. You can mention that you trained four new starters on the refunds process last year, at that scope. Answer slot: the JD asks about escalations, so expect a probe on real cases. If you have handled something like this, say what happened and what part was yours, in your own words; if not, say so plainly and stay with how you would handle it | F4 is thin on evidence, so the structure carries the answer; CASE because it is a live decision, with F6 as the only related quote |
| B3 | "A customer reports a problem in our software and you can't reproduce it. What do you do?" | CASE | [generic] | Structure: ask for steps, device and any error text; ask for a screenshot or recording; confirm what you have tried; log it with those details; tell the customer what happens next and when. Say aloud that you would check the team's known-issues process before guessing | Tests the F5 gap with a problem needing no software background to structure; generic because it makes no claim about your past |
| B4 | "Here's a ticket: 'It doesn't work, fix it.' Write the reply you'd send." | CASE | [generic] | Write it live: a short acknowledgment, two specific questions, and the next step. Keep it plain and kind, without jargon. In a text chat this may be asked literally, so practise it in your own phrasing until it takes under a minute | F3 is the requirement your material shows least, and a text interview can test it directly; CASE because it is a live task |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the quote's own word, "around". Answer slot: how the number was counted, what it is sensitive to such as quieter or busier days, and the assumption behind it you would defend least; if you do not know how it was counted, say so plainly. Say which part is yours, in your own words. Never turn "around 60" into a precise figure | A headline figure on your background invites a defend-the-number probe (F1); EXP because it tests attribution honesty |
| C2 | "What do you use Freshdesk for day to day?" | EXP | [grounded] "I use Freshdesk every day" | Describe in your own words what you actually do in it. Answer slot: the JD asks about ticketing tools, so expect a probe on how you use it. If you use particular features, say which and what for; if you use only the basics, say so plainly. Never list features you do not use | F2 is the requirement with the clearest evidence, so it is where a prober checks depth; EXP because it tests what you actually did |
| C3 | "You trained four new starters on refunds. What did you do, and what did the team do?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Keep the quote's scope: you trained four new starters on the refunds process, last year. Answer slot: if you set the content or the method, say how, in your own words; if the process and materials were someone else's and you delivered them, say so plainly. Say how you knew it worked only if you actually know | F6 is a good story and an attribution probe is the likeliest follow-up; EXP because it tests what was yours |

### D. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me about yourself and how you ended up applying." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A short arc in three or four messages built from your own lines: three years as a customer service advisor at an energy supplier; Freshdesk every day; training four new starters on the refunds process last year. Then why this role, in your own words. Answer slot: the reason for applying is yours to say; if it is simply that the role matched your skills, say so plainly | The casual opener is still scored, and it is where the arc is set (F1, F2, F6) |
| D2 | "What draws you to customer support work?" | JD | [generic] | Pick a real reason and the kind of moment that reflects it; keep it to a short message or two. If no specific moment comes to mind, say so plainly, then give the nearest thing your own experience carries, or how you would approach it | An easy-sounding question about motivation that is still scored; generic because it needs no claim about your past |
| D3 | "What does a good day in support look like for you?" | JD | [generic] | Say what a good day means to you in your own words: a clear queue, customers helped, handovers done. If the picture is not specific yet, say so plainly and describe what you would want it to be | Rapport register; tests whether your picture of the job matches theirs |

### E. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Quick: why you, when other applicants have software support experience?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year"; "I've never worked for a software company" | Hold: three years as a customer service advisor at an energy supplier, Freshdesk every day, four new starters trained on the refunds process last year. Hold that through two follow-ups by returning to those lines. Concede specifically: "I haven't worked for a software company." Never claim the gap away, and never add to the lines | F5 makes this the pressure form of A1; JD because it scores fit against the listed requirements |
| E2 | "The role needs confidence handling escalations. What's your evidence?" | JD | [grounded] | Pause, restate the question, then answer from your own experience. Answer slot: if you have handled escalated contacts, name the kind and what you did; if you have not, or it was not your job, say so plainly and describe how you would handle one, using the B2 structure | F4 is where the material is silent, so the challenge arrives here; JD because it scores the stated requirement |
| E3 | "Everything here is written. How do I know your writing holds up?" | JD | [grounded] "answering around 60 calls and emails a day" | The honest answer begins with this chat itself. The quote says calls and emails, so the emails are the written part. Answer slot: if anyone ever commented on your written replies, say who and what; if not, say so plainly and point to how you have written today | F3 is the gap a text interview exposes most directly; JD because it scores the stated written-communication requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Could we do the next step on a video call, or can you confirm this process from a Lumenvale email address?" | Your invitation says the process is "carried out entirely on Telegram", so the request is reasonable and gives you a way to confirm who you are dealing with |
| R2 | "Which ticketing tool does the team use, and how are escalations passed between people?" | Shows you think in workflows and addresses F2 and F4 from your side |
| R3 | "For someone coming from outside software, what would the first 90 days of learning look like?" | Meets the F5 gap directly and signals the ramp plan you rehearsed in A1 |
| R4 | "How is the quality of written replies reviewed here?" | Signals you take F3 seriously; the answer tells you how you would be judged |
| R5 | "Is the role fully remote, with set hours, and who would I report to?" | Practical, and it tests how clear the employer is about the basics |
| R6 | "What separates people who do well in their first six months from those who struggle?" | Shows you are thinking about succeeding, and surfaces what the lead really values |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Worked for a software company, or in software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk |
| Administered or configured the ticketing system | Inflated form of F2 | F2's quote at its own scope; C2's slot asks only what you do in it |
| Ran the team's training or onboarding programme | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on the refunds process last year. C3's slot asks only which part was yours |
| Handled exactly 60 contacts a day as a measured average | Inflated form of F3 | The quote at its own scope: "around 60". C1's slot asks only how it was counted |

## Sources

Provided documents: the Telegram invitation and the four listed job-ad requirements as you relayed them, and your own background in your message. No dossier was consumed.

Searches sent, all refused by the host (permission not granted): "Lumenvale Software company"; "Lumenvale Software Customer Support Specialist remote careers"; "Lumenvale Software recruiter Telegram interview scam". No fetches were sent. Nothing about Lumenvale, including whether the company or the named recruiter can be confirmed, is established by this pack.

Research tier: L1 — searches 0 of 6 completed (3 sent, all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Search permission was not granted; would have fed a values cheat sheet if a values round existed |
| 2. Lumenvale Software interview process, support role | unavailable | Same; would have confirmed the loop. The loop here rests on the invitation's own words |
| 3. Lumenvale Software strategy and recent news | unavailable | Same; would have fed CO questions, so the pack has none |
| 4. Interviewer name and company | n/a | The team lead is not named, so there was no query to form |
| 5. Representative or company posting for the role | unavailable | The careers-page query was refused; would have supplied the full ad text, so JD cells quote only your relayed summary |

Un-numbered: "Lumenvale Software company" and "Lumenvale Software recruiter Telegram interview scam" were sent outside every declared target and refused, so they moved nothing.

## Upgrade menu

- The full job ad text, copied from the page you applied through → F1 to F4 requirements become verbatim JD quotes, and more JD questions get a raising source
- Lumenvale's own published values or product description, from their official site → a values cheat sheet if a values round turns out to exist, and a company-knowledge question
- Any detail from the recruiter or team lead on format, length or topics, such as a typing or ticket test → persona weights and a build section for any pre-declared task
- The team lead's name → an interviewer read and a reverse question tied to their path
- Your answers to the F3 and F4 slots, such as feedback on your emails or any escalated contacts you handled → those rows move to grounded and B2, E2 and E3 become story-mapped
- A performance review or quality-score record from the energy supplier, anonymised → F1 and F6 evidence can move from medium to high
- Allowing a web search, or running the research yourself → values, loop and strategy facts replace the placeholders above
