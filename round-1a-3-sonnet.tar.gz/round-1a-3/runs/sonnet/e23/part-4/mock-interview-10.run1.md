Before the prep, a warning: parts of that message match a common recruitment scam pattern. I'll flag them first, then load the interview-prep skill.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/e23/part-4/rooms/case-10-denied-5dcecfb4/lumenvale-software_customer-support-specialist_interview_pack.md`. It has 18 practice questions, a map of your background against the ad, reverse questions and a list of claims not to make. I built it for a text chat with the team lead and weighted it towards live support scenarios and probing of your gaps.

**Before you reply to Marcus:** the message has features that often show up in recruitment scams. The offer and onboarding are meant to happen entirely in a Telegram chat, which usually means handing over ID and bank details. It also reached you on Telegram, although you applied through the careers page. I couldn't verify Lumenvale Software or Marcus Hale because my web searches were refused, so treat both as unverified. The pack's "Process check" section lists what to do: find the careers page yourself and see if the role is listed, ask for a video call, and ask for the offer by email from a company address. Don't send ID or bank details in chat, and don't pay for anything.

The pack is built around these points:
- **Biggest gap:** you haven't worked for a software company. Question A1 rehearses a plain "I haven't worked for a software company" followed by a plan for learning the product, and the pack names it as your highest-value prep.
- **Freshdesk and Zendesk:** say Freshdesk by name and don't present it as Zendesk.
- **Escalations:** your message doesn't mention any, so A4 and E2 are for you to fill in with a real example, or to say plainly if you haven't handled one.

**Upgrade menu** (the last section of the saved file):
- The full text of the job ad
- Search permission, which would add the company's values and strategy
- Your own answers on writing quality and escalations
- The team lead's name
- A job-underwriter dossier

I can play the sceptical team lead on A1, with follow-ups, as a live practice round. I can also save a `tuesday-dossier.md` of the gaps this prep found, or convert the pack to Word.

Can you paste the full job ad? That would turn the four requirements you relayed into exact quotes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Candidate: Imani. Interviewer: the support team lead, unnamed; the invitation came from Marcus Hale of the talent team. Round: one text chat on Telegram. Built as a hiring-manager-style round, because the interviewer is the team lead for the role.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding for your own words, not a script, and every statement about your past rests on a sentence you wrote.

| Type | Meaning |
|---|---|
| VAL | Behaviour against the company's published values (none were available, so no VAL questions) |
| EXP | Whether a claim about your experience survives follow-up |
| JD | A stated requirement of the role, including its gaps |
| CO | Company and strategy knowledge (none were available, so no CO questions) |
| CASE | A live problem from the role, worked through in front of the interviewer |

Because this is a text chat, your replies are the writing sample: short paragraphs, the answer first, no padding.

## Process check: before you invest time or send anything

| Observation | Source | Provenance | What to do |
|---|---|---|---|
| The whole process, offer and onboarding included, is described as running in one Telegram chat | "Our hiring process is fully remote and is carried out entirely on Telegram" and "your offer and onboarding will be completed in this chat as well" — the message you received | [generic] | Onboarding normally means sending identity and bank details. Send none in chat. Ask for the offer and contract by email from a company address, and for the next step by video call |
| The contact reached you on Telegram, while you applied through the careers page | Your material does not say you gave a Telegram handle on the application | [generic] | Check whether the application form asked for your Telegram. If it did not, treat the contact as unverified |
| The message names a recruiter and a job, and gives no verifiable detail such as a company email address or a link to the posting | The message you received | [generic] | Find the careers page yourself by typing the address, not by tapping a link, and see whether the role and a talent team contact are listed there |
| Nothing in the message asks for money so far | The message you received | [generic] | Stop if anyone asks you to pay for equipment, training or software, to buy anything, or to move money |

I could not verify Lumenvale Software or Marcus Hale: the web searches I tried were refused (see Sources). Treat both as unverified until you have checked them through the company's own channels.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length, though a one-line claim with nothing inspected behind it invites a probe. Say it as written: three years as a customer service advisor at an energy supplier. Your title was advisor, so use that word and let the interviewer map it to support |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say it as written, naming Freshdesk. Whether Freshdesk counts as similar is the interviewer's call, so name the tool and do not present it as Zendesk |
| F3 | "clear written communication" — the job ad as you relayed it | "answering around 60 calls and emails a day" — your message | low | [grounded] | discovery | Emails are written work, but the quote does not show how your writing was judged or what it was like. Answer slot: the ad asks for clear writing, so expect a probe on your replies. If you can say what a good reply of yours looked like, say it in your own words; if you cannot, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — the job ad as you relayed it | none given | none | [grounded] | discovery | Your material does not show escalation work either way. Answer slot: the ad names escalations, so expect a probe. If a customer issue went beyond you at the energy supplier, say what happened and what part was yours; if escalations were not part of your role, say so plainly and say how you would handle one |
| F5 | The employer is Lumenvale Software, a software company — your message | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan in the future tense, never as a past |
| F6 | Helping colleagues learn the work (role-family expectation, not in the ad) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Say it as written: you trained four new starters on your refunds process last year. Keep to those words and let the interviewer ask for more |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support | A2, D1, E1 |
| Zendesk or a similar ticketing tool | A3, C3, D3 |
| Clear written communication | B3, C1, D2 |
| Confident handling escalations | A4, B1, B2, B5, E2 |
| Software-company gap (not in the ad, raised by F5) | A1, E1 |
| Company strategy (CO) | none, because no company research could be run |
| Company values (VAL) | none, because no published values were available and no values round is documented |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live support scenarios you answer in writing | Highest. A hiring-manager-style round tends to test live problem handling, and a text chat suits scenarios | Clarify first, state the aim, then the steps; write the answer in short lines |
| Skeptic | Probes the software gap and the Freshdesk-versus-Zendesk gap | Highest. F5 and F2 are the two places the material is thinnest against the ad | Rehearse the F5 answer until it is boring; plain acknowledgment plus a learning plan |
| Data-Driven Prober | Asks how the sixty a day and the four trainees were counted and what was yours | Medium. Both are figures a reader will test | Say what you know about the count and say plainly what you do not |
| Conversational | Friendly opener, then casual questions that are still scored | Medium. A chat format often starts casually | Have a 90-second arc ready; treat casual questions about tools as scored |
| Pressure | Short time-boxed challenges | Low. Text chat makes interruption harder, but a short challenge can still appear | Hold your quoted position through two follow-ups, then concede the F5 limit specifically |

## Question banks

### A. Skeptic (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you find hardest on day one?" | JD | [grounded] "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked for a software company." Then give a plan in the future tense for learning the product and the team's tools, in your own words. Hold through two follow-ups by returning to the plan, never by claiming product knowledge you do not have | F5 is the gap the interviewer will go to first, so this objection arrives in some form. JD because it scores the role's fit |
| A2 | "You've spent your career in energy. Why move to software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Say the three years and the role in those words. Answer slot: the reason for the move is yours and nothing in the material carries it. Say your actual reason; if the reason is mainly the remote format, say so plainly, then add only what you can truthfully say about the work | F1 carries the background, but no row carries motivation, so the question tests honesty about the reason. JD because it scores why this role |
| A3 | "We use Zendesk and you've said Freshdesk. How would you close that gap?" | JD | [grounded] "I use Freshdesk every day" | Hold on the quote: you use Freshdesk every day, and the ad asks for Zendesk or a similar tool. Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly and stay with Freshdesk. Then the ramp as a plan, in the future tense | F2 is a tool-name match rather than the named tool, so the probe is likely. JD because it scores the ticketing-tool requirement |
| A4 | "Tell me about a time a customer issue was escalated, or you escalated it." | JD | [generic] | Selection scaffold: pick an occasion with a named stake, what you personally did, and how it ended with the customer. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | F4 has no evidence, and the ad names escalations, so this is the likeliest question to arrive unrehearsed. JD because it scores a stated requirement |
| A5 | "What would make you leave a job like this within six months?" | JD | [generic] | No claim about your past is needed. Name one real thing you would need from a team to stay, and say it without blame. Avoid answering that nothing would | A Skeptic tests motivation consistency alongside A2. JD because it probes fit with the role |

### B. Case / Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says a refund was promised twice by email and has not arrived. They are angry in chat now. Walk me through your next ten minutes." | CASE | [generic] | Clarify first: what was promised, by whom, what the ticket shows. Then acknowledge, own the next step, give a time for the next update, and record it. Say what you would not promise | Live handling of an escalating customer, the heart of the ad's escalation line. CASE because it is a live problem |
| B2 | "A customer reports a bug and wants it fixed today. Engineering says next week. What do you tell the customer and what do you do inside the team?" | CASE | [generic] | Clarify the impact, give an honest expectation, offer a workaround if one exists, write the escalation so engineering can act without asking again, and set an update rhythm. Say you would not promise the date | Tests the software-support side that F5 leaves unproven. CASE because it is a live problem |
| B3 | "A ticket says only: your app is broken, fix it now. What do you reply first?" | CASE | [generic] | Write the reply aloud in short lines: acknowledge, ask the two or three details that unblock you, say what happens next. Keep it under about six lines | Scores written clarity directly, which F3 leaves unproven. CASE because you produce the work live |
| B4 | "You have twenty open tickets and an angry customer lands in chat. How do you order your work?" | CASE | [generic] | Say your criteria out loud, such as impact and time sensitivity, then tell the waiting customers something honest. Name what you would do first and why | Tests prioritisation in a queue-based job. CASE because it is a live problem |
| B5 | "A customer asks for something policy does not allow and will not accept no. What do you do?" | CASE | [generic] | Acknowledge, explain the reason in one sentence, offer what you can do, and say when you would hand it to someone with authority. Hold the policy without sounding cold | Ties to the ad's escalation line without presupposing your past. CASE because it is a live problem |

### C. Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around sixty calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the figure as you wrote it. Answer slot: how it was counted, what it varies with, which assumption you would defend least, and how much of it was calls rather than emails. Answer each in your own words; where you do not know, say so plainly | The figure is the headline metric in your message, and F3 rests on it. EXP because it tests the claim under follow-up |
| C2 | "You trained four new starters. What was your part in that?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold on the quote: you trained four new starters on your refunds process last year. Say in your own words what you did with the four; if part of it was set by someone else, say which part and stay with the part you did | F6 is a one-line claim with nothing behind it, so attribution is the likely probe. EXP because it tests what was yours |
| C3 | "Walk me through how you use Freshdesk day to day." | EXP | [grounded] "I use Freshdesk every day" | Describe only what you actually do in it, in your own words. If the interviewer names a feature you do not use, say so plainly and stay with what you do use | Tests F2 at the level of real use. EXP because it tests depth behind a tool name |

### D. Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc: the three years and the role as quoted, then what you want next, in your own words. Keep it to beats you can stand behind | An opener that sets the tone for every later question. EXP because it is your story in your words |
| D2 | "What does a good written reply look like to you?" | JD | [grounded] "answering around 60 calls and emails a day" | Give two or three criteria in your own words and write the answer in that same style. Where you describe your own replies, keep to the fact that you answer calls and emails daily | Scores written communication directly, with F3 as the evidence. JD because it scores a stated requirement |
| D3 | "What are you using in help-desk tools these days?" | JD | [grounded] "I use Freshdesk every day" | Speak only to what you use: Freshdesk, daily. Answer slot: if you have looked at Zendesk, say how; if you have not, say so plainly and say what you would look at first | A casual question about the tool named in the ad, so it is scored. JD because it scores the ticketing requirement |

### E. Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year"; "I've never worked for a software company" | Hold: three years as a customer service advisor at an energy supplier, Freshdesk every day, four new starters trained on your refunds process last year. Concede specifically: "I haven't worked for a software company." Then the learning plan from A1. Do not fold on the held points, and do not add to them | Pressure on F5 with F1, F2 and F6 as the held ground. JD because it scores fit against the stated gap |
| E2 | "Thirty seconds: the angriest customer you have dealt with." | JD | [generic] | Selection scaffold as in A4: a named stake, what you did, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing or how you would handle it | Time-boxed version of the escalation probe in F4. JD because it scores the escalation requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When a ticket needs engineering, what does a good handover look like, and who decides?" | Shows you think about escalation as a process and tells you whether the team has one |
| R2 | "What does the first month look like for someone new to software support, and what training is given?" | Owns the F5 gap openly and asks for the ramp |
| R3 | "What tools does the team use, and how is reply quality reviewed?" | Connects to the tool and written-communication requirements |
| R4 | "Can the next step be a video call, and can the offer and contract come by email from a company address?" | A real employer can answer plainly; evasion tells you something |
| R5 | "Who would I report to, and which hours does the team cover?" | Practical for a remote role and shows you are weighing the job too |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The pack's observation is that your material says Freshdesk, not Zendesk. A3's slot allows either branch |
| Experience handling escalations | Inflated form of nothing said; F4 is silence | No claim is written. A4, B1, B2, B5 and E2 are a scaffold and live problems, never your past |
| Software-company or product-support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." Then a plan |
| Having designed or led the refunds training | Inflated form of F6 | F6's quote at its own scope: you trained four new starters on your refunds process last year |
| Having a measured quality or satisfaction record on your replies | Inflated form of F3 | F3's quote at its own scope: you answered around sixty calls and emails a day |

## Sources

Provided: your description of the job ad and your background, and the Telegram message you received.

Searches sent, all refused because web search was not permitted in this session:

- "Lumenvale Software company values" — refused
- "Lumenvale Software Customer Support Specialist interview Telegram recruiter scam" — refused
- "Customer Support Specialist remote job description Zendesk escalations" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | The search was refused. It would have fed a values sheet and VAL questions |
| 2. interview process | unavailable | No search was sent after the refusals. Persona weights rest on your own words, which describe one text chat with the team lead |
| 3. strategy or recent news | unavailable | No search was sent after the refusals. It would have fed CO questions, so there are none |
| 4. interviewer name | n/a | The team lead is unnamed; Marcus Hale is the recruiter, not the interviewer |
| 5. representative job description | unavailable | The search was refused. Your relayed requirements fix the fit snapshot, but the full ad text would have tightened it |
| Un-numbered: the scam and process check | unavailable | The search was refused, so the Process check section rests on the message's own words |

## Upgrade menu

- The full text of the job ad → the four relayed requirements become exact quotes and any mid-list requirement gets a question
- Search permission for this session → company values, documented loop and current strategy, which would add VAL and CO questions and a verification of the company
- Your own answers to F3 and F4 (what a good reply of yours looked like, and any escalation you handled) → those rows move from discovery to story-mapped answers
- The team lead's name → an interviewer read and a reverse question tied to their path
- A tuesday-dossier.md from the job-underwriter skill → verified evidence and a prohibited-claims list in place of the locally built one
