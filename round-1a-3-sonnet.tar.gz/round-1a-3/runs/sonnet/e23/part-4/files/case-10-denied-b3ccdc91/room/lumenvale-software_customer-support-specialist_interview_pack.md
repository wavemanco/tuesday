# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Candidate: Imani. Interviewer: the support team lead (name not given), by text chat on Telegram. Built as a hiring-manager round, since the team lead is the likely future manager. This is the first version.

## How to use this pack

- Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words.
- Type key: VAL is behavioral or values alignment. EXP is a work-experience deep-dive. JD is role- or job-ad-driven. CO is company and strategy knowledge. CASE is a live hypothetical problem.
- Question IDs run by persona: A Case, B Skeptic, C Prober, D Conversational, E Pressure, V Values. Fit-snapshot rows are F1 to F6. The Values bank is V so that it does not collide with F rows.
- The interview is a text chat, so every answer is also a writing sample. Short, plain, well-ordered replies score twice.
- The job-ad lines below are as you relayed them in your message. The full ad was not supplied.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap against the number. Lead with the quote's own terms: three years as a customer service advisor at an energy supplier. Expect a probe on what the role involved, so stay with what you said |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad's own wording allows a similar tool, so say Freshdesk plainly and say you use it every day. Your material says Freshdesk and nothing about Zendesk, so Zendesk stays out of what you claim |
| F3 | "clear written communication" — the job ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written work, but the quote does not show whether the replies were clear, and the link is this pack's derivation. Answer slot: the ad's line makes a probe on how you keep a written reply clear likely. If you have a way of checking your replies, say what it is in your own words; if you have none you can name, say so plainly and return to the calls and emails |
| F4 | "confident handling escalations" — the job ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show whether you handled escalations. Answer slot: the ad's line makes this probe near-certain. If you dealt with escalated cases, say what the case was and which part was yours; if escalations went to someone else, or there were none, say so plainly and return to the calls and emails |
| F5 | Familiarity with a software company's products and customers — role-family prose, not in the ad as relayed | "I've never worked for a software company" — your message | none | [grounded] | capability | You stated it, so the words are yours: "I've never worked for a software company." Then a plan for learning the product, said as a plan and never as a past |
| F6 | None stated in the ad; a strength you raised | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Nothing to bridge. Use it at its own scope: four new starters, the refunds process, last year. Expect "how much of that was you", so keep to those words |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live ticket scenarios typed into the chat; scored on structure and tone | Highest. A hiring-manager round for a support role buys "can this person do the job", and a text chat is the natural place to test written replies live | Clarify, state what you will do, state what you cannot promise, keep it short |
| Skeptic | Probes the escalations line and the software gap | Highest. F4 is a required item with nothing behind it in your material and F5 is a gap you flagged yourself | Rehearse the escalations question until it is boring; say limits plainly |
| Data-Driven Prober | Reads your lines closely: the 60 a day, the four trainees | Medium. A team lead has your CV and will test the numbers | Know what you can and cannot say about how each figure was counted |
| Conversational / Rapport | Friendly openers: walk me through your journey | Medium. A chat opener is almost certain, and casual questions are still scored | A short arc for the biography question |
| Pressure | Time-boxed or blunt: why you over someone with software experience | Low to medium. Support leads sometimes test composure, but no signal here points to a stress style | Pause, anchor in what you said, hold through two follow-ups |
| Values / Behavioral | Customer-first scenarios | Low to medium. No published values were available, so these use standard stems | Pick a real instance or say none comes to mind |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same refund and says they will cancel and leave a review. Reply to me as you would in the chat." | CASE | [generic] | Write it as you would send it: acknowledge in one line, say you have looked at the earlier messages instead of asking again, say what you will do and by when, say plainly what you cannot promise, give one next step. Keep it short. The question needs no claim about your past, so the guidance makes none | The F3 requirement is cheapest to test by having you write live; CASE because it is a live problem |
| A2 | "A customer says a feature has stopped working and sends one line. What do you ask first?" | CASE | [generic] | Clarify before solving: what they were doing, what they saw, any error message, when it started, device or browser, a screenshot. Then say what you would check and when you will come back. Say you would use the knowledge base for product specifics rather than guess | Tests whether the F5 gap shows up as guessing; CASE because it is a live problem |
| A3 | "Two urgent tickets arrive at once and you can take only one. How do you choose?" | CASE | [generic] | State your criteria aloud: how many people are affected, what is blocked, any deadline, who is already waiting longest. Then say you would tell the second customer promptly and ask the lead how the team prioritises. No claim about your past is needed | A routine support judgment call; CASE because it is a live problem |
| A4 | "A customer demands a manager and will not tell you what the problem is. What are your next steps?" | CASE | [generic] | Stay calm, ask once what outcome they want, explain what you can do yourself and what needs someone else, then hand over with the facts gathered so the customer does not repeat themselves. Say you would tell the customer what happens next. No claim about your past is needed | Covers the ad's escalations line (F4) as a decision, which is safer ground than a past you may not have; JD content, CASE delivery |
| A5 | "You think a ticket needs engineering, but the customer wants an answer today. What do you do?" | CASE | [generic] | Say what you would gather before handing over (steps, account, screenshots, what you already tried), tell the customer honestly what you know and when they will hear back, and keep ownership of the follow-up. No claim about your past is needed | Tests the F5 gap in the live setting; CASE because it is a live problem |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The ad asks for confident handling of escalations. What escalations have you handled?" | JD | [grounded] "answering around 60 calls and emails a day" | The highest-ROI rehearsal in this pack. Answer slot: if you dealt with escalated cases, say what the case was and which part was yours, in your own words; if escalations went elsewhere, or there were none, say so plainly and return to the calls and emails you answered. Hold through two follow-ups by returning to what the quote carries, never by adding to it. Concede specifically: say what you have not handled and say how you would learn the team's escalation path | F4 is a required item with no evidence behind it, so this objection arrives in some form; JD because it scores the stated requirement |
| B2 | "You have not worked for a software company. What will be hardest for you on day one?" | JD | [grounded] "I've never worked for a software company" | Say it plainly: "I've never worked for a software company." Then give a plan, not a past: how you would learn the product, what you would ask for in week one, how you would find out what you do not know. Hold through a follow-up about technical customers by returning to F1 and F2, and concede that you cannot speak to this product yet | F5 is a stated gap and the likeliest objection after F4; JD because it tests fit with the role |
| B3 | "Which part of this job description would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the one you honestly believe, then say how you would close it. Do not invent a modest weakness. Whichever you pick must be true | The stem is standard for skeptics; JD because it asks you to rank the ad's own lines |
| B4 | "Why move from energy into software support, and why now?" | JD | [generic] | Selection scaffold: pick the real reasons, name one concrete thing about this role that draws you, and keep it consistent with the rest of your answers. If you cannot name a reason beyond wanting a remote job, say that plainly and say what you hope to learn | Motivation consistency is what skeptics score; JD because it concerns fit for this role |
| B5 | "We use Zendesk. How would you get up to speed on it?" | JD | [grounded] "I use Freshdesk every day" | Open with the quote: "I use Freshdesk every day." Then a plan: ask for a sandbox or a walkthrough, read the help documentation, shadow a colleague for the first tickets. The question asks for a plan, so say a plan | F2 covers the tool requirement; the ad's own "similar ticketing tool" wording supports leading with Freshdesk |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted, and how much of it was yours?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: say how the figure was counted if you know, what it is sensitive to, and the assumption behind it you would defend least, all in your own words. "I don't know exactly how it was counted" is an honest answer. Keep to the quote's own scope: around 60, calls and emails together | F3 and F1 draw on this figure, so it is the number a prober tests; EXP because it checks attribution |
| C2 | "Walk me through the refunds training you did." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence carries: four new starters, the refunds process, last year, in your own words. Answer slot: say which part was yours; if the training was shared or set by someone else, say so plainly | F6 is the only evidence of teaching others; EXP because it asks what you did |
| C3 | "How do you use Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | Say what you use it for, in your own words, naming only what you actually use. If there is a feature you have not touched, say so plainly rather than guess | F2 is the evidence for the tool requirement and is a one-line CV-style claim, so expect a probe on it |

### D. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey to this application." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc: where you are (three years as a customer service advisor at an energy supplier), what draws you to this role, and what you would bring. Answer slot: the middle part is your reason for moving, in your own words; if you have no reason beyond the move itself, say that plainly | A chat opener is almost certain and scored; EXP because it checks the arc against F1 |
| D2 | "What did a typical day look like as a customer service advisor?" | EXP | [grounded] "answering around 60 calls and emails a day" | Describe it at the quote's own scope: around 60 calls and emails a day. Add only what you remember doing, in your own words | Casual in register, but it feeds F1 and F3 |
| D3 | "How do you feel about working remotely, mostly through writing?" | JD | [generic] | Selection scaffold: pick a real example of how you stay focused and in touch, or if none comes to mind, say so plainly and say how you would set it up. Do not claim remote experience your material does not show | The role is remote; JD because it tests fit with that |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already supported software customers?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I've never worked for a software company" | Pause, then hold what the first quote carries: three years as a customer service advisor at an energy supplier. Concede plainly: "I've never worked for a software company." Hold through two follow-ups, and do not fold on the core point to restore harmony | F1 against F5 is the sharpest comparison an interviewer can draw; JD because it ranks you against the ad |
| E2 | "You said you trained new starters. How much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence: you trained four new starters on the refunds process last year. Answer slot: say which part was yours, in your own words; if any of it was shared, say so plainly. Never enlarge your part after a second follow-up | F6 is the only teaching evidence, and "how much was you" is the stock pressure probe |

### V. Values / Behavioral (weight 2)

No published company values were available, so these use standard stems and are not mapped to Lumenvale's values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an instance with a named stake, a choice you made, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem; VAL because it tests behavior |
| V2 | "Tell me about a time you had to tell a customer something they did not want to hear." | VAL | [generic] | Selection scaffold: pick an instance where the message was clear, kind and landed. If no such time comes to mind, say so plainly, then say how you would deliver it | Adapted from the standard "unpopular truth" stem; VAL because it tests behavior |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | D1, D2, E1 |
| "experience with Zendesk or a similar ticketing tool" | B5, C3 |
| "clear written communication" | A1, A2, C1 |
| "confident handling escalations" | B1, A4, A5 |
| Remote working | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 30 days look like for someone coming from outside software?" | Shows you have a ramp plan for F5 |
| R2 | "How do escalations work here: what is the path and who owns the customer after handover?" | Shows you take the escalations line seriously |
| R3 | "Which ticketing tool and knowledge base does the team use, and how do you keep answers consistent?" | Shows tool curiosity without a claim about any tool |
| R4 | "How is the quality of written replies measured?" | Ties to the written-communication line |
| R5 | "What do the strongest people on the team do differently?" | Shows you aim to learn from the best |
| R6 | "How does a new starter's first week work: who do they shadow and what access do they get?" | Shows you are thinking about onboarding |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material says Freshdesk, not Zendesk |
| Has proven clear written communication | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day". The pack's observation: the material says emails were answered, not how clear they were |
| Has software-company or software-product support experience | A negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company". No slot |
| Handled around 60 tickets a day | The quote limits it, F3 | "around 60 calls and emails a day": calls and emails together, around, per day. Nothing more |

## Sources

Provided documents: your message (the Telegram text, the job-ad requirements as you relayed them, and your background).

Searches sent, all refused (search permission was not granted):

- "Lumenvale Software company values careers": refused
- "Lumenvale Software Telegram recruiter interview scam": refused
- "Lumenvale Software Customer Support Specialist remote interview process": refused

Research tier: L1 — searches 0 of 6 returned, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The values cheat sheet and a CO question; search was refused |
| 2. `Lumenvale Software interview process Customer Support` | unavailable | Loop structure and persona weights; search was refused |
| 3. `Lumenvale Software strategy` / recent news | unavailable | A CO question grounded in current strategy; no call was sent after the first refusals |
| 4. `{interviewer name} Lumenvale Software` | n/a | The team lead is unnamed, so there was no query to form |
| 5. representative `Customer Support Specialist` JD | unavailable | More requirement rows; no call was sent after the first refusals |

## Upgrade menu

- The full job-ad text → any lines beyond the four you relayed become rows, and the JD-tagged questions become `[grounded]`
- The support team lead's name → an interviewer read and a reverse question tied to their path
- Your own answers to the slots on F3 and F4 → those rows leave `discovery` and the banks gain story-mapped answers
- A support-domain artifact, such as a Freshdesk report or a training outline you are free to share → F1, F2 and F6 could move from `medium` to `high`
- Search permission → the values cheat sheet, loop structure and a CO question
- The recruiter's process details → coverage of anything pre-declared
- A job-underwriter dossier → verified evidence and a dossier-backed prohibited-claims list
