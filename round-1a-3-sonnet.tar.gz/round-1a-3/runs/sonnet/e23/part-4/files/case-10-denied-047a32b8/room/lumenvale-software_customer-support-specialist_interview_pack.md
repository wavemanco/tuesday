# Interview prep pack: Customer Support Specialist, Lumenvale Software

- **Role:** Customer Support Specialist (remote), Lumenvale Software
- **Interviewer:** the support team lead; no name given. Marcus Hale (talent team) arranged it
- **Format:** one typed text chat on Telegram, per Marcus's message. This is the only session the pack prepares for
- **Relationship assumed:** hiring-manager style, since a support team lead is most likely the person you would report to. This is an assumption; if the lead is a peer, the weights in section 8 change

## How to use this pack

- Personas describe how a question arrives; types describe what is being scored. Every question carries both
- Guidance is scaffolding, not a script. Say it in your own words, and only what you actually did
- This interview is typed, so answers should be short messages (three to six lines), not speeches. Your written replies are themselves part of what is being scored
- Rehearse in this order: B1 first (the pack's highest-ROI prep), then A4, then the rest

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values the company publishes |
| EXP | Work-experience deep-dive | Whether your stated experience survives follow-ups; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth about the company |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

Requirements are quoted from your message's summary of the ad, not the ad itself. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you summarised it in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms, so there is no gap, but it is a line with nothing inspected behind it and a probe is likely. Lead with it in its own terms and keep your own job title as you wrote it |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you summarised it in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad's "or a similar" wording leaves room for the tool you named, so lead with the quote as written. Your material does not say whether you have used Zendesk by name. Answer slot: if you have used Zendesk, say where, in your own words; if you have not, say so plainly and return to the tool you use every day |
| F3 | "clear written communication" — the ad, as you summarised it in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails among your contacts, not how clear they were, and the bridge should not stretch it. Answer slot: if you have anything that shows how clear your replies were, say what it is, in your own words; if you have nothing, say so plainly and stay with the emails you answered. This interview is itself typed, so your messages in it are the sample the lead reads |
| F4 | "confidence handling escalations" — the ad, as you summarised it in your message | none given | none | [grounded] | discovery | Your material does not show escalations either way. Strong evidence here would be one specific case: what came in, where it went, what you did. Answer slot: the ad's escalation line makes a probe on a time you dealt with one likely. If you did, say what happened and which part was yours; if escalations went to someone else or did not come up in your role, say so plainly and say how you would handle one |
| F5 | The employer is a software company: "Lumenvale Software" — Marcus's message. The ad as you summarised it lists no software requirement | "I've never worked for a software company" — your message | medium | [grounded] | capability | A gap wording cannot close, and you have said so yourself. Your words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | No ad requirement; a strength your message raises | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Say it in its own terms: four new starters, the refunds process, last year. Keep "trained". The quote does not say what the training involved or whether you set it up, so expect a probe on which part was yours |

## Persona table

The loop here rests on Marcus's own words: one session, a typed chat, run by the support team lead. No archetype fallback is used. Weights start from the hiring-manager prior (Case/Strategist and Skeptic), adjusted for the typed medium and for your message.

| Persona | How it shows up in this chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Typed scenarios: an angry customer, a stuck ticket, an escalation | High. The hiring-manager prior puts it first, and F3 and F4 are requirements a lead can only test with live problems; a typed chat makes the written reply the evidence | Clarify, then reply, then state what happens next; rehearse A1 to A5 by typing them out timed |
| Skeptic | Quiet probing of what your material does not show | High. F5 is a gap you stated, F4 has no evidence given, and the hiring-manager prior includes this persona | Rehearse B1 until it is boring: your stated limit, the quotes at their own scope, a plan said as a plan |
| Conversational / Rapport | Casual typed openers: tell me about yourself, what is your day like | Medium. A chat is where a lead opens casually, and casual questions are still scored | Prepare C1 as a short typed arc built only from your quotes |
| Data-Driven Prober | Asks how a figure was counted | Medium. F3 and F6 each carry a figure, and a figure is where a prober starts | Know how each figure was counted and say plainly where you do not know; D1 to D3 |
| Values / Behavioral | Scenario prompts about customer-first behavior | Low. No values source was read and Marcus names no values round, so none is detected | Keep two selection scaffolds ready; E1 and E2 |
| Pressure | Time-boxed, blunt challenge | Low. Nothing in Marcus's message suggests a stress format | Hold-then-concede on F1 and F2 below |
| Peer Evaluator | Seam and collaboration questions | Low. It rises only if the lead turns out to be a peer, which is the question put to you below | Reciprocity framing; G1 and G2 |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: they were charged twice and say they will cancel today. Type me the first reply you would send." | CASE | [generic] | Structure the reply: one plain sentence that you understand the problem, what you are doing about it and by when, only the question you really need answered, and nothing you cannot promise. Type it, then read it as the customer would. The question needs no claim about your past, so the guidance makes none | F3's requirement delivered as a live task; in a typed chat the reply is the evidence |
| A2 | "A customer's issue needs the engineers and there is no fix yet. They want an exact time. What do you tell them, and what do you do inside the team?" | CASE | [generic] | Clarify first (what the customer is blocked on and whether there is a workaround), then give an honest expectation without inventing a time, name who you are bringing in, and promise the next update at a stated point. Invented certainty is the failure to avoid | F4's escalation requirement as a decision rather than a story |
| A3 | "A customer asks for a manager and says they will post about this publicly. How do you handle it?" | CASE | [generic] | Stay calm and specific: acknowledge, restate what you can do now, say plainly what you cannot, and say who you would involve and why. A plan for the moment, with no claim about a time it happened | Escalation pressure from the F4 requirement, with a Pressure flavour |
| A4 | "Tell me about a time you dealt with an escalation." | JD | [generic] | Open prompt, theme from the ad's escalation line. Selection scaffold: pick a case with a named stake, what you personally did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F4 is the row with no evidence given, so this is the question most likely to expose it; JD because it scores the stated requirement |
| A5 | "Forty tickets are waiting at the start of your shift. How do you decide what to answer first?" | CASE | [generic] | Say your ordering logic aloud in a few lines: what is most urgent for the customer, what is blocking them, what can be answered quickly, and what you would flag to the lead. Make no claim about how your current job orders work | Tests structure under volume; included because the role is a support queue |

### B. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company before. What would you find hardest about starting here?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Beat one, your stated limit, in your words: "I've never worked for a software company." Beat two, what you do carry, at the quotes' own scope: three years as a customer service advisor at an energy supplier, and Freshdesk used every day, told as facts and not as proof you are ready. Beat three, a plan said as a plan. Answer slot: say what you would learn about the product first and how you would find it out, in your own words; nothing here supplies the plan. Follow-up one, how quickly would you be useful: do not give a timeframe you cannot back; say what you would do first. Follow-up two, is that not a big gap: concede it specifically, product knowledge is what you do not have yet, and hold on the support work your quotes carry | F5 is the one gap you stated and the employer's name raises it, so this objection arrives in some form; JD because it scores fit with the employer's field, Skeptic because it presses the gap directly |
| B2 | "The ad asks for Zendesk or a similar tool. Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Open with the quote: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where, in your own words; if you have not, say so plainly and return to the tool you use every day. Do not describe tool features you have not used | F2's requirement names a specific tool; the probe tests whether the similar tool is close enough |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Choose one you can say plainly. F5 is the one your material states: "I've never worked for a software company." If you choose a different weak spot, it has to be one you actually have, and it must come with how you would close it. If no weak spot comes to mind, say so plainly, then say what you would ask the team first | Persona stem for the Skeptic; F5 is the likeliest honest answer |
| B4 | "Why move from an energy supplier to a software company, and why us?" | EXP | [generic] | Answer slot: your reasons for the move, in your own words; nothing in this pack supplies them. For why this company, name only what you have actually looked at on Lumenvale's own site before the chat. If you have not looked yet, do that first | F5 raises a motivation probe; a reason you do not hold is the one that fails the second follow-up |
| B5 | "The ad asks for clear written communication. Your background mentions calls and emails. What shows your writing is clear?" | JD | [inferred] "answering around 60 calls and emails a day" | Start with what the quote carries: emails among your daily contacts. Answer slot: if you have anything that shows how clear your replies were, say what it is, in your own words; if you have nothing, say so plainly and stay with the emails you answered. Your answers in this chat are also the sample | F3 is `low` and the interview medium is itself the test, so this probe is likely |

### C. Conversational / Rapport (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself and how you ended up applying here." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A short typed arc with the beats the quotes state: three years as a customer service advisor at an energy supplier, Freshdesk used every day, four new starters trained on the refunds process last year. Then answer slot: why this role, in your own words. Five lines at most | The biography question is scored even when it feels casual; F1, F2 and F6 supply its beats |
| C2 | "What does a normal day look like in your current job?" | EXP | [grounded] "answering around 60 calls and emails a day" | The beat the quote states: around 60 calls and emails a day. Describe the rest of your day in your own words, and add no step you did not do | A casual route into F3's figure and the day-to-day behind it |
| C3 | "What do you already know about Lumenvale?" | CO | [generic] | Say only what you have actually looked at, and name where you saw it. If you have not looked yet, say so plainly and say what you will look at next. Research was not available when this pack was built, so nothing about the company is given here; look at its own website and any public product pages before the chat | Homework signal; generic because no company research could run |

### D. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "About 60 contacts a day. How was that counted, and was that a typical day?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the quote's word "around". Answer slot: how the figure was counted, what it varies with, the assumption behind it you would defend least, and which part was yours; in your own words, and if you do not know how it was counted, say so plainly | F3's figure is the defend-the-number target |
| D2 | "Tell me about training those four new starters. Which part was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats the quote states: four new starters, the refunds process, last year, and that you trained them. Answer slot: how the four were counted, and which part of the training was yours; if it was a shared effort, say so plainly | F6 is the figure and the attribution probe together |
| D3 | "What do you actually do in Freshdesk day to day?" | JD | [grounded] "I use Freshdesk every day" | Start with the quote. Answer slot: describe what you do in the tool in your own words; do not name a feature you have not used. If a feature is asked about that you have not used, say so plainly | F2 asks for ticketing-tool experience, and the probe tests its depth |

### E. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a choice you made, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Persona stem; low weight because no values round was documented |
| E2 | "Tell me about a time you gave a customer or a colleague an unwelcome truth." | VAL | [generic] | Selection scaffold: choose a case where the hard truth actually landed, using "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Values interviewer; the support role makes the theme plausible |

### F. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you rather than someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause, restate the question, then hold at the quotes' scope: three years as a customer service advisor at an energy supplier, Freshdesk every day. Concede specifically: "I've never worked for a software company." Do not claim to be better than the other candidate | F5 turned into a time-boxed challenge; hold-then-concede is the type's bar |
| F2 | "That training you mention. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the quote at its scope: you trained four new starters on the refunds process. Answer slot: which part was yours, said plainly; if part of it came from others, say so and return to the part you did | Attribution probe from the Pressure persona on F6 |

### G. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How do you handle it when a colleague answers a customer differently from how you would?" | VAL | [generic] | Selection scaffold: say what you would check first (the customer's outcome), how you would raise it respectfully, and when you would leave it alone. If no such time comes to mind, say so plainly, then say how you would handle it | Peer persona stem; weight rises if the lead is a peer |
| G2 | "When a customer's problem has to pass to another team, how do you hand it over?" | JD | [generic] | Method, not a story: what the next person needs to see without asking again, how the customer is told what happens next, and when you follow up. No claim about your own handovers | Seam question adjacent to F4's escalation line |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 "2+ years in customer support" | C1, C2, F1 |
| F2 "experience with Zendesk or a similar ticketing tool" | B2, D3 |
| F3 "clear written communication" | A1, B5, D1 |
| F4 "confidence handling escalations" | A2, A3, A4, G2 |
| F5 employer is a software company | B1, B3, B4, F1 |
| F6 no ad requirement; a strength your message raises | D2, F2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does the first 90 days look like for someone joining in this role?" | Gets the ramp stated, and sets up the product learning plan in B1 |
| R2 | "Which ticketing tool does the team use, and how does onboarding on it work?" | Ties to F2 and shows you are thinking about the tool |
| R3 | "How are escalations handled on the team: what stays with the specialist and what goes where?" | Ties to F4 and shows you take the requirement seriously |
| R4 | "What does a good written reply look like on your team?" | Ties to F3, and an example is something you can match |
| R5 | "Is the work all typed, or are there calls or video too?" | The chat format suggests a typed role; the answer shapes how you prepare |
| R6 | "What happens after this chat: is there another step, and when and how are the contract and employer details shared in writing?" | A plain process question; it gets the steps stated so you can check them against the company's own careers page |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Worked for a software company | Negative you stated, F5 | The plain acknowledgment from your message: "I've never worked for a software company." No slot |
| Led or managed the new starters, or designed their training | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your message says you trained four people, not what the training involved. D2's slot stays on which part was yours |
| Set up or administered Freshdesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your message says you use it, not that you configured it. D3's slot stays on what you do in it |
| Handled exactly 60 contacts every day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day." D1's slot stays on how that figure was counted |

## Sources

Provided documents: Marcus Hale's Telegram message (pasted by you), and your own message (the ad's requirements as you summarised them, and your background). No full job ad text and no CV document were provided. No dossier was present.

Searches sent, all refused by the host (the permission was not granted):

- `Lumenvale Software company values` — refused
- `Lumenvale Software interview process customer support specialist` — refused
- `Lumenvale Software news strategy` — refused
- `Marcus Hale Lumenvale Software talent` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have supplied the values cheat sheet and named values for the VAL bank. Without it no values section exists and E1 and E2 are generic |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Would have shown the loop and any documented rounds. The loop here rests on Marcus's own words instead |
| 3. `Lumenvale Software news strategy` | unavailable | Would have grounded a CO question in current strategy. C3 is generic instead |
| 4. interviewer name plus company | n/a | The support team lead's name was not given, so there was no query to form. The interviewer read is absent |
| 5. representative Customer Support Specialist JD | skipped | The ad's requirements as you summarised them fix the fit snapshot and the JD-tagged questions |
| Un-numbered: `Marcus Hale Lumenvale Software talent` | unavailable | A search outside the declared targets, aimed at the recruiter rather than the interviewer; refused, so it moved nothing |

Nothing in this pack states a fact about Lumenvale Software, its product, its values or its interview process. Everything about the employer is either quoted from Marcus's message or absent.

## Upgrade menu

- The full text of the ad → rows F1 to F4 become exact quotes of the ad instead of your summary, and any mid-list tool or process requirement gets its own question
- Your CV → the evidence cells can draw on CV lines, and F3 and F4 may move off `discovery`
- Your answers to the slots in F3 and F4 (anything showing how clear your replies were; a case where you dealt with an escalation) → those rows and A4, B5 regenerate from your own words
- A redacted sample of your written replies, a quality-review or customer-satisfaction report, or a ticket-volume export, with customer details removed → medium-confidence rows can rise toward `high`
- Whether the lead is your future manager or a peer, and any focus areas Marcus gave → persona weights recomputed
- A link to Lumenvale's own careers page or published values → a values cheat sheet if a values round is documented, and a loop source for the persona weights
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; this session's search permission would need granting) → a grounding brief on the company and CO questions that are not generic
- The lead's name, if you get it → an interviewer read and a reverse question tied to their path
- The time you have before the chat → a prep triage sized to it
- A `tuesday-dossier.md` from the job-underwriter skill, if you have one → verified evidence and stated prohibited claims, which tighten rows F1 to F6
