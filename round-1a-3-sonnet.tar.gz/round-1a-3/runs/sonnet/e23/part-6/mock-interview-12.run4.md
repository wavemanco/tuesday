**Don't prepare for this interview yet, because this email is almost certainly a scam.** It matches a well-known fake-cheque employment fraud:

- **A fee before the interview.** Real employers never charge candidates to attend an interview. The "equipment registration fee" to a "supplier's account" is the first bite.
- **Passport photo and bank details.** "To speed up onboarding" is a pretext. These are what's needed for identity theft or to take over accounts.
- **The €1,850 cheque.** You'd deposit it, and your bank may make the funds look available within days. You'd then send the "balance" to the "vendor". The cheque is fake and bounces weeks later, and the money you sent is gone. You'd owe your bank the full amount.
- **The pattern as a whole.** Money and documents are requested before any interview, and the "interview" is 30 minutes with an office manager. A genuine process would not work this way.

**What I'd do:**
1. **Don't pay the €95** and don't send the passport photo or bank details. If you've already sent any of these, contact your bank straight away. If it was the passport, tell the Passport Office and keep an eye on your credit file.
2. **Don't reply to the email** beyond, at most, nothing at all. Replying confirms your address is live.
3. **Check the company independently.** Search for Brennock Facilities Ltd on the Companies Registration Office (CRO) site, and contact it using details you find yourself, not the ones in the email. Check whether the job ad was on a real board and whether the recruiter's details match.
4. **Report it.** Tell the job site where you applied, forward the email to your email provider as phishing, and report it to An Garda Síochána. Your bank's fraud team will also want to know.

You haven't done anything wrong. These scams copy real ad wording, which is why the duties sounded plausible.

**Your background suits genuine admin roles.** Running a four-physio appointment book and chasing unpaid invoices maps well onto calendars, travel and invoice processing. Your gap is Excel, since you say you're "okay" with it. If you'd like, I can build a full mock-interview pack for real remote admin assistant interviews. It would include likely questions, answer guidance drawn from your clinic experience, a plan for the Excel question, and questions to ask employers, including how to spot a legitimate hiring process. For that, it would help to have a real job description, if you have one, and to know whether the round is with a manager or a recruiter. I can also start from a generic admin-assistant pack if you don't have either yet.