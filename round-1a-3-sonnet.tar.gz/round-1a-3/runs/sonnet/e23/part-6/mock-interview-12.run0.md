**Don't pay anything, and don't send your passport or bank details. This email has the hallmarks of a known scam, so I haven't built a full prep pack around this "interview".**

**Why it looks like a scam**
- **A fee before the interview.** Real employers don't charge candidates for "equipment registration". The IBAN belongs to a "supplier", not the company.
- **The cheque-and-balance trick.** You'd deposit a €1,850 cheque and send the "balance" to a vendor. The cheque will eventually bounce, and the money you sent will be gone. The bank will hold you responsible for it, not the sender.
- **Passport and bank details before any interview.** Real employers collect these after an offer, through a proper HR process. With these details someone can commit identity fraud or open accounts in your name.
- **Hiring by email only.** A "remote" job with a 30-minute video call, no named interviewer and a generic `hr@` address fits the pattern.
- **Questions to check.** Did you apply to Brennock directly, or did they find your CV on a job board? Does a company called Brennock Facilities Ltd appear in the Irish Companies Registration Office (CRO) register, with a website and phone number you can verify independently?

**What to do**
1. Don't reply, pay or send documents.
2. If you already sent anything, contact your bank now. If you sent your passport, tell the Garda National Economic Crime Bureau and consider an ID-fraud alert.
3. Report the email to An Garda Síochána and to the job board where you found the ad.

**Prep for a real admin assistant interview**
You'll find this useful for a genuine application, or if Brennock turns out to be real and drops the payment demands. This is generic role guidance plus what you told me. It isn't the full pack.

- **What to expect.** A real interview for this role covers calendars, travel booking, Word and Excel, and supplier invoices. Expect questions on prioritising, handling conflicting requests, accuracy, and working independently when remote.
- **Your strongest material.** Your appointment-book experience maps directly onto calendars for four people. Your invoice chasing maps onto supplier invoices, though that was the receivables side rather than payables. Say so plainly and don't claim more.
- **Your likely gap is Excel.** Prepare a short, honest answer of the form "I use it for X, and I'm building up Y". Practise pivot tables, `VLOOKUP`/`XLOOKUP` and basic invoice-tracking sheets before you go.
- **Questions to rehearse.** Use your own examples for these:
  - How do you handle double-bookings or a physio running late?
  - Tell me about a difficult unpaid invoice.
  - How do you prioritise when four people want you at once?
  - What would you do if you spotted a mistake in an invoice?
  - Why remote work, and how do you stay organised without supervision?
- **Questions to ask them.** What does a typical week look like? Who would I support? How are invoices approved and paid? Which systems do you use?

If you can verify a real employer, or have a genuine application, send me the real job description and your CV. I'll build the full pack with question banks, fit map and reverse questions.

Three questions would shape it:
1. Is there a different, verified application you want prepped?
2. Can you paste your CV?
3. Do you know who the interviewer would be and what their role is?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.