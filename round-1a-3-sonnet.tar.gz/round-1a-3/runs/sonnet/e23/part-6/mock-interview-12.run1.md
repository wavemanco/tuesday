Please don't pay anything or send anything yet. This email has the hallmarks of a fake-cheque scam, so I haven't built the prep pack. A pack would assume the interview is real, and I don't think it is.

**Red flags in the email**
- **Fee to interview.** A real employer never charges a candidate a "€95 equipment registration fee" before an interview. Your slot isn't "confirmed" until you pay.
- **Passport photo and bank details before any interview.** There's no legitimate reason to need these at this stage. They're what someone needs to steal your identity or use your account.
- **The €1,850 cheque.** You deposit it, then send the balance to a "vendor". The cheque will bounce days or weeks later, after the bank has let you withdraw against it. The money you sent on is real, and you'd owe the bank. This is the core of the scam.
- **Smaller signs.** The payment goes to a "supplier's" account rather than the company's. The email contacts you first, and the pay-first order is backwards. The contact address is `hr@brennock.example`. I can't verify the company either way, but a real one would let you check it independently.

**What to do now**
1. **Don't pay, reply with documents, or deposit any cheque.** If you've already sent anything, call your bank straight away and ask them to flag or stop it.
2. **Check the company on your own.** Look up Brennock Facilities Ltd in the Irish Companies Registration Office (CRO) register. Phone the number on their official site, not one from the email. Check whether the job is posted anywhere they control.
3. **Report it.** Forward the email to your bank's fraud team and report it to An Garda Síochána. The Competition and Consumer Protection Commission (CCPC) also takes consumer-fraud reports.
4. **Reply only if you want to test it.** A short message saying you'll confirm the interview first and send nothing beforehand will usually end the conversation if it's a scam. You don't owe them a reply, though.

**Your own prep**
Your background is a good fit for the work in the ad. You ran an appointment book for four physios, which is calendar management. You chased unpaid invoices, which is close to supplier invoices. You're good with Word and okay with Excel. Those are real strengths for admin roles.

When you have a verified interview, send me the job description, who's interviewing you, and the round type. I'll build the full prep pack then, with likely questions, answers drawn from your clinic experience, and a plan for the Excel gap. If you'd rather practise now for admin interviews in general, tell me and I'll run it on that basis.