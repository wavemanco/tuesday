**Please don't pay, send documents or deposit anything. This email has the hallmarks of a fake-cheque scam, so I haven't built a prep pack for this "interview".**

**Why it looks like a scam**
- **Upfront fee:** a genuine employer never charges you a "registration fee" to interview. Here it goes to a "supplier's account" before your slot is even confirmed.
- **Passport photo and bank details before any interview:** real employers collect these only after a written offer, through a proper onboarding process. They are what a fraudster needs for identity theft or to empty your account.
- **The cheque:** you'd receive €1,850, deposit it, and send the "balance" to a vendor. The cheque will eventually bounce, and the bank will take the money back from you after you've already sent real money out. A cheque appearing in your account doesn't mean it has cleared.
- **The process doesn't match the job:** a "video interview with the office manager" is attached to a hiring process that never mentions the role, the team or who you'd work for.
- **No verifiable details:** I can't confirm anything about "Brennock Facilities Ltd". The `.example` email domain suggests the sender has no real company domain.

**What to do**
1. Don't reply, pay or send your passport or bank details.
2. If you've already sent anything, call your bank now. Ask them to stop or recall the payment and to flag your account. Report it to An Garda Síochána. If you sent passport details, watch for identity misuse.
3. Check the company yourself. Look it up in the Companies Registration Office (CRO) register and find its website independently, rather than through the email. Phone a number you found yourself.
4. Report the email to the job board where you applied, so they can remove the listing.

If the company turns out to be real and contacts you through a verified channel, a genuine employer will happily interview you without taking money or ID.

**Real interviews for this kind of role**
Your background fits an admin assistant role well. Expect questions like these:
- Walk me through how you managed four physios' diaries. How did you handle double-bookings, cancellations and urgent squeeze-ins?
- Tell me about chasing unpaid invoices. What was your approach, and what was the result?
- How comfortable are you with Excel? Be honest that you're "okay", and be ready for a short test on things like formulas, filtering and basic formatting.
- How do you prioritise when several people need something at once?
- Have you booked travel or handled supplier invoices? If not, which of your clinic tasks is closest?

If you'd like, I can build a full prep pack for a legitimate admin role. Send me a real job description or a company you've verified, plus your CV if you have one. I can also run a live practice interview where I play the office manager.