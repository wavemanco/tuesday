I'll load the skill. First, though, the email has serious red flags, and I'll cover them in the prep.
**Don't pay, and don't send your passport or bank details. This email has the hallmarks of a fake-cheque (overpayment) scam, so I haven't built an interview pack for it.**

**Why it looks like a scam**
- **Upfront fee.** A real employer never asks a candidate to pay a "registration fee" for equipment or anything else. The €95 is the bait, and it goes to an account you can't trace.
- **The cheque.** They'd send €1,850 and ask you to forward "the balance" to a vendor. The cheque will bounce days or weeks after your bank shows the funds. By then you've sent real money, the bank takes the cheque amount back from you, and you're out the full amount.
- **ID and bank details.** Asking for a passport photo and your bank details before any interview is identity-theft harvesting. A real employer asks for these only after a signed offer, through a proper HR system.
- **Everything else.** The interview slot is held back until you pay. The "supplier's account" is a third party. The email is urgent and offers a lot for little. And the interview is only a 30-minute video call with an "office manager", with no named person.

**What to do now**
1. Send nothing: no money, no receipt, no documents.
2. If you've already sent the passport photo or bank details, call your bank, tell them, and ask about monitoring or changing your account. For the passport, report it to the Gardaí or your national passport authority.
3. Check whether Brennock Facilities Ltd is a registered company (the CRO in Ireland) and whether the contact details match. Don't use the contact details in the email.
4. Report it to the Gardaí (Garda National Economic Crime Bureau), and to the job board where you saw the ad.
5. Don't reply to the sender. If you want to test it, ask for a video call with a named person before any payment. A scammer will stall or pressure you.

**Your background is a good fit for a genuine remote admin role.** Two years running a four-physio appointment book is calendar management. Chasing unpaid invoices is close to supplier-invoice processing. Word is solid, and Excel is the gap to prepare for.

If you find a real posting, I can build you a full interview prep pack with questions, answer guidance based on your own words, and a live practice round. To do that I'd need:
1. The company and the job ad, once you have a verified one.
2. Who the interview is with, and what stage it is.
3. Whether you want me to research the company. I'll only ask for that once there's a real employer to look up.

Want me to build a general admin-role prep pack from your background in the meantime? It would cover calendars, travel, Excel and invoices.