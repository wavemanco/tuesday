I've read the skill's reference files and am now running the first round of research on the district and school. I'm not sending anything from your resume.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/e23/part-3/rooms/case-9-canned-38822cff/halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 20 questions across seven interviewer styles, built for one 45-minute panel with the principal and two fourth-grade teachers. It rests on your résumé, the invite and the district's own pages. I didn't have the job posting.

- **Biggest risk:** the most likely objection is that you've never taught fourth grade. Question A1 is the one to rehearse first. G2 and A3 rehearse the next likeliest pressure points.
- **Where answers are yours to give:** your résumé doesn't show some things the panel is likely to ask about, such as how you plan for individual readers or whether you talk with families beyond the weekly email. The pack leaves those as answer slots. Say what's true, or say plainly it wasn't your practice.
- **Your Social Security number:** I didn't use it and it isn't in the pack. It isn't needed for interview prep, so take it off any copy of the résumé you share.

Say the word and I'll play the principal on A1, with follow-ups that react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did HR say anything beyond the invite, such as a sample lesson to prepare or focus areas? A deliverable would get its own build section.
Can you paste the posting? Without it the requirement rows rest on the invite and the district's pages.
Do you want a deeper research pass, with up to 6 more searches and 2 more fetches and several more minutes? It would sharpen the questions about the district's new literacy plan.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

- **Employer:** Halvering Elementary School, Orrinsford Community School District
- **Round:** one 45-minute panel on Thursday, per the invite
- **Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
- **Built on:** the invite, the résumé text you pasted, and the district's own published pages. No job posting was supplied, so JD-style rows are labeled accordingly.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Every question carries a type tag, a provenance label with the exact sentences of yours its guidance rests on, guidance, and a rationale.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether what your résumé says survives follow-up, and what was actually you |
| JD | The stated role and its requirements, gaps included |
| CO | Whether you know the district's current direction |
| CASE | A live problem from the actual job, scored on structure and reasoning |

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview, not a question for you now: say what is true in your own words, and where the slot's second branch applies, say so plainly and go back to what your own sentences carry. Saying a practice was not yours, or never existed, is a complete answer.

## Fit snapshot

The invite names one hard requirement and a title. The district's pages add the topics the panel asks about and three published beliefs. No posting was supplied, so row F6 rests on a representative posting and is labeled `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate, and your material shows it met. Words stay in the quote's terms: the license, the endorsement and its grades 1–6 range, the date it is active through. Expect a verification step; the registry record is the inspectable artifact, and this pack has not inspected it |
| F2 | "Fourth Grade Teacher position" — the invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | medium | [grounded] | transferability | Your material carries third grade at its own scope and a negative you stated. Words: "For six years I taught third grade at a public elementary school in Joliet." Plain acknowledgment: "I've never taught fourth grade." Answer slot: the invite names a fourth-grade role, so expect a probe on what changes between third and fourth. If you have seen differences from your own classroom, say what you saw, in your own words; if you have not, say so plainly and say what you would ask the fourth-grade team first |
| F3 | "reading instruction" — the district's How we hire teachers page ("Panels ask about reading instruction, classroom routines and how you work with families.") | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | Both sentences touch reading without showing your day-to-day instruction. Answer slot: the district's published belief is "Every Child a Reader: no student leaves third grade without a reading plan", so expect a probe on how you plan for individual readers. If you have made such plans, say how, in your own words; if not, or it was not your practice, say so plainly and stay with the move and the club |
| F4 | "classroom routines" — the district's How we hire teachers page | none given | none | [grounded] | discovery | Your material does not speak to routines. Nothing in your inputs or the district's published beliefs raises a specific probe, so no slot is written and no words are offered about your history. C2 rehearses it as a live problem that asks about no past |
| F5 | "Families Are Partners: each teacher speaks with every family each term" — the district's Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The sentence carries a weekly email at its own scope. Words: "I write a weekly email to families." Answer slot: the belief is about speaking with every family each term, so expect a probe on conversations beyond the email. If you have spoken with families directly, say how often and in what setting, in your own words; if not, say so plainly and stay with the weekly email |
| F6 | Work with the grade-level team (plain prose from a representative fourth-grade posting seen as a search result, not fetched) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | transferability | Your material carries a grade-level move at its own scope and a negative you stated. Words: "I led our grade level's move to a new reading curriculum in 2024." Plain acknowledgment: "I've never been a team lead." No slot: the requirement is this pack's derivation from a representative posting, which raises none |

## Reading the interviewer

Public professional footprint only. Nothing is available on the two fourth-grade team members, so they get no read.

| Public fact (quoted) | Source | Practical implication |
|---|---|---|
| "has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist" | Illinois principals forum speaker page | Reading is her home ground, so expect the reading questions to be the ones with follow-ups. F3 is where your material is least specific |
| "Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5" | Illinois principals forum speaker page | Her topic spans third through fifth grade, which includes the grade you taught (F2). If reading conferences come up, answer from what you actually do and say plainly where something is not your practice |

**Mirror opportunity, a shared domain and not a shared career jump:** her public work is reading in grades 3 to 5. Your side is one sentence from F3's evidence, offered at its own scope: "I've run the after-school reading club for the last two years." Do not borrow her vocabulary for it. A reverse question tied to her path is R1.

## Persona table

The loop is documented: the district's hiring page describes one 45-minute building panel of the principal and two grade-level teachers, and your invite matches it. A panel blends the top two personas of each member's relationship. The principal reads as a hiring-manager relationship; the two teachers read as peers. No values-style round is documented, so the Values weight rests on the panel's stated topics and the three published beliefs, not on a separate round.

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | The principal probing the grade you have not taught and the leadership you have not held | High. Hiring-manager prior; F2 and F6 carry stated negatives, and the principal's reading background makes the third-to-fourth step a natural focus | Rehearse A1 until it is boring. Use only your own sentences, with the limits said plainly and a plan said as a plan |
| Peer Evaluator (bank B) | The two fourth-grade teachers asking about working beside them | High. Two of three panelists are peers; their view is whether you reduce or add to their load | Reciprocity first: what you bring them, then what you would ask of them. Disagreement and credit stories only where a sentence of yours carries them |
| Case/Strategist (bank C) | Live problems on reading, routines and the district's literacy plan | Medium. Hiring-manager prior, and the hiring page lists reading instruction and routines as panel topics | Clarify, objective, approach, checks, risks; think aloud and challenge one premise respectfully |
| Values/Behavioral (bank D) | Open prompts built on the three published beliefs | Medium. Families is a stated panel topic and the beliefs are published, but no values round is documented | Map a story where one of your sentences carries it; where none does, use the scaffold and its honest branch |
| Conversational (bank E) | A friendly opener and the license check | Medium-low. Panels open softly, but a documented 45-minute loop leaves little room | A 90-second arc built only from your own sentences |
| Data-Driven Prober (bank F) | A teacher asking how you know the club or a curriculum is working | Medium-low. Your résumé gives no figures to probe, so probes go at method and evidence | Say plainly what you know and do not know; name the assumption you would defend least |
| Pressure (bank G) | A time-boxed challenge to your fit for fourth grade | Low. Nothing documented suggests a stress style | Pause, restate, hold two follow-ups, concede specifically |

## Question banks

Twenty questions, ordered by persona weight.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What changes at fourth grade, and what would you do about it?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | **The highest-ROI prep in this pack.** Concede first, in the sentence you stated: "I've never taught fourth grade." Then hold only what the quote carries: "For six years I taught third grade at a public elementary school in Joliet." Follow-up one, what changes: answer slot. If you have seen differences from your own classroom, say what you saw, in your own words; if you have not, say so plainly and say what you would ask the fourth-grade team first. Follow-up two, why you: return to those two sentences and stop; let the panel draw the inference. Follow-up three, your first month: say it as a plan in the future tense, never as a past. The limit, named before it is asked: your material says third grade, not fourth, and the hold goes no wider | F2 is the most predictable objection to this candidate, in some form from at least one of the three panelists. JD because it scores the stated role, Skeptic because it goes at the gap |
| A2 | "Which part of this job would be hardest for you on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead" | Choose one limit from your own two sentences and say it plainly: "I've never taught fourth grade" or "I've never been a team lead." Then say how you would learn it, as a plan. Pick the one you can speak to most concretely | The standard Skeptic stem, aimed at F2 and F6, the two places your material states a limit |
| A3 | "You led your grade level's move to a new curriculum, but you've never been a team lead. How do those fit together?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say both sentences as they stand and do not reconcile them with a story your material does not carry: "I led our grade level's move to a new reading curriculum in 2024." "I've never been a team lead." If asked what leading covered, say in your own words which parts were yours and which belonged to others; if it was narrower than the question assumes, say so plainly and return to the sentence. Hold the first sentence through two follow-ups without enlarging it | F6 holds both sentences, and the seam between them is where a careful panelist presses. EXP because it tests attribution of a stated lead |
| A4 | "Why fourth grade, and why now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | The answer has to be yours: name one specific draw to this grade and this district that is true for you, with your six years of third grade in the sentence. The district's published beliefs are a source of themes only where one genuinely is. If no specific draw comes to mind, say so plainly, then say what you want to find out about the grade | Motivation consistency, the Skeptic's second line after F2. No sentence of yours carries a reason, so the guidance is a scaffold |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you disagreed with a grade-level colleague." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pick a disagreement where you held a view and the working relationship was intact afterwards; name the stake, your part and what the other person did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I led our grade level's move to a new reading curriculum in 2024", told at that scope without adding a disagreement it does not mention, or say how you would handle one | The peer stem on disagreement; F6 is the only row with a grade-level sentence. VAL because it scores working-with-equals behavior |
| B2 | "How do you handle credit when a result belongs to the whole grade level?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for the group and "I" for your part, and the sentence you can stand on is "I led our grade level's move to a new reading curriculum in 2024." Name your colleagues' part in your own words. If your part was narrower than that sentence suggests, say so plainly | Peer panelists price credit-sharing; F6's sentence is the one place it is tested. VAL for the behavior, EXP-adjacent for the attribution |
| B3 | "Walk us through how your grade level moved to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the sentence's own beats: the grade level's move, the new reading curriculum, 2024, and that you led it. Tell them in your own words and stop where the sentence stops. Answer slot: the district's published belief that "assessments inform teaching and never replace it" makes a probe on how you checked the move was working likely. If you used assessment results, say how, in your own words; if you did not, or it was not yours to do, say so plainly and return to the move | F3 and F6 both draw on this sentence, and a teacher who has lived a curriculum change will ask for its details. EXP because it tests what was actually yours |
| B4 | "What would you need from us in your first month, and what would you bring us?" | CASE | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | Reciprocity first: lead with what you bring, from your own sentences at their scope, then what you would ask. Ask things the team can answer, such as how routines run and what the team already knows about the new curriculum. Offer principles for sharing work, not claims about their seam | The peer reciprocity probe. CASE because it is a live scenario about the role; F2 and F3 supply the two sentences it may use |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "In October a fourth grader is reading well below the class. What do you do first?" | CASE | [grounded] | Clarify before you structure: reading well below by what measure, and does a reading plan from third grade exist, given the district's belief that no student leaves third grade without one. Then objective, a small set of next steps, how you would check it is working (assessments inform teaching and never replace it), and what would make you change course. Think aloud; challenge one premise respectfully. It asks about no past, and the guidance makes no claim about yours | Reading instruction is a documented panel topic (F3), and the principal's reading background suggests a live reading problem. CASE with JD content |
| C2 | "Walk us through the routines you would set up in the first two weeks with a new class." | CASE | [generic] | A pattern, not a story: what students must be able to do on their own for the day to run, how you would teach each routine, how you would check it is holding, how you would adjust. Keep it to what you would do, as a plan, and ask which routines the team already shares | F4 is the row with no evidence, and routines are a documented panel topic, so this is rehearsed as a live problem. `[generic]` because it is a pattern for the problem, not a fact about this district |
| C3 | "The board adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027. What would you want to know before you teach under it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Anchor in your own sentence at its scope, "I led our grade level's move to a new reading curriculum in 2024", then think aloud: what the curriculum covers in fourth grade, what training and time the team gets, how assessments will be used, how families will hear about it. The district news item also mentions a family reading night each term. Challenge one premise respectfully. Do not say what your own move taught you unless you can say it in your own words | The one CO question, from the district's August 2026 news item; F6 supplies your sentence. CO because it tests whether you know where the district is heading |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you made sure a child had a plan for becoming a reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Pick a time a specific child's reading needed a plan: what you noticed, what you did, what followed, with no identifying details. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years", at that scope, or say how you would handle it | The first published belief, Every Child a Reader, asks for a reading plan; F3 supplies the one sentence nearby. VAL because it scores behavior against a named belief |
| D2 | "Tell me about how you work with families." | VAL | [grounded] "I write a weekly email to families" | Story-mapped on the sentence's beats: weekly, an email, to families. Answer slot: the belief is that each teacher speaks with every family each term, so expect a probe on conversations beyond the email. If you have spoken with families directly, say how often and in what setting, in your own words; if not, say so plainly and stay with the weekly email | Families is a stated panel topic and a published belief; F5 is the row. VAL because the belief, not the email, is what is scored |
| D3 | "Tell me about a time assessment results changed what you did in class." | VAL | [grounded] | Pick a time a result changed a plan: the result, what you changed, what you saw afterwards. If none comes to mind, say so plainly; your material has no sentence on assessment, so there is no nearest sentence to offer. Say instead how you would use results to adjust teaching and never to replace it | The third published belief, Teach for Tomorrow, Not for the Test, puts assessment on the panel's agenda; F3 has no assessment sentence, so the guidance is a scaffold |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your journey, and how you came to this application." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc in that order, in your own words, using only those four sentences at their own scope, closing on your own reason for this role. No sentence of yours carries the reason, so it is yours to say | Panels open soft and the opener is scored. F2, F3, F5 and F6 supply the sentences, which makes this the arc to rehearse most often |
| E2 | "Tell us about your license and endorsement." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | One sentence at its own scope: your Illinois Professional Educator License, the Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. Then stop; the invite makes the license a condition, so a plain answer is the whole answer. Keep the registry record to hand in case you are asked to show it | F1, the one hard requirement the invite states. JD because it scores a stated requirement |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Story-mapped on the sentence's beats: the club, after school, the last two years, and that you run it. Answer slot: the district's belief that assessments inform teaching makes a probe on how you know the club is working likely. If you have a way you tell, say what it is, in your own words; if you have none, say so plainly and say what you would look at | F3 holds this sentence, and a prober reads résumé lines one by one. EXP because it tests what the club actually is |
| F2 | "How would you know whether a reading curriculum is working?" | CASE | [grounded] | Structure it: what working means for readers, what you would look at, what you would ask students and families, the assumption you would defend least, and what would change your mind. Keep to the district's own line that assessments inform teaching and never replace it. It asks about no past, and the guidance makes no claim about yours | Your résumé has no figures to probe, so the prober goes at method; F3 is the row. CASE because it is a live method problem |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade" | Pause and restate the question. Hold only two sentences: "For six years I taught third grade at a public elementary school in Joliet" and "I led our grade level's move to a new reading curriculum in 2024." Concede in your own stated sentence: "I've never taught fourth grade." Do not compare yourself with other candidates, because you cannot see their material. Hold through two follow-ups by repeating, not adding | A time-boxed version of A1; F2 and F6 supply the sentences. JD content, Pressure delivery |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold the sentence: "I led our grade level's move to a new reading curriculum in 2024." Concede specifically, in your own words, which parts were yours and which belonged to others, and if leading covered less than the question assumes, say so plainly. Never fold the core sentence to restore harmony; on the second follow-up, repeat it rather than enlarge it. If the leadership seam comes up, "I've never been a team lead" is already stated | The standard attribution probe, aimed at F6's sentence and the likeliest follow-up to A3. EXP because it tests what was actually yours |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1, the license and endorsement | E2 |
| F2, fourth grade | A1, A2, A4, G1 |
| F3, reading instruction | B3, C1, C3, D1, D3, F1, F2 |
| F4, classroom routines | C2 (no evidence of yours; rehearsed as a live problem) |
| F5, families | D2 |
| F6, grade-level team | A3, B1, B2, B3, B4, G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your talk Small Groups, Big Readers you described weekly reading conferences in grades 3 to 5. What does that look like on a fourth-grade team here, day to day?" | Tied to the principal's own public work and path, so it turns the panel into a conversation about reading. Ask it as a question, not as a claim about your own practice |
| R2 | "No student leaves third grade here without a reading plan. How do fourth-grade teachers receive and use those plans in the fall?" | Shows you read the published belief, and it asks about the very transition your material is thinnest on |
| R3 | "The literacy plan brings a new reading curriculum to grades 3 to 5. Where is the team in preparing for it, and what would be most useful from a new colleague?" | Shows current awareness and offers help before asking for it |
| R4 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two peers on the panel |
| R5 | "The beliefs say each teacher speaks with every family each term. How does the team approach that, and how do you share the load?" | Takes your own family-communication sentence into the district's practice without claiming more of it |
| R6 | "How does the fourth-grade team share leadership across the year, and how could someone new take on a part of it?" | Opens the leadership seam on your terms, without describing what you have not done |

## Prohibited claims

What this pack will not coach, and why. These were built before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | The plain acknowledgment: "I've never taught fourth grade." A1's slot asks only what you have seen from your own classroom |
| Has been a team lead | A negative you stated, F6 | The plain acknowledgment: "I've never been a team lead." A3 holds the sentence about the move and goes no wider |
| Chose or designed the new reading curriculum | Inflated form of the F6 and F3 sentence | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is this pack's observation: your material says the move, not who chose the curriculum |
| Runs small-group reading conferences | Inflated form of the F3 club sentence, and the topic of the principal's talk | The quote at its own scope: "I've run the after-school reading club for the last two years." The limit is this pack's observation: your material says the club, not a conference practice |
| Speaks with every family each term | Inflated form of the F5 sentence, widened by the district's belief | The quote at its own scope: "I write a weekly email to families." The limit is this pack's observation: your material says a weekly email, not conversations |

## Sources

**Provided documents:** the interview invite from Human Resources, Orrinsford Community School District; the résumé text you pasted. A government identifier appears in the pasted résumé; it is not needed for interview prep and was not used.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Fetched the district's Mission and Beliefs page: three beliefs by name (Every Child a Reader; Families Are Partners; Teach for Tomorrow, Not for the Test). Fed rows F3 and F5 and banks C and D as published-values sources |
| 2. `{company} interview process {role family}` | yes | Fetched the district's How we hire teachers page: one 45-minute building panel, the principal plus two grade-level teachers, topics reading instruction, classroom routines and families. It establishes the loop, so persona weights follow it. It names no values round, so no values cheat sheet is included |
| 3. `{company} strategy` / recent news | yes | The search result on the board's literacy plan fed C3 and R3. It came from the search result only, not a fetched page, and it raised no answer slot |
| 4. `{interviewer name} {company}` | yes | The principals forum speaker page fed the interviewer read and R1 |
| 5. representative `{role title}` JD | yes | A representative fourth-grade posting came back as a search result only, with its qualifications cut off. It fed only F6's requirement, labeled `[inferred]`, with no quotation and no slot |

**Searches sent, by query:**

- "Orrinsford Community School District values mission" → https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel" → https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Halvering Elementary School Orrinsford district strategic plan news" → https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary" → https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Illinois fourth grade teacher job posting elementary PEL requirements" → https://k12jobsboard.example/listings/fourth-grade-teacher

**Pages fetched:** the mission-and-beliefs page and the how-we-hire-teachers page above.

## Upgrade menu

- The posting text itself → F6 and the JD-tagged questions become `[grounded]` rows, and any requirement the posting lists that this pack has not seen gets its own row and question
- Anything HR said about format, such as a sample lesson or focus areas → a build section for any deliverable they declared, and sharper persona weights
- The names of the two fourth-grade team members → an interviewer read for each and per-member persona weights from their public footprint
- Your answers to the slots in A1, F2, F3 and F5 → they become quoted evidence and regenerate those rows and the questions that rest on them
- A copy of one weekly family email, or a description of the reading club → F3 and F5 move from `medium` toward `high`, since an inspectable artifact is what raises the band
- The educator license registry record for your license → F1 moves from `medium` toward `high`
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the district's literacy plan and recent context, and less generic CO and CASE questions
- A `tuesday-dossier.md` from the job-underwriter, if you have one → a verified-evidence list and sourced prohibited claims; not needed for this pack
