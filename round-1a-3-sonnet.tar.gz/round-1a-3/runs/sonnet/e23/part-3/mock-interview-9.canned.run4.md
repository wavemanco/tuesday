Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 20 questions across six interviewer styles, a fit snapshot, a requirement-coverage table, a persona table, six reverse questions and a list of claims it won't coach. I left your SSN out of the pack and out of every search. Interview prep doesn't need it, and you may want it off any resume you send out.

I assumed one panel with no pre-announced deliverable, and I had no posting text. A typical fourth-grade posting stood in for the posting-based rows, and the pack labels them `[inferred]`.

The district's published beliefs and hiring page shaped the pack. The beliefs are Every Child a Reader, Families Are Partners and Teach for Tomorrow, Not for the Test. The hiring page says the panel asks about reading instruction, classroom routines and families. The principal's background as a reading specialist points the same way. The question to rehearse hardest is A1, "You've taught third grade, so what makes you ready for fourth?" You said you've never taught fourth grade. The pack coaches you to say that plainly, hold on your six years of third grade, and give a ramp plan.

Say the word and I'll play the principal on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did HR say anything about a sample lesson, writing sample or anything else to bring? If so, I'll add a build section for it.
Can you paste the full job posting? It would turn the `[inferred]` rows into `[grounded]` ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Interviewers: Principal Dolores Vantongeren plus two members of the fourth-grade team (names not given). Relationship: a principal (hiring-manager role) and two prospective peers. Candidate: Grace.

Built on this assumption: one panel, no pre-declared deliverable, and no posting text supplied, so the posting-derived rows come from a typical posting and are labeled `[inferred]`.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral / values alignment: does past behavior show the district's published beliefs |
| EXP | Work-experience deep-dive: do your own claims survive a follow-up |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company knowledge: do you know this district and its current plans |
| CASE | Live problem from the role: structure and reasoning |

Guidance is scaffolding, not a script. Every sentence about your past in this pack is one you wrote, quoted; where the pack does not know something, it leaves an answer slot for you to fill in your own words, or to say plainly that it did not happen or was not yours. The single highest-ROI rehearsal is A1.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met. It is a CV line with nothing inspected behind it, so have your license details to hand. Say it in the quote's own terms: the PEL with the Elementary Education endorsement, active through June 30, 2029 |
| F2 | "Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "reading instruction" — Orrinsford hiring page | "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your material says a curriculum move and a club, not day-to-day reading instruction, and the words stay there. Answer slot: the district's Every Child a Reader belief ("no student leaves third grade without a reading plan") makes a probe on supporting an individual child's reading likely. If you worked on a child's reading plan, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the move and the club |
| F4 | "how you work with families" — Orrinsford hiring page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The email is the quote's whole scope. The district's Families Are Partners belief says "each teacher speaks with every family each term". Answer slot: if you have spoken with families directly, say when and how, in your own words; if not, or it was not yours, say so plainly and stay with the weekly email |
| F5 | "assessments inform teaching and never replace it" — Orrinsford mission and beliefs page | none given | none | [grounded] | discovery | The material is silent on this. Answer slot: expect a probe on how you check how students are doing. If results changed what you did next, say what you looked at and what you changed, in your own words; if that was not part of your work, say so plainly and say what you would want to look at first |
| F6 | "work with the grade-level team" — K12 Jobs Board typical posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | none | Lead with the move in the quote's own terms. Limit, as the pack's observation: your message says you have never been a team lead, so "led" stays on the move and does not travel to the team |
| F7 | "classroom routines" — Orrinsford hiring page | none given | none | [grounded] | discovery | The material is silent on this. Answer slot: expect a probe on the routines you set. If you set routines for your class, say which and why, in your own words; if they were set by someone else, or you had none, say so plainly and say what you would want in place first |
| F8 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board typical posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | The sentence says the grade and the years, not which subjects. Answer slot: say which of those subjects were yours to teach, in your own words; if some were taught by others, say so plainly and stay with the sentence |

## Reading the interviewer

| Fact | Provenance | What it means for you |
|---|---|---|
| Dolores Vantongeren has been principal of Halvering Elementary since 2022, after nine years as a reading specialist | [grounded] | Reading-instruction probes from her are likely to be specific. Describe reading work exactly as you did it; she will recognize padding |
| Her 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | [grounded] | Mirror opportunity: your reading work sits in her territory. Use F3's sentence, "I've run the after-school reading club for the last two years.", at its scope. Do not claim a practice her talk describes unless you did it |
| The two fourth-grade team members are unnamed | [grounded] | No read on them. Treat them as Peer Evaluators; the upgrade menu says what names would add |

Public footprint only; nothing beyond roles and a published talk was used.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal probing fourth grade and team leadership | High: F2 is a gap you stated, and a principal buying capability derisks gaps first | Rehearse A1 until it is boring; plain acknowledgment, then the third-grade sentence, then a ramp plan |
| Peer Evaluator | The two fourth-grade teachers: what you would need, what you would add | High: the invite names two members of the fourth-grade team, and peers price what a hire costs their work | Reciprocity framing; seam principles, not claims about their routines |
| Case/Strategist | Live problems on reading, routines and the 2027 curriculum | High: the hiring page says panels ask about reading, routines and families, and the principal's background is reading | Clarify, objective, approach, how you would know, risks; think aloud |
| Values/Behavioral | Stories against the three published beliefs | Medium: the beliefs are published, but no values-style round is detected as defined (the hiring page names reading, routines and families), so beliefs theme questions without a cheat sheet | Story where one of your sentences carries it; otherwise a selection and the honest branch |
| Conversational | Opener and close | Medium: any panel opens warmly, and those answers are still scored | A 90-second arc built only from your own sentences |
| Prober | Attribution follow-ups on the move and the email | Low: your CV has no figures to defend, so probes arrive as "which parts were yours" | Say exactly what was yours; say plainly when you cannot separate it |
| Pressure | Not included | No source shows a stress format; the hiring page describes one panel on reading, routines and families | A5 carries the one pressure-shaped question |

Loop: one 45-minute panel of the principal and two grade-level teachers, per the district hiring page and your invite; references follow after the panel, per the hiring page.

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license gate | none, and why: a term your material shows met, so nothing to rehearse beyond having the details ready |
| F2 fourth grade | A1, A2, A3, A5, B1 |
| F3 reading instruction | B4, C1, C2, D1 |
| F4 families | D2, F2 |
| F5 assessment | C4, D3 |
| F6 grade-level team | A2, B1, B2, B3, F1 |
| F7 classroom routines | C3 |
| F8 subjects | E2 |
| Beliefs: Every Child a Reader | D1, C1 |
| Beliefs: Families Are Partners | D2 |
| Beliefs: Teach for Tomorrow, Not for the Test | D3, C4 |

## Question banks

### A. Skeptic (principal and team), highest weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What makes you ready to teach fourth?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | The highest-ROI rehearsal in this pack. Say the plain acknowledgment first: "I haven't taught fourth grade." Then hold on what the quote carries: "Six years teaching third grade at a public elementary school in Joliet." Then a ramp plan, spoken as a plan and never as a past: what you would ask the fourth-grade team and what you would want to see in your first weeks. Follow-up one, on what differs between the grades: say what you would want to find out and from whom, and do not describe differences you have not taught. Follow-up two, on whether students would be where you learn: concede the limit specifically, that you have not taught the grade, then return to the six years and add nothing to either. Answer slot: if any of your work has touched fourth-grade students or content, say what it was, in your own words; if none has, say so plainly and stay with the third-grade sentence | F2 is the stated gap and the objection this panel is most likely to raise in some form; JD because it scores the title itself, delivered in the principal's Skeptic register |
| A2 | "Have you ever been a team lead?" | JD | [grounded] "I've never been a team lead." — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer plainly: "I haven't been a team lead." Then what your material carries, at its scope: "I led our grade level's move to a new reading curriculum in 2024." Keep "led" on the move; it does not become the team or the grade level. Answer slot: a typical posting lists working with the grade-level team, so expect a probe on your part in the move. Say which part was yours to decide and which was decided elsewhere, in your own words; if the move was set by someone else, or your part was small, say so plainly and stay with the sentence | F6 against the stated negative; a prober-friendly question in a skeptic's mouth, so JD |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" — your message; "I've never been a team lead." — your message | Pick the weakness your own material states, either "I haven't taught fourth grade" or "I haven't been a team lead", say it in one sentence, and give a first step as a plan: who you would ask and what you would look at first. Choose the one you can attach a concrete first step to. If a different weakness is truer, say that one plainly instead. If no weakness comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 again in the persona's own stem; JD because it scores honest self-assessment against the listed job |
| A4 | "Why are you leaving your school after six years, and why Halvering?" | CO | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | A selection scaffold: the material gives no reason for the move, so the reason has to be yours. One true sentence on what you are moving toward, then the district beliefs that really connect for you, by their published names: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Name only the ones that are true for you. Do not criticize your current school. If no reason comes to mind beyond the opening existing, say so plainly, then give the nearest honest reason you do have | The standard why-leave-why-here probe; CO because the answer is scored on knowledge of this district |
| A5 | "Why should we choose you over someone who has already taught fourth grade?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV; "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've run the after-school reading club for the last two years." — your CV; "I write a weekly email to families." — your CV; "I've never taught fourth grade" — your message | Hold, using only your own sentences at their scope: the PEL with the Elementary Education endorsement, the six years of third grade, the reading club you run, the weekly email to families. Say them as what you bring, not as a comparison with someone you have not met. Hold through two follow-ups by repeating what you bring, never by adding to it. On the second, concede the one thing they can name that you cannot: "I haven't taught fourth grade." Never claim to be the stronger candidate | The pressure-shaped question in a panel that otherwise will not apply it; F2 is the premise, and the hold uses only quoted rows |

### B. Peer Evaluator (two fourth-grade teachers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from our team in your first month, and what would you bring to it?" | JD | [grounded] "I've never taught fourth grade" — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | Two halves, in reciprocity order. What you bring: the move and the club, each at its quote's scope. What you need: "I haven't taught fourth grade," then the principles you would ask about, such as how the team works together and what your first weeks should look like, rather than claims about their routines. Propose seam principles instead of pretending to know their seam | F2 and F6 in the peer's register: the peers price what you cost and add to their load |
| B2 | "Tell us about a time you disagreed with a teammate about how to teach something." | VAL | [generic] | A selection scaffold: pick a disagreement with a named stake, what you said, what happened to the working relationship, and what it meant for the children; it should show spine and tact together. If no such time comes to mind, say so plainly, then give how you would handle one. The question needs no claim about your past, so the guidance makes none | F6 as a collegial disagreement story; the stem comes from the Peer Evaluator persona, so it is `[generic]` rather than anything about this team |
| B3 | "How do you handle credit when work spans the whole grade level?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | "We" for context, "I" for contribution: the sentence already does it, with "our grade level's move" as the shared part and "I led" as yours, so say it at that scope. Answer slot: if some parts of the move were decided or done by colleagues, say which, in your own words; if you cannot separate them, say so plainly. Never stretch "led" to cover colleagues' work | F6 and the attribution probe peers use; EXP because it tests what was actually yours |
| B4 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." — your CV | Tell the beats the sentence states, in your own words: an after-school reading club, run by you, for the last two years. Answer slot: given the district's reading focus, expect a probe on what a session looks like and what was yours to set. Describe a session in your own words; if the format was set by someone else, or parts were not yours, say so plainly and stay with the club you run | F3 is the evidence; the likeliest place a reading-focused panel digs |

### C. Case/Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your class is reading well below grade level in October. What do you do in the first two weeks?" | CASE | [grounded] | Structure it aloud: what you would ask first (what is already known about the child, what has been tried), the objective, your approach in the classroom, who else you would involve including the family, how you would know it is working, and the risk you would watch. The district's own word for the outcome is a reading plan ("no student leaves third grade without a reading plan"), so use the word plan. The question asks for a decision, not a past, so the guidance makes no claim about yours | F3 and the Every Child a Reader belief; CASE because it is a live problem from the role |
| C2 | "The board has adopted a new grades 3–5 reading curriculum starting fall 2027. What would you want to know before it arrives?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Clarify first: what it covers, the timeline, what training comes with it, and how it sits beside what students already do. Then objective, approach, how you would know it is working, and one premise you would respectfully challenge. Where your own sentence applies, say it at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if something from that move is worth carrying over or doing differently, say what it is, in your own words; if you did not see enough of it to say, say so plainly. Do not claim to know the new curriculum's contents | F3 and the district's August 2026 literacy plan; CO because few candidates will have found it |
| C3 | "It's the second week of school. Which routines do you want running before your first reading lesson, and why?" | CASE | [grounded] | Clarify what you would ask first (class makeup, the routines the school already has), state the objective, then name a few routines in your own terms, each with its reason. Answer as the plan you would make, since the question asks for a plan and your material does not say what routines you have set | F7 is a requirement the hiring page names and the material is silent on; CASE because it is a live setup |
| C4 | "How did your grade level check whether the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Answer slot: the district's belief that assessments inform teaching makes a probe on how you checked likely. If you tracked how the move was going, say what you looked at and what you did with it, in your own words; if nothing was tracked, or the tracking was not yours, say so plainly and stay with the sentence: "I led our grade level's move to a new reading curriculum in 2024." Say the limit before you are asked for it | F5 and F6 together; the question presupposes a check the quote does not state, so its second branch lets the premise be false |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about a time a child's reading was a concern and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years." — your CV | A selection scaffold: pick a moment with a named stake, what the concern was, what you did, what changed or did not, and what you would do now. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I've run the after-school reading club for the last two years.", or how you would handle it | F3 against Every Child a Reader; no sentence of yours carries a story about one child, so this is a scaffold |
| D2 | "Tell us how you keep families partners in their child's learning." | VAL | [grounded] "I write a weekly email to families." — your CV | Story map on the one sentence: the beats it states are weekly, an email, to families, in your words. Answer slot: the district's belief says each teacher speaks with every family each term, so expect a probe on direct conversations. If you have spoken with families directly, say when and how, in your own words; if not, or it was not yours, say so plainly and stay with the email | F4 against Families Are Partners; the email is the evidence and its scope is the limit |
| D3 | "Tell us about a time information about how a student was doing changed what you did next." | VAL | [grounded] | A selection scaffold: pick a specific piece of information, what it told you, what you changed, and what you checked afterward. If no such time comes to mind, say so plainly, then say how you would handle it. No sentence of yours carries this story, so the guidance supplies none | F5 against Teach for Tomorrow, Not for the Test; the material is silent, so the guidance is selection, not a story |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got here." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV; "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV; "I write a weekly email to families." — your CV | A 90-second arc in this order, each in your own words at its sentence's scope: the license and endorsement, six years of third grade in Joliet, the curriculum move, the reading club, the weekly email. Close on why fourth grade and why Halvering. Answer slot: the material gives no reason, so say yours in your own words | F1, F3, F4 and F6 as one spoken arc; EXP because it is a CV walk-through, however friendly |
| E2 | "Which subjects have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Answer slot: a typical posting lists reading, writing, math, science and social studies, so expect this. Say which of them were yours to teach, in your own words; if some were taught by others, or you did not teach some, say so plainly and stay with the sentence | F8; the requirement comes from a typical posting, so the row is `[inferred]` |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Which parts of that move were yours, and which were not?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Hold at the sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say which parts were yours, in your own words; if parts were set elsewhere, or you cannot separate them, say so plainly, and do not add a part to make it bigger. Name the limit before they press | F6; the attribution check the persona uses on any claim of leading |
| F2 | "What goes into the weekly email to families?" | EXP | [grounded] "I write a weekly email to families." — your CV | Answer slot: say what goes into it, in your own words; if parts are templated or set by someone else, say so plainly and stay with the sentence: "I write a weekly email to families." | F4; the only specific, checkable habit in your material, so a prober starts there |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You moved from reading specialist to principal. How does that shape what you look for in a fourth-grade reading block?" | Ties to the principal's own public path and tells her you researched her, not just the school | [grounded] |
| R2 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two peers: it asks about their load, not your needs | [generic] |
| R3 | "The board adopted a new grades 3–5 reading curriculum for fall 2027. How is the team preparing, and where would a new teacher plug in?" | Shows you found the current plan; invites them to place you in it | [grounded] |
| R4 | "How do fourth-grade teachers handle the term conversations with every family?" | Takes up the Families Are Partners belief in its own words and shows you read the page | [grounded] |
| R5 | "What does support look like for a teacher who is new to the grade?" | Turns F2 into a ramp conversation instead of leaving it as an objection | [generic] |
| R6 | "What would make someone clearly successful in this role by the end of the first semester?" | Asks them to say what the job rewards, which you can then answer to in later rounds | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I haven't taught fourth grade." Then the third-grade sentence at its own scope. No slot |
| Has been a team lead | Negative you stated: "I've never been a team lead." — your message | The plain acknowledgment: "I haven't been a team lead." The move stays "I led our grade level's move to a new reading curriculum in 2024" |
| Led the grade level, or ran the team | Inflated form of F6's quote | The quote at its own scope. The limit is the pack's observation: your material says the move, not the team. A2 and F1 slots stay inside the move |
| Made sure every student has a reading plan | Inflated form of F3's quotes | The curriculum move and the reading club at their own scope. The limit is the pack's observation: your material says the move and the club, not individual plans. B4 and C1 do not claim it |
| Speaks with every family each term | Inflated form of F4's quote | The weekly email at its own scope. The limit is the pack's observation: your material says the email, not conversations. D2's slot asks only about direct conversations, in your words |

## Sources

Provided documents: the HR invitation text; the résumé text you pasted. Your Social Security number was in the pasted text and was not used.

Searches sent:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Halvering Elementary School Orrinsford fourth grade teacher interview" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Dolores Vantongeren principal Halvering Elementary" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Illinois elementary school fourth grade teacher job posting responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher (snippet only; its qualifications line was cut off and nothing was taken from it)
- "Orrinsford Community School District strategic plan news 2026" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet only, read as published August 2026)

Fetches sent:

- https://orrinsfordschools.example/about/mission-and-beliefs
- https://orrinsfordschools.example/careers/how-we-hire-teachers

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three beliefs by name: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test; F3, F4, F5 and the D bank |
| 2. Interview process | yes | One 45-minute panel of the principal and two grade-level teachers; topics reading, routines, families; persona weights and F3, F4, F7 |
| 3. Strategy and recent news | yes | The August 2026 three-year literacy plan, with a new grades 3–5 reading curriculum from fall 2027; C2 and R3 |
| 4. Interviewer footprint | yes | Principal's path and 2025 talk; the interviewer read and R1. The two team members have no names, so nothing more was searched |
| 5. Representative posting | yes | F6 and F8 and the E2 question; both are `[inferred]` |

## Upgrade menu

- The full posting text: F6 and F8 move from `[inferred]` to `[grounded]`, and any requirement the typical posting missed gets a question
- Anything HR said about format or a deliverable, such as a sample lesson or a writing sample: adds a build section for it, since an announced deliverable is graded
- The names of the two team members: personas assigned per member, and a tailored reverse question for each
- Your answers to the answer slots, said outside a drill, for F3, F4, F5, F7 and F8: those rows move from silence to your own quoted words and their bank cells regenerate
- A screenshot of your license record: F1 confidence moves from medium to high
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It would add a grounding brief on the district, loop reports for fourth-grade hiring, and recent organization context
- A `tuesday-dossier.md` from an earlier evaluation of this role (the job-underwriter skill) would add verified evidence and a sourced highest-objection pick, which would sharpen A1; the pack does not depend on one
