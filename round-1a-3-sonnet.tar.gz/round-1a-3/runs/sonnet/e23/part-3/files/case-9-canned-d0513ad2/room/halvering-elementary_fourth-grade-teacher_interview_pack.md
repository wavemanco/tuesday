# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. A 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team (their names and roles were not given).

Built on this assumption: a panel blends the principal's hiring-manager style with two peers' styles, and no posting was supplied, so a representative fourth-grade listing stands in for one (rows marked `[inferred]`).

## How to use this pack

Personas are how a question is asked. Types are what it is scored on. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it tests |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether your résumé claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the district's current direction |
| CASE | How you structure a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Meet it with either honest branch: say what you did, or say plainly it was not yours or never happened, then return to what your own words carry.

Question IDs run by persona: A, B, C, D, E, G, H. The letter F is skipped so that F-numbers always mean fit-snapshot rows. A1 is the highest-ROI prep in this pack.

## Fit snapshot

The evidence column holds your words only. Requirements are quoted from the invite, from the district's own page, or from a fetched representative listing (K12 Jobs Board, not this district's posting, so those rows are `[inferred]`).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, so nothing is bridged. It is a CV line with nothing inspected behind it here, so expect it to be confirmed. Say it in the quote's own terms |
| F2 | "plan and teach reading, writing, math, science and social studies" — representative listing | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The quote gives the grade and the years and says nothing about which subjects you taught. Answer slot: expect a probe on which of these subjects you planned and taught; say which, in your own words; if it was some of them, or not all planned by you, say so plainly and stay with the third-grade teaching you did |
| F3 | "experience in grades 3 to 5 preferred" — representative listing | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | Third grade sits inside that range, so the quote reaches it. Lead with its own terms: six years teaching third grade at a public elementary school in Joliet |
| F4 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then F3's quote at its own scope. How you would get up to speed is a plan, said in the future tense in your own words, never as a past |
| F5 | "work with the grade-level team" — representative listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | Reword only the quote: "In 2024 I led our grade level's move to a new reading curriculum." What working with colleagues looked like inside that move is not in your material, and B1 holds it as a slot. Read it beside F6 |
| F6 | Team leadership: not named in the invite or the listing, included because your message raises it | "I've never been a team lead" — your message | none | [generic] | capability | The negative is yours, so the words are yours: "I've never been a team lead." Say it plainly beside F5's quote at its own scope, and do not merge the two into a middle title |
| F7 | "communicate regularly with families" — representative listing | "I write a weekly email to families" — your CV | medium | [inferred] | none | The quote reaches the requirement. Lead with the routine in your own terms: you write a weekly email to families. A named routine beats an adjective |
| F8 | "Families Are Partners: each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your quote is a written email and the belief is speaking with every family each term, so the words stay at the email. Answer slot: if you also speak with families, say how and how often, in your own words; if you do not, or not with every family, say so plainly and stay with the weekly email |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan" — district Mission and Beliefs page | "I've run the after-school reading club for the last two years" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Both quotes are reading work at their own scope and neither mentions reading plans. Answer slot: the belief is anchored at third grade, where your six years sit, so expect a probe on plans; if you wrote or contributed to any, say what and for whom, in your own words; if none, or not yours, say so plainly and stay with the club and the curriculum move |
| F10 | "differentiate instruction using assessment data" — representative listing | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Answer slot: if you have used assessment results to change what you taught, say what and how, in your own words; if you have not, or it was not yours to do, say so plainly and say how you would start |
| F11 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [grounded] | discovery | Same silence as F10, raised by the district's own words. Answer slot: if you have a time you kept a test from steering your teaching, say what happened, in your own words; if you have none, say so plainly |
| F12 | "keep clear classroom routines" — representative listing | none given | none | [inferred] | discovery | Your material is silent on routines. Answer slot: if you set routines in your room, say which and why, in your own words; if they were set by the school or someone else, or there were none, say so plainly |

## Reading the interviewer

Public professional footprint only, and only for the principal. The two team members are unnamed, so there is nothing to read for them.

| # | What is published | Source | Provenance | What it means for you |
|---|---|---|---|---|
| I1 | Dolores Vantongeren has been principal of Halvering Elementary School since 2022 | Illinois principals forum speaker page, from a search result | [grounded] | She leads the panel and the decision runs through her |
| I2 | Nine years as a reading specialist before that | Same page | [grounded] | Expect reading questions asked from the inside. Keep every reading answer to what your own sentences carry and do not bluff method vocabulary |
| I3 | A 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | Same page | [grounded] | Reading in grades 3 to 5 is her stated subject. Mirror opportunity from F9: "I've run the after-school reading club for the last two years." Say it at that scope; do not claim conferences. Reverse question 1 is built on it |

## Persona table

The relationship priors for a panel blend each member's top two personas: the principal's hiring-manager pair (Case/Strategist, Skeptic) and the team members' peer pair (Peer Evaluator, Data-Driven Prober). The invite establishes one 45-minute panel, so no archetype fallback is used. No loop source documents a values round, so Values/Behavioral is weighted as a theme drawn from the district's published beliefs, not as a round.

| Persona (bank) | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the grade change and the leadership seam | High. F4 and F6 are gaps you stated, and the invite's role title names the grade | Rehearse A1 until it is boring: plain concession in your own quoted words, one held fact, a plan in the future tense |
| Peer Evaluator (B) | The two fourth-grade teachers ask what you would need from them and what you bring them | High. Two of three panelists are on the team you would join, and F5 is your team evidence | Reciprocity: what you offer as well as what you need; propose principles, not knowledge of their seam |
| Case/Strategist (C) | Live problems from the role: a struggling reader, assessment results, the district's literacy plan | Medium. The principal's pair includes it, and I2 and I3 tilt it toward reading | Clarify, then objective, approach, how you would check it, risks. Think aloud |
| Values/Behavioral (D) | Open prompts keyed to the three published beliefs | Medium. The district page says the beliefs guide every hire, but no round is documented | One story per belief where a quote carries one, a selection scaffold where none does |
| Conversational (G) | The opening biography question, a licence check, a day in your room | Medium. Casual register, still scored | A 90-second arc from your own sentences, and treat casual questions as scored |
| Data-Driven Prober (E) | Line-by-line questions on the curriculum move and the family email | Low. Your CV carries no figures, so there are no numbers to press | Know what you can and cannot say about how each thing worked; say plainly when you do not know |
| Pressure (H) | A time-boxed challenge on the grade change and on how reading-heavy your examples are | Low. Nothing in the invite signals a stress format | Pause, restate, hold the quoted position through two follow-ups, concede specifically |

## Question banks

### Bank A: Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI prep in this pack. Pause and restate. Hold only what the quote carries: six years teaching third grade at a public elementary school in Joliet. Concede in the same breath in your own words: "I've never taught fourth grade." Then say what you would do first in the new grade, as a plan. Follow-up 1, what would be hardest: name the one part you honestly judge hardest. Follow-up 2, why take the risk: return to the six years and add nothing to them. Follow-up 3, how do you know what fourth grade needs. Answer slot: if you have seen fourth-grade classrooms, plans or standards, say what and where; if you have not, say so plainly and say what you would find out first. Never describe your third-grade work as fourth-grade work | F4 is your biggest stated gap and the role title raises it, so this arrives in some form. JD because it scores the stated grade level, delivered in the Skeptic's quiet register |
| A2 | "You led your grade level's move to a new reading curriculum, and you've never been a team lead. Help me understand how both are true." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say both sentences at their own scope, in this order: "I led our grade level's move to a new reading curriculum in 2024." Then "I've never been a team lead." Do not merge them into a middle title. Answer slot: expect a probe on what "led" covered; if specific parts were yours to decide, say which, in your own words; if no part was yours to decide, or "led" covers less than the question assumes, say so plainly and return to the move as you wrote it. Hold the first sentence through two follow-ups and concede only what you can name | F5 and F6 sit side by side in your own material, which is where a careful panelist will press. EXP because it tests what was actually yours |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead" | Choose the one you honestly judge weakest; either quote can be the answer, and the choice is yours, not the pack's. Say the plain acknowledgment in the quote's words, then a plan in the future tense. Name one, not both. Do not deny having a weakness. Answer slot: if neither is your weakest, say what is, and say plainly if you have not yet looked | F4 and F6 are the two stated gaps. JD because it scores honest self-assessment against the role |
| A4 | "Why this school, why this grade, and why now?" | VAL | [grounded] "I've run the after-school reading club for the last two years" | The reasons are yours and the pack cannot supply them: give the true ones in two or three sentences. If reading is part of why Halvering, you can say you've run the after-school reading club for the last two years, at that scope, and let the panel connect it to the district's published "Every Child a Reader". Answer slot: if reading is not what drew you, say what did; do not borrow a reason because it matches the district page | F9 shows where your reading work meets the district's first published belief. VAL because the district's page raises motivation against its beliefs; the Skeptic asks it as consistency |

### Bank B: Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How do you like to work with a grade-level team, and what would you need from us in your first weeks?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Use reciprocity: what you bring and what you need. Anchor in the sentence as written: in 2024 you led your grade level's move to a new reading curriculum. Answer slot: what working with your grade-level colleagues looked like inside that move; if something you needed from them, or they needed from you, stands out, say it in your own words; if the move did not involve much back and forth, say so plainly and stay with the sentence. For the first weeks, name one or two principles you would follow as a new member of a team you did not build, in your own words | F5 is your only team evidence and the listing names working with the grade-level team. JD because it scores that requirement; the peer persona delivers it |
| B2 | "Suppose you and a teammate disagree about how to handle a unit. Walk us through what happens." | CASE | [generic] | Structure it: what you would ask first, what you would treat as shared ground, what you would look at together, who decides and how, and what you do if you still disagree. This needs no claim about your past. If a true example from your own grade level comes to mind, give it in your own words; if none does, say so plainly and answer as a plan | A live problem at the seam between colleagues, the Peer Evaluator's core test. CASE because it asks for reasoning, and `[generic]` because it is a pattern, not a fact about this team |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for context and "I" for contribution. Say the sentence as you wrote it, then answer slot: if colleagues carried parts of that move, name those parts and who by role, in your own words; if you cannot separate what was whose, say so plainly and stay with what you led | F5 is the only story that spans people, so credit is where it gets probed. EXP because it tests attribution |
| B4 | "What could we borrow from you, and what would you want to borrow from us?" | JD | [grounded] "I write a weekly email to families"; "I've run the after-school reading club for the last two years" | Name them as things you do, at that scope: a weekly email to families, and an after-school reading club run for two years. Offering to share them is your choice and a future offer, not a claim that they would help. What you would want to borrow is yours to say, in your own words | The reciprocity question from the peer persona. F7 and F9 hold the two things your material gives you to offer |

### Bank C: Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board adopted a three-year literacy plan this August, with a new grades 3–5 reading curriculum from fall 2027. What does that mean for a fourth-grade classroom?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you read the plan with one fact: a three-year plan, adopted in August 2026, with a new grades 3–5 reading curriculum from fall 2027. Then think aloud: what you would need to know first (what it replaces, when teachers see it, what training comes with it), what it means for fourth grade, what you would ask the team. The only past you may point to is the sentence about your own grade level's move in 2024, which is one grade level's move at an earlier time, not this plan. Answer slot: if that move taught you something about how a curriculum change goes, say what, in your own words; if nothing carries over, say so plainly. Reciting the plan shows you read it; your questions about it show how you think | The strategy sweep found the plan, and F5 is the nearest thing in your material. CO because it tests current district knowledge; the plan came from a search result, so confirm it on the district's site |
| C2 | "In the first week of school, one student is reading well below the others in your class. What do you do?" | CASE | [generic] | Structure it: clarify what you know and what came with the student (records, a plan, what the family says), set the objective, choose an approach, say how you would check progress, say who you would involve, and name the risks. The district's published "Every Child a Reader" is the frame, so ask whether a reading plan exists. Answer slot: if you have done something like this in your own room, say what and what you would change; if you have not, say so plainly and answer as a plan | F9 raises the belief, and I2 makes reading the likeliest case. CASE because it is a live problem; `[generic]` because it is a pattern and makes no claim about your past |
| C3 | "A short assessment comes back with mixed results across your class. Walk us through what you do next." | CASE | [inferred] | Structure it: what the assessment measured, what the results do and do not tell you, what else you would look at besides the score, what changes in the next lesson, and how you would check it worked. Let the assessment feed the teaching and not replace it, which is the district's published wording. Answer slot: if you have done this in your own room, say what you did, in your own words; if you have not, say so plainly and answer as a plan | F10 and F11 are both silent in your material, so a live problem lets you reason without claiming. CASE with a JD source because the listing names assessment data; `[inferred]` because that listing is typical, not this district's |

### Bank D: Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us about a student or a group you helped become a stronger reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Story beats the quote states: an after-school reading club, run for two years. Answer slot: if a particular student's or group's reading moved while you ran it, say what you saw and what part was yours, in your own words; if you cannot point to one, say so plainly and stay with the club as you ran it. Second slot: the belief names a reading plan for every student by the end of third grade, so if you wrote or contributed to any, say what and for whom; if not, say so plainly | The district's first published belief is "Every Child a Reader". F9 is your closest evidence and a story is the bar, not the slogan |
| D2 | "When have you brought a family in as a partner on a child's learning?" | VAL | [grounded] "I write a weekly email to families" | Story beats the quote states: a weekly email, to families. Answer slot: if a family's reply changed what you did for a child, say what happened, in your own words; if the emails go one way, say so plainly. Second slot: the belief says each teacher speaks with every family each term, so if you also speak with families, say how, and if you do not, say so plainly and stay with the email | The second published belief is "Families Are Partners". F7 and F8 are your evidence and its limit |
| D3 | "Tell us about a time you had to weigh preparing students for a test against teaching what you thought mattered." | VAL | [generic] | Selection scaffold: pick a time with a named decision, what you gave up or kept, and what happened afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not invent a time to fit the belief | The third published belief is "Teach for Tomorrow, Not for the Test". F11 is silent in your material, so this is a scaffold, not a story map |

### Bank E: Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how you led your grade level's move to the new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Beats the quote states: your grade level's move, to a new reading curriculum, in 2024, which you led; tell them in your own words. Answer slot: which parts were yours, and which were not. Second slot: assessment is raised by the listing and the district's words, so expect a probe on how you knew the new curriculum was working; if you looked at any results, say what and how they were counted, in your own words; if you looked at none, or it was not yours, say so plainly and stay with the move you led | F5 is the one story with enough weight to be walked through, and F10 and F11 are where the probe goes next. EXP because it tests what was yours |
| E2 | "Tell us about the weekly email to families: what goes in it, and how do you decide?" | EXP | [grounded] "I write a weekly email to families" | Say what the quote says: you write a weekly email to families. Answer slot: if you decide what goes in by some routine, say how, in your own words; if there is no set routine, say so plainly and describe a typical email as it actually is | F7 is a CV line with nothing inspected behind it, so a reader will ask to see inside it. EXP because it tests a routine you named |

### Bank G: Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc, one beat per sentence: six years teaching third grade at a public elementary school in Joliet; in 2024 you led your grade level's move to a new reading curriculum; you've run the after-school reading club for the last two years; you write a weekly email to families. The turn toward fourth grade and Halvering is yours, in your own words, and A4 holds it. Stop there | An opener is near certain in any panel and sets the register. F3 to F9 supply every beat, so nothing in it needs adding |
| G2 | "We need to confirm your licensure. Where does yours stand?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as written: you hold the Illinois Professional Educator License, with the Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029. Have your licence number to hand if they ask for it. Add nothing | F1 is the invite's one stated requirement and your material shows it met. JD because it scores the stated qualification |
| G3 | "Walk us through a day in your classroom." | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Describe a day as it actually ran in your third-grade room, in order. Answer slot: the listing names clear classroom routines as a typical expectation; if you set any, say which and why, in your own words; if the school or someone else set them, or there were none, say so plainly and describe the day as it ran. Do not polish it into a model day you did not run | F12 is silent in your material and F2 asks which subjects you taught, so this casual question carries both. `[inferred]` because the listing is typical, not this district's |

### Bank H: Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Pause and restate. Concede in your own words: "I've never taught fourth grade." Hold one fact at its own scope: six years teaching third grade at a public elementary school in Joliet. Do not claim you are the better candidate; state what you bring and let the panel draw the comparison. Answer slot: what you bring is yours to name from your own sentences, and if you cannot name it in a sentence, say so plainly | F4 sets the objection and F3 is the fact nearest it. JD because it scores the stated grade level under time pressure |
| H2 | "Your examples are all reading. This job covers more than reading. Convince us." | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Pause. Acknowledge that your examples so far are reading, which is true of those two sentences, and do not apologise for it. Answer slot: which other subjects you taught; if you taught math, science or social studies, say which and how, in your own words; if you did not plan some subject, say so plainly and stay with what you taught. Hold your position through two follow-ups | F2 is where the listing's five subjects meet a reading-heavy set of examples. JD because it scores a stated responsibility; the Pressure persona times it |

## Requirement coverage

| Requirement | Fit rows | Question IDs |
|---|---|---|
| Licence and endorsement | F1 | G2 |
| Plan and teach five subjects | F2 | H2, G3, G1 |
| Experience in grades 3 to 5 | F3 | A1, G1 |
| Fourth grade | F4 | A1, A3, H1 |
| Work with the grade-level team | F5 | B1, B2, B3, E1, A2 |
| Team leadership | F6 | A2, A3. Not a stated requirement in the invite or the listing; covered because your message raises it |
| Communicate regularly with families | F7 | E2, D2 |
| Families Are Partners | F8 | D2 |
| Every Child a Reader | F9 | D1, C2, A4 |
| Differentiate using assessment data | F10 | C3, E1 |
| Teach for Tomorrow, Not for the Test | F11 | D3, C3 |
| Clear classroom routines | F12 | G3 |
| Board literacy plan (context, not a requirement) | none | C1 |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| 1 | To the principal: "Your Small Groups, Big Readers talk covered weekly reading conferences in grades 3 to 5. How much of that do you see in fourth-grade classrooms here?" | Tied to her own path (I2, I3). It shows you read her work and turns an interview into a reading conversation |
| 2 | "The board adopted a literacy plan with a new grades 3 to 5 reading curriculum from fall 2027. What would you want a fourth-grade teacher hired now to do to be ready for it?" | Uses the strategy sweep, and asks what she expects of someone new to the grade |
| 3 | To the team: "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the peers on the panel |
| 4 | "What does support look like in the first year for a teacher who is new to fourth grade?" | Names your F4 gap constructively, as a question about onboarding and not as an apology |
| 5 | "Families Are Partners says each teacher speaks with every family each term. What does that look like in practice for fourth grade here?" | Shows you read the district's page and gives you a concrete expectation to answer against |
| 6 | "What would you hope to see from a fourth-grade teacher by the end of the first term?" | Lets the panel state the bar, and tells you what to aim at |

## Prohibited claims

Built locally from the fit snapshot before the banks. No cell in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade, or describing third-grade work as fourth-grade work | Negative you stated, F4 | The plain acknowledgment "I've never taught fourth grade", then F3's quote at its own scope. No slot |
| Having been a team lead | Negative you stated, F6 | The plain acknowledgment "I've never been a team lead", beside F5's quote at its own scope. No slot |
| Rolling out the reading curriculum across the school, or crediting it with student results | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation, not words for you: the material says your grade level's move, and no outcome. E1's slot stays inside the move |
| Speaking with every family each term | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: the material says a weekly email, not a spoken exchange. D2's slot asks only how you speak with families, if you do |

## Sources

Provided documents: the interview invite from Human Resources, Orrinsford Community School District, and your pasted résumé text. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches and fetches, in order:

- Search "Orrinsford Community School District mission values": returned orrinsfordschools.example/about/mission-and-beliefs
- Search "Halvering Elementary School Orrinsford Community School District news": returned orrinsfordschools.example/news/board-adopts-literacy-plan
- Search "Dolores Vantongeren principal Halvering Elementary": returned ilprincipalsforum.example/speakers/dolores-vantongeren
- Search "fourth grade teacher job posting Illinois elementary school responsibilities qualifications": returned k12jobsboard.example/listings/fourth-grade-teacher
- Fetch orrinsfordschools.example/about/mission-and-beliefs: returned the three beliefs and their definitions
- Fetch k12jobsboard.example/listings/fourth-grade-teacher: returned the representative listing's responsibilities and qualifications

The literacy plan and the principal's footprint come from search-result text only; those pages were not fetched. Confirm the plan and her details on the district's own site before Thursday.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Bank D and rows F8, F9, F11, from the district's published beliefs. No values-style round is documented, so there is no values cheat sheet |
| 2. `{company} interview process {role family}` | skipped | The invite already fixes the loop: one 45-minute panel of the principal and two fourth-grade team members. Persona weights follow from it |
| 3. `{company} strategy` / recent news | yes | C1 and reverse question 2, from the August 2026 board literacy plan |
| 4. `{interviewer name} {company}` | yes | The interviewer read, A4's frame and reverse question 1, for the principal only |
| 5. representative `{role title}` JD | yes | Rows F2, F3, F5, F7, F10 and F12 stand on a representative listing, all `[inferred]` |

## Upgrade menu

- The district's actual posting for this role → rows F2, F3, F5, F7, F10 and F12 move from `[inferred]` to `[grounded]`, and any requirement it adds gets a question
- Anything HR said about preparing, such as a sample lesson or a demo → a build section for each declared deliverable
- Names and roles of the two team members → a per-member persona read, a tailored reverse question, and whether one is the grade-level lead, which bears on F6
- Your answers to the answer slots, stated in your own words, on F2 (subjects taught), F5 (what "led" covered), F8 (speaking with families), F9 (reading plans) and F10 (assessment data) → quoted into the snapshot, with those rows and their questions regenerated
- Your licence record showing the endorsement and expiry → F1 moves from medium to high
- A sample weekly family email, or the materials from your 2024 curriculum move → F7 and F5 can move up from medium, and E1 and E2 get firmer ground
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a district strategy brief and recent staffing context, so the CO and CASE questions rest on more than one search result
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and prohibited claims arrive from it in place of the list built here, and it is never required
