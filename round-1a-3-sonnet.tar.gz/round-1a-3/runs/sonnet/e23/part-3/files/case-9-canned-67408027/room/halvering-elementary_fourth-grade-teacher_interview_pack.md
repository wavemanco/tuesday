# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District. **Candidate:** Grace.
**Round:** 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).
**Relationship read:** the principal's seat is weighted as a hiring-manager seat; the two teammates' seats are weighted as peer seats.
**Built on:** your invite, your resume text, and four searches and two fetches of public pages (see Sources). No full posting and no recruiter guidance were available, so requirements come from the invite, the district's published beliefs, and a representative posting labelled inferred.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script: say only what you actually did. Fit rows are numbered F1 to F9; question banks are lettered A to E and G (the letter F is left unused so the two never get confused).

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether what your resume says survives follow-up questions, and what was actually yours |
| JD | The role's stated duties and requirements, gaps included |
| CO | Whether you know the district's current plans |
| CASE | A live problem from the role, reasoned aloud |

Your invite documents no dedicated values round, so there is no values cheat sheet. The three published beliefs still theme bank E.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Nothing to recover: your CV states the license, the endorsement and the date, so lead with them in those terms. It is a CV line with nothing inspected behind it, so have the license record to hand in case anyone asks for it |
| F2 | "Fourth Grade Teacher position" — your invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | The words stay at the quote's scope: "I've taught third grade for six years at a public elementary school in Joliet." Any step from third grade to fourth is an answer slot: if you already know how your third-grade work lines up with fourth, say how, in your own words; if you do not yet know how the two grades differ, say so plainly and say what you would ask the fourth-grade team first |
| F3 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | The gap is one you stated, so the words are yours: "I haven't taught fourth grade." Then a plan in your own words for your first weeks, said as a plan and never as a past. Never a claim to fourth-grade experience, and nothing added to make the gap feel smaller |
| F4 | "a new grades 3–5 reading curriculum from fall 2027" — Orrinsford board literacy-plan page | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | The words stay at the quote's scope: "In 2024 I led our grade level's move to a new reading curriculum." The pack observes that nothing in your material says it is the curriculum Orrinsford is moving to, or that the move reached past your grade level. Answer slot: expect a probe on how the move went. Say what you did and what others did, in your own words; if parts were not yours, say so plainly and return to your grade level's move |
| F5 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford mission page | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | The words stay at the quote's scope: "I've run the after-school reading club for the last two years." A club is not a reading plan, and the pack does not bridge the two. Answer slot: if any of your third graders left with a reading plan, say who made it and what part was yours; if no such plan existed at your school, or it was not yours, say so plainly and stay with the club |
| F6 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford mission page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The words stay at the quote's scope: "I write a weekly email to families." An email is not a conversation with each family, and the pack does not bridge the two. Answer slot: if you also spoke with families directly, say when and how, in your own words; if the email was the whole of it, say so plainly and say what you would add |
| F7 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford mission page | none given | none | [grounded] | discovery | Your material does not show assessment work either way. Answer slot: if assessment results have changed what you taught, say how, in your own words; if they were not part of your planning, or the plan was set by others, say so plainly and say how you would start |
| F8 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board snippet | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The quote names the grade, not the subjects, and the pack does not fill the gap. Answer slot: if your third-grade teaching covered subjects beyond reading, say which, in your own words; if it was reading only, or others planned the rest, say so plainly |
| F9 | "work with the grade-level team" — representative posting, K12 Jobs Board snippet | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | The posting line is typical for the role, not confirmed for this team. Your words: "In 2024 I led our grade level's move to a new reading curriculum," and, where asked, "I haven't been a team lead." Answer slot: if colleagues worked alongside you in that move, say how you worked with them; if it was mostly your own work, say so plainly |

## Reading the interviewer

| Item | What the source says | Provenance | Practical implication |
|---|---|---|---|
| Career pattern | Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist (ilprincipalsforum.example, speaker page) | [grounded] | — |
| Published talk | Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 (same page) | [grounded] | — |
| Reading depth | — | [inferred] | Reading questions from the principal's seat can go deeper than the usual. C2, D1 and D2 are the rehearsal for it |
| Mirror opportunity | Her talk covers grades 3 to 5; your third-grade teaching sits at the start of that range: "Six years teaching third grade at a public elementary school in Joliet" (F2); "I've run the after-school reading club for the last two years" (F5) | [inferred] | Shared subject area, not a shared career jump. Answer slot: if you hold reading conferences or small groups with students, say how, in your own words; if you do not, say so plainly and say what you do instead. Do not name her talk as though you share her practice |
| The two teammates | Names not given, so there is no read | [generic] | Personas for them come from the peer seat, not from anything about them |

Public professional footprint only. Nothing else about her was looked for.

## Persona table

Weights were set in three passes. Pass 1, relationship priors: the principal's seat reads as hiring manager (Case/Strategist plus Skeptic), the teammates' seats as peer (Peer Evaluator plus Data-Driven Prober), blended for a panel. Pass 2, interviewer signals: the principal's years as a reading specialist and her talk on reading conferences tilt the case questions toward reading. Pass 3, the loop: your invite establishes one 45-minute panel and documents no values round, so Values/Behavioral is not guaranteed.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal derisking the gaps you stated, bank A | high: hiring-manager prior, and your material states the fourth-grade gap (F3) | Rehearse A1 until it is boring; say the plain acknowledgment F3 gives; bridge only with the adjacent evidence F2 carries |
| Peer Evaluator | The teammates asking what working beside you is like, bank B | high: peer prior, and the posting line on the grade-level team (F9) | Say what you would bring them, not only what you need; propose principles for the seam rather than pretending to know it |
| Case/Strategist | Live problems and the district's literacy plan, bank C | medium: hiring-manager prior, tilted by the reading-specialist background | Clarify, then objective, then approach, then how you would know; think aloud |
| Data-Driven Prober | Teammates reading your CV line by line, bank D | medium: peer prior, but your CV holds no figures, so the probes go to what each line covers | Know what each line covers and say plainly where it stops |
| Values/Behavioral | Stories themed on the three published beliefs, bank E | medium: no values round documented, but the beliefs are published and fetched | Name a real instance for each belief, or say plainly that none comes to mind |
| Conversational | The opening biography question, bank G | medium: the biography stem belongs to this persona; kept to two questions | A 90-second arc built only from your own sentences |
| Pressure | Interruptions and time-boxing | low: nothing in the invite or the public footprint suggests it; no bank, touched only by the pressure-style stem in A4 | Pause, restate, hold the sentence you can back |

## Question banks

### A. Skeptic (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, not fourth. Why should we hire you for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI prep in this pack. Name the limit yourself, first: "I haven't taught fourth grade." Then the one sentence your material carries: "I've taught third grade for six years at a public elementary school in Joliet." Answer slot: if you know how your third-grade work lines up with fourth, say how, in your own words; if you do not yet know how the two grades differ, say so plainly and say what you would ask the fourth-grade team first. Follow-up one, what will be hardest: name one real thing you would need to learn, as a plan. Follow-up two, so you would be learning on our students: concede exactly, "I haven't taught fourth grade," then return to the quote and the plan. Never answer by adding experience | F3 is the stated gap and F2 the adjacent evidence, so this is the objection most likely to arrive in some form. JD because it scores the posted grade; Skeptic stem, with the negative sourced in F3 |
| A2 | "Your resume shows a curriculum move you led but no team-lead role. How do you see your place on a team like ours?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Plain acknowledgment first: "I haven't been a team lead." Then the move at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." Then how you would work as a member of the team, as a plan in your own words. Answer slot: if colleagues worked alongside you in that move, say how you worked with them; if it was mostly your own work, say so plainly and return to the move | F9 and F4. The posting line on the team is typical for the role, not confirmed for this one, so this probes the gap you named rather than a stated requirement |
| A3 | "Why fourth grade, and why Halvering, now?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: your reason has to be your own, so pick what actually draws you to fourth grade and what draws you to this school. Two published facts you can speak to by name: the belief Every Child a Reader, and the board's literacy plan, which moves grades 3–5 to a new reading curriculum from fall 2027. If the move you led is part of your reason, say it at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." If you have no reason beyond wanting a new grade, say so plainly | F2 and F4. CO because the answer is stronger when it names the plan; the motivation probe is the Skeptic's |
| A4 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pause and restate the question. Hold what the sentence says: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: say which parts were yours to decide and which were set by others, in your own words; if most of it was decided above your grade level, say so plainly and return to your grade level's part. Hold through two follow-ups; concede exactly what was not yours, no more and no less | F4 is the one leadership claim on your CV, so it is where attribution is tested. EXP, delivered in the Pressure persona's style |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick one real weakness. The one your material states is fourth grade: "I haven't taught fourth grade." Then say it as a plan: what you would ask the team in your first week. Answer slot: if a second area comes to mind from your own experience, such as a subject or a routine, name it and say what you would do; if none does, say so plainly rather than offering a weakness you do not have | F3. Skeptic stem; it overlaps A1 on purpose, because the answer should not change when the wording does |

### B. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you disagreed with a colleague about how to teach something." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: choose a disagreement about practice rather than personality, with a named stake, what you said, what changed or what you accepted, and a working relationship intact. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "In 2024 I led our grade level's move to a new reading curriculum," at its own scope, or say how you would handle a disagreement | F9. Peer stem on disagreement; the quote is offered only as the nearest material, not as a story about a disagreement |
| B2 | "Our classes sit side by side. Where's the seam between what each of us decides and what we decide together, and what happens when we disagree?" | JD | [generic] | Propose principles rather than pretending to know their seam. Ask what the team already shares, such as pacing, materials and assessments, before proposing anything. Then principles in your own words: what is decided together, what stays in each classroom, and how a disagreement gets raised early. The guidance makes no claim about your past | F9. Peer stem; generic because it is a pattern for the problem, not a fact about this team |
| B3 | "How do you handle credit when work is shared across a team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The sentence carries its own split: "our grade level's move" is the we, "I led" is the I. Say it that way. Answer slot: if colleagues did parts you did not, name them plainly; if no one else did, say so | F4. Peer stem on credit; the move is the only shared-work sentence in your material |
| B4 | "It's October and the other fourth-grade classes are further along in reading than yours. What do you do first?" | CASE | [generic] | Clarify first: further along by what measure, on the same curriculum, with what students. Then what you would look at, whom on the team you would ask, and what you would change against what you would hold. Think aloud and speak only in plans. The guidance makes no claim about your past | F3 and F9. A live problem a teammate might set; it presupposes nothing about your past |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our board adopted a literacy plan that moves grades 3–5 to a new reading curriculum from fall 2027. What would you want to know before that reaches fourth grade?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what the curriculum is, when fourth grade starts, what support there will be, how the team will begin. One sentence of your own, at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: if there are lessons from that move you would bring, say them in your own words; if you cannot name any yet, say so plainly and say what you would ask. Do not say it is the same curriculum | F4. CO because it rests on the plan the board adopted in August 2026 (fetched) |
| C2 | "A new student joins your fourth-grade class reading well below the rest. Walk me through the first month." | CASE | [grounded] | Clarify what information the school already has and what supports exist. Then the objective, your approach in your own practice, and how you would know it is working: the district's belief is that assessments inform teaching and never replace it. Include how you would bring the family in. If small-group reading is how you would teach it, say so; only if it is. The guidance makes no claim about your past | F5 and F7. CASE from the belief Every Child a Reader; the principal's reading background makes it a likely one |
| C3 | "How would you set up the first two weeks of fourth grade so routines are clear?" | JD | [inferred] | Plan only: which routines first, why in that order, and how you would check they are working. The posting line, keep clear classroom routines, is typical for the role, not confirmed for this school. The guidance makes no claim about your past | Representative-posting requirement with no row of evidence in your material; a CASE-style plan is the honest way to cover it |
| C4 | "Fourth grade covers reading, writing, math, science and social studies. How would you plan a week across them?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Structure the plan aloud: what is fixed, what is flexible, what you would ask the team. Answer slot: if your third-grade teaching covered subjects beyond reading, say which and how you planned them, in your own words; if it was reading only, or others planned the rest, say so plainly and say how you would learn the fourth-grade pacing | F8. The subject list is typical for the role, not confirmed for this team |

### D. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through how your grade level moved to the new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats are the ones the sentence states: the move, your grade level, 2024. Answer slot: if you set any stage of the move, say which and how you decided, in your own words; if there were no such decisions for you, or they were made elsewhere, say so plainly and return to the move. Follow-up: name the part you would defend least, in your own words; if you have no such part, say so | F4. A Prober goes two levels deep on a single line |
| D2 | "Tell us about the after-school reading club you've run." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats are the ones the sentence states: after school, a reading club, the last two years. Answer slot: the belief that assessments inform teaching raises a probe on how you know the club is working. If you track anything, say what; if you do not, say so plainly and say what you would track | F5 and F7. The question is premised only on the sentence |
| D3 | "How do you use assessment results to plan what you teach next?" | JD | [grounded] | Answer slot: if you do, give one real example, in your own words; if assessment results were not part of your planning, or the plan was set by others, say so plainly and say how you would start. The district belief is that assessments inform teaching and never replace it | F7 is a discovery row with no quote, so the answer has to come from you |

### E. Values/Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader: no student leaves third grade without a reading plan. Tell me about a student who struggled with reading and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: a real student, no name, what you saw, what you did, what changed, and an outcome you can describe honestly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years." Answer slot: if any of your third graders left with a reading plan, say who made it and what part was yours; if there was no such plan, or it was not yours, say so plainly and stay with the club | F5. VAL themed from the published belief |
| E2 | "Families Are Partners: each teacher speaks with every family each term. Tell me about a time a family's concern changed what you did." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold: a real instance, what the family raised, what you did differently, how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I write a weekly email to families." Answer slot: if you also spoke with families directly, say when and how; if the email was the whole of it, say so plainly | F6. VAL themed from the published belief |
| E3 | "Teach for Tomorrow, Not for the Test: tell me about a time you taught something you believed was right for a child even though it was not what a test measured." | VAL | [grounded] | Selection scaffold: a real instance, what you believed, what you did, and how it landed with whoever disagreed. Pick one where the hard part actually happened. If no such time comes to mind, say so plainly, then say how you would weigh it | F7. VAL themed from the published belief; the guidance makes no claim about your past |

### G. Conversational (weight 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc built from those four sentences and nothing else: third grade for six years, the move in 2024, the club, the weekly email. Close with why fourth grade, in your own words. Answer slot: if there is a reason from your own experience, say it; if the honest reason is that you are ready for a new grade, say that plainly | F2, F4, F5, F6. The biography stem is scored even though it sounds casual |
| G2 | "What's a book you've loved sharing with students, and why?" | EXP | [generic] | Pick a real one and say what it did for readers in your room, in plain terms. If no book comes to mind, say so plainly and name one you would want to use and why. The guidance makes no claim about your past | Conversational stem on the role's subject; generic because it carries no fact about this employer or about you |

### Requirement-coverage line

| Requirement | Questions |
|---|---|
| Valid Illinois PEL with elementary endorsement (F1) | — none, and why: it is a term you meet or do not, not an answer to rehearse. Have the license record to hand |
| Fourth Grade Teacher position (F2, F3) | A1, A3, A5, B4, C2, C3 |
| New grades 3–5 reading curriculum from fall 2027 (F4) | A4, C1, D1 |
| Every Child a Reader (F5) | C2, D2, E1 |
| Families Are Partners (F6) | E2 |
| Assessments inform teaching (F7), and the typical posting's differentiate instruction using assessment data | C2, D2, D3, E3 |
| Plan and teach reading, writing, math, science and social studies (F8) | C4 |
| Work with the grade-level team (F9) | A2, B1, B2, B3, B4 |
| Keep clear classroom routines (typical posting) | C3 |
| Communicate regularly with families (typical posting) | E2 |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | "Your talk on weekly reading conferences in grades 3 to 5: what does that look like in a fourth-grade classroom here?" | Ties to the principal's own published talk, so it reads as research on her rather than on the school |
| R2 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two teammates: it asks what you can bring them, not only what you need |
| R3 | "How will the move to the new grades 3–5 reading curriculum in fall 2027 be supported for fourth grade?" | Shows you read the board's August 2026 plan and ask about the part that reaches your grade |
| R4 | "How does the fourth-grade team plan together, and who decides on pacing?" | Covers the seam from B2 in their words, and gives you what you need to know about the team |
| R5 | "The plan includes a family reading night at every school each term. Where would a fourth-grade teacher fit in?" | Draws on the plan's family element and the belief Families Are Partners |
| R6 | "What would a good first semester look like for the person in this role?" | Asks for their definition of success instead of guessing it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F3 | The plain acknowledgment F3 gives: "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative you stated, F9 | The plain acknowledgment: "I haven't been a team lead." Then F4's quote at its own scope |
| Led the reading curriculum change for the school or the district | Inflated form of F4 | F4's quote at its own scope. The pack observes that your material says your grade level's move |
| Runs a family-engagement program, or speaks with every family each term | Inflated form of F6 | F6's quote at its own scope. The pack observes that your material says a weekly email. The E2 slot asks only about direct contact |
| Gave students reading plans | Inflated form of F5 | F5's quote at its own scope. The pack observes that your material says the club, not plans. The slot stays inside the club |

## Sources

Provided documents: the interview invite; the resume text and message you pasted.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or page | Returned |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: fourth grade teacher job posting Illinois elementary qualifications | https://k12jobsboard.example/listings/fourth-grade-teacher (snippet only; its qualifications line was cut off and the page was not fetched) |
| Fetch: mission and beliefs page | Three beliefs and their one-line meanings, as quoted in F5, F6, F7 |
| Fetch: board literacy-plan page | August 2026 three-year literacy plan, as used in F4, A3, C1 and R3 |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Three beliefs by name; they raise F5, F6, F7 and theme bank E |
| 2. Orrinsford interview process, fourth grade teacher | skipped | Your invite already fixes the loop: one 45-minute panel of the principal and two fourth-grade team members. Persona weights follow from it |
| 3. Orrinsford strategy and recent news | yes | The August 2026 literacy plan feeds F4, A3, C1 and R3 |
| 4. Interviewer name and school | yes | The principal's public footprint feeds the interviewer read, the persona weights and R1. The two teammates have no names, so nothing was searched for them |
| 5. Representative fourth grade teacher posting | yes | The snippet feeds F8, F9 and C3, C4, all labelled inferred; its truncated qualifications line moved nothing |

## Upgrade menu

- The full posting text for this role: F8 and F9 and the typical-posting questions C3 and C4 become grounded or are corrected, instead of resting on a representative posting
- Anything HR said about focus areas, a sample lesson or something to bring: graded-deliverable build sections, which this pack assumes are not needed
- The names of the two fourth-grade team members: a read of each one's public footprint, personas per member, and a reverse question tied to each path
- The state's public educator-license lookup record for your license: F1 moves from medium to high
- Your answers to the slots in F5, F6, F7 and F8: those rows gain quoted evidence and the guidance for D2, D3, E1, E2, E3 and C4 is regenerated
- How many days or hours you have before Thursday: a prioritized prep schedule sized to it, which this pack omits
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, adding district context, more of the principal's public talks, and reports on how the district interviews
- An underwriter-built dossier, if you have one: strategy limits per weak area and a verified objection list, never required
