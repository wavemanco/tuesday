# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. A 45-minute panel on Thursday with Principal Dolores Vantongeren (the hiring-manager seat) and two members of the fourth-grade team (peer seats, names not given).

## How to use this pack

Personas describe how a question will be asked. Types describe what is being scored. Every question carries one of each, so you can see both what to rehearse and how it will feel. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether the claims in your CV survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the district's current direction |
| CASE | How you structure a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. It names what a panel is likely to probe and gives two honest branches: say what you did, or say plainly that the practice was not yours or did not exist, and return to the sentence your CV does carry.

## Fit snapshot

No job posting was supplied, so the requirements come from, in this order: the invite, the district's own pages, then a representative listing found by search. The listing is a search snippet only. Rows built on it are unquoted prose labeled `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The invite states this as a condition and your CV states it met, with nothing inspected behind it beyond your own line, so expect it taken as read and say it in the quote's own terms: "I hold an Illinois Professional Educator License with the Elementary Education endorsement for grades 1 through 6, registered and active through June 30, 2029." |
| F2 | "reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says the move and the club, not your own reading lessons, and the words stay at that scope: "In 2024 I led our grade level's move to a new reading curriculum, and for the last two years I've run the after-school reading club." Answer slot: reading instruction is a named panel topic, so expect a probe on what happens in your own reading lessons. If any part of your own lessons changed with the move, say what changed and how you decided; if none did, or the move was about something other than your lessons, say so plainly and stay with the move and the club |
| F3 | "classroom routines" — district hiring page | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [grounded] | discovery | The sentence touches the requirement without showing it. Answer slot: classroom routines are a named panel topic. If any routine in your classroom was yours to set, say which and why, in your own words; if routines came from the school or team, or you did not set any, say so plainly and stay with the six years in third grade |
| F4 | "how you work with families" — district hiring page | "I write a weekly email to families." — your CV | medium | [grounded] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms, that you write it and that it is weekly, because a named routine beats an adjective |
| F5 | "each teacher speaks with every family each term" — district mission page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The belief says speaking and your sentence says writing, and the words stay at the sentence: "I write a weekly email to families." Answer slot: if you spoke with families, say in what setting, how often and which families, in your own words; if the email was your channel and you did not speak with each family each term, say so plainly and stay with the email |
| F6 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past, with first steps that are really yours to take. Never a claim to fourth-grade experience |
| F7 | Teach across the elementary subjects — representative listing, K12 Jobs Board search result, snippet only | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | transferability | Your material says third grade, and the pack's observation is that it does not say which subjects or how third and fourth grade differ. Words at the quote's own scope: "I've taught third grade for six years at a public elementary school in Joliet." Answer slot: if you expect any part of your third-grade planning to change in fourth grade, say what; if you have not looked at fourth-grade expectations yet, say so plainly and stay with the six years |
| F8 | Work with the grade-level team — representative listing, K12 Jobs Board search result, snippet only; the invite names two fourth-grade team members on the panel | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | transferability | Leading a move and holding a lead post are different things, and your two sentences say both. Words: "In 2024 I led our grade level's move to a new reading curriculum. I haven't been a team lead." Answer slot: if colleagues worked on the move with you, say who did what and which part was yours; if you did it alone, or the work was not divided, say so plainly and stay with the sentence |
| F9 | "assessments inform teaching and never replace it" — district mission page | none given | none | [grounded] | discovery | Nothing in your material touches this. Answer slot: the belief makes a probe on how assessment feeds your teaching likely. If you have used assessment results to change what you taught, say what kind and what changed; if you have not, or the results were not yours to use, say so plainly and say how you would |
| F10 | "no student leaves third grade without a reading plan" — district mission page | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [grounded] | discovery | The sentence touches the requirement without showing it. Answer slot: if reading plans were part of your third-grade work, say whose they were and what you did with them; if there were none, or they belonged to someone else, say so plainly and stay with the six years |

## Reading the interviewer

Public professional footprint only, from one search result. One panelist is a principal with a public reading background. The two teammates have no public information in hand.

| Fact | Source | Provenance |
|---|---|---|
| Principal of Halvering Elementary School since 2022 | ilprincipalsforum.example/speakers/dolores-vantongeren, search result snippet | [grounded] |
| Nine years as a reading specialist before that | same | [grounded] |
| 2025 forum talk "Small Groups, Big Readers" covering weekly reading conferences in grades 3 to 5 | same | [grounded] |

| What it suggests | Provenance |
|---|---|
| Reading instruction questions from this seat are likely to go deeper than the district page's one-line topic suggests: C1, D1 and F1 are the rehearsal for it | [inferred] |
| Her talk was about conferences in grades 3 to 5. Ask her about it (R2) instead of claiming familiarity with the practice, because no row of your material speaks to it | [inferred] |
| Shared vocabulary is reading curriculum. Your sentence for it is "I led our grade level's move to a new reading curriculum in 2024" (F2), offered at that scope and left for her to take further | [inferred] |
| No row carries a career jump of your own, so no shared jump is offered | [inferred] |

## Persona table

The loop is the district's documented one: a single 45-minute building panel of the principal and two grade-level teachers (district hiring page, and your invite). No archetype fallback was needed. No source names a values round, so no values-style round is detected here and no values cheat sheet is built. The three published beliefs still theme the D bank.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal probing the fourth-grade gap and the team-lead gap | High. The principal sits in the hiring-manager seat, and F6 and F8 are gaps in your own words, which is where a Skeptic starts | Rehearse A1 until it is boring. Hold "I haven't taught fourth grade" and concede one specific thing, with a plan. Bank A, 4 questions |
| Peer Evaluator | The two fourth-grade teachers asking what you add to their team and how you disagree | High. Two grade-level teachers are on the panel, and F8 is the row they will price | Reciprocity: say what you need and what you bring, at the scope of your sentences. Bank B, 4 questions |
| Case/Strategist | Live classroom problems on reading, routines and assessment | Medium to high. The district page names reading instruction and routines as panel topics, and the principal's public background is reading | Clarify, structure, then answer, and challenge one premise respectfully. Bank C, 4 questions |
| Values/Behavioral | Scenarios mapped to Every Child a Reader, Families Are Partners and Teach for Tomorrow, Not for the Test | Medium. The mission page says the beliefs guide every hire, but no loop source says the panel scores them | Where a quoted sentence carries a story, use it; otherwise use the selection scaffold and its honest branch. Bank D, 3 questions |
| Conversational | The opener, the "what do you know about us" question, and a friendly licence check | Medium. A 45-minute panel opens and closes in a friendly register that is still scored | A 90-second arc built from your own sentences. Bank E, 4 questions |
| Data-Driven Prober | A teammate asking how the club and the email are known to work | Low to medium. Your CV carries no figures, so the probes land on what you track | Know what you can and cannot say about how you would tell, and say plainly when you do not know. Bank F, 2 questions |
| Pressure | Interruptions and time-boxing | Low. Nothing in the invite or the hiring page suggests it, so there is no bank | The hold-then-concede structure in A1 covers it if it appears |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have six years in third grade and no fourth grade on your résumé. What will be newest to you on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I haven't taught fourth grade. I've taught third grade for six years at a public elementary school in Joliet." Then concede one specific thing: name what you expect to be newest, in your own words, and what you would do first about it, said as a plan. Hold through two likely follow-ups, "what specifically?" and "how would you know you were behind?", by returning to the plan, never by adding experience. Answer slot: if you have looked at fourth-grade expectations, say what you saw; if you have not, say so plainly and say where you would start. Do not argue that third grade proves you can teach fourth, and let the panel draw that line | F6 is your stated gap and the first place a Skeptic goes, so this question arrives in some form. JD because it scores the role's grade level, with F7 as the adjacent evidence and its limit |
| A2 | "What would you want to learn from our fourth-grade team in your first few weeks?" | JD | [grounded] "I've never taught fourth grade" | A plan, not a past. Start from the plain acknowledgment: "I haven't taught fourth grade, so I would start by asking." Then name two or three things you would ask, and a good source for them is the topics the district says panels cover: reading instruction, classroom routines and how you work with families. Say why each matters to you in your own words, and what you would do with the answers. Answer slot: if you expect something in your own third-grade practice to carry over, say what; if you would start fresh, say so plainly | F6 and F7 make the ramp plan the natural follow-up to A1. JD because it scores readiness for the grade; the hiring page is the source of the three topics |
| A3 | "You haven't been a team lead. How do you see your place on a team like ours?" | EXP | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Hold both sentences at their own scope: "I haven't been a team lead. In 2024 I led our grade level's move to a new reading curriculum." Do not stretch the move into a team post, because the panel can tell an initiative from a lead role. Answer slot: if colleagues worked on the move with you, say who did what and which part was yours; if you did it alone, or the work was not divided, say so plainly and stay with the sentence. Close on what you would ask of the team, in your own words | F8 holds two of your sentences in tension, and the teammates on the panel are the ones to notice. EXP because it tests attribution |
| A4 | "Why fourth grade, why Halvering, and why now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | A motivation question, and nothing in your material states your reasons, so this is a selection scaffold. Three beats, each in your own words: what draws you to fourth grade, what draws you to this school, and why this year. Choose the reasons that are actually true. For the school beat, use something the district publishes, such as its three beliefs, Every Child a Reader, Families Are Partners and Teach for Tomorrow, Not for the Test. If no single reason comes to mind, say so plainly, then give the nearest honest one | The Skeptic scores motivation consistency, and F6 and F7 are what make a grade change need explaining. JD because it scores fit to this role |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about the 2024 move to a new reading curriculum on your grade level. What part of it was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F2 and F8, with the beats the sentence states: 2024, your grade level, a new reading curriculum, you led the move. Say it in your own words: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: if any part of the move's work was yours to decide, say which part and how you decided; if the move was set up by others, or you cannot separate your part, say so plainly and stay with the sentence | This is the one quoted sentence about shared work, so the peers will test it (F2, F8). EXP because it tests what was actually yours |
| B2 | "How do you handle credit when work spans several teachers?" | VAL | [generic] | Selection scaffold: pick a time you shared work with colleagues, and use "we" for context and "I" for your own contribution. It needs a named piece of shared work, a plain statement of your part, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit is a standard peer probe, and F8 is why it matters for you. VAL because it scores behavior with equals |
| B3 | "Tell me about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Selection scaffold: a specific disagreement about teaching, what you said, what the colleague said, and how it ended with the relationship intact. If no such time comes to mind, say so plainly, then say which principle you would use to decide rather than predicting an outcome | Peers price disagreement style (F8). Open prompt, so it supplies no event; VAL because it scores behavior |
| B4 | "What would you need from us in your first month, and what would you bring us?" | JD | [grounded] "I write a weekly email to families." "I've run the after-school reading club for the last two years" | Reciprocity, in two halves. Need: name what you would ask the two teachers, and the A2 list works. Bring: say only what your sentences carry, that you write a weekly email to families and have run the after-school reading club for two years, and offer them as things you could talk through, not as results. Answer slot: if either is something you have thought about sharing with a team, say how; if you have not, say so plainly and say what you would ask first | Peers price what a new hire adds to their load (F2, F4). JD because it scores working on the team |

### C. Case/Strategist (weight: medium to high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It is September and a student in your class reads well below grade level. What do you do in the first two weeks?" | CASE | [generic] | A live problem, so no claim about your past. Clarify first: what is known about the student, what reading information exists, what the school already uses, what the family has said. Then state the objective, the approach, how you would tell the family, and when you would check back. Ask what the school already uses before proposing your own approach. Challenge one premise respectfully | Reading instruction is a named panel topic, and the principal's public background is reading. CASE because it asks for structure on a problem from the actual role |
| C2 | "It is the second week of school. Which classroom routines do you teach first, and why?" | CASE | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | A plan, so name the first routines in your own words and why each comes first. Answer slot: if the routines you would teach are ones you set up in your own classroom, say which; if they came from the school or team, or you would choose differently for fourth grade, say so plainly | Routines are a named panel topic, and F3 has nothing in your material behind it. CASE because it is a decision, not a record |
| C3 | "The board adopted a three-year literacy plan this August. What stands out to you in it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Know the plan's published contents from the district news item: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Read as a search result, not the full page, so check it before Thursday. Say what stands out to you. If it is true for you, connect it with the one sentence you can stand behind: "In 2024 I led our grade level's move to a new reading curriculum." Let the panel draw any further inference. Answer slot: if you saw what changed after that move, say what you saw; if you did not, or it is too early to say, say so plainly and stay with the move | The one current-strategy question, built on research and tied to F2. CO because it scores whether you can think at the district's altitude |
| C4 | "A set of reading assessment results for your class comes back flat. What do you do with them?" | CASE | [grounded] | A live problem. Clarify what the assessment measured and what else you know about the students, read the results alongside what you see in class, decide what changes in teaching, and tell the families. Anchor in the district's belief: "assessments inform teaching and never replace it". Answer slot: if you have used results this way in your own classroom, say what you did and what changed; if you have not, say so plainly and say how you would | F9 has nothing in your material behind it, and the third belief makes this probe likely. CASE because it is a live problem, with VAL flavor |

### D. Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a student was not reading where they needed to be, and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold tied to Every Child a Reader: a specific student situation (no name), what you noticed, what you did, what changed. The club sentence is the one quote that touches reading outside lessons, so use it only if the instance really came from there. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 and F10 touch this belief without showing it. An open prompt themed on the published belief; VAL because it scores behavior against it |
| D2 | "Tell me about a time you worked through a concern with a family." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold tied to Families Are Partners: a specific concern, what the family said, what you did, how it ended. Where the belief says teachers speak with every family each term, hold your sentence at its own scope: "I write a weekly email to families." Answer slot: if you spoke with families directly, say how and how often; if you did not, say so plainly and stay with the email. If no such time comes to mind, say so plainly, then how you would handle it | F4 and F5 are where your sentence and the belief differ. VAL because it scores the second published belief |
| D3 | "Where do you land when a test score and what you see in your classroom disagree?" | VAL | [grounded] | State a position in your own words, anchored to the belief's wording: "assessments inform teaching and never replace it". Then a selection scaffold for an example: a specific moment, what each source said, what you decided. If no such moment comes to mind, say so plainly, then say how you would decide | F9 has nothing in your material behind it. VAL because it scores the third published belief |

### E. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey that brought you here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A 90-second arc from those four sentences, in that order, each at its own scope, ending on your answer to why now (the third beat of A4). Tell it in your own words and add nothing the sentences do not say | The casual opener is scored, and these are the rows it draws on (F7, F2, F4). EXP because it tests your own account of your path |
| E2 | "What is your after-school reading club reading these days?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Casual and scored. Name something specific the club is reading or doing this month, in your own words. If you cannot recall, say so plainly and describe what the club is for in your own words | Casual questions on hot panel topics are scored, and reading is the principal's field (F2). JD because it scores reading instruction asked casually |
| E3 | "What do you know about us?" | CO | [grounded] | Pick one or two published things and tie them to something you actually care about: the three beliefs by name, the panel's own stated topics, or the board's literacy plan. Do not recite the list, and do not build on anything about the interviewers beyond their public professional paths | A rapport interviewer scores homework depth. CO because it scores current knowledge of the district |
| E4 | "Just to confirm, your Illinois license and elementary endorsement are current?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | One sentence, then stop: "I hold an Illinois Professional Educator License with the Elementary Education endorsement for grades 1 through 6, registered and active through June 30, 2029." Have your licence details from your own records at hand in case HR asks to verify | F1 is the one condition the invite states, and knockout checks arrive in a friendly register. JD because it scores a stated requirement |

### F. Data-Driven Prober (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "What does the after-school reading club do, and how would you tell whether it is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe what it does in your own words. Answer slot: if you track anything, say what and how it was counted, and name the assumption behind it you would defend least; if you track nothing, say so plainly and say what you would look at. Never state a figure you cannot explain | F2 and F9 are the rows a prober presses. EXP because it tests what you can say about your own work |
| F2 | "Tell me about your weekly family email. Who receives it and what goes in it?" | EXP | [grounded] "I write a weekly email to families." | Say it in the quote's terms: you write it, and it is weekly. Answer slot: if you know how many families receive it or respond, say how you know; if you do not, say so plainly. Never supply a number you did not count | F4 is a CV line with nothing inspected behind it. EXP because it tests the claim |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence and endorsement | E4 |
| F2 reading instruction | B1, C1, C3, D1, E1, E2, F1 |
| F3 classroom routines | C2 |
| F4 how you work with families | B4, D2, E1, F2 |
| F5 speaking with every family each term | D2 |
| F6 fourth grade | A1, A2, A4 |
| F7 teaching across subjects | A1, A2, A4, E1 |
| F8 grade-level team | A3, B1, B2, B3, B4 |
| F9 assessment informing teaching | C4, D3, F1 |
| F10 reading plans by the end of third grade | D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal in 2022. What from that work shapes how you want fourth-grade reading to run?" | Ties to the principal's own path and turns the interrogation into a conversation about her work |
| R2 | "Your 2025 forum talk was on weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here today?" | Shows you looked at her public talks and asks instead of claiming familiarity |
| R3 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two teachers, who are pricing what you add to their load |
| R4 | "The board's literacy plan includes a new grades 3–5 reading curriculum from fall 2027. How will the fourth-grade team be involved, and what should a new teacher know before then?" | Draws on the published plan and signals you read it |
| R5 | "Each teacher speaks with every family each term. What does that look like in practice here, and how does the team share it?" | Draws on the published belief and shows you take Families Are Partners seriously |
| R6 | "References are taken up after the panel. What is the timeline from here?" | Draws on the district's own process page and answers something you need to plan around |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't taught fourth grade." Then a plan. No slot |
| Has been a team lead | Negative you stated, F8 | The plain acknowledgment: "I haven't been a team lead." Beside it, "I led our grade level's move to a new reading curriculum in 2024" at its own scope, never as a post |
| Chose or built the new reading curriculum | Inflated form of F2 | F2's sentence at its own scope. The limit is the pack's observation, not words for you: your material says the move, not what the curriculum was or who selected it. B1's slot stays inside the move |
| Speaks with every family each term | Inflated form of F4 and F5 | F5's sentence at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says the email, not conversations with each family. D2's slot stays inside the email |

## Sources

Provided documents: the interview invite and the CV text in your message. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three published beliefs by name, which theme the D bank. They also supply the quoted requirements in F5, F9 and F10 |
| 2. `Orrinsford Community School District interview process` | yes | The one 45-minute building panel of the principal and two grade-level teachers, and its three named topics. Persona weights follow. No values round is named, so no values cheat sheet is built |
| 3. `Orrinsford Community School District news strategic plan` | yes | C3 and R4, from the literacy plan item. Read as a search result only, not fetched in full |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | The interviewer read, R1 and R2. Read as a search result only. The two teammates were not named, so there is nothing on them |
| 5. representative `fourth grade teacher` JD | yes | F7 and F8, as unquoted `[inferred]` prose from one listing's snippet. Moved nothing that the invite and the district pages did not already fix, except the team and subject-range rows |

Searches sent, with what came back:

1. `Orrinsford Community School District mission values` returned https://orrinsfordschools.example/about/mission-and-beliefs
2. `Orrinsford Community School District Halvering Elementary interview process teacher` returned https://orrinsfordschools.example/careers/how-we-hire-teachers
3. `Orrinsford Community School District news strategic plan` returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. `Dolores Vantongeren principal Halvering Elementary` returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. `fourth grade teacher job description Illinois elementary` returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: the mission page at https://orrinsfordschools.example/about/mission-and-beliefs and the hiring page at https://orrinsfordschools.example/careers/how-we-hire-teachers.

## Upgrade menu

- The full job posting: F7 and F8 become quoted requirements instead of `[inferred]` prose, and the JD-tagged questions are rebuilt on the district's own wording
- Anything HR said beyond the invite, such as a demo lesson, a sample to bring or topics to cover: a declared deliverable gets its own build section
- Your own answers to the answer slots in F2, F3, F5, F8, F9 and F10: those rows become `[grounded]` story maps, and the guidance cells that lean on them can be rewritten around what you actually did
- The names of the two fourth-grade teammates: peer persona weights can be read from any public professional footprint, and a reverse question can be tailored to them
- A printout or screenshot of your licence's public registry record: F1 can move from `medium` to `high`, because a registry record is the inspectable artifact for a licence
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes: a grounding brief on the literacy plan and any recent district context, the principal's other public talks, and role-family loop reports. Say the word and I will run it
- A tuesday-dossier.md from an earlier underwriting pass: verified evidence, graded gaps and prohibited claims arrive pre-checked, and it is never a prerequisite
