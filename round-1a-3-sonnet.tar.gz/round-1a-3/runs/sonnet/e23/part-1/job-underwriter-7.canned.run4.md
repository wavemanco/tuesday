I'm reading the skill's remaining reference files, then I'll run the budgeted research on Calderbrook and the role. After that I'll write the assessment.
**Yes, apply. Status: `go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5a, R6a, R7, R10 · unclear: R4 (clear, timely written records)
- `important` — adjacent: R5b (leg-ulcer care), R9 (own small caseload) · unclear: R6b (continence care), R8 (end-of-life visits), R11 (electronic patient record)
- `preferred` — absent: R12 (Doppler assessment)

R9 (`medium`) is new to you but the post is supported; R12 is desirable only, and the team lead has spoken publicly about training staff in it (RR3); R4 and R8 are silences in your CV that you may be able to fill from existing work.

**Opportunity ledger.** The role looks defined and openly paid (RR2, RR4). Open items are whether the post is live on the employer's own site (RR1), the rota (RR5) and the terms attached to a CIC (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a closed or unverifiable posting (RR1), or a rota or terms that clash with constraints you haven't told me (RR5, RR6).

Your National Insurance number isn't needed to assess a role, so I haven't used it. Keep it off applications until an employer asks at offer stage.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page, calderbrookhealth.example/about |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Working pattern | Pool cars provided plus mileage; hours, rota and on-call not stated | `[grounded]` advert, silence noted |
| Scope read | A conventional entry-level community post; support is stated and the caseload is small | `[inferred]` from "small caseload" and "supported by a senior community nurse" |
| Pay | £31,050–£37,800 plus mileage. Survey of Band 5 community staff nurses in England: median £34,300, interquartile range £32,400–£36,600; 24% had a pool or lease car | `[grounded]` advert; `[generic]` Wardround 2026 pay guide (a survey pattern, not this employer's offer) |
| Market calibration | Title, seniority and range sit in line with role-family norms; the posted range encloses the survey's interquartile range | `[generic]` Wardround 2026 pay guide |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at the 2025 forum she spoke on nurse-led leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` communitynursingforum.example/speakers/rhiannon-mabbott |
| Unknowns | Rota and on-call; caseload size; employment terms beyond salary; whether the post is open | — |
| Contradictions | None found between the advert and the About page; the careers page could not be read (RR1) | `[grounded]` About page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | CV states a PIN and active registration. Stated, not yet checked against the public register | `[grounded]` CV | Optional: check the NMC register entry to raise to `high` |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states category B; pool cars remove any car-ownership question | `[grounded]` CV; advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, per the CV | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | Ward nursing involves records, but the CV says nothing about documentation quality or audit | `[grounded]` CV silence | See G1 |
| R5a | Wound care | must_have | direct | medium | none | CV names pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | adjacent | low | transferability | Pressure-ulcer and surgical-wound care carries over. Limit: the CV shows no compression therapy or leg-ulcer assessment | `[inferred]` adjacency from wound care on the CV | See G3 |
| R6a | Catheter care | must_have | direct | medium | none | CV names catheter care | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | CV does not mention it | `[grounded]` CV silence | See G5 |
| R7 | Insulin administration | must_have | direct | medium | none | CV names it | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | low | discovery | CV silent; acute medical wards may involve end-of-life care, but nothing is stated | `[grounded]` CV silence; `[generic]` that acute medical wards may involve it | See G2 |
| R9 | A small caseload of your own | important | adjacent | medium | transferability | You told me you have never held your own caseload. Adjacent: 18 months visiting patients at home in their first week after discharge. Limit: short-episode follow-up, not an ongoing caseload | `[grounded]` CV and your statement | See G4 |
| R10 | Nursing housebound adults in their own homes | must_have | direct | medium | none | The discharge-to-assess secondment is home visiting. Limit: first-week visits, not long-term housebound care | `[grounded]` CV | none |
| R11 | Electronic patient record | important | unclear | low | discovery | CV does not say what record system you used | `[grounded]` CV silence | See G1 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have not done one. The advert lists it as desirable only | `[grounded]` your statement; advert | Closure path in G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and the electronic patient record (R4, R11) | discovery | The CV says nothing about documentation or record systems | R4 is an essential; the advert says records are clear and timely | An electronic record used on the ward or in the D2A team; documentation audits; handover or discharge paperwork you owned | An audit result, or a reference naming your record-keeping | `[grounded]` CV silence |
| G2 | End-of-life care (R8) | discovery | Nothing in the CV | Visits are part of the post, and interviewers usually probe this | Last-days care planning; anticipatory medication; supporting a family; a preferred-place-of-death discharge | A reflective account or a reference | `[grounded]` CV silence; `[generic]` that interviewers probe it |
| G3 | Leg-ulcer care (R5b) | transferability | Wound care is present; leg-ulcer care is not | Leg-ulcer care is a named part of the job | Compression bandaging; leg-ulcer assessment during D2A visits; training attended | A training certificate or competency record | `[inferred]` bridge from wound care |
| G4 | Own caseload (R9) | transferability | Home visits in the D2A team, but no caseload of your own | The post carries a small caseload, with support | Planning your own day of visits; prioritising a list; escalating to a senior | A job description of the secondment | `[inferred]` bridge from D2A work |
| G5 | Continence care (R6b) | discovery | Catheter care is present; continence is not stated | The advert pairs the two | Bladder or bowel assessments; continence products; catheter-removal trials | A competency record | `[grounded]` CV silence |
| G6 | Doppler assessment (R12) | capability | You have not done one | Desirable only. The team lead's published talk on Doppler training for new community staff suggests it is trainable on the job (RR3) | — | — | `[grounded]` your statement; `[inferred]` trainability from RR3 |

For G6 the closure path is to ask in the informal chat whether Doppler training is provided. Do not claim any Doppler experience.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | About page: "Current vacancies are listed on our careers page" | The post may be open, closed, or listed at a different address; the careers page I tried returned nothing | `[grounded]` fetch of calderbrookhealth.example/careers returned no page; the URL was my guess, so this settles nothing | Is this post currently open, and what is the closing date? | unresolved |
| RR2 | Support and scope stated | positive_signal | — | "supported by a senior community nurse" | A small caseload with named support is a gentler start | `[grounded]` advert | Who is the senior nurse, and how often are caseload reviews? | noted |
| RR3 | Team lead's published interest in training newcomers | positive_signal | — | Speaker page: "Doppler training for staff new to community work" | Doppler may be taught after joining | `[grounded]` forum speaker page | Is Doppler training provided, and how soon after joining? | noted |
| RR4 | Pay stated openly | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posted range encloses the survey's interquartile range; where you would start in it is unknown | `[grounded]` advert; `[generic]` survey band | Where in the range would someone with five years' experience start? | unresolved |
| RR5 | Rota, on-call and caseload size unstated | unknown | — | "end-of-life visits" | Community nursing commonly has weekend or out-of-hours elements | `[generic]` role-family pattern, not a claim about this employer | Does the rota include weekends, evenings or on-call, and how many patients make up a caseload? | unresolved |
| RR6 | Employment terms beyond salary unstated | unknown | — | "Community Health CIC"; "under an NHS contract" | Pension, leave and sick pay may or may not follow NHS terms | `[inferred]` from CIC status and the contract wording | Are terms and conditions the same as NHS Agenda for Change? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the D2A secondment, worded as home visiting after discharge. Do not describe it as a caseload | R9, R10; avoids overstating | `[grounded]` CV | pending your approval |
| E2 | Move wound care, catheter care and insulin administration up to the top of the CV, with your existing wording and no added facts | R5a, R6a, R7 | `[grounded]` CV | pending your approval |
| A1 | Take the informal chat with Rhiannon Mabbott and ask the RR1, RR3, RR5 and RR6 questions | The advert invites it; her talks cover leg ulcers and Doppler training | `[grounded]` advert; forum speaker page | pending your approval |
| A2 | Say plainly you have not held a caseload or done Doppler, and ask how both are taught | Candour plays well with a supported post | `[inferred]` from the supported structure | pending your approval |

Your approval of these proposals covers the advice above as well as the table. Nothing goes into your CV or any message until you say so.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 district nursing vacancy"; both returned the About page (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved: role reality's organization row, RR1 (live posting unconfirmed) |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary 2026 Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the hiring-contact row, RR3, A1 |

I offer to write `tuesday-dossier.md` from this assessment if you want to keep it.

## Upgrade menu

- A link to the live posting on Calderbrook's own site → RR1 closes.
- A copy of any documentation audit, competency record or training certificate → R4, R5b, R6b move toward `medium`.
- Your own non-negotiables (pay floor, days, no weekends) → the hard-gates line can be checked against them.
- An NMC register check on your PIN → R1 rises to `high`.
- A deeper research pass on Calderbrook (public staff reports, leadership and funding news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. Constraints — do you have any firm limits on pay floor, working days, hours or weekend work? Answer in text, or say skip.
2. G1 — Which record system did you use on the ward or in the D2A team, and has your documentation ever been audited or praised? Answer in text, attach a document, or say skip.
3. G2 — Have you cared for dying patients and their families, and what did you personally own, for example anticipatory medication or a preferred-place-of-death discharge? Answer in text, paste a voice transcript, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.