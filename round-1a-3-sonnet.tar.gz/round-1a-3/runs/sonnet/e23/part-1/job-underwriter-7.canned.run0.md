I'll read the reference files this skill requires before building the assessment.
Reading is done. Next I'll check the employer and the Band 5 pay range with a few targeted searches, then write up the assessment.
**Yes, this is worth applying for. Status: `go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5 · unclear: R4 (Clear, timely written records)
- `important` — direct: R7a, R9a · adjacent: R6 (Wound and leg-ulcer care), R10 (Own small caseload) · unclear: R7b (Continence care), R8 (End-of-life visits), R9b (Care planning), R11 (Electronic patient record)
- `preferred` — absent: R12 (Doppler assessment)

R6, R10 — credible bridges, limits named; R4, R7b, R8, R9b, R11 — your CV is silent, which is not the same as absent; R12 — a desirable item you don't have.

**Opportunity ledger.** The role looks real and well supported. Pay is in line with the market (RR3), and a senior nurse and pool cars are promised (RR5). Four things are unconfirmed: the live posting (RR1), the contract terms (RR2), the hours (RR4) and the grade against your experience (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the post turning out to be closed (RR1), or terms far from what you'd accept (RR2, RR4, RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` About page, calderbrookhealth.example/about |
| Role | Band 5 district nursing post covering housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, on an electronic patient record | `[grounded]` JD |
| Support and resources | A small caseload of your own, backed by a senior community nurse; pool cars provided; mileage paid | `[grounded]` JD |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page, communitynursingforum.example/speakers/rhiannon-mabbott |
| Scope read | Doppler is listed as desirable, and the team lead has spoken publicly on training newcomers to it, so it may be taught on the job. That is a reading, not a promise | `[inferred]` from the JD's "desirable" tier and the speaker page |
| Market calibration | A 2026 survey puts community Band 5 nurses at a median £34,300, interquartile range £32,400–£36,600. 61% of respondents were paid mileage and 24% had a pool or lease car. A pattern, not this employer's offer | `[generic]` Wardround 2026 UK Community Nursing Pay Guide; `[grounded]` JD for the posted £31,050–£37,800 |
| Unknowns | First-year outcomes; caseload size; hours, weekend and evening rota; contract terms; which electronic record system; what training is provided | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the About page. The posting itself was not confirmed on the employer's site (RR1) | `[grounded]` About page read; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration with a PIN and revalidation due March 2028. Nothing has been checked against the register, so `medium` | `[grounded]` CV | Look up your own NMC register entry to raise it to `high` |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. No document inspected | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical ward staff nurse, against a one-year minimum | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | Nothing in the CV speaks to documentation. A ward nurse and a discharge-team nurse will have kept records, but I won't present that as your claim | `[grounded]` CV silence; `[inferred]` that ward and discharge work involve records | See G4 |
| R5 | Caring for adults in their own homes | must_have | direct | medium | none | 18 months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: those are recently discharged patients, not long-term housebound ones | `[grounded]` CV | none |
| R6 | Wound and leg-ulcer care | important | adjacent | medium | transferability | Wound care including pressure ulcers and surgical wounds carries over. Leg-ulcer care, which usually involves compression therapy, is not in your CV | `[grounded]` CV; `[generic]` that leg-ulcer care is its own skill set | See G2 |
| R7a | Catheter care | important | direct | medium | none | Stated plainly in the CV | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | The CV does not mention it | `[grounded]` CV silence | See G1 |
| R8 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Acute medical wards often care for dying patients, but your CV doesn't say you did | `[grounded]` CV silence; `[generic]` about acute medical wards | See G1 |
| R9a | Insulin administration | important | direct | medium | none | Stated plainly in the CV | `[grounded]` CV | none |
| R9b | Care planning | important | unclear | low | discovery | The CV does not mention planning care, as opposed to delivering it | `[grounded]` CV silence | See G1 |
| R10 | A small caseload of your own, supported by a senior nurse | important | adjacent | medium | transferability | Home visiting on the discharge team is adjacent. You say you have never held your own caseload, so that limit is named wherever the bridge is used | `[grounded]` CV and your statement | See G3 |
| R11 | Using an electronic patient record | important | unclear | low | discovery | The CV names no record system | `[grounded]` CV silence | See G4 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. It is desirable, not essential, and the team lead has spoken on training newcomers to it | `[grounded]` your statement; `[inferred]` that training may be offered | Ask in the informal chat (A1); never claim it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Continence, end-of-life and care planning (R7b, R8, R9b; important) | discovery | The CV names catheter care and insulin but not these three duties | They are named duties in the advert, and your CV might already cover them without saying so | Caring for dying patients on the ward or helping a family at the end; bladder or bowel care beyond catheters; writing or updating a care plan or discharge plan | A discharge plan you wrote, an end-of-life care record template, or a reflective account | `[grounded]` CV silence; `[generic]` that the ward and discharge work plausibly touched them |
| G2 | Leg-ulcer care (R6; important) | transferability | Pressure ulcer and surgical wound care, no leg ulcers or compression | The advert names leg-ulcer care and Doppler together, so it is the clinical centre of the post | Compression bandaging, or a leg or foot wound you managed, even once | A wound assessment chart, or a training record | `[grounded]` CV; `[inferred]` that this is the main clinical learning curve |
| G3 | Working alone on a caseload (R10; important) | transferability | Home visits on the discharge team, but no caseload of your own | The advert says you will hold a small caseload | Deciding visit frequency, escalating to a GP or consultant, closing a patient's episode | A role description for the secondment, or a reference from its lead | `[grounded]` your statement; `[inferred]` that the secondment involved some of these decisions |
| G4 | Records and the electronic record (R4, R11) | discovery | No documentation or system named | The advert asks for clear, timely records on an electronic patient record | Which record system the ward and discharge team used; any record-keeping audit | System name, an audit result, or a reference line | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The post may be listed on a different page: the address I tried was a guess and returned nothing | `[inferred]` from the failed fetch | Is this post currently open, and when does it close? | unresolved |
| RR2 | Contract terms unstated | unknown | — | "Band 5 … £31,050–£37,800 a year plus mileage" | A community interest company may hold the contract on NHS terms or on its own. Pension, sick pay and leave could differ | `[generic]` pattern for providers working under NHS contracts | Is this post on NHS Agenda for Change terms, with NHS Pension Scheme membership? | unresolved |
| RR3 | Salary stated and within market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posted range brackets the survey's interquartile range | `[grounded]` JD figure; `[generic]` survey band | Where on the range would my experience place me? | noted |
| RR4 | Hours and out-of-hours unstated | unknown | — | "end-of-life visits" | End-of-life care may need evening or weekend visits | `[generic]` pattern for district nursing | What are the working hours, and is there a weekend or evening rota? | unresolved |
| RR5 | Support and resources named | positive_signal | — | "supported by a senior community nurse"; "pool cars are provided" | A new caseload holder is not left unsupported and travel is covered | `[grounded]` JD | What does the support look like in the first three months? | noted |
| RR6 | Band 5 against five years' experience | unknown | — | "at least one year's post-registration experience" | The grade may be a step sideways if you are already at or above Band 5 | `[inferred]` from your five years against a one-year minimum; your current grade was not given | Is there a route to Band 6, and what does it take? | unresolved |

## Application plan

Every row is proposed, not final. The CV language in E1 and E2 was audited clause by clause against your own sentences and adds no facts.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the secondment, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | R5 | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | List your clinical skills in the advert's order, using only your words: "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" | R6, R7a, R9a | `[grounded]` CV | `resume_edits_pending_approval` |
| E3 | Do not write leg-ulcer care, Doppler, end-of-life care, care planning, an electronic record system or a caseload of your own on the CV until you confirm them | R4, R6, R7b, R8, R9b, R10, R11, R12 | `[grounded]` map rows | pending your approval |
| A1 | Take up the advert's invitation to an informal chat with Rhiannon Mabbott and ask RR1, RR2, RR4 and RR6 verbatim. Add one more: whether Doppler training is provided to staff new to community work | The register doubles as your question list | `[grounded]` JD invitation, speaker page | pending your approval |
| A2 | In the application and chat, state the two limits plainly in your own words: you have never held your own caseload and have never done a Doppler assessment | R10, R12. Stating a limit first leaves less to be found out at interview | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: all CV claims, which are self-report until you confirm them or an artifact is read. Your National Insurance number isn't needed to evaluate a role, so I haven't used it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page at that address. Moved role reality's organization and contradictions rows and RR1. The employer is established as described and the posting is not confirmed live |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing Agenda for Change pay scale 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the scope read and A1. Public professional footprint only |

I can save this as a `tuesday-dossier.md` if you'd like one to carry forward.

**Upgrade menu**
- A check of your own NMC register entry, or a scan of your licence → R1 and R2 can reach `high`.
- Answers on continence, end-of-life and care planning, with a care plan or discharge plan you wrote → R7b, R8 and R9b move to `direct` or stay as named gaps (G1).
- Any record of compression bandaging or leg-wound care → R6's bridge narrows (G2).
- A reference line or role description for the secondment → R10's bridge firms up (G3).
- The record system you used and any audit result → R4 and R11 close (G4).
- The careers page link or recruiter's email → RR1 closes.
- A deeper research pass on Calderbrook (contract basis, staffing, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Have you cared for dying patients, done bladder or bowel care beyond catheters, or written or updated a care plan or discharge plan? What was your part in each?
G3 — On the discharge team, who decided how often a patient was visited and when to escalate or close them? Was that you?
C1 — Do you have a pay floor, hours you can't work, or a current grade I should weigh against Band 5? I've treated your constraints as not given.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.