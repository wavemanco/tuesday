I've read the skill's rules and I'm now loading the web search tool so I can check that the employer and the posting are real before I write the assessment.
**Yes, this is worth applying to: `conditional_go`. You meet both stated gates, and the gaps are about training and evidence, not eligibility. The one condition that matters first is confirming the vacancy is still open.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (clear, timely written records)
- `important` — direct: R5, R6, R8, R10 · adjacent: R7 (leg-ulcer care), R13 (own small caseload) · unclear: R9 (continence care), R11 (care planning), R12 (end-of-life visits)
- `preferred` — absent: R14 (Doppler assessment)

R7 and R13 are credible bridges with limits named in the map. R14 is the one thing you have said you haven't done, and it is only desirable.

**Opportunity ledger.** The employer exists and the pay is in range (RR3), the senior-nurse support is explicit (RR2), and the team lead's public footprint matches the advert. Whether the post is still live is unconfirmed (RR1), and hours, contract basis, mileage and Doppler training are not stated (RR4, RR5, RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the vacancy is confirmed live (RR1); (2) your record-keeping, including electronic records, can be evidenced (R4, G1); (3) the leg-ulcer and caseload bridges are framed honestly as adjacent (R7, R13).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` About page, found by search |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| First 90 days and first year | Not stated | `[grounded]` advert silent |
| Scope read | A Band 5 post with a small caseload and a named senior supporter looks like a normal entry route into community nursing, not an overloaded one | `[inferred]` from the advert's support wording |
| Market calibration | Band 5 community staff nurses in England have a median basic pay of £34,300, interquartile range £32,400 to £36,600. The advert's £31,050–£37,800 brackets that median. Basis: one 2026 pay survey (n=1,240), a pattern and not this employer's offer | `[generic]` survey; `[grounded]` advert figure |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team at Calderbrook, after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Unknowns | Whether the vacancy is live; hours and contract basis; Doppler training provision; how mileage works alongside pool cars | `[grounded]` advert silent |
| Contradictions | None between the advert and the contact's public profile. The careers page was not confirmed (RR1) | `[grounded]` search results; fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states registered nurse (adult), PIN given, active, revalidation due March 2028. Self-reported, and the public NMC register would let you or an employer inspect it | `[grounded]` CV | none |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. Nothing inspectable yet | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is graded on fit, not as a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records (on an electronic patient record) | must_have | unclear | low | discovery | CV says nothing about documentation or electronic records, so nothing is claimed for you | `[grounded]` CV silence | question G1 |
| R5 | Care for housebound adults in their own homes | important | direct | medium | presentation | 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. The CV could lead with this | `[grounded]` CV | edit E1 pending approval |
| R6 | Wound care | important | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and wound experience carries over. Limit: nothing stated on leg-ulcer assessment or compression, which is a different wound type. Strengthener: any leg-ulcer patients you dressed or reviewed | `[grounded]` CV wound care; `[inferred]` adjacency | see G4 |
| R8 | Catheter care | important | direct | medium | none | CV: catheter care | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | The CV names catheter care only; continence care is wider and is not claimed | `[grounded]` CV | question G3 |
| R10 | Insulin administration | important | direct | medium | none | CV: insulin administration | `[grounded]` CV | none |
| R11 | Care planning | important | unclear | low | discovery | CV silent on care planning | `[grounded]` CV silence | question G3 |
| R12 | End-of-life visits | important | unclear | low | discovery | CV silent. An acute medical ward may have involved dying patients, but nothing says you did, so no claim is made | `[grounded]` CV silence | question G2 |
| R13 | A small caseload of your own, supported by a senior nurse | important | adjacent | medium | transferability | Bridge: home visits to discharged patients in D2A. Limit: you have said you have never held your own caseload, so carrying and prioritising one is new. The advert's senior support is how it narrows | `[grounded]` your statement and CV; `[grounded]` advert | see G5 |
| R14 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have never done one. No direct or adjacent evidence exists, so it is carried as a minor risk given its preferred priority | `[grounded]` your statement | closure path in G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | A must-have the CV does not address | The advert lists clear, timely records as essential, and every task is recorded on an electronic record | Your ward's electronic observation or notes system; D2A visit notes or handover records; any documentation audit | A record-keeping audit result, a reference mentioning your documentation | `[grounded]` CV silence; `[generic]` that community roles weight records heavily |
| G2 | End-of-life visits (R12, important) | discovery | Not stated | Home end-of-life care is a named duty | Caring for dying patients on the ward; anticipatory care or discharge to die at home; supporting families | A reference, a thank-you card, a ward end-of-life training record | `[grounded]` CV silence |
| G3 | Continence care and care planning (R9, R11, important) | discovery | Catheter care is stated; the rest is not | Both are named in the advert | Bladder or bowel assessments; contributing to discharge or D2A care plans | Care plan templates you completed (anonymised), training records | `[grounded]` CV silence |
| G4 | Leg-ulcer bridge (R7, important) | transferability | Pressure-ulcer and surgical-wound care, no leg-ulcer evidence | The team lead has publicly spoken on leg-ulcer clinics, so this is likely a focus | Dressing or reviewing leg ulcers, compression bandaging, tissue viability teaching | Training certificate, a tissue viability referral record | `[inferred]` from the speaker page |
| G5 | Caseload bridge (R13, important) | transferability | D2A visits, no own caseload | Prioritising and planning a caseload is the day-to-day job | Planning your own D2A visit list; deciding visit order or escalating | A D2A rota or visit-planning example | `[grounded]` your statement |
| G6 | Doppler (R14, preferred) | capability | No evidence, by your own account | Desirable only, but it is the likeliest topic the team lead will raise | A closure path, not an experience: ask about training | Not applicable until training | `[grounded]` your statement; `[inferred]` that it is likely to come up |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not confirmed on the employer's own careers page | unknown | — | "Current vacancies are listed on our careers page" (About page) | The page I tried may simply not be the right address, or the vacancy may have closed | `[inferred]` from the failed fetch; `[generic]` that adverts are sometimes stale | Is this vacancy still open, and what is the closing date? | unresolved |
| RR2 | Senior-nurse support for a new caseload | positive_signal | — | "supported by a senior community nurse" | Reduces the risk of carrying a caseload alone | `[grounded]` advert | Who would the senior nurse be, and how much time do they have for new starters? | noted |
| RR3 | Advertised pay against the market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Range brackets the surveyed England median for a Band 5 community nurse | `[grounded]` advert; `[generic]` survey | Where on the range would five years' hospital experience be placed? | noted |
| RR4 | Hours, on-call and contract basis unstated | unknown | — | None: the advert is silent | Community nursing often involves weekends or extended hours; whether it applies here is unknown | `[generic]` role-family pattern | What are the working hours and weekend or out-of-hours expectations, and is the post permanent? | unresolved |
| RR5 | Mileage alongside pool cars | unknown | — | "pool cars are provided" and "plus mileage" | Mileage may apply to personal-car use only, to travel to hubs, or to out-of-hours work | `[inferred]` from the two phrases together | When is mileage paid, given pool cars are provided? | unresolved |
| RR6 | Doppler training provision | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The employer may train new starters, since the team lead has spoken on Doppler training for staff new to community work | `[inferred]` from the speaker page | Is Doppler training provided to new starters, and how soon after joining? | unresolved |

## Application plan

Every row is proposed and none is applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Use the advert's invitation to chat with Rhiannon Mabbott before applying, and ask RR1, RR4 and RR6 | The register doubles as interview preparation | `[grounded]` advert | pending your approval |
| E1 | Move your discharge-to-assess secondment to the top of the CV, in your own words: "Seconded for the last 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | Directly matches the advert's home-visiting core (R5) | `[grounded]` CV | pending your approval |
| E2 | Group "wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" in a skills line near the top, with no additions | These match the advert's named tasks (R6, R8, R10) | `[grounded]` CV | pending your approval |
| E3 | In the supporting statement, say plainly that you have not yet done a Doppler assessment | An honest statement reads better than silence, since the team lead has spoken on this topic | `[grounded]` your statement; `[inferred]` on how it will be received | pending your approval |
| A2 | Hold any record-keeping, end-of-life or continence line until you answer G1 to G3 | Nothing can be claimed from CV silence | `[grounded]` map rows R4, R9, R11, R12 | pending your approval |

## Evidence status

Verified: none yet. Everything above comes from the CV and your message, so it is self-reported; the public NMC register entry would inspect R1.

Your National Insurance number isn't needed to judge fit and I haven't used it. Leave it off the application until an employer asks for it at the offer stage.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page, so the live posting is unconfirmed. Moved: the organization row and RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change 2026 Doppler leg ulcer", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the hiring-contact row, G4, RR6 and A1 |

## Dossier offer

If you want a saved record of this assessment, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your NMC register entry or a licence check code → R1 and R2 move from `medium` to `high`.
- Answers to G1 to G3 → R4, R9, R11 and R12 can move from `unclear`, and the record-keeping condition can close.
- Any leg-ulcer dressing or tissue viability record → R7's bridge strengthens.
- The recruiter's answers on RR1, RR4 and RR5 → the open entries close.
- A deeper look at Calderbrook (staff and patient reports, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

G1 — On your ward and in D2A, how did you record patient care, and have you used an electronic patient record? Is there any audit or feedback on your documentation?
G2 — Have you cared for dying patients, or helped arrange for someone to die at home? What was your own part in it?
G3 — Beyond catheters, have you done continence assessments or helped write care plans, for example in D2A? What did you do yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.