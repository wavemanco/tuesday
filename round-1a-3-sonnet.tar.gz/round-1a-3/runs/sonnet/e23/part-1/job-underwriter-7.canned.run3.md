I'll read the reference files the skill names before building the assessment.
# Job Underwriting Assessment: Community Staff Nurse, Band 5, Calderbrook Community Health CIC

## Decision snapshot

**Yes, this one is worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R6, R8, R9 · adjacent: R5 (Care of housebound adults at home) · unclear: R4 (Clear, timely written records), R7 (Leg-ulcer care), R10 (End-of-life visits)
- `important`: adjacent: R13 (Own small caseload) · unclear: R11 (Continence care), R12 (Care planning)
- `preferred`: absent: R14 (Doppler assessment)

R5, R13: home visiting on discharge-to-assess is the bridge, with its limits named; R4, R7, R10, R11, R12: your CV is silent, and recall could recover them; R14: a training gap on a `preferred` row, not an eligibility bar.

**Opportunity ledger.** Support and pay look sound: the senior-nurse backing and pool cars are stated (RR4) and the pay range is stated (RR3). The posting itself is not yet confirmed live (RR1) and hours are unstated (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The vacancy is confirmed open on Calderbrook's own site or by the named lead (RR1).
  2. Your answers on R7 and R10 decide how the CV is framed, not whether you apply. Anything you have done goes on, and anything you have not stays off.
  3. Doppler (R14) is framed as a training need, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` "About Calderbrook Community Health" search result; page not fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse; pool cars provided | `[grounded]` advert |
| Scope read | A post that expects some newcomers to community work, because it pairs a caseload with named senior support and lists Doppler as desirable rather than essential | `[inferred]` from the advert's support and desirable wording |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. In 2025 she spoke at a community nursing forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker-profile search result |
| Market calibration | Band 5 community staff nurse, England: survey median £34,300, interquartile range £32,400 to £36,600 (n=1,240). This advert's £31,050–£37,800 spans that range. The survey is a pattern, not this employer's offer. | `[generic]` Wardround 2026 pay guide, from the search snippet; `[grounded]` advert for the range |
| Unknowns | Hours and rota; first-year expectations; how caseload builds up; whether Doppler training is provided | `[inferred]` from the advert's silence on each |
| Contradictions | None between the advert and the About page; the vacancy itself was not found on a careers page (RR1) | `[grounded]` About page snippet; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. I have not checked the NMC register, so there is no inspectable proof yet | `[grounded]` CV | You can check your own register entry; the employer will |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B; nothing inspected | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is graded as fit, not as a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | none | discovery | CV is silent on records and on electronic systems. Community teams usually lean on records because visits are unsupervised | `[grounded]` CV silence; `[generic]` community-nursing pattern | Question G3 |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge. Limit: the CV does not show ongoing care of housebound patients over time | `[grounded]` CV | Bridge case in G5 |
| R6 | Wound care | must_have | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds. Leg ulcers are separate (R7) | `[grounded]` CV | none |
| R7 | Leg-ulcer care | must_have | unclear | none | discovery | Leg ulcers are not mentioned; wound care generally does not establish them | `[grounded]` CV silence | Question G1 |
| R8 | Catheter care | must_have | direct | medium | none | CV states catheter care | `[grounded]` CV | none |
| R9 | Insulin administration | must_have | direct | medium | none | CV states insulin administration | `[grounded]` CV | none |
| R10 | End-of-life visits | must_have | unclear | none | discovery | CV is silent on end-of-life care. An acute ward may well have given you some, which is a recall prompt, not a claim | `[grounded]` CV silence; `[inferred]` that a ward setting may hold relevant experience | Question G2 |
| R11 | Continence care | important | unclear | none | discovery | Not stated; only catheter care is | `[grounded]` CV silence | Queue G4 |
| R12 | Care planning | important | unclear | none | discovery | Not stated on the CV | `[grounded]` CV silence | Queue G4 |
| R13 | Holding a small caseload of your own | important | adjacent | medium | transferability | You told me you have never held your own caseload; home visits on discharge-to-assess are the adjacent work. The advert pairs the caseload with senior support | `[grounded]` your statement and CV; advert | Bridge case in G5 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You told me you have never done one. The team lead has spoken on Doppler training for staff new to community work | `[grounded]` your statement; speaker-profile result | Closure path in G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7, must_have) | discovery | Wound care is stated; leg ulcers are not | A named duty in the advert, and the team lead's own speciality | Dressing or compressing a venous leg ulcer; wound assessment that reached a leg-ulcer patient; a tissue-viability referral | A competency record or training certificate | `[grounded]` CV silence; `[grounded]` team lead's talk topic |
| G2 | End-of-life visits (R10, must_have) | discovery | CV is silent | A named duty; resolving it moves a must-have off `unclear` | Caring for dying patients on the ward; being present at a rapid discharge home to die; supporting families | A training record or reflective note (kept anonymised) | `[grounded]` CV silence; `[inferred]` ward setting may hold relevant experience |
| G3 | Records and electronic patient record (R4, must_have) | discovery | CV is silent on documentation | An essential in the advert and the one that reads as a screening criterion | Using an electronic record on the ward or on discharge-to-assess; audits of your notes; documenting visits made alone | A named system on the CV; an audit result | `[grounded]` CV silence; `[generic]` records are a standard community focus |
| G4 | Continence care and care planning (R11, R12, important) | discovery | Neither is on the CV | Important, not essential; could still sharpen the CV | Bladder or bowel care plans; discharge care plans written for the discharge-to-assess team | A care-plan template you used (anonymised) | `[grounded]` CV silence |
| G5 | Home care and own caseload (R5, R13) | transferability | Discharge-to-assess visits carry over; the CV does not show ongoing housebound care or a caseload | The bridge to this role. The limit is that visits were in the first week after discharge and not a standing caseload | Following the same patients across visits; deciding visit order; escalating a deterioration | A discharge-to-assess team description or referral numbers | `[inferred]` bridge derived from the CV's secondment line |
| G6 | Doppler assessment (R14, preferred) | capability | Not done, confirmed by you | Preferred, so a closure path matters more than a verdict | A short Doppler course; an in-post training agreement with the team | A course booking or certificate | `[grounded]` your statement; `[grounded]` team lead's talk on Doppler training for new community staff |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not yet confirmed live | risk_signal | low | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer exists as described, but the vacancy may sit on a different address or job board, or have closed. A guessed careers address returned no page, which is weak evidence | `[grounded]` About page lists vacancies on a careers page; fetch of the address I tried returned no page; `[generic]` vacancies are often posted elsewhere | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Hours and rota unstated | unknown | — | "end-of-life visits" | The post may involve weekend or out-of-hours work, since end-of-life care often needs it | `[generic]` pattern for community nursing; `[inferred]` from the advert's silence | What are the working days and hours, and is there a weekend or out-of-hours rota? | unresolved |
| RR3 | Pay stated and in line with the survey band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is stated openly and spans the survey interquartile range | `[grounded]` advert; `[generic]` survey band | Which point in the range would I start on, given five years' registered experience? | noted |
| RR4 | Support and pool cars stated | positive_signal | — | "supported by a senior community nurse"; "pool cars are provided" | Scope is a supported caseload, not a solo one | `[grounded]` advert | How is a new community nurse's caseload built up, and is Doppler training provided? | noted |

## Application plan

All rows below are proposals, and the status in each row covers its advice as well as its wording.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: move the discharge-to-assess secondment to the top, in your own words ("seconded 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge"), with wound care, catheter care and insulin administration beside it | see R5, R6, R8, R9 | `[grounded]` CV | pending your approval |
| E2 | Keep leg-ulcer care, end-of-life care, Doppler assessment and "caseload" off the CV unless you confirm each from your own experience | see R7, R10, R13, R14 | `[grounded]` CV silence and your statements | pending your approval |
| A1 | Take the advert's offer of an informal chat with Rhiannon Mabbott before applying, and use it for RR1–RR4. If Doppler comes up, say plainly that you have not done it and would want the training | The advert invites the chat; her talk topics suggest Doppler training exists for staff new to community work | `[grounded]` advert; speaker-profile result | pending your approval |
| A2 | Ask the verification questions in RR1–RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your CV claims, including your NMC registration and driving licence, are self-reported and not inspected. I did not look up your NMC entry, because that would send your personal identifier to an outside service. Your National Insurance number is not needed to assess a role, so I have not used it. Applications usually don't ask for it until an offer is made.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC Community Staff Nurse Band 5 district nursing Halifax"; read "About Calderbrook Community Health" (calderbrookhealth.example/about). The fetch of calderbrookhealth.example/careers returned no page. Moved: role reality's organization row (employer exists as described) and RR1 (vacancy not confirmed) |
| 2. Role-family sweep | yes | Searched "Band 5 community district nurse staff nurse role requirements Doppler training NHS pay scale"; read "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead"; read "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: role reality's hiring-manager row and plan row A1 |

## Dossier offer

I can write this up as a `tuesday-dossier.md` to keep or carry forward, if you'd like one.

## Upgrade menu

- The live posting link, or the recruiter's email domain, would close RR1.
- A competency record, training certificate or anonymised audit would raise R7, R10 or R4 from `unclear` toward `medium` or `high`.
- Your NMC register entry, which you can check yourself, would raise R1 beyond `medium`.
- Your answers on hours and any constraints on pay, location or shifts would let me check the hard gates against you; they are currently not given.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) is available, and I'll run it if you say so.

## Questions

G1 — Have you ever dressed, bandaged or assessed a patient's leg ulcer, even occasionally, and what did you do yourself?

G2 — Have you cared for patients at the end of life on the ward, or helped a patient get home to die? What was your part?

G3 — Which electronic or paper record system did you use on the ward and on discharge-to-assess, and has anyone ever audited your notes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.