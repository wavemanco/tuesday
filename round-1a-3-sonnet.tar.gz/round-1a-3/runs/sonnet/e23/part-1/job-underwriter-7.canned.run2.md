I'll read the reference files the skill requires before building the assessment.
**Yes, worth applying to, with one thing to settle first. Status: `conditional_go`.** Your two hard gates (R1, R2) are met on your CV's word. R4, a must-have, is unclear because your CV is silent on it.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R6, R8, R9 · adjacent: R5 (Home-based nursing of housebound adults), R11 (A small caseload of your own) · unclear: R7 (Leg-ulcer care), R10 (End-of-life visits)
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R5, R11: adjacent, with the bridge being your home visiting in discharge-to-assess and the limit being no ongoing caseload; R4, R7, R10: unclear, each closable by a fact from you; R12: absent, and desirable rather than essential.

**Opportunity ledger.** Sound on what the posting and public pages show. It offers supervised entry (RR3), pay inside the survey band (RR4) and pool cars (RR5). The open points are whether the posting is still live (RR1) and the caseload and rota (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm your records and electronic-record experience, R4 (G1); (2) the posting is confirmed open, RR1; (3) your NMC entry shows as current on the public register, since R1 and R2 rest on your CV alone.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` the employer's own About page (its self-description, not independent) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` advert |
| Structure | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | A supported post for nurses early in community work: a one-year post-registration minimum, Doppler only desirable, and senior support built in | `[inferred]` from those three terms in the advert |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` the forum's speaker page |
| Market calibration | Band 5 community staff nurses in England: median basic pay £34,300, interquartile range £32,400–£36,600, 24% with a pool or lease car. The advert's £31,050–£37,800 spans that range. This is a band to expect, not this employer's offer | `[generic]` one 2026 pay-guide result (n=1,240), not independently checked; `[grounded]` advert for its own figure |
| Unknowns | Caseload size and how it builds; weekend, evening or on-call cover; hours; the electronic record system; the closing date | `[grounded]` advert silent on each |
| Contradictions | None found between the advert and the About page. The employer's careers page could not be fetched, so the live posting is unconfirmed (RR1) | `[grounded]` About page read; careers fetch returned no page |

## Evidence map

Your CV and message are self-report, so claims sit at `medium` at most. Nothing has been inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), PIN given, registration active, revalidation due March 2028. Specific, but not checked against the register | `[grounded]` CV | Check your own entry on the NMC online register before applying |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. The advert asks for a full UK licence only | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | CV: five years as a staff nurse on an acute medical ward. Length of experience is graded as an ordinary requirement, not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | CV says nothing on record-keeping or any record system. Staff nurses keep records as a matter of course, but the CV does not state it, so nothing is asserted | `[grounded]` CV silence; `[generic]` that nursing roles involve record-keeping | G1 question |
| R5 | Nursing housebound adults in their own homes | important | adjacent | medium | transferability | Your 18-month discharge-to-assess secondment involved visiting patients at home in their first week after discharge. Limit: that is a short post-discharge window, and the CV does not show continuing care of long-term housebound patients | `[grounded]` CV | State the limit plainly in the application (plan E2) |
| R6 | Wound care | important | direct | medium | presentation | CV lists wound care including pressure ulcers and surgical wounds, which are the types stated, not all wound types. It sits among other claims rather than leading | `[grounded]` CV | E1 pending approval |
| R7 | Leg-ulcer care | important | unclear | low | discovery | CV names pressure ulcers and surgical wounds but not leg ulcers, so your wound care is related but not shown to cover them | `[grounded]` CV | G2 question |
| R8 | Catheter and continence care | important | direct | medium | presentation | CV states catheter care. Continence care beyond catheters is not stated | `[grounded]` CV | E1 pending approval |
| R9 | Insulin administration and care planning | important | direct | medium | presentation | CV states insulin administration. Care planning is not stated, so only administration is claimed | `[grounded]` CV | E1 pending approval |
| R10 | End-of-life visits | important | unclear | low | discovery | CV silent. Palliative patients may have been on your ward or home visits, which is a lead for a question, not a claim | `[inferred]` from the acute ward and home-visiting settings | G3 question |
| R11 | A small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You told me you have never held your own caseload. Adjacent: home visiting in discharge-to-assess. The advert pairs the caseload with senior support | `[grounded]` your statement, CV and advert | State it plainly (E2); ask in the informal chat how caseloads build |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have not done one. It is desirable, not essential. Closure path: training after appointment. The team lead has spoken publicly on Doppler training for staff new to community work | `[grounded]` your statement, advert and speaker page; `[inferred]` that this team may offer such training | Ask in the informal chat |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and electronic patient record (R4, must_have) | discovery | The CV is silent on record-keeping and on any record system | R4 is a `must_have` row at `unclear`; this is the condition holding the decision at `conditional_go` | Using an electronic patient record on the ward or in discharge-to-assess; same-day entries after home visits; handover notes; a documentation audit you took part in | A named system, a documentation audit result, a reference line from a manager | `[grounded]` CV silence; `[inferred]` that settling it moves the decision to `go` |
| G2 | Leg-ulcer care (R7, important) | discovery | Pressure-ulcer and surgical-wound care are stated; leg ulcers and compression therapy are not | The advert names leg-ulcer care, and the Doppler item shows the team treats it as a specialty | Dressing leg ulcers on the ward; applying compression bandaging; a wound-care study day or competency sign-off | A training certificate or competency record | `[grounded]` CV; `[generic]` that community teams commonly treat leg ulcers as a core part of the caseload |
| G3 | End-of-life visits (R10, important) | discovery | Nothing in the CV on end-of-life care | End-of-life visits are one of the advert's named duties | Caring for dying patients on the ward; a discharge to home for end-of-life care; working with the family or the palliative team | A competency record or training certificate | `[grounded]` CV silence |
| G4 | Own caseload (R11, important) | transferability | Home visiting is evidenced; ongoing responsibility for a set of patients is not, by your own account | The advert pairs the caseload with senior support, so this is a limit to state, not hide | The discharge-to-assess visit list: who built it, and how patients were followed up | A line from the secondment lead | `[inferred]` bridge from the secondment; `[grounded]` your statement |
| G5 | Doppler assessment (R12, preferred) | capability | No Doppler experience, which you confirmed | A desirable item, so a minor risk | Training attendance after appointment | A training place offered by the employer | `[grounded]` advert and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer matches the posting, but the posting may sit on a page I could not reach or may have closed | `[grounded]` About page found; careers fetch returned no page | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Caseload size and rota unstated | unknown | — | "You will hold a small caseload of your own" | Caseload size, visit load and any weekend, evening or on-call cover are unspecified | `[generic]` community nursing rotas often include some out-of-hours cover; `[grounded]` advert silent | How big is a caseload at the start and how does it grow, and what weekend or evening cover is expected? | unresolved |
| RR3 | Supported entry | positive_signal | — | "supported by a senior community nurse" | Support is built into the post, and the team lead has spoken publicly on training staff new to community work | `[grounded]` advert and speaker page | What does the senior nurse's support look like in the first months, such as accompanied visits or sign-offs? | noted |
| RR4 | Pay inside the market band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the survey's interquartile range, so no seniority-pay mismatch is visible. Where a new starter would sit in the range is unknown | `[grounded]` advert figure; `[generic]` one survey snippet | Where in the £31,050–£37,800 range would my starting salary sit, given five years' ward experience? | unresolved |
| RR5 | Pool cars provided | positive_signal | — | "pool cars are provided" | Removes the need for your own car for visits; in the survey sample a pool or lease car was the minority arrangement | `[grounded]` advert; `[generic]` survey snippet | How are pool cars booked, and is one available for every shift? | noted |

## Application plan

`resume_edits_pending_approval`: nothing below is final until you approve it, the covering-letter wording and the chat advice included. Every clause traces to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: lead the experience section with your own words — "seconded to the discharge-to-assess team (last 18 months), visiting patients at home in their first week after discharge", then one skills line: "wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" | See R5, R6, R8, R9. It moves your strongest community evidence to the top without adding a fact | `[grounded]` CV | pending your approval |
| E2 | Covering letter, one paragraph in your voice: "I haven't held my own caseload or done a Doppler assessment. For the last 18 months, with the discharge-to-assess team, I have visited patients at home in their first week after discharge." | See R11, R12. It states both limits and the bridge, and the advert invites a caseload supported by a senior nurse | `[grounded]` your statements and CV | pending your approval |
| A1 | Take the informal chat the advert offers with Rhiannon Mabbott, and ask the RR1, RR2, RR3 and RR4 questions, plus whether Doppler training is offered | The advert invites the call, so it is where the register's questions get answered | `[grounded]` advert | pending your approval |
| A2 | Leave your National Insurance number off the CV and application form | See evidence status: it isn't needed to assess a role | `[generic]` employers typically collect it at offer stage | pending your approval |

## Evidence status

Verified: none yet. I assumed you are evaluating, not yet applying. The National Insurance number in your message isn't needed to evaluate a role, so I haven't used or recorded it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization row; RR1 (posting live status unconfirmed) |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 Agenda for Change salary 2026 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration; RR4, RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's hiring-contact row; R12 and RR3; plan A1 |

I can save this as a `tuesday-dossier.md` if you'd like to keep or reuse it.

**Upgrade menu**

- Your NMC register entry and licence check → R1 and R2 to `high`.
- An answer to G1, G2 or G3 → R4, R7 or R10 moves from `unclear` toward `direct` or `adjacent`, and the decision likely moves to `go` once R4 is settled.
- A training certificate or competency record for leg-ulcer or end-of-life care → R7 or R10 to `high` once inspected.
- Mabbott's answers on caseload, rota and Doppler training → RR2, RR3 and RR4 close, and R12's closure path firms up.
- Any pay floor, hours or rota limits you have → hard-gate checks against your constraints, which are currently unknown.
- A deeper research pass on Calderbrook (staff and leadership changes, past reports; up to 5 more searches and 2 more fetches) → say the word and it runs.

G1 — Which electronic patient record or documentation system did you use on the ward and in discharge-to-assess, and what part did you have in how visits were written up (same-day entries, handover notes, audits)?

G2 — Have you cared for patients with leg ulcers, including compression bandaging, and in what setting (ward, home visits, training)?

G3 — Have you cared for patients at the end of life, on the ward or on home visits, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.