# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Candidate: Sam. Interviewer: Hannah Lowther, Talent Partner. Round: recruiter screen, 30-minute phone call, Thursday 2pm; she rings the mobile number on your application. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move, then the team and next steps.

## How to use this pack

Personas describe how a question arrives (who is asking, in what register). Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether what you say about your experience survives a follow-up, and what was actually yours |
| JD | Whether you fit a stated requirement of the advert, or a screening item the recruiter named |
| CO | What you know about the company |
| CASE | A live problem from the role, scored on structure |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the call: answer it from your own experience, in your own words, and if the thing did not happen or was not yours, say so plainly. Nothing in the pack should be said unless it is true of you.

The highest-ROI rehearsal in this pack is B1, the gap between delivery scheduling at a wholesaler and the advert's production-schedule coordination. It will come up in some form, and an unrushed, non-defensive answer changes the call.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but your own statement with nothing inspected behind it, so expect a check on the role and the years. Say it in the quote's terms |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries across depots, not production schedules, and the words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the JD names planning, the warehouse and QA, so expect a probe on who you coordinate with. If you worked with teams like those on scheduling, say which and how, in your own words; if not, say so plainly and stay with the deliveries |
| F3 | "track supplier deliveries and chase late orders" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | The quote already reaches the chasing half in role-relevant terms. Lead with it as written: you chase suppliers when orders slip. Expect a probe on how you know an order has slipped (C3) |
| F4 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote reaches the requirement. It is also a headline figure, so expect the defend-the-number probe (C1). Keep the sentence at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year |
| F5 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and does not show what the rebuild involved. Answer slot: say which tool the spreadsheet is in; if it is Excel, say what you built in it, in your own words; if it is not, say so plainly and say what you did in it |
| F6 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Your material does not show any reporting of this kind. Answer slot: the JD asks for weekly dispatch reporting, so expect a probe. If you report on deliveries or anything like on-time performance, say what and how often, in your own words; if you do not, say so plainly and stay with the stock-count spreadsheet |
| F7 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | Words you can say as written: "I've never used SAP. We run our own in-house stock system." The advert calls this a plus, not a requirement. Answer slot: the JD says "or similar", so expect a probe on the in-house system. Say what you use it for, in your own words; if only a little, say so plainly. Then a plan, never a past: how you would learn a new system |
| F8 | "£38,000–£44,000" — JD | "I'm hoping for £42,000" — your message | medium | [grounded] | none | The figure sits inside the advertised range. Say it in the quote's own words (A5) |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Two days fits the advert; the three-day ceiling is your own stated limit. Keep both halves of the sentence as you wrote them (A3) |
| F10 | "your notice period" — recruiter's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term, not something wording can settle, and the pack does not bridge it (A4) |
| F11 | "what's prompting a move" — recruiter's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | The quote answers the question. Say it in its own terms and add nothing the sentence does not say (A1, B5) |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; her four named items asked as chat | High. Recruiter-screen prior is Conversational plus a light Skeptic, and her message names salary, notice period, hybrid and motivation herself. The bank is 6 questions because every item she named is asked in this register | Short prepared answers for each of her four items; treat casual questions as scored |
| Skeptic | Quiet probing of the gaps: production scheduling, SAP, Excel, dispatch reporting, why leave | Medium. Screens check the advert's requirements against the CV, and your material has several rows that are not settled (F2, F5, F6, F7) | Rehearse B1 until it is boring; the honest limit said plainly, then a plan for learning |
| Data-Driven Prober | Asks how the stock-count figure was counted | Low to medium. Your one headline figure is F4, and a screen may touch it briefly | Know what you can and cannot say about how it was counted; say plainly where you do not know |
| Case / Strategist | A live problem from the role | Low for the screen, higher in later rounds. The loop beyond this call is not established, so this is insurance | Clarify, structure, then answer; use the advert's three teams as your stakeholders |
| Pressure | Time-boxed challenge such as sixty seconds on why you | Low. Recruiter screens rarely run this register, but the shortlisting question exists in friendly form | Hold what your quotes carry, concede the SAP limit plainly, stop |
| Values / Behavioral | Not banked | No values-style round is detected: no loop source was read, and the generic archetype fallback reads no | n/a |
| Peer Evaluator | Not banked | Not plausible on a call with the recruiter | n/a |

The loop beyond Thursday is not established by any source read. Persona weights rest on the recruiter-screen prior and her own message, not on this company's documented process.

## Question banks

### A. Conversational (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, what's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it in the sentence's own terms: the office closing next year, the only offer relocation to Reading, and that you don't want it. Add nothing the sentence does not say. Then give one sentence on what draws you to this role, picked from the advert's own lines, the ones you actually want to do; if none stands out, say so plainly | She named it as an agenda item, so it is certain. EXP because it tests whether your account of your own situation stays consistent; F11 holds the quote |
| A2 | "Tell me about your current role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F1 and F3: the four years and the wholesaler, then scheduling deliveries for the three depots, then chasing suppliers when orders slip. Those are the beats the quotes state; tell them in your own words and stop there until asked | The opener for most screens, and the base every later probe returns to; EXP because it is your own history in your own words |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Answer her question on the advert's two days first: you live in north Bristol and two days at Avonmouth is fine. Give the ceiling if flexibility comes up, as you wrote it: you wouldn't want more than three. Keep it a preference as stated, not a rule and not an offer | She named hybrid as an agenda item; F9 holds the quote. JD because it screens a stated term of the advert |
| A4 | "What's your notice period?" | JD | [grounded] "your notice period" — recruiter's message | Your material does not establish this, so there is no quote to rehearse. Look up the figure in your contract before Thursday and say that figure. If you do not know whether it can be shortened, say so plainly rather than offering a date you cannot confirm | Named by her, so certain. JD because it is a screening term, not a story; F10 is a gate and the pack does not bridge it |
| A5 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000."; "4 years as a logistics coordinator at a building-supplies wholesaler" | Say the figure once, in your own words: "I'm hoping for £42,000." Before Thursday, decide for yourself how firmly you hold it, because the only words the pack can quote are "hoping for". If she asks why that figure, the only reason the pack can quote is the four years as a logistics coordinator; add anything else only if it is true, in your own words. Then stop | Named by her, so certain. F8 holds the quote; JD because the advert states a range and this is where you fit inside it |
| A6 | "What do you know about us?" | CO | [grounded] "diagnostic-test manufacturer, about 400 staff" — JD | The advert says a diagnostic-test manufacturer, about 400 staff, with a site at Avonmouth in Bristol. Beyond that, the pack could not research the company (searches were refused), so spend twenty minutes on their website before Thursday and say only what you read. If you did not get to it, say that plainly and ask her about the team | A casual opener that is still scored. CO because it tests homework; the guidance makes no claim about your past |

### B. Skeptic (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is a building-supplies wholesaler and this is a manufacturer's production schedule. What would be new for you?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots" | The highest-ROI rehearsal in this pack. Hold what the quotes carry: "I schedule deliveries for our three depots." Answer slot: the JD names planning, the warehouse and QA, so expect a follow-up on who you coordinate with. If you have worked with teams like those on scheduling, say which and how; if not, say so plainly and return to the deliveries. Then a plan, never a past: which of the three teams you would sit down with first and what you would ask them. Hold through two follow-ups by returning to the deliveries, never by adding to them | F2 is where the advert presses hardest, and the material is thin there. JD because it scores a stated requirement |
| B2 | "SAP is listed as a plus. Have you used it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it as stated: "I've never used SAP. We run our own in-house stock system." Answer slot: the advert says "or similar", so expect a probe on the in-house system. Say what you use it for, in your own words; if only a little, say so plainly. Then how you would learn a new system, as a plan | F7 is a stated negative, and the advert calls the item a plus. JD because it scores a stated preference |
| B3 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The quote says spreadsheet, not Excel. Answer slot: say which tool it is in; if Excel, say what you built in it, in your own words; if not, say so plainly and say what you did in it. Do not rate yourself with an adjective the quote does not carry | F5's evidence is thin, so this is likely to be asked directly. JD because the advert names Excel |
| B4 | "The role reports weekly on on-time dispatch. Where have you come across that kind of reporting?" | JD | [grounded] "report weekly on on-time dispatch" — JD | Your material does not show it. Answer slot: if you report on deliveries or anything like on-time performance, say what and how often, in your own words; if you do not, say so plainly and stay with the stock-count spreadsheet. Then, as a plan, what you would want defined first | F6 has no evidence, and the advert lists the reporting as a duty. JD because it scores a stated responsibility |
| B5 | "Would you be looking if the office weren't closing?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Answer in your own words in one or two sentences, and keep it consistent with your quote: you are looking because the office is closing and relocation is the only offer. Do not offer an earlier plan or a hidden reason you have not told her. If the honest answer is that you do not know, say that | Tests motivation consistency. F11 holds the quote; EXP because the probe is about whether your account of your own situation holds |

### C. Data-Driven Prober (low to medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend the number in your own words. Answer slot: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep the claim at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year | F4 is the one headline figure, and a figure is where a probe lands. EXP because it tests attribution |
| C2 | "What did rebuilding the stock-count spreadsheet involve?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The beats the quote states: it was a rebuild of the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slot: the JD asks for accurate stock records, so expect a probe on what you changed. Say what changed, in your own words; if you do not remember or it was not yours alone, say so plainly | F4 again, as the follow-up that follows the figure. EXP because it asks what you did |
| C3 | "When an order slips, how do you know, and what do you do?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The beats the quote states: you chase suppliers when orders slip. Answer slot: the JD asks for supplier delivery tracking, so expect a probe on how you know an order has slipped. If you track it in a particular list or system, say which; if there is no such tracking or it is not yours, say so plainly and return to the chasing | F3 reaches the chasing half; the tracking half is where a follow-up goes. EXP because it asks what you did |

### D. Case / Strategist (low weight for the screen, insurance for later rounds)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier delivery that tomorrow's production run needs is two days late. What do you do?" | CASE | [generic] | Structure it aloud: what is affected and who needs to know first (the advert names planning, the warehouse and QA), what you would ask the supplier, what the options are, when you escalate, what you record. The question needs no claim about your past, so the guidance makes none | Live problem from the JD's supplier-chasing line (F3's requirement); generic because it is a pattern, not a fact about Quillmoor |
| D2 | "The stock record and the physical count disagree on a batch QA is waiting for. What do you do?" | CASE | [generic] | Structure it: freeze what depends on the number, recount, find where the records diverge, tell the people waiting, correct the record and note why. No claim about your past | From the JD's stock-records line (F4's requirement), asked as a decision rather than a figure |
| D3 | "How would you report on-time dispatch each week? What would you want in it?" | CASE | [generic] | Clarify before structuring: on time against what date, what counts as dispatched, who reads it and what they decide. Name the definition you would settle first. No claim about your past | From the JD's weekly dispatch line (F6's requirement); it lets you meet the gap as a design question |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we shortlist you over someone who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year."; "Never used SAP — we run our own in-house stock system." | Pause, restate, then hold only what the quotes carry: four years as a logistics coordinator at a wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip, and rebuilding the stock-count spreadsheet. Concede the limit plainly: "I've never used SAP." Then stop. Hold through two follow-ups by returning to those quotes, never by adding to them | F7 is a stated negative and the likeliest pressure point. JD because it scores the stated preference |
| E2 | "That's a third fewer discrepancies. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the sentence: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot: which part was yours; if others contributed, or you do not know how much of the fall came from the rebuild, say so plainly. Hold through two follow-ups by returning to the rebuild | F4's figure under pressure; EXP because it tests attribution honesty |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A2, E1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, D1 |
| Track supplier deliveries and chase late orders | C3, D1 |
| Keep stock records accurate | C1, C2, D2, E2 |
| Report weekly on on-time dispatch | B4, D3 |
| Confident with Excel | B3 |
| ERP experience (SAP or similar) a plus | B2, E1 |
| £38,000–£44,000 | A5 |
| Hybrid, two days a week at Avonmouth | A3 |
| Notice period (recruiter's item) | A4 |
| What is prompting a move (recruiter's item) | A1, B5 |
| Company knowledge | A6 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does this role work day to day with planning, the warehouse and QA, and who does it report to?" | The advert names three functions; this shows you read it and gets you the seam you could not research |
| R2 | "Who reads the weekly on-time dispatch report, and what do they do with it?" | Ties to the advert's reporting line and tells you what the number is for |
| R3 | "Which system does the team use for stock and orders, and how is training handled for someone new to it?" | The advert says SAP or similar; this turns your stated gap into an onboarding conversation |
| R4 | "Are the two Avonmouth days fixed, or set by the team?" | She asked how hybrid would work for you; this gets the employer's side of the same question |
| R5 | "Who would I meet next, and what would each stage focus on?" | The pack could not research the loop; her answer tells you which personas to rehearse |
| R6 | "What would a good first ninety days look like?" | A standard question, useful because it surfaces what success is measured on |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP or an ERP, or calling the in-house stock system an ERP | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." The in-house system is described only as "our own in-house stock system", and what it does is B2's slot |
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries across depots, not production schedules |
| Cut stock discrepancies by a third through the rebuild alone | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Which part was yours is C1's and E2's slot |
| Happy to work three days a week at Avonmouth | Inflated form of F9 | F9's quote at its own scope: two days is fine, and you wouldn't want more than three |
| Was made redundant, or your role is being cut | Inflated form of F11 | F11's quote at its own scope: the Bristol office is closing next year and the only offer is relocating to Reading |

## Sources

Provided documents: the Quillmoor Diagnostics advert (pasted), Hannah Lowther's LinkedIn message (pasted), and your own background notes (your message). No dossier was present.

Searches sent, all refused by the host:

- `Quillmoor Diagnostics values`: refused
- `Quillmoor Diagnostics interview process operations coordinator`: refused
- `Quillmoor Diagnostics Avonmouth news`: refused
- `Hannah Lowther Quillmoor Diagnostics Talent Partner`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every search was refused. It would have fed a values cheat sheet; none is built because no values-style round is detected, and it would have sharpened A6 |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every search was refused. It would have named the later rounds and reweighted personas; weights rest on the recruiter-screen prior |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | Every search was refused. It would have fed a CO question grounded in current strategy; A6 is built from the advert's own lines only |
| 4. `Hannah Lowther Quillmoor Diagnostics Talent Partner` | unavailable | Every search was refused. The interviewer read is absent; it would have changed no question, since her own message already names her agenda |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A4 and F10 stop being a gap in the material, and the answer can be quoted
- Answers to the slots in F2, F5, F6 and F7, which are who you coordinate with, which tool the spreadsheet is in, whether you report on dispatch, and what the in-house system does → those rows and B1 to B4 are regenerated from your own words
- The stock-count spreadsheet itself, or the discrepancy records behind the one-third figure → F4 and F5 can rise from medium and low, and C1 and E2 get firmer ground
- Search permission granted → targets 1 to 3 would run: the values page, the loop, and recent news, which would sharpen A6 and the later-round weights. A deeper pass of up to 6 more searches and 2 more fetches, taking several more minutes, would add a strategy brief; say so if you want it
- The recruiter's answer on next steps, or the names of later interviewers → per-round mini-packs with their own persona weights
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a named objection to rehearse, in place of the objection inferred here
