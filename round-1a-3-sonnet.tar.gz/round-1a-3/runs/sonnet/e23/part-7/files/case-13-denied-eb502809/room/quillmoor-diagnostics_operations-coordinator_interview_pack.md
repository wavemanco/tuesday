# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Candidate: Sam. Interviewer: Hannah Lowther, Talent Partner. Round: recruiter screen, 30-minute phone call, Thursday at 2pm. She will ring the mobile number on your application. Her message says she will cover salary expectations, notice period, how the hybrid pattern would work for you, and what is prompting a move, then tell you about the team and next steps.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is testing |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No question carries this type in this pack: no values round is named in your material and no published values were read |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | A live problem from the actual role, scored on structure |

Highest-ROI prep: B4, the wholesaler-to-manufacturer carry-over question. Your message gives no quote on production schedules, so it is the likeliest place for a probe to land. The four topics Hannah named (A3, A4, A5, B1) are certain to come up, so rehearse them out loud once each.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on the role. Lead with the quote's own terms: four years, logistics coordinator, a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots and chasing suppliers, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinate with likely. If any of that contact was yours, say with whom and how, in your own words; if there was none, or it was not yours, say so plainly and stay with the depots and the suppliers |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap on chasing: the quote reaches it. Lead with its terms: you chase suppliers when orders slip. The sentence says nothing on how deliveries are tracked, so expect that probe, and keep to what the sentence states |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap: the quote reaches it. The figure is the magnet. Keep its terms: "about a third", "over a year". The rebuild and the fall sit side by side with no stated link between them, so rehearse C1 |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on dispatch or deliveries. Answer slot: the advert's weekly line makes a probe likely. If you produce regular reports on deliveries or dispatch, say what they cover and how often, in your own words; if you do not, say so plainly and stay with the scheduling and chasing |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet, not which tool, so it touches the requirement without showing it. Answer slot: the advert's Excel line makes a probe on the tool and your level likely. If it was Excel, say what you did in it, in your own words; if it was another tool, or you are unsure, say so plainly and stay with the rebuild itself |
| F7 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert lists it as a plus, so the answer is short and plain |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | The quote says an in-house stock system, not whether it is comparable to an ERP, so the material does not show it reaches the requirement. Answer slot: the "or similar" wording makes a probe on what that system did likely. If you worked in it, say what you did there, in your own words; if it was not comparable, or little of it was yours, say so plainly and stay with the fact that you have never used SAP |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the band. Say it in the quote's own terms, a hope and not a floor: "I'm hoping for £42,000." |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Both halves are yours and both stay: two days is fine, more than three is not wanted. Lead with the two; the ceiling comes out if she asks about more days |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term she has named, so it is surfaced here rather than bridged, and the pack asks for it in the closing question |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. The reason is plain; say it in the quote's own order and scope: the office closing next year, the only offer being Reading, and that you don't want it |

## Persona table

Weights start from the recruiter-screen prior (conversational, with a light skeptic) and are adjusted by what Hannah's message shows. No interviewer profile was read and no loop beyond this call is known, so nothing else moves them. Values and Peer personas are left out: no values round is named in your material, and Hannah is not a peer.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly agenda run: background, salary, hybrid, notice, why you are moving, why Quillmoor | High. The recruiter-screen prior puts it first, and her message names four agenda topics that all arrive in a casual register. Six questions, A1 to A6 | Pre-script a 90-second background arc (A1); treat each casual question as scored; use your turn at the end for real questions, not "I think you've covered everything" |
| Skeptic | Light probing of the gaps: the move, SAP, the wholesaler-to-manufacturer step | Medium. The prior adds a light Skeptic, and the advert asks for production scheduling and lists ERP as a plus, both thin in your material (F2, F7, F8). Four questions, B1 to B4 | Rehearse B4 until it is boring: hold only what the quotes state, say the limit plainly, offer a plan and never a past |
| Data-Driven Prober | Checks the CV line by line: the one-third figure, the spreadsheet, Excel, reporting | Medium. Nothing in her message points to it, but the F4 figure and the advert's Excel and weekly-report lines (F5, F6) give it material. Four questions, C1 to C4 | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure | A time-boxed "why you" or a challenge on the Reading offer | Low. Nothing in her message signals it, and the prior does not include it for this round. Two questions, D1 and D2 | Pause, restate, hold the position the quotes carry through two follow-ups, concede only what is true |
| Case / Strategist | A light scenario on a late supplier or a stock mismatch | Low. A recruiter screen is not usually case-led, but the advert's duties make a short scenario possible. Three questions, E1 to E3 | Clarify, state the objective, set out options, say who you would tell and what you would record |

## Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background and what's brought you to this role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F1 and F3: the four years, the logistics coordinator role and the wholesaler, then what the job is, which are the beats the quotes state; tell them in your own words. Close with the reason you are looking, from B1, in one sentence. Answer slot: the sentence on why this role has no source in your material. Say in your own words what draws you to it; if nothing in particular does, say so plainly and stay with what the advert describes | Hannah's message says she will ask what is prompting a move, and this is where it enters. F1 and F3 are the evidence; EXP because it tests that your story is told consistently |
| A2 | "What does a typical week look like in your current role?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F3: scheduling deliveries for three depots, and chasing suppliers when orders slip, the two beats the quote states, in the present tense it uses. Answer slot: the advert also names stock records and a weekly dispatch report. If other regular tasks fill your week, say what they are in your own words; if none do, or you do not do some of them, say so plainly and stay with the scheduling and chasing | F3 is the most direct match in the pack. JD because it is the advert's core duty asked in a casual register |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure in the quote's own terms: "I'm hoping for £42,000", and that it sits inside the advertised £38,000 to £44,000. Keep it a hope and not a floor. Answer slot: if she asks about your current salary, or whether there is room either way, say in your own words what you are willing to share and whether there is room; your material states £42,000 and nothing about either | Named in Hannah's message; F9 holds the evidence. JD because the band comes from the advert |
| A4 | "How would the hybrid pattern work for you, with two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Lead with the two days: "I live in north Bristol, so two days at Avonmouth is fine." Keep the second half for when she asks about more days: you wouldn't want more than three. Do not call yourself flexible on days; the quote says fine with two and not wanting more than three. Answer slot: if she asks how you would get to Avonmouth, say what you know in your own words; if you have not looked, say so plainly | Named in Hannah's message; F10 holds the evidence. JD because the pattern is in the advert |
| A5 | "What's your notice period, and when could you start?" | JD | [grounded] | Your material does not establish your notice period, so the words are yours alone. Answer slot: state the notice your contract gives and the earliest start it allows. If there is room to shorten it, say so in your own words; if there is none, say so plainly. Do not offer a date you have not checked | F11 is the one row the material is silent on, and Hannah's message names it, so it will be asked. JD because start timing is part of her screen |
| A6 | "What do you know about Quillmoor, and what appeals about the role?" | CO | [generic] | This pack holds no company facts beyond the advert, which describes a diagnostic-test manufacturer of about 400 staff, so anything more has to come from your own reading before Thursday. Answer slot: say in your own words what drew you to apply; if nothing beyond the advert did, say so plainly and name the advert lines that interested you. Do not recite company facts you have not read | A why-us question sits naturally beside the motivation topic in her message. CO because it tests homework; it stays generic because no company research ran |

### B. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Story-mapped on F12, in the quote's own order and scope: the Bristol office is closing next year; the only offer is relocating to Reading; you don't want that. Say it as plainly as the quote does, and do not call it redundancy or a forced exit. Answer slot: if she asks whether you would be looking otherwise, answer from the truth in your own words; if you would not, say so plainly | A named topic in Hannah's message; F12 holds the evidence. EXP because it tests whether the reason holds up and stays consistent with the application |
| B2 | "You haven't used SAP. How would you get up to speed on an ERP system here?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment from F7: "I've never used SAP." The advert lists ERP as a plus, so keep the acknowledgment to one clause. Then the in-house system, at the quote's scope: you run your own in-house stock system. Answer slot: say what you did in it, in your own words; if it was not comparable to an ERP, or little of it was yours, say so plainly. Then a plan, never a past: how you would learn their system and who you would ask | F7 and F8 are the evidence and the probe lands where they are thinnest. JD because ERP is a stated plus |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pick the item from the advert you honestly find thinnest. The pack's own observation is that F2, F5 and F7 are where your material is thinnest, but the choice is yours. If it is SAP, the words are "I've never used SAP", then a learning plan. Whichever you pick, hold what you do carry: you schedule deliveries for three depots and chase suppliers when orders slip. Answer slot: if you honestly think another part is your weakest, name it plainly and say how you would close it | The classic Skeptic stem; F2, F5 and F7 are the likeliest picks. JD because it scores the advert's list directly |
| B4 | "This is a manufacturer: you'd coordinate production schedules between planning, the warehouse and QA. Your background is at a wholesaler. How does that carry over?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack, and the hold is only what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip. Say that and stop. Follow-up one, where she asks who you coordinate with: answer slot, if any of that contact was with a planning team, a warehouse or a quality function, say with whom and what the contact was, in your own words; if there was none, or it was not yours, say so plainly and return to the depots and the suppliers. Follow-up two, where she asks whether you have done production scheduling: answer from your own experience, either branch, and never describe delivery scheduling as production scheduling. Concede plainly whatever difference is true, then give a plan, not a past: in your first weeks you would ask to be shown how the hand-offs between planning, the warehouse and QA run | F2 is where the advert's mandate presses hardest and your material is adjacent, so this objection arrives in some form. JD because it scores the stated requirement; the Skeptic delivery is a polite "help me understand" |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the drop in stock discrepancies. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend the number in its own terms: discrepancies fell by about a third over a year; keep "about" and "over a year". Answer slot: how the figure was counted, in your own words, or say plainly that you do not know how it was counted. Answer slot: what the figure is sensitive to. Answer slot: the assumption behind it you would defend least. Answer slot: which part of the fall was yours; if you cannot separate your rebuild from other causes, say so plainly | F4 holds the figure, the likeliest thing to be probed. EXP because it tests attribution and honesty about the number |
| C2 | "Tell me about the stock-count spreadsheet you rebuilt." | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F4: you rebuilt the stock-count spreadsheet, which is the beat the quote states. Answer slot: the advert asks for accurate stock records, so expect a probe on what you changed and why. Say what you changed in your own words; if others worked on it, say which part was yours; if you cannot recall the detail, say so plainly and stay with the fact that you rebuilt it | F4 is the evidence for the stock-records line. JD because it scores that requirement through a past example |
| C3 | "How would you describe your Excel skills?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | An open question, so it needs no claim from your past; the advert's line asks for confidence in Excel. Answer slot: describe your level and what you do in it, in your own words, with only things you could show if she asked for an example. If the rebuilt spreadsheet was not in Excel, or you use it little, say so plainly and name the tool it was in | F6 is thin because the quote names a spreadsheet and not the tool. JD because Excel is a stated requirement; inferred because the link to your spreadsheet is the pack's derivation |
| C4 | "The role reports weekly on on-time dispatch. What reporting do you do today, if any?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you produce regular reports on deliveries or dispatch, say what they cover and how often, in your own words; if you do not, say so plainly and stay with what the quote states: you schedule deliveries for three depots and chase suppliers when orders slip. Do not describe a report you do not produce | F5 has no evidence in your material, and the advert names the weekly report, so a probe is likely. JD because it scores a stated duty |

### D. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've got sixty seconds: why should we pick you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Hold the three things the quotes carry: four years as a logistics coordinator at a wholesaler, scheduling deliveries for three depots, and chasing suppliers when orders slip. Concede the one thing you have said, that you've never used SAP, in one clause, then stop. If she presses twice, repeat the same facts rather than widening them. Answer slot: if you want one sentence on what you would bring to a manufacturer, say it in your own words, tied to something you actually did; if nothing comes, say so plainly and stay with the facts | The time-boxed form of F1, F3 and F7. JD because it scores the advert's whole ask |
| D2 | "Wouldn't relocating to Reading be the safer option for you?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold the position the quote carries: the only offer is relocating to Reading, and you don't want it. Concede what is true as the quote has it: it is the offer on the table. Do not widen it into reasons the quote does not give. Answer slot: if she asks why, give your reasons in your own words; if the reason is simply that you don't want to leave Bristol, say so plainly. On a second push, repeat the position and move to what you are looking for in the role, in your own words | The pressure form of F12. EXP because it tests whether the reason survives a challenge |

### E. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a key delivery will be a week late, and production is scheduled for Monday. What do you do?" | CASE | [generic] | Structure it: what you need to know first (what is affected, how firm the new date is, what the schedule can absorb); the objective; the options; who you tell, which the advert gives as planning, the warehouse and QA; and what you record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing line (F3's requirement), asked as a decision. CASE because it scores structure; generic because it is a pattern for the problem and not a fact about this employer |
| E2 | "Stock records and a physical count disagree on a line the day before a dispatch. What do you do?" | CASE | [generic] | Structure it: confirm the count first, check recent movements against the record, decide whether the dispatch can proceed, correct the record, and note what to prevent. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's stock-records line (F4's requirement). CASE because it scores reasoning; generic because it makes no claim about you or the company |
| E3 | "What would you want in a weekly on-time dispatch report?" | CASE | [generic] | Clarify first: on time against which date, and who reads it. Then the measure, the cut by order or product, the late items with causes and the chase status, and one line on what changed from last week. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's weekly-report line (F5's requirement), and a way to show reasoning where your material is silent. CASE because it scores structure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1, D1 |
| Coordinate production schedules between planning, the warehouse and QA | B4, E1 |
| Track supplier deliveries and chase late orders | A2, E1 |
| Keep stock records accurate | C1, C2, E2 |
| Report weekly on on-time dispatch | C4, E3 |
| Confident with Excel | C3, C2 |
| ERP experience (SAP or similar) a plus | B2 |
| £38,000–£44,000 | A3 |
| Hybrid: two days a week at Avonmouth | A4 |
| Notice period (named by Hannah) | A5 |
| What is prompting a move (named by Hannah) | B1, D2 |
| Company values | none, because no values round is named in your material and no published values were read |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with day to day across planning, the warehouse and QA?" | The advert names those three functions, so it shows you read the scope and lets her describe the real shape of the team |
| R2 | "Which systems does the team use for production schedules and stock, and what training is there for someone new to them?" | It turns the SAP gap into a question about onboarding instead of leaving it as an apology |
| R3 | "How is on-time dispatch measured today, and who reads the weekly report?" | It answers your own clarify step from E3 and signals you think about what the report is for |
| R4 | "How are the two days at Avonmouth usually arranged: fixed days, or agreed with the team?" | She asked how the hybrid pattern would work for you; this shows you are planning for it |
| R5 | "What would a good first three months look like in this role?" | It invites a concrete picture of success and gives you what to aim at in the next round |
| R6 | "Is this a new role or a replacement, and what led to the hire?" | It gives context on what the role is for, in a neutral register that is easy for a recruiter to answer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation, not words for you: the material says deliveries and suppliers, not production. B4's slots stay inside the depots and the suppliers |
| The stock-count rebuild caused the fall in discrepancies | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material gives the rebuild and the fall side by side, with no stated link. C1's slots ask only how it was counted, what it is sensitive to, the weakest assumption and which part was yours |
| Used advanced spreadsheet functions to rebuild the stock-count spreadsheet | Inflated form of F6 | F6's quote at its own scope: "I rebuilt our stock-count spreadsheet." The limit is the pack's observation: the material does not show the tool or what was done in it. C3's slot asks only which tool and what you did |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." No slot on SAP itself |
| Is flexible on how many days are in the office | Inflated form of F10 | F10's quote at its own scope: two days is fine, and you wouldn't want more than three. A4 keeps both halves |
| £42,000 is a firm minimum | Inflated form of F9 | F9's quote at its own scope: "I'm hoping for £42,000." A3 keeps it a hope |

## Sources

Provided documents: your message (the advert text, your background and what you would tell her) and Hannah Lowther's LinkedIn message, as pasted.

Searches sent, each refused (permission to search was not granted), with nothing returned:

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics Avonmouth news` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

No dossier was present. No search was retried after the refusals.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have fed a values cheat sheet only if a values round were detected; none is, so it would have moved A6's wording and the reverse questions |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have shown the rounds after this call. Hannah's message already establishes this session as one phone call with her, so the persona weights rest on the recruiter-screen prior |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | Would have made A6 a grounded strategy question; it stays generic without it |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have supplied an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period and earliest start date → F11 is surfaced and not bridged, so a stated term would close it and make A5 a quoted answer
- A line on what the stock-count spreadsheet was built in and what the rebuild changed, and how the one-third figure was counted → F4 and F6 gain evidence, and C1, C2 and C3 move from answer slots to story maps
- A line on whether you produce any regular report on deliveries or dispatch → F5 moves from no evidence to a quote, and C4 and A2 follow
- A line on what the in-house stock system does and what you do in it → F8 becomes gradable and B2's slot becomes a story map
- Your CV → the message lines in F1 to F12 can be checked against it, and any further CV lines become quoted evidence
- Pasted text from Quillmoor's careers or about page, or permission to search → A6 and the reverse questions become grounded in the company, and a values or strategy section becomes possible; a deeper pass would cost up to 6 more searches and 2 more fetches and several more minutes
- Hannah's public professional footprint, or one email asking her who the role reports to → an interviewer read and a reverse question tied to her path
- Your prep time before Thursday → a prioritised schedule sized to it
- A tuesday-dossier.md from the job-underwriter, if you have one → verified evidence and any sourced limits per area; it is never required
