I'll read the skill's reference files before building the pack.
Your pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md` in the working directory. I built it for Hannah's recruiter screen around the four topics she listed. The web searches I tried (values, process, strategy, Hannah) were refused, so the company side of the pack rests on the advert and her message only.

It has 18 practice questions. The one to rehearse hardest is B2, the SAP question: your own notes state the gap, so expect it in some form. Start with A1 to A4, which are her four agenda items: your story, salary, hybrid and notice period.

Say the word and I'll play Hannah on A1 to A4, or the Skeptic on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? Hannah will ask it, your material doesn't say, and it's the one row the pack can't coach around.
Do you have a CV to paste? It would replace the quotes from your notes with CV lines and could add rows. If you'd rather not, the pack stands as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner. Recruiter screen, Thursday 2pm, a 30-minute phone call to your mobile. Built from the advert, your notes and Hannah's last message. Web research was not permitted in this run, so nothing here rests on outside sources (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding for your own words, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your real experience, or say plainly it was not yours.

Hannah's message names her agenda: salary, notice period, the hybrid pattern, what is prompting the move, then the team and next steps. Rehearse bank A first (A1 to A4), then B2. Banks C to E are insurance.

| Type | What it scores |
|---|---|
| VAL | Past behaviour against the company's published values |
| EXP | Whether your own account of your work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | Reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinate with likely. If you work alongside a planning, warehouse or QA function, say with whom and how, in your own words; if you do not, or it is not part of your job, say so plainly and stay with the depots |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [grounded] | discovery | The quote touches deliveries without showing whether you track what suppliers are due to send. Answer slot: if you track supplier deliveries, say how, in your own words; if tracking is not part of your job, or someone else does it, say so plainly and stay with chasing suppliers when orders slip |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on it. Lead in the quote's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a defend-the-number probe (C1, E2). Say it at the sentence's scope, keeping "about a third" and "over a year" |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you produce any report on deliveries or stock, say what it covers and how often, in your own words; if you do not, say so plainly and stay with "I schedule deliveries for our three depots and chase suppliers when orders slip." |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. A length-of-experience line, not a gate, and your quote already reaches it in the advert's own terms |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says a spreadsheet, not which tool. Answer slot: say what the spreadsheet was built in, in your own words; if it was not Excel, say so plainly and say what you do use |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "Never used SAP." Then how you would learn an ERP, said as a plan and never as a past. The advert calls it a plus, not a requirement |
| F9 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | transferability | The quote says an in-house stock system and nothing about what it covers; the words stay there: "we run our own in-house stock system." Answer slot: say what you use it for, in your own words; if it is narrower than an ERP, say so plainly |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | medium | [grounded] | none | Gate, shown met: the figure sits inside the advert's band. Say it as the quote has it, a hope and not a floor |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Gate, shown met at two days. Keep both halves of your own sentence: fine with two, not wanting more than three |
| F12 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and the call will ask for it. Nothing is coached around it |
| F13 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. Say it as the quote has it, plainly and once |

## Persona table

The loop is established by Hannah's own words: one 30-minute phone call with her, covering the topics she listed. No archetype fallback is used, and no values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly logistics and motivation questions: pay, notice, hybrid, why move | High. Her message lists exactly these four topics and says she will then describe the team, so most of the 30 minutes is this register | Short arcs rehearsed aloud; treat each casual question as scored (A1 to A5) |
| B. Skeptic | Quiet probing of gaps: SAP, manufacturing versus wholesale, why now | Medium. Her list has no skills probe, but a screen usually checks the advert's gaps, and your material states one (F8) | Rehearse the SAP answer until it is boring (B2); keep bridges to what your quotes carry |
| C. Data-Driven Prober | Asks how the one-third figure was counted | Low. Not on her list, but the figure is the one number she could pick up | Know what you can and cannot say about how it was counted (C1) |
| D. Case / Strategist | A light live problem on late supplier orders or stock records | Low. Not on her list; the advert's duties make a casual scenario possible | Clarify, structure, then answer aloud (D1 to D3) |
| E. Pressure | Time-boxed challenge on why you over someone with SAP | Low. A friendly screen rarely turns on this, but it is cheap to rehearse | Hold through two follow-ups, concede specifically (E1, E2) |

## Question banks

Highest-ROI prep: B2, the SAP question. Your own message states the gap, so it is the objection most likely to arrive in some form, and a calm, rehearsed answer changes the call.

### A. Conversational (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: what do you do now, and what's prompting a move?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three beats, each a clause the quotes state, in your own words: the role (4 years, logistics coordinator, a building-supplies wholesaler); the job (scheduling deliveries for three depots, chasing suppliers when orders slip); the reason (the Bristol office closing next year, the only offer relocating to Reading, which you don't want). Say the last beat flat, once. Answer slot: if something in the advert drew you beyond the move itself, say what, in your own words; if the move is the reason and nothing more, say so plainly and stay with the Reading offer | F6 and F13 are the evidence; the question is Hannah's own agenda item. EXP because it tests that your account of your own work is consistent |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | State it as the quote has it: "I'm hoping for £42,000." Then stop and let her respond; the advert's band, "£38,000–£44,000", already contains it. Answer slot: before Thursday, decide whether £42,000 is a hope or a floor; your words so far say a hope, and the pack knows no floor, so it names none | F10 is the evidence. JD because the advert states the band the answer is scored against |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Lead with the first half of your own sentence: "I live in north Bristol, so two days at Avonmouth is fine." Give the limit if the pattern comes up as open-ended, in the quote's terms: "I wouldn't want more than three." Do not describe yourself as flexible about days; the quote has a limit. Answer slot: if she asks which days or how you would get to Avonmouth, answer from your own plans; the material says neither | F11 is the evidence. JD because the advert sets the two-day pattern |
| A4 | "What's your notice period, and is there any room to start earlier?" | JD | [grounded] | Give your notice period as it stands in your contract. Answer slot: if you have not checked the contract, say so plainly and say you will confirm by message after the call; whether any of it can be shortened is yours to say only if you know. The pack holds no figure for it | F12 is a gate the material does not establish, so the cell asks nothing and coaches no number. JD because it is a term the role depends on |
| A5 | "What do you know about us, and why this role?" | CO | [grounded] | Use only what the advert states: a diagnostic-test manufacturer of about 400 staff, with a role between planning, the warehouse and QA. Research was not permitted in this run, so nothing further is sourced. Answer slot: before Thursday, read their own site and say what you found in your own words; if you found nothing, say so plainly and ask her about the team instead | No row carries this; it is the advert's own opening line. CO because it tests homework, kept honest to what is sourced |

### B. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of the advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Name one area in a sentence, then the nearest thing your quotes carry. Your material offers two: SAP, where the quote is "Never used SAP — we run our own in-house stock system.", and coordinating across planning, the warehouse and QA, where the nearest is "I schedule deliveries for our three depots and chase suppliers when orders slip." Which is weaker is yours to judge. Then a plan, said as a plan and never as a past | F8 and F1 are the two likeliest answers. JD because it scores the advert's list directly |
| B2 | "The advert mentions SAP or similar, and you haven't used SAP. How would you get up to speed on an ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The highest-ROI rehearsal. Concede in the quote's words: "Never used SAP." Then the nearest thing the quote carries: "we run our own in-house stock system." Then a plan in your own words, what you would learn first and who you would ask, as a plan and never as a past. Follow-up one, "So no ERP at all?": restate the quote. Answer slot: say what you use the in-house system for, in your own words; if it is narrower than an ERP, say so plainly. Follow-up two, "How long would it take?": answer slot: give a time only if you know one; if you do not, say that plainly and say what you would look at first. Limit named before asked: the quote says nothing about what the in-house system covers, so do not call it similar unless you can say how | F8 is the stated gap and F9 its only bridge. JD because the advert lists it, as a plus |
| B3 | "This is a manufacturer and you've been at a wholesaler. What would be different about the job?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip. Answer slot: the advert's planning, warehouse and QA line makes a probe on that likely. If you work alongside such a function, say with whom and how, in your own words; if you do not, or it is not part of your job, say so plainly and stay with the depots. Then what you would want to learn about how the factory works, as a plan | F1 is the transferability row and the second likeliest objection. JD because it scores the production-scheduling line |
| B4 | "Why leave now, and would you take the Reading offer if this doesn't come off?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold the quote's position: "the only offer is relocating to Reading, which I don't want." Do not hedge into maybe; the quote has no maybe. Answer slot: if you have a date by which Reading has to be decided, say so; if you do not, say that plainly. If she asks whether you are talking to other employers, answer truthfully; the material says nothing about it | F13 is the evidence. EXP because it tests whether the account of why you are leaving stays consistent under a second question |
| B5 | "You've said £42,000. What makes that the right number for you?" | JD | [grounded] "I'm hoping for £42,000." | Hold the quote: it is what you are hoping for. Answer slot: say what you base the figure on, in your own words; if it is simply where you hope to land within the advert's band, say that plainly. Do not present it as a floor | F10 is the evidence. JD because the band is the advert's |

### C. Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through that one-third drop in discrepancies: how were they counted, and what part was yours?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say it at the sentence's scope: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year; keep "about". Answer slots, each in your own words: how discrepancies were counted; what the figure is most sensitive to; the assumption behind it you would defend least; which part was yours. "I don't know exactly how it was counted" is an honest branch if true. Do not say the rebuild cut or caused the fall unless you can say how you know | F4 is the headline figure. EXP because defend-the-number is the probe a figure draws |
| C2 | "Which tools did you use for the stock-count spreadsheet?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The quote says a spreadsheet and does not name a tool. Answer slot: say what it was built in, in your own words; if it was not Excel, say so plainly and say what you do use. Do not claim more skill than you can show on the spot | F7 is a discovery row. The label is inferred because the link from spreadsheet to the advert's Excel line is this pack's |
| C3 | "Tell me about reporting you've done on delivery or dispatch performance." | JD | [grounded] | Your quotes carry no reporting. Pick a report you actually produced or contributed to on deliveries or stock: it needs a name, who received it and how often. If no such report comes to mind, say so plainly, then give the nearest thing your material does carry, "I schedule deliveries for our three depots and chase suppliers when orders slip.", or how you would build one | F5 is the silent row; the advert's weekly on-time dispatch line raises it. An open prompt, so it supplies no event |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery that planning is waiting on will be a week late. What do you do?" | JD | [generic] | Structure it aloud: what exactly is late and what depends on it; who needs to know now; what the supplier can commit to and by when; the options if it cannot be met; how you record it and follow up. The question needs no claim about your past, so the guidance makes none | The advert's chase-late-orders line (F2, F3) as a live decision. JD with CASE delivery; generic because it is a pattern, not a fact about this employer |
| D2 | "The system says there is stock of an item and the warehouse cannot find it. What do you check first?" | JD | [generic] | Structure it: confirm what was counted and when; check recent movements; check the location and any pending transactions; decide whether to adjust the record or recount; note the cause so it does not repeat. No claim about your past | The advert's accurate-stock-records line (F4) as a live decision. JD with CASE delivery |
| D3 | "On-time dispatch has dropped this month. How would you find out why?" | CASE | [generic] | Clarify first: how on-time is defined and measured, and what changed. Then split by where it slipped, supplier, picking, QA release or transport; decide what to check first; say what you would report. No claim about your past | F5's requirement as a live problem; CASE because it scores reasoning, not experience |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause, restate the question, then hold on what the quotes carry: four years as a logistics coordinator, scheduling deliveries for three depots and chasing suppliers when orders slip. Concede specifically: "Never used SAP." Hold through two follow-ups by returning to those quotes, never by adding to them | F8 is the pressure point; F6 and F3 are the held ground. JD because it scores the advert's plus against the rest |
| E2 | "That one-third result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slot: say which part was yours, in your own words; if you cannot separate the rebuild from other changes that year, say so plainly. Concede that specifically, and do not fold on the sentence itself | F4's attribution probe. EXP because it tests exactly what was yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, B3 |
| Track supplier deliveries and chase late orders | D1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | C3, D3 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, B2, E1 |
| £38,000–£44,000 | A2, B5 |
| Hybrid, two days at Avonmouth | A3 |
| Notice period | A4 |
| What is prompting a move | A1, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which systems does the team use today for stock and scheduling, and how much would I need to learn in the first month?" | Turns the SAP gap into a forward-looking question and shows you are thinking about the work |
| R2 | "How do planning, the warehouse and QA hand schedules to each other now, and where does it tend to slip?" | Asks about the advert's central coordination line and invites her to describe the real problem |
| R3 | "What does the weekly on-time dispatch report look like today, and who reads it?" | Shows you read the reporting duty as a real deliverable |
| R4 | "How are the two Avonmouth days usually set: fixed days, or agreed by the team?" | Follows from your own hybrid answer and checks the pattern is workable |
| R5 | "After this call, what are the next stages, who would I meet, and what would each focus on?" | She has said she will cover next steps; this gets detail and signals interest in the process |
| R6 | "What would a good first 90 days look like in this role?" | Gives her a chance to describe the job's priorities, which you can then speak to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says delivery scheduling for depots, not production scheduling. B3's slot stays inside the depots |
| Cut or reduced discrepancies by a third | Inflated form of F4 | F4's quote at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The pack's observation: your sentence does not say the rebuild caused the fall |
| Advanced Excel skills, or that the spreadsheet was built in Excel | Inflated form of F7 | F7's quote at its own scope. The pack's observation: your material says a spreadsheet, not the tool. C2's slot asks only what it was built in |
| ERP or SAP experience | Negative you stated, F8 | The plain acknowledgment: "Never used SAP." Then a plan, never a past |
| The in-house stock system is similar to an ERP | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." The pack's observation: your material does not say what it covers |
| £42,000 is my minimum or non-negotiable | Inflated form of F10 | The quote: "I'm hoping for £42,000." The pack's observation: your words say a hope, not a floor |
| Flexible on how many days in the office | Contradicted by F11 | The quote: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| Open to relocating to Reading | Contradicted by F13 | The quote: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

## Sources

Provided documents: the advert text you pasted, your notes about yourself, and Hannah Lowther's LinkedIn message.

Searches sent, all refused (no permission granted for web search): "Quillmoor Diagnostics values"; "Quillmoor Diagnostics interview process operations coordinator"; "Quillmoor Diagnostics strategy news Avonmouth"; "Hannah Lowther Quillmoor Diagnostics". No fetches sent. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have fed a values cheat sheet only if a values round were detected; none is, so this moved nothing here. A5 stays limited to the advert |
| 2. Interview process, role family | unavailable | Would have confirmed the loop beyond this call. Persona weights rest on Hannah's own message instead |
| 3. Strategy and recent news | unavailable | Would have grounded A5 and a CO question; both stay limited to the advert |
| 4. Interviewer name and company | unavailable | Would have fed an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative role JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → resolves F12 and gives A4 a real answer instead of a prompt to check
- Your CV → the fit snapshot's evidence cells become CV quotes, and any CV line the message does not carry adds rows
- The stock-count discrepancy log, or the before and after counts → F4 can rise from medium confidence and C1 and E2 can rest on inspected numbers
- Your answers to the slots in F1, F2, F5, F7 and F9 (outside any rehearsal) → those rows become quoted evidence and the B3, C2 and C3 guidance regenerates
- Web search permission → rows 1 to 4 above run, giving a values read, loop detail, a strategy-grounded A5 and, if a public footprint is found, an interviewer read
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and recent organisation context for CO questions
- Hannah's prep email, if she sends one → any pre-declared focus areas beyond the four she named
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and allowed strategies per gap, replacing the locally built prohibited list
