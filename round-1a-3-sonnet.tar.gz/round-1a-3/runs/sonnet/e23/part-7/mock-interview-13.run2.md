I'll read the reference files the skill points to before building the pack.
Your prep pack for Thursday's call with Hannah is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/e23/part-7/rooms/case-13-denied-1e38b3ff/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It has 18 rehearsal questions with answer guidance built only on what you told me. It also has a fit table against the advert, reverse questions for Hannah, and a list of claims not to make.

Web search was blocked in this session, so there's nothing about Quillmoor beyond the advert. The "why Quillmoor" answer (B4) is a template you fill in from the advert. I built it for a recruiter screen, which Hannah's message makes clear it is.

- **Highest-ROI prep:** B1, "what have you done that's closest to coordinating production schedules between planning, the warehouse and QA?" Your material says delivery scheduling for three depots, not production scheduling. Rehearse the honest answer until it's boring.
- **SAP:** you've never used it, and the advert only calls it a plus. B2 and B5 cover it, including a plan for how you'd learn it.
- **Excel:** you said you rebuilt a stock-count spreadsheet, not that it was in Excel, so C3 leaves a slot for you to say which tool it was.
- **Salary and hybrid:** "hoping for £42,000" is inside the £38,000–£44,000 range, and the pack keeps it as a hope, not a floor. Two days at Avonmouth is fine. "Wouldn't want more than three" stays a preference.
- **Why you're moving:** the pack tells you not to say you're being made redundant. What you told me is that the office is closing and the only offer is Reading.

I can play Hannah and run any question live, starting with B1, if you say the word. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word.

What is your notice period? She has it on her agenda and nothing you've told me covers it, so A5 can't be rehearsed until I know.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Candidate: Sam. Round: recruiter screen, a 30-minute phone call on Thursday at 2pm with Hannah Lowther (Talent Partner), who will ring the mobile number on your application. Her stated agenda, in her words: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.

This pack was built from the advert, Hannah's LinkedIn message and your own account of your background. No web research could run (see Sources), so there is no company-specific content beyond the advert.

## How to use this pack

- Personas describe how a question arrives. Types describe what is being scored.
- Type tags: VAL (behavioral and values alignment), EXP (work-experience deep-dive), JD (role and advert requirements), CO (company and strategy knowledge), CASE (a live problem from the role).
- Answer guidance is scaffolding, not a script. Everything it says about your past rests on a sentence you wrote, quoted beside it. Anything marked answer slot is for you to fill from your own experience or to answer plainly that it was not yours.
- Highest-ROI prep: B1, the production-scheduling question. It is the advert's headline duty and your material is thinnest against it. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: four years, logistics coordinator, a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of your scheduling involved working with a warehouse or quality team, say how and what your part was, in your own words; if it did not, or it was not yours, say so plainly and stay with the three depots |
| F3 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap. Say it in the quote's own terms: you chase suppliers when orders slip. Expect a probe on how, since nothing is inspected behind the line, and answer it in your own words |
| F4 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | discovery | Scheduling deliveries touches tracking without showing it. Answer slot: if you keep track of supplier deliveries in any way, say how, in your own words; if you do not, or it is not yours, say so plainly and return to chasing suppliers when orders slip |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a probe on it. Lead with what you rebuilt, then "about a third over a year" at its own scope, never as an exact number. The defend-the-number slots are in C1 and D2 |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on delivery performance. Answer slot: the advert's weekly dispatch line makes a probe likely. If you report on delivery performance, say what and how often, in your own words; if you do not, or it is not yours, say so plainly and return to the stock-count spreadsheet you rebuilt |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says spreadsheet and your material does not say which tool. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, say which and say where, if anywhere, you have used Excel; if you have not, say so plainly and stay with the rebuild |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | low | [grounded] | capability | A gap wording cannot close for SAP, and you said so. Words: "I've never used SAP." The advert marks ERP experience a plus, which is the pack's observation about the advert. The in-house system stays at its own scope: "we run our own in-house stock system." Answer slot: if Hannah asks whether it counts as similar, say what you used it for, in your own words; if you used it in a narrower way, or it was not yours, say so plainly. Then how you would learn SAP, said as a plan and never as a past |
| F9 | "salary expectations" — Hannah's message; "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advert's range. Say it as you said it to me, as a hope: "I'm hoping for £42,000." It is a hope in your message and the words keep it one |
| F10 | "how the hybrid pattern would work for you" — Hannah's message; "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Met in your own words. Say the first clause as given. The last clause is a preference ("wouldn't want"), and the words keep it one |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is surfaced here and not bridged, and the one question about it is in the message that presented this pack |
| F12 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. Say the reason as you gave it. Your material says the office is closing and the only offer is Reading, which is not the same as your role being cut; see the prohibited list |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, agenda-led phone call that works through salary, notice, hybrid and motivation | High. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah's message sets a four-item agenda that is exactly that: knockout checks in a friendly register | Treat every casual question as scored. Answer what was asked in a sentence or two, give the number or fact, then stop. Have the 90-second background arc ready (A2) |
| B. Skeptic | Quiet probing of the gaps and of "why leave, why here, why now" | High. The prior says light, but your own material states a gap (SAP) and is thin on the headline duty, and Hannah has asked about motivation directly | Rehearse B1 until it is boring. Name the limit plainly and calmly, then give the nearest thing your quotes carry and a future-tense plan |
| C. Data-Driven Prober | Asks how the stock-count figure was counted and which tools you use | Medium. Recruiters usually stop at one follow-up, but the "about a third" figure is on your account of yourself and is the easiest number to probe | Know what you can and cannot say about how the figure was counted, and say plainly if you do not know |
| D. Pressure / Stress Interviewer | Time-boxed "why you" and a push on salary | Low to medium. A recruiter is unlikely to stress-test composure, but a salary push is a normal part of the call | Pause, restate the question, hold your answer through two follow-ups, concede only what is true |
| E. Case / Strategist | A short live scenario from the role | Low. She said she will tell you about the team after her questions, which points away from a case, but the next round with the hiring manager is likely to carry one | Clarify, then structure, then answer, thinking aloud |

## Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A2 |
| Coordinate production schedules between planning, the warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | E1; no separate JD question on tracking, because F4 is an answer slot inside E1 and B1 |
| Keep stock records accurate | C2, C1 |
| Report weekly on on-time dispatch | E2 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B2 |
| £38,000–£44,000 | A4, D3 |
| Hybrid, two days at Avonmouth | A3 |
| Notice period and motivation (Hannah's agenda) | A5, A1 |

## Question banks

### A. Conversational / Rapport Builder (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, what's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Story-mapped on F12, with only the beats the quote states: the Bristol office is closing next year, the only offer is relocating to Reading, you don't want that. Say it plainly in your own words, in one breath, with no comment on your employer. Answer slot: a follow-up on why Quillmoor is likely. If something in the advert drew you, say what, in your own words; if nothing specific did, say so plainly and stay with the reason you are looking | Hannah named this item in her agenda, so it is near certain. EXP because it tests whether the account of the move holds up against the employment history; there is no motivation tag, and the F12 row carries the evidence |
| A2 | "The advert asks for two or more years in operations or logistics coordination. Walk me through your background against that." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with these beats only: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; the stock-count spreadsheet rebuild, with the fall "about a third over a year" at its own scope. Then stop. Do not add a beat you could not defend under a follow-up | The requirement is the advert's first, and the biography question is the one every recruiter opens with. F1 is the evidence; JD because it scores the stated requirement, delivered as a biography |
| A3 | "The role is hybrid, two days a week at our Avonmouth site. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Answer what she asked first, in the quote's own terms: "I live in north Bristol, so two days at Avonmouth is fine." The second clause is a preference. If the pattern comes up as possibly changing, say it as the quote does, "I wouldn't want more than three", and keep it that soft. Answer slot: if she asks how you would get to Avonmouth, answer from what you know of the route, and if you have not yet worked it out, say so plainly | Hannah listed hybrid in her agenda. F10 is the evidence; JD because the two-day pattern is an advert term |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | One number, said as a hope: "I'm hoping for £42,000." Then stop and let her respond. Do not turn it into a minimum or add a justification your material does not carry. Answer slot: if she asks what you earn now, decide before Thursday whether you will share it and what you will say; your material does not carry the figure and the pack does not supply one | Salary is the first item in her agenda and a knockout check in a friendly register. F9 is the evidence; JD because the range is an advert term |
| A5 | "And what's your notice period?" | JD | [grounded] | Your material does not establish it, so the pack supplies nothing. Answer slot: state the notice period in your contract, in weeks or months, exactly as written; if you are unsure, check the contract before Thursday; say a part of it is flexible only if you know that from your employer or your contract | Hannah named it in her agenda. F11 is a term the material does not establish; JD because it bears on the start date the advert implies |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The core of this job is coordinating production schedules between planning, the warehouse and QA. What have you done that's closest to that?" | JD | [grounded] "I schedule deliveries for our three depots"; "chase suppliers when orders slip" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I schedule deliveries for our three depots", then "chase suppliers when orders slip". Answer slot: if any of your scheduling involved working with a warehouse or quality team, say how and what your part was, in your own words; if it did not, or it was not yours, say so plainly and stay with the three depots and the suppliers. Follow-up 1, "is that production scheduling?": your material says delivery scheduling, so say what your work was and let her draw the comparison. Follow-up 2, "what would you need to learn?": answer in future tense, what you would ask planning, the warehouse and QA in your first weeks, as a plan and never as a past. Follow-up 3, "what makes you think you can do it?": return to the two quotes, never to a claim wider than them | F2 is the evidence and the likeliest place to be probed, since it is the advert's first duty and your quote sits beside it, not on it. JD because it scores the stated responsibility |
| B2 | "You've never used SAP. How would you handle that in this role?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | The plain acknowledgment is yours: "I've never used SAP", then the quote at its scope: "we run our own in-house stock system." Answer slot: if she asks whether the in-house system counts as similar, say what you used it for, in your own words; if you used it in a narrower way, or it was not yours, say so plainly. Close with how you would learn SAP, in future tense | F8 is the evidence, and the negative is one you stated, so the question may use it. JD because the advert names ERP experience |
| B3 | "What is it about the Reading offer that you don't want?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Hold the quote's scope: the only offer is relocating to Reading, which you don't want. Answer slot: your material gives no reason beyond that. If there is one, say it in your own words and keep it about your situation, not your employer; if you would rather not go into it, say so plainly and return to the fact that you live in north Bristol | A recruiter checks whether a stated reason for moving is the whole reason. F12 is the evidence; EXP because it tests the account against the history |
| B4 | "Why Quillmoor, and why this role rather than another coordinator job?" | CO | [grounded] "chase suppliers when orders slip"; "I live in north Bristol" | Selection scaffold from the advert, since no company research was possible: choose one thing in the advert that matches work you have actually done, for example the line about chasing late orders against your quote "chase suppliers when orders slip", and say why it interests you in your own words. If nothing in the advert stands out beyond the location and the pay, say so plainly, then give the nearest thing your material carries, which is that you live in north Bristol | This is the Skeptic's "why here" question, and without research there is nothing company-specific to add. CO because it tests homework; the F3 row carries the one match to the advert |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system"; "I rebuilt our stock-count spreadsheet" | Name one gap first and calmly. The one your material states is SAP: "I've never used SAP", then how you would learn it, in future tense. Answer slot: the advert asks for confidence with Excel. If the spreadsheet you rebuilt was in Excel, say what you did in it, in your own words; if it was another tool, say which; if you have not used Excel much, say so plainly | The standard Skeptic stem, aimed at the two requirements where your material is thinnest. F7 and F8 are the evidence; JD because it scores the advert's requirements |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what you rebuilt and the figure at its own scope: about a third, over a year. Answer slot: the four things a figure raises. How it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; "I don't know how it was counted" is an honest answer if it is true. Never make it exact | The only figure in your material, so a magnet target. F5 is the evidence; EXP because it tests whether the claim survives scrutiny |
| C2 | "How do you keep stock records accurate day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Start with the rebuild as quoted. Answer slot: the advert's line on keeping stock records accurate makes a probe on your routine likely. If you have a routine for it, say what it is, in your own words; if the spreadsheet rebuild is the whole of what you did, say so plainly | The advert's stock-accuracy duty needs a rehearsed answer. F5 is the evidence; JD because it scores the stated responsibility |
| C3 | "How confident are you in Excel, and what do you do in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot only, because the quote says spreadsheet and not Excel: if it was Excel, say what you did in it, in your own words; if it was another tool, say which, and say where, if anywhere, you have used Excel; if you have not used it much, say so plainly and stay with the rebuild. Do not call yourself advanced | Excel is one of the advert's listed requirements and the one a phone screener can check by asking. F7 is the evidence; JD because it scores the stated requirement |

### D. Pressure / Stress Interviewer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should I put you through to the hiring manager?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Pause, then hold on the three quotes only: four years as a logistics coordinator at a building-supplies wholesaler, you chase suppliers when orders slip, you rebuilt the stock-count spreadsheet. If she pushes on SAP or production, concede exactly what you said: "I've never used SAP." Never fold on what the quotes carry, and never claim more to restore the mood | A time-boxed "why you" is the standard pressure stem and recruiters use it to decide who goes forward. F1, F3 and F5 are the evidence; JD because it scores fit against the advert |
| D2 | "That result on stock counts. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold what the quote says: you rebuilt the spreadsheet. Answer slot: whether the fall in discrepancies was down to the rebuild, to other people's work, or to both. Say which parts were yours, in your own words; if you do not know how much of the fall was the rebuild, say so plainly. Hold through two follow-ups, concede only what is true | The attribution probe exists to catch inflation. F5 is the evidence; EXP because it tests what was actually yours |
| D3 | "£42,000 is near the top of our range. Could you do £40,000?" | JD | [grounded] "I'm hoping for £42,000" | Hold calmly: "I'm hoping for £42,000", and let the silence do the work. Your message says hoping, so the pack states no minimum for you. Answer slot: if there is a number below which you would decline, set it before Thursday and say it plainly; if there is not, say what you would actually weigh | Salary pushback is a normal part of the call. F9 is the evidence; JD because the range is an advert term |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you at 2pm that a delivery needed for tomorrow's production run will be two days late. What do you do first?" | CASE | [generic] | Clarify before structuring: what the delivery feeds, what stock is on hand, who else is affected. Then objective, options (a partial delivery, an alternative source, a changed schedule), who you would tell and when, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing duty. Generic because it is a pattern for the problem and not a fact about this employer |
| E2 | "On-time dispatch dropped this week. How would you find out why?" | CASE | [generic] | Clarify how on-time is defined and what changed, then split by product, depot or site, supplier and day, check the late orders one by one, and say what you would report and to whom. Think aloud and name the assumption you would test first. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's weekly on-time dispatch report. Generic for the same reason as E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Is this a new role or a replacement, and who would it report to?" | It shows you are thinking about where the role sits, and it is a question a Talent Partner can answer |
| R2 | "What would a good first three months look like in this role?" | It turns the call from screening into planning, and her answer tells you what is weighted in practice |
| R3 | "Which system does the team use for stock and production planning today?" | It is the honest follow-up to SAP: you learn whether it is SAP or something else before the next round |
| R4 | "How are the two Avonmouth days set, as fixed days or agreed with the team?" | It shows you have taken the hybrid pattern seriously, and it is a real planning question for you |
| R5 | "How is on-time dispatch measured today, and who reads the weekly report?" | It uses the advert's own duty and shows you are already thinking about the job |
| R6 | "After this call, what are the next steps and how long do they usually take?" | She has said she will cover next steps, so use it to confirm the timeline rather than ask it fresh |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| That your role is being made redundant or cut | Inflated form of F12 | F12's quote at its own scope. The limit is the pack's observation: the material says the office is closing and the only offer is Reading |
| That you have used SAP or an ERP | Negative you stated, F8 | The plain acknowledgment: "I've never used SAP." The in-house stock system stays at its own scope |
| That you are confident or advanced in Excel | Inflated form of F7 | "I rebuilt our stock-count spreadsheet." The limit is the pack's observation: the material says spreadsheet, not Excel |
| That you have scheduled production or coordinated planning, the warehouse and QA | Inflated form of F2 | "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries, not production. B1's slot stays inside the depots |
| That your spreadsheet cut discrepancies by a third | Inflated form of F5 | F5's quote at its own scope: "discrepancies fell by about a third over a year". The limit is the pack's observation: the material says the rebuild and the fall, not that one caused the other. C1 and D2 slots ask only what was counted and what was yours |
| That £42,000 is your minimum | Inflated form of F9 | "I'm hoping for £42,000." The material says a hope, not a floor |
| That you will not work more than three days a week on site | Inflated form of F10 | "I wouldn't want more than three." The material says a preference, not a limit |

## Sources

Provided documents: the advert as pasted; Hannah Lowther's LinkedIn message as pasted; your account of your background, pasted. No dossier was in context.

Searches sent, all refused because the host had not granted web search permission, so nothing was returned and nothing from the web is used in this pack:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics strategy news" — refused
- "Hannah Lowther Quillmoor Diagnostics" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search was refused. It would have fed the CO question B4 and a values-style round check; with no loop source documenting one, no values cheat sheet is built |
| 2. Quillmoor Diagnostics interview process, operations coordinator | skipped | Hannah's message establishes the loop for this session: one 30-minute phone call with her, covering a stated agenda. Persona weights follow the recruiter-screen prior |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Search was refused. It would have fed CO and CASE content; B4 is a selection scaffold built from the advert, and no grounding brief is included |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Search was refused. It would have fed an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative operations coordinator advert | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F11 stops being a surfaced gate and A5 becomes a specific rehearsal
- Your answers to the slots in F2, F4, F6, F7 and F8, pasted in your own words → those rows move from discovery to grounded evidence and B1, B2, C2 and C3 become story-mapped
- Your CV → every quote in the fit snapshot gets a second source and the medium rows get a chance to rise
- Web search permission granted → targets 1, 3 and 4 run: a values and strategy read for B4 and Hannah's public footprint for a tailored reverse question
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief and sharper CO and CASE questions
- Hannah's answer to "what will the hiring-manager round cover" → coverage for any pre-declared deliverable, and persona weights for that round
- A dossier from a prior evaluation of this role → a pre-ranked objection and a prohibited-claims list that does not have to be inferred
