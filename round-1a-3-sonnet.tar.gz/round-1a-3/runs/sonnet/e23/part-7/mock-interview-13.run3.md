I'll read the reference files the skill points to before building the pack.
Your prep pack is written and saved. I'm finishing the message that presents it.

The pack is at `/var/tmp/tuesday-measure/1a3/runs/sonnet/e23/part-7/rooms/case-13-denied-f7600c1b/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It has 18 questions, grouped by how Hannah might ask them. Hannah's own four topics (salary, notice, hybrid, the move) are in the first group.

I built it from the advert, Hannah's message and your notes. Web search was refused, so nothing in it comes from outside research. It stays at the advert's level on Quillmoor, and there's no interviewer read on Hannah.

- **Most likely objection:** SAP (B2). Your own message says you've never used it and the advert names it. Rehearse that answer first.
- **Your notice period:** the pack writes no words for it, because your material doesn't say what it is. Read the figure off your contract before Thursday.
- **Salary:** £42,000 is inside the £38,000–£44,000 range. The pack treats it as a hope, as you phrased it, so decide whether it's also your floor before Thursday.

Say the word and I'll play Hannah on B2, the SAP question, and give feedback afterwards. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

1. Can you paste your CV or application text as submitted? Hannah has it in front of her, and it would let the evidence rows quote it instead of your notes.
2. What is your notice period, as your contract states it? It would give the notice-period question real words instead of a blank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, 30-minute phone call. Hannah Lowther, Talent Partner, will ring the mobile number on your application.
**Her stated agenda (her LinkedIn message):** salary expectations, notice period, how the hybrid pattern would work for you, what's prompting a move; then the team and next steps.
**Built on:** the advert, Hannah's message and your notes. No CV was supplied, and web research was refused (see Sources), so nothing here rests on anything about Quillmoor beyond the advert.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for your own words, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether what you say you did survives follow-up, and what was actually you |
| JD | Whether you can do the stated role, gaps included |
| CO | Homework on the company and why this one |
| CASE | Structure and reasoning on a live problem from the role |

An **answer slot** is an instruction for the interview, not a question for you now: it tells you where an interviewer is likely to probe and gives two honest branches, one for if you did the thing and one for if you didn't, or it wasn't yours. Either branch is a good answer. Provenance labels: `[grounded]` traces to your material or the advert, `[inferred]` is this pack's derivation, `[generic]` is a pattern with no claim about you or Quillmoor.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, with nothing inspected behind it, and the words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's line makes a probe on who else was involved likely. If you worked with other teams in scheduling those deliveries, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the chasing in the quote's own terms: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote already reaches the requirement. The figure is "about a third over a year", and it stays that way; the defend-the-number slots it raises are in C1 |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on anything like this, and the pack writes no words for it. Answer slot: the advert's line makes a probe likely. If you report on anything about deliveries or orders, say what, to whom and how often, in your own words; if you do not, or it was not yours, say so plainly and return to scheduling deliveries and chasing suppliers when orders slip |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | The quote already reaches the requirement in the advert's own terms. Say it as written |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and not what you did inside it. Answer slot: the advert's line makes a probe on the tool likely. If it was Excel, say what you did in it, in your own words; if it was another tool, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | Your words: "I've never used SAP; we run our own in-house stock system." The limit is the pack's observation: your material does not say what the in-house system does or what you did in it. Answer slot: if you worked in it, say for what, in your own words, describing what it does rather than what it is called; if you did not use it directly, say so plainly |
| F8 | "£38,000–£44,000" — advert; "salary expectations" — Hannah's message | "I'm hoping for £42,000" — your message | high | [grounded] | none | Inside the advertised range, £2,000 below its top. It is a hope as you stated it, and your message says nothing about how firm it is, so say it as the hope it is: "I'm hoping for £42,000" |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert; "how the hybrid pattern would work for you" — Hannah's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The two days are met on your own word. Say it as you said it, with three as the most you would want |
| F10 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | A plain circumstance, in your own terms, and nothing in your material adds to it. Say it as written and add nothing about your employer |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and the pack writes no words for it |

## Persona table

The loop for this session is established by Hannah's own message: one 30-minute call with her, then the team and next steps. Nothing is known about later rounds, so the pack makes no claim about them.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, unstructured; her four announced topics arrive as chat | Highest. A recruiter screen starts here, and her message lists four logistics topics and then her own pitch of the team. Casual questions are still scored | Pre-script the four topics in the words your quotes carry; keep each to a few sentences; never answer her questions about the role with "I think you've covered it" |
| B. Skeptic | Quiet probing of the thin spots: the move, SAP, production scheduling, reporting | Second. The light-Skeptic prior for a recruiter screen, and F7, F1 and F4 are where your material is thinnest | Rehearse B2 until it is boring: say the limit in your own words, then stop |
| C. Data-Driven Prober | A light probe on the figure or the spreadsheet | Third. She named no numbers in her agenda, but the figure on your application is the likeliest thing to be asked about | Know what you can and cannot say about how the figure was counted, and say plainly where you don't know |
| D. Pressure | A time-boxed or pushed version of the motive or the chasing question | Low. A salary or motive question can arrive with pushback, but nothing in her message signals a stress style | Pause, restate, hold, then concede only what is true |
| E. Case / Strategist | A quick live scenario from the role | Low. She named no case, and recruiter screens rarely run one | Clarify, structure, answer; think aloud |
| F. Values / Behavioral | A "tell me about a time" prompt | Low. No source I read names a values round, and her agenda has none | Insurance only |

**Highest-ROI prep: B2**, the SAP question. It is the one place your own message states an absence and the advert names the thing, so it will arrive in some form. A1, A3, A4 and A5 are certain to be asked, but they need only your own words said cleanly, and A5 needs a fact only you hold.

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So what's prompting the move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it in your own order: you're looking because the Bristol office is closing next year, the only offer is relocating to Reading, and that is not something you want. Keep it a circumstance rather than a grievance, one or two sentences, then stop and let her take the next thing. Nothing more is supplied about the closure or your employer, because your material carries nothing more | Hannah named this as one of her four topics, so it is near-certain; F10 holds the only quote the pack has. EXP because it checks what actually happened rather than an aspiration |
| A2 | "Tell me about your background in logistics coordination." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped on F5, F2 and F3, in the order the advert lists its duties: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down about a third over a year. Tell it in your own words in about 90 seconds. No beat beyond these is supplied; the probes behind each beat are rehearsed in B3, C1, C2 and D1 | Scores the 2+ years requirement (F5) and sets up everything she may probe next. JD because the advert's own requirement is what it tests |
| A3 | "What are you looking for salary-wise?" | JD | [grounded] "I'm hoping for £42,000" | Say it as you said it: "I'm hoping for £42,000." The advertised range is £38,000–£44,000, so the figure sits inside it. If she presses for flexibility, answer only from a number you settled on before the call; the pack holds none | Hannah named this topic, so it is near-certain; F8 has the quote. JD because the advert states the range |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it as you said it: you live in north Bristol, two days at Avonmouth is fine, and three is the most you would want. State the limit once and stop. Commute time and how you travel are not in your material, so nothing is written about them; say them only if they are true and she asks | Named by Hannah; F9 has the quote. JD because the advert states the two days |
| A5 | "What's your notice period, and is there any flexibility on it?" | JD | [grounded] | The pack has nothing on your notice, so it writes no words. Before Thursday, read the figure off your contract rather than recalling it, and say it once with its unit. Whether any part of it can be shortened is a fact you would need to know before offering it, and a start date is a promise, so give only one you can keep | Named by Hannah; F11 is a gate row, surfaced and not bridged. JD is the nearest of the five types, since it scores a term of the offer rather than a duty |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why Quillmoor, and why now?" | CO | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want"; "I live in north Bristol, so two days at Avonmouth is fine" | Two parts. Why now is the sentence you gave: the Bristol office is closing next year and the only offer is Reading, which you don't want. Why here is yours to name, and it has to be true. Answer slot: the advert gives you a diagnostic-test manufacturer of about 400 staff, a site at Avonmouth, and a role between planning, the warehouse and QA; say in your own words which of those draws you; if the honest answer is mostly that it is near where you live in north Bristol, say that plainly rather than reaching for something larger. Add one fact about Quillmoor you found yourself on their own site, since the pack could not research any | Motivation consistency is what a skeptical screen scores (F10). CO because it tests homework; the pack's research was refused, so this stays at the advert's altitude |
| B2 | "The advert mentions ERP experience, SAP or similar. Where are you on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | The deepest rehearsal in the pack; hold the structure through three levels. Level 1: say it plainly, in your words: "I've never used SAP; we run our own in-house stock system." Stop, and add nothing the sentence doesn't carry. Level 2, "What does the in-house system do, and what did you do in it?" Answer slot: say what the system does and what you did in it, in your own words, describing what it does rather than what it is called; if you did not use it directly, or know little of how it works, say so plainly and return to the sentence above. Level 3, "How quickly could you pick up SAP?" The honest answer is a plan, said as a plan and never as a past: say what you would do to learn it, and give a timescale only if you would stand behind it, since nothing in your material supports one. Hold through the follow-ups by returning to the advert's own word for it, "a plus", and concede the one true thing: you haven't used SAP | F7 is the one row where your message states an absence and the advert names it, so this question will arrive in some form: the highest-ROI prep. JD because it scores a stated requirement; it sits in the Skeptic bank because it is the gap probe |
| B3 | "This role schedules between planning, the warehouse and QA. You schedule deliveries for three depots. How does one carry over to the other?" | JD | [grounded] "I schedule deliveries for our three depots" | Hold at the sentence's scope: "I schedule deliveries for our three depots." Answer slot: the advert's line makes a probe on who else was involved likely. If you worked with other teams in scheduling those deliveries, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the depots. Don't argue the two are the same kind of work; describe what you do and let her draw the line. Hold through two follow-ups by returning to the depots, never by adding to them | F1 is where the advert's headline duty presses hardest on your material. JD because it scores the stated requirement |
| B4 | "The role reports weekly on on-time dispatch. What reporting have you done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Answer slot: the advert's line makes this probe likely. If you report on anything about deliveries or orders, say what, to whom and how often, in your own words; if you do not, or it was not yours, say so plainly and return to scheduling deliveries and chasing suppliers when orders slip. Don't describe a report you could not show or explain | F4 has no quote, so the pack writes no words for it. JD because it scores a listed duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Four slots, each answered in your own words, none supplied by the pack: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before she names it; and which part was yours. "I don't know how it was counted" is an honest answer; say it plainly rather than reconstructing a method. Say "about a third over a year" as you said it, and don't sharpen it into a percentage | F3 holds your only figure, and a headline number is where probes land. EXP because it tests what the figure rests on |
| C2 | "The role keeps stock records accurate. What was involved in rebuilding the stock-count spreadsheet?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped on F3, with only the beats the sentence states: you rebuilt the stock-count spreadsheet; discrepancies fell by about a third over a year. Answer slot: the advert's accuracy line makes a probe on what changed in the rebuild likely. If you can say what you changed, say it in your own words; if you can't, or part of it wasn't yours, say so plainly and stay with the rebuild and the outcome as you stated them | F3 is your evidence for the stock-records duty. JD because it scores that duty |
| C3 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Answer slot: the advert says confident with Excel, so expect a probe on which tool the spreadsheet was in. If it was Excel, say what you did in it, in your own words, naming only what you could repeat under a second question; if it was another tool, say so plainly and stay with the rebuild. The label is `[inferred]` because the link from spreadsheet to Excel is the pack's derivation | F6 is a discovery gap: the quote says spreadsheet, not Excel. JD because the advert lists the requirement |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: you say you chase suppliers when orders slip. What does that involve?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Pause, restate the question in a line, then hold the sentence: you chase suppliers when orders slip. Answer slot: the advert's chase-late-orders line makes a probe on how likely. If you go about it in a particular way, say how, in your own words and in the time you have; if there is no set way, or it varies, say so plainly and stay with the sentence. If interrupted, finish the clause you were on rather than restarting, and concede plainly what you can't say rather than filling the gap | F2 is the evidence for the chasing duty; the time box tests whether you hold it under pressure. JD because the advert names the duty |
| D2 | "So this is a move away from Reading, not towards us?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Hold-then-concede. Concede the true part at once, in the sentence's own terms: you're looking because the Bristol office is closing next year and the only offer is Reading, which you don't want. Then hold: that is why you started looking, which is a different thing from why you applied here, and your answer to the slot in B1 is the "towards". Don't deny the push and don't claim a pull you can't name. Hold through two follow-ups by repeating the facts, not by raising the enthusiasm | F10 is the likeliest source of a pushed motive question. EXP because it tests whether the account stays the same under pressure |

### E. Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier emails at 4pm: a delivery QA needs for Thursday will be four days late, and planning says the line can't wait. What do you do first?" | CASE | [generic] | No claim about your past is needed. Think aloud: clarify first (what is late, whether four days is confirmed or the supplier's estimate, what it holds up, who else is affected); state the objective; weigh the options (partial delivery, other stock or another source, re-sequencing); say who you would tell among planning, the warehouse and QA and what you would tell them; say what you would record. Challenge one premise respectfully | A live problem from the advert's coordination and late-order duties (F1, F2), asked as a decision. `[generic]` because it is a pattern for the problem, not a fact about Quillmoor |
| E2 | "The system shows 120 units and the shelf shows 97. How do you find out why?" | CASE | [generic] | No claim about your past is needed. Clarify: which count is newer, what moved between the two, which location. Then structure: recount, check what was received, moved or picked since the last count, correct the record with a note of why, and look at what caused it so it doesn't recur. Report what you found | A live problem from the advert's stock-accuracy duty (F3). `[generic]` for the same reason as E1 |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Selection scaffold: choose a time with a named stake, what you said and to whom, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, that you chase suppliers when orders slip, or say how you would handle it | Insurance: no source I read names a values round, so this is low weight. VAL because it scores behavior against a value rather than a duty |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose a time with a named stake, the metric you set aside, and the outcome. If no such time comes to mind, say so plainly, then say how you would handle it | Insurance, as F1. VAL for the same reason |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 production schedules across planning, warehouse, QA | B3 (JD), E1 (CASE) |
| F2 supplier deliveries and late orders | D1 (JD), E1 (CASE) |
| F3 accurate stock records | C2 (JD), C1 (EXP), E2 (CASE) |
| F4 weekly on-time dispatch reporting | B4 (JD) |
| F5 2+ years in coordination | A2 (JD) |
| F6 Excel | C3 (JD) |
| F7 ERP, SAP or similar | B2 (JD) |
| F8 salary | A3 (JD) |
| F9 hybrid | A4 (JD) |
| F10 the move | A1 (EXP), D2 (EXP), B1 (CO) |
| F11 notice period | A5 (JD) |

## Reverse questions

| # | Question for Hannah | Why it lands |
|---|---|---|
| R1 | "After this call, what are the stages, who would I meet, and roughly how long does it take?" | She offered to cover next steps; this shows you are thinking about the process and gives you the timeline |
| R2 | "Who does the Operations Coordinator report to, and how does the role work day to day with planning, the warehouse and QA?" | The advert names those three groups, so it shows you read it, and the answer tells you where the scheduling decisions sit |
| R3 | "Which systems does the team use for stock and scheduling, and is training provided on them?" | It puts the SAP question on the table as a forward-looking one, and asks rather than assumes what the team uses |
| R4 | "How is on-time dispatch measured today, and what does the weekly report look like?" | The advert makes weekly reporting a duty; this shows you take it seriously and tells you what you'd inherit |
| R5 | "How are the two days at Avonmouth set: fixed days, or agreed with the team?" | It settles the practical detail behind your hybrid answer |
| R6 | "Is this a new role or a replacement, and what would a good first three months look like?" | It shows you are thinking about delivering, and reveals how settled the role is |

These are role-generic: with web research refused and no interviewer profile, none is tied to Hannah's own path.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Scheduled production between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says delivery scheduling, not production scheduling. B3's slot stays inside the depots |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." No slot |
| The in-house stock system counts as an equivalent system | Inflated form of F7 | F7's quote at its own scope: "we run our own in-house stock system." B2's slot asks only what it does and what you did in it |
| Cut discrepancies by an exact figure or percentage | Inflated form of F3 | F3's quote at its own scope: "about a third over a year." C1's slots ask only how that was counted |
| £42,000 as a fixed requirement | Inflated form of F8 | F8's quote at its own scope: "I'm hoping for £42,000." The limit is the pack's observation: your message gives a hope and nothing about how firm it is |
| Being open to any number of office days | A claim your own words contradict, F9 | The contradicting quote: "I wouldn't want more than three" |

## Sources

**Provided:** the Quillmoor advert (pasted); Hannah Lowther's LinkedIn message (pasted); your own notes in this conversation. No CV was supplied.

**Searches sent, all refused (the host did not grant search permission):**
- "Quillmoor Diagnostics company values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth Bristol news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

No page fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search refused. Would have supplied published values to theme VAL questions; no values-style round is detected, so no cheat sheet was ever due |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Search refused. Would have shown the stages after this call and adjusted persona weights beyond this session |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Search refused. Would have grounded B1 in current company strategy rather than the advert alone |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Search refused. Would have supplied a public professional footprint for an interviewer read and one reverse question tied to her path |
| 5. Representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your CV or application text as submitted → F1 to F7 evidence cells can quote the application Hannah has in front of her, and `[inferred]` rows may become `[grounded]`
- Your notice period, read off your contract → F11 gets a quoted source and A5 gets words
- What the in-house stock system does and what you do in it → F7 and the B2 slot get your own sentence instead of a gap
- Which tool the stock-count spreadsheet is in → F6 and C3 move from discovery to a quoted answer
- Any weekly or regular reporting you do on deliveries → F4 and B4 move from discovery to a quoted answer
- Whether you work with other teams when scheduling deliveries → F1 and B3
- Web search permission, then a company pass (values, process, strategy, Hannah's public professional footprint) → B1 gets a company fact, persona weights get the loop, one reverse question can tie to her path; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief
- A tuesday-dossier.md from an earlier evidence review, if you have one → verified evidence and prohibited claims arrive ready-made; not needed for this pack
