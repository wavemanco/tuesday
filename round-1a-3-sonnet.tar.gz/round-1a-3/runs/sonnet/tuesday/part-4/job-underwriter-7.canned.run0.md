Checking whether Calderbrook Community Health CIC exists and the post is live, then I'll write up the assessment.
**Decision snapshot**

**Yes, it's worth applying to. R1 and R2 (hard gates) are met on your own statement, R3 is `direct`, and R4 needs one fact from you. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R6, R7 · adjacent: R5 (Wound and leg-ulcer care), R8 (Visiting housebound adults at home) · unclear: R9 (Continence care), R10 (End-of-life visits), R11 (Care planning) · absent: R12 (Holding a small caseload of your own)
- `preferred`: absent: R13 (Doppler assessment for leg ulcers)

R5 (`medium`): wound care is real, leg ulcers are not stated; R4: the CV is silent on records; R12: no caseload held, with senior support stated in the post.

**Opportunity ledger.** The post offers senior-nurse support (RR1) and its team lead has spoken publicly on Doppler training for newcomers (RR3). Open items are that I couldn't confirm the post on the employer's careers page (RR2), the hours aren't stated (RR4), and mileage sits beside pool cars (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Your NMC register entry and driving record both read current (R1, R2; stated, not checked).
  2. R4 closes with a named record system.
  3. The hours in RR4 suit you.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | Not established: the role-family search returned nothing, so no market band is given and the pay can't be compared to norms here | `[grounded]` search result empty |
| Hiring lead | Rhiannon Mabbott, Community Nursing Team Lead, leads the Halifax district nursing team after eleven years as a district nurse; in 2025 she spoke on nurse-led leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | Doppler training for newcomers is a topic she presents on, which suggests the desirable Doppler skill is teachable in this team; whether it is offered to this post is unstated | `[inferred]` from the talk topic |
| Live posting | Not confirmed: the careers address I tried returned no page | `[grounded]` failed fetch |
| Unknowns | Hours and rota, mileage rules, caseload size, training offered | — |
| Contradictions | None between the advert and the About page; the careers listing was not seen | `[grounded]` About page against JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states active Adult registration, revalidation due March 2028. Stated, not checked, so `medium` | `[grounded]` CV | Check your own NMC register entry reads current |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Stated, not checked | `[grounded]` CV and JD | Check your driving record status |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. This is a length-of-experience requirement, not a gate, and CV-only evidence | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on records and on any electronic record system, so there is nothing to inspect | `[grounded]` CV silence | G1 question |
| R5 | Wound and leg-ulcer care | important | adjacent | medium | transferability | CV states wound care including pressure ulcers and surgical wounds. Limit: leg-ulcer care is not stated | `[grounded]` CV | G3 |
| R6 | Catheter care | important | direct | medium | none | CV states catheter care; no artifact inspected | `[grounded]` CV | none |
| R7 | Insulin administration | important | direct | medium | none | CV states insulin administration; no artifact inspected | `[grounded]` CV | none |
| R8 | Visiting housebound adults at home | important | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: a short post-discharge window, not a long-term housebound list | `[grounded]` CV; the limit is `[inferred]` from the secondment wording | E1 |
| R9 | Continence care | important | unclear | low | discovery | CV states catheter care only | `[grounded]` CV silence | G2 question |
| R10 | End-of-life visits | important | unclear | low | discovery | CV is silent | `[grounded]` CV silence | G2 question |
| R11 | Care planning | important | unclear | low | discovery | CV is silent | `[grounded]` CV silence | G2 question |
| R12 | A small caseload of your own | important | absent | none | capability | You say you've never held one. The post states senior support. If D2A visits were allocated to you, that could become a partial bridge | `[grounded]` your statement and the JD | G4 |
| R13 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You say you've never done one. It is only desirable | `[grounded]` your statement and the JD | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | No record system or documentation work named | A must-have, and the only one the CV leaves open | Charting on an electronic record on the ward; recording D2A home visits; handover notes you wrote | System name, an audit result, a sign-off | `[grounded]` CV silence |
| G2 | Continence, end-of-life, care planning (R9, R10, R11, important) | discovery | CV names catheter care but none of the three | Three listed duties with no evidence yet | Bladder or bowel care plans; last-days care you gave or coordinated; writing or updating care plans | Competency sheets, care-plan samples with details removed | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5, important) | transferability | Pressure-ulcer and surgical wound care is stated; leg ulcers are not | The post names leg-ulcer care first among duties | Compression bandaging, ulcer reviews, supervised leg-ulcer dressings | A wound-care competency record | `[grounded]` CV |
| G4 | Own caseload (R12, important) | capability | Never held; the closest experience is home visiting after discharge | A learning-curve item with support stated, not a blocker | D2A visits allocated to you, a list you planned yourself | None to request now | `[grounded]` your statement |
| G5 | Doppler (R13, preferred) | capability | Never done | Preferred only | Training is the closure path | Ask whether training is offered (RR3) | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Senior-nurse support for a first caseload | positive_signal | — | "supported by a senior community nurse" | A route into holding your first caseload | `[grounded]` JD | How is a new nurse's caseload built up, and how often is it reviewed with the senior nurse? | noted |
| RR2 | Live posting not confirmed on the employer's careers page | unknown | — | "Calderbrook Community Health CIC, Halifax" | The address I tried may simply be wrong, or the advert may be a copy elsewhere | `[inferred]` from one failed fetch | Is this post live on your careers page, and when does it close? | unresolved |
| RR3 | Team lead speaks on Doppler training for newcomers | positive_signal | — | "Doppler training for staff new to community work" | The desirable skill may be taught in post | `[inferred]` from a talk topic; the post's training isn't stated | Is Doppler training offered to new starters, and how soon? | noted |
| RR4 | Hours and rota unstated | unknown | — | "end-of-life visits" with no hours given | Weekend or out-of-hours work may be part of the post | `[generic]` community nursing rotas vary; not a claim about this one | What is the working pattern, including weekends and on-call? | unresolved |
| RR5 | Mileage listed beside pool cars | unknown | — | "pool cars are provided"; "plus mileage" | It's unclear which journeys earn mileage | `[inferred]` from the two terms side by side | When is mileage paid if pool cars are provided? | unresolved |

## Application plan

`resume_edits_pending_approval`: E1–E3 change nothing until you approve.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the experience section with: "seconded for the last 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | R8 | `[grounded]` CV wording | pending your approval |
| E2 | Keep the wound line as written (pressure ulcers and surgical wounds); do not add leg ulcers | R5 | `[grounded]` CV | pending your approval |
| E3 | Add your record system's name once confirmed | R4 | `[grounded]` pending G1 | pending your approval |

Actions A1 and A2 are also proposals, pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Use the informal chat with Rhiannon Mabbott, listed in the advert, to ask the RR1–RR5 questions verbatim | The register doubles as interview preparation | `[grounded]` advert and register | pending your approval |
| A2 | Check your NMC register entry and driving record read current before submitting | R1, R2 | `[grounded]` CV states, not checked | pending your approval |

## Evidence status

Verified: none yet. Your NI number isn't needed, so I haven't used it or repeated it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. Moved the organization row and RR2 |
| 2. Role-family sweep | yes | Searched "district nurse Band 5 community staff nurse role requirements Doppler leg ulcer preceptorship", which returned no results (not established). Moved market calibration, left unstated |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the hiring-lead and scope-read rows, RR3 and A1 |

I'd like to offer a tailored CV and then a mock interview round if you go ahead, and I can emit this assessment as `tuesday-dossier.md` whenever you want it.

**Upgrade menu**
- Your record system's name or an audit result → R4.
- Examples of continence, end-of-life and care-planning work → R9, R10, R11.
- A wound-care competency record showing leg-ulcer exposure → R5.
- Your hours and pay limits → hard-gate checks against them, currently unknown.
- A pay-scale table or your current Band comparison → pay calibration, which my search couldn't supply.
- Rhiannon's answers on RR2–RR5 → those entries close.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Which electronic record system have you charted on day to day, and did your D2A visits go on it or on paper?

G2 — Which of continence care, end-of-life care and writing or updating care plans have you personally done, and what was yours in each?

RR4 — Are there hours or pay limits you'd treat as non-negotiable, such as weekends, evenings or a minimum salary?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.