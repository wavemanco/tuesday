Web search was refused, so this runs on your pasted text alone.

## Decision snapshot

**Duinvaart: yes, worth applying to. Status: `conditional_go`.**
**Kroonhaven: no, not worth your time. Status: `no_go`, because B2, B3 and B6 are must-haves with no planning evidence behind them.**

**Fit ledger: Duinvaart**

- `hard_gate`: unclear: A1 (Hybrid, three days in the Rotterdam office)
- `must_have`: direct: A2, A3, A4, A5a · unclear: A5b (Temperature compliance across a refrigerated fleet)
- `important`: direct: A6
- `preferred`: adjacent: A7 (Dutch a plus)

A5b (`low`): no cold-chain or temperature-monitoring work is stated; A7: conversational Dutch against a "plus".

**Fit ledger: Kroonhaven**

- `hard_gate`: unclear: B1 (On-site in Utrecht)
- `must_have`: adjacent: B4 (Run the weekly S&OP meeting), B7 (Fluent Dutch) · unclear: B5 (Advanced Excel) · absent: B2 (3+ years of supply or demand planning in FMCG), B3 (Own the 13-week supply plan), B6 (SAP IBP or a similar planning system)

B2, B3, B6: you've never worked in planning, so these are capability gaps; B4: a bridge, its limit named; B7: conversational against fluent.

**Opportunity ledger.** Duinvaart's deliverables are concrete (RA4), but the employer is unchecked (RA1), pay is not stated (RA2) and the office days are unresolved against your location (RA3). Kroonhaven's scope is clearly defined (RB3), but its employer is unchecked (RB1) and pay is not stated (RB2).

- **Hard gates, Duinvaart:** none failed; unconfirmed: A1 (Hybrid, three days in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Hard gates, Kroonhaven:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for Duinvaart:** (1) the commute works for three Rotterdam days, A1 and RA3; (2) the posting and employer verify, RA1; (3) you can speak honestly to temperature or condition data, or show it is learnable, A5b.
- **What would change Kroonhaven:** planning, forecasting or capacity work that you haven't mentioned (GB1). Even then B2 and B6 would remain gaps.

## Role reality

| Element | Duinvaart | Kroonhaven | Provenance |
|---|---|---|---|
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run weekly S&OP | `[grounded]` both postings |
| Working pattern | Hybrid, three days in the Rotterdam office | On-site in Utrecht | `[grounded]` both postings |
| Scope read | An analyst role that reads like your current one with a cold-chain data domain added | A planning-owner role, a different function from analysis | `[inferred]` from the postings' duties against your stated background |
| Market calibration | Not calibrated | Not calibrated | `[grounded]` the search was refused, so there is no band and no claim about pay |
| Unknowns | Pay; employer's footprint; whether the temperature data already sits in a system | Pay; employer's footprint; the planning system actually used | `[grounded]` the postings state none of these |
| Contradictions | None between the postings and your background | None | `[grounded]` the pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't said where you live or what commute you will accept, and your employer is in Amsterdam | `[grounded]` posting term; your location not stated | GQ2 |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, which is self-reported and not yet inspectable | `[grounded]` your background | Offer a dashboard screenshot (sanitised) to raise to `high` |
| A3 | Strong SQL | must_have | direct | medium | none | You use SQL daily, which is confirmed and specific but has no artifact yet | `[grounded]` your background | Offer a sanitised query sample |
| A4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily | `[grounded]` your background | Same screenshot as A2 |
| A5a | Track on-time delivery | must_have | direct | medium | none | You work on the on-time delivery dashboard your depot managers use | `[grounded]` your background | Same screenshot |
| A5b | Track temperature compliance across a refrigerated fleet | must_have | unclear | low | discovery | Nothing stated on temperature or condition monitoring, so this is a question and not a verdict | `[grounded]` CV silence; `[generic]` that parcel networks sometimes carry condition data | GQ1 |
| A6 | Work with depot managers on route changes | important | direct | medium | none | Depot managers use your dashboard and you ran the weekly route-performance review. Whether you also drove the route changes is not stated | `[grounded]` your background | Say precisely what you owned in that review |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, which is adjacent to a "plus" and is not fluency | `[grounded]` your statement | State it as "conversational" |
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Same location gap as A1, with five on-site days implied by "on-site" | `[grounded]` posting term; your location not stated | GQ2 |
| B2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning, and nothing adjacent is stated. A years-requirement is not a gate, but no work is near it | `[grounded]` your statement | Closure path: a planning role in a logistics setting first |
| B3 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No forecast or capacity-planning work is stated | `[grounded]` your statement | GQ3, only if you want this reconsidered |
| B4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran the weekly route-performance review. Limit: it is not stated to have been a cross-functional supply, demand and finance forum | `[grounded]` your background; `[generic]` what S&OP usually involves | Describe who attended and what was decided |
| B5 | Advanced Excel | must_have | unclear | low | discovery | Your stated tools are SQL and Power BI; Excel is not mentioned | `[grounded]` CV silence | Confirm only if B stays live |
| B6 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analytics tools, not planning systems | `[grounded]` your background | Closure path: a short SAP IBP course, which wouldn't be enough on its own for this role |
| B7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational against fluent. The posting ties the role to fluency for the weekly meeting and plan ownership | `[grounded]` your statement; posting says "fluent Dutch" | None |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (A5b, must_have) | discovery | Your on-time work is clear; temperature or condition monitoring is not mentioned | It is half the Duinvaart headline duty, so the answer decides how you position | Any SLA or exception reporting on time-critical parcels; sensor, damage or hold-time data; compliance reporting to a client or regulator | A sanitised exception report or dashboard page | `[grounded]` CV silence; `[inferred]` that exception-style reporting would be the nearest bridge |
| GB1 | Planning-adjacent work (B2, B3, must_have) | discovery | Nothing planning-related stated | It would decide whether Kroonhaven is a stretch or out of reach | Volume forecasting for depots; capacity or staffing-to-demand calculations; inputs you supplied to someone else's plan | A forecast sheet or a capacity model | `[grounded]` your statement that you've never worked in planning |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Duinvaart not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The search was refused, so nothing was checked. The firm may be small, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RA2 | Pay not stated | unknown | — | (the posting gives no pay figure) | Pay may be fine, or may not match what you need | `[inferred]` from the posting's silence | What is the budgeted salary range for this post? | unresolved |
| RA3 | Office days against your location (A1) | unknown | — | "Hybrid, three days a week in our Rotterdam office" | The commute may be impractical from where you live | `[inferred]` from your Amsterdam employer, with your home location unstated | Is the three-day pattern fixed, or flexed for travel and team peaks? | unresolved |
| RA4 | Clear deliverables | positive_signal | — | "build weekly dashboards in Power BI" | Scope is defined and matches your daily work | `[grounded]` posting | Who consumes these dashboards today? | noted |
| RB1 | Kroonhaven not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as RA1, side by side and none likelier | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RB2 | Pay not stated | unknown | — | (the posting gives no pay figure) | As RA2 | `[inferred]` from the posting's silence | What is the budgeted salary range for this post? | unresolved |
| RB3 | Defined, owned scope | positive_signal | — | "Own the 13-week supply plan" | Responsibility is clear, though the planning authority it carries is unstated | `[grounded]` posting | Who signs off the plan if production and forecast conflict? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the Duinvaart CV with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran, in your own wording, with no added scope | A2, A4, A5a, A6 | `[grounded]` your sentences | `resume_edits_pending_approval` |
| E2 | Say "conversational Dutch" and don't round it up | A7 | `[grounded]` your statement | pending your approval |
| Q1 | Ask RA1 to RA3's questions verbatim before you invest in interviews | Register doubles as prep | `[grounded]` register | pending your approval |
| Q2 | For Kroonhaven, spend effort only if GB1 turns up real planning work. Otherwise skip | B2, B3, B6 | `[grounded]` map rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were both refused. Would have moved: whether each employer exists and the posting is live (RA1, RB1) |
| 2. Role-family sweep | unavailable | Searches for "operations analyst logistics Rotterdam salary" and "supply planner FMCG Netherlands salary SAP IBP" were both refused. Would have moved: the market-calibration row and the pay checks (RA2, RB2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- Permission to search → the employer checks (RA1, RB1) and a pay band for both roles.
- A sanitised dashboard screenshot or SQL sample → A2 to A5a go to `high`.
- Your answer on temperature data → A5b resolves, and Duinvaart's third condition closes.
- Your location → A1 and B1 resolve, and RA3 closes.
- A tailored edit ledger for Duinvaart is resume-tailor's job, and I can run it if you want it.

If you'd like, I can save this as `tuesday-dossier.md` so it carries into later steps.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

GQ1 (GA1) — Have you ever worked with temperature, hold-time or condition data on shipments, or with exception reporting to clients? What did you own, and who used it?

GQ2 (A1, B1) — Where do you live, and would three Rotterdam days a week, or five in Utrecht, be workable for you?

GQ3 (GB1) — Have you done any forecasting, capacity or staffing-to-demand work, even as an input to someone else's plan? What was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.