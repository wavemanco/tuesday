Two searches done. I found no trace of Velloway Logistics, and I found a pay benchmark. Next I'm opening the pay guide to check its figures before I write the full assessment.
## Decision snapshot

**No, don't go ahead. This job is very likely a scam: RR1, RR2, RR3 and RR4 are severe red flags. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R3, R4 · adjacent: R2 (Strong attention to detail)

R2 (`medium`) — indirect evidence only; R1 — the posting's pay can't be set against your floor.

**Opportunity ledger.** The messages ask for a payment, a cheque lodgement, and bank, tax and ID details before any written offer, and the whole process runs on chat (RR1, RR2, RR3, RR4). The employer couldn't be established from here (RR6), the contact address isn't tied to it by anything I found (RR5), and the pay terms are open-ended (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer confirmed independently on its own website; the equipment payment, the cheque and the bank and ID details dropped from the process (RR1, RR2, RR3); interviews and an offer made outside chat (RR4); and a pay figure that clears your floor (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", as named in the posting. A search for it and the role returned no results, so I can't establish the firm from here | `[grounded]` posting; `[grounded]` search returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "set your own hours" | `[grounded]` posting |
| Pay as posted | "up to €26 an hour plus commission on every order you process"; no base rate, hours guarantee or commission rate stated | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Scope read | A coordinator-level data-entry style role with no stated team, manager or reporting line | `[inferred]` from the posting's silence on all three |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200 a year, interquartile range €28,400 to €34,100. The guide excludes commission-only and freelance work, so it is not a like-for-like band for an hourly "up to" rate | `[generic]` Pennoral 2026 Ireland pay guide (n=1,140) |
| What the posted rate buys | At the €26 top rate, 15 to 30 hours is about €20,300 to €40,600 over 52 weeks. Reaching €30,000 needs about 22 hours a week at that top rate, every week | `[inferred]` arithmetic from the posting's figures |
| Unknowns | Who the employer is; base rate and guaranteed hours; commission rate; employee or contractor; who "payroll" is | — |
| Contradictions | The €349 for equipment is to be refunded "with your first wages". A later message instead sends a cheque to lodge, keep €350 and forward the rest (€2,500) to the same equipment partner. The terms changed between messages | `[grounded]` your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to €26 an hour", 15–30 hours and unquantified commission don't settle whether the floor is met | `[grounded]` your statement; `[grounded]` posting wording | Needs the guaranteed rate and hours in writing from the employer, through a contact found on its own site |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day and a weekly tracker are work that needs care, but you gave no error-rate or quality evidence. The limit is that the trait itself is unmeasured | `[grounded]` your background, self-reported | If the role ever verifies: lead with the volume and the tracker, name the limit |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Confirmed in your message, with no file to inspect | `[grounded]` your background, self-reported | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket replies at about 60 a day in Zendesk over 3 years. Self-reported, no sample inspected | `[grounded]` your background, self-reported | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | "up to €26 an hour plus commission" and 15–30 hours; no base rate, guaranteed hours or commission rate | Your floor is a term of the job; the posting can't show whether it is met | Not applicable; this is the employer's to state | A written offer from the employer naming rate, hours and contract type | `[grounded]` posting wording; `[inferred]` that the floor needs about 22 hours a week at the top rate |
| G2 | Attention to detail (R2, must_have) | transferability | High-volume ticket handling and a weekly tracker; no stated accuracy measure | A trait requirement is usually probed through examples of caught or prevented errors | A time you caught a mis-tagged ticket, a wrong tracker figure, or a mistake a new starter made while you trained them | A tracker extract or a QA note, anonymised | `[inferred]` bridge from your tickets and tracker; `[generic]` that such roles probe for error examples |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded to start | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A job that charges for equipment before work starts is a known scam pattern | `[generic]` pattern, not a claim about who sent this | To the employer, through contacts found on its own website, never the chat: "Do you ask new hires to pay for equipment before they start, and who is the named equipment partner?" | confirmed |
| RR2 | Cheque to lodge and money to send on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can be lodged and later returned unpaid, leaving the money you sent on as your loss; this exact shape is a known scam pattern | `[generic]` pattern, not a claim about who sent this | Covered by RR1's question and route | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details were asked for at the screening stage, before any written offer naming role and pay | `[grounded]` your messages | Covered by RR1's question and route; add: "Which payroll provider will hold these, and at what address do I enter them?" | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." Then "you passed the interview and the job is yours!" | The posting and your messages show interview and offer both happening only in chat | `[grounded]` posting and your messages | Covered by RR1's question and route; add: "Can I have a written offer on company letterhead from an address on your own domain?" | confirmed |
| RR5 | Contact address not tied to the employer | risk_signal | medium | "email velloway.hr@postmail.example" | The address may be a general mail service rather than one on a company website; nothing I found links it to the employer | `[grounded]` your message; `[grounded]` no company site found in search | Is velloway.hr@postmail.example an address your company uses for hiring, and is it listed on your own website? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for firms with no footprint, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Pay open-ended | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process." | "Up to" is a ceiling; with no base rate, hours guarantee or commission rate, your €30,000 floor can't be tested | `[inferred]` from the posting's figures against your stated floor; `[generic]` salaried median €31,200 for comparison | What is the guaranteed hourly rate, the guaranteed weekly hours, and how is commission calculated? | unresolved |

**Hold.** Don't pay the €349, don't lodge the cheque if it arrives, and don't send the bank, PPS or passport details (RR1, RR2, RR3). I don't need your IBAN or any ID and I haven't used the one you pasted. This request is very likely a scam. Check with the employer through contact details you find independently on its own website, never the Telegram handle or the postmail address, and pause the chat meanwhile. The sender's identity is unresolved, and the Telegram handle, the posting and the postmail address are all unverified. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send no money, bank details, PPS number or passport photo; lodge no cheque | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Look for the employer's own website and contact it from there with RR1's question | see RR1, RR6 | `[grounded]` register | pending your approval |
| A3 | If you have already sent or lodged anything, tell your bank at once and report it to An Garda Síochána | Speed matters when money has moved | `[generic]` general guidance | pending your approval |
| A4 | Aim at salaried customer-operations roles that name the employer, give a written offer and show a base salary; the pay guide's median sits just above your €30,000 floor | see R1, market calibration | `[generic]` pay guide median €31,200 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers Order Processing Coordinator"; it returned no results, so the employer is not established. This moved RR6 and role reality's organization row, and left the posting unchecked against a careers page |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), then fetched it. This moved the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a Telegram handle, so there was no query to form |

If you'd like, I can save this as a `tuesday-dossier.md` for you to keep.

**Upgrade menu**

- A link to the role on the employer's own careers site, or its website address → RR6 closes or hardens, and the posting gets checked against it.
- The employer's own answers to RR1's questions, via a contact you find on its site → RR1 to RR5 resolve or stay confirmed.
- The base rate, guaranteed weekly hours and commission rate in writing → R1 and RR7 can be settled against your floor.
- The name of a real person who would interview you → target 3 can run.
- A deeper research pass on the employer (leadership, public reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.