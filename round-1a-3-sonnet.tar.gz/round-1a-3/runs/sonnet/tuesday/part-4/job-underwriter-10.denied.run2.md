Web search was declined, so this runs on what you pasted. I couldn't check Fernquay itself.

## Decision snapshot

**Yes, worth taking the call, and nothing you've shared is a red flag, but the company isn't established from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer), R9 (Research calls with school owners)

R7 — checkout is one stage of a booking flow; R8 — squad work bridges it, and you've never been the only designer; R9 — your sessions were with customers, not business owners.

**Opportunity ledger.** The posting is open about pay, equity range, working pattern and scope (RR4). The employer is unverified from here (RR1), and the equity terms (RR2) and design support for a first designer (RR3) are unspecified.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay's own site or careers page shows the role and a matching email domain (RR1); (2) the pay and two office days fit your terms (R1, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools. Not corroborated by any search | `[grounded]` posting |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Closest collaborator | Co-founder Ronan Kehoe, who also messaged you | `[grounded]` posting and your message |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | Design, research and delivery bundled into one first-designer post, which is ordinary at this team size and is not a bundling red flag | `[generic]` pattern for six-person product teams |
| Market calibration | Not done: the role-family search was refused, and a band from memory would not be a source | `[grounded]` the run's own accounting |
| First 90 days | Learn the booking flow and start research calls with school owners | `[inferred]` from the posting's mandate |
| Unknowns | Whether the company checks out; equity terms; funding runway; design support; who Saoirse (CTO) works with | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the message: both name Ronan. The posting names no CTO | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are within reach. You haven't said you accept two fixed days | `[grounded]` your intro and the posting | Confirm in G1 |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You gave no pay floor, so the posting's figure is checked against nothing | `[grounded]` no constraint stated | G1 asks whether the pay meets your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | "4 years as a product designer at a Dublin travel-booking company" exceeds the ask. It is self-report, with no artifact inspected | `[grounded]` your intro | Share a portfolio link to raise to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" shows use. Depth of craft is not evidenced, so expect a probe | `[grounded]` your intro | Share a Figma file or case study |
| R5 | You have run your own user research | must_have | direct | medium | none | "Ran monthly usability sessions with customers" | `[grounded]` your intro | Share a session guide or findings summary |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | "Worked in a squad with four engineers". Fernquay has two | `[grounded]` your intro | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. Limit: whether you owned stages before checkout is unstated | `[grounded]` your intro; `[inferred]` that checkout is one stage of a booking flow | See G2 |
| R8 | Work as the first and only designer | important | adjacent | low | transferability | Squad work with engineers carries over. Limit: you've never been the only designer, so setting design direction alone is unevidenced | `[grounded]` your intro; requirement `[inferred]` from "You would be our first designer" | Bridge case in the application plan |
| R9 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers. School owners are business operators using a tool. Limit: no business-owner research stated | `[grounded]` your intro | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay and office days (R2, hard_gate; R1) | hard_gate | The posting states pay, but no floor from you. Two office days sit within reach of Galway | A gate nothing settles can't be treated as met, and the answer could move the status | — | Your own floor, and your view on equity | `[grounded]` no constraint stated |
| G2 | Booking flow beyond checkout (R7, must_have) | transferability | Checkout redesign confirmed. Stages before checkout not mentioned | The role's main mandate is the whole flow | Owning search or availability screens; redesigning cancellations or changes; flow-level metrics beyond checkout | A case study spanning more than checkout, flow diagrams | `[grounded]` the intro is silent on other stages; `[generic]` that the whole flow is the first-designer mandate |
| G3 | Research with business owners (R9, important) | transferability | Monthly customer sessions confirmed | Owners differ from consumers in goals and vocabulary | Sessions with partner businesses; calls with suppliers or agents; feedback from B2B accounts | A session guide, a findings summary | `[grounded]` the intro names customers only; `[generic]` that B2B research differs from consumer research |
| G4 | Sole-designer ownership (R8, important) | transferability | Squad experience; never the only designer | Direction-setting alone is the unevidenced half | Making design calls with no peer review; setting up a small design system | Examples named in the plan | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "six people in Galway making booking software for sea-kayak and surf schools" | It may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The grant may carry vesting, strike price or dilution terms that change its value | `[generic]` pattern for early-stage equity | What are the vesting schedule and strike terms, and how much runway does the company have? | unresolved |
| RR3 | Design support for a first designer unstated | unknown | — | "You would be our first designer" | Direction and critique may rest wholly on the co-founder | `[inferred]` from the posting's silence on design leadership | Who sets product direction, and who reviews design work? | unresolved |
| RR4 | Pay, equity range, hybrid terms and scope stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Terms are concrete, so the posting is open about what it offers | `[grounded]` posting | Is the band fixed or negotiable within it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the time on WhatsApp if it suits. Scheduling by chat for a video call is a routine step | You asked whether the message was odd | `[generic]` ordinary recruiting practice | pending your approval |
| A2 | Look up Fernquay's own website yourself and check that the role is listed and that the email domain on the invite matches the site | Closes RR1 | `[generic]` | pending your approval |
| A3 | Ask the questions in RR1, RR2 and RR3 verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Lead with the checkout redesign and the monthly usability sessions. Say plainly that you've never been the only designer and that you worked in a squad with four engineers | R3–R6 are direct; R7–R9 get an honest bridge | `[grounded]` your intro | pending your approval |
| A5 | Prep for the 45-minute call with Ronan and Saoirse is the mock-interview module's job: ask for it separately | Not done here | `[grounded]` your message | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway"; refused. It would have moved role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland startup first designer 2026"; refused. It would have moved the market calibration row |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have moved the scope read and A4 |

I'll offer one thing beyond this assessment: a tuesday-dossier.md, so any later step starts from this analysis.

## Upgrade menu

- Permission for web search, so I can re-run targets 1–3: closes RR1 and the market calibration, and adds the scope read.
- A link to Fernquay's careers page or the live posting: closes RR1.
- A portfolio or case-study link, with the Figma file and a research-session summary: raises R3–R6 toward `high`.
- Your pay floor: settles R2.
- A written equity term sheet: closes RR2.
- A deeper research pass once search is allowed (up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

G1 — What is your minimum salary, and are two fixed office days in Galway fine?
G2 — Did you own any part of the booking flow before checkout, such as search, availability or changes? What was yours, and what happened?
G3 — Have you ever spoken with business owners or partners rather than consumers? Who were they, and what did you learn?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.