Searches are done, so here is the assessment.

# Job Underwriting — Remote Order Processing Coordinator

## Decision snapshot

**No, don't go ahead with this one. Status: `no_go`.** RR1, RR2, RR3 and RR4 are confirmed severe red flags. I can't establish the firm from here. The requests it makes are very likely a scam, so pay nothing, deposit nothing and send nothing yet.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Earn up to €26 an hour)
- `must_have` — direct: R2, R3, R4

R1 — a ceiling with no floor; R3 (`medium`) — Excel tracker confirmed, depth unstated.

**Opportunity ledger.** The role fails on its own terms, whatever your fit. It asks you to pay for equipment (RR1), to lodge a cheque and forward part of it (RR2), and to hand over bank, tax and ID details before any offer (RR3). It also runs its whole process on Telegram (RR4). Three further signals sit beside those: contact off any employer domain I can find (RR5), an employer I couldn't establish (RR6), and pay with no floor (RR7). I found no positive signal.

- **Hard gates:** none failed; unconfirmed: R1 (Earn up to €26 an hour).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** only different facts would. You would need a written offer from the employer's own verifiable domain, with no payment, no cheque and no bank, tax or ID details asked for before it. You would also need interviews held live, and the employer confirmed through its own website.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. A search for the name returned no results, so the entity is not established | `[grounded]` search returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "set your own hours" | `[grounded]` posting |
| Pay as stated | "up to €26 an hour plus commission"; no floor, no commission terms | `[grounded]` posting |
| Pay worked through | 15 hours at €26 is €20,280 a year and 30 hours is €40,560, both at the ceiling rate and over 52 weeks. Reaching €30,000 at the ceiling takes about 22 hours a week | `[grounded]` posting figures; `[inferred]` arithmetic |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, interquartile range €28,400–34,100. The guide excludes commission-only and freelance work. It is a band, never this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, from the search snippet only |
| Process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Contradictions | The posting lists no equipment requirement and says "full training provided". The chat then asks you to buy a laptop and headset | `[grounded]` posting set against the messages |
| Unknowns | Who the employer is; employee or contractor status; commission terms; guaranteed hours | — |

## Evidence map

I assumed your stage is evaluating. Your background is typed into the chat, so it counts as self-report: leads, not proof.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because the posting gives a ceiling and no floor or guaranteed hours | `[grounded]` your statement and the posting | Ask the employer for the hourly floor and guaranteed hours in writing, via G1 |
| R2 | Strong attention to detail | must_have | direct | medium | none | A weekly team tracker and about 60 tickets a day point to detail work, but nothing inspectable has been offered | `[grounded]` your background; `[inferred]` the reading of it | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. Formula and pivot depth are not stated | `[grounded]` your background | A sanitized screenshot of the tracker would raise this to `high` |
| R4 | Good written English | must_have | direct | medium | none | Written Zendesk ticket work at volume, and your chat answers | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor and hours (R1, hard_gate) | hard_gate | A ceiling of €26 an hour, 15–30 hours, undefined commission | €30,000 is reachable only near the top of both ranges, and the posting promises neither | Not applicable: a pay gate is a term, not experience | A written statement of hourly rate and guaranteed hours from the employer's own domain | `[grounded]` posting terms; `[inferred]` from the arithmetic above |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. Asking a new starter to pay for equipment before any wages matches a known pattern | `[generic]` pattern, not a claim about any named party | Can you confirm in writing, from an address on your own website, that new starters are never asked to buy equipment? | confirmed |
| RR2 | Cheque deposit, then forwarding part of it | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. A cheque can show in your balance before the bank has finished checking it. If it is later returned, the money you forwarded is your loss | `[generic]` pattern | Why would an employer's onboarding involve a new starter forwarding money from a cheque? Please confirm this from your own website's contact details | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Nothing in the material is an offer: no written terms naming the role and its pay. Payroll details this early match a known pattern | `[generic]` pattern | Where is the written offer naming the role and pay, and will payroll details be taken only in your own portal? | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the offer both happened only in chat, so nothing here can be checked against a live person | `[grounded]` posting and messages | Can I speak with a named hiring manager by phone or video before accepting anything? | confirmed |
| RR5 | Contact off any employer domain I can find | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | I can't match this address to an employer website. The messages may not come from who they name | `[inferred]` from the address against the failed search | Can you write to me from an address on your own company website? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and say who I would report to? | unresolved |
| RR7 | Pay with no floor | unknown | — | "Earn up to €26 an hour plus commission on every order you process." | The effective annual figure may fall well under €30,000, against a salaried median of €31,200 | `[generic]` Pennoral band; `[grounded]` posting | What is the guaranteed hourly rate, the guaranteed weekly hours, and how is commission calculated? | unresolved |

**Hold.** Do not transfer the €349. Do not lodge the cheque or forward any of it. Do not send the IBAN, your PPS number or a passport photo. Your passport, PPS number and IBAN aren't needed for this assessment and I haven't used them, so keep them out of this chat too. This job is very likely a scam. For RR1–RR4 and RR7, check through contact details you find yourself on the employer's own website, never through the Telegram chat or the email in these messages. If you can't find an employer independently, the sender's identity is unresolved.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pause the Telegram conversation: pay, deposit and send nothing | see RR1–RR4 | `[grounded]` register | pending your approval |
| A2 | Look the employer up independently, on its own website and the Irish company register, before any further contact | see RR6 | `[generic]` a public register is a standard place to check | pending your approval |
| A3 | Put the verification questions to the employer through contacts you find yourself | see RR1–RR5, RR7 | `[grounded]` register | pending your approval |
| A4 | Report the posting to the jobs site. If you had sent money or details, tell your bank straight away | see RR1–RR3 | `[generic]` standard step | pending your approval |
| A5 | Turn to real employers. Your parcel-courier customer-service background sits close to customer-operations roles, and the salaried median I found meets your floor | see R2–R4, R1 | `[generic]` Pennoral band; `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics"; no results, so the employer is not established. This moved role reality's organization row and RR6 |
| 2. Role-family sweep | yes | Searched "Remote Order Processing Coordinator salary Ireland work from home order processing". It returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), read from the snippet only. This moved the market calibration and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a chat handle, so there was no query to form |

## Upgrade menu

- The employer's own careers page or website → RR6 and RR4 can close or confirm.
- A written offer from an address on the employer's own domain → RR3 and RR5 resolve.
- A written hourly floor and guaranteed hours → R1 and RR7 close.
- A sanitized screenshot of your Excel tracker → R3 to `high`.
- A deeper research pass on this employer (up to 5 more searches and 2 more fetches), if you want it.

I can save this as a `tuesday-dossier.md` if you'd like to keep it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.