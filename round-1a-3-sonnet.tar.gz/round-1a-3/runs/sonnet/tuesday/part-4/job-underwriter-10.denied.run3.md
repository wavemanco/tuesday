Web search wasn't permitted, so I'm working from what you pasted. The assessment below is built on that and labelled accordingly.

## Decision snapshot

**Yes, worth applying to, on conditions. I can't confirm Fernquay exists as described from here, and nothing in the posting or the WhatsApp message asks you for money or personal details. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (First designer on the team)

R7 — checkout is a credible bridge, its limit named; R9 — no solo-designer history, the main stretch.

**Opportunity ledger.** The role is concrete and well scoped (RR4). The company is unverified, which is a gap in my checking and not a finding against it (RR1). Equity terms and design support are unstated (RR2, RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Fernquay's own careers page and the invite comes from its own domain (RR1); (2) the salary holds and the equity terms are acceptable to you (R2, RR2); (3) you learn who reviews your design work and how you get to school owners (R9, RR3); (4) you present the checkout work as adjacent to end-to-end ownership, not as it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not independently confirmed | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reporting line | Closest working relationship is with co-founder Ronan Kehoe. The message came from "Ronan from Fernquay" and adds Saoirse, the CTO, to the call | `[grounded]` posting and message |
| Working pattern | Hybrid, two Galway office days a week | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | A solo-designer seat: no design peer or lead is mentioned | `[inferred]` from "first designer" and the team size given |
| Market calibration | Not run, because search was unavailable. I won't give a band from memory | n/a |
| Unknowns | Equity terms, design support, who sets product priorities, whether the posting is live on Fernquay's own site | `[inferred]` from the posting's silence |
| Contradictions | None between the posting and the message | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location term is met. You haven't said whether fixed office days suit you; the confidence grades your word, not an inspected artifact | `[grounded]` your statement | Q1 covers whether the office days work for you |
| R2 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | No floor was given, so the posted range can't be checked against anything | `[grounded]` posting figure; no constraint stated | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years at a Dublin travel-booking company, self-reported with no artifact inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. A file or case-study screens would be the inspectable proof | `[grounded]` your background | offer: a case-study link raises this to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Whether you planned and synthesised them yourself isn't stated | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | Credible adjacency: you redesigned a travel-booking checkout. Limit: checkout is one stage of the flow, and your ownership of the whole flow isn't stated | `[grounded]` your background; `[inferred]` that checkout is one stage of a booking flow | G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were usability sessions with customers. Limit: interviewing small-business owners about their operations is a different exercise | `[grounded]` your background; `[inferred]` from the posting's wording | G3 |
| R9 | Work as the first designer, with no design peer | important | adjacent | low | transferability | You have worked with engineers and owned a redesign, but never as the sole designer. The posting doesn't state this as a requirement; I read it from "first designer" | `[inferred]` from the posting; `[grounded]` your statement | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end flow ownership (R7, must_have) | discovery | A checkout redesign is established; the steps before and after it, and who decided them, aren't | A must-have at `adjacent`; this is the likeliest point for the call to probe | Taking a flow from discovery research through design to shipped; owning search-to-confirmation screens; deciding what was cut | The checkout case study, before/after screens, an outcome metric | `[grounded]` background gaps; `[generic]` that a booking-flow role probes whole-flow ownership |
| G2 | Working as the sole designer (R9, important) | transferability | Squad work with four engineers; no solo-designer seat | A first-designer seat means no peer review and setting your own process | Setting up a Figma library or component conventions; running design for a side or freelance project; being the one design voice in a project | A component library, a freelance or side project, a process doc | `[grounded]` your statement; `[generic]` that first-designer seats lack peer review |
| G3 | Owner interviews (R8, important) | transferability | Usability sessions with customers, not discovery calls with operators | Research calls are a named duty | Calls with business customers or partners; stakeholder interviews; a research plan you wrote | A discussion guide, a synthesis deck | `[inferred]` from the posting against your sessions |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (research did not run) | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small for a footprint, the posting may be stale, or the footprint simply wasn't checked here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page, and which address will the calendar invite come from? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, strike price, share class and dilution may not be set out | `[inferred]` from the posting's silence on terms | What is the vesting schedule, the strike price and the share class, and has there been a funding round? | unresolved |
| RR3 | Design support and authority unstated | unknown | — | "You would be our first designer: own the booking flow end to end" | You may carry the whole flow without a design reviewer or decision rights | `[inferred]` from the posting's silence on design leadership | Who reviews your design decisions, and who sets product priorities? | unresolved |
| RR4 | Specific posting: named product, named co-founder, stated pay range, stated hybrid terms | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Scope and terms are defined rather than evasive | `[grounded]` posting | Which school owners could you speak to in your first month? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp scheduling as routine, since a video call arranged by message and invite is normal. Before the call, check that the invite's sender address and link domain match the address on Fernquay's own website, and use the link from the invite | Answers your "felt odd" question; see RR1 | `[generic]` normal hiring step | pending your approval |
| Q1 | Ask the RR1, RR2 and RR3 verification questions on the call, word for word, and confirm the salary range | The register doubles as call prep; see R2 | `[grounded]` register | pending your approval |
| P1 | Positioning advice: lead with the checkout redesign and the monthly sessions, and say plainly that you've worked in a squad and haven't been the only designer | See R5, R7, R9 | `[grounded]` your statements | pending your approval |
| P2 | Be ready to walk through your checkout case study. Ronan said they liked it, so it's what they'll probe | See G1 | `[grounded]` the message | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers". They would have settled whether the company exists as described and whether the posting is live (RR1, role reality) |
| 2. Role-family sweep | unavailable | One search was refused: "first product designer startup Ireland salary Galway Dublin 2026". It would have fed the market calibration and the R2 comparison |
| 3. Hiring manager's public footprint | unavailable | One search was refused: "Ronan Kehoe Fernquay co-founder". It would have sharpened the scope read and the plan's positioning |

I'll offer the whole dossier file, `tuesday-dossier.md`, if you want it to keep or reuse.

## Upgrade menu

- A link to the role on Fernquay's own careers page, or the sender address on the invite → RR1 resolves and the cap on the decision lifts.
- Your salary floor and how you feel about fixed office days → R1 and R2 are checked against your terms.
- The checkout case study link → R4 and R7 can reach `high`.
- Permission to run web search → the three research targets run and the market band fills in.

**Questions**

Q1 (R2) — What is the lowest salary you would accept, and are two fixed office days a week acceptable to you?
G1 (R7) — At the travel company, did you take any flow from first research through to shipped? What did you own, and what did the squad own?
G2 (R9) — Have you ever been the one design voice on a project, such as freelance work, a side project or setting up a component library?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.