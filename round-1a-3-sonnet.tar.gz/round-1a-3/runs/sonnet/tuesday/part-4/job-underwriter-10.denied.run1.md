Web search wasn't permitted in this session, so I'm assessing from what you pasted and labelling accordingly.

## Decision snapshot

**Worth continuing, on conditions. Nothing in the posting or the WhatsApp message asks you for money, ID or bank details, but I couldn't establish Fernquay from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Research calls with school owners), R8 (Own the booking flow end to end)
- `important` — adjacent: R9 (First designer, no design peers)

R6 — a credible bridge, its limit named; R8 — checkout is one stage of a booking flow; R2 — waiting on your pay floor.

**Opportunity ledger.** The employer is not established from here (RR1), design decision rights are unstated (RR2) and the equity terms are open (RR4). The pay range is stated (RR3) and the team structure is concrete (RR5). The WhatsApp message asks only for a call time, and scheduling by chat for a video interview is routine, so it takes no register entry.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and the posting verified independently, see RR1; (2) €52,000–€60,000 meets your pay floor, see R2; (3) equity terms made concrete, see RR4; (4) decision rights over design made concrete, see RR2, and your first-designer case framed honestly as adjacent, see R6, R8 and R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, self-described as "six people in Galway making booking software for sea-kayak and surf schools" | `[grounded]` posting's own wording; not checked against any outside page |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship alongside two engineers; closest working partner is co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; instrument, vesting and dilution not stated | `[grounded]` posting |
| Scope read | One person carries research, design and delivery, with no stated design lead or peers | `[inferred]` from the mandate list against a six-person team and "first designer" |
| Market calibration | Not run: the role-family search was not permitted, so no salary band is claimed for this title | — |
| Unknowns | Who decides design questions; equity terms; funding and revenue; whether the posting is live on a careers page; first-90-day outcomes (none stated) | — |
| Contradictions | None between the posting and the WhatsApp message; the posting has not been cross-checked against a careers page | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | Confidence grades your own account: you moved back to Galway last year (prose background, not a stated non-negotiable). Fit is `direct` because the office is in Galway | `[grounded]` your background and the posting | none |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the range, but you have given no pay floor, so there is nothing to compare it to. The equity terms are not stated either | `[grounded]` posting; no candidate floor given | Answer G3; ask RR4's question |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. This is your account, with no document inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. They have already seen your checkout case study, but I have not inspected it | `[grounded]` your background and Ronan's message | Have the case study file ready to walk through |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Whether you also planned and synthesised them is not stated, so expect a probe | `[grounded]` your background | Be ready to say exactly what was yours |
| R6 | Research calls with school owners | must_have | adjacent | medium | transferability | Bridge: customer sessions at a consumer travel-booking company. Limit: nothing in your background shows interviews with small-business owners. Strengthener: any owner or B2B conversation you have run | `[grounded]` your background; `[inferred]` that owner calls differ from consumer sessions | Answer G1 |
| R7 | Working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Bridge: you redesigned the checkout flow. Limit: checkout is one stage, and nothing says you owned the stages before it. Strengthener: any pre-checkout work you led | `[grounded]` your background; requirement `[inferred]` from "own the booking flow end to end" | Answer G2 |
| R9 | Working as the only designer | important | adjacent | medium | transferability | You have never been the only designer, in your own words. Bridge: you owned a checkout redesign and a monthly research cadence. Limit: unknown who set design direction on those | `[grounded]` your statement; requirement `[inferred]` from "first designer" | Answer G2; rehearse saying it plainly |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Research with business owners (R6, must_have) | transferability | Monthly customer usability sessions, but nothing involving small-business owners as the interviewees | The role's research calls are with school owners, which is a different audience from travel-booking customers | Interviews with hotel, tour or activity operators; supplier or partner calls; internal-tool feedback sessions | A sanitized research plan, a synthesis doc, a recording snippet | `[grounded]` background is silent on owners; `[inferred]` that this is the likeliest probe |
| G2 | Breadth of flow ownership and who set direction (R8, R9) | transferability | A checkout redesign and the research cadence, with no detail on stages before checkout or on the design lead | The role is "end to end" with no design peers, so the limit of your ownership decides how credible the bridge is | Search or availability design; basket and pricing screens; confirmation and post-booking emails; setting the research agenda yourself | Before-and-after flows, a decision log, a roadmap slice | `[grounded]` background is silent on both; `[inferred]` that this shapes the interview |
| G3 | Pay floor (R2, hard_gate) | hard_gate | The range is stated; your floor is not | A gate that is not established stays on the snapshot until you answer it | Your current salary band, your minimum, and how much weight you give equity | Not applicable: a stated figure suffices | `[grounded]` posting states the range; no floor given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who will be on the call? | unresolved |
| RR2 | Responsibility without stated decision rights | unknown | — | "You would be our first designer: own the booking flow end to end" | The role may carry the booking flow's outcomes with no design lead, and design calls may sit with the co-founder | `[inferred]` from the ownership language against the posting's silence on decision rights | Who makes the final call on design decisions, and who reviews design work today? | unresolved |
| RR3 | Pay range stated | positive_signal | — | "Salary €52,000–€60,000" | The posting shows its pay rather than withholding it | `[grounded]` posting | What is the process for moving within that range? | noted |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | The instrument, vesting and dilution are unspecified, so its value cannot be judged | `[inferred]` from the posting's silence on terms | Is the equity options or shares, what is the vesting schedule, and what is the current fully diluted ownership? | unresolved |
| RR5 | Concrete team and mandate | positive_signal | — | "ship alongside our two engineers" | Team size, partners and scope are specific rather than vague | `[grounded]` posting | What would the first booking-flow project be? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the call through the emailed calendar invite and check that the sender's domain matches a Fernquay site you found yourself, and that the link is a mainstream video platform | A routine check for any small employer; it puts nothing about this one in doubt | `[generic]` routine step | pending your approval |
| A2 | Look up Fernquay's own website and Ronan Kehoe's and Saoirse's public professional profiles before the call | This is the check I could not run; it settles RR1 | `[generic]` how a small employer is usually verified | pending your approval |
| A3 | Lead the conversation with your checkout redesign and the monthly sessions, in your own words and your own scope | Ronan's message names the checkout case study | `[grounded]` the WhatsApp message | pending your approval |
| A4 | Say plainly that you have not been the only designer, then describe what you did own | The R9 bridge holds only with its limit stated | `[grounded]` your statement | pending your approval |
| A5 | Ask RR1, RR2 and RR4 verbatim in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you want prep for the call with Ronan and Saoirse, mock-interview is the module for that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Fernquay's product and its careers listing) were not permitted. It would have moved role reality's Organization and Contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search (Irish product designer salary) was not permitted. It would have moved the market calibration line and the pay comparison against R2 |
| 3. Hiring manager's public footprint | unavailable | One search on Ronan Kehoe was not permitted. It would have moved the scope read and which story the plan leads with |

I'll offer the dossier once: if you'd like, I can save this as `tuesday-dossier.md` to carry forward.

## Upgrade menu

- Allowing web search → RR1 resolves one way or the other, R2 is set against a salary band, and Ronan's public footprint informs A3.
- A link to the posting on Fernquay's own careers page → RR1 and the contradictions row close.
- Your portfolio or the checkout case study → R4 rises to `high`.
- A sanitized research plan or synthesis → R5 rises to `high`, and G1 narrows.
- Your pay floor → R2 and the hard-gates line resolve.
- Ronan's answers on equity terms and decision rights → RR2 and RR4 close.

## Questions

G1 — Have you ever interviewed business owners (hotel, tour or activity operators, suppliers) rather than consumer customers? What did you own, and what came of it?

G2 — Which stages of the booking journey beyond checkout did you personally design, and who set direction on the checkout redesign: you, or a design lead?

G3 — Is €52,000–€60,000 at or above the pay you need?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.