Search permission was refused, so this runs on what you pasted. Nothing external is checked.

## Decision snapshot

**Yes, take the call, on conditions. Status: `conditional_go`.** On legitimacy: I can't establish Fernquay from here (RR1), and I found nothing in either message that asks for money, documents or ID.

**Fit ledger.**

- `hard_gate`: direct: R7 · unclear: R8 (Pay of €52,000–€60,000)
- `must_have`: direct: R1, R2, R3, R5 · adjacent: R4 (Own the booking flow end to end)
- `important`: adjacent: R6 (First designer, no design peer)

R4 — a credible bridge, its limit named; R6 — adjacent, never the only designer; R8 — waiting on your pay floor.

**Opportunity ledger.** Fernquay is not established from attributable sources, so the posting is unverified (RR1). The mandate is broad for one designer, with no stated success measures (RR2). The equity terms are missing (RR3). On the other side, pay, equity range and working pattern are stated up front (RR4). The posting and the WhatsApp message ask for no payment, documents or ID. Scheduling by WhatsApp for a video call is routine, so no register entry rests on it.

- **Hard gates:** none failed (R7 `direct`); unconfirmed: R8 (Pay of €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Fernquay verifies: the role is on its own site and the invite comes from an address at that site's domain (RR1).
  2. The pay range clears your floor (R8).
  3. First-year scope and who sets design priorities are concrete on the call (RR2, R4, R6).
  4. Your checkout work is framed as adjacent to owning the whole flow, never as owning it end to end (R4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not checked against any outside source |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working relationship | Closest to co-founder Ronan Kehoe; the call is with him and Saoirse, the CTO | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | Product design, research and shipping with engineers in one seat. That is plausible at six people, but it has no design peer to catch mistakes | `[inferred]` from the mandate against the stated team size |
| Market calibration | Not run, because search was refused. I won't quote a salary band from memory | — |
| Unknowns | Equity terms, funding and runway, success measures, who sets design priorities, first-90-day outcomes | — |
| Contradictions | None between the posting and the message | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, stated by you; nothing inspected yet | `[grounded]` your message | none |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily", stated; no file or case study inspected by me | `[grounded]` your message | Offer: link the checkout case study they already saw, to raise it |
| R3 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The posting's calls are with school owners, so the kind of participant differs and not much else | `[grounded]` your message | none |
| R4 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow in a squad. Limit: you didn't say you owned the steps before or after checkout, or scope decisions | `[grounded]` your message; `[inferred]` the limit, from what you didn't say | See G1 |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your message | none |
| R6 | Works as first designer, with no design peer or lead | important | adjacent | medium | transferability | You've never been the only designer. Adjacent work: running your own usability sessions and a checkout redesign. Limit: no evidence of setting design direction alone | `[inferred]` requirement, from "You would be our first designer"; `[grounded]` your message | See G2 |
| R7 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. Commute is not stated, and you haven't given constraints | `[grounded]` posting and your message | none |
| R8 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the range. You haven't stated a floor, so whether it clears is not established | `[grounded]` posting; no statement from you | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole booking flow (R4, must_have) | transferability | A checkout redesign; nothing on the steps before or after it, or on who set scope | R4 is a `must_have` at `adjacent`; the question will likely be how far your ownership went | Search or availability steps you shaped; confirmation, cancellation or rebooking; payment edge cases worked through with engineers | The checkout case study, a flow map, before/after results, a Figma link | `[grounded]` message silence on scope; `[generic]` that this is the likely probe for a "whole flow" mandate |
| G2 | Designing without a design lead (R6, important) | transferability | Squad work and self-run sessions; no sign of solo direction-setting | This is the biggest step up in the role compared with your history | Setting up the usability-session routine; a component library or tokens; making design calls when no lead was available | A research-session template, a design-system file, a spec an engineer built from | `[grounded]` message; `[generic]` that a first-designer seat is judged on this |
| G3 | Pay against your floor (R8, hard_gate) | hard_gate | A stated range and no floor from you | Decides whether this hard gate is met | Your current salary band and the lowest offer you'd accept, whether or not equity counts | None needed | `[grounded]` posting range; floor not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` you found little online | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Broad mandate, no stated success measures | unknown | — | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | One seat may carry design, research and product judgement with no definition of success and no design lead | `[inferred]` from the mandate against the posting's silence on measures | What would a good first year look like for the booking flow, and who sets design priorities? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage's basis, vesting, exercise price and funding stage aren't given, so its value can't be judged | `[inferred]` from a percentage with no terms | What is the vesting schedule, what is the percentage of, and when did you last raise? | unresolved |
| RR4 | Concrete, upfront terms | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | Pay, working pattern and the person you'd work with are all stated | `[grounded]` posting | Who else would I work with day to day, and how many of the six are in Galway? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find the role on Fernquay's own website, found independently. Check that the calendar invite came from an address at that site's domain | See RR1 | `[generic]` standard check | pending your approval |
| A2 | Ask the RR1, RR2 and RR3 questions verbatim, plus one on the pay range if R8 is still open | The register doubles as call prep | `[grounded]` register | pending your approval |
| A3 | Lead with the checkout redesign and the monthly usability sessions. Say plainly that you worked in a squad with four engineers and have not yet been the only designer | See R4, R6. Every clause traces to your own message | `[grounded]` your message | pending your approval |
| A4 | If they ask for a "messy real project", ask the scope, the time box and whether it is paid. Share only work you're free to share | Their posting says "we would rather see one messy real project than a polished deck" | `[generic]` common practice; `[grounded]` posting quote | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers product designer Galway" were refused. Existence, a live listing and consistency with the posting are unchecked, so RR1 stands |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland startup 3-5 years experience 2026" was refused. Market calibration and the pay check for R8 are not run |
| 3. Hiring manager's public footprint | unavailable | Search "Ronan Kehoe Fernquay co-founder" was refused. It would have moved the scope read and what to lead with |

I can save this as a `tuesday-dossier.md`, which interview prep can read if you want to rehearse for the call with Ronan and Saoirse.

**Upgrade menu**

- Granting web search lets me re-run these targets. Refused calls count against the cap, so one search and two page fetches remain.
- Your pay floor closes R8 and G3.
- A link to the checkout case study they saw would raise R2 and R4 toward `high`.
- Ronan's answers on equity terms close RR3. The role's careers-page link, or the invite's sending domain, closes RR1.

**Questions**

G3 — What is the lowest salary you'd accept, and does equity change that?
G1 — Which parts of the booking journey beyond checkout did you personally design, and who decided the scope?
G2 — Have you made design decisions without a lead or design peer, and what did you set up yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.