Searches were refused, so this runs on the two postings and your background only.

## Decision snapshot

**Duinvaart: yes, worth your time. R2, R3 and R4 (the `must_have` rows) are all `direct`. Status: `conditional_go`.**
**Kroonhaven: no, skip it. R10, R12 and R13 (all `must_have`) are `absent`. Status: `no_go`.**

### Duinvaart Cold Chain, Operations Analyst

**Fit ledger.**
- `hard_gate`: unclear: R1 (Hybrid, three days a week in Rotterdam)
- `must_have`: direct: R2, R3, R4
- `important`: direct: R7; adjacent: R6 (Temperature compliance on a refrigerated fleet)
- `preferred`: adjacent: R5 (Dutch a plus)

R6 — a credible bridge, its limit named; R1 — commute not yet confirmed by you.

**Opportunity ledger.** Concrete deliverables (RR3). The employer and live posting are unchecked from here (RR1), and the pay is not stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: three days a week in Rotterdam works for you; (2) RR1: the posting is live on Duinvaart's own careers page.

### Kroonhaven Foods, Supply Planner

**Fit ledger.**
- `hard_gate`: unclear: R8 (On-site in Utrecht)
- `must_have`: adjacent: R9 (Fluent Dutch); unclear: R11 (Advanced Excel); absent: R10 (3+ years supply or demand planning in FMCG), R12 (SAP IBP or similar planning system), R13 (Own the 13-week supply plan)
- `important`: adjacent: R14 (Run the weekly S&OP meeting)

R10, R12, R13 — no planning work in your history; R9 — conversational, not fluent; R14 — a bridge, its limit named.

**Opportunity ledger.** Employer unchecked from here (RR5), pay not stated (RR6). The no-go comes from the fit side, not from anything wrong with the role.

- **Hard gates:** none failed; unconfirmed: R8 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to be different:** planning experience in FMCG (R10), hands-on planning-system work (R12), owning a supply plan (R13), and fluent Dutch (R9).

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| Duinvaart | Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Duinvaart | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Duinvaart | Unknowns | Salary; team size and reporting line; employer's own careers page not checked | `[grounded]` posting silent; research refused |
| Kroonhaven | Mandate | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run weekly S&OP | `[grounded]` posting |
| Kroonhaven | Working pattern | On-site in Utrecht | `[grounded]` posting |
| Kroonhaven | Scope read | A planning-owner role, not an analyst role: the plan and the meeting are both yours | `[inferred]` from "own" and "run" against the requirements list |
| Both | Market calibration | Not available: no role-family sweep ran, so no pay band or norm is given | `[grounded]` searches refused |
| Both | Contradictions | None visible within either posting's text | `[grounded]` postings as pasted |

## Evidence map

Your background is typed prose, so it counts as self-report: `medium` is the ceiling until you attach something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam (Duinvaart) | hard_gate | unclear | none | hard_gate | You have not stated a location or commute limit. You work in Amsterdam, but your home location is not given | `[grounded]` posting term; no constraint stated | Gate question G3 in the closing block |
| R2 | 2+ years in logistics or operations analysis (Duinvaart) | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier. A length-of-experience requirement is graded as fit, not a gate | `[grounded]` your background | none |
| R3 | Strong SQL (Duinvaart) | must_have | direct | medium | none | SQL daily. "Strong" is a degree no artifact has yet shown | `[grounded]` your background | offer: a sanitized query would raise to high |
| R4 | Power BI or Tableau (Duinvaart) | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard your depot managers use | `[grounded]` your background | offer: a sanitized dashboard screenshot would raise to high |
| R5 | Dutch a plus (Duinvaart) | preferred | adjacent | medium | transferability | Conversational Dutch is partial; it is not fluent | `[grounded]` your stated level | state "conversational" plainly; never "fluent" |
| R6 | Temperature compliance across a refrigerated fleet (Duinvaart) | important | adjacent | medium | transferability | On-time delivery tracking is delivery-performance work you did. Limit: you have not mentioned any temperature or cold-chain data. Roles like this usually pair delivery KPIs with temperature checks | `[grounded]` your OTD work; `[generic]` how such roles are built | G1 |
| R7 | Work with depot managers on route changes (Duinvaart) | important | direct | medium | none | You ran the weekly route-performance review and built the dashboard depot managers use | `[grounded]` your background | none |
| R8 | On-site in Utrecht (Kroonhaven) | hard_gate | unclear | none | hard_gate | No location or commute limit stated | `[grounded]` posting term; no constraint stated | Ask only if you decide to pursue it |
| R9 | Fluent Dutch (Kroonhaven) | must_have | adjacent | medium | transferability | Conversational Dutch is the nearest evidence. Limit: it is below the posting's word. A weekly S&OP meeting is likely held in the working language, so this limit would show | `[grounded]` your stated level; `[inferred]` the meeting language | none; do not claim fluency |
| R10 | 3+ years supply or demand planning in FMCG (Kroonhaven) | must_have | absent | none | capability | You have never worked in planning, and the parcel-carrier role is not FMCG planning. This is a long-experience requirement, not a legal gate, but it cannot be closed for this posting | `[grounded]` your statement | closure path in plan B1 |
| R11 | Advanced Excel (Kroonhaven) | must_have | unclear | none | discovery | Your background names SQL and Power BI, not Excel. Silence, not absence | `[grounded]` background silent | G2; does not change the status |
| R12 | SAP IBP or a similar planning system (Kroonhaven) | must_have | absent | none | capability | No planning-system work stated | `[grounded]` your statement | closure path in plan B1 |
| R13 | Own the 13-week supply plan, capacity against forecast (Kroonhaven) | must_have | absent | none | capability | You have never owned a plan like this; route-performance reporting is analysis, not capacity-versus-forecast balancing | `[grounded]` your statement | closure path in plan B1 |
| R14 | Run the weekly S&OP meeting (Kroonhaven) | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: that was a performance review, and S&OP is a planning-decision forum, which you have not stated running | `[grounded]` your review; `[inferred]` what S&OP is | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, important) | transferability | On-time delivery work is stated; nothing on temperature data or cold-chain KPIs | R6 is the one Duinvaart row where your history stops short of the posting, so it is the objection to prepare for | Delivery-exception or damage-rate reporting; service-level reports with thresholds; any monitoring of time-sensitive or special-handling parcels | A sanitized report or dashboard page showing an exception or threshold metric | `[grounded]` background silent on temperature; `[generic]` that this is the likely probe |
| G2 | Advanced Excel (R11, must_have) | discovery | Excel is never mentioned | It would not change Kroonhaven's status, since R10, R12 and R13 stay `absent` | Pivot-heavy models, lookups across large sheets, forecasting workbooks | A sanitized workbook | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart not verified from here | unknown | — | "Duinvaart Cold Chain, Rotterdam" | Nothing is known against it; the check could not run | `[grounded]` searches refused | Is this role currently open, and who would I report to? | unresolved |
| RR2 | Duinvaart pay not stated | unknown | — | (no figure in the posting as pasted) | The posting may withhold pay, or the paste may have dropped it | `[grounded]` posting as pasted | What salary range is budgeted for this post? | unresolved |
| RR3 | Duinvaart deliverables are concrete | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | Scope is defined, and it matches work you have done | `[grounded]` posting | How many depots and depot managers would I work with? | noted |
| RR4 | Kroonhaven not verified from here | unknown | — | "Kroonhaven Foods, Utrecht" | Nothing is known against it; the check could not run | `[grounded]` searches refused | Is this role currently open, and who would I report to? | unresolved |
| RR5 | Kroonhaven pay not stated | unknown | — | (no figure in the posting as pasted) | The posting may withhold pay, or the paste may have dropped it | `[grounded]` posting as pasted | What salary range is budgeted for this post? | unresolved |

## Application plan

Everything here is proposed and pending your approval, the edits table and the prose lines alike. Nothing changes until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: lead the CV with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran, in your own wording, reordered with no added facts | R4, R7 | `[grounded]` your background | pending your approval |
| E2 | Write Dutch as "conversational" | R5 | `[grounded]` your stated level | pending your approval |
| E3 | Cover-note line: "I built the on-time delivery dashboard our depot managers use at a parcel carrier; I haven't worked with temperature data." | R6; names the limit up front | `[grounded]` your background | pending your approval |
| A1 | Check the posting on Duinvaart's own careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |
| B1 | Skip Kroonhaven. If planning interests you, entry-level planning or planning-analyst roles are a better first step than a 3+ years FMCG posting | R10, R12, R13 | `[generic]` role-family pattern, not a claim about Kroonhaven | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Searches for each employer's careers page were refused. It would have settled whether each employer and posting exists as described (RR1, RR4) |
| 2. Role-family sweep | unavailable | Searches for a Rotterdam operations-analyst pay band and a Utrecht FMCG supply-planner pay band were refused. They would have fed market calibration and RR2, RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you grant search access, I can re-run the two unavailable targets. A deeper company pass on either employer (up to 5 more searches and 2 more fetches) is also on offer, once, after that.

## Upgrade menu

- Each posting's link or its careers-page address → RR1 and RR4 close.
- A sanitized dashboard screenshot → R4 to `high`; a sanitized SQL query → R3 to `high`.
- An example of a threshold or exception report → G1, and R6's bridge firms up.
- The posted salary, if the original lists it → RR2 and RR5 close.
- The hiring manager's name for either role → role reality's scope read and which story to lead with.

I can also write this up as a `tuesday-dossier.md` if you'd like one.

## Questions

G3 (R1) — Is three days a week in Rotterdam workable for you, given where you live?
G1 (R6) — Have you ever reported on exceptions or thresholds, such as damaged, delayed or time-sensitive parcels? What was yours, and did anyone act on it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.