I've run three searches: the company, market pay for the role, and Ronan's public professional profile. Next I'll check whether the job is on Fernquay's own careers page.
## Decision snapshot

**Yes, this is worth pursuing, and the company and posting match what Fernquay publishes on its own pages (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6
- `important` — adjacent: R7 (Own the booking flow end to end), R8 (First designer, no design peers)

R7 — a credible bridge, its limit named; R8 — squad work bridges, solo ownership untested; R2 — waiting on your pay floor.

**Opportunity ledger.** The employer is established and the range is openly stated (RR1, RR4). The open items are equity terms and runway (RR2) and design support in a one-designer role (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits at or below €60,000, per R2; (2) the equity terms and runway answer acceptably, per RR2; (3) you are comfortable being the only designer, per R8 and RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page (search result) |
| Posting | Fernquay's own careers page lists the same role: first design hire, hybrid with two days a week in Galway, €52,000–€60,000 plus equity, and "apply with one real project" | `[grounded]` careers listing (search result) |
| Contact channel | Ronan messaged on WhatsApp to schedule a 45-minute video call, with an emailed invite. The message asks for nothing except the call (no money, no documents, no ID). Scheduling by message for an interview held on video is a routine step. Plan row A1 has a quick check | `[grounded]` your message; `[generic]` that this is common practice |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and previously a product lead at a Galway travel-software company for five years | `[grounded]` public profile (search result), roles only |
| Scope read | Booking flow, research calls and shipping with two engineers is a broad but coherent remit for a first design hire in a six-person product company | `[inferred]` from the posting's scope list against the stated team size |
| Market calibration | Product designers with 3–5 years in Ireland: median base €57,000, interquartile range €51,500–€62,000. The posting's range sits inside that band, plus equity. It is one 2026 survey (n=520), Ireland-wide rather than Galway or startup-specific, and not this employer's offer | `[generic]` Tillerby 2026 salary report; `[grounded]` posting's range |
| Unknowns | Equity terms, company runway, who reviews design work, what follows this call | — |
| Contradictions | None found between your posting and the careers listing | `[grounded]` listing seen in search result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so location is met on your own statement. You haven't said whether fixed office days suit you | `[grounded]` your message, posting | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No pay floor has been stated, so the term can't be settled. Confidence grades your statement of a constraint, and none exists yet. The posted range sits inside the survey's interquartile range | `[grounded]` posting figure; `[generic]` Tillerby band | Closing question for R2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, self-reported with no artifact inspected yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated. Depth is unprobed, and the case study they praised is the inspectable artifact, which I haven't seen | `[grounded]` your background | Share the case study link to raise R3 to R7 |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Their research calls are with school owners, and usability testing is one kind of research among several, so expect a question on interviews | `[grounded]` your background; `[generic]` that research types differ | none |
| R6 | Working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned a checkout flow, which is one stage of a booking flow. Your message doesn't say whether you owned the earlier steps or had decision rights | `[grounded]` your background; `[inferred]` that checkout is one stage | G1 |
| R8 | Be the first designer, with no design peers | important | adjacent | medium | transferability | You've never been the only designer, so solo ownership is untested. Squad work with four engineers carries over, but peer review and design direction did not | `[grounded]` your background | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R7, important) | transferability | A checkout redesign. The scope you owned beyond checkout and your decision rights aren't stated | The posting's first named duty is this flow, so the limit of your checkout work will likely come up | Owning availability or selection screens; a deposit, cancellation or rebooking rule; confirmation emails; deciding a trade-off with engineers | Checkout case study, before/after screens, sanitized funnel numbers | `[grounded]` your message is silent on scope; `[generic]` that this duty will be probed |
| G2 | First designer, no design peers (R8, important) | transferability | Squad experience with engineers; no stated solo design ownership | A first-designer role means setting standards and making calls without a design lead | Building a component library; setting design conventions for a squad; making design calls while the lead was away; freelance or side projects | A Figma library file, a design-decision note | `[grounded]` you've never been the only designer; `[generic]` what first-designer roles involve |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting match the company's own pages | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle, and funded by its customers." | The company exists as described and the role is live on its careers page | `[grounded]` About page and careers listing from search results | What does the process look like after this call, and who else will I meet? | noted |
| RR2 | Equity terms and runway unstated | unknown | — | "plus 0.5–1% equity" | The share type, vesting and dilution aren't given, and "funded by its customers" doesn't say how long the money lasts | `[inferred]` from the posting's silence; `[grounded]` About page funding line | What are the vesting terms and share type, and how many months of runway does the company have at current revenue? | unresolved |
| RR3 | One designer, no stated design support | risk_signal | low | "You would be our first designer: own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers." | Design, research and delivery all sit with one person, with no design feedback in the team | `[inferred]` from the scope list and team size | Who gives feedback on design work, and which decisions are mine versus yours or Ronan's? | unresolved |
| RR4 | Pay stated and inside the market band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The range is openly stated and sits within the typical band for this experience | `[grounded]` posting; `[generic]` Tillerby band, Ireland-wide | Where would my experience place me in that range? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the calendar invite came from an address at Fernquay's own domain, and that the video link opens a normal meeting service | Quick routine check on the invite you were sent; see Contact channel | `[generic]` common practice | pending your approval |
| A2 | Put RR2 and RR3's questions to Ronan and Saoirse verbatim | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | Lead with your checkout redesign and your monthly usability sessions, in your own words, saying what was yours and what was the squad's | See R5, R7. Ronan's public history includes product lead work in travel software, so a booking-flow story fits his background | `[grounded]` your background; `[inferred]` from his public profile | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about). Searched "Fernquay product designer job Galway", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). A fetch of fernquay.example/careers returned no page. Moved: RR1, role reality's Organization, Posting and Contradictions rows |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup 3+ years", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved: market calibration, RR4, R2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Public role history only. Moved: role reality's Hiring manager row, A3 |

## Dossier offer

If you'd like to keep this analysis, I can save it as a `tuesday-dossier.md` for later steps.

## Upgrade menu

- Your pay floor → R2 closes, and the decision likely simplifies to `go` or `no_go`.
- A link to the checkout case study or your Figma file → R3, R4, R5, R6 and R7 can move from `medium` toward `high`.
- Answers to G1 and G2 → R7 and R8 get a sharper bridge, with the limits stated.
- Their answers on equity terms and runway → RR2 closes.
- A prep pack for the call with Ronan and Saoirse → the mock-interview module builds it.
- A deeper research pass on Fernquay (funding and customer signals, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

R2 — What is the lowest total package you would accept, and do two fixed office days a week suit you?

G1 — Which parts of the booking journey beyond checkout did you personally design, and which decisions were yours rather than the squad's?

G2 — Have you ever set design direction or standards without a design lead, even on a side project, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.