I'm reading the job-underwriter playbook and now running the first research searches on Calderbrook and the pay band. I won't send your personal identifiers in any search.
**Worth applying to — on conditions. Status: `go`.** Calderbrook asks for one year of post-registration experience and you have five. The one real hurdle is a new caseload with no leg-ulcer Doppler skills, and the posting names Doppler training as something a new starter would expect to receive.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · adjacent: R4 · unclear: R5
- `important` — adjacent: R6 · direct: R8 · unclear: R9
- `preferred` — absent: R7

- **Hard gates:** none failed. R1 (NMC registration, Adult) and R2 (full UK driving licence) are `direct` on your stated details. Both are stated, not checked: the NMC register entry and your DVLA record are yours to check.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the job is confirmed live on Calderbrook's own careers page (RR1); (2) the district-nursing gap is framed honestly as adjacent, not as holding a caseload (R4); (3) you ask about Doppler training and induction before accepting (R7, RR3).

**Opportunity ledger.** The posting is specific about duties and about supervision by a senior community nurse, and it states pay and a team-lead contact (RR2, RR3). Two items are unverified: whether the vacancy is live (RR1) and the size of the caseload (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehab across Calderdale under an NHS contract. Founded 2015, 410 staff, four hubs | `[grounded]` about page fetched |
| Role | Band 5 district nursing: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Support | Small own caseload, supported by a senior community nurse; pool cars provided | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage, against a survey median of £34,300 (interquartile range £32,400–£36,600) | `[grounded]` JD; `[generic]` Wardround survey |
| Market calibration | The advertised range sits around the survey median. Pool cars are less common than mileage payment, which is a plus | `[generic]` role-family search |
| Team lead | Rhiannon Mabbott, a district nurse of eleven years, spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Unknowns | Caseload size, visits per day, on-call or weekend rota, Doppler training provision | — |
| Contradictions | None found. The careers page was not seen, so the posting's liveness is unconfirmed | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Registration stated active, revalidation March 2028. Self-reported and not checked against the register | `[grounded]` CV | Check your own entry on the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B licence stated. Not checked against your driving record | `[grounded]` CV | Check your own driving record |
| R3 | At least one year's post-registration experience | must_have | direct | high | none | Five years as a ward staff nurse is well beyond one year. It is a duration requirement, not a gate | `[grounded]` CV | none |
| R4 | Community district nursing at a caseload level | must_have | adjacent | medium | transferability | 18 months visiting patients at home in the discharge-to-assess team is a credible bridge. Limit: you have never held your own caseload, and the JD says the role does | `[grounded]` CV; `[inferred]` bridge | G1 |
| R5 | Wound and leg-ulcer care | must_have | unclear | low | discovery | Pressure ulcers and surgical wounds are stated. Leg-ulcer care, including compression, is not mentioned, so it is open whether you have done any | `[grounded]` CV silence | G2 |
| R6 | End-of-life care in the home | important | adjacent | low | discovery | The CV is silent. A medical ward and home visits make some exposure likely, but that is inference | `[inferred]` from ward and home-visit roles | G3 |
| R7 | Doppler assessment (desirable) | preferred | absent | none | capability | You state you have never done one. The JD lists it as desirable, and the team lead has spoken on training staff new to it | `[grounded]` your statement; `[grounded]` forum page | Ask about training |
| R8 | Catheter care, insulin administration | important | direct | medium | none | Both are stated on the CV. Neither is shown by a document | `[grounded]` CV | none |
| R9 | Clear, timely electronic records | important | unclear | low | discovery | The JD asks for it. The CV does not name a record system. It is probably covered by ward and discharge documentation, but that is inference | `[inferred]` | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R4, must_have) | transferability | Home visits in the first week after discharge, with no caseload ownership stated | This is the main step up in the role | Planning your own visit lists, escalating deterioration, discharging or handing over patients | A short description of your autonomy on the discharge-to-assess team | `[inferred]` bridge; `[generic]` that caseload ownership is the usual step up |
| G2 | Leg-ulcer care (R5, must_have) | discovery | Pressure and surgical wounds only | The JD names leg-ulcer care first among the duties | Compression bandaging, ankle-brachial index checks seen or done, venous ulcer dressing | Any leg-ulcer treatment or training record | `[grounded]` CV silence |
| G3 | End-of-life care at home (R6, important) | discovery | Nothing stated | End-of-life visits are one of the listed duties | Syringe driver use, anticipatory medicines, verification of expected death | A training record or a short description | `[inferred]` |
| G4 | Electronic patient record use (R9, important) | discovery | No record system named | Records are named in the essential criteria | The ward or discharge team's electronic record | Name of the system | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not matched on the employer's careers page | unknown | — | "Current vacancies are listed on our careers page" | The posting may be live and the careers page simply was not reachable, or it may have closed | `[inferred]` from the about page naming a careers page that was not seen | Is this role listed on your own careers page, and is it still open? | unresolved |
| RR2 | Pay stated and in line with the market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent pay at about the survey median | `[grounded]` JD; `[generic]` survey | What is the starting point on the range for someone with my experience? | noted |
| RR3 | Doppler is desirable, not essential, and the team lead teaches it | positive_signal | — | "Desirable: Doppler assessment for leg ulcers" | The team may train new starters | `[grounded]` JD; `[inferred]` from the speaker page | Is Doppler training provided, and how soon after starting? | noted |
| RR4 | Caseload size and rota unstated | unknown | — | "You will hold a small caseload of your own" | The caseload may grow quickly, or on-call duties may apply | `[inferred]` from the posting's silence | How many patients on the caseload, and is there a weekend or on-call rota? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the discharge-to-assess secondment, stating the visits you did and how you worked on your own | see R4 | `[grounded]` CV | pending your approval |
| E2 | Name the electronic record system you used, if any | see R9 | `[inferred]` | pending your approval |
| E3 | Say plainly that you have not yet done Doppler assessment and ask about training | see R7, RR3 | `[grounded]` your statement | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott and use the register's questions | see RR1, RR3, RR4 | `[grounded]` JD | pending your approval |

Nothing above is final until you approve it. That covers the advice as well as the CV edits.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing" and fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). It confirmed the employer exists as described. The careers page was not reachable from that page, so RR1 stays open |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary scope Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the team-lead row and RR3 |

Your National Insurance number isn't needed for this assessment and I haven't used it. Don't put it on an application before an offer.

I can save this assessment as a `tuesday-dossier.md` file you could reuse later, if you'd like one.

**Upgrade menu**
- The employer's careers page link, or the posting's own link → settles RR1.
- Any leg-ulcer or compression training record → raises R5.
- Your discharge team's record system and any end-of-life training → raises R6 and R9.
- Deeper research on the employer (up to 5 more searches and 2 more fetches) → adds funding, staffing and recent-news checks to the register. Tell me if you want it.
- If you want the CV tailored once you've decided to apply, resume-tailor does that.

**Questions**
1. (G2) Have you done any leg-ulcer care, such as compression bandaging, on the ward or in the discharge team?
2. (G1) In the discharge-to-assess role, how far did you plan and run your own visits without a senior alongside?
3. (G4) Which electronic record system did you use there?

You can answer briefly, say "skip" to any of them, or paste a training record instead.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.