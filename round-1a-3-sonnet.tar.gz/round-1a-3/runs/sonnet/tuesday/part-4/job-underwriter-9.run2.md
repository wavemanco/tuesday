## Decision snapshot

**Yes, asking for bank details, your PPS number and a passport check after a written offer is routine onboarding (plan row A1). On the job itself, it's worth accepting on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Hybrid, two days Limerick office), R3 (Salary €38,000–€42,000)
- `must_have` — direct: R4, R6, R7, R10 · adjacent: R8 (Pension changes) · unclear: R5 (Irish PAYE, PRSI, USC)
- `important` — adjacent: R11 (240 staff, monthly cycle) · unclear: R9 (Staff payroll queries)

R8 — a credible bridge, its limit named; R5 — your background doesn't say which country's rules you ran payroll under; R2 and R3 — only you can say whether they meet your own limits.

**Opportunity ledger.** The ad and the offer agree on role, pay band and hybrid pattern (RR3). Two things are unknown: the written terms behind the offer (RR2) and how much support you'd get on pension changes (RR1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Hybrid, two days Limerick office), R3 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the office days and the €40,000 fit your own limits — R2, R3; (2) you ran payroll under Irish PAYE, PRSI and USC — R5; (3) a handover or training on pension changes is agreed — R8, RR1; (4) the written contract matches the offer — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer email |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` ad |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Working pattern | Hybrid, two days a week in the Limerick office; start date agreed after your notice period | `[grounded]` ad and offer email |
| Pay | €40,000 offered, against an advertised €38,000–€42,000 | `[grounded]` ad and offer email |
| Process | Two in-person interviews at their office, then a written offer with a five-working-day reply window | `[grounded]` your account |
| Scope read | The ad gives no team size, payroll software or success measures. It's unclear whether you'd be the only payroll person | `[inferred]` from the ad's silence on all three |
| Market calibration | Not run: the web searches were not permitted, so there's no salary band to set against €40,000 | — |
| Unknowns | Who handles pension changes today; team size; payroll software; probation, hours, leave and pension scheme terms | — |
| Contradictions | None between the ad and the offer email | `[grounded]` your two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | A payroll qualification or working towards one | hard_gate | direct | medium | none | You hold a Payroll Technician certificate (2024). It's your own account, and no certificate has been inspected | `[grounded]` your background | A copy of the certificate would raise this to `high` |
| R2 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | You have been to the office twice, but you haven't stated whether the commute and days suit you. The row is graded on your statement, which doesn't exist yet | `[grounded]` the two interviews; `[inferred]` that this signals feasibility, which isn't a stated limit | Question Q1 |
| R3 | Salary €38,000–€42,000 | hard_gate | unclear | low | hard_gate | €40,000 sits inside the advertised band. You haven't stated a pay floor, so it can't be met or failed yet | `[grounded]` ad and offer email | Question Q1 |
| R4 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff at a hotel group. Self-reported, with no inspectable artifact | `[grounded]` your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You ran payroll, but you haven't said under which tax regime. Hotel-group payroll in Ireland would normally use these, but that's an assumption | `[grounded]` background silent on jurisdiction; `[generic]` what hotel-group payroll in Ireland involves | Question Q2 |
| R6 | Monthly reconciliation of payroll to the general ledger | must_have | direct | medium | none | Your background names the monthly payroll-to-ledger reconciliation as part of your job | `[grounded]` your background | none |
| R7 | Processing starters and leavers | must_have | direct | medium | none | Named in your background | `[grounded]` your background | none |
| R8 | Processing pension changes | must_have | adjacent | low | transferability | You have not done pension changes yourself, as you said. Limit: you haven't set up or changed a pension record. The bridge is that you ran full payrolls where pension deductions presumably flowed through, which is a derivation, not something you confirmed | `[grounded]` your statement; `[inferred]` the deduction exposure from payroll running | Question Q3 |
| R9 | Answering staff payroll queries | important | unclear | low | discovery | Your background doesn't mention staff queries | `[grounded]` background silent | Held for a later turn |
| R10 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your background | none |
| R11 | Scale: 240 staff, monthly cycle (implied by the ad) | important | adjacent | medium | transferability | You ran 90 staff on a fortnightly cycle. The monthly reconciliation is the same task, but you haven't run a population of 240 | `[grounded]` your background and the ad; `[inferred]` the requirement from the ad's staff figure | Ask the team size and software (RR3's question) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish tax regime (R5, must_have) | discovery | You ran payroll, but your background doesn't name the regime | The role names PAYE, PRSI and USC, so which regime you ran decides whether R5 is `direct` | Filing PAYE returns or P30s for the hotel group; applying USC and PRSI classes to starters; year-end reconciliation | A redacted payslip layout, a Revenue return summary, or the payroll software's name | `[grounded]` background silent; `[inferred]` that confirming it moves R5 to `direct` |
| G2 | Pension changes (R8, must_have) | transferability | You saw your manager handle them and did not do them yourself. Pension deductions probably ran through your payrolls | A must-have you haven't done. Being plain about it, and asking for a handover, is safer than discovering it on day one | Applying pension deductions in runs; processing opt-ins or opt-outs for starters and leavers; supplying pension contribution reports to your manager | A pension contribution reconciliation you prepared | `[inferred]` bridge from payroll running; `[generic]` that interviews for this kind of role probe this point |
| G3 | Staff queries (R9, important) | discovery | No mention in your background | Part of the role, so a gap on paper | Answering payslip or tax-credit queries; fixing a pay error for a colleague | None needed yet | `[grounded]` background silent. Not asked this turn, because of the question budget |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pension changes named in the duties with no stated handover (R8) | unknown | — | "process starters, leavers and pension changes" | You may be expected to run pension changes from day one, with no one currently trained on them | `[inferred]` from the ad's listing of the duty against your account of never having done them | Who handles pension changes today, and what handover will I get? | unresolved |
| RR2 | Terms beyond the offer email not yet seen | unknown | — | "starting on a date we agree once your notice period ends" | A written contract with probation, hours, leave and pension scheme details may not yet have been issued | `[generic]` employers normally follow an offer with written terms; nothing here shows whether that happened | Can you send the full contract, including probation, hours, leave and pension terms, before the reply date? | unresolved |
| RR3 | Ad and offer consistent, with a named manager and in-person interviews | positive_signal | — | "€40,000 a year ... reporting to Declan Garvagh, Finance Manager" | The role and pay are clearly defined and match the advertised band | `[grounded]` your two pasted texts and your account of the interviews | How large is the finance team, and what payroll software do you use? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the request for bank details, PPS number and passport as routine onboarding. Bank details are for salary, the PPS number is for Revenue and the passport is for the right-to-work check. Your "never hand them over" rule is sound for the stage before an offer, and this request comes after one | Answers your question | `[generic]` how employers onboard after an offer | pending your approval |
| A2 | Enter the details only in the employer's own portal. Find the portal address on Marrowgate Housing's own website, or ring the People Team on the number published there, and don't rely only on a link in an email. Don't send them as email attachments | The check is yours, and it costs a few minutes | `[generic]` standard onboarding hygiene | pending your approval |
| A3 | Confirm that the email you received came from the same address domain as the employer's website, before you reply to accept | The one verifiable link between the email and your interviews | `[generic]` standard onboarding hygiene | pending your approval |
| A4 | Before the five-working-day reply date, ask RR2's question about the written contract and RR1's question about pension handover | The reply window is the cheapest time to ask | `[grounded]` RR1, RR2 | pending your approval |
| A5 | Tell Declan plainly that pension changes were your manager's at the hotel group, and ask for a handover. Don't present pension changes as something you've run | Matches your own statement | `[grounded]` your statement, R8 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent ("Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers Payroll Administrator") and both were refused. It would have confirmed the employer's pages and that the ad is live. For now the evidence is the two in-person interviews |
| 2. Role-family sweep | unavailable | One search was sent ("payroll administrator salary Ireland Limerick 2026") and refused. It would have supplied the market calibration line, set against €40,000 |
| 3. Hiring manager's public footprint | unavailable | One search was sent ("Declan Garvagh Finance Manager Marrowgate Housing") and refused. It would have informed the scope read and which of your stories to lead with |

## Upgrade menu

- Allowing web search would run the three targets above: the employer's own pages, a Limerick payroll salary band against the €40,000, and Declan Garvagh's public professional footprint.
- Your answer on whether the office days and €40,000 meet your own limits would close R2 and R3.
- Your answer on which tax regime you ran would move R5 to `direct` or surface a real gap.
- A copy of the Payroll Technician certificate would raise R1 to `high`.
- The full contract would close RR2.

Dossier: say so if you'd like this saved as `tuesday-dossier.md` to build on later.

**Questions**

- Q1 (R2, R3) — Do two days a week in the Limerick office and €40,000 both work within what you need? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- Q2 (G1, R5) — Was the hotel group's payroll run under Irish PAYE, PRSI and USC, and did you handle USC and PRSI classes and Revenue filings yourself? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- Q3 (G2, R8) — What did you see of pension changes at the hotel group, such as opt-outs, new starters joining the scheme or contribution reports, and what was your part in them? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.