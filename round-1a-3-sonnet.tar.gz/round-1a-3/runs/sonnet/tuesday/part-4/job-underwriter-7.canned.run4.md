Checking whether Calderbrook Community Health CIC and this role show up on public sources, then I'll write the assessment.
**Aoife, yes, this one is worth applying for.** No gate fails (R1, R2 and R3 are `direct`), though pay (R4) is still open. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3 · unclear: R4 (Pay £31,050–£37,800 plus mileage)
- `must_have`: direct: R5 · unclear: R6 (Clear, timely written records)
- `important`: direct: R8, R11a · adjacent: R7 (Home-based care of housebound adults), R9 (Leg-ulcer care), R10 (Catheter and continence care), R13 (Own small caseload) · unclear: R11b (Care planning), R12 (End-of-life visits)
- `preferred`: absent: R14 (Doppler assessment)

R13 — a credible bridge through your discharge-to-assess home visits, its limit named; R12 and R6 (both `low`) — likely to exist in your history but unconfirmed.

**Opportunity ledger.** The employer exists as described and names a lead for an informal chat (RR2). The open items are whether the posting is live (RR1), the rota (RR3), caseload and supervision terms (RR4), and mileage alongside pool cars (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); unconfirmed: R4 (Pay £31,050–£37,800 plus mileage); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay range meets your floor (R4); (2) the posting is confirmed open (RR1); (3) you can truthfully speak to end-of-life visits and electronic records (R12, R6); (4) you check your own NMC register entry and DVLA record (R1, R2).

Your National Insurance number isn't needed for this and I haven't used it. Please keep it out of applications until an offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page (fetched) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning | `[grounded]` advert |
| Supervision | A small caseload of your own, supported by a senior community nurse; size and sign-off arrangements not stated | `[grounded]` advert |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, previously a district nurse for eleven years, and spoke in 2025 on nurse-led leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` speaker page |
| Scope read | A standard entry-level community role. The "desirable" Doppler line and the named senior support suggest newcomers to community nursing are expected | `[inferred]` from the advert's wording and the lead's public talk topics |
| Market calibration | A 2026 survey (England, n=1,240) puts community Band 5 median pay at £34,300, interquartile range £32,400–£36,600. The advertised £31,050–£37,800 brackets that median. Surveys of this kind are one sample, not this employer's offer. | `[grounded]` survey figures; `[generic]` the comparison |
| Unknowns | Posting live status; rota and weekend or on-call duties; caseload size; Doppler training provision; EPR system | — |
| Contradictions | None found; the careers page could not be read (see Evidence status) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | You state Adult registration, active, revalidation due March 2028. Stated, not checked; the check is yours | `[grounded]` CV | Check your own NMC register entry |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full category B licence. Stated, not checked | `[grounded]` CV | Check your own DVLA record |
| R3 | Role based in Halifax | hard_gate | direct | medium | none | The advert places the role in Halifax and you live there. Whether visits cover all of Calderdale is not stated | `[grounded]` advert and CV | none |
| R4 | Pay £31,050–£37,800 plus mileage | hard_gate | unclear | none | hard_gate | You have not given a pay floor, so I can't say whether the range meets it | `[grounded]` advert; no constraint supplied | Closing question |
| R5 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a ward staff nurse, stated | `[grounded]` CV | none |
| R6 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | The CV doesn't mention record-keeping or any electronic record system. Ward nursing usually involves documentation, which is an inference not a claim | `[grounded]` CV silence; `[generic]` ward practice | Closing question |
| R7 | Care of housebound adults in their own homes | important | adjacent | medium | transferability | You visited patients at home in their first week after discharge for 18 months. Limit: short post-discharge episodes, not long-term housebound patients | `[grounded]` CV | none |
| R8 | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds stated | `[grounded]` CV | none |
| R9 | Leg-ulcer care | important | adjacent | low | transferability | Wound care is stated; leg ulcers and compression therapy are not | `[grounded]` CV | See G4 |
| R10 | Catheter and continence care | important | adjacent | medium | discovery | Catheter care stated; continence care not | `[grounded]` CV | See G3 |
| R11a | Insulin administration | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R11b | Care planning | important | unclear | low | discovery | The CV doesn't mention care planning | `[grounded]` CV silence | See G3 |
| R12 | End-of-life visits | important | unclear | low | discovery | The CV doesn't mention palliative or end-of-life care | `[grounded]` CV silence | Closing question |
| R13 | Hold a small caseload of your own, with senior support | important | adjacent | medium | transferability | You have never held a caseload. Limit: the discharge-to-assess work was visiting, not owning ongoing care. The advert's named senior support lowers the bar | `[grounded]` CV and advert | State this plainly in the application |
| R14 | Doppler assessment (desirable) | preferred | absent | none | capability | You have not done one. The team lead has spoken about Doppler training for newcomers, which suggests training may be offered but doesn't confirm it | `[grounded]` CV; `[inferred]` training likelihood | Ask in the informal chat |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R12, important) | discovery | The CV is silent on palliative care | It is a named duty, and the advert's duty list is what an interviewer is likely to probe | Caring for dying patients on the ward; contributing to anticipatory medication or a care-of-the-dying plan; speaking with families at the end of life | A reflective note, a training certificate, a ward palliative-care link role | `[grounded]` CV silence; `[generic]` that interviews probe the listed duties |
| G2 | Written records and electronic patient records (R6, must_have) | discovery | No record-keeping or system named | It is an essential criterion | Any electronic record system you used on the ward or the D2A team; audit results on your documentation | A system name, an audit result, training records | `[grounded]` CV silence |
| G3 | Continence care and care planning (R10, R11b) | discovery | Catheters are stated; continence and care planning are not | They are named duties, and the answer could lift both rows | Bladder and bowel care plans; writing or updating discharge care plans | A care-plan example, with identifying details removed | `[grounded]` CV silence |
| G4 | Leg-ulcer care (R9) | transferability | Wound care is stated; no leg-ulcer or compression evidence | The team lead's public interest is in leg ulcers | Applying or observing compression on the ward | A competency record, a training record | `[inferred]` adjacency from wound care; `[grounded]` lead's talk topics |
| G5 | Doppler (R14, preferred) | capability | No Doppler experience | It is only desirable. The honest path is to say so and ask about training | None to claim | A Doppler course place, if offered | `[grounded]` CV |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Current vacancies are listed on our careers page" (About page) | The page I tried returned nothing; it was a guessed address, not a link from the site. The post may be listed elsewhere on the site | `[grounded]` fetch result; `[inferred]` reason | Is this post open, and what is the closing date? | unresolved |
| RR2 | Named lead and informal-chat route | positive_signal | — | "For an informal chat about the role, contact Rhiannon Mabbott" | A reachable lead who has publicly discussed training for newcomers | `[grounded]` advert and speaker page | What does support for someone new to community work look like in the first months? | noted |
| RR3 | Working pattern not stated | unknown | — | "caring for housebound adults in their own homes ... end-of-life visits" | Community nursing rotas often include weekends or later visits, though what applies here is unstated | `[generic]` pattern, not a claim about this employer | What are the working hours, weekend rota and any on-call for this post? | unresolved |
| RR4 | Caseload and supervision terms unspecified | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" and "supported" may be defined loosely | `[inferred]` from undefined wording | How many patients, and how is your work reviewed and signed off? | unresolved |
| RR5 | Mileage alongside pool cars | unknown | — | "pool cars are provided ... plus mileage" | Mileage may apply to personal-car use or to other travel | `[inferred]` from the advert's two statements | When is mileage paid if pool cars are provided? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the discharge-to-assess secondment, worded as home visits after discharge (not as a caseload) | See R7, R13 | `[grounded]` CV | pending your approval |
| E2 | Add a records or electronic-system line only once you confirm the facts | See R6 | `[grounded]` R6 row | pending your approval |
| Q1 | Take up the informal chat; ask RR1, RR3, RR4 and RR5 verbatim, and whether Doppler training is offered (R14) | The advert invites it | `[grounded]` advert | pending your approval |
| A1 | In the application, say plainly that you haven't held your own caseload and that you would value the senior-nurse support the advert describes | See R13 | `[grounded]` CV and advert | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse district nursing" and fetched "About Calderbrook Community Health" (calderbrookhealth.example/about); the employer exists as described. A second fetch of calderbrookhealth.example/careers returned no page, so the posting is unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change 2026 £31,050 £37,800", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration row |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the scope read, RR2 and Q1 |

## Closing run

The dossier offer: I can save this as `tuesday-dossier.md` if you want a record to carry forward.

Upgrade menu:
- Your pay floor and any limits on hours → R4 resolves.
- A named record system, audit or training evidence → R6 can move toward `medium`.
- A care-of-the-dying, care-plan or compression-training record → G1, G3 and G4 strengthen.
- The employer's own careers link → RR1 closes.
- A deeper pass on Calderbrook (up to 5 more searches and 2 more fetches) — say the word and it runs.

Questions:

R4 — What is the lowest salary and the least flexible working pattern you'd accept? Everything in R4 and RR3 hangs on it.

G1 — Have you cared for dying patients on the ward or in the discharge team, and what part did you personally play?

G2 — What electronic record system did you use, and has anyone reviewed your documentation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.