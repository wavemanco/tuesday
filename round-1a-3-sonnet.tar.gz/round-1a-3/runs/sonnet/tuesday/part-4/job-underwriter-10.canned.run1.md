I've finished the three searches, and the company looks real. Next I'm fetching their own site to check the posting is live and matches what you were sent.
Short answer: yes, it's worth taking the call, and nothing I found points to a problem. I checked their own About page, a salary survey and Ronan's public profile. I couldn't find the posting itself on their site, which is one thing to close. Details below.

## Decision snapshot

**Yes, worth applying to and taking the call, with three things to check. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two Galway office days), R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R8
- `important`: adjacent: R6 (Research calls with school owners), R7 (Own booking flow end to end), R9 (First and only designer)

R7 and R9: credible bridges, limits named; R4 (`medium`): confirmed, waiting on a portfolio.

**Opportunity ledger.** The employer matches the posting on its own About page (RR1), and the stated pay sits inside the survey range (RR5). The open items are where the role is listed (RR2), who has the final say on design (RR3) and the equity terms (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two Galway office days), R2 (Salary €52,000–€60,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 hold against your own limits; (2) RR2 closes, meaning you find the role listed on Fernquay's own channels; (3) RR3 and RR4 are answered on the call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page fetched |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work closely with Ronan | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, the rest flexible | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Hiring-side background | Ronan is listed as co-founder and CEO, and previously a product lead at a Galway travel-software company for five years. Their travel-booking background and yours overlap | `[grounded]` public profile; `[inferred]` overlap, from your Dublin travel-booking years |
| Scope read | One product surface plus the research behind it, which is coherent for a first design hire | `[inferred]` from the posting's responsibilities |
| Market calibration | For 3–5 years of experience in Ireland, the survey median is €57,000 (interquartile range €51,500–€62,000), so the posted range sits inside it. This is a nationwide pattern, not Galway-specific and not Fernquay's offer | `[generic]` one survey (Tillerby 2026, n=520), search snippet only; `[grounded]` posting for the range |
| Unknowns | Where the role is listed; how many schools use Kelproster; who has the final say on design; equity terms | `[grounded]` nothing in the posting or About page covers these |
| Contradictions | None between the posting and the About page. The About page adds sailing schools and Scotland, which the posting doesn't mention | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | unclear | medium | hard_gate | You said you moved back to Galway last year, so the commute is plausible. You haven't said whether two fixed office days suit you | `[grounded]` your message | Closing question, tagged R1 and R2 |
| R2 | Salary €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the pay. You haven't given a minimum, so there is nothing yet to check it against | `[grounded]` posting; no floor from you | Closing question, tagged R1 and R2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, confirmed in your message, with no document inspected yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" shows use, not strength. A portfolio would show the strength | `[grounded]` your background | Offer a portfolio link |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Not yet inspected | `[grounded]` your background | Offer a sanitized session guide or readout |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Customer usability sessions carry over. Limit: usability testing differs from interviewing business owners about how they run their schools | `[grounded]` your background; `[inferred]` the limit, from the posting's wording | See gap queue G3 |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned the checkout flow. Limit: you haven't said you owned the journey around it | `[grounded]` your background | See gap queue G1 |
| R8 | Work directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R9 | First and only designer, with no design peers (inferred) | important | adjacent | medium | transferability | You've never been the only designer. Limit: no stretch without design review. Squad work and running your own research cadence are the bridge | `[inferred]` from "you would be our first designer" against your statement | See gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole booking journey (R7, important) | transferability | The checkout redesign is the closest match. Nothing yet on what sat before or after it, or who set priorities | It is the role's central responsibility; the bridge is the checkout work, and its limit is that it's one stage | Changes to search, availability or pricing screens; confirmation or cancellation flows; follow-up after launch | The checkout case study, a flow map, before/after screens, a results readout | `[grounded]` your description; `[inferred]` the limit |
| G2 | Working as the only designer (R9, important) | transferability | You've worked with engineers but not without design peers | Bridge: you ran your own monthly research cadence. Limit: no design review to lean on | Calls you made without design sign-off; setting your own process or standards | A short example of a decision you made alone | `[grounded]` your statement; `[inferred]` the limit |
| G3 | Interviewing school owners (R6, important) | transferability | Usability sessions with customers, not discovery interviews with business owners | Bridge: you already run customer sessions. Limit: the audience and the type of research differ | Any session where you asked how customers run their business, not just how they used the screens | A sanitized session guide or readout | `[grounded]` your description; `[inferred]` the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting on its own site | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company is as described in the posting. The About page lists a co-founder named Saoirse Doyle but doesn't state a title | `[grounded]` About page fetched | How many schools use Kelproster today? | noted |
| RR2 | Posting not found on Fernquay's own site | unknown | — | "We are six people in Galway…" (posting) | The one careers address I tried returned no page. The role may be listed elsewhere. I guessed that address, so this is weak evidence either way | `[inferred]` from one failed page | Where is this role listed on your own site? | unresolved |
| RR3 | First designer, decision rights unstated | risk_signal | low | "You would be our first designer: own the booking flow end to end" | Ownership may sit with design or stay with the co-founders. Low because the posting is plainly open about being a first hire | `[inferred]` from the posting's silence on decision rights | Which product calls does the designer make, and which stay with you? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage has no stated basis: vesting, strike price, or share of what. With no outside funding, there is no priced round to value it against | `[grounded]` posting; `[inferred]` the valuation point | Is the equity options or shares, what's the vesting, and 0.5–1% of what fully diluted base? | unresolved |
| RR5 | Stated pay falls inside the survey range | positive_signal | — | "€52,000–€60,000" | A stated range suggests the posting isn't evasive about pay | `[grounded]` posting; `[generic]` survey band | How is pay reviewed after the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat WhatsApp scheduling as routine. Take the call details from the calendar invite, and check it came from an address at the domain their About page uses (fernquay.example) | Scheduling a call by chat for a video call held elsewhere is an ordinary step | `[generic]` common practice at small companies; `[grounded]` About page domain | pending your approval |
| A2 | Lead with the checkout case study they named. Say plainly "I redesigned our checkout flow and ran monthly usability sessions with customers", then say what was yours and the squad's | They named the case study themselves, and each clause traces to your own words | `[grounded]` your message; the invite | pending your approval |
| A3 | Say honestly that you haven't been the only designer. Name the bridge: squad work and your own research cadence | R9 is the real stretch, and it's better raised by you | `[grounded]` your statement | pending your approval |
| A4 | Ask RR2, RR3 and RR4 verbatim on the call | The register doubles as call preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway". Fetched "About Fernquay" (fernquay.example/about), and tried fernquay.example/careers, which returned no page. Moved role reality's organization and contradictions rows, RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "Product Designer salary Ireland startup Galway senior product designer", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report); I read only the snippet. Moved market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe); I read only the snippet. Moved role reality's hiring-side row and A2 |

If you'd like, I can save this as `tuesday-dossier.md` so a later pass can pick it up, and the mock-interview module can help you rehearse for the call.

**Upgrade menu**

- A portfolio link or the checkout case study you sent them: R4 and R7 (`medium` now) can move toward `high`.
- A sanitized usability session guide or readout: R5 and R6.
- Your minimum salary and office-day limits: R1 and R2 settle.
- Where Fernquay lists the role, or their answer on it: RR2 closes.
- Equity terms: RR4 closes.
- A deeper research pass on Fernquay (customers, news, hiring pattern; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

- R1, R2: Is there a minimum salary or a limit on fixed office days that would rule this out, or are €52,000–€60,000 and two Galway office days both workable?
- G1: In the checkout redesign, which parts of the wider booking journey did you personally own, and who set the priorities?
- G2: Was there ever a stretch where you made design decisions without anyone reviewing or directing them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.