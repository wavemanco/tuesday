I'm reading the rest of the underwriting playbook's reference files so my answer follows its required format. Then I'll check the employer and give you a straight answer.
**Yes, that's normal. Asking for bank details, your PPS number and a passport scan after a written offer that names the role and pay is routine onboarding. Status: `conditional_go`, for reasons unrelated to that request.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Two days a week in the Limerick office), R2 (Salary €38,000–€42,000, offer €40,000), R3 (Right-to-work check)
- `must_have` — direct: R4, R6, R7, R8 · unclear: R5 (Working knowledge of Irish PAYE, PRSI and USC)
- `important` — direct: R9 · adjacent: R10 (Run monthly payroll for 240 staff) · absent: R11 (Process pension changes) · unclear: R12 (Answer staff payroll queries)

R11 — a real gap, named; R5 — unconfirmed that your payroll experience was Irish; R10 — a scale step from 90 staff to 240.

**Opportunity ledger.** The pay sits inside the advertised band and the offer matches the ad (RR2). The employer is not confirmed from here (RR1), and the offer is silent on contract terms (RR3) and on who covers pension changes while you learn them (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Two days a week in the Limerick office), R2 (Salary €38,000–€42,000, offer €40,000), R3 (Right-to-work check); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Marrowgate's own website confirms the role and the email domain (RR1); (2) the written contract terms check out (RR3); (3) the pension-change gap is stated honestly, not glossed (R11, RR4, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick. Not yet confirmed against its own website, because my searches were refused. | `[grounded]` ad and offer, as you pasted them |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff queries | `[grounded]` ad |
| Offer terms | Permanent, €40,000, hybrid with two days in the Limerick office, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Contradictions | None between the ad and the offer: title, hybrid pattern, location and pay all agree, and €40,000 is inside the €38,000–€42,000 band | `[grounded]` ad against offer |
| Process | Two in-person interviews at their office, then a written offer from an address at marrowgatehousing.ie. I have not checked that domain against the company's website. | `[grounded]` your account |
| Unknowns | Contract and probation terms, pension scheme, payroll software, team size, start date | `[grounded]` the offer is silent on each |
| Market calibration | Not run, because the search was refused. I give no salary band from memory. | `[grounded]` research refused |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You gave no constraint on commute or location. Whether this works for you is unknown, not failed. | `[grounded]` ad, offer; no constraint stated | Your answer to the closing question tagged R1, R2 |
| R2 | Salary €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | The offer is inside the band. Your own floor was not given, so the fit is unconfirmed. | `[grounded]` ad, offer | Same closing question |
| R3 | Right-to-work check | hard_gate | unclear | none | hard_gate | The offer states the check; nothing you told me settles it. It is a term, not experience. | `[grounded]` offer email | none unless a problem exists; your passport is for their check |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff. Self-reported, with no inspectable artifact at intake. | `[grounded]` your background, prose | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say the hotel payroll was Irish or which tax systems it used. | `[grounded]` background silent on jurisdiction | Closing question G2 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, self-reported. | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. No certificate seen, so it stays `medium`. | `[grounded]` your background | A copy of the certificate would raise it to `high` |
| R8 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | You describe doing this monthly. | `[grounded]` your background | none |
| R9 | Process starters and leavers | important | direct | medium | none | You state starters and leavers at the hotel group. | `[grounded]` your background | none |
| R10 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff. The process carries over; you have not run this scale or a monthly cycle as owner. | `[grounded]` your background; `[inferred]` that the process transfers | Name the scale step honestly in conversation |
| R11 | Process pension changes | important | absent | none | capability | You said your manager handled these and you never did. The gap is stated, not a hole to hide. | `[grounded]` your statement | Closure path in G1 |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention staff queries. | `[grounded]` background silent | Not asked; low impact |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R11, important) | capability | You have not processed them; your manager did. | An explicit duty in the ad. Naming it up front is better than being found out on day 30. | Checking a pension contribution change on a payslip run; handling an opt-out or a rate change you reviewed | A short written handover plan from the employer | `[grounded]` your statement; `[generic]` that this is learnable on the job with a handover |
| G2 | Irish payroll tax knowledge (R5, must_have) | discovery | The hotel group's payroll jurisdiction and your hands-on tax work are not stated. | A must-have the employer will assume you meet. It is the one thing worth being sure of before accepting. | Weekly or fortnightly PAYE, PRSI and USC runs; Revenue payroll submissions; year-end returns | A payslip layout or anonymised payroll summary | `[grounded]` background silent; `[inferred]` from the hotel group being likely Irish, which you have not confirmed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from here | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The search that would have checked the company's own site was refused. The reasons are side by side: no check was run, the company may be small, or the pasted details may not match its site. Your two in-person interviews already place the employer for you. | `[generic]` pattern; `[grounded]` search refused | Can you confirm the role and my start terms by email from your company address, and point me to the portal address on your website? | unresolved |
| RR2 | Offer matches the ad on role, location, hybrid pattern and pay | positive_signal | — | "permanent post of Payroll Administrator at €40,000 … two days a week in our Limerick office" | The offer is consistent with the posting as you pasted it. | `[grounded]` ad against offer | Who covers the first month if pension changes arrive before I'm trained on them? | noted |
| RR3 | Contract terms not in the offer | unknown | — | "starting on a date we agree once your notice period ends" | Probation, hours, leave and pension scheme are not stated in the email. | `[inferred]` from the email's silence | Can you send the written contract and the pension scheme details before I accept? | unresolved |
| RR4 | Pension-change cover during onboarding | unknown | — | "process starters, leavers and pension changes" | The duty sits in your role but you have no hands-on experience; handover arrangements are unstated. | `[inferred]` from the ad's list against your stated gap | What handover or training is planned for pension changes in my first three months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter bank, PPS and passport details only in the employer's own onboarding portal, at the address Marrowgate's own website gives, not a link you can't place. Don't send scans by email. | The "never hand those over" instinct is right before an offer; this request comes after one that names the role and pay. | `[generic]` standard onboarding practice; `[grounded]` the offer says a portal link follows acceptance | suggested |
| A2 | Bring the original passport on day one, as they ask. | The offer states it. | `[grounded]` offer email | suggested |
| A3 | Before accepting, ask Declan the RR3 question and ask for the written contract. | Closes the open terms without delaying acceptance past five working days. | `[grounded]` RR3 | pending your approval |
| A4 | If pension changes come up, you could say: "My manager handled pension changes in my current role, so I haven't run them myself; I'd want to learn your scheme's process in my first weeks." | It states the gap as it is and adds nothing you haven't evidenced. | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported prose, so it stays at `medium` at most until you confirm or show an artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent: "Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers Payroll Administrator". Both were refused. That is why RR1 stays unresolved and R5 and R12 are unconfirmed against the posting. |
| 2. Role-family sweep | unavailable | One search was sent: "payroll administrator salary Ireland Limerick 2026". It was refused. It would have given a market band for the salary comparison in role reality. |
| 3. Hiring manager's public footprint | unavailable | One search was sent: "Declan Garvagh Finance Manager Marrowgate Housing". It was refused. It would have informed how to frame your pension-change gap to him. |

I can save this analysis as `tuesday-dossier.md` if you want it for later.

Upgrade menu:
- Permission to run the three searches → closes RR1 (employer confirmed) and adds a market band for €40,000.
- A copy of your Payroll Technician certificate → R7 to `high`.
- An anonymised payslip layout from the hotel group → R5 and R12 firm up.
- A deeper pass on Marrowgate (leadership changes, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

R1, R2 — Is there a commute, salary floor or notice-period limit that would stop you accepting €40,000 with two office days in Limerick?

G2 — Was the hotel group's payroll run under Irish PAYE, PRSI and USC, and which parts of that did you run yourself?

G1 — Have you ever processed or checked a pension contribution change, even once, and what was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.