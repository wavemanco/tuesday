Running the company and salary searches now, then I'll write the assessment.
**Worth pursuing, and the company checks out as real as far as its own pages show. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5 · adjacent: R6 (Own the booking flow end to end)
- `important` — direct: R7 · adjacent: R8 (First designer, no design peers)

R2 — waiting on your pay floor; R6 — the checkout redesign is a credible bridge, its limit named; R8 — adjacent, no solo-designer history; R4 (`medium`) — confirmed, waiting on an artifact.

**Opportunity ledger.** The employer is attributable and the posting matches its own pages (RR1), and the stated pay sits inside the survey band (RR3). Equity terms are unstated (RR2), and no design peer or reviewer is named (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the €52,000 low end meets your own minimum, which you haven't told me (R2); (2) the equity instrument, vesting and share base come in writing before you weigh it (RR2); (3) you are comfortable being the sole designer and hear how design gets reviewed (R8, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` company About page, fetched |
| Mandate | First design hire: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting and careers page agree |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Contact channel | The careers page says to apply by email with one real project. Ronan, who messaged you, is named as co-founder on the company's own About page and on a professional profile (co-founder and CEO, formerly a product lead at a Galway travel-software company). Scheduling a video interview by WhatsApp with an emailed invite is a routine step | `[grounded]` About page, profile snippet; `[generic]` scheduling by chat for an interview held on video is routine |
| Scope read | Normally scoped for a first designer at a six-person company: one product area, direct access to a co-founder | `[inferred]` from the posting's scope against its team size |
| Market calibration | Tillerby's 2026 Ireland survey (n=520) gives product designers with 3–5 years a median base of €57,000, interquartile range €51,500–€62,000. The posting's range sits inside it. The survey is national, not Galway- or startup-specific, and is not this employer's offer | `[generic]` survey band; `[grounded]` the posting's figure |
| Unknowns | Equity instrument and terms; who reviews design work; whether the Saoirse Doyle named on the About page holds the CTO title the message gives (the page, as fetched, doesn't state a title) | `[grounded]` pages read |
| Contradictions | None between the posting and the careers or About pages | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year; no stated constraint conflicts. Confidence is `medium` because it rests on your own account | `[grounded]` posting and your message | none |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the range, but you haven't given a floor, so whether it meets your terms isn't settled. Confidence is `none` because there is no statement of yours to grade | `[grounded]` posting figure; no candidate constraint supplied | Tell me your pay floor (G1) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. A years requirement is not a gate. `medium` because it's your account, with no inspectable artifact yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" across four years. Confirmed and plausible, but nothing inspected | `[grounded]` your message | Share the checkout case study or a portfolio link, which would raise this to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The role also names research calls with school owners, which are interviews with owners; usability sessions are a related method. That distinction is carried here, not widened | `[grounded]` your message; `[inferred]` that owner interviews differ from usability testing | Ask for an example of a session you planned and ran yourself |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned your company's checkout flow. Checkout is one stage of a booking flow, so what carries over is the redesign work and its limit is the stages around it | `[grounded]` your message; `[inferred]` that checkout is one stage of a booking flow | G2 |
| R7 | Working directly with engineers | important | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your message | none |
| R8 | Being the first designer, with no design peers | important | adjacent | low | transferability | You have not been the only designer anywhere. Adjacent: you owned a flow redesign and ran your own research cadence. Limit: you have not set process or standards without other designers around. Roles like this usually ask for exactly that | `[grounded]` your statement; `[generic]` first-designer roles usually include setting process | Use RR4's question in the call |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | The range is stated; your minimum isn't | The one gate not yet checked; the decision rests on it | Your minimum base, and whether equity counts toward it for you | A figure from you | `[grounded]` no floor supplied |
| G2 | Breadth of the booking flow (R6, must_have) | transferability | A checkout redesign, with no detail on which parts you owned or what surrounded it | R6 is a `must_have` row at `adjacent`; wider ownership narrows the likeliest objection | Owning availability or search screens, pricing and add-ons, confirmation emails, or changes after booking, or the research behind the checkout work | A case study, before-and-after screens, or a metric from the checkout work | `[inferred]` the objection would come from the "end to end" wording; `[grounded]` your account names checkout only |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer attributable; posting matches its own pages | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company exists as described and the role is live on its own careers page | `[grounded]` About and careers pages fetched | Could I speak to a school owner who uses Kelproster before I decide? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The range may come with no stated instrument, vesting or share base. With a customer-funded company, its value would depend on profit or a sale | `[grounded]` posting gives a range and no terms; `[generic]` small-company equity usually carries vesting | Is the equity options or shares, what is the vesting schedule, and what share count does the percentage apply to? | unresolved |
| RR3 | Pay stated and within the band | positive_signal | — | "€52,000–€60,000" | No seniority-pay mismatch for a designer with 3–5 years (see R2) | `[grounded]` posting figure; `[generic]` survey band | Where in the range would a designer with my four years sit? | noted |
| RR4 | No design peer or reviewer named | unknown | — | "You would be our first designer" | Craft feedback and design standards may rest with you alone | `[inferred]` from "first designer" against a six-person team | Who reviews design work today, and how are decisions made when design and engineering disagree? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite came from an address at fernquay.example and that the video link opens on the platform it names. If you're unsure, ask jobs@fernquay.example, the address on the careers page, to confirm the time. This is routine care, not a sign of a problem | You can't tell from here whether the WhatsApp number is Ronan's | `[grounded]` careers page address | pending your approval |
| A2 | Bring one real project, the checkout case study they've already praised, and say plainly what was yours and what the team's | The posting says they'd rather see one messy real project; see R4, R6 | `[grounded]` posting | pending your approval |
| A3 | Lead with the checkout redesign and the monthly usability sessions, and state plainly that you haven't been the only designer before, and that checkout was one stage of a booking flow | Each point traces to your own sentences; see R5, R6, R8 | `[grounded]` your message | pending your approval |
| A4 | Ask RR1, RR2 and RR4's questions verbatim in the call | The register doubles as call preparation | `[grounded]` register | pending your approval |

For the 45-minute call itself, the interview-prep side of Tuesday can run a drill if you want one.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality (organization, contradictions) and RR1; the careers-page fetch also checked your pasted posting against the live page |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience startup Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved the contact-channel row and the role he holds. It confirms he is named as co-founder; it does not show the WhatsApp number is his |

I'd also offer, once, a deeper pass on Fernquay (customer and employee reports, recent news; up to 5 more searches and 2 more fetches). It could add to the register but wouldn't change the status on current evidence.

If it would help, I can save this as `tuesday-dossier.md` for later use. No pressure.

**Upgrade menu**

- Your pay floor and any other must-haves (notice period, hours) → R2 and the hard-gates line settle.
- The checkout case study or a portfolio link → R4 can reach `high`, and R6's scope can be read directly.
- The equity terms in writing → RR2 closes.
- A deeper research pass on Fernquay (as above) → say the word and it runs.

**Questions**

G1 — What is the lowest base salary you would accept, and is there anything else (days in the office, notice, hours) that is a firm no for you?
G2 — In the checkout redesign, which screens or steps did you personally own, and what did you do around them (research, pricing, confirmation, changes after booking)?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.