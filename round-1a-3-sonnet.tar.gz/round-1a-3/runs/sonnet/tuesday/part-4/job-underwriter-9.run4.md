Web searches were refused, so nothing below is checked against outside sources. It rests on what you pasted. These requests are routine after a real written offer, and the role looks worth accepting on conditions.

## Decision snapshot

**Yes, a written offer followed by bank details, PPS number and a passport check is normal, and it doesn't make the job look wrong. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Hybrid, two office days), R11 (Salary €38,000–€42,000)
- `must_have` — direct: R1, R3, R4 · adjacent: R5 (Monthly payroll for 240 staff) · unclear: R2 (Irish PAYE, PRSI and USC)
- `important` — direct: R6, R8 · unclear: R9 (Staff payroll queries) · absent: R7 (Pension changes)

R7 — a confirmed gap with a closure path; R5 — a credible bridge, its limit named; R2 (`low`) — unconfirmed, one question away.

**Opportunity ledger.** The offer is concrete: a named role, a salary within the posted band, a reporting line and a request for acceptance (RR3). The employer could not be checked from here (RR1). Support for pension changes is unknown (RR2).

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two office days), R11 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm the employer on its own website before you enter any details (RR1); (2) your pay and office-day limits are met (R10, R11); (3) you find out how pension changes are handled in your first months (R7, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer email |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; payroll-to-ledger reconciliation; staff queries | `[grounded]` ad |
| Terms | Permanent, €40,000, hybrid with two office days, reporting to Declan Garvagh, Finance Manager; accept within five working days | `[grounded]` offer email |
| Process so far | Two in-person interviews at their office, then an offer from people@marrowgatehousing.ie | `[grounded]` your account |
| Onboarding asks | Bank details, PPS number and a passport scan through a portal after you accept; original passport on day one | `[grounded]` offer email |
| Are the onboarding asks normal? | Yes. Employers routinely collect these after a written offer, to pay you, register you with Revenue and check your right to work. Your "never hand them over" rule is right before an offer, or for anyone who isn't your verified employer | `[generic]` pattern for employers after an offer |
| Market calibration | Not checked, because search was unavailable. The posted €38,000–€42,000 and the offered €40,000 are your only figures | `[grounded]` ad and offer; no band researched |
| Unknowns | Payroll software and team size; who handles pension changes today; contract terms beyond the email | — |
| Contradictions | None between the ad and the offer | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | You state 3 years of fortnightly payroll; no document inspected | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say the hotel payroll was run under Irish statutory rules, and the certificate's content is unstated | `[grounded]` silence on jurisdiction | ask G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP stated; no work sample inspected | `[grounded]` your background | none |
| R4 | Payroll qualification, or working towards one | must_have | direct | medium | none | Payroll Technician certificate (2024) stated; I haven't seen it, and I'm assuming it counts as a payroll qualification | `[grounded]` your background; `[inferred]` that it meets the ad's wording | none |
| R5 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Your payroll is fortnightly for 90 staff, so the cycle and headcount differ. The limit is scale and a monthly cycle you haven't run | `[grounded]` your background | none; name the limit if asked |
| R6 | Process starters and leavers | important | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R7 | Process pension changes | important | absent | none | capability | You haven't done them; your manager handled them | `[grounded]` your statement | ask G2; closure path in plan |
| R8 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Nothing stated either way | `[grounded]` silence | optional; fold into the interview |
| R10 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The role's terms are clear. You haven't told me your limits, so I can't tell whether they are met | `[grounded]` offer; no candidate constraint given | ask G3 |
| R11 | Salary €38,000–€42,000, offered €40,000 | hard_gate | unclear | none | hard_gate | The offer is inside the posted band. Your pay floor isn't given | `[grounded]` ad and offer; no candidate constraint given | ask G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory knowledge (R2, must_have) | discovery | A three-year payroll history, with the jurisdiction and statutory content not stated | A must-have; confirming it settles whether R2 is `direct` | Running Revenue returns for PAYE, PRSI classes or USC; the content of the Payroll Technician course | Certificate or syllabus; a redacted payslip run | `[grounded]` silence; `[generic]` that a payroll hire is probed on this |
| G2 | Pension changes (R7, important) | capability | A confirmed absence. Your manager handled them | It's in the ad's duties, so expect it to come up | Updating contribution rates, or processing opt-ins and opt-outs, even once | A short pension-administration course, or the employer's scheme guide once you start | `[grounded]` your statement; `[generic]` that new hires are usually trained on scheme specifics |
| G3 | Pay and office-day limits (R10, R11, hard_gate) | hard_gate | The terms are stated and your limits are unknown | A gate; it decides whether to accept at all | Your minimum salary; the office days and commute you can sustain | None needed | `[grounded]` no constraint given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | Search was unavailable, so this is an unchecked item and not a finding. The entity may be a normal employer I couldn't look up. This puts none of the onboarding steps in doubt | `[generic]` pattern when an employer can't be checked, not a claim about this one | Can you point me to the role on your careers site, and confirm that Declan Garvagh is the Finance Manager? | unresolved |
| RR2 | Pension changes unsupported | unknown | — | "process starters, leavers and pension changes" | You may be expected to run them from week one with no handover | `[inferred]` from the ad listing them against your stated gap (R7) | Who handles pension changes today, and what handover or training would I get? | unresolved |
| RR3 | Offer is concrete and in band | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | The role, pay and line manager are specific and match the posting | `[grounded]` offer email | Is there a written contract and a probation period to review before I accept? | noted |

Bank, PPS and passport requests after this offer take no register entry, because they're routine at this stage.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before accepting, check the employer yourself. Find Marrowgate's site and the People team's contact details independently, then ask them to confirm the offer and who sent it | RR1; this is your own safeguard | `[grounded]` RR1 | pending your approval |
| A2 | Enter the bank, PPS and passport details only in their own onboarding portal. Reach it from the address on their website, not from a link in an email you didn't expect | The portal is where this data belongs; the address is what you check | `[generic]` standard onboarding practice | pending your approval |
| A3 | Before or with your acceptance, ask the RR2 question and ask for the contract in writing | R7, RR3 | `[grounded]` R7, RR2 | pending your approval |
| A4 | If you accept, plan a short pension-administration course for your first months | R7 closure path | `[inferred]` from the R7 gap | pending your approval |
| A5 | Note the five-working-day deadline when you decide, and ask for more time if A1 isn't done | The offer's own terms | `[grounded]` offer email | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent ("Marrowgate Housing Limerick housing association", "Marrowgate Housing Payroll Administrator Limerick careers") and both were refused. It would have moved role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | One search was sent ("payroll administrator salary Ireland 2026 payroll administrator Limerick") and refused. It would have given the market calibration line |
| 3. Hiring manager's public footprint | unavailable | A name was given (Declan Garvagh, Finance Manager), but search permission was refused, so none was sent. It would have moved the scope read and the application plan's positioning |

## Dossier offer

If you'd like a saved `tuesday-dossier.md` of this assessment, say so.

## Upgrade menu

- Search permission, so targets 1–3 can run: RR1 would close or stay open on evidence, and role reality would gain a salary band and the manager's background.
- Your certificate or syllabus: R2 and R4 could move to `high`.
- A redacted payslip run or reconciliation sample: R1, R5 and R8 could move to `high`.
- The employer's pension-scheme guide: RR2 and R7 would sharpen.

## Questions

G1 (R2) — Was your hotel-group payroll run under Irish PAYE, PRSI and USC, and did your Payroll Technician course cover them? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 (R7) — Have you ever processed anything pension-related yourself, even a single opt-in, opt-out or rate change? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 (R10, R11) — Does €40,000 meet your minimum, and are two office days a week in Limerick workable for you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.