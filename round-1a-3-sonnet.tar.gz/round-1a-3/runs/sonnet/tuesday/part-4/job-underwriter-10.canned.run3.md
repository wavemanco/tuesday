Running the first research searches on Fernquay, then the salary check and Ronan Kehoe's public footprint.
## Decision snapshot

**Yes, it's worth applying to, and the employer matches its own pages (RR4). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus 0.5–1% equity)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R8 (Own the booking flow end to end)
- `important` — adjacent: R6 (Run research calls with school owners) · unclear: R9 (First designer, no design team)

R8 — a credible bridge, its limit named; R6 (`low`) — the audience of your sessions is unconfirmed; R9 (`low`) — only your own statement so far.

**Opportunity ledger.** The employer and posting agree with the company's own pages, and pay and process are stated openly (RR4). The open items are the equity terms (RR1), a one-designer remit (RR2) and the company's revenue footing (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus 0.5–1% equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) pay and equity terms meet your floor (R2, RR1); (2) the one-designer remit comes with concrete support (R9, RR2); (3) the checkout work is framed as adjacent to end-to-end ownership, never as it (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` "About Fernquay" page, fetched |
| Mandate | First design hire: booking flow, research calls with school owners, shipping with two engineers | `[grounded]` posting and careers page |
| Working pattern and pay | Hybrid, two Galway days a week. €52,000–€60,000 plus equity; the 0.5–1% figure appears in your posting text, and the careers page says only "plus equity" | `[grounded]` posting and careers page, fetched |
| Scope read | One person covering design, research and delivery is a wide remit, but it hangs together for a six-person product company | `[inferred]` from the posting's bundle of duties against the stated team size |
| Market calibration | Survey of 520 Irish product designers with 3–5 years: median base €57,000, interquartile range €51,500–€62,000. This is a survey band, not Fernquay's offer, and I read only the search snippet | `[generic]` Tillerby 2026 Ireland Design Salary Report |
| Ronan Kehoe | Co-founder and CEO of Fernquay. Previously product lead for five years at a Galway travel-software company | `[grounded]` search-result snippet of his public profile, page not fetched |
| Unknowns | Equity terms, revenue and runway, who gives design feedback, which two office days | `[grounded]` absent from the posting and pages read |
| Contradictions | None on pay, hybrid pattern or "first design hire" between the posting and the careers page. Saoirse Doyle is named as co-founder, and the pages I read don't state "CTO" | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at our Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year, so the location is met. It is self-report, and which two days isn't stated | `[grounded]` posting and your message | Confirm the two days on the call |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so fit can't be settled. The posting's band sits inside the survey's interquartile range | `[grounded]` posting; `[generic]` survey band | Q: your floor (G1) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, stated and specific, with no document yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed. The artifact that would raise it is a file or case study, and they have already seen the checkout case study | `[grounded]` your background and the WhatsApp message | Offer the case study or a Figma file link |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers, which is running research. The method and audience are unstated | `[grounded]` your background | none |
| R6 | Run research calls with school owners | important | adjacent | low | transferability | Usability sessions with customers are credible adjacent work. The limit is that nothing says they were business owners, or that the sessions were discovery calls and not usability tests. I took the lower band | `[grounded]` your sessions; `[inferred]` that school owners are business operators | Q: who the customers were (G3) |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your background | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, which is part of a booking flow. The limit is that nothing says you owned the stages before and after it | `[grounded]` your checkout redesign; `[inferred]` that checkout is one stage of several | Bridge case in G4 |
| R9 | First designer, no design team to lean on | important | unclear | low | discovery | An inferred requirement from "our first designer". You have never been the only designer, and I don't know whether you've worked without a design lead | `[inferred]` from the posting; `[grounded]` your statement | Q: sole-ownership moments (G2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | Posted band and equity range, but no floor from you | Decides whether the role is acceptable at all, and RR1 can't be judged without it | Your minimum base, and what equity would need to look like to matter | Your own figures | `[grounded]` no floor stated; `[generic]` equity value depends on terms |
| G2 | Working without a design lead (R9, important) | discovery | You've been in a squad, but "never the only designer" says nothing about solo decisions | Their first-designer framing makes this the likeliest probe | Making a design call with no design reviewer; setting up a component library or shared styles; choosing what to research with nobody assigning it | A decision record, a Figma library you started, a research plan | `[inferred]` that this is the likeliest probe |
| G3 | Research with business owners (R6, important) | transferability | Monthly usability sessions with customers, audience unconfirmed | Their research is calls with school owners | Sessions with business customers or partners; discovery interviews, not only usability tests | A research plan, a session guide, a findings summary | `[grounded]` the CV-level claim; `[inferred]` the posting's research is owner-facing |
| G4 | End-to-end booking flow (R8, must_have) | transferability | Checkout redesign is evidence of adjacent work. The limit is that nothing says you owned stages around it. The strengthener is the checkout case study they already liked | The posting says end to end | Work on search or availability, confirmation emails, or changes and cancellations | The checkout case study, plus any before-and-after flow map | `[grounded]` your checkout redesign; `[generic]` that booking flows span several stages |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unspecified | unknown | — | "0.5–1% equity" | The percentage may be hard to value without vesting, strike price or the share count | `[grounded]` posting gives a range only; `[generic]` early-company equity value depends on those terms | What are the vesting schedule, cliff and strike price, and what share count does 0.5–1% refer to? | unresolved |
| RR2 | One designer carries design, research and delivery | risk_signal | low | "You would be our first designer: own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | There may be no design peer for feedback or growth. Severity is low because the posting is open about it | `[inferred]` from the posting's scope against its silence on design support | Who gives design feedback today, and what should the first six months deliver? | unresolved |
| RR3 | Revenue footing not stated | unknown | — | "funded by its customers" | Stability depends on revenue, and none is published | `[grounded]` about page; `[generic]` customer-funded firms vary widely | How many schools pay today, and what runway does current revenue give you? | unresolved |
| RR4 | Pay and process stated openly | positive_signal | — | "€52,000–€60,000" and "we would rather see one messy real project than a polished deck" | The posting matches the careers page, and the interview asks for real work, not a polished deck | `[grounded]` posting and careers page, fetched | Which parts of the booking flow have changed most in the last year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the call with the checkout redesign as "checkout flow", then say plainly that you haven't owned the stages around it | They said they loved the case study; see R8 and G4 | `[grounded]` the WhatsApp message and your background | pending your approval |
| A2 | Put RR1, RR2 and RR3's questions to Ronan and Saoirse verbatim | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | Prepare one real project, rough edges included, as the posting asks | See RR4 and R4 | `[grounded]` posting | pending your approval |
| A4 | Scheduling by WhatsApp is normal for a small team. For your own comfort, check the emailed invite came from a Fernquay address, such as the jobs@fernquay.example contact on the careers page | The request is only a call, so none of this is a concern | `[generic]` for small teams; `[grounded]` careers page address | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers Product Designer Galway". Fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). It confirmed the company exists as described and the posting is live, so no failed-attribution entry. It moved role reality's organization and contradictions rows |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup 3-5 years experience 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), snippet only. It moved the market calibration row and R2's reasoning |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. It moved role reality's people row and A1 |

If you want a `tuesday-dossier.md` of this assessment, say so and I'll write it.

## Upgrade menu

- A link to the checkout case study or a Figma file → R4 toward `high`, and G4's bridge firms up.
- Your pay floor → R2 and RR1 resolve, and the hard-gates line changes.
- Answers to G2 and G3 → R9 and R6 move.
- A deeper pass on Fernquay (customers, funding and press; up to 5 more searches and 2 more fetches) → RR3 firms up. Say the word and it runs.
- Preparing for the call with Ronan and Saoirse is a separate job, interview prep, and I can do it if you ask.

G1 — What's the lowest base salary you'd accept, and how much would equity need to look like to change that?

G2 — Has there been a time you made a design decision with no design lead to review it, such as choosing what to research, starting a component library, or settling a disagreement with engineers?

G3 — Were the customers in your monthly sessions business owners or consumers, and were the sessions usability tests or open conversations?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.