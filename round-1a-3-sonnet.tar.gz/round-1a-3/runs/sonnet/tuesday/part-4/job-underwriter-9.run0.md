I'm reading the last of the underwriting references. After that I'll check whether Marrowgate Housing exists, then write up the assessment.
**Yes, this is normal. Giving your bank details, PPS number and a passport scan after a written offer is routine onboarding, and nothing in this offer sets it apart. The role is `conditional_go`, on R4 (Irish PAYE, PRSI, USC), R11 (pension changes) and your own terms for R1 and R2.**

I couldn't check Marrowgate Housing against public sources. The web searches were refused, so everything below comes from what you pasted.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days a week in Limerick), R2 (Salary €38,000–€42,000)
- `must_have` — direct: R3, R5, R6 · unclear: R4 (Working knowledge of Irish PAYE, PRSI and USC)
- `important` — direct: R8, R9 · adjacent: R7 (Monthly payroll for 240 staff) · unclear: R10 (Answer staff payroll queries) · absent: R11 (Pension changes)

R4 — your background doesn't say whose rules the hotel payroll ran on; R11 — never done, your manager handled them.

**Opportunity ledger.** The offer is specific about role, pay and reporting line, and it follows two in-person interviews (RR1). The onboarding requests are the routine kind (RR2). The employer is not yet checked against public sources (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Limerick), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 meet your own terms, which you haven't given me; (2) R4 is confirmed on your side, so you know you can do it to Irish rules; (3) you agree how you'll be trained on R11 before you start.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` JD and offer email |
| Offer | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid two days a week in Limerick; reply within five working days | `[grounded]` offer email |
| Pay against advertised band | €40,000 sits inside the posted €38,000–€42,000 | `[grounded]` JD and offer email |
| Onboarding steps | Bank details, PPS number and passport scan go in an onboarding portal after you accept; original passport on day one | `[grounded]` offer email; `[generic]` that employers commonly collect these for salary payment, Revenue registration and right-to-work checks |
| Scope read | The role is larger than your current one: 240 staff against 90, and monthly cycles against fortnightly | `[inferred]` from the JD and your background |
| Market calibration | Not run, because no search ran | none |
| Unknowns | Whether the employer's public footprint matches the posting; whether the portal link will be on the employer's own site; who handles pension changes day to day | none |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Limerick office | hard_gate | unclear | none | hard_gate | You haven't said whether this meets your constraints; confidence grades your statement of a constraint, and none was given | `[grounded]` JD and offer; constraints not given | Question G-R1 below |
| R2 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | Your floor isn't stated, so I can't say if €40,000 meets it | `[grounded]` offer; floor not given | Question G-R1 below |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated by you; medium is the intake ceiling for unprobed prose | `[grounded]` your stated background | Share a payslip run summary or reference if asked |
| R4 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You didn't say the hotel payroll ran under Irish rules, though the 2024 certificate may cover them | `[grounded]` your background is silent on jurisdiction | Question G-R4 below |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated by you | `[grounded]` your stated background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; the certificate itself wasn't inspected | `[grounded]` your stated background | Keep the certificate to hand |
| R7 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | Carries over: full payroll runs. Limit: 90 staff, fortnightly cycle, not 240 monthly | `[grounded]` your background; `[inferred]` that scale is the stretch | Ask about the software and team during onboarding |
| R8 | Process starters and leavers | important | direct | medium | none | Stated by you | `[grounded]` your stated background | none |
| R9 | Reconcile payroll to general ledger each month | important | direct | medium | none | Monthly payroll-to-ledger reconciliation, stated by you | `[grounded]` your stated background | none |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention handling staff queries | `[grounded]` your background is silent | none; low stakes at this priority |
| R11 | Process pension changes | important | absent | none | capability | You told me you haven't done these; your manager handled them | `[grounded]` your own statement | Closure path: ask what pension scheme they use and for training or a handover |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory rules (R4, must_have) | discovery | The certificate and hotel role don't say they were Irish | A must-have I can't confirm either way | Running Irish PAYE and PRSI through payroll software; USC bands in your certificate coursework; Revenue filings you prepared or reviewed | Certificate syllabus, a redacted payslip | `[grounded]` background silent on jurisdiction |
| G2 | Pension changes (R11, important) | capability | You said your manager handled them | It's named in the JD; you'd be learning on the job | Watching your manager process one; preparing pension contribution schedules; deductions you applied | A short description of any involvement | `[grounded]` your own statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer is specific and follows in-person interviews | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The role and terms are concrete | `[grounded]` offer email and your two interviews | Who handles pension changes today? | noted |
| RR2 | Bank, PPS number and passport requested after a written offer | positive_signal | — | "Once you accept, we will send you a link to our onboarding portal" | Routine onboarding for a named role at a stated salary | `[generic]` common practice; `[grounded]` it follows a written offer naming role and pay | Which portal address do you use, and is it listed on your own website? | noted |
| RR3 | Employer not yet checked against public sources | unknown | — | "Marrowgate Housing, a housing association in Limerick" | No search ran, so nothing is confirmed or contradicted | `[grounded]` the searches were refused | Can you confirm the portal address you'll be sending is the one on your own website? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the portal from the employer's own website, or confirm the address with the People Team by a number or email you find on that site; enter your details only there | see RR2, RR3 | `[generic]` standard precaution for any onboarding link | proposed |
| A2 | Before accepting, confirm in writing hybrid terms, start date and notice period | see R1, R2 | `[grounded]` offer email | proposed |
| A3 | Ask Declan Garvagh how pension changes are handled and whether handover or training is included | see R11, G2 | `[grounded]` R11 row | proposed |
| A4 | Reply within the five working days, or ask for an extension if you need more time | five working days is the offer's stated limit | `[grounded]` offer email | proposed |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; the call was refused. It would have fed role reality and RR3 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator Ireland salary housing association Limerick"; the call was refused. It would have fed market calibration |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh was named, but no search was sent because search was refused; it would have fed the scope read |

I can build a `tuesday-dossier.md` from this assessment if you want to keep it.

## Upgrade menu

- Permission to search the web → Marrowgate's own site and careers page (RR3 closes), a market band for the salary, and a read of Declan Garvagh's public professional footprint.
- Your hybrid and salary constraints → R1 and R2 move from `unclear` to met or failed.
- Whether the hotel payroll ran under Irish rules → R4 moves.
- Any involvement in pension changes → R11 may move from `absent`.

## Questions

1. **G-R1** — Do the two office days a week in Limerick and €40,000 meet what you need, or is there a limit I should know about?
2. **G-R4** — Did your hotel group payroll run under Irish PAYE, PRSI and USC, and did your certificate cover them?
3. **G2** — Have you had any hands-on part in pension changes, even preparing or checking them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.