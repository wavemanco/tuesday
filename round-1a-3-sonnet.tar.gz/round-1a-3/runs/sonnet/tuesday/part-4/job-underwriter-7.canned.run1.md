I've read the playbook and I'm now checking whether the employer is real and what the market pays, before I write the assessment.
Employer and pay band are checked. One last check: the team lead named in the advert.
**Yes, this is worth applying for, with three conditions: `conditional_go`.** The advert's essentials all appear on your CV, apart from "clear, timely written records", which it doesn't mention.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R7 · adjacent: R5 (Housebound adults at home), R6 (Own small caseload) · unclear: R4 (Clear, timely written records)
- `important` — direct: R9, R11 · adjacent: R8 (Leg-ulcer care) · unclear: R10 (Continence care), R12 (End-of-life visits), R13 (Care planning)
- `preferred` — absent: R14 (Doppler assessment)

R5, R6 — a real home-visiting bridge, its limits named; R4, R12 — the rows to close first.

**Opportunity ledger.** The employer is real, the pay sits inside the market range, and a senior nurse supports a small caseload (RR2, RR3). The open items are that the posting isn't confirmed live and the rota and mileage are unstated (RR1, RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting is confirmed live (RR1).
  2. You confirm your record-keeping experience (R4).
  3. The caseload and leg-ulcer limits are stated honestly as adjacent (R6, R8).

Your NMC registration (R1) and driving licence (R2) are stated, not checked. The NMC register and your DVLA record are yours to check. Your National Insurance number isn't needed for this and I haven't used it, so leave it off applications until a written offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing under an NHS contract, founded 2015, about 410 staff | `[grounded]` its About page |
| Mandate | District nursing for housebound adults: wounds and leg ulcers, catheter and continence, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Support and caseload | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Scope read | An entry route into community nursing: essentials ask for one year post-registration and no community experience | `[inferred]` from the essentials list |
| Working pattern | Pool cars provided, mileage paid. Rota, weekends and on-call are not stated | `[grounded]` JD for the cars and mileage |
| Market calibration | The posting's £31,050–£37,800 spans the survey's interquartile range for Band 5 community staff nurses (£32,400–£36,600, median £34,300). A pool or lease car is less common than mileage (24% against 61% paid mileage). It is a pattern, not this employer's offer | `[generic]` Wardround 2026 pay guide; `[grounded]` JD for the posting's range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team and has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Unknowns | Closing date, rota, mileage rate, which EPR system, whether Doppler training is offered | — |
| Contradictions | None found between the JD and the About page. The careers page could not be opened | `[grounded]` About page read; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | You state active registration, revalidation due March 2028. Stated, not checked | `[grounded]` your CV | Check your own NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated. Pool cars remove the need for your own vehicle | `[grounded]` your CV | Check your own DVLA record |
| R3 | One year or more post-registration | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, self-reported | `[grounded]` your CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on documentation or electronic records. A hospital nurse almost certainly documents, but no evidence is stated | `[grounded]` CV silence; `[generic]` that community EPR documentation differs from ward charting | Question G2 |
| R5 | Caring for housebound adults at home | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge. Limit: short-term post-discharge visits, not ongoing care of housebound patients | `[grounded]` your CV | State the limit in the application |
| R6 | A small caseload of your own | must_have | adjacent | medium | transferability | You have never held a caseload; the home visiting is the bridge. The role is supported by a senior nurse | `[grounded]` your statement and the JD | State plainly that you haven't held one |
| R7 | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds stated | `[grounded]` your CV | none |
| R8 | Leg-ulcer care | important | adjacent | low | transferability | Wound care is stated but leg ulcers are not mentioned. Limit: compression and venous assessment are not evidenced | `[grounded]` CV wound care only | Question G3 |
| R9 | Catheter care | important | direct | medium | none | Stated on your CV | `[grounded]` your CV | none |
| R10 | Continence care | important | unclear | low | discovery | Catheter care is stated; wider continence care is not | `[grounded]` CV silence | Covered in G2's answer if relevant |
| R11 | Insulin administration | important | direct | medium | none | Stated on your CV | `[grounded]` your CV | none |
| R12 | End-of-life visits | important | unclear | low | discovery | Not on the CV. Acute medical wards often involve end-of-life care, but nothing is stated | `[grounded]` CV silence; `[generic]` about ward work | Question G1 |
| R13 | Care planning | important | unclear | low | discovery | Not stated. Discharge work may have involved planning, but that is unconfirmed | `[grounded]` CV silence | Covered in G1's answer if relevant |
| R14 | Doppler assessment (desirable) | preferred | absent | none | capability | You have never done one, and the JD lists it as desirable only | `[grounded]` your statement and the JD | Ask about training in the informal chat |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R12; also R13) | discovery | Not on the CV | An important duty; a concrete example would lift two unclear rows | Caring for dying patients on the ward; anticipatory care or care-planning conversations; family discussions; discharge plans for end-of-life patients | A ward end-of-life care pathway or a reflective entry (anonymised) | `[grounded]` CV silence; `[generic]` that ward end-of-life work often overlaps community practice |
| G2 | Clear, timely records (R4; also R10) | discovery | Nothing on documentation or electronic records | An essential criterion the CV does not address | Electronic patient record use on the ward or the discharge team; audit of notes; handover documentation; continence assessments | An anonymised audit result or the name of the system you used | `[grounded]` CV silence; `[inferred]` that this is the most likely screening point, since it is an essential the CV doesn't mention |
| G3 | Leg-ulcer care (R8) | transferability | Wound care stated; leg ulcers absent | The bridge works only if its limit is stated | Compression bandaging, ABPI or venous assessment, wound-care referrals, tissue viability input | Training records or a competency sign-off | `[grounded]` CV wound care only |
| G4 | Doppler assessment (R14) | capability | Never done | Desirable only; carried as a minor gap | Any vascular or ABPI exposure counts as adjacent | A training record | `[grounded]` your statement and the JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The About page says vacancies are on a careers page, but the careers address I tried returned no page; it may sit elsewhere | `[grounded]` About page; careers fetch returned nothing | Is this post open, and what is the closing date? | unresolved |
| RR2 | Supported caseload | positive_signal | — | "supported by a senior community nurse" | A small supported caseload suits a first community post | `[grounded]` JD | How does the caseload build up in the first months? | noted |
| RR3 | Pay within market range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay and pool cars compare well with the survey | `[generic]` Wardround 2026 survey against the `[grounded]` JD range | Where do new joiners usually start on the scale? | noted |
| RR4 | Rota, mileage rate and on-call unstated | unknown | — | "plus mileage" | District nursing rotas often include weekends, but nothing is stated here | `[generic]` role-family pattern; `[grounded]` JD silence | What are the working hours, weekend rota and mileage rate? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the discharge-to-assess secondment up your CV. Proposed wording: "Discharge-to-assess team (18-month secondment): visiting patients at home in their first week after discharge" | R5; it uses your own words only | `[grounded]` your CV | `resume_edits_pending_approval` |
| P1 | In the supporting statement, say you haven't held your own caseload and haven't done Doppler assessment, and point to the home-visiting work as your base | R6, R14; stating limits keeps you honest if probed | `[grounded]` your statement | pending your approval |
| A1 | Use Rhiannon Mabbott's informal chat to ask the RR1, RR3 and RR4 questions, and whether Doppler training is offered. She has spoken on Doppler training for staff new to community work | R14, RR1, RR4 | `[grounded]` speaker page | pending your approval |
| A2 | Check your own NMC register entry and DVLA driving record before applying | R1, R2 | `[grounded]` stated, not checked | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing" and "Community Staff Nurse Band 5 district nursing Calderbrook Community Health CIC vacancy", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). The fetch of calderbrookhealth.example/careers returned no page. It moved role reality's organization and contradictions rows and produced RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing role requirements post-registration experience salary 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the hiring contact row and A1 |

I can save this assessment as `tuesday-dossier.md` if you'd like to reuse it later.

## Upgrade menu

- An example of record-keeping or electronic records you've used → R4, and R10 if continence assessments featured, could move from unclear to direct or adjacent.
- An end-of-life or care-planning example → R12 and R13 could move from unclear.
- Training records for compression bandaging or venous assessment → R8's bridge strengthens.
- The careers-page link or the live posting → RR1 closes.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Have you cared for dying patients on the ward or in discharge work, and did you take part in care-planning or family conversations? What was your part?

G2 — What electronic patient record did you use, and did you do anything beyond routine documentation, such as audits or continence assessments?

G3 — Have you done any compression bandaging, venous assessment or leg-ulcer care, or had training in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.