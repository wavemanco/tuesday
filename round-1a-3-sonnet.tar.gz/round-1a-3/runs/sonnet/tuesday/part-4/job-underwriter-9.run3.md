**Yes. Bank details, a PPS number and a passport check are routine once a written offer has been made, so your rule applies to the stage before an offer, not after one. Status on accepting: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000)
- `must_have`: direct: R3, R5, R6, R7 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important`: direct: R8 · adjacent: R9 (240 staff, monthly) · unclear: R11 (Staff payroll queries) · absent: R10 (Pension changes)

R4 — Irish statutory knowledge not yet shown; R10 — pensions were your manager's, so a handover to agree; R9 — more staff and a monthly cadence, with the bridge limits named.

**Opportunity ledger.** The offer follows two in-person interviews and names the role, pay, manager and working pattern in line with the ad (RR1). What it doesn't yet carry is written contract terms (RR2) or the payroll system and sign-off arrangement (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Limerick office), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the written contract arrives with probation, notice and pension terms (RR2); (2) you confirm R4 from your own experience; (3) a handover for pension changes is agreed (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick. I could not check it against its own website. | `[grounded]` ad and offer email |
| Mandate | Monthly payroll for 240 staff, starters, leavers and pension changes, payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` ad |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Terms offered | Permanent, €40,000, hybrid two days in Limerick, start after your notice period | `[grounded]` offer email |
| Pay against the ad | €40,000 sits inside the advertised €38,000–€42,000 | `[grounded]` ad and offer |
| Market calibration | Not run, because the salary sweep was refused. €40,000 is set only against the ad's own band, not the market. | `[grounded]` ad and offer |
| Scope read | One named post running payroll for 240 staff. The ad names no team, software or reviewer. | `[inferred]` from the ad's silence |
| Unknowns | Written contract, probation, notice, pension scheme, payroll system, who signs off each run | `[grounded]` offer email is silent on them |
| Contradictions | None between the ad and the offer on title, pay band or hybrid pattern | `[grounded]` ad against offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Limerick office | hard_gate | unclear | none | hard_gate | You gave no limit on office days. You attended two in-person interviews at the office, which is not a statement of what you will accept. | `[grounded]` your message | Q G1 |
| R2 | Salary €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | You gave no pay floor, so I can't say whether €40,000 meets it. | `[grounded]` your message | Q G1 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, confirmed by you, with nothing inspectable yet. | `[grounded]` your message | A reference letter from the hotel group would raise it to `high` |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say whether the hotel payroll was Irish or which statutory deductions you handled personally. Low rather than none because you have three years of payroll and a certificate to build on. | `[grounded]` the silence in your message | Q G2 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use of pivot tables and XLOOKUP, self-reported. | `[grounded]` your message | A sanitized workbook would raise it |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The awarding body wasn't named and no copy has been seen. | `[grounded]` your message | A copy of the certificate would raise it to `high` |
| R7 | Monthly payroll-to-general-ledger reconciliation | must_have | direct | medium | none | You did the monthly payroll-to-ledger reconciliation at the hotel group. | `[grounded]` your message | A sanitized reconciliation would raise it |
| R8 | Starters and leavers | important | direct | medium | none | You did starters and leavers, self-reported. | `[grounded]` your message | none |
| R9 | Monthly payroll for 240 staff | important | adjacent | medium | transferability | The bridge is real payroll running at a smaller scale. The limit is that it was 90 staff and fortnightly, so more than double the headcount and a different cadence went unexercised. The strengthener is describing the hotel group's busiest-period complexity. | `[grounded]` your figures; `[inferred]` that the cadence change is the likeliest probe | Prepare the bridge honestly, as adjacent |
| R10 | Processing pension changes | important | absent | none | capability | You said you have never done these and that your manager handled them. No direct or adjacent evidence exists. | `[grounded]` your statement | A handover plan (A4) |
| R11 | Answering staff payroll queries | important | unclear | none | discovery | Your message is silent on it. | `[grounded]` the silence in your message | Optional recall, no question asked |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor and office-day limit (R1, R2, hard_gate) | hard_gate | No stated limits on either | A gate nothing settles stays open until you answer | A minimum salary you set, a commute or caring limit on office days | None needed | `[grounded]` your message gives no constraints |
| G2 | Irish PAYE, PRSI, USC (R4, must_have) | discovery | Three years of payroll and a certificate, but no statement on statutory deductions | A must-have, and the one row that could move the status from `conditional_go` to `go` | Calculating or checking tax credits and USC on payslips, PRSI class corrections, year-end reconciliation to Revenue returns | The certificate syllabus, a sanitized payslip-checking note | `[grounded]` the silence; `[generic]` that employers screen this first for payroll posts |
| G3 | Pension changes (R10, important) | capability | Handled by your manager | Part of the role from week one | Watching, not doing, doesn't count. Closure is learning on the job under a handover. | A written handover or training plan from Marrowgate | `[grounded]` your statement |
| G4 | Scale and cadence (R9, important) | transferability | 90 staff fortnightly against 240 monthly | A probe is likely in onboarding | Seasonal starter surges, multi-site payroll, month-end close | A sanitized run summary | `[grounded]` figures; `[inferred]` the probe |
| G5 | Staff queries (R11, important) | discovery | Nothing stated | Part of the day-to-day | Payslip, leave-pay and tax-credit queries from staff | None | `[grounded]` the silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer matches the ad | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager, hybrid with two days a week in our Limerick office" | The terms are specific and agree with the ad's band and hybrid pattern | `[grounded]` ad and offer | Will a written contract follow with these same terms? | noted |
| RR2 | No written terms beyond the email | unknown | — | "starting on a date we agree once your notice period ends" | Probation, notice and pension terms may sit in a contract to follow | `[inferred]` from the email's silence | What are the probation period, notice period and pension scheme, and will they be in writing before I accept? | unresolved |
| RR3 | Payroll system and sign-off unnamed | unknown | — | "Run the monthly payroll for our 240 staff" | The ad names no software, team or reviewer, so support and sign-off are unknown | `[inferred]` from the ad's silence | Which payroll system do you use, and who reviews and approves each monthly run? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply to accept inside the five working days, after asking RR2's question by email so the answer is in writing | see RR2 | `[grounded]` offer email | pending your approval |
| A2 | Ask RR3's question with the same email or at the first call with Declan | see RR3, R9 | `[grounded]` register | pending your approval |
| A3 | Enter bank details, PPS number and the passport scan only in Marrowgate's own onboarding portal, reached from the address on its own website. If the emailed link goes elsewhere, stop and ask the People Team using contact details from that site. Bring the original passport on day one. | Sending these details is routine after an offer. What matters is that they go to the employer. | `[generic]` standard onboarding hygiene | pending your approval |
| A4 | Ask for a pension-changes handover. Proposed wording: "In my last role my manager handled pension changes, so I'd value a walk-through of your scheme and process in my first weeks." | see R10, G3 | `[grounded]` traces to your own sentence | pending your approval |
| A5 | Before sending anything, find Marrowgate's own site and check that the sender's email domain and the portal address match it | The employer was not checked from here. | `[generic]` basic verification | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; refused. It would have shown whether the employer and live posting match the ad (role reality, contradictions row). |
| 2. Role-family sweep | unavailable | Searched "payroll administrator Ireland salary Limerick 2026"; refused. It would have given the market calibration line. |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; refused. It would have informed the scope read and the plan's positioning. |

Marrowgate cannot be established from here. That is because the searches were refused, not because anything failed to match.

If you'd like, I can write this up as a `tuesday-dossier.md` to keep.

**Upgrade menu**
- Your minimum pay and office-day limits would settle R1 and R2.
- The written contract would close RR2 and likely move the status to `go`.
- The Payroll Technician syllabus or a copy of the certificate would raise R6 to `high` and may settle R4.
- A reference letter or sanitized reconciliation from the hotel group would raise R3 and R7.
- Search permission would let me check Marrowgate's own site against the ad. Two searches remain in the budget, so the market band and Declan's footprint may not both fit.

**Questions**
- G1 — Is there a minimum salary or a limit on office days that €40,000 and two Limerick days a week would break?
- G2 — Which of PAYE, PRSI and USC did you personally handle in the hotel group's payroll, was it Irish payroll, and did your certificate cover them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.