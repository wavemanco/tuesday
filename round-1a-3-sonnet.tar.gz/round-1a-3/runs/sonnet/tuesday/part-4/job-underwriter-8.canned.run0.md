Checking whether Velloway Logistics shows up as a real employer, then I'll write up the assessment.
**Short answer: don't go ahead.** I can't establish the firm from here, and this job is very likely a scam. Please don't paste your IBAN anywhere. I haven't used it, your PPS number or your passport, and none of them is needed for this assessment.

# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't apply or reply further. RR1, RR2, RR3 and RR4 are confirmed severe red flags. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R2, R3 · unclear: R4 (Good written English)
- `important`: adjacent: R5 (Order processing work)

R1 — "up to €26" does not settle your floor; R5 — a credible bridge, its limit named.

**Opportunity ledger.** The messages ask for payment for equipment (RR1), a cheque to lodge and pass on (RR2), and bank, tax and ID details before any offer (RR3). The hiring process runs wholly in chat (RR4). The employer is not established (RR5), the reply address is not tied to a company website (RR6), and the pay ceiling sits well above the market band (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** no payment, cheque or pre-offer bank, tax or ID request. A real interview with a named person. A written offer from an employer you can verify independently, stating the hourly rate and contract hours so R1 can be checked.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics"; searches returned nothing attributable to that name | `[grounded]` two searches, no results |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Contradictions | The posting says nothing about buying equipment. The later message asks you to pay €349 for a "work kit" | `[grounded]` posting against the messages |
| Pay arithmetic | At the ceiling rate, 15 hours a week is about €20,280 a year and 30 hours is about €40,560. Reaching €30,000 at the ceiling needs about 22 hours a week | `[inferred]` from "up to €26", 15–30 hours, 52 weeks |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, interquartile range €28,400 to €34,100. The guide excludes commission-only and freelance work, and the posting's rate is a ceiling, so this is a band to expect, not this employer's offer | `[generic]` pay guide, one search |
| Unknowns | Who the employer is, the base rate, the commission terms, the contract type, guaranteed hours | `[grounded]` posting silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint; posting: "up to €26 an hour", 15–30 hours) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because "up to" gives no base rate and the hours are a range | `[grounded]` your statement and the posting | Settles only with a written offer stating rate and hours |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day and upkeep of a weekly tracker point to it. Self-reported, with no inspectable accuracy measure | `[grounded]` your description | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. The limit is that the formula or pivot depth is not stated | `[grounded]` your description | none |
| R4 | Good written English | must_have | unclear | low | discovery | Ticket handling in Zendesk probably involves written replies, but that is not stated | `[inferred]` from the Zendesk role | Only matters if you pursue a real role |
| R5 | Order processing (implied by the title) | important | adjacent | medium | transferability | Parcel-courier ticket handling carries over. It did not exercise order entry itself, and the carry-over is that parcel-queries work shares the order-to-delivery chain | `[inferred]` from your courier role | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | The posting gives only a ceiling rate and a range of hours | The floor decides whether any offer is acceptable to you | Not applicable; this is a term, not experience | A written offer from a verified employer stating the hourly rate and contract hours | `[grounded]` posting wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. Don't pay. Who sent it, and whether any named employer is involved, is unresolved | `[generic]` a known pattern for requests of this kind, not a claim about any firm | "Do you ask new hires to pay for equipment, and who is the equipment partner?" Ask through contacts you find on the firm's own site, never the chat | confirmed |
| RR2 | Cheque to lodge and pass on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. Don't deposit the cheque. "The rest" is €2,500 by subtraction, which would leave your account before you could know the cheque had cleared | `[generic]` a known pattern of lodging a cheque and passing money on; `[inferred]` the €2,500 from the quote | "Do you ever send new hires a cheque to lodge and transfer on? Please confirm in writing from your own domain." Same independent route as RR1 | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | This request came before any offer, and it is very likely a scam | `[generic]` pattern: payroll details follow a credible written offer, not a first screening | "At what stage do you collect bank, tax and ID details, and through which portal?" Same independent route | confirmed |
| RR4 | Hiring run wholly in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews", and the offer arrived in the same chat | The posting and the messages show interviews and the offer happening only in chat, with no named person | `[grounded]` posting and messages | "Can I have a call or video interview with a named colleague before any offer?" Same independent route | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at the role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR6 | Reply address not tied to a company site | risk_signal | low | "Any problems, email velloway.hr@postmail.example." | The address may not come from who it names. Low rather than medium because I found no company site to compare it with | `[inferred]` from my search finding no company site | "Is this address one your company uses? Please confirm from a contact on your own site." | unresolved |
| RR7 | Pay ceiling above the market band | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process" | A ceiling is not an offer. The salaried band is lower, and the guide excludes commission-only work, so the comparison is imperfect. Low for that reason | `[generic]` band from one pay guide; `[inferred]` the comparison | "What is the base hourly rate, the commission scheme and the guaranteed weekly hours?" | unresolved |

**Hold.** RR1 to RR4 all fit the same hold. Pay nothing, deposit nothing, and send no bank, tax or ID details. No employer could be identified independently from here, so the sender's identity is unresolved. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pay nothing, lodge nothing and send no details. Pause replying | See RR1 to RR4 | `[grounded]` register | pending your approval |
| A2 | If you want to check, find the firm's own website yourself and use contacts from it, never the chat or the email in the message | See RR5, RR6 | `[grounded]` register | pending your approval |
| A3 | Look at salaried customer-operations and order-processing roles on employers' own careers pages. Your courier ticket work is adjacent (R5) | The guide's median of €31,200 is above your €30,000 floor, and its lower quartile of €28,400 is below it | `[generic]` pay guide band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator"; both returned no results, so the employer is not established. It moved RR5 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "order processing coordinator remote Ireland hourly pay entry level", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It moved market calibration, RR7 and A3 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a chat handle, so there was no query to form |

I can write this up as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- The jobs site's name and a link to the posting would show whether the posting is still live, which moves RR5.
- A company website or address found independently would let RR1 to RR6 be put to the employer directly, which moves RR5 and RR6.
- A written offer from a verifiable employer stating the hourly rate and contract hours would settle R1.
- A sanitized, data-free copy of your tracker template would raise R2 and R3 from `medium` toward `high`. This only matters for a genuine role.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) is available. Say the word and it runs.

RR5 — Which jobs site was the posting on, and did it link to a company website or give an email on a domain of its own? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.