I've run 4 searches. They all attribute to Fernquay, so I'm now reading their careers page to check it matches your posting.
**Yes, it's worth pursuing, and Fernquay's own pages match your posting (RR5). Status: `conditional_go`.** Their message thanks you for applying, so the live step is the video call.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer, no design team)

R7 — a credible bridge from checkout, its limit named; R8 — squad experience, never solo; R2 — waiting on your pay floor.

**Opportunity ledger.** Fernquay's own pages match the posting (RR5), and the posted pay sits at a survey median (RR3). Equity terms (RR1), design support (RR2) and runway (RR4) are still open. The WhatsApp message adds no entry here (see A1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits inside the posted band — R2, RR3; (2) the equity terms turn out acceptable — RR1; (3) you are satisfied with who reviews your design work as a sole designer — RR2, R8; (4) the checkout bridge is presented as adjacent, never as owning a whole booking flow — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: booking software (a product called Kelproster) for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about, as a search result |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting and careers page |
| Compensation | €52,000–€60,000 plus equity. The 0.5–1% figure appears in your posting copy, and the careers page I read says only "plus equity" | `[grounded]` posting and careers page |
| Market calibration | A 2026 Irish survey puts product designers with 3 to 5 years at a median base of €57,000 (interquartile range €51,500–€62,000), so the posted band brackets it. This is a market band, never Fernquay's offer, and I saw only the search snippet | `[generic]` role-family sweep, this month |
| Scope read | Sole-designer scope in a six-person company, with the booking flow as the core product surface | `[inferred]` from "first designer" and the product description |
| Unknowns | First-90-days outcomes, equity terms, who reviews design work, runway | `[grounded]` the posting is silent on each |
| Contradictions | None found between your posting copy, the careers page and the about page | `[grounded]` careers page fetched; about page seen as a search result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office is in your city. You haven't said how many office days you will accept, so this stays `medium` | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor or a view on equity, so whether this term works for you is unknown | `[grounded]` no constraint given | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated in your message and not yet confirmed against a CV | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated. Strength is better shown by the checkout case study they already saw, which I haven't inspected | `[grounded]` your message and their WhatsApp message | Bring the Figma file or prototype to the call |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers is user research. Limit: those were customers of a travel-booking company, and the role's calls are with school owners, a different audience | `[grounded]` your message; `[inferred]` the audience difference | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, which is one stage of a booking flow. Which other stages you covered isn't stated | `[grounded]` your message; `[inferred]` that checkout is one stage | G1 |
| R8 | First designer, with no design team | important | adjacent | medium | transferability | Four years in a squad with other engineers carries over. You have never been the only designer, so solo ownership is untested | `[grounded]` your message | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end booking flow (R7, must_have) | transferability | A confirmed checkout redesign. Nothing yet on the stages around it | It is the core of the role. The bridge is credible but its limit decides how you frame it | Work on search or availability, the confirmation or payment step, or handoff to engineering for any of them | The checkout case study, a flow map, a before-and-after prototype | `[grounded]` the checkout redesign is stated; `[inferred]` that this is the likeliest probe |
| G2 | Working as the only designer (R8, important) | transferability | Squad experience, no solo role | You would set your own process and have no design peer | Freelance or side projects, a design-system start, work where you decided design direction alone | A side-project file, a process doc, a research plan you wrote | `[grounded]` your statement that you were never the only designer; `[generic]` that first-designer roles hinge on this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may come without vesting, strike price or a stated share class, which changes what it is worth | `[generic]` equity at small companies varies widely by terms | What is the vesting schedule and cliff, and what share class or option scheme does the 0.5–1% sit in? | unresolved |
| RR2 | No design lead, and unclear who reviews your work | unknown | — | "You would be our first designer" | Design critique may come only from the co-founder and engineers | `[inferred]` from "first designer" and "work most closely with our co-founder" | Who gives design feedback today, and how will you judge whether my work is good? | unresolved |
| RR3 | Posted pay brackets the market median | positive_signal | — | "€52,000–€60,000" | The band isn't underpriced for a designer with 3 to 5 years, and it's stated openly | `[grounded]` posting figure; `[generic]` survey median from a search snippet | Is the band negotiable within the range depending on experience? | noted |
| RR4 | Runway not stated | unknown | — | "funded by its customers" | A customer-funded company may have steady revenue, but its capacity to add a salary and equity isn't shown | `[generic]` pattern for self-funded firms; `[grounded]` the about-page quote | How is this hire funded, and what runway does the current plan give? | unresolved |
| RR5 | Footprint matches the posting | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle" | Fernquay's own pages agree with the posting on size, place, founders, role and pay. This is their own material, with no third-party source such as a customer or registry yet | `[grounded]` about and careers pages | Which schools use Kelproster today, and could I speak to one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat WhatsApp scheduling for a video call as routine. Before the call, confirm the emailed invite comes from a fernquay.example address, and reply in that email thread too | Ronan Kehoe is named as co-founder on the about page and in your posting, and LinkedIn lists him as co-founder and CEO. A search snippet can't prove the WhatsApp sender is that person, so the email check does | `[generic]` common practice; `[grounded]` Ronan named on their about page, careers material and a LinkedIn result | pending your approval |
| A2 | Decide your pay floor, and your view on equity, before the call | See R2, RR3 | `[grounded]` R2 row | pending your approval |
| A3 | Present the checkout redesign as what it was: your redesign of one flow stage. Say plainly that you have worked in a squad and never as the only designer | See R7, R8 | `[grounded]` your own sentences | pending your approval |
| A4 | Ask RR1, RR2 and RR4 verbatim on the call | The register doubles as call preparation | `[grounded]` register | pending your approval |

If you want to rehearse the call with Ronan and Saoirse, mock-interview covers that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). The about page "About Fernquay" (fernquay.example/about) came back as a search result and I didn't fetch it. Moved: role reality's organization and contradictions rows, and RR5 |
| 2. Role-family sweep | yes | Searched "Product designer salary Ireland Galway startup 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved: market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved: A1. It adds that he is a co-founder and was previously a product lead at a Galway travel-software company |

I couldn't find independent sources such as customers, a company registry or press, beyond Fernquay's own pages and the LinkedIn result. Being small and sparsely covered isn't a warning sign in itself.

I can save this as a `tuesday-dossier.md` if you'd like.

**Upgrade menu**

- Your CV or portfolio link → confirms R3, R5 and R6, and raises R4 to `high` with the Figma file or checkout case study.
- Your pay floor → settles R2.
- The recruiter's emailed invite domain → settles A1.
- Answers on equity, design support and runway → close RR1, RR2 and RR4.
- A deeper research pass on Fernquay (up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

- R2 — What is the lowest salary you would accept, and would you count the equity toward it?
- G1 — Beyond checkout, did you touch any other stage of the booking flow (search, availability, confirmation or payment)? What did you own?
- G2 — Have you ever made design decisions with no other designer reviewing them, such as freelance or a side project? What happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.