I've finished reading the underwriting playbook. Next I'm checking whether Calderbrook Community Health CIC and this posting can be verified online, then I'll write the assessment.
**Worth applying to — yes. Status: `go`.** R1 and R2, the two hard gates, are `direct` on your own statement. R3, the one-year experience essential, is `direct` too. You miss no essential, and your two gaps (R12, R5b) are the ones the posting itself treats as trainable or desirable.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R6, R7, R10 · adjacent: R5b (Leg-ulcer care), R11 (Hold own small caseload) · unclear: R8 (Continence care), R9 (End-of-life visits)
- `preferred` — absent: R12 (Doppler assessment for leg ulcers)

R11 — a real bridge via discharge-to-assess, limit named; R12 — a plain gap on a desirable item; R8, R9 — CV silent, worth a line if true.

**Opportunity ledger.** Pay, pool cars, senior support and a named contact are all stated (RR2). Three things are open: I couldn't confirm the posting on the employer's own site (RR1), the hours and rota are unstated (RR3), and the terms of employment are unstated (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a posting that turns out not to be live (RR1), or a rota or terms (RR3, RR4) that clash with what you need.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` employer's About page |
| Role | District nursing team, housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning; own small caseload with a senior community nurse supporting | `[grounded]` JD |
| Pay and car | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse; at a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | An entry route into community nursing: one year post-registration is the only experience bar, and Doppler is desirable rather than essential | `[inferred]` from the JD's essential and desirable lists |
| Market calibration | Survey median basic pay for a Band 5 community staff nurse in England is £34,300 (interquartile range £32,400–£36,600), so this band brackets the median. 61% of respondents were paid mileage and 24% had a pool or lease car, so pool cars are better than typical. This is an England-wide self-reported survey, not a Halifax figure or this employer's offer | `[generic]` role-family sweep, one salary survey (n=1,240) |
| Unknowns | Hours, weekend and evening rota, lone-working arrangements, induction length, contract type, pension and sick-pay terms, mileage rate | — |
| Contradictions | None found between the JD and the About page; the posting itself was not found on the careers page (see RR1) | `[grounded]` About page read; careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | You state active adult registration with revalidation due March 2028. It is stated, not checked: I have not looked it up | `[grounded]` CV | You check your own entry on the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full category B licence. Stated, not checked | `[grounded]` CV | You check your own record on the DVLA licence service |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical ward staff nurse is well beyond the stated bar. A length-of-experience requirement is not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV does not mention record-keeping or any electronic patient record system. Silence, not evidence either way | `[grounded]` CV silence | Question G1 |
| R5a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds are stated | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | adjacent | low | transferability | Your wound care carries over in part. Limit: leg ulcers and compression therapy are not stated, so the bridge is partial | `[grounded]` CV for wound care; `[inferred]` adjacency | Describe it honestly as adjacent; see G3 |
| R6 | Catheter care | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R7 | Insulin administration and care planning | important | direct | medium | none | Insulin administration is stated. Care planning for insulin is not separately stated, so the claim stays at administration | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | Catheter care is stated; wider continence care is not | `[grounded]` CV | See G2 |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care | `[grounded]` CV silence | Question G2 |
| R10 | Visiting housebound adults at home | important | direct | medium | none | 18 months on a discharge-to-assess team visiting patients at home in their first week after discharge. Limit: a time-limited post-discharge episode, not a standing district nursing round | `[grounded]` CV | none |
| R11 | Hold a small caseload of your own, with senior support | important | adjacent | medium | transferability | Home visiting on discharge-to-assess is the bridge. Limit: you say you have never held your own caseload, and the posting provides a supporting senior nurse | `[grounded]` CV and your statement | Say so plainly in the application; see G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you have never done one. Closure path: ask about training, since the team lead has spoken publicly on Doppler training for staff new to community work | `[grounded]` your statement and the forum page | Ask in the informal chat |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | No mention of records or electronic systems | A must-have currently `unclear`; the posting stresses clear, timely records | Using an electronic patient record on the ward; discharge documentation; handover or care-plan entries; audit feedback on documentation | A reference line, an audit result, or a statement of which system you used | `[grounded]` CV silence; `[generic]` that records are a common focus for community roles |
| G2 | End-of-life and continence care (R9, R8, important) | discovery | The CV is silent on both beyond catheters | Two of the posting's listed care areas | Caring for dying patients on a medical ward; verification of expected death; symptom-control or anticipatory medication plans; bladder and bowel care beyond catheters | A training record or a reference line | `[grounded]` CV silence |
| G3 | Leg-ulcer care and caseload (R5b, R11, important) | transferability | Wound care and home visiting are stated; leg ulcers and caseload ownership are not | These are the bridges the application must make honestly | Dressing or compression work on venous ulcers; managing a group of discharged patients across several visits | A competency sign-off or training certificate | `[grounded]` CV; `[inferred]` the bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer is established. The posting may simply sit on a careers page I could not reach, since I guessed that address and it returned nothing | `[grounded]` About page read; fetch of the guessed careers address returned no page | Can I confirm this vacancy is open, and where is it advertised on your own site? | unresolved |
| RR2 | Pay, pool car, senior support and named contact stated | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided"; "supported by a senior community nurse" | The terms are concrete and the pay sits within the survey band | `[grounded]` JD; `[generic]` survey band | What does the supporting senior nurse's time look like in the first months? | noted |
| RR3 | Hours, rota and lone-working unstated | unknown | — | "caring for housebound adults in their own homes" | The posting may include weekend or evening visits; it does not say | `[inferred]` from the JD's silence | What are the working hours, and how often are weekends and evenings worked? | unresolved |
| RR4 | Employment terms unstated | unknown | — | "Calderbrook Community Health CIC" | As a company working under an NHS contract, its pension, sick pay and leave terms may differ from NHS terms; the posting does not say | `[generic]` pattern for independent providers under NHS contracts, not a claim about this one | Which pension, sick-pay and leave terms apply, and is the post permanent? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the offer of an informal chat with Rhiannon Mabbott and ask the questions in RR1, RR3 and RR4, plus what induction and Doppler training look like | The posting invites it; the register doubles as interview preparation | `[grounded]` JD and register | pending your approval |
| A2 | Lead with your discharge-to-assess home visiting and describe it as that, not as a district nursing caseload | R10 and R11: the evidence is real and its limit is part of the honest account | `[grounded]` CV | pending your approval |
| A3 | State plainly that you have not done Doppler assessment and ask about training | R12; it is desirable only and you have no claim to make | `[grounded]` your statement | pending your approval |
| A4 | Check the vacancy on Calderbrook's own site before investing effort | RR1 | `[grounded]` RR1 | pending your approval |

If you go ahead, tailoring your CV to this posting is a separate step I can do.

## Evidence status

Verified: none yet. Everything above is CV-equivalent self-report. R1 and R2 are stated, not checked, and the checks are yours: the NMC register for your registration and your own DVLA record for the licence. The National Insurance number you pasted isn't needed for this, so I haven't used or repeated it; keep it out of anything you send until an employer asks for it after a written offer.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing" and read the result "About Calderbrook Community Health" (calderbrookhealth.example/about). Role reality's organization row. Fetched calderbrookhealth.example/careers, a guessed address, which returned no page; the posting is therefore unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nurse Halifax salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]`, and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's contact row, and plan rows A1 and A3 |

I can save this assessment as a `tuesday-dossier.md` if you'd like to keep it or carry it into later steps.

**Upgrade menu**

- A link to the live posting or Calderbrook's careers page → RR1 closes.
- Your pay floor, hours and any non-negotiables → the hard-gates line can check the role's terms against them.
- Which electronic record system you used, plus an audit or reference line → R4 moves.
- Any end-of-life, continence or leg-ulcer training records → R9, R8 and R5b move.
- A deeper research pass on Calderbrook (contract performance, staff turnover, inspection reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- C1 — What pay floor, working hours and any other non-negotiables should I check this role against?
- G1 — Which record system did you use on the ward and in your discharge-to-assess work, and has anyone commented on your documentation?
- G2 — Have you looked after dying patients or handled continence care beyond catheters, and what part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.