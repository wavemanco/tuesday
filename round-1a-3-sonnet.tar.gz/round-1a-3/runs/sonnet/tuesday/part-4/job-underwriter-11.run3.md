Web search was refused in this session, so everything below rests on your text alone. Nothing in it comes from outside research.

# Job Underwriting — Duinvaart (FIRST) and Kroonhaven (SECOND)

## Decision snapshot

**FIRST, Operations Analyst at Duinvaart: yes, worth your time. Status: `conditional_go`.**
**SECOND, Supply Planner at Kroonhaven: no, not worth your time as the posting stands. Status: `no_go`, because B2, B3 and B6 are `must_have` rows with no planning evidence behind them.** The decision is yours.

**FIRST fit ledger**

- `hard_gate` — unclear: A1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: A2, A3, A4, A5a · unclear: A5b (Temperature compliance on a refrigerated fleet)
- `important` — direct: A6a · adjacent: A6b (Route changes with depot managers)
- `preferred` — adjacent: A7 (Dutch a plus)

A5b — cold-chain temperature work is the open question; A6b (`medium`) — review work that may bridge to route changes, its limit named.

**FIRST opportunity ledger.** The duties and tools are specific (RRA3). The employer is unverified because I couldn't check it (RRA1), and pay isn't in the text you pasted (RRA2).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies and the posting is live (RRA1); (2) the three Rotterdam office days work for you (A1); (3) the cold-chain gap is stated plainly, never papered over (A5b).

**SECOND fit ledger**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B4 (Run the weekly S&OP meeting), B7 (Fluent Dutch) · unclear: B5 (Advanced Excel) · absent: B2 (3+ years of FMCG supply or demand planning), B3 (Own the 13-week supply plan), B6 (SAP IBP or similar planning system)

B2, B3, B6 — no planning evidence, and you told me you've never worked in planning; B4 (`medium`) — a review-meeting bridge, its limit named.

**SECOND opportunity ledger.** The mandate is clearly scoped (RRB3). The employer is unverified because I couldn't check it (RRB1), and pay isn't in the text you pasted (RRB2).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a planning role you've held but didn't mention, or a posting that drops the experience and language requirements. Neither is in what you've shared.

## Role reality

**FIRST — Duinvaart Cold Chain, Rotterdam**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Cold-chain operator running a refrigerated fleet, Rotterdam | `[grounded]` posting header |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An individual-contributor analyst post that works with depot managers, with no team-lead language | `[inferred]` from the duties listed against the absence of any management wording |
| Market calibration | Not done: the role-family sweep couldn't run, so I won't state a salary band | — |
| Unknowns | Salary; who sets route changes (analyst or depot managers); how temperature data is collected | — |
| Contradictions | None within the posting. Not cross-checked against the company's careers page | `[grounded]` posting only |

**SECOND — Kroonhaven Foods, Utrecht**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Food producer with a chilled ready-meals range, Utrecht | `[grounded]` posting header |
| Mandate | Own the 13-week supply plan; balance production capacity against the forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A full-ownership planning post: the plan and the meeting are both the holder's | `[inferred]` from "own" and "run" in the duties |
| Market calibration | Not done: the sweep couldn't run | — |
| Unknowns | Salary; whether fluent Dutch is screened strictly; which planning system is in use beyond "SAP IBP or similar" | — |
| Contradictions | None within the posting | `[grounded]` posting only |

## Evidence map

Your background is in your message, so it counts as self-report at `medium` at most until you confirm specifics or share an artifact.

**FIRST**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't stated a commute or office-days constraint, so the gate isn't settled either way | `[grounded]` your message is silent on it | GA2 |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You stated 4 years as an operations analyst at a parcel carrier. Confirmed but not inspectable | `[grounded]` your message | none |
| A3 | Strong SQL | must_have | direct | medium | none | "SQL ... daily" over 4 years. Specific, no artifact yet | `[grounded]` your message | none |
| A4 | Power BI or Tableau | must_have | direct | medium | none | "Power BI daily, including the on-time delivery dashboard our depot managers use". Your exact ownership of that dashboard isn't stated | `[grounded]` your message | GA3 |
| A5a | Track on-time delivery | must_have | direct | medium | none | Same dashboard, plus the weekly route-performance review you ran | `[grounded]` your message | none |
| A5b | Temperature compliance across a refrigerated fleet | must_have | unclear | none | discovery | Nothing you've said touches temperature control. Parcel carriers may or may not handle temperature-controlled freight, so this is an open question, not a confirmed gap | `[grounded]` your message is silent; `[generic]` that parcel networks vary in this | GA1 |
| A6a | Build weekly dashboards in Power BI | important | direct | medium | none | Same evidence as A4 | `[grounded]` your message | none |
| A6b | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review and depot managers use your dashboard. Limit: you haven't said that review led to route changes, or that you made them | `[grounded]` your message; the limit is `[inferred]` from what's missing | GA3 |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is something, not fluent. As a "plus" it differentiates rather than gates | `[grounded]` your message | none |

**SECOND**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraint stated; commute from Amsterdam isn't established | `[grounded]` your message is silent on it | GB1 |
| B2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you've never worked in planning. Four years of analysis is adjacent work, not planning years, and the posting asks for planning years | `[grounded]` your message | Carry as a material risk |
| B3 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No capacity-versus-forecast balancing in what you've described | `[grounded]` your message | Carry as a material risk |
| B4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review, which is recurring cross-team review work. Limit: it wasn't S&OP, and there was no supply, capacity or forecast trade-off in it | `[grounded]` your message; the limit is `[inferred]` | none |
| B5 | Advanced Excel | must_have | unclear | none | discovery | Your tools are SQL and Power BI; Excel isn't mentioned | `[grounded]` your message is silent | none, since the role is already `no_go` on B2, B3 and B6 |
| B6 | SAP IBP or a similar planning system | must_have | absent | none | capability | A BI tool is not a planning system | `[grounded]` your message | Carry as a material risk |
| B7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational is a level below fluent. The posting names fluency, and a weekly meeting held in Dutch would test it | `[grounded]` your message; `[generic]` that planning meetings run in the local language | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (A5b, must_have) | discovery | No mention of temperature-controlled freight or compliance reporting | It's the one headline duty with no evidence behind it, and the one that distinguishes this role from your current one | Handling chilled or pharma parcels; monitoring a service-level or compliance threshold with an audit trail; any cold-chain customer contract | A compliance report, a KPI definition, an incident review | `[grounded]` silence in your message; `[generic]` that this duty distinguishes cold-chain roles |
| GA2 | Rotterdam hybrid terms (A1, hard_gate) | hard_gate | No stated constraint | A gate that doesn't hold ends the application whatever the fit | Your home location and what commute you'd accept | None needed beyond your answer | `[grounded]` your message |
| GA3 | Route changes (A6b, important) and dashboard ownership (A4, must_have) | transferability | The review and dashboard are confirmed, but not whether you built the dashboard or whether the review changed any route | It decides whether you can say "worked with depot managers on route changes" or only "reviewed route performance with them" | A route or depot schedule that changed after your review; a depot manager who asked for a dashboard change | A screenshot with figures removed, a review agenda | `[grounded]` your message; `[inferred]` the limit |
| GB1 | Utrecht on-site terms (B1, hard_gate) | hard_gate | No stated constraint | Same as GA2, for a fully on-site role | Your location and acceptable commute | None needed beyond your answer | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRA1 | Duinvaart not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | I couldn't check, so this says nothing about the company. It may be well established, too new or small, or the posting may be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers page, and who I'd report to? | unresolved |
| RRA2 | Pay not stated in the text pasted | unknown | — | (no pay figure in the posting as pasted) | The posting may carry it and the paste may have dropped it | `[inferred]` from the pasted text | What salary range is budgeted for this post? | unresolved |
| RRA3 | Duties and tools are concrete | positive_signal | — | "Track on-time delivery and temperature compliance ... build weekly dashboards in Power BI" | The scope is defined and measurable | `[grounded]` posting | Which depot managers would I work with first? | noted |
| RRB1 | Kroonhaven not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | I couldn't check, so this says nothing about the company. Same possibilities as RRA1, none ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers page, and who I'd report to? | unresolved |
| RRB2 | Pay not stated in the text pasted | unknown | — | (no pay figure in the posting as pasted) | The posting may carry it and the paste may have dropped it | `[inferred]` from the pasted text | What salary range is budgeted for this post? | unresolved |
| RRB3 | Ownership and cadence are explicit | positive_signal | — | "Own the 13-week supply plan ... run the weekly S&OP meeting" | The role has real authority and a clear rhythm; that makes it demanding for someone new to planning | `[grounded]` posting | Who signs off the plan when capacity and forecast disagree? | noted |

RRA1 and RRB1 each cap a `go` at `conditional_go` until the employer verifies. Ask the employer through contacts on its own website.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| EA1 | Resume line: "Worked daily in SQL and Power BI, including the on-time delivery dashboard that depot managers use." Upgrade the verb to "built" only if you confirm that you built it (GA3). | A4, A6a. Your sentence names the dashboard but not your ownership, so I took the lower reading | `[grounded]` your message | pending your approval |
| EA2 | Resume line: "Ran the weekly route-performance review." | A5a, A6b. Your own words, no added scope | `[grounded]` your message | pending your approval |
| EA3 | Don't claim temperature or cold-chain experience unless GA1 confirms it. If asked, say it would be new to you and name the compliance-style monitoring you have done | A5b | `[grounded]` A5b row | pending your approval |
| EA4 | Ask the RRA1, RRA2 and RRA3 questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| EB1 | If you apply to SECOND anyway: say plainly that you haven't worked in planning and lead with B4's review work. Expect B2, B3 and B6 to carry the screen | Rows B2, B3, B4, B6 | `[generic]` how requirement-heavy postings are usually screened | pending your approval |

If FIRST turns into an interview, mock-interview can run drills for it.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Duinvaart and for Kroonhaven were refused, so neither company's existence and posting status are checked. They would have moved RRA1 and RRB1 |
| 2. Role-family sweep | unavailable | Searches on analyst pay in Rotterdam and planner pay in the Netherlands were refused. They would have moved the market-calibration rows, RRA2 and RRB2, and how strictly "fluent Dutch" is screened (B7) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- Allowing web search → RRA1 and RRB1 get checked and the market calibration rows fill. Up to 5 more searches and 2 more fetches on deeper diligence if you want it.
- A hiring manager's name for either role → the scope read and which of your stories to lead with.
- A screenshot of your on-time dashboard, figures removed → A4 and A6a toward `high`.
- Your pay floor and location → A1 and B1 settle, and the pay entries get something to compare against.

Do you want me to finalize the EA1–EA3 resume language, or save this as a `tuesday-dossier.md` for later?

GA1 — At the parcel carrier, did you handle any temperature-sensitive or compliance-reported freight (chilled food, pharma)? What did you personally own?
GA2 and GB1 — Where are you based, and could you do three office days a week in Rotterdam, or a fully on-site job in Utrecht?
GA3 — Did you build the on-time dashboard or maintain it, and did a route or depot schedule ever change because of your weekly review?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.