Search permission was declined, so this runs on your two postings and your background only. The company checks and salary bands are marked as not done.

# Snapshot: Duinvaart Cold Chain, Operations Analyst

**Yes, worth applying. D2, D3, D4 and D5a are direct, on the condition that D1 holds. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: D1 (hybrid, three days a week in Rotterdam)
- `must_have`: direct: D2, D3, D4, D5a
- `important`: adjacent: D6 (depot managers on route changes) · unclear: D5b (temperature compliance)
- `preferred`: adjacent: D7 (Dutch a plus)

D5b: a discovery question on cold-chain exposure; D6: a bridge, its limit named.

**Opportunity ledger.** The employer could not be checked (DR1) and pay is unstated (DR2). The tracking and dashboard duties are stated plainly (DR3).

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam days work for you (D1); (2) the employer and posting verify (DR1).

# Snapshot: Kroonhaven Foods, Supply Planner

**No, I wouldn't spend your time here. K2, K3 and K6 are absent and K7 is only adjacent. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: K1 (on-site in Utrecht)
- `must_have`: adjacent: K4 (run the weekly S&OP meeting), K7 (fluent Dutch) · unclear: K5 (advanced Excel) · absent: K2 (3+ years planning in FMCG), K3 (own the 13-week supply plan), K6 (SAP IBP or similar)

K2, K3 and K6: you said you've never worked in planning, so these are capability gaps; K4: a bridge, its limit named.

**Opportunity ledger.** The employer could not be checked (KR1) and pay is unstated (KR2). The scope is clear (KR3), so the problem is fit, not the role.

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** forecasting or capacity-planning work you haven't mentioned (see KG1). Without it, the experience bar is a mismatch, not a presentation problem.

## Role reality

| Element | Duinvaart: what it is | Provenance |
|---|---|---|
| Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, weekly Power BI dashboards, route changes with depot managers | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | Looks like the analyst job you already do, plus a cold-chain compliance layer | `[inferred]` from the JD duties against your background |
| Market calibration | Not done: search was declined and the posting states no pay | `[grounded]` JD silent on pay; no search run |
| Unknowns | Pay; fleet size; where the temperature data comes from; Dutch level needed day to day | `[grounded]` JD silence |

| Element | Kroonhaven: what it is | Provenance |
|---|---|---|
| Mandate | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run weekly S&OP | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A full planning-owner role, not an analyst-support post | `[inferred]` from "own", "balance" and "run" in the duties |
| Market calibration | Not done: search was declined and the posting states no pay | `[grounded]` JD silent on pay; no search run |
| Unknowns | Pay; Dutch level in practice; which planning system is in use | `[grounded]` JD silence |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in Rotterdam (a term, so a gate) | hard_gate | unclear | none | hard_gate | You gave no constraints, and your employer is in Amsterdam; whether three Rotterdam days works is unknown | `[grounded]` posting terms; no constraint stated | Question 1 |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported, nothing inspected yet | `[grounded]` your background | none |
| D3 | Strong SQL | must_have | direct | medium | none | You use SQL daily; "strong" is the employer's judgment and will be probed | `[grounded]` your background | Offer: a sanitized query or report would raise it |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use | `[grounded]` your background | Offer: a dashboard screenshot would raise it |
| D5a | Track on-time delivery | must_have | direct | medium | none | The dashboard and weekly route-performance review are this work | `[grounded]` your background | none |
| D5b | Track temperature compliance | important | unclear | low | discovery | Nothing in your background mentions temperature-controlled freight; it may exist and be unmentioned | `[grounded]` background silent | Question 2 |
| D6 | Work with depot managers on route changes | important | adjacent | medium | transferability | Bridge: you ran the weekly route-performance review with depot managers. Limit: reviewing performance is not the same as agreeing route changes | `[grounded]` your background; `[inferred]` limit | Say plainly what you did and didn't change |
| D7 | Dutch a plus | preferred | adjacent | medium | presentation | Conversational Dutch against a nice-to-have; state the level honestly | `[grounded]` your statement | State "conversational" on the CV, never "fluent" |
| K1 | On-site in Utrecht (a term, so a gate) | hard_gate | unclear | none | hard_gate | You gave no constraints; five days on-site is a heavier commitment than a hybrid role | `[grounded]` posting terms; no constraint stated | Question 1 |
| K2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning. This is an experience requirement, not a gate, so it is graded here | `[grounded]` your statement | Closure path: a planning-adjacent role first |
| K3 | Own the 13-week supply plan against forecast | must_have | absent | none | capability | Performance analysis looks backward; the role owns a forward plan | `[grounded]` your statement; `[generic]` that the two are different work | Question 3 |
| K4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Bridge: you ran a weekly route-performance review. Limit: a cross-functional review of a forward plan is a different meeting | `[grounded]` your background; `[inferred]` limit | Frame as adjacent only |
| K5 | Advanced Excel | must_have | unclear | low | discovery | Your tools are SQL and Power BI; Excel depth is unstated | `[grounded]` background silent | Ask in the next turn if the role lives |
| K6 | SAP IBP or a similar planning system | must_have | absent | none | capability | You've never worked in planning, and nothing suggests a planning system | `[grounded]` your statement | Closure path: a course, after the role question |
| K7 | Fluent Dutch | must_have | adjacent | medium | transferability | Bridge: conversational Dutch. Limit: running a Dutch-language S&OP meeting needs more | `[grounded]` your statement | Never claim fluent |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| DG1 | Three Rotterdam days (D1; K1 for Utrecht) | hard_gate | No constraint stated | Decides whether Duinvaart is viable at all | Not applicable: it is a yes/no on terms | Not applicable | `[grounded]` posting terms |
| DG2 | Temperature compliance (D5b, important) | discovery | Background silent on controlled-temperature freight | Would close the only domain unknown on a strong-fit role | Chilled or pharma parcels; delivery-window compliance; SLA breach reporting; any threshold or exception tracking | A sanitized exception report or dashboard view | `[grounded]` background silence; `[generic]` that cold chain roles weight this |
| KG1 | Planning evidence (K3, must_have) | discovery | You say you never worked in planning | The only thing that could move this role off `no_go` | Peak-season volume forecasts; depot capacity vs. forecast volume; staffing or fleet needs from forecasts | A forecast sheet, a peak plan or a capacity deck | `[grounded]` your statement; `[inferred]` that this is the likeliest overlooked source |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer not checked from outside the posting | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | Whether the employer and posting are live is untested; reasons are not ranked | `[grounded]` no search ran | Can you point me to this role on your careers site, and who I'd report to? | unresolved |
| DR2 | Pay not stated | unknown | — | no figure in the posting | Pay may or may not match what the role pays elsewhere | `[grounded]` JD silent | What salary range is budgeted for this role? | unresolved |
| DR3 | Clear scope: named metrics, named tool | positive_signal | — | "build weekly dashboards in Power BI" | The role's output is defined | `[grounded]` JD | Who consumes the weekly dashboard today? | noted |
| KR1 | Employer not checked from outside the posting | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Whether the employer and posting are live is untested; reasons are not ranked | `[grounded]` no search ran | Can you point me to this role on your careers site, and who I'd report to? | unresolved |
| KR2 | Pay not stated | unknown | — | no figure in the posting | Planning owner roles may pay above your current level, so a mismatch is possible either way | `[generic]` role-family pattern | What salary range is budgeted for this role? | unresolved |
| KR3 | Clear scope | positive_signal | — | "Own the 13-week supply plan" | The role is well defined; it is a fit problem, not a posting problem | `[grounded]` JD | Who currently owns the plan? | noted |

## Application plan

Duinvaart. Each row is pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| DE1 | Lead the CV with the on-time delivery dashboard and the weekly route-performance review; wording drafted once you confirm whether you built or maintained the dashboard | see D4, D5a | `[grounded]` your background | resume_edits_pending_approval |
| DE2 | Don't claim cold-chain experience; if Question 2 turns something up, state it as adjacent with its limit | see D5b | `[grounded]` D5b row | pending your approval |
| DE3 | State Dutch as conversational | see D7 | `[grounded]` your statement | pending your approval |
| DE4 | Verify the posting on Duinvaart's own careers page before investing effort | see DR1 | `[grounded]` DR1 | pending your approval |

Kroonhaven. Each row is pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| KE1 | Don't apply unless KG1 turns up real forecasting or capacity-planning work | see K2, K3, K6 | `[grounded]` K rows | pending your approval |
| KE2 | If you apply anyway, never present the route-performance review as planning, and ask DR-style verification questions KR1 and KR2 | see K4 | `[grounded]` K4 row | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused. It would have fed role reality and DR1 and KR1 |
| 2. Role-family sweep | unavailable | Searches on operations analyst and supply planner salaries were refused. It would have fed market calibration and DR2 and KR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

Want this saved as `tuesday-dossier.md` to carry forward? Say so and I'll write it.

**Upgrade menu**
- Permission to search runs the company and posting checks plus salary bands. That would close DR1 and KR1 and calibrate DR2 and KR2. One L1 search remains; a deeper L2 pass adds up to 5 more searches and 2 more fetches.
- An answer to Question 2 would move D5b.
- A sanitized dashboard screenshot or query would raise D3 and D4 toward `high`.
- Confirming whether you built or maintained the dashboard would let me draft DE1 safely.
- A hiring manager's name would feed the scope read and the plan's lead story.

**Questions**
1. (D1, K1) Is three days a week in Rotterdam workable from where you live, and is five days on-site in Utrecht something you'd even consider?
2. (D5b) Did any of your parcel-carrier work touch temperature-controlled, time-critical or compliance-threshold shipments, even occasionally?
3. (KG1) At the carrier, did you do any volume forecasting or capacity planning, such as peak-season volumes against depot capacity, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.