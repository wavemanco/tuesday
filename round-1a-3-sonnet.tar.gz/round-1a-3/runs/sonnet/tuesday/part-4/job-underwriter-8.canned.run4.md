Two quick web searches found nothing on Velloway or on this hiring pattern. Below is the full read, built from your posting and messages.

## Decision snapshot

**No, don't go ahead. Don't pay, deposit the cheque or send any details. These messages ask for a €349 payment, a cheque deposit and your bank, tax and ID details before any written offer, and this request is very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

R2, R3, R4 — your own account fits, with no inspectable artifact yet; R1 — the posting's "up to" wording leaves your €30,000 floor unsettled.

**Opportunity ledger.** The role fails on its own terms, whatever your fit: it asks you to deposit a cheque and forward funds (RR1), pay for equipment (RR2), hand over bank, tax and ID details before an offer (RR3), and be hired wholly by chat (RR4). The sender's contact route is unresolved (RR5), and the firm could not be established from here (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer verified independently through its own website, and a written offer from its own domain naming the role, pay and contract. There would also have to be no request to pay, deposit a cheque or send ID details before an offer. None of that is in the messages as they stand.

Your IBAN, PPS number and passport aren't needed for this assessment, so I haven't used or repeated them. Please don't paste your IBAN into the chat.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" — two searches (a careers search and a scam-pattern search) returned no results, so the firm is not established | `[grounded]` my searches returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission on every order" | `[grounded]` posting |
| Pay against your floor | At €26 an hour for 15–30 hours, 52 weeks a year, pay runs €20,280–€40,560. €30,000 needs about 22 hours a week all year at the top rate, and the posting says "up to" and gives no commission terms | `[inferred]` arithmetic on the posting's figures, assuming 52 paid weeks |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Contact route | A Telegram handle, then an email address at postmail.example, which is not shown to be the employer's own domain | `[grounded]` your messages |
| Market calibration | Not run, because the decision is already fixed by RR1–RR4 | — |
| Unknowns | Who the employer is, the base hourly rate, commission terms, contract type, who pays wages | — |
| Contradictions | The posting says "No experience needed, full training provided" and lists no equipment purchase; the messages then ask for €349 | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint; posting: "up to €26 an hour", "15–30 a week") | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to" and the hours range put annual pay anywhere from about €20,000 to €40,000 | `[grounded]` your stated floor and the posting's figures | Moot while RR1–RR4 stand; the base rate would be asked of a verified employer |
| R2 | Strong attention to detail | must_have | direct | medium | none | You keep a team tracker and handle about 60 tickets a day; confirmed in your account, no inspectable artifact | `[grounded]` your background summary | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You maintain a weekly Excel tracker; no sample inspected | `[grounded]` your background summary | none |
| R4 | Good written English | must_have | direct | medium | none | Daily written ticket handling in Zendesk; no sample inspected | `[grounded]` your background summary | none |
| R5 | A quiet place to work | important | unclear | none | discovery | Nothing stated either way | `[grounded]` your messages are silent | none; the decision is not waiting on it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | The posting gives only a ceiling rate and a wide hours range | The gate is unsettled, but RR1–RR4 decide the status first | Not applicable: this is a term, not experience | A written offer from a verified employer stating base rate, hours and commission | `[grounded]` posting wording; `[inferred]` that RR1–RR4 outrank it |
| G2 | Quiet workspace (R5, important) | discovery | Not mentioned | A minor practical fit point | Not applicable | None needed | `[grounded]` silence in your messages |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque to deposit, then funds to forward | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A deposited cheque can show as available before it has cleared, and the money you forward is then yours if it is recalled. The €2,500 to forward is also far above the €349 equipment price quoted earlier | `[generic]` how cheque clearing works; `[grounded]` the two amounts are from the messages | Put to the employer through contact details you find yourself on its own website, never this chat or address: "Does your company ask new hires to deposit a cheque and forward part of it?" The sender's identity is unresolved | confirmed |
| RR2 | Pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A demand to pay for the job or its equipment, after a passed screening and again at offer stage | `[grounded]` quoted in your messages | See RR1: "Do you ask new hires to pay for equipment?" | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Those details were requested before any interview or written offer | `[grounded]` quoted in your messages | See RR1: "Do you collect IBAN, PPS and passport details before a written offer?" | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interview and offer both happen only in chat, with no live contact | `[grounded]` posting and messages | See RR1: "Can I interview with someone on a video call, and who would they be?" | confirmed |
| RR5 | Offer and contact off a verifiable employer route | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | The offer closed a chat-only process and points to an address at a mail provider, not shown to be the employer's domain; the check is on your side | `[inferred]` from the offer's route against the posting's silence on any company address | Which company domain will my written offer come from? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

Hold while you check: don't pay, deposit the cheque or send any details. The sender's identity is unresolved for RR1–RR5. This request is very likely a scam. Don't deposit the cheque.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying on Telegram for now; send no IBAN, PPS number, passport photo or €349, and do not lodge the cheque if it arrives | see RR1–RR3 | `[grounded]` register | pending your approval |
| A2 | Find the firm yourself through your own search, contact it only via details on its own website, and ask the RR verification questions verbatim | see RR1–RR6 | `[grounded]` register | pending your approval |
| A3 | If you ever do share details or lodge a cheque, phone your bank straight away | Banks can act faster early | `[generic]` how banks handle disputed payments | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers Order Processing Coordinator"; no result, so the firm is not established. Moved RR6 |
| 2. Role-family sweep | skipped | RR1–RR4 already fix the decision; it would only have fed a market calibration line, which is omitted |
| 3. Hiring manager's public footprint | n/a | No name was given |
| Outside the targets: scam-pattern search | yes | Searched "remote order processing coordinator job Telegram interview cheque equipment payment scam warning"; no result; it moved nothing |

## Dossier and upgrade menu

I can save this as a `tuesday-dossier.md` for future use if you'd like.

- The firm's own website or careers page, found independently → RR6 and RR5 can close.
- A written offer from a company domain naming role, base rate, hours and contract → R1 settles.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) → say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.