Running the company and salary searches now, then I'll write up the assessment.
I only have what you pasted. All four of my web searches were refused, so I couldn't check Fernquay myself. That is why the company side below reads "not established".

## Decision snapshot

**Yes, worth applying to, once you've confirmed Fernquay on its own pages. Status: `conditional_go`.** On legitimacy: nothing you pasted asks you for money, a deposit, or bank or ID details (RR6), and I can't establish the firm from here (RR1). Scheduling over WhatsApp with the invite by email is covered in A1.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (First designer on the team)

R6 — checkout is a credible bridge to the whole flow, its limit named; R8, R9 — adjacent, built in a team and not yet alone.

**Opportunity ledger.** The employer is not established from here (RR1). Pay, scope and the interview route are stated (RR2, RR6). Equity terms, decision rights and runway are open (RR3, RR4, RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and this posting confirmed on the company's own pages (RR1); (2) the pay band checked against your floor (R2); (3) decision rights with Ronan, equity terms and runway answered on the call (RR3, RR4, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools. Not independently confirmed | `[grounded]` posting; `[grounded]` you found little online |
| Role | First designer; owns the booking flow, runs research calls with school owners, ships with two engineers, works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Pay and terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in Galway | `[grounded]` posting |
| Hiring process | 45-minute video call with Ronan and the CTO, Saoirse; WhatsApp message, then an emailed invite | `[grounded]` your message |
| Scope read | One person covering design, research and shipping, with no design peer | `[inferred]` from "first designer" and "end to end" |
| Market calibration | Not run, because the role-family search was refused. The figure above is the posting's own, not a market comparison | `[grounded]` posting |
| Unknowns | Runway and funding; equity terms; which decisions are yours versus Ronan's | `[inferred]` from the posting's silence |
| Contradictions | None between the posting and the message (role, names). Neither could be checked against a company site | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year; self-reported | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so the band can't be tested against anything | `[grounded]` posting figure; no floor given | G2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily"; no inspectable file yet | `[grounded]` your background | Offer a Figma file or case study link |
| R5 | You have run your own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers. The claim is usability sessions, no wider | `[grounded]` your background | Offer a discussion guide or readout |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout in a travel-booking product. The limit: checkout is one stage, and your ownership of the stages around it is unstated | `[grounded]` your background; `[inferred]` that checkout is part of a booking flow | G1 |
| R7 | Work directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your background | none |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were usability work with customers. `[generic]` Interviewing business owners about how they work is a different activity | `[grounded]` your background; `[generic]` pattern | G3 |
| R9 | Be the first designer, working without a design peer | important | adjacent | medium | transferability | You have never been the only designer. The limit: no experience setting direction or practice alone | `[inferred]` from "first designer" in the posting | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership (R6, must_have) | transferability | A checkout redesign; no statement of which parts were yours or what lay outside checkout | A `must_have` at `adjacent`; the posting says "end to end" | Mapping the path from search to confirmation; owning handoff and post-launch checks; changes to pricing or availability screens | The case study Ronan mentioned, a flow diagram, a before-and-after metric | `[grounded]` your background; `[inferred]` this is the likeliest probe |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The band is stated; your floor isn't | A gate left unconfirmed can't be cleared | Your minimum base, and whether equity counts toward it | None needed; your own statement is the evidence | `[grounded]` posting figure; floor not given |
| G3 | Working without a design peer (R8, R9, important) | transferability | A team-based record and monthly usability sessions; nothing on solo direction or owner interviews | These are the two ways this role differs from your last one | Covering a design lead's absence; a side or freelance project; interviewing non-customer stakeholders | A messy real project, which the posting says it prefers to a polished deck | `[grounded]` your background and the posting's wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated openly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Compensation is concrete, not withheld | `[grounded]` posting | Is the band fixed, or does it move with experience? | noted |
| RR3 | Equity terms unspecified | unknown | — | "0.5–1% equity" | Vesting, share class and strike terms are not given | `[inferred]` from the posting's silence | What are the vesting terms and what do the percentages apply to? | unresolved |
| RR4 | Decision rights unstated | unknown | — | "own the booking flow end to end … work most closely with our co-founder" | Ownership may be shared with Ronan in practice | `[inferred]` from the posting's silence on who decides | Which product decisions would I make alone, and which go through you? | unresolved |
| RR5 | Runway and funding unstated | unknown | — | "We are six people" | Nothing in the posting says how the team is funded | `[inferred]` from the posting's silence | How is Fernquay funded, and how long is the runway? | unresolved |
| RR6 | No requests for money, deposit, or bank or ID details | positive_signal | — | "Could you do a 45-minute video call with me and Saoirse, our CTO?" | The only ask is a video call with two named people | `[grounded]` your message and the posting | Who else would I meet after this call? | noted |

## Application plan

Every row is proposed and waits for your approval. That covers the advice in A4 as well as the rows themselves.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own site or careers page yourself, not through the message, and check the posting is there. Check the emailed invite comes from the same domain and that its video link opens a standard video service. Scheduling by WhatsApp with the invite by email is a routine step | RR1 | `[generic]` practical check; no claim about Fernquay | pending your approval |
| A2 | Ask RR1, RR3, RR4 and RR5's questions on the call, word for word | The register doubles as call prep | `[grounded]` register | pending your approval |
| A3 | Decide your pay floor before the call | R2, G2 | `[grounded]` R2 | pending your approval |
| A4 | Lead with your own words: "I redesigned our checkout flow and ran monthly usability sessions with customers, in a squad with four engineers." Say plainly that you haven't been the only designer before, and offer the messy-project route in G3. Don't say "owned the booking flow", "led research" or "ran discovery": none of those is in what you told me | R5, R6, R9 | `[grounded]` your own sentences | pending your approval |

For the call itself, mock-interview is the module that runs prep and practice.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches, "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers", were both refused. It would have moved RR1 and the role-reality organization and contradictions rows. You said you found little online, but that report can't stand in for the check |
| 2. Role-family sweep | unavailable | One search, "product designer salary Ireland startup first designer 3+ years equity", was refused. It would have moved the market calibration row and the R2 and RR2 comparison |
| 3. Hiring manager's public footprint | unavailable | One search, "Ronan Kehoe Fernquay co-founder", was refused. It would have moved the scope read and A4's positioning |

If you'd like, I can save this as `tuesday-dossier.md` to carry forward.

**Upgrade menu**

- Permission to search, or a link to Fernquay's site or careers page that you find yourself → RR1 closes or sharpens, and the market band can be set against the posting.
- Your pay floor → R2 resolves.
- The checkout case study or a Figma file → R4 and R6 can reach `high`.
- A usability discussion guide or readout → R5 and R8 firm up.
- Ronan's professional profile or any published talks → the scope read and the framing in A4.

G1 — On the checkout redesign, which parts were personally yours (research, flows, visuals, handoff, post-launch checks), did it cover the path from search to confirmation, and what happened after launch?
G2 — What is the lowest base salary you'd accept, and does equity count toward it at all?
G3 — Have you ever made design calls with no other designer to review them, such as covering for a lead, a solo project or a side project, and what did you do?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.