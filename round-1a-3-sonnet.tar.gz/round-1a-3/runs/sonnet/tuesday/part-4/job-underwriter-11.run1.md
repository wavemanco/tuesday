Web search was declined in this session, so everything below rests on your two postings and your background. Employer facts and market pay are unchecked.

## Decision snapshot

**Duinvaart (Operations Analyst): yes, it's worth your time, with conditions. R2, R3 and R4 are `direct`. Status: `conditional_go`.**
**Kroonhaven (Supply Planner): no, I wouldn't spend your time on it. R9, R11 and R13 are `absent` must-haves. Status: `no_go`.**

**Fit ledger: Duinvaart**
- `hard_gate`: unclear: R1 (Hybrid, three days Rotterdam)
- `must_have`: direct: R2, R3, R4
- `important`: adjacent: R6 (Work with depot managers on route changes) · unclear: R5 (Temperature compliance tracking)
- `preferred`: adjacent: R7 (Dutch a plus)

R2, R3, R4 are your daily work; R6 is a credible bridge, its limit named; R5 (`none`) has nothing to read yet.

**Fit ledger: Kroonhaven**
- `hard_gate`: unclear: R8 (On-site in Utrecht)
- `must_have`: adjacent: R12 (Fluent Dutch) · unclear: R10 (Advanced Excel) · absent: R9 (3+ years planning in FMCG), R11 (SAP IBP or similar system), R13 (13-week supply plan ownership)
- `important`: adjacent: R14 (Run weekly S&OP meeting)

R9, R11, R13 — planning experience you've said you don't have; R12 — conversational Dutch against a fluent requirement.

**Opportunity ledger.**
- Duinvaart: employer unchecked (RR1) and salary withheld (RR2), but its outputs and tools are named (RR3).
- Kroonhaven: employer unchecked (RR4) and salary withheld (RR5).

- **Hard gates:**
  - Duinvaart: none failed; unconfirmed: R1 (Hybrid, three days Rotterdam); candidate constraints not given — checks against them unknown.
  - Kroonhaven: none failed; unconfirmed: R8 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:**
  - Duinvaart `conditional_go` conditions: (1) the employer verifies and the posting is live (RR1); (2) three days a week in Rotterdam works for you (R1); (3) your cold-chain or temperature-data exposure is established or honestly carried as a gap (R5).
  - Kroonhaven `no_go` would need different facts: planning work in your history (R9, R11, R13), which you've told me you don't have, and Dutch at the posting's fluent level (R12).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart: mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, weekly Power BI dashboards, route changes with depot managers | `[grounded]` posting |
| Duinvaart: terms | Hybrid, three days a week in the Rotterdam office; salary not stated | `[grounded]` posting |
| Duinvaart: scope read | An analyst post whose named outputs (weekly dashboards, depot-manager work) match what you do at the parcel carrier | `[inferred]` from the posting against your stated duties |
| Kroonhaven: mandate | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Kroonhaven: terms | On-site in Utrecht; fluent Dutch required; salary not stated | `[grounded]` posting |
| Kroonhaven: scope read | A planning-owner role, not an analyst role | `[inferred]` from "own the 13-week supply plan" |
| Market calibration | Not run: search was declined | — |
| Unknowns | Both: salary, team size, who you'd report to, employer details | `[grounded]` both postings silent |
| Contradictions | None found between the postings and what you told me | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't stated location or schedule limits, so I can't say whether this is met | `[grounded]` your message silent on constraints | Question G1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You describe 4 years as an operations analyst at a parcel carrier: specific, but no artifact inspected | `[grounded]` your stated background | CV would let me check how it reads |
| R3 | Strong SQL | must_have | direct | medium | none | You use SQL daily; stated, nothing inspected | `[grounded]` your stated background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily, including the on-time delivery dashboard your depot managers use. A screenshot would raise it | `[grounded]` your stated background | Offer: a sanitized dashboard screenshot |
| R5 | Temperature compliance tracking (refrigerated fleet) | important | unclear | none | discovery | You haven't mentioned temperature or cold-chain data. Parcel on-time work is adjacent to the on-time half only | `[grounded]` your background silent on temperature data | Question G2 |
| R6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and your dashboard is used by depot managers. Limit: a review is not stated to have driven route changes | `[grounded]` your stated work; limit named | Question G3 |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but short of working fluency | `[grounded]` your own description | none; state your level plainly |
| R8 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraints given; posting is fully on-site | `[grounded]` posting; your message silent | Question G1 covers location in general |
| R9 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've said you've never worked in planning. The length is a requirement, not a gate | `[grounded]` your statement | Closure path in G5 |
| R10 | Advanced Excel | must_have | unclear | none | discovery | You list SQL and Power BI; Excel isn't mentioned | `[grounded]` your background silent | Not asked: the decision is stable without it |
| R11 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system among your tools | `[grounded]` your stated tools | Closure path in G5 |
| R12 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational is below fluent; a posting that says "fluent" may screen on it | `[grounded]` your description; `[generic]` that stated language levels are often screened literally | none |
| R13 | Own the 13-week supply plan, capacity against forecast | must_have | absent | none | capability | No planning work stated | `[grounded]` your statement | Closure path in G5 |
| R14 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review: a recurring cross-team meeting. Limit: S&OP reconciles demand, supply and finance, which that review wasn't stated to do | `[grounded]` your stated review; `[generic]` what S&OP covers | none |

R1–R7 are Duinvaart; R8–R14 are Kroonhaven.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whether the location and schedule terms work (R1, R8) | hard_gate | No limits stated by you | A gate unresolved keeps the decision conditional | n/a | n/a | `[grounded]` your message silent |
| G2 | Temperature or cold-chain data (R5, important) | discovery | On-time work stated; temperature not | The posting names it as half the tracking job | Tracking food, pharma or other time-sensitive loads; flagging delay-driven spoilage or damage; any sensor, route or SLA breach data | A sanitized report or dashboard view | `[grounded]` background silent; `[inferred]` it could lift R5 |
| G3 | Route changes (R6, important) | discovery | Review ran weekly; outcomes not stated | Decides whether R6 is `direct` or stays `adjacent` | A route or depot change your review led to; a recommendation a depot manager acted on | A review pack with sensitive data removed | `[grounded]` your stated review |
| G4 | Excel depth (R10, must_have) | discovery | Not mentioned | Doesn't move a `no_go` | n/a | n/a | `[grounded]` background silent |
| G5 | Planning experience (R9, R11, R13) | capability | None stated | Three must-haves | A scoped-down target such as a planning-analyst or demand-analytics role, or a planning-tool course plus a small forecast project | A forecast model or planning-tool certificate | `[grounded]` your statement; `[generic]` that adjacent analyst roles are a common route into planning |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart: employer not established from here | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The search was refused, so nothing is confirmed: the posting may be live and fine, stale, or not a real hiring employer | `[generic]` pattern, not a claim about this company | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Duinvaart: salary withheld | unknown | — | no figure in the posting | May sit below what you need; many postings omit it | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Duinvaart: outputs and tools named | positive_signal | — | "weekly dashboards in Power BI" | The scope is concrete and matches your work | `[grounded]` posting | Who uses the weekly dashboards today? | noted |
| RR4 | Kroonhaven: employer not established from here | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The search was refused, so nothing is confirmed: possibilities as for RR1 | `[generic]` pattern, not a claim about this company | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Kroonhaven: salary withheld | unknown | — | no figure in the posting | May sit below what you need | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart CV: lead with "the on-time delivery dashboard our depot managers use" and "ran our weekly route-performance review", using your own wording | see R4, R6 | `[grounded]` your sentences | resume_edits_pending_approval |
| A1 | Duinvaart: ask the questions of RR1 and RR2 early, verbatim, and confirm the hybrid terms | see R1, RR1 | `[grounded]` register | pending your approval |
| A2 | Duinvaart: state your Dutch level as you described it, "conversational" | see R7 | `[grounded]` your wording | pending your approval |
| A3 | Kroonhaven: don't apply for now | see R9, R11, R13 | `[grounded]` map rows | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported, so every claim above is a lead until you confirm specifics or show an artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for both employers were refused. It would have checked that each exists and the posting is live: role reality and RR1, RR4 |
| 2. Role-family sweep | unavailable | Searches for both role families were refused. It would have set market pay and scope against the postings: role reality's calibration and RR2, RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given in either posting |

## Dossier offer

If you want, I can save this as `tuesday-dossier.md` so later steps pick up where this leaves off.

## Upgrade menu

- Your CV, or a sanitized screenshot of the on-time dashboard → R2, R3, R4 toward `high`, and a check on how they read.
- Allowing search → rerun targets 1 and 2: confirms both employers (RR1, RR4) and sets pay against market (RR2, RR5).
- A deeper research pass (up to 5 more searches and 2 more fetches) → recent news and company history. Offered once; say the word and it runs.
- Your pay floor and any other must-haves → R1 and R8 checked against them.
- Duinvaart's salary range from a recruiter → RR2 closes.
- If you go ahead with Duinvaart, resume-tailor can adapt your CV to it.

## Questions

G1 — Is three days a week in Rotterdam workable for you?
G2 — Have you worked with temperature, cold-chain or other time-sensitive load data, and what was your part in it?
G3 — Did your weekly route-performance review ever lead to a route or depot change, and what did you own in it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.