# Job Underwriting — Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead. RR1, RR2, RR3 and RR4 are confirmed severe red flags. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Earn up to €26 an hour)
- `must_have` — direct: R2, R4 · adjacent: R3 (Strong attention to detail)

R1 — pay is stated only as "up to"; R3 — a credible bridge, its limit named.

**Opportunity ledger.** The posting asks you to pay for equipment (RR1), lodge a cheque and forward part of it (RR2), hand over bank, tax and passport details before any offer (RR3), and be hired only by chat (RR4). I can't establish the firm from here (RR5). The requests are very likely a scam, so pay and send nothing yet.

- **Hard gates:** none failed; unconfirmed: R1 (Earn up to €26 an hour).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the payment, cheque and ID requests (RR1, RR2, RR3) are withdrawn. The firm is established on its own website with a live posting (RR5). Rate, hours and contract basis come in writing from its own domain (R1, RR7). The interview and offer happen through the firm's own channels (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics, as named in the posting and messages | `[grounded]` posting; a search for the name returned no results, so the entity is not established (RR5) |
| Mandate | Order processing, remote, "plus commission on every order you process" | `[grounded]` posting |
| Hours and pay | 15–30 hours a week, "up to €26 an hour" plus commission, commission rate not stated | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Contract basis | Not stated: employee or self-employed is unknown | `[grounded]` posting silent |
| Scope read | A clerical order-entry post of the kind that fits your spreadsheet and ticket background | `[inferred]` from the posting's tasks and requirements |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200 a year, interquartile range €28,400 to €34,100. The guide excludes commission-only and freelance work, so it is a rough comparison only | `[generic]` Pennoral 2026 Ireland pay guide, found by one search |
| Unknowns | Who runs the Telegram handle; the firm's own site; the guaranteed rate; the commission rate; contract basis | — |
| Contradictions | The first message says the €349 kit is refunded with your first wages. The later message sends a cheque of €2,850, of which you keep €350 and forward the remaining €2,500 to the same "equipment partner". The €349 and €2,500 asks do not match | `[grounded]` the two messages, with €2,850 − €350 as arithmetic |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Earn up to €26 an hour, 15–30 hours a week (your floor: at least €30,000 a year) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor, which is specific and your own. Fit is `unclear` because "up to" leaves the real rate open and the commission is unquantified. At €26, €30,000 a year needs about 22 hours a week, and 15 hours at €26 reaches about €20,280 a year | `[grounded]` your stated floor and the posting's figures; `[inferred]` the arithmetic | Get the guaranteed rate, hours and contract basis in writing from the firm's own domain (RR7) |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. This is your own account with no inspectable artifact yet, so `medium` | `[grounded]` your stated background | none for this posting |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 tickets a day and the tracker show sustained careful handling in related work. Limit: nothing here measures order-entry accuracy or error rates | `[grounded]` your stated background; `[inferred]` the bridge | none for this posting |
| R4 | Good written English | must_have | direct | medium | none | Ticket handling in Zendesk involves written customer replies, which I read as written-English work | `[inferred]` from ticket handling | none for this posting |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | "Up to €26 an hour", 15–30 hours, commission rate not stated | Whether the role could meet €30,000 a year is not settled by the posting | Not applicable: this is a term of the role, not your experience | A written offer from the firm's own domain stating the rate, hours, commission and contract basis | `[grounded]` posting wording; `[inferred]` that the terms are unsettled |
| G2 | Attention to detail (R3, must_have) | transferability | Ticket volume and tracker upkeep, with no accuracy measure | Only matters if a verified role comes up | Error-rate or QA scores from your courier job; a tracker you kept accurate over time | A sanitized tracker screenshot or a QA score summary | `[grounded]` your background; `[inferred]` the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | The material asks you to pay for the job's equipment. The sender's identity is unresolved | `[generic]` asking new hires to pay up front is a recognised warning sign of requests like this | Do you ask new hires to pay for equipment before they start, and is this chat contact one of your recruiters? Ask it through contacts found on the firm's own site, never the chat or the email | confirmed |
| RR2 | Cheque to lodge, part forwarded | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | The request has you lodge a cheque and send part of it on. The sender's identity is unresolved | `[generic]` a pattern in requests of this kind: a lodged cheque can later fail to clear while a transfer you sent has already gone | Do you send new hires a cheque and ask them to forward part of it to a supplier? Same route as RR1 | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | The request comes after a chat "screening" and before any written offer naming the role and pay | `[grounded]` the message's timing against your account that nothing written had arrived | Do you collect IBAN, PPS number and passport photos before a written offer, and through which channel? Same route as RR1 | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The posting says interviews and the offer happen only in chat | `[grounded]` the posting's own words | Can I speak to someone at your firm's published number, and will there be a written offer? Same route as RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` a search for the name returned no results | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Contact address on a mail-provider domain | risk_signal | low | "Any problems, email velloway.hr@postmail.example." | The address sits on a mail-provider domain, and the firm's own domain is unknown to me, so the message may not come from who it names | `[grounded]` the address as written; `[inferred]` that it cannot be matched to the firm | Which email domain does your HR team use, as shown on your own website? | unresolved |
| RR7 | Pay stated as "up to" plus unquantified commission | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process." | The top rate is well above the salaried comparison (€31,200 ÷ (52 × 40) is about €15 an hour), but that guide excludes commission-only and freelance work, so I take the lower severity | `[generic]` Pennoral guide band; `[inferred]` the hourly arithmetic | What is the guaranteed hourly rate, what is the commission rate, and is this an employment contract or self-employment? | unresolved |

**Hold.** Pay nothing, lodge no cheque and send no IBAN, PPS number or passport photo while you check who sent these messages. I don't need any of those for this assessment, and I haven't repeated your IBAN here. The sender's identity is unresolved. This request is very likely a scam. Don't deposit the cheque. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or €349 | see RR1, RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it | see RR2 | `[grounded]` register | pending your approval |
| A3 | Look for the firm's own website yourself and use only contacts found there for the verification questions | see RR5, RR6 | `[grounded]` register | pending your approval |
| A4 | Report the posting to the jobs site | see RR1 to RR4 | `[grounded]` register | pending your approval |
| A5 | Redirect your search to customer-operations roles with a published salary. Your 3 years at a parcel courier, about 60 tickets a day in Zendesk, training two starters and the Excel tracker are the background to lead with. The salaried band spans your €30,000 floor | see R1 to R4 | `[grounded]` your background; `[generic]` Pennoral band | pending your approval |

## Evidence status

Verified: R1 claim (your €30,000 floor). Unverified leads: R2, R3 and R4 claims, which rest on your stated background without an inspectable artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and got no results. The employer is not established, which gives RR5 and role reality's organization row. The Telegram handle and the email domain could not be checked |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It moved the market calibration `[generic]` and RR7 |
| 3. Hiring manager's public footprint | n/a | Only a chat handle was given, no name, so there was no query to form |

If you'd like, I can save this as a `tuesday-dossier.md` to carry into later searches. Say the word.

## Upgrade menu

- The live listing link or the firm's own website → RR5 and the contradictions row can close either way.
- A written offer from the firm's own domain with rate, hours, commission and contract basis → R1 and RR7 resolve.
- A sanitized screenshot of your Excel tracker or a QA score summary → R2 can reach `high` and R3's limit narrows.
- A deeper research pass on the firm (leadership, public candidate reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

RR5 — Does the jobs-site listing link to a company page or website for Velloway Logistics? If so, paste the address.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.