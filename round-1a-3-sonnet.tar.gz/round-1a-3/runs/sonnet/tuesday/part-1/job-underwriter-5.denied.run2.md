I've been reading the underwriter playbook's reference files, and I still need the output rules before I write the assessment.
# Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, this is worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9 is a credible bridge, its limit named; R10 and R11 — the background you gave is silent, so each is a question to ask, not a gap found.

**Opportunity ledger.** The role is clearly scoped on stack and pay (RR3). The reporting line, team size and ownership of "build and run" are unknown (RR1, RR2), and so are the equity terms and whether the role is new or a backfill (RR4, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work from somewhere in the US or in Denver — R1; (2) the range clears your own pay floor — R2; (3) the BigQuery gap is framed honestly as adjacent, never as BigQuery experience — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about page text you pasted (not checked live, see Evidence status) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity (equity terms not stated) | `[grounded]` JD |
| Market calibration | The posted low end is $3,000 below the report median of $151,000 and the high end is $2,500 above the top of its interquartile range ($139,000–$163,500). The midpoint, $157,000, sits above the median. Pellucid is Series C, inside the report's Series B–D cohort, and six years fits its typical 5–8 for "Senior". The report is a market band, never Pellucid's offer to you | `[grounded]` JD figures and the Datawright 2026 pay report as provided (US, n=2,310) |
| Scope read | The report's typical scope is one domain's pipelines with no direct reports. This posting spans ingestion, warehouse and contracts, which reads as somewhat broader than one domain; it names no reports | `[inferred]` from the JD's three areas against the report's typical scope |
| Unknowns | Hiring manager, team size, on-call duty, equity terms, new role or backfill | `[grounded]` JD silent on each |
| Contradictions | The mandate says BigQuery, but the requirements ask only for "a cloud warehouse". BigQuery is probably a soft requirement, which is not confirmed | `[inferred]` from the JD's own wording |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver | hard_gate | unclear | none | hard_gate | Your location and work-authorization status are not stated, so the gate is not established | `[grounded]` JD; candidate constraints not given | Ask: Q1 below |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor is not stated; the range itself is in the JD | `[grounded]` JD; floor not given | Ask: Q1 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated by you; nothing inspected yet. Experience length is a requirement, not a gate | `[grounded]` your background, self-reported | A dated role history or LinkedIn would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated; no artifact seen | `[grounded]` your background, self-reported | A code sample or repo would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. The count is yours and no artifact was seen | `[grounded]` your background, self-reported | A sanitized model lineage or project screenshot would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The JD's mandate names BigQuery, which is R9 | `[grounded]` your background; JD wording | none |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow named as your orchestrator | `[grounded]` your background, self-reported | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite; coverage and results are unstated | `[grounded]` your background, self-reported | One sentence on what it caught would raise it |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake plus dbt carries over. Limit: you have never used BigQuery, so its cost and partitioning behaviour is unexercised. Warehouse-specific differences are the usual place interviewers probe a switch | `[inferred]` requirement from the JD mandate; `[grounded]` your Snowflake and dbt claim; `[generic]` the interviewer probe | See gap G1 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background says nothing on source systems | `[grounded]` background silent | See gap G2 |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Dbt tests and Great Expectations are adjacent. Nothing says you defined agreements with downstream consumers | `[grounded]` background silent on contracts | See gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt at scale, no BigQuery | The mandate names BigQuery, so it is the most likely objection | A personal or work dbt project run against BigQuery, including its free sandbox; Snowflake cost or clustering tuning that maps across | A short public repo or write-up | `[inferred]` bridge from Snowflake and dbt; `[generic]` that this is the likeliest objection |
| G2 | Ingestion from app and CRM sources (R10, important) | discovery | Nothing on sources or ingestion tooling | The JD lists ingestion first | Pulling product event data or a SaaS API such as a CRM into the warehouse; building or maintaining connectors; handling schema drift from an app team | A pipeline diagram or a README | `[grounded]` background silent |
| G3 | Data contracts (R11, important) | discovery | Tests exist; no stated agreements with consumers | The JD says analysts depend on them | Schema or freshness agreements with analysts; versioned models; alerts on breaking changes | A sanitized contract or test spec | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and reporting line unnamed | unknown | — | posting names no hiring manager (per your note) | The data function's seniority and your reporting line cannot be judged yet | `[grounded]` the posting as provided | Who would this role report to, and how large is the data team today? | unresolved |
| RR2 | "Build and run" scope undefined | unknown | — | "Build and run the pipelines" | Running may include on-call or sole ownership across ingestion, warehouse and contracts | `[inferred]` from the JD's wording; `[grounded]` the report's typical one-domain scope | Does this role own pipelines end to end, and is there an on-call rotation? | unresolved |
| RR3 | Pay stated and in line with the market | positive_signal | — | "$148,000–$166,000 plus equity" | The range straddles the market median; no seniority-pay mismatch | `[grounded]` JD figures and the Datawright report as provided | Where in the range would my experience place me? | noted |
| RR4 | Equity terms not given | unknown | — | "plus equity" | The grant type, size and vesting are unknown, so total compensation is not comparable | `[grounded]` JD silent | What is the equity grant type, size and vesting schedule? | unresolved |
| RR5 | New role or backfill unknown | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The wording could describe a new function or an existing one | `[inferred]` from the JD's wording | Is this a new position or a backfill? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the 180-model dbt project and the Great Expectations suite, stated with the figures you gave and no more | R5, R8 | `[grounded]` your background | pending your approval |
| W1 | A small public dbt project on BigQuery's free sandbox, to narrow the R9 limit with an inspectable artifact | R9, G1 | `[inferred]` from the gap | pending your approval |
| A1 | Confirm location and pay-floor fit before investing in the application | R1, R2 | `[grounded]` the R1 and R2 rows | pending your approval |
| Q1 | Ask the RR1, RR2, RR4 and RR5 questions verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent one search to check the pasted company and posting text. It was refused, so this host did not allow it. It would have confirmed the posting is live and the stage and size are current, and it fed role reality's organization and contradictions rows. Those rest on your pasted text |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration and the pay check, so a further search would add nothing to them |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

## Upgrade menu

- Your location and your pay floor → R1 and R2 move from `unclear` to `direct` or fail, and the status firms up.
- A BigQuery exercise or a public repo → R9 gets an inspectable artifact behind it, and its limit narrows.
- Examples of ingestion or contract-style work → R10 and R11 move off `unclear`.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- Permission to search, so the pasted company pages can be checked live → target 1 runs. A deeper pass on funding, leadership and recent news would take up to 5 more searches and 2 more fetches; say the word and it runs.

I can also write this up as a `tuesday-dossier.md` if you want a copy to keep.

Questions, in order of what could move the decision:

1. R1 and R2: do you live in the US or Denver, and does $148,000 base clear your pay floor?
2. G2: have you built or run ingestion from an app or a CRM into the warehouse, and what did you own?
3. G1: have you touched BigQuery at all, even in a side project?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.