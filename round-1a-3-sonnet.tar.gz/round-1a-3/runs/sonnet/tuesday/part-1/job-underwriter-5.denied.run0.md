The fetch of the careers page was denied, so I'm continuing from your pasted text and the pay report, and I'm not retrying the fetch.

**Is this worth it? Yes, worth applying to, on conditions: R1 and R2 are hard gates I can't confirm yet, and the employer check didn't run (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9 — a credible bridge, its limit named; R10 — your background is silent on app and CRM sources; R11 — your background is silent on contracts.

**Opportunity ledger.** The pay is posted and sits across the market's median and upper quartile (RR2). The employer and posting could not be checked from here (RR1), the scope may be wider than one domain (RR3), and the equity terms are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed against your location, work authorization and pay floor; (2) the role and employer verified live on the company's own careers page (RR1); (3) the BigQuery bridge framed as adjacent, never as BigQuery experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the About text you pasted; not independently checked |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Seniority read | 5+ years asked; your 6 years sits inside the 5–8 years the report calls typical for Senior | `[grounded]` JD and the Datawright report you supplied |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500, n=2,310. The posting's low end is $3,000 under the median, and its top is $2,500 over the 75th percentile. Treat the band as the market, never as this employer's offer | `[grounded]` the report you supplied; `[inferred]` that the posted salary is base |
| Scope read | The posting spans ingestion, warehouse modelling and contracts, where the report says typical scope is one domain's pipelines with no direct reports. It may be wider than usual, or one family of pipelines described broadly | `[inferred]` JD scope against the report (RR3) |
| Unknowns | Hiring manager (none named), team size, who owns what, on-call expectations behind "run", equity terms | `[grounded]` the JD is silent on each |
| Contradictions | None between the JD and the About text as pasted; neither was checked against the live site | `[grounded]` pasted material |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US; the posting's terms are plain | `[grounded]` JD; candidate side silent | Q1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given, so the range can't be tested against it | `[grounded]` JD; candidate side silent | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, self-reported with nothing inspected. A years requirement is not a gate | `[grounded]` your typed background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" rests on your word alone | `[grounded]` your typed background | A sanitized model or DAG would raise it to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models on Snowflake; confirmed in prose, nothing inspected | `[grounded]` your typed background | A sanitized lineage or docs screenshot would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | The requirement says "a cloud warehouse", and Snowflake is one. BigQuery specifically is R9 | `[grounded]` JD and your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named in your background, the same tool the JD names | `[grounded]` JD and your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite; scope and coverage unstated | `[grounded]` your typed background | A coverage summary or suite config would raise it to `high` |
| R9 | BigQuery (named in the role description, not the requirements list) | important | adjacent | medium | transferability | Carries over: dbt modelling and warehouse work on Snowflake. Limit: no BigQuery use. `[generic]` partitioning and pricing mechanics differ between the two warehouses | `[grounded]` JD and your background; `[generic]` on the differences | G1 |
| R10 | Ingestion from the app and the CRM | important | unclear | low | discovery | Six years of pipeline work suggests ingestion, but your sources are unstated | `[inferred]` from your pipeline work; sources unconfirmed | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your 180 models and test suite may involve contracts or schema agreements; nothing says so | `[inferred]` from your dbt and testing work | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Warehouse and dbt work carries over; BigQuery itself was never used | The JD names it in the role description, and a screen may probe it | A small dbt-on-BigQuery project; a migration or query-tuning task you did on any warehouse | A short sandbox repo with a README | `[inferred]` bridge from Snowflake work; `[generic]` that screens probe a named platform |
| G2 | App and CRM ingestion (R10, important) | discovery | Your background doesn't say which sources fed your pipelines | It is half the stated mandate | Product event streams; Salesforce or HubSpot syncs; API or webhook loads; HRIS or payroll-system feeds | An architecture diagram or DAG list, sanitized | `[grounded]` background silent on sources |
| G3 | Data contracts (R11, important) | discovery | Nothing says whether analysts relied on agreed schemas or tests | It is named in the mandate | Schema tests on model outputs; agreed column definitions with analysts; alerts on breaking changes | A sanitized schema-test config or an analyst-facing doc | `[grounded]` background silent on contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees." | The check that would confirm the employer and live posting did not run. The possibilities include a stale posting or a mismatch with the live site, none ranked likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay disclosed, in range | positive_signal | — | "$148,000–$166,000 plus equity" | The range straddles the report's median and upper quartile, and is stated openly | `[grounded]` JD and the report you supplied; `[inferred]` that it is base | Is the range base salary? | noted |
| RR3 | Scope may exceed one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One person may own ingestion, modelling and contracts, with team size and on-call unstated | `[inferred]` JD scope against the report's typical scope | How many data engineers and analysts are there, which of ingestion, warehouse and contracts does this role own, and is there an on-call rotation? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Type, vesting and size are not given | `[grounded]` JD silent | What equity is granted at this level, and on what vesting schedule? | unresolved |

## Application plan

Every row is proposed; nothing here, including the advice in prose, is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up | see R5, R8 | `[grounded]` your background | pending your approval |
| E2 | State Snowflake plainly and name BigQuery as a platform you are moving to, not one you've used | see R9 | `[grounded]` your background | pending your approval |
| W1 | A small dbt-on-BigQuery sandbox project as a work sample | see G1 | `[inferred]` from the R9 bridge | pending your approval |
| A1 | Open the role from the company's own careers page yourself before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1, RR3 and RR4's questions verbatim in the first conversation | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The one fetch, of the senior-data-engineer careers page, was refused, so nothing was read. It would have settled RR1 and the contradictions row, and is why the decision stops at `conditional_go` |
| 2. Role-family sweep | skipped | The Datawright report you supplied already fixes market calibration and the pay check in RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there was no query to form |

## Closing

I can save this as `tuesday-dossier.md` to carry forward, if you'd like.

**Upgrade menu**
- Your location, work authorization and pay floor → R1 and R2 close.
- The live careers-page text, or permission to fetch it → RR1 closes and the cap on the decision lifts.
- The hiring manager's name → the scope read and which story the plan leads with.
- A sanitized lineage screenshot, suite config or DAG list → R5, R8 and R4 toward `high`, and R10 and R11 firm up.
- A BigQuery sandbox project → R9 narrows.
- A deeper research pass (funding, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) → RR1 and the register; say the word and it runs.

**Questions**
- Q1 (R1): Are you in the US with authorization to work there, and would you take remote or Denver?
- Q2 (R2): What base salary is your floor?
- Q3 (R10): What sources fed your payroll-company pipelines, and did any come from a product app or a CRM?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.