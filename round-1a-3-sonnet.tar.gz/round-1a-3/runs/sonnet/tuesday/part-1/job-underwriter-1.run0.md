Harborlight's careers page and the market band are unchecked: both web searches were refused, so those parts rest on the posting and your summary alone.

## Decision snapshot

**Yes, apply. You are a fit on the core of the role: R1, R2, R3, R4 and R5 are each `direct`, and R6 (the metrics layer) is the one open must-have. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (metrics layer)
- `important` — direct: R7a · unclear: R7b (clinicians), R8 (mentoring junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

R6 — Looker governance points toward it, but a metrics layer isn't stated; R7b and R8 — your summary is silent; R9 (`medium`) — a credible bridge, its limit named.

**Opportunity ledger.** The employer is unchecked (RR1) and pay and location are withheld (RR2). The responsibilities are specific, with named partners (RR3), and it's unknown whether a metrics layer exists or you'd build one (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify on Harborlight's own careers site (RR1); (2) the metrics-layer question resolves (R6, RR4); (3) the HIPAA bridge is framed as adjacent, never as healthcare experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` JD header, not independently checked |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve dashboards, roadmap partnership, mentoring two junior analysts | `[grounded]` JD |
| Stated requirements | 5+ years product analytics; expert SQL; experiment design at scale; Looker or similar; written communication with non-technical stakeholders; healthcare data (HIPAA) a plus | `[grounded]` JD |
| Scope read | A senior individual-contributor post with informal mentoring of two juniors, not an explicit people-manager title | `[inferred]` from "mentor two junior analysts" with no reporting-line language |
| Market calibration | Not established: the role-family search was refused, and a pay band isn't offered from memory | `[generic]` no band stated |
| Unknowns | Pay; location or remote terms; whether a metrics layer exists; the experimentation platform; reporting line; hiring manager | `[grounded]` JD silent on each |
| Contradictions | None between the JD and your summary; the careers page was not checked | `[grounded]` the two inputs compared |

## Evidence map

Your background was typed into the conversation, so it counts as self-report, and `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, confirmed and specific, with nothing inspectable yet | `[grounded]` your summary | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake over six years; "expert" is a self-grade, which an interviewer will probe | `[grounded]` your summary | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran a 30+ tests a year program, including the pricing test behind an 11% retention lift, on a base of about 2M subscribers | `[grounded]` your summary | A sanitized readout of the pricing test would raise it to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the Looker instance from scratch, 40+ governed dashboards | `[grounded]` your summary | A screenshot or sanitized LookML would raise it to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo the exec team reads; monthly presentation to the VP Product | `[grounded]` your summary | A sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggest metric definitions, and you built a consent-state model for the warehouse, but a shared metrics layer is not stated. Low, not none, because there is a thread to pull | `[grounded]` your summary's silence on metric definitions; `[inferred]` that governance implies some definition work | G1 |
| R7a | Partner with product managers | important | direct | medium | none | Monthly presentation to the VP Product, plus the test program run with product teams | `[grounded]` your summary | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your summary involves clinical stakeholders | `[grounded]` your summary's silence | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your summary does not mention mentoring or managing anyone | `[grounded]` your summary's silence | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Handled GDPR and CCPA consumer PII and built the warehouse's consent-state model. Limit: no health data, no HIPAA, no covered-entity or business-associate experience. Teams hiring in regulated health data often screen on this term, though it is listed as a plus | `[grounded]` your summary; `[generic]` screening pattern | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed Looker dashboards and a consent-state model; no stated shared metric definitions | The one open must-have; resolving it likely firms up `conditional_go` | LookML measures others reused; a metric dictionary or a retention or churn definition that teams standardized on; reconciling conflicting numbers between teams; a dbt or semantic-layer project | A metric dictionary page, sanitized LookML, a definition doc | `[grounded]` summary silent on shared definitions; `[inferred]` that this moves the decision |
| G2 | Mentoring junior analysts (R8, important) | discovery | No mention of mentoring or managing | The role names two juniors, so an interviewer will ask for examples | Onboarding a new analyst; reviewing others' SQL or test designs; running an analytics guild; informal coaching | None needed; a short description is enough | `[grounded]` summary silent; `[generic]` that such roles probe this |
| G3 | Clinician partnership (R7b, important) | discovery | Stakeholders named are the exec team and the VP Product | The posting says analysis feeds roadmap decisions with clinicians, a stakeholder type you haven't mentioned | Working with domain experts such as ops, support or nutrition or culinary staff; translating a technical result for a specialist who owns the outcome | A short example | `[grounded]` summary silent; `[inferred]` that domain-expert partnership is the nearest analogue |
| G4 | HIPAA / healthcare data (R9, preferred) | transferability | Consent-state modeling and GDPR/CCPA PII handling | Preferred, so a minor risk. The bridge helps if its limit is stated | What carries over: consent and access governance, PII handling. What doesn't: PHI, minimum-necessary rules, BAAs, health-data audit practice. A strengthener would be a short HIPAA primer course | A consent-state schema diagram or doc, sanitized | `[grounded]` your summary; `[inferred]` bridge limits |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The search that would have checked this was refused, so nothing is confirmed either way. The employer may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location withheld | unknown | — | "Senior Product Analyst" (the JD states neither) | The posting may omit them, or they may sit below your floor or outside your location | `[inferred]` from the JD's silence | What is the budgeted salary range, and is the post remote or hybrid? | unresolved |
| RR3 | Scoped responsibilities with named partners | positive_signal | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | Scope looks defined and the success path is plausible | `[grounded]` JD | Who owns the decisions this analysis feeds? | noted |
| RR4 | Metrics layer: existing or to be built | unknown | — | "define and maintain the metrics layer" | The role may inherit a layer or be building one from scratch, which changes seniority and effort | `[inferred]` from "define and maintain" read both ways | Is there a metrics layer today, and who maintains it? | unresolved |

## Application plan

`resume_edits_pending_approval` — every row below is a proposal, built from your own sentences, and nothing is applied until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program: "designed and ran 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | See R3 | `[grounded]` your summary | pending your approval |
| E2 | Pair the Looker line with governance: "built the company's Looker instance from scratch, 40+ governed dashboards" | See R4, R6 | `[grounded]` your summary | pending your approval |
| E3 | Present the consent-state model and GDPR/CCPA PII handling as the data-governance bridge, and state plainly that you have no healthcare or HIPAA experience | See R9 | `[grounded]` your summary | pending your approval |
| Q1 | Ask RR1 through RR4's verification questions verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the posting on Harborlight's own careers site before sending anything | See RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search was sent and refused for lack of permission. It would have fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search was sent and refused for the same reason. It would have fed the market calibration row and any pay mismatch entry |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you'd like a saved `tuesday-dossier.md` of this assessment to carry into later steps, say so and I'll produce it.

## Upgrade menu

- Granting web-search permission lets me rerun targets 1 and 2, which would close or confirm RR1 and set the posting against a market band.
- Your actual resume would replace self-report with a document and could firm up R1 through R5.
- A sanitized pricing-test readout would take R3 to `high`; a Looker screenshot or LookML snippet, R4 (and R6 if it shows shared metric definitions); a sample monthly memo, R5; a consent-state schema, R9.
- The hiring manager's name unlocks a scope read and which story to lead with.
- The posting link or any pay or location detail would settle RR2.

## Questions

G1 — Have you defined or owned metrics that several teams used (for example, one definition of retention or churn that dashboards and tests all pointed at, in LookML or a doc)? What did you own, and did the definitions last?

G2 — Have you mentored, onboarded or reviewed the work of other analysts, even informally? What did that involve?

Constraints — Do you have non-negotiables on pay, location or remote work, or work authorization that this role would need to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.