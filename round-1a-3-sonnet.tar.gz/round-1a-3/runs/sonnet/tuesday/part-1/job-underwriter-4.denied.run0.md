I've read the job-underwriter playbook and its reference files. Next I'm loading the search tool so I can check that Brindlemoor exists and that the posting is live, and read the research-tier rules.
## Decision snapshot

**Yes, apply, but on conditions rather than unconditionally. Status: `conditional_go`.** Your core evidence meets the posting in R2, R3, R4, R5, R6 and R7. The status is capped because the employer is unverified (RR1) and the "fully remote (UK)" term is unconfirmed (R1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain)

R6 (`medium`) — "ran" the tests, with design ownership still to state; R8b — nothing shown yet on the product side; R10 — a credible bridge, its limit named.

**Opportunity ledger.** The mandate is concrete (RR4), but the employer is not yet established (RR1), no pay is stated (RR2), and team shape and reporting lines are unknown (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) UK location and right to work are confirmed on both sides (R1); (3) you frame pet insurance as adjacent (R10) and product recommendations as not yet evidenced (R8b), never as experience you have.

Not having managed anyone is not a gap on this map. The posting lists no people-management requirement, so it has no row. Whether the role carries direct reports is an unknown (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD header; not independently checked |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Hands-on senior individual-contributor scope; no team, headcount or direct reports stated | `[inferred]` from the JD's silence on reports against its "own" wording |
| Domain read | Pet and motor are both personal-lines products where GLM rating on risk characteristics is a common approach, so your method carries over while the pet rating factors are new | `[generic]` role-family pattern, no search run |
| Market calibration | Not established: no search ran, so there is no pay band to set against the role | — |
| Unknowns | Salary; team size and direct reports; first-year outcomes; the contract basis | `[grounded]` absent from the pasted JD |
| Contradictions | None found within the JD and your background; the JD was not checked against the company's own pages | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but residence and right to work in the UK are not stated, and you gave no constraints | `[grounded]` your background; `[inferred]` UK presence from the employer's location | Ask G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, the last two as senior analyst; stated and specific, with no inspectable artifact yet | `[grounded]` your background, self-reported | none |
| R3 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book; "maintained" covers the monitoring side | `[grounded]` your background, self-reported | A model-governance or monitoring summary, sanitised, would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Same evidence as R3, specific and confirmed in prose | `[grounded]` your background | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use is stated; "strong" is a level no one has probed | `[grounded]` your background | A code sample or a pipeline description would raise it |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 tests last year with underwriting. "Ran" does not say whether you designed them (hypothesis, sizing, control) or only executed them, so expect a probe | `[grounded]` your background | Be ready to state which design and read decisions were yours |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | Your tests were run with the underwriting team and reviewed with their head | `[inferred]` from the pricing review and the tests | none |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Your background names underwriting and no product function | `[grounded]` silence in your background | Ask G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (you flagged none; the JD does not require it) | preferred | adjacent | low | transferability | Your GLM and test work transfers. The limit: you have not worked with pet rating factors, vet-cost trends or claims patterns | `[inferred]` bridge from your motor work; requirement stated by you, not by the JD | Make the bridge case with its limit named, and read up on pet pricing before any interview |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location and right to work (R1, hard_gate) | hard_gate | The JD says fully remote, UK; your background implies a UK employer but states neither residence nor right to work | A failed gate would end the application, and an unconfirmed one keeps the decision at `conditional_go` | Not applicable: the gate is a fact, not an experience | Nothing to attach | `[grounded]` the JD's term; `[inferred]` UK presence |
| G2 | Recommendations for product (R8b, important) | discovery | Your work is described against underwriting, with no product team named | The role names product as a second audience, so it is the one named duty with no evidence | A test result that changed a product feature, a cover tier or a proposition; a pricing paper for a product or commercial team; a pricing-versus-volume trade-off you explained to a non-underwriter | A pricing-review deck excerpt or a one-page recommendation note, sanitised | `[grounded]` silence in your background; `[inferred]` that it could move R8b |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | No search ran, so nothing here confirms the employer or that the posting is live. It may be new or small, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | No pay figure appears in the pasted JD | The figure may sit anywhere relative to your expectations; no market band was established to compare it with | `[inferred]` from the posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Team shape and authority unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the sole pricing analyst for the product, with no stated team, decision rights or direct reports | `[inferred]` from "own" against silence on team and authority | Who else is on the pricing team, which price changes does this role decide, and are there direct reports? | unresolved |
| RR4 | Concrete mandate | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The duties are named and map onto defined outputs, so success should be assessable | `[grounded]` JD | What would a strong first six months look like? | noted |

## Application plan

Every row is proposed and waits for your approval, the prose advice in the Notes column included. Nothing here becomes CV language or outreach until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| V1 | Find the role on the company's own careers page, and get the interviewer's details from there rather than from any message you receive | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with the young-driver GLM build and maintenance, the 14 price tests, and the quarterly review to the head of underwriting | see R3, R4, R6, R7 | `[grounded]` your background | pending your approval |
| E2 | Describe pet insurance as adjacent: the same GLM and test method on a new line of business, with the pet-specific factors named as what you would learn | see R10 | `[inferred]` bridge, limit named | pending your approval |
| P1 | Prepare a plain answer on management: you have not managed anyone, the posting lists no such requirement, and you can describe how you led work without authority | see RR3 | `[grounded]` your background and the JD | pending your approval |
| Q1 | Ask the questions of RR1, RR2 and RR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported and sits at `medium`; none of it has been confirmed against an artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Brindlemoor pet insurance" and "Brindlemoor careers Senior Pricing Analyst" were refused because search permission was not granted. It would have moved RR1 and the Organization and Contradictions rows of role reality |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst pet insurance UK salary remote" was refused. It would have moved the market-calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have moved the scope read and the positioning in E1 |

Because the searches were refused, the employer's status is unknown, not negative.

I can save this as a `tuesday-dossier.md` if you want a file to carry forward.

## Upgrade menu

- Search permission, so the three L1 targets can run: this would close or confirm RR1, add a pay band against RR2, and sharpen the scope read.
- A sanitised model-governance or monitoring note: R3 to `high`.
- A one-page pricing recommendation that reached a product or commercial audience: R8b and G2 close or narrow.
- Your UK location and right to work, and your pay floor: R1 resolves, and a pay comparison becomes possible.

## Questions

1. **G1** — Are you UK-resident with the right to work there without sponsorship? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G2** — Has a test result or pricing view of yours gone to anyone outside underwriting, such as product, commercial or finance, and what changed because of it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **Constraints** — Do you have a pay floor, or any other non-negotiables (contract type, notice period, start date)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.