Checking the employer's careers page, because the search snippet says Leeds office four days a week and your JD says fully remote.
# Job Underwriting — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Should you go for it? Not yet. Your fit looks sound, but the posting and the employer's careers page disagree about where the job is done, and that has to be settled first. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · adjacent: R5b (Monitor rating models)
- `important` — unclear: R8 (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain)

R1 — the posting and the careers page disagree; R5b — adjacent, limit named; R8 — nothing in your background yet.

**Opportunity ledger.** The working-pattern contradiction is the live issue (RR1). The salary is withheld (RR2) and the team and decision rights are not described (RR4). The mandate is clearly stated and sits under a named director (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Awaited answers:** (1) whether you can work from Leeds four days a week, if that is the real arrangement — R1; (2) Brindlemoor's confirmation of the working pattern — RR1, R1; (3) the salary range — RR2.
- **What would change this:** confirmed fully remote, which likely moves it to `go` or `conditional_go`. Confirmed Leeds four days a week, with that unworkable for you, makes it `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling a pet-insurance product; the role is live on its careers page | `[grounded]` JD; careers page fetched |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | The Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". The two sources contradict each other | `[grounded]` both sources, quoted |
| People management | The JD does not mention managing anyone | `[grounded]` JD silent |
| Compensation | Not stated in the JD or on the careers page | `[grounded]` both silent |
| Market calibration | UK senior pricing analysts at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612). This is a survey band, not Brindlemoor's offer, and it is not specific to pet insurance. Only the search snippet was read, not the full survey | `[generic]` Pricewell 2026 survey |
| Scope read | One product's pricing analytics under a director, with no direct reports mentioned. This reads as an individual-contributor senior post | `[inferred]` from the JD's silence on reports and its "own pricing analytics" wording |
| Hiring manager's public footprint | Odile Varga spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors") on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years. Only the search snippet was read | `[grounded]` profile snippet; professional footprint only |
| Unknowns | Salary; team size; who decides rating changes; first-year outcomes; the real working pattern | — |
| Contradictions | JD against careers page on location, as above (RR1) | `[grounded]` both sources |

## Evidence map

Your background is typed prose, so it carries the standing of a CV: self-report, `medium` at most until something is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says remote and the careers page says Leeds four days a week, so the role's terms are unsettled. You have not stated a location or office-days constraint, so there is no statement to grade | `[grounded]` the two quoted sources; no candidate constraint given | RR1's question to Brindlemoor, plus your own answer to the Leeds question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer, 2 of them as senior analyst. Specific, but not yet inspected | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Specific, no artifact yet | `[grounded]` your stated background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, not inspected | `[grounded]` your stated background | none |
| R5a | Build rating models | must_have | direct | medium | none | You built the young-driver GLM, which is the same activity. The carry-over to a pet book is not tested here (see R10) | `[grounded]` your stated background | none |
| R5b | Monitor rating models | must_have | adjacent | low | discovery | You said "maintained". Maintaining a model is near monitoring it, but your account does not say what was tracked. Low is the lower of two plausible bands | `[grounded]` your wording; `[inferred]` that maintenance plausibly included some tracking | G1 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with underwriting. "Ran" does not say whether you designed them, so that is carried as a likely probe | `[grounded]` your stated background; `[generic]` that "design" is commonly probed apart from "run" | Confirm in your next answer or in an artifact |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Actuarial leads are not mentioned, and the JD says "or" | `[grounded]` your stated background and the JD wording | none |
| R8 | Turning results into recommendations for product | important | unclear | low | discovery | The JD names product as an audience. Your account names underwriting only, so nothing is established either way | `[grounded]` JD quote; your account silent on product | G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your stated background | none |
| R10 | Pet-insurance domain knowledge (implied by the product, not a stated requirement) | preferred | adjacent | medium | transferability | Your GLM rating work is on a motor book and you have not worked on pet insurance. What carries over is the rating-model craft. The limit is that pet-specific rating factors have not been exercised. Pet pricing typically rates on things like breed and age | `[inferred]` requirement derived from the product named in the JD; `[generic]` typical pet rating factors | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R5b, must_have) | discovery | "Maintained" the young-driver GLM, with no detail on what was tracked or acted on | A must-have at `adjacent`. The hiring manager's public talk is on monitoring rating models, so this is where a probe is likely | Tracking actual against expected loss ratio after launch; drift or segment checks; deciding when to refit; a monitoring pack someone else read | A sanitized monitoring report, a refit note, or a dashboard screenshot | `[grounded]` your wording and the talk title; `[inferred]` that a probe is likely here |
| G2 | Recommendations for product (R8, important) | discovery | Your underwriting work is described. Nothing mentions a product team | The JD lists product as a second audience, and it is the only part of the mandate with no evidence from you | Taking a price-test result to a product owner; informing a product or feature change from rating analysis; a joint paper with product | A recommendation memo or deck extract (sanitized) | `[grounded]` JD and your account's silence |
| G3 | Pet-insurance domain (R10, preferred) | transferability | Motor GLM work, no pet work | Preferred only, so a bridge case is enough. It must not be framed as pet experience | Rating-factor work on a personal-lines book with similar sparse segments; any exposure to veterinary-cost or claims-cost data | A short note on how you would adapt your model to pet rating factors | `[inferred]` bridge from your motor GLM work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (see R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | One source may be out of date, for example the careers page not yet updated. I can't tell which from here | `[inferred]` from the two quoted sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Compensation not stated | unknown | — | JD gives no figure | The figure may sit anywhere in the survey band in role reality, or the employer may simply not publish pay | `[generic]` band from the Pricewell survey; `[grounded]` the JD's silence | What is the salary range for this post? | unresolved |
| RR3 | Clearly stated mandate under a named director | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | Scope is defined at the level of one product, and a named senior owner sits above the role | `[grounded]` JD and careers page | What does success in the first year look like for this role? | noted |
| RR4 | Team and decision rights not described | unknown | — | "Own pricing analytics…" with no mention of team or authority | The role may recommend rating changes rather than make them | `[inferred]` from the JD's scope wording against its silence on decision rights | Who signs off rating changes, and who else is on the pricing team? | unresolved |

## Application plan

All rows are proposals pending your approval. Any wording you would say or send traces to your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern before investing in the application. Ask the question in RR1 through contact details found on Brindlemoor's own site | R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your three own statements, in your own wording: you built and maintained the GLM rating model for the young-driver book; you ran 14 price tests last year with the underwriting team; you present the quarterly pricing review to the head of underwriting | R4, R5a, R6, R7 | `[grounded]` your stated background | pending your approval |
| A3 | If asked about pet insurance, say plainly that you haven't worked on it and that your rating work is on a motor book. Do not call monitoring work more than "maintained" until G1 is answered | R10, R5b | `[grounded]` your stated background | pending your approval |
| A4 | Be ready to describe exactly what you checked on the young-driver model after launch, because the hiring manager has spoken publicly about monitoring rating models | R5b | `[grounded]` profile snippet; `[inferred]` that it will come up | pending your approval |
| A5 | Don't volunteer or imply management experience. The JD does not ask for it, and you have none | JD silent | `[grounded]` JD silent; your statement | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating. No separate CV was provided; your typed background is treated as CV-equivalent.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It shows the role is live and surfaced the working-pattern conflict, which fed role reality, R1 and RR1. The employer is established as hiring, so there is no failed-attribution entry |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. It fed the market calibration line and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. It fed the scope read, G1 and plan row A4 |

## Dossier offer

I can save this as a `tuesday-dossier.md` if you want to carry it into later steps. It's optional.

## Upgrade menu

- Your CV, or a sanitized model document or monitoring report for the young-driver GLM, would let R4, R5a and R5b reach `high`.
- A test-design write-up for one of the 14 price tests would settle R6.
- Your location and any non-negotiables (pay floor, office days) would turn R1 and the candidate-constraint checks into real answers.
- Brindlemoor's answers on working pattern and salary would close RR1 and RR2.
- A deeper research pass on Brindlemoor (funding, hiring pattern, public employee reports, recent news; up to 5 more searches and 2 more fetches) will run if you say the word.

## Questions

G0 (R1) — Where are you based, and could you work from a Leeds office four days a week if that is the real arrangement? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 (R5b) — After the young-driver model went live, what did you personally track and act on (for example actual against expected loss ratio, drift, when to refit)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 (R8) — Have you ever taken a pricing or price-test result to a product team, and what changed as a result? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.