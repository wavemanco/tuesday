I'm checking that the posting is live on Pellucid's careers page, and I've finished reading the playbook files. After that I'll write the assessment.
**Is this worth applying to? Yes, on conditions.** R3, R4, R5, R6, R7 and R8 all come out `direct`, and the stated pay is in line with your recruiter's report. The open items are R1 and R2 (your location and pay floor) and whether the posting is live (RR1). Status: `conditional_go`.

One thing didn't run. I tried to fetch the careers page to confirm the posting is live, but the fetch was never approved, so I haven't verified it. I haven't retried.

# Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9: a credible bridge with its limit named; R10 and R11: your background is silent on them; R1 and R2: open until your location and pay floor are on the table.

**Opportunity ledger.** The pay is stated and sits inside the market report's range (RR5). The posting could not be checked from here (RR1), the manager and team are unnamed (RR2), the equity is unquantified (RR3), and the scope could be wide for one hire (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and work authorization fit R1 and your pay floor fits R2; (2) the live posting verifies, see RR1; (3) the BigQuery gap (R9) is stated openly as adjacent, never glossed.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about page text you pasted |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Seniority and scope | 5+ years; no direct reports mentioned. This matches the report's typical "senior" scope of one domain's pipelines with no reports, though ingestion, modelling and contracts together could be broader (RR4) | `[inferred]` JD against the pasted report's scope line |
| Market calibration | Report: Senior Data Engineer at Series B–D, base median $151,000, interquartile range $139,000–$163,500, usually 5–8 years. The posting's $148,000 low end is below that median and its $166,000 top is above the 75th percentile. This is the market band, never Pellucid's offer beyond the posting's own figure | `[grounded]` the Datawright report you pasted and the JD figure; `[inferred]` the comparison |
| Location | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Hiring manager and team; equity terms; first-year outcomes (none stated); who owns data contracts today | `[grounded]` JD silence |
| Contradictions | JD and about page give no conflict; the live careers page was not checked | `[grounded]` pasted text; fetch not completed |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't stated, so the gate is neither met nor failed | `[grounded]` JD; no candidate statement | G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given; the band is clear, but equity terms are not stated | `[grounded]` JD; no candidate statement | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years of data engineering at a B2B payroll company; prose self-report, no inspectable artifact yet | `[grounded]` your intake message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily"; depth beyond daily use is untested | `[grounded]` your intake message | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake; a repo or docs site would make this inspectable | `[grounded]` your intake message | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; the BigQuery question is carried separately in R9 | `[grounded]` your intake message | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration; scale and your ownership of it weren't stated, so expect a probe | `[grounded]` your intake message | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite | `[grounded]` your intake message | none |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The same dbt practice on Snowflake carries over; limit: you have never used BigQuery, so its specifics are unexercised, and warehouses usually differ in cost and physical-design levers | `[grounded]` your statement; `[generic]` the warehouse-differences clause | G4 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say what sources you ingested | `[grounded]` background silence | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your background is silent on contract-style agreements with analysts | `[grounded]` background silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay fit (R1, R2) | hard_gate | No statement of where you live, your work authorization, or a pay floor | These gates decide whether any effort is worth spending | A US address or relocation plan; a salary floor you would not go below | Your stated floor and location | `[grounded]` no statement given |
| G2 | App and CRM ingestion (R10) | discovery | Payroll work is described, but not what systems fed your pipelines | It is half the role's mandate, and the answer could move R10 to `direct` | Loading from a product database or event stream; a CRM sync such as Salesforce or HubSpot; a vendor API feed | A DAG listing or architecture sketch (sanitized) | `[grounded]` background silence; `[inferred]` that it could move R10 |
| G3 | Data contracts (R11) | discovery | Nothing on agreements with analyst consumers | The JD names contracts as something analysts "depend on" | Schema or SLA agreements with analysts; dbt model contracts or tests tied to a consumer; a deprecation process | A sanitized contract doc or dbt YAML | `[grounded]` background silence |
| G4 | BigQuery (R9) | transferability | Strong Snowflake and dbt evidence; no BigQuery use | The one named-stack gap on the JD | Anything on BigQuery, including a side project | A small dbt-on-BigQuery project | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver." | My check of the careers page did not complete, so liveness is unconfirmed. Possible reasons sit side by side: the posting may be stale, aggregated, or not a current hiring page | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager and team unnamed | unknown | — | "The posting names no hiring manager" (your note) | Reporting line and team size are unknown | `[grounded]` posting silence | Who would this role report to, and who else is on the data team? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Type, amount and vesting are unstated | `[grounded]` JD silence | What is the equity grant: type, amount, vesting and valuation basis? | unresolved |
| RR4 | Breadth of scope for one role | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | Ingestion, modelling and contracts together could exceed one domain's pipelines; severity kept at the lower value since the JD doesn't say it is a solo post | `[inferred]` JD scope against the report's typical-scope line | How many data engineers are on the team, and who owns each part of this mandate? | unresolved |
| RR5 | Pay stated and in line with the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is not withheld; the band spans the report's median and tops its 75th percentile | `[grounded]` JD and the pasted report | Where in the band would a hire with six years land, and what sets it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle R1 and R2 (location, authorization, pay floor) before spending effort | see G1 | `[grounded]` R1, R2 | pending your approval |
| A2 | Resume line: "Built the dbt project at a B2B payroll company: about 180 models on Snowflake." Every clause traces to your own sentences | see R5 | `[grounded]` your intake message | resume_edits_pending_approval |
| A3 | Cover-note line: "My warehouse experience is Snowflake with dbt; I haven't used BigQuery." Traces to your statement | see R9 | `[grounded]` your intake message | pending your approval |
| A4 | A small dbt project on BigQuery to narrow the R9 limit | see G4 | `[generic]` role-family pattern | pending your approval |
| A5 | Ask RR1–RR4's questions verbatim in the loop | the register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A fetch of the careers page was sent but never approved, so no page returned. It would have moved the contradictions row and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration line, the scope read and RR5, so a search would add nothing |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can offer to write the dossier file (`tuesday-dossier.md`) if you want to carry this assessment forward.

## Upgrade menu

- Your location, work authorization and pay floor → R1 and R2 settle, and the decision likely simplifies to `go` or `no_go`.
- The careers page text pasted in, or fetch access → RR1 closes and role reality's contradictions row fills.
- A sanitized dbt repo or docs listing, a Great Expectations config, or an Airflow DAG listing → R5, R7 and R8 move toward `high`.
- Answers to G2 and G3 → R10 and R11 resolve.
- The hiring manager's name → role reality's scope read and which verified story to lead with.
- A deeper research pass on Pellucid Learning (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Where are you based, are you authorized to work in the US, and what is the lowest base you'd accept?
G2 — Have you ingested data from a product app and a CRM (a product database, event stream, or a Salesforce/HubSpot-type system)? What did you own?
G3 — Did you ever agree schemas, freshness or SLAs with analysts who depended on your models, and how were they enforced?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.