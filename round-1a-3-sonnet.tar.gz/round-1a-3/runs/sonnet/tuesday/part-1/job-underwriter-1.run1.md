Web search wasn't permitted in this session, so I worked from the JD and your background alone. The assessment is below.

## Decision snapshot

**Yes, apply, on conditions. Your must-have fit is strong: R1, R2, R3, R4 and R7, the `must_have` rows, are all `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R7
- `important`: adjacent: R6a (Partner with PMs to turn analysis into roadmap decisions) · unclear: R5 (Define and maintain the metrics layer), R6b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R5 (`low`) is likely closeable with one answer; R8 (`none`) is silent in your background; R9 (`medium`) is a credible bridge with its limit named.

**Opportunity ledger.** Sound on its face but unverified. The employer could not be checked from here (RR1), pay and location are unstated (RR2), and success measures and team structure are unstated (RR3). The posting does name concrete duties and two mentees (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the posting verify as live on Harborlight's own careers page (RR1); (2) pay and location, once known, fit your own limits (RR2); (3) mentoring and clinician partnership are framed as gaps or adjacent work, never as experience you don't have (R8, R6b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C | `[grounded]` JD header; the employer itself is unchecked (RR1) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve dashboards, partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Working pattern and pay | Location, remote policy and compensation not stated | `[grounded]` JD silent |
| Scope read | A senior individual-contributor role with a mentoring remit ("mentor", not "manage"); no reports are named | `[inferred]` from the JD's verbs |
| Market calibration | Not run, because the role-family search was refused. No pay band is offered, and the posting withholds one | `[grounded]` JD silent on pay |
| Unknowns | Pay, location, success measures, experimentation platform and traffic volume, who owns metric definitions today | — |
| Contradictions | None found between the JD and your account; the careers page was not checked | `[grounded]` JD and your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company of about 2M subscribers. No CV has been inspected, so this stays at `medium` | `[grounded]` your message | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake across six years. "Expert" is your own rating and no artifact backs it yet | `[grounded]` your message | offer: a sanitized complex query or data model would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD doesn't define "at scale", so the match is read against your subscriber base | `[grounded]` your message; `[inferred]` on the "at scale" reading | offer: a sanitized experiment readout would raise to high |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your message | offer: a dashboard screenshot or LookML sample would raise to high |
| R5 | Define and maintain the metrics layer | important | unclear | low | discovery | A from-scratch Looker build with "governed" dashboards suggests metric definitions were yours. You haven't said you defined or maintained a shared metrics layer, so this is an inference, not a claim | `[inferred]` from the Looker build and "governed" | see G1 |
| R6a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present to the VP Product monthly and the pricing test produced a result. You haven't said that analysis changed a roadmap decision | `[grounded]` your message | an example where your analysis changed a product or pricing decision |
| R6b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background touches clinical stakeholders | `[grounded]` your message silent | see G3 |
| R7 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads. That executives are non-technical readers is a reading, not something you said | `[grounded]` your message; `[inferred]` on the audience | offer: a sanitized memo would raise to high |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring or onboarding | `[grounded]` your message silent | see G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer-PII handling and the warehouse consent-state model carry over as privacy governance. The limit is that you haven't worked with health data or HIPAA, which is a separate regime with its own rules | `[grounded]` your message; `[generic]` that HIPAA differs from GDPR/CCPA | say plainly you have no healthcare experience and point to the consent-state model |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, important) | discovery | A from-scratch Looker build, but no stated ownership of shared metric definitions | The JD lists it first among duties, so how it's framed shapes the application | Defining a canonical retention or churn metric; LookML models or a metrics glossary others reused; resolving disputes over a number's definition | A LookML excerpt, a metric dictionary, or a governance doc | `[grounded]` your message silent on definitions; `[inferred]` that it likely exists |
| G2 | Mentoring junior analysts (R8, important) | discovery | No mentoring mentioned | A named duty, and an interviewer will ask for an example | Onboarding a new analyst; code or query reviews; coaching someone through their first experiment | A name-free description of what you did | `[grounded]` your message silent; `[generic]` that senior analyst loops usually probe this |
| G3 | Clinician partnership (R6b, important) | discovery | Nothing in your background touches clinical stakeholders | The domain is care navigation, so this is the likeliest unfamiliar part | Working with any domain expert (e.g. nutrition or culinary teams) to turn their judgment into a metric or test | A brief or readout shaped by a domain expert | `[grounded]` your message silent |
| G4 | Healthcare and HIPAA data (R9, preferred) | transferability | Consent-state model and GDPR/CCPA handling | It's a plus, not a requirement, but it's the gap interviewers will name first | Your consent-state model, covering data access and retention, as the bridge. Limit: no health data or HIPAA | A short description of the consent-state model | `[grounded]` your message; `[generic]` that HIPAA is distinct |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer. Research was refused, so none of these is ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Pay, location and work arrangement unstated | unknown | — | "Senior Product Analyst — Harborlight Health" (no terms given) | Terms may sit outside your limits, or may simply not be published | `[inferred]` from the JD's silence | What is the pay band, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Success measures and team structure unstated | unknown | — | "Own product analytics for our care-navigation app" | Accountability may be broad with no stated definition of success | `[inferred]` from the scope language against silence on outcomes | What would a successful first year look like, and who do the two analysts report to today? | unresolved |
| RR4 | Concrete duties and a named team | positive_signal | — | "mentor two junior analysts" | Role scope appears defined, with a team in place | `[inferred]` from the specificity of the duties | Who owns metric definitions today, and how are experiments prioritized? | noted |

Under `conditional_go`, RR1 is the standing entry that caps the status until the employer and posting verify.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program (30+ A/B tests a year; the pricing test behind an 11% retention lift) and the Looker build (40+ governed dashboards), using your figures exactly as given | see R3, R4 | `[grounded]` your message | `resume_edits_pending_approval` |
| E2 | Name the consent-state model and your GDPR/CCPA handling as privacy work. Do not claim healthcare or HIPAA experience | see R9 | `[grounded]` your message | `resume_edits_pending_approval` |
| W1 | Prepare one sanitized monthly metrics memo as a writing sample | see R7 | `[grounded]` your message | pending your approval |
| Q1 | Ask RR1 to RR4's verification questions verbatim, in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the posting is live on Harborlight's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "Senior Product Analyst digital health salary range experimentation Looker scope team lead"; the call was refused. It would have moved the market calibration row and any pay mismatch entry |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd suggest the dossier, `tuesday-dossier.md`, once you've answered a question or two, and I can emit it whenever you ask.

## Upgrade menu

- Allow web search → targets 1 and 2 run; RR1 may close and a pay band would fill the market calibration row. A deeper pass (up to 5 more searches and 2 more fetches) can follow if you want it.
- Your pay floor, location and other non-negotiables → the hard-gates line stops reading unknown.
- An answer to G1, plus a LookML excerpt or metric dictionary → R5 moves toward `direct`.
- A sanitized query, experiment readout, dashboard screenshot or metrics memo → R2, R3, R4 and R7 can each reach `high`.
- The hiring manager's name → role reality's scope read, and which story the plan leads with for that reader.

C1 — What are your non-negotiables for a role like this: pay floor, location or remote, anything else?

G1 — Did you personally define and maintain shared metric definitions (LookML models or similar) that other dashboards reused? What did you own, and who relied on them?

G2 — Have you mentored or onboarded junior analysts, formally or not? Who, over what period, and what did you actually do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.