I'm still reading the job-underwriter playbook's reference files, mainly the worked report's table shapes, before I write the assessment.
**Yes, apply, on conditions. Status: `conditional_go`.** The posting rests on your own background and a company I couldn't find online. The conditions are RR1, RR2 and R1, below.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain)

R10 — a credible bridge, its limit named; R6b — monitoring not yet confirmed; R1 — waiting on your confirmation.

**Opportunity ledger.** The employer could not be established from a search (RR1) and the posting you pasted states no pay (RR2). Authority over rate changes and any reports are unspecified (RR3). The named outputs are concrete (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies through its own site or an official register (RR1); (2) the pay lands somewhere you would accept, which I can't check until I know your floor (RR2); (3) you confirm you can work fully remote from the UK (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech writing pet insurance | `[grounded]` JD header; no company page found by search (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. A third-party profile page lists the same title at Brindlemoor, so the role's reporting line is consistent with your message | `[grounded]` your message; `[grounded]` search result snippet, page not fetched, self-reported profile and not an official source |
| Hiring manager's footprint | Spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years. Her talk topic overlaps the JD's "monitor rating models"; what she looks for beyond the JD is not something research can establish | `[grounded]` profile snippet |
| Scope read | A senior individual-contributor post. The JD states no line-management duty, so your having never managed is not a stated gap | `[grounded]` JD silent on reports; `[inferred]` IC scope from the "analyst" title and "own pricing analytics" |
| Market calibration | UK senior pricing analyst roles at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. It is a general band, not specific to pet insurance and not this employer's offer (RR2) | `[generic]` Pricewell 2026 pay survey; `[grounded]` JD as pasted states no pay |
| Unknowns | Pay; who signs off rate changes; whether the role has reports; size and maturity of the pet book | — |
| Contradictions | None between the JD and your account. There is no company page to compare against | `[grounded]` JD and your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You haven't stated where you live or work from; your UK motor insurer role suggests it, but that is not a statement. Confidence grades your own statement of the term, which hasn't been given | `[grounded]` JD term; `[inferred]` UK from your employer | G4 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, specific and plausible but unprobed prose | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated, with no inspectable artifact yet | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for a young-driver book; specific, no artifact yet | `[grounded]` your message | a sanitized model-documentation page would raise to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Audience matches underwriting; actuarial leads are not mentioned | `[grounded]` your message | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM evidence as R4, read against the "build" responsibility | `[grounded]` your message | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is stated; monitoring practice (drift, actual-versus-expected, thin cells) is not, and the claim resolves downward until you say more | `[grounded]` your message silent on monitoring detail | G1 question |
| R7 | Design and read price tests | must_have | direct | medium | none | You "ran 14 price tests last year" with underwriting. Whether you designed them is not stated, so write "ran" unless you confirm the design role | `[grounded]` your message | none |
| R8a | Recommendations for underwriting | important | direct | medium | none | The tests were run with the underwriting team and you present the quarterly review to its head | `[grounded]` your message | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing you've said touches a product team | `[grounded]` your message silent | G3 question |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your message | none |
| R10 | Pet-insurance domain knowledge (not required by the JD; the product is pet insurance) | preferred | adjacent | medium | transferability | Motor GLM rating and price-test practice carry over. Limit: you have never worked on pet, and rating factors and claims drivers differ by line, for example breed, age and pre-existing conditions in pet | `[grounded]` your message; `[generic]` pet versus motor differences | G2 bridge case |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" the young-driver GLM, but no detail on how performance was tracked | A must-have currently at `unclear`; the hiring manager has spoken publicly on monitoring in small books | Actual-versus-expected tracking, drift alerts, refits triggered by monitoring, handling thin cells in a small segment such as young drivers | A monitoring pack, a refit note, a review deck excerpt | `[grounded]` your message silent; `[grounded]` her talk topic from the profile snippet |
| G2 | Pet-insurance domain (R10, preferred) | transferability | Strong motor GLM and testing, no pet exposure | The JD asks only for insurance experience as a plus, so this is the objection most likely to come up in a call rather than a screen | A rating segment with sparse data; renewal pricing; cost-inflation adjustments | An optional short note listing what you would check first moving a GLM from motor to pet | `[generic]` that a domain-switch objection is likely for this posting |
| G3 | Recommendations for product (R8b, important) | discovery | Underwriting audience evidenced, product audience not | Half of the JD's recommendation duty is aimed at product | Taking a test result to a product or commercial team; a pricing change that shaped a product feature | A test readout or a product-facing slide | `[grounded]` your message silent |
| G4 | Fully remote (UK) (R1, hard_gate) | hard_gate | Term not stated by you | An unconfirmed gate stays visible until you answer | — | — | `[grounded]` your message silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would be on the interview panel? | unresolved |
| RR2 | Pay not stated | unknown | — | no salary appears in the posting as pasted | The figure may sit above or below the band in role reality, or the employer may not publish pay | `[inferred]` from the missing figure against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Authority and reports unspecified | unknown | — | "turn the results into recommendations for underwriting and product" | The role may be advisory, with rate changes signed off elsewhere, and may or may not carry reports | `[inferred]` from the JD's recommendation wording against its silence on decision rights | Who signs off a rate change this role recommends, and does the role have any direct reports? | unresolved |
| RR4 | Outputs concretely stated | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope looks defined, with named work products | `[grounded]` JD states the duties | What would you expect the first model review or price test to be? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Brindlemoor through Companies House, the FCA register, or its own site before spending effort | RR1 | `[generic]` insurers and intermediaries in the UK normally appear on the FCA register | pending your approval |
| A2 | Lead the application with the GLM young-driver model (R4, R6a), the 14 price tests you ran (R7) and the quarterly review to the head of underwriting (R5), in your own existing wording | Your direct matches | `[grounded]` your message | pending your approval |
| A3 | Describe pet as an area you have not worked in, and describe the motor GLM and testing as the transferable part. Optionally add a short note of questions you would ask before moving a GLM from motor to pet, framed as questions, not experience | R10, G2 | `[grounded]` your message | pending your approval |
| A4 | If reports come up, say plainly that you haven't line-managed anyone. The JD does not ask for it | Scope read | `[grounded]` JD silent on reports | pending your approval |
| A5 | Ask RR2 and RR3 verbatim in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech"; no results, so the company is not established. Moved: RR1 as a standing entry, capping the decision at `conditional_go` |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga); snippet read, page not fetched. Moved: role reality's hiring-manager rows and G1's why-it-matters |

I can write this up as `tuesday-dossier.md` to carry forward if you want it.

**Upgrade menu**

- A link to the live posting or Brindlemoor's own careers page → closes RR1 and lifts the `conditional_go` cap.
- Your pay floor and whether you can work fully remote from the UK → R1 and RR2 settle against your terms.
- A sanitized model-monitoring pack, actual-versus-expected tables, or a test readout → R6b and R7 move toward `high`.
- A deeper research pass on Brindlemoor (funding, leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

- G1 — Which monitoring did you personally run on the young-driver GLM (for example actual-versus-expected tracking, drift checks, refit triggers), and what did it lead you to change?
- G3 — Have you taken a price-test result or model change to a product or commercial team, rather than underwriting, and what happened?
- G4 — Are you UK-based and able to work fully remote, and do you have any non-negotiables such as a pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.