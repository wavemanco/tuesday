Checking that the Pellucid posting is live and matches what you pasted, then I'll write up the verdict.
**Yes, worth applying to, once you confirm the two terms I can't see (R1, R2). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery warehouse) · unclear: R10 (data contracts), R11 (ingestion from app and CRM)

R7 — a credible bridge, its limit named; R10, R11 — your background says nothing either way; R1, R2 — one answer each from you.

**Opportunity ledger.** The posting is live, and the posted range straddles the market median (RR1). The reporting line, on-call load, equity terms and who owns the data contracts are unstated (RR2, RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm US work authorization and location, and a pay floor at or below the range (R1, R2); (2) the BigQuery bridge is framed as adjacent, never as BigQuery experience (R7); (3) RR2 and RR4 are answered in the interview loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the company's own About page, fetched. Funding is self-reported there and not independently checked |
| Mandate | Pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting, fetched |
| Posting status | Live ("Accepting applications"), text matches what you pasted | `[grounded]` careers page, fetched |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | Looks like ownership of one reporting domain's pipelines, with no reports mentioned | `[inferred]` from the posting's scope list and its silence on direct reports |
| Market calibration | Posted $148,000–$166,000 against a base median of $151,000 and an interquartile range of $139,000–$163,500: the low end sits just under the median and the high end above the 75th percentile. "Senior" typically means 5–8 years and one domain with no direct reports, so six years is mid-band. The report covers base pay; whether the posting's "Salary" is base is assumed | `[grounded]` the posting and the Datawright 2026 report you supplied (n=2,310, Series B–D); `[inferred]` that "Salary" means base |
| Unknowns | Hiring manager and team size; on-call; equity terms; whether data contracts already exist | `[grounded]` the posting names none of these |
| Contradictions | None between the posting and the careers or About pages | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or your authorization. Confidence is `none` because there is no statement to grade | `[grounded]` posting; your message silent | Question G1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given, so I can't say whether the range meets it | `[grounded]` posting; your message silent | Question G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years stated. It's prose self-report with nothing inspectable, so `medium` | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated; no artifact | `[grounded]` your background | Offer: a sanitized model or script would raise to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the project, about 180 models, on Snowflake | `[grounded]` your background | Offer: a sanitized project structure or docs page would raise to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse | `[grounded]` your background | none |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as your orchestrator | `[grounded]` your background | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | none |
| R7 | A dbt-modelled BigQuery warehouse | important | adjacent | medium | transferability | The posting names BigQuery only in the responsibilities, not the requirements. You've never used it. What carries over is Snowflake warehouse work and dbt modelling. The limit is BigQuery's own SQL dialect, cost model and tooling, which you haven't exercised | `[grounded]` posting and your "never used BigQuery"; `[generic]` that both are cloud columnar warehouses and dbt models carry across adapters | Frame honestly as adjacent; consider a small BigQuery sandbox project |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing in your background mentions contracts or schema agreements, but your tests and models may have served that purpose | `[grounded]` posting; `[inferred]` that your test suite may be related, unconfirmed | Question G3 |
| R11 | Ingestion from app and CRM | important | unclear | low | discovery | Payroll work likely involved ingestion, but sources and tooling aren't stated | `[inferred]` from your payroll-company role; unconfirmed | Ask later if the decision firms up |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and authorization (R1, hard_gate) | hard_gate | Not stated | If you're not US-based and authorized, the role is out | — | — | `[grounded]` your message silent |
| G2 | Pay floor (R2, hard_gate) | hard_gate | Not stated | The range is the decision's biggest term | — | — | `[grounded]` your message silent |
| G3 | Data contracts (R10, important) | discovery | Silent | It's a named deliverable | Defining schema or column-level agreements with analysts; versioned model contracts in dbt; breaking-change processes with downstream teams | dbt model docs, a schema-change policy, a sanitized contract or test file | `[grounded]` posting and CV silence; `[inferred]` that your tests may count |
| G4 | App and CRM ingestion (R11, important) | discovery | Silent on source types and tooling | A core responsibility | Loading from SaaS APIs or an app database; incremental loads; CRM syncs | An architecture sketch or DAG screenshot | `[grounded]` CV silence |
| G5 | BigQuery (R7, important) | transferability | Adjacent only | The posted warehouse | A side project on BigQuery; a Snowflake-to-BigQuery migration you touched | A small repo or notebook | `[grounded]` your "never used BigQuery" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range straddles the report's median and its top is above the 75th percentile | `[grounded]` posting and Datawright report | Is the range base pay, and what sets where an offer lands in it? | noted |
| RR2 | Reporting line, team size and on-call unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | One engineer may carry build, operations and on-call for ingestion through contracts | `[inferred]` from "build and run" against the posting's silence on team | Who does this role report to, how many data engineers and analysts are on the team, and is there an on-call rotation? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The grant, vesting and strike may be material or negligible | `[grounded]` the posting gives no terms | What is the equity range, vesting schedule and strike price? | unresolved |
| RR4 | Contract ownership unclear | unknown | — | "the data contracts our analysts depend on" | Contracts may already exist, or the role may have to create them | `[inferred]` from the posting's phrasing | Do data contracts exist today, or does this role create them, and who signs off changes? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer G1 and G2 before investing effort | see R1, R2 | `[grounded]` gate rows | pending your approval |
| E1 | Lead the CV with "Built our dbt project on Snowflake — about 180 models" and "set up our Great Expectations test suite", in your own words | see R5, R9 | `[grounded]` your background | pending your approval |
| E2 | Say plainly that you have used Snowflake and not BigQuery; claim no BigQuery or data-contract experience unless G3 confirms it | see R7, R10 | `[grounded]` your background | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the loop | the register doubles as interview prep | `[grounded]` register | pending your approval |

If you apply and want the CV tailored, resume-tailor does that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It showed the posting is live and consistent with your paste, so there is no failed-attribution entry. Role reality's organization, posting-status and contradictions rows rest on it |
| 2. Role-family sweep | skipped | The Datawright report you supplied already fixes the market calibration line and the scope norm, so a search would change neither |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can offer a one-sentence dossier, `tuesday-dossier.md`, if you want to carry this forward.

## Upgrade menu

- Your location, authorization and pay floor → R1 and R2 close, and the status moves to `go` or `no_go`.
- A sanitized dbt project outline, a model or a test file → R4 and R5 to `high`, and G3 answered.
- A small BigQuery project → R7's bridge narrows.
- The hiring manager's name → role reality's scope read and which story to lead with.
- A deeper research pass on Pellucid Learning (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Are you based in the US with work authorization, and would you work remotely or from Denver?
G2 — What is the lowest base salary you'd accept?
G3 — Have you personally defined schema or data agreements with analysts or downstream teams, in dbt tests or otherwise? What did you own, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.