Still reading the underwriter's reference files before I write the assessment. I've done the worked report and gap taxonomy, and the conventions, risk rules and output rules come next.
## Decision snapshot

**No, this isn't a waste of your time, but it's a stretch and not a cold-apply win. R1b, a `must_have`, is absent: you have no titled PM years. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1a (PM work without a PM title), R2 (Shipped API or platform products) · absent: R1b (3+ years titled PM experience)
- `important` — direct: R4a, R7 · adjacent: R6 (Own the roadmap), R8 (Specs and delivery with two squads) · unclear: R4b (Sales and support stakeholders), R5 (Agile delivery), R9 (Adoption metrics)

R1b — titled years can't be closed by rewording; R2, R6, R8 — adjacent, limits named; R9 (`low`) — a memory lead waiting on your confirmation.

**Opportunity ledger.** The scope is stated clearly (RR4). Authority behind "own the roadmap" is unknown (RR5), compensation is not given (RR2), and how strictly the years bar is applied is unknown (RR1). I could not establish the employer from here (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline confirms the 3+ years bar is applied flexibly (R1b, RR1); (2) the employer and the live posting verify (RR3); (3) the R2 and R9 bridges firm up with specifics from you (G1, G2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header as you pasted it; not checked against any Quartzline page |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years PM experience (marked must-have); shipped API or platform products; technical fluency; stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| Scope read | A defined platform-PM remit, with named squads, metrics and partners | `[inferred]` from the JD's listed responsibilities |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Compensation and location | Not stated | `[grounded]` JD silent |
| Market calibration | Not established: no search ran, so there is no band to set against this title | `[grounded]` search unavailable this session |
| Unknowns | Who holds roadmap authority; how strictly the years bar is applied; pay; whether other PMs sit alongside | — |
| Contradictions | None inside the pasted JD; the careers page was not checked | `[grounded]` JD only |

## Evidence map

I only have your summary, not the resume itself. Every candidate claim sits at the intake ceiling, `medium` at most, until you confirm specifics or show an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | PM experience, as work done: roadmap input, specs, cross-team delivery | must_have | adjacent | medium | transferability | You wrote requirements documents, coordinated engineers and PMs, and ran roadmap-input sessions. That is PM-shaped work done from the vendor's delivery side. Limit: the PMs owned the prioritisation decisions; you fed them | `[grounded]` your summary; `[inferred]` the adjacency | Frame as adjacent work with the limit named; see G2 for the one thing that could lift it |
| R1b | 3+ years of product management experience, as titled years | must_have | absent | none | capability | You have never held a PM title, so nothing meets the years literally. Work near it is evidence for R1a, not for this row | `[grounded]` your statement | Closure path in G3; carried as a material risk (RR1) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your vendor's REST APIs and wrote the internal playbook. That is deep use and delivery of an API product. Limit: nothing shows you shaped or shipped the API itself | `[grounded]` your summary; `[inferred]` the adjacency | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading, and integration architecture across 30+ integrations. Self-reported, with no artifact inspected yet; expect a probe | `[grounded]` your summary | An artifact would raise it to `high`: the sanitized playbook or an integration architecture diagram |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, the clients' engineers and PMs over many engagements | `[grounded]` your summary | None |
| R4b | Stakeholder management with sales and support | important | unclear | low | discovery | Your summary doesn't mention sales or support; the JD also asks for launch coordination with them | `[grounded]` your summary silent | G4 |
| R5 | Agile delivery | important | unclear | low | discovery | You ran UAT and go-lives, but nothing says you worked in sprints or backlogs | `[grounded]` your summary silent | Fold into G4's answer if relevant |
| R6 | Own the roadmap | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions for product. Limit: input into someone else's roadmap, not owning priorities or trade-offs | `[grounded]` your summary; `[inferred]` the limit from "for product" | G2 |
| R7 | Discovery with integration partners | important | direct | medium | none | Scoping workshops and roadmap-input sessions with clients integrating your APIs. Partners and clients are close but not identical | `[grounded]` your summary | None |
| R8 | Specs and delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: client-specific scope, not a standing product backlog for squads | `[grounded]` your summary; `[inferred]` the limit | G2 |
| R9 | Defining and tracking adoption metrics | important | unclear | low | discovery | Your summary states no metrics. Agent memory suggests you built an internal request-triage tool that support agents adopted. It is unconfirmed and unspecified, so it is a lead, not evidence | `[inferred]` from a `memory_lead`; nothing confirmed | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped API or platform products (R2, must_have) | transferability | Heavy integration delivery on your vendor's REST APIs; nothing about shaping or shipping the API itself | A must-have at `adjacent`; the gap is between delivering an API and shipping one | A change to your vendor's API or developer docs that came out of your integrations: a requirement you wrote that engineering shipped, a deprecation you handled, a partner-facing guide | A spec, a changelog entry, a ticket thread, a published doc | `[grounded]` your summary; `[inferred]` that this is the likeliest probe |
| G2 | Owning prioritisation, specs and metrics (R6, R8, R9 and the lift to R1a) | discovery | The unconfirmed triage tool in agent memory; roadmap input and requirements docs in your summary | If the tool was yours end to end, it is the closest thing to PM ownership in your history | Deciding what the tool would and wouldn't do; picking who it was for; tracking whether agents used it; iterating after feedback | Usage numbers, a before-and-after note, a one-page write-up, screenshots | `[inferred]` from a `memory_lead`; unconfirmed |
| G3 | Titled PM years (R1b, must_have) | capability | No PM title in seven years | Rewording cannot close this row; the posting marks it must-have | Not applicable: the row is about the title. Work near it already counts in R1a | None | `[grounded]` your statement |
| G4 | Sales, support and agile (R4b, R5) | discovery | Your summary is silent on sales, support and sprint-based delivery | The JD names launch coordination with sales and support, and agile delivery | Joint go-live plans with sales; support handover docs; working inside your clients' or your own sprint cadence | A launch checklist, a handover doc | `[grounded]` your summary silent |

G3 is the closure path: no wording moves it, so it is carried as a risk. Routes through roles with a lower years bar, such as an internal move at your current employer, are a `[generic]` pattern, not a claim about Quartzline.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Years of PM experience marked must-have against R1b | risk_signal | medium | "3+ years product management experience (must-have)" | The bar may be applied literally at screening, or may flex for strong adjacent experience. Reasons for medium, not high: the JD's other requirements read as practice-based | `[inferred]` from the JD's must-have marking | How strictly is the 3+ years of PM experience applied, and would seven years of API integration delivery plus roadmap input be considered? | unresolved |
| RR2 | Compensation not stated | unknown | — | no compensation figure appears in the posting as pasted | The posting may withhold pay, or the figure may be elsewhere; no band was researched, so nothing is calibrated | `[grounded]` the posting as pasted; no band exists this session | What is the budgeted salary for this role? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR4 | Responsibilities, squads and metrics are specified | positive_signal | — | "run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics" | The remit is genuinely defined | `[grounded]` JD | What are the first two or three adoption metrics you would want this role to move? | noted |
| RR5 | Authority behind "own the roadmap" not evidenced | unknown | — | "Own the roadmap for our partner-facing API platform" | Roadmap decisions may sit with leadership, or may be shared with sales | `[inferred]` from the JD's silence on decision rights | Who makes the final call on roadmap priorities, and how are conflicts with sales resolved? | unresolved |

RR3 caps a `go` at `conditional_go` until the posting and employer verify.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask through a human contact how strictly the 3+ years is applied, before a cold application | see RR1, R1b | `[grounded]` RR1 | pending your approval |
| A2 | Seek an introduction to the hiring manager or a platform engineer at Quartzline | Warm routes usually bypass literal screens; this is a pattern, not a fact about this employer | `[generic]` role-family pattern | pending your approval |
| E1 | Resume: surface the roadmap-input sessions and the playbook near the top, in your own wording, and add no PM title or PM-years claim | see R1a, R6; every clause stays within your sentences | `[grounded]` your summary | `resume_edits_pending_approval` |
| W1 | A one-page sanitized product-style write-up of the playbook or, if you confirm it, the triage tool: problem, users, decisions, outcome | see R2, R8, R9 | `[grounded]` R2, R8, R9 rows | pending your approval |
| Q1 | Ask RR1, RR2 and RR5's questions verbatim in a first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

**Offer (labelled addition, not part of the assessment):** tailoring the resume line by line to this posting is a separate job, and resume-tailor covers it. Say the word and I'll run it as an approve-first ledger.

## Evidence status

Verified: none yet. Unverified lead: a request-triage tool adopted by support agents, from agent memory; it prompts a question only and carries no weight in the map.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Quartzline logistics technology Series B API platform" and "Quartzline careers Product Manager Platform APIs". Would have moved role reality's organization and contradictions rows and RR3 |
| 2. Role-family sweep | unavailable | One search was refused: "platform API product manager salary scope solutions engineer to product manager transition". Would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Upgrade menu

- Search permission for this session → targets 1 and 2 run: RR3 may clear or deepen, and role reality gets a market calibration and a pay band for RR2.
- A link to the live posting or Quartzline's careers page → RR3 and the contradictions row.
- The resume itself → R1a, R3, R7 and R8 move from your summary to the document's own wording.
- A sanitized playbook excerpt or integration architecture diagram → R3 to `high`.
- A spec, changelog entry or ticket thread tied to the vendor's API → R2 narrows.
- The hiring manager's name → role reality's scope read and which story the plan leads with.

I can write this up as `tuesday-dossier.md` if you'd like to keep or reuse it.

G2 — Tell me about the internal request-triage tool: did you decide what it would do and who it was for, how many people used it, and how did you know it worked? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — Did anything you wrote or fed back from an integration end up as a shipped change to your vendor's own API, docs or product? What was your part, and who else was involved? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Constraints — What are your non-negotiables for a move like this: pay floor, location or remote, and anything you won't trade for the title? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.