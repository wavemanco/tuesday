**Not a waste of time, but a stretch. R1a (no PM title, so no titled PM years) is the exposure, and R1b, R2, R7 and R8a are credible bridges rather than matches. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — adjacent: R1b (PM work in substance), R2 (shipped API or platform products) · absent: R1a (3+ years titled PM experience)
- `important` — direct: R3, R4a, R6 · adjacent: R7 (specs and delivery with two squads), R8a (own the roadmap) · unclear: R4b (sales and support in launches), R5 (agile delivery), R8b (adoption metrics)

R1a — no PM title held, so no titled years to claim; R1b, R2 — bridges with their limits named; R4b, R5, R8b — waiting on your answers.

**Opportunity ledger.** The scope is concrete: two squads, a partner-facing API, adoption metrics (RR4). Three things are unresolved: whether the "3+ years" accepts adjacent work (RR1), whether the employer exists as described, because my search was refused (RR2), and the unstated pay, level and location (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the recruiter confirms that product work done outside a PM title counts toward the years (RR1, R1a); (2) the employer and live posting verify (RR2); (3) you can confirm one example where you owned or shaped a product decision, from G1 or G5 (R8a, R8b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently verified (RR2) |
| Mandate | Own the roadmap of a partner-facing API platform; partner discovery; specs and delivery with two squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD names none |
| Must-have flag | The JD marks only the 3+ years as "(must-have)"; the other requirements sit in an unflagged list, and I tiered them accordingly | `[grounded]` JD wording |
| Scope read | A platform PM with direct engineering partnership and a customer-facing API surface, rather than a pure growth or pure strategy post | `[inferred]` from "two engineering squads" and "integration partners" |
| Market calibration | Not run. The role-family search was refused, so no pay band or title norm is stated | — |
| Unknowns | Pay, level, location, reporting line, who owns adoption metrics today | `[grounded]` JD silence |
| Contradictions | None visible inside the JD alone; no careers-page cross-check was possible | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, held as a PM | must_have | absent | none | capability | You state you have never held a PM title, so there are no titled years to claim. The work done is carried on R1b. Whether the employer credits substance over title is RR1's question | `[grounded]` your statement | Ask RR1's question of the recruiter; claim no PM years or title anywhere |
| R1b | Product management work in substance (same JD line, read as the work) | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions, requirements documents, and coordinating engineers and PMs on custom builds sit near PM work. The limit: input and requirements for client builds, with no stated ownership of a product's priorities | `[grounded]` CV for the work; `[inferred]` adjacency, derived from those bullets | See G1 and G5 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ end-to-end integrations of your vendor's REST APIs and a team-wide integration playbook. The limit: you worked the implementation side of the API and no stated role decided or shipped the API itself | `[grounded]` CV; `[inferred]` adjacency | See G4; a work sample would narrow the limit |
| R3 | Technical fluency: API docs, schemas | important | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture, all specific. Confirmed only by your own account, so expect a probe | `[grounded]` your resume summary | none |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, the clients' engineers and PMs across 30+ engagements | `[grounded]` your resume summary | none |
| R4b | Stakeholder management with sales and support in launches | important | unclear | low | discovery | The resume summary is silent on sales. The support-adoption lead is unconfirmed memory, so it prompts a question only | `[grounded]` silence; `[inferred]` that the lead may bear on support | See G2 |
| R5 | Agile delivery | important | unclear | low | discovery | UAT and go-live are described, with nothing on sprints or backlog work | `[grounded]` silence | See G3 |
| R6 | Discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly roadmap-input sessions with clients. Limit: they were clients of your employer's APIs, and whether the posting's "partners" differ is unknown | `[grounded]` your resume summary | none |
| R7 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and integration architecture for custom builds are spec-like. The limit: no stated ownership of a squad's backlog or sprint priorities | `[grounded]` CV; `[inferred]` adjacency | See G5 |
| R8a | Own the roadmap | important | adjacent | medium | transferability | You collected client feedback for product. The limit: you supplied input and the summary shows no prioritization authority | `[grounded]` your resume summary; `[inferred]` adjacency | See G5 |
| R8b | Define and track adoption metrics | important | unclear | low | discovery | The summary holds no metrics work. The triage-tool lead from a prior conversation is unconfirmed | `[grounded]` silence; `[inferred]` that the lead may bear on it | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics (R8b, important) | discovery | Nothing on metrics in the summary. A prior conversation suggests an internal request-triage tool that support agents adopted. This is unconfirmed | The one place you may have owned a product-like outcome and measured its uptake. It could also lift R4b | A tool or process you designed and others used; any measure of uptake, tickets handled, or time saved; deciding what to build next from usage | A usage screenshot, a README, a rollout note, adoption numbers | `[grounded]` CV silence; `[inferred]` that it could move R8b and R1b |
| G2 | Sales and support in launches (R4b, important) | discovery | Silent on sales; support appears only through the unconfirmed lead | The JD names sales and support coordination for launches | Briefing sales on a custom build or a new API capability; training support on a go-live; a handoff or escalation process you set up | An enablement doc, a launch checklist, a handoff template | `[grounded]` CV silence |
| G3 | Agile delivery (R5, important) | discovery | UAT and go-live appear, with no sprint or backlog evidence | A requirement the resume leaves unaddressed | Joining sprint planning or refinement with a product squad on custom builds; prioritizing client-requested changes into a team's backlog | A board export or sprint notes, sanitized | `[grounded]` CV silence |
| G4 | Shipped API or platform products (R2, must_have) | transferability | Strong adjacent evidence from 30+ integrations. It stops before product ownership | A `must_have` at `adjacent`; the bridge decides how the application reads | A client-driven change to the API that you wrote up and engineering built; API design feedback you gave; the playbook's influence on how the API was documented | A change request you wrote, a sanitized spec, a one-page teardown of an API you know well | `[grounded]` CV; `[generic]` that this is the objection a reader of this posting is most likely to raise |
| G5 | Spec ownership and roadmap input (R7, R8a, important) | transferability | Requirements and roadmap-input sessions are present. No decision rights are shown | Distinguishes input from ownership, which this role's title implies | A client feedback theme that became a roadmap item; a requirement you wrote that shaped a build; a trade-off you argued to engineering | The request or spec, plus the outcome | `[grounded]` CV; `[inferred]` bridge, derived from the roadmap-input sessions |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Years requirement may be read by title | risk_signal | medium | "3+ years product management experience (must-have)" | The posting may require the years under a PM title, or may accept product work done in other roles; the JD does not say | `[inferred]` from the JD's wording against its silence on how the years are counted | Does the 3+ years need to be under a PM title, or does product work done in a solutions or implementation role count? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the check did not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Pay, level and location withheld | unknown | — | The posting states no pay, level or location | A move from a seven-year senior role into a first PM post may change level or pay; the figure may sit below what you need | `[inferred]` from the posting's silence and the career change | What is the pay band and level for this role, and where is it based? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | Responsibilities are specific enough to judge, and success is measurable | `[grounded]` JD states both | What adoption metrics does the platform track today, and who owns them? | noted |

RR2 is a standing entry and caps the decision at `conditional_go` until the posting verifies. A name appearing in a posting does not tell me anything about the firm's honesty, and most small companies are simply small.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter RR1's question before investing in the loop | The years requirement is the largest exposure (R1a) | `[grounded]` RR1 | pending your approval |
| E1 | Lead the resume with the 30+ integrations bullet and the roadmap-input bullet. The edit is reordering only | Surfaces R2 and R8a; no wording changes (reframing audit: nothing added) | `[grounded]` your resume summary | `resume_edits_pending_approval` |
| E2 | Say "ran quarterly sessions collecting client feedback as input to product" and not "owned the roadmap" | Keeps R8a at the evidence: input, not authority | `[grounded]` your resume summary | `resume_edits_pending_approval` |
| W1 | A one-page sanitized spec or API teardown | Narrows the limit on R2 and R7 | `[grounded]` R2, R7 rows | pending your approval |
| Q1 | Ask the register's questions of RR1 to RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Consider moves inside your current employer, or toward API-platform products where integration experience is the domain, alongside this post | Moves from solutions into PM are often made that way | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: an internal request-triage tool that support agents adopted, from a prior conversation, unconfirmed. It prompts G1 and nothing else.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology API platform Series B"; the search was refused. It would have fed RR2 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "Product Manager Platform APIs salary range B2B SaaS Series B partner API product manager"; the search was refused. It would have fed the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- The recruiter's answer on RR1 settles whether R1a is a bar or a risk; the decision likely simplifies to `go` or `no_go`.
- A usage screenshot, README or rollout note for the triage tool, if it is yours, would raise R8b and could lift R4b.
- Your non-negotiables (pay floor, location, work arrangement) would turn the hard-gates line from unknown into checked.
- Your actual resume as a document, rather than the summary, would let me audit E1 and E2 against your real lines.
- Allowing web search would let me run the employer check and the pay-band sweep I attempted (RR2, RR3, market calibration).
- A hiring manager's name would feed role reality's scope read and the plan's lead story.

If you want a record to carry forward, I can write this up as `tuesday-dossier.md`.

G1 — Did you build the internal request-triage tool I have a note about? If so, what did you personally own, who used it, and how did you know it worked?

G5 — Did any client feedback you collected become a roadmap item or a build, and did you write the request or spec? What was your part, and what was the outcome?

Orientation — What are your non-negotiables for a move into PM: a pay floor, location or remote needs, and whether you would accept a level or pay step down?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.