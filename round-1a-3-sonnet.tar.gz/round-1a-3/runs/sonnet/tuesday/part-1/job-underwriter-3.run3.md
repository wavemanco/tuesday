**Not worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin five days a week), R2 (Base pay $70–85k)
- `must_have` — direct: R4, R5, R9 · adjacent: R3 (8+ years growth leadership) · unclear: R6 (SEO and content)
- `important` — unclear: R7 (Brand and PR), R8 (Partnerships and sales ops), R10 (Team of one, ambiguity)

R1, R2 — the posting's terms against your constraints, which no fit elsewhere offsets; R3 — your nine years in growth don't separate out the lead and head years; R6 — SEO doesn't appear in your background.

**Opportunity ledger.** The terms conflict with you on location and pay (RR1, RR2). The role bundles the whole growth function onto a team of one with no committed budget (RR3), carries always-on language (RR4) and has undefined success metrics (RR5). The employer is unverified because my searches were refused (RR6). The one favorable entry is direct CEO access (RR7).

- **Hard gates:** failed: R1 (On-site Austin five days a week), R2 (Base pay $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting would have to change on both counts, to remote work and to a base at or above your $150k floor (R1, R2). Nothing in your background or wording moves either one.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one". The employer says this and I haven't checked it | `[grounded]` JD header |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start. Reports to the CEO, dotted line to the board | `[grounded]` JD |
| Location and hours | On-site Austin five days a week, "no exceptions". Evenings and weekends "when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms stated | `[grounded]` JD |
| Scope read | Several specialist jobs under one title, with no stated budget or first hires | `[inferred]` from the function list against the JD's silence on resources |
| Market calibration | Not established. The role-family sweep didn't run, so I offer no market band. Against your floor, the top of the posted range is $65k short | `[grounded]` JD figure and your stated floor |
| Unknowns | Budget, equity terms, success metrics, who the customer is (merchants or consumers), whether the employer and posting are live | `[grounded]` JD silence |
| Contradictions | None found inside the posting. The careers page wasn't checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, five days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own confirmed constraint (remote-only, Portland, not relocating). The gate fails because the JD rules out remote work | `[grounded]` JD quote and your statement | Only the employer changing the term resolves it; see RR1 |
| R2 | Base pay of $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your confirmed $150k floor. The gate fails because the posted top is below it | `[grounded]` JD quote and your statement | Only the employer changing the term resolves it; see RR2 |
| R3 | 8+ years growth leadership | must_have | adjacent | medium | discovery | You state 9 years in growth with lead and then head titles, but not how many were in lead roles. I took the lower reading. Self-reported, nothing inspectable | `[grounded]` your message | Dates for the lead and head roles |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid. Self-reported, no artifact yet | `[grounded]` your message | A channel dashboard export would raise it to `high`, if it ever matters |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and name Braze. Self-reported | `[grounded]` your message | A lifecycle program summary would raise it |
| R6 | SEO/content | must_have | unclear | low | discovery | Your background doesn't mention SEO. It may exist and be unlisted | `[grounded]` silence in your message | Any SEO or content work |
| R7 | Brand and PR | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence in your message | Any brand or PR ownership |
| R8 | Partnerships and sales ops | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence in your message | Any partnership or sales-ops work |
| R9 | Owning revenue growth with a controlled budget | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. The limit is that this was at one of your two companies, and how much of the scale-up was yours is unprobed | `[grounded]` your message | Board or finance deck excerpt would raise it |
| R10 | Thriving on ambiguity as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7. You haven't described working alone | `[grounded]` your message | None while the decision is stable |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Nothing in your background either way | A must-have row, but it can't move a `no_go` set by R1 and R2 | Owning content or organic channels inside a lifecycle or paid role | A traffic report or content calendar | `[grounded]` silence; `[inferred]` that it can't change the decision |
| G2 | Brand, PR, partnerships, sales ops (R7, R8, important) | discovery | No evidence either way | Important rows. They show how much of the bundle you've actually done | Launch PR, affiliate or partner deals, handing leads to sales | A partner agreement or a launch brief | `[grounded]` silence |
| G3 | Solo operation (R10, important) | discovery | Team-building shown, solo work not | Matters only if the role were otherwise viable | Running a function alone early in a company | A role description from that period | `[grounded]` your message |
| G4 | On-site five days (R1, hard_gate) | hard_gate | The JD and your constraint conflict | Decides the outcome. Wording cannot solve it | — | — | `[grounded]` JD and your statement |
| G5 | Base $70–85k (R2, hard_gate) | hard_gate | The JD's top figure is below your floor | Decides the outcome. Wording cannot solve it | — | — | `[grounded]` JD and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site requirement against your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Incompatible with what you told me you will accept | `[grounded]` JD and your statement | Is the five-day on-site requirement fixed for this role, as the posting says? | confirmed |
| RR2 | Base pay against your floor (R2) | red_flag | high | "$70–85k base" | The posted top is below your $150k floor | `[grounded]` JD and your statement | Is $70–85k the full base range for this role? | confirmed |
| RR3 | Bundled functions, team of one, no stated budget | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one to start" | You could be accountable for the whole function without resources or decision rights | `[inferred]` from the function list against the JD's silence on budget | What budget, tools and first hires are committed to this function? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be a standing expectation | `[inferred]` from the JD's wording | In the last year, how often have evenings or weekends actually been required? | unresolved |
| RR5 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held accountable without a stated definition of success | `[inferred]` from the JD's wording | What would a successful first year look like, and who sets and reviews the metrics? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. My searches were refused, so none of these is ruled in or out | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Direct CEO access | positive_signal | — | "Report to the CEO with a dotted line to the board" | Reporting is senior and close to the decision-makers | `[grounded]` JD | How often does the head of growth meet the CEO, and what does the board line involve in practice? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting as written. I propose no resume edits | See R1, R2, RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | If you proceed anyway, put RR1 and RR2's questions to the employer first, through contacts on its own site, before spending interview time | A confirmed gate conflict makes these questions essential | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1 and R2, which are your own stated constraints. Verified is about the claim, not the fit, and both rows' fit is `hard_gate_fail`. Unverified: your experience claims behind R3, R4, R5 and R9, which are prose only. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Novaline's site and role was refused. It would have fed role reality's organization and contradictions rows and RR6 |
| 2. Role-family sweep | unavailable | The search for Head of Growth pay was refused. It would have fed the market calibration row and a market check on R2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'm not using memory for company facts or market figures, so nothing above rests on them.

If you'd like, I can write this up as `tuesday-dossier.md` to carry into later steps.

**Upgrade menu**

- Permission to run web search lets me check whether Novaline and the role are real and live (RR6), and gives a market pay band for R2 and RR3.
- Dates for your lead and head titles would settle R3.
- A channel dashboard export, a lifecycle summary or a board/finance deck excerpt would raise R4, R5 and R9 to `high`.
- Any SEO, brand, PR, partnership or sales-ops work would fill G1 and G2.
- The CEO's or hiring manager's name would sharpen the scope read.
- The employer's answers on budget, equity terms and success metrics would close RR3 and RR5.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.