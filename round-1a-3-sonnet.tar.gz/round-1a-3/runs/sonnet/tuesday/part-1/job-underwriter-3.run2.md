# Job Underwriting Assessment: Head of Growth at Novaline

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin five days), R2 (Base $70–85k)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO and content)
- `important` — unclear: R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one)

R1 — your remote-only constraint against five office days; R2 — your $150k floor against a range whose top is $85k; R4 (`medium`) — a strong match, confirmed in prose, no artifact yet.

**Opportunity ledger.** Two entries conflict with your stated terms and are severe (RR1, RR2). The posting also reads as seven functions under one title held by one person (RR3), with budget and decision rights unstated (RR4), always-on hours (RR5), success metrics left open (RR6) and equity unquantified (RR7). The employer could not be established from here (RR8). The plain statement of pay and office terms is a positive (RR9).

- **Hard gates:** failed: R1 (On-site Austin five days a week), R2 (Base $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** Novaline would have to allow remote work from Portland and offer a base of at least $150k. The posting says "no exceptions" and states $70–85k.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one", Austin office. Its existence is not established from here (RR8) | `[grounded]` JD header |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO, dotted line to the board | `[grounded]` JD |
| Working pattern | "On-site in our Austin office 5 days a week — no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figure or terms given | `[grounded]` JD |
| Success outcomes | "Success metrics will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD, silence on outcomes |
| Scope read | Seven functions with no bench is broader than the remit you describe (paid, lifecycle, experimentation, teams of 3–7) | `[inferred]` JD function list against your stated background |
| Market calibration | Not established. The role-family sweep could not run, so no market band is given. The gap to your floor is arithmetic: $65k above the top of the range and $80k above the bottom | `[grounded]` JD figures and your stated $150k floor |
| Unknowns | Budget, decision rights, equity terms, whether Austin or pay flex, planned hires | — |
| Contradictions | None found between the posting and your account. The posting was not checked against a careers page | `[grounded]` posting and your message only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" (your constraint: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own specific, confirmed statement of the constraint. Fit is failed because the JD rules out exceptions to the office requirement | `[grounded]` JD quote and your confirmed constraint | Surface in the snapshot. Only you revising the constraint or the employer changing terms resolves it |
| R2 | Compensation of $70–85k base (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own confirmed floor. Fit is failed because the top of the posted range is $65k below it | `[grounded]` JD figures and your confirmed constraint | Surface in the snapshot. Only a changed offer or a revised floor resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, as growth lead and then Head of Growth at two companies. It is prose with no document yet, and how many of the 9 years were leadership-titled is not itemized, so expect to be asked | `[grounded]` your message | None needed for this decision |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid, and scaled one company from $8M to $40M ARR over three years with a budget you controlled. It is confirmed and specific, but no inspectable artifact has been seen | `[grounded]` your message | None needed for this decision |
| R5 | Lifecycle / CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. It is confirmed and specific, with no artifact inspected | `[grounded]` your message | None needed for this decision |
| R6 | SEO / content | must_have | unclear | low | discovery | Your summary does not mention SEO or content. Silence is not evidence of absence, and nothing here establishes the work | `[grounded]` silence in your summary | See G1 |
| R7 | Brand, PR and partnerships | important | unclear | low | discovery | Your summary does not mention any of the three | `[grounded]` silence in your summary | See G2 |
| R8 | Sales ops | important | unclear | low | discovery | Your summary does not mention sales ops | `[grounded]` silence in your summary | See G3 |
| R9 | Working as a team of one ("players who don't need a bench") | important | unclear | low | discovery | You describe building and managing teams of 3–7. Whether you have run the whole function hands-on without a team is not stated | `[grounded]` your message, silent on solo operation | See G4 |

## Gap recovery queue

R1 and R2 fail, so no recovery question could move the status, and none is asked.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO / content (R6, must_have) | discovery | Nothing on SEO or content in your summary | A must-have row at `unclear`; it could not outweigh R1 and R2 | Briefing or commissioning content for acquisition; owning organic landing pages or a content calendar | A traffic or ranking report, a content brief | `[grounded]` summary silence; `[inferred]` that it could not outweigh R1 and R2, from the hard-gate rule |
| G2 | Brand, PR, partnerships (R7, important) | discovery | Nothing on any of the three | An important-tier row; unresolved rows here leave the seven-function mandate only partly matched | A co-marketing partnership, a launch press push, a referral or affiliate deal you negotiated | A partnership agreement, a coverage list | `[grounded]` summary silence |
| G3 | Sales ops (R8, important) | discovery | Nothing on sales ops | Important tier; the posting folds it into the same mandate | Lead routing or scoring rules, CRM-to-sales handoff, pipeline reporting | A routing spec, a pipeline dashboard screenshot | `[grounded]` summary silence |
| G4 | Team of one (R9, important) | discovery | Team-building is described, solo operation is not | Important tier; the posting says the team starts at one | An early stint before your first hire, when you ran channels yourself | A channel plan from that period | `[grounded]` your message's team-building emphasis |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Office requirement conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role cannot be done from Portland on these terms. For you this is incompatible, whatever the market thinks of it | `[grounded]` JD quote against your confirmed constraint | Is the five-day Austin requirement firm for this role, or is a remote arrangement ever considered? | confirmed |
| RR2 | Base pay below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base is $65–80k under your floor. A seniority-to-pay mismatch is also possible, but no market band was established here, so it stays a hypothesis | `[grounded]` JD figures and your floor; `[inferred]` mismatch hypothesis, unverified | Is the base fixed at $70–85k, and what are the equity terms? | confirmed |
| RR3 | Several specializations bundled in one role | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | One person may be asked to cover work that is usually split across roles, at a price set for fewer | `[inferred]` JD function list against "a team of one" | Which of these seven functions are in scope in year one, and what is the plan for the first hires? | unresolved |
| RR4 | Budget and decision rights unstated | unknown | — | "Own all revenue growth end to end" | Accountability may come without spend authority or tools | `[inferred]` from the JD's silence on budget | What budget and decision rights come with the role? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine. "When it matters" is undefined | `[inferred]` from the JD's wording | How often does this happen in practice, and is it compensated? | unresolved |
| RR6 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be held accountable without a fixed definition of success | `[inferred]` from the JD's wording | What outcomes would define a good first year? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The upside cannot be valued without grant size and terms | `[grounded]` JD, no figures given | What are the grant size, vesting terms and current valuation basis? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR9 | Pay, office and reporting terms stated plainly | positive_signal | — | "Report to the CEO with a dotted line to the board"; "no exceptions" | The posting is transparent about the terms that matter most to you, so the mismatch shows up before you invest effort | `[grounded]` JD | Who on the leadership team would you work with most closely? | noted |

Research could not run, so RR8 stands as recorded.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't invest in an application on the posting's stated terms | see R1, R2, RR1, RR2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Optional: put the questions in RR1 and RR2 to Novaline through contact details you find on its own website. This only matters if you would genuinely take the job on changed terms | see RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | If terms did change, lead with your own account of R4 and R5 (paid, lifecycle, the $8M to $40M ARR scale-up as you described it) and state R6, R7 and R8 as areas you haven't described | see R4, R5, R6, R7, R8 | `[grounded]` your message | pending your approval |

## Evidence status

Verified: none yet. Your claims are self-report in prose.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A Head of Growth"; the call was refused, so nothing was read. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base salary range 2026"; the call was refused, so nothing was read. It would have moved the market calibration row and the seniority-to-pay hypothesis in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd like to offer the full write-up as `tuesday-dossier.md` if you want to carry this into other work.

## Upgrade menu

- Search access, or a link to Novaline's careers page → RR8 and the organization row resolve, and the market calibration row gets a band.
- An answer from Novaline on the remote and pay questions → RR1 and RR2 resolve, and the status could move only if both change.
- A CV with dated titles → R3 gets its leadership-years basis, and the band could rise toward `high` with an inspectable artifact such as a growth dashboard or a channel report.
- Anything on SEO/content, brand, PR, partnerships, sales ops or running growth without a team → R6 to R9 firm up.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.