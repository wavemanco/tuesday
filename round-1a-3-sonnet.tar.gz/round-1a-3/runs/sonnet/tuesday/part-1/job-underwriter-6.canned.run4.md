Read the posting and ran three checks on Quillfield, the pay band and Tamsin Achebe. Here is the assessment.

# Job Underwriting Assessment — Revenue Operations Lead at Quillfield

*Generated 2026-11-20. Stage assumed: evaluating. Your background was taken from your message and is self-report; no CV was provided.*

## Decision snapshot

**Yes, I'd go for it. Status: `conditional_go`.** R7b (billing data) is `absent` and R6 (forecast ownership) is `adjacent`, so apply with those named up front.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay)
- `must_have` — direct: R3a, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (owning a forecast), R7a (finance on revenue data) · unclear: R3b (B2B software company) · absent: R7b (billing data)
- `important` — direct: R8

R6 — adjacent through the monthly pipeline review, never owned; R7b — no billing-data work confirmed; R5 (`medium`) — confirmed use, depth unproven.

**Opportunity ledger.** Sound on what is visible: pay is stated and sits inside the market band (RR2), and the employer and the manager's function check out (RR4). Still open are whether Quillfield lists the role itself (RR1), how forecast and billing ownership is split (RR3), and what success looks like in year one (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days in the office), R2 (£61,500–£67,000 plus options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 sit inside your own limits; (2) R6 and R7b are carried honestly as adjacent and not yet exercised, and RR3's answer shows how much of both lands on you from day one; (3) RR1 verifies, meaning the role is open on Quillfield's own site.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own the CRM and billing data. Build the pipeline and renewal reporting that sales and finance run on. Run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Terms | Bristol, hybrid, two days a week in the office. £61,500–£67,000 plus share options | `[grounded]` JD |
| Requirements | 4+ years in revenue operations, sales operations or a similar analytics role at a B2B software company. HubSpot or Salesforce administration. Strong SQL and spreadsheet modelling. Experience owning a forecast. Experience working with finance on billing or revenue data | `[grounded]` JD |
| Scope read | Billing data is named in both the mandate and the requirements. Quillfield sells invoicing software, so finance-facing work is likely central to the seat | `[inferred]` from the JD's billing language and the company's product description |
| First-year outcomes | Not stated in the posting. The first visible deliverables are probably the pipeline and renewal reporting and a first forecast cycle with the CFO | `[inferred]` from the JD's three responsibilities |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; earlier, sales operations manager at Corvane Payments for four years. That she is the hiring manager comes from your recruiter | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield", snippet only; the recruiter's word as you reported it |
| Market calibration | UK B2B software revenue operations leads: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posting's range sits inside that band. This is a UK-wide pattern, not Bristol-specific and not this employer's offer. Share options are unvalued | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide, snippet only; `[grounded]` JD for the posted range |
| Unknowns | Whether Quillfield runs HubSpot or Salesforce. Reporting line and team size. Option terms. First-year outcomes | `[grounded]` JD silence |
| Contradictions | None between the posting and the company page. The role was not found on Quillfield's own careers page (see RR1) | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | You have not stated location or schedule limits, so this term is unsettled. Confidence grades your statement of a constraint, and there is none yet | `[grounded]` JD quote; no constraint stated | Gate question in the closing block |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated. For context, the posted range sits inside the market band, and the options are unvalued | `[grounded]` JD figure; `[generic]` Ledgerline band | Same gate question |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You have 5 years in sales operations, the last 2 running revenue operations for the UK team. This is self-report with nothing inspected. A years requirement is not a gate | `[grounded]` your background | none |
| R3b | …at a B2B software company | must_have | unclear | medium | discovery | You said B2B payments company; whether that reads as software is the employer's call. Quillfield sells payments and invoicing software, so the sector may read as close | `[grounded]` your statement; `[inferred]` from Quillfield's product description | Say in a line whether your employer sells a software product (G4) |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, not inspected. The posting accepts either CRM; which one Quillfield runs is not stated | `[grounded]` your statement; JD | A credential record would raise it to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily are stated. How often you use them does not show "strong" or "modelling" | `[grounded]` your statement | A sanitized query or model would settle it |
| R6 | Experience owning a forecast (the post runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You have not owned the company forecast; finance did. The adjacent work is the monthly pipeline review you run with your sales director. The limit is that a review is not forecast ownership | `[grounded]` your statement | G1 |
| R7a | Working with finance on revenue data | must_have | adjacent | low | discovery | You rebuilt renewal dashboards, which is revenue-adjacent work. Working with finance on them is not stated | `[grounded]` your renewal dashboards; `[inferred]` that they touch revenue data | G2 |
| R7b | Billing data (own it; work with finance on it) | must_have | absent | none | capability | You said you have never worked on billing data, and nothing adjacent is confirmed | `[grounded]` your statement | Closure path in G3 |
| R8 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is not stated (G2) | `[grounded]` your statement | A sanitized screenshot would raise it to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | You run the monthly pipeline review with the sales director; finance owned the forecast | R6 is a `must_have` at `adjacent`, and the JD has this post running the quarterly forecast with the CFO | Your pipeline numbers or commit calls going to finance for the forecast. Reconciling your pipeline view with finance's forecast. Explaining a miss in the review. A weighted-pipeline or renewal-projection report others relied on | A sanitized review deck, a pipeline-to-forecast reconciliation, a renewal projection sheet | `[grounded]` your statement that finance owned it; `[generic]` that these are common adjacent work in revenue operations seats |
| G2 | Finance on revenue data (R7a, must_have) | discovery | Renewal dashboards rebuilt; no finance involvement stated | Could lift R7a, and R8's reach | Finance supplying renewal or revenue figures. Agreeing a definition of renewal revenue with finance. Checking dashboard totals against finance's numbers | A dashboard definitions note or a sanitized screenshot | `[grounded]` your statement; `[inferred]` that resolving it moves R7a |
| G3 | Billing data (R7b, must_have) | capability | You said none, and nothing adjacent is confirmed | The posting names billing data in the mandate and in the requirements | Not recall: you told me no. The path is closure, such as learning how invoices, credit notes and payments flow into revenue, and building a small worked example on sample data | A work sample on public or sample invoice data, once built | `[grounded]` your statement; `[inferred]` that a work sample narrows this gap without closing it |
| G4 | B2B software company (R3b, must_have) | discovery | Your employer is a B2B payments company | Decides whether R3b reads as met | Your employer selling a software product or platform to business customers | Your employer's own product page | `[grounded]` your statement; `[inferred]` that this resolves R3b |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not seen on Quillfield's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed only through the job board and recruiter, or my search simply did not surface the page | `[inferred]` from the search returning the About page only | Is this role open on your careers site, and where is it listed? | unresolved |
| RR2 | Pay stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The posting is transparent on pay; the options are the unpriced part | `[grounded]` JD; `[generic]` Ledgerline band | What are the option terms: number, vesting and strike price? | noted |
| RR3 | Ownership of the forecast and billing data not split | unknown | — | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The post may carry forecast and billing ownership with no stated team, reporting line or finance counterpart | `[inferred]` from the JD's scope against its silence on team and reporting | Who owns the forecast and the billing data today, and what team and reporting line does this role have? | unresolved |
| RR4 | Employer and hiring manager's function check out | positive_signal | — | "Tamsin Achebe, Head of Revenue Operations at Quillfield" | The manager you were given sits in a matching function at the named company | `[grounded]` search result snippets | How would the work split between this role and your own? | noted |
| RR5 | First-year outcomes not stated | unknown | — | "build the pipeline and renewal reporting our sales and finance teams run on" | Success may be undefined for a demanding mandate | `[inferred]` from the JD's silence on outcomes | What would a good first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the operations story using the resume lines below | see R3a, R4, R8 | `[grounded]` your background | pending your approval |
| F1 | Name the forecast and billing gaps yourself, with the wording below | see R6, R7b | `[grounded]` your statements | pending your approval |
| W1 | A one-page worked example on public or sample invoice data, not employer data | see R7b, G3 | `[inferred]` a sample narrows the gap, it does not close it | pending your approval |
| Q1 | Ask RR1, RR3, RR5 and the option-terms question of RR2 verbatim, early | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | With Tamsin, lead in operating terms. Her public title and earlier sales operations role point to someone who knows the function; I can't say what she is looking for | see RR4 | `[inferred]` from her public title and prior role | pending your approval |

**Proposed resume lines** (`resume_edits_pending_approval`). I audited each clause against your own sentences. I have not seen your CV, so these are drafts to fit into it.

- E1a: "Sales operations, 5 years at a B2B payments company; the last 2 running revenue operations for the UK team." (your words: "5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team")
- E1b: "Salesforce admin certified. Rebuilt the pipeline and renewal dashboards. Run the monthly pipeline review with the sales director. SQL weekly, Excel daily." (your words, with "our" dropped so I don't claim a scope you didn't state)

**Proposed interview wording for F1** (`pending your approval`): "Finance owned the company forecast where I work, so I haven't owned one. What I do own is the monthly pipeline review with our sales director, and I rebuilt the pipeline and renewal dashboards. I haven't worked with billing data, and I'd want to learn how it flows here first." Each clause traces to your sentences; the last clause is intent, not history.

## Evidence status

Verified: none yet. Your claims are self-report from your message, not CV-checked. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers"; result "About Quillfield" (quillfield.co.uk/about). It confirmed the employer as described. No careers page came back, so the live posting is unconfirmed on the employer's own site (RR1) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol"; result "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration and RR2. It covered pay only, from the snippet |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager row, RR4 and A1; snippet only |

If it's useful, I can save this as a `tuesday-dossier.md` to carry forward.

## Upgrade menu

- Your CV: the fit rows get read against it, and the resume lines become specific edits.
- A Salesforce credential record: R4 to `high`.
- A sanitized screenshot of the pipeline and renewal dashboards: R8 to `high`, and G2 may resolve.
- A sanitized SQL query and a spreadsheet model: R5 firms up.
- Your answers on location, hours and pay limits: R1 and R2 move to `direct` or `hard_gate_fail`.
- The recruiter's or Tamsin's answers: RR1, RR3 and RR5 close.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

R1, R2 — Are there any limits on location, office days or pay that would rule this role out for you?

G1 — Where did your pipeline numbers go once the monthly review ended, and what part of that did you personally own versus finance?

G2 — Did you work with anyone in finance to build the renewal dashboards, and what data did they supply?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.