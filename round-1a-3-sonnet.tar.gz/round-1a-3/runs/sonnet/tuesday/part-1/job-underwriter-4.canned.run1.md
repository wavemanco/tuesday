I'm checking Brindlemoor's careers page, because its snippet says "Leeds office four days a week" and your posting says fully remote.
**Probably yes on fit, but settle the location first. Brindlemoor's own careers page says "Leeds office four days a week", while your posting says "Fully remote (UK)" (R1). Status: `hold_pending_answers`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R6, R7 · unclear: R5 (Monitor rating models)
- `preferred`: direct: R8

R1: the posting and the careers page disagree; R5 (`low`): monitoring is not yet evidenced.

**Opportunity ledger.** The role is live on the employer's own page, but its working pattern conflicts with the posting you were given (RR1). Pay (RR2) and team and book scale (RR3) are unstated. One entry runs the other way: a clear reporting line and a hiring manager with published work on rating-model monitoring (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on the actual working pattern (R1, RR1) and whether it suits you. If it does, the status would likely move to `go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the role reports to the Director of Pricing | `[grounded]` JD and Brindlemoor careers page |
| Mandate | Pricing analytics for the pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". The two conflict and I haven't resolved it | `[grounded]` both sources quoted |
| Experience asked | 4+ years, strong SQL and Python, GLMs, presenting to underwriting or actuarial leads. Insurance is "a plus"; pet insurance is not asked for. Neither source mentions line management or direct reports | `[grounded]` JD and careers page silence |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors") on monitoring rating models in small books, and was previously head of pricing analytics at Calloway Re for six years. I read a search snippet only | `[grounded]` search result |
| Scope read | Her published focus suggests rating-model monitoring will be probed, which is why R5 matters | `[inferred]` from the talk title against the JD's "monitor rating models" |
| Market calibration | Median base £58,400, interquartile range £52,100–£64,900 for UK senior pricing analysts at insurers and insurtechs (n=612). This is a market band, not Brindlemoor's offer, and the posting states no pay (RR2). Read from a snippet | `[generic]` Pricewell 2026 survey |
| Unknowns | Pay, team size, book size, rating-model stack | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a location or remote requirement, so the constraint is ungraded. The fit is unclear because the posting and the careers page conflict | `[grounded]` the two quoted sources | Ask whether a Leeds-based pattern works for you (question below) and confirm the real terms with Brindlemoor |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a motor insurer. Confirmed in prose, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Self-reported, nothing inspectable yet | `[grounded]` your background | A sanitized query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. Motor, not pet, which the JD doesn't require | `[grounded]` your background | A sanitized model summary would raise it |
| R5 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" doesn't establish what monitoring you did (performance tracking, drift, actual-versus-expected). I took the lower reading. A lead exists, so low rather than none | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with the underwriting team. Specific and confirmed, no artifact | `[grounded]` your background | A sanitized test readout would raise it |
| R7 | Present results and recommendations to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The posting asks for underwriting or actuarial leads | `[grounded]` your background | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance meets "insurance experience". Pet-insurance knowledge isn't asked for | `[grounded]` JD and your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Rating-model monitoring (R5, must_have) | discovery | "Built and maintained" the GLM, with no description of how performance was tracked | A must-have, and likely a focus for this hiring manager. Resolving it could lift R5 to `direct` | Regular actual-versus-expected reviews; drift or segment-performance dashboards; triggering a model refit from monitoring results; reporting model performance to underwriting | A sanitized monitoring pack, a dashboard screenshot, or a refit note | `[grounded]` CV-equivalent silence on monitoring; `[inferred]` from her talk that it will be probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between posting and careers page (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The posting you have may be older or from another source, the careers page may be stale, or the terms may differ by arrangement. None of these is ranked as likely | `[generic]` pattern of postings drifting from careers pages; `[grounded]` that the two texts conflict | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pay not stated in the JD | unknown | — | JD gives no salary | The offer may sit above or below the market band in role reality, or the company may not publish pay | `[inferred]` from the JD's silence against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Team and book scale unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be a lone analyst or part of a team, on a small or large book | `[inferred]` from the JD's silence on team and volumes | Who else sits in the pricing team, and roughly how large is the pet book and what is the rating stack? | unresolved |
| RR4 | Clear reporting line and a monitoring-minded hiring manager | positive_signal | — | "reports to the Director of Pricing" | The role has a defined owner with a stated interest in model monitoring | `[grounded]` careers page and search result | What does success look like in the first year? | noted |

## Application plan

Every row is proposed and nothing is applied until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before applying, confirm the working pattern with Brindlemoor through contact details on its own careers site | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead the application with the 14 price tests run with underwriting, then the quarterly pricing review you present to the head of underwriting, then the GLM you built and maintained. Use your own wording and state plainly that your experience is motor | see R6, R7, R4 | `[grounded]` your background | pending your approval |
| P2 | Add no pet-insurance knowledge or line-management claims. Neither is asked for, and neither is in your evidence | see R8, JD silence | `[grounded]` JD | pending your approval |
| Q1 | In interviews, ask the RR1 to RR4 questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance" (no results, so nothing established beyond the careers page) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirms the posting is live and surfaced the working-pattern conflict (R1, RR1) |
| 2. Role-family sweep | yes | Searched "Senior pricing analyst insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It moved the market calibration row |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It moved the scope read and P1's positioning |

I didn't find anything on Brindlemoor beyond its careers page, so its size and stage are unconfirmed.

I can write the full assessment up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your actual CV, plus a sanitized query, model summary or test readout → R2, R3, R4 and R6 could rise from `medium` to `high`.
- Your answer on location and pay floor → R1 resolves, and RR2 can be set against your floor.
- An answer to G1 → R5 may become `direct`.
- Brindlemoor's confirmation of the working pattern → RR1 and R1 close.
- A deeper research pass on Brindlemoor (funding, leadership, news; up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

1. **R1:** Where are you based, and would Leeds four days a week work for you, or is fully remote a must?
2. **G1:** How did you monitor your young-driver GLM after launch, and what did you do when it drifted? Please say which parts were yours.
3. **RR2:** What is your pay floor for a move like this?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.