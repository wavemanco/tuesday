Searching was refused, so this runs without research. The three searches were counted, and the Evidence status section shows the effect.

## Decision snapshot

**Yes, apply, on conditions: R2, R3, R4, R5a, R6, R7a and R8 land `direct`. Your missing pet experience (R10) is a preferred-tier bridge, not a blocker. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models), R7b (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R10 — a credible bridge, its limit named; R5b, R7b — unconfirmed, waiting on your answers.

**Opportunity ledger.** The employer could not be checked (RR1), the team and reporting lines are unstated (RR2), and the JD gives no pay (RR3). One entry runs the other way: the responsibilities are concrete (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) you confirm R1; (3) pet is framed as adjacent, never as pet-pricing experience (R10); (4) your answers on G2 and G3 hold up (R5b, R7b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not checked externally |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Reporting line | Odile Varga, Director of Pricing | `[grounded]` your message |
| Seniority read | 4+ years is asked; you have 5, the last 2 as senior analyst | `[grounded]` JD and your background |
| Line management | The JD lists no management requirement; whether the role has reports is unstated | `[grounded]` JD silence |
| Market calibration | Not done, because the role-family sweep could not run. The JD states no pay, so there is no band and no comparison | `[grounded]` JD silent on pay |
| Unknowns | Pay, team size, reports, tooling, how mature the pet product is, how success is measured | — |
| Contradictions | None inside the JD. JD against careers page was not checked | `[grounded]` JD; careers page unchecked |

## Evidence map

Confidence stays at `medium` or below because everything comes from your typed background, which is self-report until probed.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | Your message gives no location or right-to-work statement. A UK motor insurer role suggests UK, but that is not a confirmed constraint | `[grounded]` JD term; `[inferred]` UK from your employer | Question R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, against a length requirement graded on fit, not as a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. Depth is not described, and no artifact has been inspected | `[grounded]` your background | Be ready to describe a model-build or analysis you did end to end |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | none |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which may include monitoring but does not say what was tracked. I take the lower band | `[grounded]` your wording; `[inferred]` that maintenance may cover monitoring | Question G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests with underwriting last year. "Ran" is your word: the design choices and the readout are not described, so expect a probe | `[grounded]` your background | Prepare to describe test design and readout in your own terms |
| R7a | Recommendations to underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7b | Recommendations to product | must_have | unclear | low | discovery | Nothing in your background touches a product or proposition owner | `[grounded]` silence in your background | Question G3 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | The quarterly review to the head of underwriting is a direct match for underwriting leads. Actuarial leads are not mentioned | `[grounded]` your background | none |
| R9 | Insurance experience | preferred | direct | medium | none | 5 years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge | preferred | adjacent | low | transferability | Inferred requirement: the JD names the pet product but does not ask for pet experience. You have none, and said so. The GLM work carries over. The limit is that pet-specific rating factors and claims behaviour are untested in your evidence | `[grounded]` your statement; `[inferred]` bridge from the GLM work | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based, fully remote (R1, hard_gate) | hard_gate | The JD says fully remote, UK. Your message does not state your location or right to work | An unconfirmed gate caps the decision at `conditional_go` until answered | Not experience: this is a term you meet or don't | Your own statement is enough | `[grounded]` JD and your message |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Built and maintained" is stated. What was tracked after go-live is not | JD pairs build with monitor; resolving it moves R5b to direct | Actual-versus-expected tracking by rating factor; drift checks or refresh triggers; a periodic model review; loss-ratio checks after a rate change | A sanitised monitoring pack, a model review paper, or a dashboard screenshot | `[grounded]` silence in your background; `[inferred]` that "maintained" may include monitoring |
| G3 | Recommendations to product (R7b, must_have) | discovery | All your recommendations are described as going to underwriting | JD names product as a recipient; resolving it moves R7b to direct | A test result that changed a product feature, discount or proposition; a rate change agreed with a product or commercial owner | A test readout or a review deck extract | `[grounded]` silence in your background |
| G4 | Pet-insurance domain (R10, preferred) | transferability | A young-driver motor GLM and 14 tests, with no pet pricing | Preferred tier, so a minor risk; the bridge case is what Odile will probe | Pricing a small or novel segment; frequency and severity modelling on thin data | A sanitised model summary showing how you handled a thin-data segment | `[grounded]` your statement; `[inferred]` the bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Team and reporting scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the sole pricing analyst for the product, or part of a team. Reports are unstated | `[inferred]` from the JD's "own" against its silence on team | Who else works on pricing for this product, and does this role have or expect to gain direct reports? | unresolved |
| RR3 | Pay not stated | unknown | — | The JD you pasted contains no pay figure | The range may be shared later or may sit below what you want | `[grounded]` JD silent; `[inferred]` the rest | What salary range is budgeted for this role? | unresolved |
| RR4 | Responsibilities are concrete | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The scope is defined and matches work you have done | `[grounded]` JD | What would a successful first year look like in this role? | noted |

To clear RR1: a link to the live role on Brindlemoor's own careers page, or the recruiter's email domain.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Brindlemoor and the live posting through its own careers site before investing in an application | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV summary with three claims in your own words: built and maintained the GLM rating model for the young-driver book; ran 14 price tests with underwriting last year; present the quarterly pricing review to the head of underwriting | R4, R6, R8 | `[grounded]` your background | resume_edits_pending_approval |
| B1 | Say plainly in the loop: "I haven't priced pet insurance. I built and maintained the GLM rating model for our young-driver book, ran 14 price tests with underwriting last year, and present the quarterly pricing review to the head of underwriting." | R10 | `[grounded]` your own statements | pending your approval |
| Q1 | Put RR2, RR3 and RR4's questions to Odile verbatim, including the one on reports | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Nothing in this plan is final until you approve it. If you decide to apply, the resume-tailor module can do the line-by-line CV edits.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech"; the call was refused, so nothing came back. It would have fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "Senior Pricing Analyst pet insurance UK salary remote"; the call was refused. It would have fed the market calibration line and the pay check in RR3 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have fed the scope read and which story to lead with |

If you want a portable record of this assessment, I can emit it as `tuesday-dossier.md`.

## Upgrade menu

- A link to, or pasted text of, the role on Brindlemoor's own careers page: RR1 narrows or closes, and role reality's contradictions row gets checked.
- Your location and right to work: R1 resolves, and the hard-gate checks run against your real constraints.
- A sanitised monitoring pack (a model review or an actual-versus-expected report): R5b moves to direct, and R4 and R5a can reach `high`.
- A sanitised price-test readout: R6 can reach `high`.
- A sanitised quarterly pricing review deck: R7a and R8 can reach `high`.
- The salary range: RR3 closes, and the figure can be compared with your own floor.
- Anything public you find on Odile Varga's professional background, such as a profile or talk (paste it): role reality's scope read and the lead story in the plan.

Questions:

R1 — Are you UK-based with the right to work in the UK, and is there a pay or hours line you won't cross?

G2 — After your young-driver GLM went live, what did you monitor (for example, actual against expected, drift, refresh triggers), and who owned it?

G3 — Has any price-test result or rate change gone to a product or commercial owner rather than underwriting? What was yours to decide, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.