Search permission wasn't granted, so this read rests on the posting and your background alone.

# Job Underwriting Assessment: Head of Growth at Novaline

## Decision snapshot

**No. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin, 5 days a week), R2 (Base $70–85k)
- `must_have` — direct: R3, R4, R5
- `important` — unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one, no bench)

R1 — location conflicts with your remote-only limit; R2 — base pay conflicts with your $150k floor; R3 (`medium`) — nine years stated, no artifact yet; R6, R7, R8 — your background does not address them yet.

**Opportunity ledger.** Judged apart from your fit, the posting puts seven functions on one person with no stated team, budget or success metrics (RR3, RR6, RR7). It also pays $70–85k against an 8+ year mandate (RR4) and expects evenings and weekends (RR5). Novaline's own claims about itself are unverified (RR8). One entry runs the other way: the CEO reporting line (RR9).

- **Hard gates:** failed: R1 (On-site Austin office 5 days a week), R2 (Base $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the employer changing R1 to allow remote work from Portland and R2 to a base of at least $150k, or you revising your own limits, which is your call. R1's own wording is "no exceptions."

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; the company's own description, not checked |
| Mandate | Own all revenue growth end to end across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Scope read | Seven functions, one person, no bench: this reads as a whole growth department asked of a single hire | `[inferred]` from the function list against "team of one to start" |
| Working pattern | Austin office 5 days a week "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside"; no equity figure given | `[grounded]` posting |
| First-year outcomes | None stated; "success metrics will evolve" | `[grounded]` posting |
| Market calibration | Not run: search was unavailable, so the pay band is uncalibrated | `[grounded]` research tier line below |
| Unknowns | Budget, hiring plan, equity terms, who sets targets | `[grounded]` posting silent on each |
| Contradictions | None inside the posting; not checked against Novaline's own site | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own confirmed statement that you are remote-only and in Portland. Fit fails because the posting rules out exceptions | `[grounded]` JD quote and your statement | Surface only; wording cannot solve it. Only the employer changing terms or you revising the limit resolves it |
| R2 | Base $70–85k (your floor: $150k) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your confirmed floor. Fit fails because the posted maximum is below it | `[grounded]` JD quote and your statement | Surface only; equity is unquantified in the posting |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years, growth lead then Head of Growth. Self-reported, nothing inspectable yet | `[grounded]` your prose background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid. Spend levels and channels are not stated | `[grounded]` your prose background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and name Braze. No artifact yet | `[grounded]` your prose background | none |
| R6 | SEO/content | important | unclear | none | discovery | Your background lists paid, lifecycle and experimentation. Silence is not absence | `[grounded]` your prose background | Gap queue G1 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing in your stated background addresses these | `[grounded]` your prose background | Gap queue G2 |
| R8 | Sales ops | important | unclear | none | discovery | Your background names no sales-ops work | `[grounded]` your prose background | Gap queue G3 |
| R9 | Working as a team of one (inferred from "team of one to start") | important | unclear | low | discovery | You led teams of 3–7, which is the opposite shape. Your SQL, GA4 and Braze depth suggests hands-on work, but that is my reading | `[inferred]` from team size and tool list | Gap queue G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, important) | discovery | No SEO or content work stated | Ownership of this channel is in the mandate | Programmatic or editorial SEO you directed, content that fed subscription acquisition | A channel performance report or organic-traffic dashboard | `[grounded]` background silence |
| G2 | Brand, PR, partnerships (R7, important) | discovery | Nothing stated | Three more functions sit under the mandate | Launch PR, affiliate or co-marketing deals, brand campaigns | A partnership summary or campaign recap | `[grounded]` background silence |
| G3 | Sales ops (R8, important) | discovery | Nothing stated | Named in the mandate | CRM-to-revenue handoffs or lead routing you built | A process doc or pipeline dashboard | `[grounded]` background silence |
| G4 | Solo execution (R9, important) | discovery | Team leadership stated, solo output not | The posting says "team of one" | Periods where you personally ran several channels at once | A role or period summary | `[inferred]` from team sizes stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your limit (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The posted location term conflicts with your remote-only, Portland-based limit | `[grounded]` JD quote and your statement | Does the five-day Austin requirement allow any remote arrangement for this role? | confirmed |
| RR2 | Base pay below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted base sits below your $150k floor whatever the equity is worth | `[grounded]` JD quote and your statement | Is $70–85k the full cash budget, and what equity grant is meant? | confirmed |
| RR3 | Bundled specializations, no team | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one to start" | Several full roles may be folded into one title and priced for fewer | `[inferred]` from the function list against the team and pay terms | Which functions have agency or contractor support, and when is the first hire planned? | unresolved |
| RR4 | Seniority-pay mismatch | risk_signal | medium | "8+ years growth leadership required… $70–85k base" | Pay may sit below what this mandate usually commands; no band was calibrated, so this stays a signal | `[inferred]` from the posting's years and scope against its pay; research unavailable | How was the base range set against the 8+ years and this scope? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than occasional | `[inferred]` from the phrasing | In the last quarter, how often did growth work run into evenings or weekends? | unresolved |
| RR6 | No definition of success on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue growth without agreed targets | `[inferred]` from the posting's silence | What does success look like at 90 days and 12 months, and who sets it? | unresolved |
| RR7 | Authority and budget not stated | unknown | — | "Own all revenue growth end to end" | The role may carry revenue accountability without named budget or decision rights | `[inferred]` from the posting's silence | What budget and decision rights does this role hold? | unresolved |
| RR8 | Employer unverified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Existence, stage and profitability are the posting's own claims; research did not run, so none is established either way | `[grounded]` posting's self-description | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR9 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has direct founder access | `[inferred]` from the reporting line | Who sets this role's growth targets, the CEO or the board? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | see R1, R2 | `[grounded]` map rows | pending your approval |
| A2 | If you proceed against `no_go`, ask the register's verification questions verbatim before investing time; none of them can change what the posting says on R1 or R2 | see RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | On future postings, check location and pay terms against your two limits before reading anything else | see R1, R2 | `[grounded]` your stated limits | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Head of Growth" was refused. It would have moved RR8 (whether Novaline exists as described and the posting is live) |
| 2. Role-family sweep | unavailable | The search "Head of Growth Series A startup salary range base compensation 2026" was refused. It would have moved the market-calibration row and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` if you want a record of it.

- Permission to search → RR8 and RR4 get checked against Novaline's own pages and a market band. Neither would change `no_go`.
- Your resume, or an artifact such as a channel performance report, a Braze dashboard or the $8M-to-$40M ARR summary → R3, R4 and R5 can reach `high`.
- Anything on SEO, brand/PR/partnerships, sales ops or solo execution → R6 to R9 move off `unclear`.
- The hiring manager's name → role reality's scope read.

No questions this turn: no answer you could give would change `no_go`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.