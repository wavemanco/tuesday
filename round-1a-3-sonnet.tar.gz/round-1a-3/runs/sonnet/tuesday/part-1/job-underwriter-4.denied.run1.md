Web search was refused here, so this runs on your pasted JD and background only.

## Decision snapshot

**Yes, apply, on conditions. Pet insurance (R10) is a bridge rather than a block, and the JD names no people-management requirement. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7a, R8 · adjacent: R5b (Monitor rating models)
- `important`: unclear: R7b (Recommendations to product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R10 is a credible bridge with its limit named; R5b is adjacent because "maintained" is your word and "monitored" isn't; R7b has nothing in your background on product yet; R1 is waiting on your location answer.

**Opportunity ledger.** The employer is unchecked (RR1) and the pay is withheld (RR2). The scope is concretely stated (RR3), and team size and direct reports are unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and a live posting verified (RR1). (2) Your UK location and right to work confirmed (R1). (3) Pay checked against your floor (RR2). (4) Product-facing recommendation experience confirmed, or framed honestly as absent (R7b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product; not checked beyond the posting | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing; public footprint not researched | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Pay | Not stated in the pasted JD | `[grounded]` JD as pasted |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Scope read | A hands-on senior individual-contributor post for one product line; the JD mentions no reports | `[inferred]` from "Own pricing analytics" and the JD's silence on reports |
| Market calibration | Not established: the role-family search was refused, so no band is given | `[grounded]` search refused |
| Unknowns | Pay; team size and direct reports; who signs off price changes; whether the posting is live | `[grounded]` JD silence |
| Contradictions | None between the JD and your background; the employer's own pages were not checked | `[grounded]` the two inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | The JD states the term; you didn't state your location or right to work. UK employment history points to UK residence, but that is a reading, so the band is low | `[grounded]` JD; `[inferred]` from UK motor-insurer employment | G1 question below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years in pricing analytics at a UK motor insurer, specific and confirmed, no document inspected | `[grounded]` your background message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated; "strong" is a depth claim with no artifact yet, so expect a probe | `[grounded]` your message | offer: a sanitized query or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book; specific, limited inspectable proof | `[grounded]` your message | offer: a sanitized model spec or factor-selection note would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | Same claim as R4, covered by "built" | `[grounded]` your message | none |
| R5b | Monitor rating models | must_have | adjacent | low | discovery | "Maintained" is adjacent to monitoring but isn't it. I take the lower reading | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | see G4 |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting. "Ran" is your verb; design and readout ownership aren't separated, so the claim stays at "ran" | `[grounded]` your message | say "ran" until you confirm what you designed and read yourself |
| R7a | Recommendations to underwriting | must_have | direct | medium | none | Tests run with the underwriting team, and a quarterly pricing review presented to the head of underwriting | `[grounded]` your message | offer: a sanitized review deck would raise to high |
| R7b | Recommendations to product | important | unclear | low | discovery | Nothing you described touches a product function; it may exist unstated | `[grounded]` your message's silence | G2 question below |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer, though not pet | `[grounded]` your message | none |
| R10 | Pet-insurance product knowledge (not a listed requirement) | preferred | adjacent | medium | transferability | GLM rating and price testing carry over from motor. The limit is that you've done no pet-specific work. `[generic]` Pet rating typically uses different rating factors from motor | `[inferred]` from the JD's "our pet-insurance product"; `[grounded]` your stated gap | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location and right to work (R1, hard_gate) | hard_gate | The JD says fully remote (UK); your message doesn't state where you live or your right to work | A gate the inputs don't settle; it caps the status until answered | None needed; a plain statement of status | None | `[grounded]` JD term and your message's silence |
| G2 | Recommendations to product (R7b, important) | discovery | Underwriting-facing work is clear; no product-facing work is described | Decides whether the JD's second audience is covered or a stated gap | A pricing change you briefed to a product or proposition team; a new-feature or cover-level pricing input; a launch you supplied rating for | A briefing note, a review slide, a launch pricing paper | `[grounded]` message silence; `[generic]` that pricing and product teams commonly share decisions |
| G3 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM rating and price testing, none in pet | Likeliest objection at screening; a bridge with a named limit reads more credibly | Any exposure to frequency/severity modelling on a non-motor line; any pet or small-claims data you've touched | A sanitized model note or analysis on a non-motor line | `[inferred]` bridge from the motor work; `[generic]` that this is the likeliest objection |
| G4 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is stated; ongoing monitoring isn't | A must-have at adjacent; the fix could be wording rather than new evidence | Tracking the model's actual-versus-expected results over time; flagging model drift; a periodic performance report | A monitoring report or dashboard screenshot, sanitized | `[grounded]` your wording; `[inferred]` that maintenance may have included monitoring |

I haven't put a question on G4 this turn. G1, G2 and the pay floor could move the decision; G4 more likely moves wording.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | Unchecked here because no search ran. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | The pasted JD states no pay | The figure may sit below what the seniority would command, or the posting may simply omit it | `[inferred]` from the JD's silence; no market band was established | What salary is budgeted for this post? | unresolved |
| RR3 | Responsibilities concretely stated | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | Scope is defined at the level of tasks and audiences | `[grounded]` JD | Which decisions do these recommendations feed, and who signs off price changes? | noted |
| RR4 | Team size and reports unknown | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean a sole analyst on the product, and the post may or may not carry reports | `[inferred]` from the JD's wording and silence on team | How big is the pricing team, and does this role have direct reports? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with your own three statements, reordered and with no new wording: the young-driver GLM model you built and maintained; the 14 price tests you ran with underwriting; the quarterly pricing review you present to the head of underwriting | See R4, R6, R8 | `[grounded]` your message | pending your approval |
| E2 | Keep your own verbs, "ran" for the tests and "maintained" for the model, until you confirm what you designed and monitored | See R5b, R6 | `[grounded]` your wording | pending your approval |
| A1 | Find Brindlemoor's own careers page and confirm the role is live before applying | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Say plainly that you haven't worked on pet insurance. The carry-over is motor GLM rating and price testing; the limit is pet-specific rating you haven't done | See R10 | `[grounded]` R10 row | pending your approval |
| Q1 | Ask the RR1 to RR4 verification questions verbatim in the first conversation, including whether the post has reports | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Brindlemoor's careers and site was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search for market scope and pay for this title was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | A name was given but the search was refused. It would have moved the scope read and which story the plan leads with |

If you'd like, I can write this up as `tuesday-dossier.md` to carry forward.

## Upgrade menu

- Allow web search here to run the three targets above: Brindlemoor's own pages (RR1), a pay and scope band (RR2 and the market calibration row), and Odile Varga's public professional footprint (the scope read).
- A deeper research pass on Brindlemoor (funding, leadership churn, public staff reports, recent news; up to 5 more searches and 2 more fetches), if search is allowed.
- Sanitized artifacts: a query or notebook (R3), a model spec (R4), a review deck (R7a, R8). Each would move its row toward `high`.
- Your answer to G2 resolves R7b; your answer on location resolves R1; a monitoring report resolves R5b.
- The recruiter's reply on pay and team resolves RR2 and RR4.

G1: Are you UK-based with the right to work in the UK, and does fully remote within the UK suit you?
G2: Have you briefed pricing results to a product or proposition team, such as a cover change, a new feature or a launch, and what did you own?
RR2: What is your pay floor for this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.