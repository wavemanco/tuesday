Checked the live posting and the about page against what you pasted. The full read follows.

## Decision snapshot

**Yes, this looks worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Based in the US, remote or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R7 — a credible bridge, its limit named; R10, R11 — responsibilities your background doesn't speak to yet.

**Opportunity ledger.** Clear on pay and stack (RR1), thin on equity terms (RR2), team shape (RR3) and on-call expectations (RR4). Nothing in the register argues against applying.

- **Hard gates:** none failed; unconfirmed: R1 (Based in the US, remote or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed against your own location and pay terms; (2) RR3's reporting line and team shape confirmed in the first conversation; (3) BigQuery presented as adjacent to your Snowflake work, never as experience (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page fetched; matches your paste |
| Posting status | Live, shown as accepting applications; its text matches your paste | `[grounded]` careers page fetched |
| Mandate | Pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Reads as an individual-contributor post owning a reporting pipeline domain. The posting names no team, no reports and no hiring manager | `[inferred]` from the JD's silence on team and reporting line |
| First-year outcomes | None stated. The likely shape is app and CRM ingestion into BigQuery models with contracts and tests | `[inferred]` from the responsibilities list |
| Market calibration | The stated $148,000–$166,000 sits around the median ($151,000) at the low end and runs past the top of the interquartile range ($139,000–$163,500). "Senior" typically means 5–8 years with one domain's pipelines and no reports. Basis: the Datawright 2026 report you supplied, n=2,310, Series B–D. A band, not this employer's offer | `[generic]` role-family band; `[grounded]` the JD's own figure |
| Unknowns | Equity size and vesting; reporting line and team size; on-call load; who the analysts are | — |
| Contradictions | None between your paste and the live pages | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the US, remote or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated your location, so whether the posting's terms are met isn't established | `[grounded]` JD term; no candidate statement given | Q1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the range, but your pay floor isn't given, so the term can't be checked | `[grounded]` JD figure; no candidate floor given | Q1 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a payroll company, confirmed in your message but with no inspectable artifact yet. Six sits inside the typical senior span of 5–8 years | `[grounded]` your stated 6 years; `[generic]` the typical span, from the report you supplied | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily," specific but unprobed. A repo link or sanitized code sample would be the inspectable artifact | `[grounded]` your stated background | Offer: a sanitized model or DAG sample would raise it to `high` |
| R5 | dbt | must_have | direct | medium | none | Built the dbt project on Snowflake, about 180 models. Specific and plausible, with no artifact inspected | `[grounded]` your stated background | Offer: a sanitized lineage-graph view or model list would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The posting's BigQuery wording is carried separately in R7 | `[grounded]` your stated background | none |
| R7 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The carry-over is dbt modelling and warehouse SQL on Snowflake. The limit: you have not used BigQuery, so its cost model, partitioning and adapter specifics are unexercised | `[grounded]` your "never used BigQuery"; `[generic]` that BigQuery-specific cost and partitioning habits differ from Snowflake's | See G1 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as your orchestrator; unprobed | `[grounded]` your stated background | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, a specific claim with no artifact inspected. How far you owned it beyond setup is unasked | `[grounded]` your stated background | Offer: sanitized suite config or data docs would raise it to `high` |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Nothing you've said covers ingesting product-app or CRM data. A payroll company may have had comparable sources, but that's not established | `[grounded]` background silent on sources | See G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your tests may overlap with contract work, but no stated experience defines schemas or agreements with downstream consumers | `[grounded]` background silent on contracts | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Strong dbt and warehouse-SQL work on Snowflake; no BigQuery use | The posting names BigQuery in its first sentence, so expect it to come up | Bridge: dbt modelling and warehouse SQL carry over. Limit: no BigQuery cost, partitioning or adapter experience. Strengthener: a small dbt-on-BigQuery project built in a free sandbox | A short public or sanitized repo, or a dbt project run against BigQuery | `[grounded]` your stated gap; `[generic]` that BigQuery differs from Snowflake on cost and partitioning |
| G2 | Ingestion from app and CRM (R10, important) | discovery | The background doesn't say where your pipelines' data came from | It is the first responsibility the posting lists | Pulling product-event data or a CRM export (Salesforce, HubSpot) into the warehouse; building or maintaining connectors; handling API limits or late-arriving data | A DAG, ingestion design note or architecture diagram, sanitized | `[grounded]` background silent on sources; `[inferred]` that it matters because the JD lists it first |
| G3 | Data contracts (R11, important) | discovery | Great Expectations tests exist; schemas or agreements with downstream analysts aren't mentioned | The posting names the contracts analysts depend on as a core output | Agreeing column definitions or freshness expectations with analysts; failing a build when an upstream schema changes; documenting model owners and expectations | A dbt schema file with contracts or tests, or a data-expectations doc, sanitized | `[grounded]` background silent on contracts; `[inferred]` that your test-suite work overlaps |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is clear and sits at or above the market median, with its top above the interquartile ceiling, so there's no seniority-pay mismatch | `[grounded]` JD figure; `[generic]` band from the report you supplied | Where in the range would an offer for my experience land? | noted |
| RR2 | Equity unquantified | unknown | — | "plus equity" | The grant size, vesting and strike may be material or negligible; the posting doesn't say | `[inferred]` from the JD naming equity without terms | What is the equity grant for this level, and what are the vesting terms? | unresolved |
| RR3 | Team shape and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may own the domain alone or inside a team. The posting names no manager and no teammates | `[inferred]` from the JD's silence | Who does this role report to, and who else works on the data platform? | unresolved |
| RR4 | On-call expectations unstated | unknown | — | "Build and run the pipelines" | "Run" may include out-of-hours incident response; the posting doesn't say | `[inferred]` from the word "run" | Is there an on-call rotation for this role, and how often do pipelines page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and pay floor against R1 and R2 before investing in the application | The decision waits on these | `[grounded]` R1, R2 rows | pending your approval |
| E1 | Lead with your own words: built the dbt project on Snowflake, about 180 models; set up the Great Expectations test suite; Airflow orchestration. State Snowflake explicitly and make no BigQuery claim | These cover R5, R8 and R9; R7 stays adjacent | `[grounded]` your stated background | pending your approval |
| W1 | A small dbt-on-BigQuery project, if you want to narrow the limit in G1 | Strengthens R7 with an inspectable artifact | `[inferred]` from G1 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Tailoring the resume to this posting is resume-tailor's job, if you decide to go ahead.

## Evidence status

Verified: none yet. Unverified leads: none from prior context. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Both calls checked your pasted text against the live pages. Role reality: organization, posting-status and contradictions rows; the employer attributes and the posting is live, so no failed-attribution entry |
| 2. Role-family sweep | skipped | Your pasted Datawright report already fixes the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

If you'd like to carry this forward, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your location and pay floor → R1 and R2 settle; the status likely becomes `go` or `no_go`.
- Answers to G2 and G3 → R10 and R11 move from `unclear` toward `direct` or `adjacent`.
- Your actual resume → rows now rest on your prose, so confidence is capped at `medium`; the resume lets each row be checked against your own lines.
- A sanitized dbt lineage view, Great Expectations config or DAG sample → R4, R5, R8 and R9 toward `high`.
- Equity terms, or the hiring manager's name once known → RR2 and RR3 close, and the scope read in role reality firms up.
- A deeper research pass on Pellucid Learning (funding and leadership changes, hiring patterns, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

Q1 (R1, R2) — What are your non-negotiables on location and pay: where you're based and authorized to work, and the lowest base you'd accept?

G2 — Have you ingested data from a product application or a CRM into your warehouse? What did you own, and what went wrong or needed handling?

G3 — Have you agreed schemas, definitions or freshness expectations with the analysts who consume your models? What happened when an upstream change broke one?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.