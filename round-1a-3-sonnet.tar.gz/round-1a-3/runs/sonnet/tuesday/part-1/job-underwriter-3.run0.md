Web search was declined, so this runs on your posting and background alone.

## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, five days a week), R2 (Compensation: $70–85k base)
- `must_have`: direct: R3, R4, R5
- `important`: adjacent: R10 (Execute seven functions solo, no team) · unclear: R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops)

R1 and R2 — your two stated limits, each contradicted by the posting's own words; R3, R4 and R5 — your background lines up with what the posting asks for; R10 — a bridge, its limit named.

**Opportunity ledger.** What feels off sits in the role, not in your fit: seven functions are bundled into one person (RR3), the pay doesn't match the seniority asked for (RR4), the hours are open-ended (RR5), and success is left undefined (RR6). The employer is unverified from here (RR8). One entry runs the other way: pay and office terms are stated openly, so you can rule the role out in minutes (RR9).

- **Hard gates:** failed: R1 (On-site in Austin, five days a week), R2 (Compensation: $70–85k base).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting would have to say a base of at least $150k (R2, RR1) and allow a Portland-based hire to work remotely (R1, RR2). It currently says "no exceptions" on the second.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" (the employer's own claims) | `[grounded]` posting header; not verified, since research did not run |
| Mandate | Own all revenue growth: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops; "a team of one to start" | `[grounded]` posting |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figures given | `[grounded]` posting |
| Seniority | "8+ years growth leadership required" | `[grounded]` posting |
| Success measures | "Success metrics will evolve as we learn"; no first-90-days or first-year outcomes stated | `[grounded]` posting silence |
| Scope read | Seven functions for one hire reads as several roles folded into one title, priced as one | `[inferred]` from the function list against "team of one" and the base range |
| Market calibration | Not run, so there is no band for this title and scope, and none is claimed here | The upgrade menu says what a sweep would add |
| Unknowns | Marketing budget; equity size and vesting; what the evolving metrics will be; the board's role; whether the company and posting check out | `[grounded]` posting silence on each |
| Contradictions | None inside the posting. A "Head of" title beside a team of one and $70–85k is a tension (RR3, RR4) | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in our Austin office 5 days a week — no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit (remote-only, in Portland, not relocating). The gate fails because the posting rules out remote work in the words "no exceptions" | `[grounded]` posting quote and your confirmed constraint | Surface it. Only the employer changing terms, or you revising the limit, resolves it |
| R2 | Compensation: $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor of $150k base. The gate fails because the top of the posted range is below it | `[grounded]` posting figure and your confirmed constraint | Surface it. Wording cannot close a gap this size |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You gave 9 years, with growth lead and then Head of Growth titles. It is self-reported and nothing has been inspected | `[grounded]` your background as stated | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You stated you owned paid at two B2C subscription companies, and controlled a budget in the $8M to $40M ARR scale-up. Nothing inspected | `[grounded]` your background as stated | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You stated you owned lifecycle and are deep in Braze. Nothing inspected | `[grounded]` your background as stated | none |
| R6 | SEO/content | important | unclear | low | discovery | Your summary names paid, lifecycle and experimentation and says nothing on SEO or content. Silence is not evidence either way | `[grounded]` silence in your summary | Recall prompt G1, in the gap queue |
| R7 | Brand and PR | important | unclear | low | discovery | Same silence in your summary | `[grounded]` silence in your summary | Recall prompt G1 |
| R8 | Partnerships | important | unclear | low | discovery | Same silence in your summary | `[grounded]` silence in your summary | Recall prompt G1 |
| R9 | Sales ops | important | unclear | low | discovery | Same silence in your summary. The posting's "sales ops" and "partnerships" suggest a B2B motion, while your stated experience is B2C subscription | `[grounded]` silence in your summary; `[inferred]` B2B reading from the posting's function list | Recall prompt G1 |
| R10 | Execute seven functions solo, no team ("team of one to start") | important | adjacent | low | transferability | Carries over: hands-on channel ownership plus team-building (teams of 3–7). The limit: nothing stated shows you running this many functions alone | `[inferred]` from your stated team sizes and channel ownership | Gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand and PR, partnerships, sales ops (R6, R7, R8, R9, important) | discovery | Your summary is silent on all four | They are all `important` rows, but the status is already `no_go` on R1 and R2, so closing them would not change the decision | Owning a content calendar or organic channel; a launch with press coverage; a co-marketing or affiliate partner; CRM or pipeline reporting you built for a sales team | Organic traffic report, a partner agreement, a press clip, a sales dashboard | `[grounded]` your summary's silence; `[inferred]` that it can't move the status |
| G2 | Running multiple functions with no team (R10, important) | transferability | Hands-on ownership of paid, lifecycle and experimentation, and teams of 3–7, but no stated stretch alone across this many functions | Shows how much of this seven-function remit is bridged and where the limit sits | A period when you executed channels yourself with no reports; a stage before a team existed | A channel P&L or plan from that period | `[inferred]` bridge from your stated experience |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay below your stated floor (R2) | red_flag | high | "$70–85k base" | The posted range conflicts with your $150k base requirement at every point in it | `[grounded]` posting figure and your confirmed floor | Is $70–85k the budget for this post, or is it open for a hire with 8+ years of growth leadership? | confirmed |
| RR2 | On-site five days conflicts with your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out remote work in terms, so you cannot work from Portland | `[grounded]` posting quote and your confirmed constraint | Is the five-day on-site requirement fixed for this post? | confirmed |
| RR3 | Responsibility without resources, bundled specializations | risk_signal | medium | "Own all revenue growth end to end… You will be a team of one to start" | One person is accountable for seven functions, with no stated budget or help. Several roles may be folded into one title | `[inferred]` from the function list against "team of one" and the silence on budget | What budget and headcount are committed for the first year, and which of the seven functions come first? | unresolved |
| RR4 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required… $70–85k base" | The range may sit below what this mandate commands. No market band was fetched, so this is a pattern, not a measurement | `[generic]` role-family pattern; `[grounded]` the posted figures | How was the base range set, and against which market data? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine and not occasional | `[inferred]` from the posting's phrasing | How often in the last six months were evenings or weekends needed? | unresolved |
| RR6 | Success metrics left undefined on a demanding mandate | risk_signal | medium | "Must thrive on ambiguity; success metrics will evolve as we learn" | Accountability for all revenue growth with no agreed definition of success | `[inferred]` from the JD's wording against its silence on targets | What would count as success at 6 and 12 months, and who sets it? | unresolved |
| RR7 | Equity upside unspecified | unknown | — | "meaningful equity upside" | The posting doesn't say how much equity, or on what terms | `[grounded]` posting silence on both | What equity is offered, how does it vest, and what is the current cap table position? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Search was declined, so nothing was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR9 | Pay and office terms stated up front | positive_signal | — | "$70–85k base… On-site in our Austin office 5 days a week" | You can see the deal-breakers before spending effort on the process | `[grounded]` posting | Is there anything else about the terms not shown in the posting? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1, R2, RR1 and RR2 are failed gates | `[grounded]` map and register | pending your approval |
| A2 | If you apply anyway, ask the register's verification questions (RR3 to RR8) verbatim and treat the answers as essential | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Revisit if the posting is reposted with a remote option and a base of at least $150k | Both gates would need to change | `[grounded]` R1, R2 | pending your approval |

## Evidence status

Verified: your constraint claims in R1 and R2, your own stated limits with nothing to inspect. Unverified leads: R3, R4, R5 and R10, which rest on your background as you described it. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for Novaline was sent and refused. It would have checked that the company exists as described and the posting is live, feeding RR8 |
| 2. Role-family sweep | unavailable | A search for market pay and scope for this title was sent and refused. It would have given the market calibration line and tested the mismatch in RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Permission to search → RR8 resolves or stays open, and RR4 gets a market band to test against.
- A link to the live posting or the company's careers page → RR8.
- A named hiring contact → role reality's scope read.
- A channel report or P&L from the $8M to $40M ARR scale-up → R4 and R5 to `high`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.