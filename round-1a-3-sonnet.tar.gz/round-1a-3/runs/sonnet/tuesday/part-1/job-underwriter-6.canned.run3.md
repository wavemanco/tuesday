Read the posting and ran three searches. The full assessment follows.

## Decision snapshot

**Leaning yes as a stretch, and I can't call it yet. R1 and R2 (Bristol hybrid and the pay band) are unconfirmed against your own limits, and R6a and R8 are duties you told me you haven't done. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid two days a week), R2 (Salary £61,500–£67,000 plus share options)
- `must_have` — direct: R3a, R4 · adjacent: R5 (Strong SQL and spreadsheet modelling), R7 (Working with finance on billing or revenue data) · unclear: R3b (At a B2B software company), R6b (Experience owning a forecast) · absent: R6a (Run the quarterly revenue forecast with the CFO), R8 (Own the billing data)
- `important` — direct: R9

R6a — stated by you, and the forecast is a named duty; R8 — stated by you, and billing data is named in the duties; R6b (`low`) — a team-level forecast would change it; R3b — whether your payments employer counts as software.

**Opportunity ledger.** The role looks sound and transparent so far: pay is stated and sits inside the survey band (RR3). Who owns the forecast, the billing data and the surrounding team is not yet clear (RR1, RR2, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days a week), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the awaited answers are R1 and R2 (G1), R6b (G2) and R7 (G4). If R1 and R2 clear, I expect `conditional_go`, with the conditions that you state the R6a and R8 gaps plainly and that RR1 and RR2 verify in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` the posting you linked |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` the posting |
| Hiring manager | Tamsin Achebe is Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. That she is the hiring manager is from your recruiter | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (snippet only, profile not fetched); `[grounded]` your recruiter |
| Scope read | A lead-level post under a Head of Revenue Operations that bundles CRM, billing data, reporting and forecast support. It is unclear who owns the forecast number | `[inferred]` from the posting's duties against the manager's title |
| Market calibration | The posted range sits inside the middle of the survey's spread and straddles its median. The survey is UK-wide, not Bristol-specific, and is a band to expect, never this employer's offer | `[generic]` search result "Ledgerline 2026 UK Revenue Operations Pay Guide" (median £64,200, interquartile range £57,800–£70,400, n=438); `[grounded]` posting figure |
| Unknowns | Share option terms; billing system and who owns it today; forecast ownership; team size; your location | — |
| Contradictions | None found between the posting and Quillfield's About page. The search did not return a Quillfield careers page listing this role, so the posting is confirmed only on the job board | `[grounded]` the searches run |

## Evidence map

Your background was typed into the conversation, so it is treated as self-report. `medium` is the ceiling until something inspectable is seen.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | No constraint of yours is stated, so the gate is unsettled | `[grounded]` posting; your intake silent | G1 question |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so the posted range cannot be checked against it | `[grounded]` posting; your intake silent | G1 question |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. Stated, no artifact inspected | `[grounded]` your intake | offer: a CV would let me check how it reads |
| R3b | ...at a B2B software company | must_have | unclear | low | discovery | You describe a B2B payments company. Whether it counts as software is not established | `[grounded]` your intake, silent on this | G6 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, stated. The posting accepts either CRM, and the credential has not been inspected | `[grounded]` your intake | offer: your credential link would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | You use SQL weekly and Excel daily. That shows frequency, not depth, and modelling is not described | `[grounded]` your intake | G7 |
| R6a | Run the quarterly revenue forecast with the CFO | must_have | absent | none | transferability | You say finance owned the company forecast. Adjacent: you run the monthly pipeline review with your sales director and rebuilt the pipeline and renewal dashboards. Limit: those feed a forecast, but you did not own the number or answer to a CFO for it | `[grounded]` your intake | G3 |
| R6b | Experience owning a forecast | must_have | unclear | low | discovery | You did not say whether you owned any forecast below company level, such as your UK team's pipeline or renewals number | `[grounded]` your intake, silent | G2 question |
| R7 | Experience working with finance on billing or revenue data | must_have | adjacent | low | transferability | Renewal dashboards are revenue-related reporting. You haven't worked on billing data, and finance involvement is not stated | `[grounded]` your intake | G4 question |
| R8 | Own the billing data | must_have | absent | none | capability | You say you have never worked on billing data. Nothing direct or adjacent is stated | `[grounded]` your intake | G5 |
| R9 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards, and your sales director's monthly review uses them. Whether finance used them is not stated (see R7) | `[grounded]` your intake | offer: a sanitized dashboard screenshot would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | Posted terms, none of your limits | Unconfirmed gates cap the status at hold | Not applicable, these are terms and not experience | Your own statement | `[grounded]` posting; `[inferred]` that this is what holds the status |
| G2 | Owning any forecast (R6b; must_have) | discovery | Pipeline review and dashboards, no forecast ownership stated | Could narrow R6a's distance for a duty the posting names | Your UK team's quarterly pipeline or renewals number; a bookings forecast you maintained; a variance you explained to your sales director | A sanitized forecast sheet or a review deck | `[grounded]` your intake; `[inferred]` that it narrows R6a |
| G3 | Company forecast with the CFO (R6a; must_have) | transferability | You supplied inputs, finance owned the number | The headline duty; the bridge is real but limited | Pipeline and renewal numbers finance took into its forecast | A review deck showing what finance consumed | `[grounded]` your intake |
| G4 | Working with finance on revenue data (R7; must_have) | transferability | Renewal dashboards, finance involvement unknown | Could lift R7 and R9 | Finance reconciling or using your renewal numbers; agreeing definitions with finance (what counts as renewed, churned, expanded) | A definitions doc or email thread, sanitized | `[grounded]` your intake |
| G5 | Owning billing data (R8; must_have) | capability | Nothing direct or adjacent, by your own account | A named duty with no evidence behind it | None stated | None; the closure path is to learn Quillfield's billing system, which RR2's answer would name | `[grounded]` your intake |
| G6 | Software employer (R3b; must_have) | discovery | A payments company, not clearly software | A quick answer settles it | Whether your employer sold software on subscription or built its own platform | Your employer's product page | `[grounded]` your intake |
| G7 | SQL and modelling depth (R5; must_have) | discovery | Frequency of use only | Depth decides whether "strong" holds | A query joining several tables; a spreadsheet model with scenarios | A sanitized query or model | `[grounded]` your intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The CFO may own the model and this role feeds it, or this role may build it | `[inferred]` from the phrase "with the CFO" | Who owns the forecast model and number today, and what would this role own in the first quarter? | unresolved |
| RR2 | Billing data ownership and system unknown | unknown | — | "own our CRM and billing data" | Billing data may sit in a separate system with finance-held definitions, which matters for R8 | `[inferred]` from the posting naming billing data without naming a system | Which billing system holds the data, who owns it today, and what shape is it in? | unresolved |
| RR3 | Pay stated and in band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The posting is transparent on pay; the figure sits inside the survey's middle spread. Option terms are unstated | `[grounded]` posting figure; `[generic]` survey band | How are the share options structured, including vesting and the share of the company they represent? | noted |
| RR4 | Team around the role unknown | unknown | — | "Revenue Operations Lead" (title) | Several functions are bundled in the posting, and the Head sits above the role | `[inferred]` from the duties list against the manager's title | Who else sits under the Head of Revenue Operations, and which of CRM, billing data, reporting and forecast does each own? | unresolved |

## Application plan

Every block here is proposed, not applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with your own story: 5 years in sales operations, the last 2 running revenue operations for the UK team, Salesforce admin certified, rebuilt pipeline and renewal dashboards | R3a, R4 and R9 are the rows you can stand on | `[grounded]` your intake | pending your approval |
| P2 | State the gaps plainly: "I haven't owned the company forecast — finance did — and I haven't worked on billing data." Say it beside what you did do, "I run the monthly pipeline review with our sales director." | R6a and R8 will be asked about; this wording stays inside your own sentences | `[grounded]` your intake | pending your approval |
| P3 | Ask the RR1, RR2 and RR4 questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | For Tamsin Achebe, lead with the pipeline review and renewal dashboards. Her public title and background are the grounding; what she looks for in a candidate is not published and is not assumed | They sit closest to the work a Head of Revenue Operations reviews | `[inferred]` from her stated title | pending your approval |
| P5 | Settle G1 before investing in the application | Unconfirmed gates cap the decision | `[grounded]` R1, R2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers"; result "About Quillfield" (quillfield.co.uk/about). Established the company as described; no careers page listing the role was returned. Moved role reality's organization and contradictions rows |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software"; result "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. Moved the hiring manager row and P4 |

I can send a deeper research pass on Quillfield if you want one. It covers funding and leadership changes, public employee reports and recent news, and costs up to 5 more searches and 2 more fetches. It runs only if you say so.

I can also save this as a `tuesday-dossier.md` you can reuse, if you'd like.

**Upgrade menu**

- Your CV → I can check how R3a, R4 and R9 read and whether any evidence is buried.
- A link to your Salesforce credential → R4 to `high`.
- A sanitized query or spreadsheet model → R5 resolves.
- A forecast-style artifact from your team → R6b, then R6a's bridge.
- Evidence that finance used your renewal numbers → R7 and R9 firm up.
- Your answers on location and pay → R1 and R2 close, and the status can move off hold.
- Tamsin Achebe's published talks or writing, if any exist → sharper P4.

**Questions**

G1 — Does Bristol hybrid (two office days a week) and £61,500–£67,000 work for you, and is there a pay floor or a travel limit I should hold the role against?

G2 — Have you ever owned a forecast at any level, such as your UK team's pipeline or renewals number, even though finance owned the company one? What did you own, who relied on it, and how did you know it was right?

G4 — When you built the renewal dashboards, did anyone in finance use them or check them against their own numbers? What did that involve?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.