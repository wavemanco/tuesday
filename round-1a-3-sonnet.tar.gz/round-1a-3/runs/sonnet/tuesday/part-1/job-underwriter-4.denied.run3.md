I'm finishing the assessment now. The web searches were declined, so everything below rests on your JD and your background only.

## Decision snapshot

**Yes, worth applying to, on conditions. R1, R2, R3, R4, R5a and R6 land `direct`, and R5b and R10 are still open. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (UK-based, fully remote)
- `must_have` — direct: R1, R2, R3, R4, R5a, R6 · unclear: R5b (Design price tests)
- `important` — unclear: R7 (Turn results into recommendations for underwriting and product)
- `preferred` — direct: R8 · adjacent: R9 (Pet-insurance pricing knowledge)

R5b — "ran" is not "designed"; R7 — the underwriting side is partly evidenced, the product side is not; R9 (`medium`) — a credible bridge, its limit named.

**Opportunity ledger.** A clearly scoped role under a named Director of Pricing (RR4). It is unverified as an employer from here (RR1), and the pay is not stated (RR2). The posting is also silent on how much of the recommendation you would own (RR3).

- **Hard gates:** none failed; unconfirmed: R10 (UK-based, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can confirm you meet R10; (2) the employer and the live posting verify, see RR1; (3) you can say honestly what you owned in the price tests, see R5b; (4) the pet-insurance gap is framed as a gap, never as pet-pricing experience, see R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, hiring for its pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A hands-on senior individual-contributor post. The posting lists no line-management duty | `[inferred]` from a duties list that is entirely analytic |
| First 90 days | Likely taking over the existing rating models and test pipeline before leading new ones | `[inferred]` from "build and monitor" and "own", with no outcomes stated |
| Market calibration | Not run. The role-family search was declined, and I won't fill it from memory | `[grounded]` search refused |
| Unknowns | Salary; team size and whether "own" means sole owner; decision rights over rating changes; the employer's stage | `[grounded]` JD silence |
| Contradictions | None visible inside the JD; not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics at a UK motor insurer, 2 as senior. Self-reported, nothing inspected | `[grounded]` your background, stated | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. No artifact inspected | `[grounded]` your background, stated | offer: a sanitized query or notebook would raise to high |
| R3 | GLM experience | must_have | direct | medium | none | You state building and maintaining the young-driver GLM rating model. Specific, no artifact yet. Expect a probe on link functions, validation and factor selection | `[grounded]` your background; `[generic]` that GLM roles get probed on method | offer: a model-spec summary or validation note would raise to high |
| R4 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" is stated. Reading "maintained" as covering monitoring is my reading, so I took the lower band | `[grounded]` built and maintained; `[inferred]` monitoring | none |
| R5a | Run and read price tests | must_have | direct | medium | none | You state 14 price tests last year with the underwriting team. Specific, no artifact | `[grounded]` your background, stated | none |
| R5b | Design price tests | must_have | unclear | low | discovery | You said "ran", not "designed". What you owned in the test design is not established | `[grounded]` the verb you used | G1 |
| R6 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Specific, no artifact | `[grounded]` your background, stated | none |
| R7 | Turn results into recommendations for underwriting and product | important | unclear | none | discovery | The underwriting side is adjacent through the review and the tests. Nothing stated about recommendations to a product team | `[grounded]` background silent on product | G2 |
| R8 | Insurance experience, a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background, stated | none |
| R9 | Pet-insurance pricing knowledge (the role prices this product) | preferred | adjacent | medium | transferability | Risk-factor GLM rating in motor carries over as method. Limit: you have not worked on pet insurance, so you have no exposure to its data, claims patterns or rating factors | `[inferred]` bridge from your motor rating work; `[grounded]` your statement that you have no pet experience | G3 bridge case below |
| R10 | UK-based, fully remote | hard_gate | unclear | none | hard_gate | No constraints were given. You work at a UK insurer, which does not establish where you live or your right to work | `[grounded]` constraints not stated | the one gate question, in the closing block |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design price tests (R5b, must_have) | discovery | "Ran 14 price tests" shows execution. It does not show who chose the hypotheses, the splits, the sample sizes or the stopping rules | The JD says "design and read"; which verb is true decides how you position this | Choosing the test cells and the control; sizing a test or setting its duration; defining the success measure with underwriting; deciding whether a result was strong enough to roll out | A test plan, a results readout, or a post-test summary | `[grounded]` the verb in your background; `[generic]` that "design" is probed separately from "run" |
| G2 | Recommendations to underwriting and product (R7, important) | discovery | A quarterly review and test work with underwriting. Nothing says a recommendation of yours changed a rate, or reached a product team | It is the closing duty in the JD, and the one where influence matters more than analysis | A test result that changed a rate or a segment decision; a proposal taken to a pricing committee; a pricing change you argued for | A review deck, a recommendation memo, or a summary of a rate change | `[grounded]` background silent; `[generic]` that this duty is where analysts and decision makers part |
| G3 | Pet-insurance knowledge (R9, preferred) | transferability | Motor GLM rating, by your account | A preferred row, but it is the product you would price | Any rating work on a non-motor line; any work where you learned a new line's claims data quickly | A short note on what you would need to learn first, as a work sample | `[inferred]` bridge; `[generic]` that a new line's data is the usual early learning curve |

**G3 bridge case.** The adjacent evidence is your GLM method on a risk-factor rating model. The limit is that you have no pet-line exposure. The strengthener is a one-page note on how you would approach the first 90 days on an unfamiliar line.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The search was refused, so nothing about the employer is confirmed. It may be new or small, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | no salary in the posting you shared | The figure may be on the employer's listing and not in the copy you have, or it may be withheld | `[inferred]` from the JD's silence | What is the budgeted salary range for this post? | unresolved |
| RR3 | Recommendation authority unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while others decide on rate changes | `[inferred]` from "recommendations" against silence on decision rights | Who decides on a rating change, and how often do the pricing team's recommendations go ahead? | unresolved |
| RR4 | Defined duties and a named senior owner | positive_signal | — | "Own pricing analytics … build and monitor rating models, design and read price tests" | The scope is concrete, and the hiring manager is a named Director of Pricing | `[grounded]` JD | What would success look like in the first year? | noted |

If you decide to proceed against RR1, the answer to its question is the first thing to get. I'm going only on what you've shared, and I can get this wrong, so check the posting on the employer's own site before investing effort. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV summary with: "Pricing analyst, 5 years at a UK motor insurer. Built and maintained the GLM rating model for the young-driver book. Ran 14 price tests last year with the underwriting team. Present the quarterly pricing review to the head of underwriting." | Maps to R1, R3, R5a and R6. Each clause is your own sentence. "Ran" is kept, not "designed" | `[grounded]` your background | `resume_edits_pending_approval` |
| P1 | Positioning: say plainly that pet insurance is new to you and that your method carries over. Do not claim pet-pricing experience | R9's limit | `[grounded]` your statement | pending your approval |
| P2 | Positioning: do not raise management. The posting lists none. If asked, say you have not managed anyone | You flagged it; the JD does not require it | `[grounded]` JD silence on line management | pending your approval |
| A1 | Confirm your location and right to work against R10 before applying | The one open hard gate | `[grounded]` R10 | pending your approval |
| A2 | Check the posting on the employer's own site first | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | In the loop, ask RR2 and RR3 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech"; the call was refused. It would have fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; the call was refused. It would have fed the market calibration line and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have fed the scope read and which story to lead with |

I can save this assessment as `tuesday-dossier.md` for your later rounds, if you want it.

**Upgrade menu**

- Permission to search → RR1 could close, the market calibration line and RR2's band would be filled, and the scope read would be checked against Odile Varga's published background.
- The live posting link or the careers page → RR1 and RR2 close, if it states pay.
- A sanitized query, notebook or model-spec note → R2 and R3 to `high`.
- A test plan or results readout → R5a and R5b firm up.
- A recommendation memo or review deck → R7 firms up.
- Your location and right to work → R10 closes.

**Questions**

- R10 — Are you based in the UK, with the right to work there? This is the one gate the JD sets, and nothing here establishes it.
- G1 — In the 14 tests, which parts did you personally own: the hypotheses, the cell and control design, the sample sizing, the readout? Who set the success measure?
- G2 — Is there a test result you took to underwriting, or to a product team, that changed a rate or a decision? What did you recommend and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.