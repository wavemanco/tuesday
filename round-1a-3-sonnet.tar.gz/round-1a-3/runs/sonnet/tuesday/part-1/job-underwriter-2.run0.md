Reading the playbook is done. I'm running the two L1 research searches now: whether Quartzline exists as described, and what a platform-API PM role normally looks like.
## Decision snapshot

**No, this role isn't a waste of your time, but it is a stretch: R1b and R2 are adjacent and R1a is absent. Apply with named conditions · `conditional_go`.**

**Fit ledger.**

- `must_have` — adjacent: R1b (PM work, not PM years), R2 (shipped API/platform products) · absent: R1a (3+ years held in a PM role)
- `important` — direct: R5, R6a · adjacent: R3 (roadmap and partner discovery), R4 (specs, delivery with squads) · unclear: R6b (launches with sales/support), R7 (agile delivery), R8 (adoption metrics)

R1a — the titled-years gap; R2 — a bridge, its limit named; R5 (`medium`) — CV-stated, nothing inspected.

**Opportunity ledger.** The duties are stated concretely (RR4), but the titled-years bar may be read literally (RR1), the employer and posting are unchecked (RR2), and pay and level are withheld (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the 3+ years is confirmed to count product work done outside a PM title (RR1, R1a); (2) the employer and live posting verify (RR2); (3) the shipped-product bridge is evidenced and framed as adjacent, never as having shipped a platform (R2, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not independently checked: search was refused (see Evidence status) | `[grounded]` JD header, as pasted |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years PM experience (marked must-have); shipped API or platform products; technical fluency (API docs, schemas); stakeholder management across engineering, sales and customers; agile delivery. Only the first is labelled must-have, so I tiered the shipped-product requirement `must_have` and the rest `important` | `[grounded]` JD; `[inferred]` tiering from the JD's own emphasis |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A mid-level, platform-facing PM post with direct squad delivery and partner contact | `[inferred]` from the "3+ years" bar and the two-squad scope |
| Market calibration | Not run: the role-family sweep was refused, so there is no title, level or pay band here | `[generic]` no sweep ran |
| Unknowns | Pay, level, location or hybrid terms, decision rights over the roadmap, whether "3+ years" needs a PM title, who the hiring manager is | `[grounded]` JD silent on each |
| Contradictions | None within the JD. It was not cross-checked against a careers page | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of PM experience, read literally as time in a PM role | must_have | absent | none | capability | You've never held a PM title. The JD doesn't say whether adjacent years count, so RR1 carries the open question. Closure paths: a role with a PM title, or an internal move at your current employer, where you already work alongside PMs | `[grounded]` your statement and the JD wording; `[inferred]` the internal-move path from your coordination with PMs | Ask RR1's question before investing; a PM-titled stretch is the only direct closure |
| R1b | 3+ years of PM experience, read as product-management work (discovery, roadmap input, specs) | must_have | adjacent | medium | transferability | The CV shows roadmap-input sessions, requirements documents and coordination with PMs on custom builds. Limit: that is input to product and delivery beside PMs. Nothing stated shows you deciding priorities, and the years of that work aren't stated | `[grounded]` CV claims, nothing inspected | Ask for dates of the roadmap-input sessions; a sanitized roadmap-input summary would raise it |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your employer's REST APIs and wrote the integration playbook the team uses. Limit: that is integrating and enabling a platform others built, and no shipped product of your own is stated. An earlier-conversation note mentions an internal triage tool, which is an unconfirmed lead I'm not counting | `[grounded]` CV claims; the triage tool is a `memory_lead`, a question basis only | G1's question |
| R3 | Own the roadmap and run discovery with integration partners | important | adjacent | medium | transferability | You ran scoping workshops with clients and quarterly roadmap-input sessions that fed product. Limit: you collected the input, and nothing says you set priorities. Client integrators are close to the JD's integration partners | `[grounded]` CV claims; `[inferred]` closeness of clients to partners | Same as R1b |
| R4 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated your engineers and clients' engineers on custom builds. Limit: those are integration requirements, not product specs for a roadmap, and no squad ownership is stated | `[grounded]` CV claims | A sanitized requirements document would show the form |
| R5 | Technical fluency: API docs, schemas | important | direct | medium | none | Postman, SQL and OpenAPI specs, plus REST integration architecture, are stated | `[grounded]` CV claims | none |
| R6a | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and PMs across 30+ clients | `[grounded]` CV claims | none |
| R6b | Coordinate launches with sales and support | important | unclear | low | discovery | The CV mentions go-live with clients but nothing about working with sales or support on a launch | `[grounded]` CV silence | G2's question |
| R7 | Agile delivery | important | unclear | low | discovery | The CV names UAT and go-live but not sprints, backlogs or squad ceremonies. Silence isn't absence | `[grounded]` CV silence | G2's question |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Nothing in the CV. The triage tool lead, if confirmed, may bear on this | `[grounded]` CV silence; the lead is a `memory_lead` | G1's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption metrics (R2 and R8, `must_have` and `important`) | transferability | Integration work for a platform others built; no shipped product or adoption measure stated | R2 is a must-have at `adjacent`, and a confirmed shipped internal tool would be the strongest bridge on the page | An internal tool you scoped, built or commissioned and others adopted; a usage count or adoption figure you reported; a playbook with measured uptake | A short write-up, a usage or adoption screenshot, a launch note | `[grounded]` CV silence; `[generic]` that this requirement is the likeliest probe in a platform-PM loop |
| G2 | Agile delivery and sales/support launches (R7 and R6b, `important`) | discovery | Client go-lives and UAT described; no sprint, backlog or sales/support launch work stated | These are the two JD duties the CV doesn't touch | Working inside engineers' sprints or backlogs on custom builds; a go-live where sales or support prepared customers | A sprint board export or a launch checklist (sanitized) | `[grounded]` CV silence |
| G3 | PM years (R1a and R1b, `must_have`) | capability | No PM title. Product-adjacent years aren't dated | The literal reading may screen you out before anyone reads the substance | Dated roadmap-input work; any stretch where you owned a backlog or priorities | Dated role history; a sanitized roadmap-input summary | `[grounded]` your statement; `[generic]` that a literal years screen is common |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Titled-years bar may be literal | risk_signal | medium | "3+ years product management experience (must-have)" | Applicant screens for this wording are often literal, so adjacent years may not count. A hiring manager may weigh partner-facing integration experience for a platform-API role. Without a title, expect to be screened on the first reading | `[generic]` pattern for years requirements; not a claim about Quartzline | Does the 3+ years need to be under a PM title, or does product work done in solutions or implementation roles count? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Search was refused, so this is a check not run, not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who would I be interviewing with? | unresolved |
| RR3 | Pay, level and location withheld | unknown | — | JD gives no compensation, level or location | A career-changer may be levelled or paid below a PM with 3+ years. Without the posted figure I can't tell | `[inferred]` from the JD's silence | What range and level is budgeted for this role? | unresolved |
| RR4 | Duties and delivery structure stated concretely | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The scope is defined, with named squads and a measurable outcome | `[grounded]` JD | Who sets the adoption targets today, and where do they sit? | noted |

Nothing in this register rests on a payment, deposit or ID request, so no scam-pattern warning applies. RR2 records a check not run.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | On the resume, move the roadmap-input sessions, requirements documents and integration playbook above the delivery-only bullets, keeping each as you described it | see R1b, R3, R4 | `[grounded]` CV | `resume_edits_pending_approval` |
| W1 | A one-page sanitized sample requirements document or roadmap-input summary from real client work, labelled as integration-side work | see R3, R4 | `[grounded]` R3 and R4 rows | pending your approval |
| A1 | Before investing in a full application, ask the RR1 question of the recruiter or the hiring manager | see RR1, R1a | `[grounded]` RR1 | pending your approval |
| A2 | Look at an internal move at your current employer, where you already work with PMs, as a route to a titled PM stretch | see R1a, G3 | `[inferred]` from your coordination with PMs | pending your approval |
| Q1 | Ask RR1 to RR4's verification questions in the loop; they double as interview preparation | The register is your question list | `[grounded]` register | pending your approval |

Positioning stays honest: your story is integration and enablement work for a platform, plus feeding client input to product. No line should say you owned a roadmap, shipped a product or held PM scope unless your answers to G1 and G2 support it.

## Evidence status

Verified: none yet. Unverified leads: an earlier-conversation note about an internal request-triage tool that support agents adopted. It is unconfirmed, and it only prompts G1's question.

Research tier: L0 — searches refused 2 (counted against L1's budget of 5; fetches 0 of 2)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company careers Product Manager Platform APIs"; the call was refused. It would have confirmed whether Quartzline exists as described and whether the posting is live (role reality's organization and contradictions rows, and RR2) |
| 2. Role-family sweep | unavailable | Searched "API platform product manager requirements transition from solutions engineer without PM title"; the call was refused. It would have set the market-calibration line and how often the titled-years bar flexes (role reality, RR1, RR3) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you'd like a `tuesday-dossier.md` of this assessment to carry forward, say the word and I'll emit it.

## Upgrade menu

- Search permission, then the two L1 sweeps → RR2 closes or sharpens, and market calibration and the titled-years norm fill in.
- Details of the triage tool, plus an inspectable artifact (a short write-up or an adoption screenshot) → R2 and R8 can move up, with `high` available only once confirmed and inspected.
- Dates of your roadmap-input sessions → R1b's time in product-adjacent work becomes visible.
- A sanitized requirements document or roadmap-input summary → R3 and R4's `adjacent` bridge gets a concrete artifact.
- The hiring manager's name → role reality's scope read, and which verified story to lead with.
- Your non-negotiables → the hard-gates line stops reading unknown.

## Questions

G1 — I have a note from an earlier conversation that you may have built an internal request-triage tool that support agents adopted. Is that right, and if so what did you own, did it go to real users, and how did you know it was adopted?

G2 — On your custom builds, did you work inside the engineers' sprint or backlog process, and did you ever coordinate a launch with sales or support? What part was yours?

Orientation — Do you have non-negotiables for a move, such as a pay floor against your current level, location or hybrid terms, or title and level?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.