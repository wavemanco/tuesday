I've read the playbook and I'm now running the research: the company's footprint, UK pricing-analyst pay norms, and Odile Varga's public professional profile. After that I'll write up the decision.
# Job underwriting: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, worth applying to, on conditions. R2, R3, R4, R5a, R6 and R7 are `direct` must-haves, but R1 is unconfirmed and the employer isn't established (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · adjacent: R5b (Monitor rating models)
- `important`: adjacent: R9 (Pet-insurance domain) · unclear: R8 (Recommendations to product)
- `preferred`: direct: R10

R9 — a credible bridge from motor, its limit named; R5b — "maintained" is what you stated, monitoring isn't evidenced yet; R8 — product side not evidenced yet.

**Opportunity ledger.** The scope is concrete (RR3), but I couldn't establish the employer from public sources (RR1), the pay is withheld (RR2), and the team structure is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you meet the UK remote terms, R1; (2) the employer and live posting verify, RR1; (3) the pay clears your floor, RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD |
| Establishment | My search on the company name returned nothing. A search result shows a profile naming Odile Varga as Director of Pricing at Brindlemoor, but a personal profile doesn't verify the employer | `[grounded]` search results; see RR1 |
| Mandate | Own pricing analytics for pet: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Management | The JD asks for no line management, so having never managed anyone isn't a stated requirement | `[grounded]` JD silent; whether the role has reports is unknown |
| Scope read | The title and the 4+ years ask match your 5 years and 2 as senior analyst | `[inferred]` from the JD's years against your stated history |
| Market calibration | Median base £58,400, interquartile range £52,100 to £64,900 for senior pricing analysts at UK insurers and insurtechs (a survey snippet, not read in full). The posting withholds pay, so this is the band to expect, never this employer's offer (RR2) | `[generic]` Pricewell 2026 survey; `[grounded]` JD for the withheld pay |
| Hiring manager | Odile Varga, Director of Pricing. Spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result snippet |
| Unknowns | Pay, team size and reporting line, who owns the product recommendations, the size of the pet book | — |
| Contradictions | None visible, but there is no company page to compare the JD against | `[grounded]` no company page found |

## Evidence map

Your background was typed in, so I treat it as CV-equivalent self-report. That caps confidence at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | You haven't stated where you live or your right to work. A UK motor insurer is only indirect evidence | `[grounded]` JD; `[inferred]` UK base from your employer | Closing question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, stated and specific, nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. No code or artifact inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | A sanitized model spec would raise this to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM build as R4 | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | adjacent | medium | discovery | You said "maintained". Monitoring (drift, loss-ratio tracking, alerts) isn't stated, so I resolve downward | `[grounded]` your wording; `[generic]` monitoring is a likely probe, given the role's stated duties | Closing question G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with underwriting. "Ran" is what you stated, and expect a probe on who designed and read them | `[grounded]` your background | A test-readout deck would raise this to `high` |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Turn results into recommendations for product | important | unclear | low | discovery | Underwriting is evidenced. Product isn't mentioned | `[grounded]` your background silent on product | See upgrade menu |
| R9 | Pet-insurance domain | important | adjacent | medium | transferability | Pricing a motor book is the same discipline on different rating factors. Pet carries factors you haven't priced, such as breed, age and pre-existing conditions | `[inferred]` from the JD's pet focus; `[generic]` pet rating factors differ from motor | Bridge case in the application plan |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" the GLM, with no stated monitoring routine | A must-have at `adjacent`; a confirmed answer could move it to `direct` | Actual-vs-expected tracking by segment; drift or stability checks; a refit trigger; a dashboard the underwriters used | A monitoring pack, a dashboard screenshot, a refit memo | `[grounded]` your wording; `[inferred]` that confirming it moves R5b |
| G2 | Recommendations to product (R8, important) | discovery | Underwriting recommendations are evidenced. Product is silent | The JD names product as an audience | A price-test result that changed a product feature, a tier, or a discount structure | A recommendation memo or a review slide | `[grounded]` JD against your background |
| G3 | Pet domain (R9, important) | transferability | Motor rating work only | The limit to name: you haven't exercised pet-specific factors | Any work on age-based or condition-based rating, or on renewal-pricing effects | A short note mapping your motor factors to pet analogues | `[inferred]` bridge from your motor rating work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | (the JD states no figure) | The figure may sit anywhere in or outside the market band in role reality | `[generic]` band; `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "build and monitor rating models, design and read price tests" | The duties are specific and measurable | `[grounded]` JD | Which of these three duties takes most of the week? | noted |
| RR4 | Team structure unstated | unknown | — | "Own pricing analytics" | You may be the only analyst, or one of several | `[inferred]` from "own" against the JD's silence on a team | Who else sits in pricing, and who does the role report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on the company's own careers page before investing effort | RR1 caps this at `conditional_go` until it verifies | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the young-driver GLM build and the 14 price tests. Say "ran" until you confirm you designed and read them | R4, R5a and R6 are your strongest rows, and "ran" is your word | `[grounded]` your background | pending your approval |
| A3 | Frame pet as a bridge from motor pricing, never as pet experience, and name its limit | R9 is `adjacent` | `[grounded]` R9 | pending your approval |
| A4 | Prepare one monitoring example if G1 confirms one. Her published talk is on monitoring rating models, so it's a likely topic | R5b | `[grounded]` talk topic from the search snippet | pending your approval |
| A5 | Ask RR1, RR2 and RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned no results, so the company is not established. This fed the Establishment row in role reality and RR1 |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). I used the snippet only. This fed the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. This fed the hiring-manager row and A4 |

I can save this as a `tuesday-dossier.md` if you want to carry it forward. It's optional.

## Upgrade menu

- Your pay floor and where you live → R1 and RR2 close, and the hard-gates line stops flagging unknown constraints.
- A monitoring pack or dashboard screenshot → R5b moves toward `direct`.
- A model spec or a test readout → R4 and R6 can reach `high`.
- Any product-facing recommendation you've made → R8 closes.
- The live posting on Brindlemoor's own careers page → RR1 closes.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

R1 — Do you live in the UK and have the right to work there without sponsorship, and is fully remote UK working fine for you?
RR2 — What's the minimum base salary you'd accept?
G1 — On the young-driver GLM, did you track how it performed after launch, and what did you do when it drifted?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.