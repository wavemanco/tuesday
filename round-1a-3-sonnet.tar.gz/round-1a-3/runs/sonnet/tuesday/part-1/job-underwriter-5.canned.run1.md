I've read the playbook. Next I'll load the web tools and check that the posting is still live on Pellucid's own site. Then I'll write the assessment.
**Yes, it's worth applying, with conditions. Status: `conditional_go`.** The condition is that the posting's location and pay terms fit your own limits (R1, R2), which you haven't told me yet.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery) · unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R8 (`medium`) — a credible bridge, its limit named; R9, R10 — responsibilities your background doesn't speak to yet.

**Opportunity ledger.** The pay is published and sits in the market band (RR2). Equity terms (RR3), team size and scope (RR1) and the hiring manager and process (RR4) are all unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 meet your own location and pay constraints; (2) R8 is framed as a bridge from Snowflake, never as BigQuery experience; (3) RR1's scope question gets a concrete answer in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company's own About page, returned by search; funding and headcount are self-reported |
| Mandate | Build and run the pipelines behind reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` careers page, fetched |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` careers page |
| Working pattern | Remote (US) or the Denver office | `[grounded]` careers page |
| Scope read | The posting spans ingestion, warehouse modelling, contracts and running it all, which may be more than one domain's pipelines. Team size and reporting line are not stated. | `[inferred]` from the posting's list of duties against its silence on team |
| Market calibration | The Datawright report gives a base median of $151,000 and an interquartile range of $139,000–$163,500 for Senior Data Engineers at Series B–D companies, where "Senior" typically means 5–8 years. The posting's $148,000 floor is $3,000 under that median and its $166,000 top is $2,500 over the upper quartile. The posting's 5+ years sits inside the typical 5–8. The comparison assumes the posted salary is base pay and leaves equity out. | `[grounded]` the report you supplied and the posting; the comparison is `[inferred]` |
| Unknowns | Equity terms; team size and who owns the warehouse today; hiring manager; interview process | — |
| Contradictions | None between the posting you pasted and the live careers page | `[grounded]` careers page fetched |

## Evidence map

No CV was shared, so these rows rest on your typed background. That caps them at `medium`, and presentation gaps can't be judged yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and any location limits weren't stated, so nothing grades your side of this term | `[grounded]` posting; your side not given | Q1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't stated. The range itself is firm and sits in the band, but whether it meets your floor is unknown. | `[grounded]` posting; your floor not given | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is specific, but self-reported with nothing inspectable yet. Expect a probe on scope. | `[grounded]` your stated background | A sanitized dbt lineage graph or DAG excerpt would raise it to `high` |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Stated as daily use over 6 years. No code or artifact has been inspected. | `[grounded]` your stated background | A sanitized query or repo excerpt would raise it |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so the requirement as written is met. | `[grounded]` your stated background | A project docs page or lineage screenshot would raise it |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly as your orchestrator. The posting accepts "or similar", so the match is exact. | `[grounded]` your stated background | A sanitized DAG excerpt would raise it |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so it was yours. What it covered and how it was run isn't stated. | `[grounded]` your stated background | A suite config excerpt or a note on what it caught would raise it |
| R8 | BigQuery as the warehouse | important | adjacent | medium | transferability | Carries over: warehouse modelling in dbt, which is the layer this posting names. Limit: you have not used BigQuery, and the requirements say "a cloud warehouse" while the mandate names BigQuery. Platform specifics such as its cost and partitioning model are the usual place a probe lands. | `[grounded]` your Snowflake and dbt work; `[generic]` where interviews probe a warehouse switch | A small dbt-on-BigQuery project would narrow the limit (G1) |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background doesn't say what you ingested or from which systems. A payroll pipeline likely involved sources, but that isn't evidence. | `[grounded]` silence in your background | Ask later if useful (G2) |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing stated about contracts, schemas or analyst-facing guarantees. Your Great Expectations work may be adjacent, but that isn't confirmed. | `[grounded]` silence in your background | Q3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake and dbt work, no BigQuery use. The bridge is the modelling layer. The limit is the platform's own behaviour. | It is the one named technology you lack, so it is where a screen is most likely to look | Any dbt model you've moved between warehouses; a personal project on a public BigQuery dataset | A small repo or write-up | `[inferred]` bridge from your stated work; `[generic]` that it's the likeliest probe |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Silence on sources and ingestion methods | Ingestion is the first duty the posting lists | Loading product events or a CRM export into a warehouse; syncing from a SaaS API; handling schema drift from an upstream app | A sanitized pipeline diagram | `[grounded]` background silent; `[inferred]` that it matters because the posting lists it first |
| G3 | Data contracts (R10, important) | discovery | Silence on contracts. The quality suite is the nearest thing. | The posting calls out contracts "our analysts depend on" | Agreeing column definitions or freshness expectations with analysts; failing a build when a source schema changed; versioning a model analysts query | A contract doc, schema test config, or a changelog | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope and team size unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the platform's whole data stack, or one domain within a team | `[inferred]` from the posting's breadth against its silence on team | How many data engineers are on the team, and who owns the warehouse today? | unresolved |
| RR2 | Pay published and in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is specific and sits around the report's median | `[grounded]` posting and the supplied report | Where in the range would this role land for my experience? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and valuation may be undisclosed | `[inferred]` from the posting naming equity without terms | What is the equity grant, vesting schedule and latest valuation? | unresolved |
| RR4 | No hiring manager or process named | unknown | — | "The posting names no hiring manager" (your note) | The reporting line and loop may be set later | `[grounded]` your note on the posting | Who would I report to, and what are the interview stages? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the 180-model dbt project and the Great Expectations suite as the two headline proofs | R5, R7 | `[grounded]` your stated background | pending your approval |
| W1 | Build a small dbt project on a public BigQuery dataset | narrows the limit on R8 | `[generic]` a common way to close a warehouse-switch gap | pending your approval |
| Q1 | Ask the questions in RR1, RR3 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

If you go ahead, tailoring your CV to this posting is resume-tailor's job.

## Evidence status

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | yes | Search "Pellucid Learning online tutoring K-12 Denver Series C" returned the company's About page. Fetched pellucidlearning.com/careers/senior-data-engineer, which is live ("Accepting applications") and matches your paste. The employer is attributable. Size and funding come only from its own page. |
| 2 | Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and the pay comparison |
| 3 | Hiring manager's public footprint | n/a | The posting names no hiring manager |

I'd like to save this as `tuesday-dossier.md` so later steps can build on it. Say the word.

## Upgrade menu

- Your location and pay floor close R1 and R2, which are the gates still open.
- A sanitized dbt lineage graph, DAG excerpt or quality-suite config raises R3 to R7 toward `high`.
- Your CV lets me check whether it buries any of these rows.
- A small dbt-on-BigQuery project narrows R8's limit.
- A description of your ingestion or contract work resolves R9 and R10.
- The hiring manager's name enables a scope read of how this role is led.
- Deeper diligence on Pellucid (funding, leadership changes, employee reports, recent news) would cost up to 5 more searches and 2 more fetches. Say the word and it runs.

R1 — Are you US-based (or willing to be in Denver), and do you have any limits on where or how you'd work?
R2 — What is the lowest base salary you would accept, so I can set it against the $148,000–$166,000 range?
G3 — Have you defined or enforced expectations that analysts relied on, such as agreed column definitions, freshness checks or build failures on schema change? If so, what did you own and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.