Running the L1 research now: checking whether Harborlight Health exists as described, and the market band for this role.
**Yes, apply. You are a fit on the stack the posting leads with: R1, R2, R3, R4 and R5 are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: no rows
- `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R6 (define and maintain the metrics layer)
- `important`: direct: R7a · adjacent: R7b (partner with clinicians) · unclear: R8 (mentor two junior analysts)
- `preferred`: adjacent: R9b (privacy-governed data handling) · absent: R9a (healthcare data experience, HIPAA)

R6 — dashboards confirmed, metrics-layer ownership not yet; R7b — a bridge from your VP Product partnership, limit named; R8 — your background is silent on it.

**Opportunity ledger.** The role is unverified and under-specified, not worrying. The employer and posting are unconfirmed (RR1), the pay is not in what you pasted (RR2), and the test volume behind "at scale" is undefined (RR3). The posting also puts the metrics layer, experimentation, dashboards, partnering and mentoring under one title (RR4). One entry runs the other way: the posting names its partners and a mentoring remit (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the pay is acceptable to you (RR2, floor not given); (3) your answer on R6 lets you say truthfully that you defined metrics, or the claim stays as dashboard-building (G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C, with a care-navigation app | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Seniority read | An individual contributor with a mentoring remit. "Mentor" is the posting's word, so a reporting line is not implied | `[inferred]` from the JD's "mentor" against its silence on line management |
| Market calibration | Not given. No search ran, and I don't state pay bands from memory | `[generic]` nothing asserted; see Evidence status |
| Unknowns | Pay, location or remote terms, test volume, who owns the warehouse and data modeling, first-year outcomes | `[grounded]` JD silent on each |
| Contradictions | None between the JD and your background | `[grounded]` both sources read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. Self-reported and specific, with no inspectable artifact yet. The domain differs (meal-kit, not health), but this is a years requirement, not a gate | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on a Snowflake warehouse is confirmed and specific. "Expert" is your own level, and nothing inspectable backs it. `[generic]` Screens for this wording often include a live exercise | `[grounded]` your stated background; `[generic]` the screen | none; expect to be tested live |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran a program of 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Whether your volume matches this app's "at scale" is unknown (RR3) | `[grounded]` your stated background | offer: a sanitized readout of the pricing test would raise this to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. Looker is the named tool | `[grounded]` your stated background | offer: a sanitized dashboard screenshot or a modeling sample would raise this to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. Confirmed, with no artifact inspected | `[grounded]` your stated background | offer: a sanitized memo would raise this to `high` |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" are confirmed. Owning metric definitions is not stated, and I won't read that into the dashboards. Low because it rests on an inference | `[grounded]` the dashboards claim; `[inferred]` that a definitions role may sit behind it | G1 question below |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | You present to the VP Product monthly. What you did for the PMs below that level is not stated | `[grounded]` your stated background | none |
| R7b | Partner with clinicians | important | adjacent | low | transferability | Nearest evidence is your work with product leadership. Limit: no clinical or domain-expert partnership is stated. Strengthener: any case where you worked with a non-analyst specialist on a decision | `[inferred]` adjacency from your VP Product work | see G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring. I won't infer it from seniority | `[grounded]` silence in your background | G2 question below |
| R9a | Healthcare data experience (HIPAA), a plus | preferred | absent | none | capability | No healthcare or HIPAA work is stated. You said you haven't worked in healthcare. A "plus" means this is not a blocker | `[grounded]` your statement | see G4 |
| R9b | Privacy-governed data handling, the nearest part of R9a | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: that is not HIPAA experience. `[generic]` HIPAA rules for health data differ from consumer-privacy regimes, and the posting does not say how heavily it weighs them | `[grounded]` your stated background; `[generic]` the regime difference | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | Governed Looker dashboards, but no statement of who defined the metrics behind them | A must-have, and the first duty the posting lists. Confirming it would turn R6 from `unclear` to `direct` | Writing the definition of a core metric such as retention or churn; resolving a conflict between two teams' numbers; maintaining shared modeling code or a metric dictionary | A metric dictionary, a modeling file excerpt, or a definitions doc | `[grounded]` the CV-equivalent silence; `[inferred]` the effect on R6 |
| G2 | Mentoring (R8, important) | discovery | No mention of mentoring | The posting names two junior analysts, so this is a stated duty | Onboarding an analyst, reviewing their queries or analyses, running a team training, or informal coaching | A training deck, a review checklist, or an onboarding doc you wrote | `[grounded]` the silence |
| G3 | Clinician partnership (R7b, important) | transferability | VP Product partnership as the bridge. Limit: no clinician or similar specialist is stated | Clinical input is a named part of the role | Working with a specialist such as ops, nutrition or customer care to decide something | A decision memo that named the specialist's input | `[inferred]` bridge from your VP Product work |
| G4 | HIPAA and healthcare data (R9a, R9b, preferred) | capability for R9a, transferability for R9b | The consent-state model and GDPR/CCPA handling bridge only partly | A preferred item, so a minor risk | Closure path: a short HIPAA primer course. The bridge: your consent-state model, with its limit stated | A one-page description of the consent-state model | `[grounded]` your statement; `[generic]` that a primer is a common closure path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. This caps the decision at `conditional_go` | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay not in the posting as pasted | unknown | — | no figure in the text you gave me | The posting may state pay elsewhere, or the employer may withhold it | `[inferred]` from the pasted text's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | "Experiment design at scale" undefined | unknown | — | "design and analyze A/B tests" | Test volume may differ from your 2M-subscriber base, which changes which of your methods transfer | `[inferred]` from the JD's silence on user counts | How many active users does the app have, and how many tests run a quarter? | unresolved |
| RR4 | Several specializations under one title | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards" | The role may combine analytics-engineering work with analyst work. Low because the posting names mentoring and partners, which suggests defined scope | `[inferred]` from the duty list in the JD | Who owns the warehouse and data modeling, and how much of the metrics layer is already built? | unresolved |
| RR5 | Named partners and a mentoring remit | positive_signal | — | "partner with product managers and clinicians … mentor two junior analysts" | Scope reads as defined: the people you work with are named | `[grounded]` JD | Who are the two junior analysts, and how long have they been on the team? | noted |

## Application plan

Each row is proposed language or an action. The plan as a whole is `pending your approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the three items the posting leads with, in your own words: you built the company's Looker instance from scratch (40+ governed dashboards); you designed and ran the experimentation program (30+ A/B tests a year, including the pricing test behind an 11% retention lift); you write the monthly metrics memo the exec team reads | R3, R4, R5 | `[grounded]` your stated background | pending your approval |
| P2 | Describe the consent-state model as what you built, and name GDPR/CCPA as the regimes. Do not write "HIPAA" or "healthcare-ready" | R9b, R9a | `[grounded]` your stated background | pending your approval |
| P3 | Hold any "owned the metrics layer" wording until G1 is answered. "Built the Looker instance with governed dashboards" is the claim your evidence carries today | R6 | `[grounded]` the R6 row | pending your approval |
| P4 | Check the posting on Harborlight's own careers page, and ask the RR1 and RR2 questions of the recruiter before investing in the loop | RR1, RR2 | `[grounded]` the register | pending your approval |
| P5 | Ask RR3 and RR4 verbatim in the loop; the answers decide how R3 and R6 should be framed | RR3, RR4 | `[grounded]` the register | pending your approval |

Tailoring your CV to this posting is resume-tailor's job, and I haven't done it here.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the host refused it. It would have moved RR1 (employer and live posting) and the role-reality organization row |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range Looker experimentation 2026"; the host refused it. It would have moved the market-calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can send a dossier file (`tuesday-dossier.md`) with this assessment if you want to carry it between sessions.

## Upgrade menu

- Search permission granted, so the two refused searches can run → RR1 may close and the market-calibration row can fill in.
- A hiring manager's name → the scope read and which story to lead with.
- A sanitized pricing-test readout, dashboard screenshot or monthly memo → R3, R4 or R5 to `high`.
- A metric dictionary or modeling excerpt → R6 to `direct`.
- The recruiter's pay range → RR2 closes, and you can compare it with your floor.

G1 — In your Looker build, did you personally define how the company's core metrics were calculated and keep them consistent across the 40+ dashboards? What did you own, and who signed off the definitions?

G2 — Have you mentored, onboarded or reviewed the work of other analysts, formally or informally? What did you do, for how many people, and for how long?

C1 — Do you have non-negotiables this role has to meet, such as a pay floor, location or remote terms, or work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.