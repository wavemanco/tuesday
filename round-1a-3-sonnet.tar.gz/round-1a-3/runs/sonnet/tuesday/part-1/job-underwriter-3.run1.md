Web searches were declined, so this runs only on your posting and your background. The employer and pay checks are marked unavailable below.

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Compensation: $70–85k base), R2 (On-site in Austin 5 days a week)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important` — adjacent: R9 (Team of one to start) · unclear: R7 (Brand, PR), R8 (Partnerships, sales ops)

R1 and R2 — the posting's terms against your floor and your remote-only line; R3, R4 and R5 (`medium`) — confirmed but not yet inspectable.

**Opportunity ledger.** The role bundles seven functions into a team of one at a stated base of $70–85k (RR3, RR4). Always-on hours are written in (RR5), success metrics are left open (RR6), and the employer could not be established from here (RR7). One entry runs the other way: a stated CEO reporting line (RR8). Your two hard constraints are also filed as confirmed red flags (RR1, RR2).

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in Austin 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting would need a base at or above your $150k floor (R1) and permission to work remotely from Portland (R2). The posting says "no exceptions" on location.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; the stage and profitability claims are unchecked |
| Mandate | Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team | A team of one to start, with no stated headcount, budget or hiring plan | `[grounded]` posting; silence on budget `[inferred]` |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms given | `[grounded]` posting |
| Success measures | "Success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | The title and the 8+ year bar describe a senior owner. Seven functions with no staff and a base this size describe a scope the pay does not cover. | `[inferred]` from the posting's scope, staffing and pay against each other |
| Market calibration | Not run. The pay search was refused, and no market figure is stated from memory. | `[generic]` none available; see Evidence status |
| Unknowns | Equity terms, budget, who the growth channels run through today, whether the buyer is B2B or B2C | — |
| Contradictions | The posting asks for "growth leadership" and gives you no one to lead. The careers-page cross-check could not run. | `[inferred]` from the posting's own text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base (your floor: $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor, which is specific and yours. The posting's top figure sits $65k below it and its bottom $80k below. | `[grounded]` posting and your statement | Only the employer changing terms resolves it |
| R2 | On-site Austin 5 days a week, no exceptions (you: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The posting rules out any remote arrangement in its own words. | `[grounded]` posting and your statement | Only the employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years, with a Growth lead, then Head of Growth progression. A length-of-experience bar is not a gate. Confirmed in prose, with no inspectable artifact yet. | `[grounded]` your background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state that you owned paid, with a controlled budget during the $8M to $40M ARR scale-up. Limited inspectable proof. | `[grounded]` your background | A channel spend and results export would raise it to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state that you owned lifecycle and name Braze. Limited inspectable proof. | `[grounded]` your background | A Braze program summary or retention report would raise it to `high` |
| R6 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention SEO or content. It may exist in unlisted work. | `[grounded]` your background's silence | See G3 |
| R7 | Brand and PR | important | unclear | none | discovery | Your background is silent on both. | `[grounded]` your background's silence | See G5 |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Your background is silent on both. | `[grounded]` your background's silence | See G5 |
| R9 | Team of one to start | important | adjacent | low | transferability | You built and managed teams of 3–7 and owned the strategy for several channels. Working with no support staff isn't stated. The lower band is taken because the team claim and the solo claim differ. | `[grounded]` your team sizes; `[inferred]` that solo execution is a different working mode | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay below your floor (R1, hard_gate) | hard_gate | The posting states $70–85k base; your floor is $150k | A failed gate caps the status at `no_go` however strong the fit | Nothing counts. Wording cannot solve a gate. | An employer-stated change of range, which the posting gives no sign of | `[grounded]` posting and your statement |
| G2 | On-site five days against remote-only (R2, hard_gate) | hard_gate | The posting says on-site Austin, "no exceptions" | A failed gate caps the status at `no_go` | Nothing counts | An employer-stated change of terms | `[grounded]` posting and your statement |
| G3 | SEO/content (R6, must_have) | discovery | Your background doesn't establish organic or content work | A must-have row at `unclear`, though it can't move the status past the failed gates | Owning an organic acquisition target at your subscription companies; a content calendar you set; technical SEO fixes you pushed through | A search-console or organic-traffic report, a content plan | `[grounded]` background silence; `[generic]` that subscription growth roles often touch organic |
| G4 | Working as a team of one (R9, important) | transferability | Team-building is evidenced; solo execution isn't | It sets how credibly you'd claim the scope | Early-stage periods before you had hires; channels you ran personally day to day | A role-history timeline, with headcount by period | `[grounded]` team sizes; `[inferred]` limit of the bridge |
| G5 | Brand, PR, partnerships and sales ops (R7 and R8, important) | discovery | Your background is silent on all four | They are half the posting's list | Brand campaigns you led, press coverage you earned, partner deals you ran, CRM or pipeline work with a sales team | A coverage list, a partner agreement, a pipeline dashboard | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay conflicts with your floor (see R1) | red_flag | high | "$70–85k base" | The range is incompatible with your stated $150k minimum | `[grounded]` posting figure against your statement | Is $70–85k the full range for this role, or is there a higher band? | confirmed |
| RR2 | On-site rule conflicts with remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role cannot be done from Portland | `[grounded]` posting quote against your statement | Is five-day on-site fixed for this role, with no remote arrangement of any kind? | confirmed |
| RR3 | Seniority and scope against stated pay | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The pay may sit below what this mandate and seniority usually carry. The market band could not be searched, so this is unconfirmed. | `[inferred]` from the posting's own scope and pay | What is the total package, including equity terms, and how was the range set? | unresolved |
| RR4 | Seven functions, no bench, no stated resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench" | You may be accountable for outcomes across all channels without budget or staff | `[inferred]` from the scope list against the posting's silence on budget | What budget and headcount are committed in the first year? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be the norm rather than the exception | `[inferred]` from the posting's phrasing | How often did evenings and weekends come up in the last quarter? | unresolved |
| RR6 | No success definition on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may arrive without agreed targets | `[inferred]` from the quote against the mandate's breadth | What would success look like at six and twelve months? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search ran, so this is unconfirmed. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR8 | Reporting line stated | positive_signal | — | "Report to the CEO with a dotted line to the board" | A senior seat with a defined reporting line | `[grounded]` posting | Which board members would the dotted line involve, and how often? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this role as posted | See R1, R2, RR1, RR2 | `[grounded]` the two failed gate rows | pending your approval |
| A2 | If you proceed anyway, ask RR1 through RR7 verbatim and hold off on any application effort until RR1 and RR2 are answered in writing | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | No resume edits proposed. R3, R4 and R5 already read as direct, and the failed gates make tailoring moot. | See R3 to R5 | `[grounded]` map | pending your approval |

## Evidence status

Verified: none yet. The fit rows rest on your stated background, which counts as self-report at intake.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Novaline e-commerce enablement startup Austin Series A" and "Novaline Head of Growth Austin careers". They would have fed the contradictions row and the employer-not-established entry (RR7). |
| 2. Role-family sweep | unavailable | One search was refused: "Head of Growth salary Series A startup Austin base compensation 2026". It would have fed the market calibration row and RR3. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

---

Say the word if you want this saved as a `tuesday-dossier.md`.

**Upgrade menu**
- Search access → I can run the employer and pay checks (2 searches remain of the L1 five), which moves RR7, RR3 and the contradictions row.
- A link to the live posting or Novaline's careers page → RR7 and role reality's contradictions row.
- The hiring manager's name → role reality's scope read.
- Inspectable artifacts (a spend export, a Braze report, an organic-traffic or coverage report) → R4 and R5 to `high`, and R6 to R8 resolve.

No questions this turn. Nothing you could answer would change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.