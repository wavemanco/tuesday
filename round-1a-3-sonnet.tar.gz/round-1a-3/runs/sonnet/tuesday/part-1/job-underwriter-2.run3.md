Checking whether Quartzline exists as described and what this role normally pays, then I'll write up the assessment.
**Am I wasting my time? No, but this role is a stretch.** Nadia, you clear the technical-fluency and customer-facing requirements (R3, R4a, both `direct`). You do not have the titled 3+ years of PM experience (R1b, `absent`), and shipping API products (R2) is only `adjacent`. Status: `conditional_go`.

Web search was refused in this session, so Quartzline is unverified and the pay band is uncalibrated. Everything below rests on the JD and resume you pasted.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1a (PM work near the title), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder work with sales), R5 (Agile delivery) · absent: R1b (3+ years of PM experience, titled)
- `important` — adjacent: R6 (Own the roadmap), R7 (Discovery with integration partners), R8 (Specs and delivery with two squads), R10 (Launches with sales and support) · unclear: R9 (Define and track adoption metrics)

R1b — titled years absent, a screening risk and not a gate; R2 (`medium`) — adjacent, its limit named; R9 — waiting on one answer from you.

**Opportunity ledger.** The scope is clearly stated (RR4). The employer is not yet established (RR1), pay and location are withheld (RR2), and it is unknown whether the years requirement bends for equivalent experience (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the posting verify as live — RR1; (2) the recruiter signals that equivalent product-owning work can count toward the years requirement — R1b, RR3; (3) the R2 bridge is framed as adjacent and never as having shipped a product.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header, unverified |
| Mandate | Own the roadmap of the partner-facing API platform, run partner discovery, write specs, drive two engineering squads, define adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Level | Mid-level PM: the posting asks for 3+ years and names no team to manage | `[inferred]` from the years requirement and the absence of any management scope |
| Scope read | One product area with two squads. It is a defined remit, not a bundle of roles | `[inferred]` from the strand and squad count |
| Market calibration | Not done: the role-family sweep did not run and the JD states no pay | `[grounded]` JD as pasted has no figure |
| Unknowns | Pay, location or remote, level, reporting line, hiring manager, whether the years requirement is flexible | `[grounded]` JD silence |
| Contradictions | None inside the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product management experience (work near the title) | must_have | adjacent | medium | transferability | You wrote requirements documents, ran roadmap-input sessions and worked alongside PMs and engineers on custom builds. That is PM-adjacent work, not PM ownership | `[grounded]` resume | See G1 |
| R1b | 3+ years of PM experience, titled | must_have | absent | none | capability | You state you have never held a PM title. Years requirements like this are often screened literally | `[grounded]` your statement; `[generic]` screening pattern | Ask RR3 early; carried as the main risk |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your employer's REST APIs and wrote the integration playbook the team uses. Limit: integrating a product is not owning its lifecycle | `[grounded]` resume | See G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading are stated, and 30+ integrations back them. Confirmed prose with no inspectable artifact yet, so `medium` | `[grounded]` resume | The playbook, if shareable, would raise this to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops and UAT | `[grounded]` resume | None |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The resume is silent on sales work | `[grounded]` resume silence | See G5 |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | Custom builds were coordinated, but the delivery method is not stated | `[grounded]` resume silence on method | See G4 |
| R6 | Own the roadmap for the API platform | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions that fed product. Limit: you supplied input to roadmap decisions, you did not make them | `[grounded]` resume | See G1 |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and feedback sessions with clients who integrate the APIs. Limit: it served implementation and product input, not your own bet-testing | `[grounded]` resume | See G1 |
| R8 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture and coordinated engineers. Limit: not owning a squad's backlog | `[grounded]` resume | See G4 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The resume states no adoption metrics. A prior-context lead about a request-triage tool is unconfirmed and prompts a question only | `[grounded]` resume silence; `memory_lead` unconfirmed | See G3 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches of a kind. Limit: not a product launch with sales and support enablement | `[grounded]` resume | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM work and roadmap ownership (R1a, R1b, R6, R7) | transferability | Roadmap input, requirements writing and partner workshops, but all as a vendor-side implementer | R1b is the titled-years gap. A truthful bridge shows work near the PM role and states its limit | Acting or interim PM stints; product-owner duties on a custom build; deciding what went into a release; a feature you prioritized | A spec, a roadmap-input summary, a release note | `[grounded]` resume; `[generic]` that hiring screens weigh titled years |
| G2 | Shipped API or platform product (R2) | transferability | 30+ integrations and a team-wide playbook, with no product you owned | R2 is a must-have, and the playbook and any tool people adopted are your closest product evidence | A playbook other teams adopted; an internal tool people used; a client-facing API guide | The playbook (sanitized), usage figures, adoption screenshots | `[grounded]` resume; `[generic]` that the gap is real |
| G3 | Adoption metrics (R9) | discovery | A possible request-triage tool that support agents adopted, unconfirmed | It could be your strongest evidence for both R2 and R9 | Usage counts, tickets handled, time saved, how you knew it worked | Usage dashboard, a before/after figure | `[inferred]` from the unconfirmed lead |
| G4 | Agile delivery and spec ownership (R5, R8) | discovery | Coordination of custom builds, with no method or prioritization role stated | R5 is an unresolved must-have | Sprint planning, backlog grooming, ranking work for squads | A sprint board screenshot, a delivery plan | `[grounded]` resume silence |
| G5 | Work with sales and launches (R4b, R10) | discovery | Silent on sales and support | Both are named in the JD | Scoping with account executives, renewal or upsell input, go-live comms with support | A launch checklist, an enablement doc | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer. Research did not run, so nothing is established either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location withheld | unknown | — | The posting as pasted names no salary, level or location | The figure may sit below the role-family band, or the posting may simply omit it | `[grounded]` JD as pasted | What salary band and level is this post, and is it remote or office-based? | unresolved |
| RR3 | Flexibility of the PM-years requirement | unknown | — | "3+ years product management experience (must-have)" | It may be screened literally, or equivalent product-owning work may count | `[generic]` pattern in how years requirements are screened | Would you consider equivalent product-owning experience in place of 3 titled years, and what would that look like? | unresolved |
| RR4 | Clearly stated scope | positive_signal | — | "Own the roadmap for our partner-facing API platform … drive delivery with two engineering squads" | Responsibilities, squads and metric ownership are explicit | `[grounded]` JD | Which adoption metrics are targeted in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Quartzline's own careers page before drafting anything | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR3 question to the recruiter before investing in tailored materials | See R1b, RR3 | `[grounded]` RR3 | pending your approval |
| A3 | Lead with the 30+ integrations, the playbook and the roadmap-input sessions, each as you described it: you led integrations and collected client input, you did not own the roadmap or ship an API product | See R2, R6, R7, and the Verb and Scope axes of the reframing audit | `[grounded]` resume | pending your approval |
| A4 | If you confirm the triage tool, build your product evidence around it, using only the figures you supply | See R2, R9 | `[grounded]` G3 | pending your approval |
| A5 | Seek an introduction or referral before applying cold | How hiring often works at small companies | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-context mention of an internal request-triage tool that support agents adopted — unconfirmed, and it prompts a question only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Quartzline's careers page was refused in this session. It would have moved RR1 and the Organization row in role reality |
| 2. Role-family sweep | unavailable | The search for scope and pay norms for API platform PMs was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can write all of this to `tuesday-dossier.md` if you want it saved.

**Upgrade menu**

- Permission for web search → RR1 and the Organization row close, and the pay band and market calibration appear.
- Your non-negotiables (pay floor, location or remote, travel) → the hard-gate checks run instead of reading as unknown.
- Answers to the questions below → R2, R9, R1a and R5 can move from `adjacent` or `unclear` toward `direct`.
- Your work with sales (account executives, renewals, launch comms) → R4b and R10 close.
- The hiring manager's name → the application plan can say which story to lead with for that reader.
- The playbook or any sanitized artifact → R3 and R2 to `high`.

**Questions**

- **G3 (R2, R9):** A prior conversation suggested you built an internal request-triage tool that support agents adopted. If so, what problem did it solve, which part was yours, who used it, and how did you know it worked?
- **G1 (R1a, R1b):** Outside a PM title, have you ever made product decisions yourself, such as ranking a backlog, acting as interim PM, or deciding what went into a release? What was yours and what was the PM's?
- **G4 (R5, R8):** How were the custom builds delivered (sprints, a backlog), who set priorities, and where did you sit in that?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.