**Yes, worth applying to. The weakest rows are R8 (billing data, absent) and R6 (forecast ownership, adjacent). Status: `conditional_go`.**

I checked the posting against the Quillfield and market pages I could find, which sits in the target table below the upgrade menu.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options)
- `must_have` — direct: R3, R4 · adjacent: R5 (strong SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R7 (Working with finance on billing or revenue data), R11 (At a B2B software company) · absent: R8 (Own billing data)
- `important` — direct: R10 · adjacent: R9 (Own CRM data)

R6 — a credible bridge, its limit named; R8 — no evidence, confirmed by you; R4 (`medium`) — certification stated, record not seen.

**Opportunity ledger.** The employer is real, and the pay is stated and sits inside the market band (RR4, RR5). Open points are that I couldn't find the posting on Quillfield's own site (RR1), no success measures are stated (RR2), and the split of forecast ownership is unclear (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your own location and pay floor clear R1 and R2; (2) the posting verifies on Quillfield's own site (RR1); (3) the forecast and billing gaps (R6, R8) are presented as what they are, adjacent and absent, never as owned.
- **What would change this:** a failed R1 or R2 would make it `no_go`, whatever the fit elsewhere.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 employees; Series A (£11M) closed April 2025 | `[grounded]` About Quillfield page, via search result |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, named by the recruiter (your report); her public title is Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` search result snippet, page not fetched; the recruiter's naming is your report |
| Scope read | A Head of RevOps already exists, so this looks like a lead role inside an existing function, not a build-from-scratch post; the posting itself doesn't give a reporting line | `[inferred]` from her public title against the posting's silence on reporting |
| Market calibration | Median base £64,200, interquartile range £57,800–£70,400 for UK B2B software revenue operations leads (n=438, 2026 guide). The posted band sits inside that range. It is a national band, not Bristol-specific, and is no guide to what Quillfield will offer a given person | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting for its own figure |
| Unknowns | Success measures and first-year outcomes; reporting line; team size; which CRM is used; where billing data lives; how forecast ownership splits between the Lead, the Head of RevOps and the CFO; option terms | `[grounded]` posting is silent on each |
| Contradictions | None between your description and the About page. The posting was not found at quillfield.co.uk/careers (see RR1) | `[grounded]` About page read; careers address returned no page |

## Evidence map

Your background is self-report at this stage: leads, not proof. Nothing is inspected yet, so `medium` is the ceiling.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or what office days you'll work, so the gate is not established | `[grounded]` posting; no candidate statement | Q1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated, so I can't say whether the band meets it | `[grounded]` posting; no candidate statement | Q1 |
| R3 | 4+ years in revenue operations, sales operations or similar | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. Stated and specific, but no document yet | `[grounded]` your background | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. Certification is stated; the scope of your day-to-day admin work is not | `[grounded]` your background | offer: the certification record would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily are stated. "Strong" and "modelling" are not shown by frequency of use | `[grounded]` your background | offer: a sanitised query or model you built |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You've never owned the company forecast; finance did. The bridge is running the monthly pipeline review with your sales director. Limit: a pipeline review is not forecast ownership | `[grounded]` your statements | Q2 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue", so revenue data could count. You rebuilt renewal dashboards, but whether that was with finance is not stated, and you've never worked on billing data | `[grounded]` your statements; `[inferred]` that renewal data is revenue data | Q3 |
| R8 | Own billing data (a duty in the posting's first sentence) | must_have | absent | none | capability | You've said you've never worked on billing data. There's no adjacent work to bridge from | `[grounded]` your statement | closure path in G3 |
| R9 | Own CRM data (a duty in the posting's first sentence) | important | adjacent | medium | discovery | Certified admin and rebuilt dashboards are stated. Ownership of data quality or configuration is not | `[grounded]` your background | confirm in a later answer |
| R10 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Sales use is clear from the monthly review; finance use is not stated | `[grounded]` your background | offer: a sanitised dashboard screenshot would raise this to `high` |
| R11 | At a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether it sells software is not stated | `[grounded]` your background | confirm below, in the upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | A monthly pipeline review you run, with finance owning the forecast | The posting puts the quarterly forecast with the CFO in the role's own duties | Producing pipeline coverage or renewal projections that fed finance's forecast; presenting numbers that someone else's forecast then used | A sanitised forecast input sheet or review pack | `[grounded]` your statements; `[generic]` that forecast ownership is likely to be probed in a role like this |
| G2 | Working with finance on revenue data (R7, must_have) | discovery | Renewal dashboards, but no stated finance involvement | A must-have that could move from `unclear` to `adjacent` or `direct` | Reconciling closed-won or renewal figures with finance; agreeing a revenue definition with them | A definitions doc or a dashboard note | `[grounded]` your statements |
| G3 | Own billing data (R8, must_have) | capability | No billing-data work, confirmed by you | It is a named duty, so it will probably come up in the loop | Closure path: ask what ramp is expected and whether finance co-owns it; optionally build a small exercise that joins invoice figures to CRM closed-won data | A written exercise, only if you want one | `[grounded]` your statement; `[inferred]` that an exercise would help |
| G4 | Location and pay gates (R1, R2, hard_gate) | hard_gate | No stated constraints | If either fails, the status becomes `no_go` | Office-day tolerance and your pay floor | none needed | `[grounded]` no candidate statement |
| G5 | B2B software sector (R11, must_have) | discovery | A payments company, product type not stated | Minor, but it is in the requirement's own wording | Your employer's product being software or a platform | none needed | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed at another address on their site, the posting may be stale, or the page may simply live elsewhere; none ranked likely. The employer itself is established | `[generic]` pattern; `[grounded]` fetch returned no page at that address | Can you point me at this role on Quillfield's own careers site? | unresolved |
| RR2 | No success measures stated | unknown | — | "You will own our CRM and billing data, build the pipeline and renewal reporting..." | Duties are listed with no outcomes, so what counts as success is open | `[grounded]` the posting names no outcomes | What would good look like at six and at twelve months? | unresolved |
| RR3 | Who owns the forecast number | risk_signal | low | "run the quarterly revenue forecast with the CFO" | The Lead may prepare the forecast while the CFO owns the number, or the reverse; a Head of RevOps exists too | `[inferred]` from the posting's wording plus her public title | Who owns the forecast number, and how do the Lead and the Head of Revenue Operations split decisions? | unresolved |
| RR4 | Pay stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The figure sits within the interquartile range of the national band; option terms are open | `[grounded]` posting; `[generic]` band | What are the option terms: size, vesting and strike? | noted |
| RR5 | Employer is verifiable | positive_signal | — | "Quillfield, the invoicing software company" (your description) | Its About page describes a Bristol company with a funded round, matching how you described it | `[grounded]` About page | How is the revenue team structured today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role on Quillfield's own site, or ask the recruiter for the link, before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Settle R1 and R2 against your own location and pay floor first | A failed gate caps the decision | `[grounded]` R1, R2 rows | pending your approval |
| E1 | Lead with your own words: "rebuilt our pipeline and renewal dashboards" and "run the monthly pipeline review with our sales director". Don't describe the review as forecasting | R10, R6 | `[grounded]` your sentences | pending your approval |
| E2 | When asked, say it as you told me: "Finance owned the forecast; I run the monthly pipeline review with our sales director; I haven't worked on billing data." Every clause is yours | R6, R8 | `[grounded]` your sentences | pending your approval |
| H1 | For Tamsin Achebe: her public path is sales operations manager to Head of Revenue Operations, so your sales-ops-to-RevOps path and the pipeline review are the stories closest to hers. Ask her how billing data is learned in the role | Positioning for this reader | `[grounded]` search snippet; positioning is `[inferred]` | pending your approval |
| W1 | A sanitised screenshot or walkthrough of your renewal dashboard | R10, R4 | `[grounded]` your background | pending your approval |
| Q1 | Ask RR1–RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers Revenue Operations Lead Bristol", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved: the organization row, RR1 and RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software UK", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Only the snippet was read. Moved: the scope read, RR3 and H1 |

I can save this as a `tuesday-dossier.md` if you want to reuse it later.

## Upgrade menu

- Whether your employer's product is software → R11 closes.
- Your certification record, or a sanitised query or model → R4 and R5 can reach `high`.
- A sanitised renewal-dashboard screenshot → R10 can reach `high`.
- Any forecast input you produced → G1 narrows R6's limit.
- The recruiter's link to the role on Quillfield's own site → RR1 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

Q1 (G4 — R1, R2): Can you work two days a week in a Bristol office, and what is the lowest salary you would accept?

Q2 (G1 — R6): Have you produced pipeline or renewal projections that finance then used in the forecast? What did you own, and what happened to the numbers?

Q3 (G2 — R7): Have you worked with finance on revenue or renewal figures, for example agreeing definitions or reconciling numbers? Which part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.