I've read most of the playbook. Two reference files, the evidence-map row shape and the gap-question rules, still need reading before I write the assessment.
Next I'm running a quick check that Pellucid Learning and the posting are real and live. The pay report you pasted already covers the market side.
**Yes, it's worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote US or Denver), R10 (Salary $148k–$166k)
- `must_have`: direct: R1, R2, R3, R4a, R5, R6
- `important`: adjacent: R4b (BigQuery warehouse); unclear: R7 (App and CRM ingestion), R8 (Data contracts)

R4b is a credible bridge with its limit named; R7 and R8 are unevidenced, not shown absent.

**Opportunity ledger.** Sound on the terms stated. The posted pay sits at or above the market median (RR1). Equity, team and reporting line are unstated (RR2, RR3), and the employer and live posting are unchecked from here (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Remote US or Denver), R10 (Salary $148k–$166k); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm the location and pay terms work for you (R9, R10).
  2. The role is confirmed live on the company's own careers page (RR4).
  3. The BigQuery bridge is presented as adjacent, never as BigQuery experience (R4b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the About text you pasted; not independently checked (RR4) |
| Mandate | Build and run the pipelines behind reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | One reporting domain end to end. Nothing in the JD mentions direct reports | `[inferred]` from the JD's three named layers; the JD is silent on reports |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically 5–8 years; usual scope is one domain's pipelines, no direct reports. The posted range runs from just under the median to above the upper quartile | `[generic]` Datawright 2026 report (n=2,310) your recruiter sent; `[grounded]` JD for the posted figures |
| Unknowns | Hiring manager, team size, reporting line, equity terms, first-year outcomes, whether the posted salary is base | — |
| Contradictions | None between the JD and the About text as pasted; the live pages were not checked | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years in data engineering at a B2B payroll company. It is prose self-report, so `medium` is the intake ceiling. | `[grounded]` your stated background; `[generic]` for the 5–8 year "Senior" span, from the supplied report | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You state "Python and SQL daily". Specific, but with nothing inspectable yet. | `[grounded]` your stated background | A code sample or repo excerpt would raise to `high` |
| R3 | dbt | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. | `[grounded]` your stated background | A sanitized model lineage or project structure would raise to `high` |
| R4a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. | `[grounded]` your stated background | none |
| R4b | BigQuery as the specific warehouse | important | adjacent | medium | transferability | You have never used BigQuery. Warehouse modelling in dbt carries over as method; BigQuery's own specifics are unexercised. | `[grounded]` your statement; `[generic]` that warehouse-specific behaviour differs by platform | See G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and in your background. | `[grounded]` JD and your stated background | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. | `[grounded]` your stated background | A sanitized suite config would raise to `high` |
| R7 | Ingestion from app and CRM | important | unclear | none | discovery | Your background does not mention source systems or ingestion. Silence is not absence. | `[grounded]` background silence | See G2 |
| R8 | Data contracts analysts depend on | important | unclear | none | discovery | Your background does not mention contracts or analyst-facing guarantees. | `[grounded]` background silence | See G3 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The JD states the terms. Your location and constraints were not given. | `[grounded]` JD; your side unstated | See G4 |
| R10 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | The JD states the range. Your floor was not given. | `[grounded]` JD; your side unstated | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4b, important) | transferability | Snowflake and dbt carry over as method. BigQuery itself is untested, and you've said so. | The role's warehouse is named as BigQuery, so it will likely come up in screening | A personal or side project on BigQuery's free tier; a Snowflake-to-BigQuery comparison you wrote up | A small public dbt-on-BigQuery project | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that the named platform draws screening questions |
| G2 | App and CRM ingestion (R7, important) | discovery | Nothing in your background names source systems | The JD lists ingestion first among its responsibilities | Loading product-event data into a warehouse; syncing CRM objects; owning a connector or an extract job | A pipeline diagram or a DAG screenshot | `[grounded]` background silence; `[inferred]` from the JD's ordering that ingestion carries weight |
| G3 | Data contracts (R8, important) | discovery | Your background says nothing about contracts or analyst-facing guarantees | The JD says analysts depend on them | Agreeing schema or freshness guarantees with analysts; versioning a model's interface; tests that block a breaking change | A contract doc, or a dbt model config with contracts or tests | `[grounded]` background silence |
| G4 | Location and pay terms (R9, R10, hard_gate) | hard_gate | The JD states both. Your side of each is unstated. | A gate that is unconfirmed holds the decision at conditional | Not applicable: this asks whether the gate is met | None needed | `[grounded]` JD; your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay against market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range runs from just under the report's median to above its upper quartile, so it is not low for the title. It may include or exclude bonus. | `[grounded]` JD figures against the supplied report's median and quartile | Is the range base salary, and where in it would my experience place me? | noted |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Grant size, vesting and strike are not stated. | `[inferred]` from the JD's silence | What is the typical grant for this level, its vesting schedule, and the current strike price? | unresolved |
| RR3 | Team, reporting line and hiring manager unstated | unknown | — | You note the posting names no hiring manager; the JD says "Build and run the pipelines" | You may be the sole data engineer, or one of several. Unknown either way. | `[inferred]` from the JD's single-role phrasing; the report's norm is `[generic]` | Who does this role report to, and who else works on data engineering and analytics? | unresolved |
| RR4 | Employer and live posting not checked from here | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)" | These facts come from the company's own page as you pasted it. My attempt to fetch the careers page was declined, so liveness and stage are unchecked. | `[grounded]` your pasted About text; no outside check ran | Can you point me at this role on your careers site, and tell me who I'd interview with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Built the dbt project on Snowflake (about 180 models), with Airflow orchestration and a Great Expectations test suite I set up" | Puts the JD's core stack in one line; every clause traces to your own sentences | `[grounded]` your stated background | `resume_edits_pending_approval` |
| E2 | For the BigQuery question, say: "I've done six years of data engineering at a payroll company, building our dbt project on Snowflake; I haven't used BigQuery yet." | States the adjacency without claiming platform experience | `[grounded]` your stated background | pending your approval |
| A1 | Check the live posting on the company's own careers page before applying | See RR4 | `[grounded]` RR4 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The fetch of pellucidlearning.com/careers/senior-data-engineer was declined and no search was sent. It would have moved role reality's contradictions row and RR4 |
| 2. Role-family sweep | skipped | The supplied pay report fixes the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

Say the word if you'd like a short check of the company, or just paste the careers-page text, and I can fill the missing rows. I can also keep the dossier of this assessment in `tuesday-dossier.md` if you'd like it for later.

**Upgrade menu**

- The careers-page text, a link, or permission to fetch it → RR4 and the contradictions row close.
- A reply on G2 or G3, or a code or lineage artifact → R7 or R8 move off `unclear`, and R2, R3 or R6 can rise to `high`.
- The hiring manager's name → the scope read and which of your stories to lead with.
- Deeper company diligence (funding and leadership changes, employee reports; up to 5 more searches and 2 more fetches) → fuller risk register, if you want it.

**Questions**

- G4 (R9, R10) — Are you based in the US, or willing to be in Denver, and is $148,000 at or above your base-pay floor?
- G2 (R7) — Have you built ingestion from a product app's data or a CRM into a warehouse, and what did you own?
- G3 (R8) — Have you defined or enforced data contracts, or agreed schema and freshness guarantees with analysts, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.