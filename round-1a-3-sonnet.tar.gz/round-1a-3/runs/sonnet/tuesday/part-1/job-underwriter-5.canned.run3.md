Reading the playbook's remaining reference files (row shape, gap rules, decision rules) before I write the assessment.
# Job Underwriting Assessment: Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Is it worth it, Ines? Yes, worth applying to, on conditions only you can settle: R1 and R2, the hard gates, are unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (a dbt-modelled warehouse in BigQuery); unclear: R10 (ingestion from our app and CRM), R11 (the data contracts our analysts depend on)

R9 — a credible bridge from Snowflake, its limit named; R10, R11 — your background as given doesn't touch ingestion sources or contracts; R1, R2 — unsettled until you give your location and pay floor.

**Opportunity ledger.** Sound on what is posted: the pay range sits at or above the market median (RR1). The equity terms are missing (RR2). The team, manager and reporting line are not stated (RR3). The funding and headcount claims rest on the company's own pages only (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: your location and US work eligibility fit "Remote (US) or Denver"; (2) R2: the range clears your pay floor; (3) R9 is framed as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). The posting is live ("Accepting applications") and its wording matches what you pasted. | `[grounded]` company about page and careers page, fetched; the funding and size claims have no source beyond the company's own page |
| Mandate | Own the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements named | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Scope read | One reporting domain spanning two source systems and the warehouse layer; no direct reports mentioned, which matches the report's typical scope of one domain's pipelines with no direct reports | `[inferred]` from the JD's silence on reports, set against the pay report's scope note |
| Market calibration | The posted $148,000–$166,000 against a base median of $151,000 and IQR of $139,000–$163,500 for Senior Data Engineers at Series B–D companies. The low end is $3,000 under the median and the top is $2,500 over the 75th percentile. Your 6 years sits inside the report's usual 5–8 for "Senior". The posting says "salary", the report measures base, and I assume they match. | `[grounded]` JD and the Datawright 2026 report you supplied (US, n=2,310); `[generic]` as a role-family norm, never this employer's offer |
| Unknowns | Hiring manager (unnamed), team size, equity terms, whether pay differs for Denver versus remote, whether you would be the only data engineer | `[grounded]` JD silence |
| Contradictions | None between the careers page and the pasted posting | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You have not stated where you live or your US work eligibility, so the term can't be checked either way | `[grounded]` JD quote; `[grounded]` your constraints not given | Question Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You have not stated a pay floor. The posted range is clear, but whether it clears your floor is not established | `[grounded]` JD quote; `[grounded]` your floor not given | Question Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It is self-report with nothing inspected, so `medium`. This is a length-of-experience requirement, not a gate | `[grounded]` your stated background | Check the CV dates and titles match |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact seen. "Strong" is the JD's word and rests on your own account | `[grounded]` your stated background | A code sample or repo link would raise this to `high` |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models, on Snowflake. Confirmed and specific, but no project artifact inspected | `[grounded]` your stated background | A sanitized model-lineage screenshot or project structure would raise this to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the stated requirement is met. The BigQuery-specific part is R9 | `[grounded]` your stated background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as your orchestrator; ownership and scale not stated | `[grounded]` your stated background | A sanitized DAG excerpt or diagram would raise this to `high` |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, which is the work itself, not merely adjacent to it. Coverage and who used it are not stated | `[grounded]` your stated background | Name what the suite covered; a suite summary would raise this to `high` |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Your dbt-on-Snowflake work carries over. Limit: you have never used BigQuery. Dbt models are largely SQL, but BigQuery's pricing and table-layout choices differ from Snowflake's | `[grounded]` your stated Snowflake and "never used BigQuery"; `[generic]` on the platform differences | Gap G1 |
| R10 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background mentions Airflow pipelines but not what you ingested or from where. There is no evidence either way | `[grounded]` your background is silent on sources | Gap G2 |
| R11 | The data contracts our analysts depend on | important | unclear | low | discovery | Your Great Expectations suite may be adjacent, but you haven't described agreements with downstream users. Not asserted as a claim | `[inferred]` from the Great Expectations suite, as a lead only | Gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R9, important) | transferability | Confirmed dbt and Snowflake work; no BigQuery use | The posting names BigQuery as the warehouse, so this is the most visible adjacency. Interviewers on warehouse-specific roles often test platform specifics | Snowflake cost or performance tuning; any other warehouse you've used (Redshift, Postgres); a partitioning or clustering decision | A small personal dbt project run against BigQuery as a work sample; a sanitized Snowflake tuning write-up | `[grounded]` the gap itself; `[generic]` that such roles probe platform specifics |
| G2 | App and CRM ingestion (R10, important) | discovery | Pipelines orchestrated in Airflow; sources not described | The role's first named job is ingestion, and the JD is explicit that sources are the app and CRM | Syncing a SaaS CRM's API into a warehouse; loading product-database or event-stream data; using a managed ELT tool or writing your own loaders | A sanitized DAG, an architecture diagram, an ingestion-source list | `[grounded]` background silent on sources |
| G3 | Data contracts (R11, important) | discovery | A test suite you built; no stated agreements with analysts | "Data contracts" is in the posting's headline mandate; a clear answer here could move R11 to `direct` | Agreeing a schema or freshness guarantee with a downstream team; dbt model contracts or tests on models analysts query; alerting when an upstream change broke a report | A contract doc, a dbt contract config, an incident write-up | `[grounded]` background silent; `[generic]` that such roles lean on this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay against market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is competitive and openly stated, which reads as transparency | `[grounded]` JD and the Datawright report | Is the range the same for remote and Denver, and where in it would someone with 6 years and my background be placed? | noted |
| RR2 | Equity named without terms | unknown | — | "plus equity" | Value may vary widely with grant size, vesting and valuation | `[generic]` equity terms vary by company; no claim about this one | What is the grant range, the vesting schedule, and the latest valuation basis for this level? | unresolved |
| RR3 | Team, manager and reporting line not stated | unknown | — | "Build and run the pipelines" | You may be the sole owner of the pipelines, or part of an established team; the posting doesn't say | `[inferred]` from the JD's "build and run" against its silence on team and manager | Who is on the data team today, who would I report to, and who owns the analyst-facing contracts now? | unresolved |
| RR4 | Funding and headcount claims have only company-sourced support | unknown | — | "Series C ($52M, February 2026)" | The claim may be accurate; I found no second source in one search | `[grounded]` search returned the company's own about page only | Who led the Series C, and what runway does it give the data function? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the three JD-named strengths you stated: your dbt project (about 180 models), your Airflow orchestration, and the Great Expectations suite you set up | see R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| P2 | Name Snowflake plainly as the warehouse you used, and say BigQuery is new to you; claim no BigQuery experience anywhere | see R9 | `[grounded]` R9 | pending your approval |
| P3 | Optional work sample: a small dbt project run against BigQuery on a personal cloud account, to narrow G1 | see R9, G1 | `[grounded]` G1 | pending your approval |
| P4 | Ask RR1, RR2, RR3 and RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), which checked your pasted posting: live and matching. Searched "Pellucid Learning Series C $52M tutoring Denver", which returned only "About Pellucid Learning" (pellucidlearning.com/about), the text you pasted, so there is no independent source. Moved: role reality's organization and contradictions rows, and RR4 |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and already fixes the pay band and the scope norm; it fed role reality's market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form. The upgrade menu names what a name would unlock |

## Dossier offer

I can write all of this to `tuesday-dossier.md` for later use, if you'd like.

## Upgrade menu

- Your location and US work eligibility → R1 closes.
- Your pay floor → R2 closes against the posted range.
- A sanitized dbt lineage view, DAG excerpt or Great Expectations suite summary → R5, R7 and R8 move toward `high`.
- An answer on contracts (G3) or on ingestion sources (G2) → R11 or R10 may move to `direct`.
- A small BigQuery work sample → G1 narrows.
- The hiring manager's name, once the recruiter shares it → role reality's scope read, and which of your stories the plan leads with for that reader.
- A deeper research pass on Pellucid Learning (a second source for the Series C, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

Q1 (R1) — Where are you based, and are you able to work for a US employer from there, or from Denver?
Q2 (R2) — What is the lowest base pay you'd accept, and does equity count toward it for you?
Q3 (G3) — Have you ever agreed a schema, freshness or quality guarantee with a downstream team? What did you own, who was involved, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.