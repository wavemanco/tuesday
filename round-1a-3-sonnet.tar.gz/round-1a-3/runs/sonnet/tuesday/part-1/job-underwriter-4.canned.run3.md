Checking the company's own careers page, because the search snippet says Leeds office four days a week and your JD says fully remote.
## Decision snapshot

**Yes, go for it, as long as the working pattern suits you. Status: `conditional_go`.** R1 (fully remote) is the open condition: the JD says remote, but Brindlemoor's own careers page says something different.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7a · unclear: R7b (Monitoring rating models)
- `preferred` — direct: R8 · adjacent: R9 (Pet-insurance product knowledge)

R7b — maintenance stated, monitoring not; R9 — a credible bridge, its limit named.

**Opportunity ledger.** The role reads as real and live, but the posting contradicts itself on where you would work (RR1) and withholds pay (RR2). One entry runs the other way: the hiring manager is named and has a public pricing record (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as remote, or as something you can accept — R1, RR1; (2) the pay lands above your floor — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling pet insurance; the careers page lists this role as accepting applications | `[grounded]` JD header, careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` JD, careers page |
| Working pattern | The JD says "Fully remote (UK)"; the careers page says "Leeds office four days a week" | `[grounded]` both sources |
| People management | Neither the JD nor the careers page states direct reports or asks for management experience, so your never having managed anyone is not a stated gap | `[grounded]` JD and careers page silence |
| Compensation | No figure stated. A pay survey of senior pricing analysts at UK insurers and insurtechs (n=612) shows a median base of £58,400 and an interquartile range of £52,100 to £64,900. That is a market band, never this employer's offer (RR2) | `[generic]` Pricewell survey, seen as a search snippet; `[grounded]` JD for the missing figure |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books, and previously led pricing analytics at Calloway Re for six years. This lines up with the monitoring half of the role | `[grounded]` her public profile, seen as a search snippet; `[inferred]` that it bears on R7b |
| Unknowns | Salary; which working pattern is current; team size; how much pet-claims data the book holds | — |
| Contradictions | Remote (JD) against Leeds four days a week (careers page) | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location constraint, so the claim side is empty. The two sources disagree on the role's terms, so fit stays unclear until the pattern is confirmed and you say whether it matters | `[grounded]` JD quote "Fully remote (UK)" and careers page "Leeds office four days a week" | G1, then RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer. That is confirmed and specific, but it is prose with nothing inspectable behind it | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Specific, but no artifact has been seen | `[grounded]` your background | offer: a sanitized query or notebook sample would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. It is motor, which R9 covers | `[grounded]` your background | offer: sanitized model documentation or a factor summary would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | offer: a sanitized review deck would raise to high |
| R6 | Design and read price tests, turn results into recommendations | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" is what you said, so design and recommendation work are not yet separately stated; claim only what you said | `[grounded]` your background | none |
| R7a | Build rating models | must_have | direct | medium | none | Same evidence as R4: a GLM you built | `[grounded]` your background | none |
| R7b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained"; nothing says how the model was watched. Low rather than none because maintenance is a concrete thread | `[grounded]` your wording; `[inferred]` that maintenance involved monitoring | G2 |
| R8 | Insurance experience a plus | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R9 | Pet-insurance product knowledge (the JD asks for none; the role is for the pet product) | preferred | adjacent | medium | transferability | The bridge is motor GLM rating. Pet rating uses factors motor does not (for example breed and the animal's age), so factor-selection work would not transfer directly. State this plainly | `[grounded]` your motor GLM work; `[generic]` the pet-versus-motor factor difference; `[inferred]` requirement from the product named in the JD | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says remote, the careers page says Leeds four days a week, and you have not said whether location is a constraint | A gate. If you need remote and the careers page is current, the status moves to `no_go` | Not a recall gap: the answer is a fact about the role and about your circumstances | Brindlemoor's written answer on the current working pattern | `[grounded]` both sources; `[inferred]` the status consequence |
| G2 | Monitoring rating models (R7b, must_have) | discovery | "Built and maintained" the GLM, with nothing on how it was tracked | R7b is a must_have row at `unclear`, and monitoring is half of the role's first sentence | Tracking actual against expected on the young-driver model; a recurring dashboard for loss-ratio or conversion drift; deciding when to recalibrate or refit; a monitoring pack that went to underwriting | A sanitized monitoring pack, a dashboard screenshot, or a refit memo | `[grounded]` your "maintained" wording; `[generic]` that monitoring packs are a common model-governance artifact |
| G3 | Pet-insurance knowledge (R9, preferred) | transferability | A confirmed motor GLM, with nothing touching pet rating | A preferred row that the JD does not require; the likeliest probe in an interview is where the bridge stops | Any work on a product with age or risk-class rating factors; any reading you can honestly cite on how pet pricing differs | None needed beyond candor about the limit | `[inferred]` the bridge from your motor work; `[generic]` that it is the likeliest probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between the posting and the careers page (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD may predate a policy change, one source may be an error, or the role may be hybrid; none is ranked as likely | `[inferred]` from the two sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week, and which is current? | unresolved |
| RR2 | Salary withheld | unknown | — | The JD as pasted states no pay figure | The figure may sit anywhere in or outside the market band in role reality, or the company may simply not publish it | `[inferred]` from the missing figure against the `[generic]` band | What base salary range is budgeted for this post? | unresolved |
| RR3 | Named hiring manager with a public pricing record | positive_signal | — | Careers page: "reports to the Director of Pricing" | The reporting line is to a named senior pricing practitioner, so the role has a clear owner | `[grounded]` careers page and her public profile | How is rating-model monitoring split between this role and you? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask Brindlemoor which working pattern is current, using contact details from its own careers page, before investing in an application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead your positioning with two things you said: you built and maintained the GLM rating model for the young-driver book, and you ran 14 price tests with the underwriting team last year | see R4, R6 | `[grounded]` your own sentences | pending your approval |
| P2 | Say plainly that you have not worked on pet insurance, and offer motor GLM rating as the adjacent evidence | see R9 | `[grounded]` your background | pending your approval |
| P3 | Hold any wording about monitoring until G2 is answered | see R7b | `[grounded]` R7b row | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2 and RR3 verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality: the role is live and the reporting line agrees, but the working pattern contradicts the JD (RR1, R1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary remote pet insurance", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration row, as a `[generic]` band read from the search snippet, not the full page |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved the hiring-manager row and RR3, from the snippet only, limited to her public professional record |

I can save all of this as `tuesday-dossier.md` if you want it for later.

## Upgrade menu

- Your location constraint (remote-only, or Leeds possible) → R1 closes, and the decision becomes `go` or `no_go`.
- Your pay floor → RR2 can be set against the band in role reality.
- A sanitized monitoring pack, dashboard or refit memo → R7b rises toward `direct`.
- A sanitized model factor summary, a price-test readout, a review deck or a query sample → R4, R6, R5 and R3 can rise to `high`.
- Your CV → checks for buried evidence and proposed edits.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Is working from the Leeds office four days a week something you could do, or is fully remote a requirement for you?

G2 — After the young-driver GLM went live, what did you track on it, how often, and who saw the results?

RR2 — What is the lowest base salary you would accept for this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.