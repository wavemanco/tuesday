**Yes, it's worth applying. R3, R4, R5, R6, R7 and R8, the six must-haves, are each `direct`, and R1 and R2 are the two terms still to confirm. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay $148,000–$166,000 plus equity), R2 (Remote (US) or Denver office)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery-modelled warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9 — a credible bridge, its limit named; R10, R11 — your background is silent, one question each; R1, R2 — waiting on your own terms.

**Opportunity ledger.** Sound on what is stated: the pay is stated and sits in range of your recruiter's report (RR5). What's missing is the posting's live status (RR1), the reporting line (RR2) and the equity terms (RR3). RR4 asks whether the scope is bigger than the team behind it.

- **Hard gates:** none failed; unconfirmed: R1 (Pay $148,000–$166,000 plus equity), R2 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay and location terms work for you — R1, R2; (2) BigQuery is framed as adjacent, never as experience — R9; (3) the posting is confirmed live — RR1; (4) the team-size answer in the first conversation doesn't put you alone on the whole stack — RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about page as you pasted it; not independently checked |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver office. The posting doesn't say whether the figure is base | `[grounded]` JD |
| Scope read | Ingestion, warehouse modelling, contracts and testing all sit in one role, and the posting is silent on team size and direct reports | `[inferred]` from the JD's scope list against its silence on team |
| Market calibration | Report: Senior Data Engineer at Series B–D companies, base median $151,000, interquartile range $139,000–$163,500, "senior" typically 5–8 years, typical scope one domain's pipelines with no direct reports. The posting's midpoint ($157,000) is $6,000 above that median, and its top ($166,000) is $2,500 above the range's upper quartile. This is the report's band, not this employer's offer | `[grounded]` the Datawright 2026 report you supplied (n=2,310, one report); the comparison is `[inferred]` |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Team size, reporting line, equity terms, which CRM and app data sources, on-call expectations | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the about page as pasted | `[grounded]` the two pasted pages; not checked against the live site |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so the term can't be checked. The range sits around the report's median | `[grounded]` JD and report; no constraint given | Ask whether the terms work (G1) |
| R2 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't stated, so whether you can take a US-remote or Denver seat is not established | `[grounded]` JD; no constraint given | Ask (G1) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | "6 years of data engineering" at a B2B payroll company is a specific claim with nothing yet inspectable. Six years sits inside the report's 5–8 typical span for the title | `[grounded]` your background; `[grounded]` report | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is specific and confirmed by you, with no artifact | `[grounded]` your background | none; a repo or query sample would raise it to `high` |
| R5 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models" is specific and owned, with no inspectable artifact yet. A dbt docs site or lineage view would be one | `[grounded]` your background | Offer: a dbt docs or lineage screenshot, sanitized |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as written is met. BigQuery is a separate row (R9) | `[grounded]` your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" is a direct match. Your claim doesn't say how large the DAG estate was or whether you owned it | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite" is an owned, specific claim, with no artifact yet | `[grounded]` your background | Offer: a Great Expectations data-docs page or suite listing, sanitized |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The dbt and warehouse-modelling work carries over. The limit is that you have not used BigQuery at all. SQL modelling skills usually transfer across warehouses, while cost model and storage layout are where a newcomer's gap shows | `[grounded]` your statement of no BigQuery use; `[generic]` how warehouses differ | See G2 |
| R10 | Ingestion from the app and the CRM | important | unclear | low | discovery | Nothing you've said covers where your data came from or how it was ingested | `[grounded]` your background silent | See G3 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your tests and your dbt models may count, but you haven't said whether you agreed formal expectations with data producers or analysts | `[grounded]` your background silent | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay and location terms (R1, R2) | hard_gate | The posting's terms are known; your own limits are not | A gate left unconfirmed keeps the decision at `conditional_go` until it's answered | A salary floor; a state of residence or a Denver commute | None to attach; your own statement | `[grounded]` constraints not given |
| G2 | BigQuery (R9, important) | transferability | Strong dbt and SQL on Snowflake; no BigQuery use | The one stack item named in the JD that you haven't touched | Any BigQuery use: a side project, a migration discussion, queries you've run in a sandbox | A small dbt-bigquery project, if you choose to build one | `[grounded]` you said never used; `[inferred]` that this is the likeliest probe |
| G3 | Ingestion from app and CRM (R10, important) | discovery | Nothing about your sources or loaders | The JD lists ingestion first among the pipelines | Loading a product database or event stream; pulling a CRM's data by API or a managed connector; writing a custom Python loader | A loader's README or a DAG listing | `[grounded]` background silent; `[generic]` that ingestion is a standard first question in this kind of role |
| G4 | Data contracts (R11, important) | discovery | Great Expectations and dbt work may count; nothing says an agreement existed | The JD says analysts depend on the contracts | Agreeing column definitions or freshness with an upstream team; enforcing a schema in dbt; alerting analysts when a source broke | A written schema agreement, a model's YAML, an incident note | `[grounded]` background silent; `[inferred]` that your tests are the nearest equivalent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live status not independently checked | unknown | — | "Senior Data Engineer — Pellucid Learning" | The posting may have changed or closed since you copied it | `[grounded]` the pasted pages are the company's own; my search to check them was refused | Is this role still open, and what is the hiring timeline? | unresolved |
| RR2 | Hiring manager not named | unknown | — | "The posting names no hiring manager" | The reporting line and the team behind the role are unknown | `[grounded]` your note on the posting | Who would I report to, and which team does this role sit in? | unresolved |
| RR3 | Equity unspecified, and whether the pay figure is base | unknown | — | "$148,000–$166,000 plus equity" | The equity value and the base comparison with the report can't be settled | `[inferred]` from the posting's silence on both | What is the equity grant, and is the range base salary? | unresolved |
| RR4 | End-to-end scope with no team size | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be sole or near-sole owner of ingestion, modelling and contracts, wider than the one domain the report describes as typical | `[inferred]` from the JD's scope list against the report's one-domain norm | How many data and analytics engineers are on the team, and who owns ingestion versus modelling today? | unresolved |
| RR5 | Pay stated and in range of the market report | positive_signal | — | "$148,000–$166,000" | The range sits around the report's median, with its midpoint above it | `[grounded]` the posting and the report | Where in the range would an offer for my background fall? | noted |

I'm going only on what you've shared and what the pages you pasted say, and I can get this wrong. Check the posting is live on the company's own careers page before you invest effort. It's your call.

## Application plan

Resume wording itself is resume-tailor's job.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with your own three lines: the dbt project on Snowflake (about 180 models), Airflow for orchestration, and the Great Expectations test suite you set up | See R5, R7, R8; each traces to your own sentences | `[grounded]` your background | pending your approval |
| A1 | Describe BigQuery plainly: dbt on Snowflake, with no BigQuery use yet. Never claim BigQuery experience | See R9 and its limit | `[grounded]` your statement | pending your approval |
| A2 | Optionally build a small dbt-bigquery project to narrow the R9 limit | See G2; only if you want the work sample | `[inferred]` from R9's limit | pending your approval |
| A3 | Check the posting is live on the careers page before applying | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims are intake-level (`medium` at best) until something inspectable arrives.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused: "Pellucid Learning online tutoring K-12 Denver Series C $52M" and "Pellucid Learning careers Senior Data Engineer". Role reality's organization and contradictions rows and RR1 rest on the pasted text only |
| 2. Role-family sweep | skipped | The Datawright report you supplied already fixes the market calibration line and RR5 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can offer a dossier of this assessment (`tuesday-dossier.md`) if you'd like to carry it into later steps.

## Upgrade menu

- Your pay floor and where you're based, and whether you'd go to Denver → R1 and R2 close; the status likely moves to `go` or `no_go`.
- Any BigQuery exposure, even a sandbox → G2 narrows R9's limit.
- Answers on ingestion and data contracts → R10 and R11 resolve.
- A sanitized dbt docs or lineage view, a Great Expectations data-docs page, or an Airflow DAG listing → R5, R7 and R8 can reach `high`.
- The recruiter's answers on team size, reporting line and equity → RR2, RR3 and RR4 resolve.
- Search access, if you grant it → the L1 checks on the company and posting would run, and a deeper pass (up to 5 more searches and 2 more fetches) is available on request.

**Questions**

- G1 (R1, R2) — Do the posting's terms work for you: US-based remote or Denver, at $148,000–$166,000?
- G3 (R10) — Where did the data you ingested come from, and did you build or own the loading?
- G4 (R11) — Did you ever agree schema, freshness or definitions with the teams producing or consuming your data, and what happened when a source broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.