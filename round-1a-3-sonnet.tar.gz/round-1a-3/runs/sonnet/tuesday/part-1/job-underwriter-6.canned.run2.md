**Decision snapshot**

**Yes, it's worth applying, but as a stretch candidate. R6a (owning a forecast) and R7a (working with finance on billing data) are real gaps, and R1 and R2 are still unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol office, two days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3a, R4 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6b (monthly pipeline review) · unclear: R3b (at a B2B software company), R7b (or on revenue data) · absent: R6a (Experience owning a forecast), R7a (Working with finance on billing data)
- `important` — direct: R8

R6a, R7a — plain gaps; R6b — a bridge, its limit named; R1, R2 — not settled without your constraints.

**Opportunity ledger.** The employer and the hiring manager can both be attributed (RR1), and the stated pay sits within the market range I found (RR2). Open items are the mandate's scope (RR3), who owns the forecast today (RR4), the listing's absence from the company's own site (RR5) and the share-option terms (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol office, two days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay band both work for you — R1, R2; (2) the hiring manager treats forecast ownership and billing data as things you'd grow into, not day-one requirements — R6a, R7a, RR3, RR4; (3) the pipeline-review bridge is told as adjacent, never as forecast ownership — R6b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` About Quillfield page (quillfield.co.uk/about) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (snippet only; page not opened) |
| Stage | Evaluating, assumed because you asked whether to go for it | `[inferred]` from your question |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | One person carries four jobs: CRM, billing data, reporting and forecasting. The JD names no team, tools or success measures | `[inferred]` from the JD's scope against its silence |
| Market calibration | Ledgerline 2026, revenue operations lead, UK B2B software (n=438): median base £64,200, interquartile range £57,800–£70,400. The posting's range contains that median and sits inside the interquartile range. This is a UK-wide pattern, not Quillfield's offer, and I found no Bristol-specific cut | `[generic]` Ledgerline guide; `[grounded]` JD for the posting's figures |
| Unknowns | Team size, who owns the forecast today, share-option terms, success measures | — |
| Contradictions | None found between the JD and the About page. The role is not on any Quillfield page I could reach (RR5) | `[grounded]` About page read; one careers address returned no page |

## Evidence map

I've seen no CV, only your message, so every claim is self-report and the intake ceiling is `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol office, hybrid, two days a week | hard_gate | unclear | none | hard_gate | You gave no location constraint, so I can't say whether this term is met | `[grounded]` JD quote; your constraints not given | Ask G7 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | You gave no pay floor. The band sits within the market range I found (RR2) | `[grounded]` JD figure; `[generic]` market band | Ask G7 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. Specific and plausible, but no document inspected | `[grounded]` your message | Offer: your CV would let me check how this reads |
| R3b | ...at a B2B software company | must_have | unclear | medium | discovery | Your employer is a B2B payments company. Whether that counts as "software" is not settled. Quillfield itself sells invoicing and payments software, so the domains sit close | `[grounded]` your message; `[inferred]` closeness from the About page | G5 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, by your statement. The JD says "or", so HubSpot isn't needed. The certification itself is not inspected | `[grounded]` your message and JD | Offer: the certification record would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | "SQL weekly, Excel daily" gives frequency, not depth, and you haven't described any modelling | `[grounded]` your message | G6 |
| R6a | Experience owning a forecast | must_have | absent | none | capability | You've never owned the company forecast; finance did | `[grounded]` your message | G2 |
| R6b | Forecast-adjacent work: monthly pipeline review with sales leadership (the bridge for R6a) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. The limit: you haven't said that review feeds the forecast finance owns, so it is not forecast ownership | `[grounded]` your message | G1 |
| R7a | Working with finance on billing data | must_have | absent | none | capability | You've never worked on billing data. The JD says "billing or revenue data", but the mandate says you'll "own our CRM and billing data", so billing is in the job either way | `[grounded]` your message and JD | G3 |
| R7b | ...or on revenue data | must_have | unclear | low | discovery | Pipeline and renewal dashboards are revenue-related, but you haven't said finance supplied or used the figures | `[grounded]` your message; `[inferred]` revenue link from the dashboards | G4 |
| R8 | Build pipeline and renewal reporting | important | direct | medium | none | You rebuilt your company's pipeline and renewal dashboards. The JD says sales and finance run on this reporting, and you haven't said finance used yours | `[grounded]` your message and JD | Offer: a sanitized dashboard walkthrough would raise this to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast-adjacent work (R6b, must_have) | transferability | You present the monthly pipeline review; it is unclear whether its numbers feed finance's forecast | It is the one bridge to the biggest gap, and its limit decides how honestly it can be framed | Pipeline coverage or commit calls; adjusting stage probabilities; reconciling the pipeline view to finance's number | A sanitized review deck or pipeline-coverage view | `[grounded]` your message; `[inferred]` that this bridge narrows R6a's objection |
| G2 | Owning a forecast (R6a, must_have) | capability | No forecast ownership, by your account | The posting lists it as a requirement and the mandate has you running it with the CFO | A scoped route: a forecast view built from dashboards you already own, shown as a work sample without claiming ownership | A small forecast model on sanitized data | `[grounded]` your message and JD |
| G3 | Billing data (R7a, must_have) | capability | No billing-data work, by your account | The mandate says you'd own it | None from what you've said | None | `[grounded]` your message and JD |
| G4 | Revenue data with finance (R7b, must_have) | discovery | Renewal dashboards exist; finance's involvement is not stated | The JD's "or revenue data" could satisfy this requirement | Renewal figures reconciled with finance; finance reviewing your dashboards; shared definitions of ARR or renewal rate | A dashboard definition sheet or a finance sign-off email | `[grounded]` your message; `[inferred]` that this could meet the "or" |
| G5 | B2B software sector (R3b, must_have) | discovery | Employer described as a B2B payments company | It sets how the sector clause reads | Whether the company sells a software product customers use directly | A company product page | `[grounded]` your message |
| G6 | SQL and spreadsheet modelling depth (R5, must_have) | discovery | Frequency stated, depth not | "Strong" is the posting's word | Joins across CRM and billing-style tables; cohort or renewal queries; scenario models in Excel | A sanitized query or model | `[grounded]` your message and JD |
| G7 | Location, hybrid and pay (R1, R2, hard_gate) | hard_gate | No constraints given | Either could fail outright | Not applicable | Not applicable | `[grounded]` your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and hiring manager attributable | positive_signal | — | "Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol; 96 employees." | The employer exists as described, and the named hiring manager holds a matching role there | `[grounded]` About page and profile snippet | Who would I report to, and who is on the interview panel? | noted |
| RR2 | Pay consistent with market | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The posted range is in line with the pattern for the title | `[grounded]` JD figure; `[generic]` Ledgerline band | How is placement within the band decided? | noted |
| RR3 | Mandate with no team, tools or success measures | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast with the CFO" | Four jobs may land on one person with no stated support | `[inferred]` from the JD's scope against its silence | What team and tooling does this role have, and what would a good first year look like? | unresolved |
| RR4 | Forecast ownership split unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The Head of Revenue Operations may hold or share the forecast today, so what this role would own is unstated | `[inferred]` from the JD line against the hiring manager's public title | Who owns the quarterly forecast today, and how would it split between this role and yours? | unresolved |
| RR5 | Listing not found on the company's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" (on Tallyboard) | The role may be new, listed elsewhere, or only on the job board. I tried one careers address and it returned no page | `[grounded]` fetch result; reasons listed side by side, none ranked | Where does this role appear on Quillfield's own site? | unresolved |
| RR6 | Share-option terms withheld | unknown | — | "plus share options" | Value depends on grant size, vesting and strike price, none of which are stated | `[generic]` option terms vary widely between employers | What are the grant size, vesting schedule and strike price? | unresolved |

## Application plan

I'm proposing no CV edits because I haven't seen your CV. Every row below is proposed language or action, not final.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review | see R8, R6b | `[grounded]` your message | pending your approval |
| A2 | Say the gaps plainly in your cover note or first call: "I run our monthly pipeline review with our sales director and rebuilt our pipeline and renewal dashboards. Forecasting sat with finance, so I have not owned the company forecast, and I have not worked on billing data." Every clause traces to your own words | see R6a, R7a | `[grounded]` your message | pending your approval |
| A3 | Tell the forecast story as sales-ops-to-RevOps growth. Tamsin Achebe's public career runs through sales operations, so it is a path they can place | see RR4 | `[grounded]` profile snippet; `[inferred]` fit of the story to the reader | pending your approval |
| A4 | Ask the verification questions of RR3, RR4, RR5 and RR6 in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Check Bristol, the two office days and the pay band against your own limits before investing effort | see R1, R2 | `[grounded]` JD terms | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: role reality's organization and contradictions rows, RR1 and RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Only the snippet was read. Moved: role reality's hiring-manager row, RR4 and A3 |

I'm happy to emit this as `tuesday-dossier.md` if you want a file to carry forward or reuse.

**Upgrade menu**

- Your CV → R3a, R3b and R4 can be checked against how they read, and any presentation edits can be proposed.
- A Salesforce certification record → R4 to `high`.
- A sanitized dashboard walkthrough → R8 to `high`.
- Your answer to G1 → R6b's bridge and its limit are stated precisely.
- Your answer to G4 → R7b resolves, and it may meet the posting's "or revenue data".
- Your location and pay floor → R1 and R2 settle, and the hard-gates line closes.
- A deeper research pass on Quillfield (funding, leadership changes, hiring patterns, public candidate reports; up to 5 more searches and 2 more fetches) → RR1, RR3 and RR5 firm up. Say the word and it runs.

**Questions**

G7 — Are Bristol, two office days a week and a £61,500–£67,000 base all workable for you?

G1 — In your monthly pipeline review, do the numbers you present feed the forecast finance builds, and which parts are yours?

G4 — Do your pipeline or renewal dashboards use revenue figures that finance supplies or signs off, and if so, which ones?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.