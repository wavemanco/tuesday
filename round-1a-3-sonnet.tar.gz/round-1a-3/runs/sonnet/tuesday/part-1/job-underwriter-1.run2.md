Searches were refused, so I'm running this from the JD and your background alone. Here's the assessment.

## Decision snapshot

**Should you apply? Yes. R1, R2, R3, R4 and R5, the must-haves you can evidence directly, all land `direct`, and R6 is the one must-have that is adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — direct: R8a · unclear: R7 (Mentor two junior analysts), R8b (Partner with clinicians)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 (`low`) — Looker governance points toward it, but ownership of metric definitions is unconfirmed; R8b — no clinician-facing evidence yet; R9 — a credible bridge, its limit named.

**Opportunity ledger.** The role is clearly scoped, with a named team of two juniors to mentor (RR4). The employer could not be checked from here (RR1), and both pay (RR2) and work arrangement (RR3) are unstated.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify on Harborlight's own careers page, see RR1; (2) pay and work arrangement prove acceptable to you, see RR2 and RR3; (3) the metrics-layer claim is framed only as far as you confirm you owned metric definitions, see R6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C | `[grounded]` JD header, not checked against any outside source |
| Product | A care-navigation app | `[grounded]` JD |
| Mandate | Own product analytics: metrics layer, A/B test design and analysis, self-serve Looker dashboards, roadmap partnership with PMs and clinicians | `[grounded]` JD |
| Team | Mentor two junior analysts, so a small analytics group already exists | `[grounded]` JD; `[inferred]` that the group exists from the two named mentees |
| Requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; healthcare data (HIPAA) a plus | `[grounded]` JD |
| Scope read | A senior individual contributor with light mentoring duties; the five areas are common to one senior analytics post | `[inferred]` from the JD's responsibility list; `[generic]` that this combination is a usual remit at this title |
| Market calibration | Not run, because search was refused. No pay band is offered, and none should be assumed for this employer | `[generic]` |
| Unknowns | Pay; location or remote policy; whether the metrics layer exists or must be built; how clinicians work with the analytics group; who the role reports to | `[grounded]` JD silence |
| Contradictions | None inside the JD; it was not compared with a careers page | `[grounded]` JD read alone |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics. It is specific, but self-reported and not yet inspectable, so `medium` with the caveat named | `[grounded]` your background as stated | none |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on Snowflake. The word "expert" is your own grading and nothing shows it yet; expect a live SQL exercise | `[grounded]` your background; `[generic]` that a SQL screen is the usual check for this title | A query or schema sample you can share would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You ran 30+ A/B tests a year and designed the pricing test behind an 11% retention lift. Specific and confirmed, with no artifact yet | `[grounded]` your background | A sanitized experiment readout would raise it to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch with 40+ governed dashboards. Specific, with no artifact yet | `[grounded]` your background | Dashboard screenshots or a LookML sample would raise it to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your background | A sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" suggests metric definitions were managed, but you did not say you owned them or how. Taking the lower band | `[inferred]` from "governed" in your background | See G1 |
| R7 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing on mentoring or managing | `[grounded]` silence in your background | See G2 |
| R8a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | You present monthly to the VP Product and ran the pricing test that led to the retention lift | `[grounded]` your background | none |
| R8b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background involves clinical or domain-expert stakeholders | `[grounded]` silence in your background | See G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR and CCPA consumer PII and built the consent-state model for the warehouse. Limit: no protected health information, no HIPAA covered-entity or business-associate setting, no clinical data standards | `[grounded]` your background; `[generic]` that HIPAA work differs from GDPR and CCPA work in what counts as protected data | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | Governed Looker dashboards, but no statement of who defined the metrics or where the definitions lived | R6 is the only adjacent must-have row, so confirming it makes your fit on must-haves complete | Writing LookML measures, keeping a metric dictionary, settling a disputed definition such as "active subscriber", deprecating a metric | A metric dictionary page, a LookML excerpt, a definitions doc | `[grounded]` your background silent on ownership; `[inferred]` that this is what the role's first responsibility tests |
| G2 | Mentoring (R7, important) | discovery | No mention of mentoring or managing | The role names two juniors, so some evidence helps even if informal | Onboarding an analyst, reviewing others' queries, running a SQL or experiment-design training, coaching a peer through a first test | A training doc, a review checklist, an onboarding plan | `[grounded]` silence; `[inferred]` that informal mentoring would count |
| G3 | Clinician partnership (R8b, important) | discovery | No domain-expert stakeholder work shown | The JD names clinicians as partners, which is new for you | Working with a nutritionist, culinary or operations specialist to turn their questions into analysis; translating a domain expert's hypothesis into a test | A brief or readout shared with a specialist team | `[grounded]` silence; `[generic]` that clinical partners usually need plain-language framing |
| G4 | Healthcare data bridge (R9, preferred) | transferability | GDPR and CCPA PII handling plus a consent-state model, with no health data | A preferred row; a credible bridge narrows the likeliest objection | Access controls, audit trails, de-identification or minimum-necessary handling you applied to personal data | A sanitized description of the consent-state model | `[inferred]` bridge from your privacy work; `[generic]` that health data brings extra handling rules |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small for an easy footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and say who I would be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | The JD lists no compensation | The posting may simply not publish pay | `[grounded]` JD silence | What is the budgeted salary range for this post? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | The JD names no location or remote policy | It may be remote, hybrid or on-site; this matters only if you hold a constraint | `[grounded]` JD silence | Where is this role based, and what is the remote or hybrid policy? | unresolved |
| RR4 | Scope and team stated | positive_signal | — | "mentor two junior analysts" | The responsibilities are concrete and a team already exists | `[grounded]` JD | How are the two analysts' work and priorities split today? | noted |

The status of RR1 caps the decision at `conditional_go` until the posting verifies. The way to clear it is a link to the live posting on Harborlight's own careers page, or the recruiter's email domain.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the experimentation program, the pricing test, and the Looker build, since these answer the JD's most specific asks | See R3, R4 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Show the consent-state model next to your GDPR and CCPA handling as a privacy-data bridge, and do not describe it as HIPAA or health-data experience | See R9 | `[grounded]` your background | resume_edits_pending_approval |
| E3 | Add a metrics-layer line only after you confirm what you owned | See R6, G1 | `[grounded]` G1 | resume_edits_pending_approval |
| A1 | Confirm the live posting on Harborlight's careers page, and read any pay band it lists, before spending application effort | See RR1, RR2 | `[grounded]` RR1 | pending your approval |
| A2 | In the first call, ask the verification questions of RR2, RR3 and RR4, plus how clinicians work with analytics | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app careers" was refused; it would have settled RR1, the contradictions row and the organization row |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary range Looker experimentation" was refused; it would have supplied the market calibration line and a pay band to set against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Search permission granted → targets 1 and 2 run, and RR1 and the market calibration move from open to checked.
- A link to the live posting on Harborlight's careers page → RR1 closes.
- A sanitized experiment readout, Looker screenshots or LookML sample, or a sample of the exec memo → R3, R4 and R5 each rise from `medium` to `high`.
- A metric dictionary or definitions page → R6 rises and G1 closes.
- A description of the consent-state model → R9's bridge firms up and E2 can be worded.
- The hiring manager's name → role reality's scope read and which story to lead with.
- Your pay floor and location needs → the hard-gates line can be checked against them.

I can write this up as a `tuesday-dossier.md` if you want a file to carry into later steps.

Questions:

C1 — Do you have a pay floor, a location or remote requirement, or work-authorization needs that this role would have to meet?

G1 — In your Looker work, who defined the metrics, such as "active subscriber" or "retained", and where did those definitions live (LookML, a metric dictionary, a doc)?

G2 — Have you onboarded, coached or reviewed the work of other analysts, formally or not, and what did that look like?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.