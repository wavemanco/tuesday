Searches were refused, so none of this is checked against the web. It rests on your JD and your background.

## Decision snapshot

**Yes, apply. You fit the core of the role: R1, R2, R3, R4 and R5, the must-haves, are each `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R8a · adjacent: R8b (clinician partnership) · unclear: R7 (metrics layer), R9 (mentor two junior analysts)
- `preferred`: adjacent: R6 (healthcare data, HIPAA)

R6: a credible bridge, its limit named; R9: nothing in your background speaks to it either way; R7: governed dashboards point toward it without establishing it.

**Opportunity ledger.** The role itself is clearly scoped (RR3), but the employer is not yet verified because my searches were refused (RR1). The pay is unstated (RR2), and it is unclear whether the mentoring is a reporting line (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Harborlight's own careers page (RR1); (2) the pay is confirmed against your floor (RR2); (3) the mentoring scope is clarified (R9, RR4); (4) the healthcare bridge is framed as adjacent, never as HIPAA experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C. I could not check this against an outside source. | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Seven responsibilities for one senior owner, with mentoring named but no line-management language | `[inferred]` from the JD's responsibility list and its silence on reporting lines |
| Market calibration | Not run. The sweep did not execute and the JD states no pay, so I have no band to compare against. | `[grounded]` JD silent on pay; search refused |
| Unknowns | Pay; location and remote policy; whether the juniors report to this role; how much clinician access the role has; the metrics-layer tooling | `[grounded]` JD silence |
| Contradictions | None found between the JD and your background | `[grounded]` JD against your stated background |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit company with about 2M subscribers. It is your own account with nothing inspectable yet, so `medium` is the ceiling. | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on a Snowflake warehouse. "Expert" is a level only a work sample or a technical screen shows. | `[grounded]` your stated background | A SQL sample or a screen would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD's "at scale" is undefined, and your claim is about test volume, not traffic. | `[grounded]` your stated background | A sanitized experiment write-up would raise it |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. | `[grounded]` your stated background | A dashboard screenshot would raise it |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads, and you present to the VP Product monthly. | `[grounded]` your stated background | A sanitized memo would raise it |
| R6 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: no health data, and no HIPAA-specific practice. | `[grounded]` your stated background; `[generic]` HIPAA differs from GDPR/CCPA in its rules and obligations | G3 |
| R7 | Define and maintain the metrics layer | important | unclear | low | discovery | "40+ governed dashboards" suggests shared metric definitions, but you never said you owned them. | `[inferred]` from "governed dashboards" | G1 |
| R8a | Partner with product managers on roadmap decisions | important | direct | medium | none | You present to the VP Product monthly, and the metrics memo goes to the execs. | `[grounded]` your stated background | none |
| R8b | Partner with clinicians | important | adjacent | low | transferability | Your partnering is with product and executive leaders, and you have no healthcare background. The bridge is partnering with domain experts, which you have not described. | `[inferred]` from your stakeholder work | G4 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Nothing you gave me mentions mentoring or managing analysts. | `[grounded]` background silent | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R7, important) | discovery | Governed dashboards, but no stated ownership of metric definitions | It decides whether you present as an owner or a user of the metrics layer | Writing or approving a metric definition doc; a certified-metric process in Looker; a dbt or LookML model you maintained | A metrics glossary, LookML excerpt or definition doc | `[grounded]` background silence; `[generic]` that "governed" often means defined centrally |
| G2 | Mentoring juniors (R9, important) | discovery | No mention of mentoring | The JD names it explicitly, and it is the likeliest question in a hiring-manager conversation | Onboarding a new analyst; reviewing others' queries or tests; informal coaching | None needed; a named example is enough | `[grounded]` background silence; `[generic]` that senior titles usually carry a mentoring expectation |
| G3 | HIPAA bridge (R6, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling | A preferred row, but the likeliest differentiator against healthcare-native candidates | The consent-state model's design; access controls or PII minimization you set up | A short description of the consent model | `[inferred]` bridge from the consent-state model; `[generic]` that HIPAA obligations differ from GDPR/CCPA |
| G4 | Clinician partnership (R8b, important) | transferability | PM and exec partnering only | Clinicians are named as partners in the JD | Working with domain experts such as ops, legal or customer support to turn data into decisions | An example of a decision shaped by non-product experts | `[inferred]` from your stakeholder work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The searches were refused, so this is unverified rather than doubtful. The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a live hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | No pay figure in the posting as pasted | The figure may sit below the market band for a senior role, or may be omitted from the copy you pasted. | `[inferred]` from the pasted JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Ownership and stakeholders clearly named | positive_signal | — | "Own product analytics for our care-navigation app" | The scope is defined: one product, named partners, concrete deliverables. | `[grounded]` JD | Who owns the metrics layer today, and what is it built on? | noted |
| RR4 | Mentoring scope unclear | unknown | — | "mentor two junior analysts" | Mentoring may be informal, or it may be a reporting line with performance duties. | `[inferred]` from the JD's wording | Do the two junior analysts report to this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your summary with the experimentation program, in your own words: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Do not add "at scale" or traffic figures you did not give me. | See R3 | `[grounded]` your stated background | pending your approval |
| E2 | Frame healthcare as adjacent: you built the consent-state model and handled GDPR/CCPA PII. Do not describe it as HIPAA or health-data experience. | See R6, G3 | `[grounded]` your stated background | pending your approval |
| E3 | Offer a sanitized monthly metrics memo as a writing sample | See R5 | `[grounded]` your stated background | pending your approval |
| A1 | Confirm the posting is live on Harborlight's own careers page before applying | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1 to RR4's verification questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers"; refused. It would have moved the organization row and RR1. |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker"; refused. It would have moved the market-calibration row and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I can offer a dossier of this assessment, `tuesday-dossier.md`, if you want one to carry forward.

## Upgrade menu

- Granting web search → targets 1 and 2 run, closing RR1 and calibrating RR2 against a market band.
- A sanitized experiment write-up, dashboard screenshot or metrics memo → R3, R4 or R5 toward `high`.
- Your answer on metrics-layer ownership (G1) → R7 resolves.
- Your answer on mentoring (G2) → R9 and RR4 resolve.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.

## Questions

G1 — Did you own or approve the metric definitions behind your Looker dashboards, for example a metrics glossary, certified metrics or a LookML model? What was yours?

G2 — Have you onboarded, coached or reviewed the work of other analysts? What did that look like?

Constraints — Do you have a pay floor, a location or remote requirement, or a start date that would rule this role in or out?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.