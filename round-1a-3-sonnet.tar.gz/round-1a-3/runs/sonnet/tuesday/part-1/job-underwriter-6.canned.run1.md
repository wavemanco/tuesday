Three searches and the posting read are done. I'm making one last check on whether the role appears on Quillfield's own careers page, then I'll give you the full assessment.
**Yes, go for it, as long as Bristol with two office days and the £61,500–£67,000 range work for you. Status: `conditional_go`.** The conditions are R1 and R2, which are hard gates and still open.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R5 · adjacent: R6 (Strong SQL and spreadsheet modelling), R7 (Experience owning a forecast), R8 (Run the quarterly forecast with the CFO) · unclear: R4 (At a B2B software company), R10 (Working with finance on revenue data) · absent: R9 (Experience on billing data)
- `important` — direct: R11

R7, R8 — a bridge through your monthly pipeline review, limit named; R9 — your own stated gap, no direct evidence; R1, R2 — waiting on your answer.

**Opportunity ledger.** Pay is stated and sits inside the market band (RR2), and the company has recent funding (RR5). Nothing in the posting reads as a red flag. The open items are team and reporting line (RR1), share-option terms (RR3), the posting not yet confirmed on Quillfield's own site (RR4), and no stated first-year outcomes (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol two days a week and the pay range work for you — R1, R2; (2) you state the billing gap (R9) plainly and answer the revenue-data question (R10); (3) the forecast bridge (R7, R8) is framed as adjacent, never as forecast ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` About Quillfield (quillfield.co.uk/about), read as a search result only |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches what the recruiter told you. The JD doesn't name a hiring manager | `[grounded]` search result for "Tamsin Achebe Quillfield" (profile snippet) |
| Scope read | One post carries CRM data, billing data, reporting and the forecast, and it sits under a Head of Revenue Operations if Tamsin is the manager | `[inferred]` from the JD's duty list and Tamsin's listed title |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Market calibration | UK B2B software revenue operations lead: median base £64,200, interquartile range £57,800–£70,400, n=438. The posting's midpoint is £64,250, inside that range. Not Bristol-specific, and I read only the snippet | `[generic]` Ledgerline 2026 pay guide; `[grounded]` JD range |
| Unknowns | Team size and reporting line; share-option terms; success measures; which billing system | — |
| Contradictions | None between the JD and the About page. The role itself is not yet seen on Quillfield's own site (RR4) | `[grounded]` About page against JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | Your location and office-day limits weren't given, so the gate is unsettled. Confidence grades your statement of a constraint, and none has been stated | `[grounded]` JD term; no candidate constraint given | G1 question |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. The range sits inside the pay guide's interquartile range | `[grounded]` JD figure; `[generic]` band | G1 question |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team. Specific, but no artifact inspected | `[grounded]` your background | none |
| R4 | The experience is at a B2B software company | must_have | unclear | low | discovery | You describe a B2B payments company. Whether its product is software sold to businesses isn't stated | `[grounded]` your wording | G5 |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, and Salesforce satisfies the "or". The certificate hasn't been inspected | `[grounded]` your background | The certification credential would raise this to `high` |
| R6 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show regular use. Strength and modelling work aren't described | `[grounded]` your background | G6 |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | Bridge: you run the monthly pipeline review with your sales director. Limit: finance owned the company forecast, so you haven't owned one | `[grounded]` your statements | G3 |
| R8 | Run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | Same bridge, wider limit: no work with a CFO or on a quarterly forecast cycle is stated | `[grounded]` your background, silent on both | G3 |
| R9 | Experience on billing data (JD: "working with finance on billing … data", "own our CRM and billing data") | must_have | absent | none | capability | You've said you've never worked on billing data, and nothing adjacent is established | `[grounded]` your statement | G4 closure path |
| R10 | Working with finance on revenue data | must_have | unclear | low | discovery | Renewal dashboards are revenue-related work. Whether they used finance's numbers or involved finance isn't stated | `[grounded]` your background silent on finance contact | G2 |
| R11 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. That finance used them isn't stated (see R10) | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay (R1, R2, hard_gate) | hard_gate | Neither your commute limits nor your pay floor have been given | A gate that fails would make this `no_go` whatever the fit | Not an experience question: your own limits on office days, travel and salary | Your own statement | `[grounded]` JD terms; no constraints supplied |
| G2 | Finance and revenue data (R10, must_have) | discovery | Renewal dashboards exist; finance contact is unstated | A must-have at `unclear`; the answer settles whether it is adjacent or absent | Reconciling renewal figures to finance's numbers; agreeing renewal or revenue definitions with finance; chasing a mismatch between CRM and finance reports | A dashboard screenshot showing finance-sourced fields, a definitions note, a reconciliation sheet | `[grounded]` background silent; `[inferred]` that resolving it moves a must-have |
| G3 | Forecast ownership (R7, R8, must_have) | transferability | Monthly pipeline review with your sales director; finance owned the forecast | Both rows are must-haves at `adjacent`. Limit: you haven't owned the forecast or worked with a CFO. Strengthener: showing how pipeline numbers reached finance's forecast | Pipeline numbers that fed finance's forecast; deciding which deals counted; a forecast-vs-actual review | A sanitized pipeline-review pack or the dashboards behind it | `[grounded]` your statements; `[generic]` that forecast ownership is a common interview probe for this title |
| G4 | Billing data (R9, must_have) | capability | Your own statement that you haven't worked on billing data | A must-have at `absent`, and the JD names billing data in its lead duty | Any invoice, ledger or payments-transaction export you've queried, even once. If none exists, the closure path is a self-built sample, labelled as a sample | A sanitized query or sheet | `[grounded]` your statement and JD wording |
| G5 | B2B software employer (R4, must_have) | discovery | "B2B payments company" doesn't say whether the product is software | A must-have at `unclear` | A platform or subscription product sold to business customers | The employer's product page | `[grounded]` your wording |
| G6 | SQL and modelling depth (R6, must_have) | discovery | Usage frequency stated; depth and modelling not | A must-have at `adjacent` | Queries joining CRM and finance tables; scenario or coverage models | A sanitized query or workbook | `[grounded]` your wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team, budget and reporting line unstated for a "Lead" role | unknown | — | "You will own our CRM and billing data, build the pipeline and renewal reporting … and run the quarterly revenue forecast with the CFO" | The role may carry all four duties alone, or may have support the posting doesn't show | `[inferred]` from the JD's duty list against its silence on team | Who does this role report to, and does it have direct reports or analyst support? | unresolved |
| RR2 | Pay stated, inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | A transparent range that sits within the role-family band | `[grounded]` JD figure; `[generic]` band | Where in the range would my background place me? | noted |
| RR3 | Share-option terms unstated | unknown | — | "plus share options" | The value depends on terms the posting doesn't give | `[inferred]` from the JD's silence | How many options, on what vesting schedule and at what strike price? | unresolved |
| RR4 | Posting not yet seen on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may sit at another address on their site, or the page I tried may not be the right one. The employer itself is established | `[grounded]` fetch of quillfield.co.uk/careers returned no page; that address was my guess | Is this role listed on Quillfield's own jobs page, and can you share the link? | unresolved |
| RR5 | Funded employer | positive_signal | — | "Series A (£11M) closed in April 2025" | Recent funding stands behind a 96-person company | `[grounded]` About Quillfield, read as a search result | How is the revenue operations team resourced for the year ahead? | noted |
| RR6 | No first-year outcomes stated | unknown | — | "run the quarterly revenue forecast with the CFO" | A forecast-owning role with no stated success measure may have its measures set later | `[inferred]` from the JD's silence | What would a good first year look like, and what would you want changed by then? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm that Bristol two days a week and the pay range suit you before investing time | see R1, R2 | `[grounded]` JD terms | pending your approval |
| A2 | Lead with your payments sales-operations background and the monthly pipeline review you run with your sales director. Tamsin's published earlier role was sales operations at a payments company | see R3, R7 | `[grounded]` your background; hiring-manager search result | pending your approval |
| A3 | On forecast, say: "Finance owned our company forecast; I run the monthly pipeline review with our sales director and rebuilt the pipeline and renewal dashboards." Each clause is yours | see R7, R8 | `[grounded]` your statements | pending your approval |
| A4 | On billing, say plainly that you haven't worked on billing data. Add what you do have only after G2 is answered | see R9, R10 | `[grounded]` your statement | pending your approval |
| A5 | Ask the verification questions of RR1, RR3, RR4 and RR6 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you go ahead, mock-interview can prepare you for the conversation with Tamsin.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about). The fetch of quillfield.co.uk/careers returned no page. Moved: role reality's organization row and RR4 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B SaaS Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: role reality's hiring-manager row and A2 |

I can write this up as a `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**
- Your commute and pay floor → R1 and R2 close, and the decision likely simplifies to `go` or `no_go`.
- An answer on finance contact → R10 resolves and R11 firms up.
- A sanitized pipeline-review pack or dashboard screenshots → R7, R8 and R11 can rise toward `high`.
- A sanitized SQL query or modelling workbook → R6 firms up.
- The Salesforce certification credential → R5 rises to `high`.
- The link to the role on Quillfield's own jobs page → RR4 closes.
- Answers on team, reporting line and option terms from the recruiter → RR1 and RR3 close.
- A deeper research pass on Quillfield (leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Does Bristol with two office days a week work for where you live, and is £61,500–£67,000 above your pay floor? Tell me if either is a hard no.

G2 — Have you worked with finance's revenue numbers in any form, such as reconciling your renewal dashboards to their figures or agreeing renewal definitions with them? What did you own, and what happened?

G3 — How did your monthly pipeline review relate to finance's forecast: did its numbers feed in, and who decided what went in?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.