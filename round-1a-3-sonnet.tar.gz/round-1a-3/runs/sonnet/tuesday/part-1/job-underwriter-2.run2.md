**No, you're not wasting your time. But this particular role is a stretch.** R1a (3+ years of titled PM experience) is `absent` against a `must_have`. R1b and R2a are `adjacent`, and R3 and R4a are `direct`. Status: `conditional_go`.

I couldn't run any research: both searches were refused, so nothing about Quartzline is verified.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b, R2a · unclear: R2b (Shipped API or platform products, internal-tool lead), R5 (Agile delivery) · absent: R1a (3+ years titled PM experience)
- `important` — adjacent: R6, R8, R9 · unclear: R4b (Launches with sales and support), R7 (Adoption metrics)

R1a — the titled-years gap, a fact not a wording problem; R1b, R2a — credible bridges, limits named; R2b, R5 — waiting on your answers.

**Opportunity ledger.** The scope is concrete (RR4), but the employer can't be established from here (RR1). The posting is silent on pay (RR3) and on whether PM-scope work without the title counts toward the 3+ years (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the live posting verify (RR1); (2) the title question is answered, or you apply openly as adjacent (R1a, RR2); (3) your answers on R2b and R5 don't contradict the bridge.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | A mid-sized platform PM remit: one product surface, two squads, external developers as users | `[generic]` pattern for platform PM roles at companies this size |
| Compensation | Not stated | `[grounded]` JD silent |
| Market calibration | Not established — no role-family sweep ran, so there is no band to set against the missing salary | `[grounded]` search unavailable |
| Unknowns | Salary; reporting line; who decides between sales asks and platform work; whether non-titled PM experience counts | — |
| Contradictions | None found, but nothing was checked against an outside source | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, in PM roles | must_have | absent | none | capability | You've said you have never held a PM title. This row grades the title only; the substance is in R1b. Employers may apply a titled-years line literally | `[grounded]` your statement; `[generic]` literal reading of title-years requirements | Apply openly as adjacent, or ask RR2 first. Alternatively target roles that accept the title gap |
| R1b | PM-type work without the title: requirements documents, working alongside PMs and engineers on custom builds | must_have | adjacent | medium | transferability | Resume states requirements documents and coordinating engineers, client engineers and PMs. Limit: the resume says feedback went "for product", so the prioritisation decisions appear to have been the PMs' | `[grounded]` CV; `[inferred]` the limit from the phrase "for product" | A sanitized requirements doc would raise to `high` |
| R2a | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the internal integration playbook. Limit: this is delivering on an API others built; the resume doesn't say you owned its roadmap or releases | `[grounded]` CV; `[inferred]` limit from CV silence | See G1 |
| R2b | Shipped a product or platform — an internal request-triage tool | must_have | unclear | low | discovery | Only an unconfirmed note from an earlier conversation: a triage tool that support agents adopted. Nothing on your ownership, scope or dates | `[inferred]` from agent memory (`memory_lead`), unconfirmed | G1 |
| R3 | Strong technical fluency: API docs, schemas | must_have | direct | medium | none | Resume cites Postman, SQL, OpenAPI specs and 30+ end-to-end integrations. Specific but self-reported, no artifact inspected; expect a probe on schema questions | `[grounded]` CV; `[generic]` that interviews for this role probe it | An annotated OpenAPI example or playbook excerpt would raise to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | Resume states coordination of your engineers, client engineers and PMs, and client workshops and UAT | `[grounded]` CV | none |
| R4b | Coordinating launches with sales and support | important | unclear | none | discovery | Resume describes go-lives with clients but is silent on sales and support | `[grounded]` CV silence | Not asked this turn (ranked below G1–G3) |
| R5 | Experience with agile delivery | must_have | unclear | none | discovery | Resume names no sprint, squad or backlog work | `[grounded]` CV silence | G2 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Resume states scoping workshops and quarterly roadmap-input sessions with clients. Limit: these fed your delivery work and product's inputs, not stated as discovery that decided what got built | `[grounded]` CV; `[inferred]` limit | Offer: a sanitized roadmap-input summary |
| R7 | Define and track adoption metrics | important | unclear | none | discovery | Resume is silent on any adoption measure | `[grounded]` CV silence | G3 |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and coordinating engineers on custom builds. Limit: coordination across teams, not stated as running a squad's backlog | `[grounded]` CV; `[inferred]` limit | See R1b and G2 |
| R9 | Own the roadmap for the API platform | important | adjacent | medium | transferability | You ran the roadmap-input sessions. Limit: input into someone's roadmap is not owning one | `[grounded]` CV; `[inferred]` limit | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped products (R2b, must_have) | discovery | A memory note about a triage tool; the resume doesn't mention it | It is the only possible evidence of building something others used, which is what R2a and R9 lack | Building or specifying a tool, workflow or API change that support, sales or clients adopted; deciding what went in it | A write-up, screenshots, usage numbers, a spec | `[inferred]` from memory lead; `[generic]` that this closes the biggest bridge gap |
| G2 | Agile delivery (R5, must_have) | discovery | No sprint or squad language on the resume | A must-have currently unevidenced | Running or joining sprint ceremonies with engineers on custom builds; owning a backlog or ticket queue for a client build | A board export (sanitized) or a sprint plan | `[grounded]` CV silence |
| G3 | Adoption metrics (R7, important) | discovery | No measures stated | The JD names adoption tracking explicitly | Tracking go-live rates, time-to-first-call, integration counts or support tickets per integration | A dashboard screenshot or a report | `[grounded]` CV silence; `[inferred]` the likely nearby work |
| G4 | Titled PM years (R1a, must_have) | capability | Fact, per you | Possible literal screen | Closure path, not a question: roles that accept title-less PM scope, an internal move, or open framing in the application | — | `[grounded]` your statement; `[generic]` screening practice |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | May be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; none ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Unknown whether PM-scope work without the title counts | unknown | — | "3+ years product management experience (must-have)" | The requirement may be applied by title or by substance | `[inferred]` from the JD's wording and its silence on equivalents | Would you consider PM-scope experience from an implementation or solutions role toward the 3+ years? | unresolved |
| RR3 | Compensation not stated | unknown | — | (no figure in the posting) | The figure may sit anywhere against the role-family band; no band was sourced here | `[grounded]` posting silent | What salary range is budgeted for this role? | unresolved |
| RR4 | Concrete scope and named outcomes | positive_signal | — | "two engineering squads; define and track adoption metrics" | Responsibilities, team and metrics are specified rather than vague | `[grounded]` JD | Who decides priorities when a sales request and a platform need conflict? | noted |

## Application plan

`resume_edits_pending_approval` covers E1 and E2; each other row carries its own status.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your "roadmap-input sessions collecting client feedback for product" and "wrote the internal integration playbook" bullets above routine duties, wording unchanged | See R1b, R6, R9 | `[grounded]` CV | pending your approval |
| E2 | Cover-note line built only from your sentences: you have not held a PM title, and the PM-shaped work you have done is the requirements documents, roadmap-input sessions and integration playbook | See R1a, RR2 | `[grounded]` your statement and CV | pending your approval |
| W1 | One-page write-up of the triage tool, only if you confirm it | See G1 | `[grounded]` pending confirmation | pending your approval |
| Q1 | Ask RR1–RR4 verbatim in the first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Seek an introduction or referral before applying cold | Title-years gaps are more often weighed by a person than a filter, in my read | `[generic]` role-family pattern | pending your approval |

If you decide to apply, resume-tailor can fit the resume to this posting.

## Evidence status

Verified: none yet. Unverified leads: the request-triage tool (agent memory), unconfirmed. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform Series B"; the call was refused. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary B2B SaaS Series B requirements transition from solutions engineer"; the call was refused. It would have set a market calibration against RR3 and tested whether title-less PM backgrounds are commonly accepted |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you'd like to carry it to other steps.

## Upgrade menu

- Search permission, so L1's three targets can run → RR1 can close and the missing salary gets a sourced band.
- The hiring manager's name → the scope read and which of your stories to lead with.
- An answer to G1 plus a write-up → R2b and possibly R9 move.
- A sanitized requirements doc or annotated OpenAPI example → R1b or R3 to `high`.
- A sprint or backlog artifact → R5.
- Your pay floor, location and notice constraints → hard-gate checks that are currently unknown.

**Questions**

G1 — Did you build the request-triage tool for support agents? What did you own, who used it, and what happened?

G2 — When you worked with engineers on custom builds, did you run sprints or own a backlog? What was your role?

G3 — How did you track whether integrations succeeded after go-live (rates, times, counts)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.