Short answer: yes, it looks worth applying. Below is the full assessment. I spent 1 search and 1 fetch confirming the posting is live and matches what you pasted.

## Decision snapshot

**Yes, worth applying to, on the conditions below. Status: `conditional_go`.** R3, R4, R5, R6, R7 and R8 are the `must_have` rows, and all six are `direct`. R1 and R2 are gates that your background doesn't settle.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 (`medium`) — a credible bridge from Snowflake, its limit named; R10, R11 — your background doesn't say either way, so they are questions, not weaknesses.

**Opportunity ledger.** The posting states its pay, and the band straddles the market median (RR2). Team size, reporting line and hiring manager are all unstated (RR3), and the scope may be wider than one domain (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based and authorized to work in the US, and the band clears your floor — R1, R2; (2) the scope and team shape check out in the loop — RR1, RR3; (3) BigQuery is framed honestly as adjacent to your Snowflake work, never as BigQuery experience — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company's own about page, matched in search. This is the company's own account, not independent confirmation. |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting |
| Stated requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` posting |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` posting |
| Scope read | Ingestion, modelling and contracts are all named as "build and run", which may be broader than one domain's pipelines | `[inferred]` from the mandate wording against the pay report's typical scope |
| Market calibration | The report gives a Series B–D Senior Data Engineer base median of $151,000, interquartile range $139,000–$163,500, typically 5–8 years, one domain's pipelines, no direct reports. The posting's floor of $148,000 sits inside that range below the median, and its top of $166,000 sits above the range's upper end. Equity is unquantified. This is the market pattern, never this employer's offer. | `[grounded]` posting and the pay report you supplied (n=2,310); `[generic]` for the market pattern |
| Unknowns | Hiring manager, team size, reporting line, equity terms, how many source systems feed the warehouse | `[grounded]` posting silent |
| Contradictions | None between the live careers page and your pasted text; the page reads "Accepting applications" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are or your authorization. A gate the inputs don't settle stays unclear. | `[grounded]` posting terms; your constraints not given | Question R1 below |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so the match is unknown. The band's position against the market is in RR2. | `[grounded]` posting; your floor not given | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is self-reported with no artifact yet. This is an experience requirement, not a gate. | `[grounded]` your background; 6 years sits inside the report's typical 5–8 for Senior | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use. There is no inspectable artifact yet, so expect a probe. | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. The count is yours and unverified. | `[grounded]` your background | Offer: a sanitized model lineage graph or repo excerpt would raise this to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | The requirement says "a cloud warehouse", and Snowflake is one. BigQuery specifically is R9. | `[grounded]` your background and posting wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in both the posting and your background. Your own scope of ownership isn't stated. | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. The posting doesn't name a tool. | `[grounded]` your background | Offer: a sanitized suite config or test catalogue would raise this to `high` |
| R9 | BigQuery (the posting's warehouse) | important | adjacent | medium | transferability | Your Snowflake warehouse and dbt layer carry over. The limit is that you have not used BigQuery. Pricing model, partitioning and clustering work differently from Snowflake. | `[grounded]` your background; `[generic]` that warehouses differ in cost and layout mechanics | See G1 and plan row W1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your pipelines exist, but your background doesn't say which source types fed them. | `[grounded]` background silent on sources | See G1 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is nearby work. Nothing says you defined agreements with downstream consumers. | `[inferred]` adjacency from the test suite | See G2 and question G2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R10, important) | discovery | Pipelines and Airflow are confirmed, but not the kind of sources behind them | It is the mandate's first named duty, so it will be probed | Pulling from a product database or event stream; syncing a CRM or billing system; a vendor or API connector you owned | A sanitized DAG graph or source inventory | `[grounded]` background silent on sources; `[generic]` that interviews probe the first-named duty |
| G2 | Data contracts for analysts (R11, important) | discovery | A test suite is confirmed. An agreement with the teams consuming the data is not. | It is a named responsibility, and it separates a tests owner from a contracts owner | Agreeing a schema or freshness expectation with analysts; blocking a deploy on a contract break; documenting model owners | A contract doc, a model YAML with tests and owners, or a changelog | `[grounded]` background silent; `[generic]` that this distinction gets probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope possibly wider than one domain | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The role may span ingestion, modelling and contracts for the whole platform, against a report norm of one domain's pipelines | `[inferred]` from the posting's three named duties against the report's typical scope | Which of ingestion, modelling and contracts does this role own, and which sit with other people? | unresolved |
| RR2 | Pay stated, straddling the market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is disclosed and competitive. The floor sits just below the report median and the top is above its upper quartile. Equity is unquantified. | `[grounded]` posting and pay report; `[generic]` for the market reading | Where in the band would my experience place me, and what is the equity grant and vesting? | noted |
| RR3 | Team shape and hiring manager unstated | unknown | — | Posting names no hiring manager and no team | The posting may omit them because it is a template, or the data team may be very small | `[inferred]` from the posting's silence | Who would I report to, and who else works on the data platform? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the dbt project at the top of the resume, stated as you gave it: dbt project on Snowflake, about 180 models | R5 | `[grounded]` your background | pending your approval |
| E2 | Place the Great Expectations suite you set up directly beside it | R8 | `[grounded]` your background | pending your approval |
| A1 | Say in one line that your warehouse experience is Snowflake with dbt and that you haven't used BigQuery. Don't claim BigQuery. | R9 | `[grounded]` your background | pending your approval |
| W1 | Optional: a small public dbt-on-BigQuery project to narrow the R9 limit | R9 | `[inferred]` from the BigQuery gap | pending your approval |
| Q1 | Ask the RR1, RR2 and RR3 questions verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

`resume_edits_pending_approval`: E1 and E2. Nothing here is final until you approve it, and the approval covers the advice rows as well as the edits.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C $52M tutoring Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live and matches your paste, and the about page matches the stage and size. This moved role reality's organization and contradictions rows, and no failed-attribution entry was needed. |
| 2. Role-family sweep | skipped | The pay report you supplied fixes the market calibration and the pay-mismatch check. |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form. |

If you want me to draft the resume edits or the application, I'd do that next, once R1 and R2 are answered. Your approval is needed before anything goes into a resume or message.

## Upgrade menu

- Your location, authorization and pay floor → R1 and R2 close, and the decision likely moves to `go` or `no_go`.
- A sanitized dbt lineage graph or Great Expectations suite config → R5 and R8 move to `high`.
- An answer on contracts with analysts, or on your ingestion sources → R11 and R10 close.
- A hiring manager's name → role reality's scope read, and which story the plan leads with.
- Deeper diligence on Pellucid (independent confirmation of the funding, leadership changes, employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

R1 — Are you based in the US and authorized to work there, and would you work remote or in Denver?

R2 — What base salary floor would you need for this to be worth taking?

G2 — Have you ever agreed schema, freshness or quality expectations with the analysts who use your models, and did a contract break ever block a deploy?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.