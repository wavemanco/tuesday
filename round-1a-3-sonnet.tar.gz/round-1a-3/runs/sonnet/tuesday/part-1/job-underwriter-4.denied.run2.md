Search was refused here, so this runs on the JD and your summary alone.

## Decision snapshot

**Yes, worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (Monitor rating models), R9 (Pet-insurance domain)
- `preferred`: direct: R10

R9 is a credible bridge with its limit named; R6 (`low`) turns on "maintained" versus "monitored", which only you can settle.

**Opportunity ledger.** The posting is concrete about outputs and names a director-level hiring manager (RR4). The salary (RR1), whether the role has reports (RR2) and the employer itself (RR3) are all unverified.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed, meaning you are UK-based with the right to work there; (2) the employer and the live posting verified, per RR3; (3) the salary set against your own floor, per RR1.

Your two gaps are not blockers. Pet insurance is R9, an adjacent row. Never having managed anyone is not in the JD as a requirement, so it has no row of its own. It surfaces only as a question about the role (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; not verified beyond the posting | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | One product line, owned end to end, with a director as the manager | `[inferred]` from "own pricing analytics for our pet-insurance product" and the named reporting line |
| Compensation | Not stated | `[grounded]` JD silent |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Salary; team size; whether the role has reports; how pricing sits against the "product" audience | `[grounded]` JD silent on each |
| Contradictions | None inside the JD; not cross-checked against a careers page | `[grounded]` JD read; no outside page read |

No market calibration line: the role-family sweep did not run, and a salary band from memory would not be a source.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | A UK employer suggests you are UK-based, but your residence and right to work are not stated. A gate the inputs do not settle stays a gate. | `[grounded]` JD term; `[inferred]` UK location from your employer | Question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics, the last two as senior analyst; specific, but self-reported with nothing inspected | `[grounded]` your summary | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use is stated. "Strong" is a level your summary does not evidence beyond frequency. | `[grounded]` your summary | offer: a sanitized query or notebook would raise this |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book; specific, no artifact yet | `[grounded]` your summary | offer: a sanitized model spec or factor-selection note would raise this |
| R5 | Build rating models | must_have | direct | medium | none | Rests on the same stated claim as R4, so it carries no extra strength | `[grounded]` your summary | none |
| R6 | Monitor rating models | important | adjacent | low | discovery | "Maintained" is not the same as "monitored"; I take the reading that claims less until you say what the upkeep involved | `[grounded]` "built and maintained"; `[inferred]` that monitoring is part of upkeep | Question G2 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | "Ran 14 price tests with the underwriting team" is a stated claim. Whether you designed them, and who read them out, is not stated. | `[grounded]` your summary | Question G3 |
| R8 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which meets the "underwriting" half of the requirement as written. Evidence for the "product" audience in the mandate is absent. | `[grounded]` your summary | none |
| R9 | Pet-insurance pricing context (from "our pet-insurance product") | important | adjacent | medium | transferability | The GLM and price-test method carries over from motor. Limit: you have not priced pet risks. Pet rating usually turns on animal-specific factors that motor does not use. | `[inferred]` adjacency from your motor work; `[generic]` that pet rating factors differ from motor | Bridge case, G4 |
| R10 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your summary | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based with right to work (R1, hard_gate) | hard_gate | The JD says fully remote, UK; your summary shows a UK employer but not where you live or your right to work | An unsettled gate caps the decision at `conditional_go` | Not experience: a term you meet or do not | Your own statement is enough | `[grounded]` JD term, your summary silent |
| G2 | Monitoring rating models (R6, important) | discovery | "Maintained" does not say whether you tracked live performance | The JD lists monitoring beside building; a direct answer lifts the row | Tracking actual against expected by segment; refreshing the model when performance drifted; a recurring performance report to underwriting | A sanitized monitoring report or a model-refresh note | `[grounded]` summary wording; `[generic]` that monitoring is part of owning a rating model |
| G3 | Designing and reading price tests (R7, must_have) | discovery | You ran 14 tests; who set up the test and control cells, and who wrote the readout, is open | The JD names designing and reading as the job | Choosing test and control groups; setting duration or sample size; writing the result and recommendation for underwriting | A sanitized test readout or design note | `[grounded]` summary says "ran" |
| G4 | Pet-insurance context (R9, important) | transferability | GLMs and price tests on a motor book; no pet rating work | Likely the first objection raised, though R9 sits below the `must_have` tier | Any work on frequency or severity, claims inflation, or a new-product launch pricing | An optional short note on how you would approach pet rating factors | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary not stated | unknown | — | no figure in the posting | It may sit below your floor, or the employer may simply not publish it | `[inferred]` from the posting's silence | What salary is budgeted for this role? | unresolved |
| RR2 | Team shape and reports unstated | unknown | — | "Own pricing analytics" | The role may be a sole analyst under the director, or may carry reports | `[inferred]` from "own" against the JD's silence on team | Is this an individual-contributor role, and who else sits in pricing? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Checks did not run, so this is unresolved rather than found. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR4 | Specific scope and a named director-level manager | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate is defined and has a clear reporting line | `[grounded]` JD | What does success look like in the first year? | noted |

## Application plan

Everything below is proposed, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| V1 | Check the posting on Brindlemoor's own careers page, and the company's presence, before investing effort | RR3 | `[grounded]` RR3 | pending your approval |
| E1 | Lead with the GLM rating model for the young-driver book, the 14 price tests and the quarterly review, in the words you gave me | R4, R7, R8 | `[grounded]` your summary | pending your approval |
| E2 | On pet insurance, say what the evidence holds: the same GLM and price-test method on a motor book, with no pet pricing yet | R9 | `[grounded]` R9 row | pending your approval |
| E3 | On management, say plainly you have not managed anyone if the role carries reports | RR2 | `[grounded]` your statement | pending your approval |
| Q1 | Ask RR1, RR2 and RR4's questions verbatim with Odile Varga | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Brindlemoor pet insurance insurtech", "Brindlemoor careers Senior Pricing Analyst") were refused. Would have moved role reality's organization row, the contradictions row and RR3. |
| 2. Role-family sweep | unavailable | One search ("senior pricing analyst pet insurance UK salary remote") was refused. Would have moved the market calibration line and RR1. |
| 3. Hiring manager's public footprint | unavailable | A name was given and one search ("Odile Varga Director of Pricing") was refused. Would have moved the scope read and which story the plan leads with. |

I'll offer to dossier this if you want it. Say the word and I'll write `tuesday-dossier.md`.

## Upgrade menu

- Permission to run the three searches → RR3 may close; role reality gains a salary band for RR1 and a scope read from Odile Varga's published work.
- Your location, right to work and pay floor → R1 settles and every gate check runs against your terms.
- A sanitized monitoring report → R6 can rise.
- A sanitized test readout → R7 can rise.
- A sanitized query, notebook or model spec → R3 and R4 can rise to `high`.

## Questions

**G1.** Are you UK-based with the right to work in the UK? Also, what is the lowest salary you would accept?

**G3.** On the 14 price tests, did you design them (test and control cells, sample size or duration) or run ones someone else set up, and who wrote the readout for underwriting?

**G2.** Did "maintained" include tracking the model's live performance against expected, and did that ever trigger a refresh?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.