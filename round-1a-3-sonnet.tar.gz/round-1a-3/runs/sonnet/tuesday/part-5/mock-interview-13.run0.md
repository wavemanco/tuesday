Web searches were denied, so I'll build the pack from your advert, notes and Hannah's message, and label company-specific parts as unresearched. I'm writing the pack file now.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`, 18 questions in all. It's built for Hannah's four topics (pay, notice, hybrid, reason for moving) plus the usual screening questions.

- **Assumption:** the pack rests on the advert, her message and your notes. You didn't give a CV, so every fit row rests on your notes alone.
- **Research:** the four web searches I tried were denied, so the pack holds nothing about Quillmoor beyond the advert. "What drew you to Quillmoor" is built on the advert alone.
- **Your four logistics answers:** pay, hybrid and the reason for moving are filled with your own words, quoted and not embellished. Notice is a blank, because you haven't told me yours.
- **Highest-ROI prep:** B2, "You schedule deliveries. This role coordinates production schedules with planning and QA. What part of that have you done?" That's the advert's headline duty, and your evidence is about deliveries for three depots. Rehearse that one until it's boring. The SAP gap is a smaller risk, since the advert calls it "a plus".

Say the word and I'll play Hannah as the Skeptic on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your actual notice period? It fills A3 with your own words.
Can you paste your CV? Without it, the rows on Excel, supplier tracking and reporting stay as answer slots rather than real answers. If you'd rather not, the pack works as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday at 2pm, a 30-minute phone call. Hannah Lowther, Talent Partner, will ring the mobile number on your application.

**Her stated agenda, from her message:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for you now.

| Tag | Name | What it is scoring |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether your CV and notes survive scrutiny; what was actually you |
| JD | Role / JD-driven | The advert's stated duties and terms, gaps included |
| CO | Company and strategy knowledge | Homework on the company |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

Requirements are quoted from the advert, or from Hannah's message where the row says so. Evidence is your own words from your message. You gave no CV, so every row rests on your notes alone.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's line makes a probe on planning and QA likely. If any of your scheduling involved a planning function or quality checks, say which and what you did, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots |
| F2 | "track supplier deliveries" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [inferred] | discovery | The sentence shows scheduling deliveries and chasing suppliers, and does not show whether you track what suppliers have delivered. Answer slot: if you kept track of supplier deliveries, say how, in your own words; if you did not, or it was not yours, say so plainly |
| F3 | "chase late orders" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect it to be probed: keep "about a third over a year" at that scope, as C1 and C2 rehearse |
| F5 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Silence, not a stated absence. Answer slot: the advert's reporting line makes a probe likely. If you have reported on deliveries or dispatch, say what and how often, in your own words; if not, say so plainly |
| F6 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel. Answer slot: say which tool it was and what you did in it, in your own words; if it was not Excel, say so plainly and stay with the spreadsheet you rebuilt |
| F7 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: four years, logistics coordinator, a building-supplies wholesaler |
| F8 | "ERP experience (SAP or similar) a plus" — JD, the SAP part | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. Never a claim to SAP or other ERP work |
| F9 | "ERP experience (SAP or similar) a plus" — JD, the "or similar" part | "Never used SAP — we run our own in-house stock system" — your message | low | [inferred] | discovery | The sentence says the system exists, not what it does or what you did in it. Answer slot: the advert's "or similar" makes a probe on that system likely. If you worked with orders, stock records or reports in it, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly |
| F10 | "£38,000–£44,000" — JD | "I'm hoping for £42,000" — your message | high | [grounded] | none | A pay gate the material shows met. Say it as you worded it: "I'm hoping for £42,000". No floor, range or flexibility is put in your mouth |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | A location and schedule gate the material shows met. Say it as you worded it, including the limit as a preference, "I wouldn't want more than three", and nothing added |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it |
| F13 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. Your reason is stated and specific, and she can check an office closure. Say it in those terms and add no reason the sentence does not give |

## Persona table

Her stated agenda is the loop for this session: one 30-minute call with her. The weights rest on that agenda and on the recruiter-screen prior, not on any researched fact about Quillmoor.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Friendly, structured around her four listed topics, plus "tell me about you" | High: her message names pay, notice, hybrid pattern and reason for moving, so these are near-certain | Have each logistics answer ready as your own short sentence; treat the chatty questions as scored |
| B. Skeptic | Quiet knockout-checking of the gaps: production scheduling, the SAP point, wholesaler to manufacturer | Medium: recruiters check the advert's requirements against the CV before passing someone on, and F1, F8 and F9 are the thin rows | Rehearse the single likeliest objection (B2) until it is boring; hold what your sentences carry, concede the rest plainly |
| C. Data-Driven Prober | Asks how the one-third figure was counted | Low-medium: unlikely at depth in 30 minutes, but F4 carries a figure and figures draw this question | Say the figure at its scope, say plainly what you do not know about how it was counted |
| D. Case / Strategist | A short live scenario about a late supplier or a report | Low: nothing in her message signals a case, and recruiters rarely run one; included so the style is not new | Clarify, then structure, then answer; think aloud |
| E. Pressure | Time-boxed or devil's-advocate challenges | Low: nothing in her message signals it; included so the style is not new | Pause, restate, hold through two follow-ups, concede specifically |

Peer and Values personas are left out: her message describes a recruiter call.

## Question banks

Depth follows weight. Persona A runs to six because her four listed topics each have a row.

### A. Conversational / Rapport (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background and what you do day to day." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped on F7, F3 and F4: the four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers when orders slip, and the stock-count spreadsheet you rebuilt with discrepancies falling about a third over a year. Those are the beats the quotes state; tell them in your own words in about 90 seconds and add nothing these sentences do not carry | Recruiters open with this, and F7 is the years requirement. EXP because it tests what was actually yours |
| A2 | "Where are you on salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot filled by your own words: "I'm hoping for £42,000", at that scope and nothing added. If she asks about your current pay, you can decline to give it and return to the figure you gave. If she follows up on the figure, your own words are the same sentence | F10 is a gate row shown met, and she listed pay first, so expect it early. JD because it concerns the listed job's terms |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period in your own words. If you are not sure of it, say you will confirm it rather than guess | F12 is a gate row on which your material is silent, and her message names it. JD because it concerns the listed job's terms |
| A4 | "How would the hybrid pattern work for you, with two days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot filled by your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three", at that scope. If she follows up on this topic, your own words are that same sentence, quoted, with nothing added | F11 is a gate row shown met, and her message names it. JD because the advert sets the pattern |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Story-mapped on F13: the office closing next year, the only offer being a relocation to Reading, and that you don't want it. Those are the beats the quote states; say them plainly in your own words and say nothing about your employer that the sentence does not say. If she follows up, your own words are that sentence | Her message names it, and F13 is the stated reason. EXP because it tests whether the reason holds together |
| A6 | "What drew you to Quillmoor and this role?" | CO | [grounded] | Open prompt, scaffold: the advert describes "a diagnostic-test manufacturer, about 400 staff" and the duties "Coordinate production schedules between planning, the warehouse and QA" and "report weekly on on-time dispatch". Pick the one thing in the advert that genuinely interests you and say why, in your own words; if nothing in particular does, say so plainly, then say what you are looking for in a next role. Searches were not run, so this pack holds nothing about Quillmoor beyond the advert | Recruiters ask this to test interest and consistency with A5. CO because it tests homework, and the homework available here is the advert alone |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert mentions ERP experience, SAP or similar. Where do you stand on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say it at its scope: "I've never used SAP", then the second half of your own sentence, that your company runs its own in-house stock system. Answer slot: the advert's "or similar" makes a probe on that system likely; if you worked with orders, stock records or reports in it, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly. Then a plan, never a past: how you would learn a new system in your first weeks | F8 and F9 are the ERP rows, and the advert calls it "a plus", so this is a likely check rather than a knockout. JD because it scores a stated requirement |
| B2 | "You schedule deliveries. This role coordinates production schedules with planning and QA. What part of that have you done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling involved a planning function or quality checks, say which and what you did, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots; the honest branch is a limit, not a confession. Hold through two follow-ups by returning to the depots, never by adding to them. Name the limit before she does: your material says deliveries, not production schedules. Then a plan, said as a plan: on day one you would ask what planning holds, what QA needs and when, and what the warehouse can receive | F1 is where the advert's headline duty presses hardest, so this objection arrives in some form. JD because it scores the stated requirement, with Skeptic delivery |
| B3 | "You come from a wholesaler and this is a manufacturer. How do you see the difference?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Say your starting point in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler. Then a plan, never a past: what you would want to learn first in a manufacturing setting. Open branch: if you have not worked in manufacturing, say so plainly and stay with the coordination work your sentence states | F7 is the sector fact, and the advert names the employer as a manufacturer. JD because it scores fit to the listed job |
| B4 | "How confident are you in Excel, and what have you built with it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The quote says spreadsheet, not Excel. Answer slot: the advert asks for confidence with Excel, so expect a probe; say which tool the stock-count spreadsheet was in and what you did in it, in your own words; if it was not Excel, or the work was not yours, say so plainly and stay with the spreadsheet you rebuilt | F6 is the Excel row and its evidence is thin. JD because it scores a stated requirement |
| B5 | "Tell me about reporting you've done on delivery or dispatch performance." | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Open prompt, scaffold: pick a report you produced on deliveries or dispatch and say what it measured, how often it went out and who read it, all in your own words. If no such report comes to mind, say so plainly, then give the nearest thing your material does carry, the stock-count spreadsheet you rebuilt, or say how you would build one | F5 has no evidence given, and the advert names weekly on-time dispatch reporting. JD because it scores a stated duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that one-third drop in discrepancies was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the figure at its scope: about a third over a year. Then four slots, each in your own words: how the discrepancies were counted, what the figure is most sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name your weakest assumption before she does | F4 is the headline figure, and figures draw this question. EXP because it tests attribution and how the figure was counted |
| C2 | "Walk me through what rebuilding the stock-count spreadsheet involved." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped on F4: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot: the advert asks you to keep stock records accurate, so expect a probe on what changed in how counts were recorded; if you changed that, say what, in your own words; if you did not, or it was not yours, say so plainly and stay with the rebuild | F4 is the evidence for the stock-records requirement. EXP because it tests what you actually did |
| C3 | "Tell me about a time a supplier order slipped and you chased it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Open prompt, scaffold: choose one occasion and say what slipped, who you chased, and what happened, in your own words, using only what happened. If no single occasion comes to mind, say so plainly, then give the nearest thing your material does carry: you chase suppliers when orders slip, said as the routine it is | The advert names chasing late orders and tracking supplier deliveries, F3 and F2. EXP because it tests whether the sentence has an instance behind it |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier tells you on Monday that a delivery QA needs for Thursday's production run will be three days late. What do you do first?" | CASE | [generic] | Structure it: what you would ask first, which run and what stock is on hand; who needs to know, planning, the warehouse and QA; what options you would put to them; how you would record it and follow up. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's scheduling and late-order lines, asked as a decision. CASE; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "How would you structure a weekly report on on-time dispatch?" | CASE | [generic] | Say the definition aloud first: what counts as on time, measured against what. Then the data you would need, who reads it, and what you would show first. If you do not know how the site measures it today, say so and ask. The question needs no claim about your past, so the guidance makes none | The advert's reporting line, asked as a design problem. CASE; `[generic]` because it is a pattern, not a fact about this employer |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, when other applicants have used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Pause, restate the question, then hold what the quotes carry: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip. Hold it through two follow-ups. Concede specifically and plainly: "I've never used SAP", with a plan to learn it, said as a plan. Do not claim an ERP background | F8 is the stated gap a pressure question presses on. JD because it scores a stated requirement; hold-then-concede is the type's bar |
| E2 | "That one-third drop in discrepancies: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the position the quote carries: "I rebuilt our stock-count spreadsheet." Answer slot: say which part of the fall was yours, in your own words; if you do not know what else contributed, say so plainly. Hold through two follow-ups, then concede exactly what you do not know, never the rebuild itself | F4 is where attribution gets tested. EXP because it tests what was actually yours; hold-then-concede is the pressure bar |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, D1 |
| track supplier deliveries | C3 |
| chase late orders | C3, A1 |
| keep stock records accurate | C1, C2, A1 |
| report weekly on on-time dispatch | B5, D2 |
| 2+ years in operations or logistics coordination | A1, B3 |
| confident with Excel | B4 |
| ERP experience (SAP or similar) a plus | B1, E1 |
| £38,000–£44,000, and your salary expectations | A2 |
| Hybrid: two days a week at Avonmouth | A4 |
| your notice period | A3 |
| what's prompting a move | A5 |

## Reverse questions

Hannah said she will cover the team and next steps herself, so keep these for the end and skip any she has already answered. There is no interviewer profile, so none ties to her career path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of planning, the warehouse and QA does this role work with most day to day?" | It shows you read the advert's coordination line and want to know where the work sits |
| R2 | "What system does the site run for stock and orders, and how is training handled for someone new to it?" | It addresses the ERP line directly without claiming anything, and invites her to say how much weight the "plus" carries |
| R3 | "How is on-time dispatch measured today, and who reads the weekly report?" | It shows you have thought about what you would own |
| R4 | "What would a good first six months look like for this role?" | It turns the call from screening into a conversation about doing the job |
| R5 | "What are the next steps after this call, and who would I meet?" | It gets the process in hand and shows you are moving forward |
| R6 | "What has changed in the team or the site recently that shaped this vacancy?" | It invites her to tell you why the role exists, which the advert does not say |

## Prohibited claims

Each entry is a claim this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says deliveries for three depots, not production schedules. B2's slot stays inside the depots |
| Has SAP experience | Negative you stated, F8 | The plain acknowledgment: "I've never used SAP." No slot |
| Has ERP experience | Inflated form of F9 | F9's quote at its own scope, "we run our own in-house stock system". The limit is the pack's observation: your material does not say what that system does. B1's slot asks only what you did in it |
| Cut stock discrepancies by a third | Inflated form of F4 | F4's quote at its own scope: "about a third over a year", with "I rebuilt" and the fall as your sentence states them. C1 and E2 ask only how it was counted and which part was yours |

## Sources

Provided documents: the Quillmoor advert as you pasted it, Hannah Lowther's LinkedIn message, and your notes about yourself. No CV and no `tuesday-dossier.md` were provided.

Searches sent, by query:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news" — refused
- "Hannah Lowther Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have grounded A6 and any value-themed question; no values-style round is detected anyway, so there is no cheat sheet |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | The search was refused. It would have shown the later rounds; this session's loop comes from Hannah's own message, so the persona weights are unaffected |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The search was refused. A6 stays grounded in the advert alone, and no CO question rests on company strategy |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. The interviewer read is absent, and the reverse questions stay role-generic |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → F2, F5, F6 and F9, which are thin or silent now, may gain quotes, and every row would then rest on more than your notes
- Your actual notice period → A3 becomes your own words rather than an instruction, and F12 becomes a stated fact
- Permission to run web searches → the company's values, process and strategy replace the unresearched rows in Sources, A6 becomes grounded, and the interviewer read can be built from public footprint only; a deeper pass of up to 6 further searches and 2 further fetches, taking several more minutes, can follow on your yes
- What your in-house stock system does and what you did in it → F9 and B1 upgrade from an answer slot to a story map
- Any reporting you have done on deliveries → F5 and B5 upgrade from an answer slot to a story map
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and claims to avoid would sharpen the prohibited list; nothing here needs it
