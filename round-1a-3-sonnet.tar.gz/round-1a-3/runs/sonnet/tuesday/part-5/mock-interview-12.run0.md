Running a few quick searches on the company for the prep pack, then I'll build it.
Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and it says "a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor". Requests for a fee, for ID and bank details before any offer, and to pass money on from a cheque are a known scam pattern, and these requests are very likely a scam. Hold all three (paying, depositing the cheque, sending your passport photo or bank details) until you've checked the invite with the employer, using contact details you find on its own website or careers page, not the email, number or replies in the invite. The invite may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-5/rooms/case-12-denied-71eb639d/brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md`. It has 20 questions across six interview styles, a fit table built from your own words, and reverse questions. I built it for a hiring-manager-style round, since I don't know whether the office manager would be your boss or a peer. Company research wasn't possible because the search permission was declined, so nothing in it is about the company itself. It rests on the invite's description of one 30-minute video call.

The highest-ROI prep is B1, "Which part of this job would be your weakest on day one?" The ad's travel, supplier-invoice and Excel lines go beyond what you've told me. Your honest, specific answer, with a plan for your first weeks, will do more than any polished one.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager likely to be your future manager or a peer on the team? The answer reweights every bank.
Can you paste the full text of the ad? Your summary gave me four task lines, and the exact wording would sharpen the fit table.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager (name not given). Format: a 30-minute video call, per the invite. Relationship assumed: hiring-manager style, because the material does not say whether the office manager would be your manager or a peer.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your stated claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

Requirements are the four task lines you gave me from the ad, plus the remote working in the role title. Full ad text would let me quote them exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message, the ad as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your sentence already reaches the diary work in other terms, so lead with it as written: "I ran the appointment book for four physios". Nothing is inspected behind it, so expect a probe on what running it covered; the bridge adds no practice and no figure |
| F2 | "booking travel" — your message, the ad as you described it | none given | none | [grounded] | discovery | Your material is silent on travel. Answer slot: the ad's travel line makes a probe likely. If you have arranged travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and stay with the appointment book you ran |
| F3 | "preparing documents in Word and Excel" — your message, the ad as you described it (Word part) | "I'm good with Word" — your message | medium | [grounded] | discovery | Say it as you wrote it: "I'm good with Word". Your material gives the skill, not which documents. Answer slot: if you have prepared documents in Word, say which kinds, in your own words; if you have used it lightly, or not for documents, say so plainly and stay with the skill as you rated it |
| F4 | "preparing documents in Word and Excel" — your message, the ad as you described it (Excel part) | "okay with Excel" — your message | low | [inferred] | discovery | Derived from your own hedged rating, so the bridge keeps your word: "okay with Excel". Answer slot: the ad names Excel beside Word, so expect a probe. If you have used Excel for anything, say what, in your own words; if you have not, or only lightly, say so plainly |
| F5 | "processing supplier invoices" — your message, the ad as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not which side of an invoice you were on, and not what was done with them beyond chasing; the words stay at "chased unpaid invoices". Answer slot: the ad's invoice line makes a probe likely. If you did anything with invoices beyond chasing them, say what, in your own words; if you did not, or it was not yours, say so plainly and stay with the chasing |
| F6 | Remote working — the invite's role title, "Remote Administrative Assistant" | none given | none | [grounded] | discovery | Your material is silent on how you would work remotely. The interviewer's logistics question is C3, answered in your own words |

## Persona table

Loop: the invite's own words establish one session, a 30-minute video call with the office manager, so the weights rest on that and on the assumed hiring-manager relationship, not on a documented process at this company.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist (highest) | Small live problems: a clash of requests, a booking, a mismatched invoice, a spreadsheet request | Highest: a hiring-manager prior, and the ad's four task lines can each be posed as a live problem in a 30-minute call | Clarify first, then structure aloud, then answer; ask what you need to know before acting |
| B. Skeptic (highest) | Quiet probing of the distance between your material and the ad | Highest: F2 has no evidence, F4 is hedged by your own word, and F5 is a different kind of work from supplier invoices as written | Rehearse B1 until it is boring; hold what your sentences carry, concede the rest plainly |
| C. Conversational | Friendly opener, "walk me through the journey", logistics | Medium: a short video call usually opens this way, and the questions are still scored | A 90-second arc built only from your quoted sentences; answer logistics in your own words |
| D. Data-Driven Prober | Presses on your own words: what "okay" means, what "four" counted | Medium-low: there is one figure, "four physios", and one hedged rating to press on | Know what you can and cannot say about each, and say plainly when you do not know |
| E. Peer Evaluator | Where your job ends and others' begins, how priorities are set | Low-medium: an office manager works alongside the role even if they also manage it | Reciprocity: what you would take off their plate; seam principles, not a claimed seam |
| F. Pressure | A time-boxed challenge to your fit | Low: nothing in the invite suggests a stress style | Pause, restate, hold through two follow-ups, then concede specifically |
| Values/Behavioral | Stories mapped to published values | Not banked: no values source was read, and the invite names no values round | Not applicable until a values source is in hand |

## Question banks

Highest-ROI prep: B1. The likeliest objection is the distance between a clinic front desk and this ad's travel, documents and supplier-invoice lines, and B1 is where it arrives.

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers both need the same meeting room at 10 on Tuesday, and one of them is travelling that day. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask each of them first, what is fixed and what can move, what alternative you would offer, how you would confirm the outcome in writing, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the calendar line, F1's requirement, asked as a decision; CASE because it scores structure, not history |
| A2 | "A colleague has to be in Cork for a 9 a.m. meeting on Thursday and back for a 4 p.m. call. What do you need to know before you book anything?" | CASE | [generic] | Clarify before you structure: what is fixed, what the traveller prefers, what the limits on cost and approval are, then options, then confirmation and who gets the itinerary. The question needs no claim about your past, so the guidance makes none | F2's requirement as a live problem; it is the safest place to show travel reasoning when F2 holds no evidence |
| A3 | "A supplier invoice arrives and the amount doesn't match what was ordered. What do you do with it?" | CASE | [generic] | Structure it aloud: hold it, check what was ordered and delivered, ask whoever placed the order, query the supplier, record the outcome, and leave approval to whoever holds it. The question needs no claim about your past, so the guidance makes none | F5's requirement as a decision; it lets the answer rest on reasoning rather than on experience F5 does not carry |
| A4 | "I need last quarter's supplier spend, by supplier, in a table I can read in two minutes, by tomorrow morning. What do you ask me first?" | CASE | [generic] | Clarify what it is for, which suppliers and period, where the figures live, and the format and deadline; then say how you would check the totals before sending. The question needs no claim about your past, so the guidance makes none | F3 and F4's requirement as a live problem, asked so that the tool matters less than the thinking |
| A5 | "It's Monday 9 a.m. and three people have each sent you a request marked urgent. How do you decide what goes first?" | CASE | [generic] | Ask what each is for and what happens if it waits, then order them, tell all three what to expect, and flag a real clash to whoever sets priorities. The question needs no claim about your past, so the guidance makes none | A general admin pressure case across the ad's four lines |

### B. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would be your weakest on day one: calendars, travel, documents, or supplier invoices?" | JD | [grounded] "I'm good with Word, okay with Excel" "I ran the appointment book for four physios" | The highest-ROI rehearsal in this pack. Pick the one you honestly believe is weakest. Hold what your sentences carry: "I ran the appointment book for four physios", and your own rating, "I'm good with Word, okay with Excel". Concede the weak part plainly and specifically, then give a plan for your first weeks as a plan, never as something already done. Answer slot: if you have already done any of the part you named, say what, in your own words; if not, say so plainly and stay with the plan | F2, F4 and F5 are where the ad presses past your material, so this question arrives in some form; JD because it scores the stated requirements, gaps included |
| B2 | "Tell me what running the appointment book involved." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: you ran the appointment book, and it was for four physios; tell those beats in your own words. Answer slot: if any part of keeping it in order was yours to decide, say which and how you decided; if it was set for you, or shared, say so plainly and describe how you ran it | F1 is the evidence for the calendar line and the first thing a skeptic tests; EXP because it checks what was actually yours |
| B3 | "The ad lists supplier invoices. What have you had to do with invoices?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Say what the sentence says, in your own words: at the clinic, you chased unpaid invoices. Answer slot: the invoice line makes a probe on handling them likely. If you did anything with invoices beyond chasing them, say what; if you did not, or it was not yours, say so plainly and stay with the chasing | F5 is the thinnest-matched requirement that your material does touch; JD because the question comes straight from the ad |
| B4 | "Tell me about a time you've arranged travel for someone." | JD | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick one occasion that has who it was for, what had to fit together, and what you would do differently; it can be from outside work. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or say how you would go about it, as in A2 | F2 has no evidence, so this is a scaffold, not a story map; JD because the ad names travel |
| B5 | "Why this role, and why now?" | EXP | [generic] | Give your own actual reason in your own words; the pack does not supply one. Keep it to what is true and to this role, in about 60 seconds | A skeptic's motivation-consistency probe on a move from a clinic desk to a remote admin role; EXP because it tests your story's consistency |

### C. Conversational/Rapport Builder (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" "I'm good with Word, okay with Excel" | A 90-second arc in three beats the quotes state: two years as a receptionist at a physiotherapy clinic; running the appointment book for four physios and chasing unpaid invoices; Word good, Excel okay. The fourth beat, why this role, is your own reason in your own words. Tell it in your words | F1, F3, F4 and F5 are what the opener rests on; EXP because the interviewer is checking that the story is consistent |
| C2 | "How do you keep track of a lot of moving pieces at once?" | JD | [grounded] "I ran the appointment book for four physios" | Selection scaffold: describe one method you actually use and one real occasion it worked. If no such method comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios" | The casual version of the ad's calendar line, still scored; JD because it tests the listed job |
| C3 | "When could you start, and is there anything you'd need in place to work remotely?" | JD | [generic] | Logistics slot: give your actual start date or notice period in your own words, and say what you really have in place for remote work. The pack supplies neither | F6's term, asked as logistics; JD because it is the listed job's terms |
| C4 | "Tell me about a time you used Word or Excel to get something done." | JD | [grounded] "I'm good with Word, okay with Excel" | Selection scaffold: pick one real occasion; say what the document or sheet was for and what you did with it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I'm good with Word, okay with Excel", or how you would go about it | F3 and F4 have a rating and no occasion, so this is a scaffold; JD because the ad names both tools |

### D. Data-Driven Prober (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said you're okay with Excel. What can you do in it, and what would you need to look up?" | JD | [grounded] "I'm good with Word, okay with Excel" | Answer at your own word, "okay", and name the part you would want to look up first before they ask. Answer slot: if you have used Excel for something, say what, in your own words; if not, or only lightly, say so plainly, then say how you would learn the rest, as a plan | F4 is the hedged rating a prober tests; JD because it scores the stated tool requirement |
| D2 | "You ran the book for four physios. What did four mean: whose diaries, and which parts were yours?" | EXP | [grounded] "I ran the appointment book for four physios" | Keep the number on the noun it came from: four physios. Answer slot: say which parts of the book were yours; if others at the clinic shared it, say so plainly. If you do not know how the figure was counted, say that plainly rather than reconstructing it | F1's figure is the one number in your material, which makes it a defend-the-number target; EXP because it tests attribution |

### E. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Several of us will send you requests. Where does your job start and stop, and what happens when two of us disagree on priorities?" | CASE | [generic] | Propose principles rather than a claimed seam: ask who sets priorities, flag a clash in writing to both, and do not pick a side yourself. The question needs no claim about your past, so the guidance makes none | A seam-and-credit probe from someone who works beside the role; CASE because it is a live collaboration problem |
| E2 | "What could you do in your first month that would genuinely lighten my load?" | JD | [grounded] "I ran the appointment book for four physios" | Reciprocity: offer from the work your sentence states, "I ran the appointment book for four physios", then ask which of their tasks would help most. Anything beyond the sentence is a plan, said as a plan | The reciprocity question for a peer-like interviewer; JD because it scores what you bring to the listed job |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we pick you over someone who has worked in a corporate office?" | JD | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Pause and restate the question. Hold through two follow-ups by returning to the sentence, never by adding to it: "I ran the appointment book for four physios and chased unpaid invoices". Concede specifically. Answer slot: if there is a part of the ad you have not done, name it plainly and say how you would learn it, as a plan | The Skeptic's objection in a time-boxed form; JD because it tests fit against the listed job |
| F2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the sentence as written. Answer slot: say which parts were yours; if some were shared or set by someone else, say so plainly. Two follow-ups return to the book, never beyond it | F1's attribution probe in a pressure register; EXP because it tests what was actually yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, A5, B2, C2, D2, E2 |
| "booking travel" | A2, B4 |
| "preparing documents in Word and Excel" | A4, C4, D1 |
| "processing supplier invoices" | A3, B3 |
| Remote working | C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like in this role?" | It shows you are thinking about results, and the answer tells you what to practice first |
| R2 | "Which of calendars, travel, documents and supplier invoices takes most of the week?" | The answer tells you where to put your remaining prep time, and it shows you are weighing the four lines |
| R3 | "What tools and templates does the team already use for travel bookings and invoices?" | It shows you want to work their way, and it tells you what to look at before day one |
| R4 | "Who sets priorities when requests from different people clash?" | It answers E1 from their side and shows you have thought about the seam |
| R5 | "What does the 30-minute call cover, and what happens after it?" | It tells you what to prepare for next, with no pressure on the answer |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer-like interviewer; it flips the call into a conversation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars across a company | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios". The limit is the pack's observation: the material says an appointment book for four physios, not a company's calendars. B2's slot stays inside the book |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: the material says chasing, not processing. B3's slot asks only what else was done with them |
| Strong or advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". The limit is the pack's observation: the material gives a hedged rating and no use. D1's slot asks only what Excel was used for |

## Sources

Provided: the invite as you pasted it; your message, which gave the ad's four task lines as you described them and your background. No dossier was supplied.

Searches sent, all refused (search permission was not granted in this session):

- "Brennock Facilities Ltd values": refused
- "Brennock Facilities Ltd interview process administrative assistant": refused
- "Brennock Facilities Ltd news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have given published values for VAL themes; the pack carries no values bank |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have shown whether other rounds follow; the pack rests on the invite's own description of one call |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have fed CO questions; the pack has none, and says so |
| 4. `{interviewer name} {company}` | n/a | No name was given, only the title office manager, so there was no query to form |
| 5. representative `{role title}` JD | skipped | The ad as you described it already fixes the fit snapshot's requirement rows |

## Upgrade menu

- The full ad text → the requirement quotes in F1 to F5 become exact, and any line your summary left out gets a row
- Whether the office manager would be your manager or a peer → persona weights are recomputed and a bank is added or cut
- The office manager's name → an interviewer read, and a reverse question tied to their own path
- Anything you have actually done on travel, on Word or Excel documents, or with invoices → F2 to F5 can move from discovery toward grounded evidence, and the slots in B3, B4, C4 and D1 become story maps
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and search permission, which was refused here) → the company's published values, loop and recent news replace the generic labels
- A tuesday-dossier.md, if you have one → confirmed evidence and claims to avoid arrive as ready-made constraints
