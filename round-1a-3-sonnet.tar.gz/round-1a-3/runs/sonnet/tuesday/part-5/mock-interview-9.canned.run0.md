Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-5/rooms/case-9-canned-6bc5a65c/halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 18 questions plus reverse questions, built for one 45-minute panel with the principal leading and the two fourth-grade teachers as peers. The invite had no posting attached, so the requirements come from the invite and the district's own beliefs and hiring pages.

Your pasted SSN isn't needed for interview prep, so I didn't use it or repeat it. I also kept your educator ID number out of the pack and out of every search. You can drop both from anything else you paste.

Say the word and I'll play the Skeptic on A1, the question the pack names as your highest-ROI prep: moving up from third grade without having taught fourth.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions, either of which would change parts of the pack:
1. Do you have the full job posting? If so, paste it and the requirement rows become quoted lines from it.
2. Do you want a deeper research pass on the district? It would use up to 6 more searches and 2 more fetches and take several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** one 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Relationship assumed:** the principal as the hiring-side lead, the two teachers as peers

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you can say twice under follow-up.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether what you have said about your work survives questions, and what was actually yours |
| JD | The role itself: what the job asks and whether you can do it, gaps included |
| CO | Knowledge of the school and district, at their altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Prep priority: A1 is the highest-ROI rehearsal in this pack. Everything after it is ordered by persona weight.

## Fit snapshot

No posting was supplied. Requirements come from the invite and from the district's own pages, quoted with their source. Where a row is role-family prose with no source, it is unquoted and labeled generic.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is met on your own statement: Illinois PEL, elementary endorsement covering grades 1–6, registered and active through June 30, 2029. It is a CV line with nothing inspected behind it, so expect to be asked; confirming it against your own state record before Thursday is yours to do |
| F2 | "reading instruction" — district careers page, "Panels ask about reading instruction, classroom routines and how you work with families" | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says you led the grade level's move and run the club, with nothing said about what changed in daily reading teaching, and the words stay there. Answer slot: the district names reading instruction as a panel topic, so expect a probe on what the move changed in how you taught reading. If it changed your teaching, say how, in your own words; if it did not, or the change was not yours, say so plainly and stay with leading the grade level's move |
| F3 | "classroom routines" — district careers page | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Six years of teaching touches routines without showing which ones. Answer slot: if there are routines you set and kept in your room, name two or three and how they ran, in your own words; if you used a school-wide system, or none you can name, say so plainly and stay with the six years |
| F4 | "how you work with families" — district careers page | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap, but a CV line with nothing inspected behind it. Lead with it in its own terms: you write it, weekly, to families. A named record beats an adjective |
| F5 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | An email is writing to families; the belief is about speaking with them, and the words stay at the email. Answer slot: expect a probe on how you are in touch with families beyond the email. If there was other contact, say what and how often, in your own words; if there was none, or it was not yours, say so plainly and stay with the weekly email |
| F6 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've run the after-school reading club for the last two years" — your CV | low | [inferred] | discovery | The quotes sit near the belief without showing how any student's reading plan was made. Answer slot: if a student's reading plan came out of your room or the club, say what the plan was and who made it, in your own words; if not, or it was not yours, say so plainly and stay with the club |
| F7 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Your material does not show how assessments fed your teaching. Strong evidence is one named assessment and one thing you changed because of it. Answer slot: if an assessment changed what you taught, say which and what changed; if you have not used one that way, say so plainly and say how you would |
| F8 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | work with the grade-level team — role-family expectation, no source supplied | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [generic] | transferability | Leading a move is not holding the team-lead role, and you have said you have not held it. Words: "I haven't been a team lead; I led our grade level's move to a new reading curriculum in 2024." No answer slot: a generic requirement raises none |

## Persona table

The loop is established by the district's careers page: one 45-minute building panel of the principal and two grade-level teachers. Weights below start from the relationship priors, then adjust.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A, 5 questions) | Quiet, persistent probing of the fourth-grade gap and the team-lead gap | High. The principal sits in the hiring-manager prior (Case plus Skeptic), and F8 and F9 are stated gaps | Rehearse A1 until it is boring: concede plainly, hold what the quotes carry, say the ramp as a plan |
| Peer Evaluator (B, 5 questions) | Two fourth-grade teachers asking what you bring, how you disagree, where credit goes | High. The peer prior (Peer Evaluator plus Prober) applies to both teachers, and the team is where you would work | Reciprocity framing: what you bring them, and principles for working together rather than a pretended knowledge of their seams |
| Case/Strategist (C, 3 questions) | Live problems set in a fourth-grade classroom, plus the district's literacy plan | Medium. The principal's prior includes it; the careers page names classroom routines and reading instruction as topics | Clarify, then structure, then think aloud; challenge one premise respectfully |
| Values/Behavioral (D, 3 questions) | Questions themed on the three published beliefs | Medium. The careers page names reading, routines and families as panel topics, which the beliefs echo; it names no values round, so none is assumed | One story per belief only where a quoted sentence carries it; otherwise a scaffold ending in its honest branch |
| Data-Driven Prober (E, 2 questions) | Checks on what the license says and how a claim was known | Lower. The CV holds no figures to probe, and the principal's reading-specialist background pulls reading questions toward the Skeptic and Case banks instead | Say only what you can say twice; say plainly what you did not track |

## Reading the interviewer

Public professional footprint only. Source: a speaker profile on a principals' forum site, returned as a search result and not read in full.

| Item | What the source says | Practical implication |
|---|---|---|
| Career pattern | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Reading answers may be heard by someone who has spent years on reading instruction: keep them to what you did |
| Self-described focus | A 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | Expect small-group and individual reading time to come up; see C3 and reverse question R2 |
| Mirror opportunity | Shared vocabulary of reading work, tied to F2's evidence: "I've run the after-school reading club for the last two years" | Use the sentence at its own scope; no shared career jump is offered, because no row's evidence carries one |

The two team members are unnamed, so there is no read for them.

## Question banks

Provenance quotes are your own sentences, exactly as given.

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, and fourth is a different year. What would be hardest about the move?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Concede first and plainly: "I haven't taught fourth grade." Then hold only what the first quote carries: six years teaching third grade at a public elementary school in Joliet. Answer slot: if you have a view of what changes between the two years from where you stand, say it in your own words; if you do not, say so plainly and say what you would ask the team first. Say your first steps as a plan, never as a past. Hold through two follow-ups by returning to the six years and the plan | F8 is the largest stated gap and the one this panel is built to test; JD because it scores the role itself, delivered as a Skeptic probe |
| A2 | "You said you led your grade level's move to a new reading curriculum. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Open with the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Say which parts were yours and which were not, in your own words, and name nothing you cannot say twice. Hold through two follow-ups by returning to the move, never by adding to it, and concede plainly any part that was someone else's | F2's sentence is short, so an attribution probe lands hardest here; EXP because it tests what was actually the candidate's |
| A3 | "The move you describe sounds like leading a team. Have you led one?" | EXP | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Start with the plain words: "I've never been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not call the move team leadership. Then, as a plan, how you would work as a new member of a team that already has its ways, in your own words | F9 is the stated gap a peer panel notices first; EXP because it tests the attribution of the move |
| A4 | "Why leave third grade, and your school, now?" | EXP | [generic] | Give your actual reason, in your own words; this pack supplies none. Lead with what draws you to this role and this school rather than what you want to leave behind. If part of the reason is private, say so plainly and move to what draws you | F8 makes the motivation probe likelier; EXP because it tests whether your story holds together, and the guidance makes no claim about your past |
| A5 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families" "I've never taught fourth grade" | Hold-then-concede, inside sixty seconds. Pause, restate the question, concede briefly: "I haven't taught fourth grade." Then give what your sentences carry, each at its own scope: six years teaching third grade; led our grade level's move to a new reading curriculum in 2024; run the after-school reading club for two years; write a weekly email to families. Let the panel draw the comparison; do not claim these make you the stronger candidate | F8 again, in a pressure register; JD because "why you" scores fit to the role |

### B. Peer Evaluator (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be joining a team that already has its ways of working. What would you ask us in your first week?" | CASE | [generic] | Propose principles, not a seam you cannot know: ask what the team already has in place and what it would most like from a new member, and say you would learn before changing anything. The question needs no claim about your past, so the guidance makes none | F9; the reciprocity framing peers weight; CASE because it is a live problem set in the role |
| B2 | "What would you bring our team that we'd feel in the first month?" | JD | [grounded] "I write a weekly email to families" "I've run the after-school reading club for the last two years" | Choose from what your two sentences carry and say them at their own scope: "I write a weekly email to families"; "I've run the after-school reading club for the last two years." Offer them as what you would bring, not as proof of anything. If asked for detail, answer in your own words or say plainly which part you would rather describe from a specific example | F4 and F2; JD because it scores what the role gains from you |
| B3 | "When work spans teams, how do you handle credit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for the grade level's work and "I" only for what the sentence says: you led the move. If asked who else was part of it, say so in your own words; if it is unclear who did what, say so plainly rather than assigning credit | F9; EXP because credit probes test attribution honesty |
| B4 | "A teammate teaches reading very differently from you, and parents notice. What happens?" | CASE | [generic] | Structure it: what you would ask your teammate first, what you would raise and what you would leave alone, how you would keep the focus on students, and where you would stop and ask the principal. The guidance makes no claim about your past | F9 and F2; CASE because disagreement style with equals is scored through a live problem |
| B5 | "Walk us through the routines in your classroom. How does a day, or a reading block, run?" | EXP | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Start from the six years in third grade. Answer slot: name two or three routines you set and kept and how they ran, in your own words; if you used a school-wide system, or none you can name, say so plainly and stay with the six years. Keep it to what you can say twice | F3; the careers page names routines as a panel topic; EXP because it tests what was actually yours |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our board adopted a three-year literacy plan in August, with a new grades 3–5 reading curriculum from fall 2027. What would you want to know about it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The plan is public, so do not recite it: show you read it with one item, the grades 3–5 curriculum from fall 2027, then ask: what is already decided, what is not, and what the fourth-grade team would want from a new member. Say you would learn the plan before offering opinions. If your own sentence comes up, say it at its own scope and do not compare the two curricula | The plan is the one piece of current district context found; CO because it tests homework at the district's altitude |
| C2 | "Sketch your first twenty days with a new fourth-grade class. What do you need to know first?" | CASE | [generic] | Structure it: what you would ask before day one, what you would set up first, how you would get to know the students, how families hear from you, and what you would check by day twenty. The guidance makes no claim about your past | F3 and F8; CASE because it is the role's own first problem |
| C3 | "A student joins your fourth-grade class reading well below grade level. What do you do in the first two weeks?" | CASE | [generic] | Structure it: what you would find out first, who you would ask, what plan you would write down, how the family hears about it, and how you would check it is working. The guidance makes no claim about your past | F6 and F2; CASE because the district's first belief is about every child as a reader |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you made sure a student was on the path to being a reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | The published belief is Every Child a Reader. Story-map only what the sentence states: the club, after school, two years. Answer slot: if a student's reading plan came out of the club or your room, say what the plan was and who made it, in your own words; if not, or it was not yours, say so plainly and stay with the club. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6; VAL because it maps to a published belief by name |
| D2 | "How do you work with families?" | VAL | [grounded] "I write a weekly email to families" | The published belief is Families Are Partners. Lead with the sentence: "I write a weekly email to families." Answer slot: expect a probe on how you are in touch with families beyond the email. If there was other contact, say what and how often, in your own words; if there was none, or it was not yours, say so plainly and stay with the weekly email | F4 and F5; VAL because it maps to a published belief by name |
| D3 | "How do assessments fit into how you teach?" | VAL | [grounded] | The published belief is Teach for Tomorrow, Not for the Test. Pick one assessment you used and one change to your teaching that came from it, said in your own words; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7; VAL because it maps to a published belief by name, and no sentence of yours carries a story here |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How did you know the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: the district's belief is that assessments inform teaching, so expect a probe on what you looked at. If you looked at anything to tell whether it was working, say what you looked at and what it showed, in your own words; if you did not, or it was not yours to track, say so plainly and return to leading the move. Never describe a measure you did not track | F2 and F7; EXP because it tests what the candidate actually knew about the move |
| E2 | "Your license is the Illinois PEL with an elementary endorsement. Can you tell us its status?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it from your own record, in your own words: an Illinois Professional Educator License, an elementary endorsement covering grades 1–6, registered and active through June 30, 2029. Say what the record says and nothing it does not. Checking the record before Thursday is yours | F1; JD because the invite states the license as a requirement |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 valid Illinois PEL with elementary endorsement | E2 |
| F2 reading instruction | A2, B4, C1, D1, E1 |
| F3 classroom routines | B5, C2 |
| F4 how you work with families | B2, D2 |
| F5 each teacher speaks with every family each term | D2 |
| F6 every child a reader, reading plan | C3, D1 |
| F7 assessments inform teaching | D3, E1 |
| F8 fourth grade | A1, A4, A5, C2 |
| F9 work with the grade-level team | A3, B1, B3, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help the fourth-grade team?" | Reciprocity with the two peers: it asks what helps them rather than what you need |
| R2 | "Your talk covered weekly reading conferences in grades 3 to 5. What does that look like in fourth grade at Halvering?" | Tied to the principal's own published work: it shows you read her, and it is a reading question she can answer at length |
| R3 | "You were a reading specialist before becoming principal. How does that shape what you look for in reading instruction?" | Tied to the principal's own path: it turns a probe into a conversation between two people who care about reading |
| R4 | "How will the grades 3–5 curriculum from fall 2027 be introduced to the fourth-grade team?" | Shows you read the literacy plan and are thinking about the team's work, not only your own classroom |
| R5 | "What would a strong first year look like in this role?" | Gives you the panel's own measure to work toward, and the answer shows what they weigh |
| R6 | "What is one thing the fourth-grade team has worked hard on this year?" | Invites the peers to tell a story, which is the rapport the team slot rewards |

## Prohibited claims

Built from the fit snapshot before any bank was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team, or been a team lead | Negative the candidate stated, F9 | The plain acknowledgment: "I've never been a team lead." No slot |
| Has taught fourth grade | Negative the candidate stated, F8 | The plain acknowledgment: "I haven't taught fourth grade." No slot |
| Chose or designed the new reading curriculum | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says you led the grade level's move, not who chose or designed the curriculum. A2's guidance stays inside the move |
| Led a school-wide or district-wide reading change | Inflated form of F2 | F2's quote at its own scope: your grade level's move. The material says grade level, not school or district |
| Speaks with every family each term | Inflated form of F5 | F5's quote at its own scope: a weekly email. The limit is the pack's observation: the material says an email, not conversations. D2's slot stays inside the email |

## Sources

Provided documents: the interview invite and your résumé text. No government ID and no license number was used or searched. The invite shows no sign of a scam, so there is no warning.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The district beliefs page, fetched in full. Moved rows F5, F6 and F7 and the Values bank D |
| 2. `{company} interview process {role family}` | yes | The district careers page, fetched in full. Moved the loop (one panel, three people), the persona weights, and rows F2, F3 and F4 |
| 3. `{company} strategy` / recent news | yes | A board news item, returned as a search result and not fetched, because both fetches went to targets 1 and 2. Moved C1 and R4 |
| 4. `{interviewer name} {company}` | yes | A speaker profile for the principal, returned as a search result and not fetched. Moved the interviewer read, R2 and R3 |
| 5. representative `{role title}` JD | yes | A job-board listing returned as a snippet only and not fetched, so nothing from it is quoted. It moved only the unquoted generic row F9 |

Searches sent:

- "Orrinsford Community School District mission values": https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel": https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news": https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren Halvering Elementary School principal": https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "fourth grade teacher job posting Illinois elementary school requirements": https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches sent:

- https://orrinsfordschools.example/about/mission-and-beliefs
- https://orrinsfordschools.example/careers/how-we-hire-teachers

## Upgrade menu

- The full job posting → the district-page and generic rows become quoted requirements, F9 becomes grounded, and the JD-tagged questions are rewritten to its lines
- The two team members' names → an interviewer read for each, per-member persona weights, and a reverse question tied to each one's path
- A sample of one weekly family email → F4 can move from medium toward high, because the email itself is the inspectable artifact
- Your own answers to the answer slots in F2, F3, F5, F6 and F7, stated outside a drill → those rows are regenerated from your words
- The recruiter's note on what the panel will cover → coverage beyond the three topics the careers page names, usually one email
- A tuesday-dossier.md from an earlier fit check → verified evidence and prohibited claims that sharpen the banks; the pack stands without it
