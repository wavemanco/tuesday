Web search was refused, so the pack runs on your message alone. I'm writing it to a file now.
Before the prep, one thing in the invite: it says the hiring process "is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Until you've checked, don't pay anything, deposit a cheque, or send documents or bank details through it. To check, contact Lumenvale through details you find yourself on its own website or careers page, not through this chat, and ask whether the invite came from them. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-5/rooms/case-10-denied-c557e8b7/lumenvale_customer-support-specialist_interview_pack.md`. It has 18 practice questions, a table matching your experience to the four ad requirements, reverse questions, and a list of claims not to make. I built it for a hiring-manager-style round, because the invite says you'll chat with their support team lead but not whether they'd be your manager.

My web searches on Lumenvale were refused, so nothing in the pack comes from outside your message. The company-knowledge questions are generic and say so.

Two things the pack shows about your material:
- **Your biggest gap:** "I've never worked for a software company" is the objection you're most likely to face, so question A1 is the one to rehearse first. The guidance is to state it plainly, then give a plan for learning the product, and not stretch your past.
- **What your message doesn't cover:** nothing in it shows escalations or the quality of your written replies. Those rows are marked as answer slots for you to fill from your own experience, or to answer honestly that you have none.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead you'll chat with the person you'd report to, or a peer-level lead? The answer reweights every bank.
Could you paste the full text of the job ad? Without it, the pack rests on the four requirements you listed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Customer Support Specialist, Lumenvale Software: interview prep pack

Interviewer: the support team lead (name not given), by text chat on Telegram, per the invite. Their relationship to you is not stated, so this is built as a hiring-manager-style round.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: **VAL** is whether past behaviour shows the company's published values. **EXP** is whether your claims survive scrutiny. **JD** is the ad's stated requirements. **CO** is company knowledge and motivation. **CASE** is a live problem from the job.
- Provenance labels: `[grounded]` traces to your message. `[inferred]` is derived from it, with the derivation named. `[generic]` is a pattern for the problem and says nothing factual about Lumenvale or you.
- Guidance is scaffolding, not a script. The interview is a text chat, so treat each guidance cell as a short typed reply you could also say aloud in 90 to 120 seconds.
- An answer slot is an instruction for the interview, not a question for this conversation. Answer it from your own experience, in either branch.
- Highest-ROI prep: question A1. It will almost certainly arrive in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as relayed in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line in your message with nothing inspected behind it, so expect a probe on it. Lead with the sentence in its own terms: 3 years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as relayed in your message | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | The ad names Zendesk and your sentence names Freshdesk, and the words stay: "I use Freshdesk every day." Say the tool by its name and let the interviewer weigh it against the ad's "similar ticketing tool" wording. Never describe it as Zendesk experience. Nothing is said here about what you do in it, because your message does not say |
| F3 | "clear written communication" — job ad, as relayed in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The sentence includes emails, and it does not show whether they were clear. Answer slot: the ad's written-communication line makes a probe on your written replies likely. If you did something in particular to keep them clear, say what, in your own words; if you did nothing in particular, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — job ad, as relayed in your message | none given | none | [grounded] | discovery | Your message does not say either way. Answer slot: expect a probe on escalated contacts. If you handled any, say what the contact needed, what you did and how it ended, in your own words; if you handled none, or they went to someone else, say so plainly and stay with the calls and emails you answered |
| F5 | Supporting customers of a software company: the role's context, from the job title and employer name in your message, not a stated requirement | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-company work, and nothing added to make the gap feel smaller |
| F6 | none, your own addition and not in the ad | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Not a requirement, so no gap. It stays at its own scope: four new starters, the refunds process, last year. Say it in those words and let the interviewer draw any wider conclusion |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of the stated gap and of the escalation line | Highest. A support team lead is a hiring-manager-type relationship, whose prior is Case plus Skeptic. F5 is a gap you stated and F4 has no evidence in your material, both Skeptic ground | Rehearse the stated-gap answer until it is boring: the fact first, then a plan, never a past. Bridge only from what you actually stated |
| Case / Strategist (bank B, 4 questions) | Live support scenarios typed into the chat | High. The other half of the hiring-manager prior, and the ad's written-communication and escalation lines can be tested live in a text chat | Clarify, then objective, approach and risks, in short typed steps. Challenge one premise respectfully per case |
| Conversational (bank C, 3 questions) | A friendly opener such as the journey question, plus a homework check | Medium. My read, not sourced: a lead opening a text chat will probably start with your background | A pre-scripted arc for the biography question. Treat casual questions as scored |
| Data-Driven Prober (bank D, 3 questions) | Pressing the number and the tool: how counted, what you actually do | Medium. F3 carries a figure and F6 carries a number, and both are easy to probe | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Pressure / Stress (bank E, 3 questions) | Time-boxed challenges on the tool, the gap and an escalated contact | Medium. The ad's escalation line is a composure signal, and F2 and F5 are the natural pushes | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede only what is true |
| Values / Behavioral (no bank) | Stories mapped to published values | Not banked: no published values are in hand and the invite names no values round. Send the company's values and a bank is added | n/a |
| Peer Evaluator (no bank) | Seam-splitting and collaboration scenarios | Not banked: the invite names a team lead, not a peer. Your answer to the relationship question reweights this | n/a |

Loop basis: the invite describes one session, a text chat with the support team lead, and no other round. Persona weights rest on that and on the hiring-manager prior. No archetype fallback was needed.

## Question banks

### A. The Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company before. Why should I expect you to support our customers well?" | JD | [grounded] "I've never worked for a software company" "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Say the stated fact first, in your own words: "I've never worked for a software company." Then give a plan, never a past: what you would do in your first weeks to learn the product, in your own words. You may set the tool you do use beside the gap: "I use Freshdesk every day." Expect two follow-ups, one on what you would do first and one on what if learning takes longer. Answer both as plans, and hold by returning to the plan and the quote, never by adding to your history. Concede the gap itself, which your message states | F5 is the stated gap and the likeliest opening objection, so it gets the deepest rehearsal. JD because it scores fit for the role, delivered as a Skeptic |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the part you honestly rate weakest, in your own words, then how you would close it. The gap your material states is "I've never worked for a software company", and it is a fair thing to name if it is your honest answer. Do not name a weakness you do not believe you have, and do not claim a strength to avoid naming one | F5 is the stated gap and F4 has no evidence in the material, so this stem has two places to land. JD because it scores the ad's own list |
| A3 | "The ad asks for confidence handling escalations. Tell me about a time you handled one." | JD | [grounded] | Selection scaffold, because your material carries no escalation sentence. Pick a time a contact needed more than you could give in your first reply. A usable one has what the contact needed, what you did, who else came in and how it ended, all in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is the ad's line asked live, with nothing in the material behind it. JD because it scores a stated requirement |
| A4 | "Why a software company, and why Lumenvale?" | CO | [generic] | Your reasons are yours and nothing here supplies them. Answer slot: say what actually draws you to this role and this company. Where something specific came from Lumenvale's own pages, name what you read. If nothing specific, say so plainly and say what you would want to find out first | Motivation consistency is what a Skeptic scores, and F5 makes the why-software half likely. CO because it tests homework. The label is generic because this pack holds no company research |
| A5 | "The ad asks for clear written communication. What shows yours is?" | JD | [inferred] "answering around 60 calls and emails a day" | Start from the sentence in its own words: "answering around 60 calls and emails a day." Answer slot: the ad's written-communication line makes a probe on how you kept written replies clear likely. If you did something in particular, say what, in your own words; if you did nothing in particular, or have no example to hand, say so plainly and stay with the emails you answered. In a text chat your replies are themselves a sample, so keep them short, complete and specific | F3 is thin evidence, so the pack rehearses an honest answer rather than a claim. JD because it scores the ad's line. Inferred because the link from emails answered to clarity is a derivation |

### B. The Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in, angry: they were charged twice this month and say they will cancel today. Walk me through your first reply." | CASE | [generic] | Clarify before you structure: what they were charged, when, and what they want from you. Then objective, approach, risks. A first reply that works acknowledges the problem in a line, says what you will do and by when, and says plainly what you cannot do yourself and who can. Think aloud in short steps. Challenge one premise respectfully, for example whether the double charge is confirmed yet | A support-desk staple that tests the ad's written-communication and escalation lines (F3, F4) as a live problem. CASE because it scores structure, not history |
| B2 | "A customer says the app crashes whenever they open a report, and you have never seen that feature. What do you do first?" | CASE | [generic] | Clarify first: what they see, what they were doing, whether it has happened before and what device or version they use. Then say what you can check yourself, what you would look up, and when you would hand it on with a clear write-up. Be honest with the customer about what you do not yet know and say what you will come back with | F5 is the stated gap, and this case lets you show method on unfamiliar software without claiming experience of it. CASE because it asks about no past |
| B3 | "You get a long, angry email that mixes three different problems. How do you answer it?" | CASE | [generic] | Structure it aloud: sort the three, say which you will deal with now and which later, answer in the order the customer cares about, give one clear next step per problem, and keep the tone level. Say you would reread it as the customer before sending | The ad's written-communication line (F3) as a live problem. CASE with JD content |
| B4 | "On Mondays the queue doubles and you cannot answer everything at once. How do you decide what goes first?" | CASE | [generic] | Ask what the team already uses to rank work, if anything. Otherwise offer principles in your own words, such as urgency, customer impact, who has waited longest and what is quick to close, and say what you would flag to the lead and how you would tell waiting customers. Offer principles rather than pretending to know the team's rule | Tests judgement under volume, the scale F3's figure points at. CASE because it scores reasoning, not a rehearsed answer |

### C. The Conversational / Rapport Builder (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | A 90-second arc in the order your sentences give it: 3 years as a customer service advisor at an energy supplier; answering around 60 calls and emails a day; using Freshdesk every day; training four new starters on the refunds process last year. Tell each beat in your own words and add nothing the sentences do not say. Closing beat, which nothing here supplies: your own reason for this move. Answer slot: say what actually draws you to software support; if there is no strong reason beyond the job itself, say so plainly and do not invent one | An opener that feels casual and is scored. The arc draws on F1, F2, F3 and F6, and ends on the why-this-move question that F5 makes likely |
| C2 | "What do you know about Lumenvale and who our customers are?" | CO | [generic] | Nothing about Lumenvale is supplied in this pack, because the research was not available. Say only what you have actually read on Lumenvale's own site or careers page before the chat, name where you read it, and stop. If you have not looked yet, look first, then say only what you found. If little comes up, say so plainly and say what you would want to learn first | A homework check that a rapport-style lead can ask casually. Generic because the pack has no company facts, and no guidance cell here asserts any |
| C3 | "Tell me about training the four new starters on your refunds process." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say it as the sentence does: "I trained four new starters on our refunds process last year." Keep to those beats and answer follow-ups from what you actually did, in your own words. Where a follow-up asks about something the sentence does not cover, say plainly what you did and did not do | F6 is a strength the ad does not ask for, so it is the story a lead is likely to pick up for rapport. EXP because it tests what was actually yours |

### D. The Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say you use Freshdesk every day. What does that look like?" | JD | [grounded] "I use Freshdesk every day" | Start with the sentence in its own words: "I use Freshdesk every day." Answer slot: the ad's ticketing-tool line makes a probe on what you do in it likely. Say what you actually do in it day to day, in your own words; if some of it was set up or done by someone else, or it is less than the probe assumes, say so plainly and stay with what you do | F2 covers the ad's tool requirement in other terms. JD because it scores that requirement. Asked by a Prober because it wants specifics |
| D2 | "Around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly and stay with the sentence: "answering around 60 calls and emails a day." If it was a team figure rather than yours, say so | F3's figure is the headline number in your message. EXP because it tests whether the number survives scrutiny |
| D3 | "Four new starters. Which part of that was you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold to the sentence: "I trained four new starters on our refunds process last year." Answer slot: say which part you did yourself, in your own words; if some of it was not yours, say which part plainly and stay with what the sentence carries. If asked how the four were counted, say it in your own words, or say plainly that you do not know | An attribution probe on F6. EXP because it tests what was actually yours |

### E. The Pressure / Stress Interviewer (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The ad says Zendesk. You use Freshdesk. Why should I treat them as the same?" | JD | [grounded] "I use Freshdesk every day" | Pause, restate the question, then hold what your sentence carries: "I use Freshdesk every day." The ad's own words are "experience with Zendesk or a similar ticketing tool", so point to them rather than arguing the tools are identical. Concede plainly that Freshdesk is the tool you use and that the ad names another. Answer slot: the probe will be how alike the two are in use. Say what you actually do in Freshdesk, in your own words; if that is less than the probe assumes, say so plainly and stay with the tool you use. Hold through two follow-ups by returning to the sentence | F2 is where the ad's tool name and yours differ. Pressure because it tests whether you argue past the evidence. JD because it scores the ad's requirement |
| E2 | "Sixty seconds: why you rather than someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I've never worked for a software company" | Pause and restate. Anchor only in what you stated: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day". Concede the gap in the same breath: "I've never worked for a software company." Hold to those three sentences through two follow-ups, and do not claim you would be better than the other person; say what you bring and what you would be learning | F1 and F2 are the evidence for the ad's years and tool lines, and F5 is the stated gap. A standard Pressure stem. JD because it scores fit |
| E3 | "A customer demands a refund you are not allowed to give and asks for your manager. You have sixty seconds: what do you say?" | CASE | [generic] | Pause and restate: they want the refund and a manager. Acknowledge the frustration in one line, say what you can do now, say plainly what you cannot do and why, and say who can look at it and what happens next, without promising an outcome. Hold your position without turning defensive, and concede only what is true, for instance that you cannot decide this yourself | The ad's escalation line (F4) as a composure test. CASE content with Pressure delivery |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, E2 |
| "experience with Zendesk or a similar ticketing tool" | D1, E1, E2 |
| "clear written communication" | A5, B1, B3 |
| "confidence handling escalations" | A3, B1, E3 |
| Stated gap F5, not an ad requirement | A1, A2, A4, B2, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first ninety days look like for someone new to software?" | Turns F5 into a forward-looking plan conversation and shows you are thinking about ramp-up |
| R2 | "How does the team handle escalations: who picks them up, and what does a good handover contain?" | Shows you read the escalation line (F4) as a team practice, and gives you something concrete to rehearse against |
| R3 | "How do new starters get up to speed on the product?" | Connects your ramp-up plan (F5) to the team's real process and lets the lead describe it |
| R4 | "Is there a written reply you would hold up as the standard you want?" | Asks what clear written communication (F3) means here, in the lead's own terms |
| R5 | "Will any part of the process move to a call or video, and how long should I plan for this chat?" | A process question with a prep reason: it tells you what format to rehearse and how much time to set aside |
| R6 | "What are the most common things customers write in about at the moment?" | Gives you vocabulary to prep the B-bank cases against, and shows interest in the work itself |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation, not words for you: the material says Freshdesk, not Zendesk. E1's slot stays inside Freshdesk |
| Has worked in software or software-company support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Resolved around 60 tickets a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day." The limit is the pack's observation: the sentence counts calls and emails answered, and says nothing about how many were resolved or how they were counted |
| Ran or owned new-starter onboarding | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: the sentence says trained, not who set up the training or ran onboarding |

## Sources

Provided documents: your message, which holds the invite text as pasted, the four requirements from the job ad as you relayed them, and your background. No dossier was present. The full job ad text was not supplied.

Searches sent:

- `Lumenvale Software values` — refused
- `Lumenvale Software company news strategy` — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have fed VAL question themes. No published values are in hand, so there is no VAL bank |
| 2. `Lumenvale Software interview process customer support` | skipped | The invite's own words fix the loop, one text chat with the support team lead, so persona weights and the loop need nothing more |
| 3. `Lumenvale Software` strategy and recent news | unavailable | The search was refused. It would have fed a strategy-grounded CO question; C2 and A4 are generic instead |
| 4. interviewer name and company | n/a | No interviewer name was given: the invite names the sender, and the interviewer is the unnamed team lead. The interviewer read is absent |
| 5. representative Customer Support Specialist JD | skipped | The four requirements you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text → any requirement beyond the four you listed gets its own fit row and JD-tagged question, and F3 and F4 may move from `[inferred]` to `[grounded]`
- Whether the team lead would be your manager or a peer-level lead → persona weights recomputed, a Peer bank added if peer, reverse questions retuned
- Web search permission for Lumenvale's published values and recent news → C2 and A4 become grounded in what the company publishes, and a VAL bank can be added. A deeper pass is also possible: up to 6 more searches and 2 more fetches, several more minutes
- Your own answers to the slots on F3 and F4, if you have an example in either → those rows regenerate from your words and A3 and A5 become story maps instead of scaffolds
- Anything said about what the chat will cover, or how long it runs → coverage tuned to it, and a prep schedule added
- How much prep time you have → a prioritised prep schedule sized to it
- The interviewer's name → an interviewer read from their public professional footprint and a reverse question tied to their path
- A `tuesday-dossier.md` → verified evidence, a named top objection and an absolute prohibited-claims list carried into this pack
