Searches were refused, so I'm building the pack from your message alone. Writing it now.
Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and describes a cheque arrangement: "a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor". Asking you to pay a fee, deposit a cheque and send part of it on, and hand over passport and bank details before any offer is a known scam pattern, and these requests are very likely a scam. Hold all of it until you've checked the invite with the employer, using contact details you find yourself on its own website or careers page rather than the email, number or replies in the invite. None of this prep needs your passport or bank details. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-5/rooms/case-12-denied-7bb89606/brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md`. It has 18 questions, a fit snapshot, reverse questions and a list of claims it won't coach. I built it for a first call with the office manager, weighted between a hiring-manager and a peer style, since the invite doesn't say which. Web search was refused, so nothing in it comes from research on the employer.

Your strongest material is the appointment book for four physios. The likeliest hard question is how chasing unpaid invoices compares with processing supplier invoices (A2). Travel booking and Excel are the other soft spots.

Say the word and I'll play the Skeptic on A2 so you can rehearse it live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to day to day, or a colleague you'd work alongside? The answer reweights every question bank.
Can you paste the full text of the ad? Five fit rows currently rest on your summary and would become word-for-word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: a 30-minute video call. Relationship to the role: not stated, so this pack is built on an assumption, named under the persona table.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the employer's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the employer and its work |
| CASE | How you reason through a live problem from the role |

The highest-ROI prep in this pack is A2, the comparison between chasing unpaid invoices and processing supplier invoices. It will be asked in some form, and a calm, exact answer changes the call.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Lead with the appointment book in your own terms: "I ran the appointment book for four physios." The ad says calendars and your words say appointment book; keep your words and let the interviewer make the link. Nothing is inspected behind the line, so expect a probe on it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: if any of your work involved arranging travel or bookings, say what, in your own words; if none did, say so plainly and say how you would learn the booking process |
| F3 | "preparing documents in Word and Excel" (Word) — the ad, as you described it | "I'm good with Word" — your message | medium | [grounded] | none | No gap on the tool, but a self-rating with nothing inspected behind it, so expect a probe on what you have prepared. Lead with the quote in its own terms: "I'm good with Word" |
| F4 | "preparing documents in Word and Excel" (Excel) — the ad, as you described it | "okay with Excel" — your message | medium | [grounded] | discovery | The level you gave is "okay", and the words stay there: "I'm okay with Excel." Answer slot: the ad puts Excel in the documents you would prepare, so expect a probe on what you have used it for. If you have used it for particular tasks, name them in your own words; if not, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, and does not show whether those were invoices owed to the clinic or by it, or whether any were supplier invoices. The words stay at the quote: "I chased unpaid invoices." Answer slot: if any invoices you handled were supplier invoices, say what you did with them, in your own words; if they were not, or you did not handle supplier invoices, say so plainly and stay with the chasing |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of the gaps between your background and the ad | High. The ad's duties include travel and supplier invoices, and F2 and F5 are the rows where your material is thinnest; a hiring-manager round prior also puts the Skeptic first | Rehearse A2 until it is boring: hold at the quote, never add to it |
| Case / Strategist (bank B) | Live problems from the job: a clash on a calendar, a mismatched invoice | High. An admin role is scored on judgment under small, concrete problems, and a hiring-manager prior puts Case beside the Skeptic | Clarify first, then structure, then answer; think aloud |
| Conversational (bank C) | A friendly opener and casual questions that are still scored | Medium. A 30-minute video call usually opens with the biography question | Pre-build the 90-second arc in C1; treat casual questions about Word and Excel as scored |
| Peer Evaluator (bank D) | Questions about working alongside others and what you would need | Medium. An office manager may be a colleague as much as a boss; the invite does not say | Reciprocity: what you bring as well as what you need |
| Data-Driven Prober (bank E) | Line-by-line reading of your background | Low. Your material carries almost no figures to probe | Know exactly what you can and cannot say about each line |
| Pressure (bank F) | Time-boxed challenges, devil's advocate | Low. Nothing in the invite suggests a stress format | Pause, restate, hold, then concede specifically |

Assumption this weighting rests on: the invite names one session, a 30-minute video call with the office manager, and does not say whether that person would manage you or sit beside you, so weights blend the hiring-manager and peer priors. No values-style round is detected: the invite names none, and no fallback applies because the invite itself establishes the one session.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the appointment book and the four physios are the beats the quote states; tell them in your own words and keep to that scope. Answer slot: the ad's calendars line makes a probe on how you kept the book likely. If any part of running it was yours to organise, say which and how you decided, in your own words; if there was no such part, or it was not yours, say so plainly and return to the book you ran | F1 is the evidence for the calendars line and the likeliest opener; EXP because it tests what was actually yours, and the question is premised only on F1's own words |
| A2 | "Tell me how chasing unpaid invoices compares with processing supplier invoices." | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if any invoices you handled were supplier invoices, say what you did with them, in your own words; if they were not, or you did not handle supplier invoices, say so plainly and return to the chasing. Then say how you would learn the supplier side, as a plan and not as a past. Hold through two follow-ups by returning to the chasing, never by adding to it | F5 is where the ad's invoices line presses hardest, so this objection arrives in some form; JD because it scores a stated duty |
| A3 | "How comfortable are you with Excel?" | JD | [grounded] "I'm good with Word, okay with Excel" | Hold the level you gave, "okay with Excel", and do not move the adjective in either direction under follow-up. Answer slot: the ad puts Excel in the documents you would prepare, so expect a probe on what you have used it for. If you have used it for particular tasks, name them in your own words; if not, say so plainly and say what you would practise first | F4 is the thinnest of the document skills and the likeliest second probe after F5; JD because it scores the ad's Excel line |
| A4 | "I don't see travel booking in your background. How would you handle it in this role?" | JD | [grounded] | Answer slot: if any of your work involved arranging travel or bookings, say what, in your own words; if none did, say so plainly. Then give a plan: what you would ask for first, how you would confirm bookings with the person travelling, and what you would keep a record of. The question needs no claim about your past, so the plan makes none | F2 is a row the material is silent on, so the honest answer is a slot plus a plan; JD because it scores the ad's travel line |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people ask for the same hour on the calendar of someone you support, and both say it is urgent. What do you do?" | CASE | [generic] | Structure it: what you would ask each of them first, what you would offer if only one hour exists, how you would tell both, and what you would record. The question asks about no past, so the guidance makes no claim | A live problem from the calendars line, F1's requirement, asked as a decision; generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "A supplier invoice arrives and the amount does not match the order. Payment is due on Friday. What do you do?" | CASE | [generic] | Structure it: what you would check first, who you would ask to confirm, how you would hold the payment without souring the supplier, and what you would record. Think aloud and name what you would not decide alone | A live problem from the supplier-invoices line, F5's requirement; generic because it is a pattern for the problem |
| B3 | "Someone you support flies out the day after tomorrow and has asked you to book the trip. What do you need to know first?" | CASE | [generic] | Clarify before answering: dates, preferences, budget limits, who approves, what must be confirmed in writing. Then give the sequence you would follow and what you would send back as confirmation. No claim about your past is made | A live problem from the travel line, F2's requirement; it lets you show structure where your material is silent |
| B4 | "You are handed a spreadsheet of supplier invoices and some of the figures look wrong. How do you check it before passing it on?" | CASE | [generic] | Think aloud: ask what the sheet is for and who relies on it, say what you would check and how, flag what looks wrong rather than quietly changing it, and say where you would stop and ask. Keep it to what you would do, not what you have done | A live problem from the Excel and invoices lines, F4's and F5's requirements; generic because it is a pattern for the problem |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey from where you are now to wanting this job." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc of three beats, each a clause the quotes state: two years as a receptionist at a physiotherapy clinic; the appointment book for four physios; chasing unpaid invoices. Close on why this role. Answer slot: the reason for the move is yours, so say it plainly in your own words, whatever it is | The biography question opens most calls; F1 and F5 are the rows the arc draws on |
| C2 | "Tell me about a document you prepared in Word that someone else relied on." | JD | [grounded] "I'm good with Word" | Selection scaffold: pick a document someone else used, and name what it was for, who used it and what you did to prepare it. If no such document comes to mind, say so plainly, then give the nearest thing your material does carry, which is "I'm good with Word", or say how you would approach one | F3 is a self-rating with nothing inspected, so the interviewer will ask for an instance; JD because it scores the ad's Word line |
| C3 | "What do you know about what we do here?" | CO | [generic] | Say only what you have actually read from the employer's own materials, in your own words. If you have read nothing, say so plainly and ask what the team does; a short honest answer scores better than a confident guess | Homework depth is scored even in a friendly register; generic because no research on the employer was possible for this pack |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "When two of us ask you for something at the same time, how do you decide whose goes first?" | CASE | [generic] | Structure it: what you would ask each of us, what you would check about deadlines, how you would tell the person who waits, and when you would bring it to the office manager. No claim about your past is made | A seam question from the Peer persona, tied to F1's calendars requirement |
| D2 | "How do you handle credit when work spans two people?" | EXP | [generic] | Selection scaffold: pick a piece of work you shared with a colleague, say what each of you did, and use "we" for context and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer persona's credit probe; generic because it is a stem, not a fact about this employer |
| D3 | "What would you need from me to do this job well in your first month?" | JD | [grounded] "I ran the appointment book for four physios" | Reciprocity framing. Say what you would need: how requests reach you, who approves what, where the existing records are. Then say what you bring, in the quote's terms: "I ran the appointment book for four physios." Keep the need list to what you would ask for, not to what you assume exists | The Peer persona's collegial packaging of the day-one question; F1 supplies the one thing you can say you bring |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How much of running the appointment book for four physios was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the quote: "I ran the appointment book for four physios." Answer slot: say which parts were yours to decide; if some belonged to someone else, or none were decisions, say so plainly and return to the book. The figure in the quote raises its own slots: say in your own words what the four counted and which assumption in it you would defend least, or say plainly that you do not know | F1's one figure is the Prober's natural target; EXP because it tests attribution |
| E2 | "Walk me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | Stay at the quote: "I chased unpaid invoices." Answer slot: expect a probe on the steps. If any step was yours to choose, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and describe the chasing you did | F5 is the likeliest line to be taken apart step by step; EXP because it tests what was actually yours |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has done this job before?" | JD | [grounded] "I ran the appointment book for four physios", "chased unpaid invoices", "I'm good with Word, okay with Excel" | Pause and restate the question. Hold on what the quotes carry, in your own words: the appointment book for four physios, and chasing unpaid invoices. Hold through two follow-ups by returning to those two, never by adding to them. Concede specifically where the quotes stop: your level on Excel is "okay". For the supplier side, answer slot: if you handled supplier invoices, say what you did; if not, say so plainly and say how you would learn it | A time-boxed challenge on F1, F4 and F5 together; hold-then-concede is the type-specific bar |
| F2 | "Your experience is at a physiotherapy clinic. Why would it carry over to an office like ours?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios" | Hold on the two quoted sentences and concede the setting is different, in those words, without folding on what you did. Answer slot: if any of what you did there is the same kind of work as the ad's calendars or invoices lines, say which and how, in your own words; if you cannot name any beyond what the quotes carry, say so plainly and say how you would learn the office's way of working | A devil's-advocate challenge to F1's transferability; EXP because it tests the claim under pressure |

### Requirement coverage

| Requirement (from your description of the ad) | Covered by |
|---|---|
| managing calendars | A1, B1, D1, D3, E1 |
| booking travel | A4, B3 |
| preparing documents in Word | C2 |
| preparing documents in Excel | A3, B4 |
| processing supplier invoices | A2, B2, B4, E2 |
| Fit and motivation overall | C1, C3, D2, F1, F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like for the person in this role: which calendars, which suppliers, which documents?" | It shows you are thinking about the actual work, and the answer tells you where to focus your Excel practice |
| R2 | "Which tools does the team use for calendars, travel booking and invoices?" | It lets you prepare on the right software before day one, and it reads as practical rather than generic |
| R3 | "What would a good first month look like in this role?" | It invites the interviewer to define success, and shows you plan to be useful early |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity: if the office manager is a peer, it shifts the talk from what you need to what you give |
| R5 | "How are priorities set when two people's requests clash?" | It follows from B1 and D1, and it tells you how much judgment the role is expected to carry |
| R6 | "Will there be a further step after this call, and what does it involve?" | It tells you what else to prepare, for example a second conversation or a short exercise |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for an office or a team | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says the appointment book, not an office's calendars |
| Strong or advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". The limit is the pack's observation: your material gives the level as okay |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: your material says the chasing, not the processing. A2's slot stays inside the chasing you did |

## Sources

Provided documents: the invite as you pasted it, the ad's duties as you described them, and your note on your background. No dossier was present. No document supplied the employer's values, strategy or interview process.

Searches sent: `Brennock Facilities Ltd values` — refused. `Brennock Facilities Ltd interview process administrative assistant` — refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Both calls were refused. It would have moved a values-style framing and the CO bank; nothing in the pack rests on it |
| 2. `Brennock Facilities Ltd interview process remote administrative assistant` | unavailable | The call sent was refused. It would have moved the loop structure and persona weights, which rest on the invite's own words instead |
| 3. `Brennock Facilities Ltd strategy` | unavailable | No call sent: search was refused twice, so I did not retry. It would have moved the CO bank, now generic |
| 4. `interviewer name Brennock Facilities Ltd` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad's duties as you described them fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → F1 to F5 requirements become word-for-word quotes instead of your summary, and any mid-list duty that earns no question yet gets one
- The office manager's name and whether they would manage you or sit beside you → persona weights reset, an interviewer read, and a reverse question tied to their path
- What you have used Excel and Word for, and any travel booking or supplier invoices you handled, stated in your own words → F2 to F5 move from answer slots to story-mapped rows, and A2, A3 and E2 get quoted holds
- The employer's own about or values page pasted in, or search access granted → the CO bank stops being generic and any published values can theme questions
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, which needs search access
- A tuesday-dossier.md from an earlier session → verified evidence and absolute prohibited claims carried into this pack
