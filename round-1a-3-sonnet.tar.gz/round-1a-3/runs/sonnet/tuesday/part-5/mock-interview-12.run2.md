Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview", and it says "you deposit the cheque and send the balance on to the vendor". Paying a fee, sending a passport photo and bank details before any offer, and depositing a cheque to pass money on are a known scam pattern. Those requests, and the job as a whole, are very likely a scam. Hold all of it (paying, depositing the cheque, sending your passport photo or bank details) until you have checked the invite with the employer. Use contact details you find yourself on its own website or careers page, not the email address, number or replies in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `brennock-facilities_remote-administrative-assistant_interview_pack.md`. I built it for a hiring-manager round, since the invite doesn't say whether the office manager would be your boss or a peer. Search was refused, so there is no company research in it and nothing in it comes from outside your message. The company-knowledge questions are left out and the pack says so.

It has 18 questions across five interviewer styles, a table of your evidence against each duty, and six questions to ask them. The most important rehearsal is A3, the "I don't see supplier invoices in your background" question. Your material says you chased unpaid invoices, so the pack coaches you to hold that line and say plainly if processing supplier invoices wasn't part of your work.

Say the word and I'll play the skeptical interviewer on A3.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to, or a peer on the team? The answer reweights every bank.
Can you paste the ad's full text? Without it I'm working from your summary of it, and I'll carry on without it if you'd rather not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager, name not given. Relationship assumed to be hiring-manager. Format as the invite describes it: one 30-minute video call. This is a first version; nothing has been regenerated.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values. No values round is documented here, so none is built |
| EXP | Work-experience deep-dive | Whether your background claims survive questions, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed duties, gaps included |
| CO | Company and strategy knowledge | Homework on the company. None is built, because no company research could be run |
| CASE | Hypothetical / live problem | Your structure and reasoning on a problem from the role |

Provenance labels: `[grounded]` rests on something you supplied, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern that makes no claim about you or this employer.

## Fit snapshot

The requirements are quoted from your description of the ad, since the full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your sentence already reaches this requirement in other terms. Say it as written and let the interviewer connect it to calendars: "I ran the appointment book for four physios." Nothing is added to it, and the quote does not say what running it involved, so expect a probe on that. A5 holds the slot |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show whether you have booked travel. Answer slot: the ad's travel line makes a probe likely. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and say how you would go about it |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | none | The quote names both tools and carries its own limit. Say it exactly that way: "I'm good with Word, okay with Excel." Expect a probe on Excel, and keep "okay" where you put it |
| F4 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices. It does not say whether those invoices were owed to the clinic or by it, and it does not say you processed supplier invoices. The words stay at the quote: "I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe on the supplier side likely. If you handled invoices the clinic had to pay, say what you did with them, in your own words; if the invoices you chased were owed to the clinic, or processing supplier invoices was not part of your work, say so plainly and stay with the chasing |

## Persona table

The loop is the one the invite describes: a single 30-minute video call with the office manager. Weights start from the hiring-manager relationship prior, which is an assumption because the invite does not say whether the office manager would be your manager or a peer.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the thinnest parts of the match | Top, 5 questions. The hiring-manager prior puts it first, and F2 and F4 are where the material is thinnest | Rehearse A3 until it is boring. Bridge only from what your own sentences say, and say the limit plainly |
| B. Case / Strategist | Live problems from the four duties: calendar clashes, a travel plan, an invoice query, a document task | Top, 5 questions. The hiring-manager prior puts it first, and the ad's four duties each translate directly into a live problem | Clarify first, then structure, then answer. Think aloud and say what you would check |
| C. Conversational | A friendly opener and casual questions about your background and tools | Mid, 3 questions. A 30-minute video call usually opens with rapport, and casual questions are still scored | Have a 90-second arc ready and treat the Excel question as scored |
| D. Data-Driven Prober | Asks what exactly was yours and how a figure was counted | Mid, 3 questions. "Four physios" is the one figure in your material, and the Excel rating invites a probe on what you have done | Know what you can and cannot say about each claim, and say plainly when you do not know |
| E. Peer Evaluator | Collaboration and working-style questions in a collegial register | Low, 2 questions. The relationship is assumed to be manager, not peer. If the office manager turns out to be a peer, this weight rises | Reciprocity framing: what you bring to the person's workload |

No Pressure or Values/Behavioral bank is built: nothing read documents a values round or a stress format for this single call.

## Question banks

Highest-ROI prep in this pack: A3. A question on the supplier side of invoices is the most predictable objection, because F4 is the row where the ad's requirement is wider than the quote.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" | Hold to your own rating: "I'm good with Word, okay with Excel." That puts Excel as the lower of the two in your own words. Answer slot: if there is an Excel task in the job you have not done, say which; if you cannot name one, say so plainly. Then give a ramp plan, said as a plan and never as a past | F3 is the likeliest place for the "weakest" probe to land. JD because it scores the stated duty |
| A2 | "Tell me about a time you organised travel for someone." | JD | [grounded] "I ran the appointment book for four physios" | Pick a time you arranged travel for someone: it needs a named person it was for, what they needed, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or how you would handle it | F2 is a row where the material says nothing, so the question arrives as an open prompt. JD because it scores a listed duty |
| A3 | "I don't see supplier invoices in your background. How would you handle that part of the role?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if you handled invoices the clinic had to pay, say what you did with them, in your own words; if the invoices you chased were owed to the clinic, or you did not process supplier invoices, say so plainly and stay with the chasing. Hold through three follow-ups by returning to the chasing, never by adding to it. Then give a plan for learning the supplier side, said as a plan and never as a past | F4 is where the ad's wording presses hardest against the quote, so this objection arrives in some form |
| A4 | "What draws you to this role?" | JD | [generic] | Name one duty on the ad's list that you would want to do and why, in your own words. The reason has to be yours: if none of the four stands out, say so plainly and say what does draw you. The question needs no claim about your past, so the guidance makes none | A motivation check is near-certain in a 30-minute call. JD because it ties the answer to the listed duties |
| A5 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the appointment book and the four physios, which are the beats the quote states; tell them in your own words. Answer slot: the ad's calendar line makes a probe on what running the book involved day to day likely. Say what you did, and if part of it was not yours, say so plainly | F1 is the evidence for the calendar requirement. EXP because it tests what was actually yours |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Three people ask you for the same hour in a calendar you manage, and one of them is the boss. What do you do?" | CASE | [generic] | Structure it: what you would ask first, who you would tell and when, what you would confirm in writing, and what you would put in the diary. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's calendar line, which is F1's requirement |
| B2 | "Your manager needs to be in two cities on consecutive days next month, on a tight budget. What do you need to know first, and how do you book it?" | CASE | [generic] | Clarify first: dates, fixed meetings, budget, preferences and who approves spend. Then give options, confirm the choice, share an itinerary and say what you would do if a booking falls through. No claim about your past | F2's requirement as a live problem, so the answer does not depend on having booked travel before |
| B3 | "An invoice arrives that does not match what was agreed. What do you do?" | CASE | [generic] | Check what was agreed and what was received, hold the invoice rather than pay or approve it, tell the person who ordered, query it with the supplier and keep a record. No claim about your past | F4's requirement as a live problem on the supplier side |
| B4 | "Your manager sends a rough list of figures and wants a one-page summary in Excel by tomorrow. How do you approach it?" | CASE | [generic] | Clarify the audience and what the page is for, then structure it, check the totals and say what assumptions you made. Keep to what you can do in Excel; if a step is beyond it, say so and say how you would get it done. No claim about your past | F3's Excel limit makes this a likely live test |
| B5 | "You need to send the same letter to thirty suppliers, each with their own name and amount. How do you do it?" | CASE | [generic] | Say how you would approach it: what you would set up first, how you would check each letter and how you would avoid sending the wrong amount to the wrong supplier. If you know a specific Word feature for this, name it; if not, say how you would find out. No claim about your past | F3's Word requirement as a live problem |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: how did you get to where you are?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Build a 90-second arc from one fact: "two years as a receptionist at a physiotherapy clinic." Then say in your own words how you came to apply for this role. Answer slot: the reason for applying is yours to give, so do not borrow one from this pack | The opener is near-certain and casual questions are scored. F1 and F4 draw on the same background |
| C2 | "How do you find Excel? What do you use it for?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say it in your own words and keep your rating: "I'm good with Word, okay with Excel." Answer slot: if you have used Excel for something, name it; if you have not, say so plainly | F3's Excel limit raises a casual probe in the friendly register |
| C3 | "What would a good first month look like for you?" | JD | [generic] | Name what you would want to learn first, who you would ask, and which of the four duties you would ask to see first. No claim about your past | A casual question that scores whether you have thought about the job |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Four physios. Was that the whole clinic's book, or only theirs? What exactly was yours?" | EXP | [grounded] "I ran the appointment book for four physios" | Defend the number in your own words: how the four was counted, what it depends on, which assumption you would defend least, and which part was yours. Answer slot: if anyone else shared the book, or the four changed over time, say so plainly | The one figure in the material gets probed for attribution. F1 is the row it supports |
| D2 | "Tell me about a time an unpaid invoice got resolved after you chased it." | EXP | [grounded] "chased unpaid invoices" | Story-mapped on F4 only to the beat the quote states: you chased unpaid invoices. Answer slot: if a particular case comes to mind, say who you contacted and what happened, in your own words; if none does, say so plainly and describe the chasing as you did it | F4 is the evidence for the invoice requirement, and an open prompt asks you to choose the instance |
| D3 | "Give me an example of something you have done in Excel." | EXP | [grounded] "I'm good with Word, okay with Excel" | Answer slot: if an example comes to mind, say what it was and which part was yours; if none does, say so plainly and say what you would practise first. Keep to "okay with Excel" and do not widen it | F3's limit makes a request for an example likely |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Two colleagues both tell you their request is urgent. How do you handle that?" | CASE | [generic] | Ask what each deadline is tied to, tell both what you are doing and why, and raise it with the person who sets priorities if the two cannot both be met. No claim about your past | A collegial version of the calendar and workload objection, tied to F1's requirement |
| E2 | "How do you like to get instructions, and how do you tell me when something I have asked for cannot be done?" | CASE | [generic] | Say what you need to start well, such as the purpose, the deadline and who it is for, and how you raise a problem early with an option attached. No claim about your past | Tests working style with the person you would support |

## Requirement coverage

| Requirement | Questions | Fit row |
|---|---|---|
| "managing calendars" | A5, B1, D1, E1 | F1 |
| "booking travel" | A2, B2 | F2 |
| "preparing documents in Word and Excel" | A1, B4, B5, C2, D3 | F3 |
| "processing supplier invoices" | A3, B3, D2 | F4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of calendars, travel, documents and invoices would I pick up first?" | It shows you are thinking about starting well, and it tells you what to practise before day one |
| R2 | "What tools do you use for the diary, for travel and for invoices?" | It shows you think about systems, and the answer tells you what to practise |
| R3 | "How does work reach this role: email, a shared folder, a task list? And who decides when priorities clash?" | It shows you already expect clashes and want a clear way to handle them |
| R4 | "How many people would I be supporting, and what does a typical week look like?" | It tells you the real load, and shows you are sizing the job honestly |
| R5 | "What would good look like after three months, and how would you tell?" | It converts the interview into a conversation about success, and gives you something to aim at |
| R6 | "What happens after this call? Is there another stage, and is it also by video?" | It tells you what to prepare for next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars across the office | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: the material says the appointment book, not calendars in general |
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: the material says chasing, not processing supplier invoices. A3's slot stays inside the chasing |
| Advanced Excel skills | Inflated form of F3 | F3's quote at its own scope: "okay with Excel." D3's slot asks only for an example you can name |

## Sources

Provided documents: your message, which holds the invite, the ad as you described it, and your background. No dossier was present.

Searches sent: "Brennock Facilities Ltd values", "Brennock Facilities Ltd interview process remote administrative assistant" and "Brennock Facilities Ltd news". All three were refused, so nothing from outside your message is used anywhere in this pack.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Every call was refused. It would have fed a values cheat sheet, which section 10's condition does not call for here, and the VAL bank |
| 2. `Brennock Facilities Ltd interview process remote administrative assistant` | unavailable | Every call was refused. It would have checked the loop structure; the persona weights rest on the invite's own description |
| 3. `Brennock Facilities Ltd news` | unavailable | Every call was refused. It would have fed CO questions, so none is built |
| 4. interviewer name and company | n/a | The invite gives no name, only "our office manager", so no query could be formed; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad as you described it fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → the four paraphrased requirement rows become quoted ones, and any mid-list duty the paraphrase left out gets a question
- Whether the office manager would be your manager or a peer → persona weights recomputed, and a reciprocity reverse question if a peer
- Your CV → evidence cells move from sentences in your message to CV lines, and F1 to F4 get regraded on what the CV carries
- Your own answers to the slots in F2 and F4 → those rows and their questions regenerate from your words
- Search access, or anything you find on the employer's own website → values, loop structure and company questions replace the generic ones
- A tuesday-dossier.md → verified evidence and absolute prohibited claims carried into the pack
