I've read the interview-prep playbook and I'm now running three quick searches on the company: its values, its interview process, and recent news. Then I'll write the prep pack.
Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says successful candidates get "a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor". Requests like these, before any interview or offer, are a known scam pattern, and the fee, the passport and bank details request, and the cheque arrangement are very likely a scam. Hold all of it (paying, depositing a cheque, sending your passport or bank details) until you've checked the invite with the employer it names, using contact details you find yourself on its own website or careers page, not the email address, number or answers from the sender. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `Brennock-Facilities-Ltd_remote-administrative-assistant_interview_pack.md` in `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-5/rooms/case-12-denied-bb174c58/`. I built it for a 30-minute call with the office manager, treating them as a hiring manager since you didn't say. My three company searches were refused, so it rests only on your message and has no company research. It has 18 practice questions, and **B2** is the one to rehearse first: how a front-desk background gets you ready for invoices and Excel.

Say the word and I'll play the Skeptic on B2, live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager likely to be your line manager or more of a peer? The answer reweights every question bank.
Can you paste the ad's full text? I built from your four-duty summary, and the full text would let more rows quote the ad itself.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities-Ltd_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interviewer:** the office manager, name not given. **Format:** a 30-minute video call, from your message. **Relationship:** not stated, so the pack is built on a hiring-manager prior; if the office manager is a peer or someone else, the persona weights change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims about your work survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company and its direction |
| CASE | How you reason through a live problem from the role |

No VAL or CO questions appear. No values-style round is documented, and no company research ran (see Sources).

Provenance labels: grounded means traceable to something you wrote or a cited source; inferred means derived from a thinner source, with the derivation named; generic means a pattern for the role, with no claim about you or this employer.

Guidance is scaffolding, not a script. Say it in your own words. An answer slot is an instruction for the interview, not a question for me: answer it from your own experience, and if the honest answer is that the step was not yours or did not exist, say that plainly.

## Fit snapshot

Requirements are the ad's duties as you described them in your message. Evidence is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it in your message | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it in the sentence's own terms: "I ran the appointment book for four physios." The sentence says the appointment book, and the words stay there. Expect a probe on what kept the book in order; C2 holds that slot |
| F2 | "booking travel" — the ad, as you described it in your message | none given | none | [grounded] | discovery | Your material shows no travel booking, and you have not said there was none. Answer slot: the ad's travel line makes a probe on travel you have arranged likely. If you have arranged any, for anyone, say what, in your own words; if you have not, or it was not yours, say so plainly and stay with the appointment book. A2 rehearses the live version |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it in your message | "I'm good with Word" — your message | medium | [grounded] | presentation | Say the level in those words: "I'm good with Word." The sentence states a skill level, not documents prepared, so add nothing about what the documents were. A5 holds the slot |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it in your message | "okay with Excel" — your message | low | [inferred] | discovery | Inferred from a self-rating with nothing behind it. Words: "I'm okay with Excel." Answer slot: the ad lists Excel among the document tools, so expect a probe on what you have done in it. If you can name a task, say it in your own words; if you cannot, or it was not yours, say so plainly and say the level, okay |
| F5 | "processing supplier invoices" — the ad, as you described it in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Words: "I chased unpaid invoices." Your material says chasing, and does not say whose invoices they were. Answer slot: the ad's invoice line makes a probe on the invoices you handled likely. If you can say whose they were and what part of the work on them was yours, say so in your own words; if you cannot, or it was shared, say so plainly and stay with "chased unpaid invoices" |

## Persona table

The loop is one call with the office manager, from your message, so the weights rest on that and on the round-type prior for a manager, not on any documented process at this company.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live tasks: a diary clash, a trip to book, an invoice that does not match, a messy list to tidy | High. The ad lists four concrete duties, and a hiring-manager prior puts live problems first. The call is 30 minutes, which leaves room for a handful of scenario questions | Ask before answering: what is fixed, what can move, who decides. Then propose, say how you would confirm, think aloud. Cases ask about no past, so they need no claims |
| Skeptic | Quiet probing of the step from front desk to the ad's invoice, Excel and travel lines | High. F2, F4 and F5 are where your material is thin or silent, which is where the call is most likely to turn | Rehearse B2 until it is boring. Bridge only from B2's quotes. Say limits through the slots, plainly |
| Conversational | A friendly "tell me about the clinic" that is still scored | Medium. A short single call often opens this way, and nothing in what you shared says otherwise | Rehearse the C1 arc aloud at 90 seconds. Treat casual questions on Word and Excel as scored |
| Peer Evaluator | "What would you need from me, and what can I count on you for" | Low. It rises if the office manager is a colleague rather than your line manager, which I have asked about | Reciprocity framing: what you bring as well as what you need |
| Pressure | "Sixty seconds, why you" and "how much of that was you" | Low. Nothing in what you shared signals a stress style, but compact calls compress the why-you question | Pause, restate the question, hold your sentences through two follow-ups, concede only what is true |
| Data-Driven Prober | Line-by-line on the figures | Low. Your material carries one figure, four physios | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |

## Question banks

Highest-ROI prep: **B2**. A front-desk background set against the ad's invoice and Excel lines is the objection most likely to arrive in some form.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people you support both need the same hour on Thursday: your manager, and a client who has travelled in. Talk me through what you do." | CASE | [generic] | Ask first, then propose. Which of the two meetings can move, and what is fixed. Who decides when it is your manager's call. What each person must be told, and when. Offer one option with its cost, say how you would confirm it in writing, and say what you would record. A live problem: the guidance makes no claim about your past | The ad's calendar line (F1) as a decision rather than a record. CASE because it is live; generic because it is a pattern, not a fact about this employer |
| A2 | "A manager needs to be in another city on Tuesday morning for two meetings and back that evening. What do you ask before you book anything?" | CASE | [generic] | Ask: meeting times and places, how firm they are, how the traveller prefers to travel, the spend limit and who signs it off, whether the ticket needs to be changeable. Then offer two options with the trade-off between time and cost, confirm before booking, and send one clear itinerary. No claim about your past | F2 is silent in your material, so the live version is what gets rehearsed. CASE because it is a live problem |
| A3 | "A supplier invoice arrives for €1,240. The order your manager placed was for €1,140. What do you do?" | CASE | [generic] | Do not pay or reject yet. Check the order and what was delivered, find where the difference comes from, ask whoever placed the order, and keep a note. Tell your manager the difference, what you found and what you would do next, and ask before paying. No claim about your past | The ad's invoice line as a live problem, because F5 carries chasing and not the handling of an incoming invoice. CASE because it asks about no past |
| A4 | "I give you a messy list of suppliers and amounts and I need to see what we owe each one by tomorrow. How do you go about it in Excel?" | CASE | [generic] | Clarify what the manager will decide with it, what each column holds, whether a supplier appears under more than one spelling, and whether it covers one period. Describe your approach in plain terms at your own level, and where you would need to look up a feature, say so. Check the total against the source before handing it over. No claim about your past | F4 is the thinnest document-skill row, and this question scores structure over tool names. CASE because it is a live task |
| A5 | "You said you're good with Word. What do you use it for?" | JD | [grounded] "I'm good with Word" | Say it as you did: "I'm good with Word." Answer slot: the ad lists preparing documents in Word, so a probe on the documents themselves is likely. If you can name what you have made in it, say so in your own words; if there is nothing to name, say so plainly and stay with "I'm good with Word" | F3 is a self-rating, which makes it the likeliest place for a probe. JD because it scores a stated duty |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "okay with Excel"; "chased unpaid invoices" | Pick the part that is true and say it plainly. What your material carries is a level, "I'm okay with Excel", and the work, "chased unpaid invoices". Then a ramp said as a plan, never as a past: what you would practise first and who you would check your first pieces with. Answer slot: if the weakest part is travel or the invoices, say which and what you have and have not done with it, in your own words; if you have not, say so plainly | F2, F4 and F5 are where evidence is thin or silent. JD because it scores the listed duties, in the Skeptic's register |
| B2 | "Your background is front desk at a clinic. How does that get you ready for a job with supplier invoices and Excel in it?" | JD | [inferred] "two years as a receptionist at a physiotherapy clinic"; "ran the appointment book for four physios"; "chased unpaid invoices"; "okay with Excel" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry, in your own words: two years as a receptionist at a physiotherapy clinic, you ran the appointment book for four physios, you chased unpaid invoices, you are okay with Excel. Then stop and let the interviewer draw the line to the job. Hold through two follow-ups by returning to those sentences, never by adding to them. The limit, as the pack reads your material: it says chasing and an Excel level, nothing wider, so stay inside that. Answer slot: if any of your invoice work went beyond chasing, say what and which part was yours; if it did not, say so plainly and say what you would learn first, as a plan | F4 and F5 are where this objection presses hardest, so it arrives in some form. JD because it scores the stated duties against the background |
| B3 | "You said you chased unpaid invoices. Walk me through how that worked." | EXP | [grounded] "chased unpaid invoices" | Story-mapped on F5, with only the beats the sentence states: there were unpaid invoices, and you chased them. Tell those two in your own words. Answer slot: the ad's invoice line makes a probe on whose invoices they were likely. If you can say whose, and what part of the work on them was yours, say so in your own words; if you cannot, or it was shared, say so plainly and stay with "chased unpaid invoices" | F5 is your only invoice evidence and the likeliest place to be probed. EXP because it tests what was actually yours |
| B4 | "What makes you want this job rather than another reception post?" | JD | [generic] | Your reason is yours: the material you shared carries none, so the pack supplies none. Say your actual reason in your own words, tie it to something the ad lists (calendars, travel, Word and Excel documents, invoices), and keep it about the work. Rehearse it aloud until it takes under 30 seconds | The Skeptic's why-here probe. F1 and F5 are front-desk evidence, which makes the move the obvious thing to ask. Generic because it holds no claim about your past |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about the clinic: what was your job there?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word, okay with Excel" | A 90-second arc with only the beats the quotes state, in your own words: two years as a receptionist at a physiotherapy clinic, you ran the appointment book for four physios, you chased unpaid invoices, you are good with Word and okay with Excel. Finish with why you want this job in your own words, which B4 rehearses. The pack adds no further clinic detail; add only what you can stand behind | The biography question is asked in almost every call and is scored even when it sounds casual. It draws on F1, F3, F4 and F5. EXP because it tests what you did |
| C2 | "Tell me about the appointment book: what did you do with it day to day?" | EXP | [grounded] "ran the appointment book for four physios" | Story-mapped on F1: you ran the appointment book, and it was for four physios, which are the beats the sentence states. Answer slot: the ad's calendar line makes a probe on what kept the book in order likely. If you can say which parts of keeping the book were yours, say so in your own words; if you cannot, or it was shared, say so plainly and stay with "I ran the appointment book for four physios" | F1 is the evidence for the calendar line and where it will be tested. EXP because it scores what was actually yours |
| C3 | "What are you actually using Excel for these days?" | JD | [inferred] "okay with Excel" | Say the level as your sentence has it: "I'm okay with Excel." Answer slot: if you use it for something now, say what, in your own words; if you do not, say so plainly and stay with the level | F4 is the thinnest document row, and a friendly register is where it surfaces. JD because it scores a stated duty, asked casually |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What would you need from me in your first month, and what could I count on you for?" | JD | [generic] | Reciprocity framing. What you need: priorities in order, who signs things off, a worked example of how things are done, a person to ask. What you offer: telling the interviewer early when something is unclear, and confirming requests in writing. These are commitments for the job, said as plans, not claims about your past | A peer prices what a hire costs and contributes. Generic because it carries no claim about you |
| D2 | "Two managers each tell you their request is urgent. How do you decide what comes first?" | CASE | [generic] | Ask what each deadline is and what depends on it, and whether one request is blocked on the other. If they are still tied, put the choice to the two managers together with your suggestion and the reason, rather than choosing in silence. Say what you would tell each. No claim about your past | The seam question, asked as a live problem. CASE because it asks about no past |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over another candidate?" | JD | [grounded] "ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word, okay with Excel" | Hold, then concede. Pause and restate the question. Hold the three sentences in your own words, at their own scope, through two follow-ups by returning to them, never by adding. Concede explicitly where they stop: an Excel level of okay, and invoice chasing. Never fold on the sentences themselves to restore the mood. Answer slot: if there is a reason beyond these, say it in your own words; if there is not, say so plainly and stay with the three | The Pressure persona's standard stem. F1, F3, F4 and F5 are the evidence. JD because it scores fit against the listed job |
| E2 | "That appointment book: how much of that was actually you?" | EXP | [grounded] "ran the appointment book for four physios" | Hold the sentence: "I ran the appointment book for four physios." Answer slot: if you can say which parts were yours and which were shared or set by someone else, say so in your own words; if it was shared, say so plainly and stay with the sentence. Concede only what is true, and specifically | An attribution probe on F1, the sentence that carries the calendar line. EXP because it tests ownership |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Four physios: how did you come to run the book for all four, and what was your part?" | EXP | [grounded] "ran the appointment book for four physios" | Say the figure as the sentence has it: four physios. Answer slots a figure raises, each in your own words: how the four was counted, such as whether all four were there for the whole time; what the figure depends on; the assumption behind it you would defend least; which part was yours. If you do not know any of these, say so plainly and stay with "ran the appointment book for four physios" | The one figure in your material, F1, is where a prober starts. EXP because it tests attribution |
| F2 | "You said you're okay with Excel. Where does okay stop?" | JD | [inferred] "okay with Excel" | Name, in your own words, the part of "okay" you would defend least before they ask; if you do not know where it stops, say so plainly. Answer slot: if you can name a task you have done in Excel, say so; if you cannot, say so plainly and stay with "I'm okay with Excel" | F4 is a vague self-rating, and a prober asks for its edge. JD because Excel is a listed tool |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, C2, E2, F1 |
| "booking travel" | A2 (a live problem only; no sentence of yours covers it) |
| "preparing documents in Word and Excel" | A4, A5, B1, C3, F2 |
| "processing supplier invoices" | A3, B2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you are thinking about outcomes, and the answer tells you what to practise first |
| R2 | "Of the calendars, travel, Word and Excel documents and invoices, which takes most of the week?" | The answer tells you whether F4 or F5 is the row to spend your prep evening on |
| R3 | "How is work handed over in this role, and how do you like to be kept updated?" | It signals you want a working rhythm, and is a natural question for a remote role |
| R4 | "What do the calendars and invoices run on at the moment, and what training is there on it?" | It shows you expect to learn the tools, and tells you what to look at beforehand |
| R5 | "What happens after this call, and is there another conversation?" | A process question, so you know whether to prepare for a second round and when to expect to hear |
| R6 | "What could a new person do in their first month that would genuinely help you?" | A reciprocity question, which turns the call from an assessment into a working conversation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars beyond the appointment book | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the appointment book for four physios, nothing wider |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says chasing unpaid invoices, and does not say whose they were. B3's slot stays inside what you chased |
| Prepared documents in Word for a team or manager | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word." The limit is the pack's observation: your material states a level, not documents |
| Strong or advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "I'm okay with Excel." F2's slot asks only what you have done in it |

## Sources

Provided documents: your message, covering the invite's wording, your description of the ad's duties, and your background. No dossier was present.

Searches sent, each refused, so none returned a result:

- "Brennock Facilities Ltd values" — refused
- "Brennock Facilities Ltd interview process administrative assistant" — refused
- "Brennock Facilities Ltd strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. It would have fed a values cheat sheet and VAL questions; no values-style round is documented, so the cheat sheet is absent either way |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | The search was refused. It would have checked the loop structure; the persona weights rest on your own account of one 30-minute call with the office manager |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | The search was refused. It would have fed CO questions and a grounding brief, both absent |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | Your description of the ad's four duties fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F5's requirement cells come from your summary of the ad, so the full text would let them quote the ad itself and show any duty your summary left out
- Whether the office manager would be your line manager or a peer → reweights every bank and the reverse questions
- The office manager's name → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to their path
- Web research, since the three searches sent were refused (a deeper pass would be up to 6 more searches and 2 more fetches, several more minutes) → company values, process and strategy, turning the generic rows into grounded ones and adding CO questions and a grounding brief
- Any task you did in Excel at the clinic, or any travel you have arranged for anyone, in your own words → F4 and F2 become quoted rows, and the Excel and travel answers stop being slots
- A `tuesday-dossier.md` → verified evidence, prohibited claims and the highest-ROI objection drawn from evidence instead of inferred
