Searches were refused, so I'm building the pack from what you pasted. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-5/rooms/case-13-denied-915ef8b4/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for the recruiter screen exactly as Hannah described it, around her four topics. The three web searches I tried were refused, so nothing about Quillmoor beyond the advert is in it. The pack lists this and what it would add.

The question most likely to be asked is B2: "You schedule deliveries for three depots, and this role coordinates production schedules with planning, the warehouse and QA. How do you see the step across?" Your material says deliveries, not production, so the pack has you say that plainly and stay with what you actually do.

Say the word and I'll play the Skeptic on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Hannah has your notice period on her list and it isn't in what you've shared: what is it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen with Hannah Lowther (Talent Partner), a 30-minute phone call on Thursday at 2pm. She has said she will cover salary expectations, notice period, how the hybrid pattern would work, and what is prompting a move, then tell you about the team and next steps.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it tests |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its strategy |
| CASE | How you structure a live problem |

Question IDs run A to E, then G, so they never collide with the fit-snapshot rows F1 to F12.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: the four years, the role, the wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of that scheduling ran through a planning or QA function, say how, in your own words; if it did not, say so plainly and stay with the depots |
| F3 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you schedule deliveries and chase suppliers when orders slip |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a probe on how it was counted. Keep the quote's scope, including "about": the spreadsheet was rebuilt and discrepancies fell by about a third over a year. The defend-the-number slots are in C1 and D2 |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: the advert's weekly on-time-dispatch line makes a probe on reporting likely. If you produce any regular report today, say what it covers and how often, in your own words; if you do not, or none covers dispatch, say so plainly and stay with the deliveries you schedule |
| F6 | "Confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, and does not say which tool, so the bridge is not stretched. Answer slot: the advert asks for Excel, so expect a probe on what you use it for. If the stock-count spreadsheet was in Excel, say what you did in it, in your own words; if it was in another tool, or you have not worked in Excel, say so plainly |
| F7 | "ERP experience (SAP or similar) a plus" — the advert, SAP named | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. The advert calls it a plus, so it is a risk to name, not a gate |
| F8 | "ERP experience (SAP or similar) a plus" — the advert, "or similar" | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | The sentence says "we run our own in-house stock system", and does not say whether you work in it or for what. Answer slot: the advert says "or similar", so expect a probe on whether the in-house system counts. If you work in it, say what for, in your own words; if you do not, or it is not an ERP, say so plainly |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Gate shown met: your figure sits inside the advertised band. Use your own words, at their scope: "I'm hoping for £42,000." |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Gate shown met on the two days. Use your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| F11 | "what's prompting a move" — Hannah's LinkedIn message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. Your own sentence is the answer, and the words stay in it, whole |
| F12 | "your notice period" — Hannah's LinkedIn message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Surfaced, not bridged: give it as it stands when she asks |

## Persona table

Weights are a shown judgment: change them if you know something the pack does not. Hannah's message establishes the loop for this pack: one 30-minute phone call with her, on four named topics. No values-style round is detected, so no archetype fallback is used.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A, 5 questions) | Friendly, unstructured, covering her four listed topics | High: the recruiter-screen prior is Conversational first, and A1 to A5 follow her message item by item | A 90-second arc built from the quotes in A1; treat each casual question as scored |
| Skeptic (B, 4 questions) | Quiet probing of the advert lines your material is thin on | Medium-high: the recruiter-screen prior adds a light Skeptic, and F2, F5, F7 and F8 are the thin rows | Rehearse B2 until it is boring; hold what the quotes carry and use the slots where they do not |
| Data-Driven Prober (C, 3 questions) | Reads the application line by line and asks how a figure was counted | Medium: F4 carries the one figure, and Excel and ERP are listed in the advert | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure / Stress (D, 2 questions) | Time-boxed challenge, "how much was actually you" | Low: nothing in Hannah's message suggests it, but a 30-minute call invites a sixty-second question | Pause, restate, hold the sentence you actually said, concede only what you do not know |
| Values / Behavioral (E, 2 questions) | "Tell me about a time" prompts | Low: no values round is detected and no published values are in hand, so the themes come from the advert's supplier-chasing line and a standard stem | Choose an occasion with a stake and an ending, or say plainly none comes to mind |
| Case / Strategist (G, 2 questions) | Short live problems from the role | Low: more likely with the hiring manager, but the advert's three functions invite one | Clarify, state the objective, give options, say who you would tell, then how you would record it |

The highest-ROI prep in this pack is B2: it is the objection aimed at the advert's central line, in the place your material is thinnest.

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F1, F3 and F4: the four years as a logistics coordinator at a building-supplies wholesaler, the deliveries you schedule for three depots, chasing suppliers when orders slip, and the stock-count spreadsheet you rebuilt. Each beat is a clause the quotes state; tell them in your own words in about 90 seconds, then close on your reason from A5 | The biography question opens most recruiter screens and is still scored; EXP because it tests what was actually yours |
| A2 | "What are you looking for salary-wise?" | JD | [grounded] "I'm hoping for £42,000." | Your own words, whole: "I'm hoping for £42,000." Say it once, at that scope. If she asks what you earn now, you can redirect to the role and the advertised band; nothing in your material decides whether you answer, so choose before Thursday | Salary expectations are first on Hannah's list, and F9 holds your figure; JD because it scores the listed job's terms |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, in your own words, as your contract states it. Your material does not carry it, so the pack supplies none | Notice is on Hannah's list and F12 shows it unestablished; JD because it is a term of taking the job |
| A4 | "The role is two days a week at Avonmouth on a hybrid pattern. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the commute, your own words were: "I live in north Bristol, so two days at Avonmouth is fine" | The hybrid pattern is on Hannah's list, and F10 holds your stated limit; JD because it scores the advert's stated pattern |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words, whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she presses on the Reading offer, your own words were: "the only offer is relocating to Reading, which I don't want." Say it and stop | The reason for leaving is on Hannah's list, and F11 holds your sentence; EXP because it tests what is actually driving the search |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name it before she does, using only what your sentence says. Hold: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past, in your own words. The advert lists SAP or similar as a plus, not a requirement | F7 is the one gap you have stated yourself, so it is the safest honest answer; JD because it scores the listed qualifications, gaps included |
| B2 | "This role coordinates production schedules between planning, the warehouse and QA. You schedule deliveries for your three depots — how do you see the step across?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I schedule deliveries for our three depots." State the difference plainly: the advert says production schedules, and your sentence says deliveries. Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of your scheduling ran through a planning or QA function, say how, in your own words; if it did not, say so plainly and stay with the depots. Hold through two follow-ups by returning to the depots, never by adding to them. Likely follow-up 1: "What would you need from planning and QA in your first month?" Answer it as a plan, with no claim about your past. Likely follow-up 2: "What if the warehouse and QA want different things on the same day?" Structure it: ask what each needs and by when, find what can move, tell both, record the decision | F2 is where the advert's central line presses hardest, so this objection arrives in some form; JD because it scores the stated responsibility |
| B3 | "The role reports weekly on on-time dispatch. What would that look like for you?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you produce any regular report today, say what it covers and how often, in your own words; if you do not, or none covers dispatch, say so plainly and stay with "I schedule deliveries for our three depots and chase suppliers when orders slip." Then say how you would set a weekly report up, as a plan and not a past | F5 is the one requirement your material is silent on; JD because it scores a stated responsibility |
| B4 | "Your Bristol office is closing and Reading is the only offer. Why this role, rather than another employer?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Start from your own sentence, whole. Answer slot: the advert's lines are what she will expect you to speak to. If something in them draws you, say what, in your own words; if nothing specific does, say so plainly and say what led you to apply | A reason that is about leaving something invites the question of why this role; F11 holds the sentence, and EXP because it tests motivation consistency |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third — how was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you can, at its scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of the fall was yours. If you do not know how it was counted, say so plainly. The pack supplies no method, baseline or attribution | F4 carries the one headline figure, and a figure is where a prober starts; EXP because it tests attribution and honesty about the count |
| C2 | "How comfortable are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the stock-count spreadsheet was in Excel, say what you did in it, in your own words; if it was in another tool, or you have not worked in Excel, say so plainly. The sentence says spreadsheet, so go no further than that | F6 is a requirement the evidence touches without reaching; JD because the advert states it |
| C3 | "SAP or similar is a plus here. What systems, if any, have you worked in?" | JD | [inferred] "Never used SAP — we run our own in-house stock system." | Answer slot: if you work in the in-house stock system, say what for, in your own words; if you do not, or it is not an ERP, say so plainly. Alongside it, the stated negative: "I haven't used SAP." | F7 and F8 are the two ways the advert's ERP line can go; JD because the advert states it |

### D. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Hold then concede, on what the quotes carry. Hold: the four years as a logistics coordinator, the deliveries you schedule, chasing suppliers when orders slip. Concede only what you have stated: "I haven't used SAP." Describe what you did and let her draw the inference. Sixty seconds, no more | A time-boxed pitch is the recruiter-screen form of a pressure question; F1 to F3 and F7 are what it draws on; JD because it scores fit to the listed job |
| D2 | "That drop in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold through two follow-ups by returning to your sentence: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Answer slot: which part of the fall was yours; if part was shared, or the figure was not yours alone, say so plainly. Concede what you do not know, such as how it was counted, specifically, and do not fold on the sentence itself | F4's figure is the one attribution probe in the pack; EXP because it tests what was actually the candidate's |

### E. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supplier let you down." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold, because your sentence carries the practice and no particular occasion: pick one occasion when an order slipped. It needs a named order or delivery, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." | The advert's chase-late-orders line is the raising source, and F3 is the row; VAL because it tests behavior, not knowledge |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you gave senior people unwelcome news. It needs a named stake, a moment you did not soften it, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then say how you would handle it | A standard behavioral stem, kept because no published values are in hand and no values round is detected; `[generic]` because it is a pattern, not a fact about this employer |

### G. Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "It's 3pm. A supplier tells you tomorrow's delivery, which QA needs before a production run, will be two days late. What do you do first?" | CASE | [generic] | Structure it: what you would ask first (what is in the delivery, what depends on it, how firm the two days is), the objective (protect the schedule), the options (part delivery, another source, reschedule), who you would tell and when (planning, the warehouse, QA), and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's three functions; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| G2 | "On-time dispatch dropped this week. Where do you look?" | CASE | [generic] | Structure it: ask how on-time is defined and over what period, then split the drop by stage (supplier lateness, warehouse, QA hold), decide what you would check first, and say how you would report it. No claim about your past | A diagnosis question from the advert's weekly-dispatch line; `[generic]` because it is a pattern |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| 2+ years in operations or logistics coordination | A1, D1 |
| Coordinate production schedules between planning, the warehouse and QA | B2, G1 |
| Track supplier deliveries and chase late orders | E1, G1 |
| Keep stock records accurate | C1, D2 |
| Report weekly on on-time dispatch | B3, G2 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, C3 |
| £38,000–£44,000 | A2 |
| Hybrid, two days a week at Avonmouth | A4 |
| Hannah's items: notice period, what is prompting a move | A3, A5, B4 |
| Company and strategy knowledge | none: no research ran and nothing about Quillmoor beyond the advert is in hand, so a CO question would be invented |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Who would I work with day to day across planning, the warehouse and QA?" | Those are the three functions the advert names; it shows you read the role |
| 2 | "How is on-time dispatch reported at the moment, and who reads the weekly report?" | The reporting line is the one the advert makes and your material is silent on, so the answer shows what the job really asks |
| 3 | "Which system does the team work in, and how is new people's training handled?" | SAP or similar is a plus, so the answer tells you how much that line matters |
| 4 | "What would the first month in the role look like?" | A concrete first-month picture lets you test your fit against the actual work |
| 5 | "After this call, what are the next steps and roughly how long between them?" | Hannah said she would cover next steps; this asks for the timing she may not give |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having used SAP or any other ERP system | Negative you stated, F7 | Your own sentence: "Never used SAP — we run our own in-house stock system." The plain acknowledgment is "I haven't used SAP." |
| Coordinating production schedules with planning and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries, not production schedules. B2's slot stays inside the depots |
| That your rebuild alone accounts for the whole fall in discrepancies | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence does not say the rebuild alone accounts for the fall. C1's and D2's slots ask only how it was counted and which part was yours |

## Sources

Provided documents: Hannah Lowther's LinkedIn message, the advert, and your message about your background and what you would tell her. No `tuesday-dossier.md` was present, so the pack was built from these alone.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The call was refused. It would have given the company's published value names for VAL themes. No values round is detected, so section 10 stays out either way |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Hannah's message fixes the one session and its four topics, which decide the persona weights |
| 3. `Quillmoor Diagnostics strategy news Avonmouth Bristol` | unavailable | The call was refused. It would have supported a CO question on current priorities; the upgrade menu offers it |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The call was refused. It would have supported an interviewer read and a reverse question tied to her path |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, by query: `Quillmoor Diagnostics company values` (refused); `Quillmoor Diagnostics strategy news Avonmouth Bristol` (refused); `Hannah Lowther Talent Partner Quillmoor Diagnostics` (refused). Nothing about Quillmoor beyond the advert is in this pack.

## Upgrade menu

- Your application's text or your CV → F1 to F4 can quote the application's own wording instead of your message alone
- Your notice period → A3 and F12 get your own words in place of an instruction
- Web search access, or a pasted About or values page from Quillmoor's site → a CO question grounded in the company's own wording, and the values target's accounting
- Hannah's public professional profile, pasted → an interviewer read and a reverse question tied to her path
- Whether the stock-count spreadsheet is in Excel, whether you report on dispatch today, and what you do in the in-house stock system → F5, F6 and F8 can become story-mapped rows
- A `tuesday-dossier.md` from an earlier session → verified evidence and a named top objection in place of the pack's own inference
