No dossier is present. I'll read the files the playbook names.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 21 questions across seven personas, built for the Thursday panel of Principal Vantongeren and two fourth-grade teachers. I assumed the principal asks as your hiring manager and the two teachers as peers. I had no posting from Halvering itself, so the job requirements beyond the invite come from a representative fourth-grade posting and are labeled as inferred.

Your Social Security number isn't needed for interview prep. I didn't use or repeat it, and it's worth leaving off any resume you send. Your license number stays out of the pack and out of every search I ran.

The question to rehearse most is "You haven't taught fourth grade. What would be hardest about moving up?" The pack builds that answer only from your own sentences.

Say the word and I'll play the Skeptic on that question as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have Halvering's full posting for this role, or anything HR has said about what the panel will cover, such as a sample lesson to prepare? Either would replace the inferred rows with the school's own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** One 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built on this assumption:** the principal is asking as the hiring manager, the two fourth-grade teachers as peers, and no full posting for this school was available, so job requirements beyond the invite come from a representative posting and are labeled `[inferred]`.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Question IDs skip the letter F so they never clash with the fit-snapshot rows (F1 to F8).

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether the claims on your CV hold up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the school's and district's direction |
| CASE | How you structure a live classroom problem |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your CV states the license, the endorsement and the expiry in the invite's own terms, and a fourth-grade classroom falls inside the grades 1–6 range it names. Nothing has been inspected behind the CV line, so confirming the registry entry is yours to do; bring the license details to the interview. The license number is used nowhere in this pack |
| F2 | "Fourth Grade Teacher position at Halvering Elementary School" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Your words: "I've never taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "experience in grades 3 to 5 preferred" — representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | Third grade sits inside the posting's range. Lead with it in the quote's own terms: six years, third grade, a public elementary school in Joliet |
| F4 | "differentiate instruction using assessment data" — representative posting | none given | none | [inferred] | discovery | Your material does not speak to assessment use. Answer slot: a typical posting's line makes a probe on how assessment results shaped your teaching likely. If any did, say what you looked at and what you changed, in your own words; if none did, or it was not yours, say so plainly and say what you would look at first |
| F5 | "communicate regularly with families" — representative posting | "I write a weekly email to families" — your message | medium | [inferred] | none | The quote already reaches the requirement. Lead with it in its own terms: weekly, written, to families. It is an email, so keep it at that and do not widen it to conversations |
| F6 | "work with the grade-level team" — representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your message; "I've never been a team lead" — your message | medium | [inferred] | transferability | Your material says you led the grade level's move, not how you worked with teammates, and the words stay at that: "I led our grade level's move to a new reading curriculum in 2024." Your plain acknowledgment: "I've never been a team lead." Answer slot: a probe on working with teammates is likely. If teammates were part of the move, say how you worked with them, in your own words; if not, or it was not yours to describe, say so plainly and stay with the move you led |
| F7 | "plan and teach reading, writing, math, science and social studies" — representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've run the after-school reading club for the last two years" — your CV | low | [inferred] | discovery | The CV gives the grade, the school type and the club, and does not show which subjects you taught. Answer slot: a probe on each subject is likely. Say which you taught and how, in your own words; for any you did not teach, say so plainly and say what you would do to be ready |
| F8 | "keep clear classroom routines" — representative posting | none given | none | [inferred] | discovery | Nothing in your material speaks to routines. Answer slot: if you set or kept routines, say what they were, in your own words; if not, or they were not yours, say so plainly and say what you would put in place first |

## Reading the interviewer

Only Principal Vantongeren has a public footprint. Nothing is known about the two fourth-grade teachers.

| Item | What the public record shows or implies | Provenance |
|---|---|---|
| Role and path | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] ilprincipalsforum.example/speakers/dolores-vantongeren |
| Published talk | 2025 forum talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 | [grounded] same page |
| Implication 1 | Expect reading-instruction depth from her, not general teaching questions | [inferred] from her reading-specialist years and the talk |
| Implication 2 | Her talk covers grades 3 to 5, so questions about moving from third to fourth grade in reading are likely from her | [inferred] from the talk's grade span |
| Implication 3 | Speak about reading in plain terms about what you did. Do not claim familiarity with weekly reading conferences unless it is true for you | [inferred] from the guardrail on stretching your quotes |
| Mirror opportunities | Her reading path meets two of your sentences: "I led our grade level's move to a new reading curriculum in 2024" (F6) and "I've run the after-school reading club for the last two years" (F7). Offer them at their own scope and let her draw the link | [grounded] on the quoted evidence cells, path from the page above |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet probing of the grade change and of what leading meant | High. The principal reads as a hiring manager, whose priors are Case/Strategist plus Skeptic; F2 is a stated gap, and a panel blend keeps each member's top two personas | Rehearse the single most predictable objection until it is boring; bridge only from what you stated; concede the gap plainly | A (5) |
| Peer Evaluator | Teammates asking what you would need from them and what you would bring | High. Two of three panelists are fourth-grade teammates, whose priors are Peer Evaluator plus Data-Driven Prober | Reciprocity framing: what you bring the team, not only what you need; propose principles for how the team works, never pretend to know its seams | B (3) |
| Case/Strategist | Live classroom and curriculum problems, reading-heavy | Medium. Hiring-manager prior, raised by her reading-specialist path and the district's published literacy plan | Clarify first, then objective, approach, how you would check it, risks; think aloud; challenge one premise respectfully | C (3) |
| Data-Driven Prober | Reading your CV line by line | Medium. Peer prior; every line of your CV is a potential probe | Know what you can and cannot say about each line; say plainly when you do not know | D (3) |
| Values/Behavioral | Questions themed on the district's three published beliefs | Medium-low. The invite documents one panel and no separate values round, so beliefs theme individual questions rather than a whole round | Choose real stories; "we" for context, "I" for your contribution; where none comes to mind, say so plainly | E (3) |
| Conversational | The opening biography question | Low, but it is the first thing they ask and it is scored | A rehearsed 90-second arc built only from your own sentences | G (2) |
| Pressure | A short time-boxed push on the grade change or on attribution | Low. School panels rarely lean on stress, though a short push on F2 or F6 is plausible | Pause, restate, hold the position your quotes carry through two follow-ups, concede specifics plainly | H (2) |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What would be hardest about moving up, and how would you handle it?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack: this question will arrive in some form. Say the fact first, in your own words: "I've never taught fourth grade." Then the adjacent fact at its own scope: six years teaching third grade at a public elementary school in Joliet. Do not describe what fourth grade asks of a teacher as though you have done it. Answer slot: what you think would be hardest. If you know, say it and what you would do about it, as a plan and never as a past; if you do not yet know what differs, say so plainly and name what you would ask the team in your first week. Expect two follow-ups, "what would you do in your first month?" and "what if our team's way differs from yours?" Answer both as plans, return to the third-grade fact when pressed, and concede the gap each time rather than defend it | F2 is the one gap you stated and the invite is for this grade, so it is the likeliest objection; JD because it scores fit to the listed job, Skeptic because it probes the gap quietly |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Choose the gap you are surest of; the open rows are F2, F4, F7 and F8. Name it plainly and say how you would close it, as a plan. Do not pick a weakness you do not have, and do not pick one to sound modest | The Skeptic's standard stem; the open rows give you real material to choose from |
| A3 | "You led your grade level's move to a new reading curriculum. Have you held a team-lead role?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Both sentences are yours, so say both: "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." Answer slot: if there is a difference between leading that move and a team-lead role, say what it is in your own words; if it is only a title, say so plainly. Do not claim the title | F6 holds both statements and an interviewer will test them against each other; EXP because it scores what was actually yours |
| A4 | "A fourth-grade teacher covers reading, writing, math, science and social studies. Where are you strongest, and where do you still have growing to do?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | Reading is the area your quotes touch: the club, after school, two years, and the third-grade years. Answer slot: say which subjects you taught and how, in your own words; for any you did not teach, say so plainly and say what you would do to be ready. Do not claim strength in a subject your quotes do not reach | F7 covers a typical posting's subject list, so this is a likely probe; labeled inferred because the list comes from a representative posting, not this school's |
| A5 | "Why Halvering, why fourth grade, and why now?" | CO | [grounded] | Your reasons are yours and this pack does not supply them. You may refer to the district's three published beliefs (Every Child a Reader; Families Are Partners; Teach for Tomorrow, Not for the Test) and the August 2026 board literacy plan only if they are true reasons for you. If part of the answer is that you want a grade change, say so plainly | The Skeptic's motivation stem; CO because a real reason from public material shows homework, and F2 makes the "why fourth grade" half unavoidable |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role involves working with the grade-level team. What would you need from us in your first month, and what would you bring?" | JD | [inferred] "I write a weekly email to families"; "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity first: what you bring, one sentence each at its own scope, in your own words. Then what you need, framed as questions you would ask the team about how it plans together; do not pretend to know the team's seams | F6 and F5 are the evidence; peers are pricing what a hire adds to their load, and the typical-posting team line is the reason the question is likely |
| B2 | "Tell me about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | No quote of yours carries a disagreement, so pick one: a named subject, what each side wanted, how it ended with the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer Evaluator disagreement stem; scored on spine and tact together |
| B3 | "When a change is shared across a grade level, how do you handle credit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say the sentence at its own scope. Answer slot: if teammates shared the work, say what part was theirs, in your own words; if it was only you, or you do not know the split, say so plainly and stay with the move you led. Never describe a teammate's role you cannot stand behind | F6 is the place credit-sharing probes land; EXP because it scores attribution honesty |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's October and a student in your class is reading well below grade level. Walk me through your first two weeks." | CASE | [generic] | Structure it aloud: what you would ask first (what data exists, what the student reads at), the objective, your approach, how you would check it is working, the risks. Challenge one premise respectfully. This needs no claim about your past, so the guidance makes none | A live problem set in the role, aimed at the principal's reading background and the district's belief that every child is a reader; the pattern is generic |
| C2 | "The district's new grades 3 to 5 reading curriculum arrives in fall 2027. What would you want a fourth-grade team to have ready?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Structure it: what the team needs to know first, a plan for the rollout, how you would check it, risks. Where your own experience applies, it is this sentence at its own scope. Answer slot: if asked what the 2024 move involved, say what it involved, in your own words; if the question assumes more than you did, say so plainly and answer from your structure | The board's August 2026 plan is current strategy few candidates will mention; F6 is your one link to it |
| C3 | "A few weeks in, the class routines aren't holding. What do you do?" | CASE | [inferred] | Structure it: which routines and what is actually happening, two or three hypotheses, one change, how you would check it. Challenge one premise. No claim about your past is needed | F8 is an open row, and a live problem is the safe way to rehearse it; inferred because the routine line comes from a representative posting |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How have you used assessment results to change what you teach?" | JD | [inferred] | No quote of yours carries assessment use, so choose an instance: the result, what you changed, what you saw afterward. If no such time comes to mind, say so plainly, then say what you would look at first. The district's own belief is that assessments inform teaching and never replace it, so frame any answer as informing, not replacing | F4 is open and the district publishes a belief on this; the question is likely from the peers |
| D2 | "Tell me about the reading club you run." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Beats the sentence states: the club, after school, two years. Answer slot: a probe on who comes and how a session goes is likely. Say it in your own words; if there is no set structure, or it works differently from what the interviewer pictures, say so plainly and describe the club as it is | F7; a prober reads the CV line by line and starts with the lines that sound most concrete |
| D3 | "Walk me through the weekly email to families." | EXP | [grounded] "I write a weekly email to families" | Beats the sentence states: weekly, written, to families. Answer slot: a probe on what goes in it and how you decide is likely. Say it in your own words; if there is no particular method, say so plainly and describe it as it is | F5; same prober habit, on the line the district's family belief makes relevant |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our district says no student leaves third grade without a reading plan. Tell me about a time you helped a student who was behind in reading." | VAL | [grounded] "I've run the after-school reading club for the last two years" | No quote carries a story about a student behind in reading, so choose one: no names, the stake, what you did, what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the club at its own scope, or how you would handle it | Themed on the published belief "Every Child a Reader"; F7 is the nearest evidence and it does not carry a struggling-reader story |
| E2 | "Families Are Partners is one of our district's beliefs: each teacher speaks with every family each term. How do you work with families?" | VAL | [grounded] "I write a weekly email to families" | Your words: "I write a weekly email to families." Answer slot: the belief names speaking with every family each term. If you also speak with families directly, say how and how often, in your own words; if the email is your main channel, say so plainly and say how you would make a conversation with each family happen each term | F5 reaches the posting's family line, and the district's version is speaking, not writing, so a probe on the difference is likely |
| E3 | "Our beliefs include teaching for tomorrow, not for the test. Tell me about a time you taught something you knew would not be on a test." | VAL | [grounded] | No quote carries this, so choose a real instance: what it was, why you did it, what the students got from it. If no such time comes to mind, say so plainly, then say how you would decide what to teach beyond a test | Themed on the published belief "Teach for Tomorrow, Not for the Test"; F4 is the related open row |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through your journey to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc, one sentence each at its own scope, in that order, then why fourth grade in your own words. The reason is yours and this pack does not supply it | The opening question of most panels, and scored despite the casual register; F3, F5, F6 and F7 supply the arc |
| G2 | "What are you hoping to try in a fourth-grade classroom?" | JD | [generic] | Name one thing you actually want to try and why, in your own words. If nothing specific comes to mind, say so plainly and say what you would want to learn first | A casual question that scores genuine interest; the answer belongs to you |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you for a fourth-grade classroom, when you've never taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Pause and restate the question. Concede first: "I've never taught fourth grade." Then hold the position the quotes carry: the third-grade years, the move, the club. Hold through two follow-ups by returning to those three, never by adding to them | F2 is the gap a stress interviewer goes for; the hold is only what your sentences say |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the core: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say which parts were yours and which were others, in your own words; if you do not know the split, say so plainly. Concede specifics; never fold on the core claim and never add to it | F6; attribution pressure is the standard test of a "led" line |

### Requirement coverage

| Requirement | Fit row | Questions |
|---|---|---|
| Valid Illinois license with elementary endorsement | F1 | — none, and why: a gate your CV shows met; a license check is a document check, not an interview question |
| Fourth Grade Teacher position | F2 | A1, A2, A5, H1 |
| Experience in grades 3 to 5 | F3 | G1 |
| Differentiate instruction using assessment data | F4 | D1, E3 |
| Communicate regularly with families | F5 | D3, E2 |
| Work with the grade-level team | F6 | A3, B1, B3, C2, H2 |
| Plan and teach the five subjects | F7 | A4, D2, E1 |
| Keep clear classroom routines | F8 | C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How does that show up in the way fourth-grade teachers at Halvering teach reading?" | Tied to her own path; it turns the interview into a conversation between two people who care about reading, and shows you researched her |
| R2 | "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What does a conference look like in a fourth-grade week here?" | Specific to her published work, and the answer tells you what the job expects in reading (F7) |
| R3 | "What does a strong first semester look like for a teacher who is new to fourth grade?" | Puts F2 on the table as a plan rather than a worry, and gets you their definition of success |
| R4 | "The board's literacy plan brings a new grades 3 to 5 reading curriculum in fall 2027. How is the fourth-grade team preparing, and where would a new teammate fit?" | Shows you read the district's current plan, and ties your own curriculum move (F6) to something live |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two teachers: it is what a peer wants to hear |
| R6 | "How does the team use assessment results when it plans together?" | Reaches the open F4 row and signals the district belief on assessment informing teaching |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never taught fourth grade." No slot |
| Has been a team lead | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I've never been a team lead." No slot |
| Chose or designed the new reading curriculum | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says you led the grade level's move, not that you chose or designed the curriculum. H2's slot stays inside the move |
| Ran a school-wide reading program | Inflated form of F7 | F7's club quote at its own scope. The pack's observation: your material says an after-school reading club, not a program. D2's slot stays inside the club |
| Speaks with every family each term | Inflated form of F5 | F5's quote at its own scope. The pack's observation: your material says a weekly email, not conversations. E2's slot stays inside the email |

## Sources

**Provided documents:** the interview invite as pasted; your resume text as typed in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Query 1 returned the district's mission and beliefs page, which was fetched. It supplied the three belief names for E1 to E3; no school-specific values page was returned. No values cheat sheet, because no values-style round is documented |
| 2. `{company} interview process {role family}` | skipped | The invite fixes the loop: one 45-minute panel, run by the principal and two fourth-grade team members. Persona weights and bank structure follow from it |
| 3. `{company} strategy` / recent news | yes | Query 2 returned the board's August 2026 literacy plan: C2, A5 and R4 |
| 4. `{interviewer name} {company}` | yes | Query 3 returned her forum profile: the interviewer read, the Skeptic and Case weights, R1 and R2 |
| 5. representative `{role title}` JD | yes | Query 4 returned a representative fourth-grade posting, which was fetched. It supplies F3 to F8's requirements, labeled inferred, and every JD-tagged question that rests on them |

Queries and results:

1. "Halvering Elementary School Orrinsford Community School District mission values" — https://orrinsfordschools.example/about/mission-and-beliefs
2. "Halvering Elementary School Orrinsford school improvement plan news" — https://orrinsfordschools.example/news/board-adopts-literacy-plan
3. "Dolores Vantongeren principal Halvering Elementary" — https://ilprincipalsforum.example/speakers/dolores-vantongeren
4. "fourth grade teacher job description Illinois elementary school posting" — https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches: the mission-and-beliefs page and the K12 Jobs Board listing above. The listing is a representative posting, not Halvering's own.

## Upgrade menu

- Halvering's own posting for this role: F3 to F8 become quoted requirements from the school's own words, and the JD-tagged questions are retuned
- The two fourth-grade teachers' names or roles: a reading of each panelist and persona weights per member instead of a blend
- Anything HR has said about the panel, such as focus areas or a sample lesson or writing task: coverage built to it, and a build section for any pre-declared deliverable
- Your own answers to F2, F4, F6, F7 and F8: those rows become quoted evidence and their answer slots turn into story-mapped guidance
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, adding a grounding brief on the district and school and deeper reading of the principal's talks
- A tuesday-dossier.md from an earlier fit check: the objection to rehearse most would come from evidence you confirmed rather than from my reading of your material
