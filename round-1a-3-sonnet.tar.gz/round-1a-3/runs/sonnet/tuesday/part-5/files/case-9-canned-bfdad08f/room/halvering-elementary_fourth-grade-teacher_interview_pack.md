# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Round:** one 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Relationship: a hiring-manager seat and two peer seats.
**Highest-ROI prep:** A1, the fourth-grade question. It is the stated gap the panel will see first.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Answer guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether the claims on your CV survive scrutiny; what was actually you |
| JD | The stated responsibilities and qualifications of the job, including its gaps |
| CO | Homework on the district's current strategy and recent moves |
| CASE | A live problem from the actual role, scored on structure and reasoning |

Provenance labels: `[grounded]` traces to a document you provided or a source cited in Sources; `[inferred]` is derived from a representative source (here, a jobs-board listing standing in for Halvering's own posting); `[generic]` is a rehearsal pattern with no claim about you or this employer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your CV states as met. Nothing in the material has been inspected, so expect to be asked to confirm it, and checking your status against the state's own record before Thursday is yours to do. Say it in the quote's own terms: you hold the license and the elementary endorsement, and it runs through June 30, 2029 |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, a representative listing not confirmed as Halvering's own | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your material gives the grade and the years, not which subjects were yours to plan and teach. Answer slot: the listing's five subjects make a probe on subject coverage likely. Say which you planned and taught, in your own words; if some were taught by someone else, or were not part of your grade, say so plainly and stay with the third-grade years |
| F3 | "differentiate instruction using assessment data" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if you have used assessment data to differentiate instruction, say how, in your own words; if you have not, say so plainly and say what you would look at first |
| F4 | "keep clear classroom routines" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if you set or ran routines in your room, say which and what they were for, in your own words; if you did not, or they were set for you, say so plainly and say how you would set routines in the first weeks |
| F5 | "communicate regularly with families" — K12 Jobs Board listing | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you write a weekly email to families |
| F6 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page, Families Are Partners | "I write a weekly email to families." — your CV | medium | [grounded] | discovery | The quote is an email; the page's line is about speaking with families, and the words stay at the email. Answer slot: if you also speak with families, say how and how often, in your own words; if the email is the main way you reach them, say so plainly |
| F7 | "work with the grade-level team" — K12 Jobs Board listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | transferability | The quote says you led your grade level's move; it does not say how colleagues were involved, and the words stay at the quote's scope. Answer slot: if colleagues' views shaped the move, say how and which part was yours, in your own words; if it did not run that way, say so plainly and stay with the move you led |
| F8 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page, Every Child a Reader | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | The quote is the club; the page's line is about reading plans, and the words stay at the club. Answer slot: if you made or used reading plans in your room, say how, in your own words; if there was no such practice, or it was not yours, say so plainly and stay with the club |
| F9 | "assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page, Teach for Tomorrow, Not for the Test | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if there was a time assessment results and your own judgment pointed different ways, say what you did, in your own words; if no such time comes to mind, say so plainly and say how you would weigh them |
| F10 | "experience in grades 3 to 5 preferred" — K12 Jobs Board listing | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | No gap on this line, which is a stated preference in a listing not confirmed as Halvering's own. Lead with the quote's terms: six years teaching third grade |
| F11 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |

## Reading the interviewer

Principal Dolores Vantongeren only. The two fourth-grade team members are not named, so no read is built for them.

| Public fact | Source | What it means for the interview | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page | Reading instruction is her home territory, so expect depth on how students are taught to read rather than surface answers; Banks B and F carry this | [grounded] |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | Illinois principals forum speaker page | Small-group reading and one-to-one conferences are a likely theme in her questions; B3 and R1 are built on it | [grounded] |
| Mirror opportunity: her talk's range, grades 3 to 5, includes the grade you teach | F10: "Six years teaching third grade at a public elementary school in Joliet" — your CV | A shared domain, not a shared jump: you can speak to reading in her grade band in the quote's own terms, and nothing beyond it | [grounded] |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (Bank A, 5 questions) | Quiet, persistent probing of the gaps: never having taught fourth grade, never having been a team lead, why this school and why now | High. You stated two negatives about yourself (F11 and the team-lead line), and the hiring-manager seat's relationship prior is Case plus Skeptic | Rehearse A1 until it is boring: plain acknowledgment, the quoted third-grade years, then a plan said as a plan. Hold through two follow-ups, concede specifically |
| Case / Strategist (Bank B, 4) | Live problems from the role: a reading-instruction scenario, assessment data, routines, the district's literacy plan | High. The district's how-we-hire page says panels ask about reading instruction, classroom routines and how you work with families, and the principal's background is reading specialist | Clarify first, then objective, grouping and approach, how you would check progress, risks. Think aloud; challenge one premise respectfully |
| Peer Evaluator (Bank C, 4) | Two fourth-grade teachers asking how you would work with them, where the seams are, what happens when you disagree | High. Two grade-level teachers sit on the panel per the district's how-we-hire page, and the peer prior is Peer Evaluator plus Prober | Reciprocity first: what you already do that helps their team, then what you would ask of them. Offer seam principles, not a pretended knowledge of their seam |
| Conversational (Bank D, 4) | The friendly opener ("walk us through your journey"), the license confirmation, an open close | Medium. Every panel opens somewhere, and these questions are still scored | A 90-second arc built only from your sentences; treat the casual questions as scored |
| Values / Behavioral (Bank E, 3) | Scenario prompts themed on the district's three published beliefs | Medium. The mission page says the three beliefs guide every hire, but no loop source names a round that assesses values, so none is detected and the cheat sheet is dropped; the beliefs still theme these questions | A selection scaffold for each belief that ends in the honest branch: if no such time comes to mind, say so plainly |
| Data-Driven Prober (Bank F, 2) | Reads the CV line by line and presses on attribution and how you would know | Low. Your material has no figures to defend, so probes would fall on the curriculum move and the reading club | Know what was yours and what was shared; say plainly when you do not know how something was measured |
| Pressure / Stress | Time-boxed, interrupting questions | Low, not banked. Nothing in the sources describes a stress style; a time-boxed "sixty seconds" question could still arrive, and the hold-then-concede structure in A1 and A2 covers it | Pause, restate the question, anchor in what you stated |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What makes you think you can teach fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never taught fourth grade." Then the years in the quote's own terms: six years teaching third grade at a public elementary school in Joliet. Then a plan, said as a plan and never as a past: what you would ask the fourth-grade team to show you first, and what you would learn before the first week. Hold that position through two follow-ups by returning to the third-grade years, never by adding fourth-grade experience; concede specifically what you do not yet know about the grade. Name the limit before it is asked for | F11 is the stated gap and the likeliest place a panel presses, from the principal's seat and from the peers who would share the grade; JD because it scores the stated role, with F10 as the nearest evidence |
| A2 | "You've never been a team lead. How would you contribute to a team of fourth-grade teachers?" | JD | [grounded] "I've never been a team lead" — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Plain acknowledgment first: "I've never been a team lead." Then the quote at its own scope: you led your grade level's move to a new reading curriculum in 2024; tell the beats the sentence states, in your own words. Answer slot: the listing's work-with-the-grade-level-team line makes a probe on how colleagues were involved likely. If they were, say how and which part was yours; if the move did not run that way, say so plainly and stay with the move you led. If asked how leading the move differs from being a team lead, answer from what each involved in your own experience, in your own words | F7 is the closest evidence for team work and the stated negative is where a panel will test it; JD because it scores the team requirement |
| A3 | "Why this school, and why now?" | EXP | [grounded] the Orrinsford Mission and Beliefs page | The reasons are yours and the pack holds none, so none are supplied. Give your actual reasons in your own words, in two or three sentences. If a belief on the district's mission page matters to you (Every Child a Reader, Families Are Partners, or Teach for Tomorrow, Not for the Test), say which and why in your words; if none does, do not pick one | The Skeptic's motivation-consistency probe, which is why-here and why-now; EXP because it tests whether your story holds up. The pack has nothing on your reasons, so it supplies a method, not content |
| A4 | "This job covers reading, writing, math, science and social studies, plus routines and assessment. Which of those would be thinnest for you on day one?" | JD | [inferred] derived from the listing's responsibilities and the rows F2, F3, F4 | Answer from what only you know. The pack's observation is that your material shows the third-grade years for F2 and is silent on F3 and F4, so those are where a follow-up lands. Choose the one that is truly thinnest, name it plainly, and follow with what you would do to close it, said as a plan. If the honest answer is that none is thin, say which you have actually done and one thing you would still ask the team. Never name a weakness you do not have, and never hide one you do | F2, F3 and F4 are the rows with the least evidence; the Skeptic stem "which part of the JD would you be weakest at" applies directly. JD because it scores the stated responsibilities |
| A5 | "One of the district's three beliefs is that no student leaves third grade without a reading plan. You've taught third grade. What did that look like in your room?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | Name the belief by its words from the district's page: Every Child a Reader. Answer slot: the page's no-student-without-a-reading-plan line makes a probe on how you support struggling readers likely. If you made or used reading plans, say how, in your own words; if there was no such practice, or it was not yours, say so plainly and stay with the reading club you've run for the last two years, in those words | F8 is where the district's own page presses hardest on a third-grade teacher; VAL because the raising source is a published belief, EXP in delivery |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's October. Three students in your fourth-grade class are reading well below grade level. Walk me through your first four weeks." | CASE | [generic] | Structure it aloud: what you would ask first (what the students' reading data shows and which assessments the school already uses), the objective for the four weeks, how you would group and teach, how you would bring in families, and how you would check progress and change course. Challenge one premise respectfully, such as what "below grade level" is measured by. The question needs no claim about your past, so the guidance makes none | A live problem on the reading-instruction topic the district's how-we-hire page lists for panels; F3 and F8 are where your material is silent, so structure matters most here |
| B2 | "In August the board adopted a three-year literacy plan with a new grades 3 to 5 reading curriculum from fall 2027. What would you want to know about that before joining a fourth-grade team?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Bring one fact from the news to show your homework: the board adopted a 2026–2029 literacy plan with a new grades 3–5 reading curriculum from fall 2027. Then ask before opining: what the curriculum is, who chooses it, what training and time the fourth-grade team gets. Then one point of your own: what the change means for this year's students before fall 2027. If your own move is relevant, use the quote at its own scope: you led your grade level's move to a new reading curriculum in 2024; tell its beats in your own words and do not compare it to this one | A CO question from a current, public plan that names this grade band; F7 is the nearest evidence on curriculum change. A public item any prepared candidate can recite, so the differentiation is in what you ask |
| B3 | "How would you use assessment data to plan small-group reading?" | JD | [inferred] derived from the listing's differentiate-using-assessment-data line | Structure it: ask what data is in use, say what it tells you and what it cannot, how you would group, how often you would regroup, and where your own judgment overrides it, in the district's own wording: assessments inform teaching and never replace it. Answer slot: the listing's line makes a probe on what you have done likely. If you have used assessment data to group students, say how, in your own words; if you have not, say so plainly and say what you would look at first | F3 and F9 hold no evidence, and the principal's published talk concerned weekly reading conferences in grades 3 to 5; JD because it scores a stated responsibility |
| B4 | "Tell me about the routines that keep your classroom running, and one you would change for fourth grade." | JD | [inferred] derived from the listing's classroom-routines line | The pack holds none of your routines, so choose one you actually run: what it is for, how students learned it, and what you would keep or change for older students. If no routine you designed comes to mind, say so plainly, then give the nearest thing your material does carry or how you would set routines in the first weeks | F4 is a silent row and the district's how-we-hire page lists routines among panel topics; JD because it scores a stated responsibility |

### Bank C: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How do you like to work with a grade-level team, and what would you need from us as the newest member?" | JD | [grounded] "I write a weekly email to families."; "I've run the after-school reading club for the last two years" | Reciprocity first: what you already bring, in the quotes' own terms: you write a weekly email to families, and you've run the after-school reading club for the last two years. Then what you would need, framed as questions about the team's practice (what is shared, what is planned together) rather than claims about the seam. Offer principles, not a pretended knowledge of how they work | F5 and F8 are the evidence you can offer a peer team; JD because it scores the team requirement |
| C2 | "Say one of us and you disagree about how to teach a skill. What happens next?" | CASE | [inferred] derived from the listing's team line | Principles, not a past: ask to see the reasoning and student work first, try the team's approach as written long enough to judge it, then bring your alternative as a proposal with what you would look at to compare. Answer slot: if a real disagreement with a colleague comes to mind, say what it was and what you did, in your own words; if none does, say so plainly and say how you would handle it | The peer stem about disagreement; F7 holds no disagreement evidence, so the pack supplies a method and leaves the story to you |
| C3 | "Tell us about leading your grade level's move to the new reading curriculum. What was your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats the sentence states: you led, it was your grade level's move, to a new reading curriculum, in 2024; tell them in your own words. Say what was yours and what was shared; where some of it was someone else's, say so plainly. Do not call it a team lead role or a school-wide rollout; the sentence says your grade level | F7 is the evidence and credit-sharing is the peer probe; EXP because it tests what was actually yours |
| C4 | "What goes into your weekly email to families?" | JD | [grounded] "I write a weekly email to families." | Describe, in your own words, what you actually put in it; the pack has not seen one. Answer slot: the district's page says each teacher speaks with every family each term, so a probe on conversations beyond the email is likely. If you also speak with families, say how and how often, in your own words; if the email is the main way you reach them, say so plainly and say how you would cover the conversations the district asks for | F5 is the evidence and F6 is the district's wider line; JD because it scores family communication |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk us through the journey that brought you here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | A 90-second arc built only from those sentences, in that order: six years teaching third grade at a public elementary school in Joliet; leading your grade level's move to a new reading curriculum in 2024; running the after-school reading club for the last two years; writing a weekly email to families. End on why Halvering and fourth grade, in your own words, since the pack has no reasons for you. Add no facts | The biography question opens most panels and is scored; the arc rests on F10, F7, F8 and F5 |
| D2 | "What do you enjoy most about teaching reading?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Story-map the club in the sentence's own beats: it is after school, it is a reading club, you have run it for two years. Why you started and what keeps you there are yours to say in your own words; the pack has neither | A casual-register question on a hot topic is still scored; F8 is the evidence, and reading is both the district's first-listed belief and the principal's background |
| D3 | "What would you like us to know about you that your resume doesn't say?" | EXP | [generic] | Choose one true thing, say why it bears on a fourth-grade classroom, and keep it to about 30 seconds. The pack holds nothing about you beyond the quoted sentences, so it supplies the method only. If nothing comes to mind, say so plainly and use the time for one of the reverse questions below | An open close is common in a friendly register and the answer is where candidates ramble; the pack holds no material of its own for it |
| D4 | "Just to confirm for the file: your Illinois license and elementary endorsement are current?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Answer in the quote's own terms: you hold the Illinois Professional Educator License with the Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029. If asked for the number, give it from your own record | F1 is a gate the invite states, and your CV says it is met; JD because it scores the stated qualification |

### Bank E: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader. Tell me about a time a student in your class was not reading as you had hoped, and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | A selection scaffold: pick a real student situation, described without identifying the child, with what you noticed, what you did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the after-school reading club you've run for the last two years, or how you would handle it | The first published belief on the district's page; F8 holds the club but no student story, so the pack supplies selection criteria, not a story |
| E2 | "Families Are Partners. Tell me about a time you had a difficult conversation with a family." | VAL | [grounded] "I write a weekly email to families." | A selection scaffold: pick a real conversation, with what the concern was, what you said, and where it ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the weekly email to families, or how you would handle it | The second published belief; F6 holds an email, not a conversation, so the pack supplies selection criteria, not a story |
| E3 | "Teach for Tomorrow, Not for the Test. When have assessment results and your own judgment pointed different ways?" | VAL | [grounded] the Orrinsford Mission and Beliefs page | A selection scaffold: pick a real moment, with what the results said, what you saw, what you decided and what happened. If no such time comes to mind, say so plainly, then say how you would weigh the two | The third published belief; F9 holds no evidence, so the pack names the belief by its official words and leaves the story to you |

### Bank F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How would you tell whether a new reading curriculum is working for students?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Structure the method first: what you would look at, what it would and would not show, and what you would change. Answer slot: the move you led makes a probe on what was looked at afterwards likely. If you or your grade level looked at student results, say what, and which part was yours; if nothing was measured, or it was not yours to see, say so plainly and stay with the move you led | F7 is the evidence, and a prober's follow-up goes to how you would know; EXP because it tests attribution |
| F2 | "Tell us about the reading club: who is it for, and what happens there?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe it in your own words: it is after school, and you have run it for the last two years. Who it is for and what happens there are yours to say; the pack has none of it. Answer slot: the district's Every Child a Reader belief makes a probe on how you know the club helps readers likely. If you track anything about the readers who attend, say what, in your own words; if you do not, say so plainly and stay with what you have said about the club | F8 is the evidence; EXP because it tests the claim behind a CV line |

### Requirement coverage

| Requirement | Row | Questions |
|---|---|---|
| Valid Illinois license with elementary endorsement | F1 | D4 |
| Plan and teach reading, writing, math, science and social studies | F2 | A4, B1 |
| Differentiate instruction using assessment data | F3 | A4, B3, E3 |
| Keep clear classroom routines | F4 | A4, B4 |
| Communicate regularly with families | F5 | C4 |
| Speaks with every family each term | F6 | C4, E2 |
| Work with the grade-level team | F7 | A2, C1, C2, C3 |
| No student leaves third grade without a reading plan | F8 | A5, E1, F2 |
| Assessments inform teaching and never replace it | F9 | B3, E3 |
| Experience in grades 3 to 5 | F10 | A1, D1 |
| Fourth grade teaching | F11 | A1 |
| District's current literacy plan | none | B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To the principal: "In your talk on weekly reading conferences in grades 3 to 5, small groups were a theme. In a fourth-grade day here, where do small groups and conferences fit, and what would you want running by the end of the first term?" | Ties to her published 2025 talk, Small Groups, Big Readers, and to her years as a reading specialist; it signals you researched her, not just the school |
| R2 | "The board adopted a literacy plan in August with a new grades 3 to 5 reading curriculum from fall 2027. How will fourth-grade teachers be involved in preparing for it?" | Shows you read the current plan, and the answer tells you what the next two years of the job look like |
| R3 | To the peers: "What could a new fourth-grade teacher do in their first month that would genuinely help the team?" | Reciprocity: it asks what you can give the team before what you need, which is what a peer panel is pricing |
| R4 | "How does the team handle the term conversations with families, and what do families here expect between them?" | Draws on the district's Families Are Partners belief and gives you the real standard behind F6 |
| R5 | "For a teacher new to fourth grade, what does support look like in the first months?" | F11 is the gap the panel will see; asking about support shows your plan for it before they raise it |
| R6 | "How do teachers here use assessments, and what role do they play next to a teacher's own judgment?" | Draws on the district's belief that assessments inform teaching and never replace it, and tells you whether the room matches the page |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade | Negative you stated, F11 | The plain acknowledgment: "I've never taught fourth grade." Then a plan, with no slot |
| Having been a team lead | Negative you stated: "I've never been a team lead" — your message | The plain acknowledgment: "I've never been a team lead." Then the quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Having led a school-wide or district curriculum adoption | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation, not words for you: your material says your grade level's move, not the school's or the district's |

## Sources

**Provided documents:** your interview invite; your resume text and the two negatives you stated, both in your message. No other provided material was used.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District mission values` | yes | The three published beliefs by official name; raising sources for F6, F8, F9 and Banks A5, E. No values-style round is detected because no loop source names one, so there is no values cheat sheet |
| 2. `Orrinsford Community School District teacher interview process` | yes | Loop structure: one 45-minute building panel with the principal and two grade-level teachers; persona weights follow it |
| 3. `Orrinsford Community School District strategic plan recent news` | yes | The August 2026 literacy plan; B2 and R2 |
| 4. `Dolores Vantongeren principal Halvering Elementary School` | yes | The interviewer read; B3 and R1. The two team members are unnamed, so no query was formed for them |
| 5. representative `fourth grade teacher` listing | yes | The listing stands in for Halvering's own posting and is not confirmed as it; F2, F3, F4, F5, F7 and F10 rest on it and are `[inferred]` |

Queries and what they returned:

- `Orrinsford Community School District mission values`: https://orrinsfordschools.example/about/mission-and-beliefs (fetched)
- `Orrinsford Community School District teacher interview process`: https://orrinsfordschools.example/careers/how-we-hire-teachers
- `Dolores Vantongeren principal Halvering Elementary School`: https://ilprincipalsforum.example/speakers/dolores-vantongeren
- `Halvering Elementary School Orrinsford fourth grade teacher job posting`: https://k12jobsboard.example/listings/fourth-grade-teacher (fetched)
- `Orrinsford Community School District strategic plan recent news`: https://orrinsfordschools.example/news/board-adopts-literacy-plan

## Upgrade menu

- The full Halvering posting text → F2, F3, F4, F5, F7 and F10 move from `[inferred]` to `[grounded]`, and the JD-tagged questions are rebuilt on its own lines
- Anything HR or the principal's office said about preparing for the panel, such as a sample lesson or plan → a build section for each declared deliverable
- The two team members' names and roles → an interviewer read for each and persona weights per seat
- Your own answers to the answer slots on F2, F3, F4, F6, F7, F8 and F9 → those rows move from silence to quoted evidence and the slots become story maps
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) on the district's wider strategy, the team members' public footprint and recent org context → more grounded CO and CASE questions
- A `tuesday-dossier.md` from an earlier role check, if you have one → verified evidence and recorded objections in place of the inferred ones
