# Interview pack: Fourth Grade Teacher, Halvering Elementary School

**Round:** 45-minute panel, Thursday. Panel per the invite: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).
**Relationships assumed:** the principal as hiring manager, the two team members as peers. Weights rest on that and on the invite, which describes the one session.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the published values |
| EXP | Work-experience deep-dive | Whether your résumé's claims survive scrutiny |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company knowledge | Homework depth on the district and school |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Question IDs run by persona: A Skeptic, B Peer Evaluator, C Case/Strategist, D Data-Driven Prober, E Values/Behavioral, G Conversational, H Pressure. The letter F is skipped so that F-numbers mean fit-snapshot rows only.

## Fit snapshot

Requirement sources: the invite, and the district's mission page (fetched). Role-family rows F7 and F8 are plain prose because no posting text was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your message | medium | [grounded] | none | The gate is shown met in the invite's own terms, and the stated range, 1–6, includes fourth grade. It is a résumé line with no record inspected behind it, so expect to be asked. Say it as stated: "I hold an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029." Checking your record is yours to do |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "Fourth Grade Teacher position", adjacent-grade evidence — invite | "Six years teaching third grade at a public elementary school in Joliet" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "I taught third grade for six years at a public elementary school in Joliet." Answer slot: the invite's title makes a probe on third versus fourth likely. If you have seen a fourth-grade classroom or its materials, say what you noticed, in your own words; if you have not, say so plainly and stay with the third-grade years |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan" — Orrinsford mission page | "I led our grade level's move to a new reading curriculum in 2024" — your message, "I've run the after-school reading club for the last two years" — your message | medium | [grounded] | discovery | The two sentences touch reading without showing how any individual student's needs were handled, and the words are an answer slot. If any of your reading work was shaped around individual students, say what and how, in your own words; if it was not, or it was not yours, say so plainly and stay with the curriculum move and the club |
| F5 | "Families Are Partners: each teacher speaks with every family each term" — Orrinsford mission page | "I write a weekly email to families" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "I write a weekly email to families." Answer slot: the page's family line makes a probe on the email likely. Say what the emails carry and whether families answer them, in your own words; if they go one way only, say so plainly and say what you would add |
| F6 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — Orrinsford mission page | none given | none | [grounded] | discovery | Your material does not show this one either way. Answer slot: if an assessment ever changed what you taught, say what it showed and what you changed, in your own words; if none did, say so plainly and say what you would look at first in a new class |
| F7 | Working with a grade-level team — role-family prose, no quoted source | "I led our grade level's move to a new reading curriculum in 2024" — your message | medium | [generic] | transferability | Words stay at the quote's scope: "I led our grade level's move to a new reading curriculum in 2024." The sentence says the move, not a team role, and the words go no wider. No slot is raised, because a role-family requirement raises none |
| F8 | Planning and teaching across subjects — role-family prose, no quoted source | "Six years teaching third grade at a public elementary school in Joliet" — your message | medium | [generic] | transferability | Your material says the grade and the years, not which subjects. A strong answer names the subjects you taught, in your own words; if you taught some and not others, say which |

## Reading the interviewer

Public professional footprint only. The two team members are unnamed, so there is nothing to read for them.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022; nine years as a reading specialist before that | ilprincipalsforum speaker page, fetched | [grounded] | Expect reading instruction to be where the principal listens hardest. Read F4 before Thursday |
| A 2025 forum talk titled Small Groups, Big Readers, on weekly reading conferences in grades 3 to 5 | same page | [grounded] | Reading questions may come in that vocabulary. Use the same plain words for what you actually do, and do not borrow "small groups" or "conferences" unless that is your practice. Your F4 sentences: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the fourth-grade gap and the move | High. The hiring-manager prior is Case/Strategist plus Skeptic, and F2 puts the gap on the table for all three seats | Rehearse A1 until it is boring: acknowledge, hold, concede specifically |
| Peer Evaluator | The two team members asking what you would bring and need | High. The peer prior is Peer Evaluator plus Prober, and the invite names two fourth-grade team members | Reciprocity framing in B1; share credit precisely in B3 |
| Case/Strategist | A live reading problem or a first-weeks plan | Mid. Hiring-manager prior, and the principal's public talk is on reading conferences | Clarify, state the objective, plan, say how you would check |
| Data-Driven Prober | Attribution probes on the move, the club and the emails | Mid. Peer prior. Your sentences carry no figures, so probes will land on who did what | Say what was yours, and say plainly what you do not know |
| Values/Behavioral | Questions themed on the district's three beliefs | Mid. The invite names no values round, but the mission page says three beliefs guide every hire, so the themes are likely in any seat | Pick real instances; use the scaffold's honest branch where none comes to mind |
| Conversational | The opening biography question, and the license check | Low to mid. No seat's relationship prior leads with it | A 90-second arc built only from your sentences |
| Pressure | A time-boxed "why you" | Low. No prior for these seats puts it first | Pause, restate, hold two follow-ups, concede one specific thing |

Weights rest on relationship priors and on the invite's description of the session. No source beyond the invite documents the district's process, and the invite's account of this one session means no archetype fallback was needed.

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, not fourth. What will be newest to you on day one?" | JD | [grounded] "I've never taught fourth grade" and "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't taught fourth grade." Then the fact the second quote carries: "I taught third grade for six years at a public elementary school in Joliet." Answer slot: what is newest is yours to say. If you have seen a fourth-grade classroom or its materials, say what you noticed, in your own words; if you have not, say so plainly and say what you would look at first. Hold through two follow-ups by returning to the six years, never by adding to them, and concede specifically that the grade is new to you | F2 is your stated gap and F3 the adjacent evidence. This objection arrives in some form from any of the three seats, which is why it gets the deepest rehearsal. JD because it scores the position the invite names |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Pick the part your own judgment says is thinnest, name it in one sentence, and say what you would do about it in the first weeks. The pack does not pick it for you. If nothing specific comes to mind, say so plainly and say how you would find out where you stand | The Skeptic's stem. F2 is the likeliest influence on your answer, though the choice is yours. JD because it scores the job; generic because it is a pattern |
| A3 | "You've been at your school for six years. Why leave, and why Halvering?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | The fact is the quote's: "I taught third grade for six years at a public elementary school in Joliet." The reason is yours. Answer slot: give your actual reason for leaving and for choosing this school and this grade, in your own words; the pack supplies none. If the main reason is something other than the grade, say that plainly | The Skeptic's why-leave, why-here probe. F3 supplies only the years. EXP because it tests whether the story holds across both whys |
| A4 | "Orrinsford's beliefs are Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. Which would stretch you most?" | VAL | [grounded] | Name one belief by its exact name. Say plainly where your own experience is thinnest, then what you would do about it. If you cannot choose, say so and give the reason. Claim no strength you cannot back with an instance | The mission page is the raising source. F4 through F6 are the rows to reread before choosing. VAL because it scores the published beliefs |
| A5 | "A parent writes that their child is reading below grade level and asks what you will do. What is your reply and your plan?" | CASE | [generic] | Clarify first: what the parent has seen and what the school already knows. State the objective, then your plan as what you would do, then how you would check progress and tell the family. Use only methods you actually use, and if you use none for this, say how you would find out what the school already does. The question needs no claim about your past, so the guidance makes none | A live problem from the first belief's theme, in the form F4's requirement raises. CASE because it is a decision, not a record |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd join our fourth-grade team. What could you do in your first month that would help us, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity first. What you bring, at the sentence's scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if anything from that move would be useful to a fourth-grade team, say what, in your own words; if you do not yet know what carries over, say so plainly and return to the move. Then what you would ask the team to show you first, in your own words | The peer's reciprocity stem; F7 is the row it draws on. JD because it scores the team requirement |
| B2 | "When have you disagreed with a colleague about how to teach something, and how did it end?" | VAL | [generic] | Pick a real time with a named point of disagreement, what you said, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. The pack supplies no incident | The peer's disagreement stem. VAL because it is behavioral, though not tied to a published belief |
| B3 | "When work spans a team, how do you handle credit?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-map it on the one sentence: the grade level's move, 2024, you led. Answer slot: say which parts were yours, in your own words; if some parts were done or decided by others, say so plainly and return to what the sentence carries. Share credit precisely, never by shrinking or widening your part | The peer's credit stem; F7. VAL because it scores collegial behavior |
| B4 | "Orrinsford's beliefs include Families Are Partners. What would partnership with families look like in your classroom?" | VAL | [grounded] "I write a weekly email to families" | The question looks forward, so describe what you would do, in your own words. For what you do now, say only: "I write a weekly email to families." Answer slot: say what the emails carry and whether families answer them; if the email goes one way only, say so plainly and say what you would add | F5, with the mission page as the raising source. VAL because it scores a published belief |

### C. Case/Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader starts the year reading well below the rest of the class. What do you need to know first, and what do you do in the first month?" | CASE | [generic] | Clarify first: what the student's records and teacher notes already show. State the objective, give the plan as what you would do, and say how you would check it is working and tell the family. Use only methods you actually use. The question needs no claim about your past, so the guidance makes none | A reading problem, matching the principal's public focus in the interviewer read and F4's theme. CASE because it is a live decision |
| C2 | "The board adopted a three-year literacy plan with a new grades 3–5 reading curriculum from fall 2027. How would you want to be part of that?" | CO | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Confirm the plan's details on the district's own page before saying them aloud, because the pack read only a search snippet. If you refer to your own history, say it at the sentence's scope. Answer slot: if lessons from the 2024 move apply, say which, in your own words; if the district's curriculum differs or you know little about it, say so plainly and say what you would want to learn | The CO question grounded in current strategy. Inferred because the derivation is a search-result snippet, not a fetched page. F7 is the row it touches |
| C3 | "Sketch how you would plan your first six weeks with a new fourth-grade class." | CASE | [generic] | State the objective, what you would ask the team first, what you would learn about the students, and how you would adjust. Use only practices you actually use. The question needs no claim about your past, so the guidance makes none | Covers F3 and F8's planning theme as a live problem. CASE because it scores structure |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Of the curriculum move, the reading club and the family emails, which would you point to as your strongest, and why?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years" and "I write a weekly email to families" | Pick one and say what it is in its own sentence's words. Let the interviewer draw the conclusion about what it shows; an inference you assert yourself is the one that gets tested. Your reason for choosing it is yours to give | A prober tests what you would defend. F4 and F5 hold the three sentences. EXP because it tests how you attribute your own work |
| D2 | "How did you know the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The quote carries the move, not any result. Answer slot: the mission page says assessments inform teaching, so expect this probe. If you looked at any results, say what and how they were counted, in your own words, and name the assumption you would defend least; if you did not, say so plainly and say what you would look at | F4 and F6; the mission page raises the assessment theme. EXP because it scores whether the claim survives a second question |
| D3 | "What was the weakest part of that move?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence. Answer slot: name a weakness only if you saw one, and say what you did about it, in your own words; if you did not see one, say so plainly. Never invent a flaw to look candid | The prober's weakest-assumption stem. F4. EXP because it tests candor about your own work |

### E. Values/Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader is Orrinsford's first belief. Tell me about a time a student's reading was not moving and what you did." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" | The two sentences carry a curriculum move and a club, not an individual student's story, so the story must come from your own memory. Pick a time with a named student, what you tried and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in those sentences' words, or how you would handle it | F4, with the first belief as the raising source. VAL because it scores a published belief |
| E2 | "Families Are Partners is another of the district's beliefs. Tell me about a time you worked with a family to help a student." | VAL | [grounded] "I write a weekly email to families" | The sentence carries the weekly email and nothing wider. Pick a real instance with a named stake and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the email, in its own words, or how you would handle it | F5. VAL because it scores a published belief |
| E3 | "Teach for Tomorrow, Not for the Test says assessments inform teaching and never replace it. Tell me about a time an assessment changed what you taught." | VAL | [grounded] | Your material has no sentence for this one. Pick a real time with what the assessment showed and what you changed. If no such time comes to mind, say so plainly, then say how you would use an assessment in a new class | F6 has no evidence, so this is the scaffold case. VAL because it scores a published belief |

### G. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk us through your journey and what brought you to Halvering." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet", "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years" and "I write a weekly email to families" | A 90-second arc with four beats, each in its sentence's words: six years of third grade in Joliet, the 2024 move, the club, the weekly email. Answer slot: the link between them and Halvering is your actual reason; give it in your own words. If it is mostly about something other than the school or grade, say so plainly | The opening is scored even when it sounds casual. F3 to F5 hold the beats. EXP because it tests your own account of your path |
| G2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats the sentence states are after school, a reading club, you run it, two years. Tell them in your own words. Anything further is your own answer to their follow-ups; if you do not know, or someone else set it, say so plainly | F4. EXP because it tests what was actually yours |
| G3 | "Can you confirm your license and endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say kind, endorsement, status and expiry exactly as stated: "I hold an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029." Keep your license record to hand if asked for a number | F1, the invite's one stated requirement. JD because it scores the listed qualification; any seat can ask it |

### H. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade", "Six years teaching third grade at a public elementary school in Joliet", "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" | Pause and restate the question. Hold on what the quotes carry: six years of third grade in Joliet, the 2024 move, the club. Concede one specific thing: "I haven't taught fourth grade." Hold through two follow-ups by returning to those sentences. Answer slot: if there is something else in your own experience you would point to, say it in your own words; if not, hold the three and concede the one | F2 against F3 to F4. JD because it scores fit against the stated position |
| H2 | "That curriculum move — how much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say which parts were yours, in your own words; if some belonged to others, say so plainly and name that exactly. Hold through two follow-ups by returning to the sentence, and never widen it beyond your grade level | The pressure persona's attribution stem. F7. EXP because it tests attribution |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 license | G3 |
| F2 and F3 fourth grade | A1, A2, A3, C3, H1 |
| F4 reading | A5, C1, C2, D2, D3, E1, G2 |
| F5 families | B4, E2 |
| F6 assessments | D2, E3 |
| F7 team | B1, B2, B3, H2 |
| F8 subjects | C3 — no question of its own beyond planning, since it is role-family prose from no supplied posting |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To the principal: "You came to the principal's role after nine years as a reading specialist. What from that work do you still look for in a classroom?" | It follows the principal's public path and moves the conversation to the work |
| R2 | To the principal: "Your 2025 talk was on weekly reading conferences in grades 3 to 5. What does that look like here for a fourth-grade teacher?" | It ties to the principal's own published theme and asks about the day-to-day |
| R3 | To the team members: "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for peers: it asks about their load, not only yours |
| R4 | To the team members: "What do you wish you had known in your first month at Halvering?" | It asks for their experience, which is concrete and easy to answer |
| R5 | To the panel: "Orrinsford's beliefs say each teacher speaks with every family each term. What does that look like in fourth grade here?" | It uses the district's own published words and asks about practice |
| R6 | To the panel: "How does the fourth-grade team work together day to day?" | It asks about the team you would join |
| R7 | To the panel: "What are the next steps, and when should I expect to hear?" | It gives you a plan for the days after Thursday |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative you stated: "I've never been a team lead" — your message | The plain acknowledgment: "I haven't been a team lead." Your sentence on the move says it was the grade level's move, which is a different thing, and the words stay at that scope |
| Owned the district's curriculum adoption | Inflated form of F7 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: your material says your grade level's move, not the district's |
| Speaks with every family each term | Inflated form of F5 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says a weekly email, not a conversation with each family. B4's slot stays inside the email |

## Sources

**Provided documents:** the interview invite and the résumé text you pasted in your message. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The mission page named the three beliefs; they feed F4 to F6, A4, B4 and E1 to E3 |
| 2. Interview process | skipped | The invite already fixes the one session and who is on it, which fixes the persona weights |
| 3. District strategy and recent news | yes | One result, a board literacy plan, read as a snippet only; it feeds C2 and is why C2 is inferred |
| 4. Principal's public footprint | yes | The principal's speaker page fixed the interviewer read, A-bank themes and R1 and R2 |
| 5. Representative fourth-grade teacher posting | yes | Two queries: one for this school's posting returned no results; one for the role family returned a listing snippet. It moved F7 and F8 as plain role-family prose only; a snippet raises no answer slot |

Searches and fetches sent:

| Query or URL | Outcome |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: Halvering Elementary School Orrinsford fourth grade | no results |
| Search: Dolores Vantongeren principal Halvering Elementary | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: fourth grade teacher job description Illinois elementary | https://k12jobsboard.example/listings/fourth-grade-teacher |
| Fetch: the mission page | returned the three beliefs and their one-line definitions |
| Fetch: the principal's speaker page | returned the career and talk summary |

## Upgrade menu

- The full posting text → F7 and F8 become quoted, grounded rows, and new job-tagged questions follow from its own lines
- What HR said about the format, such as a sample lesson, a presentation or topics for the panel → a build section for anything announced, and a reweighting of every bank
- The names and roles of the two team members → an interviewer read for each and persona weights per seat
- Your answers to the answer slots on F3 to F6 → those rows upgrade from questions to grounded evidence, and the matching guidance cells regenerate
- Your license record showing status and expiry → F1 moves from medium toward high
- Your reading club materials or a write-up of the 2024 move → F4 and F7 gain an inspectable artifact and the questions about them gain beats
- The district's literacy plan page, read in full → C2 and R-bank items drawn from it move from inferred to grounded
- A tuesday-dossier.md from an earlier check of a role → verified evidence and any prohibited claims it holds would sharpen the guidance, and the pack stands without one
