# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen with Hannah Lowther, Talent Partner. A 30-minute phone call, Thursday at 2pm; she rings the mobile number on your application.

**Her stated agenda, in her words (her LinkedIn message):** "I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your experience survives scrutiny, and what was actually you |
| JD | The advert's stated duties and requirements, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the call, not a question for you here. A logistics slot works the same way, for pay, notice, hybrid and reason for leaving.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I schedule deliveries for our three depots." Your material says delivery scheduling, not production scheduling, and says nothing about planning or QA teams. Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of your delivery scheduling ran through planning or quality colleagues, say who and what you agreed, in your own words; if it did not, or it was not yours, say so plainly and return to the depots you schedule for |
| R2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote says you schedule deliveries and chase suppliers; it does not show how an order's status is followed. Answer slot: the advert's tracking line makes a probe on how you know an order has slipped likely. If you had a way of tracking, say what it was, in your own words; if there was none, or it was not yours, say so plainly and stay with "chase suppliers when orders slip" |
| R3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but nothing is inspected behind it, so expect a probe. Lead in the quote's own terms: you chase suppliers when orders slip |
| R4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, and the figure will be probed. Keep both halves at the sentence's own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The sentence does not say one caused the other, so the pack does not either |
| R5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote names a spreadsheet, not Excel. Answer slot: the advert's Excel line makes a probe on the tool likely. If the spreadsheet was in Excel, say so and say what you used in it, in your own words; if it was another tool, or you did little in it, say so plainly and stay with the spreadsheet you rebuilt |
| R6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: the advert's weekly-report line makes a probe on your reporting likely. If you produce any regular report on deliveries, say what it covers and how often, in your own words; if you do not, say so plainly and say what you would want to see in a first weekly report |
| R7 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap: the quote already speaks in the advert's terms. Say it as written |
| R8 | "ERP experience (SAP or similar) a plus" — advert, the SAP part | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past |
| R9 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" part | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | The quote says your company runs an in-house stock system; it does not say you use it or that it is an ERP. Answer slot: the "or similar" wording makes a probe on that system likely. If you work in it, say what you do in it, in your own words; if you do not, or it is not comparable, say so plainly and return to R8's words |
| R10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your own constraint, which is the strongest evidence it can have. The two days are met. Say it in your own words, both halves together |
| R11 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your own figure, in your own words. Nothing is added to it |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (bank A, 5 questions) | A friendly phone call that walks through her four stated agenda items | Highest. The recruiter-screen prior is Conversational plus a light Skeptic, and her own message lists pay, notice, hybrid and reason for moving. The risk is treating casual questions as unscored | Prepare a 90-second arc from your own sentences only, and give each logistics answer in your own words |
| Skeptic (bank B, 4 questions) | Quiet probing of the gaps: production scheduling, SAP, why this company | High. It is the light-Skeptic half of the same prior, and R1 and R8 are the thinnest rows | Rehearse the most predictable objection (B1) until it is boring. Build bridges only from your own adjacent sentences, and say the limit plainly |
| Data-Driven Prober (bank C, 3 questions) | Reads your numbers and tools closely | Medium. The one figure you gave is a natural target, and a recruiter may test it lightly | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure / Stress (bank D, 2 questions) | A short, blunt question to test composure | Low. The recruiter prior does not lean this way, so these are insurance | Pause, restate, hold the sentence you actually said, and concede only what the material shows |
| Values / Behavioral (bank E, 2 questions) | A "tell me about a time" question taken from the advert's own duties | Low. No published values were read and no values round is documented, so the themes come from the advert | Pick one real occasion with a named stake. If none comes to mind, say so plainly |
| Case / Strategist (bank F, 2 questions) | A live scheduling or reporting problem | Low for this call, more likely in a later round. The advert's own vocabulary (planning, warehouse, QA, on-time dispatch) supplies the problems | Clarify first, then structure, then answer |
| Peer Evaluator | Not banked | Hannah is a recruiter, not a peer, so this persona has no part in this call | None |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Build the 90-second arc from three beats, each the quote's own: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; the stock-count spreadsheet rebuilt and discrepancies down by about a third over a year. Tell them in your own words and add no further beats | R7 is the evidence for the experience requirement. It is the opening question of a friendly call and it is scored |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot: give your figure in your own words, which were "I'm hoping for £42,000." Say nothing beyond them. If she asks about your current pay, you can decline to give it and return to your own figure | R11 holds the figure. JD because it is the listed job's term, and it is her first agenda item |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. The pack does not supply a figure | Her second agenda item. This is generic because nothing in your material states it |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot: your own words, whole, were "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks a follow-up about the commute, your own words were the same, with nothing added | R10 holds the constraint. JD because the hybrid pattern is a term of the listed job |
| A5 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot: say it in your own words, which were "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Add no characterization of your employer and no detail the sentence does not hold | Her fourth agenda item. EXP because it scores motivation consistency, and the reason is in your own message |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that is closest to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **Highest-ROI prep in this pack.** Start from your own sentence at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." First follow-up, about whether that is production scheduling: hold the sentence and give the scope in positive terms, "My scheduling has been deliveries across three depots." Second follow-up, about the planning and QA side: answer slot. If any of your scheduling ran through planning or quality colleagues, say who and what you agreed, in your own words; if it did not, or it was not yours, say so plainly and return to the depots. Close with a plan, never a past: what you would ask first about how planning, the warehouse and QA hand over to each other | R1 is the evidence for the core duty and the thinnest row for it, so this objection arrives in some form. JD because it scores the stated duty |
| B2 | "Have you used SAP or a similar system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Words: "I've never used SAP." Answer slot: the advert's "SAP or similar" makes a probe on your company's own system likely. If you work in it, say what you do in it, in your own words; if you do not, or it is not comparable, say so plainly. Then a plan: say how you would learn the team's system, and ask which one it is | R8 and R9 hold the evidence. The advert marks ERP as a plus, so this is likely to be a knockout-style check in a friendly register |
| B3 | "Which part of this advert would be your weakest on day one?" | JD | [generic] | Selection scaffold: pick the line in the advert you would lean on the team for first, name why in one sentence, and say what you would do about it in your first weeks. If no such line comes to mind, say so plainly, then name the nearest thing your own sentences carry, or how you would handle it | R1, R6 and R8 are the thin rows, and the choice of which to name is yours. A persona stem, so it is asked of every candidate |
| B4 | "You have been in building supplies. What draws you to a diagnostics manufacturer?" | CO | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own stated reason for looking was "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Answer slot: say what in the advert drew you to the company or the role, in your own words; if nothing about diagnostics in particular did, say so plainly and name the advert lines that match the work you do. No company research was possible for this pack, so nothing here supplies a fact about Quillmoor | Why now and why here are the Skeptic's questions. CO because it tests homework depth, and it has no company-specific grounding in this pack |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend-the-number slots, each in your own words. How the figure was counted. What it is sensitive to. The assumption behind it you would defend least. Which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no method, baseline or assumption | R4 holds the headline figure. Every headline figure draws a defend-the-number question |
| C2 | "Tell me about the spreadsheet you rebuilt." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on the sentence's own beats: you rebuilt a stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slot: the advert's Excel line makes a probe on the tool likely. If it was Excel, say so and say what you used in it, in your own words; if it was another tool, or you did little in it, say so plainly and stay with the spreadsheet you rebuilt | R4 and R5 are both drawn from this sentence. The advert's Excel line is the raising source for the tool probe |
| C3 | "The role reports weekly on on-time dispatch. What reporting do you do today?" | JD | [generic] | Answer slot: if you produce any regular report on deliveries, say what it covers and how often, in your own words; if you do not, or it is not yours, say so plainly and say what you would want to see in a first weekly report. The pack describes no report because your material shows none | R6 is the advert's last duty and the row with no evidence. The premise comes from the advert, not from you, so the guidance does not adopt it |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "Never used SAP — we run our own in-house stock system." | Pause and restate the question. Hold on what you said: the four years, scheduling deliveries for three depots, chasing suppliers when orders slip. Concede the one thing you have stated: "I've never used SAP." Hold through two follow-ups by returning to those sentences, and add nothing to them | R7 and R8 are the two sides of this question. Pressure tests whether you hold a position without folding on the core claim |
| D2 | "That discrepancy figure — how much of that was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the sentence at its own scope: you rebuilt the spreadsheet. Answer slot: if the rebuild drove the fall, say how you know, in your own words; if you cannot separate the rebuild from anything else in that year, or you do not know, say so plainly and return to "I rebuilt our stock-count spreadsheet." | R4 holds the figure. This is the persona stem for attribution, and the second branch keeps the claim at what the sentence says |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a delivery slipped and you had to chase it." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: pick one occasion with a named stake, what you did, and where it ended up. Your sentence carries the practice, "chase suppliers when orders slip", and nothing else about it, so the occasion and its outcome are yours to name. If no such time comes to mind, say so plainly, then give the nearest thing your own sentence carries, or how you would handle it | R2 and R3 are the evidence. The theme comes from the advert's "track supplier deliveries and chase late orders" line |
| E2 | "Tell me about a time you had to work with other teams who wanted different things." | JD | [generic] | Selection scaffold: pick one occasion with a named stake, who wanted what, what you did, and whether the relationship was intact after. If no such time comes to mind, say so plainly, then give the nearest thing your own sentences carry, or how you would approach it | The theme comes from the advert's planning, warehouse and QA coordination line, which is R1's requirement. It asks for a real occasion, so none is supplied |

### F. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Planning says a batch will be ready Friday, the warehouse cannot dispatch until Monday, and QA has not released it. What do you do first?" | CASE | [generic] | Clarify first: what is firm and what is not, and who owns each date. Then the objective, the options, and who you would tell and when. Think aloud, and challenge one premise politely. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's planning, warehouse and QA line. Generic because it is a pattern for the problem, not a fact about this employer |
| F2 | "Weekly on-time dispatch has dropped over two weeks. Diagnose it." | CASE | [generic] | Clarify what on-time means and how it is measured, then segment the drop, then name the first checks, then the risks. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's weekly-report duty (R6's requirement). A persona stem for the Case persona |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, E2, F1 |
| Track supplier deliveries | E1 |
| Chase late orders | E1 |
| Keep stock records accurate | C1, C2, D2 |
| Confident with Excel | C2 |
| Report weekly on on-time dispatch | C3, F2 |
| 2+ years in operations or logistics coordination | A1 |
| ERP experience (SAP or similar) a plus | B2, D1 |
| Hybrid: two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |
| Her agenda: notice period | A3 |
| Her agenda: what's prompting a move | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Who would I work with day to day across planning, the warehouse and QA?" | It uses the advert's own three teams, so it shows you read the role closely |
| 2 | "What would a strong first three months look like in this role?" | It points the call at the job rather than at your gaps |
| 3 | "Which system does the team work in day to day?" | It meets the SAP gap with curiosity instead of defensiveness |
| 4 | "How is on-time dispatch measured today, and what does the weekly report look like now?" | It takes the advert's last duty and asks to see it |
| 5 | "Is the two-day Avonmouth pattern the same every week?" | It asks about the employer's pattern, not yours |
| 6 | "What are the next steps and the timeline after today?" | She has said she will cover this, so it confirms details rather than opening a topic |

No reverse question is tied to an interviewer's career path, because no interviewer profile was available.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative the candidate stated, R8 | The plain acknowledgment R8 gives: "I've never used SAP." No slot |
| Has ERP experience | Inflated form of R9 | R9's quote at its own scope. The limit is the pack's observation: the material says the company runs an in-house stock system, not that you use it or that it is an ERP. B2's slot stays inside the system |
| Coordinated production schedules | Inflated form of R1 | R1's quote at its own scope. The limit is the pack's observation: the material says delivery scheduling for three depots, not production scheduling. B1's slot stays inside the depots |
| Cut stock discrepancies by a third by rebuilding the spreadsheet | Inflated form of R4 | R4's quote at its own scope. The limit is the pack's observation: the sentence gives the rebuild and the fall, not a cause. D2's slot stays inside the rebuild |
| Open to more than two office days, or to any pattern | Inflated form of R10 | R10's quote whole, in your own words, with nothing added |

## Sources

**Provided documents:** the advert you pasted; Hannah Lowther's LinkedIn message; your own summary of your background and what you would say.

**Searches sent, all refused:**
- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics strategy news Avonmouth" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have moved the values themes in the Values bank, and whether a values cheat sheet applies |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. It would have moved the loop structure and persona weights beyond this one call |
| 3. `Quillmoor Diagnostics strategy news Avonmouth` | unavailable | Every call was refused. It would have moved the CO question, which is generic here |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have moved an interviewer read and one tailored reverse question |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access in this session → grounded values, loop and strategy rows, and Hannah's public professional footprint for a tailored reverse question. If search is enabled, a deeper pass is available once: up to 6 more searches and 2 more fetches, several more minutes
- Your CV → R1 to R9 would quote its lines in place of your summary, and any `low` rows may move up
- Your answers to the answer slots on R2, R5, R6 and R9 → those rows upgrade from `discovery` to a quoted row, and the matching bank guidance regenerates
- A `tuesday-dossier.md` → verified evidence, the objection worth the deepest rehearsal, and absolute prohibited claims arrive ready-made
