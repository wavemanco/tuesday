# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

**Interviewer:** the support team lead (name not given). **Relationship:** assumed to be your future manager, so the pack is built for a hiring-manager round. **Format:** a text chat on Telegram, as the invite describes it. **Loop:** one session, from the invite's own words.

Built from your message only. Company research was not available (see Sources), so nothing here is a claim about Lumenvale.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries one of each, so you can see the coverage at a glance.

| Tag | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem, reasoned through |

Guidance is scaffolding, not a script. Every clause about your past rests on a sentence you wrote, quoted next to it. Where your material is silent, the guidance is an answer slot: say what is true in your own words, or say plainly that it is not. The interview is a text chat, so rehearse by typing your answers, not just thinking them.

The single highest-ROI rehearsal is A1, the software-background question.

## Fit snapshot

The ad's requirements are as you listed them in your message. Rows F5 and F6 are not in that list.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as listed in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on the number, but a line from your message with nothing inspected behind it, so expect a probe on what the work was. Lead with it in its own terms: three years, customer service advisor, an energy supplier. If asked whether that counts as support, answer from what you did in the role, not from the job title |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as listed in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | Say it as you wrote it: Freshdesk, every day. The ad's own door is "or a similar ticketing tool", and whether Freshdesk counts as similar is the interviewer's call, so name it plainly and let them judge. Your message does not mention Zendesk, so nothing in this pack says you have used it |
| F3 | "clear written communication" — job ad, as listed in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote joins calls and emails, so it does not show how much of it was written or how the writing was judged. Answer slot: the ad's line makes a probe on your written replies likely. If any of your written replies were checked, praised or reused by others, say which and by whom, in your own words; if none were, or you cannot say how much of the day was writing, say so plainly and stay with the emails you answered each day |
| F4 | "confidence handling escalations" — job ad, as listed in your message | none given | none | [grounded] | discovery | Your material does not show an escalation either way. Answer slot: the ad's line makes a probe on a handled escalation likely. If you handled any escalated contacts, say what happened and what part was yours, in your own words; if none reached you, or that step was not yours, say so plainly and describe your day-to-day contact work in your own words |
| F5 | Familiarity with software products or a software-company setting (not in the ad you listed; a common expectation for the role family) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-company experience, and nothing added to make the gap feel smaller |
| F6 | Coaching or onboarding colleagues (not in the ad you listed; a common role-family expectation) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Say it at its own scope: four new starters, the refunds process, last year. The quote does not say it was a programme you designed or that you led a team, and the words stay there |

## Persona table

Loop: one session, a text chat with the support team lead, from the invite's own words. No archetype fallback is needed. Weights start from the hiring-manager prior (Case/Strategist plus Skeptic) and are adjusted below.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the software gap (F5) and the thin rows (F3, F4) | High. The hiring-manager prior puts it near the top, and your own message names the software gap | Rehearse A1 until it is boring. Bridges only from your quoted sentences; the plain acknowledgment plus a ramp plan; calibrated candor over bluffing |
| Case/Strategist | Live support scenarios, answered in writing in the chat | High. The hiring-manager prior, and a text chat makes "write me your first reply" easy to ask | Clarify, state the objective, approach, what you tell the customer, what you hand over. Type it as you would send it |
| Conversational | Biography opener, written-style and remote-work questions | Medium. A chat has to open somewhere and the biography question is the usual opener; this is judgement, not sourced | A pre-scripted 90-second arc built only from your quoted sentences. Treat casual questions as scored |
| Data-Driven Prober | Checks the figures: around 60 a day, four new starters | Medium. Your message gives two figures a prober would test | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Peer Evaluator | Collaboration and handover scenarios | Low. It rises only if the lead is a colleague rather than your manager, which is open | Reciprocity framing: what you bring the other person, not only what you need |
| Pressure | Time-boxed, devil's-advocate challenges to the software gap | Low. Nothing in your material says the lead will interrupt, but F5 is the natural target if they do | Pause, restate, hold through two follow-ups on your quotes, then concede specifically |
| Values/Behavioral | Past-behaviour stories | Low. No published values in hand and no source naming a values round, so these two prompts are generic behavioural stems | Choose real instances; if none comes to mind, say so plainly |

## Question banks

### A. Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company before. How would you get up to speed on a product that is new to you?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked for a software company." Then hold only what your quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk, which you use every day. Say how you would learn the product as a plan in your own words, never as something already done. Hold through two follow-ups by returning to those quotes, never by adding to them, and concede plainly what you do not yet know | F5 is the stated gap and the most predictable objection, so it will arrive in some form. JD because it scores a gap in the role's requirements |
| A2 | "Which part of this ad would you be weakest at on day one?" | JD | [inferred] derived from the rows the snapshot grades thinnest: F3, F4, F5 | Choose the one that is truly yours and say it plainly, then give the ramp plan. If it is F5, the words are in F5; if F3 or F4, the words are those rows' answer slots. Calibrated candor scores better than naming a polished non-weakness | The Skeptic's standard stem, aimed at where F3, F4 and F5 are thinnest. JD because it scores the listed requirements |
| A3 | "Tell me about a time a customer escalated, or asked for someone more senior." | JD | [grounded] "answering around 60 calls and emails a day" | A selection scaffold. Pick one contact where the issue left your hands or the customer wanted someone else; it needs what the customer wanted, what you did, and how it ended, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, answering around 60 calls and emails a day, or how you would handle it | F4 has no evidence, and the ad's escalation line makes this probe likely. JD because it scores a stated requirement |
| A4 | "Which ticketing tool do you use day to day, and what do you use it for?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk and say you use it every day, in those words. Answer slot: the ad's tool line makes a probe on how you use it likely. Say what you actually do in it, in your own words; if the interviewer names Zendesk or a feature you have not used, say so plainly and return to Freshdesk, which you use every day | F2 is the evidence for the tool requirement. JD because it scores a stated requirement directly |
| A5 | "Why move from an energy supplier into software support, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Your reason is yours, and your message gives none, so the pack supplies none. Say the actual reason in a sentence or two, about what draws you to this role, and do not offer one you could not back with a second question. The only history it rests on is three years as a customer service advisor at an energy supplier | The Skeptic's why-leave, why-here, why-now probe; F1 and F5 make the move from energy to software the obvious thing to ask. EXP because it tests motivation against your history |

### B. Case/Strategist (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in angry: they were charged twice and say they will cancel today. Type me your first reply." | CASE | [generic] | Write it as you would send it, in three or four sentences: acknowledge the double charge and the upset, say what you will check and when they will hear back, ask only for what you need, and do not promise a refund you cannot authorise yourself. The question needs no claim about your past, so the guidance makes none | A live written scenario suits a text chat and scores F3's requirement directly. CASE because it is a problem set in the role |
| B2 | "A customer says a feature is not working and you do not know the product well yet. What do you do in the first ten minutes?" | CASE | [generic] | Clarify what they see and what they expected, ask for the steps and any error, check what internal help exists, ask a colleague before guessing, and tell the customer what happens next. Say aloud what you would not do: guess an answer you cannot confirm | Aimed at F5, the software gap, as a problem rather than a history question. CASE because it asks about no past |
| B3 | "Three messages arrive together: a customer locked out, a billing question, and a fourth complaint from someone who has already written three times. In what order do you reply, and why?" | CASE | [generic] | State the ordering principle aloud before the order, and say what you would ask the lead if the team has a rule for this. Reasoning matters more than the order | Prioritisation is the daily work of the role; the ad's own list implies it. CASE because it is live reasoning |
| B4 | "A customer demands a manager. When do you escalate, and what do you write in the handover?" | CASE | [generic] | Structure it: what the customer wants, what has already been tried, what you need from the next person, and what you have told the customer. Say when you would escalate and when you would keep the contact. The question needs no claim about your past, so the guidance makes none | F4 is thin, so the escalation line is turned into a decision you can answer without a story. CASE because it is a live problem |

### C. Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself and what led you to this role." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A pre-scripted arc of about 90 seconds, a few typed lines in chat. Three beats, each a clause your sentences state: three years as a customer service advisor at an energy supplier; Freshdesk, which you use every day; four new starters trained on the refunds process last year. The end of the arc is your own reason for wanting this role; your message gives none, so none is supplied | The biography opener is the most likely first question in any chat. F1, F2 and F6 carry it. EXP because it tests what you did |
| C2 | "What does a good written reply to a customer look like to you?" | JD | [grounded] "answering around 60 calls and emails a day" | Give your own view in a few sentences, as a standard you hold rather than a claim about your replies. Answer slot: the ad's written-communication line makes a probe on your own writing likely. If any of your written replies were checked, praised or reused by others, say which, in your own words; if none were, or you cannot say how much of the day was writing, say so plainly and stay with the emails you answered each day | F3 is the thinnest evidence for a requirement the chat itself will test. JD because it scores the stated requirement |
| C3 | "This role is remote. Have you worked remotely before?" | JD | [generic] | Answer with what is true, yes or no, plainly. Your material says nothing about remote work and the pack supplies nothing. If yes, say what the arrangement was; if no, say so plainly and say what you would put in place for working at home, as a plan | The role is remote, and the question presupposes nothing about your past. JD because it scores the listed job's terms |

### D. Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the figure at its scope: around 60, calls and emails together, per day. The defend-the-number slots are yours to fill in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was you. If you do not know how it was counted, say so plainly. Do not turn it into tickets or a target | F3's figure is the headline number a prober tests first. EXP because it checks a figure against what you can say about it |
| D2 | "How many of those were emails and how many were calls?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you know the split, say it in your own words; if you do not, say so plainly and return to "around 60 calls and emails a day", at that scope | The split is the follow-up that decides how much of F3 is written work. EXP because it checks the same figure one level deeper |
| D3 | "You mention training four new starters on the refunds process. Walk me through that." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say what your sentence says, in those words: four new starters, the refunds process, last year. Answer slot: the figure raises "which part was yours". Say which part of it was yours, in your own words; if the process or materials were someone else's, or it was not formal, say so plainly and describe what you did with the four | F6 is a CV-style line with nothing inspected behind it. EXP because it tests attribution |

### E. Peer Evaluator (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A teammate hands you a half-finished ticket. How do you handle it?" | CASE | [generic] | Reciprocity first: finish the customer's problem, then raise the handover with the teammate directly and without blame, with the gap named specifically. The question needs no claim about your past, so the guidance makes none | Likely only if the lead is a colleague; kept to a hypothetical so it asks about no past. CASE because it is a live scenario |
| E2 | "When you need an answer from another team and they are slow, what do you do?" | CASE | [generic] | Say what you tell the customer, who you ask, how you follow up, and when you would raise it with the lead. A principle, not a pretence that you know this team's seams | A peer's collaboration probe in its simplest form. CASE because it is a live scenario |

### F. Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, with no software background?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | Pause and restate the question. Concede the plain fact first: "I haven't worked for a software company." Then hold what your quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk, which you use every day. Hold through two follow-ups by repeating those, adding nothing, and concede specifically what you would need to learn | F5 is where a time-boxed challenge would land. JD because it scores a gap in the role's requirements |
| F2 | "That training you gave. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Pause. Answer slot: say which part was yours, in your own words; if it followed someone else's process or plan, say so plainly. Hold the quoted core, that you trained four new starters on the refunds process last year, and concede the specific part that was not yours without folding on the rest | F6 is the one line a pressure question can test for attribution. EXP because it checks what was yours |

### G. Values/Behavioral (weight low)

No published values are in hand, so these two are tagged EXP rather than VAL.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | A selection scaffold. Pick a time where what the customer needed and what a target or rule asked pulled apart; it needs the two pulls, what you chose, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for a service role; nothing in the material raises it more specifically. EXP because it tests past behaviour |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | A selection scaffold. Choose a time the hard truth actually landed and the relationship held; "we" for context, "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standard stem for a values-style prompt. EXP because it tests past behaviour |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" (F1) | C1, D1, F1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | A4 |
| "clear written communication" (F3) | B1, C2, D2 |
| "confidence handling escalations" (F4) | A3, B4 |
| Software familiarity, not in the ad (F5) | A1, A2, A5, B2, F1 |
| Coaching colleagues, not in the ad (F6) | C1, D3, F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone who has not worked in software before?" | It turns F5 from an objection into a plan the lead describes, and shows you are already thinking about ramping up |
| R2 | "Which kinds of customer questions take newcomers longest to get comfortable with?" | It tells you where to spend your first weeks and shows you expect to learn |
| R3 | "How does the team handle escalations: who picks them up, and what do you want first-line to pass on?" | F4 is your thinnest row, and the answer shows you what good handovers look like here |
| R4 | "Which ticketing tool does the team use, and how much of the day is chat versus email?" | It tells you how close your Freshdesk work is to theirs and how much of the job is written, which sets how much of F3 matters |
| R5 | "Is the next step a call or a video conversation with the team, or does the process stay in writing?" | So you can prepare spoken answers as well as written ones |
| R6 | "How is quality measured on the team, and what do your strongest people do differently?" | It signals you care about the standard, and it gives you something concrete to aim at in the first weeks |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your message says Freshdesk, not Zendesk. A4's slot stays inside Freshdesk |
| Handled 60 tickets a day, or a 60-a-day target | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day". The limit is the pack's observation: the quote counts calls and emails together and says nothing about tickets. D1's slots ask only how it was counted |
| Strong written communication, proven by the volume of emails | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the quote does not say how much was written or how it was judged. C2's slot stays inside the emails you answered |
| Led or ran the onboarding or training of new starters | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". D3's slot asks only which part was yours |
| Software-company or software-support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |

## Sources

Provided documents: your message, which holds the invite text, the job ad's four listed requirements and your background.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent:

- `Lumenvale Software values` — refused
- `Lumenvale Software interview process customer support specialist` — refused
- `Lumenvale Software company news strategy` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have fed a values cheat sheet and the VAL tag; neither is built, and G1 and G2 are tagged EXP |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The search was refused. It would have shown the loop structure; the loop here rests on the invite's own words alone, and persona weights rest on the hiring-manager prior |
| 3. `Lumenvale Software company news strategy` | unavailable | The search was refused. It would have fed a CO question grounded in current strategy; the bank has no CO question |
| 4. `{interviewer name} Lumenvale Software` | n/a | The interviewer is described only as the support team lead, so there was no name to query. The interviewer read is absent |
| 5. representative Customer Support Specialist JD | skipped | The four requirements you listed fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad → F1 to F4 requirement cells become full quotes, and mid-list requirements you did not mention get their own questions
- Your CV → F3, F4 and F6 may find quoted evidence beyond your message, and the answer slots become story-mapped answers
- An example of an escalated contact you handled, or a written reply of yours that someone praised, typed into this chat → F4 and F3 become quoted rows with story-mapped guidance
- Whether the support team lead would be your manager or a colleague → every bank is reweighted, and Peer questions rise or fall
- The lead's name and role → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- Permission to run searches on Lumenvale (up to 6 searches and 2 fetches at the standard tier) → rows 1 to 3 of the target table fill in, a CO question and a values cheat sheet become possible, and generic questions become grounded
- Any prep email or notes from the hiring side about what the chat will cover → coverage of anything pre-declared
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims arrive pre-graded, so the highest-ROI objection comes from evidence rather than inference
