# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner. **Round:** recruiter screen, a 30-minute phone call, Thursday at 2pm. Her own agenda, in her message: salary expectations, notice period, how the hybrid pattern would work for you, and what is prompting a move, then the team and next steps.

Built from the advert, Hannah's message and your own notes. No company research ran (see Sources), so nothing here claims a fact about Quillmoor beyond the advert.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: where a row quotes your words, say them in your own words at the same size, and where a row has an answer slot, answer from what is true.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether a claim about your work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries and chasing, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you worked with likely. If you worked with any of those groups, say who and what you did together, in your own words; if you did not, or it was not yours, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms, you chase suppliers when orders slip, because a named action beats an adjective |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect the four defend-the-number probes in C1. Lead with what the sentence says, at its own scope: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | The material is silent here, which is not an absence you stated. Answer slot: the advert's weekly on-time dispatch line makes a probe on reporting likely. If you produce any regular report, say what it covers and how often, in your own words; if you produce none, or it is not yours, say so plainly and stay with the stock-count spreadsheet |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap on length. Say it in its own terms: four years, logistics coordinator, building-supplies wholesaler |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | Derived from the sentence touching the requirement: it says spreadsheet, not Excel. Answer slot: if the spreadsheet was in Excel, say so and what is in it, in your own words; if it was another tool, say so plainly and stay with the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then the adjacent fact at its own scope: "we run our own in-house stock system." Then how you would learn a new system, said as a plan and never as a past. Your material says an in-house stock system, not an ERP, and the pack does not call it one |
| F8 | "£38,000–£44,000" — advert; "your salary expectations" — Hannah's message | "I'm hoping for £42,000" — your message | high | [grounded] | none | No gap: your figure sits inside the advertised band. Your words, as said, with nothing added |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert; "how the hybrid pattern would work for you" — Hannah's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | No gap. Your words, whole and at their own scope, with nothing added |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. The call needs your own answer, and the pack supplies none |
| F11 | "what's prompting a move" — Hannah's message | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap. Your words, as said, with nothing added |

## Persona table

Weights start from the recruiter-screen prior (Conversational with a light Skeptic), then adjust for what is known. No interviewer profile exists, so no interviewer-signal adjustment was made. The only loop source is Hannah's own message, which establishes this one session and what it holds; later rounds are not established, so Case, Pressure and Peer are weighted for the rounds after this one rather than assumed.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Conversational | Friendly logistics and a "tell me about your background" opener | Top. Her four stated topics are logistics, and the recruiter prior puts this persona first | A short arc built from your own sentences; treat the casual questions as scored | A1 to A5 |
| Skeptic | Quiet probing of the advert's checklist: ERP, manufacturing, why here | Second. A recruiter checks the advert's list against what you say, and F7 and F1 are the thinnest rows | Rehearse the likeliest objection until it is boring: B1 | B1 to B4 |
| Data-Driven Prober | Reads your lines and asks how a figure was counted | Mid. She may touch the stock-count figure, and the hiring manager certainly will | Say what you know of how it was counted, and say plainly what you do not | C1 to C3 |
| Case / Strategist | A live problem from the role | Low for this call, likely with the hiring manager later | Clarify, structure, then answer, thinking aloud | D1, D2 |
| Pressure | Time-boxed challenge to your fit | Low for this call | Pause, restate, hold the sentence you said, concede the specific gap | E1, E2 |
| Peer Evaluator | Seam questions with planning, the warehouse or QA colleagues | Low for this call, plausible in a later round | Reciprocity framing, and principles rather than a pretended seam | F1, F2 |
| Values / Behavioral | None: no round that assesses values is established | Not weighted. Hannah's message names no such round, and no company values were read | Not applicable | none |

## Question banks

### A. Conversational (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey. What's your background?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Story-mapped on F5 and F1, about 90 seconds: the role and the four years, then what the work is, which are the beats those two sentences state. Tell them in your own words and stop, so she can ask for more. Add no further beat that the sentences do not carry | The opener a rapport-style recruiter uses, and the likeliest first question. EXP because it checks what the background actually was; F5 and F1 are what it draws on |
| A2 | "What are you looking for salary-wise?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, filled by your own words, said whole: "I'm hoping for £42,000." Say it plainly and stop. If she asks about current or past pay, prepare to decline or redirect without giving any figure | Hannah listed salary expectations first. F8 is the evidence; JD because it tests the advert's stated pay band |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words | Hannah listed notice second. F10 is a gap in the material, not in your position; the pack supplies no figure. JD because it tests a term of the job |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, filled by your own words, said whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the days or the journey, your own words again, quoted, with nothing added | Hannah listed the hybrid pattern third. F9 is the evidence; JD because it tests the advert's stated pattern |
| A5 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot, filled by your own words, said whole: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up on the Reading offer, your own words again, quoted, with nothing added | Hannah listed the reason for the move fourth, and the Skeptic's why-now arrives through it. F11 is the evidence; EXP because it tests consistency of your story |

### B. Skeptic (second weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert lists ERP experience, SAP or similar, as a plus. What's your experience there?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | **Highest-ROI prep in this pack.** First, the plain concession, said before she can press: "I haven't used SAP." Then the adjacent fact at its own scope: "we run our own in-house stock system." Answer slot, if she asks what that system does: say what you use it for, in your own words; if you do not know what it covers beyond your own use, say so plainly. Answer slot, if she asks how you would get up to speed: say how you would go about learning it, as a plan in your own words, and claim nothing about how quickly you have learned systems before. Hold by returning to those two sentences through two follow-ups, never by adding to them | F7 is the thinnest row against a line the advert names, and you have already volunteered the negative, so this objection arrives in some form. JD because it scores a stated requirement |
| B2 | "Which part of the advert would you be weakest at on day one?" | JD | [grounded] | Selection scaffold: pick the one line of the advert your own material carries least, name it first, and say how you would close it as a plan. The pack observes that F1, F4, F6 and F7 are the thinnest rows. If no such line comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stock Skeptic stem, and the advert is its raising source. JD because it asks you to rank the stated requirements |
| B3 | "We make diagnostic tests, and you've come from building-supplies wholesale. Where do you expect the job to be different?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Start from what you did, in those quoted terms. Answer slot: the advert's production schedules between planning, the warehouse and QA make a probe on production scheduling likely. If you have worked with production schedules or any of those groups, say how, in your own words; if not, or it was not yours, say so plainly and stay with the deliveries and the chasing. Put what you expect to differ to her as a question (R1) rather than asserting it as a fact | F1 is where the move from wholesale to manufacturing presses hardest. JD because it scores the production-scheduling line |
| B4 | "What's drawn you to Quillmoor?" | CO | [generic] | Selection scaffold: no company facts are in this pack, because the research did not run, so none are coached. Pick something from the advert's own listed duties that you actually want to do, and say it in your own words. If nothing about the company comes to mind beyond the job, say so plainly, then say which listed duty you would most want to do. Keep it consistent with A5 | The Skeptic's why-here arrives beside why-now. CO because it tests the homework, `[generic]` because company research was unavailable |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that figure was counted: discrepancies fell by about a third over a year." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what the sentence says, at its own scope. Then four slots, each answered in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; and which part was yours. If you do not know how it was counted, say so plainly, which is an honest answer. The pack supplies no method, baseline or assumption | F3 is a figure with nothing inspected behind it, which is what a Prober tests first. EXP because it checks attribution and counting |
| C2 | "How confident are you with Excel, and what do you do in it day to day?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what the sentence carries: you rebuilt the stock-count spreadsheet. Answer slot: if it was in Excel, say so and what is in it, in your own words; if it was another tool, or you did little beyond the rebuild, say so plainly and return to the rebuild. Name no function or feature you have not told the pack about | F6 is the advert's second stated requirement and the sentence does not name Excel. JD because it scores a stated requirement |
| C3 | "The role reports weekly on on-time dispatch. What reporting, if any, is part of your current work?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Say what the sentence carries, at its own scope. Answer slot: if you produce any regular report, say what it covers and how often, in your own words; if you produce none, or it is not yours, say so plainly and return to the deliveries | F4 is silence in the material and a named duty in the advert, so the probe is likely. JD because it scores that duty |

### D. Case / Strategist (low weight for this call)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that a delivery the week's production plan depends on will be four days late. What do you do first?" | JD | [generic] | Structure it aloud: what the delivery holds up and by when; who needs to know, which on this advert means planning, the warehouse and QA; what options exist; what you would ask the supplier for; what you would record. The question needs no claim about your past, so the guidance makes none | The advert's chase-late-orders and schedule-coordination lines, set as a live problem; CASE delivery, JD content. `[generic]` because it is a pattern for the problem |
| D2 | "The system says 120 units and the shelf has 90. Where do you start?" | JD | [generic] | Structure it aloud: whether the count or the booking is the likelier error, what you would check first and why, what you would do about the record today, and how you would stop it recurring. The question needs no claim about your past, so the guidance makes none | The advert's stock-accuracy line as a live problem; CASE delivery, JD content. `[generic]` because it is a pattern for the problem |

### E. Pressure (low weight for this call)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Pause and restate the question. Hold the sentence you said: "I schedule deliveries for our three depots and chase suppliers when orders slip." Concede the specific gap: "I haven't used SAP." Claim nothing about the other candidate. Hold through two follow-ups by returning to the same sentence, never by adding to it | F7 is the gap a Pressure interviewer leans on. JD because it tests the stated ERP line under composure |
| E2 | "That figure, a third: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the sentence: you rebuilt the stock-count spreadsheet. Answer slot: say which part was yours; if anything else changed over the year, or you do not know what moved the figure, say so plainly. Hold through two follow-ups by returning to the rebuild, then concede the specific thing you do not know | F3 again, in Pressure packaging. EXP because it tests attribution honesty |

### F. Peer Evaluator (low weight for this call)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Planning and the warehouse each ask for something different on the same morning. How do you decide whose goes first?" | CASE | [generic] | Propose principles rather than pretending to know the seam: what each is blocked on, what is time-critical, who else is waiting, agree the order with both and tell them why, and escalate when you cannot settle it. Frame it as what you bring them. The question needs no claim about your past, so the guidance makes none | The advert puts the role between planning, the warehouse and QA. `[generic]` because it is a pattern for the problem |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time your work depended on another team; it needs what you did, what they did and how the work was named afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stock Peer stem, tied to the advert's cross-team role. EXP because it tests how you describe shared work |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B3, D1, F1 |
| Track supplier deliveries and chase late orders | D1 |
| Keep stock records accurate | C1, D2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, E1 |
| £38,000–£44,000 | A2 |
| Hybrid, two days a week at Avonmouth | A4 |
| Notice period (Hannah's message) | A3 |
| What is prompting a move (Hannah's message) | A5 |

## Reverse questions

For you to ask Hannah, in the closing slot of a screen where "any questions" is scored.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of planning, the warehouse and QA would I work most closely with day to day?" | The advert names all three, and her answer shows which slot in B3 and F1 matters most. It also puts the wholesale-to-manufacturing difference to her as a question |
| R2 | "What does the process look like after this call, and who would I meet next?" | It lets you aim the later rounds at the right bank, since a hiring-manager round weights Case and Skeptic up |
| R3 | "Which system does the team use today, and how is a new starter trained on it?" | It treats the ERP gap as something to plan for, and she can answer it in a sentence |
| R4 | "What would a good first three months look like in this role?" | It shows you are thinking about the weekly dispatch reporting and the stock records as outcomes |
| R5 | "How are the two Avonmouth days usually set, fixed days or agreed with the team?" | It is the employer's side of the hybrid pattern she asked about, and it shows you have thought about how the week would run |

## Prohibited claims

What this pack will not coach, with the basis for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't used SAP." No slot |
| Has ERP experience | Inflated form of F7 | F7's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation, not words for you: the material says an in-house stock system, not an ERP. B1's slot stays inside what that system does for you |
| Coordinated production schedules across planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries and chasing, not production schedules. B3's slot stays inside the deliveries |
| Cut stock discrepancies by a third through the rebuild | Inflated form of F3 | F3's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence gives the rebuild and the fall, and does not say what caused the fall. C1 and E2 ask only how it was counted and which part was yours |

## Sources

Provided documents: your message, holding the advert, Hannah Lowther's LinkedIn message and your own notes. No `tuesday-dossier.md` was present.

Searches sent, all refused by the host before returning anything:

- `Quillmoor Diagnostics company values`: refused
- `Quillmoor Diagnostics interview process operations coordinator`: refused
- `Quillmoor Diagnostics Avonmouth news strategy`: refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The one call was refused. It would have fed a values-style round's VAL bank and B4's company grounding; B4 is `[generic]` instead |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | The one call was refused. It would have shown the rounds after this call and tuned the weights for Case, Pressure and Peer |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The one call was refused. It would have grounded B4 and a company-strategy question |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The one call was refused. It would have supplied an interviewer read and a reverse question tied to her path; that section is absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the lines you would put on it → F1 to F7 take the CV's own wording as evidence; the stock-count spreadsheet itself, or any regular report you produce, would lift F3 and F4 toward `high`
- Whether the stock-count spreadsheet is in Excel, and whether you produce any regular report → F6 and F4 each move from an answer slot to a quoted row
- Your actual notice period → F10 and A3 become a quoted row
- Search permission for Quillmoor → a company-grounded B4, any published values, the later rounds, and Hannah's public footprint for an interviewer read; a deeper pass is available too, up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from an earlier check of this role → user-verified evidence, a named highest-priority objection, and any prohibited claims, in place of the ones inferred here
