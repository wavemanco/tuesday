# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, name not given. Relationship: not stated, so built as a hiring-manager-style round. Format, from your message: a text chat on Telegram.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries one persona (its bank) and one type (its tag).
- Type key:
  - EXP: a deep-dive on your work experience; do your claims survive follow-ups, and what was actually you.
  - JD: a question from the ad's stated requirements; can you do the listed job, gaps included.
  - VAL: whether past behaviour shows what a company values; no published Lumenvale values were available, so these use generic themes.
  - CO: company and strategy knowledge. This pack has none, because research was unavailable (see Sources).
  - CASE: a live problem from the role, scored on structure and reasoning.
- Guidance is scaffolding, not a script. It is written to be typed as a few short messages, since your interview is a text chat.
- Bank letters skip F so they never collide with fit-snapshot rows (F1 to F6).
- Highest-ROI prep: B1. It is the question this pack expects to be asked in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length. Say it in the quote's own terms: the role, the three years, the energy supplier. A line with nothing inspected behind it, so expect a probe on the role. The pack's observation: the quote names an energy supplier, not a software company |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Lead with the tool by name and the frequency, in the quote's own terms: "I use Freshdesk every day." The pack's observation: your material names Freshdesk, not Zendesk, and says nothing about setting the tool up. Answer slot: the ad names Zendesk, so expect a probe on it. If you have used it, say where, in your own words; if you have not, or it was not part of your work, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — the job ad, as you described it | "answering around 60 calls and emails a day" — your message | medium | [grounded] | discovery | The quote reaches written work through the emails, and it counts calls and emails together. Say it in its own words and at its own scope. The pack's observation: the material does not split calls from emails and does not show what made a reply clear. Answer slot: if asked what share was written, say what you know, in your own words; if you did not track the split, say so plainly and return to the quote |
| F4 | "confidence handling escalations" — the job ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad raises them, so expect a probe. If you handled any, say what happened and what part of it was yours, in your own words; if escalations were not part of your work, or went to someone else, say so plainly and describe the day-to-day work you did have |
| F5 | supporting colleagues who are new to a process — a role-family pattern, no source supplied | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Say it at its own scope: four new starters, the refunds process, last year. The pack's observation: the material says four starters and one process, not a training programme or the team's whole onboarding. No slot is raised, since nothing supplied asks for this |
| F6 | working in a software company's support team — a role-family pattern, no source supplied | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn it, said as a plan and never as a past. Never a claim to software-company support work, and nothing added to make the gap feel smaller |

## Persona table

The loop is established by your message: one session, a text chat with the support team lead. No further rounds are documented, so no archetype fallback is used. No values round is documented, so there is no values cheat sheet.

| Persona (bank) | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live support scenarios typed into the chat: write the reply, handle the escalation, triage a spike | High. A team lead hiring for a role is buying capability and checking what a short chat can show; scenarios fit a text format. Held at the top weight with B | Clarify, then structure, then answer; write replies as you would on a ticket (A1, A2, A3, A5) |
| Skeptic (B) | Quiet probing of the energy-to-software move, the missing escalation evidence and Zendesk | High. F6 is a stated gap and F4 has nothing under it; a hiring-manager round presses the gaps | Rehearse B1 until it is boring: hold the quote, state the limit, give a plan (B1 to B4) |
| Data-Driven Prober (C) | Line-by-line questions on your own sentences: how a figure was counted, how the training went | Medium. Your material has one figure and one training claim, so there is a little for a prober to press | Know what you can and cannot say about each sentence; say plainly when you do not know (C1, C2, C3) |
| Conversational / Rapport Builder (D) | A friendly opener and casual questions that are still scored | Medium. A text chat usually opens softly, and the casual questions carry the same weight | A short, quoted arc for "tell me about yourself" (D1); treat casual questions as scored (D2, D3) |
| Pressure (E) | Time-boxed or devil's-advocate challenges | Lower. Interruption is harder in a text chat, but a short-fuse "sixty seconds" or "how much was you" can still arrive | Hold the quoted position through two follow-ups, then concede only what is true (E1, E2) |
| Values / Behavioral (G) | "Tell me about a time" prompts, mapped to customer-first themes | Lower. No values round or published values were found, so these use generic themes | A scaffold ending in the honest branch if no story comes to mind (G1, G2) |
| Peer Evaluator (H) | Collaboration and what-would-you-need questions | Lower. If the lead is a future manager this is light, and it rises if they turn out to be a peer | Reciprocity: what you would need and what you would bring (H1, H2) |

## Question banks

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in capital letters that they were charged twice and want to cancel today. You have one message to reply. What goes in it?" | CASE | [generic] | Structure the one message: acknowledge the double charge in plain words, say what you will check or do and by when, and ask only for what you need in order to act. If someone else has to approve a refund, say so and say what happens next. The question needs no claim about your past, so the guidance makes none | A live written reply drawn from the ad's writing line (F3), asked as a decision. CASE because it is a live problem |
| A2 | "A customer has asked three times for the same fix and says they will leave a public review. You cannot resolve it yourself. Walk me through what you do." | CASE | [generic] | Structure it: what you would check first, what you tell the customer now, who it goes to and what you hand over with it, when you will update the customer next, and what you record on the ticket. Keep the tone level. The question needs no claim about your past, so the guidance makes none | The ad's escalation line (F4) as a live decision rather than a record. CASE because it asks about no past |
| A3 | "Ticket volume doubles after a software release. What do you want to know first, and what do you do in the first hour?" | CASE | [generic] | Clarify before structuring: what changed, which tickets, how severe. Then one holding reply for everyone affected, group the duplicates, tell your lead what you are seeing, and give customers a time for the next update. The question needs no claim about your past, so the guidance makes none | Puts you in a software setting you have not worked in (F6) and scores clarify-then-structure there. CASE because it is a live problem |
| A4 | "You'd be in our ticketing tool from day one. Tell me how you use Freshdesk day to day." | JD | [grounded] "I use Freshdesk every day" — your message | Story-mapped on F2: the tool and the frequency are the beats the quote states; say them in your own words. Answer slot: the ad names Zendesk, so expect a probe on it. If you have used it, say where; if you have not, or it was not part of your work, say so plainly and stay with Freshdesk | F2 is the evidence for the ticketing requirement and the likeliest place for a tool-specific probe. JD because it scores the stated requirement |
| A5 | "Write me the reply you'd send to a customer whose refund has not arrived after ten days." | CASE | [generic] | Write the actual reply in the chat, as you would on a ticket: greeting, what you would check (say what you would check, not results you have not seen), what happens next and when, and a clear close. Short sentences. The question needs no claim about your past, so the guidance makes none | F3 is the writing requirement, and in a text chat your replies are the writing the interviewer can see. CASE because it is a live task |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is energy, not software. What will be hardest for you in the first month?" | JD | [grounded] "I've never worked for a software company" — your message; "3 years as a customer service advisor at an energy supplier" — your message; "I use Freshdesk every day" — your message | The highest-ROI rehearsal in this pack. Hold: "I've never worked for a software company." Then only what the quotes carry: the three years as a customer service advisor at an energy supplier, and that you use Freshdesk every day. Then a plan, never a past: what you would learn first and who you would ask, only steps you would really take. Follow-up 1, "How do you know you'd pick it up quickly?": return to the quotes and concede plainly that you cannot know until you are doing it. Follow-up 2, "Tell me about a time you learned something technical fast." Answer slot: if one comes to mind, say what it was and what you did, in your own words; if none does, say so plainly and describe how you would go about it | F6 is the biggest gap and this objection arrives in some form. JD because it scores fit for the listed job; Skeptic delivery |
| B2 | "Why are you leaving energy for software support, and why us?" | JD | [generic] | Selection scaffold: give your actual reason in one or two sentences, one that points toward this role and not only away from the last one. Then name one thing from the ad that you really want to do. This pack holds no verified facts about Lumenvale, so use none; if no single reason comes to mind, say so plainly and give the nearest true one | The motivation probe a gap like F6 invites. JD because it scores fit for this job; `[generic]` because research on the company was unavailable |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Choose from the ad's four lines the one that is true for you and name it plainly, then say the first step you would take to close it, as a plan. The pack's observation, for your own choosing: your material shows least on escalations (F4) and says nothing about Zendesk itself (F2). Do not offer a weakness you do not have | The Skeptic stem for a candidate with thin rows. JD because it scores the stated requirements |
| B4 | "What escalations have you handled, and what was your part in them?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Answer slot: the ad raises escalations, so expect this probe. If you handled any, say what happened and what part of it was yours, in your own words; if escalations were not part of your work, or went to someone else, say so plainly and return to "answering around 60 calls and emails a day." Do not describe how an escalation usually goes as if it were yours | F4 has nothing under it, so this is where the probe lands. EXP because it tests what was actually yours |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The figure is 'around 60 calls and emails a day.' How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Say the figure at its own scope: calls and emails together. Answer slots, in your own words: how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest answer if it is true | F3's headline figure, the one a prober presses first. EXP because it tests attribution |
| C2 | "Walk me through how you trained the four new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Story-mapped on F5: four new starters, the refunds process, last year. Those are the beats the quote states; tell them in your own words and add nothing it does not say. If asked something you cannot answer from what you did, or that was not yours, say so plainly | F5 is a claim that invites a follow-up on how. EXP because it tests what was actually yours |
| C3 | "You'd be writing to customers all day. What makes one of your replies clear?" | JD | [grounded] "answering around 60 calls and emails a day" — your message | Give your own standard in two or three plain sentences. It is a view about your writing, not a claim about what you did. If an example would help, use a real reply of yours; if none comes to mind, say so and stay with the standard | F3 is the writing requirement and its evidence does not show what made a reply clear. JD because it scores the stated requirement |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me about your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" — your message; "answering around 60 calls and emails a day" — your message; "I use Freshdesk every day" — your message; "I trained four new starters on our refunds process last year" — your message | Four beats, each one a sentence you wrote: the three years as a customer service advisor at an energy supplier; answering around 60 calls and emails a day; Freshdesk every day; training four new starters on the refunds process last year. Then why this role, in your own words. In a text chat, put it in four or five short lines | F1, F3, F2 and F5 are the pool this answer draws on. EXP because it tests whether your own story holds together |
| D2 | "What kind of customer do you enjoy helping most?" | JD | [generic] | Answer honestly in one or two sentences. A story is optional; if you reach for one, use a real one, and if none comes to mind, say so and give the kind of customer you mean | A casual question that is still scored on economy and interest. JD because it probes fit with the work the ad lists |
| D3 | "What does your remote working set-up look like?" | JD | [generic] | Describe your own set-up as it is. Where something is not in place yet, say so plainly instead of promising it | The role is remote per your message. The pack holds no facts about your set-up, so it supplies none |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" — your message; "I use Freshdesk every day" — your message; "I've never worked for a software company" — your message | Hold the quotes: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Hold through two follow-ups without adding to them. Concede the one thing that is true: "I've never worked for a software company." Never fold on what the quotes carry just to ease the exchange | F1 and F2 are the held position and F6 is the concession. JD because it scores fit for the listed job; Pressure delivery |
| E2 | "Sixty a day sounds like volume. How much of that was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Hold the quote at its own scope: answering around 60 calls and emails a day. Answer slot: if any of the figure was shared, or counted a different way, say how; if you cannot split it, say so plainly. Concede only what is true, and specifically | F3 is where an attribution challenge lands. EXP because it tests what was actually yours |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a choice you made, and what the customer got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values stem for a support role. Lower weight because no values round or published values were found |
| G2 | "Tell me about a time you had to say no to a customer." | VAL | [generic] | Selection scaffold: pick a time with a clear request, your decision and how the customer took it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The ad's escalation line (F4) raises this theme. VAL because it scores past behaviour, not a published value |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "We'll be working side by side. What would you need from us in your first weeks, and what would you bring?" | JD | [grounded] "I use Freshdesk every day" — your message; "I trained four new starters on our refunds process last year" — your message | Two halves. What you would need, as a plan: what you would ask for and who you would ask. What you would bring, in the quotes' own terms: Freshdesk every day, and training four new starters on the refunds process last year. Nothing wider than those two sentences | Reciprocity framing, drawing on F2 and F5. JD because it scores fit with the team |
| H2 | "A colleague tells you, in front of the team, that you handled a ticket wrongly. What do you do?" | CASE | [generic] | Structure it: listen, check the ticket, fix it and tell the customer if they are right, say so privately with specifics if you disagree, then agree how it is handled next time. Show spine and tact together. The question needs no claim about your past, so the guidance makes none | A disagreement-with-equals scenario. CASE because it is a live problem |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| "2+ years in customer support" | E1, D1 | E1 is JD-tagged; D1 is the biography arc |
| "experience with Zendesk or a similar ticketing tool" | A4, B3 | A4 holds the Zendesk answer slot |
| "clear written communication" | A1, A5, C3 | A1 and A5 are live writing |
| "confidence handling escalations" | A2, B4, G2 | B4 holds the answer slot |
| Software-company background (F6, not a listed requirement) | B1, B2, E1 | B1 is the highest-ROI prep |
| Company and strategy knowledge | none, and why | Research was unavailable, so no CO question was written |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a good first month look like for someone new on the team?" | It turns the ramp-up probe into a plan you are already working on |
| "Which tickets reach you as escalations, and what does a good handover look like?" | It shows you take the ad's escalation line seriously and want the team's own standard |
| "Which ticketing tool does the team use, and how do new starters learn the product?" | It speaks directly to the tool requirement and the product learning curve |
| "Will there be a call or video chat after this, and how long should I expect this chat to run?" | It lets you prepare for the right format and shows you are planning ahead |
| "How does the team measure good support, and what would you most like to improve?" | It moves from your numbers to theirs and invites a real answer |
| "Which hours and time zones does the team cover?" | It covers a practical term for a remote role, so you are not guessing later |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in software or software-company support | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never worked for a software company." No slot |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: the material names Freshdesk, not Zendesk. A4's slot stays inside Freshdesk |
| Administered or configured Freshdesk | Inflated form of F2 | F2's quote at its own scope. The material says use, not set-up |
| Handles around 60 written tickets a day | Inflated form of F3 | F3's quote at its own scope: calls and emails together. The material does not split them or say they were tickets |
| Ran or led training or onboarding for the team | Inflated form of F5 | F5's quote at its own scope. The material says four new starters and one process, not a programme |

## Sources

Provided documents: your message (the job ad's requirements as you described them, and your background), and the invite text (the round format: one text-chat interview with the support team lead).

Queries sent:

- `Lumenvale Software company values` — refused
- `Lumenvale Software interview process customer support specialist` — refused
- `Lumenvale Software strategy recent news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Every call was refused. It would have fed VAL questions by value name and a values cheat sheet, if a values round had been documented |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Every call was refused. It would have shown whether further rounds follow; the loop here rests on the invite's own words |
| 3. `Lumenvale Software strategy recent news` | unavailable | Every call was refused. It would have fed CO questions and a grounding brief |
| 4. `{interviewer name} Lumenvale Software` | n/a | The interviewer is described only as the support team lead, so there was no name to query; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The requirements you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad → the quoted requirements in F1 to F4 come from the ad itself rather than from your description, and any hours, location or pay terms become fit rows
- Whether the support team lead would be your manager or a peer → persona weights are recomputed, and a reciprocity question is added if a peer
- Permission to search on Lumenvale → the three L1 targets would run; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is offered once after that
- Your own answers on F4 and F2: any escalations you handled, and any use of Zendesk → those two rows move from answer slots to quoted evidence
- The support team lead's name → an interviewer read and a reverse question tied to their own path
- Anything the sender says about the chat's length or format → coverage is tuned to it
- A `tuesday-dossier.md`, if you have one → verified evidence and a named top objection, which this pack builds without
