# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead (name not given). Format: a text chat. Relationship assumed to be manager-style until you say otherwise, so the pack is built as a hiring-manager round.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say things in your own words, and say only what you actually did. Because the interview is a text chat, every reply you send is also a sample of the ad's "clear written communication" line (F3), so rehearse in short, well-ordered messages.

Type key:

- VAL: behavioral or values alignment (no questions here: no published values were in hand and no values round is documented)
- EXP: work-experience deep-dive; do your claims survive scrutiny
- JD: role and job-ad driven; can you do the listed job, gaps included
- CO: company and strategy knowledge
- CASE: a live problem from the actual role

Label key: `[grounded]` traces to something you gave me; `[inferred]` is my derivation, named in the row; `[generic]` is a role-family pattern with no claim about Lumenvale or about you.

## Fit snapshot

Requirements are the ad's four lines as you described them in your message. Evidence is your own sentences, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message; "answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with the years and the role in the quote's own terms, and let the volume line sit as you said it: around 60 calls and emails a day |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your words name Freshdesk and the ad names Zendesk or a similar tool. Say it in the quote's own terms, naming the tool you use rather than the one the ad names: "I use Freshdesk every day." Leave the comparison to the interviewer |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote has emails in it and says nothing about how they read. Answer slot: the ad's line, and a chat interview, make a probe on your writing likely. If any of your replies were reviewed or rated, say how, in your own words; if not, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: expect a probe on a case that went beyond you. If a case was passed up to you or by you, say what happened and what part was yours, in your own words; if escalations were not part of your role, or none reached you, say so plainly and stay with the calls and emails you answered |
| F5 | Software-company context: a gap you raised yourself, not a line of the ad | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past |
| F6 | Helping colleagues learn the work: a role-family expectation, not a line of the ad | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap on its own terms, but a self-reported line with nothing inspected behind it. Tell it at its own scope: you trained four new starters on your refunds process, last year |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live support scenarios: repeat contacts, bugs you cannot see, triage, a customer demanding a manager | High. The invite says the interview is a text chat with the support team lead; the hiring-manager prior is Case plus Skeptic, and F3 and F4 are lines a live scenario can test | Clarify first, say what you would do and what you would not promise, say when you would hand over and what you would write; keep each message short |
| B. Skeptic | Quiet, persistent probing of the thin rows: escalations, software context, the tool named in the ad, why leave energy | High. F4 is the ad line your material is silent on and F5 is a gap you stated; F2 names a different tool | Rehearse the most predictable objection (B1) until it is boring; plain acknowledgment where you have a stated negative, then a plan; no bluffing |
| C. Data-Driven Prober | Goes line by line through the numbers: how the sixty a day was counted, who the four starters were | Medium. F1 and F6 each carry a figure, and a CV-style line invites the denominator | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| D. Conversational / Rapport Builder | Friendly openers: walk me through your journey, what is a normal day | Medium. A chat interview tends to open casually, and casual questions are still scored | A short arc built only from your own sentences; treat casual questions about the ad's lines as scored |
| E. Pressure / Stress | Time-boxed or devil's-advocate challenges: why you over someone with software experience | Low. The hiring-manager prior does not weight it; two questions cover F5 and F6 under pressure | Pause, restate, hold what your quotes carry through two follow-ups, concede specifically |
| G. Peer Evaluator | What you would need from the team, how you handle disagreements with colleagues | Low. A support team lead may behave collegially; if you tell me they are a peer, this rises | Reciprocity framing: what you bring the team as well as what you need |

## Question banks

Highest-ROI prep in the pack: B1, the escalation question. The ad asks for confidence handling escalations, your material is silent on it (F4), and it will arrive in some form.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem and says they are thinking of cancelling. What is your next reply?" | CASE | [generic] | Structure it; it needs no claim about your past. Acknowledge the repeat contact specifically, say the problem back in one line so they know it was read, say what you will do now and by when, and say what you will not promise. In a chat, write the reply out as you would send it, short | A live problem built from the written-communication line (F3); in a text interview the reply is itself the evidence. CASE because it scores structure under a realistic customer message |
| A2 | "A customer says the fix you gave did not work, and it may be a fault on our side that you cannot see. What do you do?" | CASE | [generic] | Structure it; it needs no claim about your past. Ask first what they see and what changed, say plainly that you do not yet know the cause, tell them what happens next, and pass it on with the details a colleague would otherwise have to ask for again | F5 is the row this probes: problems on the product side are where software context matters most, and the question tests whether your structure holds without it. CASE because it is a live problem |
| A3 | "You have an outage report, a billing error and a how-to question all waiting. How do you order them, and what do you tell the people waiting?" | CASE | [generic] | Structure it; it needs no claim about your past. Ask first how the team sets priority, then reason on impact and urgency, and tell waiting customers honestly what to expect. Do not pretend to know their rules | Triage under volume is a natural test given F1. CASE because it asks for structure and reasoning on a problem from the role |
| A4 | "A customer demands a manager and says they will post about us publicly. How do you handle it, and when do you hand it over?" | CASE | [generic] | Structure it; it needs no claim about your past. Stay with the customer's actual problem, acknowledge without arguing, say what you can do now, name the point where it needs someone with more authority, and say what you would write in the handoff | The ad's escalation line (F4) arrives here as a live problem as well as an experience question. CASE with JD content |
| A5 | "What do you know about Lumenvale and who our customers are?" | CO | [generic] | Nothing about Lumenvale could be established for this pack, so the answer has to come from the company's own website and product pages beforehand: what it makes, who uses it, one thing you would want to ask. If you find little, say so plainly and ask the team who their customers are | Homework depth is scored in any round, and F5 makes it likelier here. CO; labelled generic because no company facts were in hand |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a customer's problem was escalated and you were involved." | JD | [grounded] "answering around 60 calls and emails a day" | The highest-ROI rehearsal in this pack. Pick a case with a named stake, a point where it left your hands or came to you, and what you did next, and speak only to what you did. Answer slot: if you passed a case up, or took one over, say what happened and what part was yours, in your own words; if escalations were not part of your role, or none reached you, say so plainly and describe the work in the quote's own words, answering around 60 calls and emails a day. Rehearse the plain version until it is boring | F4 is the ad line your material is silent on, so this question will arrive. JD because it scores a stated requirement; EXP delivery |
| B2 | "You have not worked for a software company before. How would you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company" | Start with your own words: "I've never worked for a software company." Then a plan, never a past: pick the steps you would really take in your first weeks, such as using the product as a customer would, reading its help content, and asking the team which questions come up most. Say only what you would do | F5 is a gap you stated, so the question is near-certain. JD because it scores the role's product demands, asked as a ramp plan |
| B3 | "The ad names Zendesk, and you use Freshdesk. How would you get comfortable on our ticketing tool?" | JD | [grounded] "I use Freshdesk every day" | Lead with the quote: "I use Freshdesk every day." Then how you would learn the new tool, as a plan. Answer slot: if you have used Zendesk, say where, in your own words; if not, say so plainly and return to Freshdesk. Give your own honest estimate of how long you would need, or say you would ask the team how long onboarding on it usually takes | F2 is graded presentation: the evidence is real and the tool differs. JD because it scores the ad's tooling line |
| B4 | "Why a software company after energy?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "I've never worked for a software company" | The reason has to be yours, in your own words; the pack supplies none. Pick the real reason it is this role and this company. If no reason comes to mind beyond wanting the job, say so plainly, then say what in the ad appeals, or how you would handle the change | Skeptics probe why leave, why here, why now, and F5 makes the change visible. EXP because it tests the consistency of your story |
| B5 | "Which part of this job would you find hardest in your first month?" | JD | [grounded] "I've never worked for a software company" "I use Freshdesk every day" | Calibrated candor: name one thing, say plainly that it is a gap, and add a plan. Your own words point to the product side and to a tool the ad names that your material does not name as yours. Pick the one that is true for you; do not claim to have no weak spot | A standard skeptic stem aimed at F5 and F2. JD because it scores honest self-assessment against the ad |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around sixty calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | State it as you said it: around 60 calls and emails a day. Answer slots, each in your own words: how it was counted, if you know; if you do not, say so plainly. What the figure is sensitive to, if you know. The assumption behind it you would defend least. Which part was yours | F1 carries the headline figure, which is a magnet for probers. EXP because it tests attribution and honesty about how a number was reached |
| C2 | "How many of those were calls and how many were emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | The quote says around 60 and does not split calls from emails. Answer slot: if you know the split, say it as you know it; if you do not, say so plainly and stay with "around 60 calls and emails a day". Do not estimate a split you cannot stand behind | F3 is why the written share may matter to this interviewer. EXP because it presses one level deeper into the same figure |
| C3 | "Walk me through how you trained the four new starters on your refunds process." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped on F6: the beats the quote states are four new starters, the refunds process, and last year; tell them in your own words. Say plainly what part was yours. The pack adds no further beats | F6 is the only evidence of helping others learn the work. EXP because it tests what was actually yours |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: how did you get here and why this role?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | A short arc in three or four lines of chat, using only those four sentences in your own words. Why this role is your own reason, in your own words; the pack supplies none | A friendly opener that is still scored for economy and genuine interest. EXP because it is a CV walk-through; F1, F2 and F6 supply the beats |
| D2 | "What does a normal day look like for you right now?" | EXP | [grounded] "answering around 60 calls and emails a day" "I use Freshdesk every day" | Say what those two sentences say: calls and emails, and Freshdesk. Anything beyond that is yours to say in your own words, and only if it is true | A casual question that tests whether your daily reality matches the ad (F1, F2). EXP |
| D3 | "What makes a customer reply good, in your view?" | JD | [generic] | Your own view in a few lines. A pattern many people use: what happened, what we will do, and by when. It makes no claim about your past, so nothing here says what you have done | The ad's written-communication line (F3) asked casually. JD; generic because it asks for a view, not a fact about you |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already supported software?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "answering around 60 calls and emails a day" "I use Freshdesk every day" "I've never worked for a software company" | Hold-then-concede. Pause and restate the question. Hold only what those quotes carry: three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day, and using Freshdesk every day. Concede specifically: "I've never worked for a software company." Hold through two follow-ups by returning to those facts, and never add a claim to win the exchange | The sharpest form of F5. JD because it scores fit against the ad under time pressure |
| E2 | "That training you gave: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the quote: "I trained four new starters on our refunds process last year." Say plainly what part you did, and concede any part that was someone else's or that you do not know. Do not enlarge it to defend it | F6 is a self-reported line, and attribution is the usual pressure probe. EXP |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When you are stuck on a ticket, what do you need from the team, and what can we expect from you?" | CASE | [generic] | Reciprocity framing, as a plan and not a past: what you would bring (a clear handoff, saying what has already been tried) and what you would ask the team for. Ask how the team usually handles handoffs rather than pretending to know | A peer-style question about the seam between you and the team. CASE because it is a live working scenario; no claim about you |
| G2 | "Tell me about a time you disagreed with a colleague about how to handle a customer." | EXP | [generic] | Selection scaffold: pick a time with a named stake, the disagreement stated fairly, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement style with equals is what a peer scores. EXP; generic because nothing in your material carries this story |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" (F1) | C1, C2, D1, D2, E1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | B3, D1, D2 |
| "clear written communication" (F3) | A1, D3, C2 |
| "confidence handling escalations" (F4) | B1, A4, A2 |
| Software-company context (F5) | B2, B4, B5, A2, A5, E1 |
| Helping colleagues learn the work (F6) | C3, E2, D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first month look like for someone new to your product?" | Turns the software-context gap (F5) into a ramp conversation and shows you are planning for it |
| R2 | "How does the team handle escalations: where is the line between solving a ticket and handing it on?" | Shows you are thinking about the ad's escalation line (F4), and gets you the team's real rule |
| R3 | "Which ticketing tool does the team use day to day, and how do new starters get trained on it?" | Addresses F2 openly and shows you care about getting productive |
| R4 | "What does good written communication look like on your team: is there a style guide, or are replies reviewed?" | Signals you take the ad's written-communication line seriously (F3), and shows you what is measured |
| R5 | "Will there be another stage after this chat, such as a call or video with the team, so I can prepare for the right format?" | A practical prep question about format; it shows you plan ahead |
| R6 | "What could a new person do in their first month that would genuinely help the team?" | Reciprocity: it shifts from what you need to what you bring, which a peer-style interviewer weights |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk. B3's slot stays on whether you have used it |
| Software or SaaS support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Ran or designed a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says the training, not a programme |

## Sources

Provided documents: the Telegram invite and the description of the ad's four requirements, plus your background, all in your message. No company documents, ad text or CV were supplied.

Searches sent, all refused, nothing returned:

- "Lumenvale Software company values": refused
- "Lumenvale Software interview process customer support specialist": refused
- "Lumenvale Software news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Every call was refused. Would have moved: a values cheat sheet and VAL themes; none are in this pack |
| 2. Lumenvale interview process, support | unavailable | Every call was refused. Would have moved: documented loop structure; the persona weights rest on the invite's single text chat with the support team lead and the hiring-manager prior |
| 3. Lumenvale strategy and recent news | unavailable | Every call was refused. Would have moved: a strategy-grounded CO question; A5 is generic instead |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Customer Support Specialist ad | skipped | Your four requirements fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text: the four requirement quotes become the ad's own words, and any terms it states (hours, time zone, pay, right to work) become rows of their own
- The team lead's name and whether they would be your manager or a peer: a tailored reverse question, and persona weights reset from their role
- Any prep guidance on the chat (time limit, focus areas, a task to do beforehand): coverage added for it
- Your answers to the slots in F3 and F4, said outside the pack's drill: those rows are rebuilt on your own sentences instead of slots
- Your CV: the evidence cells quote it in place of your message
- Search permission: Lumenvale's values, documented process and strategy become grounded rows, and A5 stops being generic; a deeper pass would be up to 6 more searches and 2 more fetches, several more minutes
- A tuesday-dossier.md from an earlier pass: verified evidence, prohibited claims and the likeliest objection taken from it instead of inferred here
