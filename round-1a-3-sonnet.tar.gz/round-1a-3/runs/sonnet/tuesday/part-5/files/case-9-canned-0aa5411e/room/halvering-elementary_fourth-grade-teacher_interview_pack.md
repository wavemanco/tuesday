# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Role:** Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
- **Round:** one 45-minute panel on Thursday
- **Panel:** Principal Dolores Vantongeren (hiring-manager seat) and two members of the fourth-grade team (peer seats, names not given)
- **Built on:** the invite and your résumé text. No job description was supplied, so JD-derived rows rest on a representative listing and are marked `[inferred]`.

## How to use this pack and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Wherever guidance says "answer slot", it is an instruction for the interview, and either honest branch is a good answer.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the district's published beliefs |
| EXP | Work-experience deep-dive | Whether your résumé claims survive scrutiny, and what was actually you |
| JD | Role-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth on the district's published plans |
| CASE | Live problem | Structure and reasoning on a problem from the actual role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, with nothing inspected behind it beyond your own statement. Say it in the CV's terms: kind, endorsement, status, expiry. Words: "I hold an Illinois Professional Educator License with an elementary endorsement for grades 1–6, active through June 30, 2029." The license number is not needed in the interview and is not in this pack |
| F2 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. B1 is the highest-ROI rehearsal |
| F3 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, a representative posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | The quote shows the grade and the years, not which subjects. Answer slot: the listing names five subjects, so expect a probe on which you taught. If you taught any of them, say which, in your own words; if some were taught by others or were not yours, say so plainly and stay with what you did teach |
| F4 | "reading instruction" — the district's hiring page, which says panels ask about it | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | none | No gap in role-relevant terms, but CV lines with nothing inspected behind them, so expect a probe on both. Lead with them in their own terms. Answer slot: the hiring page names reading instruction, so expect a probe on what you do day to day. Say it in your own words; if the two sentences are all you can say, say so plainly and stay with them |
| F5 | "classroom routines" — the district's hiring page, which says panels ask about it | none given | none | [grounded] | discovery | Your material does not show routines either way. Answer slot: if you set routines in your own room, say which and why, in your own words; if you have not set routines yourself, say so plainly and describe how you would |
| F6 | "differentiate instruction using assessment data" — K12 Jobs Board listing, a representative posting | none given | none | [inferred] | discovery | Your material does not show this either way. Answer slot: if you have changed what you taught for different students based on assessment results, say how, in your own words; if not, or it was not yours, say so plainly and say what you would look at first |
| F7 | "Families Are Partners: each teacher speaks with every family each term." — the district's mission and beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The quote is a weekly email, not conversations, and the words stay there: "I write a weekly email to families." Answer slot: the belief says each teacher speaks with every family, so expect a probe on direct conversations. If you spoke with families, say how and how often, in your own words; if the email was how you reached them, say so plainly and stay with the email |
| F8 | "Every Child a Reader: no student leaves third grade without a reading plan." — the district's mission and beliefs page | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've run the after-school reading club for the last two years." — your CV | low | [inferred] | discovery | Both quotes touch reading and third grade; neither speaks to reading plans. Answer slot: the belief names a reading plan for every student leaving third grade. If reading plans were part of your third-grade work, say how, in your own words; if there were none, or they were not yours, say so plainly and stay with the club |
| F9 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — the district's mission and beliefs page | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if assessment results changed what you taught, say what and how, in your own words; if they did not, or that was not yours to decide, say so plainly and say how you would use them |
| F10 | "work with the grade-level team" — K12 Jobs Board listing, a representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your message | medium | [inferred] | none | The first quote reaches teamwork at grade level in its own terms. Keep "led" at the move's scope; it is not a team lead's role, and your plain acknowledgment is yours: "I haven't been a team lead." Answer slot: expect a probe on how the move ran among colleagues. If any part of how it ran was yours to set, say which; if it was set for you, or there was no such step, say so plainly and stay with the move |

## Persona table

The panel is a blend: the principal sits in the hiring-manager seat, and the two fourth-grade teachers sit in peer seats. The district's hiring page documents one 45-minute building panel on reading instruction, classroom routines and families, so these weights rest on a documented loop, not an archetype. No values-style round is documented, so there is no values cheat sheet. F-row references below point to the fit snapshot.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting, "what would you need from us", credit and disagreement | high: two of three seats are fourth-grade teachers, and the role is joining their team (F10) | Reciprocity: say what you would bring as well as what you need; propose principles for the seam instead of pretending to know it |
| B. Skeptic | Quiet probing of the gap: moving up a grade, why now | high: F2 is a stated gap and the likeliest question in some form | Rehearse the one predictable objection until it is boring; bridge only from adjacent evidence you stated; say the limit plainly, then give a plan |
| C. Case / Strategist | Live classroom problems and plan-level questions from the principal | high: the hiring page names reading instruction, routines and families as panel topics, and the principal's seat asks about the role itself | Clarify first, state the objective, structure, then answer; think aloud; challenge one premise respectfully |
| D. Values / Behavioral | Scenarios mapped to the three published beliefs | medium: the mission page says the beliefs guide every hire, but no round is documented as assessing them | Pick a real instance per belief, "we" for context and "I" for contribution; where none comes to mind, say so |
| E. Conversational | Friendly openers and "what draws you here" | medium: every panel opens this way, and casual questions are still scored | A 90-second arc in your own sentences; never answer "I think you've covered everything" to the reverse-question slot |
| G. Data-Driven Prober | "How do you know it worked" on your claims | low: the résumé text carries no outcome figures, so there is nothing to defend numerically, only attribution | Say plainly what you tracked and what you did not |
| H. Pressure | Time-boxed or devil's-advocate challenges | low: nothing in the sources suggests a stress style | Pause, restate, hold the position the quotes carry through two follow-ups, concede specifically |

## Reading the interviewer

Public professional footprint only. The two fourth-grade team members' names were not given, so their seats are read from the role, not from any profile.

| Public fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page, read as a search snippet | [grounded] | Reading questions may come from someone with a reading specialist's background. C1, E2, G1 and G2 are the rows to know cold |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | Same page, same snippet | [grounded] | If she raises small groups or conferences, answer from what you actually do. C1's structure leaves room for grouping. Do not adopt her vocabulary as your own practice |
| Mirror opportunity: her talk spans grades 3 to 5, and F4's evidence carries your reading club | Pairs the page above with F4: "I've run the after-school reading club for the last two years." | [grounded] | Offer the club in that sentence's terms if reading comes up. Do not say the club uses small groups or conferences unless it does |

## Question banks

Question IDs skip F so they never collide with fit-snapshot rows. This pack has 24 questions. The Question column is the interviewer's line.

### A. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You'd be joining our fourth-grade team. What would you need from us in your first month?" | JD | [grounded] "I've never taught fourth grade"; "I led our grade level's move to a new reading curriculum in 2024" | Start with the plain fact: "I haven't taught fourth grade." Then name what you would ask for, in your own words; the pack does not supply the list. Offer something back in the sentence's own terms: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you already know what fourth grade asks of students, say what and how you know; if you do not, say so plainly and say what you would ask them first | The peer seats price what a hire costs their team, and F2 makes this the natural opener. JD because it scores the stated role |
| A2 | "Where would the seam be between your classroom and the one next door, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not facts about this school. Keep the ones you actually hold: say what is shared and what is each teacher's own; raise a disagreement with the colleague first; follow the school's decision once made while saying what you would still like to revisit. The question needs no claim about your past, so the guidance makes none | F10's requirement is working with the grade-level team, and peers ask it as a seam question. JD, with a collegial delivery |
| A3 | "Tell me about a time you and a colleague disagreed about how to teach something." | JD | [generic] | Selection scaffold: pick a time with a named point of disagreement, what you said, what happened, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement stories show spine and tact together, and F10 is where teamwork is probed. JD, because the team requirement is the listing's |
| A4 | "How do you handle credit when a change involves the whole grade?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | If you use that move, say it as written. Answer slot: if colleagues shared the work, say who did what, in your own words; if you did most of it, or it was set for you, say so plainly and return to the sentence | F4 and F10 make attribution the likeliest follow-up. EXP because it tests what was actually yours |
| A5 | "What would you bring to our team that we might not already have?" | JD | [grounded] "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | Say each in its own words and let the panel draw the inference; do not tell them what these show. Choose the one that fits what they have said so far | The reciprocity slot for peers, rehearsed with F4 and F7 as its evidence. JD because it scores fit with the team |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't taught fourth grade. What will be hardest for you in your first month?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | **Highest-ROI prep in this pack.** The limit comes before anyone asks: "I haven't taught fourth grade." Then the sentence at its scope: "Six years teaching third grade at a public elementary school in Joliet." Then the hardest thing, in your own words; the pack does not name it. Rehearse three follow-ups. (1) "What changes between third and fourth?" Answer slot: if you have looked at what fourth grade asks of students, say what; if you have not, say so plainly and say what you would look at first. (2) "What would you want from us?" See A1. (3) "How will we know you're ready?" Say how you would check, as a plan and not a past | F2 is the stated gap, so this objection arrives in some form. JD because it scores the stated role, Skeptic because it probes the gap |
| B2 | "Why fourth grade, and why now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: your actual reason for moving up, in your own words. The pack does not supply one, and a true reason said plainly holds up better than a polished one a follow-up can break. Start from the sentence and keep the reason connected to it | Motivation consistency is what Skeptics score, and F2 invites it. JD because it concerns the role |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name the one you would actually be weakest at, then what you would do in the first week, as a plan. The pack's own observation: F3, F5 and F6 are where your material is silent, and your honest answer may sit there. If it is fourth grade itself, "I haven't taught fourth grade" is the plain form | A standard Skeptic stem; F2, F3, F5 and F6 are where the material is thin. JD because it scores the listed job including its gaps |
| B4 | "You've never been a team lead. What did leading your grade level's move to a new reading curriculum involve for you?" | EXP | [grounded] "I've never been a team lead."; "I led our grade level's move to a new reading curriculum in 2024" | Concede the plain fact first: "I haven't been a team lead." Then the sentence as written. Answer slot: if any part of how the move ran was yours to decide, say which and how you decided, in your own words; if it was set for you, or there was no such step, say so plainly and describe the part you did | F10 pairs a move you led with a title you have not held, which is exactly where a Skeptic probes. EXP because it tests attribution |

### C. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's week two and a third of your class reads well below the rest. How do you plan your reading time?" | CASE | [generic] | Think aloud in order. Clarify: what do I know about these children and from what, and does a reading plan already exist for them. Objective: where should they be in six weeks. Grouping: how you would group, and what it would cost the others. Check: how you would know it is working. Risk: what could go wrong, such as children feeling labelled. Challenge one premise politely. Use grouping words only if you can speak to them | The hiring page names reading instruction as a panel topic, and the principal's public talk is on reading (see Reading the interviewer). F4 and F6 are the evidence rows this problem exercises. CASE because it is a live problem; no claim about your past |
| C2 | "Walk us through how you'd set up classroom routines in the first week." | CASE | [generic] | Structure it: which routines matter most, how you would teach each one, how you would check it held, what you would adjust. Answer slot: your material carries no sentence on routines (F5). If you set routines in your own room, say which and why, in your own words; if you have not set routines yourself, say so plainly and describe how you would | The hiring page names classroom routines as a panel topic, and F5 is a row with no evidence. CASE, with the answer slot guarding against supplying a practice |
| C3 | "A parent emails you three times in one week, worried about their child's reading. What do you do?" | CASE | [grounded] "I write a weekly email to families." | Structure: read all three, acknowledge the worry, find out what the parent has seen, look at what you know about the child's reading, set a follow-up with a date. You may add the sentence as written: "I write a weekly email to families." Do not say it solves anything | The hiring page names families as a panel topic, and F7 is the evidence. CASE because the problem is live |
| C4 | "In August the board adopted a three-year literacy plan. What stands out to you about it as someone who would teach fourth grade?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Read the plan itself first; this pack saw only a search snippet, which says it includes a new grades 3–5 reading curriculum from fall 2027 and a family reading night at every school each term. Fourth grade sits inside that range; say what you notice, in your own words. If you mention your own curriculum move, use the sentence as written and do not imply it is comparable in size. Answer slot: if lessons from that move would help, say them; if none you can stand behind, say so plainly and say what you would ask about the rollout | The one strategy-grounded question, resting on a published district plan that rivals can also read, so the divergence is yours. CO because it tests homework at the district's altitude; F4 supplies the sentence |
| C5 | "In many fourth-grade classrooms the teacher plans reading, writing, math, science and social studies. Which would you plan first, and where would you want the team's help?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | The order and the help are yours to name. Answer slot: if you taught any of these subjects in third grade, say which; if some were taught by others or were not yours, say so plainly and stay with what you did teach | F3 is a representative-listing requirement, so the question is framed as typical for the role, not as this team's practice. JD because it scores a listed duty |

### D. Values / Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a student in your class wasn't reading where they needed to be. What did you do?" | VAL | [generic] | Selection scaffold: pick a time with a child or situation you can describe without names, what you tried, and which part was yours as against the team's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests the belief "Every Child a Reader" (F8). VAL because it scores the published belief |
| D2 | "Tell me about a time you worked with a family to support a child." | VAL | [grounded] "I write a weekly email to families." | The sentence is the nearest thing your material carries, and it holds only a weekly email to families. Answer slot: the belief says each teacher speaks with every family, so expect a probe on conversations. If you spoke with a family about a child, say how, in your own words; if the email was how you reached families, say so plainly and stay with it | Tests the belief "Families Are Partners" (F7). VAL because it scores the published belief |
| D3 | "Tell me about a time assessment results changed what you taught." | VAL | [generic] | Selection scaffold: pick a time with a named result, the change you made, and what you noticed after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would use results | Tests "Teach for Tomorrow, Not for the Test" (F9, and F6 for the listing's version). VAL because it scores the published belief |

### E. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc, one beat per sentence, in that order, said as written. You may name the gap yourself so the panel hears it from you: "I haven't taught fourth grade." Close with your own reason for fourth grade, which is an answer slot the pack does not fill | The standard opener, and casual questions are still scored. F2, F4, F7 supply the beats. EXP because it walks the résumé |
| E2 | "What's been on your mind about reading instruction lately?" | JD | [grounded] "I've run the after-school reading club for the last two years." | Say the club as written. Answer slot: what you do in it, in your own words; if running it is all you can say, say so plainly and stay with that | A friendly question on the hiring page's first topic (F4). JD because reading is the listing's core |
| E3 | "What drew you to Halvering?" | CO | [grounded] | Answer slot: your actual reason, in your own words. The pack supplies only what is published: the district's three beliefs by name (Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test), the board's literacy plan, and the principal's public reading background. Name one only if it genuinely draws you | A rapport question that scores genuine interest. CO because it tests homework; the guidance makes no claim about you |

### G. Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the move to the new reading curriculum that you led at your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell the beats the sentence states: your grade level, a move to a new reading curriculum, 2024, and that you led it. Answer slot: if parts of how it ran were yours to decide, say which and how you decided; if none were, or it was set for you, say so plainly and stay with the move. Second slot: the belief says assessments inform teaching, so expect "how did you know it was working". If anything was measured, say what; if nothing was, say so plainly | F4 and F10 make this the line a Prober reads closely. EXP because it tests what was actually yours |
| G2 | "How do you know the reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Say the club as written. Answer slot: if anything was tracked or noticed that you can describe, say it in your own words and where it came from; if nothing was tracked, say so plainly and say what you would look at | The résumé text has no figure to defend, so the Prober asks about the claim itself (F4, F9). EXP because it tests whether the claim survives scrutiny |

### H. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | Pause and restate the question. Concede once and exactly: "I haven't taught fourth grade." Hold on what the quote carries: "Six years teaching third grade at a public elementary school in Joliet." Through two follow-ups, return to that sentence and add nothing. Say nothing about the other candidate | F2 under time pressure. JD because it scores the role; Pressure because it tests composure |
| H2 | "That reading curriculum move — how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead." | Pause, restate, hold: "I led our grade level's move to a new reading curriculum in 2024." Concede specifically: "I haven't been a team lead." Answer slot: which parts were yours and which belonged to colleagues or the school, in your own words; if the word "led" covers less than the question assumes, say so plainly. Do not fold on the sentence to restore harmony | The same sentence as B4 and G1 in a third delivery style, because the objection is likely however it arrives. EXP because it tests attribution |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Illinois license with an elementary endorsement (F1) | none: a gate your material shows met; it is a term, not a rehearsed answer, and the school verifies it |
| Fourth Grade Teacher role (F2) | A1, B1, B2, B3, H1 |
| plan and teach reading, writing, math, science and social studies (F3) | C5, E1 |
| reading instruction (F4) | C1, E2, G1, G2, A4, A5, C4 |
| classroom routines (F5) | C2 |
| differentiate instruction using assessment data (F6) | C1, D3 |
| Families Are Partners (F7) | C3, D2 |
| Every Child a Reader (F8) | D1 |
| Teach for Tomorrow, Not for the Test (F9) | D3, G1, G2 |
| work with the grade-level team (F10) | A1, A2, A3, A4, B4, G1, H2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What do you hope a new fourth-grade teacher does differently in reading because of that?" | Ties to her public path and shows you read about her, not only the district |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the peer seats; it asks what helps them, not what you need |
| R3 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is Halvering preparing, and where would a fourth-grade teacher fit?" | Shows you read a published plan and asks about the role's real work |
| R4 | "Which parts of the fourth-grade year do students new to the grade find hardest?" | Practical, and gives you something concrete to prepare against |
| R5 | "What does a strong first term look like for someone coming from another grade?" | Invites the panel to describe success in terms you can work toward |
| R6 | "The plan includes a family reading night each term. What do you expect the fourth-grade team's part to be?" | Connects a published item to the team you would join |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative the candidate stated, F10 | The plain acknowledgment: "I haven't been a team lead." No slot |
| Led the school's move, or the whole school's, to the new reading curriculum | Inflated form of F4 and F10 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024". The limit is the pack's observation: the material says the grade level's move, not the school's |
| Chose, designed or built the new reading curriculum | Inflated form of F4 | The same quote at its own scope. The material says the move to a curriculum, not who selected or wrote it; slots in G1 and B4 stay inside the move |
| Speaks with every family each term | Inflated form of F7 | The quote at its own scope: "I write a weekly email to families." The material says an email, not conversations |

## Sources

**Provided documents:** the interview invite and your résumé text, both from your message.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

**Searches sent**

| Query | What came back |
|---|---|
| Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Orrinsford Community School District teacher interview process panel | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Halvering Elementary School Orrinsford district news strategic plan | https://orrinsfordschools.example/news/board-adopts-literacy-plan (search snippet only; page not fetched) |
| Dolores Vantongeren principal Halvering Elementary | https://ilprincipalsforum.example/speakers/dolores-vantongeren (search snippet only; page not fetched) |
| fourth grade teacher job description Illinois elementary school requirements | https://k12jobsboard.example/listings/fourth-grade-teacher (search snippet only; the qualifications text was cut off mid-sentence and is not used) |

**Pages fetched:** the district's mission and beliefs page, and the district's "How we hire teachers" page.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three beliefs by name, which raise the VAL questions D1 to D3 and fit rows F7 to F9. No values cheat sheet, because no loop source documents a values-style round |
| 2. `{company} interview process {role family}` | yes | Fetched hiring page: one 45-minute building panel, principal plus two grade-level teachers, topics named. It matches your invite, so persona weights rest on a documented loop, not an archetype |
| 3. `{company} strategy` / recent news | yes | The board's literacy plan, read as a snippet: question C4, reverse questions R3 and R6 |
| 4. `{interviewer name} {company}` | yes | The principal's public footprint, read as a snippet: Reading the interviewer, C1, R1. The two team members were not named, so they have no read |
| 5. representative `{role title}` JD | yes | A representative listing from a jobs board, not this district's: rows F3, F6, F10 and question C5, all `[inferred]` |

## Upgrade menu

- The posting text for this role → F3, F6 and F10 become `[grounded]`, and any requirement the real posting names that the representative listing did not gets its own row and question
- Anything HR or the principal said about the panel, such as a demo lesson or work to bring → a build section for each announced deliverable
- The names of the two fourth-grade team members → personas assigned per seat, plus a tailored reverse question for each
- Your own words on the answer slots → rows F3, F5, F6, F7, F8, F9 and the guidance in B1, C2, D1 to D3, G1, G2 become `[grounded]` instead of scaffolds
- A copy of your license record from the state, showing kind, endorsement, status and expiry as it stands → F1 rises from medium toward high
- A sample reading-club schedule or the documents from your curriculum move → F4 rises from medium toward high
- How many hours you have before Thursday → a prep triage ordered by what matters most
- A `tuesday-dossier.md` from an earlier session → verified evidence and risks carried into this pack, never a prerequisite
