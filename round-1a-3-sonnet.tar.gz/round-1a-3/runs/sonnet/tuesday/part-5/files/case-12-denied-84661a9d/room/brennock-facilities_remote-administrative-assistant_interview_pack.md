# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager. Relationship to you not stated, so this is built as a hiring-manager-style round. Format, from your message: a 30-minute video call.

## How to use this pack

- Personas are how a question is asked. Types are what it is scoring.
- Type key: VAL = behaviour against published values. EXP = whether your own experience survives scrutiny. JD = the stated duties of the role. CO = knowledge of the company and its strategy. CASE = a live problem from the role.
- Guidance is scaffolding, not a script. Where a line quotes you, say it in your own words at that scope. Where a line says answer slot, it is an instruction for the interview: answer from your own experience, or say plainly it was not yours.
- The highest-ROI rehearsal in this pack is B2, because it sits where the ad's invoice line is furthest from your own words (F5).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you relayed it in your message | "two years as a receptionist at a physiotherapy clinic" — your message, "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The ad says calendars and your words say appointment book. Keep your words: "ran the appointment book for four physios." They carry a shared booking diary for four people. The pack's observation, not words for you, is that they do not say office or senior-staff calendars. Nothing is added to the quote |
| F2 | "booking travel" — the ad, as you relayed it in your message | none given | none | [grounded] | discovery | Your material is silent on travel, so the words are yours to supply. Answer slot: the ad's travel line makes a probe likely. If you have arranged any travel for anyone, say what, in your own words. If you have not, or it was never part of a job of yours, say so plainly and stay with the appointment book |
| F3 | "preparing documents in Word and Excel" (the Word half) — the ad, as you relayed it in your message | "I'm good with Word" — your message | medium | [grounded] | presentation | Your own words already reach the Word half in other terms: "I'm good with Word." Say it at that scope. It states a skill, and the pack adds no documents or tasks to it |
| F4 | "preparing documents in Word and Excel" (the Excel half) — the ad, as you relayed it in your message | "okay with Excel" — your message | low | [inferred] | discovery | "Okay" is your own hedge and the pack keeps it. Answer slot: the ad pairs Excel with documents, so expect a probe on what you have used it for. Say what you actually did in it, in your own words. If you have not used it for work tasks, or would need to look something up, say so plainly and stay with "okay with Excel" |
| F5 | "processing supplier invoices" — the ad, as you relayed it in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Keep your words at their own scope: "chased unpaid invoices." The material does not say whose invoices they were or what the chasing involved, and the pack does not fill that in. Answer slot: expect follow-ups on whose invoices they were and what the chasing involved. Say what you know, in your own words. If you do not know whose they were, or part of it was not yours, say so plainly and return to the chasing |
| F6 | "Remote" — the role title, as you relayed it in your message | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work remotely from home. This is a term you meet or do not, and no wording changes it, so no words are coached for this row |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| managing calendars | A1, D1, C1, E1 |
| booking travel | A2, B3 |
| preparing documents in Word | A4, C2 |
| preparing documents in Excel | A5, B5, C2 |
| processing supplier invoices | A3, B2, E2 |
| Remote | none, and why: F6 is a term, not experience, and it asks nothing of you in an answer |
| Whole-profile items | B1, B4, C1, C3, D2, D3 |

## Persona table

Assumption: the office manager runs a hiring-manager-style round. Your message gives one session, a 30-minute video call run by the office manager, and nothing about the relationship. The weights rest on that one stated session plus the assumed relationship.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | A small live task: a clash, a booking, a mismatched invoice | High. The ad's four duty areas, as you relayed them, are practical tasks, and the hiring-manager prior favours live problems | Clarify first, state the steps aloud, check your own output before it goes out |
| Skeptic (bank B, 5 questions) | Quiet probing of where your words stop short of the ad: travel, invoices, Excel | High. F2, F4 and F5 are the rows where your material is thinnest against the ad | Rehearse B2 until it is boring. Use only the sentences you have given me, and give the ramp as a plan |
| Conversational (bank C, 3 questions) | Friendly opener, casual questions that are still scored | Medium. A 30-minute call usually opens with your background, but your message does not say so | A 90-second arc built from your own sentences |
| Peer Evaluator (bank D, 3 questions) | Where your work meets the office manager's, what you would need from them | Medium. It moves up if the office manager is a colleague you would work alongside, which the message asks about | Reciprocity: what you bring as well as what you need |
| Data-Driven Prober (bank E, 2 questions) | Line-by-line on your own sentences | Low to medium. Your material holds no headline figures, only the count of four physios | Know what you can and cannot say about each sentence and say plainly where it stops |
| Pressure | Interruptions, time-boxing | Low. Nothing in your message points to it. No bank, and B2 carries the hold-then-concede rehearsal | Pause before answering and hold your position through two follow-ups |
| Values / Behavioral | Stories against published values | Low. No published values were read and no values round is named, so no values sheet is built and the pack carries no CO questions | n/a |

## Question banks

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two colleagues each ask you to book the same one-hour slot in a diary you manage, and only one of them can have it. How do you decide, and what do you say to the other?" | CASE | [generic] | Think aloud in order. Ask what each needs the slot for and whether either can move. Decide on what you learn, not on who asked first or loudest. Tell the other person straight away and offer an alternative. Record what you did so the diary shows why. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's calendars line (F1's requirement), asked as a decision. CASE because it scores structure, not history |
| A2 | "A colleague must be in Cork for a 10am meeting on Thursday and back the same evening. What do you ask first, and how do you book it?" | CASE | [generic] | Clarify before booking: any travel policy or budget, how they prefer to travel, whether the end time is fixed, what name and details the booking needs. Offer two options with times and costs, get a yes in writing, book, and send the itinerary. The question needs no claim about your past, so the guidance makes none | F2 is silent in your material, so a scenario lets you show process without a past. CASE because it is a live task |
| A3 | "A supplier invoice arrives for more than the quote you were sent. What do you do before it goes any further?" | CASE | [generic] | Hold it. Check the invoice against the quote and any order. Ask the person who requested the work whether the extra was agreed. If it is unexplained, go back to the supplier with the specific lines. Ask who approves payments and route it to them. Log what you found and who decided. The question needs no claim about your past, so the guidance makes none | F5's requirement as a live problem, so you can show how you would think about it without a past that the material does not carry. CASE because it scores reasoning |
| A4 | "At 3pm you're handed a page of rough notes and asked for a clean one-page summary in Word by 5pm. What do you ask, and how do you check it before it goes out?" | CASE | [generic] | Ask who it is for, what it is for, what must be in it, and whether there is a template. Draft it, check names, dates and figures against the notes, read it once more, and send it with a line saying what you changed or were unsure of. The question needs no claim about your past, so the guidance makes none | F3's requirement as a task rather than a skill claim. CASE because it scores process |
| A5 | "You're given a month of supplier invoices in a spreadsheet and asked for totals by supplier. How would you do it, and how do you know the totals are right?" | CASE | [generic] | Check the layout first: one row per invoice, consistent supplier names. Total by supplier, then total the whole sheet a second way and compare. Flag anything odd rather than fixing it silently. Answer slot: say which Excel tools you would reach for, in your own words. If you would need to look one up, say so plainly and say where you would look | F4 is where your own hedge sits, and the ad pairs Excel with invoices. CASE because it scores how you would check your own work |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel", "chased unpaid invoices" | Choose one you can say plainly and then plan for. Your own words give two honest candidates: "okay with Excel" is your own hedge, and "chased unpaid invoices" is chasing, which the ad's invoice line goes beyond. Name one at the scope of your own words. Then give the ramp as a plan: what you would learn first and how. A weakness that is really a strength in disguise is the answer to avoid | F4 and F5 are where your material is thinnest against the ad, so this stem lands there. JD because it scores the stated duties against you |
| B2 | "The role includes processing supplier invoices. What invoice work have you done?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Level 1: say "chased unpaid invoices" at that scope and stop. Level 2: expect whose invoices they were and what the chasing involved. Answer slot: say what you know, in your own words. If you do not know whose they were, or part of it was not yours, say so plainly and return to the chasing. Level 3, if pressed on how that compares with what the role needs: hold your words, concede the limit specifically, "chasing unpaid invoices is what I can speak to", then give the ramp as a plan: what you would ask to be shown first, and by whom. The limit is named before it is asked for: your material says chasing, not processing. Never describe a step you did not take | F5 is the widest gap between the ad and your words, so this objection will arrive in some form. JD because it scores a stated duty |
| B3 | "Tell me about a time you booked travel for someone." | JD | [grounded] "ran the appointment book for four physios" | Pick a time you arranged a trip or transport for someone, yours or a colleague's. It needs who it was for, what they needed it to do, and what you checked before confirming. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "ran the appointment book for four physios", or how you would handle it | F2 is silent in your material, so this is a selection scaffold with its honest branch. JD because it scores a stated duty |
| B4 | "Why this role, coming from a physiotherapy clinic?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Answer slot: your reason is yours and the pack has none to give. Say, in your own words, what draws you to this work. Three short pieces fit: where you have been, "two years as a receptionist at a physiotherapy clinic", what draws you here, and what you want to do more of. If one piece is not settled for you, say so plainly rather than inventing a neat one | Motivation consistency is what the Skeptic scores, and F1 holds the only background in your material. EXP because the reason for a move is part of the experience story |
| B5 | "How comfortable are you with Excel?" | JD | [grounded] "okay with Excel" | Use your own words: "okay with Excel", and mean it. Answer slot: expect "what for?". Say what you have actually used it for, in your own words. If the answer is little or nothing at work, say so plainly. Then give a plan for what you will practise before and in your first weeks, as something you will do. Do not trade "okay" for something stronger under a second question | F4 is your own hedge, and this is the plain form of the probe on it. JD because it scores a stated tool |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc with only the beats your sentences carry: two years as a receptionist at a physiotherapy clinic, you ran the appointment book for four physios, you chased unpaid invoices. Then the turn to this role. Answer slot: say why you are here, in your own words. If the reason is not settled, say what you are sure of. Do not add duties the sentences do not carry | The opening biography question is scored on economy. F1 and F5 carry the beats |
| C2 | "Tell me about something you've put together in Word or Excel that you were pleased with." | JD | [grounded] "I'm good with Word", "okay with Excel" | Pick one document or sheet you made and can describe in a sentence: what it was for, who used it, what you would do differently. If no such piece comes to mind, say so plainly, then give the nearest thing your material does carry, "I'm good with Word", or how you would handle it | F3 and F4 state skills, not pieces of work, so this is a selection scaffold. JD because the ad names Word and Excel |
| C3 | "What did you enjoy most about running the appointment book?" | EXP | [grounded] "ran the appointment book for four physios" | Answer slot: what you enjoyed is yours and the pack cannot supply it. Say it in a sentence or two tied to the book itself, and keep to "ran the appointment book for four physios". If nothing stands out, say plainly what you would want more or less of in this role | F1 is the evidence behind the premise. EXP because casual questions about your own work are still scored |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where's the seam between what you'd handle and what I'd handle, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a map you cannot know: ask which requests are yours, flag anything that is not clearly yours rather than guessing, and when you disagree, say your reason once, ask what they need, and agree who decides. The question needs no claim about your past, so the guidance makes none | Raised if the office manager is a colleague you would work alongside. CASE because it is a live working problem |
| D2 | "What would you need from me in your first month to do this well?" | JD | [generic] | Reciprocity first: say what you would aim to take off their plate, then what you need: access, who approves what, how requests reach you, where the current diary and invoice routines live. The question needs no claim about your past, so the guidance makes none | A peer prices what a hire adds to their own load. JD because it scores the duties as working conditions |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time work was shared with colleagues. It needs what was yours and what was theirs. If no such time comes to mind, say so plainly, then say how you would handle it | A peer-persona stem. VAL because it scores behaviour, though no published values were read here |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How much of running the appointment book was actually you?" | EXP | [grounded] "ran the appointment book for four physios" | Say the sentence as it stands: "ran the appointment book for four physios." Answer slot: if some of it was shared with the physios or other staff, say which parts and whose. If all of it was yours, say so plainly. Hold the sentence through a second follow-up | F1 is the sentence a prober will take line by line. EXP because it scores attribution |
| E2 | "When you chased an unpaid invoice, who did you contact and what did you say?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: describe what one chase looked like, using only what you actually did. If it varied, or you do not remember specifics, say so plainly and describe in general how you went about it. Do not add a process, template or escalation step you did not use | F5's evidence is one line, so this is the second-level probe behind B2. EXP because it scores whether the claim survives detail |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like in this role, and which of the four areas, calendars, travel, documents or invoices, takes most of it?" | It shows you have read the duties and tells you where to put your practice time |
| R2 | "Which tools do you use for diaries and for invoices, so I can get up to speed before day one?" | It signals readiness and points straight at F4 and F5 |
| R3 | "What would a good first month look like?" | It turns the interview toward the work and gives you the standard to aim at |
| R4 | "Who would I work with most day to day, and how do they like requests to reach me?" | It shows you think about the people around the role |
| R5 | "What happens after this call, and roughly how long do decisions take?" | It lets you plan your follow-up and your week |
| R6 | "What could a new person do in their first month that would genuinely help you most?" | Reciprocity: it asks what you can give, not just what you need |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for an office or for senior staff | Inflated form of F1 | F1's quote at its own scope: "ran the appointment book for four physios." The limit is the pack's observation: your material says an appointment book for four physios |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: your material says chasing, not processing. The slots in B2 and E2 stay inside the chasing |
| Advanced or expert Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel." The limit is the pack's observation: your material says okay, not advanced |

## Sources

Provided documents: the invitation text and the ad's duties as you relayed them, and your background, all in your message. No dossier was present.

Searches sent, all refused, none returned:

- "Brennock Facilities Ltd values": refused
- "Brennock Facilities Ltd interview process administrative assistant": refused
- "Brennock Facilities Ltd news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | The one search call was refused. It would have fed a values sheet if a values round were detected; none is, so nothing in the pack changes |
| 2. Brennock Facilities Ltd interview process, administrative assistant | unavailable | The one search call was refused. It would have fed loop structure. Your message establishes the one session, so persona weights rest on it and the assumed relationship |
| 3. Brennock Facilities Ltd strategy or recent news | unavailable | The one search call was refused. It would have fed CO questions. The pack carries none, and the CASE bank is generic |
| 4. Interviewer name and company | n/a | No name was given |
| 5. Representative Remote Administrative Assistant JD | skipped | The duties as you relayed them fix the fit rows and the JD questions |

## Upgrade menu

- The ad's full text: the rows built from your summary become quoted ad lines, and any duty your summary left out gets a row and a question
- Who the office manager would be to you, as manager or colleague: reweights every bank, and the Peer Evaluator rows move up or down
- Whether you can work remotely from home: settles F6
- Your answers to the slots in B2, B3 and B5: upgrade F2, F4 and F5 from slots to quoted evidence
- How much prep time you have: adds a prioritised schedule sized to it
- Permission to search: moves rows 1 to 3 of the Sources table from unavailable to researched, and can add CO questions
- A tuesday-dossier.md from an earlier session: verified evidence and prohibited claims arrive pre-checked, and the highest-ROI objection is read from it rather than inferred
