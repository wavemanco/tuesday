# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, 30-minute phone call with Hannah Lowther (Talent Partner), who will ring the mobile number on your application.
**Her stated agenda, in her words:** "I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."
**Built on this assumption:** the whole loop you are preparing for is that one call, as her message sets it out. Nothing about Quillmoor was researched (see Sources), so company-specific rows are absent rather than guessed.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| EXP | Whether your experience survives scrutiny, and what was actually yours |
| JD | The advert's stated duties and requirements, including where you are thin |
| CO | Knowledge of the company and its strategy (none in this pack: no research ran) |
| CASE | A live problem from the role, reasoned aloud |
| VAL | Past behaviour against the company's published values (none in this pack: no values page was read) |

Question IDs run by persona. The letter F is skipped for personas so a question can never be confused with a fit-snapshot row (F1 to F12), so the values persona is G.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap on the years: the quote states four against the advert's two-plus. Nothing inspected sits behind it, so expect it to be taken as you say it; say it in the quote's own terms |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on who you coordinated with is likely. If any of those groups were part of your scheduling, say which and how, in your own words; if none were, or the coordinating was not yours, say so plainly and stay with the deliveries you schedule for three depots |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [inferred] | discovery | The sentence touches supplier deliveries without showing how you know an order has slipped; the derivation is from the chasing. Answer slot: if you tracked supplier deliveries in some way, say how, in your own words; if you did not, or it was someone else's job, say so plainly and stay with the chasing |
| F4 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | The sentence reaches the requirement in your own terms: "I chase suppliers when orders slip." Lead with it as you said it; nothing added about how or how often |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap on the stock-count work, but a figure with nothing inspected behind it, so expect it to be probed. Keep it as stated, "about a third", "over a year". The defend-the-number slots are in C1 and D2 |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting, and says nothing about its absence. Answer slot: the advert's weekly dispatch line makes a probe on reporting likely. If you produced any regular reporting on deliveries, say what, how often and who received it, in your own words; if you did not, or it was not yours, say so plainly, then say what you would measure first, as a plan |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The sentence says a stock-count spreadsheet, not Excel; the derivation is spreadsheet to Excel, and the words stay at "spreadsheet". Answer slot: if it was in Excel, say what you did in it, in your own words; if it was another tool, say so plainly and describe what you rebuilt |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." The advert marks ERP as a plus, not a requirement. The other fact stays at its scope: "we run our own in-house stock system." Answer slot for "or similar": if you worked in that system yourself, say what for, in your own words; if you did not, or it is not comparable, say so plainly. Then how you would learn a new system, said as a plan and never as a past |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | The figure is yours and it sits inside the advertised band. Give it as you said it; nothing is added to it |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your sentence stays whole: two days is fine, and three is the most you would want. Nothing is added about the journey |
| F11 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and Hannah has put it on her agenda. A4 holds it open as a slot for your own answer |
| F12 | "what's prompting a move" — Hannah Lowther's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | The reason is yours and stated whole: use that sentence. Nothing is added to it |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in operations or logistics coordination" | A1 |
| "Coordinate production schedules between planning, the warehouse and QA" | B1, D1, E1 |
| "track supplier deliveries" | E1, G1 |
| "chase late orders" | G1, E1 |
| "keep stock records accurate" | C1, C3, D2, E2 |
| "report weekly on on-time dispatch" | B4 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B2, B3 |
| "£38,000–£44,000" | A3 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A5 |
| Notice period (Hannah's agenda) | A4 |
| What is prompting a move (Hannah's agenda) | A2 |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | A friendly run through pay, notice, hybrid and why you are moving, then a chat about you | Highest. A recruiter screen starts from this persona in the relationship priors, and Hannah's own message lists logistics first. Depth: 5 questions | Your own words for each logistics topic; one arc built only from your quoted sentences (A1) |
| B. Skeptic | Quiet probing of the thin rows: production schedules, reporting, SAP | High-mid. The priors give a recruiter screen a light Skeptic; raised here because F2, F3, F6 and F8 are the snapshot's gap rows. Depth: 4 | Rehearse B1 until it is boring; bridges only from what you said, limits stated plainly, plus a plan for getting up to speed |
| C. Data-Driven Prober | Reads your background closely: the "about a third" and the Excel line | Mid. Not a recruiter prior, but F5 is a figure and F7 a named tool, and both are the kind of line that gets one follow-up. Depth: 3 | Know how the figure was counted, or say plainly that you do not |
| D. Pressure | A short, time-boxed "why you" | Low. A friendly screen rarely applies pressure, but "why you over someone from a manufacturer" is a fair one-liner. Depth: 2 | Pause, restate, hold on what you stated, concede the specific limit |
| E. Case / Strategist | A quick scenario from the role | Low. A recruiter seldom runs a case; a hiring manager is likelier, if there is a later round. Depth: 2 | Clarify first, then structure, aloud |
| G. Values / Behavioral | An open "tell me about a time" | Low. No values-style round is detected: no loop source names one, and the one session known is a recruiter call. Depth: 2 | Choose one occasion with a stake and an ending; if none comes to mind, say so |

## Question banks

### A. Conversational / Rapport Builder (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. How did you get to where you are now?" | EXP, JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped on F1, F4 and F5, using only the beats the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell it in your own words in about ninety seconds, then land on why you are looking now (A2). It adds no title, team size or event beyond those sentences | A casual opener that is still scored; F1 is the years requirement and the arc carries it. EXP because it tests whether the story is consistent, with JD content on the years |
| A2 | "What's prompting the move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot, your own words, whole and at their scope: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up on Reading, give those words again, with nothing added. If she asks what draws you to this role, answer from what you actually find appealing in the advert; this pack supplies no reason | Hannah named this topic herself, and F12 is the reason. EXP because it tests whether the motivation story holds together |
| A3 | "What are you looking for salary-wise?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, your own words: "I'm hoping for £42,000." F9 shows it inside the advertised band. If she asks what you earn now, you can decline to give it and return to the figure you hoped for; nothing else is put in your mouth here | Pay is the first item on her agenda. JD because the band is the listed job's term |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words, as it is in your contract. The pack holds no figure for it | F11 is open and on her agenda. JD because it is a term of the listed job's start |
| A5 | "How would the hybrid pattern work for you — two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the commute, give that sentence again, with nothing added | F10 is a term the advert sets and Hannah has named. JD because it is the listed job's pattern |

### B. Skeptic (weight: high-mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What's your experience of that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The highest-ROI prep in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of planning, the warehouse or QA were part of your scheduling, say which and how, in your own words; if none were, or the coordinating was not yours, say so plainly and stay with the deliveries you schedule for three depots. Follow-up one, comparing delivery scheduling with production scheduling: say the differences you actually know, and if you do not know them, say so. Follow-up two, how you would get up to speed: answer as a plan in your own words, such as what you would ask each of those groups first, never as a past. Hold through both by returning to the quote, not by adding to it | F2 is the biggest gap against the advert's duties, so this objection arrives in some form; a rehearsed, non-defensive answer changes the call. JD because it scores a stated duty |
| B2 | "ERP experience, SAP or similar, is a plus. Where do you stand on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment from your own words: "I've never used SAP." Then the one other fact at its scope: "we run our own in-house stock system." Answer slot for "or similar": if you worked in that system yourself, say what for, in your own words; if you did not, or it is not comparable, say so plainly. Close with how you would learn a new system, as a plan | F8 is the one gap you stated yourself, and the advert calls it a plus, so the likely question is how you would close it |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [inferred] derived from the thin rows F2, F3, F6 and F8 | Selection scaffold, not a script: choose from your own material, name the area plainly, and say what you would do about it first, as a plan. The pack's own observation is that your material is thinnest on those four rows. If no area comes to mind, say so plainly, then name where you would ask for most help in the first weeks | Persona stem applied to this advert; the label is inferred because it is derived from the snapshot's gaps |
| B4 | "The role reports weekly on on-time dispatch. What reporting have you done?" | JD | [grounded] | Answer slot: if you produced any regular reporting on deliveries or dispatch, say what, how often and who it went to, in your own words; if you did not, or it was someone else's, say so plainly, then say what you would measure first as a plan. Nothing here names a report or metric for you | F6 is silent in your material, so a probe is likely. JD because it scores a stated duty |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. Walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Keep the sentence at its scope. Then the four slots a figure raises, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; and which part of the result was yours. If you do not know how it was counted, say so plainly | F5 is the figure on your background that a close reader goes to first. EXP because it tests attribution and the figure's assumptions |
| C2 | "The advert says confident with Excel. What did you do in the stock-count spreadsheet you rebuilt?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: say which program it was in. If it was Excel, say what you did in it, in your own words; if it was another tool, say so plainly and describe what you rebuilt. Do not claim a level or name functions you did not use | F7 is the only Excel evidence and it names a spreadsheet, not Excel; the label is inferred for that step |
| C3 | "What did you change when you rebuilt the stock-count spreadsheet?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: say what you changed, in your own words. If you cannot recall specifics, or the changes were not yours to make, say so plainly and return to the sentence: you rebuilt the stock-count spreadsheet | The advert's "keep stock records accurate" line is met by F5; this is the natural next probe on it |

### D. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over someone who has worked in a manufacturer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Pause, restate, then hold on those two sentences and nothing wider. Hold through two follow-ups by returning to them. Concede the specific limit in your own words: if you have not worked in a manufacturer, say so plainly, then return to the two sentences | F2 is where this challenge presses. JD because it scores fit to the stated duties, with Pressure delivery |
| D2 | "That result — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on the sentence's own attribution: you rebuilt the stock-count spreadsheet. Answer slot: say what else, if anything, played a part in discrepancies falling, in your own words; if you do not know, say so plainly. Hold through two follow-ups by returning to the rebuild | F5 is a figure, and attribution probes exist to catch inflation. EXP because it scores honesty about your share |

### E. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you on Tuesday that a delivery the production schedule depends on will be a week late. Who do you talk to, and what do you do?" | CASE | [generic] | Structure it aloud: ask first what the late delivery holds up and how firm the new date is; state the objective; say who needs to know and what each needs from you (the advert names planning, the warehouse and QA); give two options and what each costs; say what you would record and when you would check back. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's late-orders and schedules lines (F2, F4); generic because it is a pattern for the problem, not a fact about this employer |
| E2 | "A stock record and the shelf count disagree. Take me through what you would do." | CASE | [generic] | Clarify how far apart they are and whether stock moved recently; check the movements; recount; find the cause; correct the record and note why; say how you would stop it recurring. No claim about your past is made | A live problem from the advert's stock-records line (F5); generic for the same reason |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time an order slipped and you had to chase it." | JD, EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Selection scaffold, because the sentence states a practice and no occasion: pick one occasion; it needs what slipped, whom you chased and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I schedule deliveries for our three depots and chase suppliers when orders slip" | The advert's late-orders line (F3, F4) raises the theme; an open prompt asks you to choose the instance |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: pick a time with a named stake, a moment you said it plainly, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then say how you would handle it | Persona stem, low weight in a recruiter screen; generic because no quoted sentence carries it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which two days would the team be at Avonmouth, and are they fixed or agreed within the team?" | Hannah has the hybrid pattern on her agenda, and this makes it about how the team works; it adds nothing to your own stated limits |
| RQ2 | "Who would I work with day to day across planning, the warehouse and QA?" | The advert names those three groups, so it shows you read the role, and the answer shows how large the coordination is |
| RQ3 | "What stock or ERP system does the site run today, and how much of the role is spent in it?" | It brings up the SAP gap (F8) on your terms and tells you how much weight it carries |
| RQ4 | "How is the weekly on-time dispatch report produced today, and who reads it?" | It shows interest in the reporting duty and tells you whether it is built or maintained |
| RQ5 | "What would a good first three months look like?" | A specific close beats "I think you have covered everything", which a rapport-style interviewer reads as a missed preparation signal |
| RQ6 | "Is this a new role or a replacement, and who would I report to?" | It is the first thing a candidate needs to know about the seat, and it is a plain, low-pressure ask for a recruiter |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never used SAP." B2 holds it |
| Has ERP experience through the in-house stock system | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation, not words for you: your material says the company runs one, not that it is an ERP or that you worked in it. B2's slot stays inside the quote |
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries, not production schedules. B1's slot stays inside the deliveries |
| Is confident with Excel | Inflated form of F7 | F7's quote at its own scope, a stock-count spreadsheet. The limit is the pack's observation: your material says spreadsheet, not Excel. C2's slot asks only which tool |
| My rebuild cut discrepancies by a third | Inflated form of F5 | F5's quote at its own scope, "about a third" and "over a year". The limit is the pack's observation: the sentence gives the rebuild and the fall side by side, not the cause. D2's slot asks only what was yours |
| Three days at Avonmouth is fine | Inflated form of F10 | F10's sentence whole. The limit is the pack's observation: your words give two days as fine and three as the most you would want. A5 holds the sentence |

## Sources

Provided documents: your message (the advert text, your notes about yourself, and Hannah Lowther's LinkedIn message). No `tuesday-dossier.md` was present.

Searches sent, all refused (search permission was not granted):

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics Avonmouth news` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have fed a values cheat sheet; none is built, and no values-style round is detected in any case |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have shown rounds after this call; the loop for this call is fixed by Hannah's own message, so only later-round weights are affected |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | Would have grounded CO questions and a grounding brief, which are absent |
| 4. `Hannah Lowther Talent Partner Quillmoor Diagnostics` | unavailable | Would have fed an interviewer read and a reverse question tied to her path, both absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, or pasted pages from Quillmoor's own site → CO questions and a grounding brief replace the absence, and any published values or interview-process page can be checked against this pack
- Hannah's LinkedIn profile text, pasted → an interviewer read and a reverse question tied to her own path
- Your CV → F1 to F8 can be checked against it, and rows rest on its sentences where they say more than your message
- Your notice period → A4 becomes your quoted words and F11 settles
- Whether the stock-count spreadsheet was in Excel, whether any of your scheduling involved planning, the warehouse or QA, whether you used the in-house stock system yourself, and whether you have done any regular reporting → F2, F3, F6, F7 and F8 move from answer slots to story-mapped rows in B1, B2, B4 and C2
- A tuesday-dossier.md from an earlier role check → verified evidence and the objection worth the deepest rehearsal arrive pre-set; the pack does not need one
- If a later round is scheduled, who and when → per-round mini-packs with their own persona weights
