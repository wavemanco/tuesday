# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, name not given. Assumed relationship: your future manager (a hiring-manager round). Format: a text chat.

## How to use this pack

- Personas are how a question is asked. Types are what it is scoring.
- The five type tags: VAL is behavior against published company values; EXP is whether your experience survives a close read; JD is a line from the ad; CO is company and strategy knowledge; CASE is a live problem from the role.
- Guidance is scaffolding, not a script. Where a cell quotes you, those are your own words from your message; where it holds an answer slot, the answer has to come from what you actually did.
- The interview is a text chat, so rehearse by typing your answers, not only saying them.
- The highest-ROI rehearsal in this pack is B1, the question about moving into software from an energy supplier. It is the likeliest objection to your profile, and it has the most follow-up levels.

## Fit snapshot

The requirements are the four lines of the ad as you listed them in your message. No full ad text and no CV were provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but your message is the only source and nothing is inspected behind it, so expect a probe. Lead with the quote's own terms: three years, customer service advisor, an energy supplier. Keep your own title rather than renaming it support specialist. The software question is F5's |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Name the tool you use rather than the ad's: "I use Freshdesk every day." Add nothing about what you do inside it unless asked, and never claim the ad's named tool. Your material names Freshdesk only |
| F3 | "clear written communication" — your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote says emails, mixed in with calls, and shows nothing yet about how they read. Answer slot: the ad's line on written communication makes a probe on your writing likely. If you can point to a kind of email you wrote, say what it was and what made it work, in your own words; if most of your contacts were calls, or there is no such example, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — your message | none given | none | [grounded] | discovery | Your material does not mention escalations either way. Strong evidence here would be a named kind of escalated case and what you did next. Answer slot: the ad's line makes a probe likely. If you handled escalated cases, say what kind and what you did, in your own words; if they went to someone else, or there were none, say so plainly and stay with the calls and emails you answered |
| F5 | Familiarity with a software company's world — not in the ad as you listed it; a role-family expectation, unquoted | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would get up to speed, said as a plan and never as a past. Never a claim to software-company work, and nothing added to make the gap feel smaller |
| F6 | Supporting teammates — not in the ad as you listed it; a role-family expectation, unquoted | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Extra evidence rather than an ad line answered. Say it at its own scope: you trained four new starters on the refunds process, last year. Keep "trained"; it is not "led a training programme" or "ran onboarding" |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live support scenarios typed into the chat: a hard customer, a queue problem, a first reply to write | High. The hiring-manager prior puts it first, and the ad's escalation and ticketing lines invite scenarios. A text chat also makes a written reply the natural test | Clarify what you would need to know, then objective, approach, the customer message, what you would record. Think aloud in the chat |
| Skeptic | Quiet probing of the gaps: the move from an energy supplier to software, escalations, why leave and why here | High. The hiring-manager prior puts it second, and F5 is a gap you have stated while F4 is one your material is silent on | Rehearse B1 until it is boring. Bridges use only the quotes in F1, F2 and F6, and the limit is said plainly |
| Conversational / Rapport | Friendly, loose openers in the chat; they still score | Medium. A team lead's chat often opens in this register, and the interviewer's style is not known | A short arc for the background question built from your quotes, and treat casual questions as scored |
| Data-Driven Prober | Asks how a number was counted and which part was yours | Medium. Your message carries two figures, the 60 a day and the four starters | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Pressure | Time-boxed challenges, such as why you over someone from software | Low. Nothing in the invite signals it and the hiring-manager prior does not lead with it | Pause, restate, hold the position through two follow-ups, concede one specific thing |
| Peer Evaluator | Hand-offs and disagreement with teammates and other teams | Low. The lead is not a peer, so this arrives mainly as scenarios about working with other teams | Offer principles for a hand-off rather than pretending to know how their teams are split |

No values round is in the pack. The only description of the loop is your message, which names one text chat with the support team lead and no values round.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem and says they want to cancel. You have five minutes before your next ticket. What do you do?" | CASE | [generic] | Structure it: read the earlier contacts first, say what you can resolve now, say plainly what you cannot and who can, tell the customer what happens next and when, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's escalation line (F4's requirement), asked as a decision. [generic] because it is a pattern for the problem, not a fact about this employer |
| A2 | "A customer is angry in the chat and what they want is outside what you can approve. Write me your next three messages." | JD | [generic] | Message one: acknowledge the problem in plain words. Message two: what you can do now and what you cannot. Message three: who takes it next, what they will have in front of them, and when the customer hears back. Short, no jargon, no promises you cannot keep | Covers F4's requirement and F3's requirement at once, in the medium the interview is held in. JD content, CASE delivery |
| A3 | "A bug in our software means lots of customers write in about the same error at once. How do you handle your queue?" | CASE | [generic] | Clarify first: is it a known issue, who owns it, is there a workaround. Then group the contacts, keep every reply consistent, and tell the team lead what you are seeing. Say what you would not do, which is guess at a fix | A software-flavored problem that tests structure rather than product knowledge, which F5 says you do not yet have. [generic] |
| A4 | "On your first morning you are given a ticketing tool you have never used. How do you get productive in it?" | JD | [grounded] "I use Freshdesk every day" | Start from your own words, "I use Freshdesk every day", then give a plan, never a past: what you would look for first and who you would ask. Do not claim features of a tool you have not used | F2's requirement, asked as a hypothetical so the answer is a plan. JD because it scores the ticketing line, CASE because it is delivered as a live problem |
| A5 | "Reply to this ticket as if it just arrived: 'Your update broke my export and I have a deadline today. Fix it NOW.'" | JD | [generic] | A short first reply: acknowledge the deadline, ask the one question you need answered, say when the customer will hear from you next. If you do not know the product, say what you would check rather than guessing a fix | F3's requirement tested directly, by writing. The chat format makes a written exercise likely |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your three years were at an energy supplier. What do you think will be hardest about moving into software support?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier" | The highest-ROI rehearsal in this pack. Say the limit first, in your own words: "I've never worked for a software company." Then hold on what your quotes carry: "3 years as a customer service advisor at an energy supplier". Then a plan, never a past: what you would learn in the first weeks. Follow-up one, how fast you would be productive: do not give a number you cannot back, say what you would learn first. Follow-up two, a technical question you cannot answer: say you would check and come back, never guess. Follow-up three, why software: give your actual reason in your own words. Hold through all three by returning to the quotes, never by adding to them | F5 is the stated gap and the objection this candidate will meet in some form. JD because it scores the ramp into the role, Skeptic because it targets the gap |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the real one from the ad's four lines. If it is the software side, say "I've never worked for a software company", then how you would close it as a plan. If your honest answer is a different line, say that one plainly. A weakness named first and closed with a plan is stronger than one the interviewer finds | The Skeptic stem the pack expects. F4 and F5 are where the material is thinnest, but the choice is yours to make honestly |
| B3 | "Tell me about a time a customer's issue had to be escalated." | JD | [grounded] "answering around 60 calls and emails a day" | Pick a time that has a customer problem, a point beyond what you could resolve or approve, what you did next, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "answering around 60 calls and emails a day", or how you would handle it | The ad's escalation line (F4) turned into an open prompt, so it supplies no event. JD content, EXP delivery |
| B4 | "Your three years were at an energy supplier. What from that work carries over to software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "answering around 60 calls and emails a day" and "I use Freshdesk every day" | Describe the work in those words and let the interviewer draw the inference. Do not tell them what it proves. Name one thing you would bring, stated as what you did. If nothing specific comes to mind, say so plainly | F1 is the evidence for the experience line and F2 for the tool line, and the question tests whether they travel. EXP because it tests what the work actually was |
| B5 | "Why leave energy for software, and why this company?" | EXP | [generic] | Give your real reasons for moving, in your own words, and your real reasons for this company. For company-specific reasons, read Lumenvale's own website first, because this pack could not research it. If you do not have a specific reason for the company yet, say so plainly | Motivation consistency is the Skeptic's core test. [generic] because no company facts were available |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "answering around 60 calls and emails a day", "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | A 90-second arc that uses those four sentences and no more, in your own words, then your own reason for wanting this role | F1, F2 and F6 are the beats a background question draws on. Friendly questions are still scored |
| C2 | "Do you prefer talking to customers or writing to them, and why?" | JD | [grounded] "answering around 60 calls and emails a day" | Say your honest preference. If it is calls, say so plainly, then say how you make writing work. Keep to "answering around 60 calls and emails a day" as what you can say about the volume | F3's requirement in a casual register. JD content, delivered casually |
| C3 | "What is the best support experience you have had as a customer?" | JD | [generic] | Choose a real one. Name the one detail that made it work. If none comes to mind, say so plainly and describe what you think a good one would be | A casual question about the standard the role is scored against. [generic] |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said about 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Four slots, each in your own words: how "around 60" was counted; what it moves with; the assumption behind it you would defend least; and which part of that volume was yours alone. If you do not know how it was counted, say so plainly | F3 holds the figure, and a headline number is where a Prober starts. EXP because it tests attribution and counting |
| D2 | "Tell me about the four new starters you trained. What was your part in it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say it at its own scope: "I trained four new starters on our refunds process last year." Slots, in your own words: how the four were counted, what that count depends on, the assumption behind it you would defend least, and which part was yours. If part of it was set by someone else, say which part was yours | F6 holds the figure and the verb, and the question tests that you hold both at their scope |
| D3 | "What do you use Freshdesk for day to day?" | JD | [grounded] "I use Freshdesk every day" | Say what you actually do in it, in your own words, and keep to the tool you named. Answer slot: if you are asked which other ticketing tools you have used, name them from your own experience; if Freshdesk is the only one, say so plainly | F2's requirement, probed to the detail. Freshdesk is the tool you stated |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" and "I've never worked for a software company" | Hold on those two sentences, then concede one thing specifically: "I've never worked for a software company." Do not claim you would be faster or better than someone from software | A time-boxed version of B1, testing composure. F5 is the concession, F1 and F2 the hold |
| E2 | "That training you did: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the sentence says and no more. Answer slot: say which part was yours, in your own words; if part of it was set by someone else, say so plainly and say which part was yours | The attribution probe on F6, tested under pressure |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Support often has to tell engineers what customers are hitting. How would you hand over a bug so it is useful to them?" | CASE | [generic] | Principles, not a claim about their process: what the customer saw, the steps, how many are affected, what customers have been told so far. Offer to adapt it to what they prefer. You are not pretending to know the seam | A hand-off scenario for a software support role. The guidance makes no claim about your past |
| F2 | "A teammate gives a customer different advice from yours. What do you do?" | CASE | [generic] | Check the customer is not left confused first, then raise it with the teammate directly and without blame, and escalate to the lead only if you cannot settle it. Say you would want it consistent rather than right-by-seniority | A disagreement scenario between equals. The guidance makes no claim about your past |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 "2+ years in customer support" | B4, C1, E1 |
| F2 "experience with Zendesk or a similar ticketing tool" | A4, D3 |
| F3 "clear written communication" | A2, A5, C2, D1 |
| F4 "confidence handling escalations" | A1, A2, B3 |
| F5 software company familiarity, not in the ad as you listed it | A3, B1, B2, B5, E1 |
| F6 supporting teammates, not in the ad as you listed it | C1, D2, E2 |
| Company and strategy knowledge (CO) | none, because no company research ran, so there is nothing to ground a CO question in |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 30 days look like for someone joining from outside software?" | It names your gap on your terms and lets the lead define the ramp, which you can then prepare against |
| R2 | "Which products or ticket types do new starters find hardest to learn first?" | It shows you are already thinking about the ramp and tells you what to read |
| R3 | "How are escalations handled on the team: what does a first-line person own and what goes to someone else?" | It gets the real structure behind the escalation line, so you can answer about it accurately |
| R4 | "What does a good written reply look like on your team, and is there a style guide or review?" | It shows you take the written-communication line seriously and tells you the standard |
| R5 | "Is there a call or video step after this chat, and how long does the process usually take?" | It tells you what else to prepare for and how to plan your time |
| R6 | "How does the team measure how well it is doing?" | It shows you want to know the standard you will be held to, and it prepares you for the first review |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not the ad's named tool. D3's slot stays with the tools you have used |
| Has worked for a software company or in software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Led or designed the refunds training, or ran onboarding | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: the material says trained four, not designed or ran anything. D2's slot stays inside the training |

## Sources

Provided documents: your message, which holds the invite text, the four requirements as you listed them, and your background. No full ad text and no CV. No dossier.

Searches sent, all refused because web search was not permitted:

- `Lumenvale Software company values` — refused
- `Lumenvale Software interview process customer support specialist` — refused
- `Lumenvale Software strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The call was refused. Published values would have themed VAL questions and the pack has none |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The call was refused. A documented loop would have checked the persona weights; they rest on your message and the hiring-manager prior |
| 3. `Lumenvale Software strategy news` | unavailable | The call was refused. It would have grounded CO questions, so the CASE questions are [generic] and no CO question is included |
| 4. interviewer name and company | n/a | No name was given for the support team lead, so there was no query to form. The interviewer read is absent |
| 5. representative Customer Support Specialist JD | skipped | The four ad lines you listed already fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → any responsibilities or mid-list items it holds become requirement rows with their own JD questions, and the [inferred] and [generic] rows tied to it become [grounded]
- Your CV → more of your own sentences for the fit snapshot, so F3, F4 and F6 can be story-mapped instead of answer slots
- A sentence or two in your own words on whether you handled escalated cases, what kind of emails you wrote, and whether Freshdesk is the only ticketing tool you have used → F2, F3 and F4 move from slots to story-mapped guidance
- Web search allowed, or pasted text from Lumenvale's own website values or careers pages → VAL and CO questions grounded in the company, and loop structure checked. A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, can follow
- The support team lead's name or public profile → persona weights read from their footprint and a reverse question tied to their path
- Any note from the hiring team on what the chat will cover → coverage of the stated focus areas instead of round-type priors
- A `tuesday-dossier.md` from an earlier fit check → graded evidence and a prohibited-claims list built from verified material instead of this pack's local one
