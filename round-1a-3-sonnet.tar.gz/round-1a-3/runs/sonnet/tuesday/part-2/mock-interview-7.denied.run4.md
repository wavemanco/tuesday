Search permission was declined, so I'm building the pack from your JD and background only and labelling everything else as generic. I'm writing the pack file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-7-denied-72711845/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions across seven interviewer styles, a fit table for each JD line, a list of claims not to make, and reverse questions for Tobias.

I couldn't run any of the four web searches (company values, interview process, strategy, Tobias), so nothing in the pack is a researched fact about Saltmarsh. Questions that depend on company knowledge, such as A4 and D2, are generic. I built it for a hiring-manager round, assuming Tobias would be your manager.

The highest-value prep is B2: "You ran the weekly content-drop calendar for your main title. This role runs a live-events calendar for two titles. What changes?" Your material covers the calendar, but not events or a second title. The pack coaches you to say what you ran in your own words, name what is new as something to learn, and not stretch "ran" into "owned".

Two limits you stated, never leading a team and never working on in-app purchases, are in the pack. Say them plainly if asked, each with a plan for how you'd learn it.

I can also play the Skeptic on B2, the question the pack names as highest-ROI, so you can rehearse it out loud.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and has the recruiter said anything about focus areas or a presentation or take-home? Either answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not confirmed. This pack assumes a hiring-manager round, because he heads the function the role sits in.
- **Format:** one 60-minute session, session mode.
- **Research:** none of the four searches ran (permission was declined). Persona weights rest on a pattern, not on Saltmarsh's documented process, and nothing here is a researched fact about the company.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your experience claims survive follow-up, and exactly what was yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Rows labelled generic are patterns for a problem, not facts about Saltmarsh. Answer slots are instructions for the interview, not questions for you now.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not events and not two titles. The words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-titles lines make a probe on both likely. If any of your drops were events or built around them, say which and how, in your own words; if they were content releases only, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | A calendar touches coordination without showing which teams or how. Answer slot: the JD names four teams, so expect a probe on each. Say which of them you worked with on a drop and what you needed from each, in your own words; if you worked with fewer, or the coordination was not yours, or none existed, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the retention numbers, not that you owned a review or chose the KPIs. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who chose what was reported likely. If you chose which numbers went in, or ran a review after a drop, say how, in your own words; if the numbers came to you set, or no review step existed, say so plainly and stay with what you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote already reaches the checklist in other terms. Lead with it as it stands: "I wrote the release checklist our QA team still uses." The pack's observation: it says wrote and still uses, not that you ran each release through it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years on a weekly calendar, and does not show whether the title was live-service for the whole four. This is an experience requirement, not a gate, so it is graded like any other row. Answer slot: the JD's 3+ years line makes a probe on how long you worked on live content likely. Say how long, in your own words; if it was the two years of the calendar, say so plainly and describe that work |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, and a quote with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran it, weekly, for your main title, for the last two years. A named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the wording, but a presenting line with nothing inspected behind it, so expect a probe on how the numbers were counted (C1). Lead with it as it stands: "I presented the monthly retention numbers to the studio head." |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written artifact a team still uses touches the requirement, and it is the only written piece in your material. Answer slot: if you wrote other plans, recaps or announcements that people acted on, say which, in your own words; if the checklist is the main written piece, say so plainly and stay with it |
| F9 | Experience with in-app purchases: no line in the JD as supplied; listed because you stated it | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I have never worked on a game with in-app purchases." The JD lines as supplied do not name in-app purchases, so this matters if a revenue question comes up. Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Leading a team: no line in the JD as supplied; listed because you stated it | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | Words: "I have never led a team." The pack's reading of the supplied JD is that it asks you to coordinate and own a calendar and a checklist, not to manage people. Keep coordination claims to what your quotes carry |

## Persona table

Weights come from three passes. Relationship prior: a hiring-manager round, assumed, puts Case/Strategist and Skeptic first. Interviewer signals: none, because the profile search did not run, so no adjustment. Loop: your own words give one 60-minute session with Tobias and nothing else about the loop. The fallback archetype is Generic, so no values-style round is detected and weights stay close to the prior. If the relationship is different, the table reweights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: plan, replan, diagnose | Highest. Hiring-manager prior, and the JD is a list of live problems | Clarify, then objective, approach, metrics, risks, thinking aloud; challenge one premise respectfully |
| B. Skeptic | Probes the move from content drops to events, two titles and KPI ownership | High. Hiring-manager prior, and the largest gaps (F1 to F3) are aimed at the role's core | Rehearse the top objection (B2) until it is boring; hold what your quotes carry, concede the rest specifically |
| C. Data-Driven Prober | Follows the retention numbers to their assumptions | Medium. The JD names retention metrics and KPIs | Know what you can and cannot say about how the numbers were counted; say plainly where you do not know |
| D. Conversational | Opening journey question, motivation, communication style | Medium. Almost every loop opens this way, and the questions are still scored | A 90-second arc built only from your own sentences |
| E. Peer Evaluator | Seam-splitting with adjacent teams | Low. Tobias is not a peer on this assumption, but the role works across four teams | Reciprocity framing; propose seam principles, not a pretend seam |
| F. Pressure | Time-boxed or devil's-advocate probes | Low. No signal that this style is used | Pause, restate, hold through two follow-ups, concede specifically |
| G. Values/Behavioral | Scenario probes | Low. No values-style round is detected and no published values were read | Pick a story with a named stake, or use the honest branch |

## Question banks

### A. Case/Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of our titles each want the same week for an update, and you can only support one. How do you decide, and who do you need in the room?" | CASE | [generic] | Clarify first: what is the constraint, engineering capacity, QA window or community readiness. Then objective, options, the decision rule you would use, the metrics you would watch and the risk of each option. Think aloud. Challenge one premise respectfully, for example whether the clash is real. The question needs no claim about your past, so the guidance makes none | Live problem built from the JD's two-titles and calendar lines (F1's requirement). CASE because it scores structure, and `[generic]` because it is a pattern for the problem, not a fact about Saltmarsh |
| A2 | "Retention for players who joined during an event comes in below target. Diagnose it, and tell me what goes in the review." | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: define the measure and the cohort, compare to the target, segment, form two hypotheses, say what goes in the review and what you would change. Name the assumption in your diagnosis you would trust least before they ask. To anchor, say what your material carries at its scope: "I presented the monthly retention numbers to the studio head." Anything about how those numbers were diagnosed is not in the quote | F3 and F7 meet here. CASE delivery on JD content, because the post-event review is a named duty |
| A3 | "Two days before an update goes live, QA flags a blocker and community has already announced the date. What happens next?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure: confirm the facts, list the options (delay, cut scope, ship with a known issue), say who decides and who must be told, how the date message changes, and what goes back into the checklist. Anchor at the quote's scope: "I wrote the release checklist our QA team still uses." Answer slot: the JD's release-checklist line makes a probe on how the checklist is used at release time likely. If you ran releases through it, say how, in your own words; if you only wrote it, or running it was not yours, say so plainly and stay with the checklist you wrote | F4's requirement tested live. CASE delivery on JD content |
| A4 | "Pick one of our two titles. What would you want to know about its players before you plan its next run of events?" | CO | [generic] | Name the title you pick; the pack could not research Saltmarsh, so it cannot name it for you. Structure the unknowns: who the players are, what they do in a week, what the last events did, what the team can build. Say only what you have seen in the product yourself. Playing both titles before Friday is what turns this from generic into specific | The company-knowledge slot, left generic because research did not run. CO and CASE overlap |
| A5 | "Design, art, engineering and community each tell you their piece of an update will land a week late. How do you replan?" | CASE | [generic] | Clarify what is fixed (the date, the scope, the quality bar), then options, who must agree, what you tell each team, how you protect the date for the others and what you record. No claim about your past | JD's four-team coordination line as a live problem. The practice question about your past sits in B3 |

### B. Skeptic (weight: second, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Choose from your own material, not a rehearsed humble-brag. If revenue or in-app comes up, the words are: "I have never worked on a game with in-app purchases." If team leadership comes up: "I have never led a team." Follow each with a plan for how you would learn it, said as a plan. Do not widen either sentence and do not reach for adjacent experience your quotes do not carry | F9 and F10 are stated negatives, and the question invites exactly them. JD content, Skeptic delivery |
| B2 | "You ran the weekly content-drop calendar for your main title. This role runs a live-events calendar for two titles. What changes, and what would you have to learn?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | **Highest-ROI rehearsal in this pack.** Open with what you ran, at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Then name what is new, events and a second title, as things to learn, with how you would learn them as a plan. Answer slot: the JD's live-events and two-titles lines make a probe on events likely. If any of your drops were events or built around them, say how; if they were content releases only, say so plainly and stay with the calendar. Follow-up one, "what is different between a drop and an event": hold by returning to the calendar in the quote's own words. Follow-up two, "so you have not run events": concede specifically that events and a second title are not in your material. Follow-up three, "what would you get wrong in your first month": answer with a plan, the two things you would check first and who you would ask. Keep to the quote's verbs throughout | F1 is the evidence for the calendar requirement and where the scope gap sits, so this objection arrives in some form whatever the wording. JD content with Skeptic delivery. It gets the most follow-up levels because it is aimed where the material is thinnest |
| B3 | "The JD names design, art, engineering and community teams on each update. How have you worked with those teams?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the quote's scope: "I ran the weekly content-drop calendar for our main title." Answer slot: the JD lists four teams, so expect a probe on each. Say which of them you worked with on a drop and what you needed from each, in your own words; if you worked with fewer, or the coordination was not yours, or none existed, say so plainly and stay with the calendar you ran | F2 is a discovery row, so this guidance is a slot and not a story. JD requirement tested as a past-practice question |
| B4 | "Tell me about a time you needed another team to move and could not tell them to." | EXP | [generic] | Selection criteria: an instance with a named stake, a specific ask, and a working relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is the JD's coordination line. A scaffold, not a story map, because no quoted sentence of yours carries this story |

### C. Data-Driven Prober (weight: middle, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented, at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot, in your own words, for the four things a prober asks: how the numbers were counted, what they are sensitive to, which assumption behind them you would defend least, and which part was yours. If you do not know how they were counted, say so plainly. Name the weakest assumption before they do | F7 is a presenting line with nothing inspected behind it. The headline-number slot, EXP because it tests attribution |
| C2 | "Which retention measures would you put in front of a live-event review, and why those?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Choose measures you can define aloud: what each counts, over what window, for which players. Answer slot: if the measures in the numbers you presented are ones you would reuse, say which; if you would choose different ones, or did not choose the earlier ones, say so plainly | F3 and F7 requirement coverage. JD content, Prober delivery |
| C3 | "Tell me about a time you reviewed how a release or drop performed, and what you did with the result." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Selection criteria: an instance where you can name what was looked at, who read it and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I presented the monthly retention numbers to the studio head." Whether any review followed a drop is not in your material. If one did, say what it covered in your own words; if none did, say so plainly | The theme is the JD's post-event-review line (F3). An open prompt, so no event is supplied |

### D. Conversational (weight: middle, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc, one beat per sentence, in your own words: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title for the last two years; the release checklist your QA team still uses; the monthly retention numbers you presented to the studio head. Close with why this role, in your own reasons: if the reason is not yet clear to you, say so plainly and name the JD line that pulls you | The opener, and it carries the 3+ years requirement (F5) in your own words. EXP with JD content |
| D2 | "What is drawing you to Saltmarsh?" | JD | [generic] | Give your actual reasons. Specifics about Saltmarsh must come from what you have seen yourself: play both titles before Friday so you can name what you saw. The pack could not research the company and will not supply reasons for you | Motivation question in a casual register, still scored. `[generic]` because research did not run |
| D3 | "How do you like to communicate a plan to a team that has to build it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Start from the quote's scope: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote other plans, recaps or announcements that people acted on, say which, in your own words; if the checklist is the main written piece, say so plainly and stay with it | F8 is a discovery row and the JD names written communication |

### E. Peer Evaluator (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Engineering has a fixed amount of capacity and your calendar asks for more than that. Where is the seam between us, and what happens when we disagree?" | CASE | [generic] | Propose seam principles, not a pretend seam: who owns the calendar, who owns capacity, how trade-offs are brought forward and who decides when they do not agree. Add reciprocity, what you bring their team and not only what you need. No claim about your past | JD coordination line, peer packaging. Low weight because Tobias is not a peer on this assumption |
| E2 | "How do you handle credit and blame when an update spans four teams?" | JD | [generic] | A principle, said plainly: credit goes to the teams that built it, and you answer for the coordination you took on. No story is mapped because no quoted sentence of yours carries one | The JD's four-team line as a collaboration probe |

### F. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you rather than someone who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Never led a team, and never worked on a game with in-app purchases" | Pause, restate, then two facts in your own words and no more: you ran the weekly content-drop calendar for your main title for the last two years, and you wrote the release checklist your QA team still uses. Hold through two follow-ups by returning to those facts. Concede specifically when pressed: "I have never worked on a game with in-app purchases." Never fold on the two facts just to restore harmony | The time-boxed version of B2. JD content, Pressure delivery |
| F2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Your quote's verb is ran, and that is where you hold. Answer slot: the JD's plan-and-run line makes a probe on the decisions likely. If the decisions on what shipped when were yours, say which and how you made them; if others set the content and you ran the schedule, or no such decision existed, say so plainly and stay with the calendar you ran. Hold through two follow-ups by returning to "I ran the weekly content-drop calendar for our main title for the last two years"; concede specifically whatever part was not yours | The attribution probe exists to catch inflation, so the rehearsal is precision. F1 is the row it tests |

### G. Values/Behavioral (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection criteria: a named stake, what you said, what happened, and a relationship that survived. If no such time comes to mind, say so plainly. The nearest thing your material carries is "I presented the monthly retention numbers to the studio head." Whether any of those numbers was unwelcome is not in your material. If one was, say what you said and what followed, in your own words; if none was, say so plainly | Standard behavioral probe. Low weight because no values-style round is detected |
| G2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection criteria: a specific decision, the metric it cost, and why you chose it. If no such time comes to mind, say so plainly, then give how you would weigh it. No story is mapped because no quoted sentence of yours carries one | A values-style probe from the persona stems. `[generic]` because no published Saltmarsh values were read |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B2, F2 |
| Coordinate design, art, engineering and community on each update | A5, B3, B4, E1, E2 |
| Own the post-event review and the KPIs it reports | A2, C2, C3 |
| Manage the release checklist with QA | A3 |
| 3+ years producing live-service games or apps | D1, F1 |
| Experience running a content calendar | B2, F2 |
| Comfortable with player-retention metrics | A2, C1, C2 |
| Clear written communication | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this role across the two titles?" | The answer shows what you inherit versus what you set up, and shows you are thinking about the ramp |
| R2 | "Which KPIs does the post-event review report today, and who decides what goes in it?" | Tests where F3's gap sits in practice: whether the role defines the review or inherits it |
| R3 | "Where do updates most often slip today, and who is in the room when that happens?" | Surfaces how coordination across four teams works now, and what you would be walking into |
| R4 | "How are the two titles' calendars set today, together or separately, and who resolves clashes?" | Tells you whether A1 is a real situation, and shows you are planning across titles |
| R5 | "How does the release checklist with QA work today, and what would you want changed?" | Connects to the checklist you wrote and invites a working conversation on it |
| R6 | "What would someone coming from a different kind of game need to learn fastest here?" | Turns the background gap into a shared planning question instead of an objection |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F10 | The plain acknowledgment F10 gives: "I have never led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment F9 gives: "I have never worked on a game with in-app purchases." No slot |
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for the main title, not events and not two titles. B2's slot stays inside the calendar |
| Owned the post-event review and chose the KPIs | Inflated form of F3 | F3's quote at its own scope. The material says you presented the numbers. C3's slot asks only what a review covered, if one followed a drop |
| Managed each release with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist and QA still uses it. A3's slot stays inside that |

## Sources

Provided documents: the JD text you pasted, and the background you described in your message. No `tuesday-dossier.md` was present.

Searches sent, all refused:

- `Saltmarsh Games values`: refused
- `Saltmarsh Games interview process Live Operations Producer`: refused
- `Saltmarsh Games mobile studio strategy news`: refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have moved the VAL themes and, only if a values round were documented, a values cheat sheet |
| 2. `Saltmarsh Games interview process` | unavailable | Every call was refused. It would have moved persona weights and replaced the fallback archetype with the documented loop |
| 3. `Saltmarsh Games strategy` | unavailable | Every call was refused. It would have moved A4 and the CO/CASE bank from generic to grounded |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The call was refused. It would have moved the interviewer read, the persona weights and one reverse question |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or a pasted Saltmarsh careers page, values page or interview guide: the generic CO and CASE rows (A4, D2, G2) become grounded, persona weights follow the documented loop, and a values cheat sheet is added if a values round is documented
- A deeper research pass once search is allowed (up to 6 more searches and 2 more fetches, several more minutes): a strategy brief and Tobias's public talks or writing, for a tailored reverse question
- Tobias's relationship to the role and any recruiter guidance on focus areas or a take-home: reweights every bank, and adds a build section for any announced deliverable
- Your answers to the slots in F1, F2, F3, F5 and F8 (events among your drops, which teams you worked with, who chose the retention numbers, how long the title was live-service, other writing you did): those rows move from transferability or discovery toward story maps, and the guidance for B2, B3, C3 and D3 gets sharper
- The release checklist itself, a retention deck or a sample post-update recap: inspectable artifacts that would lift F3, F4, F7 and F8 above medium or low confidence
- Your prep time before the interview: adds a prioritised schedule that puts B2 first
- A `tuesday-dossier.md` from an earlier role check, if you have one: adds verified evidence and a named top objection in place of the inferred one
