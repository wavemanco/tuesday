Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md` in the working directory. It covers all three rounds on 29 November, with a shared fit snapshot, a question bank and reverse questions for each round, and a values cheat sheet for the panel.

I built it from the schedule the recruiter gave you. The interviewers are known by role only, because no names are assigned yet. Your background comes only from your message, since there's no CV in it. I ran no web searches: the pasted values, the recruiter's email, the JD and your summary of the strategy brief already covered every research target.

The pack names the contact-centre objection as your highest-ROI prep, because it comes up in all three rounds. That is R2-B1, the manager round, with lighter versions in R1-B2 and R3-B2. Your two stated gaps, no contact-centre work and no presenting above regional level, are written in your own words and never bridged. None of your sentences carries a story for any of the four values, so those cells are selection scaffolds that end with an honest "say so plainly" branch.

Say the word and I'll play the manager as the Skeptic on R2-B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop on 29 November 2026, three rounds back to back: Round 1, 30 minutes with the recruiter; Round 2, 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural; Round 3, 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four published values. Interviewer names are not assigned yet, so every interviewer is known by role only.

Built in loop mode: one shared fit snapshot, then a mini-pack per round. Everything about your past rests on your own message; no CV was supplied.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and where a cell says answer slot, answer from what actually happened.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether what you say about your work holds up and is precisely yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the credit union's altitude: strategy, competition |
| CASE | Structure and reasoning on a live problem from the role |

Highest-ROI prep: R2-B1, the contact-centre objection. It is the likeliest question in the loop, it arrives in three forms (R1-B2, R2-B1, R3-B2), and a calm rehearsed answer changes the whole round.

## Fit snapshot (shared by all three rounds)

No row is a gate: the JD's only term-like line is a years requirement, and a years requirement is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log and the teller training, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the steps around the log likely. If any of those steps were yours to decide, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn that side, said as a plan and never as a past. Never a claim to contact-centre work or an equivalent, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The sentence shows a monthly complaints spreadsheet your regional manager uses; it does not show what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it showed how many complaints came in or how long they took to resolve, say what it showed and how that was worked out, in your own words; if it showed something else, say so plainly and stay with the spreadsheet |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script; it does not say who else was taught. Words: "I trained new tellers on our escalation script." Answer slot: if anyone you taught or guided on escalations was not a new teller, say who and how, in your own words; if they were all new tellers, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your message either shows or rules this out. Strong evidence would be any piece of work alongside a digital or product team. Answer slot: if you have worked with a digital team, say on what and with whom, in your own words; if you have not, say so plainly and say what you would ask that team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The figure is yours and the work is retail banking; the open point is whether the label matches. Words: "I have six years in retail banking, the last three as a branch supervisor." Say in your own words why you count it as customer operations, and keep to what you did |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | The word formal is yours; the sentence does not say which rules governed the log. Words: "I handled the branch's formal complaints log." Answer slot: if the log was kept under a regulator's rules, say which and how they shaped what you did; if it was an internal log, or you do not know the rules behind it, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Your sentence does not say whether you have presented at regional level, so that is not claimed |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The sentence says spreadsheet, not Excel. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say so and what you did in it; if it was another tool, say which and say so plainly |

## Grounding brief: the 2026 strategy

I have your summary of the brief the recruiter sent, not the brief itself. The items are as you gave them.

| # | Item | Provenance | What it changes in this pack |
|---|---|---|---|
| G1 | Move 40% of member service to digital channels by 2028 | [grounded] | Feeds R2-C2 and R2-B2; a complaints journey has to be one members would use |
| G2 | Consolidate eight branches into five hubs over 2027 | [grounded] | Feeds R3-B3 and a reverse question; the branch managers on the panel are the people this lands on |
| G3 | Launch a small-business lending product in Q1 2027 | [grounded] | No question depends on it; it is a possible reverse-question topic |
| G4 | The main competitive pressure is app-only banks | [grounded] | Gives the digital questions their stakes; a good complaints experience is part of why a member stays |

## Round 1: recruiter, 30 minutes

Persona weights, with reasoning:

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background and motives; feels unscored | High: recruiter screens start here, and logistics come in this register | Prepare a 90-second arc and treat every casual question as scored |
| Skeptic | A quiet knockout check on the gaps | Light: the recruiter will want to know the two gaps before passing you on | Say the gap plainly and move to the plan |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6, F1 and F3. The beats are only the clauses the quotes state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Tell each in your own words in about ninety seconds and end on why this role, in your own words. Your message gives no dates for the log, the training or the spreadsheet, so keep order and timing to what you can stand behind | The standard opener, and the arc is reused in Rounds 2 and 3; EXP because it tests what the CV-style claims actually were |
| R1-A2 | "The role asks for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Presentation on F6. Say "I have six years in retail banking, the last three as a branch supervisor." Then say in your own words why you count that as customer operations, and describe only what you did | The years line is a JD requirement a recruiter may check literally; F6 is the evidence |
| R1-A3 | "Why Ashgrove?" | CO | [grounded] | The question needs no claim about your past. Choose one of the four published values and name it by its official name, then tie it to something you actually did. If nothing comes to mind, say so plainly and talk about what working for a member-owned credit union means to you. Do not recite the values as slogans | Motivation consistency is scored in every screen; the values page is the source of the names |
| R1-A4 | "What are you actually playing with in digital self-service these days?" | JD | [grounded] | Answer slot on F5: the JD's line about working with digital teams on self-service journeys makes this likely. If you have worked with a digital team or used a self-service journey in your branch work, say what and with whom, in your own words; if not, say so plainly and say what you would want to learn first | Casual register, still scored; the JD flags it as a plus the role leans on |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one and say it plainly: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Then say, as a plan, what you would do first about it. Do not try to argue the gap away | F2 and F8 are the two stated gaps; this question collects both |
| R1-B2 | "The role covers the contact centre as well as branches. You've never worked in a contact centre, so how do you see that side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The lighter version of R2-B1. Open with "I haven't worked in a contact centre." Then name, in your own words, the first things you would do to learn it. Do not liken any branch work to contact-centre work; your material does not show that | F2 is the biggest gap against the JD's first line; a recruiter asks it as a knockout check |

### Logistics

Each guidance cell is an instruction for the interview, not a question for you now.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "What are you looking for on pay?" | JD | [generic] | Give your own number, or ask for the role's band first. If you are asked for your current pay, you can decline politely and return to the role | The job's terms are not in the JD, and the only safe answer is your own |
| R1-C2 | "What notice period do you have, and when could you start?" | JD | [generic] | Give your actual notice period and the start date it allows, in your own words | Notice is a standard screen item |
| R1-C3 | "Where would you be working from, and how does that fit the role?" | JD | [generic] | Say where you can work and how often, in your own words. If you do not yet know, say so | The JD gives no location terms; this is where they surface |
| R1-C4 | "Why are you looking to leave your current role?" | EXP | [generic] | Give your actual reason in your own words, and keep it about what you are moving toward | Reason for leaving is asked in every screen and consistency is scored |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "How will the 20-minute case in the panel round work, and will I see anything beforehand?" | The case is the biggest unknown; the answer decides whether the pack needs a build section |
| 2 | "How does the panel score against the four values, and is there anything I should read beforehand?" | Shows you took the values round seriously |
| 3 | "How is the contact centre team organised, and how does it connect to the branches?" | Targets your biggest gap directly, as a learner |
| 4 | "Which digital teams would this role work with most?" | Answers F5's open question for you |
| 5 | "What is the timeline after the 29th?" | Closes the loop and shows interest |

## Round 2: Head of Member Services, 45 minutes, mostly behavioural

Persona weights, with reasoning:

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes: "Tell me about a time…" | Highest: the recruiter described the round as mostly behavioural | Choose stories only where a quoted sentence carries one; otherwise use the scaffold and its honest branch |
| Skeptic | Quiet probing of the gaps, with the manager's view of the contact centre | High: a hiring manager is derisking gaps, and this manager would own the result | Rehearse the contact-centre objection until it is boring |
| Case/Strategist | A live problem from the role | Lower: the case is the panel's job in Round 3 | Clarify first, then structure, then answer |

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior something they did not want to hear. It needs a named stake, the moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural probe; the story must be one you can tell with I for what you did |
| R2-A2 | "When did you put a member ahead of an internal target or process?" | VAL | [grounded] | Selection scaffold, drawn from the value Members First, Always: pick a decision where what was best for the member and what was easiest for the credit union pulled apart. It needs the decision, what you weighed and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value, asked in a manager's register |
| R2-A3 | "Tell me about a time you coached someone through a difficult escalation." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: the beats are the training of new tellers on the escalation script, told in your own words. Answer slot: the JD asks about coaching branch supervisors, so expect a probe on who else you taught. If anyone you taught or guided on escalations was not a new teller, say who and how; if they were all new tellers, say so plainly and stay with the tellers | F4 is the closest evidence to the JD's coaching line |
| R2-A4 | "Tell me about a time you worked with another team to change how something worked for members." | VAL | [grounded] | Selection scaffold from the JD line about working with digital teams: pick a time you worked across a team boundary to change something members experienced. It needs who the other team was, what you each owned and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 has no evidence yet; this is the behavioural form of that gap |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "You've never worked in a contact centre. This role owns complaints across branches and the contact centre. How will you earn credibility with that team?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Open with the plain words: "I haven't worked in a contact centre." Name the limit before it is asked for: the contact-centre side is where you have the most to learn, said as a plan and never as a past. Hold on what the quotes carry: "I handled the branch's formal complaints log." Follow-up one, "What is different about complaints that arrive by phone?": answer slot. If you have any direct sight of how phone complaints are handled, say what, in your own words; if you have none, say so plainly and say what you would ask the team first. Follow-up two, "Would you rather have someone who has run a contact centre?": concede plainly that such a person would know that side better, and return to the log. Do not argue that branch work equals contact-centre work | F2 is the biggest gap against the JD's first line, and this manager would own the outcome; JD because it scores a stated requirement |
| R2-B2 | "I don't see digital teams anywhere in your background. How would you handle the self-service side of this role?" | JD | [grounded] | Answer slot on F5. If you have worked with a digital team, say on what and with whom, in your own words; if you have not, say so plainly and say what you would ask that team first. Do not claim digital work your message does not state | The interviewer's line is a stem for a gap the pack observes, not one you stated |
| R2-B3 | "Walk me through the monthly complaints spreadsheet you built. What did it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F9: the beats are that you built it, that it is monthly, that it is about complaints and that your regional manager uses it. Answer slot: the JD asks for monthly reporting on complaint volumes and resolution times, so expect a probe on what it counted. If it showed how many complaints came in or how long they took to resolve, say what it showed and how that was worked out; if it showed something else, say so plainly. Also say which tool it was built in: if Excel, say what you did in it; if another tool, say which | F3 and F9 are the reporting and Excel requirements; EXP because it tests what you actually built |
| R2-B4 | "Tell me about the branch's formal complaints log. What did handling it involve?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7 and F1: you handled the branch's formal complaints log, told in your own words. Answer slot: the JD asks for experience of regulated complaints. If the log was kept under a regulator's rules, say which and how they shaped what you did; if it was an internal log, or you do not know the rules behind it, say so plainly and stay with the log you handled | F7 is where the JD's regulated-complaints line presses |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-C1 | "The average time to resolve a complaint rose sharply last month. Diagnose it." | CASE | [generic] | The question asks about no past. Clarify what resolution time counts (receipt to closure, or first contact to closure), which channels and which complaint types. Then structure: segment by channel, complaint type, branch and stage. Hypotheses to test: a spike in volume, a stuck stage, staffing, a handover between channels, a change in how closure dates are recorded. Metrics: average against median, ageing of open cases. Challenge one premise respectfully: is the rise real, or a recording change? | The JD's monthly reporting line, asked as a live problem; it also exercises the Excel requirement without a claim |
| R2-C2 | "We aim to move 40% of member service to digital channels by 2028. Which complaint types would you keep human-led, and how would you decide?" | CO | [inferred] | The question asks about no past. The target is the strategy summary's; the criteria are this pack's derivation from that target and the Plain Words value. Clarify what counts as service moved; propose decision criteria (how emotional or complex the complaint is, whether the member can use the digital route, what a wrong answer costs); say what you would measure. Name the risk: a member told something once in an app and not understood | G1 is the strategy move the manager's team most visibly owns |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first 90 days look like, and what would tell you it was going wrong?" | Lets you hear the manager's scoring sheet |
| 2 | "Where does the complaints process work well today, and where do members or staff say it does not?" | Shows you are thinking about the process, not only the title |
| 3 | "How do the contact centre and the branches hand a complaint to each other today?" | Aims at the seam your gap sits in, as a learner |
| 4 | "Which self-service journeys are already planned for complaints, and who in digital would I work with first?" | Answers F5's open question |
| 5 | "What do senior leaders ask about in the monthly report?" | Turns the reporting line into a conversation about what the audience needs |

## Round 3: panel of two branch managers, 60 minutes, including a 20-minute case

Persona weights, with reasoning:

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored scenario probes mapped to the four values | Highest: the recruiter said the panel is the values round and scores against the four values | One story per value where a quote carries one; the scaffold and its honest branch where none does |
| Case/Strategist | The 20-minute escalation case and strategy probes | High: a third of the round is a case, and branch consolidation lands on these managers | Clarify, structure, answer, with the values' own words |
| Peer Evaluator | Seam-splitting between a branch manager and this role | Medium: you would coach their supervisors | Propose seam principles instead of pretending to know the current seam |
| Pressure and Skeptic | Short, time-boxed challenges | Low: panels of managers rarely lead with these, but expect one or two | Hold what the quotes carry, concede the two stated gaps plainly |

Conversational openers are covered by Round 1's arc (R1-A1).

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell us about a time you made a call from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First, Always: pick a decision where you took the member's side. It needs what the member needed, what you weighed and what happened to the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first value, asked in the panel's own words |
| R3-A2 | "Tell us about a time you changed how something was said because members did not understand it." | VAL | [grounded] | Selection scaffold for Plain Words: pick a time you reworded something for members. It needs what was unclear and what changed. Your material says you trained tellers on an escalation script, not that you wrote or reworded it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second value; the pack's observation on the script keeps you from claiming a rewrite |
| R3-A3 | "Tell us about a time you weighed what a branch's numbers said against what it meant to its town." | VAL | [grounded] | Selection scaffold for Neighbours, Not Numbers: pick a time a figure and a local judgement pulled apart. It needs the figure, the local fact and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The third value, and the one the hub consolidation tests hardest |
| R3-A4 | "Tell us about a problem you kept hold of until it was solved." | VAL | [grounded] | Selection scaffold for Own the Fix: pick a problem where you were the one holding it from discovery to the end. It needs who handed it to you, what you did to keep hold and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The fourth value; the one a complaints lead is most directly scored on |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-B1 | "A member's complaint has been escalated twice and is still open. Walk us through what you do." | CASE | [generic] | A stand-in for the real case, whose format is not yet known. The question asks about no past. Suggested shape over 20 minutes: clarify first (what happened, what the member has been told, who holds it now, any time limits that apply); state the objective (the member's problem solved and told plainly); segment (what is stuck, where); approach, with the person keeping hold named; metrics; risks. Think aloud and challenge one premise respectfully. Use their words: the member's side of the counter, and whoever finds the problem keeps hold | The recruiter named the case; the format will change the detail, not the shape |
| R3-B2 | "A member raised a complaint at the counter and again by phone. Each team thinks the other has it. Who owns it, and what do you change so it cannot happen?" | CASE | [generic] | The question asks about no past. Say who owns it now (the one who found it keeps hold, by their own value), what you would do for the member today, and what you would change in the handover between branch and contact centre. Say what you would measure and what could go wrong with the change | The branch and contact-centre seam from the JD's first line, in a case; it is the third form of the contact-centre objection |
| R3-B3 | "Eight branches become five hubs over 2027. A member in a town that loses its branch has a complaint. What does the process look like for them?" | CO | [grounded] | The question asks about no past. The eight-to-five consolidation is from the strategy summary (G2). Clarify what that town's members currently rely on and which channels will remain; start from where the member is; make clear who keeps hold of the complaint; use plain words; track complaint volumes and resolution times by town. Name the risk: a complaint lost between the closing branch and the hub | G2 lands directly on these managers, and the value Neighbours, Not Numbers is its test |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Where is the seam between a branch manager and this role on a complaint at my branch, and what happens when we disagree?" | JD | [grounded] | The question asks about no past. Propose seam principles instead of pretending to know today's seam: the member hears from one person, whoever finds it keeps hold, and disagreements are settled by what the member needs. Offer reciprocity: what you would give the branch, which the JD frames as coaching supervisors on escalations | Peers price what the hire costs and gives their branch |
| R3-C2 | "How do you handle credit when a result spans teams?" | EXP | [generic] | Selection scaffold: pick a time a result was shared across teams. It needs who did what and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe on collaboration |
| R3-C3 | "What would you need from us as branch managers?" | JD | [grounded] | The question asks about no past. Ask for things that serve the member and the branch: a clear first contact, access to the supervisors you would coach, and honest early warning when a complaint is going wrong. Pair each with what you would give back | The reciprocity move the Peer row of the persona model calls for |

### Pressure and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause and restate the question. Hold only what the quotes carry: "I handled the branch's formal complaints log." "I trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." Concede specifically if pressed: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Hold through two follow-ups by returning to the quotes, and say nothing about what an internal candidate lacks | A pressure stem for composure; the concession is stated before it is asked for |
| R3-D2 | "The role reports monthly and presents to senior leaders. You've never presented above regional level. What makes you confident you can?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Open with "I haven't presented to anyone above regional level." Then say, as a plan, how you would prepare. Answer slot: your sentence does not say whether you have presented at regional level. If you have, say what, in your own words; if not, say so plainly. Do not claim a confidence you cannot back | F8 is a stated gap; the panel may probe it even though they are not senior leaders |

### Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "When a complaint goes well at your branch, what does it look like, and what do you wish supervisors did differently?" | Shows you want to start from the branch's view |
| 2 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel |
| 3 | "Which complaints reach you first, and how do you hear how they ended?" | Targets the handover your role would own |
| 4 | "How do you expect the move from eight branches to five hubs to change what members bring to the counter?" | Ties to G2 and the Neighbours, Not Numbers value |
| 5 | "Which of the four values do staff find hardest to live out day to day?" | Shows the values are not just words to you |

## Values cheat sheet

A values-style round is documented: the recruiter says the panel scores against the four values. None of your quoted sentences carries a story for any value, so each row is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: pick a decision where the member's interest and the easiest path pulled apart; it needs what you weighed and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold: pick a time you reworded something members did not understand; it needs what was unclear and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold: pick a time a figure and a local judgement pulled apart; it needs the figure, the local fact and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold: pick a problem you held from discovery to the end; it needs who handed it to you and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 own the process end to end | R2-B4, R3-B1, R3-B2 |
| F2 across branches and the contact centre | R1-B2, R2-B1, R3-B2 |
| F3 report monthly on volumes and resolution times | R2-B3, R2-C1 |
| F4 coach branch supervisors on escalations | R2-A3, R3-C1 |
| F5 work with digital teams on self-service | R1-A4, R2-A4, R2-B2, R2-C2 |
| F6 4+ years in financial-services customer operations | R1-A2 |
| F7 regulated complaints | R2-B4 |
| F8 present to senior leaders | R1-B1, R3-D2 |
| F9 Excel reporting | R2-B3, R2-C1 |

## Prohibited claims

Built before the banks. None of these is coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the log, not the process |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: the material says tellers, not supervisors |
| Has contact-centre experience, or an equivalent | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; the four values as pasted ("copied this morning from ashgrovecu.org/about/values"); the recruiter's email on the three rounds; your summary of the 2026 strategy brief (not the brief itself); your background message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | skipped | Could not have moved the values cheat sheet or the VAL questions: the pasted values text fixes them |
| 2. `{company} interview process {role family}` | skipped | Could not have moved the loop or persona weights: the recruiter's email fixes the three sessions, who runs each and the values scoring |
| 3. `{company} strategy` / recent news | skipped | Could not have moved the CO bank: your summary of the July 2026 brief supplies the four strategic points |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV or earlier resume → more quoted sentences for F1, F3, F4, F7 and F9, and a sharper arc for R1-A1
- Your own answers to the answer slots, said outside a drill → F1, F3, F4, F5, F7, F8 and F9 become story-mapped rows, and the matching bank cells upgrade
- The interviewers' names once assigned → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to each one's own path
- The recruiter on the 20-minute case → whether it uses material in advance; if it does, a build section for it, and R3-B1's stand-in is replaced
- The strategy brief itself → a fuller grounding brief with the figures and dates, which are currently only as you summarised them
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering strategy, interviewer footprints, role-family loop reports and recent organisation news → richer CO and CASE questions and the grounding brief; say the word if you want it
- A `tuesday-dossier.md` from an earlier session → verified evidence and prohibited claims carried in, so the highest-ROI objection is evidence-derived instead of inferred
