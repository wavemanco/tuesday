Searches weren't permitted here, so I'm building the pack from what you've told me and labeling everything unresearched as generic. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-3-denied-c77b66c1/stripe_product-operations-manager_interview_pack.md`.

Web search wasn't permitted in this session, so all four research calls were refused. The pack rests only on what you told me, and nothing in it is a claim about Stripe or about your past. Its 19 questions are labeled `[generic]`, and the fit snapshot is a worksheet to fill in. I assumed a blended round, since your note doesn't say who you're meeting.

The question I'd rehearse first is B1, "Which part of this role would you be weakest at on day one?" It's the most predictable question for any candidate.

Say the word and I'll run a live drill as the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round (future manager, peer, skip-level, cross-functional), and has the recruiter said anything about focus areas or a deliverable? This reweights every bank.
2. Can you paste your CV and the job description? Without them the fit snapshot stays a worksheet and the guidance stays scaffolds, though I can keep going without them if you'd rather.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round prep pack

Role: Product Operations Manager. Company: Stripe. Round: final round. Interviewer: not known. Relationship: not known, so persona weights are blended.

Built from your message alone. No job description, CV, interviewer name or recruiter guidance was supplied, and research could not run (see Sources). Every row below is labeled `[generic]`, and nothing in this pack is a claim about Stripe or about your past.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows a company's published values |
| EXP | Whether claims about your work survive scrutiny |
| JD | The stated role: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem, structured aloud |

## Fit snapshot (worksheet)

No CV or background was given, so this is the worksheet variant: every evidence cell reads `none given`. The requirements are plain-prose role-family requirements with no source, so they raise no probes and carry `[generic]`. Fill the worksheet in, or send your CV, and these rows become real.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating work across several product and business teams (role-family) | none given | none | [generic] | discovery | Strong evidence here is a piece of work you coordinated, with the teams named and what you personally did. Selection scaffold: choose one cross-team effort whose outcome you can describe without "we"; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |
| F2 | Running or improving a product launch or release process (role-family) | none given | none | [generic] | discovery | Strong evidence is a launch or release you took part in, with your own role stated at its true size. Selection scaffold: choose one launch and be exact about which part was yours; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |
| F3 | Using data to decide what product teams should do (role-family) | none given | none | [generic] | discovery | Strong evidence is a decision a number changed, with how the number was counted and its weakest assumption in your own words. Selection scaffold: choose one such decision; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |
| F4 | Getting results without formal authority over the people involved (role-family) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team and how it ended, including a part that did not go your way. Selection scaffold: choose one such moment; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |
| F5 | Designing lightweight process and tooling that teams actually adopt (role-family) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed and what teams did with it afterwards, good or bad. Selection scaffold: choose one such process; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |
| F6 | Communicating status, risk and recommendations to senior leaders (role-family) | none given | none | [generic] | discovery | Strong evidence is a message to senior people that changed something, and how it was received. Selection scaffold: choose one such message; if none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 | A1, A4, D1, D3 |
| F2 | A1, A3, A5 |
| F3 | A2, E2 |
| F4 | B4, C3, D1, D2, G1 |
| F5 | A3, A4, B3 |
| F6 | B1, C1, G1 |

## Persona table

The loop is not established: your note says "final round" and nothing about how many sessions it holds or who runs them. Weights therefore rest on the generic archetype (flat weights, said plainly), not on Stripe's documented process. Correct me if you know the schedule.

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | A live launch, adoption or process problem | high | A role-family judgment: operations roles are usually tested on structure. `[generic]` | Clarify, then objective, segmentation, approach, metrics, risks, thinking aloud |
| Skeptic | Quiet probing of why this role, why now, and day-one weakness | high | Final rounds usually re-test motivation and gaps. `[generic]` | Rehearse the weakest-point answer until it is boring |
| Pressure | Time-boxed challenges, "how much was you" | medium | Unknown interviewer, so a plausible but unconfirmed style | Pause, restate, hold through two follow-ups, then concede specifically |
| Peer Evaluator | Seam-splitting with adjacent teams | medium | Possible if a peer sits on the loop; relationship unknown | Reciprocity framing; propose principles for the seam |
| Conversational | Chatty openers that are still scored | medium | Opening minutes of almost any round | A 90-second arc, prepared |
| Values/Behavioral | Scenario probes | low | No values page or loop source in hand, so no values round is detected | Choose stories in which the hard truth actually landed |
| Data-Driven Prober | Line-by-line CV probing | low | No CV supplied, so nothing to probe yet; no bank written | Added once a CV exists |

## Question banks

Highest-ROI prep in this pack: B1, "Which part of this role would you be weakest at on day one?". Some form of it is the most predictable question for any candidate.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and three teams disagree on whether it is ready. What do you need to know first, and how do you decide what happens next?" | CASE | [generic] | Clarify the decision and who owns it, then the criteria for ready, then the options (ship, ship narrowed, delay), then how you would communicate the call. Name one premise you would challenge. The question needs no claim about your past, so the guidance makes none | Live problem from the core of a product operations role; CASE because it scores structure |
| A2 | "Adoption of a newly launched feature is 20 percent below plan. Diagnose it." | CASE | [generic] | Ask how plan was set and how adoption is counted before diagnosing; segment by who, where in the funnel and when; separate a measurement problem from a product problem; state the weakest assumption in your own diagnosis | Metric-diagnosis case; covers F3 |
| A3 | "Design a launch process for a company shipping many products at once. Where do you start, and what does the process deliberately leave out?" | CASE | [generic] | Start with what goes wrong today, then the smallest process that fixes it; say what you would not standardize and why; say how you would tell it is being adopted | Tests F5 and whether you over-build |
| A4 | "Product teams tell you a new process is slowing them down. What do you do?" | CASE | [generic] | Listen for the specific friction before defending anything, test whether it is the process or its rollout, offer a change you could make this week, and say what you would keep | Adoption pushback is a standard operations scenario; covers F1 and F5 |
| A5 | "What would you want to understand about how products reach customers here before changing how a launch is run?" | CO | [generic] | Do this homework from Stripe's own published material, since this pack could not research it and supplies no facts. Frame as questions you would ask, not claims about the company | The strategy brief could not be built, so this stays generic; CO because it tests homework depth |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap in your own terms, say plainly why it is a gap, then give a concrete first-ninety-days plan to close it. Hold it through two follow-ups; do not retreat to "I'd learn quickly". Choose the gap before you are asked. A gap you can name calmly reads as self-knowledge | Highest-ROI rehearsal: the question is predictable and the answer is entirely yours to prepare; JD because it scores fit against the role |
| B2 | "Why Stripe, why product operations, and why now?" | JD | [generic] | Three short parts in your own words: the pull of the role, the pull of the company, the timing. Each part has to be a reason you actually hold | Motivation consistency is what a final round re-tests |
| B3 | "What does a product operations manager do that a program manager or a product manager does not?" | JD | [generic] | Define the seam in your own terms and say where the roles overlap honestly. A position you can defend beats a textbook list | Probes whether you understand the role's boundaries; covers F5 |
| B4 | "Where would you say no to a product team?" | JD | [generic] | Give the principle first (what makes a request worth refusing), then how you would say it so the relationship survives. Do not claim a time you did this unless one is yours | Tests spine and tact together; covers F4 |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two reasons that are true for you, then stop. Hold under a challenge by returning to what you stated; concede uncertainty explicitly where you have it | Composure test; covers F6 |
| C2 | "Choose the piece of work you would put forward as your best. How much of it was actually you?" | EXP | [generic] | Choose before the interview. Be exact about your own share, say what was a team's, and name the part you would defend least. Selection scaffold: if no piece comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Attribution probe; precise honesty is the whole rehearsal |
| C3 | "Thirty seconds: what would you change first about how a company like this ships products?" | CO | [generic] | Say what you would ask first rather than assert a diagnosis; one hypothesis labeled as a hypothesis; one way you would test it. Make no claim about Stripe's actual process | Time-boxed strategy pressure; covers F4 |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for a seam (who decides, who is consulted, how disagreement escalates) rather than pretending to know it; say how you disagree with an equal | Seam-splitting is the peer's core probe; covers F1 and F4 |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: choose one cross-team effort where credit was shared; say what was yours and what was not. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Credit-sharing probe; covers F4 |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Give specific asks, then what you would bring the peer's team in return | Reciprocity framing; covers F1 |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in your own words: where you started, the one or two moves that mattered, and why this role is the next one. Every step must be something you did | Casual but scored; the arc is yours to write |
| E2 | "What has been holding your attention lately in how teams use data or tools to run product work?" | JD | [generic] | Pick something you have actually spent time on; if nothing comes to mind, say so plainly and name what you would explore first | Casual register on a hot topic; covers F3 |

### G. Values/Behavioral

No values page or loop source was in hand, so these use persona stems only and do not map to Stripe's published values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Persona stem; covers F4 and F6 |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose a decision with a real cost to the metric and say who decided. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Persona stem; honest branch is the point |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does the team decide which launches get operational support and which do not?" | Shows you think about prioritization, which is the job |
| R2 | "What would a good first ninety days look like, and how would you tell by day sixty it was going well?" | Turns the interview into scoping the role |
| R3 | "Which relationship between this team and the product teams is hardest right now?" | Invites candor about the real problem |
| R4 | "What was a recent decision that went differently than the team expected, and what changed afterwards?" | Signals interest in how the team learns |
| R5 | "What would make you hesitate about hiring me?" | Gives you a chance to answer the objection live |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer interviewer; skip it otherwise |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any statement about your past work that comes from this pack's wording | No sentence of yours is in hand, so nothing can be inflated or contradicted yet | Your own sentences; once you give some, this list is rebuilt against them |

## Sources

Provided documents: your message only. No JD, CV, dossier or link.

Searches sent: "Stripe operating principles values" (refused), "Stripe interview process product operations manager" (refused), "Stripe strategy 2026 annual letter stablecoins agentic commerce" (refused), "Stripe Product Operations Manager job description responsibilities" (refused).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied published value names for a values cheat sheet and VAL mapping; none is in the pack |
| 2. Stripe interview process, product operations | unavailable | Would have established loop structure and moved persona weights; weights rest on the generic archetype instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded CO and CASE questions in current priorities; A5 and C3 stay generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have given the fit snapshot sourced requirements; they are role-family prose labeled generic |

## Upgrade menu

- Your CV or a pasted summary of your recent roles → the six worksheet rows get quoted evidence, confidence and gap types, and the guidance becomes story-mapped instead of scaffolds
- The job description text → the six generic requirements become quoted, sourced requirements and the JD-tagged questions are rebuilt against them
- Who you are meeting and your relationship to them (manager, peer, skip-level, cross-functional) → persona weights and banks restructure
- The recruiter's prep notes or the schedule, if your final is several sessions → per-session mini-packs and any pre-declared deliverable gets its own build section
- The interviewer's name → a tailored reverse question and weights read from their public footprint
- Permission to run searches, or Stripe's values page pasted in → values cheat sheet, loop structure and current-strategy questions
- A tuesday-dossier.md from an earlier check of this role, if you have one → verified evidence and constraints on what the pack may coach
