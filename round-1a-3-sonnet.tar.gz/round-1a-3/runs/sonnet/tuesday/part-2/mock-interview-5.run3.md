Search permission was refused on all four of my research calls, so I'm building the pack from your message and the recruiter's wording alone. Nothing about Kelverton comes from research.
Your prep pack is saved as `Kelverton-Rail_senior-partnerships-manager_interview_pack.md`. I built it for a two-person panel, Deepa as your future manager and Ross pushing on commercials. It has 18 questions and a section for the 15-minute POV.

- **Missing report:** the market report didn't come through, so I haven't seen it. The POV section gives the structure for using it (one point to agree with, one to diverge from, one thing to say no to), but the content is blank until you paste it.
- **No research:** search permission was refused on all four calls. There's nothing in the pack about Kelverton's values, strategy or the two interviewers; those parts are labelled generic or inferred.
- **Biggest prep item:** B1, "which part would you be weakest at on day one?" The pack has you say plainly that you've never sold into rail and never carried a direct quota, then give the bus and light rail planning at its real scope, then a ramp plan. I'd put your second hour there.
- **Ross's ground:** the £4M gets probed on how it was counted, what you'd defend least and which part was yours (D1 to D3, C2, C3). I can't supply those answers; they come from your own records.
- **Timeline question:** "9 years in partnerships, last 4 at payments" plus "5 years in consulting before that" doesn't add up on its face. Settle the dates before Tuesday (B4).

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, or shall I stay on the recruiter's wording?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second round, Tuesday. Panel per the recruiter's email: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute POV on where you would take operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves, then Q&A in which Ross will push on commercials.

Built on this assumption: your message and the recruiter's words are the only inputs. No job description was supplied, the market report did not reach me, and no research ran (search was refused), so nothing here is a claim about Kelverton, rail or the two interviewers.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: VAL is values alignment. EXP is a deep-dive on your own experience. JD is the role as listed. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. Every line in quotation marks that you are meant to say is proposed language, pending your approval: change anything that is not how it happened.
- An answer slot is an instruction for the interview, not a question for now. Both branches are fine; the honest one is the one that matches what you did.

## Prep triage (about four hours)

1. 60 min. Build the POV spine (section: Graded deliverable). Choose one thesis, write the opening assumptions (A1) and the operator close. Time it aloud against 15 minutes.
2. 45 min. Rehearse B1 until it is boring: the two plain acknowledgments in F4 and F5, then the ramp plan. This is the highest-ROI prep in the pack.
3. 60 min. Ross's ground: D1 to D3, C2 and C3. From your own records, work out how the £4M was counted and what you would defend least. The pack cannot supply this; only you can.
4. 45 min. The market report: one item you agree with, one you diverge from, one anti-pick (A2). Do not recite its shortlist.
5. 30 min. One timed run of the whole 15 minutes, then A5 and B1 aloud.

Everything else (E1, E2, A4, B3) is insurance.

## Fit snapshot

No gate rows: nothing in your message or the recruiter's words states a term you must meet.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel, not operator partnerships, with nothing inspected behind it, so the words stay at that scope: "For four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the recruiter's "operator partnerships" makes a probe on whether the two kinds of partner work alike likely. If any of how you worked with those partners carries to operators, say which, in your own words; if none does, or you are unsure, say so plainly and stay with the channel you ran |
| F2 | "land on what it means for the operators themselves" — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote carries network planning for bus and light rail in consulting; it does not carry train operating companies, and "from the other side" is yours to explain. Words: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter's land-on-operators line makes a probe on what operators care about likely. If any of that work put you in front of operators, say what they cared about, in your own words; if it did not, or they were not train operators, say so plainly and stay with the network planning you did |
| F3 | "Ross will push on commercials" — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue with nothing inspected behind it, and it stays exactly that: "roughly £4M of influenced revenue". Answer slot: a figure draws four probes: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Say each in your own words; if you do not know how it was counted, say so plainly |
| F4 | Accountability for a commercial number (role-family expectation, no source: no JD supplied) | "never carried a direct quota, only influenced revenue" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then what you would want to learn about how this role's number is set, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Prior experience selling into rail operators (role-family expectation, no source: no JD supplied) | "Never sold into rail specifically" — your message | none | [generic] | capability | You have stated the gap. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. F2 is the adjacent work, at its own scope |

## Graded deliverable: the 15-minute POV

Announced by the recruiter, so it is graded. No slides: you talk it through, and it must land on what it means for operators.

Grounded facts to build on (yours, quoted exactly from the fit snapshot):

- F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"

Shape, speakable in about 10 to 12 minutes so there is room before Q&A: (1) assumptions you are making, said as assumptions (A1); (2) one thesis; (3) its mandatory concession; (4) what you would say no to (A2); (5) the close for operators.

Thesis options. They are positions to test, not facts about Kelverton or rail, and none is yet checked against the market report.

| Thesis | What it argues | Mandatory concession | Provenance |
|---|---|---|---|
| T1 Fewer, deeper | Concentrate on a small set of operators and agree a shared plan for what the software should change for each, rather than widening the list | You give up reach: operators outside the set wait, and you do not yet know how many partners Kelverton has or what it counts as a partnership | [generic] |
| T2 A repeatable path | Make the route from first deployment to wider roll-out the same each time, so an operator can see the next step and its cost | A template can fit awkwardly where an operator's situation is unusual, and commercial guard rails would need Ross's input | [generic] |
| T3 A partner layer | Build a small group of third parties around the software so operators get more from what they already run | Slower to pay back than eighteen months might allow, and it adds support load; your ISV channel is the only adjacent evidence (F1) and F5 limits how far it transfers | [generic] |

Differentiation. The report did not reach me, so I cannot say what its consensus is. The method: bring one item from it that you agree with, to show you read it; then one thesis-driven divergence, with the reason; then the anti-pick, the one thing the role should say no to. A shortlist recited from a report both interviewers have read scores as homework; a reasoned departure from it scores as judgement.

The close the recruiter asked for: finish with one concrete change an operator would notice within the eighteen months, in the operator's terms and tied to one measure. Use a figure only if it comes from the report or your own records.

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the actual roadmap: plan this, prioritise that | High. The recruiter calls Deepa your future manager, which puts her at the hiring-manager row (Case/Strategist plus Skeptic), and the POV is itself a case | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Skeptic | Quiet, persistent probing of the rail gap and the move | High. Same hiring-manager row; F5 is the largest stated gap | Rehearse B1 until boring; plain acknowledgment, adjacent evidence at its scope, concrete ramp |
| Data-Driven Prober | Every number to its assumptions | High. The recruiter says Ross will push on commercials; I read that as the Prober first and Pressure second, an assumption because his relationship to the role is not stated beyond his title, and F3 is the figure he can probe | Know what you can and cannot say about how the £4M was counted; say plainly when you do not know |
| Pressure | Interruptions, time-boxing, "how much was you" | Medium. Ross's second persona by the same reading | Pause, restate, anchor in your own sentences, hold through two follow-ups, concede specifically |
| Conversational | Friendly, unstructured openers | Low. The first 15 minutes are the POV, so a biography question may not come, but casual questions are still scored | A 90-second arc from E1; treat casual questions as scored |

Values/Behavioral and Peer have no bank. The recruiter named no values round, and no peer is on the panel. The loop is fixed by the recruiter's own words (one 60-minute panel of two), so no archetype fallback is used.

## Question banks

### A. Case/Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you tell us where you'd take operator partnerships, what are you assuming about where they are today?" | CASE | [generic] | State two or three assumptions aloud before the thesis: what operator partnership covers, which operators come first, what success looks like at eighteen months. Mark each as an assumption they can correct. The question needs no claim about your past, so the guidance makes none | The POV line puts the open problem first, so a clarifying move is scored (F1); CASE because structure comes before the answer |
| A2 | "What would you say no to in your first year?" | CASE | [generic] | Name one thing you would deliberately not do and the reason, in a sentence; it must follow from the thesis you chose. This is the anti-pick | Separates judgement from a shared shortlist; CASE because it scores prioritisation |
| A3 | "An operator has bought the software but isn't getting the benefit it was sold on. What do you do in the first thirty days?" | CASE | [generic] | Structure: what you need to know first, who on the operator's side and ours, what you would offer, what you would not promise, how you would tell it worked. End on what changes for the operator's own people. The question needs no claim about your past | The recruiter asked you to land on operators (F2); a live case tests whether you do it unprompted |
| A4 | "Why would an operator want a deeper partnership with us instead of simply staying a customer?" | CO | [inferred] | Answer from the operator's seat: what they gain, what it costs them, what would make them decline. No fact about Kelverton or operators is supplied here; mark what you are assuming | Derived from your description of what Kelverton sells; CO because it tests thinking at the company's altitude, and [inferred] because no research ran |
| A5 | "An operator offers to be a public reference in return for a better price. How do you respond?" | CASE | [generic] | Structure: what the reference is worth against what the discount costs, who would have to sign off (ask, do not assume), what you could offer instead of price, and the line you would not cross. The question needs no claim about your past | Ross will push on commercials (F3); a scenario scores judgement without a quota you have not carried (F4) |

### B. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI rehearsal in this pack. Say it first, plainly: "I've never sold into rail specifically." Then, at the quote's scope: "I spent five years in transport consulting, in bus and light rail network planning." Then the ramp, as a plan and never a past: whom you would learn from in the first thirty days and what you would ask them. Answer slot: if any of the consulting work put you close to train operators, say how, in your own words; if it did not, say so plainly and stay with the network planning you did. Hold through two follow-ups by returning to those two sentences, never by adding to them | F5 is the stated gap and F2 the adjacent work, so this objection arrives in some form; JD because it scores the role's demands |
| B2 | "Your last role was an ISV channel at a payments company. What carries over to train operators, and what doesn't?" | JD | [grounded] "last 4 at a payments company running the ISV channel" | State the channel at its scope: "For four years I ran the ISV channel at a payments company." Answer slot: if any of how you worked there carries to operators, say which and why, in your own words; if none does, or you are unsure, say so plainly and say what you would test first. Giving the half that does not carry protects the half that does | F1 is the bridge and the likeliest place a skeptic presses; JD because it scores the transfer |
| B3 | "Why this move, and why now?" | EXP | [generic] | Give your own reason in one sentence. Nothing you shared states one, so the pack supplies none. Keep it to reasons you would still give if asked a second time | The motivation probe belongs to the Skeptic; EXP because it tests whether your account of your own career holds |
| B4 | "Walk me through the dates: how do the nine years in partnerships and the five in consulting fit together?" | EXP | [grounded] "9 years in partnerships"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The pack's own observation: your message says nine years in partnerships with the last four at the payments company, and the consulting "before that", so it does not show where the other five partnership years sit. Answer slot: give the order and rough dates as you would on a CV; if any of the years overlap, say so plainly | A reader will try to reconcile F1 and F2 first; EXP because it tests whether the CV claims survive |

### C. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate. Say the plain acknowledgment, "I've never sold into rail specifically", then what you did at its scope: "For four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the reason you over them is yours to give; if a reason comes from your own work, say it, and if you are not sure of one, say so and say what you would prove first. Hold through two follow-ups; concede only what your own words concede | F5 is the objection in its most compressed form; JD because it scores fit against the role |
| C2 | "That £4M, how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold the quote exactly, including the word influenced. Answer slot: say which part was yours and which was others', "we" for context and "I" for contribution; if your part was smaller than the channel's, say so plainly. Concede that specifically, then return to the sentence | F3 is the figure a pressure interviewer tests for attribution; EXP because it scores precise ownership |
| C3 | "Influenced revenue isn't revenue you were accountable for. Why should that count for us?" | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | Concede first, in your own words: "I've never carried a direct quota, only influenced revenue." Then hold the figure at its scope, "roughly £4M of influenced revenue", and let them weigh it. Answer slot: if you know how it was counted, say how, in your own words; if you do not, say so plainly. Never call it closed, booked or won | F4 and F3 together are the commercial objection; EXP because it tests how you describe your own number |

### D. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say how it was counted, in your own words. Your message gives no method and the pack supplies none; if you do not know how it was counted, say so plainly | F3 is a headline figure, so a defend-the-number question is certain; EXP because it tests how well you know your own claim |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name the assumption in your own words before they do. The pack names none; if you cannot name one, say so plainly and say what you would check in your records | The weakest-assumption move turns a gotcha into credibility (F3) |
| D3 | "How was a partner defined when the channel went from 6 to 40?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: say how a partner was counted and whether the 6 and the 40 were counted the same way, in your own words; if there was no formal definition, say so plainly | F1's two counts are sensitive to definition, so a prober checks them |
| D4 | "What should we measure you on at month six?" | JD | [generic] | Structure: one measure of what operators gain, one commercial measure, one of how the partnerships are going. Say which you would want agreed as direct and which as influenced, since F4 says you have carried only influenced revenue. No past claim is made | Ross's commercial push (F3, F4) arrives as a forward question too; JD because it scores the role's accountability |

### E. Conversational (either)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships"; "last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc from those three sentences only: nine years in partnerships, the last four running the ISV channel at a payments company, and before that five years in transport consulting in bus and light rail network planning. Settle B4's dates first. Leave "from the other side" out unless you can say in one sentence what it means | A friendly opener still scores economy and honesty (F1, F2) |
| E2 | "What are you actually following in rail tech these days?" | CO | [generic] | Answer slot: name what you really follow, in your own words; if nothing yet, say so plainly and say what you would read first. Do not name a trend you have not read | A casual question about the sector is scored, and F5 makes it likely |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months (F1) | A1, A2, A4, B2, section: Graded deliverable |
| Land on what it means for operators (F2) | A3, A4, B1, section: Graded deliverable |
| Ross will push on commercials (F3) | A5, C2, C3, D1, D2, D3, D4 |
| Accountability for a commercial number (F4) | C3, D4 |
| Prior selling into rail (F5) | B1, B2, C1, E2 |
| Other JD requirements | none, and why: no JD was supplied, so none are known |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does operator partnership cover here today, and what do you count as a partnership rather than a customer?" | The POV rests on this scope, and asking shows you took it seriously |
| R2 | "Which operator relationship is the best example of what you want more of, and what made it work?" | Invites a story and shows you start from operators |
| R3 | "Where does this role's number sit against the commercial plan: what is it accountable for, and what does it influence?" | Puts your stated gap (F4) on the table in your own terms; best put to Ross |
| R4 | "What would an operator say today is the hardest part of working with Kelverton?" | Signals the operator-first reading the recruiter asked for |
| R5 | "What would you want me to learn first in the first 90 days, and from whom?" | Turns the rail gap (F5) into a plan; best put to Deepa as the future manager |
| R6 | "If I'd joined six months ago, what would you want to be different by now?" | Gets Deepa's real measure of success in her own words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never sold into rail specifically." No slot |
| Carried a quota or owned revenue directly | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| Generated or closed £4M | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says influenced, not closed or booked |
| Has first-hand knowledge of train operators' own work | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning in consulting, not train operating companies from the inside |
| Built the ISV channel from scratch | Inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40". The pack's observation: the quote implies six partners already existed |

## Sources

Provided: your message, including the recruiter's email as you quoted it. The market report was named but did not reach me, so it was not read.

Searches sent, all refused:

- "Kelverton Rail values": refused
- "Kelverton Rail strategy train operating companies scheduling software": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The one call was refused. It could only have themed VAL questions; no values-style round was detected, so no cheat sheet is included |
| 2. Kelverton Rail interview process, partnerships | skipped | The recruiter's email fixes the loop: one 60-minute panel of two, a 15-minute POV, then Q&A. Persona weights could not change |
| 3. Kelverton Rail strategy / recent news | unavailable | The one call was refused. The CO questions (A4, E2) are [inferred] or [generic] and there is no grounding brief |
| 4. Interviewer public footprint | unavailable | Both calls (Deepa, Ross) were refused. There is no interviewer read, and the reverse questions are role-generic |
| 5. Representative Senior Partnerships Manager JD | unavailable | No call was sent: no JD was supplied and search had just been refused. F4 and F5 stay role-family prose, labelled [generic] |

## Upgrade menu

- The market report, pasted: the CO and CASE questions become [grounded], and the differentiation section gets its consensus item to agree with and diverge from
- The job description: the generic F4 and F5 become quoted requirements, JD-tagged questions become [grounded], and any location, pay or schedule terms can be checked
- Search permission: a first pass over Kelverton's values, strategy and the two interviewers' public footprint (up to 6 searches and 2 fetches), adding an interviewer read and a grounding brief. A deeper pass adds up to 6 more searches and 2 more fetches and takes several more minutes
- Surnames or profile links for Deepa and Ross: persona weights read from their public footprint, and a reverse question tied to each one's own path
- A one-line career timeline: settles the nine years in partnerships against the five in consulting, upgrading B4 and E1
- How the £4M was counted, in your words, ideally the partner-sourced or influenced revenue report from your own records: F3, C2, C3 and D1 to D3 move from answer slots to story-mapped answers
