# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Role:** Product Manager, Platform APIs
- **Company:** Quartzline
- **Round:** a 45-minute conversation with the hiring manager, on Thursday (from your message)
- **Interviewer:** the hiring manager; no name given
- **Built from:** your tuesday-dossier.md (underwriting decision `conditional_go`) and your message. Company research did not run (see Sources), so nothing here states a fact about Quartzline beyond the job description's own lines.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims on your record survive scrutiny, and what was actually yours |
| JD | The stated requirements, including the gaps |
| CO | Company and strategy knowledge (none in this pack: research did not run) |
| CASE | A live problem set in the role, scored on structure and reasoning |

Question IDs run by persona: A, B, C, D, E, G, H. The letter F is skipped because F1 to F6 are fit-snapshot rows. An answer slot is an instruction for what to say in the interview, not a question for you now.

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is your confirmed claims from the dossier's `verified_candidate_evidence`, quoted without the dossier's confidence notes. The dossier carries no evidence map, so confidence and gap type come from the handoff's weak-area list where it gives them, and are this pack's reading where it does not.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's limit stays attached: this is adjacent work, never product management experience. Your first-person words are sourced from the dossier's `prohibited_claims`: "I haven't held a product manager title or role." Then the quoted work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." R1's "3+ years" makes a probe on how many of your years count likely. This pack counts none of them as product management. The roadmap-input sessions are confirmed with limited inspectable proof, so volunteer that limit before it is extracted |
| F2 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | transferability | The quote is integrating the vendor's REST APIs; your material does not show shipping an API product. That is this pack's reading: the dossier does not list R2 among its weak areas, so it is worth checking with the underwriter. Words that stay inside the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: R2 asks for shipped API or platform products, so expect a probe on where integrating an API ends and shipping one begins. If you shipped an API or platform product, say what it was and which part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch REST APIs, architecture and a playbook, and do not show whether any of it was API docs or schemas. Answer slot: R3 names API docs and schemas, so expect a probe on your hands-on contact with them. If you read or wrote API docs or schemas in those integrations, say which and what you did with them, in your own words; if you did not, say so plainly, and say what you would want to confirm about how Quartzline defines the fluency it needs. Words that stay inside the quote: "I wrote the internal integration playbook my team uses." |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes carry client-side work and input to product; they do not name engineering or sales. Words at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product." The sessions are confirmed with limited inspectable proof, so name that limit yourself. Answer slot: R4 names engineering, sales and customers, so expect a probe on the engineering and sales side. If you worked with either in those integrations or sessions, say who and how, in your own words; if you did not, say so plainly and stay with the clients and product the quotes name |
| F5 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | No quote speaks to this requirement, so no bridge is offered; the dossier's strategy for it is `clarify`. Answer slot: R5 names Agile delivery experience, so expect a probe on how you have worked with delivery teams. If you have worked that way, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how the two squads define it |
| F6 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | A gap wording cannot close, and the dossier records it: `acknowledge_gap` for "Owning a roadmap and prioritization authority (R1 sub-claim)", with `prohibited_claims` "Having owned a product roadmap" and "Having set prioritization for an engineering squad". Words, sourced from that area: "I haven't owned a roadmap or had prioritization authority." Then how you would learn it, said as a plan and never as a past: find out which roadmap decisions the role makes alone and which belong to the two squad leads, and how adoption is measured today, both of which the dossier leaves open. No bridge from the roadmap-input sessions: they fed product, and they do not reach ownership |

Proposed language, pending your approval: edit any bridge that is not how you would say it. Nothing here is applied.

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic dominant), are adjusted by the dossier (it names one objection and two open unknowns), and rest on the loop you described: one 45-minute conversation with the hiring manager. No interviewer profile exists, so there are no interviewer-signal adjustments.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems from the role: diagnose adoption, sequence work across two squads, run discovery | High. Hiring-manager prior. The role's responsibilities give the interviewer ready material, and a CASE question needs no history, so it is where a gap in titled experience is easiest to test | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise. Keep answers in the conditional, never in the past tense of owning a roadmap |
| Skeptic (B) | Quiet, persistent probing of the title and roadmap gap, delivery practice, and motive | High. Hiring-manager prior, and the underwriter named the objection (B1), which makes this the pack's highest-ROI rehearsal | Rehearse B1 until it is boring; bridge only from quoted work with the limit named; give a plan for the gap; calibrated candour over bluffing |
| Data-Driven Prober (C) | Reads the record line by line: how 30+ was counted, what the playbook contains, how the sessions ran | Mid. The record carries one headline number and one claim with limited proof, which are the seams a prober pulls | Know what you can and cannot say about how each number was counted; name the weakest assumption first; offer to walk through the playbook |
| Conversational (D) | Friendly openers: the journey, what you are exploring, what you want to know | Mid. A 45-minute conversation opens warmly, and casual questions are still scored | A 90-second arc built from your quoted sentences only; treat casual questions about API docs as scored; never let the closing question slot go generic |
| Pressure (E) | Time-boxed challenge: "why you, in sixty seconds", "how much of that was you" | Low. Nothing in your inputs signals a stress style; it is the Skeptic's objection delivered under time | Pause, restate, hold the quoted claim through two follow-ups, concede specifically, never fold on the core |
| Peer Evaluator (G) | Seam-splitting with the two squad leads: where the PM decides and where they do | Low. A hiring manager is not a peer, but the dossier's open unknown about decision authority makes the seam a likely theme | Propose seam principles rather than pretending to know the seam; reciprocity from the one quoted thing you can point to |
| Values/Behavioral (H) | Scenario probes on stakeholder situations | Low. No values-style round is detected: no loop source names one, and your own words describe one conversation. Banked at two questions so the style is not new live | A selection scaffold that ends in its honest branch; "we" for context, "I" for contribution |

## Question banks

B1 is the underwriter's named objection (`likely_interviewer_objections`) and the highest-ROI prep in this pack: it will be asked in some form, and a rehearsed, non-defensive answer changes the interview.

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Suppose partner API adoption has been flat for two quarters. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify before structuring: how adoption is defined and measured today, and what the baseline is. Then state the objective, segment partners by how far they have got (not started, integrating, live, lapsed), give two or three hypotheses per segment, name the data that would separate them, and name the risks. Think aloud and challenge one premise, such as whether flat adoption is the right signal. The question needs no claim about your past, so the guidance makes none | The role names adoption metrics and the dossier leaves the baseline unresolved, so a diagnosis problem is likely. CASE because it scores structure on the role's own problem |
| A2 | "Two partners ask for conflicting changes to the same endpoint, and both squads are full this quarter. How do you decide what happens?" | CASE | [generic] | Clarify first: what each change is worth to its partner, who is blocked, what breaks if it waits, and who holds the final call when squads are full. State your decision criteria before the decision, then the options (sequence, split, decline one, offer a workaround), the trade-off you would accept, and how you would tell each partner. Stay in the conditional: this is how you would decide, not a story of having decided. The dossier lists roadmap ownership as an `acknowledge_gap` area, so no past-tense claim belongs here | F6 is the gap this scenario sits on, so it tests roadmap judgement without needing roadmap history. CASE because it is a live decision problem |
| A3 | "A partner-facing change needs both squads to ship. How do you write the spec and keep delivery aligned across them?" | CASE | [generic] | Ask which squad owns which interface and how each plans its work. Then outline the spec you would write: partner problem and evidence, scope and non-scope, acceptance, rollout and deprecation, documentation. For alignment, propose principles for the seam rather than claiming to know it: one source of truth, a named decider per kind of decision, a cadence with both leads. Challenge one premise, such as whether one spec should span both squads | The role names specs and delivery with two squads. CASE because it asks for a method; a follow-up on delivery practice (F5) may come after it |
| A4 | "Define adoption metrics for a partner API platform. What do you track, and what do you refuse to track?" | CASE | [generic] | Start from the decision each metric would drive. Sketch a funnel from sign-up to first successful call to production traffic to sustained use, separate leading from lagging measures, and segment by partner type. Name the vanity measures you would refuse and why. Ask what baseline exists today and say you would want it before setting targets. Challenge one premise, such as counting partners against counting traffic | The role names defining and tracking adoption metrics, and the baseline is an open risk in the dossier. CASE because it scores reasoning, not history |
| A5 | "It is your first month. How do you run discovery with integration partners?" | CASE | [generic] | Objective first: what decision the discovery must inform. Then who you would talk to (partners at different stages, plus the squad leads for what is feasible), what you would ask, how you would record it, and how findings would reach whoever decides the roadmap. Say it as a plan. Closing beat: how you would know discovery is working. The question needs no claim about your past, so the guidance makes none | The role names discovery with integration partners; F4 is the nearest evidence, so expect the interviewer to compare your plan against it. CASE because it asks for a method |

Proposed language, pending your approval: guidance is scaffolding; use only what is true of you.

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier fields `likely_interviewer_objections`, `prohibited_claims`, `acknowledge_gap` | The underwriter's objection, asked as written: both negatives in it are sourced by `prohibited_claims` and `acknowledge_gap`. Deepest rehearsal. One, concede first and plainly: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Two, name the limit before it is asked: what you offer is adjacent work, never product management experience. Three, only the quoted work, at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." "I wrote the internal integration playbook my team uses." "I ran quarterly roadmap-input sessions feeding client evidence to product", then say yourself that this one is confirmed with limited proof. Describe the work and stop; do not tell them what it proves. Four, close with a plan, not a past: map decision rights with the two squad leads, get the adoption baseline, start discovery with partners. Follow-up one, on the three years: hold by returning to the quotes, and concede that you are not offering three years of the job. Follow-up two, on why you over a titled PM: say what you did and let them weigh it. Never claim a title, a roadmap, or prioritization for a squad (section 13) | The dossier names this as the objection this candidate meets, built on F1 and F6. JD because it scores the stated requirement; Skeptic because it probes the biggest gap |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] dossier `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)"; dossier role_profile R5 "Agile delivery experience" | Give the honest answer the dossier already established. Words, sourced from the `acknowledge_gap` area: "I haven't owned a roadmap or had prioritization authority." Then the plan, as a plan: find out which decisions the role makes alone and which belong to the two squad leads, and how adoption is measured today. Do not offer a second weakness you cannot back. Answer slot: if pressed for another, R5 names Agile delivery experience; if you have worked that way, say how, in your own words; if you never worked that way, say so plainly | Persona stem for the Skeptic, and the question that pulls F6 and F5 into the open. JD because it scores the listed job including its gaps |
| B3 | "The role asks for shipped API or platform products. You led 30+ client integrations of the vendor's REST APIs — where does integrating an API end and shipping one begin?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says and nothing past it: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's observation, not words for you: your material shows integrating, not shipping an API product. Answer slot: R2 names shipped API or platform products. If you shipped one, say what it was and which part was yours, in your own words; if you did not, or it was not yours, say so plainly and return to the integrations you led. Do not draw the line in a way that makes integrating sound like shipping | F2 is a must-have requirement with adjacent evidence only, so this probe is likely. JD because it scores that requirement directly |
| B4 | "How have you worked in Agile delivery, and does it match how our squads work?" | JD | [grounded] dossier role_profile R5 "Agile delivery experience" | No quote speaks to this requirement, so nothing about your past goes into the answer. Answer slot: R5 names Agile delivery experience, so expect a probe on how you have worked with delivery teams. If you have worked that way, say how, in your own words; if you never worked that way, say so plainly. Either way, ask how the two squads run delivery and say what you would want to confirm about how Quartzline defines it | The dossier marks this area `clarify`, so the guidance stays question-shaped. JD because the requirement is stated, preferred rather than must-have |
| B5 | "You've led client integrations of the vendor's REST APIs. Why move toward product, and why here?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reason is yours, so this pack supplies none: give your actual reason in your own words, in two sentences. If you point to what you have done that sits nearest to product work, it is this and no further: "I ran quarterly roadmap-input sessions feeding client evidence to product", confirmed with limited proof, so say so. For "why here", say only what you have actually read about Quartzline; the pack could not research the company | Motivation consistency is the Skeptic's standard probe (why leave, why here, why now). EXP because it tests whether the story survives cross-examination, with F1 as the background |

Proposed language, pending your approval: quoted sentences are yours; everything else is for you to fill in honestly.

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name the figure as the quote has it: 30+ end-to-end client integrations. Then four answers, each in your own words: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least; which parts were yours. Say the weakest assumption before the interviewer does. If you do not know how it was counted, say so plainly. Never describe a counting method you did not use | The one headline figure on the record gets a defend-the-number question; F1 and F2 both lean on it. EXP because it tests attribution and honesty about method |
| C2 | "Walk me through the internal integration playbook you wrote: what is in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say what the quote says: "I wrote the internal integration playbook my team uses." The playbook is inspectable, so offer to walk through it and bring it if you can. Answer slot: R3 names API docs and schemas, so expect a probe on whether the playbook covers either. If it does, say how, in your own words; if it does not, say so plainly and stay with what the playbook is | The playbook is the inspectable artifact in F3 and F1, so a prober will go to it first. EXP because it tests what you actually wrote |
| C3 | "Walk me through how you ran the quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what the quote says: "I ran quarterly roadmap-input sessions feeding client evidence to product." It is confirmed with limited inspectable proof, so volunteer that before it is extracted: say what you can show and what you cannot. Answer slot: R4 names engineering, sales and customers, so expect a probe on who was in the room. Say who attended, in your own words; if the sessions were with clients and product only, or you do not know beyond that, say so plainly. Never describe the sessions as setting the roadmap (`prohibited_claims`: "Having owned a product roadmap") | F4 and F1 both rest on this medium-confidence claim, so it is the seam a prober will find. EXP because it tests what the sessions were and what was yours |

Proposed language, pending your approval: quoted sentences are yours; the slots are for you to fill honestly or decline.

### D. Conversational (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each a quoted sentence at its own scope: the integrations you led; the playbook you wrote; the roadmap-input sessions you ran, with their limited-proof caveat said in one clause. Close with your own reason for this role, in your own words; the pack supplies none. No title, no dates, no years beyond what you can state yourself | A warm opener that is scored. EXP because it sets the story every later probe tests, built from F1 |
| D2 | "When have you worked directly with API docs or schemas, and what was the most recent time?" | JD | [generic] | Selection scaffold: pick one instance where you read or wrote API docs or schemas; it needs the API it concerned, what the document or schema was for, and what you did with it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | R3 names API docs and schemas, and a rapport-style question about it is still scored. JD because it tests the listed technical-fluency requirement; the scaffold is used because no quoted sentence carries it (F3) |
| D3 | "What would you want to know about this role that the job description doesn't tell you?" | JD | [grounded] dossier role_profile `unknowns`: "Decision authority versus the two squad leads", "How adoption is measured today" | Ask the two things the dossier left open, as questions and never as claims about Quartzline: which roadmap decisions this PM makes alone and which belong to the squad leads, and how adoption is measured today. Add the reason you are asking, in your own words. Do not tell them what the answer probably is | The unknowns are the underwriter's analysis, so they enter as questions. JD because it scores whether you understand what the listed job leaves undefined |

Proposed language, pending your approval: use only what is true of you.

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Pause and restate the question. Concede first: you are not offering three years in the seat (`prohibited_claims`: no title, no roadmap). Then two sentences of quoted work and stop: "I led 30+ end-to-end client integrations of the vendor's REST APIs." "I wrote the internal integration playbook my team uses." Hold through two follow-ups by returning to those quotes, never by adding to them. Concede specifically what you do not have; do not fold on what you did | B1 under time pressure, so the same limit applies. JD because it scores R1 |
| E2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote: the verb is led and the noun is integrations. Answer slot: say which parts were yours, in your own words, as in C1's four answers; if some parts were not yours, say so plainly and say whose. Hold through two follow-ups. Concede something specific if it is true, such as not knowing how it was counted, and never concede the core of what the quote says | Persona stem for attribution under pressure. EXP because it is the attribution check on F1 and F2 |

Proposed language, pending your approval: the slot is yours to answer or decline.

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where is the seam between the PM and the two squad leads, and what happens when we disagree?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Do not pretend to know the seam: the dossier lists decision authority against the two squad leads as unknown. Propose principles instead: a named decider per kind of decision, disagreements settled on partner evidence, the PM's remit stated up front. Then ask which decisions the PM makes alone (reverse question 1). For reciprocity, the one quoted thing you can point to is "I ran quarterly roadmap-input sessions feeding client evidence to product", confirmed with limited proof, so say so. Do not describe it as setting priorities for a squad (`prohibited_claims`: "Having set prioritization for an engineering squad") | The dossier's open risk about squad authority makes the seam a likely theme. JD because it scores the listed job's delivery with two squads; F6 is the row it presses on |
| G2 | "Tell me about a time you disagreed with engineering or sales about scope, and how it ended." | JD | [generic] | Selection scaffold: pick a time with a named disagreement, a stake, your own position, and how you worked it through with the other function. It needs your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | R4 names engineering and sales, and no quoted sentence carries that side (F4). JD because it scores the stated stakeholder requirement |

Proposed language, pending your approval: use only what is true of you.

### H. Values/Behavioral (weight: low)

No company values were researched, and no values-style round is detected, so these are generic prompts on R4's theme, not mapped to published values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to a client." | VAL | [generic] | Selection scaffold: pick a time where the truth was unwelcome, you said it anyway, and the relationship was intact at the end; it needs a named stake and your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Values interviewer, and R4 names customers. VAL because it scores behaviour, not a requirement; no published value was available to map it to |
| H2 | "When did you put a partner's need ahead of an internal deadline?" | VAL | [generic] | Selection scaffold: pick a decision where the partner's need and the internal date pulled apart, you chose, and you can say what it cost. It needs your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Values interviewer, themed on R4's customers. VAL for the same reason as H1 |

Proposed language, pending your approval: use only what is true of you.

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | B1, B2, E1, D1 |
| R2 "Shipped API or platform products" | B3 |
| R3 "Technical fluency: API docs, schemas" | C2, D2 |
| R4 "Stakeholder management across engineering, sales, customers" | C3, G2, H1, H2 |
| R5 "Agile delivery experience" | B4 |
| Responsibility "Own the roadmap for the partner-facing API platform" | A2, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk is that squad authority is asserted in the job description and not evidenced. The answer tells you what you would actually own, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no stated baseline, so the answer tells you what you would be judged against |
| 3 | "When a squad lead and the PM disagree on sequencing, how does that get resolved?" | It tests the same authority risk from the disagreement side, and it is the question G1 sets up |
| 4 | "What would a strong first 90 days look like for someone whose background is integration work rather than a PM seat?" | It turns the B1 objection into a ramp conversation on your terms, and your answer is the plan you have already rehearsed |
| 5 | "How does discovery with integration partners run today: who does it, and how often?" | The role names discovery with partners, and the answer shows whether you would inherit a cadence or build one |
| 6 | "What would you expect a new PM to have shipped by the end of the second quarter?" | It makes the expectation concrete and shows whether the role is measured on delivery, adoption or both |

## Prohibited claims

Built before the question banks, which are written against them. The first three come from the dossier's `prohibited_claims`; the rest are built here as inflated forms of your quoted sentences.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | `prohibited_claims` | The quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Plain acknowledgment, sourced from that field: "I haven't held a product manager title or role." |
| "Having owned a product roadmap" | `prohibited_claims` | "I ran quarterly roadmap-input sessions feeding client evidence to product", at its own scope and with its limited-proof caveat. Plain acknowledgment, sourced from that field: "I haven't owned a product roadmap." |
| "Having set prioritization for an engineering squad" | `prohibited_claims` | The same quote at its own scope. Plain acknowledgment, sourced from that field: "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says integrations of the vendor's REST APIs, not shipping an API product. B3's slot stays inside the integrations |
| Wrote API docs or schemas | Inflated form of F3 | F3's quote about the playbook at its own scope. The material says the playbook, not API docs or schemas. C2's and D2's slots ask only what the playbook covers |
| Managed engineering and sales stakeholders | Inflated form of F4 | F4's quotes at their own scope: clients and product. The material does not name engineering or sales. C3's and G2's slots stay inside what the quotes carry |

## Sources

Provided documents: your tuesday-dossier.md (version 1.1, generated 2026-08-14) and your message. A dossier was consumed. It supplied `role_profile` (the job description's requirements and responsibilities, and the unknowns), `handoff_to_mock_interview` (verified evidence, weak areas with their allowed strategies, the objection, risks, employer questions and prohibited claims) and `decision` (context only). It carried no `evidence_map`, `evidence_state`, `risk_register` or `candidate_constraints`, so grading comes from the handoff alone.

Searches sent, all refused (permission to search was not granted): "Quartzline company values principles"; "Quartzline interview process product manager"; "Quartzline strategy partner API platform news". Nothing came back, and nothing from outside your documents is used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have given official value names for a values cheat sheet. Section 10 is dropped; no values-style round is detected either, so H1 and H2 are generic |
| 2. `Quartzline interview process product manager` | unavailable | Would have named the loop's rounds. Persona weights rest on your own description of one hiring-manager conversation and the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | Would have grounded a CO question and a strategy-based CASE question. The CASE bank is generic and there is no CO question |
| 4. `interviewer name Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search, or a pasted Quartzline values page and strategy brief → official value names, a strategy-grounded CASE question and CO questions in place of generic ones, and the loop's real rounds. A deeper research pass would add a strategy brief and interviewer footprint (up to 6 more searches and 2 more fetches, several more minutes)
- The hiring manager's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email, if one exists → stated focus areas, and any pre-declared deliverable gets its own build section
- An agenda or notes from one roadmap-input session → F1 and F4 move from medium toward high, and C3's limited-proof caveat shrinks
- Your answers to the slots in F2, F3, F4 and F5, outside a drill → those rows become quoted evidence and their guidance becomes story-mapped
- The raw CV behind your confirmed claims → more rows to quote, and a check on whether anything the dossier dropped belongs here
