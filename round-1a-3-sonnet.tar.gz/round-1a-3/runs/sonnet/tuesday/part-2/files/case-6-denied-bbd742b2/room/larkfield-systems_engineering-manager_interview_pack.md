# Interview prep pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Role: Engineering Manager at Larkfield Systems, industrial IoT, about 600 people. Rounds as you described them: Round 1, Tuesday, 45 minutes, the Director of Engineering who would be your manager. Round 2, the Thursday after, 60 minutes, a panel of two staff engineers and a product manager. Round 3, the following Monday, 30 minutes, the VP Engineering, described by the recruiter as "values and leadership philosophy". No interviewer names were given.

Built on: your message only. No CV, no full job description, and no web research (the searches were refused, see Sources). Everything about your past below is one of your own sentences, quoted.

## 1. How to use this pack, and the type key

Personas are how a question arrives; types are what it scores. Guidance is scaffolding to rehearse from, not a script: where it says answer slot, the words are yours, and "I was not the one who did that" or "that step did not exist" is always an honest answer.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether a claim about your work survives scrutiny |
| JD | A stated responsibility in the role description |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | A live problem set in the role |

Highest-ROI prep in the whole pack: A2, the hardware-roadmap objection. It will arrive in some form in all three rounds, and it is the row where the role description meets a gap you named yourself.

## 2. Prep triage

| When | Do these, in order | Tied to |
|---|---|---|
| Before Tuesday | A2 aloud until it is boring, then A1 and A5, then C1 (the 60% figure), then your 90-second arc D1 | Round 1 bank, F7, F1, F2 |
| Between Tuesday and Thursday | F1 and F2 (the 40 interviews and the hiring loop), E1 (seam with staff engineers), G2 (product disagreement), then re-run A2 in a collegial register | Round 2 bank, F3, F7 |
| Between Thursday and Monday | I1 (your leadership philosophy, in your own words), I2, J1, K1 | Round 3 bank, F7 |

Everything else is insurance. After each round, what the interviewer actually probed is the best input for the next round's weights.

## 3. Fit snapshot (shared across the three rounds)

Requirements are quoted from the role description in your message. Evidence is your own words, quoted. No row is a gate: the role description names no term such as location, pay, schedule or a credential.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, not two squads, and the words stay there: "For 3 years I was a team lead of 6." Answer slot: the two-squads line makes a probe on leading more than one team likely. If you have led more than one team at once, say how, in your own words; if not, or it was not yours, say so plainly and stay with the team of 6 |
| F2 | "own delivery" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Adjacent work: a quarter pushed through against roadmap pressure, and a 60% drop after it. Your sentence says the burden dropped after the push; it does not say the push alone caused the drop, and the words stay at that scope. Nothing inspected sits behind the figure, so expect a probe on how it was counted |
| F3 | "hiring" — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap on the requirement's face, but a line with nothing inspected behind it. Lead with the loop in the quote's own terms: you run it, for backend roles. The pack's observation: the sentence does not say who decided offers, or whether the 40 were interviews you conducted or interviews the loop held, so it is carried at the lower reading, "about 40 interviews last year" |
| F4 | "growth" — role description in your message | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: the growth line makes a probe on developing engineers likely. If you have helped anyone on your team grow, say what and what part was yours, in your own words; if there was no such step, or it was not yours, say so plainly |
| F5 | "for 11 engineers" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | The scale in your sentence is 6, not 11, and the words stay there. How the 11 are organized, and whether leads sit between you and them, is not in the role description; the reverse question R1-3 asks it |
| F6 | "building device-management services" — role description in your message | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: the line makes a probe on your domain background likely. If any work of yours touched managing fleets of devices, say what, in your own words; if none did, say so plainly and say what you would ask first |
| F7 | "partner with hardware and product on roadmap" — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Derived from your stated absence of owning a hardware-adjacent roadmap; partnering is not owning, and your material does not show whether you have partnered. Words you can say: "I've never owned a hardware-adjacent roadmap." Answer slot: the role line makes a probe on working with hardware and product likely. If you have worked with a hardware or product team on a roadmap in any capacity, say what and what part was yours; if not, or it was not yours, say so plainly |

The role description as you gave it does not list managing managers. Your stated absence of that experience is in the prohibited list below and is rehearsed at K1.

## 4. Prohibited claims (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or managed 11 engineers | Inflated form of F1 and F5 | The quote at its own scope: "3 as a team lead of 6". The pack's observation: your material says a team of 6 |
| Managed managers | Negative you stated, in the F7 evidence | The plain acknowledgment from your own sentence: "I've never managed managers". No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F7 | The plain acknowledgment from your own sentence: "never owned a hardware-adjacent roadmap". A2's slot stays inside working alongside hardware, never owning |
| Cut the on-call burden by 60% | Inflated form of F2 | The quote at its own scope: the burden "dropped 60% after I pushed a reliability quarter through". The limit is the pack's observation: the sentence says after, not that the push alone caused it |
| Designed or owned the hiring process, or decided who was hired | Inflated form of F3 | "I run our hiring loop for backend roles". The pack's observation: the sentence says running the loop, not designing it or deciding offers |

Requirements no quote speaks to (growth, device-management, partnering with hardware and product) are answer slots, not listed claims.

## 5. Requirement coverage (all three rounds)

| Requirement | Question IDs |
|---|---|
| "Lead two squads" (F1) | A5, B1, J2 |
| "own delivery" (F2) | B1, B3, F3, C1, C2 |
| "hiring" (F3) | F2, F1 |
| "growth" (F4) | I3 |
| "for 11 engineers" (F5) | A5, J2 |
| "building device-management services" (F6) | F4, B1 |
| "partner with hardware and product on roadmap" (F7) | A1, A2, A3, B2, E1, G2, H1 |
| Headline figure, the 60% | C1, C2 |
| Headline figure, about 40 interviews | F1 |
| Company values by name | none, and why: no published values page was in hand (searches refused) |
| Company strategy (CO) | none, and why: strategy research was refused, so no question is grounded in Larkfield's strategy |

# ROUND 1 — Tuesday, 45 min, Director of Engineering (would-be manager)

Loop source: your own account of the round. Persona weights below rest on that and on the hiring-manager prior, not on any documented Larkfield process.

## 6. Persona weights, Round 1

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | high | A hiring manager is buying capability and derisking gaps, and the gaps in your own message (F7, F1, F5) are the obvious targets | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing a competency the interviewer owns |
| Case / Strategist | high | A hiring manager tends to set live problems on the actual roadmap, and this role's roadmap line is the one the Director owns | Clarify, then objective, then segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | medium | The 60% figure is a headline number (F2) and gets probed to its assumptions | Know how it was counted and say plainly if you do not; name the weakest assumption you know of before they do |
| Conversational | low | 45 minutes, and the opener will be casual and still scored | A 90-second arc, built only from your own sentences |
| Pressure, Values, Peer | low | No bank this round; they appear in Rounds 2 and 3 | — |

## 7. Question banks, Round 1

### A — Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Name the roadmap-partnering line, because it is where your own sentence leaves the role open: say that you have never owned a hardware-adjacent roadmap, in your own words. The role description as you gave it does not list managing managers, so lead with the roadmap row; if the Director raises managers, use K1's words. Then give a ramp plan as a plan, never as a past: what you would ask the hardware lead for in your first weeks. Answer slot: if you have worked alongside a hardware or product team in any capacity, say what and what part was yours; if not, or it was not yours, say so plainly | F7 is the biggest open row against this role's roadmap line, and a hiring manager's first move is to ask where the risk sits; JD because it scores the stated requirement | 
| A2 | "You've never owned a hardware-adjacent roadmap. What makes you think you can partner with the people who do?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in this pack. Name the limit before it is asked for, in your own words: "I've never owned a hardware-adjacent roadmap." Follow-up one, what do you bring: say what your sentence carries, at its scope, "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure", and let the interviewer draw the inference; do not say what it proves. Follow-up two, have you worked with hardware at all. Answer slot: if you have, in any capacity, say what and what part was yours; if you have not, or it was not yours, say so plainly and return to the sentence above. Follow-up three, what would you do in the first month: a plan, claiming nothing. Hold by returning to what your sentences carry, never by adding to them; concede the limit exactly, once | F7 is where the role's roadmap line presses on a stated absence, so this objection arrives in some form; JD because it scores the stated requirement, and the depth follows from it being the pack's top objection | 
| A3 | "Tell me about a time you worked with a team outside engineering on a roadmap." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | An open prompt, so choose the instance. Selection criteria: a named stake, what you asked of the other team, and what the relationship looked like afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The nearest sentence you have is the one quoted here; it says roadmap pressure, and does not say another team was involved, so use it only at that scope | F7's role line raises the theme; JD because it tests the stated requirement through a past instance | 
| A4 | "Why this role, and why now?" | EXP | [generic] | Give your actual reason in your own words. This pack supplies none: your material gives no reason, and a reason written for you is one you cannot hold under a second question. Keep it to what draws you to the role as described, and keep it consistent with what you say in Rounds 2 and 3 | A Skeptic scores motivation consistency, and the reason for moving is a standard probe; EXP because it tests the story behind the move | 
| A5 | "You've been a team lead of 6. This role is two squads and 11 engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from your sentence at its own scope: "For 3 years I was a team lead of 6." Then say what you would do differently as a plan, as a plan and never as a past. Answer slot: the two-squads and 11-engineers lines make a probe on running more than one team likely. If you have led more than one team at once, say how, in your own words; if not, or it was not yours, say so plainly and stay with the team of 6 | F1 and F5 are the scale and structure gaps the role names; JD because it scores the stated lines | 

### B — Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You take over two squads building device-management services, and one is consistently behind. What do you want to know first?" | CASE | [generic] | Clarify first: what behind means and against what commitment, what changed, who depends on the squad. Then objective, segmentation (people, scope, dependencies), approach, metrics, risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem set on the role's own two-squads and delivery lines (F1, F2, F6); CASE because it scores structure rather than a right answer; generic because it is a pattern for the problem, not a fact about Larkfield | 
| B2 | "Hardware changes how devices check in, two weeks before your squad's release. What do you do?" | CASE | [generic] | Clarify what changed and for which devices, then the release's commitments and who holds them, then options (hold, scope down, ship behind a flag), then the conversation you would have with hardware and with product. The guidance makes no claim about your past. Do not pretend to know how Larkfield's release process works; ask | A hypothetical on F7's hardware seam, set so you can show structure without owning a hardware roadmap; generic, because Larkfield's own release process was not established | 
| B3 | "Product wants a feature this quarter, and your engineers want to pay down reliability work. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure the decision: what each choice costs and who bears it, what evidence would settle it, what you would say to each side. Where it helps, point to your sentence at its own scope, "I pushed a reliability quarter through against roadmap pressure", and stop there. Who applied the pressure, and what you said, are not in your material and are yours to say or leave out | The decision sits on F2's delivery line and F7's product line; CASE because it asks for a decision rather than a record | 

### C — Data-Driven Prober (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 60% drop in on-call burden was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number, in your own words, with four slots. Answer slot: how it was counted; if you know, say it, and if you do not, say so plainly. Answer slot: what it is sensitive to. Answer slot: the assumption behind it you would defend least, named before the interviewer names it. Answer slot: which part was yours; if anything else contributed, say what, and if nothing else did, say so. Your sentence says the burden dropped after the push; keep it there | F2's headline figure is the one a prober tests first; EXP because it scores attribution honesty | 
| C2 | "That quarter went against roadmap pressure. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold your sentence through two follow-ups: "I pushed a reliability quarter through." Answer slot: which part of the quarter was yours, in your own words; if the push was shared, or someone else led it, say so plainly. Concede any specific uncertainty explicitly, and never fold on what the sentence states just to restore harmony | F2 again, in the attribution probe the Pressure and Prober personas both use; EXP because it scores what was actually the candidate's | 

### D — Conversational (1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the beats your sentence states: 9 years in engineering, 3 of them as a team lead of 6, now at a payments company. End with why this role, in your own words (A4). Nothing else is supplied, so nothing else goes in | A casual opener that is still scored, and the arc is the one answer worth pre-scripting; F1's quote carries all the beats | 

## 8. Reverse questions, Round 1

| # | Ask | Why it lands |
|---|---|---|
| R1-1 | "What does good look like for the two squads at the end of my first six months?" | Gives you the scoring sheet for the role and something concrete to rehearse against |
| R1-2 | "How do the squads and hardware agree the roadmap today, and where does it strain?" | F7 is your biggest open row; asking invites the Director to teach you the seam, which reads as learning, not hiding |
| R1-3 | "How are the 11 engineers organized across the squads, and who leads day to day?" | Resolves the scale and structure behind F1 and F5, including whether leads sit between you and the engineers |
| R1-4 | "What is the hardest conversation you expect me to have in my first quarter?" | Surfaces the real risk and gives you a chance to address it |
| R1-5 | "Is there anything about my background you would want me to address now?" | Hands the interviewer the objection live, which converts A2 from an ambush into a conversation |

# ROUND 2 — Thursday after, 60 min, panel: two staff engineers and a product manager

Assumption, said plainly: panel names were not given, so personas are blended per role. The staff engineers are treated as peers and technical evaluators, and the product manager as a cross-functional interviewer. Weights rest on that blend, not on a documented process.

## 9. Persona weights, Round 2

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | high | Two of three panelists are staff engineers, who price what this hire costs and contributes to their work | Reciprocity framing; propose seam principles rather than pretending to know the seam; spine and tact together |
| Data-Driven Prober | high | Staff engineers verify depth, and the 40 interviews and the hiring loop are figures and claims to test (F3) | Say what you know about how a number was counted, and say plainly where you do not |
| Values / Behavioral | medium | The product manager is outside the function; cross-functional rounds tend to be behavioral | Where your own sentence carries a story, map it at its scope; where none does, a selection scaffold with the honest branch |
| Case / Strategist | low | One live problem from the product side on the roadmap line (F7) | Clarify first, then structure |
| Conversational, Skeptic, Pressure | low | No bank: rapport arrives in the opening minutes and A-bank objections return collegially in the Peer bank | — |

## 10. Question banks, Round 2

### E — Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does a manager's call end and a staff engineer's begin on a technical decision, and what do we do when we disagree?" | JD | [generic] | Propose principles rather than claim to know Larkfield's seam: who owns the outcome, who owns the technical call, how a disagreement is escalated and when it is not. Ask the panel how it works today, and say what you would want from them as well as what you would bring. The guidance makes no claim about your past | Peers test turf awareness and disagreement style; JD because the role's delivery line (F2) and roadmap line (F7) sit on this seam; generic because Larkfield's seam was not established | 
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Principles in your own words: name the contribution of others specifically, share credit for what was shared, and claim only your own. Your material has no sentence about credit, so the pack supplies no past; if you want an example, it has to be one you can stand behind from your own memory | A persona stem on collegial attribution; VAL because it scores behavior, and generic because nothing in the material speaks to it | 
| E3 | "What would you need from the staff engineers in your first month?" | JD | [generic] | Reciprocity framing: what you would ask of them and what you would offer in return. Ask what they would tell a new manager to learn first. The guidance makes no claim about your past | The peer stem on partnership fit; JD because the role description puts delivery on the manager while the staff engineers carry the technical call (F2) | 
| E4 | "A staff engineer thinks your squad's technical plan is wrong and you disagree. Walk me through it." | CASE | [generic] | Clarify what the disagreement is actually about, restate their position fairly, say what evidence would change your mind, name who decides and by what rule, and what you would record afterwards. A live problem that presupposes nothing about your past | A collegial form of the pressure objection; generic because it asks for a method | 

### F — Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "About 40 interviews last year. How was that counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Defend-the-number, your own words, at the lower reading. Answer slot: how it was counted, including whether the 40 were interviews you conducted or interviews the loop held; if you know, say it, and if you do not, say so plainly. Answer slot: what it is sensitive to. Answer slot: the assumption behind it you would defend least. Answer slot: which part was yours | F3's headline figure is a prober's target; EXP because it scores attribution | 
| F2 | "This role owns hiring for its squads. How do you run a hiring loop?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Lead with the sentence's own terms: "I run our hiring loop for backend roles." Answer slot: the role's hiring line makes a probe on how hires are decided likely. If you decided or recommended hires, say which and how, in your own words; if the decision was not yours, say so plainly and stay with the loop you run. Nothing here describes how your loop works, because your material does not | F3 is where your evidence reaches the role most directly, so it gets the most precise rehearsal; JD because it scores the stated hiring line | 
| F3 | "How do you know a squad's delivery is on track?" | JD | [generic] | Name what you would watch and why, in a short structure: commitments and dates, leading signals, who tells you early, and what you do when it slips. The guidance makes no claim about your past; if you use an example, it comes from your own sentences, at their scope | The role's delivery line (F2) tested as a method; generic because Larkfield's own measures were not established | 
| F4 | "Device-management services are a specific domain. What would you need to learn first?" | JD | [generic] | Answer slot: if any of your work touched managing fleets of devices, say what, in your own words; if none did, say so plainly. Then the plan, as a plan: what you would ask these staff engineers to explain first, and what you would read. Do not pretend to know the domain | F6 is an open row that staff engineers will test directly; JD because it scores the stated services line | 

### G — Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | An open prompt, so choose the instance. Selection criteria: a named customer impact, the internal metric you did not serve, what it cost you, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no instance | A persona stem for a cross-functional interviewer; VAL because it scores behavior; generic because your material carries no sentence about customers | 
| G2 | "Tell me about a time you and product disagreed about the roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | An open prompt, with the role's product line as its source. The nearest sentence you have is the one quoted here: it says roadmap pressure and does not say it was product, so use it only if it is yours to say, and then only at its scope. Otherwise, selection criteria: a named disagreement, what each side wanted, what you did, how it resolved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7's product line raises the theme; VAL because it scores behavior under a roadmap conflict | 

### H — Case / Strategist (1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Product wants to ship a feature that depends on a hardware change nobody has scheduled. How do you proceed?" | CASE | [generic] | Clarify what the feature needs from hardware and how firm the need is, then the options (descope, stage, ask for a schedule, ship around it), what you would take to hardware and to product, and what you would commit to in the meantime. A live problem that presupposes nothing about your past | F7's product and hardware lines in one problem; generic because it is a pattern, not a fact about Larkfield | 

## 11. Reverse questions, Round 2

| # | Ask | Why it lands |
|---|---|---|
| R2-1 | "How do technical decisions get settled between a manager and the staff engineers here?" | Shows you respect the seam in E1 and want the real answer |
| R2-2 | "What could a new manager do in their first month that would genuinely help your work?" | The reciprocity question for peers; it signals you are thinking about their load |
| R2-3 | "How does product input reach the squads today, and where does hardware fit in?" | Gets the product manager to describe the F7 seam in their own words |
| R2-4 | "Which parts of the device-management services are hardest to operate?" | Invites the staff engineers to teach you the domain, which answers F6 honestly |
| R2-5 | "What has helped the squads deliver reliably, and what gets in the way?" | Learns the real constraints on F2 before you own them |

# ROUND 3 — Monday after, 30 min, VP Engineering ("values and leadership philosophy")

Loop source: the recruiter's description, as you relayed it. It names a round that assesses values, which counts as a values-style round. Persona weights follow the recruiter's description over the executive prior, which would otherwise tilt toward Case and Pressure.

## 12. Persona weights, Round 3

| Persona | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | high | The recruiter named values and leadership philosophy | Where your own sentence carries a story, map it at its scope; where none does, a selection scaffold with the honest branch; we for context and I for contribution |
| Pressure | medium | A skip-level interviewer tends to time-box and test composure, and 30 minutes is short | Pause, restate, hold through two follow-ups, concede specifically |
| Skeptic | medium | A VP will see the stated absences (managing managers, hardware roadmap) in the same breath as the leadership question | Rehearse the single most predictable objection until boring |
| Conversational | low | A 30-minute round leaves room for one opener | The arc from D1 |
| Case / Strategist | low | The round is described as values, so no bank; if the VP turns strategic, use the Round 1 method from B1 | — |

## 13. Question banks, Round 3

### I — Values / Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The philosophy has to be yours, in your own words, because nothing in your material states one and the pack supplies none. Answer slot: say what you believe about leading engineers; then, if an example is wanted, use only your sentences at their scope, a team lead of 6 and a reliability quarter pushed through against roadmap pressure. Do not say what they prove | The recruiter named leadership philosophy, which is the round's raising source; VAL because it scores values rather than competence; F1 and F2 carry the only sentences available | 
| I2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | An open prompt from a persona stem. Your sentence is the nearest thing you have; it says roadmap pressure and does not say who applied it or that anything unpopular was said, so use it only if those facts are yours, at its scope. Otherwise, selection criteria: a named stake, a moment you did not fold, an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 carries the one sentence near this theme; VAL because it scores whether the hard truth landed, not generic virtue | 
| I3 | "How do you help an engineer grow?" | JD | [generic] | Answer slot: the role's growth line makes a probe on developing people likely. If you have helped anyone on your team grow, say what and what part was yours, in your own words; if there was no such step, or it was not yours, say so plainly. Then the method you would use, as a plan, never as a past | F4 has no evidence, so this is where the honest branch matters most; JD because it scores the stated growth line | 
| I4 | "Tell me about a time you changed your mind about how to lead." | VAL | [generic] | An open prompt with the recruiter's theme as its source. Selection criteria: what you believed, what changed it, what you did differently, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no instance | Leadership philosophy is the recruiter's own phrase; generic because your material has no sentence about it | 

### J — Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you over a candidate who has already managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "I run our hiring loop for backend roles — about 40 interviews last year" | Pause, restate, then concede first, in your own words: "I've never managed managers." Then say what you have, at its scope: "I run our hiring loop for backend roles." Describe what you did and let the interviewer draw the inference; do not say what it proves. Hold through two follow-ups; the position you hold is only what the sentences carry, so do not stretch to answer pressure | The pressure stem tests composure on the stated gap in F7's evidence; JD because it scores fit to the role, and F3's sentence is the one that reaches it | 
| J2 | "You would lead 11 engineers, and you have led a team of 6. Defend that." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pause, restate. Hold the sentence: "For 3 years I was a team lead of 6." Concede the gap in scale plainly rather than defend it. Answer slot: if you have led more than one team at once, say how; if not, or it was not yours, say so plainly. Then your plan, as a plan | F1 and F5 together in a pressure register; JD because it scores the role's own scale | 

### K — Skeptic (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "You have never managed managers. Does that matter for this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | State the plain acknowledgment in your own words: "I've never managed managers." The role as you described it does not list leading other leads, so ask what the structure is rather than assume it, then give your plan as a plan. Nothing in your material says more about it, and the pack supplies nothing else | The stated absence is on the record in F7's evidence, and a VP will test it against the role's structure; JD because it checks the role's scope | 
| K2 | "What would you want to have changed in your first ninety days?" | JD | [generic] | A plan, in a short structure: what you would learn, whom you would meet, what you would not change yet. The guidance makes no claim about your past | A VP tests judgement about pace, and the role's delivery line (F2) is where early changes would show | 

### L — Conversational (1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Tell me what you are looking for next." | EXP | [generic] | Answer in your own words, in two or three sentences. The pack supplies no reason, and it should match your answer to A4 | A casual opener for a 30-minute round, still scored for consistency with Round 1 | 

## 14. Reverse questions, Round 3

| # | Ask | Why it lands |
|---|---|---|
| R3-1 | "What do you most want to see in the engineering managers here?" | Gives you the VP's own leadership language to align to, in their words |
| R3-2 | "What distinguishes the managers who do well here?" | Surfaces the bar in practice, not the poster |
| R3-3 | "How do you develop managers here?" | Opens the growth conversation without claiming experience you have not stated |
| R3-4 | "Where do engineering, hardware and product disagree most, and how are those settled?" | F7 at the VP's altitude |
| R3-5 | "What would you want me to have changed by the end of my first year?" | Anchors the role's scope after K2 |

## 15. Sources

Provided documents: your message (the role description, the three rounds and their lengths, and your background). No dossier was present.

Searches sent, each refused (permission was not granted in this session):

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The values cheat sheet (section dropped, no values page in hand) and the VAL questions' themes would have come from published values; they come from the recruiter's words and persona stems instead |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked your account of the loop against a documented one; weights rest on your account |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have fed CO questions and a grounding brief; none are in the pack |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot rows and the JD-tagged questions |

Sections dropped, with their conditions: values cheat sheet (published values not in hand), grounding brief (no research or brief), reading the interviewer (no interviewer information), graded deliverables (none announced), delivery coaching (no assessment provided).

## 16. Upgrade menu

- Search permission, or the Larkfield values page and any documented interview loop pasted in → the values cheat sheet, CO questions grounded in strategy, and a check on your account of the loop
- Full job description text → the seven requirement rows rest on three clauses today; the rest of the posting would add rows and questions
- Your CV → every evidence cell is currently one sentence from your message; a CV would add quotes, and F1, F3 and F5 would stop resting on a single line
- The artifact behind the 60% (an on-call report or incident dashboard for the quarter) and behind the hiring loop (the scorecards or loop schedule) → F2 and F3 could rise from medium toward high, and C1 and F1 would have counted figures to rehearse from
- Your answers to the answer slots on F1, F4, F6 and F7, outside a drill → those rows become quoted evidence, and A1, A2, A5, F4 and I3 are regenerated from them
- Interviewer names (the Director, both staff engineers, the product manager, the VP) → an interviewer read, per-member persona weights for the panel, and a reverse question tied to each person's own path
- Anything the recruiter said about focus areas or an exercise → coverage the pack currently assumes from round-type priors; one email to the recruiter usually gets it
- What each round actually asked, after it happens → Rounds 2 and 3 reweighted and re-banked from real signal
- A `tuesday-dossier.md` from an earlier fit analysis → verified evidence and a `prohibited_claims` list in place of the locally built one; nothing here depends on one
