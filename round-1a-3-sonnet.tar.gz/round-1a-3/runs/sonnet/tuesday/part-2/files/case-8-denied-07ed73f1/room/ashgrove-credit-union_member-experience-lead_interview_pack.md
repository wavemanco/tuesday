# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Mode: loop, three rounds on 29 November (shared sections first, then one mini-pack per round).

| Round | Length | Who | Relationship | Name known |
|---|---|---|---|---|
| 1 | 30 minutes | The recruiter | Recruiter screen | No |
| 2 | 45 minutes | The Head of Member Services | Your future manager, mostly behavioural | No |
| 3 | 60 minutes | A panel of two branch managers, with a 20-minute case on a complaint escalation | Panel, and the values round: scored against the four values | No |

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: every sentence about your past is one of your own, quoted, and wherever your material is silent the guidance is an answer slot, which you fill in your own words or answer plainly that it was not yours.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behaviour demonstrates Ashgrove's published values, not generic virtue |
| EXP | Whether what you say about your experience survives scrutiny, and what was actually you |
| JD | The posting's stated responsibilities and requirements, including where you have gaps |
| CO | Company and strategy knowledge, thought through at the company's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Question IDs: A and B are round 1; C, D and E are round 2; G, H, J, K and L are round 3. F-numbers are fit-snapshot rows.

## Prep triage

| Order | When | Do | Tied to |
|---|---|---|---|
| 1 | 20 to 21 Nov | Write your own answers to the answer slots on F1, F3, F4, F5, F7 and F9, a few lines each, true to what you did. Paste them back and I will regenerate the rows they change | B1, B3, C1, C3, C4, D3, E2 |
| 2 | 22 Nov | Say the contact-centre line and the senior-leaders line aloud until each is one wording you can repeat, since the same answer will be asked in more than one round | D1, B2, K1, D2 |
| 3 | 23 to 24 Nov | Run the round-three escalation case aloud to twenty minutes | H1, H2, H3 |
| 4 | 25 to 26 Nov | Find one real story for each of the four values from your own experience | G1 to G4 |
| 5 | 27 Nov | Say the one-page monthly report aloud | E2, E1, E3 |
| 6 | 28 Nov | One drill on D1, and have your own answers to the logistics questions ready | D1, A3 to A6 |

Everything else in this pack is insurance.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process across branches and the contact centre, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which parts of a complaint's path were yours likely. If any step beyond the log was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you have stated, and the one this pack expects to be probed in every round. Words: "I have never worked in a contact centre." Then how you would learn that side, said as a plan in your own words and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence touches monthly complaints reporting without showing what the spreadsheet measured. Answer slot: the JD's volumes-and-resolution-times line makes a probe on what it held likely. If it showed complaint volumes or resolution times, say which and how each was counted, in your own words; if it did not, or you do not know how it was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on coaching people at supervisor level likely. If you have coached a colleague at your own level or above on escalations, say who and what your part was, in your own words; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with a digital team, and you have not said there was none. Answer slot: the JD's digital-teams line makes a probe likely. If you have worked with a digital or IT team on anything members use, say what and what your part was, in your own words; if you have not, say so plainly and say how you would start, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms, six years in retail banking and the last three as a branch supervisor, with each number staying on the noun it came from |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The sentence says a formal complaints log, not that the complaints were regulated. Answer slot: the JD's regulated-complaints line makes a probe on which rules those complaints fell under likely. If they followed external rules, say which and what part was yours, in your own words; if the log was an internal process, or you do not know, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you have stated. Words: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past. The sentence does not show what, if anything, you presented at regional level, so that stays an answer slot in D2 |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel. Answer slot: if it was built in Excel, say so and say what it did, in your own words; if it was another tool, or you cannot say, say so plainly and stay with the spreadsheet you built |

## Grounding brief: Ashgrove's July 2026 strategy

These are the four points you relayed from the brief the recruiter sent. The brief is about four months old on 20 November 2026. Learn the vocabulary; do not coach the interviewers on it.

| Item | The brief, as you gave it | Where it surfaces | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | E3, C3 | [grounded] |
| Branch network | "consolidate eight branches into five hubs over 2027" | E1, J2 | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | No bank question: know it exists | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | E3 | [grounded] |

# Round 1: recruiter screen, 30 minutes

### Persona weights

| Persona | How it shows up | Weight | Reasoning shown | Counter-strategy |
|---|---|---|---|---|
| Conversational | Friendly, unstructured; logistics and motivation in a chatty register | high | The recruiter-screen prior is Conversational plus a light Skeptic, and your note says this round is 30 minutes with the recruiter | A pre-scripted 90-second arc; treat casual questions as scored |
| Skeptic | Quick checks on the listed requirements | low | Same prior, light; the gaps you stated in F2 and F8 make a check on them plausible | The honest line first, one wording, repeated in later rounds |

### Conversational bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc whose beats are the quotes' own: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log; training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Say each at that scope, in your own words, and stop at the beats the sentences state. Use the same arc in round three | The opener of every screen, and the arc the later rounds will hear again; F6, F1, F4 and F3 are its material. EXP because it tests what you actually did |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Your reason is yours; this pack holds none of your motives and supplies none. If one of the four published values, Members First, Always, Plain Words, Neighbours, Not Numbers or Own the Fix, really matches why you want this, say which and why in your own words. If the strategy points are what draw you, say that instead. If neither is true for you, give your honest reason and leave the values out | Motivation consistency is the core of a screen, and CO because it checks homework on the published values and strategy. No fit-snapshot row is involved |
| A3 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason for looking, in your own words, true, and kept to what you are moving toward | The reason for leaving is a logistics item every screen carries; EXP because it tests whether your story stays consistent across rounds |
| A4 | "What salary range are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked what you earn now, you can decline and return to the role's band | Pay is a standard screen item and the listed job's term, so JD |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | Notice is a standard screen item and a term of the job, so JD |
| A6 | "Is the location, and getting between sites, workable for you?" | JD | [grounded] | Logistics slot: give your actual location and travel constraints in your own words. If you do not know where the role is based, say so and ask the recruiter | The JD's "across branches and the contact centre" implies more than one site, so location is a likely screen item; JD because it is a term of the listed job |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you handled regulated complaints before?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you handled, in those words: the branch's formal complaints log. Answer slot: the JD's regulated-complaints line makes a probe on which rules those complaints fell under likely. If they followed external rules, say which and what part was yours; if the log was an internal process, or you do not know, say so plainly and stay with the log you handled | F7 is the evidence for a listed requirement and an easy knockout check; JD because it tests that requirement directly |
| B2 | "The role covers the contact centre as well as branches. What's your experience on the contact-centre side?" | JD | [grounded] "Never worked in a contact centre" | The honest line is the quote: "I have never worked in a contact centre." Then a plan, said as a plan: how you would learn that side in your first weeks, in your own words, with nothing about contact-centre work described as if you had done it. Use exactly this wording again in D1 and K1 | F2 is a stated gap and a screener's quickest check against the JD; JD because it scores a listed scope |
| B3 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built, in those words. Answer slot: if it was built in Excel, say so and say what it did, in your own words; if it was another tool, or you cannot say, say so plainly and stay with the spreadsheet | F9 is the evidence for a listed requirement, and the quote says spreadsheet, so the screen is where the tool gets named; JD because it checks a stated requirement |

### Reverse questions for round 1

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "For the escalation case in the panel round, is anything shared in advance, and what format does it take?" | It removes the biggest structural unknown in the loop, and recruiters can usually answer it in one line |
| 2 | "Where is the role based, and who in the contact centre would I work with day to day?" | It settles the location item and shows you are already thinking about the contact-centre side |
| 3 | "When are the panel members confirmed, so I can prepare for their branches?" | Interviewers are not yet assigned, and a name unlocks a tailored read |
| 4 | "Which of the strategy points, digital, the move to hubs or small-business lending, touches complaints first?" | It shows you read the brief and asks where the role sits in it |
| 5 | "How is the decision made after the third round, and when would I hear?" | It is process homework that costs the recruiter nothing to answer |

# Round 2: Head of Member Services, 45 minutes

### Persona weights

| Persona | How it shows up | Weight | Reasoning shown | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | "Tell me about a time" probes on how you work | high | The recruiter says this round is "mostly behavioural"; the interviewer would be your manager | Map each beat to a quoted sentence; "we" for context, "I" for your contribution; where the material is silent, an answer slot |
| Skeptic | Quiet probing of the gaps against the JD | medium | The hiring-manager prior is Case/Strategist plus Skeptic, and the gaps in F2 and F8 sit exactly where the JD presses | Rehearse D1 until it is boring; the honest line first |
| Case/Strategist | A live problem from the roadmap | low | The hiring-manager prior would make this dominant, but "mostly behavioural" tilts it down; the strategy points supply the problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

### Values/Behavioral bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached a colleague through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: training new tellers on the escalation script is the beat the sentence states; tell it in your own words at that scope. Answer slot: the JD's coaching line makes a probe on a hard case likely. If there was an escalation you coached someone through, say what it was and what part was yours; if the training was on the script and not case by case, or it was not yours to coach, say so plainly and stay with the training | F4 is the evidence for the coaching requirement and its limit is the tellers, not supervisors; JD because the open prompt scores the listed coaching duty |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior something they did not want to hear. It needs the truth you carried, who it was for, and what happened to the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural probe for a role that reports upward, and F8 means the audience matters; VAL because it scores behaviour under pressure, not a published value by name |
| C3 | "Tell me about a time you worked with a digital or IT team to improve something members use." | JD | [grounded] | Answer slot: the JD's digital-teams line makes this probe likely. If you worked with such a team, say on what and what your part was, in your own words; if you did not, say so plainly, then say how you would start working with one, as a plan | F5 has no evidence, so the honest answer has to be ready before the probe arrives; JD because it scores the listed digital-teams duty |
| C4 | "Walk me through the escalation script you trained new tellers on." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Describe, in your own words, what the script was for and who used it; this pack does not know its steps and supplies none. Answer slot: the JD's coaching-on-escalations line makes a probe on when a case should be escalated likely. If you set or wrote the script, say so and how; if it was handed to you, or you trained people on it without deciding its content, say so plainly and stay with the training | F4 is a CV-style line an interviewer will open up; EXP because it tests what was actually yours |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see contact-centre experience in your background. How would you handle that side of the role?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** One wording, three levels. Level one: "I have never worked in a contact centre." Nothing before it and nothing after it that softens it. Level two, they ask how you would earn that team's trust: give a plan in your own words for your first weeks on that side, said as a plan and never as a past; this pack supplies no plan content. Level three, they ask what you would do if their way of handling complaints differs from the branches': say what you would ask first, in your own words. The limit is named before it is asked for. If you need substance beside the concession, it is the quote at its own scope: you handled the branch's formal complaints log. Hold through two follow-ups by returning to that, never by adding to it | F2 is the biggest distance between the JD's scope and the material, so this objection arrives in some form in every round. JD because it scores a listed scope |
| D2 | "This role presents to senior leaders. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level" | The honest line is the quote: "I've never presented to anyone above regional level." Answer slot: the JD's senior-leaders line makes a probe on what you have presented likely. If you have presented at regional level, say to whom and about what, in your own words; if not, say so plainly. Then a plan for how you would prepare for a senior audience, said as a plan and never as a past | F8 is a stated gap against a listed requirement; JD because it scores that requirement |
| D3 | "You handled your branch's complaints log. How does that get you to owning the whole process across branches and the contact centre?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold to the quote: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which steps beyond the log were yours likely. If any were yours to set, say which and how you decided; if there was no such step, or it was not yours, say so plainly. Then say how you would learn the parts of the process you have not handled, as a plan, without describing them as done. Hold through two follow-ups by returning to the log, never by adding to it | F1 is the scale gap between one branch's log and the whole process; JD because it scores the headline responsibility |

### Case/Strategist bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're consolidating eight branches into five hubs over 2027. Where could complaints get lost along the way, and what would you put in place?" | CO | [grounded] | A live problem; no past needed. Think aloud in order: clarify what lost would mean to a member and ask how the process works today; the objective; which members and branches are affected first; your approach; how you would know it was working; the risks. Use the brief's own words, "eight branches into five hubs over 2027". Challenge one premise respectfully, for example whether complaints get lost or only slow down. Where you do not know Ashgrove's plans, say so rather than describing them | The brief makes branch consolidation the biggest change touching complaints; CO because it tests thinking at the company's altitude, with a CASE delivery |
| E2 | "You'll report monthly to senior leaders on complaint volumes and resolution times. What goes on the one page, and what do you check before you show it?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Structure it aloud: who reads it and what they decide with it, which numbers (the JD names volumes and resolution times), how each is defined, what you check before showing it. You may start from the spreadsheet in the quote's words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it showed volumes or resolution times, say which and how each was counted, in your own words; if it did not, or you do not know how it was counted, say so plainly and stay with what it did show | F3 and F9 are your strongest adjacent material and F8 is the audience, so this is where they meet; CASE because it asks for live structure, with JD content |
| E3 | "App-only banks are our main competitive pressure, and we want 40% of member service digital by 2028. What would a self-service complaint journey need to do for a member-owned credit union to hold its own?" | CASE | [grounded] | Structure aloud: what a member needs at the moment of complaint; what plain wording means here, in the published value's own words, "if a member needs it explained twice, we wrote it wrong"; what you would ask the digital team first; how you would know it was working, using the volumes and resolution times the JD names. Say plainly what you do not know about app-only banks' complaint journeys rather than describing them | It is the brief's competitive frame applied to the JD's digital-teams duty; CASE because it is a live design problem, with CO content |

### Reverse questions for round 2

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like for whoever owns the complaints process?" | It asks your manager to define success, which lets you aim every later answer at it |
| 2 | "How would you want a new complaints lead to learn the contact-centre side?" | It turns your stated gap into a plan conversation instead of an objection |
| 3 | "What do senior leaders see about complaints today, and what do they wish they could see?" | It speaks to the monthly report and the senior audience in the JD |
| 4 | "As more service moves digital by 2028, who would the complaints lead work with most?" | It shows you read the brief and tests the digital-teams duty |
| 5 | "What would make you say, after a year, that this hire was the right call?" | It lets your manager name the standard you will be held to |

# Round 3: panel of two branch managers, 60 minutes (values round and a 20-minute case)

### Persona weights

| Persona | How it shows up | Weight | Reasoning shown | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Scenario probes keyed to the four values | high | The recruiter says: "The panel is also the values round — they score against the four values." Cross-functional or values rounds weight this persona first | Selection scaffolds with an honest branch where nothing you said carries a story; land the hard truth |
| Case/Strategist | The 20-minute escalation case | medium | The recruiter names a 20-minute case on a complaint escalation, a third of the round | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise |
| Peer Evaluator | Seam-splitting between the lead and branch management | low | Inferred: the role coaches branch supervisors, whose branches these managers run, so the seam between you and them is a natural probe | Offer seam principles rather than pretending to know the seam; reciprocity |
| Skeptic and Pressure | The contact-centre gap, and a time-boxed challenge | low | The panel blends the top personas of two members; the stated gap in F2 travels into every round | The same honest line; hold, then concede specifically |
| Conversational | An opener for people who have not read your file | low | Panels typically open this way; one question, because it reuses the A1 arc | The A1 arc, unchanged |

### Values/Behavioral bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter when it was not the easy option." | VAL | [grounded] | Selection scaffold: pick a time you chose what was right for a member over what was easier for the branch or for a target. It needs the decision, who would have preferred otherwise, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests Members First, Always from the published values page; the panel scores against it. Nothing in the snapshot carries this story, so the scaffold is the honest form |
| G2 | "Tell me about a time something you wrote or said had to be explained twice. What did you do about it?" | VAL | [grounded] | Selection scaffold: pick a time a member or a colleague needed something explained again. It needs the original wording, what was unclear, and what you changed in the wording itself. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests Plain Words from the published page. Nothing in the snapshot carries this story, so the scaffold is the honest form |
| G3 | "Tell me about a time what you knew about your branch's town changed what you did." | VAL | [grounded] | Selection scaffold: pick a time the local picture, a member you knew or something happening in the town, changed a decision from what a number alone would have said. It needs the decision and what was local about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests Neighbours, Not Numbers from the published page, and branch managers are the natural scorers of it. Nothing in the snapshot carries this story |
| G4 | "Tell me about a problem you found that you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 only as far as the sentence goes: you handled the branch's formal complaints log. Answer slot: the value's wording, whoever finds the problem keeps hold of it until it is solved, makes a probe on a case you followed from found to solved likely. If you kept hold of one, say which and what you did, in your own words; if the log was a record you kept without following cases to their end, or it was not yours to follow, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests Own the Fix; F1 is the only row that touches it and carries no case from found to solved |

### Case/Strategist bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member complained at their branch, then rang the contact centre, then wrote in about the same problem. Each place treated it as new, and you have just been told. Take us through your first twenty minutes." | CASE | [generic] | Think aloud in this order. Clarify: what the member has asked for, what they have been told, what has already been promised, how long it has run, which deadline applies and who knows it. Objective: the member's problem solved, one voice to the member, and the pattern learned from. Who holds it: you found it, so you keep hold of it, in the published value's words. Approach: one point of contact, one record, and tell the member in plain words what happens next and when. Metrics: how this pattern would show up in the monthly volumes and resolution times. Risks: the deadline, a further complaint, and a supervisor who feels exposed. Challenge one premise, for example whether it is one problem or three. The question needs no claim about your past, so the guidance makes none | The recruiter names a 20-minute case on a complaint escalation; this is a pattern for that problem, not a prediction of the panel's actual case, so it is generic. F1 is the duty it exercises |
| H2 | "The supervisor says the member is being unreasonable and does not want to escalate. What do you say to them?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Structure: listen first, ask what they have tried, put the case in the member's terms, agree what escalating would protect, and say what you will take off their hands. If you reach for common ground, the quote supports only this: you were a branch supervisor for the last three years, at that scope and no more | A follow-up the case is likely to carry, because the JD has you coach branch supervisors; F4 is the transferable limit |
| H3 | "Now the contact centre says it belongs to the branch, and the branch says it belongs to the contact centre. Who owns it?" | CASE | [grounded] | Answer first: the person who found it keeps hold of it until it is solved, in the published value's own words, and the lead makes sure no complaint falls between channels. Then say how you would settle the seam without a fight: ask each side what they need, agree one owner for this complaint today and a rule for the next one. Concede what you do not yet know, how Ashgrove splits this today, rather than describing a split | A pressure-style follow-up on the seam the JD's across-branches-and-contact-centre scope creates; the published Own the Fix value gives the answer its spine |

### Peer Evaluator bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Our branches sit alongside your role. Where is the seam between you and a branch manager, and what happens when we disagree about a complaint?" | JD | [grounded] | Offer seam principles rather than pretending to know the seam: you would ask where they feel the line is, agree it with them, and say what you bring them as well as what you need. For disagreement, if a time comes to mind when you disagreed with an equal and kept the relationship, tell it in your own words; if none does, say so plainly and say how you would handle it | The JD has you coach branch supervisors on escalations, which puts the lead next to branch management; JD because it scores a stated duty, with a peer delivery |
| J2 | "When eight branches become five hubs, how do you keep a complaint close to the town it came from?" | CO | [grounded] | A live problem on the brief's move, "consolidate eight branches into five hubs over 2027", and the published value, "every branch is part of its town". Structure: what close to the town means to a member, what would be lost when a branch becomes a hub, who local staff speak for, and how complaints are recorded so the town still shows in the report. Say plainly what you do not know about Ashgrove's plans for each hub | Branch managers are the people most affected by the hub move; CO because it joins the strategy brief to a published value |

### Skeptic and Pressure bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Your background is on the branch side. How do you earn credibility with the contact centre, and with us?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The same wording as B2 and D1: "I have never worked in a contact centre", then your plan, said as a plan. For the branch managers, the substance you can stand on is the quote: you handled the branch's formal complaints log. Add nothing | F2 again, in panel packaging; JD because it scores the listed scope |
| K2 | "Sixty seconds: why you over someone who has run a complaints team in a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre" | Hold, then concede. Pause and restate the question. Hold: say what you did at its own scope, six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log, training new tellers on the escalation script, and let them draw the inference. Concede specifically: "I have never worked in a contact centre." Hold through two follow-ups by returning to what you did, never by adding to it, and do not claim to be better than a candidate you have not met | A time-boxed challenge is the standard Pressure form, and F1, F2 and F4 are the material it presses on |

### Conversational bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Tell us about yourself, in two minutes, for people who have not read your file." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | The A1 arc, unchanged: the same four beats at the same scope. Stop at the beats the sentences state | A panel opener, and the same arc as A1 keeps what each round hears consistent; F6, F1, F4 and F3 are its material |

### Values and principles cheat sheet

Ashgrove's four published values, by name, from the page you copied on 20 November 2026.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: pick a time you chose what was right for a member over what was easier for the branch or a target, with the decision, who would have preferred otherwise, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold: pick a time something needed explaining again and you changed the wording itself, with the original wording, what was unclear, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold: pick a time the local picture changed a decision from what a number alone would have said, with the decision and what was local about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The sentence carries the log and nothing about a case followed from found to solved, which is G4's answer slot. If you kept hold of one, say which and what you did; if not, say so plainly and give the nearest case your material does carry |

### Reverse questions for round 3

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "How do your supervisors handle escalations today, and where would they most want support?" | It is a reciprocity question that puts the panel's own branches at the centre |
| 2 | "As eight branches become five hubs, what do you most want a member's complaint to stay close to?" | It ties their branches to the brief and the Neighbours, Not Numbers value |
| 3 | "What would you want from me in my first month that would genuinely help your branch?" | It is the peer reciprocity question and shows what you bring, not only what you need |
| 4 | "Which of the four values is hardest to live up to day to day in a branch?" | It invites the scorers to talk about the values in their own terms |
| 5 | "Where do complaints most often cross between a branch and the contact centre?" | It goes straight to the seam in H3 and shows you are thinking about the whole process |

## Prohibited claims

Built from the fit snapshot before any bank was written. No answer slot, hold, bridge or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's formal complaints log, not the process across branches and the contact centre. D3's slot stays inside the log |
| Has worked in or run a contact centre | Negative you stated, F2 | The plain acknowledgment: "I have never worked in a contact centre." No slot |
| Has presented to anyone above regional level | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." D2's slot stays at regional level and below |
| Coached or trained branch supervisors | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script. The limit is the pack's observation: your material says tellers, not supervisors |
| Wrote or designed the escalation script | Inflated form of F4 | The quote at its own scope: you trained new tellers on it. The limit is the pack's observation: your material does not say who wrote it. C4's slot stays inside the training |
| Reported complaint volumes and resolution times to management | Inflated form of F3 | F3's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. The limit is the pack's observation: your material does not say what it measured |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: a formal complaints log. The limit is the pack's observation: your material says formal, not regulated. B1's slot stays inside the log |
| Excel reporting skills | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. The limit is the pack's observation: your material does not name the tool |

## Sources

Provided documents: the job description you pasted; Ashgrove's four values as you copied them from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email on the three rounds; the four points you relayed from the July 2026 strategy brief the recruiter sent (the full brief was not read); your background in your own message. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values page you pasted fixes the cheat sheet's value names and the VAL questions, so a search could move nothing |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email gives three sessions and who runs each, which fixes the persona weights; no search could change them |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief points you relayed already supply the priorities and the competitive frame the CO and CASE bank uses |
| 4. Interviewer name and Ashgrove | n/a | No interviewer has been assigned, so there is no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → F1 to F9 can move from your message alone to a CV line plus your message, and a CV may carry sentences for the rows now marked discovery
- Your own answers to the slots on F1, F3, F4, F5, F7 and F9, in your own words → those rows regenerate, and so do B1, B3, C1, C3, C4, D3 and E2
- An anonymised copy, or just the column headings, of your monthly complaints spreadsheet → F3 and F9 can move from low toward medium, since the spreadsheet itself is the inspectable artifact in this field
- One real situation of your own for each of the four values, a sentence or two each → the selection scaffolds in G1 to G3 and the cheat sheet become story-mapped rows, and G4's slot can be answered
- The panel members' names and roles once assigned → an interviewer read, retuned persona weights and a reverse question on their paths
- The recruiter's answer on whether the escalation case is shared in advance → the H bank restructures around it
- Your pay range, notice period and location → the logistics slots in A3 to A6 hold your own words
- The full 2026 strategy brief → the grounding brief and the CO bank go beyond the four points you relayed
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, covering role-family loop reports and recent organisation context, and interviewer footprints once names exist → the persona weights and CO bank sharpen
- A tuesday-dossier.md, if you have one from an earlier fit check → an evidence-derived objection to rehearse deepest, and sourced prohibited claims
