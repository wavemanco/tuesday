# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Built for a hiring-manager round, assumed because the round type and the interviewer's relationship were not stated. Persona weights are provisional and reweight once the relationship is known.

## How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether the claims in your background survive scrutiny, including what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

A week is enough for the few things below, done well and in this order. Everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the span-of-control answer until it is boring | B1, then B2 |
| 2 | Rehearse the Power BI acknowledgment and your own plan for learning it | B3, D3 |
| 3 | Be able to explain how the 40% mis-pick figure was counted, and which part was yours | C1, D2 |
| 4 | Practice structuring a live operations problem aloud | A1 to A4 |
| 5 | Get the answers to the years-of-leadership and which-green-belt questions straight in your own words | B5, E2 |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution, not terminals, and says nothing about how many sites. The words stay at the quote: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's four sites make a probe on terminal or multi-site exposure likely. If any of your work touched either, say what, in your own words; if there was none, or it was not yours, say so plainly and stay with warehouse and distribution |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (the on-time half) | "cut mis-pick rate 40% by redesigning the pick path" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Both quotes are adjacent work: a quality rate and a surge plan. Neither says on-time performance, and the words stay at each quote's own scope. Answer slot: expect a probe on whether service or on-time results were measured. If they were, say what was measured and how it was counted; if not, say so plainly and stay with the mis-pick rate and the surge plan as you stated them |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (the cost half) | none given | none | [grounded] | discovery | Your material shows nothing on cost. Answer slot: if any of your work was tracked in cost terms, say what was counted; if none was, say so plainly, and say what you would measure first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD names 12 supervisors and your material says 3, and the words stay at the quote: "I'm currently a senior shift manager over 3 supervisors." Answer slot: expect a probe on span of control. If you have led or coordinated larger groups, say how many and in what role; if not, say so plainly and stay with the 3 |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Solid Excel is not the same as building reporting, and the bridge should not be stretched. Answer slot: if you built reports or dashboards in Excel, say what and for whom; if you did not, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would get to working level, said as a plan and never as a past. Never a claim to Power BI work |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material gives seven years in operations and a current people-leading role, not how many of those years involved leading people. This is a length-of-experience requirement, not a gate. Answer slot: say the years you led people, with titles as they were; if only part of the seven years was leading, say that figure and never round up |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | discovery | Your material says green belt, not which discipline or body, and the pack reads it at the smaller scope. The words stay at the quote: "I'm green belt certified." Answer slot: expect a probe on which certification and what you did with it. Say which one, in your own words; if you have not applied it since, say so plainly and stay with the certification |

## Persona table

The relationship is assumed to be hiring manager, and no loop source establishes this company's rounds, so the fallback is the Generic archetype with no tilt. Weights are provisional.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist (A) | Live operations problems from the role: diagnose, plan, structure | high | Hiring-manager prior; the JD asks for on-time, cost and reporting results that are natural live problems | Clarify, set the objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of scale, terminal exposure, Power BI and years of leadership | high | Hiring-manager prior; F1, F4, F6 and F7 are where the material is thinnest | Rehearse the single most predictable objection until it is boring; bridge only from your stated quotes; give the ramp plan as a plan |
| Data-Driven Prober (C) | Line-by-line questions on the 40% figure and Excel | medium | Headline metrics draw probes; the reporting requirement invites it | Know what you can and cannot say about how the figure was counted; name the weakest assumption first, or say you do not know |
| Pressure (D) | Time-boxed challenges and "how much was you" | medium | Hiring managers test composure on the same gaps the Skeptic finds | Pause, restate, anchor in what you said, hold through two follow-ups, then concede specifically |
| Conversational (E) | Friendly "walk me through the journey" openers | medium | Almost every loop opens this way; casual questions are still scored | Prepare a 90-second arc built only from your own stated facts |
| Values / Behavioral (F) | Scenario prompts on unpopular truths and customer-over-metric | low | No values-style round is detected; no published values were read | Pick real instances with a named stake, or say plainly none comes to mind |
| Peer Evaluator (G) | Seam and credit questions from an adjacent leader | low | Terminal managers across sites may sit on the panel; relationship unknown | Reciprocity framing; propose seam principles rather than claiming to know the seam |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance is slipping at one of your four terminals. What do you need to know first, and how do you structure the diagnosis" | CASE | [generic] | Clarify before structuring: which shipments, since when, against what target. Then objective, segmentation, approach, metrics, risks, thinking aloud. Challenge one premise, such as whether the slip is real or a measurement change. The question needs no claim about your past, so the guidance makes none | The JD's on-time requirement (F2) is the likeliest live problem. CASE because it scores structure, not a remembered answer |
| A2 | "Cost-per-shipment at one terminal runs above the other three. How would you find out why, and what would you do first" | CASE | [grounded] "green belt certified" | Structure it the same way: define the cost, split it by driver, compare against the other three, pick the first test. If you reach for a method, name it as training only: "I'm green belt certified." No tool or project is named for you here. Answer slot: if you used a method on a live problem, say which and what it showed; if not, say so plainly and stay with the certification | F3 is silent on cost and F8 carries the plus-skill; JD content, CASE delivery |
| A3 | "A large customer doubles its volume for two weeks on ten days' notice, across all four terminals. Walk me through your plan" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: demand picture, capacity by site, constraints, trigger points, communication, what you stop doing. Where you speak of your own surge work, stay at the quote: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site scope makes a probe on how a plan changes across sites likely. If you have coordinated more than one site, say how; if not, say so plainly and stay with the site plan you ran | F1 and F2 meet here; the surge quote is the strongest adjacent evidence for a multi-site scenario |
| A4 | "You have Excel, a month of terminal data and no BI tool yet. What goes on the daily report to the four terminals, and what do you leave out" | CASE | [generic] | Pick a short set of measures tied to the JD's on-time and cost goals, say who reads the report and what they do with it, and say what you leave out and why. State what you would check in the data before trusting it. The question asks about no past, so the guidance makes no claim about yours | The JD asks for reporting built in Excel or Power BI (F5, F6). Asked as a design problem it tests judgment without needing the tool |
| A5 | "You inherit twelve supervisors across four sites you have not met. How do you spend the first two weeks" | CASE | [generic] | Structure: listen first, learn the baseline per site, set a small number of expectations, decide where to be physically present, and say what you would not change yet. This is a plan, not a past, and it makes no claim about your history | F4's span gap; a plan answer shows how you would close it without claiming you have done it |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers four sites and twelve supervisors. What part of that scale would be new to you on day one" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led or coordinated larger groups or more than one site, say which and how, in your own words; if not, say so plainly, then give your plan for the first weeks as a plan. Follow-up one: stay with the 3. Follow-up two: concede the gap in scale specifically, name what you would learn first, and do not add experience to close it | F4 is where the role's scale presses hardest, so this objection arrives in some form. JD because it scores the stated requirement |
| B2 | "You come from warehouse and distribution. What is different about running a terminal, and where would you be least ready" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I have 7 years in warehouse and distribution ops." Answer slot: if any of your work touched terminal-style flow, say what, in your own words; if not, say so plainly and stay with warehouse and distribution. Then say what you would ask in your first week to learn the differences, as questions and not as claims | F1 is the second most predictable objection; asking where you would be least ready is a candor test |
| B3 | "Which part of this JD would you be weakest at on day one" | JD | [grounded] "solid Excel, never used Power BI" | Name it plainly: "I have never used Power BI." You may add "solid Excel" at its own scope. Then say how you would get to working level as a plan, in your own words and your own timeline. Do not describe any Power BI work | F6 is the one gap you have stated yourself; naming it first removes the probe's force |
| B4 | "Why this move, and why Atlas Freight, now" | EXP | [generic] | Selection scaffold: give your own reasons for moving toward terminals and multi-site scope, then one specific thing about this company you have verified yourself. If you have not researched it yet, do that before the interview and say only what you found. If no reason comes to mind beyond the role, say so plainly, then give the nearest honest one | Motivation consistency is what a skeptical hiring manager checks. No company research was run for this pack, so nothing about Atlas Freight is supplied |
| B5 | "The JD asks for five or more years of operations leadership. How many of your seven years were leading people" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say the years you led people, with titles as they were. If only part of the seven years was leading, say that figure and never round up. If the role you hold now is your only people-leading role, say so plainly and stay with it | F7 is a length-of-experience requirement a screen may read literally; JD because it scores the stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate by 40%. Walk me through how that was counted" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State it as quoted: you cut the mis-pick rate 40% by redesigning the pick path. Answer slot: say how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly and say what you would check. No baseline or method is supplied here | The headline figure in F2 is the likeliest thing a prober opens |
| C2 | "Walk me through the pick-path redesign" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Tell it in your own words using only what the sentence states: the pick path, the redesign, the 40% cut in the mis-pick rate. Add nothing you cannot repeat under a second question | A natural second question after C1; the story has only the beats the sentence states |
| C3 | "What reporting have you built in Excel" | JD | [grounded] "solid Excel" | Say "solid Excel" at its own scope. Answer slot: if you built reports or dashboards, say what, for whom and how often; if you did not build reporting, or it was not yours, say so plainly and stay with "solid Excel" | The JD raises reporting (F5); the quote does not carry it, so the guidance is a slot |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who already runs terminals" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Pause, restate, then use the two quotes at their own scope. Hold through two follow-ups by returning to them. Concede the terminal and scale gap specifically, in one sentence, without adding experience. Answer slot: if you have terminal exposure, say what; if you do not, say so plainly | Pressure interviewers test whether you fold or inflate on the F1 gap |
| D2 | "That mis-pick result. How much of it was actually you" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say what part of the redesign was yours and what others did, in your own words. If it was shared, say who did what; if you do not know the split, say so plainly. Hold through two follow-ups, then concede specifically. Never widen "cut" into more than you did | The standard attribution probe on the pack's strongest figure |
| D3 | "You have never used Power BI and this job needs it. Why should I believe you will get there" | JD | [grounded] "never used Power BI" | Acknowledge once: "I have never used Power BI." Then state your plan as a plan. Hold the position through two follow-ups; concede specifically that the first weeks will be a learning curve, without claiming any Power BI work | The negative is yours, stated in F6, so a plain acknowledgment is allowed |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey" | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc of three beats. First: "I have 7 years in warehouse and distribution ops." Second: "I'm currently a senior shift manager over 3 supervisors." Third: your own reason for this role, in your own words | The biography question opens most loops and is scored; F1 and F4 supply the quotes |
| E2 | "What are you actually doing with Lean or Six Sigma these days" | JD | [grounded] "green belt certified" | Start with the quote: "I'm green belt certified." Answer slot: if you apply it now, say where and what; if you do not, say so plainly and stay with the certification | The JD lists it as a plus (F8), and the casual register hides a scored question |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral prompt. No values-style round is detected, so no company value is mapped |
| F2 | "When did you put a customer ahead of an internal metric" | VAL | [generic] | Selection scaffold: pick one instance with a named customer, the metric you set aside, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A freight business scores service against cost; the scaffold keeps you from reaching for a story you cannot back |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our terminals sit side by side. Where is the seam between yours and mine, and what happens when we disagree" | JD | [generic] | Propose seam principles instead of claiming to know the seam: shared data, a clear owner per decision, and escalation only after a direct conversation. Frame what you bring the other terminal, not only what you need. The question asks about no past | The role spans four sites, so cross-site friction is plausible |
| G2 | "How do you handle credit when work spans teams" | VAL | [generic] | Selection scaffold: pick an instance where credit was shared, say what each side did, and say how you named it. If no such time comes to mind, say so plainly, then give how you would handle it | Credit-sharing probes are the usual peer test |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, B2, D1, G1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, D1 |
| "lead a team of 12 supervisors" | A5, B1 |
| "build reporting in Excel/Power BI" | A4, B3, C3, D3 |
| "5+ years operations leadership required" | B5 |
| "Lean/Six Sigma a plus" | A2, E2 |
| Headline figure on your background: the 40% mis-pick cut | C1, C2, D2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like at each of the four sites today, and which would you want me to look at first" | It shows you think measure-first and invites the real numbers |
| R2 | "How are the twelve supervisors spread across the four sites, and what would you most like to change about how they work together" | It addresses the span gap directly, as curiosity and not as a defense |
| R3 | "Where does reporting live today, and what is the biggest gap in it" | It opens the Excel and Power BI topic on your terms |
| R4 | "If Power BI is the main tool, how do people here usually get up to speed on it" | It turns your stated gap into a learning plan, as a question about onboarding and never as an excuse |
| R5 | "What would a good first ninety days look like for this role" | It makes the hiring manager define success in their own words |
| R6 | "What is the biggest driver of cost-per-shipment right now" | It shows you take the cost half of the JD as seriously as the on-time half |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran terminal operations across multiple sites | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says warehouse and distribution, not terminals or multiple sites. B2 and A3 slots stay inside that scope |
| Led a team of 12 supervisors | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says 3, not 12. B1's slot stays inside the quote |
| Drove on-time performance | Inflated form of F2 | F2's quotes at their own scope: a mis-pick rate and a surge plan. The limit is the pack's observation: neither quote says on-time performance. D1's slot stays inside them |
| Sole owner of the pick-path redesign | Inflated form of F2's mis-pick quote | The quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". D2's slot asks only what part was yours |
| Used Power BI or built Power BI reporting | Negative you stated, F6 | The plain acknowledgment F6 gives: "I have never used Power BI." No slot |
| Five or more years of leading operations teams | Inflated form of F7 | F7's quotes at their own scope. The limit is the pack's observation: the material gives seven years in operations, not how many were leading. B5's slot asks for your own figure |

## Sources

Provided documents: the job description you pasted, and your message describing your background. No dossier was present.

Searches sent, all refused because search access was not granted:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics terminals news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have moved the values cheat sheet, which is dropped because no published values were read and no values-style round is detected |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have moved the persona weights and loop structure; the fallback archetype is Generic with no tilt |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have moved a CO question grounded in current strategy; none is in the banks |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web research (company values, interview loop, recent strategy): not run because search access was not granted. Granting it, or pasting the company's careers or values page, would upgrade B4 and add a values cheat sheet and a strategy-grounded question
- The interviewer's name and role, or the round type → reweighted personas, an interviewer read and a tailored reverse question
- The recruiter's prep email, including any focus areas or a pre-declared presentation → coverage of that deliverable and a corrected bank
- Your actual years spent leading people, with titles → F7 and B5 become `[grounded]` on your own figure
- The green belt certificate (discipline, body, date) → F8 rises from `medium` and E2 gets a firmer quote
- The before and after mis-pick report behind the 40% figure → F2 and C1 rise toward inspectable evidence
- A `tuesday-dossier.md`, if you have one → verified evidence and a named top objection in place of the inferred ones
