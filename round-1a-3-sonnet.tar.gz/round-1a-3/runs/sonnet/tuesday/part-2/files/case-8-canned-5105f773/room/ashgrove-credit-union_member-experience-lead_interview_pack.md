# Member Experience Lead — Ashgrove Credit Union — interview pack (loop mode, three rounds on 29 November 2026)

Candidate: Dara. Built on the JD, the four published values, the recruiter's process email, the 2026 strategy brief and your background note, all as you pasted them. No interviewer names exist yet for rounds 2 and 3, so persona weights run on role and loop priors and there is no interviewer read.

| Round | Who | Length and shape | Provenance |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | [grounded] |
| 2 | The Head of Member Services, who would be your manager | 45 minutes, mostly behavioural | [grounded] |
| 3 | A panel of two branch managers | 60 minutes, including a 20-minute case on a complaint escalation; also the values round, scored against the four values | [grounded] |

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Every question carries one type tag:

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your own account of your work survives follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition |
| CASE | A live problem from the role, scored on structure and reasoning |

Guidance is scaffolding, not a script: say it in your own words. Wherever your material carries no sentence for a question, the guidance is a selection scaffold or an answer slot, and it never supplies a detail you did not give. Question IDs skip the letter F so they never collide with fit-snapshot rows.

## Prep triage

Nine days run from today to 29 November, and all three rounds fall on the one day, so what you say in round 1 has to hold in rounds 2 and 3. These steps are in priority order; everything else is insurance.

| When | Do | Tied to |
|---|---|---|
| 20 to 22 Nov | Write down the true material the pack cannot supply: the four upgrade-menu asks at the end (complaints you handled, the spreadsheet, the rules the log ran to, any digital work). Nothing in the values bank can be rehearsed without it | C3 to C6, H1, H2, A7 |
| 23 to 25 Nov | Say the contact-centre answer aloud until it is boring, then the senior-presenting answer | B3 first, then B1, B2, B4, B6 |
| 26 to 27 Nov | Run the 20-minute escalation case aloud against a clock, then the two strategy cases | D4, D5, then D1, D2 |
| 28 Nov | Fix your answers on pay, notice, location and reason for leaving in your own words; settle the 90-second arc; read the reverse questions | A1, A3 to A6, the reverse questions |
| 29 Nov | One pass of B3 and G2 before round 1; nothing new | B3, G2 |

## Fit snapshot

The spine every bank reads from. Evidence cells hold only your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log and the training, not the process end to end, with nothing inspected behind it; the words stay at "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If handling the log included steps beyond the log itself, say which and what part was yours, in your own words; if it did not, or they were not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would get to know it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet your regional manager uses, not what it counted, so lead with it at that scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted either, say which and how it was counted; if it counted neither, say so plainly and say what you would add |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says training new tellers, not coaching supervisors, so the words stay at "trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on who else you helped with escalations likely. If any of that training reached people beyond new tellers, say who and what part was yours; if it did not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, so the pack writes no words for you. Answer slot: the JD's digital-teams line, and the brief's "move 40% of member service to digital channels by 2028", make this probe likely. If you have worked with a digital team on anything members used themselves, say what and what part was yours, in your own words; if you have not, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length, but a line with nothing inspected behind it, so expect a probe on what the work was. Lead with it in its own terms, "6 years in retail banking, the last 3 as a branch supervisor", and let them place it against the role; do not re-label it in the JD's phrase |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal log, not regulated complaints; the words stay at "I handled the branch's formal complaints log." Answer slot: the JD asks for regulated complaints, so expect a probe on what rules the log ran to. If it was kept to rules set outside your branch, say which and what you did under them; if it was not, or you did not work to any, say so plainly and stay with the formal log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | The limit is one you stated. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Never a claim to senior-level presenting, and nothing added to soften it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material says a spreadsheet, not Excel, and nothing about what you did in it. Answer slot: the JD names Excel, so expect a probe on the tool. Name the tool you built it in and what you did in it, in your own words; if it was another spreadsheet tool, say so plainly |

## Grounding brief

Items from the 2026 strategy brief you were sent, in your message's words. The brief is dated July 2026, about four months before today.

| Brief item | Where it can surface | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | Strategy cases D1 and D5, the motivation question A2, and F5's probe | [inferred] |
| "consolidate eight branches into five hubs over 2027" | The panel's value and strategy question E1, and the Neighbours, Not Numbers value in round 3 | [inferred] |
| "launch a small-business lending product in Q1 2027" | A2 if you are asked what you know; not a likely scoring topic for a complaints role | [inferred] |
| "the main competitive pressure is app-only banks" | Digital self-service answers in D1 and D5 | [inferred] |

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| F1 own the complaints process end to end | H2, D4, G1 | |
| F2 across branches and the contact centre | B1, B3, B4, G2, D4 | B3 is the deepest rehearsal |
| F3 monthly reporting on volumes and resolution times | D2, H1 | |
| F4 coach branch supervisors on escalations | B5, C7, D3, E3 | |
| F5 work with digital teams on self-service journeys | A7, C8, D1, D5 | |
| F6 4+ years in financial-services customer operations | A1 | |
| F7 experience handling regulated complaints | H2, D4 | |
| F8 confident presenting to senior leaders | B2, B4, B6 | |
| F9 comfortable with Excel reporting | H1 | |

---

# Round 1 — the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | A friendly opening; logistics asked casually; motivation | High: a recruiter screen prior, and 30 minutes leaves room for the biography and four logistics items | A 90-second arc built from your own sentences; treat every casual question as scored; give the same reasons you will give later |
| Skeptic, light | Knockout-style checks on the contact-centre and senior-presenting lines | Medium: the JD names both and your own sentence states both limits | One plain acknowledgment and one plan each, then stop |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in order, using only what the three sentences state: six years in retail banking with the last three as a branch supervisor; handling the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Say each at its own scope. Answer slot: why this role and why now is not in your material, so give your actual reason in your own words, and make it the one you will give in rounds 2 and 3 | F6 is the evidence the 4+ years line scores, and a recruiter opens on the biography; JD because it scores a stated requirement, EXP in delivery. F1 and F3 supply the beats |
| A2 | "What do you know about where Ashgrove is heading, and what draws you to this role?" | CO | [grounded] | Pick one item from the brief and say in your own words what it changes for how complaints reach the process, for example the brief's "move 40% of member service to digital channels by 2028", rather than reciting all four. Then give your own reason for the role. Add no inside knowledge of Ashgrove | A recruiter tests homework and motivation together; the brief you were sent is the grounded source. D1, D5 and E1 build on the same items |
| A3 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: give your own number in your own words, or ask for the role's band first. Your material states no figure, so the pack supplies none. If asked what you earn now, you may redirect to the role's band without giving a figure | The recruiter row of the persona model puts pay in a screen; JD because it scores the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | As A3 |
| A5 | "Where are you based, and does the role's location work for you?" | JD | [generic] | Logistics slot: say where you can work and how often, in your own words. Your material states no location or constraint | As A3 |
| A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words. It has to be true, and the same in all three rounds | Reason for leaving is the screen's consistency check; EXP because it tests your own account |
| A7 | "Tell me about any work you've done with digital or self-service channels." | JD | [grounded] | No quote of yours carries digital work, so this is a selection scaffold: pick work where a member used something themselves and one named piece was yours. If no such work comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 is silent in your material and the JD names it; asked casually, it is still scored |
| B1 | "The role covers the contact centre as well as the branches, and I don't see contact-centre experience in your background. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly first: "I haven't worked in a contact centre." Then a plan in your own words for how you would learn it in the first weeks. Say nothing about how contact centres run. Keep it to about a minute: a short honest answer ends a knockout-style check | F2 meets the recruiter first, and a flat answer here sets up the deeper probe at B3 |
| B2 | "This role presents to senior leaders. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I haven't presented to anyone above regional level." Then, in your own words, how you would prepare for a first senior audience, as a plan | F8 is the second stated limit; B6 rehearses it in depth for round 2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1.1 | "What happens after the panel round, and when would you expect to decide?" | Shows you are planning the next step, and tells you how long to hold your other options |
| RQ1.2 | "For the 20-minute escalation case, is the scenario given in advance or live, and should I bring anything?" | The case format decides how you prepare D4; asking it signals you are preparing |
| RQ1.3 | "Which of the four values do candidates find hardest to show in an interview?" | Shows you read the values by name and points your round 3 stories |
| RQ1.4 | "How does the contact centre connect to this role day to day?" | Meets the contact-centre limit head-on with curiosity rather than defence |
| RQ1.5 | "Is there anything in my background you'd like me to address before I meet the Head of Member Services?" | Hands you the chance to raise the gaps first and hear what the recruiter will report |

---

# Round 2 — the Head of Member Services (45 minutes, mostly behavioural)

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts, STAR-shaped | High: the recruiter calls this round mostly behavioural | A story for each prompt where a quote carries one, a scaffold ending in the honest branch where none does; "we" for context, "I" for your part |
| Skeptic | Quiet probing of the contact-centre and presenting gaps | High: the hiring-manager prior, and both limits are in your own sentence | Rehearse B3 until it is boring; concede the gap in one plain sentence and hold what your sentences carry |
| Case / Strategist | Live problems on the role: reporting, digital | Low in this round: the hiring-manager prior is case-heavy, but the round is called behavioural | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | Reads the background line by line | Low: it comes as follow-ups to H1 and H2 | Know what you can and cannot say about what the spreadsheet counted, and say plainly where you do not know |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "The role owns complaints across branches and the contact centre, and I don't see contact-centre experience in your background. What makes you the right person for it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Three beats. Concede first and exactly: "I haven't worked in a contact centre." Hold only what your sentence carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then a plan in your own words for what you would learn first and from whom. Follow-ups, and hold through each: "What do you think is different about complaints in a contact centre?" — say what you do not know, plainly, and claim nothing about how one runs. "Why not hire someone from a contact centre?" — return to the held sentence and the plan; never widen the sentence. "What would you do in week one?" — your own list, said as a plan. End on your own first step, not a promise of results | F2 is the one gap you stated and the JD names it, so this objection will arrive in some form in every round; a rehearsed, non-defensive answer changes the interview. JD because it scores the stated requirement; Skeptic delivery |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the true one and name it plainly. Your own sentence states two limits, contact-centre work and presenting above regional level, and either is an honest answer. Say which, then what you would do about it, as a plan in your own words. Do not name a weakness for tactical effect | F2 and F8 are the limits you stated; a Skeptic stem with JD content |
| B5 | "Training new tellers on an escalation script isn't the same as coaching supervisors on escalations. What would be different for you?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "6 years in retail banking, the last 3 as a branch supervisor" | Hold the sentence: you trained new tellers on the escalation script, and you have been a branch supervisor for the last 3 of 6 years in retail banking. Concede the difference in the interviewer's own terms: tellers and supervisors are different audiences. Answer slot: if any of that training reached people beyond new tellers, say who and what part was yours; if it did not, say so plainly and stay with the tellers. Then, as a plan, how you would start with supervisors | F4 is a transferable bridge with a stated limit; the concession is the credibility. JD content, Skeptic delivery |
| B6 | "You haven't presented above regional level. How will you get ready for senior audiences?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I built the monthly complaints spreadsheet our regional manager uses." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan in your own words: what you would prepare and who you would rehearse with. The JD pairs monthly reporting with presenting to senior leaders, so if you mention your own work, keep to "I built the monthly complaints spreadsheet our regional manager uses." | F8; the plan is what is scored, not the past. JD because it scores a stated requirement |
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end; use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your material carries no such time, so the pack writes none | A standard behavioural prompt for a manager round; scaffold because no sentence of yours carries it |
| C2 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | Selection scaffold: pick a decision where the member's need and the easy internal answer differed; name what the metric was, what you decided, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The prompt maps to Members First, so it is likely in both round 2 and round 3; scaffold because no quote carries a decision |
| C7 | "Tell me about a time you helped someone handle an escalation better." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The story has the beats the sentence states: new tellers, the escalation script, you training them; tell it in your own words at that scope. Answer slot: the JD's supervisors line makes a probe on what changed afterwards likely. If you saw a change, say what and what part was yours; if you did not, say so plainly and stay with the training | F4 is the only row where a quote carries a coaching-shaped story; JD content, behavioural delivery |
| C8 | "Tell me about a time you worked with a team outside your own to fix something for members." | JD | [grounded] | Selection scaffold: pick a fix that crossed a team line, with a named piece that was yours and a result a member would notice. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 is silent in your material; this is the behavioural form of the JD's digital-teams line |
| D1 | "Ashgrove wants 40% of member service on digital channels by 2028. Where do complaints fit in that?" | CO | [grounded] | A case, so structure aloud. Clarify first: what counts as a complaint when it arrives in the app or through the contact centre, and what the 40% covers. Then objective, the channels complaints can arrive through, approach, what you would measure (the JD's own volumes and resolution times), and risks. Challenge one premise respectfully. Use the brief's own words, and make no claim about your own digital work | The one strategy item that touches the role most directly, from the brief; F5 is thin, so this rehearses digital as thinking rather than experience |
| D2 | "What would you put in a monthly report to me on complaint volumes and resolution times?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | A live problem about your future manager's own need. Ask first who reads it and what they decide from it; then what you would show, how you would split it, and what you would flag. Keep it to a page. If you mention your own sheet, keep to the sentence | F3 is the reporting requirement; CASE delivery on JD content, and it asks nothing about your past |
| H1 | "Walk me through the monthly complaints spreadsheet you built that your regional manager uses." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Describe it in the sentence's own terms: you built it, it is monthly, it is about complaints, your regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel, so expect probes on all three. If it counted either measure, say which and how it was counted; if it counted neither, say so plainly and say what you would add. Name the tool you built it in, in your own words | F3 and F9; the one artifact you built, so it will be probed. EXP in delivery, JD in content |
| H2 | "What did handling the branch's formal complaints log involve?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Tell it at the sentence's scope: you handled the branch's formal complaints log. Answer slot: the JD asks for regulated complaints, so expect a probe on what rules the log ran to. If it was kept to rules set outside your branch, say which and what you did under them; if it was not, say so plainly and stay with the log. If handling it included steps beyond the log itself, say which were yours; if not, say so plainly | F1 and F7; the manager reads the background closely. EXP in delivery |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ2.1 | "What would a good first ninety days look like for this role?" | Lets your future manager describe the job's real first priorities, and shows you plan |
| RQ2.2 | "What does the monthly complaints report look like today, and who reads it?" | Ties to the JD's reporting line and surfaces the baseline you would inherit |
| RQ2.3 | "Where do escalations from branch supervisors tend to get stuck?" | Shows a coaching mindset and finds the problem you would own |
| RQ2.4 | "As more member service moves to digital by 2028, which complaints do you expect to stay with people?" | Grounded in the brief and shows you think about the digital shift from the member's side |
| RQ2.5 | "What support would I have on the contact-centre side while I learn it?" | Turns the stated limit into a plan, which is how B3 should end |

---

# Round 3 — the panel of two branch managers (60 minutes, including a 20-minute case; also the values round)

The panel scores against the four values, so this round carries the values cheat sheet. Neither panellist is named yet. The persona weights assume the two will work alongside the role.

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One prompt per value, scored against the published wording | High: the recruiter says the panel scores against the four values | A mapped story where a quote carries one, a scaffold ending in the honest branch where none does |
| Case / Strategist | The 20-minute escalation case and its variants | High: the recruiter names the case | Clarify first, one named owner, plain words to the member, one premise challenged |
| Peer Evaluator | Where the role meets a branch; what you would ask of supervisors | Medium: branch managers sit beside the role's work, which is an inference from the panel's composition | Propose principles for the seam rather than pretending to know it; lead with what you would do for them |
| Pressure | A time-boxed or challenging turn on your own account | Low: a panel of peers is not the usual home for it, but one challenge is plausible | Pause, restate, hold the sentence, concede one specific thing |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a decision where the member's side and the easy side differed; name what you decided, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack maps no story because no quote carries a decision | Members First, from the published values; F1 is the nearest evidence but carries no decision |
| C4 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a moment where what was said or written did not land the first time, and name what you changed so it would. Your sentence says you trained tellers on the script, not that you wrote it, so do not say you wrote it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words; the value's own wording makes this likely, and F1 carries training, not wording |
| C5 | "Tell me about a time you thought about your branch's town and not only its numbers." | VAL | [grounded] | Selection scaffold: pick a moment where the place, not the figure, shaped what you did, with a named result for someone local. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers; likely sharpened by the brief's branch consolidation (E1) |
| C6 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold: pick a problem you found, with the stretch where it stayed yours and the point it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not stretch the log you handled into a fix you owned | Own the Fix; the JD's "own" language makes it doubly likely |
| D3 | "A branch supervisor keeps escalating the same kind of complaint badly. How do you coach them?" | CASE | [generic] | Structure aloud: ask what "badly" means first (the route, missing facts, timing, the member's wording), look at a real example with them, agree one change, check back. Use plain words, since the panel scores them. No claim about your past | F4; a live problem that asks nothing about your history |
| D4 | "Here is a case. A member's formal complaint has been escalated twice. The branch says the contact centre holds it, and the contact centre says the branch does. You have twenty minutes: what do you do?" | CASE | [grounded] | The panel's 20-minute case, so rehearse a structure, not a story. Clarify aloud: who holds the complaint right now, what the member has been told and when, whether any time limit is running on it, what the member wants. Then the objective; the immediate step, one named owner today; who needs telling, in plain words; what you would record; what you would change so it does not recur. Challenge one premise respectfully. Make no claim about your past, and where you do not know how the contact centre works, say you would ask | F1 and F2; the recruiter names this case. The structure also demonstrates Own the Fix and Plain Words in action |
| D5 | "Same complaint, but the member first raised it in the app and nobody in a branch has seen it. What changes?" | CASE | [grounded] | Use the same structure: where it enters, who sees it first, how quickly, what the member is told, who owns it. Stay with reasoning and say where you would check rather than assume. Make no claim about digital work of your own | F5 and the brief's digital target; the brief names app-only banks as the main pressure, so a variant through the app is likely |
| E1 | "Eight branches are becoming five hubs over 2027, and every branch is part of its town. What does the person who owns complaints owe a town whose branch is closing?" | CO | [grounded] | Open on the member's side, not the numbers. Say what you would ask first: which towns, what members use now, what they would lose. Then what the complaints process can signal during the change, by branch, in the JD's own terms of volumes and resolution times. Neither defend nor criticise the decision | The brief's consolidation plus the Neighbours value, put to the people it touches. The panel is branch managers by the recruiter's email; that it touches their branches is a reading of the brief |
| E2 | "Where's the seam between you and a branch manager when a complaint goes badly, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map you cannot know: the complaint has one owner at a time, the branch keeps the relationship with its town, and the member's outcome comes before who is right. Say how you would settle a disagreement in plain words. If a time with a colleague comes to mind where you disagreed and it held, tell it; if none comes to mind, say so plainly, then how you would handle it | The Peer Evaluator's seam stem; F1's "end to end" reaches into the branches |
| E3 | "What would you ask of our supervisors, and what would you do for them?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Reciprocity: lead with what you would do for them, as a plan, then what you would ask. You may say you have been a branch supervisor, in the sentence's words, but add no account of what supervisors want | F4; the Peer Evaluator scores whether the hire adds to or reduces their load |
| G1 | "That formal complaints log — how much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, restate, hold: "I handled the branch's formal complaints log." Then concede specifically. Answer slot: if some of the log's handling was shared or belonged to someone else, say which, plainly; if all of it was yours, say that. Hold through two follow-ups by returning to the sentence, never by adding to it | The Pressure stem aimed at F1 and F7; EXP because it tests attribution |
| G2 | "Sixty seconds: why should a branch manager trust you with their hardest escalations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "Never worked in a contact centre, and I've never presented to anyone above regional level." | Three beats inside a minute: what you have, in the sentences' words; what you have not, in one plain sentence: "I haven't worked in a contact centre."; and your first step, as a plan. Hold through two follow-ups; concede one specific limit, never the core sentence | F2, F4 and F6 together; a panel of branch managers may press on trust, and B3 returns here in collegial packaging |

## Values cheat sheet

Value names and wording are from the page you copied this morning from ashgrovecu.org/about/values.

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No story mapped: no quote carries a decision from the member's side. F1 is the nearest, and it says "I handled the branch's formal complaints log and trained new tellers on our escalation script." Selection scaffold: pick a decision where the member's side and the easy side differed, with its cost and its ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Practice with C3 and C2 |
| Plain Words | If a member needs something explained twice, the writing failed, not the member | No story mapped. F1 says "I handled the branch's formal complaints log and trained new tellers on our escalation script." — training on a script, not wording. Selection scaffold: pick a moment where what was said or written did not land the first time, and what you changed. If none comes to mind, say so plainly, then the nearest thing your material does carry, or how you would handle it. Practice with C4 |
| Neighbours, Not Numbers | Every branch belongs to its town | No story mapped: no quote speaks to a town. Selection scaffold: pick a moment where the place, not the figure, shaped what you did, with a named result for someone local. If none comes to mind, say so plainly, then the nearest thing your material does carry, or how you would handle it. Practice with C5 and E1 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No story mapped: F1 says "I handled the branch's formal complaints log and trained new tellers on our escalation script." — a log handled, not a fix owned. Selection scaffold: pick a problem you found, the stretch where it stayed yours and the point it was solved. If none comes to mind, say so plainly, then the nearest thing your material does carry, or how you would handle it. Practice with C6 and D4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ3.1 | "What could a new person in this role do in the first month that would genuinely help your branch?" | Reciprocity: shows what you bring the panel's side, not only what you need |
| RQ3.2 | "How do you want to hear about a complaint that touches your branch?" | Plain Words and Neighbours in practice; it gives you the supervisor-side preference to design around |
| RQ3.3 | "With eight branches moving into five hubs over 2027, how do you see complaints being handled through the change?" | Grounded in the brief; shows you think about towns, not only totals |
| RQ3.4 | "Which of the four values do you see people find hardest to live day to day?" | Shows you took the values seriously, and points your last-minute emphasis |
| RQ3.5 | "Where do escalations tend to get stuck between a branch and the contact centre today?" | Maps straight to the case in D4 and to the problem you would own |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the branch's log, not the process end to end. H2's slot stays inside the log |
| Has worked in a contact centre, or across branches and the contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script. B5's slot stays inside that training |
| Reported complaint volumes and resolution times monthly | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material says the sheet, not what it counted. H1's slot asks only what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says a formal log, not rules it ran to. H2's slot asks which rules, if any |
| Built the reporting in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. H1's slot asks which tool |

## Sources

Provided documents: the JD; the four values, copied on 20 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the 2026 strategy brief Ashgrove published in July 2026, as sent by the recruiter; your background note. No `tuesday-dossier.md` was present. No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet: the page you copied this morning supplies the four value names and wording |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email fixes three sessions, who runs each, and which is the values round |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO and CASE questions: the July 2026 brief you sent supplies current priorities |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been named, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Two or three specific complaints you handled, a line each: what the member raised, what you did, how it ended → C3 to C6 move from scaffolds to mapped stories, and F1, F7 and G1 answers rest on your own sentences
- The monthly complaints spreadsheet, as a redacted copy or just its column headings → F3 and F9 move from discovery toward inspected, and H1's slots are answered from your own sheet
- Which rules or time limits the formal complaints log was kept to, if any → F7 moves from discovery, and H2 gets a real answer
- Any work with a digital, app or web team, however small → F5 moves from silent, and A7, C8, D1 and D5 get a story to draw on
- Anything you presented at regional level or below: to whom, and how → F8 gets a real boundary, and B6 and B2 gain a held sentence
- Your own pay, notice, location and reason for leaving, in your words → A3 to A6 fill their logistics slots with your own sentences, quoted
- The round 2 and round 3 interviewers' names and roles, once assigned → an interviewer read, reweighted personas, and reverse questions tied to their paths
- The recruiter's answer on the case format, in one email → D4 and D5 take the shape the panel actually uses
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, run only on your say-so) → public interviewer footprint once names exist, reports on loops for this role family, and recent organisational context; the strategy brief is already in hand
- A `tuesday-dossier.md` from an earlier role check → verified evidence, a prohibited-claims list and a named top objection in place of the ones this pack inferred
