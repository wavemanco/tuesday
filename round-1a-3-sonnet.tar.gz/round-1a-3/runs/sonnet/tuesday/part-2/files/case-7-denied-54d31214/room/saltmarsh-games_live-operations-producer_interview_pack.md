# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio, about 350 people)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. The title comes from your message.
- **Format:** one 60-minute interview, session mode.
- **Built on this assumption:** a hiring-manager conversation. Your note did not say whether Tobias would be your future manager, someone above them, or one of a panel, so the persona weights below follow the hiring-manager pattern. If that is wrong, the weights change.
- **Candidate:** Femi.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and ways of working, not generic virtue |
| EXP | Whether the claims in your background survive follow-up questions, and what was actually you |
| JD | Whether you can do the listed job, including the parts your material is thin on |
| CO | Company and strategy knowledge. None in this pack, because no research ran (see Sources) |
| CASE | A live problem from the role, scored on structure and reasoning |

Three things to know before you rehearse:

- **Answer slots.** Where guidance says "answer slot", it is an instruction for the interview, not a question for now. Both branches are honest: say how you did it, or say plainly it was not yours or did not exist, and return to what your sentences do say.
- **Provenance.** Each row carries one label: `[grounded]` rests on your words or the JD, `[inferred]` is derived and the derivation is named, `[generic]` is a role-family pattern that makes no claim about you or about Saltmarsh. Where guidance says something about your past, your own sentence sits beside the label.
- **IDs.** Fit rows are F1 to F8. Question IDs run A to E, then G and H. The letter F is skipped so it never collides with a fit row.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says the weekly content-drop calendar for your main title. It does not say live events or a second title, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two of our mobile titles" makes a probe on running more than one calendar likely. If you ever ran or overlapped a calendar for a second title, say how, in your own words; if you did not, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | Your sentences touch the calendar and say you never led a team. None says which teams you worked with on the drops. The JD's verb is coordinate, and the pack does not merge it with leading. Answer slot: the JD names four teams, so expect a probe on each. For each of design, art, engineering and community, if you worked with it on the drops, say how, in your own words; if you did not, say so plainly and stay with "I ran the weekly content-drop calendar for our main title for the last two years." If leadership comes up, the plain acknowledgment is "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | medium | [grounded] | transferability | Your material says you presented retention numbers monthly. It does not say you ran event reviews or chose what the KPIs were, and the words stay there: "I presented the monthly retention numbers to the studio head." The JD does not say which KPIs the review reports. Your message says you have not worked on a game with in-app purchases, and the plain acknowledgment is "I haven't worked on a game with in-app purchases." Answer slot: the JD's "own the post-event review and the KPIs it reports" makes a probe on who chose what those numbers measured likely. If any of that was yours to choose, say which and how you decided, in your own words; if it was set by others, or there was no such step, say so plainly and stay with presenting the numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your sentence says you wrote the checklist and that your QA team still uses it. The JD's verb is manage. Words: "I wrote the release checklist our QA team still uses." Answer slot: expect a probe on how a release runs against it. If you ran releases against it with QA, say how, in your own words; if that was QA's or someone else's, or there was no such step, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | The posting's term is live-service. Your sentences say associate producer at a puzzle-game studio and the weekly content-drop calendar, and the pack does not say live-service for you. A years requirement is graded like any other row, and four years is read against three. Words that reword only those sentences: "I've spent four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for our main title." Keep "associate" |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the calendar in the quote's own terms: you ran it, weekly, for your main title, for the last two years. A named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on what the line says, with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you presented the monthly retention numbers to the studio head. The line says presented, so the words stay at presenting and do not become built, owned or analysed |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist your QA team still uses touches written communication, but nothing in your material shows how clear it is, and the pack does not say it is. Words: "I wrote the release checklist our QA team still uses." Answer slot: expect a request for a sample or a walk through a document. If you can say why your team still uses it, say so in your own words; if you cannot, say so plainly and stay with the fact that you wrote it |

## 3. Persona table

Weights follow the hiring-manager assumption, adjusted by what the JD and your sentences put in play. No interviewer profile was available, so there is no interviewer-signal adjustment. Your own words establish one session; no loop source was read, and no values-style round is established.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems from the role: build a calendar, diagnose an event, break a tie between teams | high | Hiring-manager prior puts it first; the JD's duties (calendar, update coordination, release checklist) are decisions that can be set as live problems | Clarify, objective, constraints, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic | Quiet, persistent probing of the gaps: in-app purchases, two titles instead of one, which teams you worked with | high | Hiring-manager prior puts it second; F1, F2 and F3 are where the JD outruns your sentences | Rehearse the most predictable objection until it is boring; use only the adjacent facts you stated; add a ramp plan; do not bluff what the interviewer owns |
| Data-Driven Prober | Reads your lines closely and asks how the retention numbers were counted | medium | The JD names retention metrics and KPIs, and F7 is a reporting line a prober can open | Say plainly what you know and do not know about how the numbers were counted; name the assumption you would defend least before they do |
| Conversational / Rapport Builder | "Walk me through the journey", casual questions about what you play | medium | A one-hour conversation has an opening, and casual questions are still scored | A 90-second arc built from your own sentences; treat casual questions as scored |
| Peer Evaluator | Where your job ends and design's or engineering's begins; how credit is shared | low | The assumption is that Tobias is not a peer, but the JD names four teams, so seam questions can come from any interviewer | Offer seam principles instead of pretending to know the seam; say what the calendar gives each team |
| Pressure / Stress | Time-boxed "why you", "how much was actually you" | low | The material shows no skip-level or executive signal. If Tobias sits above your manager, this rises | Pause, restate, hold through two follow-ups, concede specifically, never fold the core claim |
| Values / Behavioral | Scenario prompts about unpopular truths and putting players first | low | No values page was read and no values-style round is established, so these draw on common stems only | Pick a real instance or say plainly none comes to mind; "we" for context, "I" for contribution |

## 4. Question banks

Highest-ROI prep in this pack: **B1**, the in-app-purchases question. It is the one question most likely to arrive in some form, and the one most tempting to bluff.

### A. Case / Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We run two titles and each needs a live event next month. Walk me through how you'd build the calendar for both." | CASE | [generic] | Clarify first: each title's current cadence, which teams are free when, what each event is for. Then the objective, the constraints (what design, art, engineering and community each need, and by when), sequencing so the two titles do not draw on the same team in the same week, how success is measured, and what you would cut first. Think aloud and challenge one premise, for example whether both titles need an event in the same month. The question asks about no past, so the guidance makes none | F1 is the requirement this tests. CASE because the JD's first duty is the calendar, asked as a live problem; F1's limit means a plan serves better here than a claim |
| A2 | "A weekend event misses its day-two retention target. What do you look at first, and what do you do on Monday?" | CASE | [generic] | Clarify the target, the baseline and which players are in the number. Separate a technical fault from a content or timing problem. Decide whether to hold, adjust or stop, say what you would tell the teams and what you would not yet claim, and note what goes into the post-event review. Name the assumption in your diagnosis you would defend least before they do. No claim about your past | F3 and F7 are the requirements. CASE for the live diagnosis; the weakest-assumption move is the bar for any metric answer |
| A3 | "Thursday's update is announced. Engineering says it won't clear QA until Friday. Art is finished and community has told players. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify what fails and how badly. Lay out the options (slip, cut scope, stage the release), who must hear what and when, how the release checklist would inform the call, and what you would record for the review. One anchor clause is allowed and stays at its own scope: "I wrote the release checklist our QA team still uses." Do not add that you ran releases against it; that belongs to B4's answer slot | F4 is the evidence for the QA duty. CASE because the JD's release duty is asked as a live decision |
| A4 | "Next quarter we want a second kind of live event without more headcount. How do you decide what the calendar can carry?" | CASE | [generic] | Capacity per team per week, the cost of each event type, whether players tire of the cadence, what you would stop to make room, how you would test before committing, and how you would measure it. No claim about your past | F1 and F2: calendar capacity is where the coordination limits show. CASE because it is a decision under constraint |
| A5 | "Design wants the event bigger, community wants it earlier, engineering wants it later. How do you break the tie?" | CASE | [generic] | Restate the three asks, find the real constraint behind each, name what the date protects, offer options each side can accept, and propose a decision rule: who decides and by when. Propose the rule instead of claiming to know how Saltmarsh settles it. Tell all three the reasoning. No claim about your past | F2 is a row where the material is silent, so a plan is the honest form here. CASE because it tests structure under competing asks |

### B. Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases anywhere in your background. If our event reviews report revenue-side KPIs, what's your plan for the first month?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment, once and without apology: "I haven't worked on a game with in-app purchases." Then the adjacent fact at its own scope: "I presented the monthly retention numbers to the studio head." That is retention, not revenue, and it should not be stretched. Then a plan, not a history: what you would ask first (which KPIs the reviews report, how each is defined, who owns each data source), who you would learn from, and what you would not do alone before you understood it. If pressed on how a revenue figure is counted, say plainly that you do not know yet. Hold through two follow-ups by returning to what you know and the plan, never by adding experience | F3 is where the gap and the JD's KPI duty meet, so this probe arrives in some form. JD because it scores a stated duty; Skeptic because it goes straight at the gap |
| B2 | "You described running the calendar for your main title. We'd have you on two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "two of our mobile titles" makes a probe on running more than one calendar likely. If you ever ran or overlapped a calendar for a second title, say how, in your own words; if you did not, say so plainly and stay with the main title's calendar. Then say what would change as a plan: you would map each title's cadence, team capacity and overlaps first, and say what you do not yet know | F1's limit is the most direct place the JD's scope outruns the material. JD because it scores the stated scope |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] | Pick one requirement and say why it is your weakest, in your own words. This pack reads F2 and F3 as the rows where your sentences are thinnest, so either is an honest choice; pick another if you would honestly pick another. Name it, say what you would do about it in your first thirty days, and stop. A weakness named with a plan reads as judgment; a weakness defended reads as a bluff. The guidance makes no claim about your past | Derived from the fit snapshot: F2 and F3 carry the thinnest evidence. JD because it scores honest self-assessment against the listed duties |
| B4 | "You wrote the release checklist your QA team still uses. Walk me through how a release runs against it." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what the quote carries: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage the release checklist with QA" makes a probe on how a release runs against it likely. If you ran releases against it with QA, say how, in your own words; if that was QA's or someone else's, or there was no such step, say so plainly and stay with the checklist you wrote. Do not say what the checklist proves about you; describe it and let the interviewer draw the inference | F4 is your strongest-sounding line and the likeliest place for a how-did-it-actually-run follow-up. EXP because it tests what was actually yours |
| B5 | "Four teams feed every update: design, art, engineering and community. Which of them have you worked with directly, and which haven't you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Start from the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: for each of the four teams, if you worked with it on the drops, say how, in your own words; if you did not, say so plainly. If asked whether you led them: "I haven't led a team." Then how you would get close to the team you have not worked with | F2 is the row the material is silent on, so this question lands on a blank. EXP because it tests what was actually yours; the JD's verb is coordinate, and the answer should not drift to lead |

### C. Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. What were they measuring?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what the quote carries: "I presented the monthly retention numbers to the studio head." Answer slot: say which retention measures you presented and how they were counted, in your own words, and name the assumption behind them you would defend least. Say which part was yours; if you did not build the numbers, or you do not know how they were counted, say so plainly and stay with presenting them | F7 is a reporting line a prober can open, and the defend-the-number rehearsal is precise attribution. EXP because it tests what survives a second question |
| C2 | "How would you separate an event's effect on retention from everything else that changed that week?" | JD | [generic] | Clarify the cohort and the baseline. List what else moved that week (a release, a promotion, a holiday, a bug). Compare like with like where you can, and say what you cannot isolate. State the assumption you would defend least, and what you would want to know before saying an event caused a change. No claim about your past | F3 and F7 are the requirements. JD because it scores the stated duty to own the KPIs a review reports |
| C3 | "The post-event review reports KPIs. Which would you put in it, and which would you leave out?" | JD | [generic] | Choose a small set tied to the event's stated goal, say what each is for, and name one you would leave out and why. Say you would first ask what the studio already tracks and who defines each measure. If revenue measures come up, the honest line is the acknowledgment in B1. The guidance makes no claim about your past | F3 is the requirement. JD because the review and its KPIs are named in the JD |

### D. Conversational / Rapport Builder (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are your own sentences at their own scope, in this order: four years as an associate producer at a puzzle-game studio; the last two years running the weekly content-drop calendar for your main title; writing the release checklist your QA team still uses; presenting the monthly retention numbers to the studio head. Last beat, answer slot: say in your own words why live operations at this studio; if the reason is still forming, say what you are looking for next. Add no titles, teams or results your sentences do not carry | F5 to F7 supply the arc. EXP because the interviewer is reading your background; Conversational delivery |
| D2 | "What mobile games are you playing right now, and what do you notice about how they run their events?" | JD | [generic] | Pick one or two games you actually play and say one concrete thing you notice about how each runs its calendar or events. Say what you would borrow and what you would not. If you do not play mobile games, say so plainly and name the nearest thing you do follow. Do not name games you do not play | F1's requirement is a live-events calendar on mobile titles, and casual questions about it are still scored. JD content in a casual register |
| D3 | "Each update needs a brief that four teams can act on. How do you write one?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: what is changing and why, what each team must deliver and by when, what is decided and what is open, who decides, and where questions go. One anchor clause stays at its own scope: "I wrote the release checklist our QA team still uses." Do not describe it as a brief or as cross-team | F8 is the written-communication requirement and F2 the four teams. JD because both are stated duties |

### E. Peer Evaluator (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design and engineering will each have an opinion about your calendar. Where does your job end and theirs begin?" | JD | [generic] | Offer principles, not a map of a seam you have not seen: the calendar and its dates are the producer's to hold, content and build are the teams', and disagreements go to a named decider by a named time. Say what the calendar gives each team, such as predictability. Ask where Saltmarsh draws it today. No claim about your past | F2's duty is coordination, and this probes where it stops. JD because it scores a stated duty; Peer delivery |
| E2 | "How do you handle credit when an update spans several teams?" | VAL | [generic] | Selection scaffold: pick a time credit was shared across teams. It needs a named moment, what you did to share it, and how it landed. "We" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 again, from the side of working relationships. VAL because it tests behavior, not skill; the stem is a common peer probe |

### G. Pressure / Stress (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a producer who has run live events on a monetized mobile title?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, then hold. The position is only what your sentences carry: "I ran the weekly content-drop calendar for our main title for the last two years." and "I wrote the release checklist our QA team still uses." Hold through two follow-ups by returning to those two facts, never by adding to them. Concede once, specifically, and give the plan: "I haven't worked on a game with in-app purchases." Do not argue the other producer is worse | F1 and F4 are the position held; F3's limit is what gets conceded. EXP because it tests composure and honest self-assessment |
| G2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause. Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours alone and which you shared with other teams, in your own words; if any part was set by someone else, say so plainly. Hold through two follow-ups, then concede the specific parts that were not yours. "We" for context, "I" for contribution | F1 is the claim being tested. EXP because it probes attribution |

### H. Values / Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time you gave leadership a number or a call they did not want. It needs a named stake, a moment you did not fold, and an intact relationship afterward. Your material carries only the setting, "I presented the monthly retention numbers to the studio head", not an unpopular message, so do not supply one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7's setting is the nearest fit and shows no unpopular message. VAL because the stem tests the hard truth landing |
| H2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where what was good for players cost something internal, such as a date or a number. It needs the stake, the call you made, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3's KPI duty is where players and metrics can pull apart. VAL because it tests the choice, not the slogan |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A4, B2, D2, G2 |
| "coordinate design, art, engineering and community teams on each update" | A5, B5, D3, E1, E2 |
| "own the post-event review and the KPIs it reports" | A2, B1, C2, C3, H2 |
| "manage the release checklist with QA" | A3, B4 |
| "3+ years producing live-service games or apps" | B2, D1, G1 |
| "experience running a content calendar" | A1, B2, G2 |
| "comfortable with player-retention metrics" | A2, C1, C2 |
| "clear written communication" | D3 |

## 5. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do the two titles' calendars overlap today, and where do the teams collide most?" | It asks him for the real constraint behind the JD's two-title duty, and it shows you are already thinking about capacity |
| 2 | "When an event misses, what does the post-event review look like here: who is in the room, and what changes afterward?" | It asks about the review the JD hands the role, and invites a concrete answer instead of a description of the process on paper |
| 3 | "Which KPIs does the team treat as the ones an event is judged on, and who defines them?" | It gets you the definitions you would need to ramp on, and it is an honest question from someone who has said where their experience stops |
| 4 | "How does the release checklist work with QA today, and what would you want changed?" | It shows you read the QA duty as a working relationship, and it lets you hear what he would change before you propose anything |
| 5 | "Where do you see the producer's job ending and design's or engineering's job beginning on an update?" | It puts the seam question to the person who owns it, so you are not guessing at a seam you have not seen |
| 6 | "What have people new to this role found hardest in their first three months?" | It invites candor about the real ramp and signals you are planning one |

## 6. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says your main title and content drops, not two titles or live events. B2's slot stays inside the main title's calendar |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presenting numbers, not event reviews or choosing the KPIs. C1's slot asks only how the numbers were counted and which part was yours |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." The limit is the pack's observation: the material says wrote and still uses, not managing a release. B4's slot stays inside the checklist you wrote |
| Led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |

## 7. Sources

Provided documents: the job description text and your background as written in your message, and the interviewer's name and title from the same message. Nothing else was read.

Searches sent, all refused, so none returned a result:

- "Saltmarsh Games mobile studio values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed the values cheat sheet and the themes of the VAL questions. Without it, H1 and H2 use common stems only and no values section is included |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have named the rounds and set the persona weights from the company's loop. Without it, weights follow the hiring-manager assumption and your own account of one 60-minute session |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded at least one CO or CASE question in current strategy. Without it, the CASE bank is generic and no CO question is included |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have given an interviewer read, interviewer-signal adjustments to the persona weights, and a reverse question tied to his path. Without it, all three are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## 8. Upgrade menu

- How Tobias relates to the role (future manager, someone above them, or a panel) → reweights every bank; a skip-level reading raises Pressure and strategy-heavy Case questions
- Web search permission, so the four refused targets can run → values themes for the VAL questions, the company's documented loop, strategy-grounded CO and CASE questions, and an interviewer read with a reverse question tied to his path
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes), offered once → a strategy brief to ground the CASE bank, plus recent organization context
- A link to Tobias Wrenfield's public profile, talks or writing, if you have one → an interviewer read and persona signals without waiting for search
- Your own answers to the answer slots in F1, F2, F3 and F4, stated outside a drill → those rows become story maps in your own words instead of slots
- A redacted copy of the release checklist, a content calendar or a monthly retention deck → F4, F6 and F7 can move from medium toward high, and F8 gets something to point to
- The recruiter's prep email, or anything they said about what the hour will cover or what to bring → coverage of any focus area or deliverable
- How many hours you have before Friday → a prioritized prep schedule
- A tuesday-dossier.md from an earlier evidence review → verified evidence and any claims already ruled out, so this pack could be built against them
