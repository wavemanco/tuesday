# Interview prep pack: Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Mode: loop, one shared fit snapshot and three mini-packs. Built from the role description and background in your message only; no outside research ran.

| Round | Who | Length | What it is |
|---|---|---|---|
| 1 (Tuesday) | Director of Engineering, the hiring manager and your would-be boss | 45 min | Hiring-manager round |
| 2 (the Thursday after) | Two staff engineers and a product manager | 60 min | Panel |
| 3 (the following Monday) | VP Engineering | 30 min | Described by the recruiter as "values and leadership philosophy" |

The rounds, who runs them and what each holds come from your message, which is the loop source. No interviewer names were given.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores.
- Type key: VAL is behavioral or values alignment. EXP is a work-experience deep-dive. JD is role-driven, scoring a stated requirement including its gaps. CO is company and strategy knowledge. CASE is a live problem from the role.
- This pack has no CO questions, because company research did not run.
- Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question to you now: say what is true in your own words, and where the practice never existed or was not yours, say so plainly.
- Highest-ROI prep: A2. The same objection, that you have not owned a hardware-adjacent roadmap, returns as G1 on Thursday and K1 on Monday. Rehearse it until it is boring.
- Work in this order: A2, then G1 and K1, then C1 and G2 (the 60% figure), then the rest.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six, with nothing about two squads or eleven engineers, and the words stay at that scope: "Three of my nine years in engineering have been as a team lead of six." Answer slot: the two squads make a probe on the step from one team to two likely. Say what you did lead, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the team you led |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material says you pushed a reliability quarter through, not that you owned delivery across a roadmap, and the words stay there: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the "own delivery" line makes a probe on what was yours to decide likely. If any scope or timing decision was yours, say which and how you made it, in your own words; if there was no such decision, or it was not yours, say so plainly and stay with the quarter you pushed through |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a probe on it. Lead with the loop in the quote's own terms: you run it, for backend roles, and it was about 40 interviews last year. Your material says you run the loop, not who decides the hires or sets the loop's stages |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role description, your message | none given | none | [grounded] | discovery | Your material does not show anything on growing engineers, and the bridge should not be stretched. Answer slot: the growth line makes a probe likely. If you have helped an engineer grow, say what you did and what part was yours, in your own words; if there was no such case, or it was not yours, say so plainly and stay with the team you led |
| F5 | "partner with hardware and product on roadmap" (hardware) — role description, your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Words you may say, because you stated them: "I haven't owned a hardware-adjacent roadmap." That is ownership, so the partnering the role describes is the open part. Answer slot: if you have worked alongside a hardware team in any capacity, say how, in your own words; if you have not, or it was not yours, say so plainly and say what you would ask a hardware team first |
| F6 | "partner with hardware and product on roadmap" (product) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Derived from the phrase "roadmap pressure", read as a roadmap trade-off; your material does not say who applied the pressure or how it was settled. Answer slot: the partner-with-product line makes a probe likely. If the pressure came from product and you worked it out with them, say how, in your own words; if it came from elsewhere, or there was no such working-out, say so plainly and stay with the quarter you pushed through |
| F7 | "building device-management services" — role description, your message | none given | none | [grounded] | discovery | Your material says nothing on device management or on devices. Answer slot: the device-management line makes a probe on what you have built that resembles it likely. If anything you built resembles it, say what and how, in your own words; if nothing did, say so plainly and say what you would study first |

## Round 1 (Tuesday): Director of Engineering, hiring manager, 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the gaps and the why-this-move motive | High, 4 questions. Hiring-manager prior is Case/Strategist plus Skeptic, and your message states two limits (hardware roadmap, managing managers) that sit in F5 and F1. A2 is the pack's deepest rehearsal | Rehearse the single most predictable objection until it is boring; bridge only from what you stated; concede the limit in your own words and add a concrete ramp |
| Case/Strategist (B) | Live problems on the role's own roadmap | High, 4 questions. Same prior; the role description's squads, hardware partner and product partner give it material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Data-Driven Prober (C) | Reads the figures line by line | Mid, 2 questions. You gave two figures (60% and about 40 interviews) | Know how each figure was counted and say plainly when you do not; name the weakest assumption first |
| Conversational (D) | Friendly opener that is still scored | Low, 2 questions. Hiring-manager rounds usually open with the biography | A 90-second arc; treat casual questions about the role's headline topic as scored |
| Pressure, Peer, Values | Not banked in this round | Low here. Pressure appears in rounds 2 and 3, Peer in round 2, Values in round 3 | None needed for this round |

### Question bank

**A. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "I've never managed managers" | Pick one limit you have actually stated and say it plainly, in your own words, which were "never owned a hardware-adjacent roadmap". Then say how you would close it, as a plan and not a past. Name the managers limit only if the interviewer says leads sit between you and the engineers; your words were "I've never managed managers". Offer no limit you have not stated, and do not pad the answer to make the limit feel smaller | The Skeptic's standard opener, aimed at F5 and F1, the two rows where your material states a limit. JD because it scores the listed job |
| A2 | "This role partners with hardware on the roadmap, and your background is payments. How would you get up to speed on that partnership?" | JD | [grounded] "currently at a payments company"; "never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in this pack. Concede first, in your stated words: "I haven't owned a hardware-adjacent roadmap." Hold only what the quotes carry: "I pushed a reliability quarter through against roadmap pressure." Then give the ramp as a plan: name who you would sit with first and what you would ask them. Likely follow-ups, in order. One: whether you have worked alongside a hardware team at all; answer slot: if you have, say how, in your own words, and if not, or it was not yours, say so plainly and return to the ramp. Two: what you would ask first; that is your plan, stated as a plan. Three: what happens when hardware dates and your squads' dates conflict; structure it as B1 does. Claim no hardware partnership you did not state | F5 is where the role's hardware mandate presses hardest on your material, so this objection arrives in some form; JD because it scores a stated requirement and its gap |
| A3 | "You've led a team of six. What changes when you lead two squads?" | JD | [grounded] "3 as a team lead of 6"; "I've never managed managers" | Story-mapped on F1: three years and a team of six are the beats the quote states; tell them in your own words. Answer slot: expect a probe on what you would do differently across two squads; give your own view as a view, not as a past. If the squads turn out to have leads between you and the engineers and the interviewer probes it, your stated words are "I've never managed managers"; say so plainly. This pack does not know how the squads are structured | F1 is where the step from one team to two shows. JD because it scores the listed job |
| A4 | "Why the move from team lead to engineering manager, and why industrial IoT?" | JD | [generic] | Your reasons are yours and the pack supplies none. Pick the two you would give if nobody were listening, one about the manager role and one about this domain, and say each in a sentence. If you have no reason tied to the domain, say so plainly, then give the nearest thing your own material carries, or how you would learn the domain | The Skeptic's why-here, why-now probe, aimed at F1 and F7. JD because it scores fit with the listed job |

**B. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose the hardware team has a new device generation arriving next quarter and your two squads own device-management services. What do you need to know first, and how do you plan the quarter?" | CASE | [generic] | Clarify before you plan: what changes for the services when the devices change, who decides the date, what must not break, what a failed rollout would cost. Then objective, the segments of work, approach, metrics, risks. Challenge one premise politely. Think aloud and end with the first two decisions you would take. The question needs no claim about your past, so the guidance makes none | A live problem on the role's own seam (F5, F7) that a hiring manager can score without any claim about your past. CASE because it tests structure |
| B2 | "Product wants a feature this quarter and your reliability work competes for the same people. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure it: what each option is worth, what happens if each slips, who else belongs in the decision, what you would tell product and when. If asked whether you have faced this, your own words are the quote, "I pushed a reliability quarter through against roadmap pressure", and you stop there; the counting of the 60% is C1's. Add no incident or stakeholder the quote does not carry | F6 and F2 meet here: a trade-off the role description puts you in, with your one roadmap-pressure sentence as the only history. CASE because it is a decision problem |
| B3 | "A hardware lead and one of your staff engineers disagree about a device-facing interface change. How do you handle it?" | CASE | [generic] | Clarify what each wants and what each fears; separate the technical question from the question of who decides; set the decision criteria before the answer; say what you would record and when you would escalate. Make no claim about a past dispute | The partnership seam under strain (F5), asked as a decision. CASE because it scores reasoning, not recall |
| B4 | "On-call load across both squads is rising while headcount is flat. Diagnose it and tell me what you would do first." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Define the burden first, then segment it, form hypotheses, pick one first action and say how you would know it worked. If asked about your own experience, your words are the quote, "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; stop there, and keep how it was counted for C1 | A diagnose-the-metric case set where your only quoted history sits (F2). CASE because it tests structure before answer |

**C. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part of the result was yours. The quote says the burden dropped after you pushed the quarter through, so keep to "after" unless you can back more. If you do not know how it was counted, say so plainly. Name your weakest assumption before they do | F2's headline figure. EXP because probers test counting and attribution |
| C2 | "About 40 interviews last year. Walk me through that number and what part of the loop you run." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Same four slots: how the 40 was counted; what it is sensitive to; the assumption you would defend least; which interviews and which parts of the loop were yours. Lead with the loop in the quote's terms: you run it, for backend roles. If you do not know how it was counted, say so plainly. Do not turn "run" into who decides | F3's figure and the pack's cleanest evidence. EXP because it tests what was actually yours |

**D. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering"; "3 as a team lead of 6"; "currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc whose beats are the quotes: nine years in engineering; three of them as a team lead of six; now at a payments company; an on-call burden that dropped 60% after you pushed a reliability quarter through against roadmap pressure. "I" for what you did, "we" for context. Answer slot: the reason you want this move; say it in your own words, or say plainly that you have no short version yet. End on what you want next | The opener of any hiring-manager round; casual register, still scored. EXP because it tests a CV's story (F1, F2) |
| D2 | "What have you been reading or building lately that's closest to device management?" | JD | [generic] | Pick the nearest honest thing, something you read, built or tried, with one specific you can explain. If nothing comes to mind, say so plainly, then give the nearest thing your own material carries, or what you would study first. A casual question about the role's headline topic is still scored | A rapport-register probe of F7. JD because it scores the role's stated subject |

### Reverse questions for Tuesday

| # | Question | Why it lands |
|---|---|---|
| T1 | "What would you want the first 90 days to have produced for the two squads?" | He owns the answer, and it turns the day-one-weakness question into a shared plan |
| T2 | "Where do the hardware and software roadmaps collide most today, and who arbitrates?" | Maps the seam you named as your gap (F5) instead of avoiding it |
| T3 | "How are the 11 engineers split across the two squads, and are there leads between the squads and the manager?" | Settles the structure question that A3 and K1 hang on (F1) |
| T4 | "What does good delivery look like to you, and how do you want to hear about slippage?" | Tests how he wants you to own delivery (F2) |
| T5 | "What is the hardest part of this role that the description doesn't say?" | Invites candor and gives you the real shape of the job |

## Round 2 (the Thursday after): two staff engineers and a product manager, 60 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (E) | Depth checks on figures and technical judgment | Top, 4 questions. Panel rule: blend the top two personas of each member's relationship; the technical-specialist prior is Prober plus Pressure | Know how your figure was counted; name the weakest assumption first; defer to their judgment and say which questions you would put to them |
| Values/Behavioral (F) | Scenario probes, STAR-shaped | Mid, 2 questions. The cross-functional prior for the product manager is Values plus Conversational | "We" for context, "I" for contribution; a story where the hard truth landed, or say plainly that the material shows none |
| Pressure (G) | Challenges your motive and your share of a result | Low, 2 questions. Second half of the technical-specialist prior | Pause, restate, concede what is real, hold the rest through two follow-ups |
| Conversational (H) | Casual opener and casual follow-ups | Low, 2 questions. Second half of the cross-functional prior | A tuned 90-second arc; casual questions are still scored |
| Peer Evaluator (I) | Seam-splitting between product and engineering | Low, 2 questions. Not in the panel blend by the table; added because your role description's partner-with-product line makes seam questions plausible from the PM. Recalibrate if you know the PM's style | Reciprocity framing and seam principles, not a claimed seam |

### Question bank

**E. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which assumption behind your on-call number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name that assumption in your own words before they do. If you cannot name one, say plainly that you do not know how the figure holds up and what you would check. Supply no method, baseline or counting rule you did not use | The prober's two-levels-deeper follow-up on F2's figure. EXP because it tests attribution honesty |
| E2 | "Walk us through the reliability quarter you pushed through." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The story has only the beats the sentence states: a reliability quarter, roadmap pressure, and the on-call burden dropping 60% afterwards. Tell them in your own words at those scopes. Any beat beyond them is yours to add only if it is true; the pack supplies none | F2 is the one story your material carries, so the panel will open it. EXP because it tests what you actually did |
| E3 | "Suppose a service change reaches devices in the field and can't easily be undone. How would you want delivery and review to work for that kind of change?" | CASE | [generic] | Clarify what cannot be undone and how far a change reaches; state the objective; lay out options for exposure and review; name the risks and how you would know it worked. Defer to the staff engineers on the technical specifics and say which questions you would put to them. The guidance makes no claim about your past | A live problem at the edge of F7 and F2. CASE because it scores structure and humility about what you do not yet know |
| E4 | "How do you stay close enough to technical decisions to challenge them without second-guessing your staff engineers?" | JD | [generic] | Selection scaffold: pick a real moment you challenged a technical call, or deferred one; say what made it yours or theirs and that the relationship stayed intact. If no such moment comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | F1's two-squad lead role puts you between engineers who know the systems better than you. JD because it scores the listed job |

**F. Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you disagreed with a partner team about what to build first." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you held your position, an ending, and a relationship still intact. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The partner line (F6) asked as behavior. VAL because it scores conduct, not a published value; none was in hand |
| F2 | "When did you put a longer-term outcome ahead of a date or metric someone cared about?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2: the reliability quarter, the roadmap pressure, the burden dropping 60% afterwards; tell it at those scopes in your own words and let them draw the conclusion. The quote does not say who held the date or how it ended with them; the pack does not supply that | The story your quote carries best, asked in the panel's register (F2, F6). VAL because it scores behavior under pressure |

**G. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You haven't owned a hardware-adjacent roadmap. Why should the engineers you'd lead trust you with one?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold then concede. Pause, restate the question, and concede in your stated words: "I haven't owned a hardware-adjacent roadmap." Hold what the quote carries: "I pushed a reliability quarter through against roadmap pressure." Hold through two follow-ups by returning to that, never by adding to it. If you concede more, name it yourself and specifically. Do not fold on the core and do not invent a hardware story | A2's objection returned under time pressure (F5). JD because it scores a stated requirement and its gap |
| G2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold then concede. Hold what the sentence says, that the burden dropped after you pushed the quarter through. Answer slot: say which part of the result was yours, in your own words; if you cannot separate your part from the rest, or it was not yours, say so plainly. Concede that specifically, without folding on the claim | The attribution probe the pressure persona's stem names, aimed at F2. EXP because it tests candor about your share |

**H. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell us a bit about yourself and what drew you to Larkfield." | EXP | [grounded] "9 years engineering"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc for engineers: nine years in engineering; you run the backend hiring loop, about 40 interviews last year; the on-call burden that dropped 60% after you pushed a reliability quarter through against roadmap pressure. Answer slot: what drew you to Larkfield; give your own reasons. This pack holds no facts about Larkfield, so say only what you know first-hand or from the posting, and if nothing specific draws you, say so plainly and speak to the role description's squads, device-management services and hardware and product partnership | The opener, in the casual register that is still scored (F2, F3). EXP because it tests the CV's story |
| H2 | "How does on-call work on your team today?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Describe what is true now, in your own words; the pack supplies no rotation, tooling or practice. Answer slot: if asked what it looks like after the drop, say what it is today; if you do not know, or it was not yours, say so plainly and return to the quote at its own scope | A casual question from engineers who live with on-call, aimed at F2. EXP because it tests whether your story is current |

**I. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Our teams sit side by side. Where is the seam between product and engineering on the roadmap, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know this company's seam: who owns what and why, how disagreement surfaces early, what gets escalated and to whom. Frame it as reciprocity, what you bring product as well as what you need. Make no claim about a past dispute | The partner-with-product line (F6) asked collegially. JD because it scores a stated requirement |
| I2 | "What would you need from me as your product partner, and what could I count on from you?" | JD | [generic] | State both halves as commitments you would make, not as history: what you would ask product for, and what you would give them, such as early notice when delivery is at risk. Keep each to one sentence | Reciprocity, the Peer Evaluator's scoring axis (F6). JD because it scores the partnering the role describes |

### Reverse questions for Thursday

| # | Question | Why it lands |
|---|---|---|
| P1 | "What would make the next manager's first quarter easy or hard for you?" | Asks the staff engineers to tell you their needs before you manage them |
| P2 | "Which technical decisions do you expect the manager to stay out of, and which to be in the room for?" | Draws the line between management and technical leadership in their words |
| P3 | "How does a trade-off between a customer ask and platform work get decided here today?" (to the PM) | Maps the seam you are being asked to partner on (F6) |
| P4 | "What does a good working relationship with engineering look like from your seat, and what is the most common friction?" (to the PM) | Gives the PM the floor on their own pain, and tells you what to avoid |
| P5 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question that shows you are thinking about their load |

## Round 3 (the following Monday): VP Engineering, 30 min

The recruiter's description, "values and leadership philosophy", is the loop source for a values-style round. No published Larkfield values were in hand, so there is no values cheat sheet; the questions below take their theme from the recruiter's words and the role description.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (J) | Scenario probes on leadership and conduct | Top, 4 questions. The recruiter's words name the round as values and leadership philosophy | Choose stories where the hard truth landed; "we" for context, "I" for contribution; say so plainly where the material shows none |
| Pressure (K) | Time-boxed, devil's advocate | Mid, 2 questions. Skip-level prior is Case/Strategist plus Pressure, and 30 minutes forces time-boxing | Pause, restate, concede what is real, hold the rest |
| Conversational (L) | Warm, open questions about motive | Mid, 2 questions. Dedicated-values prior is Values plus Conversational | Short true answers; do not polish a reason you do not have |
| Case/Strategist (M) | Altitude and priorities | Low, 1 question. Other half of the skip-level prior | Clarify, then structure, in plain words |
| Skeptic (N) | Consistency across rounds | Low, 1 question. The objection returns at altitude | Your answers in rounds 1 and 2 must agree with this one |

### Question bank

**J. Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Scaffold: state two principles you actually act on, one sentence each, each with one instance you can tell at its true scope. Two instances your quotes carry are the hiring-loop sentence and the reliability sentence; use them only if they fit principles you really hold, since the pack does not choose your principles. Describe what you did and let the VP draw the inference. If you cannot name a principle, say so plainly and give the nearest thing your material carries | The recruiter's own theme for this round. VAL because it scores whether your behavior matches a stated philosophy (F2, F3) |
| J2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Scaffold: a named stake, the moment you said it, how it landed, the relationship intact. The sentence carries roadmap pressure but not who applied it or whether leadership was involved. If leadership was the source and you told them what the quarter would cost, say so in your own words; if not, or no such moment exists, say so plainly and give the nearest thing your material carries, or how you would handle it. Where the material shows no ending, say so rather than supplying one | The values stem the pack's persona model names for this persona. VAL because it scores whether a hard truth actually landed (F2) |
| J3 | "Tell me about a time you helped an engineer grow into something they hadn't done before." | VAL | [grounded] "3 as a team lead of 6" | Scaffold: pick a person and a stretch; say what you did and what they did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is that you were a team lead of six, or how you would approach it | The growth line (F4), a gap, asked as behavior. VAL because it scores conduct |
| J4 | "Tell me about a hiring decision where your panel disagreed." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Scaffold: the quote carries that you run the loop and the interview count, nothing about a disagreement. If such a decision comes to mind, say what the disagreement was and what part was yours, in your own words; if none does, or it was not yours, say so plainly and describe how you run the loop | The hiring line (F3) asked as behavior. VAL because it scores judgment under disagreement |

**K. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you, over someone who has already managed managers or owned a hardware roadmap?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold then concede. Pause, restate, then concede in your stated words: "I've never managed managers" and "I haven't owned a hardware-adjacent roadmap." Hold only what the quote carries: "I pushed a reliability quarter through against roadmap pressure." Close with a ramp stated as a plan. Hold through two follow-ups by returning to that quote, never by claiming the other candidate's experience | The same objection as A2 and G1, at the altitude where it is a time-boxed trade-off (F1, F5). JD because it scores the stated requirements |
| K2 | "You're moving from a team of six to two squads and eleven engineers. What breaks first?" | JD | [grounded] "3 as a team lead of 6" | Give your own judgment in one sentence of what you think breaks first and why; the pack does not pick it for you. Concede plainly what you do not yet know about the squads' structure, and say how you would find out. Hold your answer through one follow-up | F1's step from one team to two, asked for your judgment. JD because it scores the listed job |

**L. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "What made you want to lead people and not only build systems?" | EXP | [generic] | Give your real reason in two sentences, without polish. If the reason is partly that it was the next step, say so. If no reason comes to mind, say so plainly | A warm motive probe from the VP. EXP because it tests the story behind F1 |
| L2 | "What's one thing about how you work that your resume doesn't show?" | EXP | [generic] | Choose one thing you can back with a specific you can state at its true scope; the pack cannot choose it for you. Keep it short. If nothing comes to mind, say so plainly | An open slot where a prepared answer shows preparation. EXP because it tests self-knowledge |

**M. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Where would you put your attention in your first ninety days across two squads, a hardware partner and a product partner?" | CASE | [generic] | Clarify first: what you would want to learn before deciding anything, and from whom. Then objective, the order of your first moves, and how you would know it was working. The pack holds no facts about Larkfield's current situation, so keep the answer to your method and say what you would ask | A skip-level altitude question set on the role description's own three relationships (F1, F5, F6). CASE because it scores structure |

**N. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| N1 | "What would make you say after six months that this wasn't the right role?" | JD | [generic] | Name a real condition, not a deflection. Link it to your stated limits only if it is true. Your answer must agree with what you said in rounds 1 and 2 | The Skeptic's consistency check across rounds (F1, F5). JD because it scores fit with the listed job |

### Reverse questions for Monday

| # | Question | Why it lands |
|---|---|---|
| V1 | "How would you describe the leadership philosophy you hope your managers share?" | Mirrors the round's own theme back to the person who set it |
| V2 | "Where do you see the biggest tension between hardware timelines and software delivery in the next year?" | Puts the F5 seam at the altitude of the person who sees both sides |
| V3 | "What is a decision a manager here made that you would point to as the kind you want more of?" | Gets values by example, not by slogan |
| V4 | "How do you grow people from team lead to manager here?" | Turns the stated limit on managing managers into a development conversation |
| V5 | "What does the first year look like if it goes well, and what would make you worry?" | Gives you the success and failure conditions before you are measured on them |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Lead two squads (F1) | A3, A4, E4, K2, M1 |
| Building device-management services (F7) | B1, D2, E3, A4 |
| Own delivery (F2) | B2, B4, C1, E1, E2, F2, G2, J2 |
| Hiring (F3) | C2, J4 |
| Growth (F4) | J3 |
| Partner with hardware on the roadmap (F5) | A1, A2, B1, B3, G1, K1, M1 |
| Partner with product on the roadmap (F6) | B2, F1, I1, I2, M1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative the candidate stated, F1 | The plain acknowledgment: "I haven't managed managers." Your words were "I've never managed managers". No slot |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." F5's slot stays on partnering, not owning |
| Led two squads, or managed eleven engineers | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: your material says one team of six |
| Owned delivery across a roadmap | Inflated form of F2 | F2's quote at its own scope: "I pushed a reliability quarter through against roadmap pressure". The limit is the pack's observation: your material says the quarter, not the roadmap |
| The reliability quarter caused or was responsible for the 60% drop | Inflated form of F2 | The sentence says the burden dropped "after" you pushed the quarter through. The limit is the pack's observation: your material does not say why it dropped or how much was yours. C1 and G2 hold the slots on counting and attribution |
| Decides the hires, or designed the hiring loop | Inflated form of F3 | F3's quote at its own scope: "I run our hiring loop for backend roles". The limit is the pack's observation: your material says you run the loop, not who decides |

## Sources

Provided documents: your message, containing the role description, the three rounds and your background. No dossier was present.

Searches sent, all refused, none returned anything:

- "Larkfield Systems industrial IoT company values" (target 1): refused
- "Larkfield Systems interview process engineering manager" (target 2): refused
- "Larkfield Systems industrial IoT device management strategy news" (target 3): refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet (omitted) and VAL themes; the VAL questions take their theme from the recruiter's words and the role description |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have moved any documented loop beyond the three rounds you described; persona weights rest on your message and the relationship priors |
| 3. `Larkfield Systems strategy` and recent news | unavailable | Would have moved CO questions (none written) and grounded the CASE questions; they are labeled generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | Your role description fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text, including reporting lines → F1 to F7's requirement quotes come from the full posting, and the question of whether leads sit between the manager and the 11 engineers is settled for A3 and K1
- Your CV → every evidence cell in the fit snapshot can quote more than the sentences in your message, and F4 and F7 may move off `none given`
- Your answers to the answer slots in F1, F2, F4, F5, F6 and F7 → those rows regenerate with your own words in them
- Larkfield's published values page, pasted → a values cheat sheet for Monday, and VAL questions mapped to named values
- A recent strategy brief or news pasted → CO questions and grounded CASE questions
- Permission to run web searches → the three refused searches could be re-run, which would add loop and values detail
- The recruiter's guidance on the panel's and VP's focus areas, and any pre-declared deliverable → coverage assumptions replaced with theirs; usually one email to the recruiter
- The interviewers' names and titles → an interviewer read, persona weights per panel member, and reverse questions tied to their own paths
- The hours you have before each round → a prep schedule sized to them
- A tuesday-dossier.md from an earlier pass → verified evidence and a sourced prohibited list in place of the one built here from your message
