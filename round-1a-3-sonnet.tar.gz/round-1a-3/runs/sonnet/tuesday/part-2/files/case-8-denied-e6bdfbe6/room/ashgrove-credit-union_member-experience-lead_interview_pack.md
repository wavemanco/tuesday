# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 29 November 2026.

| Round | Interviewer | Length | Relationship | Format as the recruiter described it |
|---|---|---|---|---|
| 1 | The recruiter | 30 minutes | Recruiter screen | Conversation |
| 2 | Head of Member Services | 45 minutes | Your future manager | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Panel | 20-minute case on a complaint escalation, and the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read in this pack.

## How to use this pack

- Personas are how a question arrives; types are what is being scored. The five type tags: VAL (does past behaviour show the published values), EXP (does the CV claim survive scrutiny), JD (can you do the listed job, gaps included), CO (do you know the company and its strategy), CASE (a live problem from the role).
- A bank is grouped by persona and ordered by weight. IDs run by round: A for round 1, B for round 2, C for round 3. Each row carries one type; the rationale says when a second type was a close call.
- Guidance is scaffolding, not a script. Every sentence about your past is one you wrote, quoted in the row's Provenance cell. An answer slot is an instruction for the interview: it names what an interviewer is likely to probe, then gives you two honest branches. Take whichever is true.
- Start with B1. It is the highest-ROI rehearsal in this pack.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end, with nothing inspected behind it, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat before and after the log likely. If any step around the log was yours, say which and what you did, in your own words; if none was, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence says a monthly spreadsheet, not what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it showed volumes or resolution times, say which and how they were counted, in your own words; if it showed something else, or you do not know how they were counted, say so plainly and stay with the spreadsheet |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel, and nothing inspected sits behind it. Answer slot: say which tool it was built in, in your own words; if it was something other than Excel, say so plainly and stay with what you built |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | The quote is training tellers, which is not coaching supervisors, and it stays at that scope. Answer slot: if you ever guided a fellow supervisor through an escalation, say who and what you did; if you did not, say so plainly and stay with the tellers |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Lead with your own terms: six years in retail banking, the last three as a branch supervisor. The JD's phrase, customer operations, is its vocabulary and not yours, so say retail banking and let them match it. Nothing is added to the quote |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | The pack reads "formal" as possibly touching outside rules, and that reading is the pack's, not your sentence's. Answer slot: if outside rules applied to the log, say which and what you did about them, in your own words; if none did, or you do not know, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first one, said as a plan and never as a past |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if any work with a digital team touched how members help themselves, say what it was and which part was yours; if none did, say so plainly and say what you would ask the digital team first |

No requirement in the JD is a gate in the sense this pack uses: the four-years line is a length of experience, graded like any other row.

## Grounding brief (shared)

| Item | What the supplied material says | Provenance | Question hooks |
|---|---|---|---|
| Who they are | "member-owned, about 900 staff" — JD | [grounded] | A2 |
| Digital shift | Move 40% of member service to digital channels by 2028 — strategy brief, July 2026, sent by the recruiter | [grounded] | A2, B8 |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 — same brief | [grounded] | A2, C3, C8 |
| New product | Launch a small-business lending product in Q1 2027 — same brief | [grounded] | A2 |
| Competitive pressure | The main competitive pressure is app-only banks — same brief | [grounded] | A2, B8 |

The brief is from July 2026, four months old on 20 November. Nothing in your inputs shows a stale framing in it, and nothing newer was searched for.

# Round 1: recruiter screen (30 minutes)

## Persona weights, round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; journey, motivation, logistics | High. A recruiter screen's prior is conversational with logistics, and the recruiter's email called it a 30-minute conversation | Prepare a 90-second arc built only on your quoted sentences; treat casual questions as scored |
| Skeptic (light) | Knockout checks in a friendly register | Medium. The contact-centre and regulated-complaints lines are the likeliest knockouts, because F2 and F7 are where the JD presses hardest | Say the limit plainly once, then the nearest thing your material carries |

## Round 1 bank

### Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with three beats, each only what its sentence states: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log you handled; the monthly complaints spreadsheet you built for your regional manager. Tell them in your own words and stop where the sentences stop. Close with your own one-sentence reason for this role | F6 covers the experience-length requirement; F1 and F3 carry the complaints material. EXP because it tests what the CV line really says, in a casual register that is still scored |
| A2 | "Why Ashgrove, and why now?" | CO | [grounded] | Choose one or two points from the grounding brief that really draw you, and say why in your own words. The recruiter sent you the brief, so it is shared ground: bring one point to show you read it, then your own view of it, never a recital. No claim about your past is needed, so the guidance makes none | CO because it tests homework. A recruiter asks it to hear whether the motive is consistent with the JD and the strategy |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked about current pay, you may decline or redirect without giving a figure. This pack supplies no figure | Pay is on every recruiter screen. JD because it concerns the listed job's terms; a slot because only your answer is safe |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Same reasoning as A3: the recruiter needs it to plan the loop |
| A5 | "Does the location and working pattern suit you?" | JD | [generic] | Logistics slot: state your actual location and any constraint in your own words, and ask the recruiter where the role is based and how often it takes you to branches, since the JD does not say | The JD names branches and a contact centre but not a base, so the recruiter will check it |
| A6 | "What's prompting you to look for a move?" | EXP | [generic] | Logistics slot: give your actual reason in a sentence or two, kept true and pointed at what you are moving toward. Add nothing you would not say to your current employer's face | Reason for leaving is asked at every screen. EXP because it is about your own history, which this pack holds no sentence on |

### Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "This role covers branches and the contact centre. How does your background sit against that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Hold to your own words: "I have never worked in a contact centre." Then the branch side at its own scope: "I handled the branch's formal complaints log." Then one sentence of plan about what you would learn first. The full rehearsal is B1; here, keep it short | F2 is where the JD presses hardest and F1 is the nearest evidence. JD because it scores a stated requirement |
| A8 | "The role needs experience handling regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log" | The log at its own scope: "I handled the branch's formal complaints log." Answer slot: the JD's line makes a probe on what rules applied to the log likely. If outside rules applied, say which and what you did about them, in your own words; if none did, or you do not know, say so plainly and stay with the log | F7 is the thinnest row on a stated requirement. JD because it scores that requirement; its premise is the JD's, so the guidance does not adopt it |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where does a complaint change hands today between a branch and the contact centre?" | Shows you are thinking about the process end to end and gives you the first facts about the contact-centre side |
| 2 | "What will the Head of Member Services most want to hear from me in round two?" | Turns the recruiter into a coach and sharpens round two's emphasis |
| 3 | "Is there anything in my background you would like me to address before round two?" | Invites a knockout concern early, while you can still answer it |
| 4 | "Does the panel use a scorecard against the four values, or is it a conversation?" | Prepares your structure for round three and shows you took the recruiter's email seriously |
| 5 | "Is the 20-minute case based on a real past escalation or a made-up one, and is there anything to read beforehand?" | The recruiter's email left the case unspecified, and one reply from them can change how you prepare |

# Round 2: Head of Member Services, your future manager (45 minutes)

## Persona weights, round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps | High. A hiring manager is buying capability and derisking gaps, and F2 and F8 are stated gaps | Rehearse B1 until it is boring; hold, then concede specifically |
| Values / Behavioral | Scenario probes, STAR-shaped stories | High. The recruiter described this round as mostly behavioural, which lifts it above a hiring manager's usual case-led prior | Choose stories your own sentences carry; where none does, use the scaffold and its honest branch |
| Case / Strategist | Live problems from the role's actual agenda | Medium. A manager's prior is case-led, reduced here because the recruiter said the round is mostly behavioural | Clarify, then structure, then answer; think aloud |

## Round 2 bank

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre, and this role owns complaints across branches and the contact centre. Why should I believe you can do it?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Level 1, the hold: "I have never worked in a contact centre." Then the branch side at its own scope: "I handled the branch's formal complaints log." Then one plan sentence. Level 2, "branch complaints are different": concede it specifically. Answer slot: name what you do not yet know about how the contact centre handles complaints, in your own words. Level 3, "why not hire someone who has done it": do not add a claim; say what you would lean on the contact-centre team for. Level 4, "what do you do in your first month": a plan, never a past. Choose only what you would really do, such as listening to calls, asking the team how complaints reach them, and looking at how those complaints are recorded. Hold the core through all four levels by returning to the two quotes, never by adding to them | F2 is the biggest gap against the JD's own first line, so this objection arrives in some form. JD because it scores the stated requirement; the guidance holds only what the quotes carry, because the second follow-up breaks anything wider |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick the limit you would honestly name first and say it plainly in your own words, with one plan sentence. Both of your stated limits are plain acknowledgments you may use: "I have never worked in a contact centre" and "I've never presented to anyone above regional level." Do not invent a third weakness to look balanced | F2 and F8 are the gaps your message states. JD because it asks for a self-assessment against the listed requirements |
| B3 | "This role presents to senior leaders. Where have you presented so far?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment first: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what, to whom and how it went, in your own words; if the spreadsheet was handed over and never presented, say so plainly and stay with the spreadsheet. Then a plan for a first senior presentation: ask what format leaders expect, practise aloud, and lead with the decision they need | F8 is a stated gap. JD because it scores the stated requirement; F3 is the nearest material and is held at its scope |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "Tell me about a time you helped someone handle an escalation better." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F5 with only the beats the quote states: the new tellers, the escalation script, the training. Tell them in your own words. Answer slot: the JD asks for coaching branch supervisors, so expect a probe on whether you have done the same with people at supervisor level. If you have, say who and what you did; if not, or if it was only the tellers, say so plainly and stay with the training | F5 is the evidence for the coaching requirement. EXP because it tests what you actually did, though the JD requirement makes it a close call with JD |
| B5 | "Tell me about a time you delivered an unpopular truth to a senior colleague." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said it plainly, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural probe of how you hold a position. VAL because the interview is mostly behavioural; the pack holds no sentence of yours that carries the story |
| B6 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Selection scaffold: pick a decision where the member's interest and a target pulled apart, say what you chose and what it cost, and say what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of the four values is Members First, Always, so this is the likeliest values theme in a behavioural round. VAL because it scores behaviour against that published value |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B7 | "Walk me through how you would report complaint volumes and resolution times to senior leaders each month. What do you need to know first?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Clarify first: who reads it, what decision they take from it, what counts as a complaint, and where the clock starts and stops. Then structure: what a month's numbers should show, where the data comes from across branches and the contact centre, how you would keep it to one page. The one thing you can say you have done is the quote, at its scope. Answer slot: the JD asks for volumes, resolution times and Excel, so expect a probe on whether your spreadsheet showed either and what it was built in. If it did, say what it counted and the tool; if it did not, or you do not know, say so plainly and stay with the spreadsheet | F3 and F4 are the evidence for the reporting requirements. CASE because it is a live design problem; JD would be the second tag |
| B8 | "We aim to move 40 percent of member service to digital channels by 2028. What does that mean for how members raise complaints and get them fixed?" | CO | [grounded] | Clarify first: which services and channels count, and who is being moved. Then structure: what must stay human, how a digital complaint reaches a named owner, how a member is told in plain words, and what you would measure. Answer slot: the JD asks for work with digital teams on self-service journeys, so expect a probe on it. If you have worked with a digital team on anything members used themselves, say what and which part was yours; if not, say so plainly and say what you would ask the digital team first | The 40 percent target is the brief's headline number, and F9 is the row where your material is silent. CO because it tests strategy fluency; CASE is the second tag |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where does ownership of a complaint get stuck today between branches and the contact centre?" | Shows you are reading the role as end to end, and tells you where the real work is |
| 2 | "Which two numbers in the monthly complaints report do you read first, and what do you do when one moves?" | Ties directly to the reporting duty and shows you think about what leaders do with the numbers |
| 3 | "With 40 percent of service moving to digital by 2028, which complaints do you expect to be hardest to own?" | Uses the strategy brief to ask a manager's question, not a candidate's |
| 4 | "How do branch supervisors take to coaching from the centre today?" | Gets at the coaching duty and tells you what the starting point is |
| 5 | "What would make you say, a year in, that this hire has worked?" | Ends on the manager's own success measure, and gives you something to aim at |

# Round 3: panel of two branch managers (60 minutes, with a 20-minute case)

## Persona weights, round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the four published values | High. The recruiter said the panel is the values round and scores against the four values | Map a story to each value where a sentence of yours carries one; use the scaffold and its honest branch where none does |
| Case / Strategist | The 20-minute escalation case | High for 20 of the 60 minutes. The recruiter named the case, so it is guaranteed | Clarify, objective, approach, risks; say the structure aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting and credit questions from people who work alongside your team | Medium. The panel are branch managers, so seam and ownership questions are likely. Names are not assigned, so each member's persona is the blend of the two top personas for a panel | Propose seam principles instead of pretending to know the seam; reciprocity framing |

## Values cheat sheet (round 3 only)

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's point of view, not the institution's | F1: the quote "I handled the branch's formal complaints log" carries only that you handled the log. It does not say a decision was made from the member's side. Selection scaffold: pick a decision where the member's interest and the branch's convenience pulled apart, say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs something explained twice, the wording was wrong | F5: the quote "trained new tellers on our escalation script" carries the training, not who wrote the wording. Answer slot: if wording in that script changed because of how members reacted, say what changed and who decided; if it never changed, or was not yours, say so plainly and stay with the training |
| Neighbours, Not Numbers | Each branch belongs to its town, so decisions are not made on figures alone | F6: the quote "6 years in retail banking, the last 3 as a branch supervisor" carries your branch role and its length, not a local decision. Selection scaffold: pick a decision where a branch's local context mattered more than a figure. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: the quote "I handled the branch's formal complaints log" carries the log only. Answer slot: if you followed a complaint from the log through to its fix yourself, say what you did and which part was yours; if it passed to someone else, or no single case comes to mind, say so plainly and stay with the log |

## Round 3 bank

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold from the Members First, Always row of the cheat sheet: a decision of yours, a named member situation, what it cost, and a moment you held to it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always is the first value, and the panel scores against all four. VAL because it scores behaviour against a published value |
| C2 | "Tell me about a time you made something clearer for a member." | VAL | [grounded] "trained new tellers on our escalation script" | The nearest quoted material is the training, at its scope. Answer slot: the Plain Words value makes a probe on the wording likely. If wording in the script changed because of how members reacted, say what changed and who decided, in your own words; if it did not, or the wording was not yours, say so plainly and stay with the training | F5 is the only row near it. VAL because the theme is the published Plain Words value |
| C3 | "What does 'every branch is part of its town' mean for how you would run complaints?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A view, not a past. Structure it as how a complaint raised in a branch differs from one handled centrally, and where you would want branch context kept. Your branch role stays at its own scope in the quote. Answer slot: if a local decision at your branch fits, say what it was and what part was yours; if none comes to mind, say so plainly and say how you would handle it | F6 is the quote the branch-side view rests on. VAL because it is the Neighbours, Not Numbers value; the question uses the values page's own words |
| C4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | The log at its own scope is the only story the quote carries. Answer slot: the Own the Fix value makes a probe on follow-through likely. If you followed a complaint from the log through to its fix, say what you did and which part was yours; if it passed to someone else, or no case comes to mind, say so plainly and stay with the log | F1 is the evidence, and the value is the one closest to the role's own first line. VAL because it scores a published value; EXP would be the second tag |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "A member's complaint has been closed by a branch twice and has now landed with you. Talk us through what you do, starting now." | CASE | [generic] | A practice scenario: Ashgrove's real case is not known, so the question is a pattern. Clarify before structuring: what the member says happened, what has been done and said, who holds the record, and which rules and time limits apply, asking about them and not asserting them. Then the objective; who owns it now and keeps hold of it; the first contact with the member in plain words; fixing the cause; recording and reporting; and what you would say to the supervisor. Say the structure aloud, pace it across 20 minutes, and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The recruiter named a 20-minute complaint-escalation case, and the JD's first line is owning the process end to end. CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about this employer |
| C6 | "The supervisor says you are second-guessing their judgement. How do you handle that?" | CASE | [grounded] "trained new tellers on our escalation script" | Likely as a follow-up inside the case. Structure: listen first, separate the case from the person, agree what you both want for the member, give feedback on the decision and not the person, and agree the next step. Your own coaching quote is tellers, at its scope. Answer slot: if you have given feedback to a fellow supervisor, say what you did; if you have not, say so plainly and stay with the training | F5's gap is coaching supervisors, and this is where a panel of branch managers will press on it. CASE because it is a live scenario |
| C8 | "Eight branches become five hubs over 2027. How should complaints work for a member whose branch is merging?" | CO | [grounded] | Clarify first: what changes for members and when. Then structure: keep a member's route to a named person, keep the record, watch complaint volumes during the change, and tell members in plain words. Name the tension with Neighbours, Not Numbers openly. You do not know which branches are affected, so do not guess | A branch-manager panel is likely to bring the hub plan to a complaints role. CO because it tests strategy fluency; the guidance makes no claim about your past |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C7 | "Our branches sit alongside your team. Where is the seam on a complaint, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know the seam: who speaks to the member, who holds the record, when an escalation moves, and who decides closure. On disagreement, agree the member's outcome first. Reciprocity: say what clear escalation routes would give a branch. No claim about your past is needed, so the guidance makes none | The JD asks for the process end to end across branches, and branch managers will check what that costs them. JD because it scores that requirement |
| C9 | "How much of that complaints log was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Hold the quote at its scope: "I handled the branch's formal complaints log." Answer slot: say which parts were yours alone and which were shared or someone else's, in your own words; if it was shared, say so plainly. Never widen the quote under a second question | F1 is the likeliest place for an attribution probe. EXP because it tests what was actually yours |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which complaint do you wish had reached you sooner, and how did it get to you?" | Asks the branch managers about their own world, and tells you what escalation looks like from their side |
| 2 | "What does a good escalation from your supervisors look like to you?" | Ties to the coaching duty and tells you the standard you would coach to |
| 3 | "What could a new lead do in the first month that would genuinely help your branch?" | The reciprocity question: it asks what you can give, not only what you need |
| 4 | "How is the move toward hubs being talked about in your branches, and where would you expect complaints to rise?" | Takes the brief to people who live with it, and tells you what to watch for |
| 5 | "When Own the Fix works in one of your branches, what does it look like?" | Uses their own value, and shows you took its meaning seriously |

# Shared closing sections

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's log, not the process. The slots stay inside the log |
| Has handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The pack observes that your material says a formal complaints log and does not say what rules applied. A8's slot asks only what applied to the log |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. B7's slot asks only what the spreadsheet showed |
| Built the complaints reporting in Excel | Inflated form of F4 | F4's quote at its own scope: a spreadsheet. B7's slot asks only what it was built in |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: new tellers. B4's and C6's slots stay inside the training |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I have never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end | A7, A8, B1, C5, C7, C9 |
| across branches and the contact centre | A7, B1, B2 |
| report monthly on complaint volumes and resolution times | B7 |
| coach branch supervisors on escalations | B4, C6 |
| work with digital teams on self-service journeys | B8 |
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | A8, C5 |
| confident presenting to senior leaders | B2, B3 |
| comfortable with Excel reporting | B7 |

## Sources

Provided documents: the JD pasted in your message; the values text you copied on 20 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the process; the strategy brief points from the July 2026 brief the recruiter sent; your background message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted fixes the cheat sheet and C1 to C4 |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email gives the three rounds, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief points you supplied fix the grounding brief, A2, B8 and C8 |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No names are assigned yet, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV or the bullets you use for these roles → the fit rows now quoted from your message are re-checked against it, and rows currently `discovery` may close
- A redacted copy of the monthly complaints spreadsheet, with no member details → raises F3 and F4 from `medium` toward `high`, and settles what it counted and what it was built in
- The escalation script you trained tellers on, or the log's own procedure → settles F5 and F7, and gives C2 and A8 something to quote
- The interviewers' names, once assigned → persona weights from their public footprint, and a reverse question tied to each one's path
- The recruiter's reply on whether the case is real or invented, and what to read beforehand → C5 becomes `[grounded]` instead of `[generic]`
- Hours available between now and 29 November → a prep schedule sized to them
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → interviewer footprints, loop reports and recent organisation context for Ashgrove
- A `tuesday-dossier.md` from an earlier run → verified evidence and prohibited claims arrive already graded; never required
