# Interview prep pack: Operations Manager, Atlas Freight

**Interviewer:** not known. **Round:** not stated, so this pack is built for a hiring-manager round. Reweight if that is wrong.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: every sentence about your own past is one you said, quoted, or an answer slot for you to fill in your own words. IDs run letter-by-persona; the letter F is skipped so a question is never confused with a fit-snapshot row.

| Tag | Name | What it is scoring |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows a specific value, not generic virtue |
| EXP | Work-experience deep-dive | Whether the claims on your résumé survive scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and company-level thinking |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift role and a surge plan for the site, not terminals and not four sites, and the words stay there: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-sites line makes a probe on the reach of what you ran likely. If your responsibility reached beyond your own shift or site, say where and how, in your own words; if it did not, or terminals are new to you, say so plainly and stay with the surge plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material shows a result on mis-pick rate, not on on-time performance or cost per shipment, with nothing inspected behind it. The words stay at that scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's two metrics make a probe on whether either moved likely. If you tracked either one, say what was counted and what changed; if neither was tracked, or the change was not yours, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors and the JD says 12, so the count is the gap, and the words stay at "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have had responsibility for more than 3 supervisors at any time, say when and how many, in your own words; if not, say so plainly, then give how you would approach a larger group, said as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" (the Excel half) — JD | "solid Excel, never used Power BI" — your message | low | [inferred] | discovery | "Solid Excel" does not say what was built with it, so the material neither shows nor rules out reporting. Answer slot: the JD's reporting line makes a probe on what you built likely. If you built reports in Excel, say what they showed and who read them; if you used Excel for other work, or the reports were not yours, say so plainly and stay with what you said |
| F5 | "build reporting in Excel/Power BI" (the Power BI half) — JD | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | You stated the absence, so the words are yours: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. The JD's slash may read as either tool, which is a question for the interviewer rather than something to assume |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives 7 years in warehouse and distribution ops and a current shift manager role, and does not say how many of the 7 years were in a role leading others, so the count is not rounded up. Words: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's 5+ years line makes a probe on how many of those years were leading people likely. Say the count and the roles, in your own words; if it is fewer than five, or the earlier years did not involve leading anyone, say so plainly and stay with the current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | Your quote already reaches the Six Sigma half of the line, with no certificate inspected, so expect a probe on it: "I'm green belt certified." The quote does not say which body or which methodology. Answer slot: if asked what it covers or where you have used it, say which course or body in your own words, and if the pick path redesign used it, say so; if it was separate from that work, say so plainly |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the 3-versus-12 supervisor count, terminals versus warehouse, Power BI | High. Hiring-manager prior assumed; F3, F5 and F1 are where the material is thinnest | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Case / Strategist | Live ops problems: on-time drop, cost-per-shipment rise, taking over four sites | High. Hiring-manager prior assumed; the JD is a list of operating outcomes | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | Reads the résumé line by line, asks how the 40% was counted | Medium. F2 holds a headline figure and the JD asks for reporting | Know how the figure was counted and say plainly when you do not |
| Pressure | Interrupts, time-boxes, tests the 3-versus-12 gap | Medium. A senior hire into twelve supervisors invites a composure test; no source says this loop has one | Pause, restate, hold a position through two follow-ups before conceding anything real |
| Conversational | Friendly opener, casual question about Lean | Medium. Any first conversation opens this way; casual questions are still scored | A 90-second arc built only from your own sentences |
| Peer Evaluator | Site-to-site seams and shared credit | Low. No peer round is named | Offer seam principles, not claims about a seam you have not seen |
| Values / Behavioral | Scenario probes | Low. No loop source names a values round and no published values are in hand | Select a real story or say plainly that none comes to mind |

Weights rest on the hiring-manager relationship prior and the generic loop pattern (screen, hiring manager, panel), not on Atlas Freight's documented process.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI"; "currently a senior shift manager over 3 supervisors" | Pick one weakness and name it plainly rather than spreading across several. If you pick the tool, your own words were "solid Excel, never used Power BI", so the plain version is "I've never used Power BI", followed by how you would learn it, as a plan in your own words; the pack supplies no plan and no timeline. If you pick the group, the quote is "currently a senior shift manager over 3 supervisors", set against the JD's twelve | F5 and F3 are the stated limits, so this question will land on one of them. JD because it scores the listed requirements |
| A2 | "This role has twelve supervisors across four sites. You are currently over three. How do you see the difference?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Concede the count in plain words: three is the group you are over today and twelve across four sites is bigger. Follow-up one, what would break first at twelve, is a plan in your own words and nothing about your past. Follow-up two, what you have done at a bigger size. Answer slot: if you have had responsibility for more than three supervisors, say when and how many; if not, say so plainly and return to the quote. Hold through both follow-ups by returning to the quote, never by adding to it | F3 is the largest gap against a numbered JD line, so some version of this is the likeliest question in the loop. JD because it scores the lead-a-team requirement |
| A3 | "Your background is warehouse and distribution. This role is terminal operations across four sites. What would you need to learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Words: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's terminal operations line makes a probe on terminal work likely. If any of those years touched terminal work, say what, in your own words; if none did, say so plainly. Then name the first two things you would ask to understand a terminal you did not run, as a plan in your own words | F1 is the evidence for the terminal line and the place a probe lands. JD because it scores the stated responsibility |
| A4 | "The JD asks for 5+ years of operations leadership. How many of your 7 years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Words: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Do not round 7 years of ops up into 7 years of leadership. Answer slot: say the number of years in roles leading others and what those roles were, in your own words; if it is fewer than five, or earlier years did not involve leading anyone, say so plainly and stay with the current role | F6 is a discovery gap: the count is the one fact the material lacks, and a stated minimum invites exactly this question. JD because it tests the stated requirement |
| A5 | "Why this role, and why now?" | EXP | [generic] | Selection scaffold, since no reason is stated in your material: pick one pull toward the role that is true for you and that you can connect to a line in the JD, such as the four sites, the twelve supervisors, or the on-time and cost targets. A reason you cannot back with something you have done is the one the follow-up breaks. If no single reason comes to mind, say so plainly, then give the nearest true thing, or how you would decide | Motivation consistency is the Skeptic's core score and the material carries no stated reason, so this is a scaffold. EXP because it tests whether the story holds together |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four terminals has dropped several points over a month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined, which lanes and customers, when it started, whether it is one site or all. Segment next, for example inbound against outbound, labor, equipment, volume mix. Name two or three hypotheses, the data that would separate them, a fast containment step and a root-cause step, and how you would report it weekly. Say the structure aloud before using it. The question asks about no past, so the guidance makes no claim about yours | A live problem from the JD's on-time line (F2's requirement). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost per shipment is up across the network. Where do you look first?" | CASE | [generic] | Split the figure into what is divided and what it is divided by: the cost lines on top, shipment count and mix underneath. Ask how cost per shipment is defined here before diagnosing. Segment by site, then by the biggest cost line, and say what you would check to separate a volume effect from a cost effect. Close with the first action and the metric that shows it worked | A live problem from the JD's cost-per-shipment line (F2's requirement). The question presupposes nothing about your past |
| B3 | "You take over four sites that each run a little differently, with twelve supervisors you have just met. What do you do in the first thirty days?" | CASE | [generic] | Structure: listen before changing anything, see each site run, set one common baseline of the JD's two metrics, meet each supervisor one to one, separate local variation worth keeping from variation that costs on-time or cost, and pick one visible early fix. Say what you would not change until you understood it. Everything here is a plan, and none of it is a claim about what you have done | F1 and F3 together make this the natural hiring-manager case. CASE because it scores structure rather than a past event |
| B4 | "A peak surge is six weeks out and two of the four sites are short of labor. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: demand picture, labor gap by site, levers, triggers, communication, what you would watch daily. If invited to connect it to your own surge plans, say only what the quote says: "I ran the site's peak-season surge plan two years running", and tell the rest in your own words at that scope | F1's surge-plan evidence is the closest match to a peak problem, so this case lets the quote carry weight without adding to it. CASE with an EXP edge |
| B5 | "Walk me through the weekly numbers you would want on one page to run four sites." | JD | [grounded] "solid Excel, never used Power BI" | Structure: what decisions the page serves, a handful of metrics starting with the JD's two, each defined once, one owner each, how often it refreshes. On the tool, your own words were "solid Excel, never used Power BI": say the Excel half at that scope and the other half plainly, "I've never used Power BI." Answer slot: if you built reports in Excel, say what they showed and who read them; if you did not, or they were not yours, say so plainly | F4 and F5 are the reporting rows, and this is where the JD's reporting line becomes a live question. JD content, CASE delivery |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Words: "I cut mis-pick rate 40% by redesigning the pick path." Four slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before the interviewer names it; and which part of the redesign was yours. For any of the four you do not know, say so plainly. The pack supplies none of them | F2's headline figure is the magnet target for a prober. EXP because it tests attribution and honesty about the number |
| C2 | "Did on-time performance or cost move because of the pick path change?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Words stay at the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked either one, say what was counted and what changed; if neither was tracked, or the change cannot be tied to the redesign, say so plainly and stay with the mis-pick result | F2 is a transferability row: the JD's metrics are next to the result and not on it, so this is the natural bridge probe. JD because it scores the stated metrics |
| C3 | "You ran the peak-season surge plan two years running. What did you measure?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Words: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's reporting and metric lines make a probe on measurement likely. If you measured anything on it, say what and how, in your own words; if nothing was measured, or it was not yours to measure, say so plainly and stay with the quote | F1's surge-plan evidence says what you ran and nothing about measurement, which is where a prober goes next. EXP because it tests what was actually yours |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Anchor in the quote: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to what you said. Concede specifically: if parts of the redesign or of the result were others', name which parts, in your own words; if none were, say so plainly | F2's figure is where attribution pressure lands. EXP because it tests precise honesty about your share |
| D2 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Stay inside the quotes, in your own words: 7 years in warehouse and distribution ops; a 40% cut in mis-pick rate by redesigning the pick path; the site's peak-season surge plan run two years running; green belt certified. Do not compare yourself to the other candidate and do not add anything the quotes do not carry. If they push, return to what you said rather than raising it | F1 to F7 together are the whole case; the pressure persona tests whether you hold it without inflating it. JD because it scores fit for the role |
| D3 | "You are over three supervisors today and this is twelve. Isn't this a stretch for you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause. Hold: "I'm currently a senior shift manager over 3 supervisors." Concede only the count: twelve is more than three. Then the approach to a larger group, as a plan in your own words. Answer slot: if you have had responsibility for more than three supervisors, say when and how many; if not, say so plainly and return to the quote. Do not fold on the core claim to restore harmony | A2's objection in the pressure register: same F3 gap, delivered to test composure. JD because it scores the stated team size |

### E. Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc with only the beats these five sentences state: the 7 years in warehouse and distribution ops, the current senior shift manager role over 3 supervisors, the 40% cut in mis-pick rate by redesigning the pick path, the surge plan run two years running, the green belt. Order them in your own way and tell each in your own words. Add nothing else | The opener is scored even when it feels casual. F1 to F7 supply every beat, and an arc built from them cannot outrun them. EXP because it is your own history |
| E2 | "What do you know about us, and where do you see us competing?" | CO | [generic] | Selection scaffold, since no company facts were established here: before the interview, read the careers and about pages and note two things you can say in your own words, and say only what you found. If you found little, say so plainly and ask them where they see the company competing. A confident claim about the company you cannot source is the one that costs | No company research could be run, so this is a scaffold. CO because it tests homework at the company's level |
| E3 | "What are you actually playing with in Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" | Words: "I'm green belt certified." Answer slot: if asked what it covers or where you have used it, say which course or body in your own words, and if the pick path redesign used it, say so; if it was separate from that work, or you have not used it since, say so plainly. Casual register, scored answer | F7 is the plus-skill, so the casual version of the question is likely. JD because it scores the listed plus |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles instead of pretending to know the seam: who owns which metric, what gets escalated and when, how a disagreement gets resolved with data. Add reciprocity: what you bring the other site, not only what you need. A disagreement story needs a real one; if no such time comes to mind, say so plainly and give how you would handle it | A peer would price what you add to their load; no peer is named, so this is a low-weight bank. JD because the role spans four sites |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned two teams, with a named stake, what was yours and what was theirs, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Credit-sharing is the peer persona's standard probe, and the quote-or-scaffold rule means no story is supplied for you. VAL because it scores behavior |

### H. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, and how it landed; use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard behavioral stem. No published values or values round could be established, so this is `[generic]` rehearsal rather than a values map. VAL |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need and an internal number pulled in different directions. It needs the decision, what it cost the metric, and what you would do the same or differently. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A freight role runs on service commitments against cost targets, so the stem is a plausible pairing with F2's two metrics. VAL |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "Own daily terminal operations across 4 sites" | A3, B1, B3, B4, D2, G1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C2, C3, D2 |
| "lead a team of 12 supervisors" | A1, A2, B3, D3 |
| "build reporting in Excel/Power BI" | A1, B5, C3 |
| "5+ years operations leadership required" | A4, E1 |
| "Lean/Six Sigma a plus" | E3, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is on-time performance measured across the four sites today, and which site is furthest from where you want it?" | Uses the JD's own metric and shows you think in numbers by site |
| 2 | "How is cost per shipment defined here, and who controls its inputs?" | Definitions are where operating metrics get argued; asking early shows rigor |
| 3 | "The posting says Excel/Power BI. What do the supervisors' reports run on today, and is Power BI the direction or one option?" | Raises the tool question openly and turns it into a planning conversation |
| 4 | "How are the twelve supervisors spread across the four sites, and where do they differ most?" | Shows you are thinking about span and structure, not only the headline number |
| 5 | "What would you want me to have changed or learned by day ninety?" | Makes them state the real success criteria |
| 6 | "What does a bad day at one of the terminals look like, and how does the team find out?" | Signals you plan to run the floor and not only the reports |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across 4 sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says a shift role and the site's surge plan, not terminals or four sites |
| Led a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". The material says 3 |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". The material says mis-pick rate |
| Built reporting in Excel | Inflated form of F4 | F4's quote at its own scope: "solid Excel, never used Power BI". The material does not say what was built |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has 7 years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops". The material does not say how many of those years were leading others |
| Led a Lean or Six Sigma program | Inflated form of F7 | F7's quote at its own scope: "green belt certified". The material says the certification |

## Sources

Provided documents: the job description text in your message, and your background in your message. No dossier was present.

Searches sent, all refused by the host, none returned a result:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused. It would have decided whether a values cheat sheet and mapped VAL questions were possible; H1 and H2 are `[generic]` scaffolds instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Search refused. It would have set the round structure and persona weights; weights rest on the hiring-manager prior and the generic archetype |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search refused. It would have grounded the CO bank and the CASE questions in the company's current priorities; E2 and the CASE bank are `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD in your message fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and the round type (hiring manager, peer, skip-level, recruiter, panel) → reweights every bank; the pack currently assumes a hiring-manager round
- The recruiter's guidance (focus areas, any case study, presentation or take-home) → graded-deliverable build sections and tighter coverage
- The interviewer's name or profile → an interviewer read and a reverse question tied to their own path
- Atlas Freight's careers or values pages pasted in, or search access granted → published values, the real loop and current strategy; `[generic]` rows in the CO, CASE and VAL banks become `[grounded]` or `[inferred]`
- Your own answers to the slots in F1 (reach beyond your shift or site), F2 (whether on-time or cost was tracked), F3 (any time over more than three supervisors), F4 (what you built in Excel), F6 (years leading people) and F7 (what the green belt covered) → those rows become story-mapped `[grounded]` answers
- The full posting text, if it holds more than the one line pasted → more requirement rows and questions
- A `tuesday-dossier.md` from earlier work on this role, if you have one → confirmed evidence and an evidence-derived top objection in place of the inferred one
