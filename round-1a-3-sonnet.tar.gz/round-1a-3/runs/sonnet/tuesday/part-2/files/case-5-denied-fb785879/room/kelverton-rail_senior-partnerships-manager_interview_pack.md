# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second-round panel on Tuesday, 60 minutes. Interviewers: Deepa (VP Partnerships, your future manager, in the recruiter's words) and Ross (Commercial Director). Shape, in the recruiter's words: the first 15 minutes are a short POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves; the rest is Q&A, and "Ross will push on commercials".

Built on: your message and the recruiter's email as you quoted it. No JD was supplied. The market report was attached to the recruiter's email but its text is not in this conversation, so nothing here is drawn from it. Web research was refused in this session, so nothing here is drawn from the web either. Ross's relationship to you and to Deepa was not stated; he is treated as a senior cross-functional interviewer.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: every sentence about your past is one of your own, quoted, and where the pack could not carry a story it leaves a slot for your words. The single most likely objection to you gets the deepest rehearsal, and it is the highest-ROI prep in this pack: B1.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (not banked here; see the persona table) |
| EXP | Whether your CV claims survive scrutiny and what was actually yours |
| JD | The stated role and its requirements, including the gaps |
| CO | Company and strategy homework; thinking at the company's altitude |
| CASE | A live problem from the actual role, structured aloud |

## Prep triage

You have about four hours over the weekend. Do these in order; each is tied to a section or question ID.

| Block | Time | What | Where |
|---|---|---|---|
| 1 | about 60 min | Choose one thesis, mark your copy of the report for the consensus item, the divergence and the anti-pick, and write your close on the operators | Graded deliverable |
| 2 | about 60 min | Say the POV aloud, timed, three times; after each run, answer A1 and D3 aloud | Graded deliverable, A1, D3 |
| 3 | about 45 min | Rehearse B1 until it is boring, then B2 | B1, B2 |
| 4 | about 45 min | Commercials: say plainly what you do and do not know about how each figure was counted | C1, C2, C4, D2, C3 |
| 5 | about 30 min | The 90-second arc and the report question; pick three reverse questions | F1, F2, A2, A5, reverse questions |

Everything else is insurance: A3, A4, B3 to B5, D1, E1, E2 and the remaining reverse questions.

## Fit snapshot

No JD was supplied. Requirements are the recruiter's own words, quoted, or plain role-family prose labeled by its provenance. No row is a gate: nothing in the material states a term the role requires.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Adjacent work in another sector. Your material shows a channel taken from 6 partners to 40, not a view on operator partnerships; the view is what the POV builds (graded deliverable). Words, at the quotes' own scope: "I ran the ISV channel at a payments company for the last four years, and took it from 6 partners to 40." The sector limit goes into the thesis concession, as the pack's observation: the channel was payments |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Adjacent work from the consulting side. The pack's observation: the material says bus and light rail network planning, not train operating companies, and does not say which side "the other side" is. Words at the quote's scope: "For five years I did transport consulting, bus and light rail network planning." Answer slot: the recruiter's ask makes a probe on which operators and whom you spoke to likely. If the consulting work put you in front of an operator's own people, say who and what you took from it, in your own words; if it did not, or it was not with train operating companies, say so plainly and stay with the planning you did. Say which side "the other side" is, in your own words, before you are asked |
| F3 | "Ross will push on commercials" — recruiter's email, quoted in your message | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure keeps its word: influenced. The pack's observation: the material says influenced revenue, not revenue sold, owned or closed. Words: "Roughly £4M of influenced revenue." The slots on how it was counted sit at C2 and D2 |
| F4 | carry a revenue or quota number for partner-sourced business (role-family requirement, no source supplied) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then a plan, said as a plan and never as a past: what you would ask Ross about how partner revenue is counted here before agreeing to any number. Never a claim to quota-carrying, and nothing added to make the gap feel smaller |
| F5 | sell into rail operators (role-family requirement, no source supplied) | "Never sold into rail specifically" — your message | none | [grounded] | capability | Stated by you, so the words are yours: "I've never sold into rail specifically." Then the adjacent work at F2's scope, and how you would learn the sector, said as a plan. Never implies rail sales |
| F6 | build and scale a partner channel (role-family requirement, no source supplied) | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [inferred] | none | Derived from a role-family requirement set against your quotes. No gap on that reading. Lead with the quotes' own terms: nine years in partnerships, the last four running an ISV channel at a payments company, 6 partners to 40. Expect a probe on how 6 and 40 were counted (C1): a self-reported figure with nothing inspected behind it |

## Graded deliverable: the 15-minute POV

The brief, in the recruiter's words: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

### Grounded facts to build on

| Row | Sentence quoted from that row's evidence cell | What it can carry, and its limit |
|---|---|---|
| F6 | "took it from 6 partners to 40" | That you have scaled a partner channel. Limit, the pack's observation: the channel was payments, and the material does not say over what period the growth happened |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A planning-side view of operators. Limit, the pack's observation: bus and light rail, not train operating companies |
| F3 | "roughly £4M of influenced revenue" | A commercial scale you have been near. Limit: influenced, not owned |
| F5 | "Never sold into rail specifically" | The limit to state once, on your terms, inside a concession |

### Three theses to choose from

These are positions, `[generic]` patterns, not claims about Kelverton or the rail market. Choose the one you believe and can tie to the report you read; each carries a concession you must say aloud.

| Thesis | What you would be saying | Mandatory concession | Choose it only if |
|---|---|---|---|
| T1 Depth before breadth | Over 18 months, take a small number of operator partnerships to shared, measurable outcomes before widening | Fewer new relationships to show at month 18, and the case rests on the depth being worth more than reach | Your copy of the report gives you a reason to think current relationships are thin or uneven |
| T2 Reach through the ecosystem | Extend through parties that sit around the operators, rather than only operator by operator | It adds a party between Kelverton and the operator, so the operator's own voice can thin; and the only channel-scaling in your material is in payments | The report supports leverage through third parties |
| T3 Partner to the operator's problem, not to the product | Build partnerships around outcomes the operator itself is held to, and decline those that only extend Kelverton's feature list | You are naming operator outcomes without having sold to operators, so you state them as hypotheses to test with operators in your first quarter | You can name at least one operator outcome from the report or from your consulting work |

### Differentiation: do not recite the report

The report was circulated internally, so Deepa and Ross have read it, and so has every prepared candidate. Reciting its shortlist scores as homework. Do three things in order: bring one item the report itself leads with, to prove grounding; then one place you diverge, with your reason; then the anti-pick, one thing the report points toward that you would not spend partnership effort on, and why. A senior partnerships role includes saying no, so the anti-pick is where judgment shows. The report's text is not in this conversation, so the pack cannot name the three items: mark them in your copy.

### The close: what it means for the operators themselves

The recruiter asked you to land here, so end on the operator, not on Kelverton's pipeline. In your own words, in about three sentences: who at the operator notices something change, what they do differently or stop doing, and how an operator would know it worked. Use one concrete example only, and draw it from the report or from what you actually did in consulting; the pack supplies none, because any example here would be invented.

### Shape and timing (a suggestion)

Aim for roughly ten minutes so the 15-minute block has room for interruptions. One-sentence thesis up front; the consensus item; the three moves across months 0 to 6, 6 to 12 and 12 to 18; the concession, including the one-line limit from F5 if you choose to volunteer it; the anti-pick; the close on operators. Practice it aloud, timed.

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight high, 5 questions) | Live problems on the role; follow-ups on your POV | Deepa is your future manager, which is the hiring-manager prior (Case plus Skeptic), and the POV is itself a case you set | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (high, 5) | Quiet, persistent probing of the gaps | Same hiring-manager prior, and F4 and F5 are gaps you stated, which is where a skeptic goes | Rehearse B1 until boring; concede stated limits in your own words; never bluff a competency the panel owns |
| Data-Driven Prober (medium-high, 4) | Reads the numbers line by line | The recruiter says Ross will push on commercials, and F3 and F6 hold the only figures in your material | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Pressure (medium, 3) | Time-boxed or devil's-advocate challenges | "Push" suggests a challenging register; whether Ross interrupts is unknown, so this is an assumption | Pause, restate, hold a position through two follow-ups, concede only the specific thing |
| Peer Evaluator (low, 2) | Seam-splitting between partnerships and commercial | Their relationship to each other was not stated; the seam is a natural question when both are in the room | Offer seam principles rather than a map; reciprocity framing |
| Conversational (low, 2) | A friendly opener and a final open question | Always possible in a panel; casual questions are still scored | A 90-second arc for the opener; never answer the last question with "I think you've covered everything" |
| Values/Behavioral (not banked) | Scenario probes against published values | The recruiter's description names no values round, and the values page could not be researched | None in this pack; E2 touches the nearest behavioral theme |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you had to choose the first two operator partnerships to start with, how would you choose, and what would you need from us first?" | CASE | [generic] | Structure aloud: clarify what you need from us, state the objective, segment the operators, choose two, say how you would test the choice, name the main risk. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The natural follow-up to any POV, so it arrives in some form; CASE because it scores structure on a problem from the role |
| A2 | "Pick one priority from the strategy team's report and tell me where you would push back." | CO | [grounded] "which I've read" | Use the differentiation order from the graded deliverable: one item the report itself leads with, then one divergence with your reason, then the one thing you would not spend partnership effort on. The pack cannot name the items, since the report's text is not in this conversation; the choice is yours, from the copy you read | Shared-source questions reward judgment over recitation; CO because it scores homework depth. The question's premise about the report's contents is the pack's guess at wording |
| A3 | "An operator wants to adopt our scheduling software, but their team is stretched and cannot take on another implementation this year. What do you do?" | CASE | [generic] | Clarify what stretched means and who else at the operator has a stake; set out options such as sequencing, scaling down or waiting; say what you would trade and what you would tell the operator. Make no claim about having faced this before | A live problem on the partnership-to-adoption seam; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A4 | "How would you know, at 6, 12 and 18 months, that the plan was working?" | JD | [generic] | Clarify what is measured today and by whom before offering metrics. Separate what you would watch early from what only shows late, say how each would be counted, and name the one you would trust least. The question needs no claim about your past | The recruiter's 18-month frame makes this likely; JD because it scores the stated requirement, with CASE delivery |
| A5 | "What does an operator lose if we get partnerships wrong?" | JD | [grounded] "5 years in transport consulting"; "bus and light rail network planning" | The recruiter's close asks you to land on operators, so this arrives. Story-mapped on F2, at the quotes' scope: five years of transport consulting, bus and light rail network planning. Answer slot: if that work put you in front of people who run services, say what they told you or what you saw, in your own words; if it did not, or it was never train operating companies, say so plainly and answer from structure: who at the operator is affected, what they do differently, what they stop doing | F2 is the only evidence on the operator side and the likeliest place to be probed; JD because the recruiter named it |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never sold into rail and you have not carried a quota. Why should we trust you with our operator partnerships?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40"; "5 years in transport consulting"; "bus and light rail network planning" | The highest-ROI rehearsal in this pack. Concede first, in your own stated words: "I've never sold into rail specifically, and I've never carried a direct quota, only influenced revenue." Then hold only what the quotes carry: "I ran the ISV channel at a payments company for the last four years, and took it from 6 partners to 40. Before that I did five years of transport consulting, bus and light rail network planning." Then a plan, said as a plan: what you would learn first, and from whom, before committing to a number. Follow-up one, "that is payments, not rail": concede the sector plainly and return to the quotes. Follow-up two, "so you have not worked with train operating companies": answer slot. If any of the consulting work was for or with them, say what; if it was not, say so plainly and stay with the bus and light rail planning. Hold by returning to the quotes, never by adding to them | F4 and F5 are the gaps you stated, so this objection arrives in some form; a rehearsed, non-defensive answer changes the interview. JD because it scores fit to the role, EXP in delivery |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Selection scaffold with two candidates your own words name. Pick the one you would honestly rank weaker, say it in those words, then say what you would do about it in your first quarter, as a plan and not a past. If you would rank something else weaker, say what and why; the pack cannot name it for you | The standard skeptic stem, and F4 and F5 give it its likeliest answers; JD because it scores honest self-assessment against the role |
| B3 | "Why Kelverton, why rail, why now?" | CO | [grounded] "which I've read" | Your material states no reason for the move, so the answer is your own: one true reason and one thing from the report you can point to. Answer slot: give your actual reason in your own words; if there is no strong one, say so plainly and say what you would want to find out. Never state a reason you do not hold | Motivation consistency is the skeptic's other main probe; CO because it tests whether the answer is specific to this company |
| B4 | "You ran a channel in payments. What carries over to operators, and what doesn't?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" | Story-mapped on F6: a payments company, an ISV channel, the last four years, which are the beats the quote states. Answer slot: if something from running the channel applies to operators, say what and how you know; if you cannot yet say, say so plainly and say what you would test first. The pack supplies neither list | The transfer question follows any cross-sector move; EXP because it tests what was actually learned |
| B5 | "How current is your view of train operators?" | EXP | [grounded] "5 years in transport consulting" | Answer slot: which operators and which years, and whether any were train operating companies, in your own words; if you do not have names or dates to hand, say so plainly. If you have since updated your view, say how; if not, say so plainly and say how you would update it in the first month | F2 is dated and adjacent, which a skeptic will price; EXP because it tests the boundary of a claim |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the move from 6 partners to 40 was counted." | EXP | [grounded] "took it from 6 partners to 40" | Story-mapped on F6: the channel, 6 partners at the start and 40 after, the beats the quote states. Four slots, each in your own words: how it was counted, including what counted as a partner; what the number is sensitive to; the assumption behind it you would defend least; and which part was yours. "I don't know how it was counted" is an honest branch. Name your weakest assumption before they do | Every headline figure draws a defend-the-number question; EXP because it tests attribution and counting |
| C2 | "Roughly £4M of influenced revenue: what does influenced mean there?" | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Keep the word as yours: influenced. Four slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never restate it as sold, generated or owned | F3 is the figure Ross is most likely to press; EXP because it tests whether the figure survives scrutiny |
| C3 | "How would you judge whether an operator partnership was commercially worth doing for us?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Clarify before structuring: ask what worth doing means to Kelverton and how partner revenue is counted. Then give your test as a structure: what the operator gets, what Kelverton gets, what it costs to serve, what it displaces. Say where your experience stops: "I've never carried a direct quota, only influenced revenue." Then ask for his view of how it is counted | The recruiter flagged commercials, so a commercial case arrives; JD because it scores the stated area, CASE in delivery |
| C4 | "How did the commercial terms with your channel partners work, and who set them?" | EXP | [grounded] "running the ISV channel"; "roughly £4M of influenced revenue" | The recruiter's note on commercials raises this probe. Answer slot: if you worked on what partners earned or paid, say which part you worked on and which part others set, in your own words; if the channel had no such terms, or none of it was yours, say so plainly and return to the channel you ran and the figure at its own scope | The likeliest place the commercial push lands on your history; the premise is the interviewer's, so the slot lets it be false |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | EXP | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40"; "bus and light rail network planning" | Pause and restate. Concede in your own stated words: "I've never sold into rail specifically." Then choose one thing you can show from what you did, not from what you would be good at: the quotes carry the ISV channel (6 partners to 40) and the consulting (bus and light rail network planning). Say which you stand on and why, in your own words. Hold through two follow-ups by returning to it, never by adding to it | A time-boxed version of B1; EXP because it tests composure and attribution under pressure, and F5 is its basis |
| D2 | "That £4M: how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Anchor on the word: "Roughly £4M of influenced revenue." Answer slot: which part was yours, in your own words; if you cannot separate it, say so plainly; if most of it was others' work, say that. Hold through two follow-ups by returning to the word and the slot; concede the specific thing you cannot separate, not the figure | F3 is the claim a pressure interviewer tests for inflation; EXP because it scores attribution honesty |
| D3 | "What would make you abandon the plan you just gave us?" | CASE | [generic] | Pause. Name the single condition from the concession of the thesis you chose, since that is the one you can defend, and say what you would do instead. Hold the thesis through a second push; concede only that condition, not the whole plan. The question needs no claim about your past | Tests whether you hold a position without defensiveness; CASE because it is a live challenge on your own recommendation |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit close together. Where is the seam, and what happens when we disagree about a deal?" | JD | [generic] | Offer principles, not a map: ask where the seam sits today; say how you would decide who leads on a deal; say what each side needs from the other; and say what you would bring Ross's team, so the answer is reciprocal and not only what you need. The question needs no claim about your past | Both interviewers are in the room, so the seam is a natural question; JD because it scores partnership fit |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams and credit was shared; it needs a named stake, what you each did, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The same discipline applies to the influenced figure: say which part was yours | The stem scores honesty about attribution, which the influenced figure already invites; EXP because it probes what was actually yours |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "Before that, 5 years in transport consulting"; "bus and light rail network planning" | A 90-second arc on the quotes' beats: nine years in partnerships, the last four at a payments company running the ISV channel; before that, five years of transport consulting, bus and light rail network planning. Answer slot: your actual reason for moving toward rail partnerships, in your own words; the material states none | An opener that is scored despite its register; EXP because it tests whether the story hangs together |
| F2 | "What in the strategy team's report stood out to you?" | CO | [grounded] "which I've read" | Answer slot: say which part stood out and what it made you think about operators, in your own words; if nothing did, say so plainly and say which part you would want to ask about. The pack cannot suggest an answer: the report's text is not in this conversation | A casual question about a hot topic is still scored; CO because it tests whether you read it with judgment |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want the first operator partnership win to look like inside 18 months, and who at the operator would feel it?" | Tests your close on operators against Deepa's own picture and lets her correct the POV |
| R2 | "How do you count partner-influenced revenue today, and where does that count sit between partnerships and commercial?" | Turns Ross's commercial push into a shared definition, the very place your material says influenced and not direct |
| R3 | "Which operators have got the most from working with Kelverton so far, and what was different about how they did it?" | Moves the conversation to the operators themselves, the recruiter's own close, and gives you something real to react to |
| R4 | "What would tell you, a quarter in, that this hire was working?" | Converts the role's ambiguity into a measure and surfaces both interviewers' expectations |
| R5 | "How does the strategy team's report feed the partnerships plan?" | Shows you want to build on the report, not recite it, and tells you what is already settled |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never sold into rail specifically." No slot; the adjacent work stays at F2's scope |
| Has carried a quota or owned a revenue number | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| Generated, sold or closed roughly £4M | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says influenced. C2 and D2 stay inside that word |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning and does not say which side "the other side" is |
| Built the ISV channel from nothing | Inflated form of F1 and F6 | The quote at its own scope: "took it from 6 partners to 40". The limit is the pack's observation: the material starts at 6 partners and does not show who built them |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report was attached to that email per your message, but its text is not in this conversation; nothing from it is used. No tuesday-dossier.md was present.

Searches sent, all refused:

- "Kelverton Rail values": refused
- "Kelverton Rail strategy train operating companies scheduling software news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager rail technology train operating companies job description": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The one search for it was refused. It would have fed a values cheat sheet, which a values round would justify; no such round is named, so the cost here is small |
| 2. `Kelverton Rail interview process` | skipped | The recruiter's words fix the session (one panel, two named interviewers, 60 minutes, a 15-minute POV then Q&A), which fixes the persona weights and the values-round call |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The one search for it was refused. It would have grounded CO and CASE questions in current strategy; they are labeled `[generic]` instead |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Both searches were refused. They would have fed an interviewer read and a reverse question tied to their paths; both are absent |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The one search for it was refused. It would have turned the role-family rows F4 to F6 into quoted requirements |

## Upgrade menu

- The JD text → F4 to F6 become quoted requirements and the JD-tagged questions are re-checked against the posting's own list
- The report's text, or its headline recommendations pasted → the differentiation section, A2, F2 and R5 name the consensus items, divergence and anti-pick instead of leaving them to you
- A deeper research pass, if web search is permitted: up to 6 more searches and 2 more fetches, several more minutes → strategy brief, interviewer footprints, role-family loop reports and recent org context; offered once
- The interviewers' surnames or public profiles → an interviewer read, persona weights adjusted from their published footprint, and a reverse question tied to their paths
- A partner list or pipeline report behind 6 to 40 and the roughly £4M → F1, F3 and F6 can move from medium to high confidence, and C1, C2 and D2 slots can be filled from what was counted
- Your own answers to the slots in A5, B1, B5, C1, C2, C4 and D2 → quoted into the fit snapshot, with the rows that draw on them regenerated
- One email to the recruiter: whether notes are fine for the POV and how Ross relates to Deepa → the persona weights firm up
- A tuesday-dossier.md from an earlier session → verified evidence and a prohibited-claims list carried in, which would sharpen the claims this pack treats as medium confidence
