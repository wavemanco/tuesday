# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type and relationship: not known, so persona weights are flat (see the persona table). Built from the JD you pasted and your own message; no company research ran.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Past behavior against values or principles |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Bank letters skip F so they never clash with fit-snapshot row IDs. An answer slot is an instruction for the interview, not a question for you now.

## Prep triage

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the scope step-up and the years-of-leadership count until both are boring. This is the highest-ROI prep in the pack | A1, A3 |
| 2 | Be able to defend the 40% to its assumptions, and say plainly which part was yours | B1, B2, D2 |
| 3 | Settle your one-sentence answer on reporting tools: what you have, and the Power BI limit you stated | A2, C3, D3 |
| 4 | Write out your own answers to the answer slots in the fit snapshot, then read them aloud once | F1 to F8 |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and a senior shift manager role, with nothing inspected behind it, and the words stay there: "I am currently a senior shift manager over 3 supervisors." It does not say terminals or the number of sites. Answer slot: the JD's 4-site line makes a probe on scope likely. If your role reaches beyond those 3 supervisors, say how, in your own words; if it does not, say so plainly and stay with the role you hold |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The quote shows a plan you ran, not what it measured. Answer slot: if on-time measures were part of that plan, say which and what they showed, in your own words; if they were not, or someone else owned them, say so plainly and return to the surge plan you ran |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your quote carries adjacent work, mis-pick rate, and the words stay at that scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's cost-per-shipment line makes a probe on cost likely. If cost was tracked alongside that change, say what was counted; if it was not, say so plainly and say what you would measure first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD says 12 and your quote says 3, and the pack states the difference rather than closing it. Words: "I am currently a senior shift manager over 3 supervisors." Answer slot: if any earlier role had a different number of supervisors, say which and how many; if not, say so plainly and stay with the 3 |
| F5 | "build reporting in Excel/Power BI" — JD, Excel part | "solid Excel" — your message | low | [inferred] | discovery | The quote says your Excel is solid and nothing about reporting. Words at its scope: "My Excel is solid." Answer slot: if you have built reports or trackers in Excel, say what and for whom; if your Excel use has been of another kind, say so plainly |
| F6 | "build reporting in Excel/Power BI" — JD, Power BI part | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | The quotes show 7 years in ops and a current management role, and do not show how many of the 7 years were leadership. A length-of-experience requirement is not a gate, so it is graded like any other row. Answer slot: say which years were in a supervisory or management role and what the role was called, in your own words; if the leadership years are fewer than the seven, give that number plainly and do not round up |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you are green belt certified. Answer slot: if you have applied Lean or Six Sigma methods in your work, say where, in your own words; if the certification is the extent, say so plainly |

## Persona table

The round and the interviewer are unknown, so weights are flat and the loop is the generic archetype (screen, hiring manager, panel), not this company's documented process. The order below follows how much the JD exposes, not how likely each is.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of scope, years of leadership and tooling gaps | Equal weight. Rows F1, F4, F6 and F7 are where the JD and your quotes differ in number or kind | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Data-Driven Prober (bank B) | Line-by-line on the 40% and on how performance is measured | Equal weight. Your quantified claim and the JD's two named measures invite it | Know how each figure was counted, say plainly when you do not, name your weakest assumption first |
| Case / Strategist (bank C) | Live problems on on-time, cost, reporting, peak planning | Equal weight. The JD is a run-the-operation role | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Pressure (bank D) | Time-boxed, devil's-advocate versions of the scope and attribution probes | Equal weight. Present in the generic loop | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (bank E) | Friendly biography and company questions that are still scored | Equal weight. Common in a first conversation | A 90-second arc built from your own sentences; never "I think you've covered everything" |
| Values / Behavioral (bank G) | Scenario stories; no published values were researched | Equal weight, generic. A values-style round is not detected, so there is no values cheat sheet | Choose stories where the hard truth landed, and say plainly where none comes to mind |
| Peer Evaluator (bank H) | Seams between sites, credit-sharing | Equal weight. Possible if a site peer joins | Reciprocity framing; propose seam principles rather than pretend to know the seam |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role has 12 supervisors across 4 sites. What is the biggest step up from what you do today?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | The highest-ROI rehearsal in this pack. Say your role in those words: "I am currently a senior shift manager over 3 supervisors." Name the step up as the numbers the JD gives against the number you gave, and stop there. Expect two follow-ups, a version of "why now and not after more experience" and "what would you do first". Answer the second as a plan, never as a past. Answer slot: if any earlier role had a different number of supervisors, say which and how many; if not, say so plainly and stay with the 3. Concede the difference in scope specifically and hold the rest | F1 and F4 carry the biggest difference in scope between the JD and your quotes, so this objection will arrive in some form; JD because it scores a stated requirement |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Name it first: "I have never used Power BI." Then give a plan for getting capable in it, said as a plan with your own steps and no claim of progress you have not made. Do not trade it against the Excel line; give each its own sentence | F6 is the one gap you stated yourself, so you can own the answer before it is pulled out; JD because it scores the tool requirement |
| A3 | "The posting asks for 5+ years of operations leadership. How do you count yours?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the two facts as you stated them, in separate sentences. Answer slot: say which of those years were in a supervisory or management role and what the role was called, in your own words; if the leadership years are fewer than the seven, give that number plainly and do not round up. A lower honest count holds under follow-up; a rounded one does not | F7 is graded on evidence, not treated as a gate, and the count is the likeliest place to be tested; JD because it scores a stated requirement |
| A4 | "Why this role, and why now?" | EXP | [generic] | A reason has to be yours: pick one real pull toward this scope or this company, a concrete stake behind it, and a sentence that holds if they push. If no clear reason comes to mind, say so plainly, then give the nearest honest thing you can, or how you would decide | Motivation consistency is the Skeptic's standard probe; EXP because it tests whether your story survives cross-examination; `[generic]` because it is a pattern, not a fact about this employer |

### Bank B: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You cut mis-pick rate 40%. Walk me through how that figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before they do; and which part was yours. If you do not know how part of it was counted, say so plainly. Say the claim at its own scope: "I cut mis-pick rate 40% by redesigning the pick path" | F3's headline figure is the magnet target for a prober; EXP because it tests attribution and assumptions |
| B2 | "What did you actually change in the pick path?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats the quote states are the redesign of the pick path and the 40% fall in mis-pick rate; tell them in your own words. Answer slot: if you designed the change yourself, say what you changed; if others designed parts of it, or it was a shared effort, say so plainly and describe your part | F3 is your most specific evidence, so it gets the deepest follow-up; EXP because it tests what was actually yours |
| B3 | "The JD asks you to drive on-time performance. What have you used to measure it?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Say what you ran, in those words: "I ran the site's peak-season surge plan two years running." Answer slot: if on-time measures were part of that plan, say which and what they showed; if they were not, or someone else owned them, or you did not measure it, say so plainly and return to the surge plan you ran | F2's quote touches the requirement without showing it; JD because it scores the stated requirement |
| B4 | "The JD says cost-per-shipment down. What have you worked on that touches cost?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the quote at its own scope. Answer slot: if cost was tracked alongside that change, say what was counted; if it was not, say so plainly, then say which cost figure you would build first in this role, as a plan | F3 is adjacent to cost, not a measure of it; JD because it scores the stated requirement |

### Bank C: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You take over four terminals and on-time performance is slipping at one of them. What do you need to know first, and what do you do in week one?" | CASE | [generic] | Clarify before you structure: which measure, since when, which lanes or shifts, what changed. Then objective, how you would split the problem, your approach, the metrics you would watch and the risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time and four-site lines; `[generic]` because it is a pattern for the problem |
| C2 | "Cost per shipment has risen two quarters in a row. Diagnose it." | CASE | [generic] | Ask what is in the number and how it is calculated before you decompose it. Then split it into the parts you would test, say which you would check first and why, and what evidence would change your mind. No claim about your past | A live problem from the JD's cost-per-shipment line; `[generic]` for the same reason |
| C3 | "Twelve supervisors need one weekly view of their site's performance. What goes on it, and how do you build it?" | CASE | [grounded] "solid Excel"; "never used Power BI" | Structure it: who reads it, which decision each measure supports, how it refreshes, who owns it. Say your tool position in your own words: "My Excel is solid", and for the other tool, "I have never used Power BI", then the plan for it. Do not describe Excel work you have not told me about | The JD's reporting line meets F5 and F6 here; CASE because it is a live design problem |
| C4 | "Peak season is six weeks out and the volume forecast has jumped. How do you plan the four sites?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure the plan aloud. If you draw on your own history, stay at the quote: "I ran the site's peak-season surge plan two years running." Answer slot: say what that plan covered and which parts you set, in your own words; if parts were set by others, or it was smaller than a four-site plan, say so plainly | F2's quote is your nearest peak-planning evidence; CASE because the question is set in the role |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for four sites when you supervise 3 supervisors today?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold the position your own sentences carry: senior shift manager over 3 supervisors, you ran the site's peak-season surge plan two years running, and you cut mis-pick rate 40% by redesigning the pick path. Hold through two follow-ups by returning to those. Concede the scope difference specifically, then say what you would do first as a plan. Do not fold on what you can back | F1 and F4 under time pressure; EXP because it tests composure and the honesty of the claim |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you designed the change yourself, say which parts; if others made or shaped parts of it, say so plainly and name your own part. Hold your part through two follow-ups; concede exactly what was not yours | The stock Pressure stem applied to F3; EXP because it tests attribution |
| D3 | "You have never used Power BI. Why should we hire for a role that builds reporting in it?" | JD | [grounded] "never used Power BI"; "solid Excel" | Say the plain acknowledgment: "I have never used Power BI." Then "My Excel is solid", then your plan for the tool, in your own words. Hold the Excel statement at its scope and concede the Power BI point without padding it | F6 is a stated gap and F5 the nearest evidence; JD because it scores the stated tool requirement |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get to where you are?" | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc with only the beats those sentences state: 7 years in warehouse and distribution ops, now a senior shift manager over 3 supervisors, the pick-path redesign, the surge plan. Answer slot: how you started and how you moved between roles, in your own words; if a step was not a promotion or was not your choice, say so plainly | The biography question is the most common opener and it is scored; EXP because it checks the CV story |
| E2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say the quote: you are green belt certified. Answer slot: if you have applied it in your work, say where and what you did, in your own words; if the certification is the extent, say so plainly and say what you would apply first in this role, as a plan | F8 is a plus, asked casually; JD because it scores the stated preference |
| E3 | "What do you know about Atlas Freight?" | CO | [grounded] "regional logistics, 800 employees" | Say what the JD says and nothing beyond it as fact: it describes a regional logistics company with 800 employees and 4 sites. Anything further has to be something you found yourself, and you say where you read it. If you could not find much, say so plainly and say what you would want to learn | No company research ran, so this stays at the JD's own words; CO because it tests homework depth |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time with a named stake, a moment you did not soften the message, and a relationship still intact at the end. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem; `[generic]` because no published values were researched |
| G2 | "Tell me about a time a supervisor on your team was not meeting the standard. What did you do?" | VAL | [generic] | Choose a case where you can say what the standard was, what you said and what changed. Keep your own part separate from the supervisor's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's lead-the-team line raises it; `[generic]` because the story must come from you |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than pretending to know this seam: who owns which decision, what escalates and when. Add reciprocity, what you bring their team and not only what you need. No claim about your past | A peer probe on the four-site structure; `[generic]` because it needs no fact about you |
| H2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Choose an example where credit was shared and you can say who did what. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is a standard peer probe on attribution; `[generic]` because the example must be yours |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, C1, D1, H1 |
| "drive on-time performance" | B3, C1 |
| "cost-per-shipment down" | B4, C2 |
| "lead a team of 12 supervisors" | A1, D1, G2 |
| "build reporting in Excel/Power BI" | A2, C3, D3 |
| "5+ years operations leadership required" | A3, E1 |
| "Lean/Six Sigma a plus" | E2 |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| R1 | "How are the four terminals performing today on on-time and cost-per-shipment, and which matters more this year?" | It uses the JD's own two measures and tells you what your first 90 days are for |
| R2 | "How is reporting produced today, and who builds it?" | It scopes the reporting work honestly against your tool position and shows you are thinking about the build |
| R3 | "What would you want me to have seen across the four sites by the end of month one?" | It turns the scope step-up into a shared plan |
| R4 | "How long have the twelve supervisors been in post, and where do they need the most support?" | It shows you think about the team before the process |
| R5 | "What does success look like at the end of year one, and how would you measure it?" | It lets you tie your answers back to the measures they pick |
| R6 | "Is continuous improvement a formal programme here, or something each site does its own way?" | It gives your green belt a place to land without claiming it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across several sites | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a senior shift manager role over 3 supervisors, not several sites. The slots in A1, D1 and F1 stay inside that role |
| Led a team of 12 supervisors, or a team of that size | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors" |
| Improved on-time performance | Inflated form of F2 | F2's quote at its own scope. B3's slot asks only what the surge plan measured |
| Reduced cost per shipment | Inflated form of F3 | F3's quote at its own scope. B4's slot asks only what was counted alongside the redesign |
| Used Power BI, or built reports in it | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I have never used Power BI." No slot |

## Sources

Provided documents: the JD text pasted in your message; your own message. No `tuesday-dossier.md` was present.

Searches sent, all refused, none returned a result:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have supplied the published value names for a values cheat sheet and VAL themes; bank G is generic instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have named the loop; persona weights rest on the generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current strategy; E3 stays at the JD's words |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you meet (recruiter, hiring manager, peer, panel) → reweights every bank; a recruiter screen adds pay, notice, location and reason-for-leaving rows
- The interviewer's name → an interviewer read and a reverse question tied to their path
- Search access, or a pasted careers page, values page or strategy brief → a values cheat sheet, the real loop, and a company-grounded CO question; a deeper pass, up to 6 more searches and 2 more fetches and several more minutes, would add a strategy brief and recent org context
- Your own answers to the answer slots in rows F1, F2, F3, F4, F5, F7 and F8 → those rows move from discovery or transferability toward quoted evidence, and the banks regenerate from them
- Your green belt certificate and issuer → raises F8; the before-and-after mis-pick report or KPI view behind the 40% → raises F3
- The recruiter's guidance on focus areas or any announced exercise, such as a reporting task → coverage of the exercise
- Your CV text or a `tuesday-dossier.md` → evidence cells quoted from CV lines, and prohibited claims and objections arrive ready-made
