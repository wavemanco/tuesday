# Stripe — Product Operations Manager: final-round interview pack

- **Role:** Product Operations Manager, Stripe
- **Round:** final round; format, number of sessions and interviewers not yet known
- **Interviewer:** not known
- **Built on this assumption:** a single final-round conversation with an unknown relationship to you, no job description, no CV, and no research (the search permission was declined). Persona weights are therefore blended, and every question is `[generic]`.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows how you work |
| EXP | Work-experience deep-dive: what you actually did, and how much of it was yours |
| JD | Role-driven: can you do the listed job, including where you are thinnest |
| CO | Company and strategy knowledge: homework depth |
| CASE | Live problem set in the role: structure and reasoning |

Provenance labels: `[grounded]` traces to a document you provided or cited research; `[inferred]` is derived from a representative or adjacent source; `[generic]` is a role-family pattern with no claim about Stripe or about you. Nothing in this pack is `[grounded]`, because no documents or research were available.

## Fit snapshot (worksheet)

No CV or background was provided, so this is a worksheet. The requirements are role-family expectations written as plain prose, not quoted from a posting. Each row says what strong evidence looks like and gives a selection scaffold for you to fill from your own history.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating cross-team product launches or releases (role-family expectation) | none given | none | [generic] | discovery | Strong evidence is one launch or release you coordinated, with what was yours to decide and how the teams were kept aligned. Pick one such occasion and name your actual part in it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F2 | Using metrics to inform product or process decisions (role-family expectation) | none given | none | [generic] | discovery | Strong evidence is a metric you tracked, how it was counted, and a decision it changed. Pick one and say what you tracked and what you did with it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would choose the first metric |
| F3 | Designing or improving an operating rhythm such as planning, reviews or reporting (role-family expectation) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or changed, and whether people kept using it. Pick one and say what it was and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one |
| F4 | Aligning stakeholders across product, engineering and business teams (role-family expectation) | none given | none | [generic] | discovery | Strong evidence is a disagreement between teams and what you did about it, with your own part separated from the team's. Pick one and describe your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one |
| F5 | Building process, tooling and documentation that teams adopt (role-family expectation) | none given | none | [generic] | discovery | Strong evidence is something you built or changed that other people then used, and how you know they did. Pick one and say what it was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would build first |
| F6 | Location, in-office schedule and work-authorization terms for the role (role-family expectation) | none given | none | [generic] | hard_gate | Surfaced, not bridged. Your material does not establish whether you meet these terms. No wording can change that, so confirm them with the recruiter |

## Persona weights

No loop source established the format of this final round, so the weights rest on a pattern and not on a documented Stripe process. The fallback archetype is Generic: screen, hiring manager, panel, with flat weights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems about launches, process and metrics | Highest. Both the hiring-manager and skip-level priors lead with it, and a product operations role is naturally tested through live problems | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of gaps, motivation and why now | High. It is the other lead persona in the hiring-manager prior, and a final round is a decision round | Rehearse the weakest-point answer until it is boring; build bridges only from things you really did; give a concrete ramp plan |
| Peer Evaluator (C) | Seam-splitting with adjacent teams, credit, collaboration | Medium. A final round often includes someone who would work alongside you | Offer seam principles and reciprocity; do not pretend to know their seam |
| Values/Behavioral (D) | Scenario stories about how you act under tension | Medium. The cross-functional prior leads with it; no values-style round is established, so these are not mapped to Stripe's published values | Pick stories where you can say what was yours; use "we" for context and "I" for contribution |
| Pressure (E) | Time-boxed, devil's-advocate challenges | Medium. The skip-level prior includes it and finals test composure | Pause, restate the question, hold your position through two follow-ups, concede only what is true |
| Conversational (F) | Friendly biography and open-ended questions | Low to medium. Likely as an opener; it is still scored | Prepare a 90-second arc; treat casual questions as scored |
| Data-Driven Prober (G) | Counting, denominators, assumptions | Low. It rises sharply once a CV with figures exists | Know how any number you cite was counted, and say plainly when you do not |

## Question banks

The deepest rehearsal in this pack is **B1**, the day-one weakness question. Without your CV the pack cannot name your specific objection, so B1 is the pattern version; once your CV is added it will be rewritten around the real one.

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and three teams disagree on what ready means. What do you do first?" | CASE | [generic] | Clarify before structuring: who decides, what the launch risk is, what is fixed. Then state an objective, a way to get a shared definition, and the risks of each path. Challenge one premise, such as whether two weeks is the real constraint. The question needs no claim about your past, so the guidance makes none | Launch coordination is a core role-family theme, so a live version is likely. CASE because it scores structure, not history |
| A2 | "Product teams say our release process slows them down. How would you decide what to change?" | CASE | [generic] | Start by asking what evidence of slowness exists and for whom. Separate steps that protect quality from steps that only add delay, say how you would test a change, and name what would make you leave the process alone. No claim about your past is needed | Tests whether you improve a process from evidence rather than instinct. CASE because it is a live problem |
| A3 | "A new planning cadence is ignored by half the org after a month. Diagnose it." | CASE | [generic] | Offer two or three hypotheses before asking for data: unclear owner, cost exceeds value, no consequence. Say what you would check for each and what you would try first. State which hypothesis you would drop fastest | Adoption is the usual failure of operating processes, so it is a likely diagnostic. CASE because it asks for reasoning under ambiguity |
| A4 | "How would you decide which metrics a product launch should be judged on? Say what you need to know first." | CASE | [generic] | Ask what the launch is meant to change and for whom. Propose a small set covering outcome, adoption and risk, and say which one you would distrust first and why. No figure or past result is needed | Probes metric judgment without depending on a CV figure. CASE because it is a live problem |
| A5 | "Why Stripe, and what should product operations be doing here in its first year?" | CO | [generic] | Say what you have personally read, used or noticed about Stripe, in your own words. This pack holds no verified facts about Stripe's current strategy, so none are supplied. If you have not looked closely yet, say what you would want to learn first and how | The company-knowledge slot where research would have helped most. CO because it tests homework depth and altitude |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Name one real weakness from your honest assessment, not a disguised strength. Concede it in one clear sentence, then give a concrete ramp plan as a plan, never as a past. Hold your position through two follow-ups. If nothing comes to mind, say so plainly and name where you would ask for help first | This question will be asked in some form in a final round, and a calm, specific answer changes the interview. JD because it scores fit against the role |
| B2 | "Why product operations, and why this move now?" | EXP | [generic] | Give two real reasons in two sentences: what draws you to the work and what draws you to this role. Keep them consistent with what you will say in the biography question. If part of the honest reason is practical, say that plainly | Motivation consistency is what the Skeptic scores. EXP because it tests whether your story holds up |
| B3 | "Product operations can slide into project management. How do you tell the difference?" | JD | [generic] | Give your own working definition in a sentence, then one way you would tell, such as whether you change how decisions get made or only chase their delivery. Offer one boundary you would hold. No claim about your past is needed | Tests whether you understand the function's scope, which is a common probe for this title. JD because it scores role understanding |
| B4 | "What would you want to learn in your first 30 days before changing anything?" | JD | [generic] | Name three things you would find out: how decisions get made, where teams feel friction, and what is already working. Say who you would ask. The aim is to show you diagnose before you act | Guards against the "fixer" impression a skeptic looks for. JD because it scores approach to the role |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you cannot know: who owns the decision, who owns the follow-through, how disagreements escalate. Say you would want to learn the real seam from them. Show spine and tact together | Peers price what a hire adds to their load. JD because it scores partnership in the role |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick an occasion where credit was shared and say what you did about it. Use "we" for the team and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The credit-sharing probe is a standard peer check. VAL because it tests behavior with equals |
| C3 | "What would you need from me in your first month, and what could you do for my team?" | EXP | [generic] | Lead with the reciprocal half: what you would take off their plate or make clearer. Then name two specific things you would need. Keep both about working practice, not about your history | Reciprocity framing is what the Peer Evaluator is scoring. EXP because it tests how you describe working with others |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not fold, and a relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values probe; no Stripe values are established here, so it is generic. VAL because it scores past behavior |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a real tradeoff and say what you gave up. Say what was yours to decide. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it | Customer-versus-metric tension recurs in product work. VAL because it scores judgment shown in behavior |
| D3 | "How do you decide when to hold a standard and when to make an exception to keep a launch moving?" | VAL | [generic] | State your rule of thumb first, then the test you apply: reversibility, risk to users, who bears the cost. Say who you would tell about an exception. The question needs no claim about your past | A natural bridge between values and the role's daily tradeoffs. VAL because it scores principle in action |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give one reason in your own terms and stop. Hold it through two follow-ups. Concede specifically what you do not yet know about the organisation, without folding on the core reason | Pressure interviewers test composure. JD because it scores your case for the role |
| E2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Choose the result, then separate your part from the team's in plain terms. Say what you would credit others for. If you are unsure how much was yours, say so plainly; precise honesty holds up better than a big claim | This is the attribution probe, rehearsed so candor is ready. EXP because it tests what you really did |
| E3 | "Product leadership says a process like this is bureaucracy and wants it dropped. You have a minute: defend it or concede." | CASE | [generic] | Hold first: state what the process protects. Then concede one specific thing that is genuinely weak. End with a proposal to keep what protects and drop what only adds delay. No claim about your past is needed | Tests holding a position without defensiveness. CASE because it is a live problem under time pressure |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc in three beats: where you started, what pulled you toward product operations, why this role. Use only things you can say in your own words. If no thread connects your roles, say so plainly and give the nearest honest reason | The biography opener is scored even when it feels casual. EXP because it tests your account of your own history |
| F2 | "What have you been trying out lately that changed how you work?" | JD | [generic] | Name something real and small, and what it changed. If nothing comes to mind, say so and say what you would like to try and why | Casual questions about current practice are scored for genuine interest. JD because it checks curiosity relevant to the role |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Pick a metric you owned or tracked. Walk me through how it was counted." | EXP | [generic] | Choose one and say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of it was yours, each in your own words. If you do not know how it was counted, say so plainly | The defend-the-number probe, rehearsed before you have a CV figure to attach it to. EXP because it tests precise attribution |
| G2 | "How would you know a product operations function is working? Which number would you distrust first?" | JD | [generic] | Give two or three measures of the function's effect, then name the one you would trust least and why. No claim about your past is needed | Tests whether you can measure a function whose outputs are indirect. JD because it scores role understanding |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 Cross-team launches or releases | A1, A2, B3, D3, E3 |
| F2 Metrics informing decisions | A4, G1, G2, E2 |
| F3 Operating rhythm | A3, A2, B4 |
| F4 Stakeholder alignment | C1, C2, C3, D1 |
| F5 Process, tooling, adoption | A2, A3, B3, F2 |
| F6 Location, schedule, work authorization | none: a gate is confirmed with the recruiter, not rehearsed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like in the first six months, and how will you tell?" | Turns a vague scope into something measurable and shows you think in outcomes |
| R2 | "Which teams does product operations work with most closely, and where do the seams sit today?" | Shows you think about seams before they bite, and gives you a read on how the function is positioned |
| R3 | "What is one process you would like this role to change in the first quarter, and what makes it hard?" | Invites the real priority, not the posted one, and signals you are already thinking about the first change |
| R4 | "How is product operations measured, and has that changed?" | Signals metric judgment and surfaces whether the function's value is well understood |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity: positions you as additive to their load, which a peer weighs heavily |
| R6 | "What does the final decision on this hire turn on? Is there anything from our conversation you would want to probe further?" | Gives the interviewer a chance to name a doubt you can answer on the spot |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No CV or statements about your past were supplied, so no sentence exists for this pack to inflate, and no negative was stated | Every experience cell is a selection scaffold ending in an honest branch. Bring only what you actually did, at the scope you actually had |

## Sources

Provided documents: none beyond your message. Dossier: none present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search sent was refused because search permission was not granted. They were:

| Query | What came back |
|---|---|
| Stripe operating principles values | refused |
| Stripe interview process product operations manager final round | refused |
| Stripe strategy 2026 news annual letter | refused |
| Product Operations Manager job description Stripe responsibilities requirements | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have decided whether a values-style round is detected and fed a values cheat sheet; none is included |
| 2. Stripe interview process, product operations | unavailable | Would have set the loop structure and persona weights; weights rest on the Generic archetype instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A5 and any CO question in current priorities; A5 is generic |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the F1 to F6 role-family rows into `[inferred]` rows quoted from a posting |

## Upgrade menu

- Job description text → F1 to F6 become quoted `[grounded]` requirements and the JD-tagged questions are re-aimed at the posting's own list
- Your CV or a few lines on your background → the worksheet becomes a real fit snapshot, and guidance changes from selection scaffolds to story-mapped answers for the rows your own words reach
- Who you are meeting in the final round and any recruiter guidance on focus areas or a deliverable → persona weights are recomputed, and a build section is added for any announced deliverable
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- Search permission → Stripe's published values, documented loop and current strategy replace the generic rows, and A5 and any CO question become grounded
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → strategy brief, interviewer footprint, role-family loop reports and recent organisation context
- A `tuesday-dossier.md` from an earlier role assessment → verified evidence quotes, a named top objection for B1, and absolute prohibited claims
