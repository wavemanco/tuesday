# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: a 45-minute conversation with the hiring manager (name not given), on Thursday. Built from your tuesday-dossier.md (v1.1) and your own words. Web research was not available, so nothing in this pack states a fact about Quartzline beyond what the dossier carries (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding to rehearse from, not a script. Where a Provenance cell holds a quote, that quote is the only thing the guidance says about your past. An answer slot is an instruction for the interview, not a question to me: answer whichever branch is true for you, in your own words.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows a value, not generic virtue |
| EXP | Work-experience deep-dive: whether your stated work survives scrutiny and attribution |
| JD | Role or JD-driven: a stated requirement or responsibility, including its gaps |
| CO | Company and strategy knowledge (no CO questions appear in this pack: research was refused, see Sources) |
| CASE | A live problem set in the role, delivered aloud |

The highest-ROI rehearsal is A1. The underwriter named that objection from the evidence you confirmed, so it is theirs and not an inference. Rehearse A1, then D1 (the same objection under a time-box), before anything else.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | low | [grounded] | transferability | Bridge, with its limit named, as the dossier's allowed strategy for R1 requires: adjacent work, never PM experience. The words are the quotes at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I ran quarterly roadmap-input sessions feeding client evidence to product." The limit, as the pack's observation: your material shows integration work and input to product, not the PM title or time in it. Plain acknowledgment, source `prohibited_claims`: "Having held a product manager title or role" — so the words are "I haven't held a product manager title or role." Answer slot: the JD's 3+ years line makes a probe on how long product decisions were part of your work likely. If any of your work involved product decisions, say which and for how long, in your own words; if none did, say so plainly and stay with the integrations you led |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | capability | Dossier area `acknowledge_gap`: "Owning a roadmap and prioritization authority (R1 sub-claim)". No bridge, because the underwriter looked and found none. Words, source `prohibited_claims`: "Having owned a product roadmap" — "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: what you would learn first and whom you would ask. No answer slot |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | discovery | The dossier lists R2 as a must-have and a high-priority requirement but grades no gap for it. This row is the pack's own grading from the one quote that touches it, which shows client integrations led, not whether any API or platform product shipped. Answer slot: the JD's "Shipped API or platform products" line makes a probe on what shipped likely. If you shipped an API or platform product, or part of one, say what and which part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified evidence 2 | low | [inferred] | discovery | The quotes touch technical work around REST APIs and a playbook; they do not show whether API docs or schemas were part of it. Answer slot: the JD's "API docs, schemas" line makes a probe on that likely. If docs or schemas were part of the integrations or the playbook, say how, in your own words; if not, say so plainly and stay with what the playbook covers |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [inferred] | discovery | The quotes show client-facing integration work and client evidence fed to product; they do not show work with sales or with engineering teams, and the second quote is confirmed with limited inspectable proof, so expect a probe. Answer slot: the JD's line names engineering, sales and customers, so a probe on each side is likely. If you worked with sales or engineering on those integrations or sessions, say how, in your own words; if you did not, say so plainly and stay with the clients and product |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | The dossier's allowed strategy for this area is clarify: the evidence may exist and was not established, and none of the confirmed quotes speaks to it. Answer slot: "Agile delivery experience" is the interviewer's likely probe. If you have worked that way, say how, in your own words; if you never worked that way, say so plainly. Then the clarifying move: "Here is what I'd want to confirm — how do you define agile delivery on this team?" |

Note on the dossier's prose: its decision summary describes seven years of integration leadership, but no verified entry carries a figure of years, so the pack uses none. If years come up, give your own count in your own words.

## Persona table

Loop: one 45-minute conversation with the hiring manager, from your own words, so session mode and no archetype fallback. No values-style round is detected.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap, and of why now | High (5 questions). Hiring-manager prior: they are derisking gaps; the dossier names the objection this persona asks | Rehearse A1 until it is boring; bridge only from the quotes with the limit named; concede the title and roadmap plainly |
| Case/Strategist | Live problems on the role's own platform and roadmap | High (5 questions). Hiring-manager prior: expect live problems on their roadmap; the JD's responsibilities supply the themes | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully; make no claim about your past |
| Data-Driven Prober | Line-by-line on the 30+ figure, the playbook and the sessions | Mid (3 questions). F1 carries the only figure and F4 an inspectable playbook; adoption metrics are a stated responsibility | Say how the figure was counted, or plainly that you do not know; name the assumption you would defend least; offer the playbook as something to walk through |
| Pressure | Time-boxed "why you", attribution pushes, interruptions | Mid (3 questions). The named objection invites a time-boxed form | Pause, restate, hold through two follow-ups by returning to the quotes, concede the specific thing and not the work |
| Conversational | A friendly opener such as "walk me through the journey" | Low (2 questions). A 45-minute round likely opens with biography, but it is one question | A 90-second arc built only from the three quotes, then your own reason for this role |
| Peer Evaluator | Seam-splitting with the squad leads, credit across teams | Low (2 questions). The interviewer is a manager, not a peer, but the JD names two squads and the dossier flags decision authority as unverified | Propose seam principles instead of pretending to know the seam; reciprocity framing |
| Values/Behavioral | Scenario probes on hard truths and customer-first choices | Low (2 questions). No values round is named in your words and no published values are in hand | Selection scaffolds with an honest branch; do not force a story |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap" | The deepest rehearsal in the pack. Four beats, 90 to 120 seconds. 1) Concede first, plainly: "I haven't held a product manager title or role, and I haven't owned a product roadmap." 2) The adjacent case, quotes at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product." 3) Name the limit before it is asked: "That is adjacent to the job, and I'm not calling it the same job." The sessions are confirmed with limited inspectable proof, so expect a probe: say what you can back up and where your knowledge stops. 4) A ramp plan, said as a plan: "In the first weeks I would ask which roadmap decisions are mine and which belong to the squad leads, and learn how adoption is measured today, before proposing anything." Follow-up 1, "What in that was product work?": answer slot: the JD's 3+ years line makes a probe on which of your work was product work likely. If any of it was, say which and what you decided, in your own words; if none was, say so plainly and stay with the integrations you led. Follow-up 2, "What would you get wrong in month one?": the gap from beat 1, not a new one. Follow-up 3, pressing on the three years: hold by returning to the quotes, concede that the title and the roadmap are the difference, and add nothing to the quotes | The underwriter named this objection, so it is theirs. F1 and F2 are where a hiring manager presses hardest; JD because it scores the R1 requirement, with Skeptic delivery |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap`: "Owning a roadmap and prioritization authority (R1 sub-claim)"; `prohibited_claims`: "Having set prioritization for an engineering squad" | Answer with the area the underwriter found no evidence for, plainly: "Owning the roadmap and prioritization authority. I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan in the future tense: learn which decisions are mine and which are the squad leads', read the roadmap as it stands, ask how adoption is measured today. Offer no second weakness and no bridge for this area | F2 is the named gap; this is the Skeptic's own stem. Calibrated candor here beats bluffing a competency the interviewer owns |
| A3 | "This role asks for shipped API or platform products. What have you shipped?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote states, in your own words: 30+ client integrations of the vendor's REST APIs, led, end to end. Answer slot: the JD's "Shipped API or platform products" line makes the probe likely. If you shipped an API or platform product, or part of one, say what and which part was yours; if you did not, or it was not yours, say so plainly and return to the integrations you led. Do not let the word "shipped" stand for integrations | F3 is a must-have the dossier did not grade, so this is the likeliest unplanned probe; inferred because the grading is the pack's own |
| A4 | "Why product management, and why now?" | EXP | [generic] | Selection scaffold. Name, in your own words, one specific thing in this role's work that you want to do and one reason it is this role and not another; the pack supplies no reasons. If no specific reason comes to mind, say so plainly, then give the nearest thing your own reasons carry, or how you would find out whether the role fits | The Skeptic's motivation probe; EXP because it tests consistency of your story, and generic because the pack holds no stated motive of yours |
| A5 | "Tell me about a time you worked inside an agile delivery cycle." | JD | [grounded] | Clarify strategy, no claim about your past. Answer slot: "Agile delivery experience" is the interviewer's likely probe. If you have worked that way, say how, in your own words; if you never worked that way, say so plainly. Then: "Here is what I'd want to confirm — how do you define agile delivery on this team?" | F6 is a clarify area, so the question-shaped answer is the honest one; JD because it scores the R5 line |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose new partners sign up for the API but few reach production use. What do you do first?" | CASE | [generic] | Clarify first: what counts as adoption here (the dossier lists how adoption is measured today as unknown, so ask), where in the funnel from sign-up to production they drop, which partner segments. Then objective, segmentation, hypotheses (docs, sandbox, auth, support, fit), metrics, risks. Think aloud and challenge one premise, such as what "few" is measured against. No claim about your past | Adoption metrics are a stated responsibility, and a hiring manager's live problem comes from their own roadmap; generic because it is a pattern, not a fact about Quartzline |
| B2 | "Two partners ask for conflicting features, sales wants one of them promised for a deal, and both squads are full. How do you decide?" | CASE | [generic] | Clarify first who owns the call, since decision rights are unverified in the JD. Then each partner's underlying need, deal value against platform-wide value, and the capacity cost, worked out with the squad leads. Answer as method, not as history: the prohibited list (section 13) bars any claim to have set a squad's priorities | Tests R4 across engineering, sales and customers and the roadmap gap in F2 in one problem; CASE delivery, JD content |
| B3 | "You start Monday. Sketch your first 30 days — what do you need to know first?" | CASE | [generic] | Three buckets, listening before proposing: decision rights and how the squads work, the adoption baseline, the partner picture. End with one small first deliverable. These are the same things as your reverse questions, so the two answers should match | The Case stem on the actual role; doubles as the ramp plan for F2 |
| B4 | "A widely used v1 endpoint has to be retired. Walk me through the plan." | CASE | [generic] | Who is affected, what breaks (schemas, docs, auth), the migration path and timeline, partner communication, support load, how you would know it worked, rollback. Say what you would ask engineering. No claim about your past | Tests platform-product judgment and the R3 line on docs and schemas; the question presupposes nothing about you |
| B5 | "What would you put on a partner API adoption dashboard, and what would you refuse to put on it?" | CASE | [generic] | Tie each metric to the funnel you clarified in B1; a metric earns its place only if it changes a decision; name one vanity metric you would refuse; state the weakest assumption in your dashboard; say what baseline you would ask for first | Adoption metrics are a stated responsibility with no baseline stated in the dossier, so the honest answer includes what you would need to ask |

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say 30+ client integrations. What counted as one integration?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Lead with the quote at its scope. Answer slots, each in your own words: how the 30+ was counted; what the figure is sensitive to; the assumption behind it you would defend least; which part of each was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F1 carries the only headline figure, which is where a prober starts; EXP because it tests attribution |
| C2 | "Tell me about the integration playbook — what's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats are the quote's: you wrote it, it is internal, your team uses it. The underwriter marks it inspectable, so offer to walk it through end to end and describe its contents from the document itself. Answer slot: the JD's "API docs, schemas" line makes a probe on whether the playbook covers them likely. If it does, say how, in your own words; if it does not, say so plainly and stay with what it covers | F4 rests on this document, the most inspectable evidence you have; EXP, with the R3 requirement as the reason for the probe |
| C3 | "Walk me through how you ran the quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The beats the quote states: quarterly, roadmap-input sessions, you ran them, they fed client evidence to product. This one is confirmed with limited inspectable proof, so volunteer the limit before it is extracted: say what you can back up and where your knowledge stops. The pack's observation: the quote says evidence went to product, not that a roadmap changed. If asked what product did with it, say what you actually know; if you do not know, say so plainly | F1 and F5 both lean on these sessions and neither is inspected, so the probe is certain; EXP because it tests what was yours |

### D. Pressure (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap" | A1 under a clock. Pause, restate the question, then: one sentence of concession ("I haven't held the title or owned a roadmap"), the two quotes in one breath, one forward line on what you would settle in month one. Hold through two follow-ups by returning to the quotes, never by adding to them. Concede the specific thing, the title and the roadmap, and not the work | The Pressure stem on the named objection; practice delivery here so A1's content survives interruption |
| D2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold only what the quote carries: you led them. Answer slot: which of scoping, requirements, architecture, UAT and go-live were yours, each in your own words; if a stage was shared or someone else's, say so plainly and return to what you led. Hold through two follow-ups; concede a specific stage if it was not yours, never the whole claim | F1's headline claim is exactly what an attribution push targets; rehearsing the concession is the point |
| D3 | "Two squad leads push back on your priorities in front of the team. Do you overrule them?" | CASE | [generic] | Pause. Do not answer yes or no before asking who owns the call. Then the principle: hear the evidence, name the decider, use the escalation path. Concede explicitly: "I don't know yet where the line sits here, and it's the first thing I'd settle." Method only: the prohibited list (section 13) bars claiming you have set a squad's priorities | Squad-lead authority is the dossier's open unknown, so this is the likeliest form of it under pressure; CASE because it asks about no past |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each a clause the quotes state: the integrations you led, the playbook you wrote, the sessions you ran. Close with one sentence in your own words on why this role; the pack supplies none. Add no title, years or employer claims beyond the quotes | The casual question is still scored; it is also where the arc for A1 is first heard |
| E2 | "What are you actually playing with in the API space these days?" | JD | [generic] | Selection scaffold. Name something specific you have used lately, in your own words, such as a spec, a tool or a docs approach; the R3 line makes this casual question a scored one. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would get up to speed | Casual register, JD content (F4); generic because the pack holds nothing about what you use now |

### F. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where's the seam between you and the two squad leads, and what happens when we disagree?" | JD | [inferred] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Propose seam principles instead of claiming to know the seam: the what and why, grounded in partner evidence, against the how and capacity with the squad leads; say the actual line is on your list to confirm. Disagreement path: evidence first, a named decider, then escalation. Reciprocity, from the quote at its scope: what you would bring them is client evidence, as in "I ran quarterly roadmap-input sessions feeding client evidence to product". The limit is that this was input to product, not decisions about it | Squad-lead authority is the open unknown behind F2 and F5; inferred because the reciprocity is the pack's derivation |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold. Pick a time work spanned teams; use "we" for context and "I" for your contribution; it needs a named moment where credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer stem; VAL because it scores behavior, not a JD line |

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact afterward; "we" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values stem; asked at low weight because no values round is named. No published Quartzline values are in hand, so no value is mapped |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, the metric it cost, and what the customer got; choose a story in which the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second Values stem; customer-first is a common frame, and the pack mapped no value to it |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" (must_have) | A1, A2, D1 |
| R1 sub-claim, owning a roadmap | A2, B2, D3 |
| R2 "Shipped API or platform products" (must_have) | A3, B4 |
| R3 "Technical fluency: API docs, schemas" (important) | C2, B4, E2 |
| R4 "Stakeholder management across engineering, sales, customers" (important) | B2, C3, F1 |
| R5 "Agile delivery experience" (preferred) | A5 |
| Responsibilities in the dossier's role_profile, not stated requirements | Discovery with partners: B1, B3; specs and delivery with two squads: F1, D3; adoption metrics: B1, B5 |

A4, C1, D2, E1, F2, G1 and G2 score no single requirement; they cover motivation, attribution, biography and behavior.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority as asserted in the JD but not evidenced. It reads as diligence, and the answer is something you need before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no baseline stated; the answer shows what you would be judged on |
| 3 | "How do the two squads split the platform today, and where does work fall between them?" | Shows you read the two-squad structure as a seam to understand, and informs your answers to D3 and F1 |
| 4 | "How does partner feedback reach the roadmap today, and where does it get stuck?" | Invites the interviewer to describe the loop, which gives you room to place the work F1 and F5 quote at its own scope without claiming ownership of it |
| 5 | "How do the squads run delivery day to day — cadence, planning, who writes specs?" | Tells you how this team defines the agile delivery that F6 asks about, so the "what I'd want to confirm" branch gets a real answer |
| 6 | "What would a strong first 90 days look like, and what would worry you at day 30?" | Asks the interviewer to state the bar; pairs with your B3 answer |

## Prohibited claims

Built before the banks and binding on every cell above. The first three are the dossier's `prohibited_claims`, absolute; the fourth is built here.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | F1's quotes at their own scope, plus the plain acknowledgment "I haven't held a product manager title or role." No answer slot |
| Having owned a product roadmap | Dossier `prohibited_claims`; also the `acknowledge_gap` area for F2 | The plain acknowledgment "I haven't owned a product roadmap," then a ramp plan said as a plan. No bridge and no answer slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment "I haven't set prioritization for an engineering squad." The nearest quote, "Ran quarterly roadmap-input sessions feeding client evidence to product", stays at its own scope |
| Ran product discovery with integration partners | Inflated form of the roadmap-input sessions in F1 and F5 | The sessions quote at its own scope. The limit is the pack's observation: the material says sessions that fed client evidence to product, not discovery with partners |

## Sources

Provided: your message (a 45-minute hiring-manager conversation on Thursday) and tuesday-dossier.md, dossier_version 1.1, job-underwriter, 2026-08-14. Dossier sections consumed: role_profile (requirement lines stand as the JD's; responsibilities and unknowns read as context), handoff_to_mock_interview (all fields), decision (context only; conditional_go). No evidence_map, evidence_state or risk_register was present. Rows resting on your confirmed evidence are F1, F2 and F6 (graded by the dossier) and every quote in a Provenance cell; F3, F4 and F5 are this pack's own grading, labeled inferred.

Searches sent, each refused (search permission was not granted in this session):
- `Quartzline company values` — refused
- `Quartzline interview process product manager` — refused
- `Quartzline API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have moved a values cheat sheet and mapped VAL questions; no published value is in this pack |
| 2. `Quartzline interview process product manager` | unavailable | Would have moved loop structure and persona weights; weights rest on your own words about one hiring-manager conversation and relationship priors |
| 3. `Quartzline API platform strategy news` | unavailable | Would have moved CO questions and strategy-grounded CASE questions; none appear, and the CASE bank is generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so no query could be formed; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission for this session → values, loop structure and strategy facts (up to 6 searches, 2 fetches): a values cheat sheet, CO questions and strategy-grounded CASE questions replace the generic ones; a deeper pass (up to 6 further searches and 2 further fetches, several more minutes) would add a strategy brief and interviewer footprint
- The hiring manager's name → an interviewer read, persona weights tuned to their public career pattern, and a reverse question tied to their own path
- The recruiter's prep email, with any focus areas or pre-declared deliverable → coverage of a take-home or presentation, and weights keyed to what they name
- Hours available before Thursday → a prep triage schedule sized to them
- The full JD text → the paraphrased requirement lines in F1 to F6 become exact quotes, and the responsibilities become sources a question may presuppose
- Your own answers to the slots in F3, F4, F5 and F6, said outside a drill → those rows move from inferred to grounded and their slots in A3, A5, C2 and F1 become story maps
- Agendas or notes from one roadmap-input session, and the integration log behind the 30+ count → the medium-confidence evidence behind F1, F5, C1 and C3 becomes inspectable
