# Interview pack: Live Operations Producer at Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations, treated as the hiring manager. Format assumed: the single 60-minute session. If either assumption is wrong, the persona weights and banks change.

## How to use this pack

- Personas are how a question is asked. Types are what it is scoring.
- Type key: VAL tests behaviour against Saltmarsh's published values. EXP tests whether your background survives scrutiny. JD tests a stated responsibility or requirement. CO tests knowledge of the company and its strategy. CASE is a live problem set in the role.
- Guidance is scaffolding, not a script. Every word proposed for you to say is pending your approval: change it into your own, and drop any line you could not repeat under a second question.
- Provenance labels: grounded means traceable to something you or a cited source said. Inferred means derived, with the derivation named. Generic means a role-family pattern with no claim about you or Saltmarsh.
- Answer slots are instructions for the interview. They ask for no reply here.

## Fit snapshot

Wording in the last column is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." The material shows a weekly content-drop calendar for one title, not events and not a second title. Answer slot: the JD's two-titles line makes a probe on running two calendars likely. If you scheduled live events, or worked on a second title, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with the one title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Inferred from a calendar sentence that touches coordination without naming any team. Answer slot: the JD names four teams, so expect a probe on which you worked with. If you worked with any of design, art, engineering or community on a drop, say which and what you asked of each, in your own words; if none, or the calendar sat apart from them, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting numbers is adjacent to owning a review and its KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." The material shows monthly retention numbers, not post-event reviews, and does not show who chose the numbers. Answer slot: the JD's own-the-review line makes a probe on who defined the KPIs likely. If you chose or defined any of what went into the readout, say what and how; if the numbers came from someone else, or there was no review per event, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms: you wrote it, and your QA team still uses it. Lead with those terms. The material says wrote, not managed each release, so expect a probe on the verb and keep to wrote. Nothing is inspected behind a message sentence; the checklist itself would raise the band |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The sentences show four years as an associate producer and two years of weekly drops; they do not say the title ran as a live service. Answer slot: the JD's 3+ years line makes a probe on how many years were live-service likely. If the title ran as a live service, say for how long, in your own words; if only part of the four years did, or none, say so plainly and stay with the associate-producer years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap: the quote reaches it. Lead with it as stated: weekly, main title, two years. Nothing is inspected behind it, so expect a probe on how a week's drop was decided, which E2 rehearses |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches it in role-relevant terms: monthly, to the studio head. The material holds no figure and no measure name, so there is no number to defend, and the probe will be on which measures they were, which D1 rehearses |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | One written artifact in use is adjacent to the requirement, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: if asked for more examples of your writing, say which pieces and who read them, in your own words; if the checklist is the main one, say so plainly |
| F9 | Role-family expectations, plain prose, neither in the JD: working on a monetised mobile title, and leading people | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." and "I haven't led a team." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap smaller |

## Reading the interviewer

Public professional footprint only, quoted from Sources S4.

| Public signal | What the source says | Practical implication |
|---|---|---|
| Published talk | "Patch Notes Are a Promise", GDC 2026: "a live team is judged by how often its patch notes describe what actually shipped" | Expect precision about what shipped versus what was planned. In answers, separate what was done from what was intended. A2 and B2 rehearse this |
| Career path | "previously a QA lead at a console studio" | Release and QA process questions are likely to be probed closely. H1 and G2 rehearse the checklist |
| Role | Head of Live Operations at Saltmarsh Games | The tabletop and values conversation described in S2 sit with this seat |

Mirror opportunity, pending your approval: his public path runs through QA and release quality, and F4's evidence reads "Wrote the release checklist our QA team still uses." Say it as written. It is a shared professional ground and no more; do not extend it into a claim about owning releases.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a live problem set in the role | High. Prior for a hiring manager. S2: "a live-incident tabletop on a simulated outage during a live event, then a values conversation" | Clarify, then objective, who owns what, what you say to players, what you record. Think aloud. Rehearse A1 against a timer |
| Skeptic | Quiet probing of the gaps: monetisation, live-service years, leading people | High. Prior for a hiring manager, and F9 holds two stated gaps | Rehearse the single most predictable objection until it is boring (C1). Acknowledge plainly, bridge only from adjacent evidence, give a ramp plan |
| Values / Behavioral | The second half of the session | High. S2 documents "a values conversation" in this session, and S1 names three values | One story or an honest scaffold per value (section below). We for context, I for your contribution |
| Data-Driven Prober | Measures and who owned them | Medium. The JD names retention metrics and KPIs, and S4 shows a theme of accuracy. Your material holds no figure, so the probe is on practice | Say which measures you used and what you do not know about how they were counted |
| Conversational / Rapport Builder | The opener and the walk-through of your journey | Medium. It opens most interviews and is still scored | A 90-second arc built from your four sentences (E1) |
| Peer Evaluator | The seam between live ops and QA | Low. Tobias is not a peer on the stated assumption; the seam still comes up through the release checklist | Principles for the seam, plus what you bring QA |
| Pressure / Stress | Time-boxed or interrupting follow-ups | Low. No source signals it; a timed tabletop can feel like it | Hold what your quotes carry through two follow-ups, then concede specifically |

## Question banks

Ordered by weight. Wording proposed for you to say is pending your approval.

### Bank A: Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event has been running twenty minutes and players are telling support they can't log in. You have ninety seconds: what do you do first?" | CASE | [generic] | Say it aloud in this order: what you need to know first (scope, who is affected, since when, whether the event timer can be moved), the objective, who owns the incident and who owns player communication, what players are told and when, what you record for the review. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | The tabletop format in S2 opens like this. CASE because it scores structure under time pressure. The scenario is a pattern, not a fact about Saltmarsh |
| A2 | "Engineering says a fix is forty minutes out, community wants to tell players now, and art says the make-good assets aren't ready. Walk me through the next ten minutes." | CASE | [inferred] | Applying S1's published line, "we announce what is built, not what is hoped", to this scenario: sort what is confirmed from what is hoped before anyone speaks to players, say only what is confirmed, and give the time of the next update. Name who decides what and what you ask of each team. Challenge one premise, for example how firm the forty minutes is | Inferred from S1's value and S4's theme of what shipped. CASE because it is a live problem. It makes no claim about your past |
| A3 | "The event is back up. What goes into the post-event review, and which numbers do you want first?" | CASE | [generic] | Structure: timeline, what players saw, decisions and who made them, what changes before the next event. Ask what the team already tracks before naming numbers, and say which numbers you would request rather than inventing any. No claim about your past | Follows the tabletop into the review the JD asks the role to own (F3's requirement). CASE because it is delivered as a live problem |
| A4 | "From February 2027 two of our titles share one events calendar and one live-ops group. What breaks first when both want the same weekend, and how do you decide?" | CO | [grounded] | Clarify what is shared and what is not (audience, content slots, QA capacity, community channels), state the objective, propose a decision rule with S1's "when the calendar and the players disagree, the players win" as one lens, name the risk you would watch, challenge one premise, for example whether one calendar fits both audiences equally. No claim about your past | S3 announces the shared calendar. CO because it needs company strategy; the JD's two-titles line is the requirement it also touches (F1) |
| A5 | "Tonight's patch is two hours from the event going live and QA says one checklist item isn't done. What do you do?" | CASE | [generic] | Clarify what the item is and what failing it means for players, who decides go or hold, the options (hold, ship with a stated mitigation, ship reduced scope), what you tell the teams and players, and what changes in the checklist afterwards. No claim about your past | JD's release-checklist line (F4's requirement) asked as a decision. CASE because it is set in the role |

### Bank B: Values / Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players pulled in different directions, and what you did." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold. Pick a time the schedule you were running and what players needed disagreed. It needs a named choice, what you gave up, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years.", or say how you would handle it | Raised by S1's Players Before Plans. F6 is the nearest evidence. VAL because it scores a published value |
| B2 | "Tell me about a time you told people what was built rather than what you hoped would be." | VAL | [grounded] | Selection scaffold. Pick a time you described a release or plan to others and kept to what was done. It needs a named audience, what you said, what you left out and how it landed. If no such time comes to mind, say so plainly, then say how you would handle it. No claim about your past | Raised by S1's Ship the Patch Not the Promise and echoed by S4. VAL |
| B3 | "Tell me about a time you left a checklist or process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and your QA team still uses it. Those are the beats; tell them in your own words. Answer slot: S1's Leave the Build Greener names the checklist, so expect a probe on whether it changed after releases. If you changed it, say what and why; if it stayed as written, or the changes were not yours, say so plainly and stay with having written it | Raised by S1's third value. F4 is the evidence. VAL |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. Pick a time you told someone senior what they did not want to hear. It needs a named stake, what you said and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Presented the monthly retention numbers to the studio head.", or say how you would handle it | A persona stem for values rounds. F7 is the nearest evidence. VAL |

### Bank C: Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If any of the KPIs this role reports depend on in-app purchases, how would you handle that, given there's none in your background?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what your material carries, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." and "Presented the monthly retention numbers to the studio head." Do not present either as purchase experience. Then a plan, said as a plan: ask which KPIs the post-event review reports, how each is counted and who owns each in your first weeks. Follow-up one asks how you would read a purchase KPI that moved: say what you would ask and that you do not yet know how it behaves in these titles. Follow-up two asks whether that is a risk: concede it plainly and say how you would close it, adding no comparable experience. Hold that you can run the calendar, the checklist and the readouts; concede the gap | F9 is the biggest gap and the likeliest objection, so this gets the deepest rehearsal. JD because it presses on the KPI line (F3's requirement) |
| C2 | "This role coordinates design, art, engineering and community on each update. Which of those teams did you work with on your drops, and what did you need from each?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you worked with any of those teams on a drop, say which and what you needed from each, in your own words; if you worked with some and not others, or the calendar sat apart from them, say so plainly and stay with the calendar | F2 is the row it tests. JD because it scores a stated responsibility |
| C3 | "This role runs events for two titles at once. How does that differ from the one title's weekly calendar you ran?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran at its scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you scheduled events, or worked on more than one title, say how that work differed and what you did about it; if you did neither, say so plainly and say what you would want to know first about running two calendars | F1 is the row it tests. JD |
| C4 | "The role asks for 3+ years producing live-service games or apps. Tell me how your four years line up against that." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Say what the sentences say: four years as an associate producer at a puzzle-game studio, and the last two running the weekly content-drop calendar for your main title. Answer slot: if the title ran as a live service, say for how long; if only part of the four years did, or none, say so plainly and stay with the associate-producer years and the weekly calendar. Never add a live-service year count you did not state | F5 is the row it tests. JD |
| C5 | "You haven't led a team, and this role coordinates design, art, engineering and community teams on each update. How do you get them moving the same way?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment: "I haven't led a team." Then the calendar, at its scope. Answer slot: if you worked with design, art, engineering or community on a drop, say what you asked of them and how, in your own words; if you did not, say so plainly and say how you would start | F9 and F2. EXP because it tests what your background does and does not show |

### Bank D: Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which retention measures did you present to the studio head each month?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's retention-metrics line makes a probe on which measures and how each was counted likely. Name the measures in your own words, as you actually used them; if you did not choose or compute them, or you do not know how one was counted, say so plainly and stay with presenting them | F7 is the row it tests. JD |
| D2 | "Tell me about a time a number you presented changed what the team did next." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold. Pick a time a number you showed moved a decision. It needs the number, who saw it and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Presented the monthly retention numbers to the studio head.", or say how you would act on a number that should change a plan | Raised by the JD's "own the post-event review and the KPIs it reports". F3 and F7 are the nearest evidence. JD |
| D3 | "A retention number is down after an event. What do you compare it with before you say anything to the team?" | CASE | [generic] | Clarify first: which measure, over what window, against which baseline the team already uses, and whether the audience mix changed. Then what you can say now and what you cannot yet say, and what you would pull next. No claim about your past | Tests reasoning about the JD's retention line. CASE because it is a live diagnosis |

### Bank E: Conversational / Rapport Builder (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc, one beat per sentence, in this order and in your own words: the four years, the weekly calendar, the checklist, the retention readouts. Answer slot: why this role and why now are yours to say; if one of Saltmarsh's published values fits your reason, name it, otherwise leave it out | A persona stem for the opener. F4, F6 and F7 are the beats. EXP because it tests whether your story is consistent |
| E2 | "Tell me how the weekly content-drop calendar worked at your studio." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the quote: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's content-calendar line makes a probe on how a week's drop was decided likely. If you decided what went into a week, say how; if it came from someone else or a fixed plan, say so plainly and stay with running the calendar | F6 is the row it tests. JD |
| E3 | "We lean on clear written communication. What's something you wrote that people still use?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | The checklist, at the sentence's scope: "I wrote the release checklist our QA team still uses." If asked what is in it or how it is laid out, describe it in your own words; if you do not recall, say so plainly and stay with the sentence | F8 is the row it tests. JD |

### Bank H: Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "QA and live ops sit side by side on every release. Where's the seam, and what happens when we disagree?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Offer principles for the seam rather than claiming to know it: who decides go or hold, what the checklist records, how a disagreement is surfaced. Reciprocity: what you bring QA. From your material, at its scope: "I wrote the release checklist our QA team still uses." Answer slot: if you and QA disagreed on a release and settled it, say how, in your own words; if you did not disagree, or it was not yours to settle, say so plainly and stay with the checklist | F4 is the row it tests, and the seam is where a QA-background interviewer will press. JD |
| H2 | "How do you handle credit when work spans teams?" | JD | [generic] | Describe your approach as a principle: name contributors by what they did, in the review notes and in the update. Reciprocity: credit that helps the other team's case helps yours. No claim about your past | A persona stem for the peer register, aimed at the JD's coordination line (F2's requirement). JD |

### Bank G: Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has already run monetised live events?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Never led a team, and never worked on a game with in-app purchases." | Pause, restate, then hold only what the quotes carry: "For the last two years I ran the weekly content-drop calendar for our main title." and "I wrote the release checklist our QA team still uses." Hold through two follow-ups by returning to those sentences and adding nothing. Concede plainly, without being asked twice: "I haven't worked on a game with in-app purchases." Do not compare yourself to the other candidate or claim equivalence | F9 plus F1 and F4. EXP because it tests composure over an attributable gap |
| G2 | "The release checklist: how much of that was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold on the sentence's own verb: "I wrote the release checklist our QA team still uses." Do not upgrade it to owned, designed or managed. Answer slot: if anyone else contributed, say who and what, in your own words; if no one did, say so plainly. Either way stay with wrote | F4's verb is where an attribution probe lands. EXP |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Live-events calendar for two titles (F1) | C3, A4 |
| Coordinate design, art, engineering and community (F2) | C2, H2, C5, A2 |
| Own the post-event review and KPIs (F3) | D2, D1, A3, C1 |
| Release checklist with QA (F4) | H1, A5, B3, G2 |
| 3+ years live-service (F5) | C4 |
| Content calendar (F6) | E2, B1 |
| Retention metrics (F7) | D1, D3, B4 |
| Written communication (F8) | E3 |
| Monetisation and leading people (F9) | C1, C5, G1 |

## Values cheat sheet

Detected: S2 documents "a values conversation". Value names are from S1. Wording pending your approval.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players need disagree, player impact decides | No row's evidence carries a calendar-versus-players story. Selection scaffold in B1; nearest thing, F6: "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No row's evidence carries it. Selection scaffold in B2 with its honest branch |
| Leave the Build Greener | Each release leaves the code and the checklist in better shape | F4: "Wrote the release checklist our QA team still uses." Story-mapped in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've moved from QA lead into running live operations. What from QA do you most want a producer on your team to carry?" | Ties to his public path in S4 and invites a peer conversation rather than an interrogation |
| R2 | "Your GDC talk argued that a live team is judged by how often its patch notes describe what actually shipped. How does the team check that internally today?" | Shows you read his published argument (S4) and asks for a practical answer you can use |
| R3 | "From February 2027 two titles share one calendar and one live-ops group. Which calendar would this role run first, and what changes for the producer?" | Diligence on S3; it settles whether the JD's two-title scope matches the post-announcement structure |
| R4 | "What does the post-event review look like today, and which KPIs does it report?" | Maps to the JD's ownership line, and the answer tells you how much of it is new to you |
| R5 | "What does a new producer usually need to learn first about how your events are reported and counted?" | Asks, honestly, where the ramp is steepest without conceding more than you have stated |
| R6 | "After this session, what happens next, and who else would I meet?" | Practical; S2 describes the loop as a recruiter call then this session, and this confirms the rest |

## Prohibited claims

Built before the banks. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for one title. C3's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says presenting the monthly retention numbers. D2's scaffold stays inside the presenting |
| Managed the release checklist with QA on every release | Inflated form of F4 | F4's quote: you wrote it, and your QA team still uses it. The material says wrote, not managed each release |
| Has three or more years of live-service production | Inflated form of F5 | F5's quotes at their own scope. The material shows four years as an associate producer and two years of weekly drops, and does not say live service |
| Has worked on a game with in-app purchases | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |

## Sources

Provided: the job description pasted in your message, and your background as stated in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| ID | Query or fetch | What came back |
|---|---|---|
| S1 | Search: Saltmarsh Games values; fetch of the page | https://saltmarshgames.com/values, read in full |
| S2 | Search: Saltmarsh Games interview process live operations producer; fetch of the page | https://saltmarshgames.com/careers/interviewing, read in full |
| S3 | Search: Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur, search-result text only, page not fetched |
| S4 | Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise, search-result text only, page not fetched |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name; B1 to B3 themes |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop: recruiter call then a single 60-minute session with a tabletop and a values conversation; persona weights, Bank A and Bank B |
| 3. Saltmarsh Games strategy and recent news | yes | A4 and R3. Result text only; the full announcement was not read |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read, R1 and R2. Result text only; the talk was not read |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

No dossier was present, and the pack is built from your message and the cited sources alone.

## Upgrade menu

- Confirmation that Tobias is the hiring manager you would report to, and anything the recruiter has said about the tabletop → persona weights and banks tightened to the actual session
- Which two titles the role covers → A4 and R3 move from the announced structure to your actual titles
- Your answers to the answer slots in F1, F2, F3 and F5, in your own words → those rows upgrade from discovery or transferability and their questions gain real beats
- A short excerpt of the release checklist, with anything confidential removed → F4 and F8 move from medium toward high and E3 gains something inspectable
- A redacted retention readout slide, no figures needed → F7 and F3 move toward high and D1 and D2 gain real material
- A tuesday-dossier.md from an earlier fit check, if you have one → verified evidence and prohibited claims arrive pre-graded; the pack does not need it
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief on the season-pass change, Tobias's talk in full, role-family loop reports and recent organisation context, which would add a grounding brief and sharpen A4
