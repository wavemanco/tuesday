# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your point of view (POV) on operator partnerships over the next 18 months, talked through without slides, landing on what it means for the operators themselves. The rest is Q&A, and the recruiter said Ross will push on commercials.

Built from your message and the recruiter's email as you quoted it. No job description and no market report were in hand, and web research was refused, so company-specific rows are generic and labeled.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behaviour against a company's published values (no values round is expected here, so none is banked) |
| EXP | Whether your own claims survive scrutiny, and what was actually yours |
| JD | The stated role and its gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem, reasoned aloud |

## Prep triage (about four hours, weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Build and speak the 15-minute POV aloud twice, timed | Section: Graded deliverable |
| 2 | 30 min | Re-read the market report once: pick one consensus item to cite and one point to depart from | Graded deliverable, A4 |
| 3 | 45 min | Rehearse the highest-ROI objection until it is boring | B1, B5, D1 |
| 4 | 40 min | Defend both numbers: how each was counted, what it is sensitive to, what was yours | C1, C2, C3, D2 |
| 5 | 30 min | Ross's commercial pushes: the quota answer and the margin case | B2, D3, G1 |
| 6 | 20 min | Your 90-second opening arc and your reverse questions | E1, Reverse questions |

Everything else is insurance.

## Fit snapshot

Requirements are the recruiter's own words, as you quoted them. There is no job description, so this snapshot is short and no row is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, in your message | "9 years in partnerships" — your message, "last 4 at a payments company running the ISV channel" — your message, "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, with nothing inspected behind it, and the words stay at that scope: "I spent the last four years running the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: expect a probe on what carries over from ISV partners to operators. Say which part you think transfers and why, in your own words; if little does, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, in your message | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, and does not say train operators; the limit is the pack's observation. Words stay at the quote: "Before that I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on whether that reaches Kelverton's operators. If any of that planning work touched them, say which and what you saw; if none did, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials" — recruiter's email, in your message | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue, with nothing inspected behind it, so expect it to be taken apart. Words: "roughly £4M of influenced revenue." Defend-the-number slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how part of it was counted, say that plainly |
| F4 | "Ross will push on commercials" — recruiter's email, in your message | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never carried a direct quota, only influenced revenue." Then how you would work with commercial, said as a plan and never as a past |
| F5 | "our operator partnerships" — recruiter's email, in your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you stated. Words: "I have never sold into rail specifically." Then how you would learn the operator side quickly, said as a plan and never as a past. F2 is the adjacent evidence, at its own scope |

## Graded deliverable: the 15-minute POV

Built because the recruiter announced it. Grounded facts to build on:

| Fact | Source | Provenance |
|---|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | Recruiter's email, in your message | [grounded] |
| "no slides needed, just talk us through it" | Recruiter's email, in your message | [grounded] |
| "Please land on what it means for the operators themselves" | Recruiter's email, in your message | [grounded] |
| "took it from 6 partners to 40" | F1 evidence, your message | [grounded] |
| "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | F2 evidence, your message | [grounded] |

Three theses to choose from. Pick one as your spine, not all three. Each is a position to test against the market report, not a finding about Kelverton.

| # | Thesis | The argument in one line | Mandatory concession | Provenance |
|---|---|---|---|---|
| T1 | Organise the 18 months around operator outcomes, not partner count | Choose one or two outcomes an operator would notice, prove them with a few partners, then widen | This costs reach, and you cannot size the cost without Kelverton's own account data. Say so | [generic] |
| T2 | Sequence: deepen before you broaden | Start with the operator relationships that already exist and make them better, then add partners | Your own record is growth in number (F1: "took it from 6 partners to 40"), so expect "isn't that the opposite of what you built?" Answer slot: say plainly why depth fits this role now, in your own words, and whether breadth was right then | [generic] |
| T3 | Make partnerships the way Kelverton learns what operators need | Treat each partnership as a channel for operator feedback into the commercial and product conversation | It can slow commercial deals if overdone, and Ross is the person most likely to say so. Concede it before he does | [generic] |

Differentiation: the market report was circulated by Kelverton's own strategy team, so Deepa and Ross have read it and so has every prepared candidate. Bring one consensus item once to show grounding, then one point where you depart from it with reasons. Instruction, after your re-read: choose the consensus item and the departure yourself, because the pack has not seen the report.

Anti-pick: a partnerships role's job includes saying no. Name one thing you would deliberately not do in the 18 months, and the reason. Instruction: choose it from the report or from your own judgment, and make it something you could defend to Ross.

Requested close: spend the last two to three minutes on what it means for the operators themselves. For your chosen thesis, say in one sentence what an operator would notice differently, in your own words. Do not borrow rail claims you cannot stand behind.

Shape of the 15 minutes:

| Minutes | Content |
|---|---|
| 0 to 2 | Frame: the question you are answering and your spine thesis |
| 2 to 7 | The argument: what you would do in the first six months, and why |
| 7 to 11 | The report: one consensus item, one departure, the anti-pick |
| 11 to 13 | The concession, said before they raise it |
| 13 to 15 | What it means for the operators |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on partnership choices and the POV | High. Deepa is your future manager, which the hiring-manager prior weights toward Case and Skeptic, and 15 minutes of the session is a POV | Clarify, then objective, then approach, then metrics, then risks; say your framework aloud |
| Skeptic | Quiet probing of the gaps | High. Same prior, and you have named two gaps yourself (F4, F5) | Rehearse B1 until it is boring; hold on the quotes, concede the limit plainly |
| Data-Driven Prober | Takes the figures apart | Medium. Ross is the Commercial Director and the recruiter said he will push on commercials, which signals numbers | Know how each figure was counted, say plainly where you do not (C1 to C3) |
| Pressure | Time-boxed challenges and devil's advocate | Medium. Ross's pushing may take this register; the recruiter's words do not say it will | Pause, restate, hold through two follow-ups, then concede specifically (D1 to D3) |
| Conversational | Friendly opener | Low. Likely only in the opening minutes, but casual questions are still scored | A 90-second arc (E1) |
| Peer Evaluator | Seam between partnerships and commercial | Low to medium. Ross is not your manager but sits next to your function | Reciprocity and seam principles (G1, G2) |
| Values/Behavioral | Scored behavioural probes | Not expected. The recruiter's words describe a POV plus Q&A and name no values round, so no bank is built | None |

## Question banks

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through your point of view: where would you take our operator partnerships over the next 18 months, and what does that mean for the operators?" | CASE | [grounded] | The graded deliverable above is the guidance: one spine thesis, one concession, the report's consensus item and your departure, then the operator close. Practise it to 15 minutes and again to 10 in case you are cut short | The recruiter announced this, so it will be asked; CASE because it scores structure and reasoning, JD because it is the stated job |
| A2 | "Which operator partnership would you start on day one, and what do the first 90 days look like?" | CASE | [generic] | Ask what you would need to know first, then give the objective, the approach, the measure and the main risk. You do not know Kelverton's current partners, so say that and reason from the question, not from invented detail | Tests whether you clarify before answering; generic because no company research could run |
| A3 | "If the partnerships budget were cut by a third, what would you drop first?" | CASE | [generic] | Name the criterion before the item, then the item, then what it costs. This is where your anti-pick from the POV pays off | Ross will push on commercials, and a trade-off question tests judgment under constraint |
| A4 | "What in our strategy report did you disagree with?" | CO | [generic] | Name one consensus point you accept and say why, then one you would challenge and say why, both from your own reading. If you agree with all of it, say so, then say where you would take it further | The report is equally available to everyone, so departing from it with reasons scores as judgment; generic because the pack has not seen it |
| A5 | "How would you decide which operators to partner with first?" | CASE | [generic] | Offer criteria and say what data would settle each. Propose the principle; do not pretend to know the answer for Kelverton | Tests structured prioritisation on a problem from the actual role |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically", "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI rehearsal in this pack. Hold on the quotes: "I have never sold into rail specifically." Then at their own scope: "Before that I spent five years in transport consulting, in bus and light rail network planning." Then a ramp plan, said as a plan and never as a past. Answer slot: if the follow-up asks what you have seen of the operator side, say what you actually saw; if there was nothing of that kind, say so plainly. Hold through two follow-ups by returning to the quotes, never by adding to them | F5 is the objection this question is built from, and F2 is the only adjacent evidence; JD because it scores the role's gap |
| B2 | "You've told us you've never carried a direct quota. What does that mean for how you'd work with commercial?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | "I have never carried a direct quota, only influenced revenue." Then how you would work with Ross's team, said as a plan. Answer slot: the recruiter said Ross will push on commercials, so expect a probe on what influenced revenue meant in practice. Say, in your own words, what it was tied to; if it was tied to nothing you were accountable for, say so plainly and stay with the figure | F4 is a stated negative, and Ross is the likely asker; EXP because it scores what was actually yours |
| B3 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Your material gives no reason, so the pack supplies none. Say your own reason in one or two sentences and keep it consistent with the POV you give | A standard motivation-consistency probe; generic because it asks for your reasons |
| B4 | "Operators hear from plenty of vendors. Why would a partnership with us matter to them?" | JD | [grounded] | The recruiter asked you to land on the operators. Answer from their side first, then ours, using the outcome from your spine thesis. This question makes no claim about your past | The recruiter's own request, asked adversarially; JD because it is the stated close |
| B5 | "Bus and light rail isn't a train operating company. What carries over?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say what the work was, in the quote's terms. Answer slot: say what carries over, in your own words and no wider than that work; if little does, say so plainly, then give the ramp plan | F2's limit is the pack's observation; the likelihood follows from F5 |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the roughly £4M of influenced revenue." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure as you gave it. Answer slot: how it was counted, in your own words; if you do not know how part of it was counted, say so plainly | A headline figure on your message, so it is a defend-the-number question; F3 |
| C2 | "You took the channel from 6 partners to 40. What counted as a partner?" | EXP | [grounded] "took it from 6 partners to 40" | Say the claim at its own scope. Answer slot: what counted as a partner, what the number is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; "I don't know" is an honest branch | The second headline figure; F1 |
| C3 | "How much of that £4M was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say, in your own words, which part was yours; if you cannot separate it, say so plainly. Never claim a share you cannot back through a second follow-up | F3, asked as the attribution probe |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically" | Pause, restate, then hold on what the quotes carry. Concede first: "I have never sold into rail specifically." Hold-then-concede: stay with your actual record for two follow-ups, then concede the limit specifically | F5 in the pressure register |
| D2 | "That £4M, how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold the figure at its own scope: "roughly £4M of influenced revenue." Concede what you do not know about the counting, specifically, rather than defending it broadly | F3 again, because pressure interviewers repeat the probe |
| D3 | "A partner asks for terms that cut our margin on every operator deal. Walk me through whether you'd agree." | CASE | [generic] | State the decision criteria, what you would ask first, and what you would trade for what. Make no claim about a deal you have done | Ross will push on commercials, and this tests judgment under a commercial constraint |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships", "last 4 at a payments company running the ISV channel" | A 90-second arc in this order: the consulting years, then the partnerships years, then the ISV channel, at the quotes' own scope. Answer slot: the closing sentence, on why this role, is yours to say; if you have no reason yet, settle one before Tuesday | The opener is still scored, and F1 and F2 are the spine of it |
| E2 | "What are you most interested in right now in rail partnerships?" | CO | [generic] | A casual question about a hot topic is scored. Answer from your own recent reading, and say plainly if it is thin | Rapport interviewers use it to test genuine interest |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Partnerships and commercial sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Offer principles for the seam, not a claim to know it. Reciprocity: what partnerships brings commercial, then what you would need back | Ross runs the commercial side, and the seam is where the two functions meet |
| G2 | "How would you handle credit when work spans partnerships and commercial?" | CASE | [generic] | Say the principle first, then how you would apply it. This makes no claim about your past | Tests tact and spine with an equal; likely only if the seam comes up |

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| F1: where you'd take operator partnerships in 18 months | A1, A2, A3, A5, C2, E1 | POV build section too |
| F2: land on what it means for the operators | A1, B4, B5, E1 | Close of the POV |
| F3: Ross will push on commercials (figure) | C1, C3, D2, D3, A3 | Defend both numbers |
| F4: Ross will push on commercials (quota) | B2, G1, G2 | Plain acknowledgment, then plan |
| F5: our operator partnerships (rail) | B1, B5, D1, E2 | The highest-ROI objection |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "A year from now, what would you want operators to say about a Kelverton partnership?" | It echoes the recruiter's ask to land on the operators and shows you are thinking from their side |
| 2 | "Which operator relationship would you least want to lose, and what is it resting on?" | It shows you want the real picture, not the pitch |
| 3 | "How do partnerships and commercial split an operator conversation today, and where does it chafe?" | Ross is in the room, and it opens the seam conversation on your terms |
| 4 | "What would the first 90 days need to show for you to call this hire right?" | It makes the success criteria explicit, which Deepa can speak to as your future manager |
| 5 | "Which part of the strategy report do you expect to age worst over the next 18 months?" | It shows you read the report critically, and invites a candid answer |
| 6 | "What is driving the 18-month horizon: operator contracts, a product release, or something else?" | It tests whether your POV is aimed at the right clock |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a quota or closed deals | Negative you stated, F4 | "I have never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail | Negative you stated, F5 | "I have never sold into rail specifically." No slot |
| Generated or won £4M of revenue | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: the material says influenced, not who counted it or what share was yours |
| Knows train operators from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning |
| Built the ISV partner programme | Inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40." The limit is the pack's observation: the material says you took it from 6 to 40, not that you built the programme |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report you attached was not in hand in this session, so nothing in this pack draws on it. No tuesday-dossier.md was present.

Searches sent, every one refused (no results returned):

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships manager | refused |
| Kelverton Rail strategy train operating companies scheduling software news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology train operating companies job description | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have grounded VAL themes and a values sheet if a values round were documented |
| 2. Kelverton Rail interview process | unavailable | Would have documented the loop beyond the recruiter's description |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have grounded A2, A3, A4, A5 and E2, which are labeled generic instead |
| 4. Interviewer public footprint (Deepa, Ross) | unavailable | Would have given the interviewer read and a reverse question tied to their paths; both calls were refused |
| 5. Representative role JD | unavailable | Would have added inferred requirement rows to the fit snapshot |

## Upgrade menu

- The job description text → the five recruiter-derived rows become JD-quoted requirements, and any gate rows appear
- The market report's headline findings, pasted → section 6 (grounding brief) and the A4 and CO rows move from generic to grounded, and the POV's consensus item and departure can be named
- Deepa's and Ross's public bios or talks, if you find them → an interviewer read and a reverse question tied to their own paths
- Search access, if you can grant it → the five refused research targets can run
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, once search access is granted
- Your CV → quotes sourced from your CV replace the ones taken from your message
- Your answers to the slots in B1, B2, C1, C2, C3 → those rows become story-mapped from your own words
- A tuesday-dossier.md from an earlier assessment of this role → verified evidence and constraints would sharpen the objections and the prohibited list
