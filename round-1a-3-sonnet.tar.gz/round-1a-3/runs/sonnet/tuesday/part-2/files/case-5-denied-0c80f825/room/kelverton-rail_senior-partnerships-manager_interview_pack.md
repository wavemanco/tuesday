# Kelverton Rail, Senior Partnerships Manager: second-round interview pack

**Round:** second round, Tuesday, 60 minutes, panel of Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), per the recruiter's email.
**Shape:** a 15-minute POV from you, no slides, on where you'd take Kelverton's operator partnerships over the next 18 months, landing on what it means for the operators themselves. The remaining time is Q&A, and "Ross will push on commercials".
**Built without:** the market report (attached to the recruiter's email, not shared here), the JD, and any web research. Rows that would have rested on those are labeled accordingly, and the upgrade menu at the end says what each would add.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it is scoring.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your experience claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, market, recent moves |
| CASE | A live problem from the role, answered on the spot |

Guidance is scaffolding, not a script. Where a row says "answer slot", it is an instruction for the interview: say the true thing in your own words, or say plainly that the step was not yours or did not exist. Nothing in the pack supplies a number, method or event you did not state.

## 2. Prep triage (four hours, spread over the weekend)

| Order | Time | Do this | Ties to |
|---|---|---|---|
| 1 | 75 min | Choose one thesis from section 4, write the spine of the POV as bullets (not a script), and fix your one-sentence opening and the limit you state in it | Section 4, A1, B1 |
| 2 | 45 min | Rehearse the objection the pack names as the highest-ROI prep, out loud, through all three follow-up levels | B1, C1, B4 |
| 3 | 45 min | Say the POV aloud twice against a timer, one run recorded, aiming for 13 minutes so there is air | Section 4 |
| 4 | 40 min | Rehearse the two numbers on your own message: how each was counted and which part was yours | D1, D2, C2 |
| 5 | 35 min | Skim the Ross-facing seam and credit questions, and pick your reverse questions | F1, F2, section 7 |

Everything else in the pack is insurance.

## 3. Fit snapshot

The requirements come from the recruiter's own words as you quoted them, and from your message. No JD was supplied. Where a row has no source, it is plain prose labeled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Adjacent work: a partner channel at a payments company, not operator partnerships. The words, at the quote's scope: "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: expect a probe on how that carries over to operators. If any of it carries, say which part and why, in your own words; if none of it does, or it was not yours, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The words, at the quote's scope: "I spent five years in transport consulting, on bus and light rail network planning." The pack's observation: the material says consulting, and bus and light rail, and does not show an operator's own side of the table or rail operators. Answer slot: because the close asks about operators, expect a probe on how close that work sat to them. Say in your own words who the work was for and what you saw of their side; if you saw little of it, say so plainly and stay with the planning work you named |
| F3 | "Ross will push on commercials" — recruiter email | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The only commercial figure in the material, and it says influenced. The words, at the quote's scope: "For four years I ran the ISV channel, with roughly £4M of influenced revenue." Answer slot: a figure raises four probes: how it was counted and over what period, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; "I don't know how that was counted" is an honest answer |
| F4 | "Ross will push on commercials" — recruiter email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The words: "I've never carried a direct quota, only influenced revenue, and I haven't sold into rail specifically." Then a plan, said as a plan: how you would get to a number in this role. Never a claim to selling or quota, and nothing added to make the gap feel smaller |
| F5 | "Senior Partnerships Manager" — your message (the role title) | "9 years in partnerships" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: "I've spent nine years in partnerships." |
| F6 | Shaping the commercial terms of partner deals, a role-family expectation for a senior partnerships role, no source supplied | none given | none | [generic] | discovery | Strong evidence here would be a commercial point you took part in discussing, your part in it, and what came of it. Selection scaffold: pick a partner-deal commercial discussion you were part of, with what the term was, your part, and what came of it; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## 4. Graded deliverable: the 15-minute POV

Announced deliverables are graded deliverables. This section is built from the recruiter's brief: where you'd take operator partnerships over 18 months, ending on what it means for operators. It is pending your approval: every thesis is a stance for you to adopt or drop, not a claim about Kelverton or the market.

**Grounded facts to build on**

| Row | Sentence you can stand on |
|---|---|
| F1 | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |
| F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" |

**Three thesis options.** Pick one. Each carries a concession you must make aloud, because Ross will find the limit if you do not.

| Option | Thesis (a stance) | Mandatory concession |
|---|---|---|
| T1 | Judge every operator partnership by what changes in an operator's working day, and report progress in that currency | F4's words: "I haven't sold into rail specifically." Then say this is a hypothesis you would test with operators early, in your own plan |
| T2 | Make a few operator relationships work before widening, so the sequence is the strategy | F1 is a partner-count and influenced-revenue story. Say it in those terms and say you are not claiming that scoreboard transfers to operators |
| T3 | Spend the 18 months proving one thing to operators and say no to the rest, naming what you would say no to | F4's words: "I've never carried a direct quota, only influenced revenue." Then say what you would want to understand about how a number is counted here before agreeing to carry one |

**Differentiate from the report.** Their strategy team wrote the report and both panelists have read it, so reciting its shortlist scores as homework. Use the three-part shape the pack can give you without the report in hand:

1. One consensus item from the report, named as theirs, to prove you read it. Keep it short.
2. One thesis-driven divergence, with your reason in operator terms.
3. The anti-pick: one item you would deprioritize over the 18 months, and why. Where the real job includes saying no, this is the part that sounds like judgment.

The pack cannot name those three items until it has the report. Choosing them is the highest-value hour in your weekend.

**The close the recruiter asked for.** End on what it means for operators: one change an operator would notice in their own work at month 6, 12 and 18, stated in operator terms, plus how you would know it happened. Take those changes from the report or from sentences you can stand behind. Where you would be guessing, say you would need to ask operators first.

**A 15-minute spine** (bullets, not a script):

| Time | Beat |
|---|---|
| 0:00 to 1:00 | One-sentence thesis, then your limit in F4's words, said early so it is not found later |
| 1:00 to 4:00 | The consensus item from the report |
| 4:00 to 9:00 | Your divergence and the anti-pick |
| 9:00 to 13:00 | Three horizons, with the operator-side change at each |
| 13:00 to 15:00 | What you would test in the first 90 days, what would change your mind, then stop and hand over |

## 5. Persona table

| Persona | How it shows up on this panel | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Case/Strategist | Deepa pressing the POV, then live operator-partnership problems | High. Relationship prior for a hiring manager is Case/Strategist plus Skeptic, and the round opens with a POV | Clarify, then objective, segmentation, approach, metrics, risks; challenge one premise respectfully per case |
| Skeptic | The rail-experience and quota gaps, "why leave, why here, why now" | High. Same prior; the gaps in F3 and F4 are ones you have stated | Rehearse the single most predictable objection until it is boring; state limits plainly |
| Pressure | Ross interrupting and time-boxing, testing commercial composure | Medium. Prior for an executive is Case plus Pressure, and the recruiter says Ross will push | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Data-Driven Prober | Ross on the figures: how the numbers were counted | Medium. The recruiter's cue about commercials raises it; no profile exists to adjust further | Know what you can and cannot say about how each number was counted; name the weakest assumption first |
| Peer Evaluator | Ross on the seam between partnerships and commercial | Low. He is not a peer by title, but the seam is real for the role | Offer seam principles rather than pretending to know the seam; reciprocity framing |
| Conversational | Opening biography and "what did you make of the report" | Low. Friendly, but still scored | A 90-second arc of stated beats; treat casual questions as scored |
| Values/Behavioral | Not expected | None. The recruiter's email names no values round and no values research was possible | No bank. The upgrade menu says how to check |

Assignments by panelist (Deepa mostly A and B, Ross mostly C, D and F) are an assumption from titles and the recruiter's sentence, not from interviewer profiles. No loop beyond this single 60-minute panel is assumed.

## 6. Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months, and what does that mean for the operators themselves?" | CASE | [grounded] | This is the POV; build it per section 4. If you are cut off, restart from your one-sentence thesis, not from where you were. It makes no claim about your past beyond the facts in section 4 | The recruiter's own brief, so it is certain to be asked. CASE because it is a live problem delivered unaided |
| A2 | "Which one thing in that plan would you not do, and why?" | CASE | [generic] | Name the anti-pick from section 4 and give the reason in operator terms. Concede what it costs. Do not pick something nobody would defend | The follow-up that separates a recited shortlist from judgment. CASE because it tests how you prioritize |
| A3 | "An operator tells us the software is good but the partnership around it isn't helping them. How do you find out what's wrong?" | CASE | [generic] | Clarify first: whose view, what they expected, what changed. Then segment who is affected, set an approach, name how you would know it was fixed, and flag the risks. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | Tests operator-first thinking, which the close of the POV demands. CASE because it is a diagnosis delivered live |
| A4 | "With a small team, which operators do you work with first, and how do you decide?" | CASE | [generic] | State the criteria aloud before naming any operator, and say what you would need to learn first. Pick criteria you can defend in operator terms. The guidance makes no claim about your past | Sequencing is where an 18-month plan shows its logic. CASE because it is a prioritization problem |
| A5 | "How will we know in 18 months that it worked for the operators, not just for us?" | CASE | [generic] | Offer two or three operator-side measures in operator vocabulary, drawn from the report where you can point to it. Commit only to measures you could say how to count, and say plainly where you would first have to learn the operators' own measures | The recruiter's close made operator impact the test, and Ross will press on measurement. CASE because it asks you to design the scoreboard |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail and never carried a quota. Why should we trust you with operator partnerships, and with the commercials?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" and "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Concede first, in the stated words: "I've never carried a direct quota, only influenced revenue, and I haven't sold into rail specifically." Then what the quote carries and no more: "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Follow-up 1, "so what have you delivered": return to the channel and the influenced figure at their own scope. Follow-up 2, "why not hire someone who has carried a number": do not argue you have; concede both limits again, specifically, and give your own plan for closing them, naming two things you would do in your first 90 days. Follow-up 3, "what do you need from us": say in your own words what would help you learn how a number is counted here. Hold through two follow-ups by returning to what the quotes carry, never by adding to it. State the limit in your opening so it is never found | F4 is the gap this panel is most likely to open with, and F3 is where it lands next. JD because it scores the listed job, and the answer is rehearsed candor |
| B2 | "Your background is payments ISVs and bus and light rail planning. Which of those is more use to us, and what's missing from the other?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" and "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Choose one, in your own words, and say why. Keep each claim at its scope: "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40"; "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: if any of the planning work was for rail operators, say which and what you saw; if none was, say so plainly and stay with bus and light rail | F1 and F2 are the two halves the panel must weigh against each other. EXP because it tests what each half actually was |
| B3 | "Why leave payments for rail, and why now?" | EXP | [generic] | Give your actual reason, in your own words, specific to this role and this company. It must be true and survive a second question. The material does not carry a reason, so none is supplied | A standard motivation probe, and a weak spot in any career switch. EXP because it tests whether the story is consistent |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Name the real limit in the stated words: "I haven't sold into rail specifically." Pair it with your own plan, said as a plan. Do not invent a weakness your material does not show, and do not hide the one it does | F4 makes this nearly certain. JD because it scores fit against the listed job |
| B5 | "What from your ISV channel would not work with operators?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Start from the scope the quote carries: "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: name one thing from that work you would not carry over and say why, in your own words; if you cannot yet, say so plainly and say how you would find out | F1 is the only partnership evidence, so the panel will test how far it stretches. EXP because it tests candor about transfer |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" and "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate the question. Hold the position the quotes carry: "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Hold through two follow-ups. Then concede specifically: "I haven't sold into rail specifically." Do not fold on the core claim to restore the mood | Time-boxed challenge to F1 against F4. JD because it scores fit; the real test is composure |
| C2 | "Influenced isn't revenue. What's the number you'd put your name to?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Stay with the stated word: "roughly £4M of influenced revenue". Answer slot: say how it was counted and over what period, and which part was yours, in your own words; if you do not know how it was counted, or none of it was yours to count, say so plainly and return to the channel you ran. Do not restate it as anything harder than influenced | The word influenced in F3 is the likeliest thing Ross challenges. EXP because it tests attribution under pressure |
| C3 | "Pick one risk with this hire and tell me in thirty seconds what you'd do about it." | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Pick the risk your own material shows: "I haven't sold into rail specifically." Then your plan, said as a plan, with something you would do first. Do not choose a flattering risk | Tests whether you can name your own limit unprompted. JD because it scores the gap against the role |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot, four parts, each in your own words: how it was counted and over what period; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly. Keep the word influenced | F3's figure is the magnet for this persona. EXP because it tests whether the number survives scrutiny |
| D2 | "You took it from 6 partners to 40. What counted as a partner at each end?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say how each figure was counted, the assumption you would defend least, and what part was yours, in your own words. If you do not know how it was counted, or the count was not yours, say so plainly and return to "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." | The second headline figure in F1 gets the same defend-the-number rehearsal. EXP because it tests attribution |
| D3 | "What would you put on the table as measures at the 6-month review, and what would you ask us to change?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Offer a small set you could say how to count, and give reasons. Say plainly if some measures would depend on what you learn about operators first. Do not use the question to sidestep carrying a number: the plain statement is "I've never carried a direct quota, only influenced revenue." The guidance makes no claim about your past beyond that quote | Commercial accountability is what Ross will probe, and F6 is where no evidence exists. CASE because it asks you to design your own scorecard |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships" and "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" and "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc using only the beats stated: nine years in partnerships; four of them running the ISV channel at a payments company; five years in transport consulting on bus and light rail network planning. The material does not say how the halves connect or in what order they happened, so tell that connecting beat in your own words and as it actually was | The standard opener, and the first thing the panel scores. EXP because it tests whether the story is coherent. F5 and F1 and F2 are the rows it draws on |
| E2 | "What caught your eye in our market report?" | CO | [grounded] | Bring one consensus item to show you read it, then your divergence, and never recite its figures back. The report was circulated internally, so treat it as theirs. The pack has not seen it, so this row cannot name items | A friendly question that is still scored, and the one place the report comes up directly. CO because it tests homework depth |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Partnerships and my commercial team will both be talking to operators. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam, and say what you would bring Ross's team, not only what you need. Selection scaffold for a disagreement story: pick a time you disagreed with a colleague over who owned something, with the stake, what you did, and a relationship intact at the end; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ross is a Commercial Director and the seam with partnerships is real. JD because it scores how the role works with commercial |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Stem from the persona set. Answer slot: the figure is influenced revenue, so expect a probe on whose number it was. If someone else booked it, or how credit was split was not your call, or there was no split, say so plainly and stay with the channel you ran. Use only the sentence's own scope | F3's word influenced sits exactly on the credit question. EXP because it tests attribution between teams |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1: the 18-month POV | A1, A2, A4, A5, B2, B5, E2 | |
| F2: what it means for operators | A1, A3, A5, B2 | |
| F3: commercials, the figure | C2, D1, D2, D3, F2 | |
| F4: the stated gaps | B1, B4, C1, C3 | |
| F5: senior partnerships experience | E1 | |
| F6: commercial terms (no source) | D3, F1 | Role-family expectation only |
| "no slides needed, just talk us through it" | none, and why | A delivery constraint, handled in the spine in section 4 |
| Values or competency framework | none, and why | None named; see the persona table |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first operator win look like at six months, and who on the operator side would judge it?" | It shows you think in operators' terms, which is the close of your POV |
| R2 | "Where do partnerships and the commercial team split responsibility today, and where does that line cause friction?" | A seam question for Ross, asked as someone planning to work inside it |
| R3 | "What does this role carry in terms of a target, and how is it counted?" | F4 is the gap you stated, so asking plainly keeps it honest and gets you the counting rules |
| R4 | "Which part of the report do you expect operators to push back on?" | Shows critical reading rather than recital; keep the tone curious |
| R5 | "What's one thing a new person could do in their first month that would really help your team?" | The reciprocity question for Ross, and it signals you are thinking about his load |
| R6 | "What would make you say, in a year, that this hire was the right one?" | Gives you the panel's real success measure, and you can answer back to it |

## 8. Prohibited claims

Built from the fit snapshot before the banks. None of these is coached, softened or implied anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Having sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| Having carried a quota or a number | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| Generating, closing or owning the £4M, or any per-year or recurring reading of it | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced and gives no period. The slots stay on how it was counted and which part was yours |
| Knowing train operators from the inside, or having worked at or for one | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says consulting, and bus and light rail |
| Having built or designed the ISV programme, its tiers, incentives or rules | Inflated form of F1 | F1's quote at its own scope: ran the channel and took it from 6 partners to 40. The limit is the pack's observation: the material does not say how |

## 9. Sources

**Provided:** your message, including the recruiter's email as you quoted it. The market report was attached to that email but not shared in this conversation, so it was not read and nothing in this pack comes from it. No `tuesday-dossier.md` was present.

**Searches sent (all refused, none returned results):**
- `Kelverton Rail values` — refused
- `Kelverton Rail interview process partnerships` — refused
- `Kelverton Rail strategy scheduling software train operating companies` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Ross Commercial Director Kelverton Rail` — refused
- `Senior Partnerships Manager job description rail technology software` — refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Search refused. Would have moved the values cheat sheet, had a values round been detected |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Search refused. The recruiter's words already establish this single 60-minute panel; would have moved any values or case component in the Q&A |
| 3. `Kelverton Rail strategy` | unavailable | Search refused. Would have moved the CO and CASE banks and a grounding brief, which are generic without it |
| 4. `Deepa` and `Ross` with the company | unavailable | Both searches refused. Would have moved the interviewer read, persona adjustments and one reverse question tied to their paths |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Search refused. Would have moved JD-tagged rows from generic toward inferred and filled the requirement list |

## 10. Upgrade menu

- The market report (paste the text or key pages): the three thesis options in section 4 get named consensus, divergence and anti-pick items, and E2 and the CO rows become grounded
- The JD or the advert text: the requirement rows quote the posting rather than the recruiter's email, and F6 and the JD-tagged rows get real sources
- Web search allowed in a re-run: the values, loop and strategy targets run, and the grounding brief and CO and CASE banks become grounded; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available on request
- Surnames or public profile pages for Deepa and Ross: an interviewer read, tuned persona weights, and a reverse question tied to each one's path
- Your answers to the slots (how the £4M and the 6-to-40 were counted and over what period, who the planning work was for, any disagreement story): rows F1, F2, F3 and F6, and questions B2, B5, C2, D1, D2, E1 and F1, become story-mapped rather than slotted
- The partner-attribution report behind the £4M, if you may share it: F1 and F3 move from medium confidence toward high
- A one-line email to the recruiter asking whether the Q&A includes a values or competency component: if yes, a values cheat sheet is added
- A `tuesday-dossier.md` from an earlier fit check, if you have one: verified evidence and a named top objection would replace the pack's inferred one
