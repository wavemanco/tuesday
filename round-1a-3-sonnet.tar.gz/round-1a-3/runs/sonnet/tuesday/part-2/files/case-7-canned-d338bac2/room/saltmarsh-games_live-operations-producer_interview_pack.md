# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: the Outage Hour, a single 60-minute hiring-manager interview, which Saltmarsh's own interviewing page describes as a live-incident tabletop on a simulated outage during a live event, then a values conversation. Your note did not say how Tobias relates to the role, so this pack assumes hiring manager, the relationship the interviewing page gives for this interview. If he is a skip-level or a peer, the persona weights change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values |
| EXP | Whether a claim about your experience survives follow-up questions |
| JD | A stated responsibility or requirement of this role |
| CO | Knowledge of the company's strategy and recent moves |
| CASE | A live problem, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now: say the practice in your own words if it was yours, and say so plainly if it was not or never existed.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title's weekly content drops, not live events across two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD says two titles, so expect a probe on handling more than one calendar. If you ever held more than one calendar or schedule at once, say how, in your own words; if not, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material is silent on working with any of the four teams, so nothing here is words for you. Answer slot: the JD names all four, so expect a probe on each. If you worked with any of them on a drop, say which and what you did, in your own words; if not, or if it was not yours to do, say so plainly and say how you would start |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly numbers, not that you ran a review after an event or owned the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you looked back at a drop to see what it did, say how and what came of it; if there was no such review, or it was not yours, say so plainly and stay with presenting the monthly numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap on the checklist itself, but a line with nothing inspected behind it, so expect a probe on "manage" against "wrote". Lead in the quote's own terms: you wrote it, and QA still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years in the associate producer role and two years of the weekly calendar, and does not show how many of the four years were on a live-service title. Answer slot: say how many of the years were on a live title, in your own words; if you are unsure the title counts as live-service, say how it ran and let them judge |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on how the calendar ran. Lead with it in the quote's own terms: weekly, the main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in what the quote says, and expect the defend-the-number probe: how the numbers were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. Answer slots for those sit in D1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist touches the requirement without showing how clear the writing was. Answer slot: if you have a piece of your writing a stranger could read, such as the checklist itself, know which one you would point to; if none, say so plainly and say how you would show it |
| F9 | Leading people — the JD asks you to coordinate, and leading a team is a common probe in this role family | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated, and wording cannot close it. Words: "I haven't led a team." Then how you would ramp, said as a plan and never as a past |
| F10 | In-app-purchase games — the JD does not ask for it; common in mobile live-service work | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated, and nothing is added to shrink it. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first, said as a plan and never as a past |

## Reading the interviewer

| Item | What the public sources say | What it means for you | Provenance |
|---|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | The interviewing page names this interview as the hiring manager's, so treat his questions as scoring you for the role | [grounded] |
| Background | A QA lead at a console studio before this | Expect release-quality detail; your checklist line (F4) is the place he is likeliest to dig | [inferred] |
| Published argument | GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Precision about what shipped, announced and hoped is likely his lens; it echoes the published value "Ship the Patch Not the Promise". Say only what is built, and keep your claims at their scope | [inferred] |
| Mirror opportunity | Shared vocabulary around release checklists and QA, no shared career jump shown | Your sentence "Wrote the release checklist our QA team still uses." (F4) is the one place your path and his meet; use it plainly, never as a claim to a QA background | [inferred] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a simulated outage during a live event, worked live | High. A hiring-manager round leans Case and Skeptic, and the interviewing page names a live-incident tabletop | Clarify first, then objective, who you pull in, what players are told, what gets recorded; think aloud; challenge one premise politely |
| B. Values / Behavioral | The second half of the hour: a values conversation | High. The interviewing page documents it, and Saltmarsh publishes three values | Map a story to each value only where your own sentence carries one; where none does, say so plainly and give the nearest thing or how you would handle it |
| C. Skeptic | Quiet probing of the gaps: one title against two, no in-app purchases, no team led | High. A hiring manager is derisking, and you have stated two gaps yourself | Rehearse the single likeliest objection (C1) until it is boring; bridge only from what you have said; pair each limit with a ramp plan |
| D. Data-Driven Prober | Line-by-line questions on the retention numbers and the checklist | Medium. His published patch-notes argument suggests care about what a claim rests on, which is an inference from one talk | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| E. Pressure | A time-boxed tabletop, attribution challenges | Medium. A simulated outage may be time-boxed, though the interviewing page does not say so | Pause, restate, hold a challenged position through two follow-ups, then concede specifically |
| F. Conversational | An easy opener before the tabletop | Low. A recruiter call comes first, and the hour is structured | Have a 90-second arc ready; treat casual questions as scored |

Peer Evaluator is left out: nothing here suggests a peer round.

## Question banks

### A. Case / Strategist (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Mid-event, players report they cannot log in. Talk me through the first fifteen minutes." | CASE | [generic] | Clarify before you structure: what is affected, since when, how many players, which platforms. Then the objective: protect players first. Then who you pull in (engineering, QA, community), what players are told and when, and what you record for the post-event review. State only what you know in any player update. The question needs no claim about your past, so the guidance makes none | The tabletop is the named core of the round, so a live outage is the likeliest opener; CASE because it scores structure, and `[generic]` because it is a pattern for the problem, not a fact about Saltmarsh's scenario |
| A2 | "The fix is ready, QA has not signed off, and the event ends tonight. Walk me through your decision." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Name the checklist you wrote and that QA still uses it, in the quote's terms. Then the decision structure: what you would never skip, what can be shortened, who decides, what players are told. Answer slot: the JD says you would manage the release checklist with QA, so expect a probe on what the checklist says about a release under time pressure. If the checklist you wrote covers that, say what it says; if it does not, say so plainly and say how you would decide | F4 is the evidence for the release-checklist requirement and the place a QA-minded interviewer probes; CASE because it is a live decision, with the JD requirement showing through |
| A3 | "Two live titles want the same event weekend and engineering can support one launch. How do you choose?" | CASE | [generic] | Clarify first: what has already been announced, what each launch depends on, what players are expecting. Then the principle you would apply, the options, and the trade-off you accept. Saltmarsh's published value "Players Before Plans" is the lens worth using, in your own words. No claim about your past is made | The role runs the calendar for two titles, so a collision between them is the natural case; CASE with JD content |
| A4 | "Design wants a Friday drop, art says the assets are a week late, and community has already told players Friday. What do you do?" | CASE | [generic] | Clarify what is truly late and what can ship, then what each team needs from you, what you tell players, and what you refuse to promise. The published value "Ship the Patch Not the Promise" fits: announce what is built. No claim about your past is made | The JD asks you to coordinate four teams on each update, and F2 is where the material is silent; CASE with JD content |
| A5 | "In September Saltmarsh announced Project Larkspur: one shared events calendar and a single live-ops group from February 2027. What changes for whoever runs the calendar?" | CO | [grounded] | Bring one thing you read, then one thesis with a concession, then what you would want to ask Tobias. Do not recite the announcement; any prepared candidate has it. Read the announcement page itself before Friday, because this pack has only its search-result summary. No claim about your past is made | A strategy question from a source under six months old, and one the JD may not yet reflect; CO because it tests homework at the company's altitude |

### B. Values / Behavioral (weight: highest, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players wanted different things." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time the schedule and the players' interests pulled apart; it needs a named decision and what players got. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the calendar you ran, or how you would handle it | Published value "Players Before Plans"; F1 is the nearest evidence and carries no such moment, so the guidance is a scaffold and not a story |
| B2 | "Tell me about a time you told people what was built rather than what you hoped would be." | VAL | [grounded] | Selection scaffold: pick a time what was planned and what was done differed; it needs a named announcement and who you told. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. No quote carries this story, so none is supplied | Published value "Ship the Patch Not the Promise", and it matches the theme of his published talk; VAL because it scores behaviour against a named value |
| B3 | "Tell me about a time a release left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4, with only the beats the quote states: you wrote the checklist, and QA still uses it. Answer slot: the value speaks of the checklist being left better, so expect a probe on whether it changed after a release. If you changed it, say what and why, in your own words; if you did not, say so plainly and stay with having written it | Published value "Leave the Build Greener"; F4 is the only evidence that reaches it |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [inferred] "Presented the monthly retention numbers to the studio head." | Selection scaffold: it needs a named truth, who did not want it, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is presenting the monthly numbers to the studio head, or how you would handle it. The quote does not say any number was unwelcome, so none is supplied | A standard values stem tied to F3's nearest evidence; `[inferred]` because the link is this pack's derivation |

### C. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You ran the calendar for your main title. This job runs two titles at once. What is different on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Hold the quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The material shows one title's weekly calendar, and that limit is said before it is asked. Answer slot: if you ever held more than one calendar at once, say how; if not, say so plainly. Then the ramp as a plan: what you would read, whom you would sit with, what you would not promise in week one. Expect three follow-ups, on what collides first, who breaks the tie, and what you would drop; answer each from the calendar you ran or as a plan | F1 and F5 together make this the objection most likely to arrive in some form; JD because it scores the requirement for two titles |
| C2 | "I see you have not worked on a game with in-app purchases. How would you handle that here?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly in your stated words: "I haven't worked on a game with in-app purchases." Then a plan, never a past: ask what the post-event review reports today, learn those definitions first, and pair with whoever owns them. Add nothing that shrinks the gap | F10 is a gap you stated; rehearsing the plain acknowledgment keeps it from sounding like a dodge; JD because mobile live-service work commonly involves such purchases |
| C3 | "You have not led a team. This job coordinates design, art, engineering and community on every update. What is different about coordinating?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly: "I haven't led a team." Answer slot: the JD names all four teams, so expect a probe on each. If you worked with any of them on a drop, say which and what you did; if not, or if it was not yours, say so plainly. Then a ramp plan: who you would meet in week one and what you would ask each | F9 is a gap you stated and F2 is where the material is silent; JD because it scores the coordination duty |
| C4 | "You have four years as an associate producer. This role asks for three or more years producing live-service games. How many of your four were live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: say how many of the years were on a live title, in your own words; if you are unsure the title counts as live-service, say how it ran and let them judge. Do not stretch the quotes: they give four years in the role and two years of the weekly calendar | F5 is a discovery gap; a titled-years requirement is likely read literally, which is a reading, so the probe needs a straight answer |

### D. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Four answer slots, each in your own words: how the numbers were counted; what they are sensitive to; the assumption you would defend least, named before he does; and which part was yours, the counting or the presenting. "I don't know how that was counted" is an honest branch. No method or definition is supplied here | F3 and F7 are the evidence for the retention requirement; EXP because it tests what was actually yours |
| D2 | "Tell me about a time you looked back at a content drop to see what it did." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: it needs a named drop, what you compared, and what came of it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is presenting the monthly numbers, or how you would run a post-event review | The JD makes the post-event review a duty; F3 shows monthly numbers, not a review, so the guidance does not assume one |
| D3 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F6 with only the beats the quote states: weekly, the main title, two years. Answer slot: the JD says you would plan and run the calendar, so expect a probe on what happened when a drop changed late. If that happened, say how you handled it; if it did not, or it was not yours, say so plainly and stay with the calendar you ran | F1 and F6 are the evidence; EXP because the interviewer reads the line closely |

### E. Pressure (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Never led a team, and never worked on a game with in-app purchases." | Hold what the quotes carry: the calendar you ran, and the checklist you wrote that QA still uses. Concede once, specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the calendar and the checklist, never by adding to them | F1, F4 and F10 are the position and its limit; JD because it scores fit under pressure |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the quote at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: if others contributed or QA has changed it since, say who and what; if it was only you, say so plainly. Never claim more than writing it | F4 is the line the stem "how much was actually you" aims at; EXP because it tests attribution |
| E3 | "Ninety seconds: what do you do in your first thirty days?" | CASE | [generic] | A plan, never a past: listen first, read the last events' reviews, sit in on a release with QA, learn the four teams' constraints, and decide nothing about the calendar before you have. No claim about your past is made | A time-boxed plan question is a common pressure format for a new producer; `[generic]` because it is a pattern for the problem |

### F. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses." | A 90-second arc with only the beats the quotes state: four years as an associate producer at a puzzle-game studio, the weekly calendar for the main title, the checklist QA still uses. Answer slot: why this role, why now, in your own words; nothing in the material says | The biography question opens most interviews and is scored; F5, F6 and F4 are the evidence |
| F2 | "What have you been curious about in how live games keep players coming back?" | JD | [generic] | Answer slot: a real, current interest in your own words, with one concrete example you can speak to for two minutes; if you have none, say so plainly and say what you would look at first. Nothing is supplied here | Retention is a stated requirement, and casual questions on it are scored; F7 is the evidence |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, C1, D3 |
| "coordinate design, art, engineering and community teams on each update" | A4, C3 |
| "own the post-event review and the KPIs it reports" | D1, D2 |
| "manage the release checklist with QA" | A2, B3, E2 |
| "3+ years producing live-service games or apps" | C4, F1 |
| "experience running a content calendar" | D3, F1 |
| "comfortable with player-retention metrics" | D1, F2 |
| "clear written communication" | none dedicated, and why: both halves of the hour are spoken; A1's player-update step and D2's review are the nearest, and the upgrade menu asks for a writing sample |

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold: pick a time the schedule and the players' interests pulled apart, with a named decision. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (F1: "I ran the weekly content-drop calendar for our main title for the last two years."), or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold: pick a time what was planned and what was done differed, with a named announcement. If no such time comes to mind, say so plainly, then say how you would handle it; no quote carries this story |
| Leave the Build Greener | Every release should leave the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats the quote states: you wrote it, and QA still uses it. Answer slot in B3 covers whether it changed after a release |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argues a live team should be judged by whether its patch notes match what shipped. How does this team check that today?" | Ties to his own published argument and shows you read it; the answer tells you how the team is actually measured |
| R2 | "You came to live operations from QA. What from that side do you still lean on most when a release is going out?" | Ties to his own path, and turns the interview into a conversation between two people who care about releases; only ask it if you have confirmed that background yourself |
| R3 | "With Larkspur moving to one shared events calendar, how does this producer role fit alongside it?" | Shows current awareness, and the answer tells you what you would actually be running |
| R4 | "What does a strong post-event review look like here, and which KPIs does it report today?" | The JD makes you the owner of both; the answer shows how much of it is retention and how much is purchase-linked |
| R5 | "Which of design, art, engineering and community would you most want this producer to build a working link with first?" | Gives you your first-month map and shows you are already thinking in the JD's terms |
| R6 | "What would make you say, ninety days in, that this hire was the right one?" | A standard close that surfaces the scoring sheet in his own words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says one title's weekly drops, not events across two titles. C1's slot stays inside the calendar you ran |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presenting monthly numbers, not owning a review |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: "Wrote the release checklist our QA team still uses." The limit is the pack's observation: the material says writing the checklist, not managing releases |
| Led a team | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the job description you pasted, and your message describing your background. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Queries sent:

- `Saltmarsh Games values` returned https://saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games mobile studio strategy news` returned https://saltmarshgames.com/news/project-larkspur
- `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Pages fetched: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full. The Larkspur announcement and the talk page were seen only as search-result summaries, not opened. The talk page's host is not one I can tie to GDC's own site, so the details taken from it (his earlier QA role and the talk's argument) are labelled `[inferred]` and should be confirmed by finding the talk yourself.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The values cheat sheet, three principles by official name, and the VAL questions B1 to B3 |
| 2. `{company} interview process {role family}` | yes | The loop: recruiter call, then the Outage Hour with a tabletop and a values conversation; persona weights and the case bank follow it |
| 3. `{company} strategy` / recent news | yes | CO question A5 and reverse question R3, from a September 2026 announcement seen as a summary only |
| 4. `{interviewer name} {company}` | yes | The interviewer read, a Prober tilt, and reverse questions R1 and R2; the source is a single unopened summary |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation of how Tobias relates to the role → reweights every bank if he is a skip-level or a peer
- The recruiter's note on what the Outage Hour covers, usually one email → sharper case scenarios in bank A in place of `[generic]` ones
- The sizing of your prep time before Friday → a prioritized triage of this pack
- Your answers to the answer slots in F1, F2, F3 and F5 → those rows move from discovery or transferability to stated evidence, and their bridges become your own words
- Your actual CV text → every evidence cell currently sourced to your message becomes sourced to your CV, and any line the summary left out is added
- The release checklist itself, a calendar export or schedule, and the monthly retention deck → the artifacts that could raise F4, F1 and F6, and F3 and F7 from medium toward high
- A piece of your own writing, such as the checklist or a post-event note → closes F8's discovery gap
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on Project Larkspur read from the announcement itself, the talk read from a verified page, and recent organisation context; offered once
- A `tuesday-dossier.md` from an earlier underwriting of this role → verified evidence and a named highest-ROI objection in place of this pack's inference; never required
