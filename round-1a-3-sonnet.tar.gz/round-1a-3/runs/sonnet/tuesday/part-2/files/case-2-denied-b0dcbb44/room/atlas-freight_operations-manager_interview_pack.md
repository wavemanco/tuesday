# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight. The posting you supplied describes it as regional logistics with 800 employees.
**Interviewer:** not known. Round type and relationship are not known either, so this pack uses flat persona weights (section 8).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. The guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | The posting's stated responsibilities and qualifications, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

`[grounded]` means traceable to what you gave me. `[inferred]` means derived from it, with the derivation named. `[generic]` means a role-family pattern with no claim about you or this employer.

## Prep triage

You have about a week. Do these in order; everything else is insurance.

1. Rehearse A1 aloud until it is boring. It is the most predictable question in this loop.
2. Rehearse C1 and D2, the 40% mis-pick result: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours.
3. Rehearse A2 and D3, Power BI: the plain acknowledgment, then your own plan. If you open Power BI before the interview, what you did there is yours to say only after you have done it.
4. Pick one real Lean/Six Sigma instance for E2, or settle how you will say there is not one.
5. Read Atlas Freight's own site and ask the recruiter for the round format (upgrade menu). That fixes what this pack could only assume.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows one site's surge plan and a shift-manager role, with nothing inspected behind it, and shows no terminal or multi-site work. The words stay inside the quotes: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's 4-sites line makes a probe on location coverage likely. Say where you have worked and what you were responsible for there, in your own words; if it was one site, or no terminal, say so plainly and stay with the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is an accuracy result at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Your material shows no on-time or cost-per-shipment figure, and the bridge does not stretch to one. Answer slot: the JD's two measures make a probe likely. If either was a number you watched, say which and what it showed, in your own words; if neither was, or it was not yours, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote gives 3 supervisors; the JD gives 12. The words are the quote's: "I'm over 3 supervisors today." Set the JD's number beside it only as a comparison, never as a claim, and give any step up as a plan, never as a past. Answer slot: if the number of supervisors you have worked with has ever differed from 3, say what it was and when, in your own words; if not, say so plainly and stay with the quote |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | The Excel half only. "Solid Excel" is a self-assessment that names no report, so it is not asserted as reporting. Answer slot: if you have built any recurring report in Excel, say what it showed and who read it, in your own words; if you have not built reports there, or it was not yours, say so plainly and say what you would build first |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | The Power BI half, and a gap you stated yourself. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The 7 years are operations years; your material does not show how many of them were spent leading people. The words are the quote's: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years were leading people, in your own words; if you cannot separate them, say so plainly and give the 7 years as you stated them |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the certification: lead with it in your own terms, "I'm green belt certified." Expect a probe, because nothing is inspected behind it and the quote names no project |

## Persona table

No round type, relationship or interviewer is known and no loop source was read, so the fallback is the generic archetype (screen, hiring manager, panel) with flat weights, which is noticeably weaker than a weighted pack. The reasoning for each weight is the same, and you can recalibrate it if you know the round. Each bank has 3 questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the gaps: scale, tools, why this move | Equal weight: no round type known | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| B. Case / Strategist | Live problems from the role: diagnose a slipping metric, cover a shortage | Equal weight: no round type known | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Reads your numbers line by line and asks how they were counted | Equal weight: no round type known | Know what you can and cannot say about each figure; name its weakest assumption first |
| D. Pressure | Interrupts, time-boxes, asks how much was actually you | Equal weight: no round type known | Pause, restate, anchor in what you said, hold through two follow-ups, concede only the specific thing |
| E. Conversational | Friendly and unstructured, and still scored | Equal weight: no round type known | A 90-second arc for the biography question; treat casual questions on JD topics as scored |
| F. Peer | Seam-splitting between sites and teams, credit-sharing | Equal weight: no round type known | Reciprocity framing; propose seam principles instead of pretending to know the seam |
| G. Values / Behavioral | Scenario probes, STAR-shaped stories | Equal weight, with no published values read and no values-style round detected | Choose stories where the hard truth landed; where none comes to mind, say so |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role covers 4 sites and 12 supervisors. What in your background tells me you can step up to that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | The highest-ROI rehearsal in this pack. Open in the quotes' own words: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Then the number comparison and nothing wider: "I'm over 3 supervisors today; you're describing 12." Follow-up 1, they press the gap: return to the quotes and add nothing. Follow-up 2, they ask how you would cover the jump: give a plan in the future tense, naming your own first step with the supervisors and your own first week at a site. That is a plan, not a past. The concession is the number comparison, said without apology and without a bridge to experience you did not state. Answer slot: the JD's 4-sites and 12-supervisors lines make a probe on prior span likely. If your work has ever covered a different number of supervisors or more than one location, say which, when and what you were responsible for, in your own words; if not, say so plainly and stay with the quotes | F1 and F3 hold the biggest gap between the JD and the material, so this objection arrives in some form; JD because it scores the stated requirements, Skeptic because it is asked as doubt |
| A2 | "The role builds reporting in Excel and Power BI. Where are you today with each?" | JD | [grounded] "solid Excel"; "never used Power BI" | Two answers, kept separate. Excel: your own word was "solid Excel"; say it as your own assessment and let them ask what it covers. Answer slot: if you have built any recurring report in Excel, say what it showed and who read it, in your own words; if you have not built reports there, or it was not yours, say so plainly and say what you would build first. Power BI: the plain acknowledgment F5 carries, "I haven't used Power BI.", then a plan in the future tense: what you would learn first and how you would check you had it. Name your own first step; the pack does not choose it | F4 and F5 are the stated tool gap; JD because the reporting line is explicit |
| A3 | "Why Atlas Freight, and why this step from shift manager to running operations across sites?" | CO | [grounded] "currently a senior shift manager over 3 supervisors" | Your reasons are yours and the pack holds none of them. Answer slot: give your actual reason for moving and your actual reason for this company, one or two sentences each, in your own words; if one is not yet clear to you, say so plainly and say what you would want to learn. The only company facts safe to cite are the ones in the posting you gave me, which describes regional logistics with 800 employees and 4 sites. The pack holds nothing on the company's strategy or values, so repeat nothing about them | Motivation consistency is the Skeptic's score; F1 and F3 are the step being questioned. CO because it tests homework, which this pack could not research |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites has slipped for three weeks while the other three are steady. What do you ask first, and what do you do?" | CASE | [generic] | A live problem: it asks about no past and the guidance makes no claim about yours. Structure aloud. Clarify first: what counts as on-time, since when, which lanes or customers, what changed at that site. Then the objective, then segmentation by function, shift, lane and day, then the approach of comparing the slipping site against the steady three, then metrics and risks. Challenge one premise politely, such as whether the measure itself changed at that site | The JD's on-time line (F2's requirement) turned into a live problem; `[generic]` because the scenario is a pattern, not a fact about this employer |
| B2 | "Cost-per-shipment has risen two quarters running while on-time is flat. How do you find where the money is going?" | CASE | [generic] | Ask for the definition and the denominator first. Split the cost into the components you would ask the finance side for, check whether the mix of shipments moved before concluding anything changed, and name one low-risk test to run first. Say which finding would change your plan. No past is claimed | The JD's cost-per-shipment line (F2's requirement) as a diagnosis; this is a structure question, so it carries no claim about you |
| B3 | "Peak week lands on all four sites at once and one site is short on supervisors. How do you cover it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: what you need to know (volume by site, which shifts are short, who can cross-cover), then what you do, in order. You may point to your own experience once, in the quote's words: "I ran the site's peak-season surge plan two years running." Do not describe what the plan contained or how it went; the quote does not say | F1 holds the only surge evidence; CASE because it is asked as a decision |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the figure at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Then four parts in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least (name it before they do), and which part was yours. Where you do not know how it was counted, say so plainly; that is an honest branch. The pack supplies no baseline, method or period | F2's only evidence, so every prober goes here first; EXP because it tests whether the number survives |
| C2 | "What did the pick path look like before, and what did you change?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Describe, in your own words, what the path was and what you changed. The quote carries only that you redesigned it, so the detail comes from your memory, not from this pack. Where a follow-up goes past what you said, answer from memory only and say plainly when something was not yours or did not happen | The follow-up two levels down from C1; F2 |
| C3 | "How would you define on-time performance across four terminals, and what would you watch beside cost-per-shipment?" | JD | [generic] | A how-would-you question, not a past one. Make the definition choices explicit and say which you would pick and why: what clock, at which handoff, what grace window, which exceptions. Name two or three companion measures and why they pair with cost-per-shipment, and how you would keep four sites on one definition. Answer slot: the JD's on-time and cost-per-shipment lines make a probe on what you measure today likely. If you track either at your site, say which and how it is defined; if you do not, or it is not yours, say so plainly and answer as a plan | F2's requirement as a definitions probe; JD because it tests the stated measures |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who already runs several sites?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified"; "currently a senior shift manager over 3 supervisors" | Pause, restate the question, then answer from the quotes only: "I ran the site's peak-season surge plan two years running. I cut mis-pick rate 40% by redesigning the pick path. I'm green belt certified." Hold through two follow-ups by returning to those three, never adding to them. Concede once and specifically: "I'm over 3 supervisors today; you're describing 12." Then stop. Do not compare yourself to the other candidate, whom you know nothing about | F1, F2, F3 and F7 are the whole case, and the scale gap is what makes the question bite |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Anchor in the sentence's own attribution: you redesigned the pick path. Answer slot: say what part of the result came from the redesign and what part, if any, came from others or from other changes, in your own words; if you cannot separate them, say so plainly. Never claim the figure beyond the sentence and never shrink it below it. Hold through two follow-ups; concede only the specific thing you do not know | The suite's standard attribution probe, aimed at F2's one number |
| D3 | "The role builds reporting in Power BI, and you've never used it. Why should I be comfortable?" | JD | [grounded] "never used Power BI" | Hold the position, and the position is the plan, not a defence of experience. The plain acknowledgment F5 carries comes first: "I haven't used Power BI." There is nothing to soften. Then your own first step, your own way of checking you have it, and what you would ask the team to point you to. Give no dates or numbers unless they are yours, and do not call Excel work equivalent; the quotes do not say it is | F5 is a gap you stated, so the pressure version is predictable |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc in three beats the quotes carry: the 7 years in warehouse and distribution ops, where you are now (a senior shift manager over 3 supervisors), and one result (cut mis-pick rate 40% by redesigning the pick path). Tell them in your own words. The quotes give no steps between those beats, so add one only from memory and only if it matters. Answer slot: the JD's 5+ years line makes a probe on how many of the 7 years were spent leading people likely. Give the number if you know it, in your own words; if you cannot separate them, say so plainly and give the 7 years as you stated them. Close with your own reason for this role; the pack supplies none | F6 is the requirement this casual question quietly scores; JD content, conversational delivery |
| E2 | "Tell me about a time you used what you learned in your green belt." | JD | [grounded] "green belt certified" | The quote carries the certification and no project. Selection criteria: one real instance with a named problem, what you changed and what moved. Answer slot: the JD's Lean/Six Sigma line makes a probe on where you used it likely. If you used belt methods on the pick-path redesign, say which and how, in your own words; if you did not, or it was not yours, say so plainly and name where you did use them or how you would. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would apply it here. Have to hand whatever you can show for the certificate | F7 is a plus in the JD and a casual question is where it is asked; the quote names no project, so this is a scaffold |
| E3 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Premised only on the quote. The beats it carries: you ran the site's peak-season surge plan, two years running. Tell those in your own words. The quote says nothing about what the plan contained or how it went, so the pack adds nothing; where a follow-up goes past it, answer from memory only and say plainly when something was not yours or did not happen | F1 holds the surge evidence, and a friendly interviewer will ask for it as a story |

### F. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If the dock team and dispatch disagree on a cutoff time, how do you settle it?" | CASE | [generic] | Propose seam principles instead of pretending to know how the seam works here. Ask each side what they are protecting, put the customer-facing commitment first, look at what the cutoff misses actually cost, decide, write it down and set a review date. Then say you would ask how the sites currently handle it. No past is claimed | The JD's 4-sites line (F1's requirement) as a handoff problem; CASE because it is a decision |
| F2 | "How do you handle credit when a result spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | "We" for context, "I" for contribution. For your own result the sentence's attribution is the line: you redesigned the pick path. Answer slot: the credit probe makes a question on who else contributed likely. If others contributed, say who and what, in your own words; if the work was yours alone, or you cannot say, say so plainly and keep to the sentence. Never add a collaborator or a share the sentence does not give | F2 is the only result in the material, and the peer persona probes credit on exactly that kind of result |
| F3 | "You'd be working alongside the other three sites. What do you need from us in your first month?" | JD | [generic] | Reciprocity framing. Say what you would ask for: the handoff points between sites, a standing check-in, and how each site's reports are defined. Say what you would offer as a commitment about the future, such as sharing what you learn each week. Claim nothing about your past here; the question does not need it | The JD's 4-sites line (F1's requirement); this is the peer question the pack can prepare without knowing who the peer is |

### G. Values / Behavioral

No published values were read and no values-style round is detected, so these three use the persona stems and are `[generic]` except where a quote applies. No quoted sentence carries a story for G1 or G2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No quoted sentence carries this story, so choose one. Pick a real instance with a named stake, what you actually said, and a relationship still intact afterwards. Say plainly whether the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values probe for a role that reports performance upward; the pack holds no company value to map it to |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | No quoted sentence carries this story, so choose one. It needs the customer's stake, the metric you set aside, and what it cost. Say plainly what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values probe in a freight setting, where on-time (F2's requirement) and customer commitments pull against internal measures |
| G3 | "Tell me about a time you had to hold a supervisor accountable." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | The quote carries the role and no instance. Choose a real one: the expectation, what you said, and what changed. Say plainly if it did not change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's 12-supervisors line (F3's requirement) makes this likely |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, B1, B3, E3, F1, F3 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C1, C3 |
| "lead a team of 12 supervisors" | A1, D1, G3 |
| "build reporting in Excel/Power BI" | A2, D3 |
| "5+ years operations leadership required" | E1 |
| "Lean/Six Sigma a plus" | D1, E2 |

## Reverse questions

No interviewer profile exists, so none of these is tied to an interviewer's path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and which of the four sites is furthest from where you want it?" | It follows the JD's on-time line and shows you think in definitions; the answer tells you what you would inherit |
| R2 | "What does the supervisor group look like today, and where do you most need support?" | It follows the JD's 12-supervisors line and shows you plan around people before process |
| R3 | "What do the four sites' reports look like today, and how much sits in Excel versus Power BI?" | It follows the JD's reporting line and gets you an honest read on the learning curve you named |
| R4 | "What would a strong first 90 days look like in this role?" | It shows you are planning the first quarter, and the answer sets what you would be measured on |
| R5 | "How do the four sites hand work to each other, and where does that break?" | It turns the multi-site line into a conversation about the seams |
| R6 | "If I joined a team like yours, what could a new person do in the first month that would genuinely help?" | The reciprocity question to use if your interviewer turns out to be a peer; it signals partnership instead of need |

## Prohibited claims

Built from the fit snapshot before the banks. Each entry is a claim this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope: "I'm over 3 supervisors today." The limit is the pack's observation: the material says 3, the JD says 12 |
| Owned daily terminal operations across 4 sites | Inflated form of F1 | F1's quotes at their own scope: a shift-manager role and a site's surge plan. The limit is the pack's observation: the material shows no multi-site or terminal work. Answer slots stay inside the quotes |
| Improved on-time performance, or reduced cost-per-shipment | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." The limit is the pack's observation: that is an accuracy result, and the material gives no on-time or cost figure |
| Has experience with Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Has 5+ years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "I have 7 years in warehouse and distribution ops." The limit is the pack's observation: the material does not show how many of those years were leading people |
| Led Lean or Six Sigma projects | Inflated form of F7 | F7's quote at its own scope: "I'm green belt certified." The limit is the pack's observation: the quote names no project |

## Sources

Provided documents: the job posting text and the background you gave in your message. No dossier was present.

Searches sent, all refused for lack of permission, so each returned nothing and no pages were fetched:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics strategy news terminals` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL mapping; none is built, and G1 to G3 are generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have set the loop and persona weights; the generic archetype and flat weights stand in |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have fed CO questions and a grounding brief; A3 is the only CO question and it is limited to the posting's own facts |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The posting you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (hiring manager, peer, skip-level, panel) → replaces the flat persona weights and restructures the banks
- The recruiter's note on format, focus areas or any pre-declared deliverable → coverage assumed from the generic loop becomes coverage of what they said, and a graded-deliverable section if one was announced
- The interviewer's name → an interviewer read from their public professional footprint, and a reverse question tied to their path
- Permission to search the web → the three research targets run, so the CO bank and values mapping can be grounded in Atlas Freight's own pages. A deeper pass is optional and offered once: up to 6 more searches and 2 more fetches, several more minutes
- Your own answers to the slots in F1, F2, F3, F4, F6 and F7 (locations covered, on-time or cost figures watched, supervisor counts, Excel reports built, years leading people, belt methods used) → those rows upgrade from slots to quoted material, and the guidance regenerates around them
- Your CV → more of your own sentences to map; most rows rest on one line from your message
- The green belt certificate and the before-and-after mis-pick report, kept to hand → F7 and F2 can move from `medium` toward `high`, which is what a prober checks
- A `tuesday-dossier.md` from an earlier underwriting of this role → evidence graded in advance, and an underwriter-named top objection and prohibited claims in place of the inferred ones here
