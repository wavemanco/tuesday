# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations (name and title from your message; nothing else is known about him)
**Format:** 60 minutes. Relationship not stated, so this is built as a hiring-manager round. If he is a skip-level or part of a panel, the weights in the persona table change.

## How to use this pack

- **Personas** are how a question arrives (who is asking, in what style). **Types** are what is being scored.
- Type key: **VAL** is behavior against published values. **EXP** is a deep-dive into your work history. **JD** is a stated role requirement. **CO** is company and strategy knowledge. **CASE** is a live problem set in the role. No CO or VAL questions appear because no company research ran (see Sources).
- Provenance labels: `[grounded]` rests on your message or the JD. `[inferred]` is this pack's derivation. `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.
- Question IDs go by persona: A Skeptic, B Case/Strategist, C Data-Driven Prober, D Conversational, E Pressure, P Peer, V Values. Fit-snapshot rows are F1 to F10.
- Guidance is scaffolding, not a script. Every claim about your past is one of your own sentences. An "answer slot" is an instruction for the interview: answer it from your real experience, or say plainly it was not yours.
- **Highest-ROI prep: A2.** That is this pack's inference from F10, not something Saltmarsh said. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your sentence says one main title and weekly content drops, with nothing inspected behind it. Words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "live-events calendar for two of our mobile titles" makes a probe on how a content drop differs from a live event, and on a second title, likely. If any of your drops was a timed event, or you worked on more than one title, say which and what you did, in your own words; if not, say so plainly and stay with the weekly drops |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not say which teams you worked with on an update. Answer slot: the JD names four teams, so expect a probe on each. For any you worked with on a release, say how, in your own words; for any you did not, say so plainly and stay with what your material does carry |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your sentence says you presented the numbers, not that you owned a review or set the KPIs, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: expect a probe on where those numbers came from and who decided what went into the monthly set. If any of that was yours, say which part, in your own words; if not, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the words, but a one-line claim with nothing inspected behind it, so expect a probe. The JD's verb is manage and your sentence's is wrote; keep to yours. Lead with it in its own terms: you wrote it, and QA still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are in your sentence. Your sentences do not say the main title was a live-service game, and the JD says producing where yours says associate producer. Words: "4 years as an associate producer at a puzzle-game studio." Answer slot: say in your own words how the main title was updated over your two years; if it was not a live-service game, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, and the strongest row. Lead with it in its own terms: you ran it, weekly, for the main title, for two years. Expect a probe, because nothing inspected sits behind the line |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in the words: retention numbers, presented monthly. The sentence says presented, and nothing inspected sits behind it, so expect a probe on how the numbers were counted. Answer slot: if you chose or defined any of the measures, say which, in your own words; if someone else produced them, or you do not know how they were counted, say so plainly and stay with presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | transferability | Your sentence says you wrote a checklist QA still uses; it does not say what made the writing clear. Words stay at its scope: "Wrote the release checklist our QA team still uses." Answer slot: expect a request for an example. If another piece of your writing was acted on by others, say what it was; if the checklist is your one example, say so plainly |
| F9 | No JD line asks for leading a team; your message raises it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A limit you stated, and the JD's line is to coordinate teams, not to lead one, so it may never be asked as such. Words: "I haven't led a team." Then how you would work with teams you do not lead, said as a plan and never as a past |
| F10 | No JD line mentions in-app purchases or monetization; your message raises it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A limit you stated. The pack could not research whether it matters for Saltmarsh's titles, so treat it as a likely probe, not a known requirement. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first and from whom, said as a plan and never as a past |

## Persona table

Built on the hiring-manager prior. No loop source and no interviewer footprint was available, so beyond the top two the weights rest on a generic pattern (Screen, hiring manager, panel), not on Saltmarsh's documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet probing of the gaps: day-one weakness, missing experience | Highest. The hiring-manager prior is to derisk gaps, and F9, F10 and the thin rows F2 and F3 give it material | Rehearse the single most predictable objection (A2) until it is boring; calibrated candor over bluffing |
| B Case/Strategist | Live problems: plan a quarter, diagnose a retention dip, trade off two titles | Highest. Same prior (live problems on their actual roadmap), and the JD is almost entirely planning and running | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| C Data-Driven Prober | Goes line by line through the retention numbers | Medium. The JD's KPI and retention lines (F3, F7) invite it; no interviewer signal adjusts it | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| D Conversational | "Walk me through the journey", "why live ops" | Medium. Most interviews open this way; casual questions are still scored | A 90-second arc built from your own sentences |
| E Pressure | Time-boxed "why you", "how much was actually you" | Low. Less typical for a hiring-manager round, but cheap to rehearse | Hold through two follow-ups, then concede specifically |
| P Peer | Seam with design, collaboration | Low. He is more likely your future manager than a peer; rises if a panel is added | Offer principles for the seam rather than pretending to know it |
| V Values | Scenario probes | Low. No values round is established, and the generic archetype assumes none; scenario probes still appear in any hiring-manager chat | Choose stories only where your material carries one |

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role plans the live-events calendar for two titles. What part of that would be new to you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Name what is new plainly. Answer slot: if any of your drops was a timed event, or you worked on more than one title, say which, in your own words; if not, say so plainly and stay with the weekly drops | F1 is where the JD's two-title, live-events wording goes furthest past your sentence, so this is where the first probe lands; JD because it scores the stated requirement |
| A2 | "I don't see in-app purchases in your background. How would you handle that in this role?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." [grounded] "Presented the monthly retention numbers to the studio head." | Highest-ROI rehearsal. Level one: say it plainly in your sentence's terms, "I haven't worked on a game with in-app purchases", then what you would learn first and from whom, in your own words. Level two, if pressed on what you think drives purchases: say what you do not know yet and how you would find out. Level three, if pressed on whether this is a risk to the role: concede the limit specifically, then return to the nearest thing your material carries, "Presented the monthly retention numbers to the studio head.", as nearby work and not as purchase experience. Never describe store, pricing or purchase work | F10 is the one limit you stated outright and the likeliest place to be probed, which is this pack's inference, not something Saltmarsh said; EXP because it tests what was actually your background |
| A3 | "This role coordinates design, art, engineering and community on every update, and you haven't led a team. How would you get all four moving together?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly: "I haven't led a team." Then your approach to working with teams you do not lead, as a plan in your own words ("I would"), never as a past. Answer slot: the JD names four teams, so expect a probe on each. For any you worked with on a release, say how, in your own words; for any you did not, say so plainly | F9 and F2 meet here: a stated limit against a JD line the material does not yet speak to; JD for the coordination requirement |
| A4 | "This role owns the post-event review and the KPIs it reports. What part of that have you owned?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Hold only what the sentence carries: "Presented the monthly retention numbers to the studio head." Answer slot: expect a probe on where those numbers came from and who decided what went into the monthly set. If any of that was yours, say which part, in your own words; if not, say so plainly and stay with presenting them. Hold through two follow-ups by returning to the sentence, never by adding to it | F3 is the widest gap between the JD's verb and your sentence's; JD because it scores the stated requirement |
| A5 | "The role asks for three or more years producing live-service games. Tell me about the live-service side of your four years." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say the years in your own words: "4 years as an associate producer at a puzzle-game studio." Answer slot: say how the main title was updated over your two years; if it was not a live-service game, say so plainly and stay with the calendar you ran: "I ran the weekly content-drop calendar for our main title for the last two years." Say your title as it was | F5 is the requirement the material shows least about; JD because it scores the stated requirement, and the title wording is likely to be noticed |

### B. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would plan the next quarter of live events for one mobile title. What do you need to know first?" | CASE | [generic] | Clarify first (what the title is trying to move, what has already run, what art and engineering can deliver), then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's calendar line asked as a live problem; generic because it is a pattern for the problem, not a fact about Saltmarsh |
| B2 | "A live event just ended and retention for the players who joined it is below the previous event's. Diagnose it." | CASE | [generic] | Check measurement first (same definitions and windows), then cohort mix, then what changed (content, timing, a bug in the update), then say what you cannot tell from the data and what you would look at next, ranked | Tests the retention-metrics line (F7's requirement) as a decision, not a record; generic for the same reason as B1 |
| B3 | "Two titles want the art team in the same week. How do you decide?" | CASE | [generic] | Ask what each event is meant to move, what slipping costs each, what art can actually deliver, and who decides. Then pick one, state the trade-off, and say whom you would take it to. No claim about your past | The JD's two-title wording as a trade-off; generic |
| B4 | "Walk me through the release checklist you wrote and how QA uses it." | JD | [grounded] "Wrote the release checklist our QA team still uses." | The beats the sentence states: you wrote it, and QA still uses it; tell them in your own words. Answer slot: the JD's "manage the release checklist with QA" makes a probe on what is in it and how a release runs against it likely. If you ran releases against it, say how, in your own words; if QA ran it, or you did not run a release against it, say so plainly and stay with having written it | F4 is your cleanest row and the likeliest to be probed closely; JD because it scores the stated requirement |
| B5 | "An event ends tonight. What goes on the first page of the review you send tomorrow?" | CASE | [generic] | Structure: the objective set before the event, the result against it, what moved, what you cannot tell from the data, what changes for the next event and who owns each change. One page, in that order | The JD's post-event review line asked as a deliverable; generic |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented each month. Which measures, and how were they counted?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the sentence states: monthly, retention numbers, to the studio head. Answer slot: the JD's "comfortable with player-retention metrics" makes a probe on which measures and how they were counted likely. If you chose or defined any of the measures, say which and how they were counted, in your own words; if someone else produced them, or you do not know how they were counted, say so plainly and stay with presenting them | F7 has nothing inspected behind it, so the probe is expected; JD because it scores the stated requirement |
| C2 | "Which assumption behind one of those retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the assumption, in your own words, before the interviewer does. If you do not know how a figure was counted, say so plainly; that is a credible answer. The pack supplies no assumption | The weakest-assumption move converts a gotcha into credibility; EXP because it tests attribution honesty |
| C3 | "Tell me about a time you had to explain a retention number to someone." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named number, the person who asked, what you said, and what you did not know. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Presented the monthly retention numbers to the studio head.", or how you would handle it | An open prompt on F7's theme; the sentence is the honest fallback, not a story the pack can supply |

### D. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." [grounded] "Presented the monthly retention numbers to the studio head." | A 90-second arc in four beats, each one of your sentences in your own words: the four years, the weekly calendar, the checklist, the monthly numbers. Close on why live operations, from your own reason. Answer slot: give your actual reason in your own words | The casual opener is still scored; F5, F6, F4 and F7 are the beats |
| D2 | "Tell me about the weekly calendar you ran." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The beats the sentence states: weekly, content drops, the main title, two years. Answer slot: the JD's "experience running a content calendar" makes a probe on how a week ran likely. If you set the dates or chose what went in, say which, in your own words; if someone else did, or it worked differently, say so plainly and describe how you ran it | F6 is the strongest row, so it is where to be most concrete and most precise; JD because it scores the stated requirement |
| D3 | "Why live operations, and why Saltmarsh?" | EXP | [generic] | Answer slot: give your actual reasons in your own words, one about the work and one about the studio. This pack could not research Saltmarsh, so any Saltmarsh-specific reason must be one you hold yourself from what you have read | Motivation consistency is scored in any round; generic because the pack has no company material |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events on a title with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." [grounded] "Presented the monthly retention numbers to the studio head." [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold what your sentences carry, in their own words: the weekly calendar, the checklist QA still uses, the monthly retention numbers. Concede once, exactly: "I haven't led a team, and I haven't worked on a game with in-app purchases." Do not claim an equivalence; stop inside sixty seconds | Hold-then-concede on F9 and F10; JD because it scores fit against the role |
| E2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate, hold the sentence. Answer slot: if any part of the calendar was set by someone else, say which part and that it was theirs; if not, say so plainly and describe how you ran it. Hold through two follow-ups by returning to the sentence, never by adding to it | Attribution probe on F6; EXP because it tests what was actually yours |

### P. Peer (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where is the seam between live operations and design, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you cannot know. Frame it as reciprocity: what you would bring design, not only what you need from them. Say how you would handle a disagreement as a plan ("I would"), never as a past. No claim about your past | F2's requirement asked collegially; generic because the pack has nothing on how Saltmarsh's teams divide the work |
| P2 | "This role leans on clear written communication. What is a piece you have written that others worked from?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | The beats the sentence states: you wrote it, and QA still uses it. Answer slot: if any other writing of yours was acted on by others, say what it was; if the checklist is your one example, say so plainly. The pack supplies no account of what made it clear | F8 is the thinnest requirement row, and a written-communication probe usually asks for an example; JD because it scores the stated requirement |

### V. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Presented the monthly retention numbers to the studio head.", without saying any month's numbers were unwelcome unless they were, or how you would handle it | A standard scenario probe; no published Saltmarsh values were available, so this is a persona stem, not a value |
| V2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time that involved a real choice, what you gave up, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | The customer-over-metric stem, adapted to a game; no claim about your past |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1, B3 |
| Coordinate design, art, engineering and community teams | A3, P1 |
| Own the post-event review and the KPIs it reports | A4, B5 |
| Manage the release checklist with QA | B4 |
| 3+ years producing live-service games or apps | A5 |
| Experience running a content calendar | D2, E2, B1 |
| Comfortable with player-retention metrics | C1, C2, C3, B2 |
| Clear written communication | P2 |

No defend-the-number rows: your message gives no figure to defend. No CO questions: no company research ran.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first event look like for me in my first ninety days, and how would you judge it?" | It turns the calendar requirement into a shared definition of success, and his answer tells you what he scores |
| 2 | "Which of the two titles has its calendar in better shape, and what does the other need most?" | It works in the JD's two-title frame and shows you are thinking about the actual split |
| 3 | "How does an update get from idea to release here, and where does QA sit in that?" | It ties to the checklist line you can speak to, and shows you care about the release path |
| 4 | "Which post-event measures does the studio watch most, and who reviews them with you?" | It goes to the KPI-ownership line and tells you where the retention numbers fit |
| 5 | "Do the titles I would work on have in-app purchases, and if so, how do events and the store side work together?" | It names your gap yourself and asks what to learn, which reads as diligence rather than defence |
| 6 | "What would worry you about someone in this seat at six months?" | It invites the objection you most need to hear while you can still answer it |

All six are role-generic: no interviewer footprint was available, so none ties to his path.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led the design, art, engineering or community teams | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." Then a plan, never a past. No slot |
| Has worked on a game with in-app purchases, or on store, pricing or purchase work | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you would learn first. No slot |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one main title and weekly drops. A1's slot stays inside that |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says presented, not owned. A4's slot asks only where the numbers came from and who decided what went into the set |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope. The material says wrote, not managed. B4's slot stays inside having written it |
| Has 3+ years producing live-service games | Inflated form of F5 | F5's quote at its own scope. The material says associate producer and does not say live-service. A5's slot asks only how the main title was updated |

## Sources

Provided documents: the JD text and your background as written in your message. No dossier was present.

Searches sent, every one refused because web search was not permitted:

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio news strategy" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call refused. Would have fed a values cheat sheet if a values round were found, and the VAL question themes; V1 and V2 are persona stems instead |
| 2. Saltmarsh Games interview process, live operations | unavailable | Every call refused. Would have set persona weights from named rounds; they rest on a generic pattern instead |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every call refused. Would have fed CO and strategy-grounded CASE questions; B1 to B5 are generic instead |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The one call was refused. Would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search the web, then a standard research pass (up to 6 searches and 2 fetches) → Saltmarsh's published values, the interview loop, current strategy and anything public about Tobias, turning generic persona weights and CASE questions into grounded ones. A deeper pass after that is up to 6 more searches and 2 more fetches, several more minutes
- The round type and who Tobias is to the role → reweights every bank
- Any note from the recruiter on focus areas or a pre-declared task → coverage of that task, and a build section if one was named
- Your CV text → more quoted evidence rows, and fewer selection scaffolds
- Your answers, in your own words, to the slots in F1, F2, F3, F5 and F7 → those rows upgrade from discovery or transferability
- The release checklist, a content-calendar export or a monthly retention deck, with anything confidential removed → F4, F6 and F7 can rise from medium to high
- A tuesday-dossier.md → a named highest-ROI objection and a prohibited-claims list from verified evidence
