# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data. He would be Priya's peer, with both reporting to the same VP.
**Session:** one 60-minute conversation. Built on the assumption that no recruiter guidance exists and that no research could run (search was not permitted this session).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: where it says answer slot, the answer has to come from Priya's own experience, and "that was not mine" or "there was no such step" is always an honest branch.

"Your message" in this pack means the coach's brief: the JD highlights, the candidate summary, the interviewer profile summary and the research note.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior demonstrates the company's published values. Not used in this pack: no published values were available and no values round is documented |
| EXP | Whether the candidate's claims survive scrutiny and attribution is honest |
| JD | Whether the candidate can do the listed job, gaps included |
| CO | Depth of company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — your message; "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | The material carries adjacent product-strategy work, not ownership of a go-to-market. Words stay at the quote's scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD line makes a probe on whether any of your work took a product to market likely. If any did, say what it was and which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | low | [inferred] | discovery | The quote touches revenue growth and does not show whether it reaches any of those four stages. Answer slot: the JD line makes a probe on which stage your change worked on likely. If you can place it in a stage, say which and how you know; if the change does not map to those stages, or stages were not something you tracked, say so plainly and stay with the quote |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The quote names the tools and does not show analysis you ran yourself. Words: "I'm skilled in SQL/Tableau." Answer slot: Dan's self-description makes a probe on an analysis you ran end to end likely. If there is one, say what you asked of the data and what you found, in your own words; if you worked from other people's pulls, or not in these tools, say so plainly and stay with the quote |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The quote is a revenue model used in negotiations. The pack's observation: the material does not show how partners engage, which is what a motion is. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of what you built shaped how partners worked with the company, say which part and how, in your own words; if none did, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead in the quote's own terms, setting annual volume targets with cross-org consensus, because a named outcome beats an adjective |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms and the words stay there: "I use AI tools daily." The pack's observation: the highlights do not say whether the role means using AI tools or building AI products, and the material speaks only to use |
| F7 | Sales-ops and quota-setting fluency, as a peer in sales strategy would be expected to bring (role-family requirement, generic, not in the JD highlights) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F8 | "B2B data-infrastructure SaaS" — your description of the employer, not a JD requirement | "9 at a large consumer-tech company in product strategy & ops" — your message | medium | [inferred] | transferability | Derived from the employer description set against the quote. The quote is large-company product strategy in consumer tech and does not show business-customer work. Answer slot: a probe on the consumer-to-B2B move is likely. If any of your work involved business customers, say what and which part was yours; if none did, say so plainly and stay with the quote |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| own GTM strategy for two new product lines | C1, C3, G2 |
| identify whitespace across land/adopt/expand/renew | A5, C2 |
| run independent analysis in SQL and Tableau | A3, A4 |
| partner-motion design experience required | D2, A4 |
| strong cross-functional influence | B1, B2, B3, B4 |
| AI experience a plus | E2 |
| B2B employer context (F8) | D3 |
| sales-ops and quota fluency (F7, generic) | D1, G2, B4 |

## Reading the interviewer

Public footprint beyond your summary could not be checked, because search was not permitted. Everything here rests on the profile summary you gave.

| What you gave | Practical implication |
|---|---|
| Self-described "relentlessly data-driven" | Every number gets probed to its assumptions. The Prober bank (A) leads for that reason |
| Career spine in pricing and monetization roles | Pricing, packaging and unit-economics angles are his native language: use them in C2 and C3, after clarifying and never instead of it |
| One early-stage-startup chapter | Expect a scrappiness probe about big-company pace (D3, G2). Nothing in Priya's material is a startup story, so none is offered |
| Peer, same VP | He is pricing what the hire costs and contributes to his work: B1 and B4 carry that |

**Mirror opportunity.** His profile's spine is pricing and monetization and his seat is sales strategy; yours, per F1, is "9 at a large consumer-tech company in product strategy & ops". R1 asks him about his own move without claiming yours is the same. Shared identity is never a strategy.

## Persona table

Weights start from the peer relationship prior (Peer Evaluator and Data-Driven Prober), then adjust on his signals. They rest on your account of this session as one 60-minute peer conversation, not on a documented Northwind loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober (5 questions) | Line-by-line probing of the figure and the model | Highest. Peer prior plus "relentlessly data-driven" | Know what you can and cannot say about how the number was counted, name your weakest assumption first, offer one analysis end to end |
| B. Peer Evaluator (4) | Seam-splitting, credit, "what would you need from me" | High. Peer prior; he prices what you cost his team | Reciprocity framing, seam principles not a pretended seam, disagreement with spine and tact |
| C. Case/Strategist (3) | Live GTM, whitespace and bundling problems | Medium. The role is strategy and his spine is pricing | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D. Skeptic (3) | Quiet probing of F4, F7 and F8 | Medium. The gaps are real and he owns sales strategy day to day | Rehearse the single most predictable objection until it is boring; candor over bluffing a competency he owns |
| E. Conversational (2) | Journey question, casual AI question | Low to medium. Openers in a 60-minute chat, still scored | A 90-second arc from your own sentences; treat casual AI talk as scored |
| G. Pressure (2) | Time-boxed challenge, attribution | Low. Peers rarely stress-test, but the figure invites one | Pause, restate, hold through two follow-ups, concede specifically |

No Values/Behavioral bank: no published values were available, no loop source documents a values round, and Dan is not that interviewer.

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open at the quote's scope: you proposed a store-surface change that was credited with a ~$400M ARR uplift. Then four answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. For each, say what you know; if you do not know how it was counted, say that plainly. Do not supply a baseline or method you cannot repeat under a second question | F1 holds the only figure in the material and a Prober reads figures first. EXP because it tests whether the number survives scrutiny |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name it yourself, in your own words, before he does. Answer slot: if you know which assumption is softest, say it and why; if you do not know how the figure was built, say so plainly and return to the quote. Naming a limit first reads as credibility | The follow-up a Prober asks two levels down from A1. EXP; the metric rule requires this rehearsal for F1 |
| A3 | "The role runs independent analysis in SQL and Tableau. Tell me about an analysis you ran yourself, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | No quoted sentence carries a story here, so this is a selection scaffold: pick an analysis where you wrote the queries yourself, with a question you can state in one sentence and a finding you can state in one sentence. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "skilled in SQL/Tableau", or how you would approach one | F3 is a tools claim with no analysis behind it. JD because it scores a stated requirement, delivered as an open prompt |
| A4 | "Walk me through the revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-map on the quote: a partner-level revenue model, used in carrier negotiations, which are the beats it states. Answer slot: a Prober's likely probe is what went into the model and how it was checked. If you chose the inputs or checked it against outcomes, say how, in your own words; if inputs were given to you, or there was no check, or it was not yours, say so plainly and describe the model as you built it | F4 is the strongest quoted evidence against the partner requirement and the likeliest to be taken apart. EXP because it tests what was actually yours |
| A5 | "Where in the customer lifecycle did your store-surface change do its work?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: the JD's land/adopt/expand/renew line makes this probe likely. If you can place the change in one of those stages, say which and how you know, in your own words; if it does not map to those stages, or you did not track stages, say so plainly and stay with the quote | F2's gap is silence, so the honest form is a slot. JD content with EXP delivery |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: decisions sit with whoever carries the number, shared metric definitions are agreed before debating results, and a disagreement goes to the VP as one joint written view. Say these are principles to test with him, and ask where his team draws the line today. The question needs no claim about your past, so the guidance makes none | His teams sit beside the role. JD because it scores the cross-functional requirement; `[generic]` because it is a pattern, not a fact about Northwind |
| B2 | "When have you disagreed with a peer team and still landed a joint plan?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-map on the quote: annual volume targets, set, with cross-org consensus. Answer slot: the JD's cross-functional line makes a probe on the disagreement likely. If orgs disagreed, say what about and what you did; if there was no disagreement, or you were not the one who resolved it, say so plainly and return to the consensus the quote states | F5 is the evidence for influence. EXP because he is testing disagreement style with equals, not the target itself |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: the quote says the change was credited with the uplift. If asked who else contributed and how credit was assigned, say what you know, in your own words, and what part was yours; if you do not know how credit was assigned, say so plainly and stay with the quote | A peer prices credit-sharing, and the quote's own word "credited" invites it. EXP because it tests attribution honesty |
| B4 | "What would you need from me in your first 30 days, and what would you bring my team?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Reciprocity first. What you need: how his team's target and quota mechanics work, which follows from your stated gap. What you offer, at the quotes' scope: a partner-level revenue model used in carrier negotiations, and SQL/Tableau skills, put as offers to look at something together rather than claims about results. Do not offer a plan for his team | He is judging whether the hire adds to his load or reduces it. JD because it scores role fit; the reciprocity framing is the peer counter-strategy |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick one of the two new product lines and sketch the GTM plan. What do you need to know first?" | CASE | [grounded] your research note: enterprise expansion, the Compass launch, profitability, bundling by a larger platform vendor (provided, not checked here) | Clarify before structuring: which line, who the buyer is, which motions exist today, what success means given the profitability priority, and whether Compass is one of the two lines. Then objective, segmentation, approach, metrics, risks. Think aloud, and challenge one premise respectfully. The case asks about no past, so the guidance makes no claim about yours | The JD's lead requirement, asked live. CASE because it scores structure; the research note supplies the company's vocabulary |
| C2 | "For a new line, how would you find whitespace across land, adopt, expand and renew, and what would you pull first?" | CASE | [grounded] your research note, and the JD highlight "identify whitespace across land/adopt/expand/renew" | State the unit of analysis, lay the four stages out as a grid, and put one hypothesis per stage on where whitespace might sit. Name the account and usage data you would want first, then weigh expansion against profitability by asking what expansion costs relative to what it returns. Make no claim about analyses you have run | The JD's second line, in his pricing and unit-economics idiom. CASE with JD content |
| C3 | "A much larger platform vendor bundles a competing data product into its suite. How do you position one of our new lines?" | CASE | [grounded] your research note: bundling as the main competitive threat (provided, not checked here) | Clarify first: how much the bundled product substitutes for ours, and for which customers. Then segment where switching cost and differentiated value differ, think through packaging and pricing responses and what each does to margin, and challenge the premise that matching on price is the right frame. State the risk of each option | Bundling is the one competitive threat in your note. CASE with CO content, because it tests whether you can think at the company's altitude |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sales strategy is my day job, and your background doesn't include classic sales-ops or quota-setting work. Where would you be weakest on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | The highest-ROI rehearsal in this pack. Name the limit before he asks: the material shows no GTM ownership, no partner-motion design and no sales-ops work. Level 0: pause, restate, then the plain acknowledgment, "I don't have classic sales-ops or quota-setting experience." Level 1, closest work: name "set annual volume targets with cross-org consensus" and "built a partner-level revenue model used in carrier negotiations" at their own scope, never as quota work. Level 2, "targets are not quotas": hold by returning to the acknowledgment and the two quotes, and concede specifically that you would need him to walk you through how his team's mechanics work. Level 3, "so why you": name only the JD lines your quotes reach, cross-functional influence and SQL/Tableau, and stop. Then a ramp plan said as a plan and never a past: who you would ask, what you would read, what you would deliver in the first weeks, in your own words | F7 is a stated gap and he owns this territory, so this question arrives in some form. JD because it scores a listed capability; deepest because it carries the most follow-up levels |
| D2 | "The role asks for partner-motion design experience. What have you done there?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the quote at its scope: you built a partner-level revenue model used in carrier negotiations. Answer slot: if any part of it shaped how partners worked with the company, say which and how, in your own words; if none did, or it was not yours, say so plainly and stay with the model. Hold the position through two follow-ups by returning to the model, never by adding to it | F4 is the JD's only line marked required. JD because it scores that line directly |
| D3 | "You've spent nine years at a large consumer-tech company. Why B2B data infrastructure, and why now?" | JD | [inferred] "9 at a large consumer-tech company in product strategy & ops" | The reason has to be your own and this pack does not write it: say the actual reason you would give a friend, and tie it to one of Northwind's priorities only if that is true. Answer slot: if any of your work involved business customers, say what and which part was yours; if none did, say so plainly and stay with the quote | F8 is the consumer-to-B2B gap, and his startup chapter makes a pace-and-scrappiness probe likely. JD with EXP delivery; it tests motivation consistency |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" | A 90-second arc of three beats the quotes carry: two years of strategy consulting, then nine years in product strategy and ops at a large consumer-tech company, then one highlight you choose from the quoted work. End on why this role in your own words; this pack does not write that sentence | It opens most conversations. EXP because it tests whether the biography matches the CV claims |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say the quote at its scope, then name the tools and what you use them for in your own words. If that use is narrower than the question implies, say so plainly. Treat it as scored: the JD flags AI as a plus, and your research note names Compass | A casual question on a hot JD topic. JD content in a Conversational register |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That ~$400M figure. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede. Hold: you proposed the change, and it was credited with the uplift, which is the quote. Hold through two follow-ups by returning to those verbs. Concede specifically: what you do not know about how credit was assigned, and which part of the result others carried, in your own words. Never fold on the quote, and never add to it | The headline figure draws the attribution probe. EXP because it tests candor under pressure |
| G2 | "Sixty seconds: why you over a candidate who has run quota and sales ops?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Pause, restate, concede first what is true, "I don't have classic sales-ops or quota-setting experience", then name only what the quotes carry: the partner-level revenue model, the cross-org consensus on annual volume targets, SQL/Tableau. Hold that position without upgrading it, and do not claim to be better at quota work | Composure under a comparison to a better-matched candidate. JD because it scores fit against the listed role |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization before a sales-strategy seat. What carried over, and what did you have to learn from scratch?" | Tied to his own path. It turns the motivation probe into a peer conversation about the same kind of move |
| R2 | "You had an early-stage-startup chapter. What does going to market with something new teach you that a company this size has to relearn?" | Shows you researched him, and it bears directly on two new product lines |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it asks what reduces his load |
| R4 | "Where does your team's data run out on the two new lines, and what question do you wish you could answer that you can't?" | Surfaces the analysis gap you would fill and signals independent analysis |
| R5 | "When the product-line view and the sales-motion view disagree, how do you and the VP settle it?" | A seam question that asks about process rather than assuming one |
| R6 | "How much of the bundling pressure from larger platform vendors shows up in what sales strategy sees today?" | Uses the one competitive threat in your note and invites his deal-level view |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Treated "annual volume targets" as quota-setting | A claim one of the quotes contradicts, F7 | F7's quote: "No classic sales-ops or quota-setting experience." Nothing more |
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a store-surface proposal and a product-strategy-and-ops tenure, not GTM ownership |
| Sourced or owned the ~$400M ARR uplift | Inflated form of F1 | The quote's verbs, "proposed" and "credited". The pack's observation: the material does not say how the credit was assigned |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the material says a revenue model used in negotiations, not a motion |
| Builds or ships AI products | Inflated form of F6 | F6's quote: "uses AI tools daily" |

## Sources

Provided documents: your message (JD highlights, candidate summary, interviewer profile summary, research note on Northwind's priorities and competitive threat). No dossier was present.

| Query | Result |
|---|---|
| Northwind Data company values | refused |
| Northwind Data interview process strategy GTM | refused |
| Dan Kovac Northwind Data Director Sales Strategy | refused |
| Northwind Data Compass AI copilot launch | refused |

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Search refused. Would have fed a values cheat sheet and VAL questions; both are dropped |
| 2. `{company} interview process {role family}` | unavailable | Search refused. Would have established the loop; persona weights rest on your account of the session instead |
| 3. `{company} strategy` / recent news | unavailable | Search refused. Your research note stands in unchecked for date or accuracy, and the CO and CASE rows rely on it |
| 4. `{interviewer name} {company}` | unavailable | Search refused. The interviewer read rests on the profile summary you gave |
| 5. representative `{role title}` JD | skipped | The JD highlights you supplied fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- Full JD text → the highlight rows quote the JD itself rather than your summary, and any requirement the highlights left out (sales-ops, quota) gets a row
- Priya's own answers to the slots in F1, F2, F3, F4 and F8 → those rows gain evidence, and the slot guidance in A3, A4, A5, D2 and D3 becomes story-mapped
- Priya's account of how the ~$400M figure was counted and which part was hers → A1, A2, B3 and G1 become story-mapped instead of slots
- Recruiter guidance on focus areas or a pre-declared deliverable → coverage stops resting on peer-round priors
- Search access → values, loop structure, current strategy and Dan's public footprint, which would replace the unavailable rows above and sharpen the reverse questions
- A tuesday-dossier.md, if you have one → verified evidence and prohibited claims arrive pre-graded; the pack does not need one
