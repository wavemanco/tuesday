# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Prepared 20 November 2026 for three rounds on 29 November 2026. Interviewers are not yet named. Mode: loop, because your recruiter's email gives the schedule: one shared fit snapshot, then a mini-pack per round.

| Round | Who | Length | Persona weights (from the recruiter's email, relationship priors in the pack) |
|---|---|---|---|
| 1 | The recruiter | 30 min | Conversational, then Skeptic (light) |
| 2 | Head of Member Services, your future manager, mostly behavioural | 45 min | Values/Behavioral, then Skeptic, then Case/Strategist and Data-Driven Prober |
| 3 | Panel of two branch managers; includes a 20-minute complaint-escalation case; also the values round, scored against the four values | 60 min | Values/Behavioral, then Case/Strategist, then Peer Evaluator, then Skeptic |

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether what you claim about your work survives scrutiny |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you can think at Ashgrove's altitude: strategy, competition |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. It has two honest branches: say what you did, or say plainly that it was not yours or did not exist, and return to what your own words do carry.

The highest-ROI prep in the whole pack is B5, the contact-centre question. The JD names the contact centre, you have said you have not worked in one, and a prepared, non-defensive answer changes that conversation. Round 3's C11 and C12 and round 1's A7 are the same gap and the same shape in other mouths.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any later steps were yours, say which and what you did, in your own words; if the log was where your part ended, or those steps were not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. The branches half of this requirement is carried by F1's evidence, which names one branch. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The words stay at: "I built the monthly complaints spreadsheet our regional manager uses." The quote does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours measured. If it counted either, say which and how you counted, in your own words; if it counted something else, or neither, say so plainly and stay with the spreadsheet |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent: the quote has tellers, not supervisors, and training on a script, not coaching on escalations. Words: "I trained new tellers on our escalation script." Answer slot: if you ever helped another supervisor through an escalation, say what and how; if you did not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: the JD's digital line makes a probe likely. If you have worked with a digital or product team, even briefly, say what and which part was yours; if you have not, say so plainly, then say what you would want to learn first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Length of experience is a requirement to meet, not a gate. Reword only the quote: "I've spent 6 years in retail banking, the last 3 as a branch supervisor." The quote does not say what the first three years held, so the bridge claims nothing about them |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says formal; it does not show whether those complaints were governed by external rules. Words: "I handled the branch's formal complaints log." Answer slot: if they were governed by external rules, say which rules and what your part was; if they were not, or you do not know the rules' detail, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for the first one, said as a plan. Your material does not say what presenting you have done at any level, so nothing is claimed about it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote says spreadsheet, not Excel, and the reading that claims less is the one used. Lead with the quote's own terms: you built it, it is monthly, your regional manager uses it. Say Excel only once you have confirmed the tool |

No gate rows: the JD you pasted states no authorization, licence, location, schedule or pay term, so none was asked about.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end | A1, B3, B7, C5 |
| Across branches and the contact centre | A7, B5, B8 |
| Report monthly on complaint volumes and resolution times | B10, B11 |
| Coach branch supervisors on escalations | B1, C6, C8, C11 |
| Work with digital teams on self-service journeys | B4, B9 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A8 |
| Confident presenting to senior leaders | B11, C12 |
| Comfortable with Excel reporting | B11 |

## Grounding brief: Ashgrove's 2026 strategy

From your message's summary of the strategy brief Ashgrove published in July 2026. This is a four-point summary, not the full brief.

| Item | What the brief says | Provenance | Where it can surface |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | A2, B9, C5 |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | [grounded] | A2, R2.4, C7 |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | A2 |
| Competition | The main competitive pressure is app-only banks | [grounded] | B9, C5 |

Vocabulary: the JD and the values page say members, not customers. Use theirs.

---

# Round 1: the recruiter (30 minutes)

Persona weights: the recruiter-screen prior is Conversational plus a light Skeptic, because the usual job of the call is logistics, motivation and knockout checks in a friendly register. Nothing in your material changes that. The risk is treating it as unscored.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Chatty opener, pay, notice, location, why leaving | High: recruiter screen prior | A prepared 90-second arc; treat casual questions about the JD as scored |
| Skeptic (light) | One or two knockout checks against the JD | Medium: the JD names the contact centre and regulated complaints | Say the gap plainly, then the nearest thing you actually did |

### Conversational bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: how did you get from retail banking to wanting this role?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | A 90-second arc made only of what your sentences say: "I've spent 6 years in retail banking, the last 3 as a branch supervisor. I handled the branch's formal complaints log." Those are the beats the quotes state. Why you want this role is yours to say in your own words, and the pack supplies none | F6 is the years requirement, F1 is the nearest evidence for the role itself; JD because it checks the stated length of experience, with EXP content |
| A2 | "What do you know about where Ashgrove is heading, and what draws you to it?" | CO | [grounded] | Use one or two items from the grounding brief, not the whole list: the 40% digital target for 2028 and the move from eight branches to five hubs in 2027. Then say in your own words why they matter to someone owning complaints. Do not recite; the recruiter has the brief too | The recruiter sent the brief, so this checks you read it; CO because it scores strategy fluency |
| A3 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot: give your own number, or ask what the role's band is first, and say whichever you choose in your own words. The pack gives no figure. If asked what you earn now, you may decline and return to the role's band | Pay is a standard recruiter-screen item; JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, from your own terms of employment, in your own words | Standard knockout; JD because it concerns the job's start |
| A5 | "Where are you based, and is there anything about location or hours we should know?" | JD | [grounded] | Logistics slot: state your own situation in your own words. The JD you pasted says branches and the contact centre but not where the role sits, so ask the recruiter that rather than guess | A logistics slot the recruiter will fill from your answer; the JD's silence is the pack's observation |
| A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words; the pack supplies none. If both are true, say what you are moving toward as well as what you are leaving | Motivation consistency is scored here; EXP because the reason must fit your history in F6 |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "The role covers the contact centre as well as branches, and I don't see contact-centre experience in your background. How do you see that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Short version of B5: "I haven't worked in a contact centre." Then what you did have: "I handled the branch's formal complaints log." Then your own plan for learning it, said as a plan. Do not call the two kinds of work similar; let the recruiter judge | F2 is the stated gap, and a recruiter is the first person to ask about it; JD because the contact centre is in the requirement |
| A8 | "This role needs experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Open with the quote: "I handled the branch's formal complaints log." Answer slot: if those complaints were governed by external rules, say which and what your part was; if they were not, or you do not know the rules' detail, say so plainly and stay with the log | F7 is the row where the JD's wording and your evidence differ; the question is a knockout check, so a plain answer matters more than a big one |

### Reverse questions for the recruiter

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does the 20-minute case in round 3 involve: do I prepare anything beforehand, and is it written or spoken?" | A process question with a prep reason; the recruiter can answer it and it removes the largest unknown |
| R1.2 | "How is complaint handling split today between branches and the contact centre?" | Shows you read the JD's scope and are honest that the contact centre is the part you have not worked in |
| R1.3 | "Where would the role sit, and how often would it be in branches rather than elsewhere?" | A practical question that also fills the location slot from their side |
| R1.4 | "Which parts of the role matter most in the first three months?" | Lets you hear what they weigh before the manager round |
| R1.5 | "Is there anything in my background you would want me to address with the Head of Member Services?" | Surfaces the recruiter's own read of the gaps while there is still time to prepare |

---

# Round 2: the Head of Member Services, your future manager (45 minutes, mostly behavioural)

Persona weights: the hiring-manager prior is Case/Strategist plus Skeptic, but the recruiter's email says mostly behavioural, so Values/Behavioral rises to the top and the Case/Strategist drops to a lighter bank. The manager will test the gaps in F2, F5 and F8 before deciding on the shape of the role.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts, STAR-shaped stories | Highest: the recruiter called the round mostly behavioural | Where a quoted sentence carries a story, map it; where none does, use the selection scaffold and its honest branch |
| Skeptic | The contact-centre gap, day-one weakness, scale | High: the manager would own your ramp-up | Rehearse the single predictable objection until it is boring |
| Case/Strategist | A live problem on their roadmap | Medium: the prior for a hiring manager, reduced by the behavioural steer | Clarify, structure, then answer; use Ashgrove's own vocabulary |
| Data-Driven Prober | What your spreadsheet counted, what a report should hold | Medium-low: the role reports monthly | Know what you can and cannot say about how your report was built |

### Values/Behavioral bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on the one thing the quote states: "I trained new tellers on our escalation script." Answer slot: if any teller's escalation ever needed you to coach them afterwards, say what happened and what you did; if there was no such case, or it was not yours, say so plainly and describe the training | F4 is the evidence for the coaching requirement and its limit; JD because the JD names coaching on escalations |
| B2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior something they did not want to hear. It needs a named stake, a moment you did not soften it, and a relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | A persona stem from the Values/Behavioral type; VAL because it scores whether you will bring a manager a hard truth, which the role does |
| B3 | "Tell me about a time you had to give a member an outcome they did not want." | EXP | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, with the quote as the nearest thing your material carries: "I handled the branch's formal complaints log." Pick a time the member's complaint ended in a result they did not want; it needs what the result was, how you said it, and where it left the member. If no such time comes to mind, say so plainly, then stay with the log or say how you would handle it | F1 is the evidence the question leans on; EXP because it tests your own part, and the theme comes from the JD's complaints process |
| B4 | "Tell me about a time you worked with a team outside your branch to change something for members." | JD | [generic] | Selection scaffold: pick a time you worked with people outside your branch, such as another team, to change something; it needs who they were, what you wanted changed, and your own part in it. If no such time comes to mind, say so plainly, then say how you would approach working with a digital team | F5 shows no evidence, so the honest branch matters most here; JD because the JD names digital teams |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "I don't see contact-centre experience in your background, and this role owns complaints across the contact centre too. How would you handle that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | The deepest rehearsal in the pack. **Opening:** "I haven't worked in a contact centre." Then the nearest things you did, at their own scope: "I handled the branch's formal complaints log" and "I trained new tellers on our escalation script." The limit, named before it is asked: those are branch work; do not call them similar. Then your plan as a plan, in your own words: who you would learn from, what you would want to see, and by when. **Follow-up 1, "How would branch experience carry over?":** hold the quotes and say what they are; do not widen them. **Follow-up 2, "So you would rely on the contact-centre team at first?":** concede specifically: "Yes, on day one I would be relying on the people who have worked there." Concede the gap, never the quotes. **Follow-up 3, "What if that team does not welcome it?":** answer as a plan, not as a prediction. Rehearse until it is boring | F2 is the largest stated gap against a headline line of the JD; JD because the contact centre is in the requirement. Deepest means the most follow-up levels, the exact concession wording and a limit named first |
| B6 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose the answer that is true for you; the pack's observation is that your material shows gaps at F2, F5 and F8. If it is the contact centre or presenting, say it using your own stated words: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level." Then your plan for it. Do not pick a weakness you do not have in order to sound safe | A persona stem; JD because it asks for self-assessment against the listed requirements |
| B7 | "You've handled one branch's complaints. This role covers every branch and the contact centre. What changes?" | JD | [grounded] "I handled the branch's formal complaints log" | Start from the quote and its scope: "I handled the branch's formal complaints log." Then say plainly what is different about scale as you see it, in your own words. Answer slot: if you have seen complaints from other branches reach you, say how; if you have not, say so plainly and stay with the one branch | F1's limit, asked as scale; JD because it scores the end-to-end requirement, with EXP content |

### Case/Strategist bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B8 | "Sketch how you would find out where complaints get stuck between branches and the contact centre. What do you need to know first?" | CASE | [generic] | Think aloud: clarify what a complaint is and who currently owns each step; state the objective; split by channel and by stage; say how you would find the stuck points; name what you would measure; name the risks. Challenge one premise politely, such as how complaints are recorded today. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's scope; CASE because the manager is buying structure, and `[generic]` because it is a pattern, not a fact about Ashgrove |
| B9 | "Ashgrove wants 40% of member service on digital channels by 2028. What would worry you about complaints in that shift, and what would you watch?" | CO | [grounded] | Structure: what changes for a member who complains through an app rather than at a counter; what you would want to know before it happens; what you would watch afterwards. Use "members", and the brief's own figure of 40% by 2028 and its note on app-only banks, once. The question needs no claim about your past | Grounded in the brief; CO because it tests strategy fluency at the manager's altitude |

### Data-Driven Prober bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B10 | "Walk me through the monthly complaints spreadsheet you built. What did it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open with the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted complaint volumes or how long they took, say which and how you counted them; if it counted something else, or you do not know how a figure was arrived at, say so plainly and stay with the spreadsheet. Name the assumption in it you would defend least only if you know one | F3 is where the JD's volumes and resolution times meet your evidence; EXP because it tests what was yours |
| B11 | "What would you put in a monthly complaints report for senior leaders, and how would you build it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Start from who reads it and what they decide with it; the JD names volumes and resolution times, so say what you would start with and what else you would ask for. On how you would build it, say the tool you actually use; your quote says spreadsheet, so say Excel only if that is what it was. Answer slot: if you have presented a report to someone above regional level, say so; if not, "I haven't presented to anyone above regional level" is true, and your plan follows | F9 and F8 meet here: the reporting requirement and the senior audience; JD because the JD names both |

### Reverse questions for the Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Where does complaint handling stand today across branches and the contact centre: what is working and what is not?" | Shows you are honest about the part you have not seen, and gives you their real baseline |
| R2.2 | "What would you want from this role in its first 90 days?" | Makes the manager define success in terms you can then aim at |
| R2.3 | "What do branch supervisors currently find hardest about escalating?" | Ties to the coaching requirement without claiming you already know |
| R2.4 | "How will the move from eight branches to five hubs in 2027 change who this role works with?" | Uses the brief and shows you read it |
| R2.5 | "Which complaint reports go to senior leaders today, and what do they decide from them?" | Ties to the presenting gap in a way that asks about their needs rather than your limits |
| R2.6 | "Is there a part of my background you would want to test further?" | Invites the objection now so you can answer it |

---

# Round 3: the panel of two branch managers (60 minutes, including a 20-minute case; also the values round)

Persona weights: the recruiter's email says the panel scores against the four values, so Values/Behavioral is dominant and the values cheat sheet below lives here. The 20-minute escalation case makes Case/Strategist the next weight. The panel are branch managers, the people whose supervisors you would coach, so a Peer Evaluator tilt is the pack's inference from their role (no panel member is named). The Skeptic is light: the gaps come back, but in the panel's register.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Stories scored against the four published values | Highest: stated in the recruiter's email | One story per value, quoted from your own sentences or a scaffold with its honest branch |
| Case/Strategist | The 20-minute complaint-escalation case | High: stated in the recruiter's email | Clarify, structure, answer; use the values as vocabulary |
| Peer Evaluator | The seam between branches and the complaints lead, what you would need from them | Medium: inferred from their role as branch managers | Reciprocity framing; seam principles, not a pretended seam |
| Skeptic | Contact centre, presenting, reach | Low-medium: the gaps return in panel form | The same plain acknowledgment and plan as B5 |

### Values/Behavioral bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Members First, Always: tell us about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold; the nearest thing your material carries is "I handled the branch's formal complaints log." Pick a decision where the member's view and an easier option for the branch pulled apart; it needs what the choice was, what you chose, and what it cost or saved the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | The first published value, asked as the panel will score it; F1 is the nearest evidence |
| C2 | "Plain Words: tell us about a time something you wrote or explained needed explaining twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold; the nearest thing your material carries is "I trained new tellers on our escalation script." Pick a time wording of yours, a letter, a script or an explanation, did not land first time; it needs what was unclear, how you found out, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | The second value; its test, that an explanation needed twice was written wrong, is Ashgrove's own; F4 is the nearest evidence |
| C3 | "Neighbours, Not Numbers: tell us about a time what you knew about your local community changed how you handled something." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold; the nearest thing your material carries is "6 years in retail banking, the last 3 as a branch supervisor." Pick a case where local knowledge, not a figure, changed what you did; it needs what you knew, what you did differently, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | The third value, and the one the hub consolidation in the brief makes most live for branch managers (inferred); F6 is the nearest evidence |
| C4 | "Own the Fix: tell us about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold; the nearest thing your material carries is "I handled the branch's formal complaints log." Pick a problem you found, not one handed to you; it needs how you found it, what you kept hold of, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | The fourth value; the role is about complaints that must be followed through, so expect a probe on what was actually yours. F1 is the nearest evidence |

### Case/Strategist bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "A member has complained three times about the same fee error and the branch says it is resolved. The member says they are moving to an app-only bank. You have 20 minutes: how do you handle it?" | CASE | [generic] | A practice scenario, because the recruiter has not said what the real case is. Clarify first: what was promised, what the record shows, who holds it now. State the objective for the member and for Ashgrove. Then approach, metrics and risks, thinking aloud. Use the values as your vocabulary: the member's side of the counter, one explanation in plain words, someone keeps hold until it is fixed. The question needs no claim about your past | The recruiter said 20 minutes on a complaint escalation; CASE because the panel scores structure, and the app-only bank is the brief's competitive pressure |
| C6 | "A branch supervisor escalated a complaint late and the member is angry. How would you coach them?" | CASE | [generic] | Structure: find out what happened without blame; what the supervisor needs to do differently next time; what gets recorded; how you follow up. Say what you would ask before you advise. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's coaching line; CASE because the panel are the supervisors' managers and will judge the tone |
| C7 | "Ashgrove plans to move from eight branches to five hubs during 2027. If you were responsible for complaints through that change, what would you want in place?" | CO | [grounded] | Structure: who is affected and how complaints might change for them; what you would want recorded; what you would watch. Say that you would want to hear branch managers' view first. The question needs no claim about your past | Grounded in the brief; CO because the panel's branches are the ones consolidating (inferred from the brief) |

### Peer Evaluator bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C8 | "Our branches sit next to your team. Where is the seam, and what happens when we disagree about an escalation?" | JD | [generic] | Propose principles for the seam rather than claiming to know it: who decides what, how a disagreement gets resolved, what is recorded. Do not pretend to know how it works at Ashgrove today; say you would ask. Disagreement story: selection scaffold, pick a time you disagreed with someone at your own level about a complaint; it needs the disagreement, what you did, and the relationship afterwards. If no such time comes to mind, say so plainly, then say how you would handle it | Peer stem; JD because the role works with branches |
| C9 | "How do you handle credit when a branch fixes a problem you spotted?" | VAL | [generic] | Say how you would think about it in your own words; the Own the Fix value says whoever finds the problem keeps hold of it until it is solved, so be ready to say how you would keep hold of a problem and still share the credit when branch staff fix it. The question needs no claim about your past | A persona stem; VAL because it tests Own the Fix against the reality of a role that depends on other people's work |
| C10 | "What would you need from us as branch managers in your first month?" | JD | [generic] | Lead with what you bring them, then what you need: a list of what you would ask them for, in your own words. Do not pretend to know their pain points; ask | Reciprocity question; JD because it tests partnership with the branches |

### Skeptic bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C11 | "You have been a branch supervisor and you have not worked in a contact centre. Why you for a role with this reach?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "Never worked in a contact centre" | Same shape as B5. Start from the quotes: "I've spent 6 years in retail banking, the last 3 as a branch supervisor" and "I haven't worked in a contact centre." Then your plan, as a plan. Answer slot: if you have coached other supervisors, say so; if you have not, say so plainly and stay with what you did | F2 returns in panel form; JD because the question is about the reach the JD describes |
| C12 | "This role presents to senior leaders. How would you prepare for your first one?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan as a plan, in your own words: who you would ask, how you would rehearse, what you would put first. The 20-minute case is itself a presentation to two managers; use it as practice rather than as a claim | F8 is a stated gap; JD because the requirement is explicit |

### Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for people who would work next to the role |
| R3.2 | "Which escalations reach you today, and what do you wish happened differently?" | Shows you start from their experience, not your plan |
| R3.3 | "How do you expect the move to five hubs to change what members bring to you as complaints?" | Uses the brief and speaks to what the panel will live through |
| R3.4 | "Where do you find the four values hardest to live in a branch?" | Shows you treat the values as practice, not slogans |
| R3.5 | "What would you want a complaints lead to understand about running a branch?" | Invites them to teach you, which is the Plain Words stance |
| R3.6 | "What would you want to see from me by the end of the first quarter?" | Ends on their definition of success |

---

## Values cheat sheet (belongs with round 3)

A values-style round is detected: the recruiter's email says the panel scores against the four values. The values are from the page you pasted, copied from ashgrovecu.org/about/values on 20 November 2026. No quoted sentence of yours carries a story for any of them, so each is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's point of view | F1: "I handled the branch's formal complaints log" is the nearest sentence, not a story. Scaffold in C1: pick a decision where the member's view and an easier option pulled apart. If none comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it |
| Plain Words | Explanations and writing should land the first time | F4: "trained new tellers on our escalation script" is the nearest sentence, not a story. Scaffold in C2: pick wording of yours that needed explaining twice. If none comes to mind, say so plainly, then give the nearest thing or how you would handle it |
| Neighbours, Not Numbers | Each branch is treated as part of its town, not as a figure | F6: "6 years in retail banking, the last 3 as a branch supervisor" is the nearest sentence, not a story. Scaffold in C3: pick a case where local knowledge changed what you did. If none comes to mind, say so plainly, then give the nearest thing or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log" is the nearest sentence, not a story. Scaffold in C4: pick a problem you found and kept hold of. If none comes to mind, say so plainly, then give the nearest thing or how you would handle it |

---

## Prohibited claims

Not coached in any round. Each lists its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end, across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one branch's log. B7's slot stays inside the log |
| Has contact-centre experience | Negative the candidate stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." Then a plan |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope; B10's slot asks only what the spreadsheet counted |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote: tellers, not supervisors. B1's slot stays with the tellers |
| Handled regulated complaints | Inflated form of F7 | F7's quote: the formal complaints log. A8's slot asks only about the rules that applied |
| Has presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan |
| Has advanced Excel skills | Inflated form of F9 | F9's quote: the spreadsheet. Name the tool only once you have confirmed it |

---

## Sources

Provided documents: the JD as pasted in your message; Ashgrove's four values as pasted, copied from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email on the process; your four-point summary of Ashgrove's July 2026 strategy brief; your background as written in your message.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page is in hand and fixes the values cheat sheet |
| 2. Ashgrove interview process, member-experience roles | skipped | The recruiter's email establishes three rounds, who runs each and that the panel scores the four values; persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief summary you gave is under six months old and fixes the CO bank; it is a four-point summary, not the full brief |
| 4. Interviewer names at Ashgrove | n/a | No interviewer is named, so there is no query to form; the upgrade menu says what names would unlock |
| 5. Representative member-experience JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names and titles, once assigned → an interviewer read, persona weights tuned per person, and a reverse question tied to their path; the branch managers matter most
- The recruiter's description of the 20-minute case (written or spoken, any materials, how it is scored) → a tailored case section in place of C5 and C6, which are practice scenarios
- What your monthly spreadsheet counted, and whether it was Excel → upgrades F3 and F9 and the answer slots in B10 and B11
- Whether the formal complaints you handled came under external rules, and which → upgrades F7 and A8
- Any time you helped another supervisor through an escalation → upgrades F4, B1 and C11
- Any work you did with a digital or product team, even briefly → upgrades F5 and B4
- What presenting you have done at or below regional level → upgrades F8, B11 and C12
- Your own pay, notice, location and reason-for-leaving answers → fills the logistics slots A3 to A6
- An anonymised copy of the monthly report, with no member data → can raise F3 and F9 from medium to high
- Your CV → quotes in the snapshot can then come from it as well as your message
- How many hours you have to prepare → a prioritised prep schedule across the three rounds
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisation context; offered once
- A tuesday-dossier.md from an earlier evaluation → verified evidence and a standing list of claims to avoid, in place of the ones built here
