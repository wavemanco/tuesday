# Member Experience Lead — Ashgrove Credit Union — three-round interview pack

Candidate: Dara. Loop mode: three rounds on 29 November 2026 (recruiter 30 min; Head of Member Services, your would-be manager, 45 min, mostly behavioural; panel of two branch managers 60 min, with a 20-minute complaint-escalation case, scored against the four published values). No interviewer names are assigned yet, so the pack reads roles, not people. Built on your message alone: no CV, no search calls.

## How to use this pack

- Personas are how a question arrives; types are what is being scored. Types: VAL = behavioural or values alignment; EXP = work-experience deep-dive; JD = the posting's stated duties; CO = company and strategy knowledge; CASE = a live problem.
- Guidance is scaffolding, not a script. Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. Where your sentences stop, the guidance is an answer slot: answer it from your real experience, or say plainly it was not yours or did not happen.
- Question letters skip F so they never clash with fit rows F1 to F9. Rounds: 1 = A to B, 2 = C to E and G, 3 = H to L.

## Prep triage

Nine days, hours per day unknown, so this is an order, not a timetable. All three rounds fall on one day, so the same answers get tested three times.

1. Days 1 to 2: rehearse D1 aloud until it is boring. It is the highest-ROI item in the pack, and B1 and D3 are the same answer asked from other angles.
2. Days 2 to 4: find one real moment for each of the four values (H1 to H4). Without them the values round is all scaffolds.
3. Days 3 to 5: do J1 against a timer, twice, aloud. Twenty minutes is a third of the panel.
4. Day 4: open your monthly complaints spreadsheet and check what it counted and how, for G1, G2 and B2.
5. Day 5: settle your own approach to A3 to A6 (pay, notice, location, reason for the move). These are the recruiter's first questions.
6. Days 6 to 7: learn the four strategy facts in the grounding brief; drill E3 once.
7. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far your part reached likely. If any stage beyond the log was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The sentence shows a monthly spreadsheet for your regional manager, not what it counted. Answer slot: if it showed volumes or resolution times, say which and how each was counted; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | presentation | The quote already reaches the requirement in other words. The bridge rewords only that quote: "I built the monthly complaints spreadsheet our regional manager uses." Your material says spreadsheet and names no tool, so the word Excel and any feature of it come from you or not at all |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your sentence says you trained new tellers on the script, not that you coached supervisors. Words stay at "I trained new tellers on our escalation script." Answer slot: if you ever coached a supervisor or peer through a live escalation, say what happened and what part was yours; if not, say so plainly and stay with training the tellers |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with it in your own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | low | [inferred] | discovery | Your word is formal; the JD's word is regulated, and your material does not show whether the two meet. Answer slot: if you know what rules or time limits applied to the log, say so in your own words; if you do not know, or there were none you were aware of, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated absence. Words: "I've never presented to anyone above regional level." Then a plan for getting ready, said as a plan and never as a past. Your material does not say who counts as senior at Ashgrove |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent. Answer slot: if you have worked with a digital or technology team on anything members used, say what it was and your part in it; if you have not, say so plainly and say what you would want to learn first |

## Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| Own the member complaints process end to end | F1 | B1, D1, J1 |
| across branches and the contact centre | F2 | B1, D1, D3, J3 |
| report monthly on complaint volumes and resolution times | F3 | E1, E3, G1, G2 |
| coach branch supervisors on escalations | F5 | C2, C4, J2, K1 |
| work with digital teams on self-service journeys | F9 | E2, L2 |
| 4+ years in financial-services customer operations | F6 | A1, B2 |
| experience handling regulated complaints | F7 | D2, J1 |
| confident presenting to senior leaders | F8 | C1, D3, E3 |
| comfortable with Excel reporting | F4 | B2, G1 |
| The four published values | none | H1 to H4, C3 |

## Grounding brief

From your summary of the July 2026 strategy brief the recruiter sent. I have your four points, not the brief itself.

| Item | What it says | Provenance | Where it comes up |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] your message | E2, L2, reverse questions |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] your message | J3, H3, round 3 reverse questions |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] your message | A2 |
| Competitive frame | "the main competitive pressure is app-only banks" | [grounded] your message | A2, E2 |

---

# Round 1 — recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | high | Recruiter-screen prior: conversational plus a light Skeptic. Thirty minutes is short, and the casual register is still scored | A 90-second arc for the biography question; treat every casual question about the role as scored |
| Skeptic (light) | Knockout checks on the requirements most likely to be absent | medium | A recruiter checks the JD's headline requirements against your background; your own message names two absences | Say the absence plainly first, then the plan |
| Others | Not expected in this round | low | No technical or case content in a recruiter's remit as described | None needed |

### Bank A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far and what has brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Open with those words: six years in retail banking, the last three as a branch supervisor. Then why this role, in your own words and only a reason that is true for you; the pack does not supply it. Keep it near 90 seconds | The opening question of nearly every screen; F6 is the evidence it rests on. EXP because it tests whether the CV line survives being said aloud |
| A2 | "What do you know about Ashgrove, and what draws you to a member-owned credit union?" | CO | [grounded] your summary of the July 2026 brief, in the grounding brief above | Bring one or two facts from the grounding brief, accurately and no further: the digital shift, the move from eight branches to five hubs, the Q1 2027 small-business product, or app-only banks as the competitive pressure. Then say, in your own words, why a member-owned organisation appeals, if it does. Do not speak about how Ashgrove feels about any of it; the brief summary does not say | Homework check. CO because it scores knowledge of the strategy; a recruiter often asks it casually and still scores it |
| A3 | "What are you looking for in terms of pay?" | JD | [generic] | Logistics slot. Decide beforehand which you will do: give your own number, or ask what band the role carries first. Say your own figure only if it is real for you. If asked what you earn now, you can decline politely and return to what you are looking for | Pay is a standard recruiter check, and the JD you pasted states none. JD because it concerns the role's terms |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words | Standard recruiter check; the answer is factual and yours alone |
| A5 | "Where are you able to work, and how often in person?" | JD | [generic] | Logistics slot. Give where you can work and how often, as it is for you. The JD you pasted states no location or in-person pattern, so listen for what they say and answer only for yourself | Location is a standard recruiter check, and the role spans branches and a contact centre |
| A6 | "What is prompting a move now?" | EXP | [generic] | Logistics slot. Give your actual reason in your own words. If you prefer to lead with what draws you here, lead with it, and keep it true | The reason for the move is the one recruiter question candidates treat as unscored. EXP because it tests consistency with A1 |

### Bank B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns complaints across the branches and the contact centre. What would be new to you?" | JD | [grounded] "Never worked in a contact centre" | Say it first and plainly, in your words: "I've never worked in a contact centre." Then what you do bring, only as your sentence says: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then a plan for learning the contact centre, in your own words, said as a plan. This is D1's answer in short form | F2 is the plainest gap in your material and the recruiter has the JD in front of them. JD because it scores the stated scope |
| B2 | "Do you have four years or more in financial-services customer operations, and are you comfortable with Excel reporting?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I built the monthly complaints spreadsheet our regional manager uses" | Two short answers. First the six years in retail banking, the last three as branch supervisor. Second, the spreadsheet, in those words. Answer slot: if asked what tool it was built in or what it did, answer from what you actually did; if you are unsure how some part worked, say so plainly and return to the fact that you built it | F6 and F4 are the two requirements a recruiter can tick off quickly. JD because they are posting requirements |

### Reverse questions — recruiter

| # | Question | Why it lands |
|---|---|---|
| R1a | "Will the panel members' names and roles reach me before the day?" | Names are not assigned yet, and a name lets the pack sharpen the panel round |
| R1b | "Is the 20-minute escalation case handed over on the day, or is there anything I prepare in advance?" | Settles the biggest unknown in round 3 and shows you take the case seriously |
| R1c | "What would the Head of Member Services most want covered in our 45 minutes?" | A recruiter's focus areas decide round 2's weighting |
| R1d | "How does the panel score against the four values — each one separately, or an overall view?" | The recruiter said the panel scores against the values; the method decides how many stories you need |
| R1e | "What happens after the three rounds on the 29th, and when would you expect to decide?" | Practical, and keeps the recruiter's picture of you organised |

---

# Round 2 — Head of Member Services, 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Stories with "tell me about a time" | high | The recruiter calls the round mostly behavioural, which lifts this above the hiring-manager prior | "We" for context, "I" for contribution; a story you can stand behind or the honest branch |
| Skeptic | The gaps: contact centre, one branch, senior audiences | high | A manager-to-be buys capability and de-risks gaps; your message states two absences | Rehearse the single most predictable objection (D1) until it is boring |
| Case/Strategist | Live problems from the role, then your first ninety days | medium | Hiring-manager prior; the role touches reporting and digital journeys | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | The spreadsheet, line by line | low | It is the one artifact you have named | Know what it counted; say plainly if you do not know how something was counted |

### Bank C — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold. Pick a time you told someone senior something they did not want to hear: it needs a named stake, a moment you did not soften it, and an intact working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem the recruiter's "mostly behavioural" makes likely. It also touches F8 without asserting anything about senior audiences. VAL because it scores behaviour, not scope |
| C2 | "Tell me about a time you coached someone through a hard conversation or escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F5 at its own scope: you trained new tellers on the escalation script; tell that in your own words. Answer slot: the JD asks about coaching branch supervisors, so expect a probe on whether anyone beyond new tellers was coached. If you coached someone through a live escalation, say what happened and what part was yours; if not, say so plainly and stay with training the tellers | F5 is where the JD's coaching duty meets your evidence. JD content, behavioural delivery |
| C3 | "When did you put a member ahead of an internal metric?" | VAL | [generic] | A selection scaffold. Pick a moment where the member's interest and something internal pulled apart, with a named stake and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use Ashgrove's own words only if they are true for you: "we decide from the member's side of the counter" | A persona stem that maps straight onto the first published value. VAL because it scores whether past behaviour demonstrates the value |
| C4 | "How do you decide when a complaint gets escalated and when it gets resolved at the counter?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Begin with what your sentence carries: you trained new tellers on your branch's escalation script. Answer slot: the JD's coaching duty makes a probe on the deciding likely. If you made or taught that call, say how, in your own words; if there was no such decision of yours, or the script made it, say so plainly and describe how you taught the script | F5 and F1 meet in escalation decisions. JD because it scores a stated duty |

### Bank D — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have handled one branch's complaints. What makes you ready to own the process across every branch and a contact centre you have never worked in?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Opening, in the quotes' terms: "I handled the branch's formal complaints log and trained new tellers on our escalation script. I've never worked in a contact centre." Follow-up one, "how much of that was yours": the sentence says handled, so describe what you did in the log in your own words and stop. Follow-up two, "so why you": answer slot: if any stage beyond the log was yours to set, say which and how you decided; if there was no such step, or it was not yours, say so plainly and return to the log. Follow-up three, "what if contact-centre staff do not accept coaching from someone who has not done the job": concede it exactly: "That is a fair concern, and it is true I have not worked there." Then a plan for learning the contact centre, in your own plan and said as one. Hold your position through the follow-ups by returning to the sentences, never by adding to them. Do not equate branch complaint handling with contact-centre work | F1 and F2 together are the biggest gap, and the hiring manager owns the scope. It will be asked in some form, so a non-defensive answer that is already rehearsed changes the round. JD because it scores the stated scope |
| D2 | "This role handles regulated complaints. What did formal complaint handling involve at your branch?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Start with your own word: the formal complaints log, which you handled. Answer slot: you called it formal and the JD says regulated, so expect to be asked what made yours formal. If you know what rules or time limits applied to it, say so in your own words; if you do not know, or there were none you were aware of, say so plainly and stay with the log you handled | F7 is a low-confidence row and the JD's wording differs from yours. JD because it tests a stated requirement |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose one and say it plainly; both are already in your words. Contact centre: "I've never worked in a contact centre." Senior presenting: "I've never presented to anyone above regional level." For whichever you choose, give a plan in your own words, said as a plan. Do not invent a "weakness" that is a strength in disguise | The persona's own stem, and the honest answer is already in your message. JD because it scores the stated requirements |

### Bank E — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Complaint volumes at two branches have risen sharply this month and resolution times at the contact centre are slipping. How do you find out why?" | CASE | [generic] | Clarify first: what counts as a complaint, how resolution time is measured, whether the two rises share a cause, what changed. Then objective, segmentation (branch, channel, type), approach, the numbers you would want in the monthly report, risks. Think aloud; challenge one premise politely. The question needs no claim about your past, so the guidance makes none | A live problem set in the JD's monthly-reporting duty (F3's requirement). CASE because it scores structure |
| E2 | "Ashgrove wants 40% of member service on digital channels by 2028. Where could self-service help complaints, and where should a member never be sent to an app?" | CASE | [grounded] your summary of the July 2026 brief, in the grounding brief above | Use the target as given: the brief summary says 40% by 2028 and nothing more. Clarify, then split complaints by type and by the member's situation; say where self-service helps and where a person must stay. Name the app-only competitive pressure only as the brief summary does. The question presupposes nothing about your past | The differentiator question most candidates cannot touch, from a published strategy. CASE with CO content |
| E3 | "Suppose you presented the monthly complaints report to our senior leaders. What would the first slide say, and what would you ask them for?" | CASE | [grounded] "I've never presented to anyone above regional level" | Structure it as you would the report: headline first, what changed, what you need from them. Say the limit plainly if it comes up: "I've never presented to anyone above regional level." Then a plan for getting ready, in your own words. Practise it aloud once so the first time is not in the room | F8 is stated as absent, and this is the live form of the question. CASE because it asks for a structure, not a past |

### Bank G — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built. What did it show, and who used it?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Say what your sentence says: you built it, and your regional manager uses it. Answer slot: what it showed is yours to say. If you know how each figure on it was counted, say so; if you do not know how something was counted, or part of it was not yours, say so plainly and stay with the fact that you built it. Name the assumption you would defend least, in your own words, before they do | F3 and F4 rest on this one sentence. EXP because it tests what was actually yours |
| G2 | "The role reports monthly on complaint volumes and resolution times. How did you decide when a complaint counted as resolved?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: the JD names resolution times, so expect to be asked how they were counted. If there was a definition and it was yours or you used it, say what it was; if there was no such definition, or it was not yours, say so plainly and return to the spreadsheet you built | The JD's reporting line against a sentence that does not say what the spreadsheet counted |

### Reverse questions — Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R2a | "What would a strong first ninety days look like for whoever owns complaints across branches and the contact centre?" | Shows you think about ownership of the whole scope, which is D1's territory |
| R2b | "How does a complaint move between a branch and the contact centre today, and where does that handoff worry you most?" | Goes straight to the seam your material is thinnest on, from a learner's position |
| R2c | "How will the move from eight branches to five hubs change what branches handle?" | Uses the published strategy and the manager's own roadmap |
| R2d | "Which self-service journeys would you want complaints data to shape first?" | Links F9's requirement to the 40% digital target |
| R2e | "What would make you hesitate about me for this role, and is there anything I can speak to now?" | Invites the objection in the room instead of after it |

---

# Round 3 — panel of two branch managers, 60 minutes (values round, with a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Stories scored against the four published values | high | The recruiter says this is the values round and the panel scores against the four values | One real moment per value, or the honest branch |
| Case/Strategist | The 20-minute escalation case | high | The recruiter names it; it is a third of the session | Clarify, then structure, then think aloud; do not rush to the answer |
| Peer Evaluator | Where your role meets theirs: supervisors, branches, hubs | medium | Branch managers run the branches whose supervisors the role coaches; they will price what the hire costs them | Reciprocity: what you bring their branches, with seam principles rather than a guessed seam |
| Conversational | Opening and closing warmth | medium | A cross-functional, non-specialist panel; casual asides are still scored | Short, specific, interested |

No interviewer names or profiles exist, so no signal adjustments are made. Persona assignment per panellist waits on the names.

### Bank H — Values/Behavioral (one question per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Members First, Always: tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | A selection scaffold. Pick one moment with a named member situation, a choice you made, and what it cost or settled. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. "We" for context, "I" for what you did | Published value one, in Ashgrove's own words as you copied them. The mapped story is missing because your material carries no such moment, which is the upgrade-menu item that pays most |
| H2 | "Plain Words: tell me about a time something you or your team said had to be explained twice. What did you do about it?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | The value's words: "if a member needs it explained twice, we wrote it wrong." Map to F5 at its scope: you trained new tellers on the escalation script. Answer slot: the value is about wording, so expect to be asked whether you had any say over what the script or a member-facing message said. If you did, say what and how; if not, or if the script was not yours to change, say so plainly and describe how you taught it | The one value where one of your sentences gives a foothold. VAL because it scores the specific published value |
| H3 | "Neighbours, Not Numbers: Ashgrove says every branch is part of its town. Tell me about a time you saw that from inside a branch." | VAL | [generic] | A selection scaffold. Pick a moment when the branch's place in its town, not a figure, shaped what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your material says you were a branch supervisor for three years; use no more of it than that sentence carries | The panel are branch managers, and the brief summary says eight branches are being consolidated into five hubs, so this value is live for them. VAL |
| H4 | "Own the Fix: tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | The value's words: "whoever finds the problem keeps hold of it until it is solved." Answer slot: your sentence says you handled the log, not that you kept any single complaint to its end. If there is a problem you stayed with to its end, say what it was and what you did; if there is no such case, or it was passed to someone else, say so plainly, and describe how you handled the log | The role's whole job is this value; F1 is the nearest evidence. VAL |

### Bank J — Case/Strategist (the 20-minute escalation case)

The recruiter said "a 20-minute case on a complaint escalation". The format is not described, so these are practice problems, not a prediction.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has raised the same complaint at their branch and again through the contact centre. Nobody has fixed it, and it has landed on your desk. What do you do?" | CASE | [generic] | Clarify first: what the complaint is, what has been said to the member, what clock is running on it and who set it. Objective: the member's problem fixed and told in plain words. Then segmentation (what was lost between branch and contact centre), approach (one person keeps hold of it until it is solved), metrics, risks. Use the values as your frame only in Ashgrove's own words. Think aloud; challenge one premise politely. The case needs no claim about your past | The recruiter's named case. CASE because it scores structure. F1's requirement is what it tests |
| J2 | "A branch supervisor handled an escalation badly. How do you coach them?" | CASE | [generic] | Ask first what happened and what the supervisor saw; replay it with them; agree one change; follow up. Your sentence says you trained new tellers on the escalation script; do not claim supervisor coaching from it. Answer slot: if you have coached a supervisor or peer, say how; if not, say so plainly and say how you would start | F5's requirement as a live problem. CASE because it asks for a method, not a past |
| J3 | "We are moving from eight branches to five hubs over 2027. How should complaints be handled while that happens?" | CASE | [grounded] your summary of the July 2026 brief, in the grounding brief above | Clarify: what changes for members, where complaints live today, who owns a complaint when a branch closes. Structure by member, by branch, by channel. Name the risks of local knowledge being lost, in your own words. Use only the brief summary's fact: eight branches into five hubs over 2027 | The panel are branch managers, and it is their change. CASE with CO content |

### Bank K — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Our supervisors handle complaints day to day. Where is the seam between them and you, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Propose seam principles instead of guessing the seam; one principle is Ashgrove's own: "whoever finds the problem keeps hold of it until it is solved." Say, as your sentence says, that you were a branch supervisor for three years. Disagreement: say what you would do first, in your own words. Offer what you bring them, not only what you need | The panel are the branch managers; the JD's coaching duty puts you in their supervisors' working lives. JD because it scores the stated duty |
| K2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold. Pick a time when more than one team shared the work, and what you said about who did what. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer-style probe about partnership; VAL because it scores collaboration behaviour |

### Bank L — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Tell us about your branch as you would describe it to someone who has never been there." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Describe it in your own words, briefly. Your material carries only that you were its supervisor for three years; add only what is true and yours | A warm opener that is still scored, and a chance to show Neighbours, Not Numbers without forcing it |
| L2 | "When have you worked with a digital or technology team on something members used?" | JD | [generic] | A selection scaffold. Pick a moment, with what members used, who you worked with, and your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work with them | The JD's digital line (F9) has no evidence in your material, so it needs a prepared honest branch. JD because it scores the stated duty |

### Values / principles cheat sheet

Published values as you copied them on 20 November 2026 from ashgrovecu.org/about/values.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row carries a story. Selection scaffold at H1, ending in its honest branch |
| Plain Words | If a member needs it explained twice, the wording was wrong | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script". Use at that scope only; the slot is at H2 |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor". The sentence carries the role, not a story; selection scaffold at H3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script". The sentence carries handling a log, not a case seen through; slot at H4 |

### Reverse questions — panel

| # | Question | Why it lands |
|---|---|---|
| R3a | "What would you most want a Member Experience Lead to take off your supervisors' plates?" | Puts your role in their daily working life, which is what a peer panel prices |
| R3b | "When a member complains at your branch, how does it reach you now?" | A listening question about the seam, from someone who owns the process end to end |
| R3c | "What could a new person in this role do in their first month that would genuinely help your branch?" | Reciprocity, which a peer evaluator weights |
| R3d | "How are you thinking about how the hub move will feel in your towns?" | Neighbours, Not Numbers, tied to the published strategy |
| R3e | "Which of the four values is hardest to live up to on a busy day?" | Shows you took the values seriously enough to ask about their cost |

---

## Prohibited claims

Not coached anywhere in this pack. Built from the fit snapshot; no dossier supplied one.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's log, not the process. D1's slot stays inside the log |
| Contact-centre experience or familiarity | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Presented to senior leaders or executives | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |
| Coached or managed supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: you trained new tellers on the escalation script. The limit is the pack's observation; C2's slot stays inside the training |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope; the pack's observation is that your word is formal. D2's slot stays inside the log |
| Reported on volumes and resolution times | Inflated form of F3 | F3's quote at its own scope; the pack's observation is that the sentence does not say what the spreadsheet counted |
| Advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses" |
| Managed or ran the branch | Inflated form of F6 | F6's quote at its own scope: the last three years as a branch supervisor |

## Sources

Provided documents: the JD text (your message); the values page text you copied on 20 November 2026 from ashgrovecu.org/about/values (your message); the recruiter's email on process (your message); your summary of the July 2026 strategy brief (your message); your background (your message). I have not seen the brief itself or the live values page. No dossier was present.

Queries sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Your pasted values text fixes the values cheat sheet and the VAL bank, and the names come from your copy |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email fixes the three rounds, who runs each, their lengths and the case; persona weights follow it |
| 3. Ashgrove strategy / recent news | skipped | Your four-point summary of the July 2026 brief fixes the CO and CASE content (E2, J3, A2) |
| 4. Interviewer public footprint | n/a | No names exist yet; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → your evidence cells quote it line by line, and F1, F3, F4, F5 and F6 can move up a band where it is specific
- One real moment for each of the four values: what happened, what you did, how it ended → H1 to H4, C1 and C3 move from selection scaffolds to mapped stories
- What your monthly complaints spreadsheet counted, and whether any rules or time limits applied to the formal log → F3, F4, F7, D2, G1, G2 move from answer slots to grounded answers
- Any work with a digital or technology team, or coaching of a supervisor or peer → F9 and F5 (questions L2, C2 and J2) become mapped stories
- The strategy brief itself → E2, J3 and A2 sharpen beyond the four-point summary
- The panel members' names and roles, once assigned → persona assignment per panellist and a reverse question tied to each one's path
- The recruiter's answer on whether the case is handed over in advance → Bank J becomes a preparation plan instead of practice problems
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → recent Ashgrove context for E2 and J3; say yes and I will run it
- A `tuesday-dossier.md` from an earlier fit check, if you have one → the highest-ROI objection and the prohibited list arrive pre-checked
