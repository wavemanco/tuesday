# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

| Field | Detail |
|---|---|
| Role | Senior GTM Strategy Lead, Emerging Products |
| Company | Northwind Data (B2B data-infrastructure SaaS, ~3,000 employees) |
| Candidate | Priya |
| Interviewer | Dan Kovac, Director of Sales Strategy; your peer, both reporting to the same VP |
| Format | One 60-minute conversation with Dan |
| Built on | A peer conversation, as you described it. Web research was refused in this run, so everything rests on your message (see Sources) |

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows published values, not generic virtue |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and attribution is precise |
| JD | Role or JD-driven: the stated responsibilities and qualifications, including the gaps |
| CO | Company and strategy knowledge: whether you can think at the company's altitude |
| CASE | Hypothetical or live problem from the role: structure and reasoning, delivered live |

Where guidance says Answer slot, it is an instruction for the interview, not a question for you now: answer it from your own experience, or say plainly the practice was not yours or did not exist.

Highest-ROI prep in the pack: question C1 (the sales-ops and quota-setting gap). It will be asked in some form, and a rehearsed, non-defensive answer changes the conversation.

## Fit snapshot

Requirements are quoted from the JD highlights you gave me; evidence is quoted from your message. Nothing here comes from a full JD or a CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [inferred] | transferability | The quote is product strategy and ops, not GTM ownership, and the words stay at that scope: nine years in product strategy and ops at a large consumer-tech company. Answer slot: the JD's two-product-lines line makes a probe on go-to-market work likely. If any of your product strategy work touched how a product reached customers, say what and which part was yours, in your own words; if none did, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [inferred] | discovery | The quote shows a proposal and a credited result; it does not show whether the proposal came from looking for gaps across a customer lifecycle. Answer slot: if it did, say what the gap was and how you found it, in your own words; if it did not, or the finding was not yours, say so plainly and stay with "proposed" and "credited with". The figure also raises its own slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap in the quote's own terms, but a one-line claim with nothing inspected behind it, so expect a probe on it. Lead with the quote: skilled in SQL and Tableau. Answer slot: the JD says independent analysis, so expect a request for one example. Name one analysis you ran yourself and what you did in each tool; if some of it was done by others or in other tools, say so plainly and stay with what you did |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [inferred] | transferability | The quote is a revenue model used in negotiations, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Your material shows the model, not the design of a partner motion. Answer slot: if you designed any part of how the carrier relationship worked beyond the model, say what and which part was yours, in your own words; if the model was the extent of your part, or there was no such design, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | No gap, but a CV-style line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you set annual volume targets, with cross-org consensus. The quote says target-setting and consensus; it says nothing about resistance or how consensus was reached, so those are answer slots only where a question raises them |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — your message | medium | [inferred] | discovery | The quote shows daily use of AI tools; it does not show what for, which tools, or any work on an AI product. Answer slot: the JD flags AI as a plus, so expect a specific. If you can name a task and the tool you use for it, say so in your own words; if your use is general rather than specific, say so plainly and stay with "daily" |
| F7 | sales-ops and quota-setting familiarity — role-family expectation for work beside a sales-strategy team, unquoted | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Your material carries target-setting (F5), which is adjacent and not the same kind of work; do not call it quota-setting |

## Reading the interviewer

Public professional footprint only; all rows below come from the profile details you supplied, since my searches were refused.

| Item | Reading | Provenance |
|---|---|---|
| Role and relationship | Director of Sales Strategy; your peer; same VP | [grounded] your message |
| Self-described style | "relentlessly data-driven" | [grounded] your message, his profile |
| Career pattern | Pricing and monetization roles, with one early-stage-startup chapter | [grounded] your message |
| Implication: numbers | Every figure you give will likely be taken down to its assumptions, so the defend-the-number work (A1, E2) matters most | [inferred] from the self-description and the persona model |
| Implication: case angle | Case questions will likely lean toward pricing, packaging and unit economics, his native language (D1, D3) | [inferred] from the career pattern |
| Implication: your gap is near his turf | A Director of Sales Strategy plausibly cares about quota and sales-ops mechanics, which makes F7 the likeliest objection (C1). This is a derivation from his title, not a fact about what his team owns | [inferred] from his title and F7 |
| Implication: startup chapter | One early-stage chapter is a weak signal; it is not treated as a founder history and drives no persona weight. Your material carries no builder story, so none is offered | [inferred] |
| Mirror opportunity | His monetization spine and your quote "built a partner-level revenue model used in carrier negotiations" (F4) share revenue-model vocabulary. Use his words for the topic, at the quote's scope; do not call your work pricing | [inferred] |

## Persona weights

| Pass | Input | Effect | Provenance |
|---|---|---|---|
| 1. Relationship prior | Peer | Peer Evaluator and Data-Driven Prober dominant | [grounded] persona model |
| 2. Interviewer signals | "relentlessly data-driven"; pricing and monetization spine; F7 stated | Prober up; case angle toward pricing; Skeptic raised to 4 questions because of F7 | [inferred] |
| 3. The loop | One 60-minute conversation with Dan, from your message; no values round documented anywhere in the material | Values/Behavioral stays low; no values cheat sheet; weights rest on your description of the session, not a documented process | [grounded] your message |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Data-Driven Prober (5 questions) | Takes each number down to inputs and assumptions; follow-ups go two levels deep | High: peer prior plus his own self-description | Know what you can and cannot say about how each number was counted, and say plainly when you do not know; name the weakest assumption before he does |
| B. Peer Evaluator (4) | Seam-splitting, "what would you need from me", credit and disagreement | High: peer prior; he prices what you cost and add to his work | Reciprocity framing; propose seam principles, not a pretended map of the seam |
| C. Skeptic (4) | Quiet, persistent probing of the sales-ops gap and the move into B2B | Medium-high: you stated the gap (F7) and it sits near his function | Rehearse C1 until it is boring; bridges only from what you said; a concrete ramp plan; candor over bluffing |
| D. Case/Strategist (3) | Live problems from this role: bundling, whitespace, Compass pricing | Medium: a peer is not the usual case-giver, but the pricing spine pulls a pricing case in | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| E. Pressure (2) | Time-boxes you, asks how much was actually you | Low-medium: unusual for a peer chat, but F2 and F7 invite it | Pause, restate, hold the position through two follow-ups, concede specifically |
| F. Conversational (2) | Friendly opener and AI chat; still scored | Low-medium: openers are common even in analytic conversations | Pre-script a 90-second arc; treat the AI question as scored |
| G. Values/Behavioral (2) | Scenario probes | Low: no loop source documents a values round; kept as insurance | Selection scaffold, with the honest branch when no story comes to mind |

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The store-surface change you proposed, credited with a ~$400M ARR uplift: how was that figure counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the sentence's own scope: you proposed the change, and it was credited with the uplift. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before he asks; which part was yours. For each, if you do not know, say so plainly. Never supply a method or baseline you cannot repeat under a second question | F2 holds the only headline figure in your material, so a prober goes there first. EXP because it tests counting and attribution, not the role |
| A2 | "Walk me through the revenue model you built for the carrier negotiations. Where did it get used?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: you built a partner-level revenue model, and it was used in carrier negotiations; those are the beats, told in your own words. Answer slot: the JD says independent analysis, so expect him to ask whether the data work was yours end to end. If it was, say what you did and in which tools; if some was done by others or in other tools, or there was no such split, say so plainly and stay with what you built | F4 is the second-strongest quote and the one nearest his monetization world. EXP because it tests what was actually yours |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, end to end." | JD | [grounded] "skilled in SQL/Tableau" | Start from your own words: you are skilled in SQL and Tableau. Then choose an instance: it needs a question you owned, the work you did in the tools, and a decision it informed. If no end-to-end analysis comes to mind, say so plainly, then give the nearest thing you have actually done, or how you would approach one | F3 is the only requirement that names tools, and "independent" will be tested. JD because it scores a stated requirement; the open prompt means no practice is assumed |
| A4 | "A dashboard shows expansion revenue up 20% quarter on quarter. What do you do before you believe it?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first what counts as expansion and what period and cohort the number covers; state a hypothesis early; check what changed upstream of the number; say what result would make you stop trusting it. Name your first query in words, not code | A data-driven peer tests data skepticism live, not only through the CV. CASE because it is a live problem; generic because it is a pattern, not a fact about Northwind |
| A5 | "Where in your own work have you found whitespace, in how customers started, adopted, expanded or renewed?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: the JD's whitespace line makes this probe likely. If the change you proposed came from spotting a gap in how customers entered, adopted, grew or stayed, say what the gap was in your own words; if it did not, or you cannot say how it was found, say so plainly and stay with "I proposed a store-surface change credited with a ~$400M ARR uplift" | F2 is a discovery row: the quote touches the requirement without showing it. JD because it scores the stated whitespace requirement |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | The question needs no claim about your past, so the guidance makes none. Offer seam principles instead of a map you do not have: who owns the question, who owns the data, who owns the decision. On disagreement, name what evidence would settle it and say you would take an unresolved one to your shared VP with both views stated. Ask where his team's remit ends rather than guessing | The shared VP makes the seam his first practical concern. JD because it scores the role's boundaries; generic because it is a pattern |
| B2 | "How do you handle credit when work spans teams?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: you set annual volume targets, with cross-org consensus; tell it in your own words. Answer slot: if there was disagreement on the way to that consensus, say what it was and what part was yours; if there was none, or it was not yours, say so plainly and stay with the consensus | The JD's cross-functional line; F5 is its evidence. JD because it scores influence; peers press on credit-sharing |
| B3 | "What would you need from my team in your first 90 days, and what could my team rely on from you?" | JD | [generic] | The question needs no claim about your past. Give two or three concrete asks, such as access to the data behind the sales numbers and a walk-through of how targets and coverage are set today, and two concrete gives, framed as what you will deliver for the product lines. Make the asks double as your ramp plan for F7. Do not promise outputs you have not scoped | The reciprocity question: it shows you are reducing his load. JD because it scores partnership fit |
| B4 | "Enterprise expansion, Compass and profitability all want go-to-market capacity. Where does a new product line sit in that queue, and who decides?" | CO | [grounded] your research note: enterprise expansion, the Compass AI copilot launch, reaching profitability | Per your research note, not re-checked by me. Do not claim knowledge of Northwind's internal sequencing. Offer a principle, for example that a new line earns capacity by what it contributes to those priorities, and ask him how those calls are made today | Shows you read the three priorities and can sit in the trade-off. CO because it tests company-altitude thinking |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | The highest-ROI rehearsal in the pack. Open with the plain acknowledgment, before any context: "I haven't had classic sales-ops or quota-setting experience." Then what your material carries, at its scope: "set annual volume targets with cross-org consensus", called target-setting and never quota-setting. Then a ramp plan said as a plan, not a past: what you would learn first, and from whom among the people who own those mechanics; the specifics are yours to state. Follow-up one will press that target-setting is close to quota-setting: hold by repeating the scope, that it is the nearest thing you have done and that you have not had classic quota-setting experience. Follow-up two will ask why his side should trust your GTM calls: hold by offering to work a live problem from this role with him, not by adding credentials. Follow-up three will ask what you would want covered for you: name two asks from your plan. Concede exactly this and stop: "On quota-setting I'd be learning from the people who do it." Never claim sales-ops fluency | F7 is the likeliest objection: you stated it, and it sits near his function. JD because it scores a stated expectation of the role; deepest rehearsal by design |
| C2 | "Tell me about a time you designed how a partner would take something to market." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer slot: partner-motion design is required by the JD. Your quote is a revenue model used in negotiations: say it in those words. If you designed any part of how the carrier relationship worked beyond the model, say what and which part was yours; if you did not, or there was no such design, say so plainly and stay with the model. If no instance comes to mind, say so, then say how you would approach designing one | F4 is a transferability row and the JD marks the requirement as required, so it needs a JD-tagged question. Open prompt: it supplies no event |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" | Choose from your own honest assessment; the pack's observation is that your material is thinnest on F7 and on F4's step from model to motion. Say your choice before he does, in a sentence, then the plan: the first thing you would do to close it. If you pick F7, use the C1 words. If you pick partner-motion design, stay with the model as your quote has it | Standard skeptic stem. JD because it asks you to rank the role's requirements against yourself |
| C4 | "You've spent nine years in consumer tech. What do you expect to be most different about going to market at a B2B data-infrastructure company?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | State expectations as expectations, not experience: one or two differences you actually believe, tied to land, adopt, expand and renew. Say what you would check in your first weeks, and ask him where he thinks you are wrong. Do not describe B2B work your material does not show | F1 is a transferability row and the move from consumer to enterprise is the obvious doubt. JD because it scores readiness for the role's market |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A much larger platform vendor starts bundling a similar capability into its suite at no extra charge, in accounts we're trying to expand. Where do you look first, and how does it change the product line's go-to-market?" | CASE | [grounded] your research note: bundling by a much larger platform vendor is the main competitive threat | The question presupposes nothing about your past. Clarify first: which accounts and segments overlap, how the bundle compares on function and total cost, which of land, adopt, expand and renew is exposed. State a hypothesis early, then packaging and value-metric options, then what you would measure. Challenge one premise: whether the threat is uniform or concentrated in some segments | The research note names bundling as the main threat, and his pricing spine makes packaging his native ground. CASE with CO content |
| D2 | "You have two new product lines and an installed base. How would you find the whitespace across land, adopt, expand and renew, and what would you do first?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" — JD highlights | The question presupposes nothing about your past. Clarify the objective and what data exists; segment the base; pick the stage where the line is most likely to have headroom and say why; name the first cut you would run. Say the framework aloud before using it | Direct from the JD's whitespace line. CASE because it is a live problem; it is also where F3 and F2 get tested in practice |
| D3 | "Suppose Compass, the AI copilot, has to launch into the installed base without hurting profitability. How would you think about pricing and packaging it: per seat, by usage, or inside the platform?" | CASE | [grounded] your research note, and "built a partner-level revenue model used in carrier negotiations" | Per your research note, not re-checked by me. State a hypothesis and the trade-off: margin, adoption, and defence against bundling. Name what data would decide it and how it connects to enterprise expansion. If you draw on your own work, use it in its own words, "I built a partner-level revenue model used in carrier negotiations", and do not call it pricing work | Pricing is his native language and Compass is a stated priority. CASE because it is a live problem; F4 is the only adjacent quote |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" | Pause and restate. Concede in one clause that you have not had classic quota-setting experience. Then two quoted facts in your own words, at their scope: you built a partner-level revenue model used in carrier negotiations, and you set annual volume targets with cross-org consensus. Close on what the JD asks: GTM strategy for two new product lines. Hold through two follow-ups by returning to those facts, not by adding to them | F7 and the time box together are the standard pressure move. JD because it scores fit against the stated role |
| E2 | "That ~$400M result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede on the sentence's own words: you proposed the change; the uplift was credited to it. Answer slot: what happened between the proposal and the uplift, and who did what, in your own words; if others built or launched it, or the credit was shared, say so plainly. Concede specifically what you do not know about how credit was assigned, and do not fold on the proposal itself | F2's figure is the magnet claim, and attribution probes exist to catch inflation. EXP because it tests precise attribution |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey: where you've been and why this role." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Story-mapped on F1: two years in strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company; those are the beats, in your own words. Add one sentence on why this role, from your own reasons, ending on the JD's two new product lines. Answer slot: if a probe asks what you did in either chapter beyond those words, answer in your own words; if you cannot add, say so and stay with the quote. Keep it under 90 seconds | The biography question opens most conversations and is scored. EXP because it tests the CV's spine |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start from your own words: you use AI tools daily. Answer slot: if you can name a task and the tool you use for it, say so in your own words; if your use is general, say so plainly and stay with "daily". If you have a view on Compass from the outside, give it as a view, not as insight | The JD flags AI as a plus, and casual questions on plus-skills are scored. JD because it scores a stated plus; CO flavor from the Compass priority |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, and the relationship afterwards; choose one where the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values round is documented, so this is insurance at low weight. VAL because it scores behavior; generic because no company value has been read |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: name the metric, who the customer was, and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Profitability is a stated priority, so a trade-off story is plausible. VAL, generic for the same reason as G1 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | D1, D2, D3, B4, C4, E1 |
| identify whitespace across land/adopt/expand/renew | A5, D2 |
| run independent analysis in SQL and Tableau | A2, A3, A4 |
| partner-motion design experience required | C2, C3 |
| strong cross-functional influence | B1, B2, B3 |
| AI experience a plus | F2, D3 |
| sales-ops and quota-setting familiarity (role-family, F7) | C1, C3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization before sales strategy. What from that work do you lean on most when you set go-to-market direction, and what did you have to change?" | Ties to his own path, which turns an interrogation into a peer conversation and shows you researched him |
| R2 | "What could a new person on my side do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it reduces his load before you are asked |
| R3 | "Are the two product lines this role owns connected to Compass, or on separate tracks?" | Settles scope and shows you read the three priorities |
| R4 | "When bundling by a larger vendor shows up in a deal, what does your team see first, and where does that data live?" | Speaks to the stated competitive threat in data terms, which matches his self-description |
| R5 | "How do you measure expansion and renewal today, and which of those numbers do you trust least?" | A data-driven interviewer weights this slot as a preparation signal |
| R6 | "How does our VP define success for this role in year one, and where would you and I most likely disagree?" | Brings the shared reporting line and the seam into the open, which is what a peer is pricing |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or sales-ops experience | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Set sales quotas | Inflated form of F5 | F5's quote at its own scope: set annual volume targets with cross-org consensus. The limit is the pack's observation: the material says target-setting, not quota-setting |
| Designed partner motions or ran a partner program | Inflated form of F4 | F4's quote at its own scope: built a partner-level revenue model used in carrier negotiations. C2's slot stays inside the model |
| Drove or generated the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed the change, credited with the uplift. A1 and E2 slots stay inside that sentence |
| Owned or led GTM strategy for product lines | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. D-bank answers are live problems and claim nothing |
| Built or led an AI product | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily |

## Sources

Provided documents: your message (JD highlights, the candidate summary, Dan's profile details, your research note). No full JD, CV or dossier was provided. Your research note's priorities and competitive threat were not re-checked by me.

Searches sent, all refused (permission not granted):

| Query | Outcome |
|---|---|
| Northwind Data values | refused |
| Northwind Data interview process strategy GTM | refused |
| Dan Kovac Northwind Data Director Sales Strategy | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have moved the VAL bank and a values cheat sheet if a values round is documented; G1 and G2 stay generic |
| 2. `Northwind Data interview process GTM` | unavailable | Would have moved persona weights if the loop names other rounds; weights rest on your description of one conversation |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the priorities and the bundling threat the CO and CASE rows use; it was not re-checked |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have moved the interviewer read (published talks or writing) and R1; it rests on your profile details |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you gave fix the fit snapshot rows and JD-tagged questions |

## Upgrade menu

- Allowing web search, or a pasted values page and interview-process note → G1 and G2 become mapped to published values if a values round exists, persona weights rest on a documented loop, and the strategy rows can be re-checked
- Deeper research (L2) → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief for the CO and CASE rows, and Dan's talks and writing for the interviewer read; it needs search access allowed first
- The full JD text → mid-list requirements beyond the six highlights become rows and questions; none exist now
- Your CV or one-page background → F1 to F6 evidence cells move from a one-line summary to quoted lines, and answers become story-mapped instead of slot-based; a model or analysis you can show, such as the revenue model or a Tableau view, would raise F3 and F4 toward high confidence
- Your answers to the slots in A1, A2, A3, A5, B2, C2, E2 and F2, told outside a drill → each becomes quoted evidence and upgrades its rows
- Recruiter or HR guidance on focus areas or a pre-announced deliverable → coverage beyond the round-type priors, and a build section for any deliverable
- Your prep time → a prioritized prep triage section
- A tuesday-dossier.md from an earlier fit analysis → verified evidence and ready-made prohibited claims; never required
