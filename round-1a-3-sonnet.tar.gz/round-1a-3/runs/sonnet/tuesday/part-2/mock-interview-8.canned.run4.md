The pack is written and saved. I'm making one small fix to a rationale cell that edged into your history, then I'll give you the summary.
Dara, your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-8-canned-b5f87419/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as three round-by-round mini-packs for 29 November, from the recruiter's email. Each round has its own interviewer styles, 9, 9 and 10 questions, and five questions for you to ask. Interviewer names aren't assigned yet, so there is no interviewer read. The shared parts are a fit snapshot of the JD against your own words, a values cheat sheet for the panel round, a prohibited-claims list and a requirement-coverage table.

- **Your biggest exposure:** "Never worked in a contact centre" will come up in some form in every round. D1 is the question to rehearse most. You say the limit plainly, state what you did handle (the branch's formal complaints log), then give a plan for learning the contact-centre side.
- **Second gap:** you've never presented above regional level, and the JD asks for confidence presenting to senior leaders. D2 and D3 cover it the same way.
- **Gaps your message doesn't settle:** I left answer slots for digital-team work, what governed the complaints you logged, what your spreadsheet counted and which tool it was built in, and whether any of your coaching was of supervisors. Answer those in your own words, or say plainly that it wasn't yours.
- **Panel round:** there is one question per Ashgrove value, plus a practice case on a complaint escalation. I wrote that case myself, so the real one will differ. Rehearse its structure, not its details.
- **Research:** I ran no web searches. Your pasted values, the recruiter's email and the strategy points you relayed already covered every target. I haven't seen the strategy brief itself, so that section holds only the four points you gave me.

I can play the Skeptic on D1 as a live drill, in character, with feedback afterwards. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to a Word document if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Interview day: 29 November 2026, three back-to-back rounds (loop mode, built from the recruiter's email). Interviewer names are not assigned yet, so there is no interviewer read; each round's weights rest on the relationship and round type the recruiter gave. Pack written 20 November 2026.

| Round | Who | Length | Shape, from the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services, your would-be manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. An "Answer slot" is an instruction for the interview, not a question for you: say what is true in your own words, and if the practice was not yours, or never existed, say so plainly. That is an honest answer, not a failure.

Question IDs are lettered by persona and round (the letter F is skipped because F1 to F9 are fit-snapshot rows). Highest-ROI prep in the whole pack: **D1**, the contact-centre question. It will arrive in some form in every round (B1 lightly in round 1, D1 and D3 in round 2, H2 in round 3).

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether your own account of your work holds up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem set in the role |

## The fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, with nothing inspected behind it, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the rest of a complaint's path likely. If any part of that path beyond the log was yours to handle, say which part and what you did, in your own words; if it was only the log, or the rest was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated and wording cannot close. Words: "I have never worked in a contact centre." Then a plan, said as a plan and never as a past: what you would learn first and from whom. Never a claim to contact-centre work |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The quote says the sheet was monthly and that your regional manager uses it; the material does not show what it counted. Answer slot: expect a probe on what the sheet counted. Say what it counted and how, in your own words; if you do not know how something was counted, or part of it was not yours, say so plainly |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote is new tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's line is about supervisors. If any coaching you gave was to supervisors or other experienced staff, say who and what, in your own words; if it was only new tellers, say so plainly and stay with them and the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about this either way. Answer slot: if you have worked with a digital or app team on anything members use themselves, say what it was and what your part was, in your own words; if not, or it was not yours, say so plainly and say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a line from you with nothing inspected behind it, so expect a probe. Lead with it in your own terms and let the interviewer judge how it maps to the JD's phrase; do not relabel it in the JD's vocabulary |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | The quote says formal complaints; the material does not show what governed them. Answer slot: expect a probe on what governed the complaints in the log. Say what governed them and what part of the handling was yours, in your own words; if you do not know, or none of it was yours, say so plainly and stay with the formal complaints log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." The quote does not say what you presented at regional level, so nothing is added to it. Then a plan, said as a plan: how you would prepare for a first senior presentation |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The quote says spreadsheet, not which tool. Answer slot: expect a probe on the tool. Say what it was built in, in your own words; if it was not Excel, say which tool and say so plainly |

The JD states no eligibility, licence, location, schedule or pay term, so the snapshot has no gate row.

## Grounding brief: Ashgrove's 2026 strategy

You relayed these four points from the July 2026 strategy brief the recruiter sent; I have not seen the brief itself. Use them as vocabulary, not as a recital: the brief is Ashgrove's own publication, so any prepared candidate can quote it.

| Point from the brief | Why it matters for this role | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | Bears on complaints reaching members through self-service, and on the JD's digital-teams line (F5); used in H3 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Bears on where a complaint lives when its branch changes; used in J1 | [grounded] |
| Launch a small-business lending product in Q1 2027 | A new product line is new complaint territory; used as an optional CO point in A7 | [grounded] |
| Main competitive pressure is app-only banks | The brief's own frame for why service quality matters; used in A7 and H3 | [grounded] |

---

# Round 1: the recruiter (30 minutes)

Loop source: the recruiter's email.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, unstructured; logistics, motivation, "walk me through the journey" | High. The recruiter screen prior is Conversational plus a light Skeptic, and a 30-minute screen leaves little room for anything else | Prepare a 90-second arc for A1 from your own quoted lines; treat every casual question as scored; never answer "I think you've covered everything" at the reverse-question slot |
| Skeptic, light (B) | Knockout-style checks on the JD's hard-looking lines, in a friendly register | Medium-low. The two likeliest checks are the years requirement (F6) and the contact centre (F2); the recruiter is checking fit for the loop, not deriving the gap | Say the stated limit once, plainly, then the plan; do not over-explain |

## Question banks

### A: Conversational (7 questions; the logistics rows are required for a recruiter screen)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in your own words, using only the beats these three lines state, in order: the six years, the three as a branch supervisor, the formal complaints log you handled, the monthly spreadsheet you built that your regional manager uses. End on what draws you here (A2). Add no figures, team sizes or outcomes the lines do not carry | F6 is the years check a recruiter makes first, and F1 and F3 are the two lines closest to the JD's headline duties. EXP because it tests what you say of your own path |
| A2 | "What draws you to this role?" | JD | [grounded] | Makes no claim about your past. Pick what draws you from the JD's own words, such as "Own the member complaints process end to end", or from one of Ashgrove's four published values, and say it in your own words. If part of the move is still uncertain, say what you want to learn | Motivation consistency is the recruiter screen's main risk; JD because the role's wording is the raising source |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A required logistics row for a recruiter screen; the only safe answer is your own |
| A4 | "What salary are you looking for?" | JD | [generic] | Logistics slot: either give your own number, or ask for the role's band first. If asked about your current pay, you may decline to say and redirect to the role's band | Same reasoning as A3; the pack supplies no figure |
| A5 | "Is there anything about location or working pattern we should know?" | JD | [generic] | Logistics slot: state your own constraints on where and how often you can work, in your own words, or say you have none | Same reasoning as A3 |
| A6 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, and keep it about what you want from this role rather than what you are leaving | Same reasoning as A3; EXP because it tests consistency of your own story |
| A7 | "What do you know about Ashgrove?" | CO | [grounded] | Differentiate from the brief rather than reciting it. Bring one point from the brief to show you read it, then one view of your own on what it means for complaints, labelled as your view. The four points are in the grounding brief above | The brief is equally available to every candidate, so reciting it scores as homework and a reasoned view scores as judgment; CO because it tests altitude |

### B: Skeptic, light (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as the branches. How do you feel about that, given your background?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Hold, then concede, briefly: "I have never worked in a contact centre." Then what your material carries, at its own scope: "I handled the branch's formal complaints log." Then your plan for learning the contact-centre side, in your own words, as a plan and not a past. The full rehearsal is D1 | F2 is the stated gap and the likeliest objection; this is its light-touch form for a screen. JD because it scores a stated responsibility |
| B2 | "The role asks for 4+ years in financial-services customer operations. How does your background map to that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say your own line at its own scope: "6 years in retail banking, the last 3 as a branch supervisor." Let them judge how it maps to the phrase "customer operations"; do not relabel your work in the JD's vocabulary | F6 is a years check the recruiter can tick or not; JD because it scores a listed requirement |

## Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| RV1.1 | "What would you want complaints reporting to look like by the end of the first quarter?" | Gets the role's success measure early and ties to the JD's monthly reporting line, giving you the language for round 2 |
| RV1.2 | "How does a complaint move today between a branch and the contact centre, and where does it get held?" | Tied to the JD's end-to-end line; asks for the shape of the process rather than pretending to know it |
| RV1.3 | "Who would I work with day to day on the digital side?" | Tied to the JD's digital-teams line, and signals you are asking about the working relationship before you have shown one |
| RV1.4 | "What does the Head of Member Services most want from the person in this role?" | Prepares round 2 using the recruiter's view of the person who would be your manager |
| RV1.5 | "What happens after round three, and when would you expect to decide?" | A process question that costs the recruiter nothing and sets your expectations for the day |

---

# Round 2: the Head of Member Services (45 minutes, mostly behavioural)

Loop source: the recruiter's email. This person would be your manager.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (C) | "Tell me about a time" scenarios; STAR-shaped stories | High. The recruiter described the round as mostly behavioural | Where one of your quoted lines carries a story, map it; where none does, choose from the scaffold and end on the honest branch; "we" for context, "I" for your part |
| Skeptic (D) | Quiet, persistent probing of the gaps; the hiring-manager derisking | High. A would-be manager is buying capability and derisking gaps, and F2 and F8 are two gaps you have stated yourself | Rehearse the single most predictable objection (D1) until it is boring; plain acknowledgment, then a plan; calibrated candour over bluffing |
| Data-Driven Prober (E) | "Walk me through" on the lines you wrote | Medium. Anything you state about the spreadsheet or the complaints log invites a follow-up two levels deeper | Know what you can and cannot say about what each line covered, and say plainly when you do not know |
| Case / Strategist | Live problems from the role | Low in this round, and banked in round 3 where the recruiter put the case. If it comes up here, use the structure in H1 | Clarify, then structure, then answer |

## Question banks

### C: Values / Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint you handled that was hard to resolve." | EXP | [grounded] "I handled the branch's formal complaints log" | The quote carries one beat: you handled the branch's formal complaints log. Choose the complaint from that log; it needs a named situation, what made it hard, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 is the evidence closest to the role's central duty. EXP because it tests what was actually yours |
| C2 | "Tell me about a time you coached someone through an escalation." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers on the escalation script; tell that in your own words. Answer slot: the JD's coaching line is about supervisors. If any coaching you gave was to supervisors or other experienced staff, say who and what; if it was only new tellers, say so plainly and stay with them and the script | F4 is the JD's coaching requirement and sits one step short of it. EXP, with a JD edge, because the interviewer will check the step |
| C3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Makes no claim about your past. Choose a time the hard truth actually landed, with a named stake, what you said, and how the relationship ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural probe and a likely follow-on to the F8 gap. VAL because it tests whether the truth landed, not just whether you spoke |
| C4 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Makes no claim about your past. Choose a decision where the member's interest and the branch's number pulled apart; it needs the situation, what you chose and why, and how it ended. If none comes to mind, say so plainly, then say what you would do | Echoes the first published value, "Members First, Always", and is the same theme the round 3 panel will score |

### D: Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **Highest-ROI prep in the pack.** Hold then concede, in three levels. Level one, before they press: "I have never worked in a contact centre." Then what your material carries, at its own scope: "I handled the branch's formal complaints log." Expect a follow-up on what you would do in week one; answer as a plan, in your own words: what you would learn first and from whom. Expect a follow-up on credibility with colleagues who know the work better; say what you would ask them and what you would not assume. Concede the limit exactly, in your own words: you have the branch side of complaints and not the contact-centre side. Do not claim, soften or imply contact-centre experience at any level | F2 is the stated gap on a half of the role's remit, so this arrives in some form in every round. JD because it scores a stated responsibility; the deepest rehearsal is spent where the material is thinnest |
| D2 | "The role asks you to be confident presenting to senior leaders. You've never presented above regional level. How do you get there?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold then concede: "I've never presented to anyone above regional level." Then a plan, in your own words: how you would prepare for a first senior presentation and who you would ask to rehearse with. Answer slot: if you have presented at regional level, say what and to whom, in your own words; if you have not, say so plainly | F8 is a stated gap against a JD line. JD because it scores a stated qualification |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick the one you would say first, from the two limits you have already stated, and say it in the quote's own terms. Then the plan. Calibrated candour beats bluffing a competency the interviewer personally owns; do not volunteer a weakness you cannot back with a plan | The standard Skeptic stem, aimed at F2 and F8. JD because it tests honest self-assessment against the listed duties |

### E: Data-Driven Prober (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What did it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The beats the quote states: you built it, it was monthly, your regional manager uses it. Answer slot: the JD asks for Excel reporting and for monthly reporting, so expect a probe on the tool and on what the sheet counted. Say what it was built in and what it counted and how, in your own words; if you do not know how something was counted, or part of it was not yours, say so plainly | F3 and F9 both rest on this one line, so it is the likeliest EXP probe. EXP because it tests attribution and how the figures were counted |
| E2 | "The role asks for experience handling regulated complaints. How do the formal complaints you handled fit that?" | JD | [grounded] "I handled the branch's formal complaints log" | Say your own line at its own scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what governed those complaints. Say what governed them and what part of the handling was yours, in your own words; if you do not know, or none of it was yours, say so plainly and stay with the formal complaints log | F7 is a listed requirement and the quote says formal, not regulated. JD because it scores a stated qualification |

## Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| RV2.1 | "How are resolution times measured today, and what would you want to see differently?" | Tied to the JD's reporting line; asks for the measure rather than assuming one |
| RV2.2 | "What would you want me to understand about the contact centre's complaint handling first?" | Turns the stated gap (F2) into a learning plan the manager can shape |
| RV2.3 | "When a branch supervisor and the contact centre disagree about an escalation, how does that get decided?" | Tied to the JD's escalation-coaching line and to ownership of the process |
| RV2.4 | "How do you expect the shift toward digital service to show up in complaints, and where would this role come in?" | Ties to the brief's 40% digital target and the JD's digital-teams line |
| RV2.5 | "Which forums do senior leaders see the complaints reporting in?" | Shows you are planning for the senior-presenting line (F8) and learns the audience before you meet it |

---

# Round 3: the panel of two branch managers (60 minutes, including the 20-minute case)

Loop source: the recruiter's email. The panel is also the values round: they score against the four published values, so a values-style round is detected.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (G) | Scenario probes mapped to the four values; STAR-shaped stories | High. The recruiter said the panel scores against the four values | Map one story or one scaffold to each value (the cheat sheet below); "we" for context, "I" for your part |
| Case / Strategist (H) | The 20-minute case on a complaint escalation | High. The recruiter named the case and its length | Clarify, objective, who is involved, approach, measures, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator (J) | Seam-splitting between branches and your role; "what would you need from me" | Medium. Two branch managers are the people your coaching and your reporting would touch; the brief's branch consolidation sharpens the seam | Reciprocity: what you bring their branches, not only what you need; propose seam principles rather than pretending to know the seam |
| Conversational, Skeptic, Prober, Pressure | Not banked for this round | Low. Not signalled by the recruiter's email, and the gaps are already rehearsed in round 2 | If a Skeptic probe on F2 arrives, use D1 |

## Question banks

### G: Values / Behavioral (4 questions, one per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Members First, Always means deciding from the member's side of the counter. Tell me about a decision you made that way." | VAL | [grounded] | Makes no claim about your past. Choose a decision where the member's side and the branch's convenience pulled apart; it needs the situation, what you chose and why, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Scores the first published value. VAL because the panel is looking for a specific decision, not familiarity with the slogan |
| G2 | "Plain Words means that if a member needs it explained twice, we wrote it wrong. Tell me about a time something needed explaining twice." | VAL | [grounded] | Makes no claim about your past. Choose a time the explanation was the problem rather than the member; it needs what was unclear, what you changed, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Scores the second published value. VAL because the panel scores the story, with F4 as the nearest row if your story involves the escalation script |
| G3 | "Neighbours, Not Numbers means every branch is part of its town. Tell me about a time you put that ahead of a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Your line carries only that you spent three years as a branch supervisor; the story of the town is yours to supply from your own experience. Choose a time you weighed a number against what the branch meant locally: the situation, what you chose, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Scores the third published value, and the one most exposed by the brief's branch consolidation. VAL because the panel is branch managers |
| G4 | "Own the Fix means whoever finds the problem keeps hold of it until it is solved. Tell me about a complaint you kept hold of." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: you handled the branch's formal complaints log; tell that beat in your own words. Answer slot: expect a probe on a complaint that was hard to close. If one stayed with you until it was solved, say what you did and what was yours; if none did, or the fix was not yours, say so plainly and describe how you handled the log | Scores the fourth published value and sits closest to the role's central duty (F1). VAL because it tests ownership, not diligence |

### H: Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A practice case written by this pack, not by Ashgrove: a member has complained three times about the same fee, each time told it was resolved, and has now written to the chief executive. You have just taken over. What do you do?" | CASE | [generic] | The real case will differ, so rehearse the structure. Spend the first minutes clarifying: what the member has asked for, what has been done, what deadlines or rules apply. Then the objective, who must be involved across branch and contact centre, what you tell the member in plain words, one named owner who keeps hold of it until it is solved, what you record, and what you would check for across other complaints. Challenge one premise respectfully, such as who decided it was resolved. This guidance makes no claim about your past | The recruiter said the case is a complaint escalation; the real prompt is unknown, so this is a pattern and is labelled generic. CASE because it tests structure before answers |
| H2 | "Same complaint, but the member first rang the contact centre, and your branch has never heard of it. Who owns what?" | CASE | [grounded] "Never worked in a contact centre" | Say what you would ask each side, who holds it until it is solved, and what the member is told, as seam principles rather than claims about how the contact centre works, because you have not worked there. Say what you would ask the contact-centre team rather than what you know | A second pass at the F2 gap set as a live problem. CASE because it tests cross-channel ownership without asking about your past |
| H3 | "Ashgrove wants 40% of member service on digital channels by 2028. What should happen to complaints, and how would you know it was working?" | CASE | [grounded] | Use the brief's own frame: the 40% target, and app-only banks as the competitive pressure it names. Clarify what counts as digital service; consider the member who cannot or will not use the app; then name measures by channel. Challenge one premise respectfully. Makes no claim about your past | Grounded in the strategy brief and the JD's digital-teams line (F5). CO and CASE because it tests altitude and reasoning together |

### J: Peer Evaluator (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Eight branches are due to become five hubs over 2027. A complaint starts in a branch that is closing. Where does it live, and who keeps hold of it?" | CASE | [grounded] | Seam principles, not a claim to know the hub model: one named owner at every point, the member told in plain words, and a handover that does not depend on the branch still being open. Say what you would ask the panel about how the hubs will work. Reciprocity: what you would bring their branches in the transition | Grounded in the brief's consolidation and the panel's own role. CASE because it tests a live seam |
| J2 | "What experience do you have of working with digital teams on self-service?" | JD | [grounded] | Answer slot: if you have worked with a digital or app team on anything members use themselves, say what it was and what your part was, in your own words; if not, or it was not yours, say so plainly and say what you would ask a digital team first | F5 is the JD line with no quote behind it. JD because it scores a stated requirement |
| J3 | "You would be coaching our supervisors on escalations. How do you do that without stepping on branch managers?" | JD | [grounded] "trained new tellers on our escalation script" | Say your coaching at its own scope: "I trained new tellers on our escalation script." Then seam principles: agree with each branch manager what the supervisor is coached on, who decides when you and the manager disagree, and how a branch's own approach is respected. Answer slot as in C2, if supervisors were among those you coached | F4 is the coaching requirement, and the branch managers are the people it touches. JD because it scores a stated duty, with Peer delivery |

## Values / principles cheat sheet

Names are Ashgrove's, copied from ashgrovecu.org/about/values on 20 November 2026. Working meanings are paraphrased from the page's own text.

| Value (official name) | Working meaning | Your mapped story, or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence of yours carries a decision of this kind. Scaffold for G1: a decision where the member's side and the branch's convenience pulled apart, with the situation, the choice and the ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the writer got it wrong | No quoted sentence of yours carries this. Scaffold for G2: a time the explanation was the problem, what you changed, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | F6 carries "6 years in retail banking, the last 3 as a branch supervisor", which is the three years and not a story. Scaffold for G3: a time you weighed a number against what the branch meant locally. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 carries "I handled the branch's formal complaints log". Map it in G4, with the slot on a complaint that was hard to close; if none was, say so plainly and describe how you handled the log |

## Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| RV3.1 | "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" | Reciprocity: asks what you can bring the panel's branches, not only what you need |
| RV3.2 | "How do you expect the move from eight branches to five hubs to change how complaints are handled in your branch?" | Tied to the brief's consolidation and to the J1 seam |
| RV3.3 | "Where does a complaint most often get stuck between the branch and everywhere else today?" | Tied to the JD's end-to-end line; asks for the failure point rather than assuming it |
| RV3.4 | "What does Neighbours, Not Numbers look like in how you run your branch day to day?" | Uses a published value by name and invites the panel to describe it in their own terms |
| RV3.5 | "Which of the four values do you find hardest to hold to in a busy branch?" | Tied to the values round and gives you a way to hear how the panel will score it |

---

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, C1, D1, G4, H1, H2, J1 |
| Report monthly on complaint volumes and resolution times | E1, H3 |
| Coach branch supervisors on escalations | C2, J3 |
| Work with digital teams on self-service journeys | H3, J2 |
| 4+ years in financial-services customer operations | A1, B2 |
| Experience handling regulated complaints | E2 |
| Confident presenting to senior leaders | C3, D2 |
| Comfortable with Excel reporting | E1 |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before any bank was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's formal complaints log, not the whole process |
| Has worked in a contact centre, or owned complaints there | A negative you stated, F2 | The plain acknowledgment: "I have never worked in a contact centre." No answer slot |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. E1's slot asks only what the sheet counted and how |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script |
| Has handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: you handled the branch's formal complaints log. E2's slot asks only what governed them |
| Has presented to senior leaders | A negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." D2's slot stays at regional level |

## Sources

Provided documents: the job description; the four published values, copied from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email on the loop; the four points of the July 2026 strategy brief as you relayed them; your background as you described it in your message.

No searches or fetches were sent. Dara's inputs fixed every target below; the one source I could not read was the strategy brief itself, so the grounding brief holds only the four points you relayed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted, dated 20 November 2026, fixes the cheat sheet and G1 to G4 |
| 2. Ashgrove interview process, member-experience roles | skipped | The recruiter's email names three sessions, who runs each and which round is the values round, so persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The four points you relayed from the July 2026 brief fix the grounding brief, A7, H3 and J1; the brief is under six months old |
| 4. Interviewer public footprint | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your CV text → F1, F3, F4, F6, F7 and F9 currently quote your message; CV lines would sharpen them and may raise some confidence bands
- Your answers to the answer slots in F1, F3, F4, F5, F7 and F9 (what the spreadsheet counted and was built in, what governed the complaints, whether any coaching was of supervisors, any digital-team work) → those rows regenerate with your own words in them, and the banks that draw on them follow
- The names and roles of the Head of Member Services and the two branch managers → an interviewer read, persona weights from their public footprint, and a reverse question tied to each one's path
- The full July 2026 strategy brief → a fuller grounding brief and CO questions beyond the four points you relayed
- The recruiter's description of the 20-minute case, or whether materials arrive beforehand → H1 and H2 can be rebuilt around the real prompt; usually one email to the recruiter
- How many hours you have before 29 November → a prioritised prep schedule sized to that time
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering role-family loop reports for complaints and member-experience interviews and recent organisational context at Ashgrove → want it?
- A tuesday-dossier.md from an earlier fit check, if you have one → verified evidence and recorded gaps that would replace this pack's inferred ones
