Web search was declined, so I'm building the pack from your JD and background only. Company values, loop structure and Tobias's public footprint stay unresearched, and the pack says so.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-7-denied-7a841be0/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 19 questions, built for a hiring-manager round with Tobias. Web search was refused, so company values, the interview process, Saltmarsh's strategy and Tobias's background are not in it. The persona weights rest on the hiring-manager pattern, and the pack says so.

The question to rehearse most is B1: "I don't see in-app purchase work in your background." The rest of the pack is built around two things:
- **Your stated gaps:** "I have never worked on a game with in-app purchases" and "I have never led a team", each said plainly and followed by a plan to learn.
- **Where the JD outruns your evidence:** live events (you ran content drops), two titles (you ran one) and owning the post-event review (you presented retention numbers).

Offers:
- Say the word and I'll play the Skeptic on B1 with live follow-ups.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and has the recruiter said what the 60 minutes will cover? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship not stated; this pack assumes he is the hiring manager. Format: one 60-minute session. Candidate: Femi.

Built on one assumption: a hiring-manager round, in a loop no source established. Company values, process and strategy are not researched (every search was refused, see Sources), so those parts are labeled generic or left out.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Every question has a persona, a type, a provenance label, guidance and a rationale. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. None in this pack: no values round was detected and no values page was read |
| EXP | Whether claims about your experience survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge. None in this pack: company research was refused |
| CASE | A live problem set in the role, scored on structure and reasoning |

A question that is dual-natured carries its primary type in the Type column; the rationale says the second.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a content-drop calendar for one main title, not live events and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events line makes a probe on whether any drops were timed events likely. If any were, say what they were and what part was yours, in your own words; if they were all regular content releases, or none of it was yours, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap on the calendar itself, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms, a weekly cadence over two years, because a named cadence and duration beat an adjective |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote touches the requirement without showing which teams the calendar involved, and you have stated no absence. Answer slot: the JD names four disciplines, so a probe on which of them you worked with on a drop is likely. If you worked with any, say which and what you did, in your own words; if you worked with none, or it was not yours to coordinate, say so plainly and stay with the calendar |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a review or set what it reported, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review line makes a probe on who picked the numbers likely. If you also decided which numbers went into what you presented, say what you picked and why; if they were set by someone else, or there was no review step, say so plainly and stay with presenting them |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your material says you wrote the checklist and that QA still uses it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage line makes a probe on how the checklist is used on releases likely. If you ran it on releases, say how, in your own words; if you wrote it and others ran it, or it was not used that way, say so plainly and stay with having written it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years on the calendar; it does not show whether the other two years were on live updates. A years requirement is not a gate, so the work near it counts. Answer slot: the JD's three-year line makes a probe on how many of your years were on a live game likely. If the title was live for more of the four years, say what you worked on in those years; if only the calendar years were, say so plainly and stay with those two |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the words: you presented them, monthly, to the studio head. Nothing inspected sits behind it, so expect a probe on how the numbers were counted; the pack supplies no method or figure |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A written document another team still uses is the only written evidence your message carries: "I wrote the release checklist our QA team still uses." Say it in those terms and no further |
| F9 | Not in the JD: in-app purchases, a gap you named yourself — your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Not in the JD: leading a team, a gap you named yourself — your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated. Words: "I have never led a team." The JD's wording is coordinate, not lead, and the pack's reading stops there: your material carries no coordination evidence beyond F3's thin row. Say the gap as a plan to learn, never as a past |

## Persona table

Weights start from the relationship prior for a hiring manager (Case/Strategist and Skeptic dominant, assumed from the stated role of the interviewer). No loop source established the loop, so the generic archetype applies and its tilt is flat; the persona weights rest on the relationship pattern, not on Saltmarsh's documented process. No interviewer signal beyond his title was available, so none adjusts the weights.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 5 questions) | Live problems from the role: plan this, diagnose that | High: hiring-manager prior, and the JD describes planning and coordination work | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B, 5 questions) | Quiet, persistent probing of gaps | High: hiring-manager prior, and F9 and F10 are gaps you named yourself | Rehearse the single most predictable objection (B1) until it is boring; calibrated candor over bluffing |
| Data-Driven Prober (C, 3 questions) | Reads your lines closely; asks how numbers were counted | Medium: the JD names retention metrics and a review that reports numbers; no interviewer signal either way | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (D, 2 questions) | Friendly opener that is still scored | Medium: an opening biography question is likely in most conversations | A pre-scripted 90-second arc from your quoted sentences |
| Peer Evaluator (E, 2 questions) | Seam-splitting, collaboration, credit-sharing | Low: applies if teammates sit in the loop; the JD's four-team coordination makes it plausible | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Pressure (F, 2 questions) | Time-boxed challenge of motive and attribution | Low: more likely at a skip-level or later round | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Values/Behavioral | Not included | No values-style round detected and no published values read; a dedicated values round, if one exists, is unknown | Add via the upgrade menu once values are known |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Both titles want a headline event in the same week, and engineering can support one. How do you decide?" | CASE | [generic] | Clarify first: what each title needs from that week, what is fixed, what engineering means by support. Then the objective, how you would compare the two (player impact, readiness, risk, what slips if one waits), a decision you would make now and what you would watch to revisit it, and who you tell and when. Challenge one premise respectfully: ask whether it is really one or the other. The question needs no claim about your past, so the guidance makes none | Set in the JD's two-titles calendar line (F1's requirement). CASE because it scores structure; generic because it is a pattern for the problem, not a fact about this studio |
| A2 | "Retention on one title falls 20% the week after an update ships. Diagnose it." | CASE | [generic] | Clarify which retention measure and which players (new or returning, platform, region), what shipped and when, and whether anything else changed. State a hypothesis early, then the first cuts you would make to test it, who you would ask on each team, and what you would tell the studio before you know the cause. No claim about your past | A diagnose-it problem on the JD's retention line (F7's requirement). CASE because it scores clarify-then-structure, and Prober-style follow-ups on assumptions are likely |
| A3 | "It's the afternoon before an update ships and QA flags a blocker. What does the next hour look like?" | CASE | [generic] | Clarify how severe it is, who it hits and whether a fix is known. Then who needs to know now (design, engineering, community), the options (hold, cut the feature, ship with a known issue, hotfix after) and what each does to the calendar, who decides, and what players are told. Say the trade-off aloud. No claim about your past | Set in the JD's release-checklist-with-QA line (F5's requirement). CASE because it asks for a decision under time pressure; it is the live version of a checklist question |
| A4 | "Twenty minutes after an event goes live, the community team says players are calling a reward unfair. Design says leave it. What do you do?" | CASE | [generic] | Clarify how widespread it is, which players, and what the reward does. Separate what is known from what is loud, ask design and community to state what each would risk, propose a time-boxed check with a named decision owner, and say what players hear meanwhile. Propose a seam principle rather than assuming who owns it. No claim about your past | Set in the JD's four-team coordination line (F3's requirement). CASE because it scores how you handle a disagreement between teams without a past to lean on |
| A5 | "After an event ends, you write the review that design, art, engineering and community all read. What goes in it, and in what order?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Clarify what the event was meant to do. Then a structure: what happened against that aim, the numbers the event was meant to move and why those, what you would change next time, owners and dates; one page, answer first, because four disciplines read it for different reasons. For your written evidence, stay with the quote: "I wrote the release checklist our QA team still uses." The material shows no review you wrote, so build this from first principles | JD content, CASE delivery: it scores the review line (F4) and the written-communication line (F8) at once. The one quote is the only written evidence the material carries |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchase work in your background. If our titles sell them, how would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Open with the plain statement your own words support: "I have never worked on a game with in-app purchases." Hold it there without hedging, then give a plan, said as a plan: what you would ask for first, who you would ask, and how you would check your understanding before it affects a decision. The only adjacent evidence you have is "I presented the monthly retention numbers to the studio head."; offer it at that scope and no further. Follow-ups to rehearse, in order: what would you get wrong first; why should I take that risk; what if the numbers that matter most turn out to be purchase numbers. Concede exactly: the gap is real, and say what you would do in your first month | F9 is the biggest gap in the snapshot and the likeliest objection, so this question arrives in some form. JD because it scores readiness for the listed job, Skeptic because it presses a stated gap |
| B2 | "You've never led a team, and this role coordinates design, art, engineering and community on each update. How do you get four teams pulling the same way?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the plain statement: "I have never led a team." Then stay with the JD's verb, coordinate, as a plan rather than a past: what you would agree with each team up front (what ships, by when, who decides) and how you would raise a disagreement (bring the trade-off, name the owner). Answer slot: the JD's four-disciplines line makes a probe on which of them you worked with on the calendar likely. If you worked with any, say which and what you did, in your own words; if you worked with none, or it was not yours to coordinate, say so plainly and stay with "I ran the weekly content-drop calendar for our main title for the last two years." | F10 is a stated gap and F3 is the thin row beneath it; together they form the second objection. JD because it scores the coordination line |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick the honest one. Your own words name two gaps: "Never led a team, and never worked on a game with in-app purchases." If one of them is your answer, say it plainly and say what you would do in your first weeks. If another line of the JD feels weaker to you, choose that and say why; do not offer a strength in disguise. If no weakness comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Skeptic stem, and the JD is the scoring sheet. JD because it asks you to read the posting against yourself; the choice of row (F9, F10 or another) is yours |
| B4 | "Why a live-operations role, why at a mobile studio, and why now?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Give your own reason in three beats: what draws you to live operations, what draws you to mobile, why now. One sentence each that you can stand behind; the pack supplies none because none came from you. Connect it only to work you have named: "I ran the weekly content-drop calendar for our main title for the last two years." If your honest reason is thin, say so plainly and say what you want to learn here | The motivation probe a Skeptic runs on every candidate; F1 and F2 are the evidence it should connect to. JD because it tests fit with the listed role |
| B5 | "You ran the calendar for your studio's main title. This role covers two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Then reason rather than claim: what you would learn about each title (its players, its pace, what its teams can support), how you would keep two calendars from colliding, and what you would ask in your first week. Answer slot: the JD's two-titles line makes a probe on competing priorities likely. If any of your calendar work meant weighing one title's needs against another's, say what happened and what part was yours; if not, say so plainly and stay with the one title you ran | F1 is where the JD's scope outruns the quote. JD because it scores the stated two-title requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Tell it in the quote's own terms: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on how the numbers were counted and what they depended on. If you chose or defined which retention measures went in, say which and why, in your own words; if someone else set them, or you only presented them, say so plainly and stay with the presenting. Then name, in your own words, the assumption behind those numbers you would defend least; if you do not know how they were counted, say so plainly | F7 is the line a Prober reads first, and F4 is where it is stretched. EXP because it tests what was actually yours |
| C2 | "Tell me about a time a retention number you presented led to a change in what the team did." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A selection scaffold, since your quotes carry no such time: pick one where a number led to a decision, with the number, the decision, who made it and your part in it, and tell only that. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I presented the monthly retention numbers to the studio head.", or how you would handle it | The JD's review-and-KPI line (F4) asks about acting on numbers, not only presenting them. An open prompt, so it supplies no event; JD because it scores that requirement |
| C3 | "The posting asks for three or more years producing live-service games or apps. How do your four years line up against that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say what the quotes say: "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if the title was live for more of the four years, say what you worked on in those years; if only the calendar years were, say so plainly and stay with those two. Do not round up | F6 is a hard JD requirement with a gap between four years and two. JD because it scores the stated number |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with only these beats, in your own words: the four years at the puzzle-game studio, the weekly content-drop calendar, the release checklist QA still uses, the monthly retention numbers presented to the studio head. Close on your own reason for this role (B4). Add no outcomes, numbers or team sizes the quotes do not state | An opener is scored even when it feels friendly. F1, F5, F7 and F6 supply the beats |
| D2 | "What's a mobile live-service game whose event calendar you admire, and what would you change about it?" | JD | [generic] | A selection scaffold: choose a game you genuinely play; name one thing its calendar does well and one you would change, with the reason in terms of players, not taste. If no game comes to mind, say so plainly, then name the calendar you know best and how you would study another. No claim about your past | A casual question about the JD's calendar line (F1), asked the way a Conversational interviewer asks it. JD because it tests interest in the listed work |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side — where's the seam between live ops and design, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: what gets agreed before an update starts, who decides what, how a disagreement gets raised. Offer reciprocity: what you would take off the other team's load, not only what you need from them. Ask where the seam sits today. No claim about your past | F3's coordination line in collegial packaging, for the case where a teammate joins the loop. JD because it scores the coordination requirement |
| E2 | "How do you handle credit when an update spans several teams?" | EXP | [generic] | A selection scaffold: pick a time work spanned teams and credit was shared, with the work, who else was involved, and what you said and to whom; "we" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe on the coordination line (F3). EXP because it asks for what you actually did |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, then answer only with what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years." and "I wrote the release checklist our QA team still uses." Hold through two follow-ups by returning to those two lines and adding nothing. Concede exactly where pressed: "I have never worked on a game with in-app purchases." Make no comparison with the other candidate, whose experience you do not know. Do not fold on the core claim to restore harmony | Tests composure on F1 and F5 against the gaps in F9. JD because it scores fit with the listed job |
| F2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, then hold at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the probe is on attribution. If parts of the calendar were set by others, say which and what was yours; if there was no such split, say so plainly. Hold through two follow-ups by returning to the quote; concede uncertainty specifically, and only where it is true | The persona stem on attribution, aimed at F2, the line most of the pack leans on |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B5, D2, F1 |
| "coordinate design, art, engineering and community teams on each update" | A4, B2, E1, E2 |
| "own the post-event review and the KPIs it reports" | A5, C2 |
| "manage the release checklist with QA" | A3 |
| "3+ years producing live-service games or apps" | C3, B3, F1 |
| "experience running a content calendar" | B5, F2, D1 |
| "comfortable with player-retention metrics" | A2, C1, C2 |
| "clear written communication" | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for someone in this role, on each of the two titles?" | It shows you are planning for two titles, the part of the JD that outruns your calendar experience (F1) |
| R2 | "Where do design, art, engineering and community most often have to trade off on an update, and how does the team settle it today?" | It turns the coordination line (F3) from a claim into curiosity and gets you the real seam |
| R3 | "What does the post-event review report today, and who reads it?" | It gets you the review's contents before you are asked to own them (F4) |
| R4 | "What would I need to get up to speed on in my first month that puzzle-game live content wouldn't have covered?" | It converts the gaps in F9 and F10 into a ramp plan, and invites the interviewer to name the priorities |
| R5 | "How does the release checklist work with QA today, and what would you want improved?" | It connects to F5 and shows you read the JD's release line |
| R6 | "How would you judge, six months in, whether I was doing this job well?" | A rapport-style interviewer weights the closing slot; it asks for the scoring sheet directly |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Plans and runs a live-events calendar | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the weekly content-drop calendar for one main title. B5's and F2's slots stay inside the calendar |
| Owns the post-event review and what it reports | Inflated form of F4 | F4's quote at its own scope. The material says presenting the monthly retention numbers, not the review. C1's slot stays with the numbers presented |
| Manages the release checklist release by release | Inflated form of F5 | F5's quote at its own scope: wrote it, and QA still uses it. The limit is the pack's observation |
| Three or more years producing live-service games or apps | Inflated form of F6 | F6's two quotes at their own scope: four years as an associate producer, two on the calendar. The material does not show how many years were on a live game |
| Has led a team | Negative you stated, F10 | The plain acknowledgment F10 gives: "I have never led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment F9 gives: "I have never worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the job description as pasted; your message, with your background. No dossier was present.

Searches sent, every one refused:

- "Saltmarsh Games mobile game studio values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy news" — refused
- "Tobias Wrenfield Head of Live Operations Saltmarsh Games" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet if a values round exists; not established, so none is included and no VAL questions are written |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have fixed the loop's rounds and the persona weights; they rest on the generic archetype and the hiring-manager prior instead |
| 3. `Saltmarsh Games strategy news` | unavailable | Would have grounded CO and CASE questions in current strategy; the CASE bank is generic and there are no CO questions |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or a pasted values page, recruiter email or careers-page text → a values cheat sheet if a values round exists, loop-based persona weights, CO and CASE questions grounded in the studio's current priorities, and generic rows becoming grounded
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, needs search permission → a strategy brief, Tobias's talks and writing, and reports on this role's loop
- Tobias's public bio or profile, pasted → an interviewer read, persona weights adjusted to his background, and a reverse question tied to his own path
- Whether Tobias would be your direct manager, and anything the recruiter said about the 60 minutes → reweighted banks, and a build section for any announced presentation or exercise
- Your answers to the slot lines in F1, F3, F4, F5 and F6, said outside a drill → those rows quoted into the snapshot and the guidance regenerated around what you actually did
- The weekly content-drop calendar, the release checklist document, or a monthly retention deck → F2, F5 and F7 move from medium toward high, because each is something an interviewer could inspect
- Your CV text → quotes taken from the CV itself instead of your summary
- How many hours you have before Friday → a prioritized prep order, starting with B1
- A `tuesday-dossier.md`, if you have one → verified evidence per requirement and a named top objection in place of the one this pack inferred
