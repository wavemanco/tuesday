Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-7-canned-2207e5a3/saltmarsh-games_live-operations-producer_interview_pack.md`.

Saltmarsh's interviewing page says every loop is a recruiter call, then "the Outage Hour". That is one 60-minute session with the hiring manager: a live-incident tabletop on a simulated outage during an event, then a values conversation, with no take-home. I built the pack on the assumption that Friday is that session and Tobias is the hiring manager. It has 23 questions, a values cheat sheet using the three published values by name, and six reverse questions.

- **Your biggest gap:** the pack's highest-value rehearsal is C1, "Which part of this JD would you be weakest at on day one?" Your stated gaps (no in-app purchases, never led a team) feed it. The Project Larkspur announcement, a move to a season-pass model from February 2027, makes the in-app-purchase gap more likely to come up.
- **Where your evidence is thin:** the JD asks you to coordinate four teams, own the post-event review and show written communication. Your material is silent on the first and last and only adjacent on the review, so those rows hold answer slots, not scripted claims.
- **Common ground with Tobias:** his GDC talk ("Patch Notes Are a Promise") and his QA background make your release checklist the natural overlap. The pack coaches it at exactly the scope you gave: you wrote it and QA still uses it.
- **Limits of the research:** I read only search snippets for Larkspur and for Tobias's talk. Pasting the full pages would sharpen question A5 and the interviewer read.

I can run a live drill as the Skeptic on C1, or on any other question or persona you pick. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Friday the Outage Hour with Tobias as the hiring manager, and did the recruiter tell you anything about the tabletop? That answer decides whether the bank order and persona weights stay as built.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- Role: Live Operations Producer, Saltmarsh Games
- Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager, assumed from your note and the company's interviewing page (see Sources)
- Candidate: Femi
- Built for: one 60-minute session, a live-incident tabletop followed by a values conversation (persona table says why)

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: current priorities and recent moves |
| CASE | Live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. Where a slot offers two branches, either one is a good answer if it is true.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, A5, C3, D3 |
| Coordinate design, art, engineering and community teams on each update | A1, A4, C2, G1, G2 |
| Own the post-event review and the KPIs it reports | A2, D1, D2, E2 |
| Manage the release checklist with QA | B3, C4 |
| 3+ years producing live-service games or apps | C3, F1 |
| Experience running a content calendar | D3 |
| Comfortable with player-retention metrics | D1, D2, E2 |
| Clear written communication | A3, F1 |

## Fit snapshot

No row is a gate: the JD states no location, schedule, pay, licence or authorization term, and the years requirement is graded like any other requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely, and its live-events wording a probe on events as against drops. If you ran or shared a calendar across more than one title, or planned events as well as drops, say which and how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show who the calendar was coordinated with. Answer slot: the JD names four teams, so expect a probe on which of them you worked with on a drop. If you worked with any, say which and what you needed from each, in your own words; if you did not, or that was someone else's job, say so plainly and say what part of the calendar was yours |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers, not that you ran a review or owned the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who chose the KPIs and who ran the review likely. If any review of a drop was yours to run, or any KPI yours to choose, say which, in your own words; if not, say so plainly and stay with presenting the numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Lead with it in the quote's own terms: "I wrote the release checklist our QA team still uses." Your material says wrote, not that you ran each release against it, with nothing inspected behind it, so expect a probe on how a release went through it. Answer slot: if you ran releases against the checklist with QA, say how, in your own words; if QA ran it without you, or you did not, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and a weekly calendar, and does not say whether the title was a live-service game. Answer slot: the JD's live-service wording makes a probe on this likely. If the title was live-service, say what made it so, in your own words; if it was not, say so plainly and stay with the four years and the weekly calendar. The JD says producing and your material says associate producer, so expect that gap to be noticed |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote already says what the JD asks. Lead with it in its own terms: you ran it, weekly, for the main title, for two years. A named record beats an adjective, so an exported calendar page would lift this row, and nothing is inspected behind it yet |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: monthly retention numbers, presented to the studio head. Say it that way and no wider: "I presented the monthly retention numbers to the studio head." Answer slot for the probe that follows: say how those numbers were counted if you know, and which assumption behind them you would defend least; if you do not know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | none given | none | [grounded] | discovery | Your material does not show the writing the role calls for. Answer slot: expect a probe on what you have written for players or for other teams. If you wrote anything of either kind, say what, in your own words; if you did not, say so plainly |
| F9 | A season-pass model with one shared events calendar from February 2027, as the Project Larkspur announcement's search snippet describes it; the JD is silent on monetisation | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Derivation for `[inferred]`: the announcement implies the titles' events will sit inside a season pass, and the JD does not mention it |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The live-incident tabletop: a simulated outage during a live event | High. The company's interviewing page documents a tabletop as the first part of the hour, and the hiring-manager prior also puts Case first | Clarify before structuring, then objective, who you pull in, decisions, player message, what you record. Think aloud. Challenge one premise politely |
| B. Values / Behavioral | The second part of the hour: the same page documents a values conversation | High. A documented round part, so guaranteed in this session; the three published values will theme the questions | One story per value where a sentence of yours carries it, a selection scaffold where none does. "We" for context, "I" for what you did |
| C. Skeptic | Probes at the gaps: no in-app-purchase work, no team led, associate title, one title | Medium-high. Hiring-manager prior, and F2, F3, F5 and F9 are exactly where a quiet probe lands | Rehearse C1 until it is boring. Plain acknowledgment where you stated a negative, an answer slot where the material is silent, then a ramp plan said as a plan |
| D. Data-Driven Prober | Retention numbers and post-event KPIs probed down to how they were counted | Medium. The JD names retention and KPIs; nothing in the footprint read says he is metrics-led, so no upward adjustment | Say what you know of how the numbers were counted and say plainly what you do not. Name the assumption you would defend least before he does |
| E. Pressure | Time-boxed or interrupting follow-ups inside the tabletop | Low. Nothing documented says the hour is run that way; a simulated outage may feel pressured anyway | Pause, restate, hold the position through two follow-ups, concede specifically |
| F. Conversational | An opening biography question | Low. No rapport segment is documented, but openers are common and still scored | A 90-second arc built only from what you have stated |
| G. Peer Evaluator | Cross-team seam questions in collegial wording | Low. He is the hiring manager, not a peer, but the JD's four-team coordination invites seam questions | Offer seam principles and what you bring each team, not claimed knowledge of the seam |

## Reading the interviewer

Public professional footprint only. The source is a search-result snippet of a conference talk page; the page itself was not read.

| Item | Detail | Provenance |
|---|---|---|
| Career pattern | Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | [grounded] |
| Self-described argument | His GDC 2026 talk, "Patch Notes Are a Promise", argues a live team is judged by how often its patch notes describe what actually shipped | [grounded] |
| Implication 1 | Expect weight on written announcements and on whether what you say shipped actually shipped: A3 rehearses it | [inferred] |
| Implication 2 | A QA background makes the release-checklist line (F4) likely to be probed on how a release actually went through it: C4 rehearses it | [inferred] |
| Implication 3 | Your material is a checklist QA uses, not QA work, so describe it at exactly that scope | [inferred] |
| Mirror opportunity | Shared vocabulary only: release checklist and QA. Your side, from F4's evidence cell: "Wrote the release checklist our QA team still uses." It is not offered as a shared career jump, and affinity is never the strategy | [inferred] |

## Question banks

### A. Case / Strategist (highest weight, with B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Mid-event, the game goes down for a share of your players. Talk me through your first thirty minutes." | CASE | [generic] | Structure it aloud: what you need to know first (what is down, for whom, how we know), the objective (protect players, say true things), who you pull in from the four teams the JD names and what each is asked for, the decisions that are yours and the ones you hand over, and what you record for the review. The question needs no claim about your past, so the guidance makes none | The interviewing page documents a live-incident tabletop, which is this question's shape; F2's requirement is the coordination it exercises. `[generic]` because the scenario is a pattern, not this studio's own |
| A2 | "The outage is fixed after four hours and the event ran through it. What do you do about the event, and who decides?" | CASE | [generic] | Clarify first: how many players were hit, what the event's remaining time is. Then options (leave it, extend it, compensate), the criterion you would use, who decides and who you tell, and what goes in the post-event review. Make no claim about having done this | Tests the player-first judgment the published values describe and the post-event review the JD says you own (F3's requirement) |
| A3 | "Write me the two-sentence player message for the outage: what we know and what we don't." | CASE | [generic] | Say what is known now, what is being done, and when the next update comes. Do not state a fix time you do not have. Short sentences, no hedging adjectives | Written communication is a JD line (F8's requirement), and his public talk is about notes matching what shipped. CASE in delivery, JD in content |
| A4 | "Two titles have events landing the same week and engineering can support only one. How do you decide?" | CASE | [generic] | Clarify (dates committed, player impact, risk), state your criterion, say who you take the decision to, and what you tell the team that waits. A plan only, no claim about a past decision | The JD's two-titles line (F1's requirement) and four-team coordination (F2's requirement) in one problem |
| A5 | "From February 2027 two titles move to one shared events calendar. What would you want to know in your first week to plan it?" | CO | [grounded] | Clarify before structuring: which events each title needs, what a season pass changes about pacing, who sits in the single live-ops group, what is already booked. Say you are working from the public announcement and ask what has changed since. Make no claim about your own past | At L1 the strategy sweep returned the Project Larkspur snippet, so a strategy-grounded question is owed. Not read in full: paste the announcement to sharpen this one |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time a planned drop and what players needed pulled apart. It needs a named stake, what you decided or recommended, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the calendar you ran, or how you would handle it | Players Before Plans is a published value and a documented values part; F6 is the nearest row, and it carries no conflict, so this is a scaffold |
| B2 | "Tell me about a time you had to say something wasn't ready." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time a release or drop was held back or changed. It needs what was not ready, who you told, and what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the checklist you wrote, or how you would handle it | Ship the Patch Not the Promise is a published value; F4 is the nearest row and carries no hold-back, so this is a scaffold |
| B3 | "Tell me about a time you left a process or checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and QA still uses it; those are the beats the quote states, told in your own words. Answer slot: the published value says every release leaves the checklist better than it found it, so expect a probe on what the checklist replaced or improved. If it replaced or improved something, say what, in your own words; if there was nothing before it, or no change followed, say so plainly and stay with having written it | Leave the Build Greener names the checklist directly, which makes F4 the pack's strongest value-to-story match. VAL, with JD content |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: you presented the monthly retention numbers to the studio head, the beat the quote states. Answer slot: if any month's numbers were unwelcome, say what you said and how it landed, in your own words; if none were, or nothing was unwelcome, say so plainly and stay with presenting them | A standard Values stem; F7 is the only row that puts you in front of leadership, and it does not say anything was unwelcome |
| B5 | "Which of our three values would you find hardest to live by?" | VAL | [grounded] | Choose one of the three by its published name and say honestly why it is hardest, with one concrete habit you would use. It asks about the future, so the guidance makes no claim about your past | Candor under a values frame; the three names come from the company's own page, fetched |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack: it arrives in some form, and it lands on F9, F2, F3 and F5. Choose your real weakest area. If it is the one you stated, the words are "I've never worked on a game with in-app purchases", then a plan said as a plan: what you would learn first about how a season pass earns and how it shapes the calendar, and who you would ask. Follow-up one: how long that takes. Concede only what you cannot know. Follow-up two: why that is acceptable, answered with what the role needs from you now, not with a claim to monetisation work. Name the limit before he asks for it | F9 is the largest stated gap and the one the Larkspur news makes live. JD because it scores the posting's own list |
| C2 | "You've never led a team, and this role coordinates four. How do you get design, art, engineering and community to move on your timeline." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment first: "I've never led a team." The JD's verb is coordinate, so say how you would agree dates and what you would ask each team for, as a plan. Answer slot: if you worked with any of the four on a drop, say which and what you needed from each, in your own words; if you did not, say so plainly and say what part of the calendar was yours | The negative is yours and sourced, so the question may use it. F2 is where the slot comes from |
| C3 | "The JD asks for three-plus years producing live-service games. How do your four years as an associate producer at a puzzle studio fit?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Hold on the quotes: four years as an associate producer, and the weekly calendar you ran for two of them. Answer slot: if the title was live-service, say what made it so, in your own words; if it was not, say so plainly and stay with the four years and the calendar. Hold through two follow-ups by returning to what you did, never by adding to it. Concede specifically that the title was associate | F5 is where the years requirement presses. The years line is graded as a risk, not a gate, so honesty beats framing |
| C4 | "Walk me through how a release went through the checklist you wrote." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say you wrote it and QA still uses it, in those terms. Answer slot: the JD's manage-the-checklist line makes a probe on how a release went through it likely. If you ran releases against it with QA, say how, in your own words; if QA ran it without you, or there was no such step, say so plainly and stay with having written it | His public background is QA, so this is likely; F4 holds the quote and its limit |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say how they were counted if you know, in your own words. Name the assumption behind them you would defend least before he does. Say which part was yours, presenting or also compiling them. If you do not know how a figure was counted, say so plainly: that is an honest branch, not a loss | F7 is a metric row, and every metric gets a defend-the-number question |
| D2 | "What goes in a post-event review, and which KPIs would you report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if any review of a drop was yours to run, say what it held and who read it, in your own words; if not, say so plainly, then give the structure you would use as a plan: what was planned, what happened, what players did, what changes next. Choose your KPIs and say why; none is named here for you | F3's JD line is the likeliest place the ownership wording is tested |
| D3 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F6: the calendar, its weekly rhythm, the main title, the two years: the beats the quote states. Answer slot: the JD's calendar line makes a probe on how a week ran likely. If you set the steps, say which and how, in your own words; if they were set for you, or there were none, say so plainly and describe how you ran the calendar | The JD's calendar requirement, rehearsed on the claim most likely to be examined line by line. F6 holds the quote |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Never led a team, and never worked on a game with in-app purchases." | Hold the position in what the quotes carry: you ran the weekly calendar, and you wrote the checklist QA uses. Concede specifically and early: "I've never worked on a game with in-app purchases." Hold through two follow-ups by returning to those two facts, never by claiming a monetisation or team-lead background | F9 and F6 are the pressure points; hold-then-concede is the structure |
| E2 | "That retention readout: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which part was yours, compiling, analysing, or presenting, in your own words; if you only presented numbers others produced, say so plainly. Hold what the quote says, that you presented them, through two follow-ups. Concede exactly what you do not know about how they were produced | The attribution probe the pressure persona uses; F7 and F3 are the rows it presses on |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you end up in live production?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." | A 90-second arc built only from those three sentences: the four years, the calendar, the checklist. Answer slot: say in your own words why live operations and why this studio now; if you have no clear reason, say so plainly and say what draws you today. Casual questions are still scored | The biography opener is the likeliest casual question; F5 is the row it leads into |
| F2 | "What are you playing at the moment, and what do you notice about how its events work?" | CO | [grounded] | Answer from what you actually play. If you can, spend an hour in Tidepool Tactics and Lantern Row, the two titles the Larkspur announcement names; the JD does not say which two titles the role covers. Say what you noticed about how an event starts, runs and ends. No claim about your past | A casual question about the JD's events topic; scored for real interest |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where's the seam between live ops and engineering, and what happens when we disagree about a ship date?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: engineering owns what is safe to ship, you own the calendar and the player message, and a disagreement goes to a named person with both facts in hand. Say what you bring them as well as what you need. No claim about your past | F2's requirement in collegial wording |
| G2 | "How do you handle credit when an update spans design, art, engineering and community?" | JD | [generic] | A principle, not a story: name the teams' work in the review and in the player message, and keep your own contribution to what the calendar made possible. No claim about your past | Credit-sharing is the peer persona's standard probe; F2 is the row |

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F6 carries the calendar but no conflict: selection scaffold, as B1 gives it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years.", or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F4 carries the checklist but no hold-back: selection scaffold, as B2 gives it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "Wrote the release checklist our QA team still uses.", or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats as B3 states them, with the improvement beat an answer slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. How does the team measure that today?" | Ties to his public path and talk; shows you read him, not just the company |
| R2 | "You moved from QA lead into running live operations. What did QA teach you about live events that you wish more producers knew?" | Ties to his career path and turns the interview into a peer conversation about release discipline |
| R3 | "Project Larkspur moves two titles to a shared events calendar from February 2027. How does this role sit in the single live-ops group, and what does the first quarter look like?" | Reads as homework on the company's current strategy, and tells you what the job will be after the change |
| R4 | "What does a strong Outage Hour look like to you, and what do people most often skip?" | Shows you prepared for the format and calibrates what he scores |
| R5 | "After a post-event review is written, who reads it, and what changes because of it?" | Goes to the JD's own-the-review line and to what the role is really for |
| R6 | "Which of the three values is hardest for the team to hold when a release date is close?" | Shows you took the values seriously and invites a real example from him |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | "I've never led a team." No slot, then a plan for how you would coordinate |
| Worked on a game with in-app purchases, or on a season-pass or monetised event | Negative you stated, same quote | "I've never worked on a game with in-app purchases." No slot, then a plan for what you would learn first |
| Planned or ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for one main title. A slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the monthly retention numbers. The slot stays inside that |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist, not that you ran each release against it |
| Produced a live-service game | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer and a weekly calendar. The limit is the pack's observation: the material does not say the title was live-service |

## Sources

Provided: your message, carrying the JD and your background. No dossier or CV file was present, so nothing was consumed from one.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and the B bank: three values by official name, fetched from the company's page |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: a recruiter call, then one 60-minute interview with the hiring manager, a live-incident tabletop then a values conversation, no take-home. Persona weights, the bank order and the values section follow it |
| 3. `Saltmarsh Games mobile studio strategy news` | yes | A5, F9, F2's CO question and R3. Only the search snippet was read, because both fetches went to targets 1 and 2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read and R1 and R2. Only the search snippet was read |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, by query:

- `Saltmarsh Games values` returned https://saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games mobile studio strategy news` returned https://saltmarshgames.com/news/project-larkspur
- `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read.

## Upgrade menu

- The recruiter's note on format, and whether Friday is the Outage Hour with Tobias as the hiring manager → confirms the persona weights, or restructures the banks if Friday is another round
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the Larkspur strategy and Tobias's talks, and less generic A5 and R3
- The full text of the Project Larkspur announcement and of the GDC talk page, pasted → A5, F9 and the interviewer read rest on the full pages and not on search snippets
- Your answers to the slots on F1, F2, F3, F5 and F8, in your own words → each of those rows is rebuilt on your quotes and the matching banks regenerate
- The release checklist document, an exported calendar page, a retention readout → F4, F6 and F7 can move from medium to high, since those are the inspectable artifacts in this field
- A short sample of something you wrote for players or other teams → F8 moves from none given to a quoted row
- A `tuesday-dossier.md` from an earlier underwriting pass would add an evidence-derived objection and sourced prohibited claims; the pack is complete without one
