Pack is saved. I'm doing one fix pass: the prober bank's question IDs (F1, F2) collide with the fit-snapshot row IDs, so I'm renaming them.
The shell command was blocked, so I'll make the same edits with the Edit tool.
Dara, your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-8-denied-75b0e6d3/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop, because the recruiter's email fixes the schedule. It has 33 questions: 9 for the recruiter, 12 for the Head of Member Services and 12 for the panel. Each round has its own persona weights, reverse questions and answer guidance. The panel section includes a values cheat sheet using Ashgrove's four values by name and the 20-minute escalation case. I ran no web searches, because your pasted values, recruiter email, strategy summary and JD already covered what research would have.

- **Top rehearsal (D1, round 2):** "Your complaints experience is from a branch, and you haven't worked in a contact centre. How would you own the process across both?" The guidance has you say plainly "I've never worked in a contact centre," then hold to what you actually did, with a concession line for the "why not someone who has" follow-up.
- **Second priority:** presenting to senior people. It comes up in C3, K2 and D2, and the guidance has you say "I've never presented to anyone above regional level" and give a preparation plan.
- **Where the pack leaves gaps open:** I had no CV text, so every quote is from your message. Where your sentences don't show something, the guidance is an answer slot for you to fill in your own words, or to say it wasn't yours. That covers what the spreadsheet counted, whether it was Excel, which rules governed the complaints log, any supervisor coaching, and digital-team work.
- **What the pack won't coach:** "owned the process end to end" and "coached supervisors" are listed as claims your material doesn't support. So are "worked in a contact centre" and "presented to senior leaders", which you've said you haven't done.

Say the word and I'll play the Skeptic on D1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 29 November 2026 (recruiter 30 min; Head of Member Services and likely future manager, 45 min, mostly behavioural; panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, scored against the four values). Interviewer names: not yet assigned.

## How to use this pack

- Personas are how a question is asked; types are what is scored. Guidance is scaffolding, not a script: say it in your own words.
- Types: VAL = behavioural / values alignment; EXP = work-experience deep-dive; JD = role and JD requirements; CO = company and strategy knowledge; CASE = live problem.
- Labels: `[grounded]` traces to a document you gave me; `[inferred]` is derived and the derivation is named; `[generic]` is a role-family pattern with no claim about Ashgrove or you.
- "Answer slot" lines are instructions for the interview. They ask you nothing here; they mark a place where only your own account will do, with an honest branch if the practice was not yours or never existed.
- Every quote from you comes from your message; no CV text was supplied.
- The highest-ROI rehearsal in the pack is D1 (round 2): the scope objection that your complaints experience is one branch's and you have not worked in a contact centre. A close second is presenting to senior people (F8, rehearsed in C3 and K2).

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat beyond the log likely. If any step before or after the log was yours to run, say which, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Lead with the quote in its own terms: you built it, and your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted either, say which and how, in your own words; if it counted something else, or nothing about timing, say so plainly and stay with the sheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: if you have coached any supervisor on escalations, say how, in your own words; if you have not, or it was not yours, say so plainly and stay with training tellers on the script |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material shows nothing either way. Answer slot: if you have worked with a digital or product team on anything a member uses without staff help, say what and which part was yours; if not, say so plainly and answer from the member's side of the journey |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | Not a gate: a length-of-experience requirement, and your quote already carries the number. It is a line with nothing inspected behind it, so expect a probe on what those years held. Lead with it in its own terms |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says formal complaints, and your material does not show which rules governed the log. Answer slot: the JD says regulated, so expect a probe on that. If the log was kept under a regulator's rules, say which and what they required of you, in your own words; if it was not, or you did not work to such rules, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare to do it, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Inferred from "spreadsheet" to a possible Excel link; the quote does not name the tool. Answer slot: if the sheet was built in Excel, say so and name what it did in your own words; if it was another tool, say so plainly and say what you have used |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, D1, H1, J1, J2 |
| Report monthly on volumes and resolution times | C2, K1, K2 |
| Coach branch supervisors on escalations | C1, D3, H2, I1 |
| Work with digital teams on self-service journeys | C4, E1 |
| 4+ years in financial-services customer operations | A1, B2 |
| Experience handling regulated complaints | B3, H1 |
| Confident presenting to senior leaders | C3, D2, K2 |
| Comfortable with Excel reporting | K1 |

Pay, notice, location and reason for leaving (A2 to A5) are logistics slots for the recruiter screen, not JD requirements.

## Grounding brief (Ashgrove 2026 strategy brief, July 2026, as you relayed it)

| Item | Provenance | How to use it |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] your summary of the brief | Frames the self-service questions (E1, C4); keep "plain words" in every journey you describe |
| Consolidate eight branches into five hubs over 2027 | [grounded] your summary of the brief | Likely backdrop for the branch managers in round 3 (H3), and it sits beside the value "Neighbours, Not Numbers"; expect the tension to be probed |
| Launch a small-business lending product in Q1 2027 | [grounded] your summary of the brief | New product, new complaint types; useful in a CO answer, a minor point |
| Main competitive pressure is app-only banks | [grounded] your summary of the brief | Anchors E3 and A6; a complaints process is where a member-owned credit union can be seen to differ, which you would argue as a view, not as a fact about Ashgrove |

The brief is under six months old at the time of writing. It was sent by the recruiter, so you can use it freely; do not quote targets back as if you had insider knowledge of how they are going.

## Sources and research accounting

Provided: the JD; the values page text, copied from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email on the three rounds; the 2026 strategy brief as you summarised it; your background message. No dossier present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the cheat sheet and every VAL question |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email establishes the three sessions, who runs each and what each holds, so persona weights follow it, not an archetype |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief you supplied fixes the CO and CASE material |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names yet, so no query could be formed; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Round 1: recruiter screen (30 minutes)

Persona weights, with reasoning: **Conversational** is top, because the recruiter's note says "30 minutes with me" and a screen is a friendly register that is still scored (relationship prior). **Skeptic, light**: a screen checks knockouts, and your own stated gaps (F2, F8) are the likeliest. No other persona is plausible in 30 minutes.

### A. Conversational / rapport builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: how did you get to this role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc whose beats are the four quoted sentences, in your own words and in that order: the six years, the last three as supervisor, the log, the script training, the spreadsheet. Answer slot: why this role now is yours to say; give your actual reason in your own words, and do not borrow the JD's phrases for your history | F6 and F1 to F4 are the spine of the story; EXP because it tests whether the CV survives a casual retelling |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first. If asked about current pay, prepare a line to decline or redirect, with no figure | The recruiter row of the persona model makes pay a standard screen item; the only safe answer is your own |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. | A standard screen item; no figure has been given, so none is supplied |
| A4 | "Where are you based, and does the location of this role work for you?" | JD | [generic] | Logistics slot: give your actual location and any constraint, in your own words. If the posting did not say where the role sits, ask. | Location is a term of the job; no constraint has been stated, so none is assumed |
| A5 | "What's prompting a move now?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. | The reason for leaving is a standard screen item and a motivation-consistency check |
| A6 | "What do you know about Ashgrove, and why us rather than an app-only bank?" | CO | [grounded] strategy brief, as relayed | Use the fact you can state from the brief (40% of member service digital by 2028; app-only banks as the main pressure) and one value from the page by its exact name. Say in your own words why a member-owned credit union appeals; do not claim inside knowledge | A CO question in a casual register; F6 has no bearing, so this is pure homework |

### B. Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in a contact centre. How do you see that affecting this role?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first: "I've never worked in a contact centre." Then what you would do to learn it, as a plan in your own words; no past claim. Save the full rehearsal for D1 | F2 is the likeliest knockout in a screen, and the negative is yours |
| B2 | "The JD asks for four-plus years in financial-services customer operations. Where does yours sit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it in the quote's own words and stop. Answer slot: what the six years held is yours to describe; do not widen it | F6 is a clean fit on length; the probe is what the years contained |
| B3 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Say it at its own scope: "I handled the branch's formal complaints log." Answer slot: the JD says regulated, so expect a probe on which rules applied. If the log was kept under a regulator's rules, say which and what they required of you; if it was not, or you did not work to such rules, say so plainly and stay with the log | F7 is a discovery row: the quote says formal, and the rules are unknown |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is there anything I should prepare in advance for the 20-minute case?" | Surfaces any pre-declared material before you walk in |
| R1.2 | "Could you tell me the names and roles of the people I'll meet?" | Lets the pack add an interviewer read for rounds 2 and 3 |
| R1.3 | "How does complaint handling divide between the branches and the contact centre today?" | Shows you are thinking end to end, and starts closing F2 |
| R1.4 | "What does the timeline look like after the 29th?" | A logistics question that signals you are planning ahead |
| R1.5 | "What have the strongest candidates shown the panel on the values?" | Treats the values round as something you prepared for |

## Round 2: Head of Member Services, likely your manager (45 minutes, mostly behavioural)

Persona weights, with reasoning: **Values/Behavioral** is top, because the recruiter says this round is "mostly behavioural", which overrides the manager row's Case/Skeptic prior. **Skeptic** and **Case/Strategist** are mid: a manager buying capability will price your gaps (F2, F8) and may set a live problem from the role. **Data-Driven Prober** is low: reporting and Excel are JD items, and the spreadsheet is the only reporting evidence. All four banks are rehearsed because the style may arrive in any of them.

### C. Values / behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers on the escalation script, which are the beats the quote states; tell them in your own words. Answer slot: the JD's coaching line makes a probe on one real escalation likely. If a teller took an escalation you coached them through, say what happened and what part was yours; if there was no such case, or it was not yours, say so plainly and stay with the training | F4 is the evidence for the JD's coaching requirement; VAL because it tests coaching behaviour, and the theme is the JD's |
| C2 | "Tell me about a time the numbers you reported told a story someone didn't want to hear." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built the spreadsheet and your regional manager uses it, no further. Answer slot: if a month's numbers led to an awkward conversation, say what the numbers were and what part of it was yours; if none did, say so plainly and say how you built it to be read | F3 is the only reporting evidence; EXP because it tests what was actually yours; the theme comes from the JD's reporting line and the persona stem |
| C3 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona model's stem; it also reaches F8, since "senior" is where your stated limit is |
| C4 | "Tell me about a time you worked with a team outside your branch to fix a problem." | VAL | [grounded] JD | Selection scaffold: pick a problem that crossed a boundary, name who sat on the other side, and say what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD asks for work across branches and with digital teams (F1, F5); your material has nothing quoted for it, so this is a scaffold |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your complaints experience is from a branch, and you haven't worked in a contact centre. How would you own the process across both?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | The highest-ROI prep in this pack. Level 1: say plainly "I've never worked in a contact centre," then the quote at its own scope: "I handled the branch's formal complaints log." Limit, named before it is asked: your material says the branch log, not the process end to end. Follow-up 1 (what would you need to learn first): a plan in your own words, naming what you would ask the contact-centre team; no past claim. Follow-up 2 (why not someone with contact-centre experience): hold, then concede in these words: "A candidate who has worked in one would start further ahead on that part; I haven't." Then return to the log and the monthly spreadsheet you built. Hold through two follow-ups by returning to what you stated, never by adding to it. Answer slot: if any step beyond the log was yours to run, say which; if there was none, say so plainly | F1 and F2 are where the role's headline mandate presses hardest, so this objection will arrive in some form; JD because it scores the stated requirement |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose from your own list and say it plainly: "I've never worked in a contact centre," or "I've never presented to anyone above regional level." Then a concrete ramp plan in your own words. Calibrated candour beats bluffing a competency the interviewer may own | F2 and F8 are the two stated gaps; Skeptic stem from the persona model |
| D3 | "You'd be coaching branch supervisors, and you've been one. What changes?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Say what the quotes say: three years as a branch supervisor, and training tellers on the script. Answer slot: if you have coached any supervisor, say how; if you have not, or it was not yours, say so plainly and describe how you trained tellers | F4 is a transferability row: the quote reaches tellers, not supervisors; the question's premise is the JD's, held at the quote's scope |

### E. Case / strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Members who move to a self-service journey are calling the branch confused. Sketch the plan: what do you need to know first?" | CASE | [generic] | Clarify (which journey, which members, what they were told) then objective, segmentation, approach, metrics, risks. Think aloud; challenge one premise respectfully. Use plain words in every step, which is the value, and name how you would work with the digital team. The question needs no claim about your past, so the guidance makes none | The JD's self-service line and the brief's 40% digital target make this a likely live problem; `[generic]` because it is a pattern for the problem |
| E2 | "Eight branches become five hubs over 2027. What happens to complaint handling in a town that loses its branch?" | CO | [grounded] strategy brief, as relayed | Clarify what you would need to know (which towns, what members use now, the timetable), then the member's side of the counter and the hub's side, then what you would measure (volumes and resolution times by town). Say what you would not assume | The consolidation is in the brief and the tension with "Neighbours, Not Numbers" is the obvious one; CO because it tests strategic fluency |
| E3 | "App-only banks are our main competitive pressure. Where do complaints help or hurt us against them?" | CO | [grounded] strategy brief, as relayed | Think aloud: where members meet a complaint, what an app-only bank cannot offer in person and where it is faster; give a view and say it is a view. No claim about Ashgrove beyond the brief | The brief names the pressure; this is the differentiator question most candidates cannot touch |

### K. Data-driven prober (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Walk me through the monthly complaints spreadsheet. What did it count, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the quote says, then answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted and how. If it counted either, say which and how, in your own words, and the assumption you would defend least; if it counted something else, or nothing about timing, say so plainly. Say which tool it was built in, in your own words | F3 and F9 are the reporting rows; EXP because it tests whether you know how your own figures were made |
| K2 | "The JD asks for monthly reporting on volumes and resolution times. How would you report them so senior leaders act on them?" | JD | [generic] | Structure it: what the leaders need to decide, the two or three measures, how a trend is shown, what a recommendation looks like. Say plainly that you have not presented above regional level and what you would do to prepare. The question needs no claim about your past beyond the F8 limit | F3 and F8 meet here; JD content, CASE delivery |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What does a good first 90 days look like for this role, and what would tell you it was going wrong?" | Gets the manager to define success, and signals ownership |
| R2.2 | "Where does the complaints process currently break between the branches and the contact centre?" | Ties to the end-to-end mandate and gives you a chance to learn what the contact-centre side needs |
| R2.3 | "How will the hub consolidation change who owns a complaint?" | Ties to the brief and to "Own the Fix" |
| R2.4 | "Which senior forums see the monthly complaints report, and what do they usually ask about it?" | Prepares you for F8 and shows you plan to present well |
| R2.5 | "What is the digital team's plan for self-service journeys, and where do complaints inform it?" | Ties to F5 and the 40% digital target |

## Round 3: panel of two branch managers (60 minutes, including a 20-minute escalation case; values round)

Persona weights, with reasoning: **Values/Behavioral** is top: the recruiter says "the panel is also the values round — they score against the four values". **Case/Strategist** is high because 20 of the 60 minutes are a complaint-escalation case. **Peer Evaluator** is mid, inferred: branch managers sit alongside the supervisors you would coach, so a seam question is likely (this is an inference from the JD's coaching line and the panel's roles, not a documented fact). **Pressure** is low: nothing says this panel is a stress panel, but "how much of that was you" arrives in any panel. Names are not known; if they arrive, the personas can be assigned per member.

### G. Values / behavioural (the four values, by name)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Members First, Always: tell me about a time you decided from the member's side of the counter, even though it was harder for the branch." | VAL | [grounded] values page text | Selection scaffold: pick a decision with a named member stake, who disagreed, and what you did; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Name the value as Ashgrove names it | The panel scores against the value; your quotes carry no decision story for it |
| G2 | "Plain Words: tell me about a time you explained something and it had to be explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: the script, and training tellers on it. Answer slot: if any of the script's wording was yours to write or revise, say what and why; if it was handed to you, or you did not change it, say so plainly and describe how you taught it | The value says if a member needs it explained twice, the writing is wrong; the quote carries the script, not its authorship |
| G3 | "Neighbours, Not Numbers: tell me about a time you treated a member as a person, not a figure." | VAL | [grounded] values page text | Selection scaffold: pick a member, what the numbers said, what you did instead; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Say what you would do when the numbers and the person disagree | A branch-manager panel is likely to read this value through the branch; your quotes carry no story for it |
| G4 | "Own the Fix: tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: you handled the log, no further. Answer slot: pick one complaint from it that you followed to a solution and say what you did and what part was yours; if you passed it on, or none was solved by you, say so plainly and say what you did hold | The value is "whoever finds the problem keeps hold of it until it is solved"; F1's quote carries the log, not a fix |

### H. Case / strategist (the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member's complaint reaches you after two escalations. The branch supervisor and the contact centre each say the other dropped it. You have 20 minutes: how do you handle it?" | CASE | [generic] | Clarify first (who owns it right now, what the member was told, what the complaint rules require and by when, which you would check rather than recite). Objective, then the member's side first today, then who holds it from here (Own the Fix), the plain-words reply to the member, the record, the root cause, and what you would report. Think aloud; challenge one premise. The question needs no claim about your past, so the guidance makes none | The panel's case; the escalation theme is the JD's and the recruiter's own; `[generic]` because it is a pattern for the problem |
| H2 | "Same case, but the supervisor says they followed the escalation script exactly. What now?" | CASE | [generic] | Separate the member's outcome from the script's wording: ask what was done and when, find where the script and the case parted, coach without blame, and say what you would change in the script's wording if it failed. Answer slot: if you have ever found a script wanting, say what and what you did; if not, say so plainly and answer as a plan | Tests coaching (F4) and Plain Words in one problem |
| H3 | "Members in a town that is losing its branch say we're treating them as numbers. How do you respond to the complaint, and what do you change?" | CASE | [grounded] strategy brief, as relayed; values page text | Member's side first, in plain words; acknowledge, then find what they actually lose; what you would change in how complaints from that town are held and reported. Do not argue the consolidation; say what you would take back to the people deciding | The brief's consolidation sits against "Neighbours, Not Numbers"; branch managers are likely to care |

### I. Peer evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You'd be coaching supervisors who work in our branches. Where's the seam between your coaching and our management, and what happens when we disagree?" | JD | [inferred] from the JD's coaching line and the panel's roles | Propose seam principles rather than pretending to know the seam; reciprocity (what you bring them, not only what you need). You can say you have been a branch supervisor, which your quote states: "the last 3 as a branch supervisor." Answer slot: if you have disagreed with a manager over how an escalation should be handled, say how and what happened; if not, say so plainly and say how you would handle it | F4 is a transferability row; the seam is the likeliest peer question |
| I2 | "How do you handle credit and blame when a complaint spans a branch and the contact centre?" | VAL | [generic] | Principles, not a story: who holds it, how it is recorded, how credit is shared, how a lapse is raised without blame. Say what you would agree with the managers in advance | A peer probe on collegial disagreement; no claim about your past |
| I3 | "What would you need from us in your first month?" | JD | [generic] | Reciprocity: two or three specific asks (access, time with supervisors, examples), then what you would give back. Do not claim a method you have not used | The persona model's peer stem |

### J. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "That complaints log: how much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause, restate, hold: "I handled the branch's formal complaints log" and "I built the monthly spreadsheet our regional manager uses." Hold through two follow-ups by returning to those words. Concede specifically if pressed. Answer slot: which parts of handling the log were yours, and which belonged to your supervisor or manager, in your own words; if you do not know, say so | F1 and F3 are where inflation would be tested |
| J2 | "Sixty seconds: why you over someone who has run a contact-centre complaints team?" | JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | Hold what you have, concede what you do not: "I haven't worked in a contact centre; I have six years in retail banking, the last three as a branch supervisor." Then stop; do not add a claim to win the minute | The Pressure stem, aimed at F2 |

### Values cheat sheet (the panel scores against these)

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side | Scaffold (G1): pick a decision with a named member stake; if none comes to mind, say so plainly, then give the nearest thing your material carries |
| Plain Words | Write so a member understands first time | F4: "trained new tellers on our escalation script" — answer slot on whether the wording was yours (G2) |
| Neighbours, Not Numbers | Each branch is part of its town | Scaffold (G3): pick a member and what you did beyond the figures; if none comes to mind, say so plainly |
| Own the Fix | Whoever finds a problem holds it until it is solved | F1: "I handled the branch's formal complaints log" — answer slot on one complaint followed to a solution (G4) |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Which complaints do your supervisors escalate most, and what do you wish happened before they did?" | Shows you are thinking about the people you would coach |
| R3.2 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel |
| R3.3 | "In the hub plan, how will a complaint be owned when a branch closes?" | Ties to the brief and "Own the Fix" |
| R3.4 | "Tell me about a complaint in your branch that turned out well. What made the difference?" | Invites a values story from them and shows how they define good |
| R3.5 | "Where do members get stuck in self-service today, from what you see at the counter?" | Ties to F5 and the 40% digital target |

## Prohibited claims (what this pack will not coach)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope; the limit is the pack's observation: the material says the branch's log, not the process end to end. D1's slot stays inside the log |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope; K1 in round 2 asks only what the sheet counted |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers, the script |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## Upgrade menu

- Your CV, or a few more lines on the complaints log and the spreadsheet → F1, F3, F7 and F9 upgrade from discovery slots to grounded rows; answers to the slots (what the sheet counted, which tool it was built in, what rules governed the log, any supervisor coaching) become quoted evidence once you tell me them outside a drill
- An anonymised view of the spreadsheet's layout (no member details) → the artifact that would lift F3 and F9 from medium toward high
- The interviewers' names → an interviewer read, per-member personas and a reverse question tied to each one's path
- The recruiter's answer on whether the 20-minute case is shared in advance → a build section if any deliverable is announced
- Hours available before the 29th → a prep triage sized to them
- Deeper research, offered once → up to 6 more searches and 2 more fetches, several more minutes: recent organisation context, role-family loop reports, and (once names exist) interviewers' public footprint
- A `tuesday-dossier.md` from an earlier fit check, if you have one → a verified evidence list and a named top objection, replacing this pack's inferred one
