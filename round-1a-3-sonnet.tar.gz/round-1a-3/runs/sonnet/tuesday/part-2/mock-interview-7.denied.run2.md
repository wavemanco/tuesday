Web search wasn't permitted in this session, so I'm building the pack from your JD and your background alone and labeling what that costs. I'm writing the pack file now.
Femi, your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md` in the working directory. It has 18 questions with answer guidance, a fit snapshot against the JD, reverse questions and a list of claims not to make.

Web search wasn't permitted in this session, so all four of my searches were refused. The pack contains nothing about Saltmarsh's values, interview loop, strategy or Tobias's background. Those parts are marked as missing, and the pack's Sources section lists exactly what each search would have fed.

I built it as a hiring-manager round with Tobias, since your note didn't say how he relates to the role. The weights favor case problems and skeptical probing of your gaps.

- **Highest-ROI prep:** question B1, "Which part of this role would be hardest on day one?" You said you've never worked on a game with in-app purchases and never led a team. The pack coaches you to say the first plainly, with a ramp plan. I inferred this objection myself, so it isn't confirmed.
- **Thin spots in your material:** the JD says "two titles" and "own the post-event review", and your material shows one main title and presenting the retention numbers. It's also silent on coordinating design, art, engineering and community. Those rows are answer slots, which means you say what you actually did, or say plainly it wasn't yours.

I can play the Skeptic on B1 as a live drill, or save a `tuesday-dossier.md` that records the gaps this prep exposed. Say so if you'd like the pack as a Word document.

Would Tobias be your future manager? A different answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager (your note did not say). Length: 60 minutes. Mode: session pack for one conversation.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values (not used in this pack, see persona table) |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Each has two honest branches: say how you did it, or say plainly it was not yours or never existed, and return to what you did say.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one main title and content drops, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on scale likely. If a second title or any events were yours to run, say which and how; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD names four disciplines, so expect a probe on each. If any of them fed into the weekly drops, say which and what you did with them, in your own words; if they did not, or that was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presented, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD says own the review, so expect a probe on who produced the numbers and what followed. If you compiled or interpreted them, or a decision followed, say what; if not, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you wrote it, and QA still uses it. Answer slot: if you also worked it through releases with QA, say how; if you only wrote it, say so plainly |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives the four years and the calendar, and does not show what the other years held. Answer slot: expect a probe on how much of the four years was live-service. Say what the years before the calendar involved, in your own words; if that was not live-service work, say so plainly and lead with the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The quote already says what the JD asks. Lead with it exactly. A sample calendar, if you can show one, is the artifact that would raise the band |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the numbers were built, and see C1 for the slots |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | A written document other people still use is your evidence, and its words stay in the quote: you wrote it, and QA still uses it. Nothing further is added about how well it reads |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the job: build a calendar, handle a late asset, diagnose a retention dip, run a review | High. Hiring-manager priors favor it, and the JD is a planning job. Assumption: Tobias is your future manager | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic | Quiet probing of the gaps and of why live ops, why here | High. Hiring-manager priors favor it, and F2, F3 and F5 are thin while two absences are stated | Rehearse the predictable objection until it is boring; plain acknowledgment plus a plan, never a bluff |
| Data-Driven Prober | Reads your claims line by line; asks how the numbers were counted | Medium. The JD names KPIs and retention, and your claims are short sentences with nothing inspected | Say how it was counted or say plainly you do not know; name the assumption you would defend least |
| Conversational | Friendly opener such as the journey question | Medium. It opens many conversations; the casual register is still scored | Rehearse one 90-second arc from your own sentences |
| Pressure | Time-boxed, devil's advocate | Low. Nothing in your material or the JD points to it, but one drill is cheap | Pause, restate, hold the core claim through two follow-ups, concede only what is true |
| Values/Behavioral, Peer | Not covered | No values-style round is detected: no loop source was available and the generic fallback assumes none. Under the manager assumption a peer persona is not plausible. Both return if you tell me the loop or the relationship differs | Ask the recruiter; see the upgrade menu |

## Question banks

Highest-ROI prep: B1. It is the question you are most likely to be asked in some form, and it is aimed at the two absences you stated.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have two titles, one engineering team and events landing in the same week. Build me the next eight weeks. What do you need to know first?" | CASE | [generic] | The question asks for no claim about your past, so the guidance makes none. Clarify first: what each title needs the event to achieve, what each discipline can take on per week, and which dates cannot move. Then objective, a draft sequence, how you would judge it, the risks. Think aloud and challenge one premise politely | Scores the JD's calendar requirement (F1) as a live decision, the way a manager tests it. CASE because it asks about no past |
| A2 | "Art assets for a Thursday release are late on Tuesday. Who do you talk to, and in what order?" | CASE | [generic] | No claim about your past. Establish what is actually blocked, list the options (reduce scope, slip, ship a lighter version), name who decides, say how you would tell the other teams. Say the order out loud | Scores the cross-team coordination line (F2) without needing a past story. CASE, JD content |
| A3 | "Retention dropped after last week's event. Diagnose it." | CASE | [generic] | No claim about your past. Ask which cohort and window, what else shipped, whether the drop is one segment or all; list hypotheses; say what data would separate them and what you would do next | The JD's retention line (F7) as a live problem; stem from the Case persona |
| A4 | "An event underperformed. Run the post-event review for me: what goes in it, and who is in the room?" | CASE | [generic] | No claim about your past. Structure it: the goal the event was set, what actually happened against it, what you would conclude and what you would change, who needs to hear it. Say which numbers you would report and why | The JD's post-event review line (F3). CASE because it is a live design problem |
| A5 | "You ran a weekly content-drop calendar for one title. What changes when it is two titles and events rather than drops?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Open with the quote's own words, at its scope. Then think aloud about what you would need to find out, which is a plan and not a past. Answer slot: the JD's two-titles line makes scale the probe. If a second title or any events were yours, say which; if not, say so plainly and return to the calendar you ran | F1 is the evidence and the likeliest place scale is tested. JD because it scores the stated requirement |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would be hardest for you on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | The highest-ROI rehearsal in this pack. Choose the real one and say it plainly: "I haven't worked on a game with in-app purchases." The limit, named before it is asked: your material shows no purchase-related work, so claim none and do not imply fluency. Then a plan, said as a plan and never a past: ask to be walked through how event performance is read against revenue, ask to see past post-event reviews, and pair with whoever owns that. Follow-up one, how would you close it: repeat the plan. Follow-up two, why not hire someone who already has it: concede specifically, "that is a real gap, and I would rather you heard it from me", then return to what you did run and write. Hold the statement; never add to it | This is the objection the pack infers, from the stated absence and the JD's KPI line (F3), not one an underwriter named. JD because it scores the role's gaps; Skeptic because it is the gap question itself. Inferred, not researched, since research did not run | 
| B2 | "Your last four years were at a puzzle-game studio as an associate producer. How much of that was live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" | Say the two quotes in order, at their own scope. Answer slot: the JD's three-years line makes the split the probe. Say what the years before the calendar involved, in your own words; if they were not live-service work, say so plainly and lead with the calendar. Do not round the four years up to a live-service total | F5 is where the JD's years requirement presses. JD because it scores that requirement |
| B3 | "The role coordinates design, art, engineering and community on every update. Tell me about a time you got an update out with several of them involved." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Selection scaffold, since no sentence of yours carries this story: pick one update where at least two disciplines depended on you, and say what you needed from each and how you got it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. If asked about team size or reporting lines, the plain words are "I haven't led a team", and then how you would earn alignment without authority, said as a plan | F2 has no quote behind it, so this is the scaffold case. JD because it tests the coordination line; an open prompt, so it presupposes no event |
| B4 | "Walk me through your monthly retention presentation." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Say it at its scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD says own the review and its KPIs, so expect a probe on who produced the numbers and what decisions followed. If you built or interpreted them, or a decision followed, say what, in your own words; if the numbers came from someone else, or nothing followed, say so plainly and stay with presenting them | F3 is the gap between presenting and owning. JD content, EXP delivery |
| B5 | "Why live ops, why here, why now?" | EXP | [generic] | Your own reason, in your own words. Answer slot: give the actual reason for moving toward live operations and toward this studio; if part of the reason is that you want mobile or monetization experience, say so plainly, since the interviewer will find the seam anyway. Keep it to 60 seconds | Persona stem for the Skeptic. EXP because it tests motivation consistency; generic because no research on Saltmarsh ran |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how those retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | You gave no figure, so the slots are the four a number raises, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Where you do not know how it was counted, "I don't know how it was counted" is an honest answer. Never describe a method you did not use | F7 is a quote with nothing inspected behind it, so a prober presses here |
| C2 | "Tell me about the release checklist. What is on it, and how did QA use it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say what it covers in your own words; the pack does not supply the contents. Answer slot: the JD says manage the checklist with QA, so expect a probe on how the two of you ran it each release. If you ran it with QA, say how; if QA ran it and you only wrote it, say so plainly and stay with writing it | F4 and F8 both rest on this one sentence. JD because it scores the checklist requirement |
| C3 | "How did you decide what went into a given week's drop?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Open with the quote. Answer slot: if you made those choices, say how you decided; if someone else set the contents, or there was no decision step, say so plainly and stay with running the calendar. Name the assumption in how you chose that you would defend least, before they ask | F6 is the strongest claim, so it gets the closest read. EXP because it tests what was actually yours |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc built only from those sentences, in that order: the four years, the calendar, the checklist, the retention presentations. Then answer slot: your reason for moving to this role, in your own words; if you do not yet have a crisp one, say so to yourself now and write it before Friday | Casual openers are scored. F1 to F8 are the pool the arc draws on |
| D2 | "Written communication matters here. What do you write most, and who reads it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Name the checklist in the quote's terms. Answer slot: if you also wrote other regular things, name them and who read them; if the checklist is the main example, say so plainly and describe it | F8 is one sentence thick. JD because it scores the communication line |
| D3 | "What do you know about our games so far?" | CO | [generic] | Research on Saltmarsh did not run, so the pack states nothing about the company. Before Friday, look at both titles yourself and form one observation each about their live events, in your own words; say what you saw and what you would want to learn. Answer slot: if you have played either title, say so; if not, say so plainly | Generic by necessity; the upgrade menu says what research would add |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause, restate the question, then the two sentences you can stand behind, at their scope: the calendar and the checklist. Hold the position through two follow-ups. Concede only what is true: "I haven't led a team, and I haven't worked on a game with in-app purchases." Never reach for experience you did not state | Persona stem. F1, F4 and the stated absences are what a hold has to rest on |
| E2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: say which parts were yours and which were shared or set by others; if all of it was yours, say that and stay with the quote. Hold through two follow-ups by returning to the sentence, never by adding to it | Persona stem; F1 and F6 rest on the word ran |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A5, C3 |
| Coordinate design, art, engineering and community | A2, B3 |
| Own the post-event review and KPIs | A4, B4 |
| Manage the release checklist with QA | C2 |
| 3+ years producing live-service | B2, D1 |
| Experience running a content calendar | A5, C3, E2 |
| Comfortable with player-retention metrics | A3, B4, C1 |
| Clear written communication | D2, C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like across the two titles?" | Shows you are planning the ramp rather than waiting for one |
| 2 | "Which KPIs does the post-event review report today, and which does the team trust least?" | Points at the KPI ownership the JD names and invites a real answer |
| 3 | "What would you want me to understand about how your titles earn, and how that feeds the post-event review?" | Turns the stated gap into a ramp conversation instead of a confession |
| 4 | "How do design, art, engineering and community each hear about an update today, and where does that slip?" | Shows you think about the coordination seams before touching them |
| 5 | "How does the release checklist sit between producers and QA now, and what would you change?" | Ties to the checklist you wrote and signals diligence |
| 6 | "How will you judge, six months in, whether this hire worked?" | Gives you the manager's real bar |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team or managed people | Negative the candidate stated: "Never led a team, and never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative the candidate stated, same quote | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Owned the live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one main title and content drops. A5's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says presented, not owned. B4's slot stays inside presenting |
| Four years of live-service production | Inflated form of F5 | F5's quotes at their own scope. The limit is the pack's observation: your material gives the role and the calendar years, not a live-service total. B2's slot stays inside them |

## Sources

Provided documents: the JD text and your background note, both in your message. No dossier was present.

Searches sent, all four refused (permission to search was not granted in this session):

- Saltmarsh Games company values: refused
- Saltmarsh Games interview process live operations producer: refused
- Saltmarsh Games mobile studio strategy news: refused
- Tobias Wrenfield Saltmarsh Games Head of Live Operations: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have fed a values cheat sheet and VAL questions; both are dropped, and nothing about their values is stated here |
| 2. Saltmarsh Games interview process, producer roles | unavailable | Would have named the real rounds and set persona weights; weights rest on the hiring-manager assumption and a generic loop |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have fed a CO or CASE question on their current strategy; D3 is generic instead |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have fed an interviewer read and a reverse question tied to his career path; both are absent |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search the web → values and VAL questions, the real loop, a strategy-grounded CO or CASE question, and an interviewer read for Tobias. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) could follow once searching works
- Whether Tobias is your future manager, a skip-level or a peer → reweights every bank
- The recruiter's prep email, or any stated focus areas → coverage of any announced deliverable or topic
- A sample of the content calendar, with anything confidential removed → F1 and F6 could move from medium toward high
- Your own answers to the answer slots in F1, F2, F3, F5 and F8 → those rows upgrade from slots to story-mapped guidance
- Any interviewer profile or talks of Tobias's that you already have → persona adjustments and a reverse question tied to his own path
- A tuesday-dossier.md from an earlier session, if you have one → a named highest-ROI objection and any claims already ruled out, in place of the inferred ones here
