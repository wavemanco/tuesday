Search was denied, so I'm building the pack from what you've told me. It's a loop-mode pack because you have three scheduled rounds. I'm writing the file now.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-6-denied-458feb74/larkfield-systems_engineering-manager_interview_pack.md`.

I built it from your message alone. Web search wasn't permitted, so nothing in it comes from research on Larkfield. It has no values cheat sheet, no company-strategy questions and no read on the interviewers. It has one shared fit snapshot, then a mini-pack per round (11, 11 and 8 questions, each with its own reverse questions), a prep triage, and a prohibited-claims list.

- **Tuesday (Director):** the hardware gap is the highest-ROI prep, question 1A1. Open with "I've never owned a hardware-adjacent roadmap", then give a plan, and add no past to it.
- **Thursday (panel):** staff engineers will probe the 60%, most likely as "was it just a quiet quarter?" (2B2). Your sentence says on-call burden dropped *after* the reliability quarter, not *because* of it, so hold it at that.
- **Monday (VP):** "I've never managed managers" is the probe to expect (3A4). Acknowledge it plainly and give your thinking as a plan.

I left four things out because your material doesn't support them:
- Any claim of leading two squads or 11 people.
- Owning delivery.
- Causing the 60% drop.
- Making about 40 hires, since your sentence counts interviews.

Say the word and I'll play the Skeptic on 1A1, the question the pack names as Tuesday's highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would reshape it:
1. Has the recruiter given any focus areas, or any exercise or presentation, for Thursday or Monday?
2. Do you have the full job description text? I worked from the five lines you pasted, and anything beyond them would add questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Loop mode: one shared fit snapshot, then a mini-pack per round.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (hiring manager, your would-be boss) | 45 min | Hiring manager |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min | Panel: technical peers plus a cross-functional partner |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level, values-style |

Built on: your message only (role description, round schedule, background). No interviewer names, no full job description, and no web research ran. Everything about Larkfield beyond your role description is absent, not guessed.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words.
- Type key: VAL = behavioral or values alignment. EXP = work-experience deep-dive (do your claims survive scrutiny). JD = role or job-description driven. CO = company and strategy knowledge. CASE = a live problem from the actual role.
- Provenance: grounded means traceable to something you or the role description said, inferred means derived from it, generic means a role-family pattern with no claim about you or Larkfield. Where guidance rests on your own words, the sentence is quoted in the Provenance cell.
- Answer slot: an instruction for the interview, not a question for me. It names a probe the interviewer is likely to make, then two honest branches. Either branch is a good answer; the second one is allowed to be "that did not exist" or "that was not mine".
- Question IDs: first digit is the round, then the persona letter, then the number (1A1 is round 1, persona A, question 1).

## Prep triage

Two weeks, three dates. The few things done well, in order:

1. Before Tuesday: rehearse 1A1 (the hardware probe) until it is boring. Then 1C1 (the 60%) and 1C2 (the 40 interviews), saying aloud what you can and cannot say about how each figure was counted. Then the 1D1 arc.
2. Before Thursday: 2B2 (the quiet-quarter challenge), 2A1 (product versus reliability), 2A3 (how your loop is set up).
3. Before Monday: 3A4 (leading through other leaders), 3B2 (how much was you), 3A1 (your philosophy in two sentences).
4. This week, one email: ask the recruiter for the interviewers' names and any focus areas or exercise for Thursday and Monday. It is the cheapest upgrade in the menu.

Everything else is insurance.

## Shared fit snapshot

Requirements are quoted from the role description you pasted. Evidence is your own words, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, with nothing inspected behind it: not two squads, and not device management. The words stay at that scope: "I've been a team lead of 6 for 3 years." Answer slot: the description's device-management services make a probe on the step up likely. If any of your team's work was close to device management, say how, in your own words; if none was, or it was not yours, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" — hiring clause — role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on the 40. Lead with the loop in the quote's own terms: you run the hiring loop for backend roles. The figure raises four slots (how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours), and the sentence counts interviews, not hires |
| F3 | "own delivery, hiring and growth for 11 engineers" — growth clause — role description | none given | none | [grounded] | discovery | Your material is silent on developing engineers, and silence is not an absence. Answer slot: the description's growth clause makes a probe on how you develop engineers likely. If you have coached or developed anyone, say what you did, in your own words; if there was no such work, or it was not yours, say so plainly and stay with the team of 6 |
| F4 | "own delivery, hiring and growth for 11 engineers" — delivery clause — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your material says you pushed a reliability quarter through against roadmap pressure and that on-call burden dropped 60% after. It does not say you owned delivery, and it says after, not because. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the delivery clause makes a probe on who set the dates likely. If delivery dates were yours to commit, say how you decided; if they were not yours, or there was no such step, say so plainly and stay with the quarter |
| F5 | "partner with hardware and product on roadmap" — hardware half — role description | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Your sentence speaks to owning such a roadmap; the wording stays at owning. No slot and nothing added to make the gap feel smaller |
| F6 | "partner with hardware and product on roadmap" — product half — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Roadmap pressure is not partnering with product, and the bridge should not be stretched. Answer slot: the description's product half makes a probe on how you worked with product likely. If you worked with product on what the roadmap held, say how, in your own words; if the pressure came from elsewhere, or there was no such partnering, say so plainly and stay with the quarter |

### Requirement coverage

| Requirement | Rows | Covered by |
|---|---|---|
| Lead two squads building device-management services | F1 | 1A3, 1B2, 1B3, 2B3, 3C1 |
| Own delivery | F4 | 1B1, 1B3, 2B1, 3B2 |
| Hiring (11 engineers) | F2 | 1C2, 2A3 |
| Growth (11 engineers) | F3 | 1A4, 2D2, 3A3 |
| Partner with hardware on roadmap | F5 | 1A1, 1A2, 2A2, 2A4, 3B1 |
| Partner with product on roadmap | F6 | 2A1, 2C2, 2D1 |
| Industrial IoT context | none | 1D2, 3C1 |

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps | High. The hiring-manager prior is Case plus Skeptic; I put Skeptic first because your own message states two negatives, and a manager de-risking a hire presses on stated gaps before anything else | Rehearse the single most predictable objection until it is boring; plain acknowledgment plus a plan; never bluff a competency the interviewer owns |
| Case/Strategist | Live problems from the actual roadmap | High, second. Hiring-manager prior; this person is buying capability, and the role is defined by delivery across hardware and product | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Asks how the figures were counted | Medium. Two figures in your message each raise a defend-the-number probe whoever asks, so the questions are in the bank regardless of this interviewer's style | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| Conversational | Friendly opener, biography and motivation | Low to medium. A 45-minute round usually opens with the journey, and casual questions are still scored | A 90-second arc built only from your own sentences; treat "why this role" as scored |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "I don't see hardware in your background. How would you handle the hardware partnership in this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in round 1. Open with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: what you would ask the hardware partners first and what you would want to learn before committing to dates, in your own words. Expect two follow-ups, usually the first 90 days and then what you do when hardware misses a date. Hold the plan, concede specifically what you do not yet know, and add no past to it. No answer slot: a gap you have stated gets the acknowledgment and a ramp plan, not a bridge | F5 is the stated gap and the likeliest place a hiring manager de-risks. JD because it scores the partnership requirement. It is named the highest-ROI prep because it will be asked in some form, and a calm, specific answer changes the room |
| 1A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Name the weakest part that is true. Your material states two negatives and either could be your answer, but the role description lists no manager requirement, so the hardware one is the one it raises. Say it plainly, then what you would do about it as a plan. Do not invent a third weakness to seem balanced | F5 again, in the Skeptic stem that tests honest self-assessment; JD because it scores fit to the listed role |
| 1A3 | "You've been a team lead of 6. This is two squads and 11 engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say what your material carries, at its scope: "I've been a team lead of 6 for 3 years." The step up is the interviewer's point, so concede it before they do: it is more people and two squads. Answer slot: the description's two squads make a probe on how you would split your attention likely. If any of your work already crossed more than one team, say how, in your own words; if not, say so plainly and say what you would do first | F1 is the evidence for the squads requirement and the second-likeliest probe; JD because it scores the stated scope |
| 1A4 | "Tell me about an engineer you've helped grow." | JD | [generic] | Selection scaffold, because your material carries no such story: pick one person, with a named starting point, something you did, and where they are now, each in your own words. If no such person comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | F3 is silent, so this is the discovery row turned into a rehearsal. An open prompt whose theme is the description's growth clause; JD because it scores that clause |
| 1B1 | "Hardware tells you a firmware release your squads depend on slips six weeks. It's Tuesday. What do you do this week?" | CASE | [generic] | Clarify before you structure: what in the plan actually depends on that date, who is committed to what, how firm the new date is. Then objective, options, who needs to hear what from you and when, and the risk of each. Think aloud and challenge one premise respectfully, for example whether six weeks is the real number. The question asks about no past, so the guidance makes no claim about yours | F4 and F5 meet here: delivery across a hardware dependency. CASE because it is a live problem; generic because it is a pattern, not a fact about Larkfield |
| 1B2 | "You take over two squads you didn't hire. What do you do in your first 90 days?" | CASE | [generic] | Say what you need to learn before changing anything, who you meet first, which commitments you inherit, what you would measure, and what you would deliberately not change yet. A plan in the future tense, with no past claimed | F1 and F4: the role's scope, tested as a plan. Hiring managers use this to see judgment about sequencing |
| 1B3 | "A fleet of deployed devices starts failing firmware updates after a release. How do you diagnose it, and what do you ask your squads?" | CASE | [generic] | Clarify scope first (which devices, what changed, how many). Then structure the diagnosis and the questions you would put to your squads. You are scored on structure and on the questions, not on knowing firmware: if you hit a term you do not know, say so and ask | F1 and F4 for a manager of device-management services; F4 is where your material is closest. Generic because the scenario is a pattern |
| 1C1 | "Walk me through that 60% drop in on-call burden. How was it counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say it in the sentence's own words: on-call burden on my team dropped 60% after I pushed a reliability quarter through against roadmap pressure. The sentence says after, not because; keep it that way. Answer slots, all in your own words. How it was counted: say what was counted, or say plainly you do not know how it was measured. What it is sensitive to: say what would move the figure most. Weakest assumption: name the assumption behind it you would defend least, before they do. Which part was yours: say what was yours and what was the team's; if the drop had other causes, say so plainly | F4 is your headline figure, and headline figures are what probers go to first. EXP because it tests attribution honesty |
| 1C2 | "You run the hiring loop for backend roles, about 40 interviews last year. What was your part in those?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say what the sentence says: I run our hiring loop for backend roles, about 40 interviews last year. The sentence counts interviews, not hires, so do not convert it. Answer slots, in your own words. How the 40 was counted: say, or say plainly you do not know. Which part was yours: say what you did within those interviews; if the loop's structure was set by someone else, say so plainly. The assumption you would defend least: name it before they do | F2 is a figure, and a figure raises its defend-the-number probes. EXP because it tests what was actually yours; it also carries the hiring requirement |
| 1D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc built only from your sentences, in your own words: nine years in engineering, three as a team lead of 6, currently at a payments company. Then two things you can point to in their own words: the hiring loop you run and the reliability quarter. Close on why this role: your material carries no reason, so say your own | F1, F2 and F4 supply the beats; nothing beyond them is added. EXP because it is the biography question; conversational delivery |
| 1D2 | "Why industrial IoT, and why Larkfield, and why now?" | CO | [generic] | Your material carries no reason for the move, and no research on Larkfield ran, so none is supplied. Give your own reason in two or three sentences. Name only what the role description lets you say: device-management services, two squads. Ask rather than assert anything about the company's strategy. Test it: if a second "why" would stump you, the reason is not ready | Motivation consistency is scored in every hiring-manager round. CO because it tests homework depth; generic because the company research did not run |

### Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does a strong first six months look like for these two squads, and what would you most want changed by then?" | It tells you the scoring sheet your would-be boss is using, and it shows you think in outcomes |
| R1.2 | "Where do hardware and software commitments collide most in the roadmap today, and how has that been handled so far?" | It turns the gap you have stated into a question about how the organisation already works, and shows how much ramp support exists |
| R1.3 | "Of the 11 engineers, is anyone already acting as a lead, and who is looking for their next step?" | It tells you whether this role involves leading leaders, and signals you think about growth |
| R1.4 | "What has been hardest for these squads to deliver on over the past year?" | It asks for the real delivery problem rather than the pitch, and tells you what you would inherit |
| R1.5 | "What would make you say, a year from now, that this hire was a mistake?" | It surfaces the Director's actual fear while there is time to address it, and rapport-style interviewers weight this slot as a preparation signal |

## Round 2: Thursday, panel of two staff engineers and a product manager, 60 min

Names unknown. The persona assignment below is per role, not per person; if names arrive, reassign.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", collaboration scenarios | High. Staff engineers are technical peers and the product manager is a roadmap partner in the role itself; the panel rule blends the top two personas of each member's relationship | Reciprocity framing: what you bring their team, not just what you need; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Reads the claims for depth; technical follow-ups | High, second. Staff engineers fall under the technical-specialist prior, and your reliability figure is the natural place to dig | Know what you can and cannot say about each figure; say plainly where your knowledge ends; do not bluff domain depth |
| Values/Behavioral | Scenario probes, often from outside the function | Medium. The product manager is cross-functional, and the cross-functional prior is Values plus Conversational | Pick a story where one of your sentences carries it; where none does, a selection scaffold with the honest branch |
| Conversational | Friendly, casual-register questions that are still scored | Low to medium. A 60-minute panel usually has warm-up and working-style questions | Treat casual questions as scored; keep answers economical |

Pressure is left out of this round: nothing about these three roles points to it, and the Monday round has it.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Product wants a feature this quarter; your squads say the platform needs reliability work first. How do you and I settle it?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Live-problem structure first: clarify what each side is protecting and what waiting costs, who decides, what you would propose. Offer seam principles rather than a verdict. If you reach for your own case, use only what the sentence carries: I pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Answer slot: a probe on how that disagreement ran is likely. If you negotiated with product, say how it went and what you gave up, in your own words; if the pressure came from elsewhere, or it was not negotiated, say so plainly and stay with the quarter | F6 is the product half of the partnership requirement, and F4 is where your material is closest. CASE because it is a live problem in the role |
| 2A2 | "Hardware moves a date for a device-management feature we both depend on. What do you need from me, and what do I get from you?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Reciprocity first: what you would give their team, before what you need. Say you would propose seam principles rather than claim to know the seam today. If they press on hardware depth, the plain acknowledgment is: "I've never owned a hardware-adjacent roadmap." Then the plan, in your own words | F5 in a peer register: the objection from the Thursday panel is collegial, not adversarial. CASE because it is a live seam problem |
| 2A3 | "You run the hiring loop for backend roles. How is it set up?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say what the sentence says: I run our hiring loop for backend roles, about 40 interviews last year. Answer slot: a probe on the loop's structure is likely. If you set its structure, say how, in your own words; if it was set by someone else, or there was no fixed structure, say so plainly and stay with the loop you run | F2. The staff engineers would be interviewing alongside you, so they are pricing what you cost and add to their loops. EXP because it tests what was yours |
| 2A4 | "A device in the field misbehaves and nobody can tell whether it's the firmware or our service. Who owns finding out?" | CASE | [generic] | Clarify what is known. Then a principle: one owner for the investigation regardless of cause, both teams in the room, root cause decided after the investigation starts, not before. Say honestly that you would ask the staff engineers where the real boundary sits | F1 and F5: the seam between software and hardware. Generic because the scenario is a pattern |
| 2B1 | "Walk me through that reliability quarter: what was in it, and what was it traded against?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The sentence names the quarter and the pressure and nothing about its contents. Answer slots, in your own words. What was in it: if you chose the contents, say how you chose; if someone else set them, or you do not remember, say so plainly. What it was traded against: say what roadmap work waited; if you cannot say, say so. Do not add a technical detail you could not repeat on a second question | F4. Staff engineers probe the substance behind a headline figure. EXP because it tests what the claim rests on |
| 2B2 | "How do you know the 60% wasn't just a quiet quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in round 2. Hold the sentence: dropped after, not because. Concede what you cannot show, in your own words. What it is sensitive to: say what would move the figure. The assumption you would defend least: name it. Which part was yours: say what was yours and the team's. How it was counted: if you do not know, say "I don't know how that was counted" rather than reconstruct it. Never answer a causation challenge by asserting a causation the sentence does not make | F4 is the claim a skeptical technical panel goes after, and this is the exact form it takes. EXP because it scores attribution honesty |
| 2B3 | "What do you think makes device-management services hard to run reliably?" | JD | [generic] | The staff engineers are scoring whether you can hold a technical conversation and whether you bluff. Your material shows no device-management work, so reason out loud from what you do know and mark the edge: "I haven't run this; here is what I'd ask you." Name two or three questions you would put to them, in your own words | F1. JD because it scores the stated domain; generic because no research on Larkfield's stack ran |
| 2C1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer impact, the metric, and what you chose, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The product manager is the likeliest source of a customer-first probe. VAL because it scores behavior against a value; no published values were available, so the theme is the persona's stem |
| 2C2 | "Tell me about a time you and a partner team wanted different things." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The theme is the role's partnership requirement. If the reliability quarter fits, its beats are only those the sentence states. Answer slot: what the other side wanted and how it ended, in your own words; if the pressure did not come from a partner team, say so plainly and pick another time or say none comes to mind | F6 again, as a behavioral prompt. VAL because it scores how you work with partners; it overlaps 2A1 on purpose, since panel members compare notes |
| 2D1 | "How do you like to work with a product manager week to week?" | JD | [generic] | Describe your habit in your own words: what you would share with product and when. Your material carries no such practice, so offer principles, not a claim about a past partnership | F6. Conversational register, scored on communication economy |
| 2D2 | "What part of managing engineers do you find hardest?" | JD | [generic] | Pick the one that is true, say what you do about it, and stop. Nothing is supplied for you | F3's theme in a casual register. Scores honest self-assessment |

### Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | To the staff engineers: "What is the one thing about how these squads work today that you would most like a manager to change?" | It asks the people closest to the work for the real friction, and tells you what you would inherit |
| R2.2 | To the product manager: "Where do engineering and product disagree most often, and how does it usually get settled?" | It tests the partnership requirement from the partner's side |
| R2.3 | "What do you wish an engineering manager understood about these services within a month of arriving?" | It signals humility about the domain gap, and the answer is a free syllabus |
| R2.4 | Reciprocity: "What could a new manager do in the first month that would genuinely help your work?" | It frames you as a contributor to their work, not only as a candidate; the panel includes peers |
| R2.5 | "How does on-call work for these services today?" | F4 is where your material is closest, so the question puts you on ground you have stated, and the answer tells you what the burden looks like |

## Round 3: the following Monday, VP Engineering, 30 min ("values and leadership philosophy")

The description comes from the recruiter, as you relayed it. Larkfield's published values were not available, so there is no values cheat sheet; the theme comes from the recruiter's words and the persona stems.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on how you lead and what you stand for | High. The recruiter's description names values and leadership philosophy, which overrides the skip-level prior of Case plus Pressure | Where one of your sentences carries a story, map it; where none does, a scaffold with the honest branch; "we" for context, "I" for contribution |
| Pressure | Time-boxed, devil's-advocate, tests composure | Medium. The skip-level prior includes Pressure, and 30 minutes forces time-boxing | Pause, restate, anchor in what you actually stated, hold a challenged position through two follow-ups before conceding anything real |
| Case/Strategist | Altitude questions about running engineering for this kind of business | Low to medium. The skip-level prior has strategy-heavy cases, lowered here because the round is short and values-led | Clarify, structure, say where your knowledge ends |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "What's your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your material carries no philosophy, so state yours in one or two sentences in your own words, then pick the story that shows it. The one story your material carries is the reliability quarter; if it fits what you just said, its beats are only: I pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. If it does not fit, pick another or say none comes to mind. Answer slot: if asked who pushed back or what it cost, say in your own words; if that was not so, or you do not remember, say so plainly | The recruiter named this round's theme. F4 is the one candidate story. VAL because it scores whether behavior matches the stated philosophy |
| 3A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the values round. Generic because your material carries no such story |
| 3A3 | "How do you grow engineers, and what changes with 11 instead of 6?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say how you do it in your own words; your material carries nothing on how. Answer slot: the growth clause makes a probe on what you have done likely. If you have developed engineers, say what you did; if there was no such work, or it was not yours, say so plainly and say what you would do. On 11 versus 6, concede the step before they do: I've been a team lead of 6 for 3 years | F3 and F1. VAL because leadership philosophy shows up as how you develop people |
| 3A4 | "I don't see anyone managing managers in your background. How do you think about leading through other leaders?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in round 3. Plain acknowledgment first: "I've never managed managers." Then your thinking, as a plan and in your own words: what you would want to learn first. Do not describe leading leaders as something you have done. If asked whether the role expects it, ask rather than assume; the role description lists no such requirement | A skip-level VP asks about altitude, and your own message states this negative. VAL because it scores honest self-assessment inside a leadership conversation |
| 3B1 | "Sixty seconds: why you over someone who has run a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause and restate the question. Concede what your sentence says: "I've never owned a hardware-adjacent roadmap." Then hold what your material carries, each in its own words: a team lead of 6 for 3 years, the hiring loop you run, the reliability quarter. Hold through two follow-ups by returning to those sentences, never by adding. Do not claim you would be better; say what you bring and let the interviewer weigh it | F5 is the stated gap, and F1, F2 and F4 are the holds. JD because it scores fit; Pressure delivery |
| 3B2 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence: I pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after. Concede in your own words. Which part was yours: say what was yours and what was the team's; if the drop had other causes, say so plainly. Hold through two follow-ups by returning to the sentence | F4. EXP because it tests attribution; the pressure persona's stem, with hold-then-concede |
| 3C1 | "What do you think is different about running engineering for devices in the field versus a service that lives entirely in a datacenter?" | CASE | [generic] | Clarify first, then say what you know and what you do not. Your material shows no device work, so mark the edge honestly and ask the VP what they would want a new manager to learn first. No claim about Larkfield is made | F1. Altitude question; generic because company research did not run |
| 3C2 | "If you had to drop a third of what two squads plan this year, how would you choose?" | CASE | [generic] | State the criteria first, who you would involve, and what you would tell the people whose work was cut. A plan in the future tense, with no past claimed | F4's delivery clause as a strategy question. Scores structure and the willingness to say no |

### Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does leadership look like at its best here, and where do you see it slipping?" | It speaks to the round's theme and asks for a candid answer |
| R3.2 | "How do you expect the engineering organisation to grow over the next two years, and what does that mean for someone in this seat?" | It addresses the leading-leaders question from your side without raising it as a weakness |
| R3.3 | "How do hardware and software priorities get balanced at your level?" | A strategy-altitude question that shows you understand the role sits on that seam |
| R3.4 | "What would you want an engineering manager here to be known for across the company?" | It asks the VP to define success, and the answer is your target |
| R3.5 | "What is a decision engineering leadership made recently that you would make differently now?" | A candid-leadership question that fits a values round; skip it if the room is tense |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |
| Managed managers | Negative you stated: "I've never managed managers and never owned a hardware-adjacent roadmap" | The plain acknowledgment: "I've never managed managers." No slot |
| Led two squads or a team of 11 | Inflated form of F1 | F1's quote at its own scope: a team lead of 6 for 3 years. The limit is the pack's observation: your material says a team of 6, not two squads |
| Owned delivery | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says you pushed a quarter through, not that you owned delivery. 1B1 and 2B1 keep their slots inside the quarter |
| Caused the 60% drop | Inflated form of F4 | F4's quote at its own scope: the sentence says dropped after, not because. 1C1, 2B2 and 3B2 hold the sentence and put the rest in slots |
| Made about 40 hires | Inflated form of F2 | F2's quote at its own scope: the sentence counts interviews, not hires. 1C2's slots stay inside the loop you run |
| Has worked with hardware teams | Inflated form of F5, which the sentence contradicts | The acknowledgment above, and nothing more |

## Sources

Provided documents: your message (role description, round schedule and descriptions, background). No `tuesday-dossier.md` was present. The three-session loop and who runs each are established by your own words, so no archetype fallback was used. The recruiter's description of Monday is as you relayed it.

Searches sent, all refused by the host (permission not granted):

- `Larkfield Systems industrial IoT values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems strategy news device management` — refused
- `Engineering Manager device management IoT platform job description` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet and mapped stories for Monday; absent, the Monday questions rest on the recruiter's description and persona stems |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked the loop structure; your own words already fix the three sessions, so persona weights stand |
| 3. `Larkfield Systems strategy news device management` | unavailable | Would have grounded a CO question; the CO and CASE questions are labelled generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | unavailable | Would have added role-family requirements as inferred rows; the snapshot rests on your role description alone |

## Upgrade menu

- The three interviewers' names → an interviewer read per round, persona weights tuned to their public footprint, and a reverse question tied to each person's path
- The full job description text → any requirement beyond the five lines you pasted (named tools, stack, methodology) becomes a JD-tagged question, and the coverage table gets checked against the real list
- The recruiter's prep guidance, including any exercise or presentation for Thursday or Monday → a build section for each declared deliverable and a better-aimed Thursday panel
- Larkfield's published values page, or a host that allows search → a values cheat sheet for Monday with a mapped story per value, and company-specific CO questions in place of the generic ones
- Your answers to the answer slots, said outside a drill → F2, F3, F4 and F6 upgrade from slots to quoted evidence and the guidance regenerates; the paging or on-call report behind the 60% would raise F4 from medium to high
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, needs search permission → a strategy brief, the interviewers' public talks and writing, and role-family loop reports
- A `tuesday-dossier.md` from earlier underwriting of this role → verified evidence upgraded to grounded story maps and a sharper prohibited-claims list
