Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-8-canned-4e187d52/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop pack. It has one shared fit snapshot, then a question bank and reverse questions for each round, and the four-value cheat sheet sits with the panel round. I ran no searches, because your pasted values, strategy summary and the recruiter's email already covered what research would have found. No interviewer names are assigned, so the pack has no interviewer read.

The pack names D2 as your highest-ROI prep. D2 is the question "Your last three years were as a branch supervisor, and you haven't worked in a contact centre. What makes you think you can own the complaints process across both?" Your material says you've never worked in a contact centre, and the role names it.

Say the word and I'll play the Skeptic on D2, with live follow-ups and feedback against that question's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview pack for Dara

Three rounds on 29 November 2026, built as a loop pack: one shared fit snapshot, then a mini-pack per round. No interviewer names are assigned yet, so there is no interviewer read and the persona weights rest on round type and the recruiter's own description of each round.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Not described further |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | Includes "a 20-minute case on a complaint escalation"; "also the values round — they score against the four values" |

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding to rehearse from, not a script.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behaviour demonstrates Ashgrove's published values |
| EXP | Whether what you have said about your work survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Ashgrove's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Three things to know before you start:

- An answer slot is an instruction for the interview. It asks nothing of you here. Answer it from your own experience, or say plainly that the practice was not yours.
- Each Provenance cell holds the sentence of yours that its guidance rests on. If the guidance says something about your past, the quote is the limit of what you may say.
- Question IDs run A to J across the whole loop, so a drill or a note can point at one.

## Prep triage

Nine days to 29 November, and all three rounds fall on that one day. The few things done well, in order:

1. D2 (round 2), the highest-ROI rehearsal in this pack. Say the answer aloud until it is boring.
2. Write down, in your own words, your answer to each answer slot in C1, C2, E1, E3 and G4, then check each one is what actually happened.
3. For round 3, choose one real story for each of the four values (G1 to G4), or decide honestly you have none for that value yet.
4. Before round 1, settle your own answers on pay, notice, location and reason for moving (A3, A4, B3, B4). The recruiter comes first on the day.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says a branch's formal complaints log and training on an escalation script, not the process across branches. Words at that scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's end-to-end line makes a probe on how far your part reached beyond your own branch likely. If any of it did, say how, in your own words; if it did not, say so plainly and stay with the branch's log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses, with nothing inspected behind it, and does not show what it held. Words at that scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what the spreadsheet counted or timed likely. If it counted or timed anything about complaints, say what and how, in your own words; if it did not, say so plainly and describe what it did hold |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not supervisors. Words at that scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on anyone beyond new tellers likely. If you worked through escalations with anyone else, say who and what, in your own words; if you did not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show whether this exists. Answer slot: the JD and the strategy brief both press on digital, so expect a probe. If you have worked with any digital or technology team on how members do things without a counter, say what and which part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | A length-of-experience line, not a gate. Your sentence already reaches it in other terms. Words, rewording only the quote: "I have six years in retail banking, the last three as a branch supervisor." Expect the probe to be what branch supervision covered; answer it from what you did |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal complaints log and does not show what governed it. Words at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's line makes a probe on what the log operated under likely. If it carried rules, deadlines or reporting that came from outside the branch, say what and how they shaped your handling; if it did not, say so plainly and describe how the log worked |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past. Never a claim to senior-level presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Your sentence reaches the requirement in other terms. It says spreadsheet, not Excel, so the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Nothing about features, size or skill is added |

No requirement in the JD is a gate: the 4+ years line is length of experience, and nothing else is a licence, location, schedule or pay term. Row F6 is graded like any other row.

## Grounding brief

Four points from the 2026 strategy brief Ashgrove published in July 2026, as you gave them. Your pasted summary is the source, and the full brief has not been read.

| Point | What it could mean for your answers | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | Raises F5 and the self-service line in the JD. Expect F2 in round 2 and a digital angle in the round 3 case | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Sits beside the value "Neighbours, Not Numbers — every branch is part of its town." A panel of branch managers may have branches in scope, which the material does not say. See J1 | [inferred] |
| Launch a small-business lending product in Q1 2027 | Probably not central to a complaints role. Know it exists, and do not stretch your answers toward it | [inferred] |
| Main competitive pressure is app-only banks | Gives a reason for self-service journeys and for plain, fast complaint handling to matter to members | [inferred] |

## Round 1 — the recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, with logistics tucked in | High. The recruiter screen prior is Conversational plus a light Skeptic, and the recruiter named no focus areas | Have a 90-second arc ready; treat casual questions as scored |
| Skeptic (light) | Knockout checks on the two stated gaps, in a friendly register | Medium. Your material states two negatives (F2, F8) and a recruiter is where knockouts get checked | Say each plain acknowledgment once, then the plan, then stop |

### Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats, each a clause your sentences state: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log and trained new tellers on the escalation script; built the monthly complaints spreadsheet your regional manager uses. Tell them in your own words. Close with your own reason for wanting this role, whatever it truly is | The biography question is the most predictable opener at this round (F6); EXP because it tests what was actually yours |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Choose which published thing genuinely matters to you and say why in your own words: "Members First, Always — we decide from the member's side of the counter.", or the move of 40% of member service to digital by 2028. One reason said plainly beats reciting both. The question needs no claim about your past, so the guidance makes none | The strategy brief and values page are in hand, so a specific reason is available; CO because it tests homework |
| A3 | "What is prompting your interest in a move?" | EXP | [generic] | Logistics slot: give your actual reason in your own words. Keep it about what you are moving toward only if that is true. No reason is supplied here | The recruiter row of the persona priors names the reason for leaving; EXP because it tests consistency with the rest of the story |
| A4 | "Where are you based, and what travel could you do across branches and the contact centre?" | JD | [grounded] | Logistics slot: state your actual location and the travel you can really do, in your own words. If you are unsure what travel the role involves, ask the recruiter for the expected pattern first. No figure is supplied | The JD's own line, "across branches and the contact centre", is the raising source; JD because it scores a term of the listed job |
| B1 | "You haven't worked in a contact centre. How would you get up to speed on one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly once: "I haven't worked in a contact centre." Then a plan in the future tense: what you would do in the first weeks to learn how complaints reach and leave it. Never describe contact-centre work as a past | F2 is the first knockout a recruiter checks; JD because it scores the stated requirement, with Skeptic delivery |
| B2 | "The role asks for confidence presenting to senior leaders. Have you done that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. Stop there. Round 2 goes deeper (D3) | F8 is the second stated negative, and this is a recruiter-register check on it; JD because it is a listed requirement |
| B3 | "What are you looking for in salary terms?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. Do not state current or past pay; you can decline that question politely and move to what you are looking for. No figure is supplied here | The persona priors list pay as a recruiter-screen logistics item; JD because it scores a term of the listed job |
| B4 | "What is your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period and earliest start, in your own words. No figure is supplied here | The persona priors list notice as a recruiter-screen logistics item; JD for the same reason as B3 |

### Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Who will be on the panel in the third round, and can you tell me anything about the case format?" | Names are unassigned today, and an answer lets this pack gain an interviewer read and tune the case bank |
| R1.2 | "What does the process look like after the panel, and when would you expect a decision?" | Plain, expected, and it ends the call on logistics rather than silence |
| R1.3 | "How is the contact centre set up, and who would I work with there day to day?" | Turns your biggest stated gap (F2) into diligence, and shows you are thinking about it |
| R1.4 | "Is there anything in my background you would like me to cover more fully with Head of Member Services?" | Rapport-style interviewers weight the closing slot heavily; this invites a pointer without asking for a verdict |
| R1.5 | "Which part of this role do you hear most about from the hiring team?" | Surfaces the recruiter's read of priorities, which feeds the weights for rounds 2 and 3 |

## Round 2 — Head of Member Services (your manager), 45 minutes

### Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" scenarios, STAR-shaped | Highest. The recruiter described this round as "mostly behavioural" | Map a story to each prompt only where one of your sentences carries it; otherwise use the selection scaffold and its honest branch |
| Skeptic | Quiet, persistent probing of the two stated gaps | Medium. A hiring manager is buying capability and weighing gaps, and your material states two (F2, F8) | Rehearse D2 until it is boring; plain acknowledgment, then a plan |
| Data-Driven Prober | Line-by-line questions on what you did and what was yours | Lower. The only artifacts in your material are a log and a spreadsheet, which draw walk-throughs, not figures | Say what was yours and what was shared, in your own words |
| Case/Strategist | A live problem from the role | Lower in a behavioural round, but the manager prior includes it | Clarify before structuring; think aloud |

### Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about the formal complaints log you handled. What made a complaint formal?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7: you handled the branch's formal complaints log, which is the beat the quote states; tell it in your own words. Answer slot: if the log carried rules, deadlines or reporting that came from outside the branch, say what and how they shaped your handling; if it did not, say so plainly and describe how the log worked. Do not add to "handled" | F7 is where the JD's complaints requirement presses hardest on your material; EXP because it tests what was actually yours |
| C2 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: you trained new tellers on the escalation script, at that scope. Answer slot: if you worked through escalations with anyone other than new tellers, say who and what, in your own words; if you did not, say so plainly and stay with the tellers | The JD asks for coaching on escalations (F4); an open prompt whose theme comes from the JD, so JD is the call |
| C3 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a moment that has a named stake, a point where you did not fold, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural prompt for a manager round; VAL because it scores whether the hard truth actually landed |
| C4 | "Tell me about a complaint that had to be escalated, and what happened next." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Pick one real case; the structure is what it was, what you did, what happened after, and what you would change. Your sentence carries the log and the escalation script, not any particular case, so choose the case yourself. If no such case comes to mind, say so plainly, then say how the log handled escalations or how you would | The JD makes escalation central (F4); EXP because it asks you to choose an instance |
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of your two stated gaps (F2 or F8) and say it plainly in your own words, then give the plan. Calibrated candour beats a bluffed strength. The honest choice is yours | A persona stem the Skeptic asks, and the answer your material already limits |
| D2 | "Your last three years were as a branch supervisor, and you haven't worked in a contact centre. What makes you think you can own the complaints process across both?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Limit first: your material says a branch's formal complaints log and training, not the process across the contact centre. Concession in exact words: "I haven't worked in a contact centre." Then the hold, only what your quotes carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then the plan: how complaints reach and leave the contact centre is the first thing you would learn. Two follow-ups to rehearse: how you would earn credibility with a team that already does this work, and what you would do if the contact centre's numbers disagreed with the branches. Hold through both by returning to the log, never by adding to it | F2 is the most predictable objection to this candidate: the role names the contact centre and your material says never; JD because it scores the stated requirement, with Skeptic delivery |
| D3 | "The role asks for confidence presenting to senior leaders, and you've said you haven't presented above regional level. How would you prepare?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan: what you would find out about the audience, what you would keep to one page, and who you would rehearse in front of. The plan is the answer; no past is claimed | F8 deepened from round 1 (B2); JD because it scores a listed requirement |
| E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3: you built a monthly complaints spreadsheet, and your regional manager uses it, in your own words. Answer slot: if it counted or timed anything about complaints, say what and how, in your own words; if it did not, say so plainly and describe what it did hold | F3 is the likeliest place to be probed on reporting; EXP because it tests what you actually built |
| E2 | "How much of the formal complaints log was actually yours?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold on your own verb: you handled it. Say which parts were yours and which were shared or someone else's, in your own words; if all of it was yours, say that plainly. Add nothing to "handled" | The attribution probe the Prober exists to ask (F1); EXP because it tests what was actually yours |
| E3 | "How comfortable are you with Excel reporting? What would you point to?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Point to the one thing your sentence carries: the monthly complaints spreadsheet your regional manager uses. Answer slot: say which tool it was; if it was something other than Excel, say so plainly and describe what you built. No features or skill level are supplied here | F9 is a listed requirement and your sentence says spreadsheet, not Excel; JD because it scores the stated requirement |
| F1 | "Complaint volumes at one branch have risen over two months. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify first: what changed, where, and how the volume is being counted. Then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully, such as whether volumes rose or the way they were recorded changed. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem of the shape this role faces; generic because it is a pattern, not a fact about Ashgrove |
| F2 | "Ashgrove wants 40% of member service on digital channels by 2028. How would you decide which complaints belong in a self-service journey and which need a person?" | CO | [grounded] | Structure it: what you need to know, how you would sort complaints, and who keeps hold of a complaint when it moves between channels. Where it helps, tie to the published value: "Own the Fix — whoever finds the problem keeps hold of it until it is solved." The question needs no claim about your past, so the guidance makes none | The strategy brief and the JD's self-service line both raise it (F5); CO because it tests strategy fluency |

### Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What does a strong first six months look like in this role?" | Gives you the manager's own scoring sheet |
| R2.2 | "Where does the complaints process work least well today, from where you sit?" | Shows you are thinking about the problem, not the title |
| R2.3 | "How are complaints reported upward at the moment, and what would you want changed?" | Connects directly to the reporting line (F3) without claiming anything |
| R2.4 | "How do you expect the move toward 40% digital service by 2028 to change the complaints that reach us?" | Uses the brief and the self-service line (F5) |
| R2.5 | "What would you want me to learn about the contact centre first?" | Turns F2 into a plan the manager can shape |

## Round 3 — panel of two branch managers, 60 minutes

### Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes scored against the four published values | Highest. The recruiter said the panel is "also the values round — they score against the four values" | Map a story to each value where your sentences carry one; scaffold where none does |
| Case/Strategist | The 20-minute escalation case | High. The recruiter named the case | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Peer Evaluator | "What would you need from me" and where the seam is | Medium. Branch managers are the people whose supervisors you would coach, which is an inference from the JD and the recruiter's description | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Skeptic | Trust and credibility probes on the stated gaps | Lower here, since the panel's scoring sheet is the values | Hold, then concede specifically |

### Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First, Always: pick a decision where a member's side and the branch's side pulled apart, a point where you chose the member's, and what it cost or changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always needs a VAL question when a values round is detected; no sentence of yours carries a decision of this kind, so a scaffold |
| G2 | "Tell me about a time you had to explain something to a member twice." | VAL | [grounded] | Selection scaffold for Plain Words: pick a moment where an explanation did not land, what you changed in the words, and how it landed the second time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words needs a VAL question; the value's own test is explaining twice, so the question uses it; scaffold because no sentence carries it |
| G3 | "Tell me about a time you weighed what a branch's numbers said against what its town needed." | VAL | [grounded] | Selection scaffold for Neighbours, Not Numbers: pick a moment with a real figure or target on one side and a real local need on the other, a choice you made, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers needs a VAL question, and it is the value the hub plan presses hardest; scaffold because no sentence carries it |
| G4 | "Tell me about a time you found a problem and stayed with it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7 and Own the Fix: you handled the branch's formal complaints log, at that scope. Answer slot: the value is "whoever finds the problem keeps hold of it until it is solved", so expect a probe on one that stayed open. If one did, say what it was and what part was yours, in your own words; if none comes to mind, say so plainly, then describe how the log kept complaints from being dropped | Own the Fix needs a VAL question; the log is the nearest sentence you have, and it carries only "handled" |
| H1 | "A member's complaint has gone from the branch to the contact centre and back, and the member now says they will take it further. You have twenty minutes: what do you do?" | CASE | [generic] | Structure aloud. Clarify first: what the complaint is, what has been told to the member and when, what clocks or rules apply, and who owns it now. Objective: stop the handoff loop and put one person in charge. Segmentation: the member, the branch, the contact centre, the record. Approach, metrics, risks. Challenge one premise, such as whether the complaint is one issue or two. No claim about your past is needed | The recruiter named a 20-minute case on a complaint escalation; the scenario itself is this pack's guess at its shape, not Ashgrove's |
| H2 | "The branch supervisor involved disagrees with your approach. What now?" | CASE | [generic] | Hold your approach on what the member needs, concede where the supervisor knows something you do not, and agree who keeps hold of the complaint. Say the disagreement out loud before resolving it. No claim about your past is needed | The JD's coaching line (F4) and Own the Fix both press here; CASE because it is a live problem |
| H3 | "Three months on, how would you know the fix held?" | CASE | [generic] | Name what you would watch: whether the same member returns, how long complaints stay open, whether the branch and contact centre tell the same story. Name one way your own measure could mislead you. No claim about your past is needed | The JD's reporting line asks for monthly volumes and resolution times; CASE because it asks you to design the measure |
| I1 | "Our supervisors are busy. How would you coach them on escalations without adding to their load?" | JD | [grounded] | Reciprocity framing: what you would bring them, and what you would ask of them, in plain terms. Propose principles for the seam rather than claiming to know it. No claim about your past is needed | The JD's coaching line (F4) seen through the peer's eyes; JD because it scores the listed responsibility |
| I2 | "Where is the seam between a branch manager and you when a complaint goes wrong, and what happens when we disagree?" | CASE | [generic] | Propose seam principles: who keeps hold of the complaint, who the member hears from, and how a disagreement is settled. Show spine and tact together. No claim about your past is needed | A Peer Evaluator persona stem; CASE because it asks for reasoning about a live seam |
| I3 | "When a fix involves a branch, the contact centre and a digital team, who gets the credit, and who carries the blame?" | CASE | [generic] | Principle first: the person who keeps hold of the fix reports on it, and credit is named by contribution. Offer how you would show that in the monthly report. No claim about your past is needed | A Peer Evaluator credit-sharing stem; ties to Own the Fix and the self-service line (F5) |
| J1 | "Eight branches are due to become five hubs over 2027. How would that change complaints, and what would you want to protect?" | CO | [grounded] | Structure it: what would change for members, what for staff, what could go wrong in handoffs. Tie to "Neighbours, Not Numbers — every branch is part of its town." The panel may have branches in scope, and this pack cannot tell, so do not assume it and do not defend the plan. No claim about your past is needed | The brief gives the consolidation; CO because it tests strategy fluency and the value it presses on |
| J2 | "Why should two branch managers trust someone who hasn't worked in a contact centre with their branches' complaints?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold-then-concede. Hold through two follow-ups on what your quotes carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede specifically: "I haven't worked in a contact centre." Never fold on the log, and never add to it. Then the plan | The pressure form of D2 in front of the people whose branches are affected (F2); JD with Skeptic delivery |

### Values cheat sheet (round 3)

Published values, from the page you pasted on 20 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a story here. Selection scaffold in G1, ending in its honest branch |
| Plain Words | If a member needs it explained twice, the words were wrong | No sentence of yours carries a story here. Selection scaffold in G2, ending in its honest branch |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence of yours carries a story here. Selection scaffold in G3, ending in its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." That is the nearest sentence, and it carries only "handled". Answer slot in G4 |

### Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "How would you want to hear about an escalation from your branch, and how early?" | A peer question about how you would work with them |
| R3.2 | "What would you most want the person in this role to do differently from how escalations are handled today?" | Gives you their scoring sheet in their own words |
| R3.3 | "How do you expect the hub plans to affect complaint handling in your area?" | Uses the brief and the value "Neighbours, Not Numbers" without assuming their view |
| R3.4 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel |
| R3.5 | "Which of the four values do you see tested most in day-to-day complaint handling?" | Shows you read the values as working tools and hands you a live example |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | D2, J2, H1, I2, E2 |
| The contact centre | B1, D1, D2, J2, A4 |
| Report monthly on complaint volumes and resolution times | E1, H3 |
| Coach branch supervisors on escalations | C2, C4, H2, I1 |
| Work with digital teams on self-service journeys | F2, I3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | C1 |
| Confident presenting to senior leaders | B2, D3 |
| Comfortable with Excel reporting | E3, E1 |
| Headline metrics on your sentences | — none, and why: none of your sentences states a figure, so no defend-the-number question is raised |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says a branch's log and an escalation script, not the process across branches. The slot in F1 stays inside the branch |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: a formal complaints log. The slot in C1 asks only what governed that log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and an escalation script. The slot in C2 asks only about anyone beyond them |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: a monthly complaints spreadsheet your regional manager uses. The slot in E1 asks only what it counted or timed |
| Has Excel reporting skill beyond the spreadsheet | Inflated form of F9 | F9's quote at its own scope: it says spreadsheet. The slot in E3 asks only which tool it was |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD for Member Experience Lead; the Ashgrove values page, pasted and copied on 20 November 2026 from ashgrovecu.org/about/values, not fetched; the recruiter's email on the three rounds; the 2026 strategy brief Ashgrove published in July 2026, as summarised in your message, with the full brief not read; your background, as stated in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: the pasted page supplies all four names and their definitions |
| 2. `Ashgrove Credit Union interview process` | skipped | Could not have moved the persona weights or the loop: the recruiter's email gives three rounds, who runs each, their length and the values round |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: the strategy brief you were sent already supplies current priorities and recent moves |
| 4. interviewer name | n/a | No interviewer names are assigned, so no query could be formed; the interviewer read is absent and the upgrade menu says what a name unlocks |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV text → the fit-snapshot rows that currently rest on your message become CV-sourced, and any line your message left out is added
- The column headings of the monthly complaints spreadsheet, with no member data → F3 and F9 can be graded against something inspected, and the answer slots in E1 and E3 get sharper
- Your written answers to the answer slots in C1, C2, E1, E3 and G4, stated outside a drill → those rows regenerate on your own words
- The interviewers' names once assigned → an interviewer read, persona weights tuned per person, and a reverse question tied to each person's path
- The recruiter's answer on the case format (spoken or written, any inputs given, how it is scored) → the H bank is tuned to the real shape rather than this pack's guess
- The full text of the July 2026 strategy brief → the grounding brief and the CO questions move from a four-point summary to the full document
- A deeper research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes) → recent organisation context and any public loop reports for this kind of role; say the word and I will run it
- A `tuesday-dossier.md` from earlier work on this role → verified evidence and prohibited claims arrive pre-graded; never required
