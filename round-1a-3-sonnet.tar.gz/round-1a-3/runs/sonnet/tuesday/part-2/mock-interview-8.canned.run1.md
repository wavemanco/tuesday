Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-8-canned-bd6b81dd/Ashgrove_member-experience-lead_interview_pack.md`.

It is built as three round-by-round mini-packs, 32 questions in all, because the recruiter's email fixes who runs each round and for how long. The interviewers' names aren't assigned yet, so there is no interviewer read. The 20-minute case in round 3 has no format yet, so G1 to G4 are practice shapes and not predictions.

I ran no web research. The values, strategy summary, JD and recruiter email you pasted already covered what a search would have added.

- **The one to rehearse most:** C1, the contact-centre objection. "I haven't worked in a contact centre" is the words your message gives for it, followed by a plan for learning that side. It is likely to come back in all three rounds.
- **Where your material is thin:** I quoted only what you wrote. Your sentences don't carry a story for any of the four values, so the values section is selection scaffolds, not mapped stories. Digital self-service work, coaching anyone above teller level, what the spreadsheet counted and which tool it was built in, and what made the complaints formal are all answer slots. The upgrade menu lists what to send me to turn those into real stories.
- **Strategy items:** the 40% digital target and the eight-branches-to-five-hubs plan feed E1 and G3. I only have your summary of the brief, not the brief itself.

Say the word and I'll play the Skeptic on C1 and push back with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Mode:** Loop — three rounds on 29 November 2026. One shared fit snapshot and sources block, then a mini-pack per round.
**Interviewers:** Round 1 the recruiter; Round 2 the Head of Member Services (your future manager); Round 3 a panel of two branch managers. Names are not yet assigned, so there is no interviewer read.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Guidance is scaffolding, not a script. Say it in your own words, and rehearse only what you actually did.
- An answer slot is an instruction for the interview, not a question for you now: answer from your own experience, or say plainly that the practice was not yours.
- **The highest-ROI prep in this pack is C1**: the contact-centre objection. It will arrive in some form in Round 1 (B2), Round 2 (C1) and, collegially, in Round 3 (G2). Rehearse it until it is boring.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether your own account of your work survives a second question |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

## The loop

| Round | Who | What the recruiter's email says | Provenance |
|---|---|---|---|
| 1 | Recruiter | "30 minutes with me" | [grounded] |
| 2 | Head of Member Services, your future manager | "45 minutes with the Head of Member Services, who would be your manager, mostly behavioural" | [grounded] |
| 3 | Panel of two branch managers | "60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. The panel is also the values round — they score against the four values." | [grounded] |

## Grounding brief

From the 2026 strategy brief Ashgrove published in July 2026, as you summarised it to me. I have not read the brief itself, so treat this as your summary of it.

| Item in the brief | Where it meets this loop | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | The JD's "work with digital teams on self-service journeys" (F5); question E1 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Questions G3 and reverse question 3 in Round 3; the value "Neighbours, Not Numbers" | [grounded] |
| Launch a small-business lending product in Q1 2027 | No bank question draws on it: neither the JD nor your material touches it. Available if a CO question arrives | [grounded] |
| The main competitive pressure is app-only banks | No bank question draws on it. Context for the digital items; A2 asks why Ashgrove | [grounded] |

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the JD you pasted. Evidence is your own sentences, quoted from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and the training of new tellers, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log". Answer slot: the requirement in this row makes a probe on what sat before and after the log likely. If any other stage of a complaint's route was yours, say which and what you did, in your own words; if the log was where your part ran, or nothing else was yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: learn how that side records and passes on complaints, from the people who do it, before suggesting changes. Never a claim to contact-centre work |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet, not what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses". Answer slot: the requirement in this row makes a probe on what the spreadsheet showed likely. If it showed volumes or how long complaints took to close, say what and how, in your own words; if it showed something else, or you do not know how the figures were counted, say so plainly and stay with the spreadsheet |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says new tellers, and "our" script, not supervisors. The words stay at that size: "trained new tellers on our escalation script". Answer slot: the requirement in this row makes a probe on whether anyone above teller level was coached likely. If you guided another supervisor or anyone senior to a teller on an escalation, say who and about what, in your own words; if not, say so plainly and stay with the new tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this requirement either way. Answer slot: the requirement in this row makes a probe likely. If you worked with anyone building or changing a digital or self-service route for members, say what it was and what part was yours, in your own words; if you did not, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe on what the supervisor years covered. Lead with the years in the quote's own terms: "6 years in retail banking, the last 3 as a branch supervisor" |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal complaints log, not what made those complaints formal or what governed the log. Words: "I handled the branch's formal complaints log". Answer slot: the requirement in this row makes a probe on what governed the log likely. If you can say what made the complaints formal and what rules the log followed, say so in your own words; if you cannot, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would build toward it, said as a plan and never as a past. Your sentence does not say what you presented at regional level or to whom, so the pack does not either |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a spreadsheet you built, not which tool. Words: "I built the monthly complaints spreadsheet our regional manager uses". Answer slot: the requirement in this row makes a probe on the tool and how you work in it likely. If you built it in the tool the interviewer names, say what it did, in your own words; if it was another tool, or you did not build all of it, say so plainly and stay with the spreadsheet |

---

# Round 1 — Recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, logistics, motivation | High. The skill's prior for a recruiter screen is Conversational plus a light Skeptic, and the email lists no focus areas | A 90-second arc for A1; logistics answered in your own words; treat casual questions as scored |
| Skeptic (light) | Quiet knockout checks on the gaps | Medium. Same prior; your own message names two gaps that a screen can check early | Concede first, then a one-line plan; B2 here, C1 for the full drill |

## Question bank

### A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. Where have you been, and why this role?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats the quotes state, in your own words: 6 years in retail banking, the last 3 as a branch supervisor; the branch's formal complaints log and training new tellers on your escalation script; the monthly complaints spreadsheet your regional manager uses. Close on why this role, from the JD's own lines, and stop. Ninety seconds in all | F6 is the years requirement a recruiter checks first; F1 and F3 supply the rest. JD content with EXP delivery, because it is the biography arc |
| A2 | "What draws you to Ashgrove specifically?" | CO | [grounded] | Name one published value and one item from the strategy brief that genuinely drew you, and say why in your own words. The JD calls Ashgrove member-owned. Do not recite the values list: one value, one reason | Motivation consistency is what a recruiter screen scores, and CO because it tests homework. The question needs no claim about your past, so the guidance makes none |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot. Say your own number or range in your own words, or ask for the role's band first and respond to it. The choice is yours and the pack supplies no figure. If asked what you earn now, you may decline politely and redirect to what you are looking for | Pay is a standard screen item. JD because it is a term of the listed job |
| A4 | "What is your notice period, and when could you start?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. If you do not yet know what your contract allows, say so and say when you will find out | Notice shapes the recruiter's timeline. JD because it is a term of the listed job |
| A5 | "Where can you work, and how comfortable are you with the role covering more than one site?" | JD | [generic] | Logistics slot. Say where you can work, in your own words, and ask where the role is based if you have not been told | The JD's "across branches and the contact centre" makes location a live topic. JD because it is a term of the listed job |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot. Give your own reason in one sentence, about what you want next rather than who you are leaving, and stop. Do not criticise your branch or your regional manager | Motivation consistency across all three rounds starts here. EXP because it tests whether your account stays the same under a second question |

### B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would be newest to you on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your own message names two: the contact centre, and presenting above regional level. Choose the one you would genuinely find newest, concede it plainly, and give one concrete first step. Do not pick a safe third answer | F2 and F8 are the two stated gaps; a screen is where they are checked first. JD because it scores the listed requirements, gaps included |
| B2 | "I don't see contact-centre work in your background. How would you get up to speed on that side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Concede in one sentence: "I haven't worked in a contact centre." Then the plan, as a plan: you would learn how that side records and passes on complaints, from the people who do it, before suggesting changes. The full drill with follow-ups is C1 | F2, the biggest stated gap, and half of the "branches and the contact centre" remit. JD because it scores a listed requirement |
| B3 | "Tell me about the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the sentence states, in your own words: it is monthly, it is about complaints, your regional manager uses it, you built it. Answer slot: the JD's reporting and spreadsheet lines make a probe on what it showed and which tool it was built in likely. If you can say what it showed and which tool, say so in your own words; if you cannot, or you did not build all of it, say so plainly and stay with the spreadsheet your regional manager uses | F3 and F9 both rest on this sentence and both are discovery rows, so the probe lands where the material is thin. JD because it scores the reporting and tool requirements |

## Reverse questions — Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Who will I be meeting in rounds two and three, and what does each of them most need from this role?" | Interviewer names and roles are not yet assigned, and the answer reweights rounds two and three |
| R1-2 | "For the 20-minute case in round three, can you say anything about the format, such as whether there is material in advance?" | The case format is the biggest unknown in the loop, and one answer settles how the CASE bank is weighted |
| R1-3 | "How is complaints work divided today between the branches and the contact centre, and who owns the process in between?" | Shows you have already read the role as end to end across both sites |
| R1-4 | "What would the first 90 days look like for the person in this role?" | Moves the conversation from screening to starting, and gives you a view of what success means to them |
| R1-5 | "What happens after round three, and when should I expect to hear?" | A practical close that shows interest and fixes the timeline |

---

# Round 2 — Head of Member Services, your future manager (45 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes, "tell me about a time" | High. The email says "mostly behavioural" | Story-map from your own sentences where one carries a story; otherwise pick an instance using the scaffold, and say plainly when none comes to mind |
| Skeptic | Persistent probing of the gaps | High. The skill's prior for a hiring manager is derisking gaps, and two are stated in your message. The single highest-ROI item sits here | Concede first, hold what your quotes carry, then a concrete plan |
| Case/Strategist | A live problem from the role's roadmap | Low to medium. The hiring-manager prior favours live problems, but the stated emphasis is behavioural | Clarify, objective, approach, metrics, risks; think aloud |

## Question bank

### D — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you coached someone through an escalated complaint." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats the sentence states, in your own words: new tellers, and your branch's escalation script. Answer slot: the JD's coaching line makes a probe on one particular occasion likely. If you remember one where your coaching met a real complaint, say what happened and what part was yours; if there was no such occasion, or it was not yours, say so plainly and stay with the training | F4 is the coaching requirement, and the evidence is training of tellers, not coaching of supervisors. JD because it scores the stated responsibility |
| D2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you actually said, and how the relationship stood afterwards. Choose one where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural probe that also tests the "senior leaders" requirement from the side. VAL because it scores behaviour, not credentials |
| D3 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Selection scaffold: pick an occasion where a member's situation and an internal measure pointed different ways. It needs what the measure was, what you chose, what it cost, and how it ended for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Pairs with the value "Members First, Always" and is a stock behavioural stem. VAL because it scores what you chose |
| D4 | "Tell me about a time a complaint had to be escalated." | JD | [grounded] | Selection scaffold: pick one escalation you can tell end to end: what happened, who it went to, what you did, how it ended for the member. Say "I" for your part and "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The question needs no claim about your past, so the guidance makes none | The JD makes escalations central to the role and your material carries no escalation event, so the pack gives a scaffold and not a story. JD because it scores a stated responsibility |
| D5 | "Tell me about the complaints you handled and what made them formal." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beat the sentence states, in your own words: the branch's formal complaints log. Answer slot: the requirement behind F7 makes a probe on what governed that log likely. If you can say what made the complaints formal and what rules the log followed, say so in your own words; if you cannot, say so plainly and stay with the log | F7 is a discovery row: the sentence says formal, and the material does not show what governed the log. JD because it scores a stated requirement |

### C — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role covers the contact centre as well as branches, and I don't see contact-centre work in your background. How would you own complaints in a place you have never worked?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI prep in this pack.** Concede first, in the words your message gives: "I haven't worked in a contact centre." Name the limit before it is asked for: what you have handled is the branch's formal complaints log, and you say it at that size. Then the plan, said as a plan and never as a past: in the first weeks you would learn how that side records and passes on complaints, from the people who do it, before changing anything. Follow-up 1, "What would you do first?": name one thing you would look at and one person you would ask. Follow-up 2, "Why would a contact-centre team listen to a branch supervisor?": hold the plan; you earn it by listening first, and you do not claim parity. Follow-up 3, "So you can't own it yet?": concede that ownership of that side starts from learning, and hold that you will do the learning. Do not fold into a claim you cannot back, and do not fold into "no" | F2, the stated gap behind half of the "across branches and the contact centre" remit. JD because it scores a listed requirement. Deepest rehearsal means the most follow-up levels, the exact concession wording and the limit named in advance |
| C2 | "Why you, over someone who has run complaints in a contact centre? Sixty seconds." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold what the quotes carry, in order: 6 years in retail banking, the last 3 as a branch supervisor; the branch's formal complaints log; training new tellers on your escalation script; the monthly complaints spreadsheet your regional manager uses. Concede the contact centre in one sentence and do not argue the comparison. If pressed twice, hold the same three facts and concede the same one limit. Do not add a claim to win the minute | Pressure-style stem aimed at F2. JD because it scores fit against the listed role |
| C3 | "How much of that spreadsheet was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sentence says: "I built the monthly complaints spreadsheet our regional manager uses". Answer slot: if anyone else contributed or set what went into it, say so plainly; if it was yours throughout, say that, in your own words. If you do not know how a figure in it was counted, say so rather than guess | F3 and F9. A prober's attribution check, and the honest answer is precise rather than large. EXP because it tests what was actually yours |
| C4 | "The role involves reporting monthly and presenting to senior leaders. What has your experience of presenting been?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Concede in the words your message gives: "I've never presented to anyone above regional level." Then the plan, as a plan: you would agree the one decision you are asking for before the meeting, keep to one page in plain words, and practise out loud with someone who will interrupt. Do not state what you presented at regional level unless you can say it in your own words | F8, a stated gap. JD because it scores a listed requirement |

### E — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The strategy aims to move 40% of member service to digital channels by 2028, and this role works with the digital teams on self-service journeys. Where would you start?" | JD | [grounded] | Clarify first: which journeys, which kinds of complaint, and what self-service should mean for a member who is already unhappy. Then objective, approach, metrics, risks, thinking aloud. Challenge one premise politely, such as how complaints are counted inside a service target. Answer slot: if you worked with anyone building or changing a digital route for members, say what and what part was yours, in your own words; if you did not, say so plainly and answer as a plan | Draws on the brief's 40% item and the JD's digital-teams line (F5). JD with CO delivery |
| E2 | "You have a month of complaint data and ten minutes with senior leaders. What goes on the page, and what stays off?" | CASE | [grounded] | Clarify the audience and the decision first. Then a page built around the measures the JD names, volumes and resolution times, with what you would need beside them to explain a movement. Say what you would leave off and why. Plain words, one ask. The question needs no claim about your past | The JD's monthly reporting line and its senior-leaders line in one live problem (F3, F8). CASE because it scores structure |

## Reverse questions — Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What does a good first quarter look like for this role, and how will you and I tell?" | Treats the interviewer as your manager and asks for the measure you will be held to |
| R2-2 | "Where do you see the complaints process working least well today, and what would you want me to look at first?" | Invites a direct steer and shows you are thinking about the end-to-end role |
| R2-3 | "How do the contact centre and the branches work together on a complaint at the moment?" | Turns your biggest gap into a learning conversation, in your own words from C1 |
| R2-4 | "The strategy brief aims for 40% of member service on digital channels by 2028. Which part of that do you expect this role to own?" | Ties the JD's digital-teams line to the published strategy |
| R2-5 | "What do the monthly figures look like to senior leaders today, and who would I report them to?" | Gets at the reporting line and the presentation audience, the two things C4 is worried about |

---

# Round 3 — Panel of two branch managers, including the values round (60 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored scenario probes against the four values | High. The email says the panel "score against the four values" | A selection scaffold per value, with the honest branch; name the value only when it is true |
| Case/Strategist | The 20-minute complaint-escalation case | High. Twenty of the sixty minutes are stated | Clarify, objective, approach, metrics, risks; think aloud; use Ashgrove's own words where they fit |
| Peer Evaluator | Seam-splitting between the role and the branches | Medium. The role coaches branch supervisors, and the panel are branch managers. The skill's prior for peers is the seam and who carries the load | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Skeptic | The round-two objections returning in a collegial register | Low to medium. No signal about the panel's stance, and the skill's own prior is that objections reappear in other banks | Reuse C1 to C4 unchanged; consistency across rounds is the point |

## Question bank

### F — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always. Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a time a member's situation pulled you away from the easy answer. It needs the situation, what you chose, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value, in its own words, is the raising source. VAL because it scores behaviour against that value |
| F2 | "Plain Words. Tell me about a time you explained something difficult to a member." | VAL | [grounded] | Selection scaffold: pick a time the member left understanding. It needs what was hard, how you put it, and how you knew they understood. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value is the raising source. VAL because it scores behaviour against that value |
| F3 | "Neighbours, Not Numbers. Tell me about a time what you knew about your members or your town shaped a decision." | VAL | [grounded] | Selection scaffold: pick a decision where a number alone would have pointed the other way. It needs the number, what you knew that it did not, and the outcome. Your branch-supervisor years are the setting where this would sit; the story itself has to come from you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value is the raising source. VAL because it scores behaviour against that value |
| F4 | "Own the Fix. Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] | Selection scaffold: pick a problem you found, not one you were handed. It needs how you found it, what you did to keep hold of it, who you had to chase, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value is the raising source. VAL because it scores behaviour against that value |
| F5 | "Which of our four values would be hardest for you to live up to, and why?" | VAL | [grounded] | Choose honestly, not the safest one. Say why in your own words and what you would do about it. Do not choose a value only because it sounds modest. The question needs no claim about your past, so the guidance makes none | A values panel often asks for self-assessment. VAL because it scores candour about the values |

### G — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member complained at a branch about a fee charged twice, and was told it would be sorted in a few days. They then phoned the contact centre, which had no record of it, and have now written to say they will leave. The branch manager asks what you would do. Walk us through it." | CASE | [generic] | A practice shape written for this pack; the panel's case may differ, and nothing in it is Ashgrove's. Clarify first: who holds it now, what was promised, what each record shows. Objective: the member's fix and one named owner. Approach: acknowledge, take ownership, give a plain update with a date, fix it, record it. Metrics: time to resolve, repeat contacts. Risks: the branch and the contact centre blaming each other. Challenge one premise politely, such as whether the member's account matches the record. Use "Own the Fix" and "Plain Words" only where they fit. The case asks about no past, so the guidance makes no claim | The recruiter's "a complaint escalation" is the only fact about the case, so this is a shape and not a prediction. CASE because it scores structure |
| G2 | "If you joined and found escalations handled differently in the branches and the contact centre, what would you do in your first 90 days?" | CASE | [generic] | Say first what you would find out and from whom: how each side records and passes on a complaint, and what members experience. Then one change at a time, agreed with the people doing the work. Concede plainly what you do not yet know about the contact-centre side: "I haven't worked in a contact centre." Never claim a past you do not have | The collegial return of the contact-centre objection (F2), and the end-to-end line. CASE because it scores a plan on a live problem |
| G3 | "We plan to consolidate eight branches into five hubs over 2027. A member whose branch is affected complains. How do you handle that complaint, and what does it say about Neighbours, Not Numbers?" | CO | [grounded] | Separate the decision, which is not yours, from the complaint, which is. Clarify what the member is actually asking for. Say what you can promise and what you cannot, in plain words. Keep hold of it until it is answered. Do not defend or criticise the consolidation. Name the value where it fits and stop | Draws on the brief's consolidation item and a published value, both from your provided documents. CO because it scores strategy fluency |
| G4 | "Here is a line from a complaint outcome letter: 'We have reviewed your complaint in accordance with our internal procedure and are unable to uphold it at this time.' Say it in plain words." | CASE | [generic] | An example for rehearsal; the panel's exercise may differ. Say what was decided, why in one sentence, and what the member can do next and by when. One idea per sentence. Test: would a member need it explained twice? Use it as the test, then check against "if a member needs it explained twice, we wrote it wrong". The exercise asks about no past | The value "Plain Words" in its own terms. CASE because it scores applying the value live |

### H — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where does your role stop and the branch's start when a complaint comes in?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: one owner at a time, the branch keeps the member relationship, you keep the process and the standard. Say what you would ask the panel about how it works today. The question needs no claim about your past | The role coaches branch supervisors, and the panel are branch managers. JD because it scores the end-to-end ownership line |
| H2 | "Suppose one of us disagrees with how you handled an escalation from our branch. What happens next?" | EXP | [generic] | Show spine and tact together: listen for what they saw, restate it, say what you decided and why, and agree what would change your mind. A disagreement about a member is resolved about the member. The question asks about no past, so the guidance makes none | Peer evaluators probe disagreement style with equals. EXP because it tests how you hold a position |
| H3 | "A supervisor in one of our branches has handled complaints their own way for years. How would you get them to use the escalation script?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what your material carries and stop there: you trained new tellers on your branch's escalation script. Coaching a supervisor is a further step. Say what you would do: ask what they do and why, show where the script helps the member, agree one change, and check in. Answer slot: if you have guided another supervisor on an escalation, say who and about what, in your own words; if not, say so plainly and answer as a plan | F4. JD because it scores the coaching line |

## Reverse questions — Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do your supervisors find hardest about escalations today?" | Asks the people the role would coach what the work is, rather than telling them |
| R3-2 | "How would you like a process lead to work with your branch: what would you want from me, and what would you want me to leave alone?" | A reciprocity question for a panel of managers, and it shows you are thinking about the seam |
| R3-3 | "With eight branches becoming five hubs over 2027, what do you most want kept as that happens?" | Ties the strategy brief to the value "Neighbours, Not Numbers" without assuming a view |
| R3-4 | "Which of the four values do you see tested most often in your branch's complaints?" | Turns the values round into a conversation about their work |
| R3-5 | "When a complaint goes well here, what does it look like from the counter?" | Invites a picture of success from the people who see it, and gives you something to aim at |

---

# Shared sections

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own the member complaints process end to end" | D4, G1, G2, H1 |
| "across branches and the contact centre" | B2, C1, G2 |
| "report monthly on complaint volumes and resolution times" | B3, E2 |
| "coach branch supervisors on escalations" | D1, H3 |
| "work with digital teams on self-service journeys" | E1 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | D5 |
| "confident presenting to senior leaders" | C4, E2 |
| "comfortable with Excel reporting" | B3 |

## Values cheat sheet (for Round 3)

The values are as you copied them on 20 November 2026 from ashgrovecu.org/about/values. None of your quoted sentences carries a story for any of them, so each row gives a selection scaffold, which is the honest state of the material.

| Value (official name) | Working meaning | Your mapped story, or scaffold | Used in |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold: a time a member's situation pulled you away from the easy answer, with what you chose and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1, D3 |
| Plain Words | If a member needs it explained twice, the wording was the writer's fault | Scaffold: a time you explained something hard and the member understood, with how you knew. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2, G4 |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: a decision where what you knew about your members or town outweighed a number. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3, G3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold: a problem you found and kept hold of to the end, with who you had to chase. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4, D4 |

## Prohibited claims

What this pack will not coach, and why. The pack's own observations of limits are not words for you.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: your material says one branch's log and training of new tellers, not the process end to end |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log". The pack's observation is that the sentence says formal, not what governed the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script". The pack's observation is that the sentence says new tellers |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". The pack's observation is that the sentence says a spreadsheet, not what it counted |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents:
- The JD, pasted by you.
- Ashgrove's published values, pasted by you, copied on 20 November 2026 from ashgrovecu.org/about/values. That URL is the source of the pasted text and was not fetched.
- The recruiter's email about the process, pasted by you.
- The 2026 strategy brief, published July 2026, as you summarised it. I have not read the brief itself.
- Your background paragraph, from your message.

No searches or fetches were sent, and no dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet: the pasted text names all four values and their definitions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights or the loop: the recruiter's email gives the three rounds, their lengths, and who runs each. The case format is not covered by any source and is in the upgrade menu |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO questions: the strategy brief you were sent, published July 2026, supplies the priorities |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV text → F1 to F9 evidence cells quote your CV and not only your message; any `discovery` row where the CV names the tool or the scope can move up
- What the monthly complaints spreadsheet counted and which tool it was built in → F3 and F9 move from `discovery`; B3 and C3 become story-mapped
- Any occasion you guided another supervisor, or anyone above teller level, on an escalation, and anything you have worked on with a digital or online team → F4 and F5; D1, H3 and E1 become story-mapped
- What made the formal complaints log formal, and what rules it followed → F7; D5 becomes story-mapped
- Anything you presented at regional level, and to whom → F8; C4 gains a grounded beat
- One complaint you found and stayed with to the end, one time you explained something hard to a member, one decision shaped by what you knew about your town, one time you put a member ahead of a target → F1 to F4 and the cheat sheet become mapped stories instead of scaffolds
- Your own notice period, pay expectation and where you can work, if you want them quoted into A3 to A5 as your own words
- The interviewers' names once assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to a path
- The recruiter's answer on the 20-minute case format → G1 to G4 re-aimed at the real case; usually one email
- Hours you can give per day before 29 November → a prioritised prep schedule
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisational context for Ashgrove, and a fuller grounding brief
- A `tuesday-dossier.md` from an earlier pass over this role, if you have one → verified evidence and claims to avoid, to tighten F1 to F9; not needed to use this pack
