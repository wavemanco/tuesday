No dossier or other files are in the working directory. I'll read the playbook's reference files next.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-3-denied-c63926ae/stripe_product-operations-manager_interview_pack.md`.

I built it for a hiring-manager-style final round, since I don't know who you're meeting or how many sessions the final has. It has 18 questions across six interviewer styles, requirement coverage, six reverse questions and an upgrade menu. The question I'd rehearse most is B1, "Which part of this role would you be weakest at on day one?"

**Research:** web search was denied in this session. The pack therefore contains no facts about Stripe: no named values, interview structure or strategy. Those are marked as gaps. Every question is a generic pattern for the role, and it's sections for the CV and job description are placeholders until you share them.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like it.

1. Who is the final round with (hiring manager, a peer, a skip-level, a panel), and is it one conversation or several back-to-back sessions? Your answer reweights every question bank.
2. Can you paste the job description and a few lines about your background, such as your CV? Without them I can still work, but the evidence and guidance cells stay as templates.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not known. Built as a hiring-manager-style final round, because nothing says who you are meeting or how many sessions the final holds. Web research was not available in this session, so nothing below is a fact about Stripe: every company-specific point is left for you to confirm from Stripe's own published material, and rows say so.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you understand the company's strategy and competition |
| CASE | Structure and reasoning on a live problem from the role |

Everything in this pack is labeled `[generic]`: it is a pattern for the role family, with no claim about Stripe and none about you. Your CV and a job description would turn many of these into `[grounded]` rows (see the upgrade menu).

## Fit snapshot

No CV, no job description and nothing about your background reached me, so this is the worksheet version. The requirements are role-family patterns written as plain prose, not quotes from a posting. Fill the evidence column yourself with sentences you could say truthfully; the bridge column says what strong evidence looks like and gives a selection scaffold.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Coordinating a product launch across several teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a launch you can name, the teams involved and the part that was yours. Selection scaffold: pick a launch or cross-team release where your role was clear and the outcome known; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R2 | Designing or running a recurring operating process, such as a review or planning cadence (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a process you set up or ran, who used it and what changed because of it. Selection scaffold: pick a process whose purpose you can state in one sentence and whose upkeep you can describe; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R3 | Using data to track product or program health (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a number you can explain: how it was counted, what it is sensitive to, and which part was yours. Selection scaffold: pick one metric you worked with and be ready to say how it was counted; if you do not know, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R4 | Influencing partners across functions without line authority (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer or partner team that you can describe from both sides, and how it ended. Selection scaffold: pick a case with a real tension and an intact relationship afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R5 | Prioritizing competing requests under ambiguity (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a trade-off you made, the criteria you used and what you declined. Selection scaffold: pick a time you said no or deferred something; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

The weights below rest on the hiring-manager relationship prior alone. No loop source established how Stripe's final round is run, so the loop falls back to the generic archetype (screen, hiring manager, panel) and the weights are flat beyond that prior. If your final is several back-to-back sessions, these blend across them; send the schedule and I will split them per session.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems about launches, process and metrics | High: the hiring-manager prior puts Case first, and a product operations role is plausibly assessed on live problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of day-one gaps and "why this role, why now" | High: the same prior puts the Skeptic beside Case, and a final round is where gaps get tested | Rehearse the most predictable objection (B1) until it is boring; calibrated candor over bluffing |
| C. Peer Evaluator | Seam-splitting, credit, collaboration | Medium: a final round commonly includes someone you would work beside; unconfirmed here | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| D. Conversational | Friendly, unstructured openers | Medium: an opener is likely in any session; the danger is treating it as unscored | A 90-second arc for the biography question; treat casual questions as scored |
| E. Values / Behavioral | Scenario probes on past behavior | Medium: Stripe's published values were not retrieved, so no values-style round is detected and no values cheat sheet is built | When Stripe's values are in hand, map one real story to each, by name |
| F. Pressure | Time-boxed challenge, devil's advocate | Low: the prior puts it behind the others unless the interviewer is senior | Pause, restate, hold a position through two follow-ups, concede specifically |

No Data-Driven Prober bank: it probes numbers on a CV, and there is no CV yet. It returns when you share one.

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for launching a new product across engineering, sales, support and legal. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what the product is, who it is for, the launch date and what is fixed, who decides, what success means. Then objective, the teams and what each needs, sequence and dependencies, metrics, risks. Name one premise you would challenge, such as whether one date fits every team. The question needs no claim about your past, so the guidance makes none | R1's requirement as a live problem; CASE because it scores structure, not history. `[generic]` because it is a pattern for the role, not a fact about Stripe |
| A2 | "An adoption metric for a recently shipped feature dropped 20% week over week. Diagnose it." | CASE | [generic] | Say what you would check first: whether the drop is real (instrumentation, definition, a changed denominator), then which segments, which time window, what shipped or changed alongside it, then who to ask. Name the assumption you would trust least before the interviewer does | R3's requirement; the interviewer scores whether you check the number before explaining it |
| A3 | "Two product teams each ask for the same limited operations capacity this quarter. How do you decide?" | CASE | [generic] | Ask what each request is for and what happens if it waits, then state criteria aloud (impact, urgency, cost of delay, reversibility), who needs to agree, and how you tell the team that loses. Propose the criteria rather than assuming Stripe's | R5's requirement; the answer shows whether you prioritize with stated criteria or by instinct |
| A4 | "A launch process exists but teams routinely work around it. What do you do in your first thirty days?" | CASE | [generic] | Learn before changing: who works around it and why, what it costs them, what it protects. Then one small change with an owner and a measure, and how you would hear whether it helped. The question presupposes nothing about your past | R2's requirement; tests whether you diagnose before you redesign |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack: this question arrives in some form in a final round. Pick the area where you honestly are least experienced, say it plainly in one sentence, then say how you would close it in the first weeks and whom you would ask. If you cannot choose yet, go through R1 to R5 in the fit snapshot and pick the one whose evidence cell you cannot fill. Hold through two follow-ups by staying with what you know; concede the limit specifically rather than defending it | The Skeptic's stem, and the one objection every candidate gets; JD because it scores the role's requirements against you. Which row it lands on depends on your background (R1 to R5) |
| B2 | "Why product operations rather than product management?" | JD | [generic] | A selection scaffold: say what draws you to enabling many teams rather than owning one product, in terms of work you have actually done or watched up close. Keep it to one reason and one example from your own experience. If no example comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Motivation consistency is what the Skeptic scores; JD because it tests whether you understand the role as listed |
| B3 | "Why Stripe, and why now?" | CO | [generic] | Stripe's current strategy and values could not be retrieved this session, so no company fact is supplied here. Before the interview, pick two things from Stripe's own published material (its values page, its latest annual letter, a product announcement) that you can speak to in your own words, and tie each to the work you want to do. Never recite a fact you have not read yourself | The standard motivation question with a company-knowledge test inside it; marked CO. The research gap is named in the upgrade menu |
| B4 | "Why are you looking to leave your current role?" | EXP | [generic] | Give your own reason in one or two sentences, stated about what you are moving toward rather than what you are leaving behind. Rehearse it aloud so it sounds settled. If the honest reason is hard to say, say a shorter true version rather than an invented one | A predictable Skeptic probe of motivation consistency; EXP because the answer must be yours and survive a follow-up |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Propose principles: who owns the decision, what each side needs to see, how disagreement gets escalated and how it is recorded. Then say how you would work out the real seam in your first weeks | R4's requirement; the peer is checking whether you reduce or add to their load |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Use "we" for context and "I" for what you personally did, and say it plainly about a real example if one comes to mind: pick a piece of cross-team work where the split was clear. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; scores partnership fit and attribution honesty |
| C3 | "What would you need from me in your first month, and what would you bring to my team?" | JD | [generic] | Reciprocity framing: lead with what you would bring to their team in terms of work you can honestly describe, then what you need (context, access, a first small win). Ask one question back about what their team is struggling with | The reciprocity question for the peer relationship; JD because it scores how you would operate in the role |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [generic] | A pre-scripted 90-second arc, in your own words: where you started, the one or two turns that mattered, and why this role is the next one. Stay with what you did; leave out anything you cannot stand behind in a follow-up | The standard biography opener; scored even though it feels casual |
| D2 | "What have you been learning lately that bears on this work?" | JD | [generic] | Name one specific thing you have actually been reading, trying or practicing, and one sentence on what you took from it. If nothing comes to mind, say so plainly and name the one thing you would start with | A casual question about a topic the role touches; communication economy and real curiosity are what is scored |
| D3 | "What are you looking for in your next team?" | VAL | [generic] | Two or three things, each tied to how you do your best work, stated as true of you. Check each against what you can learn about Stripe from its own published material before the interview, so the answer fits rather than flatters | A rapport question that doubles as a fit probe |

### E. Values / Behavioral

Stripe's published values were not retrieved, so these two use persona stems and are not mapped to named Stripe values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not fold, and an intact relationship at the end; the hard truth must actually have landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; scores whether the story shows spine and tact together |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real customer need, a metric that pulled the other way, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; the role sits between customer-facing and internal teams, so the choice is a likely one to be asked about |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then answer in three beats: what the role needs, one thing from your own record that speaks to it, what you would do in your first weeks. Hold the position through two follow-ups; concede a specific limit rather than folding on the whole case | Persona stem; scores composure and whether your case survives time pressure |
| F2 | "Convince me this role needs to exist." | JD | [generic] | Argue it from first principles without claiming anything about Stripe's setup: what coordination work costs when nobody owns it, and how you would know the role was paying for itself. Concede that a team can sometimes absorb the work, then say what changes at scale | Pressure on the role's purpose, which tests whether you understand the job and can hold a view |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 launches across teams | A1, C3 |
| R2 operating process | A4 |
| R3 data and metrics | A2 |
| R4 cross-functional influence | C1, C2, C3, E1 |
| R5 prioritizing under ambiguity | A3, F1 |

Every requirement here is a role-family pattern, so each rests on `[generic]` questions. With a posting, each becomes a quoted requirement with its own JD-tagged question.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is success for this role measured in the first six months, and who decides?" | Shows you think in outcomes and want a clear bar |
| 2 | "Which teams does this role work with most, and where is the working relationship strongest and weakest today?" | Signals you expect to operate across seams, and surfaces where you would be most useful |
| 3 | "What is the most important thing the last person or team in this seat did, and what is still unfinished?" | Invites a concrete answer about the role's real scope |
| 4 | "What would you want a new person to avoid in their first month?" | Collegial, and gives you usable context |
| 5 | "If your team could do one thing differently about how launches run, what would it be?" | Turns the conversation toward a problem you can show interest in solving |
| 6 | "If you work beside this role: what would help your team most from someone in it in the first month?" | The reciprocity question for a peer; drop it if the interviewer is not one |

## Prohibited claims

Nothing is listed yet, because no sentence of yours reached me: there is no wording to inflate and no stated negative to protect. The standing rule stands in its place. This pack coaches only what you say you did, in your own words, and it will not supply a figure, an outcome or a Stripe-specific fact you have not read and cannot defend. Share a CV and this section fills from your actual sentences.

## Sources

Provided documents: none beyond your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | The search was refused. It would have supplied the official value names for a values cheat sheet; none is built and Question bank E carries no named values |
| 2. `Stripe interview process Product Operations` | unavailable | The search was refused. It would have named the actual rounds and set the persona weights; the weights rest on the generic archetype and the hiring-manager prior instead |
| 3. `Stripe strategy` / recent news | unavailable | The search was refused. It would have grounded CO and CASE questions in current priorities; B3 and the CASE bank stay `[generic]` |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Product Operations Manager` JD | unavailable | The search was refused. It would have supplied `[inferred]` requirements for the snapshot; R1 to R5 are role-family patterns instead |

Queries sent, all refused: "Stripe operating principles values"; "Stripe interview process Product Operations Manager"; "Stripe strategy 2026 annual letter priorities"; "Stripe Product Operations Manager job posting responsibilities requirements".

## Upgrade menu

- The job description text → R1 to R5 become quoted requirements with `[grounded]` provenance, and every JD-tagged question is retargeted to the posting's own wording
- Your CV or a few sentences about your background → the fit snapshot's evidence cells fill from your own words, the guidance becomes story-mapped, and the prohibited list is built from your real sentences
- Who you are meeting and the round format (hiring manager, peer, skip-level, panel) → persona weights are recomputed from the relationship rather than a prior
- If your final is several sessions, the schedule → a per-session mini-pack with its own weights and bank
- Any recruiter guidance (focus areas, a case, a presentation, a take-home) → coverage built to the stated focus, and a build section for any declared deliverable
- Stripe's published values, loop structure and strategy, from web research or pasted pages → a values cheat sheet with official value names, a loop-based persona weighting, and grounded CO and CASE questions
- An interviewer name → an interviewer read from their public professional footprint, and a reverse question tied to their path
- A `tuesday-dossier.md`, if you have one → verified evidence, a named highest-ROI objection and absolute prohibited claims
