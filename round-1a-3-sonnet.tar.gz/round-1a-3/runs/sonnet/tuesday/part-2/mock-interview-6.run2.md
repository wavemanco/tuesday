Searches were refused, so I'm building the pack from your message alone. I'm writing the three-round pack now.
Your three-round prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-6-denied-95ba257b/larkfield-systems_engineering-manager_interview_pack.md`.

I built it from your message alone, using your role description as the job description. The company search was declined, so there's no research on Larkfield's values, loop or strategy. The Monday values questions are open prompts, and the company-knowledge question (3A2) is generic.

It has a shared fit snapshot, then a mini-pack for each round with its own persona weights, question bank and reverse questions. The Director round is weighted toward live role problems and gap probing, the panel toward peer and technical depth, and the VP round toward values and leadership philosophy. I'd rehearse 1B2 first. It's the question about never having owned a hardware-adjacent roadmap, and the pack expects it back in some form in all three rounds.

The pack coaches you to say plainly "I've never managed managers" and "I've never owned a hardware-adjacent roadmap", using your own words. It also lists the inflated claims it won't coach, such as "led two squads" or "cut on-call by 60%".

If you'd like a live Skeptic drill on 1B2, say so and I'll run it. I can also save a `tuesday-dossier.md` of the gaps this prep exposed, or convert the pack to Word.

1. Can you paste the full job description and your CV, or tell me to carry on without them? Either would re-grade the fit snapshot against the posting's own wording.
2. Do you want to grant search permission so I can rerun company research? It would ground the values and strategy questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (three-round loop)

Role: Engineering Manager at Larkfield Systems, from your description: "Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap."

Mode: loop. One shared fit snapshot, then a mini-pack per round.

| Round | When | Who and relationship | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss (no name given) | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager (no names given) | 60 min |
| 3 | The following Monday | VP Engineering, skip-level, described by the recruiter as "values and leadership philosophy" | 30 min |

## How to use this pack

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the values being probed, not generic virtue |
| EXP | Whether your own claims survive scrutiny; what was actually you |
| JD | The stated responsibilities of the role, including the gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role, scored on structure and reasoning |

Persona letters in question IDs: A Case/Strategist, B Skeptic, C Data-Driven Prober, D Peer Evaluator, E Values/Behavioral, F Pressure, G Conversational. An ID such as 2C1 is round 2, persona C, question 1.

Everything the pack says about your past is one of your own sentences from your message, quoted. Where a probe is likely and your material says nothing, you get an answer slot: an instruction for the interview with two honest branches. The material carries one worked story, the reliability quarter. Rounds 2 and 3 return to it from different angles, so a second story would help (see the upgrade menu).

## Fit snapshot (shared by all three rounds)

The role description in your message is treated as the job description. No CV was supplied, so every evidence cell is a sentence from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team lead of 6, with nothing inspected behind it, and the words stay there: "I have 9 years in engineering, 3 of them as a team lead of 6." It does not show two squads or this domain. Answer slot: if you led more than one team at any point, say how, in your own words; if you did not, say so plainly and stay with the team lead of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery) — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote says you pushed a reliability quarter through and that the burden dropped after, not that you owned delivery, and not that the push caused the drop. Words: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." Answer slot: the role's own delivery line makes a probe on how delivery was set likely. If delivery on your team was yours to set, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the quarter you pushed through |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring) — your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | presentation | The quote already reaches the hiring requirement in other terms. Words stay in its terms: you run the loop for backend roles, about 40 interviews last year. The pack observes that the quote says backend roles and says nothing about hiring decisions or headcount |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — your message | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have helped an engineer grow, say what you did, in your own words; if you have not, or it was not yours to do, say so plainly and say how you would approach it as a plan |
| F5 | "partner with hardware and product on roadmap" (hardware) — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | low | [grounded] | discovery | On ownership your own words are: "I've never owned a hardware-adjacent roadmap." The role says partner, and your material is silent on partnering. Answer slot: if you have worked with hardware or firmware teams on any shared plan, say how, in your own words; if you have not, say so plainly and say how you would start, as a plan |
| F6 | "partner with hardware and product on roadmap" (product) — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | transferability | Derived from roadmap pressure being adjacent to roadmap partnership; the quote does not say where the pressure came from or whether product was involved. Words stay at the quote: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if product partners were part of that, say how, in your own words; if they were not, or it was not you, say so plainly and stay with the quote |

## Round 1: Tuesday, hiring manager (Director of Engineering, 45 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | Live problems on the actual role: the two squads, hardware dependencies, roadmap pressure | High. Hiring-manager prior is Case/Strategist plus Skeptic: they are buying capability and checking gaps. 4 questions | Clarify first, then structure, then answer; think aloud; challenge one premise politely per case |
| B Skeptic | Quiet, persistent probing of F1, F4 and F5 and of why leave payments | High. Same prior; your own message names the two gaps they will find. 4 questions | Rehearse 1B2 until it is boring; calibrated candor over bluffing a competency they own |
| C Data-Driven Prober | Defend-the-number on the 60% and the 40 interviews | Low to medium. Not in the prior, but both figures are in your own pitch. 2 questions | Know how each figure was counted and say plainly when you do not |
| G Conversational | The opening biography and a growth question in a friendly register | Low. Casual questions are still scored. 2 questions | A 90-second arc built only from stated beats |

Loop source: your own words establish the loop, three rounds with who runs each and how long. No archetype fallback applies.

### Question bank

Highest-ROI prep in the whole loop: 1B2, the hardware-roadmap question. It is the gap the role description names most directly, and it returns as 2C3 and 3F2.

#### A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "You inherit two squads building device-management services and a roadmap you did not write. What do you need to know in your first thirty days, and in what order?" | CASE | [generic] | Structure it aloud: what each squad owns and what it has committed to others; the objective for thirty days; whom you hear from first (the engineers, product, hardware); what you leave unchanged until you understand it; how you would check you were right. The question needs no claim about your past, so the guidance makes none | A live problem from the role's lead line, which is F1's requirement. CASE because it scores structure, not a record |
| 1A2 | "A hardware-dependent release slips six weeks after your squads committed dates to product. Walk me through what you do this week." | CASE | [generic] | Structure it: what you need to know first (what slipped, what was committed to whom, what can be re-sequenced), whom you tell and when, how you protect the squads' other work, what you record. Say your clarifying questions aloud. The question needs no claim about your past, so the guidance makes none | The hardware-product seam is the role's own pairing, F5 and F6. CASE because it is a decision under a dependency, asked live |
| 1A3 | "Product wants new features, and the on-call load on your two squads is rising. How do you decide what the squads do this quarter?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure it: what the load is costing, what product needs by when, the options (sequence, split capacity, a bounded reliability slice), what you would show product, who decides. If you use your own example, stay with the quote: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on how that push was agreed. If you can say who agreed and how, say so in your own words; if there was no such step, or it was not yours, say so plainly and stay with the quote | F2 is the evidence closest to owning delivery; CASE delivery with an EXP follow-up likely |

#### B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B2 | "This role partners with hardware on the roadmap, and you have never owned a hardware-adjacent roadmap. How do you close that gap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Open with your own stated words: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: what you would learn first, whom you would ask, how you would test your understanding before committing dates. Follow-up one: they ask what you do know. Answer slot: if you have worked with hardware or firmware teams on any shared plan, say how, in your own words; if you have not, say so plainly and return to the plan. Follow-up two: they ask which dependency would worry you most; name one in your own words, since the pack supplies none. Follow-up three: they say a plan is not experience; concede exactly, "That's right, I haven't owned one", then return to the plan. Limit named before it is asked for: do not offer adjacent hardware work you have not described, and do not claim familiarity with how hardware release cycles run | F5 is the gap the loop most clearly probes and the one most likely to be asked in some form in all three rounds. JD because the role description names the hardware partnership; Skeptic because it targets exactly where the material is thin |
| 1B1 | "You have been a team lead of 6. This role is two squads and 11 engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Say the scope in the quote's own terms: "I have 9 years in engineering, 3 of them as a team lead of 6." Then what you expect to change, said as an expectation with the first thing you would do to learn it; the material shows nothing about running more than one team, so no past claim goes here. Answer slot: if you led more than one team at any point, say how, in your own words; if you did not, say so plainly and stay with the team lead of 6 | F1 is the scale step. JD because it scores the stated scope; Skeptic delivery because it comes as a quiet gap probe |
| 1B3 | "Why industrial IoT, and why leave a payments company for it?" | EXP | [grounded] "currently at a payments company" | Open with the stated fact: "I'm currently at a payments company." Answer slot: give your actual reasons for the move in your own words; the pack supplies none, and a reason you did not give is one you cannot hold under a second question. If you know the industry's work from your own experience, say what; if you do not yet, say so plainly and say what you would want to learn first | Motivation consistency is what the Skeptic scores; the role description sets the industrial IoT frame and F1 carries your current context. EXP because it tests your story's consistency |
| 1B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Selection scaffold: pick the gap your own words already name, "I've never owned a hardware-adjacent roadmap" or "I've never managed managers", whichever the role makes more relevant; say it plainly, then the first step you would take, as a plan. Nothing in the role description says the job manages managers, and reverse question 1R3 settles whether it does. If neither is the one, say so plainly and name the one you believe it is | A standard Skeptic stem aimed at F5; the pre-answer is calibrated candor, which is what this persona scores |

#### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "Your on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say it as quoted, in that order: the burden dropped after you pushed the quarter through, not because. The figure raises four slots, each answered in your own words: how the 60% was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly | The 60% is your headline metric, F2. EXP because it tests attribution and measurement |
| 1C2 | "You mention about 40 interviews last year. What was your part in running the loop, and how was that figure counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say it as quoted, including "about". The figure raises four slots, in your own words: how the 40 was counted (interviews you conducted, loops you ran, candidates seen); what it is sensitive to; the assumption you would defend least; which part of the loop was yours. If the decisions were someone else's, say so plainly | F3 is your direct hiring evidence. EXP because a prober checks what "run" meant |

#### G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1G1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc built only from the beats the quote states: nine years in engineering, three as a team lead of 6, currently at a payments company. Add the why-this-role beat in your own words, as in 1B3. Answer slot: any further beat from your career, in your own words; the pack supplies none | Casual openers are scored for economy and consistency; F1 carries the stated beats. EXP because it is your own history in your own order |
| 1G2 | "Tell me about a time you helped an engineer grow." | JD | [generic] | Selection scaffold: pick an engineer and a moment where something you did, not just time passing, changed what they could do; name the stake, what you did and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | The role description names growth for 11 engineers, F4, and your material is silent on it, so no story is mapped. JD because it scores a stated responsibility |

### Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| 1R1 | "What would make you say in six months that hiring me was the right call, and what would worry you by then?" | It surfaces the success measure and the doubt you would otherwise have to guess at, and it shows you expect to be measured |
| 1R2 | "How do hardware timelines and the squads' commitments get reconciled today, and who decides when they conflict?" | It turns your weakest area, F5, into a question about how the seam works, which is what a manager entering that seam needs to know |
| 1R3 | "How are the two squads led today, and does either have someone acting as a lead?" | It tells you whether the role manages managers, so you can prepare the right gap in 1B4 |
| 1R4 | "What do the 11 engineers need most from a manager right now?" | It shows the growth and delivery priorities from the boss's view, and gives 1G2 a target |
| 1R5 | "When product and engineering disagree on the roadmap, where do you want me to bring it?" | It signals that you expect friction and want the route, which answers F6's pressure story forward |

## Round 2: Thursday, panel (two staff engineers and a product manager, 60 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| D Peer Evaluator | Seam-splitting between engineering and product; "what would you need from us" | High. The panel prior blends the top two personas of each member's relationship: the staff engineers read as peers (Peer Evaluator plus Prober), the product manager as cross-functional (Values/Behavioral plus Conversational). 3 questions | Reciprocity: what you bring them, not only what you need; seam principles rather than pretending to know the seam |
| C Data-Driven Prober | Depth checks on the reliability quarter and on reliability judgment | High. Staff-engineer half of the blend; the 60% is your one metric. 3 questions | Say what you can and cannot say about how the figure was counted |
| E Values/Behavioral | Scenario probes on disagreement and hard truths, from the product manager | Medium. Cross-functional half of the blend; no names, so assignment per member is not possible. 2 questions | "We" for context, "I" for contribution; choose a story where the hard truth landed, and where the material shows none, say so |
| G Conversational | The product manager's friendly working-style question | Low. 1 question | Treat casual questions on the roadmap partnership as scored |

Loop source: your own words establish the loop. The panel names no individuals, so per-member assignment is not done.

### Question bank

#### D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "Where does engineering end and product begin on the roadmap, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Propose seam principles, not a map of a seam you have not seen: who owns the what, who owns the how, how disagreements are raised and settled. Frame it as reciprocity: what engineering gives product, such as visibility of costs. If you use your own example, stay with the quote's words. Answer slot: expect a probe on a real disagreement. If you can say who disagreed with you and how it was settled, say so in your own words; if there was no such disagreement, or it was not with product, say so plainly and stay with the quote | F6 is the evidence nearest product partnership and it is thin, so principles lead and the quote follows |
| 2D2 | "A staff engineer on your squad wants to rebuild a service you want to leave alone before a hardware release. How do you decide?" | CASE | [generic] | Structure it: ask what the rebuild fixes and what it risks, what the release needs, who is affected, what a smaller step could be, how you would record the decision and whom you would tell. Say how the staff engineer's view enters the decision. The question needs no claim about your past, so the guidance makes none | The staff engineers are scoring how you treat senior engineers who know the system better than you; F1 and F5 raise it. CASE because it is a live decision |
| 2D3 | "What would you need from the two of us in your first month, and what could you do for our work in return?" | JD | [generic] | Reciprocity in both halves. What you need: the map of what the services depend on and what they promise to others. What you give: the plan you would say in your own words, not a record. No claim about your past is needed, so none is made | A peer question; it also turns the F5 gap into a request for their expertise |

#### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "The on-call burden dropped. How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what the quote says: you pushed a reliability quarter through, and the burden dropped after. Answer slot: which of the engineering work was yours and which was the squad's, in your own words; if most of it was others' work, say so plainly and return to what the quote says you did, pushed the quarter through. Never claim the 60% as your result alone | F2 attribution, asked collegially by people who would do the work |
| 2C2 | "How would you judge whether a device-management service is reliable enough to put in front of customers' devices?" | CASE | [generic] | Structure it: what failure costs and to whom, which signals you would want to see and who owns them, what a release gate would hold, what you would ask the staff engineers to define. Ask for their definition before offering yours. The question needs no claim about your past, so the guidance makes none | The role's lead line, F1, set in a technical register; CASE because it scores reasoning, and the staff engineers own the content |
| 2C3 | "You have never owned a hardware-adjacent roadmap. Where do you expect our services to touch hardware, and what would you ask us?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Acknowledge plainly: "I've never owned a hardware-adjacent roadmap." Then the questions you would ask them, as a plan: what the services depend on from hardware, what a hardware change does to them, who they talk to. Answer slot: if you have worked with hardware or firmware teams on any shared plan, say how, in your own words; if you have not, say so plainly and return to your questions. Do not guess where the seam is | The 1B2 gap again, with the people who live in the seam; F5 |

#### E: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the beats the quote states: you pushed a reliability quarter through, against roadmap pressure, and the burden dropped after. The quote does not say the pressure came from leadership or that a truth was delivered. Answer slot: if the pressure came from leadership and you told them something unwelcome, say what and how it landed, in your own words; if it was not that kind of moment, say so plainly and stay with the quote at its own scope | A standard Values stem; F2 is the nearest story and the guidance stays inside it |
| 2E2 | "Tell me about a time you and a product partner disagreed on priorities." | VAL | [generic] | Selection scaffold: pick a real disagreement with a named stake, a position you held, and a relationship that was intact at the end; say what you did and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role description names partnering with product, F6, and your material shows no product disagreement, so no story is mapped |

#### G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2G1 | "How do you picture working with product on the roadmap week to week?" | JD | [generic] | A plan in your own words: how often you meet, what you bring, how a trade-off is raised. It claims nothing about your past, so it makes none; if you reach for an example, use the 2D1 quote and nothing beyond it | A friendly framing of F6's requirement from the product manager; scored despite the register |

### Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| 2R1 | "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity for the two staff engineers, the peer-evaluator slot that generic closers waste |
| 2R2 | "Which parts of the device-management services would you want me to understand before I make commitments on your behalf?" | It shows you will not commit dates blind, which is the F5 risk turned into a working agreement |
| 2R3 | "What do you wish engineering managers did more of when you plan the roadmap together?" | It asks the product manager for their experience of the seam, and gives you a calibration for F6 |
| 2R4 | "How do disagreements between the squads and product get resolved today?" | It tells you the real route before you propose a principle of your own |
| 2R5 | "What would you most want a new engineering manager to leave alone?" | It signals turf awareness and gets you a list of things not to break |

## Round 3: Monday, VP Engineering (values and leadership philosophy, 30 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| E Values/Behavioral | Leadership-philosophy and scenario probes | High. The skip-level prior is Case/Strategist plus Pressure, but the recruiter's description of the round as "values and leadership philosophy", as you relayed it, moves Values/Behavioral to the top. 4 questions | Principles each tied to an example from your own material, or said honestly as untested at this scale |
| F Pressure | Time-boxed challenge on the two gaps | Medium. Skip-level prior; 30 minutes favors short sharp challenges. 2 questions | Pause, restate, hold through two follow-ups, then concede exactly |
| A Case/Strategist | Strategy-flavored questions, altitude | Medium. Skip-level prior, shortened by the round's stated focus. 2 questions | Clarify, structure, answer; stay honest about what you do not yet know of the industry |
| G Conversational | Motivation and fit | Low. 1 question | Own reasons, in your own words |

Loop source: your own words establish the loop. A values-style round is detected from the recruiter's description as you relayed it. Larkfield's published values are not in hand (search was refused), so there is no values cheat sheet; the VAL questions are open prompts.

### Question bank

#### E: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3E1 | "What is your philosophy for leading engineers?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." and "I run our hiring loop for backend roles — about 40 interviews last year." | Selection scaffold: state two or three principles you actually hold, each with one thing you did that shows it. Your material today carries the reliability quarter and the hiring loop, in their own words; a principle with no example behind it is said as a principle you hold and have not yet tested at this scale. If no principle comes to mind, say so plainly, then give the nearest thing your material carries, or how you would lead | The round's stated focus; F2 and F3 are the only examples your material carries |
| 3E2 | "Tell me about a time you put a team's long-term health ahead of a short-term deadline." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the quote's beats: you pushed a reliability quarter through, against roadmap pressure, and the burden dropped after. Answer slot: if there was a deadline that gave way and you chose that, say what and how it landed, in your own words; if there was no such deadline, or it was not your call, say so plainly and stay with the quote | F2 is the one story your material carries; here it faces a VP's altitude, so the 60% attribution rules of 1C1 still apply |
| 3E3 | "Tell me about a time you helped someone on your team through a hard stretch." | VAL | [generic] | Selection scaffold: pick a person and a stretch where what you did mattered; name the stake, what you did and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Leadership philosophy is scored through people stories; F4 shows no story to map |
| 3E4 | "How do you think about hiring, beyond whether a candidate can pass the loop?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the quote as given. Answer slot: what you actually assess for and why, in your own words; if the loop assesses only skills, or the criteria were not yours, say so plainly and return to the quote. The pack names no criteria | The role's hiring line, F3; VAL because the VP is scoring judgment about people |

#### F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3F1 | "Sixty seconds: why you over a candidate who has managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." and "I run our hiring loop for backend roles — about 40 interviews last year." and "9 years engineering, 3 as a team lead of 6" | Pause and restate. Concede first and plainly: "I've never managed managers." The position you hold is only what the quotes carry: 9 years in engineering, 3 as a team lead of 6, and that you run the hiring loop for backend roles. Hold it through two follow-ups by returning to those words, never by comparing yourself to the other candidate or adding to them | The managers gap in your own words; the pressure persona is the skip-level prior. JD because it scores the stated scope |
| 3F2 | "You have never managed managers and never owned a hardware-adjacent roadmap. Why should I take that risk?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold-then-concede. Acknowledge both plainly: "I've never managed managers. I've never owned a hardware-adjacent roadmap." Then what you do bring, in the words of your own quotes only, and a plan for each gap, said as a plan. Answer slot: if you have worked with hardware teams on any shared plan, say how, in your own words; if you have not, say so plainly. Do not fold on the quoted facts to restore comfort, and do not widen them | The 1B2 gap compounded with the managers gap, delivered at the altitude where it is most likely to be asked together; F5 |

#### A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Two squads cannot do everything this year. How would you decide what they do not do?" | CASE | [generic] | Structure it: what the squads exist to deliver, what a no costs and to whom, how you would involve product and hardware in the call, how you would say no, and what you would revisit. The question needs no claim about your past, so the guidance makes none | A strategy-altitude version of the role's lead line, F1; CASE because it scores judgment aloud |
| 3A2 | "What do you know about industrial IoT device management, and what would you want to learn first?" | CO | [generic] | Answer slot: say what you actually know, in your own words; if little, say so plainly and name the first three things you would learn. No research ran, so the pack supplies no company or industry facts and you should not recite any you have not verified | The role description sets the industrial IoT frame; labeled generic because company research was refused, which is the honest cost |

#### G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3G1 | "Why this role, and why now?" | EXP | [grounded] "currently at a payments company" | Open with the stated fact: "I'm currently at a payments company." Answer slot: your actual reasons, in your own words; the pack supplies none. If the reasons are about the work, say what you know of it from your own experience; if you do not yet, say so plainly | Motivation is a values signal at this level; F1 carries your current context |

### Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| 3R1 | "What does good engineering leadership look like at Larkfield beyond delivery?" | It matches the round's stated focus and gets you the language to use in the rest of the conversation |
| 3R2 | "What do you want engineering managers here to be known for across the company?" | It surfaces the standard the VP will hold you to, in their words |
| 3R3 | "How do hardware and software engineering leadership make trade-offs together at the top level?" | It places your F5 gap inside a structure rather than in your CV, and it reads as altitude |
| 3R4 | "What have you changed your mind about in how you lead engineering?" | It invites a candid exchange, which a values conversation rewards |
| 3R5 | "What would you want from an engineering manager in their first ninety days that I would not think to ask about?" | It leaves the VP the last word on what matters, and gives you something to act on |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | 1A1, 1B1, 2C2, 3A1, 3F1 |
| Own delivery | 1A3, 1C1, 2C1, 3E2 |
| Hiring | 1C2, 3E4 |
| Growth | 1G2, 3E3 |
| Partner with hardware on the roadmap | 1A2, 1B2, 1B4, 2C3, 3F2 |
| Partner with product on the roadmap | 2D1, 2E2, 2G1 |
| Industrial IoT context | 1B3, 3A2, 3G1 |

## Prohibited claims

What this pack will not coach, and why. Built from your own sentences before any question bank was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or led through other managers | Negative you stated, F5 | "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." Partnering is a separate slot, in F5 |
| Led two squads, or led a team of 11 | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a team lead of 6 |
| Owned delivery for your team | Inflated form of F2 | F2's quote at its own scope: you pushed the quarter through. The material does not say delivery was yours to set |
| Cut on-call burden by 60%, or caused the drop | Inflated form of F2 | The quote's order: it dropped after you pushed the quarter through. 1C1 and 2C1 hold the attribution slots |
| Owned hiring for the team, or set the hiring bar | Inflated form of F3 | F3's quote at its own scope: you run the loop for backend roles, about 40 interviews last year |

## Sources

Provided documents: your message (role description, round schedule, your background). No CV, no full JD, no tuesday-dossier.md.

Searches sent (all refused, none returned a result):

- `Larkfield Systems industrial IoT company values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems industrial IoT device management strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The only search sent was refused. It would have supplied the official value names for a values cheat sheet and the VAL maps in round 3; round 3's VAL questions are open prompts instead |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The only search sent was refused. It would have checked the loop and each round's format; persona weights rest on your own description of the rounds |
| 3. `Larkfield Systems strategy` | unavailable | The only search sent was refused. It would have grounded the CO bank; 3A2 is generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given for any interviewer, so there was no query to form |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot's requirement rows and the JD-tagged questions |

## Upgrade menu

- The full job description → F1 to F6 re-graded against the posting's own wording, and any requirement your description omits gets a JD-tagged question
- Your CV → evidence cells quoted from it in place of the single paragraph in your message; more stories than the one reliability quarter, which every round now leans on
- Interviewer names → an interviewer read per round, persona weights adjusted from public professional footprint, and reverse questions tied to their own paths
- The recruiter's prep notes for any round → coverage of any announced topics or deliverables
- Search permission → rerun of company values, loop and strategy research: official value names for a values cheat sheet in round 3, a grounded 3A2, and a check of the loop against your own description
- Deep research, offered once: up to 6 further searches and 2 further fetches, several more minutes, run only on your consent → a company strategy brief and recent organisation context for the round 3 altitude questions
- A story from your own experience on growth, on a disagreement with product, or on working with hardware or firmware teams → 1G2, 2E2, 3E3 and the slots in 1B2, 2C3 and 3F2 become mapped stories instead of selection scaffolds
- A tuesday-dossier.md from an earlier engagement → verified evidence and a sourced prohibited-claims list in place of the locally built one
