Web search was refused, so nothing about Larkfield will come from research. I'm building the loop-mode pack from your message alone and writing it to a file now.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-6-denied-bc97779c/Larkfield-Systems_engineering-manager_interview_pack.md`. It's in loop mode: one shared fit snapshot, then a bank of eight questions plus reverse questions for each round.

I built it on three assumptions:
- **No research:** web search was refused, so nothing in it comes from Larkfield's own material. There is no company-values sheet and no question built on Larkfield's strategy. The research table in the file says what each refused search would have changed.
- **Your sentences only:** I had only your message, no CV, so everything about your past is one of your own sentences quoted back.
- **Monday is the values round:** I treated it that way because of the recruiter's description.

The highest-return prep is question T-B2, the hardware-roadmap objection. Every round asks it in some form. Your "I haven't owned a hardware-adjacent roadmap" is the plain acknowledgment to start from, followed by a plan, never a past.

Say the word and I'll play the Director on T-B2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two questions would restructure it:
- Would either staff engineer on Thursday's panel sit inside the squads you'd lead? That decides whether Thursday weights toward peer or toward future reports.
- Can you share your CV? That would re-grade the rows currently resting on a single sentence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop of three rounds)

**Candidate:** Yusuf. **Mode:** loop, one shared fit snapshot, then a mini-pack per round.

| Round | When | Interviewer(s) | Relationship | Source of the round facts |
|---|---|---|---|---|
| 1 | Tuesday, 45 min | Director of Engineering, the hiring manager | Would-be boss | your message |
| 2 | The Thursday after, 60 min | Two staff engineers and a product manager | Panel, mixed | your message |
| 3 | The following Monday, 30 min | VP Engineering | Skip-level, described by the recruiter as "values and leadership philosophy" | your message |

No interviewer names were given, so there is no interviewer read. The loop (each round, who runs it) is taken from your words and the recruiter's, so no archetype fallback is used. Web search was not permitted in this run: nothing here about Larkfield's values, process or strategy is researched, and the pack makes no claim about them.

## How to use this pack

Personas are how a question is asked; types are what is scored. Guidance is scaffolding for a spoken answer, not a script. Everything about your past is one of your own sentences, quoted, or an answer slot.

The five type tags:

| Tag | Meaning |
|---|---|
| VAL | Behavioral and values: does past behavior show the thing, not generic virtue |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, because research did not run) |
| CASE | Live problem from the role: structure and reasoning |

Rehearse once, use three times: the four quoted sentences, the two plain acknowledgments in F5 and F8, and T-B2 come back in all three rounds in different packaging.

Highest-ROI prep in the pack: **T-B2** (the hardware-roadmap objection). It is asked in some form by all three rounds.

## Fit snapshot (shared across the loop)

Your own sentences, quoted from your message. Requirements are the role description in your message, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads, and nothing inspected sits behind it. Words stay at: "I was a team lead of six." Answer slot: the two-squad scope makes a probe on the step up likely. If you coordinated more than one team, say how, in your own words; if you did not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery part) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries a call you pushed on your own team's roadmap and a figure that moved after it; it does not carry owning delivery across two squads. Words stay at: "I pushed a reliability quarter through against roadmap pressure." Answer slot: how the burden was counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours; "I don't know how it was counted" is an honest branch |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring part) — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a quote with nothing inspected behind it, so expect a probe on how the loop works. Lead with it in the quote's own terms: you run it, for backend roles. The figure counts interviews and stays attached to that noun |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth part) — role description, your message | none given | none | [grounded] | discovery | Your material is silent on growing people, so the words are an answer slot: if you helped anyone grow, say who, what you did and what changed, in your own words; if there was no such case, or it was not yours, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" (hardware part) — role description, your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "partner with hardware and product on roadmap" (product part) — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries roadmap pressure on a reliability quarter; it does not show who applied it or that product partnered in it. Words stay at the quote. Answer slot: if product was part of that quarter, say how, in your own words; if it was not, say so plainly and stay with the quarter |
| F7 | "Lead two squads building device-management services" (domain part) — role description, your message | none given | none | [grounded] | discovery | Your material does not show device-management work, so the words are an answer slot: if any of your work touched devices or fleets, say what, in your own words; if none did, say so plainly and say what you would learn first and from whom |
| F8 | Managing managers: not in the role description, raised by your own message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | The role description does not say whether the squads have leads, so this may or may not be asked, and a VP round on leadership is where it would arrive. Words: "I haven't managed managers." Then the step up, said as a plan and never as a past |

## Round 1: Tuesday, Director of Engineering (hiring manager, 45 min)

**Persona weights, with reasoning.** Starting prior for a hiring manager is Case/Strategist plus Skeptic: they are buying capability and de-risking gaps. Round 1 is also the only round with the person you would report to, so the Skeptic goes deepest here, aimed at F5 and F7. No interviewer signals exist to adjust this.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the actual role: a fleet issue, a first-30-days plan, a hardware-versus-product clash | High: the hiring-manager prior, and a boss gets to test judgment on his own roadmap | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic | Quiet, persistent probing of F5, F7 and the payments-to-IoT move | High: those are the biggest gaps in the snapshot and a boss is de-risking them | Rehearse the one objection until it is boring; adjacent evidence only; a plan, not a past |
| Conversational | Opening "walk me through the journey" | Medium: a 45-minute first conversation usually opens loosely, and it is still scored | A 90-second arc built only from your quoted beats |
| Prober | Reads the reliability sentence line by line | Medium: F2 holds the only figure in your material | Know what you can and cannot say about how it was counted |
| Pressure, Values, Peer | Appear lightly | Low in this round: Monday and Thursday carry them | Covered in those rounds |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "A device-management service you own starts losing check-ins from a slice of the fleet after a hardware-side release, and the quarter is already full. What do you need to know first, and how do you decide what moves?" | CASE | [generic] | Clarify first: which devices, what changed in the release, how many are affected, since when. State the objective, segment the problem (by device model, version, connection type), choose an approach, name metrics and risks, and challenge one premise aloud, such as whether the release is the cause. The scenario is an example pattern, not this company's reality, and the guidance claims nothing about your past | F7 is the domain gap this probes without asking about your past; CASE because it scores structure on a live problem, and a hiring manager's prior leans there |
| T-A2 | "You'd inherit two squads and eleven engineers. What do you do in your first thirty days, and what do you deliberately leave alone?" | CASE | [grounded] | Structure it: what you must learn first (how the squads are split, what is committed, what each depends on), what you listen for in week one, what you leave alone, and what you commit to by day thirty versus day ninety. Keep commitments small enough to defend. The question assumes nothing about your past | F1 and the role description's own numbers drive this; CASE because it is a live plan, not a past story |
| T-A3 | "Product wants a new capability this quarter. Hardware says the device side will not be ready until next. How do you run that conversation?" | CASE | [generic] | Clarify what is committed and what is fixed on each side and what happens if either slips. Then propose principles for the seam instead of pretending to know it: one shared dependency list, trade-offs decided with both in the room, a clear escalation path. Say what you would need to learn about how hardware releases work here. The guidance claims no past negotiation | F5 and F6 are the role's partnership clause; CASE because it tests how you structure a conflict you have not yet lived |
| T-B1 | "You're at a payments company today. Why a move into industrial IoT?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold: your material states where you are, not why you want this move, so the reason has to be yours, in your own words. Pick one specific to this work (devices and hardware meeting software) and true for you, then connect it to something your quoted material carries. If no specific reason comes to mind yet, say so plainly and say what you hope to learn | F7 is the domain gap; JD because it scores fit with the stated work, and the Skeptic asks it as motivation consistency |
| T-B2 | "I don't see hardware in your background. How would you handle partnering with the hardware team on roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal. Concede first, plainly: "I haven't owned a hardware-adjacent roadmap." Then, as a plan: what you would learn first, whom you would sit with, how you would keep a hardware date from surprising the squads. Follow-up one is usually how you know you can do it: hold only what the quotes carry, a team lead of six and a reliability quarter pushed through against roadmap pressure, and say plainly these are adjacent, not the same. Follow-up two is usually what you would get wrong first: name one honest, specific risk you actually see. Hold through both by returning to the quotes, never by adding to them | F5 is the biggest named gap and the one every round presses; JD because it scores the stated partnership clause, and it is the highest-ROI prep because it will be asked in some form |
| T-B3 | "You've been a team lead of six. This is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start at the quote: "I was a team lead of six." Talk about what changes as scope and plan: what you would ask on day one, such as how the squads are organised and who you would rely on. Answer slot: if you coordinated more than one team, say how, in your own words; if you did not, say so plainly and stay with the team of six | F1 is where scope jumps from one team to two; JD because it scores the stated scope |
| T-C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the three beats the quote states: nine years in engineering, three of them as a team lead of six, and where you are now, a payments company. Tell them in your own words. The last beat, why this role, is not in your material: fill it with the T-B1 scaffold and end there rather than on a recap | F1 holds the only career facts; EXP because it tests whether your story is economical and consistent |
| T-D1 | "Your on-call burden dropped 60 percent. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say what you know, in your own words, about how the burden was measured, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours; "I don't know how it was counted" is an honest answer. Your sentence says the drop came after the quarter, so hold it at that scope. Answer slot: if anything else changed in the same period, say what; if you do not know, say so plainly and return to what you pushed through | F2 holds the only figure in your material, and a headline metric is a magnet for probes; EXP because it tests attribution |

**Reverse questions, Round 1**

| # | Question | Why it lands |
|---|---|---|
| 1 | What would make this hire a clear success at six months and at a year? | It makes you outcome-oriented and shows you how your would-be boss measures; it also tells you what Round 3 will test |
| 2 | How are the two squads split today, and does each have a lead? | It surfaces whether F8 matters in this role, on your terms rather than as an ambush |
| 3 | Where do hardware and product roadmaps get reconciled today, and where does it hurt? | It turns F5 from a gap into a working conversation about the real seam |
| 4 | What does the on-call and reliability picture look like for these squads right now? | It links to F2 without claiming anything about this company |
| 5 | What is the hardest conversation you expect me to have in my first quarter? | It signals you are planning the job, and the answer tells you where the boss feels pressure |

## Round 2: Thursday, panel of two staff engineers and a product manager (60 min)

**Persona weights, with reasoning.** Panel rule: blend the top two personas of each member's relationship. The staff engineers read as peer or technical-specialist: Peer Evaluator plus Prober. The PM is cross-functional: Values/Behavioral plus Conversational. Whether the staff engineers would work inside your squads is not stated, so the Peer weight is a judgment you can recalibrate. Tune delivery per person: technical depth for the staff engineers, roadmap partnership for the PM.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Prober | Staff engineers test the reliability figure, the hiring loop and your device-management knowledge | High: the F2 figure and F3 are the two probe-able items, and F7 is the technical gap | Say what you know about the count, name the assumption you would defend least, and know where your knowledge stops |
| Peer Evaluator | Seam-splitting between EM and staff engineers, "what would you need from us" | High: staff engineers are pricing what this hire costs them | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Values/Behavioral | PM asks for a past story about stakeholders and trade-offs | Medium: a cross-functional interviewer tends to ask behavioral questions | Map a story only where a quoted sentence carries one |
| Conversational | Friendly, unstructured prompts from the PM | Medium: casual questions here are still scored | Economy and genuine interest |
| Skeptic, Pressure | Gap probes in collegial packaging | Low to medium: Round 1 and Round 3 carry them, but gaps return politely | The T-B2 answer holds here too |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-A1 | "Which assumption behind that 60 percent would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name it yourself before they do. Answer slot: if you know how on-call burden was counted, say what the figure is sensitive to and which assumption you trust least; if you do not know how it was counted, say so plainly and return to what you did, that you pushed a reliability quarter through against roadmap pressure. Staff engineers push hardest on the second follow-up, so know where your knowledge stops | F2 holds the only figure; EXP because the weakest-assumption move tests attribution honesty |
| H-A2 | "Walk us through the hiring loop you run." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Tell it at the scope you stated: you run the hiring loop for backend roles, about 40 interviews last year. Answer slot: the role puts hiring on you, so expect a probe on how the loop works; if you set any of its stages or how candidates were scored, say which and why, in your own words; if the loop was in place before you and you run it, say so plainly. Keep the figure on the noun it came from, interviews | F3 is your strongest direct row; EXP because the probe is how much of the loop was yours |
| H-A3 | "We build device management. How does it differ from the work your team does today?" | JD | [grounded] "currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slot: the role is device management, so expect a probe on where it differs from your current work; if any of your work touched devices or fleets, say what, in your own words; if none did, say so plainly and say what you would learn first and from whom. Do not bluff depth with two staff engineers in the room; ending on a sharp question back is fine | F7 is the domain gap and the staff engineers are the likeliest to press it; JD because it scores the stated device-management work |
| H-B1 | "Where does the engineering manager's call end and a staff engineer's begin when roadmap and architecture pull apart?" | JD | [generic] | Propose seam principles rather than pretending to know this team's seam: who owns the what, who owns the how, how a disagreement gets decided and recorded, what gets escalated. Ask them where it has hurt before. The question needs no claim about your past, so the guidance makes none | The Peer prior is seam-splitting; JD because it scores how the role works day to day, and the label is generic because it is a pattern for the problem, not a fact about this team |
| H-B2 | "Tell me about a time you disagreed with a senior engineer about a technical call." | VAL | [generic] | Selection scaffold: pick a case with a named stake, what you actually said, and an intact relationship at the end; "we" for context, "I" for contribution. Nothing in your material carries this story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer disagreement stem is a standard Peer probe; VAL because it scores behavior with equals, and no quoted sentence carries it |
| H-B3 | "What would you want from us in your first month, and what could we expect from you?" | JD | [generic] | Reciprocity framing: lead with what you bring them, such as a standing way to hear their technical concerns, then ask for their map of the seams. The guidance claims nothing about your past | A peer panel weights reciprocity; JD because it scores the working relationship the role needs |
| H-C1 | "Tell me about a time you held a line when a stakeholder wanted something else." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your one quoted candidate story is the reliability quarter, pushed through against roadmap pressure; its beats are those two. Answer slot: the PM will listen for how you handled the people applying the pressure; if you know who it came from and what you said to them, say so in your own words; if it was not you who spoke to them, or you do not remember it that way, say so plainly and stay with the quarter | F2 and F6 are the only story-carrying rows; VAL because it scores behavior under pressure, and the ending is not in your material so none is supplied |
| H-C2 | "How would you decide with product what goes on the roadmap when engineering raises a reliability concern?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure it: what evidence you would bring so the PM can weigh it, what product needs from you, how scope gets traded, and how you decide together. Answer slot: if product partners were part of your reliability quarter, say how, in your own words; if they were not, say so plainly and stay with how you would run it | F6 is the product half of the partnership clause; JD because it scores a stated responsibility |

**Reverse questions, Round 2**

| # | Question | Why it lands |
|---|---|---|
| 1 | What could a new engineering manager do in their first month that would genuinely help your work? | It is the reciprocity question and a peer panel weights it heavily |
| 2 | Where do engineering and product plans collide most often, and how is it handled? | It speaks to the PM directly and shows you plan for the seam |
| 3 | What technical debt do the squads carry that the roadmap keeps deferring? | It shows engineering judgment to the staff engineers and surfaces F2-type trade-offs |
| 4 | How do you hear about reliability problems before they become roadmap conversations? | It connects to F2 and tells you how the squads signal trouble |
| 5 | What do you wish the other side of this table understood better about your work? | Asked of each side, it shows you listen across the seam |

## Round 3: Monday, VP Engineering (30 min, "values and leadership philosophy")

**Persona weights, with reasoning.** Skip-level or executive prior is Case/Strategist plus Pressure. The recruiter's description names a values-style round, which is a loop source, so Values/Behavioral leads here and is guaranteed in the loop. Thirty minutes means few questions and short answers: rehearse each in under two minutes. No published Larkfield values are in hand, so there is no values cheat sheet, and the VAL themes come from the recruiter's own words and the persona stems.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy, an unpopular truth, growing people, a hard hiring call | High: the recruiter named this round's subject | Map a story only where a quoted sentence carries one; otherwise a selection scaffold with its honest branch |
| Pressure | Time-boxed challenge on managing managers and on how much of the reliability result was you | High: a skip-level tests composure on F8 and F2 | Pause, restate, concede specifically, hold through two follow-ups |
| Case/Strategist | One or two altitude questions on hardware cadence and where engineering goes | Medium: the executive prior, cut down by 30 minutes | Clarify, structure, state a hypothesis early |
| Conversational, Skeptic, Peer, Prober | Light | Low: covered earlier | n/a |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-A1 | "What is your philosophy of leading engineers, and where did it come from?" | VAL | [grounded] | Nothing in your material states a philosophy, so it has to be yours, in your own words. Scaffold: one belief, the behavior that shows it, and what it costs you; keep it to something you could point to with a team you led. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | The recruiter's own words name leadership philosophy as the subject; VAL because it scores values in action |
| M-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your one quoted candidate story is the reliability quarter, pushed through against roadmap pressure; use it only if a hard truth actually landed with the people applying the pressure, and your material does not show the ending, so none is supplied. Answer slot: if you told leadership something they did not want to hear, say what and how it landed, in your own words; if the pressure did not come from leadership, or you did not tell them, say so plainly and choose another time that fits the scaffold: a named stake, the moment you did not fold, an intact relationship | F2 is the only story-carrying row; VAL because the persona stem scores the hard truth landing |
| M-A3 | "Tell me about a time you helped someone on your team grow." | VAL | [grounded] | Nothing in your material speaks to growing people. Pick an instance with a named person, what they needed, what you did, and what changed for them, crediting their effort. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | F4 is a discovery gap and the role puts growth on you; VAL because it tests whether growth behavior is real |
| M-A4 | "You run the hiring loop for backend roles. Tell me about a hiring call that was hard." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Anchor at the scope you stated: you run the hiring loop for backend roles, about 40 interviews last year. The hard call has to come from you: pick one with a named trade-off, what you decided, and what you would weigh differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | F3 is your strongest direct row, and a VP asking about values tends to reach for it; VAL because it scores judgment, not process |
| M-B1 | "Sixty seconds: you've said you haven't managed managers. Why should we give you this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year" | Hold-then-concede. Concede first, plainly: "I haven't managed managers." Hold only what the quotes carry: a team lead of six, and the hiring loop you run for backend roles. Say these are adjacent, not the same, and say how you would learn the step up, as a plan. Hold through two follow-ups by returning to the quotes, never by adding to them | F8 is the likeliest skip-level objection; JD because it scores fit with the role, delivered as Pressure |
| M-B2 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the claim at the sentence's scope: you pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60 percent after. Concede specifically what you know others did and what you do not know about the drop. Answer slot: if you can say which parts were yours and which were your team's, say so in your own words; if the work was shared or you are not sure, say so plainly and return to what you pushed through. Do not fold on what you did, and do not widen it | F2 is the only figure and the persona stem is the standard Pressure probe; EXP because it tests attribution |
| M-C1 | "Hardware and software roadmaps run on different clocks. How would you plan engineering work against a hardware date you do not control?" | CASE | [generic] | Clarify what is fixed and what is movable, state a hypothesis early, then structure: buffers and dependency visibility, what engineering commits to versus targets, and what you would escalate. Say you would learn how this company's hardware cadence actually works. The guidance claims no hardware experience | F5 is the gap an executive may probe at altitude; CASE because it is a live planning problem |
| M-C2 | "In two years, what should engineering here be known for, and what would you have to say no to to get there?" | CASE | [generic] | Research did not run, so state no company strategy. Reason from the role description (two squads, device management, hardware and product partners) and ask the VP what the company is optimising for. State a hypothesis early, then name what you would decline | A skip-level prior tests altitude; CASE because it is a live reasoning problem, and generic because no strategy brief was available |

**Reverse questions, Round 3**

| # | Question | Why it lands |
|---|---|---|
| 1 | What do you want engineering leadership here to be known for? | It speaks at the VP's altitude and tests your M-C2 hypothesis |
| 2 | What does good look like for an engineering manager here in their first year, in your words? | It makes your success definition explicit before you are asked for it |
| 3 | What does support look like for someone stepping into two squads? | It addresses F8 honestly and invites coaching rather than defending |
| 4 | Where do you most want the engineering organisation to grow over the next two years? | It converts the values round into a conversation about direction |
| 5 | What is a leadership mistake you have seen here that you would want me to avoid? | It signals humility and surfaces the culture's real sore spots |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1: lead two squads | T-A2, T-B3 |
| F2: own delivery | T-A1, T-D1, H-A1, H-C1, M-B2, M-C2 |
| F3: hiring | H-A2, M-A4 |
| F4: growth | M-A3 |
| F5: hardware partnership | T-A3, T-B2, M-C1 |
| F6: product partnership | T-A3, H-C1, H-C2 |
| F7: device-management domain | T-A1, T-B1, H-A3 |
| F8: managing managers | M-B1, M-A1 |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't managed managers." Then the step up as a plan, never a past |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't owned a hardware-adjacent roadmap." Then a plan, never a past |
| Led or owned delivery for two squads | Inflated form of F1 | F1's quote at its own scope: a team lead of six. The limit is the pack's observation: your material says one team, not two squads |
| The reliability quarter on its own produced the 60 percent drop | Inflated form of F2 | F2's quote at its own scope: the burden dropped after you pushed the quarter through. The limit is the pack's observation: your sentence says after, not because. T-D1 and H-A1 keep their slots inside that scope |
| Hired about 40 people, or ran hiring for the whole organisation | Inflated form of F3 | F3's quote at its own scope: you run the loop for backend roles, about 40 interviews. The figure stays on interviews |

## Sources

Provided documents: the role description, the three rounds and the recruiter's description of Monday, and your own four sentences about yourself, all from your message. No dossier was present and no CV was provided.

Searches sent (all refused by the host, so none returned results):

- "Larkfield Systems industrial IoT values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems strategy news device management" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have moved the values cheat sheet for Round 3 and the VAL themes; without it there is no section 10 |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. It would have moved loop detection beyond your own and the recruiter's words, and the persona weights per round |
| 3. `Larkfield Systems strategy news device management` | unavailable | The search was refused. It would have moved a CO question grounded in current strategy and M-C2; those are generic here |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form; the interviewer reads are absent and the upgrade menu says what a name would unlock |
| 5. representative `Engineering Manager` JD | skipped | The role description in your message fixes the requirement rows F1 to F7 and the JD-tagged questions |

## Upgrade menu

- Larkfield's published values or principles (paste the page, or allow web search) → a values cheat sheet for Monday, with each value mapped to one of your quoted sentences or a scaffold
- Permission for web search, or a pasted strategy brief → the generic CASE questions M-C1 and M-C2 gain a researched CO question; a deeper pass is offered once: up to 6 more searches and 2 more fetches, several more minutes
- Your CV → F1 to F4 regraded against its own sentences, and a second quote source for rows currently at medium or none
- The recruiter's note on Thursday's format (any exercise, a system-design or case portion, whether the staff engineers would sit in your squads) → persona reweighting for Round 2 and a build section for any declared deliverable
- Interviewer names, even first names and titles → an interviewer read per round, a reverse question tied to their path, and adjusted persona weights
- Your answers to the slots in F1, F2, F4, F6 and F7 → those rows upgrade from discovery or transferability to quoted evidence, and the matching banks regenerate
- Your prep hours before each round → a prep triage sized to the time
- A `tuesday-dossier.md`, which this pack can save at your request with the gaps this prep exposed → carries them into later sessions, never required
