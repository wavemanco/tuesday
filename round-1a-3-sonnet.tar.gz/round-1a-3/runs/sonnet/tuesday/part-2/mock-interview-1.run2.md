Searches were refused, so I'm building the pack from your inputs and saving it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-1-denied-234da09a/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`.

I built it for one 60-minute peer conversation with Dan. It rests on your JD highlights and your summary of Priya, not the full JD or her CV. The three web searches I tried were refused, so Northwind's published values, its interview loop and Dan's public footprint come only from your notes. Nothing came from memory. The pack's Sources section says which searches failed and what each would have added.

- **Pack contents:** 23 questions across seven personas, weighted toward Peer Evaluator and Data-Driven Prober.
- **Highest-ROI rehearsal:** C1, the "no classic sales-ops or quota-setting experience" objection from someone whose function is built on it.
- **Also pressed hardest:** the "required" partner-motion line and the ~$400M ARR attribution.
- **Left out:** the values cheat sheet, because your notes describe no values round.

Say the word and I'll play Dan on C1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: peer, both reporting to the same VP. Format: one 60-minute conversation.
**Candidate:** Priya. Built from your JD highlights, your summary of Priya, your note on Dan's profile and your research note. It is not built from the full JD or her CV, and every evidence cell below says so by its source.

## 2. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for you now.

**Highest-ROI rehearsal: C1.** The gap Priya stated sits in the craft Dan's own function is built on. It will be asked in some form, and C1 gets the deepest rehearsal. C3 and A5 are the same objection in other packaging, so rehearse them after it.

Bank letters skip F so that a question ID never collides with a fit-snapshot row.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Past behavior against what the company says it values. Here: behavior with equals, because no values-style round is detected |
| EXP | Work-experience deep-dive | Whether the claims about your past survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | The stated responsibilities and requirements, including the gaps |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem set in the role |

## 4. Fit snapshot

Requirements are quoted from your JD highlights. Evidence is quoted from your notes on Priya. F7 is not a JD line. It comes from the gap you stated, and its requirement is plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [inferred] | transferability | Your material says product strategy and ops, not GTM for a product line, and the words stay there: "nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's GTM line makes a probe on taking a product to market likely. If any of your work was a launch or a go-to-market plan, say what part was yours, in your own words; if none was, say so plainly and stay with the work your material carries |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | A confirmed, specific claim with nothing inspected behind it, so expect a probe on how the figure was counted. The words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's land, adopt, expand and renew line makes a probe on which stage the change moved likely. If you know, say which and how it was identified, in your own words; if not, or if it was not an analysis of those stages, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | A tool list with no analysis named behind it, so the pack does not coach it as a story. Answer slot: if you ran an analysis start to finish in either tool, say which and what it showed, in your own words; if someone else pulled the data, or you used one tool only, say so plainly |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not a designed motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of a partner motion was yours to design, say which part and how you decided; if none was, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with it as stated: "I set annual volume targets with cross-org consensus." A line with nothing inspected behind it, so expect a probe on how the consensus was reached |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | Use is what the material says, not building. The words: "I use AI tools daily." Answer slot: say which tools and what for, in your own words; if your use is as a user only, say so plainly |
| F7 | Sales-ops and quota-setting fluency, plain prose. Not a JD line; from the gap in your notes | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and you have stated it. The words: "I don't have classic sales-ops or quota-setting experience." Then how you would get up to speed, said as a plan and never as a past. Never a claim to that work, and nothing added to make the gap feel smaller |

Reading: no requirement in the material is a hard gate. "Required" on F4 is an experience requirement, so it is graded as a gap and likely probed directly.

## 7. Reading the interviewer

Public footprint was not searched. The searches were refused, so this read uses only the profile facts in your note.

| Signal | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| Profile self-describes as "relentlessly data-driven" | Your note on Dan's profile | Every number gets probed to its assumptions: B1, B2, B5, G2. Name your weakest assumption before he does | [grounded] |
| Career spine is "pricing and monetization roles" | Your note on Dan's profile | Case questions tilt toward pricing, packaging and unit economics: D2, D3. That is his native language, so say aloud where you want his judgment | [grounded] |
| "one early-stage-startup chapter" | Your note on Dan's profile | Builder stories land with him, and a big-company-pace probe is likely: C4. Your material carries no startup story, so none is offered | [inferred] |
| Director of Sales Strategy, same VP | Your note | Peer: he is pricing what you cost and add to his work. The stated gap F7 sits in his function's craft, which is why C1 is the highest-ROI prep | [grounded] |

Mirror opportunities: shared vocabulary only. His pricing and monetization spine meets F4, "built a partner-level revenue model used in carrier negotiations", at the level of revenue modeling. That is not pricing design, so do not stretch it. No shared career jump is offered, because no row's evidence carries Priya's side of one.

## 8. Persona table

Weights start from the relationship prior (peer), then move on Dan's signals. The loop comes from your words: one 60-minute session with Dan, with no values-style round named, so none is detected.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting, credit, "what would you need from me" | High. The peer row sets it dominant, and he reports to the same VP | Reciprocity framing: what you bring his team, not only what you need. Propose seam principles rather than pretending to know the seam |
| B. Data-Driven Prober | Line-by-line probing of numbers and models | High. The peer row pairs it with A, and "relentlessly data-driven" moves it up | Know what you can and cannot say about how each number was counted. Say plainly when you do not know. Name the weakest assumption first |
| C. Skeptic | Probing the stated gap, partner-motion depth, big-company pace | Medium-high. F7 is stated, F4 says "required", and a startup chapter invites a pace probe | Rehearse the one objection until boring. Use bridges only from adjacent work your material carries. Pair every gap with a ramp plan |
| D. Case / Strategist | Live problems on the two lines | Medium. His pricing spine tilts cases toward pricing, packaging and unit economics, but the peer row does not make it dominant. Your note supplies the vocabulary | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| E. Conversational | Opening "walk me through the journey", casual AI question | Low-medium. A single 60-minute conversation usually opens on rapport, and casual questions are still scored | A 90-second arc. Treat casual questions on JD topics as scored |
| G. Pressure | Time-boxed challenges, "how much was actually you" | Low. A collegial peer is unlikely to interrupt, but the same probes arrive inside B | Pause, restate, hold the position through two follow-ups, concede the specific limit |
| H. Values / Behavioral | Scenario probes on candor and data | Low. No values-style round is detected, and published values were not read | Choose stories in which the hard truth landed. Where none comes to mind, say so plainly |

## 9. Question banks

Roughly 23 questions, with depth following weight. VAL questions here are behavioral stems, not values-mapped, because no published values were read.

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | A4, C1, C4, D1, D3 |
| "identify whitespace across land/adopt/expand/renew" | B3, D1 |
| "run independent analysis in SQL and Tableau" | B3, B4 |
| "partner-motion design experience required" | B2, C2, C3, D2 |
| "strong cross-functional influence" | A1, A2, A3, B5 |
| "AI experience a plus" | E2 |
| Sales-ops and quota-setting (not a JD line; from your notes) | A5, B5, C1, C2, G1 |

### A. Peer Evaluator (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our two teams sit side by side. Where do you see the seam between Sales Strategy and GTM for the new lines, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles rather than a seam you cannot yet see: decisions sit with whoever answers for the outcome, shared inputs are agreed before either of you builds on them, and a disagreement is worked between you before it goes to the shared VP. Then the one thing your material carries on building agreement: "I set annual volume targets with cross-org consensus." Answer slot: the JD's cross-functional line makes a probe on a real disagreement likely. If one came up while you built that consensus, say what it was and what you did; if none did, or it was not yours to settle, say so plainly and stay with the targets | F5 is the only evidence for cross-functional influence, and a peer prices exactly this seam. JD because it scores the stated influence requirement; the peer delivery is why it leads the bank |
| A2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" and "set annual volume targets with cross-org consensus" | Give the principle in your own words: name who contributed, say what part was yours and no more. Anchor in the sentence that already carries credit language: "I proposed a store-surface change credited with a ~$400M ARR uplift". The verb is proposed and the credit is stated as given, so keep both. Answer slot: if others contributed to the change, say who and what they did; if the proposal was most of your part, say so plainly and stay with the proposal | A peer asks because you will share work with his team; F2 carries the credit language and F5 the cross-org setting. VAL because it scores behavior with equals, with no published value read |
| A3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Reciprocity, both halves. Needs: only asks you would truly make, such as access to the data and views his team runs on and an hour on how the team sees the two lines. Offer, at the scope your material carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if there is other work you have actually done that his team could use, say it in your own words; if the model is the nearest, say so plainly | F4 is the evidence closest to his monetization vocabulary. JD because it scores the cross-functional requirement; the reciprocity framing is the peer-row counter-strategy |
| A4 | "If we split the early GTM work on the two lines between our teams, how would you cut it?" | CASE | [generic] | Clarify before cutting: which line, what stage, who carries the number. Then cut by decision rights, not by task: what you would own end to end, what you would agree with him first, what stays his. Say where you would defer to his team's data and judgment, and name the cut you are least sure of. The question needs no claim about your past, so the guidance makes none | F1 is the requirement this tests, set against a peer's turf. CASE because it is a live problem on the seam; `[generic]` because it is a pattern, not a fact about Northwind |
| A5 | "Your background has no classic sales-ops or quota-setting work. How would you work from my team's quota and coverage data?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Plain acknowledgment first, then the plan. Say: "I don't have classic sales-ops or quota-setting experience." Then, as a plan and never as a past, say how you would get working fluency from his team's data and which parts you would ask his team to walk you through, in your own words. Do not call your volume targets quotas. Rehearse the full objection under C1 | F7 is the one gap you stated, and a Sales Strategy peer is the person most likely to feel it. Peer delivery lets the C1 objection arrive as a working question; JD because it scores fit to the role's data partnership |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Four slots, each in your own words, and the pack supplies none of them: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before he does. Your sentence sets the verb: "I proposed a store-surface change credited with a ~$400M ARR uplift", so stay on proposed and credited. Answer slot: if you do not know how the figure was counted, say so plainly and say who would; do not reconstruct a method | F2 is the headline number, and a self-described data-driven interviewer goes to it first. EXP because it tests whether the claim survives scrutiny |
| B2 | "How was the partner-level revenue model used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Start with the sentence: "I built a partner-level revenue model used in carrier negotiations." Answer slot: expect a probe on what went into the model and how it was used in the room. Say what you know, in your own words; if some of it was set by others, say which; if you do not know how it was used, say so plainly and stay with the model. Name the assumption you trust least before he asks | F4 is the nearest evidence to partner work and the likeliest to be probed for depth. EXP because it tests what was actually the candidate's |
| B3 | "Pick one new line. Which metrics would tell you whether its land, adopt, expand and renew motion is working, and which would you trust least?" | CASE | [generic] | Clarify which line and what stage it is in. Take the four stages in turn: for each, one metric as your hypothesis, the data it needs and how it could mislead you. Finish by naming the metric you trust least and what you would check first. Think aloud, and challenge one premise respectfully, such as whether all four stages matter equally at launch. The guidance makes no claim about your past | F2 and F3 are the requirements it carries. CASE because it is a live problem; it is the question a data-driven peer is most likely to set |
| B4 | "Tell me about an analysis you ran yourself in SQL or Tableau." | JD | [inferred] "skilled in SQL/Tableau" | Your notes say "skilled in SQL/Tableau" with no analysis named behind it, so choose one: an analysis you ran yourself, start to finish, with the question you asked, the data you pulled or built, what you found and what you would distrust in it. Answer slot: if you pulled the data yourself, say how, in your own words; if someone else pulled it, or you used one tool only, say so plainly. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | F3 is a thin, vague claim, and "independent analysis" will be tested by a data-driven peer. JD because it scores the stated tool requirement |
| B5 | "Walk me through the annual volume targets you set. What went into them?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | The sentence: "I set annual volume targets with cross-org consensus." Answer slot: expect a probe on what went into the targets and how the level was judged. Say what went into them, in your own words; if inputs came from other teams, say so; if you cannot say how the level was checked, say so plainly. Do not call them quotas | F5 is the nearest the material gets to the territory in F7, so a Sales Strategy peer will press here. EXP because it tests what was actually done |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background has no classic sales-ops or quota-setting work. What makes you the right person to own GTM for two new lines?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" and "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep in the pack.** Pause and restate it in one line. First, the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Second, what your material carries, at its own scope: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model used in carrier negotiations". State them and leave the weighing to him. Third, name the limit before he asks: the part of this role closest to his team's craft is the part you would lean on him and his team for. Follow-up 1, that volume targets are not quotas: agree you are not claiming they were. Follow-up 2, what you know of how targets land with the people who carry them. Answer slot: say what your own work showed you if anything; if nothing, say so plainly and say how you would find out. Follow-up 3, why not hire from sales ops: return to what the JD asks you to own and to partnering with his team, and do not argue the gap away | F7 is the one gap you stated; F4 and F5 are the nearest work the material carries. Calibrated candor beats bluffing a competency the interviewer's own function owns. JD because it scores fit to the stated role, delivered as a Skeptic probe |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" | Pick one and say it first. The sourced candidate is the gap you stated: "I don't have classic sales-ops or quota-setting experience." The other honest candidate is partner-motion design: your material says "I built a partner-level revenue model used in carrier negotiations" and nothing about a designed motion. Answer slot: if you have designed part of a partner motion, say which part and how you decided; if the model is the nearest, say so plainly. Pair the weakness with a ramp plan in your own words | F7 and F4 are the two weakest rows. JD because it scores honest self-assessment against the listed job |
| C3 | "The role lists partner-motion design experience as required. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The sentence: "I built a partner-level revenue model used in carrier negotiations." The pack's observation is that the material says a model, not a designed motion, and wording must not close that distance. Answer slot: if any part of a partner motion was yours to design, say which part and how you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the model. Hold through one follow-up by returning to the model, never by adding to it | F4 is where the JD's "required" wording presses hardest, and a required line is likely probed directly. JD because it scores the stated requirement |
| C4 | "You have spent nine years at one large company. What would you do differently at a company our size?" | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A pace-and-builder probe, sharper from an interviewer with a startup chapter. The context is only what the sentence says: nine years at a large consumer-tech company in product strategy and ops. Answer slot: if there was a time you worked without the usual machinery, say what it was and what you did; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would work at this scale. Do not call your work scrappy or startup-style unless you can name the time | F1 holds the tenure the probe aims at. EXP because it tests whether experience transfers; the startup signal is why it is in this bank |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Two new lines, and a much larger platform vendor bundles against us. Where do you look for whitespace first, and what do you need to know before you say?" | CO | [grounded] "bundling by a much larger platform vendor" — your research note | Clarify first: which line, which customers, what the bundle includes and at what price. Then objective, a split by land, adopt, expand and renew, approach, metrics and risks. Use the vocabulary from your note: enterprise expansion is a stated priority and bundling is the named threat. Challenge one premise respectfully, such as whether the whitespace is in new logos or in the adopt and expand stages. Say what you would not claim yet. The guidance makes no claim about your past | The note's competitive frame is the CO ground. F2 is the requirement it carries. CO because it tests the company's current frame; CASE is the delivery |
| D2 | "Suppose a bundled alternative is priced near zero at the margin. How would you price and package a new line against it?" | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Clarify what is bundled, who the buyer is and what your line is compared with. Then the value metric, the packaging and how partners or channels change the answer, and state your weakest assumption. He is native to pricing, so say aloud where you want his judgment. Your material says "I built a partner-level revenue model used in carrier negotiations". That is revenue modeling, not pricing design, so do not stretch it | His pricing and monetization spine tilts the case this way. F4 is the nearest monetization evidence, with its limit named. CASE because it is a live problem in his native vocabulary |
| D3 | "Profitability is a stated priority. How do you decide which of the two lines gets the next dollar of GTM investment?" | CASE | [grounded] "reaching profitability" — your research note | Clarify the horizon and what counts as payback. Name criteria before scoring: size of the whitespace, cost to win, time to payback and fit with the other priorities. Say what data you would need and which you would distrust, then give a recommendation with a trigger for changing it. The guidance makes no claim about your past | Profitability is one of the three priorities in your note, and unit economics is his angle. F1 is the requirement it tests. CASE because it is a live allocation problem |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" and "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc built only from your sentences: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Then the two pieces that carry weight, on their own verbs: "I built a partner-level revenue model used in carrier negotiations" and "I proposed a store-surface change credited with a ~$400M ARR uplift". Close on why this role. Answer slot: give your actual reasons for moving and for Northwind, in your own words; the pack supplies none | F1, F2 and F4 are the three pieces the arc draws on. EXP because the opening is scored on what the CV claims; the casual register is the Conversational delivery |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Casual register, scored question. The sentence: "I use AI tools daily." Answer slot: say which tools and what for, in your own words; say plainly whether your use is as a user and not as a builder of AI products, because his next question may be about Compass, one of the three priorities in your note. Do not stretch use into building | F6 is thin, and the JD's AI-plus line is the likeliest casual follow-up. JD because it scores the stated plus |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has run partner programs and sales ops?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" and "No classic sales-ops or quota-setting experience." | Pause, restate, then answer in sixty seconds. The position held is what your sentences carry: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus", said without comparing yourself to the other person. Hold through two follow-ups by returning to those sentences, never by adding to them. Concede the specific gap in plain words: "I don't have classic sales-ops or quota-setting experience." Do not fold on the core claim to restore harmony | F4, F5 and F7 are the claim and the limit. Pressure is low-weight with a collegial peer, but the move is still worth one rehearsal; JD because it scores fit against the field |
| G2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold, then concede. The sentence: "I proposed a store-surface change credited with a ~$400M ARR uplift." Hold it through two follow-ups. Concede specifically. Answer slot: if others built, launched or measured the change, say so and say who; if the proposal was the extent of your part, say so plainly. Never move from proposed to led, and never accept a summary that is smaller or larger than your sentence | F2 is the headline figure and the likeliest attribution probe. EXP because it tests what was actually yours; the stem is the Pressure persona's own |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told leadership something they did not want to hear. It needs a named stake, what you said, how it landed and the state of the relationship afterwards. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem; candor with equals matters to a peer who will review your numbers. VAL because it is behavioral, with no published value read to map it to |
| H2 | "Tell me about a time the data contradicted your recommendation." | VAL | [generic] | Selection scaffold: pick a time the numbers went against what you had proposed. It needs the recommendation, what the data showed and what you did next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the interviewer's own words, "relentlessly data-driven". VAL because it scores behavior toward evidence, not a published value |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Your background runs through pricing and monetization roles and now Sales Strategy. How does the pricing lens show up in how you plan targets and coverage?" | Tied to his own career path. It turns the hardest probe in C1 into a peer conversation, and it signals you researched him |
| RQ2 | "What would a new peer do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load, not only your own |
| RQ3 | "Where do your team's work and the GTM work on the two lines overlap or collide today, and how would you want disagreements to be settled?" | Shows seam awareness, and gets his real answer before you commit to a seam |
| RQ4 | "Of enterprise expansion, Compass and profitability, which pulls hardest on the two new lines, and is that tension settled?" | Uses the three priorities from your note and tests whether you can think at the company's altitude |
| RQ5 | "Which numbers and views does your team trust most today, and where do you wish the data were better?" | A data-driven peer will have a strong answer, and it shows you plan to work from his data, not around it |
| RQ6 | "What would success look like at six months for whoever holds this role, in numbers you and I would both look at?" | Makes the shared measure explicit and invites him to set the bar |

## 13. Prohibited claims

Built from the fit snapshot before the banks were written. The banks hold nothing on this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Sales-ops or quota-setting experience, including volume targets described as quotas | Negative you stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Separately, F5's quote at its own scope: "set annual volume targets with cross-org consensus". No slot on the first |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a model used in carrier negotiations, not a designed motion. C3's slot stays inside the model |
| Did pricing or monetization design | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says revenue modeling, not pricing |
| Drove, led or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". G2's slot asks only who else did what |
| Owned GTM for a launch or a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The limit is the pack's observation: the material does not show a launch |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". E2's slot asks only about use |

## 14. Sources

**Provided documents:** your message, which holds the JD highlights, the summary of Priya (quoted as the coach's notes), the summary of Dan's profile and your research note (three stated priorities and the bundling threat). The research note is undated, so its freshness is unchecked. No `tuesday-dossier.md` was present.

**Searches sent, all refused, so nothing came back:**

- "Northwind Data company values data infrastructure" — refused
- "Northwind Data interview process strategy GTM" — refused
- "Dan Kovac Northwind Data Director Sales Strategy" — refused

No pages were fetched. Nothing from model memory was used for values, loop or interviewer facts.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have named published values for the H bank and decided whether a values cheat sheet applies. The H questions are behavioral stems instead |
| 2. `Northwind Data interview process` | unavailable | Would have checked the loop. Your words already establish one 60-minute conversation with Dan, so persona weights stand on them |
| 3. `Northwind Data strategy` / recent news | skipped | Could not have moved the CO bank: your note already supplies the three priorities and the bundling threat |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have added Dan's public themes to the interviewer read and a tailored RQ1. Both rest on the profile facts in your note |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot rows and the JD-tagged questions |

## 15. Upgrade menu

- Search permission → rows 1, 2 and 4 become researched: published values by name, a documented loop, and Dan's public talks and writing for the interviewer read and RQ1
- A deeper research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and recent org context for the CO and CASE banks. It runs only if search is permitted and you ask
- The full JD text → F1 to F6 requirements become full quoted lines, and any mid-list requirement missing from your highlights gets a question
- Priya's CV → evidence cells quote her own document instead of your summary, and tenure and figures can be checked
- The document that credited the ~$400M, and the written method of the carrier revenue model → F2 and F4 can move from medium toward high
- Priya's own answers to the answer slots in F1, F2, F3, F4, F5 and F6 → those rows become story-mapped guidance
- The recruiter's prep email, if one exists → stated focus areas, and a build section for any pre-declared deliverable
- The date of your research note → confirms the priorities are current, since a note older than about six months may be stale
- A `tuesday-dossier.md` from an earlier evaluation, if you have one → verified evidence and a list of claims to avoid, so the objection rehearsal rests on checked facts
