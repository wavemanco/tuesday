Researching Stripe's published values, interview process and recent strategy now, before I build your prep pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-3-denied-a78f8882/stripe_product-operations-manager_interview_pack.md`.

Web search was refused, so nothing about Stripe's values, interview loop or strategy comes from research. I didn't fill those in from memory. The pack assumes a final round with an unknown interviewer and no JD or CV, so every row is generic. It has 21 questions across seven interviewer styles. B1 ("which part of this role would you be weakest at on day one?") is flagged as the highest-ROI prep.

Say the word and I'll play the Skeptic on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round (hiring manager, peer, skip-level, cross-functional), and did the recruiter name any focus areas or a deliverable like a presentation? The answer reweights every bank.
2. Can you paste the job description and your CV? Or say "proceed without" and I'll keep the pack generic. With both, the generic rows become your real stories.
3. Do you meet the role's work-authorization and location or office-attendance terms? Your material doesn't establish this, so the pack carries it as an open gate.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. Interviewer name and relationship not yet known.
**Mode:** session, with blended persona weights, because the final round's makeup is unknown.
**Built on:** the company, the role and the round name only. No job description, no CV, no research results. Every row below is generic until you add those.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Nothing here says what you did, because you have not told me yet. Where an answer needs a story, the guidance tells you how to choose one, and every story must be one you actually lived, told in your own words.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

No job description and no background were supplied, so this is the worksheet variant. The requirements are role-family patterns for product operations, written as plain prose and not quoted from any posting. Replace them with the real ones when you paste the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional launch or planning processes across several teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a named launch or planning cycle, the teams in it, your part in it and what changed. Selection scaffold: pick one cycle that has a named set of teams, a part that was yours, and a visible result. If no such cycle comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F2 | Design and run an operating cadence such as planning, reviews and status rituals (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a recurring forum you set up or ran, who attended, and what decisions it fed. Selection scaffold: pick a recurring forum where you can say what it decided and what you kept out of it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build one |
| F3 | Define and use metrics to make or challenge decisions (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a figure you reported, how it was counted, and the decision it changed. Selection scaffold: pick one figure whose counting method you can explain from end to end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set the metric up |
| F4 | Influence peers and leaders without formal authority (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a case where you needed another team's change and had no power to order it, with the outcome and the relationship afterwards. Selection scaffold: pick one where the other side's reasons were real. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Build or improve processes and tooling that teams actually adopt (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a process or tool you changed, who used it afterwards, and how you know. Selection scaffold: pick one where adoption, not design, was the hard part. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would drive adoption |
| F6 | Communicate clearly and briefly to senior leaders, in writing and aloud (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a leadership update or recommendation you wrote or gave, and what was decided. Selection scaffold: pick one where you had to be brief and leave something out. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would structure one |
| F7 | Work-authorization and location or office-attendance terms for the role (role-family pattern, no posting) | none given | none | [generic] | hard_gate | Your material does not establish whether this is met. This is a term you meet or do not, so it is surfaced and not bridged, and wording cannot change it |

## Persona table

No loop source was read, so the pack falls back to the Generic archetype, and says so: persona weights rest on a pattern, not on a documented Stripe process. The round type and your relationship to each interviewer are unknown, so the weights are close to flat. That makes this pack noticeably weaker than one built with that answer.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live problems from the job: plan a launch, set up a cadence, diagnose a metric | [generic] Highest of a flat set: product operations is a role defined by process and metric problems, and a final round often tests structure | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic (bank B) | Quiet probing of day-one weakness, motivation and role definition | [generic] High: a final round is where remaining doubts get tested | Rehearse the most predictable objection until it is boring. Use only adjacent evidence you actually have, and name limits plainly |
| Peer Evaluator (bank C) | Seam-splitting with product and engineering, credit and disagreement | [generic] Mid: a cross-functional role is usually judged by the teams it serves | Reciprocity framing: what you bring their team. Propose seam principles, not a claimed map |
| Values / Behavioral (bank D) | Scenario probes, STAR-shaped stories | [generic] Mid: no published values were read, so this tilts on stems, not on named values | One story per theme, chosen before the interview. We for context, I for your contribution |
| Data-Driven Prober (bank E) | Walks a number back to its inputs | [generic] Mid: product operations leans on metrics | Know how each figure you cite was counted, and say plainly when you do not know |
| Conversational (bank G) | Friendly, unstructured openers | [generic] Low-mid: casual questions are still scored | A 90-second arc for the biography question, built only from what you did |
| Pressure (bank H) | Interrupts, time-boxes, tests composure | [generic] Low: possible in a final round | Pause, restate, anchor in what you actually did, hold through two follow-ups before conceding anything real |

## Question banks

Question IDs skip the letter F so they never clash with the fit-snapshot rows. Every Provenance cell is `[generic]` alone because no guidance here makes a claim about your past. Each question that asks for a story supplies no event, and each guidance ends in the honest branch.

**The highest-ROI prep in this pack is B1.** With no CV I cannot name your most predictable objection, so this is the persona stem most final rounds reach. Once I see your background, B1 gets replaced with the specific objection.

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three teams are two weeks from a joint launch and disagree on whether it is ready. Where do you start?" | CASE | [generic] | Clarify first: what does ready mean to each team, who decides, what does slipping cost. State the objective, split the disagreement into scope, quality, risk and communication, then propose agreed readiness criteria, one shared view, a named decision owner and an escalation point. Name the signals you would watch and one risk. Challenge one premise, such as whether the date is fixed | Tests F1 as a live decision. CASE because it asks about no past, so it presupposes nothing about you |
| A2 | "You are asked to set up a planning and review cadence for a product organization that has none. What do you build first, and what do you leave out?" | CASE | [generic] | Clarify who attends and which decisions the cadence must support. Start minimal, tie each ritual to a decision it feeds, say how you would know it is working, and name what you would stop. Think aloud through the trade-off between coverage and meeting load | Tests F2 and F5. Leaving things out is where structure shows |
| A3 | "A key adoption metric for a recent feature dropped 20% week over week. Diagnose it." | CASE | [generic] | Clarify the metric definition, instrumentation and time window. Check for a data or logging cause before a real change. Segment, then form internal and external hypotheses, say what you would look at first, and who you would tell and when | Tests F3. A stock stem for this persona |
| A4 | "Where do you think a product operations team can add the most value at Stripe?" | CO | [generic] | This pack holds no researched strategy, so it cannot supply content. Prepare from the company's own published material you read yourself: name one thing you read, where you read it, and what you would ask about it. If you have read none yet, say so plainly and say how you would learn it in your first thirty days | CO goes generic without research. See the upgrade menu |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Decide your honest answer before the interview. Name it plainly in one sentence, then give a concrete first-thirty-day plan to close it. Do not name a fake weakness and do not claim to have none. If no real weakness comes to mind, say what you would most want to learn first | The highest-ROI prep. This question arrives in some form, and a calm rehearsed answer changes the interview. JD because it scores the role's stated needs |
| B2 | "Why this role, why Stripe, and why now?" | CO | [generic] | Three beats in your own words: what pulls you toward product operations, what you have actually done that is relevant, and why now. Add nothing about Stripe that you did not read yourself | Motivation consistency is scored. CO because the company half needs homework |
| B3 | "In your own words, what is the difference between product operations and program management?" | JD | [generic] | Give a short definition, one example of each in action, and where they overlap. Name the part of the overlap you would want clarified with this team | Tests whether you understand the role you are applying for (F2, F5). No claim about your past |
| B4 | "Product operations can look like overhead. How would you show this team is worth its headcount?" | JD | [generic] | Choose outcomes the team can own, split leading from lagging signals, say how you would set a baseline, and state honestly what the team cannot prove. Say what you would stop doing if it did not move a decision | Tests F3 and F5 together. The question carries a generic premise, not a claim about you |

### Bank C: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, such as who owns the decision and who owns the follow-through, and do not pretend to know their actual seam. Describe how you disagree: state the shared goal, the evidence, and the point where you would escalate. Show both spine and tact | Tests F1 and F4. Collegial packaging of an objection from other banks |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick one case where several teams contributed and you can say which part was yours. We for context, I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F4. An open prompt, so it supplies no event |
| C3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity framing: offer what you would bring their team first, then two or three specific asks, such as access, context or introductions. Do not ask for anything you could find yourself | Tests partnership fit |

### Bank D: Values / Behavioral

No published Stripe values were read, so these themes come from the persona's standard stems and not from named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a point where you did not soften the message, and a relationship that was intact afterward. The hard truth should actually have landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F6. Open prompt from the persona stem |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a specific decision with a named trade-off, what the metric cost, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Open prompt from the persona stem |
| D3 | "A stakeholder you depend on keeps missing commitments, and they do not report to you. What do you do?" | VAL | [generic] | Delivered as a case: clarify why the commitments slip, agree what matters to them, make the cost visible, try a direct conversation before escalating, and say what you would escalate and how. It asks about no past, so it presupposes nothing | Tests F4 through a hypothetical, which is safe if you have no matching story |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you reported to leadership in a past role. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick a figure whose counting you can explain end to end. Cover how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. If there was no such figure, say so and describe how you would count one | Tests F3. The defend-the-number rehearsal, run on a figure you choose |
| E2 | "For that number, which assumption would you defend least?" | EXP | [generic] | Name the weakest assumption yourself, in your own words, before they do. This turns a gotcha into a credibility gain. If you do not know, say so plainly | Follow-up to E1. The weakest-assumption move |
| E3 | "How would you choose the three metrics a new product operations team reports on every week?" | JD | [generic] | Start from the decisions the metrics support, split leading from lagging, limit each to one owner, and say what you would drop. State what you would want to learn from the first month of data | Tests F3 as a design problem. No claim about your past |

### Bank G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc in your own words: where you started, the two or three steps that matter for this role, and why this role is next. Include only what you did. This pack cannot write the arc until it sees your CV | Casual register, but scored for economy and interest |
| G2 | "Casually, how do you decide whether a process is worth fixing at all?" | JD | [generic] | Give a short rule of thumb: cost of the friction, how many people it touches, whether someone owns the fix, and whether it will stick. Show you would leave some things alone | Tests F5 in a casual register. No claim about your past |

### Bank H: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate the question. Give two points you can support from what you have actually done, and do not disparage anyone. Hold your position through two follow-ups, then concede any real uncertainty specifically, without folding on the core claim | Composure test. The pack cannot supply the two points until it sees your background |
| H2 | "Pick one result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result where you can separate your part from the team's. Use we for context and I for your contribution, and say plainly which part was not yours. Hold through two follow-ups. If you cannot separate it, say so and choose a different example | Attribution honesty is the thing being scored. Open prompt from the persona stem |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 Cross-functional launch or planning | A1, C1 |
| F2 Operating cadence | A2, B3 |
| F3 Metrics and decisions | A3, B4, E1, E2, E3 |
| F4 Influence without authority | C1, C2, C3, D3 |
| F5 Process and tooling adoption | A2, B3, B4, G2 |
| F6 Senior communication | D1, A4 |
| F7 Work-authorization and location terms | none, because it is a term you meet or do not and not something to rehearse. The message asks about it directly |

## Reverse questions

Each carries a why-it-lands line. None is tied to an interviewer's career path because no interviewer profile was supplied.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like for this role at ninety days, and how would you know?" | Shows outcome orientation and gives you a target to prepare against |
| R2 | "Which decisions do you most want product operations to make easier?" | Shows you think of the role in terms of decisions, not meetings |
| R3 | "Where does work most often get stuck between teams, and what has been tried?" | Invites a candid answer and shows you expect friction |
| R4 | "What would you change about how the team plans or launches today?" | Signals you will diagnose before prescribing |
| R5 | "How is the role's impact measured, and who decides?" | Shows you care about accountability and gives you the real scoring sheet |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Use if the interviewer is a peer. It is a reciprocity question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entries yet | You have given no material about your past, so there is no sentence for this pack to inflate and no stated negative to give back | Anything you say about your past must be something you actually did, at its real scope. Once you share your CV, this section lists the stretched forms of your own sentences that the pack will not coach |

## Sources

Provided documents: your message naming the company, the role and the final round. No job description, CV, interviewer profile or dossier was supplied.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused, so nothing from the web is used in this pack:

- Stripe operating principles values: refused
- Stripe interview process product operations manager: refused
- Stripe strategy 2026 news annual letter: refused
- Stripe Product Operations Manager job posting: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have fed the values cheat sheet with official value names. The section is dropped, and bank D uses generic stems |
| 2. `Stripe interview process product operations` | unavailable | Would have named the real rounds. The pack falls back to the Generic archetype and flat persona weights |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded A4 and the CO questions. They are generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned the generic requirements in the fit snapshot into quoted, inferred ones |

## Upgrade menu

- The job description text → F1 to F6 become quoted requirements instead of role-family patterns, and the JD-tagged questions become `[grounded]`
- Your CV → every evidence cell fills, bridges become story maps, B1 becomes your specific objection, and the prohibited list gets real entries
- Who you are meeting and what the recruiter said about focus areas or a deliverable → persona weights stop being flat, and any announced presentation or take-home gets its own build section
- The interviewer's name → an interviewer read and a reverse question tied to their career path
- Your answer on work authorization and location or office attendance → F7 is either closed or carried as a risk
- Web research, which was refused this time → the official values (a values cheat sheet), the documented loop structure, and current strategy for A4. A deeper pass is available once: up to 6 more searches and 2 more fetches, several more minutes
- The time you have before the interview → a prioritized prep schedule
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, the objection worth deepest rehearsal, and absolute limits on what to claim
