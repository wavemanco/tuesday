Web searches were refused, so I'm building the pack from your material alone and recording that in its Sources section. Writing the file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-1-denied-5693a3a2/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`. I built it for a 60-minute peer conversation with Dan. It has 20 questions: 5 from the Data-Driven Prober, 4 from the Peer Evaluator, 3 each from the Skeptic, Case/Strategist and Conversational personas, and 2 from the Pressure persona. Every question has a type tag, answer guidance and a rationale.

Web searches were refused, so nothing about Northwind or Dan comes from research. Everything rests on your material, and the Sources section says what each skipped search would have added. The pack leaves out the graded-deliverables, grounding-brief, values cheat sheet and delivery-coaching sections. The pack file also holds the fit snapshot, interviewer read, persona table, six reverse questions and a prohibited-claims list.

The highest-ROI rehearsal is **C1**. Dan, as Director of Sales Strategy, will likely raise Priya's lack of classic sales-ops or quota-setting experience. The guidance is to acknowledge it briefly, bridge from the evidence you gave without calling her volume targets "quotas", and concede exactly. The other likely pressure point is the roughly $400M figure (A1 and F1). The guidance sticks to your wording that she proposed the change and the uplift was "credited".

Say the word and I'll play Dan the Prober on A1, or the Skeptic on C1. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste Priya's CV lines as written and the full JD text? Several guidance cells are selection scaffolds because only your summary was available, and her actual sentences would turn them into story maps.
2. Did the recruiter say anything about what Dan's conversation will cover, such as focus areas or a pre-assigned deliverable? That would reweight the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Format:** one 60-minute conversation.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding for a spoken answer, not a script. Where a row says "answer slot", the pack has no fact to give you, so the answer has to come from your own experience, and there are two honest branches.

| Tag | What it tests |
|---|---|
| VAL | Whether past behavior shows how you work with peers and other teams |
| EXP | Whether the claims on your CV survive scrutiny, and what was actually yours |
| JD | Whether you can do the job as listed, gaps included |
| CO | Whether you can think at Northwind's altitude: its priorities and competition |
| CASE | A live problem from the role, scored on structure and reasoning |

Question IDs run by persona (A, B, C and so on) so that drills can point at them.

## Fit snapshot

The requirements are your JD highlights. The evidence column holds only the coach's own words, quoted. Rows F1 to F6 are the JD highlights in order. F7 is a gap your notes raised, not a JD line.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights in your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes; "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | transferability | The material shows a proposal and a set of targets, not a go-to-market for a product line, and the words stay at that scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift" and "I set annual volume targets with cross-org consensus." Answer slot: the JD's two-product-lines line makes a probe on taking a product to market likely. If you had a part in a product's launch or go-to-market, say which part and what was yours, in your own words; if there was no such work, or it was not yours, say so plainly and stay with the proposal and the targets |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights in your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote touches revenue growth without showing whether it reached whitespace across the customer lifecycle. Answer slot: expect a probe on how you would find whitespace. If any of your work looked at where adoption, expansion or renewal fell short, say what you looked at and what part was yours; if none did, say so plainly and say what you would look at first |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights in your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, and Dan's profile says "relentlessly data-driven", so expect it to be probed. Lead in the quote's own terms: skilled in SQL and Tableau. A2 holds the answer slot for which analysis you would walk him through |
| F4 | "partner-motion design experience required" — JD highlights in your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not a designed partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the word "required" makes a probe on your part in how the model was used likely. If you had a part in how it was used, say what part; if you did not, or you do not know how it was used, say so plainly and return to the model you built |
| F5 | "strong cross-functional influence" — JD highlights in your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a CV-style line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you set annual volume targets, with cross-org consensus. It says volume targets and cross-org consensus, and the words stay there |
| F6 | "AI experience a plus" — JD highlights in your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | Say it as the quote has it: "I use AI tools daily." The material does not show building or launching AI products, and nothing here claims it. Answer slot: expect a casual probe on what you use them for. Name the tools and the tasks in your own words; if the use is light, say so plainly |
| F7 | Sales-side operating experience, the lens a Director of Sales Strategy applies; not a JD line, raised by the coach's notes | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it was stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to quota-setting, and nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only. Every signal below comes from the profile description in your message, so no web research backs this section.

| Signal (from your message) | What it likely means for the conversation | Provenance |
|---|---|---|
| Profile self-describes as "relentlessly data-driven" | Every number you cite gets walked to its inputs and assumptions. Know what you can and cannot say about how the figure was counted | [inferred] |
| Career spine in pricing and monetization roles | Pricing, packaging and unit-economics language is his native register. Open with a hypothesis, tie it to money, and say what data would change your mind | [inferred] |
| One early-stage-startup chapter | A builder-pace story may land, and expect a probe on comfort with ambiguity. It is one chapter, not a founder path, so do not over-tilt the delivery | [inferred] |
| Peer, same VP | He is pricing what the hire costs and adds to his own work. Lead with reciprocity: what you bring his team, not only what you need | [inferred] |

**Mirror opportunities.** His monetization spine and your F4 evidence share a vocabulary: "built a partner-level revenue model used in carrier negotiations." F2's evidence, "proposed a store-surface change credited with a ~$400M ARR uplift", is revenue-side work too. Neither is a shared career jump, so use them as shared vocabulary only, never as shared path. No row of evidence carries a startup chapter on your side, so that one is not offered as a mirror.

## Persona table

The loop is the one 60-minute conversation with Dan that your note describes, with a peer prior. No archetype fallback is used.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Data-Driven Prober | Line-by-line probing of any figure: inputs, denominators, validation, two levels deep | High. Peer prior, his "relentlessly data-driven" self-description, and the one hard figure in your material | Know how the figure was counted, or say plainly you do not. Name the weakest assumption before he does. Offer to walk through an analysis end to end |
| B. Peer Evaluator | Seam-splitting between his team and your role, "what would you need from me", credit and disagreement | High. Peer prior, and shared VP means he will live with the answer | Reciprocity framing. Propose seam principles instead of pretending to know the seam. Disagreement stories that show spine and tact together |
| C. Skeptic | Quiet persistence on the gaps: no sales-ops or quota background, consumer-tech to B2B | Medium-high. F7 and F4 are the visible gaps, and sales-ops and quota-setting are his own turf | Rehearse the single predictable objection (C1) until it is boring. Bridge only from adjacent evidence you stated. Calibrated candor over bluffing a competency he owns |
| D. Case/Strategist | A live problem on pricing, packaging, whitespace or GTM | Medium. A peer less often runs a case than a hiring manager, but his pricing spine and the JD's analysis focus raise it | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| E. Conversational | Friendly opener, "walk me through the journey", casual AI chat, the reverse-question slot | Medium. A one-hour conversation always has this register, and it is still scored | A tight 90-second arc, casual questions treated as scored, and never "I think you've covered everything" |
| F. Pressure | Interruptions, "how much was actually you", time-boxed answers | Low. A peer rarely runs stress, but the attribution probe can arrive inside Prober questions | Pause and restate. Hold the position through two follow-ups. Concede specifically, never on the core claim |
| Values/Behavioral | Scenario probes against published values | Low. No loop source names a values round, and no values page was obtained. Two VAL questions come from the peer persona stems (B2 and B3) | Story selection from your real material, with the honest branch |

## Question banks

The highest-ROI rehearsal in this pack is **C1**: the question about no classic sales-ops or quota-setting background, from a Director of Sales Strategy. It will arrive in some form, and a rehearsed non-defensive answer changes the conversation.

### A. Data-Driven Prober (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The roughly $400M ARR uplift attached to your store-surface proposal: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the sentence at its own scope: you proposed the change, and the uplift was credited to it. Four answer slots follow, each in your own words. How the figure was counted. What it is sensitive to. The assumption behind it you would defend least; name it before Dan does. Which part was yours. If you do not know how it was counted, say so plainly. Hold the position by returning to "proposed" and "credited". Do not describe a method you cannot repeat under a second question | F1 and F2 carry the only headline figure, so it is a magnet target for a data-driven peer; EXP because it tests attribution and counting, not the JD |
| A2 | "Tell me about an analysis you ran yourself in SQL or Tableau, end to end." | JD | [grounded] "skilled in SQL/Tableau" | No quoted sentence carries a story, so this is a selection scaffold. Pick one analysis you did hands-on. It needs the question you were asking, where the data came from, what you queried, what you concluded and what changed. Say the claim as the quote has it, then tell the one you pick. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | F3 is the JD's analysis requirement and has nothing inspected behind it; JD because it scores the stated skill, and Dan's self-description makes a walk-through likely |
| A3 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: a partner-level revenue model, and its use in carrier negotiations. Tell those in your own words. Answer slot: his pricing spine makes a probe on what the model rested on and how the negotiation used it likely. If you can say, say it in your own words; if a part was not yours, or you do not know, say so plainly and return to the model you built | F4 is the evidence closest to monetization, so a pricing-spine peer will go deepest here; EXP because it tests what was actually built and by whom |
| A4 | "The role lists partner-motion design as required. What part of that have you done yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you had a part in how the model was used in the negotiations, say what part, in your own words; if you did not, say so plainly, and return to the model you built. Hold through two follow-ups by returning to the model, never by adding to it | F4 is the JD's hard requirement and the widest distance between the material and the line; JD because it scores the stated requirement |
| A5 | "Walk me through how you set the annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience" | Beats the quote states: annual volume targets, with cross-org consensus. Say it in those words. Targets are not quotas in your own notes, so do not let the word drift. Answer slot: target-setting is his turf, so expect a probe on where the numbers came from and how consensus was reached. If you can say what the basis was and what part was yours, say it; if there was no formal basis, or it was not yours, say so plainly and return to the targets. If he asks whether this was quota-setting, your own words: "I don't have classic sales-ops or quota-setting experience." | F5 is the closest evidence to his core craft, and he will test where it stops; EXP because it tests the claim, and the second quote keeps the guidance from stretching it |

### B. Peer Evaluator (weight: second, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your role and mine, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know Northwind's actual seam: ask Dan where he sees it first, then offer a principle such as one set of definitions and an agreed route for escalation. Frame it as what you would bring his team, not only what you need. No claim about your past is needed here | The JD's cross-functional influence line (F5) is exactly what a peer tests first; JD because it scores the listed responsibility, and `[generic]` because it is a pattern for the problem, not a fact about Northwind |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-map on the one quoted sentence: annual volume targets, with cross-org consensus, in those words; use "we" for context and "I" for your contribution. Answer slot: if credit or ownership was unclear at any point, say what happened and what part was yours; if it never was, say so plainly and stay with the targets | F5 is the only cross-org evidence, and credit-sharing is a standard peer probe; VAL because it scores working behavior, not a deliverable |
| B3 | "Tell me about a time you disagreed with another team on a number or a target and how it resolved." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Open prompt, so a scaffold. Pick a time with a named stake, a position you held, and a relationship that was intact at the end. Whether the road to consensus on the targets involved a disagreement is yours to say. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's cross-functional influence line raises it, and a peer cares about disagreement style with equals; VAL because it scores past behavior |
| B4 | "What would you need from me in your first 90 days, and what could you do for my team?" | JD | [grounded] "skilled in SQL/Tableau" | Both halves. Needs, in your own terms: access to the data and the people, and shared definitions. What you offer, at the quote's scope: independent analysis in SQL and Tableau. Do not promise deliverables you cannot back | A reciprocity question from a peer who is pricing what the hire costs him; JD because it scores the role's analysis function |

### C. Skeptic (weight: third, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI rehearsal.** Four steps. One: acknowledge first and briefly, with the stated words: "I don't have classic sales-ops or quota-setting experience." Two: the adjacent evidence at its own scope: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model that was used in carrier negotiations." Never call the targets quotas. Three: a ramp plan, said as a plan: ask to see how targets and pipeline are tracked today and learn his team's cycle. Four: a concession in exact wording: "That's a real gap, and it's the part I'd lean on your team for." Follow-ups to rehearse: what separates a volume target from a quota, and what you would get wrong first. For the first, answer slot: if you know the difference from your own work, say it; if not, say so plainly. Hold the core claim through two follow-ups, and never bluff a competency he owns | The gap in F7, from the one person likely to own that competency; JD because it scores the gap against the role, and the deepest rehearsal because it will be asked in some form |
| C2 | "Your nine years were in consumer tech. What carries over to a B2B data-infrastructure business, and what doesn't?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Say the background in the quote's words: nine years at a large consumer-tech company, in product strategy and ops. Answer slot: if any of your work touched enterprise customers or partner contracts, say what; if none did, say so plainly, and say what you would go learn first. Name what carries over only from what your quotes carry, and name one thing you would have to learn | The background mismatch is the Skeptic's native question; F4 and F7 show how thin the bridge is, so the limit goes in the answer; JD because it scores fit for this specific business |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Calibrated candor. Choose the weakest part in your own words, one the material points to, and pair it with a concrete ramp plan. The pack's observation is that F7 and F4 are the visible candidates. Do not claim a strength to avoid naming one | A persona-stem question that tests honest self-assessment; JD because it scores against the role's listed requirements |

### D. Case/Strategist (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We're taking a new data-infrastructure product into the enterprise. Sketch the plan: what do you need to know first?" | CASE | [grounded] your research note: enterprise expansion is a stated priority | Clarify first: which product, which buyers, what the objective is. Then segmentation, approach, metrics and risks, speaking in the JD's own land, adopt, expand, renew vocabulary. State a hypothesis early and challenge one premise. It asks about no past, so the guidance claims none | The JD's GTM-ownership line (F1) as a live problem, tied to the first of Northwind's stated priorities; CASE because it scores structure |
| D2 | "How would you think about pricing and packaging an AI copilot like Compass against a competitor who bundles?" | CASE | [grounded] your research note: the Compass launch is a priority and bundling by a much larger platform vendor is the main threat | Pricing and unit economics are his native register. Clarify what Compass is meant to do, then lay out options: standalone, tiered, bundled. Weigh each against the bundling threat and against the profitability priority. State the hypothesis first and name what data would change it. It asks about no past, so the guidance claims none | His pricing and monetization spine tilts the case this way; CASE because it scores reasoning in his own language, and it touches both a priority and the main threat |
| D3 | "You have land, adopt, expand and renew data. Which cut tells you where the biggest unmet opportunity is, and what would make you distrust it?" | CASE | [grounded] the JD highlights: "identify whitespace across land/adopt/expand/renew" | Structure: what whitespace means here, a segmentation, a leading indicator per stage, and the denominators. Then answer the second half directly: what would make you distrust the cut. Think aloud, as a data-driven peer scores the distrust half as much as the cut. No claim about your past is needed | F2 as a live problem, with the data-driven probe built in; CASE because it scores structure and reasoning |

### E. Conversational / Rapport Builder (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the quote's own beats: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Then the move to this role. Answer slot: why this role and why now is yours to say; the pack has no reason to give you | The opener of almost any conversational round; EXP because it tests the CV narrative, and it is still scored |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it as the quote has it: you use AI tools daily. Then, in your own words, the tools and the tasks. If the use is light, say so plainly. You can ask Dan how Compass is landing, but do not claim product experience with AI | F6 is a JD plus, asked casually; it is scored, and JD because it checks the listed plus |
| E3 | "Northwind is pushing on enterprise expansion, the Compass launch and profitability. Why this company, and what draws you to this role in that context?" | CO | [grounded] your research note: enterprise expansion, the Compass launch and reaching profitability are the three stated priorities | Name the three priorities as your note gives them, then say which pulls you and why, in your own words. Link your answer to the two new product lines and say what you would want to learn about them. Do not guess at Northwind's internals | The current-strategy question, from your research note; CO because it tests homework depth. Its currency is unverified, since the note's date is not stated |

### F. Pressure / Stress (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold: "I proposed the change, and the uplift was credited to it." Hold that through two follow-ups by returning to the word proposed. Concede specifically, and only what the sentence does not carry. Answer slot: if you know how the credit was assigned and who else shaped it, say so in your own words; if you do not know, say so plainly. Never fold on the core claim, and never stretch it | The attribution probe on the one big number; EXP because it tests precision, and the persona is Pressure because of the delivery |
| F2 | "Sixty seconds: why you over someone who has carried a number?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause, restate, then three beats in sixty seconds: the acknowledgment ("I don't have classic sales-ops or quota-setting experience"), the adjacent evidence at its own scope, and what you would bring his team. Do not claim to be better than the other candidate; there is no evidence for it. Hold your position without defensiveness | The Pressure form of C1, delivered under time; JD because it scores fit against the role's listed requirements |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent much of your career in pricing and monetization before sales strategy. What did the pricing lens change about how you approach sales strategy?" | Tied to his own path, it converts an interrogation into a peer conversation and shows you researched him, not only the company |
| R2 | "What could a new peer do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are pricing in his load |
| R3 | "Which two product lines does this role cover, and is Compass one of them?" | The material does not say which two they are, and the answer reshapes your first 90 days; it also shows you tracked the priorities |
| R4 | "Where is the seam between sales strategy and emerging-product GTM today, and where have handoffs been hardest?" | It makes B1 a real conversation and tells you where the friction will be |
| R5 | "With a much larger platform vendor bundling, where do you see this role's analysis changing a decision: pricing, packaging or targeting?" | It shows you read the competitive threat and want to move a decision, not produce a deck |
| R6 | "Across land, adopt, expand and renew, where does the data feel least trustworthy today?" | A data-driven peer will rate this highly, and it tells you where your SQL and Tableau work would start |

## Prohibited claims

These are the claims this pack will not coach. The banks above are written against them.

| Not coached | Basis | Honest form |
|---|---|---|
| Classic sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Calling the annual volume targets quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: your material says volume targets, not quotas |
| Designed or owned the partner motion | Inflated form of F4 | F4's quote at its own scope: a partner-level revenue model used in carrier negotiations. The limit is the pack's observation: your material says the model, not the motion. A4's slot stays inside the model's use |
| Drove or delivered the $400M ARR uplift | Inflated form of F1 and F2 | The quote at its own scope: you proposed the change, and the uplift was credited to it. A1 and F1 hold that line |

## Sources

Provided documents: your message (role, JD highlights, Priya's summary, Dan's profile summary, your research note on Northwind's priorities and competitive threat).

Searches sent, both refused:
- "Northwind Data company values principles": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Both calls were not permitted. It would have given official value names for VAL theming. A values cheat sheet is not built either way, since no values-style round is detected |
| 2. `{company} interview process {role family}` | skipped | Your own words fix the loop as one 60-minute conversation with a peer, which fixes the persona weights and the skeleton |
| 3. `{company} strategy` / recent news | skipped | Your research note supplies the three priorities and the competitive threat; its date is not stated, so currency is unverified |
| 4. `{interviewer name} {company}` | unavailable | The call was not permitted. It would have deepened the interviewer read and the mirror opportunities beyond the profile you gave |
| 5. representative `{role title}` JD | skipped | Your JD highlights fix the fit-snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full JD text → six `[inferred]` or highlight-sourced rows become quote-grounded, and "required" versus "a plus" is checked line by line
- Priya's CV, verbatim → story-selection scaffolds (A2, B3, C2) become story-mapped answers, and F2 and F6 firm up
- Dan's profile text or a link → the interviewer read rests on his own words, not a summary
- The Northwind values page → VAL questions can be themed on published values, and a values cheat sheet if a values round turns up
- The recruiter's guidance on what the Dan conversation covers → coverage assumed from the peer prior becomes coverage known
- The date of your research note, or a current strategy brief → E3, D1 and D2 are confirmed current
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, and it needs search permission this session did not grant. It would add a strategy brief, Dan's talks and writing, loop reports and recent org context
- A tuesday-dossier.md, if you have one → verified evidence and stated limits for the weak rows, never a prerequisite
