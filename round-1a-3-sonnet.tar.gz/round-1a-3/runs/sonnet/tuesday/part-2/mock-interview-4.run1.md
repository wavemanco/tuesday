Searches weren't permitted, so the pack runs on your dossier alone. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-4-denied-7df6f0a0/Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for a hiring-manager conversation from your dossier alone, because both web searches were refused. It contains nothing about Quartzline's own values or strategy, and the company-knowledge question (D2) is a scaffold rather than a researched answer.

- **Highest-ROI prep:** A1, the underwriter's objection ("never held the PM title or owned a roadmap — why you over a PM with three years?"). The pack asks it as written and coaches a plain concession, then the integration-leadership bridge with its limit stated first.
- **Roadmap ownership:** it has no bridge, per the underwriter. A2 and B5 coach a plain acknowledgment plus a ramp plan, and no answer asserts the three prohibited claims.
- **Question mix:** 19 questions, weighted toward the Skeptic and Case/Strategist personas. Each has guidance tied to your three verified evidence lines, or an answer slot where nothing you've told me covers it.
- **Reverse questions:** six, seeded from the dossier's two unknowns (squad-lead decision authority and the adoption baseline).
- **Dossier age:** it is dated 2026-08-14, so check the posting still reads the same.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save an updated `tuesday-dossier.md` recording what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- Round: hiring-manager conversation, 45 minutes, Thursday (your note)
- Interviewer: name not given; relationship: hiring manager
- Built from: tuesday-dossier.md (job-underwriter, dossier_version 1.1) and nothing else; no Quartzline research ran (see Sources)
- Highest-ROI prep in this pack: A1. The underwriter named that objection in `likely_interviewer_objections`, and it is asked below as the underwriter wrote it.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows a company's published values (no bank in this pack; see the persona table) |
| EXP | Whether your claims survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

V1, V2 and V3 below are the three entries in the dossier's `verified_candidate_evidence`, in the dossier's order.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [grounded] | transferability | Adjacent work, not product-manager time: your material shows integration leadership and feeding client evidence to product, and nothing in it shows the title or years in the job. Position it as adjacent, as the underwriter set it, never as PM experience. Words, quote-scoped: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The plain acknowledgment has a dossier source, `prohibited_claims: "Having held a product manager title or role"`: "I haven't held the product manager title or role." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | A gap wording cannot close, and the dossier records it: the `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)". Words, sourced from `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap" and "I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past. No bridge: V3 is roadmap input and is kept out of this row |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [inferred] | transferability | The dossier does not grade R2; this row is the pack's own reading of V1's scope, which is integrations of the vendor's APIs, not shipping an API product. Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: R2's wording makes a probe on shipping likely. If any integration involved a change to the API or platform itself that shipped, say what and which part was yours; if there was no such step, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | discovery | V1 names architecture and REST APIs but does not show whether docs or schemas were part of it. Answer slot: R3 names API docs and schemas, so expect a probe. If you worked with either, say how and what your part was, in your own words; if you did not, say so plainly and say how you would get fluent |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [inferred] | transferability | The quotes carry the client side and the product side. Engineering and sales are not in them. Words stay at the quotes: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: R4 names engineering, sales and customers, so expect a probe on the other two. If you worked with either, say how and what your part was; if not, say so plainly and stay with the clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's `clarify` area is "Agile delivery inside a product org (R5)"; no verified entry speaks to it, so nothing about your past is written here. Answer slot: R5's wording is the interviewer's probe. If you worked that way, say how, in your own words; if you never did, say so plainly, then say what you would want to confirm about how they define it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [inferred] | transferability | Confirmed with limited inspectable proof, so expect a probe and volunteer the limit first. V3 says client evidence and sessions; the JD says integration partners, and the quote does not say whether the sessions were discovery with partners. Answer slot: if you ran that kind of conversation, say how and what you asked; if the sessions were something else, or it was not yours, say so plainly and stay with the sessions you ran |
| F8 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Nothing in the material shows adoption measurement either way. Answer slot: if you ever tracked any measure of how something was adopted, say what; if you did not, say so plainly and say what you would measure first. The dossier also lists how adoption is measured today as an unknown, so ask it live (reverse question R2) |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the title and roadmap gap, and why this move | Top weight. The hiring-manager prior is Case/Strategist plus Skeptic, and the dossier names a specific objection for this role, which lifts the Skeptic to the head | Rehearse A1 until it is boring; bridge only from the quotes in F1 with the limit said first; carry a ramp plan |
| Case/Strategist (B) | Live problems from the role: conflicting partner asks, flat adoption, a schema break, discovery, a first thirty days | Top weight. Same hiring-manager prior; the JD's roadmap, adoption and discovery lines are what a live problem would be built from | Clarify, objective, criteria, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (C) | Walks the evidence line by line | Medium. V1 carries a headline figure, 30+, which invites a defend-the-number probe | Know what you can and cannot say about how the figure was counted; name the assumption you would defend least; say plainly what you do not know |
| Conversational (D) | Friendly opener and a why-us question | Low to medium. The opening biography question is scored even when it feels casual | A 90-second arc built only from the quotes; one specific thing you found out about the company yourself |
| Peer Evaluator (E) | Seam-splitting with the two squad leads | Low. The interviewer is the hiring manager, but the JD puts you beside two squads and the squad-lead authority is an open unknown in the dossier | Propose seam principles rather than pretending to know the seam; say what you bring them |
| Pressure (F) | Time-boxes you on the objection | Low. A hiring-manager conversation of 45 minutes is unlikely to be built as a stress round, but the objection can arrive time-boxed | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| Values/Behavioral | Not banked | No values-style round is detected: your note describes one conversation with the hiring manager, and no published Quartzline values are in hand. The motivation probe is covered in A5 | none |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | The underwriter's objection, asked as written; both negatives in it have a source in `prohibited_claims`, so concede in the plain words that field gives: "I haven't held the product manager title or role, and I haven't owned a product roadmap." Then the bridge, limit first: this is adjacent work, never PM experience. Tell it in your own words from the quotes: you led 30+ end-to-end client integrations of the vendor's REST APIs; you wrote the internal integration playbook your team uses; you ran quarterly roadmap-input sessions feeding client evidence to product. Volunteer the limit on that last one before anyone extracts it: confirmed, with less inspectable proof behind it than the integrations or the playbook. Close on a ramp plan, said as a plan in your own words, never as a past. Follow-up 1, "so what did you decide?": hold by returning to the quotes, and concede plainly "I haven't set prioritization for an engineering squad". Follow-up 2, "then why not the PM with three years?": do not argue the years; restate what the quotes carry and the ramp plan. Follow-up 3, "what would convince you?": ask what the first-ninety-days bar is (reverse question R3). Concession wording: "That is a fair read of my background, and I would rather say it now than have you find it." Hold the position by returning to the quotes, never by adding to them | F1 and F2 are the largest gaps in the fit snapshot, so this question arrives in some form; JD because it scores the stated must-have |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name the real one and do not hunt for a second: roadmap ownership and prioritization authority, in the plain words the field gives: "I haven't owned a product roadmap" and "I haven't set prioritization for an engineering squad." Then the ramp plan as a plan: how you would learn how those calls are made today and who makes them, and tie it to the open question of which decisions sit with the squad leads (reverse question R1). Do not offer Agile as a weakness; the dossier has not established it either way (A4) | F2 is a recorded gap and this question asks for it directly; JD because it scores honest self-assessment against the stated role |
| A3 | "This role is about shipped API and platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what V1 carries, at its scope, in your own words: you led 30+ end-to-end client integrations of the vendor's REST APIs. Your material says integrations of the vendor's APIs, not shipping an API product, so do not claim the second. Answer slot: the JD's "Shipped API or platform products" makes this probe likely. If any integration involved a change to the API or platform itself that shipped, say what and which part was yours, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the integrations you led | F3 is the evidence for a must-have and the likeliest place to be probed after the title; JD because it scores the listed requirement |
| A4 | "Tell me about your Agile delivery experience." | JD | [grounded] | The dossier marks this a `clarify` area and no verified entry speaks to it (F6), so nothing about your past goes here. Answer slot: the JD's "Agile delivery experience" is the interviewer's probe. If you worked that way, say how, in your own words; if you never did, say so plainly. Then the honest question back: "Here is what I would want to confirm about how you define it", and ask how the two squads run delivery (reverse question R6) | F6 is a discovery row; the question is asked as an open prompt because the requirement is preferred, not a must-have |
| A5 | "What is drawing you from integration work toward product management?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The reason is yours and the pack does not supply it. Criteria: it should be true, fit in two sentences, say what draws you to a platform-API product role, and stay consistent with the adjacent framing in A1. The nearest thing in your material is the roadmap-input sessions; tell it at that scope if it is part of why. If no reason comes cleanly, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Skeptic scores motivation consistency and this is the move behind F1; JD because it tests fit for the role, not a past event |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two partners ask for conflicting API changes in the same quarter, a sales lead has already promised one of them a date, and each squad has capacity for one. How do you decide, and what do you say to each person?" | CASE | [generic] | Clarify first: what is the evidence behind each ask, what does the date commit us to, and who decides between the squads. Then objective, criteria for the trade-off, the call, and what you tell the partner who loses, the sales lead and the squads. Frame decision rights as a question you would confirm rather than a power you assume. The question needs no claim about your past, so the guidance makes none | The JD's roadmap line is where this lands, and decision authority versus the squad leads is an open unknown in the dossier; covers R4's three audiences in one problem |
| B2 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | Clarify before structuring: how adoption is measured today and what the baseline is, which is the dossier's own unknown, so asking it live is the right first move. Then segment where partners drop off, form hypotheses per segment, name the metric that would confirm each, and the first cheap test. Say your hypothesis early. The question needs no claim about your past | The JD names adoption metrics as a responsibility with no baseline stated; CASE because it is a live diagnosis |
| B3 | "A partner's integration breaks because a field in the API's response schema changed and the docs were not updated. How do you triage it, and what changes so it does not recur?" | CASE | [generic] | Triage in order: stop the bleeding for this partner, find what changed and who owned the change, confirm the docs and the schema now agree. Then the prevention: who is told before a schema change, how docs stay in step with it, how partners hear about changes. Keep it at the level of process you would propose. The question needs no claim about your past | R3 names API docs and schemas; CASE delivery of a JD question, so the candidate shows fluency instead of asserting it |
| B4 | "Five integration partners want a call about what they would need next from the API. What do you need to know before the first one, and how do you run them?" | CASE | [generic] | Clarify what the calls are for and what decision they feed; what you want to learn from each partner, how you will compare answers across five, how you separate what a partner says they want from what the evidence shows, and what you do with it afterward. The question needs no claim about your past | The JD's discovery line; CASE because it is a live setup, not a history question. If asked whether you have done it, the nearest quote is V3 at its scope (F7) |
| B5 | "Walk me through your first thirty days: who do you meet, what do you read, and what do you decide not to decide yet?" | CASE | [generic] | This is the ramp plan A1 and A2 point to, said as a plan. Structure: who you meet first and why (the two squad leads, partners, sales), what you read, what you ask about decision rights and the adoption baseline, and what you deliberately hold off on. The question needs no claim about your past | F2 has no bridge, so the ramp plan has to carry the answer; rehearsing it as its own question keeps A1 short |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words: how it was counted; what the count is sensitive to; the assumption behind it you would defend least; and which part was yours, where the quote says "Led". Keep 30+ attached to client integrations, the noun it came from. Where you know, say so; where you do not know how it was counted, say so plainly. Hold the verb at "Led", never "owned" | The only headline figure in the material (F1, F3), so a defend-the-number probe is likely; EXP because it tests attribution |
| C2 | "Pick one integration and take me from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on V1: the stages are the ones the quote names, scoping, requirements, architecture, UAT, go-live; pick one integration and tell it in your own words, at those stages and no further. Answer slot: the JD's discovery line makes a probe on how you learned what a partner needed likely. If you ran any such step in scoping and requirements, say how; if there was no such step, or it was not yours, say so plainly and stay with the stages you led | The Prober goes two levels deeper than the headline claim; F3 and F7 both sit on this story |
| C3 | "How would you know whether the integration playbook is actually working?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say it at its scope: you wrote the internal integration playbook your team uses. Answer slot: the JD's "Define and track adoption metrics" makes this probe likely. If any measure of its use was tracked, say what; if none was, say so plainly and say what you would measure first. Never describe a measure you did not track | F8 has no evidence; the playbook is the only artifact in the material that has users, so the probe lands here; EXP because it presses on what the claim rests on |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with the three beats the quotes state, in order and at their scope: you led the integrations; you wrote the playbook your team uses; you ran the roadmap-input sessions that fed client evidence to product. Name the work as integration leadership. Finish with one sentence on why this role, in your own words (A5). Add no title, team size or result | The biography question is scored even when it feels casual; covers F1, F3 and F7 in one pass |
| D2 | "What draws you to Quartzline's platform APIs specifically?" | CO | [generic] | No company research ran for this pack, so nothing about Quartzline is supplied here. Selection criteria: name one specific thing you found yourself in any public material of theirs that you can explain in a sentence, and say why it matters for a partner-facing API platform. If you have not looked yet, look before Thursday. If nothing comes, say so plainly, then give the nearest thing your material does carry, or how you would find out in your first weeks | CO is where unresearched packs go generic; the upgrade menu says what research would add |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You will work beside two squad leads. Where is the seam between you and them, and what happens when you disagree?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Propose seam principles rather than pretending to know the seam: what you would bring them is client evidence, and you would say it at its scope, you ran quarterly roadmap-input sessions feeding client evidence to product; how a disagreement gets decided is something you would agree up front, and you would ask who decides what today. Do not claim a prioritization authority you were not given | The dossier lists decision authority against the squad leads as unevidenced; reciprocity framing keeps you from claiming it |
| E2 | "Tell me about a time an engineering or sales lead wanted something different from what a client needed. What happened?" | EXP | [generic] | No sentence in your material carries this story, so this is a selection scaffold: pick a time with a named stake, a counterpart who held a different view, your own position and how you held it, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | R4 names engineering, sales and customers and F5's quotes carry only the client and product sides |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done the job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | A1 compressed. Pause, restate the question, then three moves: the plain concession, "I haven't held the product manager title or role"; one quoted strength, you led 30+ end-to-end client integrations of the vendor's REST APIs; one sentence of ramp plan. Hold: if they cut in with "so you are not a PM", say yes plainly and return to the quote. Hold through two follow-ups without adding to the quote; concede specifically, never fold on what the quote carries | The objection can arrive time-boxed; JD because it is the same scored requirement as A1 |
| F2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold the quote at its scope: you ran the quarterly sessions that fed client evidence to product. Concede the limit before it is extracted: confirmed, with little inspectable proof behind it. Answer slot: if what you fed in changed what product did, say what; if you do not know what came of it, or nothing did, say so plainly and stay with the sessions you ran. Do not describe an influence on the roadmap | V3 is the medium-confidence entry the dossier says to expect a probe on (F1, F7); EXP because it tests attribution |

## Requirement coverage

| Requirement or responsibility | Question IDs |
|---|---|
| R1 3+ years product management experience | A1, A2, A5, B5, D1, F1 |
| R1 sub-claim: roadmap ownership and prioritization authority | A1, A2, B1, E1 |
| R2 Shipped API or platform products | A3, C1, C2 |
| R3 Technical fluency: API docs, schemas | B3 |
| R4 Stakeholder management across engineering, sales, customers | B1, E1, E2 |
| R5 Agile delivery experience | A4 |
| Own the roadmap for the partner-facing API platform | A1, A2, B1 |
| Run discovery with integration partners | B4, C2, F2 |
| Write specs and drive delivery with two engineering squads | A4 touches delivery; spec-writing: none, a listed responsibility rather than a stated requirement, and the dossier gives no sign a spec sample is asked |
| Define and track adoption metrics | B2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier: decision authority against the two squad leads is asserted in the JD and not evidenced. The answer is what you need before accepting, and it reads as diligence |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier: adoption metrics are named as a responsibility and no baseline is stated. It also pre-answers B2 |
| R3 | "What would you need to see from someone coming from the integration side to feel the gap had closed by the end of the first ninety days?" | Turns the A1 objection into a stated bar you can plan against |
| R4 | "How does partner evidence reach the roadmap today?" | Connects to F7 without restating it, and shows you are asking about the part of the work you can already speak to |
| R5 | "What tends to be hardest in the first quarter for someone new to this platform?" | Open and specific enough to get a real answer; also tests the ramp plan in B5 against what they say |
| R6 | "How do the two squads run delivery today, and where does the PM sit in it?" | The honest clarify question for F6, and it gets the answer about the squads before you commit |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims: "Having held a product manager title or role"` | V1 and V3 at their own scope, as adjacent work. The plain acknowledgment: "I haven't held the product manager title or role." |
| Having owned a product roadmap | `prohibited_claims: "Having owned a product roadmap"` | V3 at its own scope: the sessions fed client evidence to product. The plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | `prohibited_claims: "Having set prioritization for an engineering squad"` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Then the ramp plan, said as a plan |
| Shipped an API or platform product | Inflated form of V1 (F3) | V1 at its own scope. The limit is the pack's observation: the material says integrations of the vendor's APIs, not shipping an API product. A3's slot stays inside the integrations |
| Shaped or influenced the product roadmap | Inflated form of V3 (F1, F7) | V3 at its own scope. The limit is the pack's observation: the material says sessions that fed client evidence to product, not what product did with it. F2's slot stays inside the sessions |

## Sources

- Provided: tuesday-dossier.md, dossier_version 1.1, generated by job-underwriter on 2026-08-14. Consumed: `role_profile` (its requirement and responsibility lines stand as the JD) and `handoff_to_mock_interview` (all of it). `decision` (conditional_go) read as context only. Not present: `evidence_map`, `evidence_state`, `risk_register`, so there are no rejected inferences and the risks come from `opportunity_risks_to_validate`. The dossier is dated 2026-08-14; confirm the posting still reads as it did.
- Search calls sent: "Quartzline company values principles" — refused; "Quartzline partner API platform strategy news" — refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have supplied value names for VAL themes and, only if a loop source documented a values round, a cheat sheet; D2 stays a scaffold |
| 2. `Quartzline interview process product manager` | skipped | Your note fixes the loop for this pack: one 45-minute conversation with the hiring manager, so persona weights stand on it |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have grounded D2 and could have added a strategy-based CO or CASE question |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search → Quartzline's published values and strategy: D2 becomes grounded and a strategy-based CO question can be added. A deeper pass beyond that is available once: up to 6 more searches and 2 more fetches, several more minutes
- The interviewer's name and role → an interviewer read, persona reweighting, and a reverse question tied to their path
- The recruiter's prep note, if any → coverage of stated focus areas or a pre-declared deliverable
- Hours available before Thursday → a prep triage ordered to your time
- Your answers to the slots in A3, A4, C1, C2, C3 and F2, given outside a drill → those rows become quoted material and the fit snapshot rows F3, F6, F7 and F8 regenerate
- An agenda or readout from one of the quarterly roadmap-input sessions, if you have one → V3 can move from medium confidence toward high
