Search permission was refused, so I'm building the pack from your message alone. Writing it to the working directory now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-5-denied-209964d8/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I built it for the panel as the recruiter described it. Web search was refused, so I couldn't research Kelverton or Deepa and Ross. The market report text wasn't in the conversation either, so the pack has nothing from it. The requirements come from the recruiter's email as you quoted it.

- **Rehearse first (about 75 minutes):** the 15-minute POV. The pack has three candidate theses, each with a concession you should say aloud. It also has a way to differentiate from the report rather than recite it.
- **Highest-ROI question:** B1, "you haven't sold into rail, so what makes you credible on day one?" It is built only on your own stated limits and your consulting years, kept at the scope you gave: bus and light rail network planning.
- **Ross's likely targets:** the £4M figure (C1 to C3, D2) and the quota gap (B2, D1). Your message says "influenced revenue", so the pack never lets it become "revenue". Your message doesn't say what period or partners the £4M covers, so you'll want an answer ready on that.

I can run a live drill as Ross on D2 or C1, the questions most likely to rattle you. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

Can you paste the job description and the market report's key pages? Without them the pack's CO and CASE questions stay generic, and I'll rebuild those parts if you send them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Panel, 60 minutes, Tuesday. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your spoken POV, no slides. Remainder: Q&A, where the recruiter's note says "Ross will push on commercials".

Built on one assumption: no job description, no text of the market report and no web research were available, so every requirement below comes from the recruiter's email as you quoted it and from your own message.

## How to use this pack and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words, and treat each answer slot as an instruction for the interview, not a blank to fill here.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows published values, not generic virtue |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | The stated role responsibilities, including the gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem, scored on structure and reasoning |

## Prep triage (four hours, spread over the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV and say it aloud three times, timed. Stop at about 10 to 11 minutes so an interruption cannot cost you the close | Graded deliverable below, A1 to A3 |
| 2 | 60 min | Write your own plain words for the rail and quota gaps and say them until they are boring. Rehearse the answers aloud | B1, B2, D1 (B1 is the highest-ROI prep in this pack) |
| 3 | 45 min | The £4M: write your own answers to how it was counted, what period and partners it covers, the assumption you would defend least, and which part was yours | C1 to C3, D2 |
| 4 | 30 min | Reread the market report for one consensus item, one place you would diverge, and one thing you would decline | Graded deliverable, differentiation row |
| 5 | 30 min | Your 90-second arc and the reverse questions | E1, reverse questions |

Everything else is insurance.

## Fit snapshot

Requirements are the recruiter's own words as you quoted them, because no JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel, not operator relationships, and the words stay there: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the recruiter's phrase "operator partnerships" makes a probe on what carries over likely. Say which parts carried over, in your own words; if none did, say so plainly and stay with the ISV channel |
| F2 | "Please land on what it means for the operators themselves" — recruiter email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote is bus and light rail network planning from the consultancy side, and the material does not show train operating companies. The words stay there: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on train operators. If any of that work involved train operating companies or heavy rail, say what and which part was yours; if none did, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials" — recruiter email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The adjacent work is influenced revenue, which does not reach direct commercial ownership, and you stated the limit yourself, so the plain words are yours: "I've never sold into rail specifically and never carried a direct quota; my figure is influenced revenue." Then the figure at its own scope: "roughly £4M of influenced revenue". The ramp is a plan, never a past |
| F4 | "Senior Partnerships Manager" — your message | "9 years in partnerships" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap in kind, but a CV figure with nothing inspected behind it. Lead with the numbers in the quote's own terms, and expect probes on the £4M (C1 to C3, D2) |

## Graded deliverable: the 15-minute POV

The recruiter's own words, as you quoted them: "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", "Please land on what it means for the operators themselves."

**Grounded facts to build on.** F1: "took it from 6 partners to 40, roughly £4M of influenced revenue". F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". F3: "Never sold into rail specifically and never carried a direct quota, only influenced revenue."

**One framing choice for you to make.** "Operator partnerships" could mean Kelverton's relationships with train operating companies as customers, or partnerships built around operators. Say which you are assuming in your first sentence and invite correction. It reads as clarifying before structuring, which is what a CASE scorer looks for.

Theses are candidate directions, each with a concession you must say aloud. Pick two or three and test them against the report; none is a finding about Kelverton.

| Thesis | What to say it means for the operators themselves | Mandatory concession | Provenance |
|---|---|---|---|
| T1: Fewer, deeper operator partnerships | End with one sentence starting "For an operator, that means" and name a concrete change that operator's own team would notice, taken from the report | Depth leaves some operators with less attention in the 18 months, and you cannot see from outside the criteria for choosing | [generic] |
| T2: A partner ecosystem around the scheduling product | Same close: what an operator's team would get sooner or no longer have to build | It depends on what the product exposes to partners, which you cannot see from outside. Say what you would check first, and say your channel material is ISV, not rail (F1) | [generic] |
| T3: Partnerships anchored on a measure operators already track | Same close: the partnership is judged on the operator's own measure | A shared measure creates commercial exposure Ross will probe, and you have not carried a direct quota (F3), so say you would build it with the commercial team | [generic] |

**Differentiation.** The report is equally available to Deepa and Ross, so reciting it scores as homework. Bring one item from its shortlist to show you read it, then one place you would go differently, with reasons, then one thing you would decline to do in the 18 months (the anti-pick; a partnerships role includes saying no). Paste the report and this row becomes specific.

**Shape and timing.** Assumption (30 seconds), thesis and why, what it means for operators, the concession, what you would verify in the first 90 days. Leave your close for last and stop before 12 minutes.

## Reading the interviewers

Public footprint was not researched, so this reads only the recruiter's words and offers no mirror opportunities.

| Interviewer | What the email gives | Implication |
|---|---|---|
| Deepa | "VP Partnerships, your future manager" | Hiring-manager prior: capability and risk, with live problems on the role. Expect the POV to be judged as the work sample |
| Ross | "Commercial Director"; "Ross will push on commercials" | Expect numbers and terms pressed, so the £4M and the quota gap are his easiest targets |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | The POV itself, then follow-up cases | Highest. Hiring-manager prior, plus a 15-minute deliverable that is a live strategy problem | Clarify, state the assumption, structure, think aloud, challenge one premise respectfully |
| Skeptic (bank B) | Quiet probing of rail and quota gaps | High. Your own message states both limits, and a future manager is pricing the risk | Rehearse the single predictable objection (B1) until boring; use only what your quotes carry; plain acknowledgment, then a ramp plan |
| Data-Driven Prober (bank C) | Line-by-line on the £4M and the 6 to 40 growth | Medium. The recruiter flagged commercials, and the headline figure is a magnet | Know and say how the figure was counted, or say plainly you do not know; name the weakest assumption first |
| Pressure (bank D) | Time-boxed challenges, precedent and scenario pressure from Ross | Medium. A Commercial Director "will push" | Pause, restate, anchor in your quotes, hold through two follow-ups, then concede the specific gap |
| Conversational (bank E) | Opening arc, casual rail-tech chat | Low-medium. Likely at the start, still scored | A 90-second arc; treat casual questions as scored |
| Values / Behavioral (bank F) | Unpopular truth, partner interest over number | Low. No loop source documents a values round, and the recruiter's email describes this session as a POV plus Q&A | Choose a story only if one is true; the scaffold has an honest branch |

## Question banks

### Bank A: Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months, and what does that mean for the operators themselves?" | CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | This is the deliverable: use the build section above. If you draw on your channel work, say it in the quote's own words: "took it from 6 partners to 40, roughly £4M of influenced revenue". Do not stretch it to operators | F1 and F2 are the requirements behind it; CASE because it is scored as a live strategy problem, JD because it is the recruiter's stated deliverable |
| A2 | "What partnership model would you decline to pursue in the first 18 months, and why?" | CASE | [generic] | Name the model, the trade-off you accept by declining it, and what evidence would change your mind. The question needs no claim about your past, so the guidance makes none | The anti-pick from the differentiation row; CASE because it tests judgment, not recall |
| A3 | "What would you measure at 6, 12 and 18 months, and what would you stop measuring?" | CASE | [generic] | Separate leading indicators from revenue, and include one measure an operator itself would recognise. Make no claim about measures you have run | F3's commercial pressure from the metrics side; CASE with JD content |
| A4 | "A large operator tells you a partnership with us is just another vendor relationship. How do you respond?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Clarify first: what the operator has experienced, and what they mean by vendor. Then structure the response. Where you draw on your background, keep its scope: "five years in transport consulting, in bus and light rail network planning" | F2 is where this lands; CASE because it is a live scenario, with a JD link to the operator-facing close |
| A5 | "What do you need to know in your first 90 days that you cannot know from the outside?" | CASE | [generic] | A plan, not a past: list what you would verify, who you would ask, and how it would change your first thesis. Naming your own limits here turns F1 and F3 into structure | The Skeptic's concern delivered as a collaborative question; CASE because it tests clarify-before-answer |

### Bank B: Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've told us you haven't sold into rail. What makes you credible with a train operator on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI rehearsal in this pack, and the hold is only what the quotes carry. Words: "I've never sold into rail specifically." Then: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: if any of that work involved train operating companies or heavy rail, say what and which part was yours; if none did, say so plainly and stay with bus and light rail. Hold through two follow-ups by returning to the quotes, never by adding to them. Concede the rail-specific gap in your own plain words, then give a ramp plan as a plan | F2 and F3 are the likeliest place to be probed, and this question will arrive in some form; JD because it scores the stated requirement, with Skeptic delivery |
| B2 | "You've said you've never carried a direct quota. What changes for you if this role carries one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain words from your own sentence: "I've never carried a direct quota; my figure is influenced revenue." Then a plan, not a past: who you would ask about how targets are set and what you would want agreed in the first 90 days | F3 is stated by you, so the plain acknowledgment has a source; JD because the commercial push is the recruiter's flagged theme |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose your own answer. Your message already names two limits, the rail selling and the direct quota, and either can be your answer in your own words. Follow it with how you would ramp, as a plan | A persona stem the Skeptic is likely to use; JD because it scores honest self-assessment against the listed job |
| B4 | "Why move from payments to rail-tech, and why now?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" | Answer slot: give your actual reason in your own words; your message does not contain one, so the pack supplies none. Expect a consistency check against the transport consulting years in your history, so say how they connect to this role, or that they do not | Motivation consistency is what a Skeptic scores; EXP because it tests whether your story survives cross-examination |
| B5 | "Your background is an ISV channel. Operators aren't ISVs. What transfers and what doesn't?" | JD | [grounded] "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say what the quotes state: you ran the ISV channel and took it from 6 partners to 40. The limit is the pack's observation: your material says the ISV channel, not operator relationships. Answer slot: if any partners in that channel resembled customers more than third-party builders, say so in your own words; if none did, say so plainly, then say what you would keep and what you would change | F1 is the transfer question at its sharpest; JD because it tests the stated operator-partnerships requirement |

### Bank C: Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say "roughly £4M of influenced revenue", never "£4M of revenue". Answer slot, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F4 is the headline figure on your CV, the first thing a prober tests; EXP because it checks attribution |
| C2 | "What period and which partners does the £4M cover?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Your sentence does not say whether the figure covers the four years, the 40 partners or a subset, so state it only as you know it. Answer slot: give the period and partner set in your own words; if you do not know, say so plainly | The ambiguity resolves downward, so it needs your answer before an interviewer asks; EXP because it tests precision |
| C3 | "How did you get from 6 partners to 40?" | EXP | [grounded] "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | The beats are the ones the quotes state: you ran the channel, and it went from 6 to 40. Answer slot: say what you did to get there, in your own words, and which part was yours; if any of the growth came from partners arriving without your involvement, or from others' work, say so plainly | F4's other number, and the natural second question after C1; EXP because it tests what was actually yours |

### Bank D: Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate the question. Concede the specific in plain words: "I've never sold into rail specifically." Then state what the quotes carry: "took it from 6 partners to 40, roughly £4M of influenced revenue". Hold that position through two follow-ups by returning to those quotes, and never fold on them | A time-boxed version of B1; EXP because it tests composure over your own stated record |
| D2 | "That £4M — how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which part was yours, in your own words; if part of it came from partners, teammates or others, say so plainly. Hold your account through two follow-ups, then concede exactly what you do not know, such as how it was counted | A persona stem for the Pressure interviewer; EXP because the probe exists to catch inflation |
| D3 | "A top operator wants a bespoke commercial term you think sets a precedent. Ross says close it. What do you do?" | CASE | [generic] | Structure it: what each side needs, what precedent it sets, what you would offer instead, and who decides. Hold your position with reasons through two follow-ups; concede that the commercial decision is Ross's if that is true of the role. The question presupposes nothing about your past, so the guidance makes none | F3's commercial pressure, delivered as a scenario; CASE because it tests composure with a senior interviewer |

### Bank E: Conversational (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc built from the quotes: nine years in partnerships, the last four at a payments company running the ISV channel, and five years in transport consulting in bus and light rail network planning. Answer slot: your message does not say what the other five partnership years were or in what order the consulting sits, so say it in your own words | The opening question in a friendly register, still scored; EXP because it tests whether your timeline is consistent |
| E2 | "What are you actually playing with in rail-tech these days?" | CO | [grounded] "which I've read" | Answer slot: if you follow anything in rail scheduling or rail-tech, name it in your own words; if not, say so plainly and say you read the market report, in your words, then what you took from it | A casual question on a hot topic, still scored; CO because it checks homework depth |

### Bank F: Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to a partner." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften it, and a relationship intact afterward; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; VAL because it tests behaviour, with no published values read to map to |
| F2 | "When did you put a partner's long-term interest ahead of a short-term number?" | VAL | [generic] | Pick a time with a named number, a named partner interest and a decision of yours; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; VAL because it tests the partnerships role's central trade-off |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1: POV on operator partnerships over 18 months | A1, A2, A3, A5, B5 |
| F2: land on what it means for operators | A1, A4, B1, B5 |
| F3: commercials | A3, B1, B2, B3, C1, C2, C3, D1, D2, D3 |
| F4: Senior Partnerships Manager | B4, C1, C3, E1 |
| JD requirements | none, and why: no JD was supplied, so none can be listed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In the strategy report, which priority do you most want operator partnerships to move in the next 18 months?" | Ties your POV to the strategy team's own document and lets Deepa set what success means |
| R2 | "What does the commercial team count as a partnership win today?" | Turns the commercials push into a shared definition and tells you how your influenced-revenue experience will be read |
| R3 | "When a deal and a partnership overlap, who owns the operator relationship?" | The seam between partnerships and direct sales, asked of both interviewers |
| R4 | "What would you want to be true of this hire at 90 days?" | Sets a concrete target for the ramp plan you have rehearsed |
| R5 | "Which operator relationships are working best today, and what makes them work?" | Shows interest in operators rather than in your own pitch, and gives you material for the Q&A |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail or carried a quota | Negative the candidate stated, F3 | The plain acknowledgment F3 gives: "I've never sold into rail specifically and never carried a direct quota; my figure is influenced revenue." No slot |
| The £4M as closed or owned revenue | Inflated form of F3 | The quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the quote says influenced, not closed |
| Worked with train operating companies or heavy rail | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning, not train operating companies. B1's slot stays inside the quote |
| Led operator partnerships | Inflated form of F1 | F1's quote at its own scope: running the ISV channel. The material says ISV partners, not operators |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report is named in your message but its text was not provided, so nothing in this pack comes from it. No dossier was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

Every search was refused (permission was not granted), so the pack rests on your message alone. Queries sent, all refused: "Kelverton Rail values"; "Kelverton Rail interview process partnerships manager"; "Kelverton Rail strategy scheduling software train operating companies"; "Deepa VP Partnerships Kelverton Rail"; "Ross Commercial Director Kelverton Rail"; "Senior Partnerships Manager Kelverton Rail job".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet; none is built, and bank F is generic |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Would have tested the loop against the recruiter's description; the recruiter's words alone establish this one session, so no archetype fallback was used |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have fed CO and CASE questions and the grounding brief; those are generic or rest on your report |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Would have fed the interviewer read and a reverse question tied to their paths; absent |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have given JD-tagged rows something to quote; the fit snapshot uses the recruiter's words instead |

## Upgrade menu

- The market report text, pasted → the differentiation row and A1 to A5 become specific, and CO questions move from generic to grounded
- The job description text → the fit snapshot quotes the posting instead of the recruiter's paraphrase, and every requirement gets a JD-tagged question
- Answers to the £4M slots (how it was counted, which period and partners, which part was yours) → C1 to C3 and D2 become story-mapped on your own words
- Whether any of your consulting work involved train operating companies → F2 and B1 may upgrade from transferability
- What the other five partnership years were → F4 and E1
- Web search permission, then a deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → Kelverton's values, strategy, and Deepa's and Ross's public professional footprint
- The recruiter, by email → whether Ross's commercial questions will be about partner economics or about Kelverton's own pricing; one email resolves it
- A tuesday-dossier.md from an earlier session, if you have one → verified evidence and constraints on the weak areas, never required
