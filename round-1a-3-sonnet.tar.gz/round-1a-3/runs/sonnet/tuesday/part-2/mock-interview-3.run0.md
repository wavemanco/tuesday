I've read the mock-interview playbook and I'm now running the default research pass: Stripe's values, its interview loop, recent strategy, and a representative Product Operations Manager posting.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-3-denied-0b4cf644/stripe_product-operations-manager_interview_pack.md`.

The web searches were denied, so the pack has no Stripe-specific facts. I didn't fill that gap from memory. I also had no job description, CV or interviewer name. The pack therefore has 21 questions across seven interview styles, every one labeled `[generic]`, and none claims anything about your past. It assumes a final round with an unknown interviewer, so the styles are blended evenly.

If you grant search access or paste Stripe's own values and interview pages, I can add company-grounded case and strategy questions.

Say the word and I'll play the Skeptic on B1, "Which part of this role would you be weakest at on day one?" The pack names it as your highest-value prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in this round (future manager, a peer, a skip-level or a mix), and did the recruiter name any focus areas or a deliverable? This reweights every question bank.
2. Can you paste the job description and a few lines of your product operations background? That turns the fit snapshot from a blank worksheet into real story maps. If you'd rather not, I'll proceed as is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer name and relationship: not given. Session mode, blended persona weights.

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding, not a script: every answer is told in your own words, from things you actually did.

Type key:

- VAL: whether past behavior shows values, not generic virtue
- EXP: whether your experience survives scrutiny, and what was actually you
- JD: the role's responsibilities, including your weak spots
- CO: company and strategy knowledge
- CASE: a live problem, scored on structure and reasoning

This pack holds no Stripe-specific facts. No search ran and nothing Stripe-related was supplied, so every row is labeled `[generic]`: a pattern for the role, not a claim about this employer. Nothing in this pack says what you did, because no CV or background was given.

## Fit snapshot (worksheet version)

No job description, CV, recruiter note or fetched posting was available. The requirements below are role-family patterns in plain prose, so none is quoted and none raises an answer slot. Evidence is `none given` on every row. The pack states no gate row because no source states a term the role requires.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a cross-functional launch or rollout across several teams — role-family pattern | none given | none | [generic] | discovery | Strong evidence looks like a launch or rollout you can narrate with its teams, its date and what you personally decided. Selection scaffold: pick one where you owned a named piece, and say what was yours and what was not. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define and track operating metrics for product teams — role-family pattern | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, which assumption you would defend least. Selection scaffold: pick one figure you can defend under two follow-ups. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Build or improve a process that teams actually adopt — role-family pattern | none given | none | [generic] | discovery | Strong evidence is a process that people kept using after you stopped pushing it, with a sign of that. Selection scaffold: pick one where you can say who used it and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Turn messy data into a recommendation for product leaders — role-family pattern | none given | none | [generic] | discovery | Strong evidence is an analysis you did yourself, a recommendation you made, and what happened to it. Selection scaffold: pick one you can walk through end to end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence engineering, design, sales and support without authority over them — role-family pattern | none given | none | [generic] | discovery | Strong evidence is a case where a team changed what it did because of you, and you can say how you knew. Selection scaffold: pick one with a named stake and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritize competing requests from many teams — role-family pattern | none given | none | [generic] | discovery | Strong evidence is a time you said no or not yet, and kept the relationship. Selection scaffold: pick one where you can state the criteria you used. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

The loop is not established: no loop source was read and the relationship to the interviewer is unknown, so weights follow a generic fallback (flat, said plainly) tilted by "final round". A final round could be one conversation or several sessions; the weights blend the hiring-manager, skip-level and cross-functional priors. If you know who you meet, the weights change.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems on running product teams: launch readiness, prioritization, adoption | Highest. Hiring-manager and skip-level priors both rank it first, and the role is an operating role that is easiest to test with live problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic (B) | Quiet probing of day-one weaknesses, motivation, and how you earn authority without owning outcomes | High. Hiring-manager prior; every candidate has a thinnest area and the final round is where it gets tested | Rehearse the most predictable objection until it is boring: say plainly where you are thinnest, then a concrete ramp plan |
| Peer Evaluator (D) | Seam questions with product management, credit across teams, a PM saying your process slows them | Medium. A product ops hire sits beside several teams, so a final round plausibly includes a collaborator | Reciprocity: what you bring their team, seam principles rather than a pretended map, a disagreement story with spine and tact |
| Pressure (E) | Time-boxed answers, why you over an internal candidate, how much was you | Medium. Skip-level prior; it tests composure, not content | Pause, restate, anchor on what you can state, hold through two follow-ups, concede specifically |
| Values/Behavioral (C) | Stories about unpopular truths and customer-over-metric choices | Lower. No loop source documents a values round, so none is assumed; it may still arrive as a cross-functional conversation | One story per theme where you have a real one; where you have none, say so plainly |
| Data-Driven Prober (F) | Walk me through how that number was counted | Lower. Applies if the interviewer reads metrics closely; unknown without a profile | Know how each figure of yours was counted, say plainly when you do not, name your weakest assumption first |
| Conversational (G) | Friendly openers that are still scored | Lower but certain to appear somewhere, usually first | A 90-second arc for the biography question; treat casual questions as scored |

## Question banks

Every question below is a live problem, an open prompt or a role question. None presupposes anything about your past. The highest-ROI prep in this pack is B1.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team is launching a feature that touches support, sales, finance and legal. The date is three weeks out. Where do you start?" | CASE | [generic] | Ask what must be true on launch day and who signs off before structuring. Then walk objective, who is affected, the plan, the measures, the risks. Say which assumption you are making aloud and challenge one premise of the question | Tests whether you clarify before you structure. Covers F1 and F5 as a live problem rather than a story |
| A2 | "An internal tool that product teams were asked to adopt has flat usage after two months. Diagnose it." | CASE | [generic] | Separate reach, activation and repeat use; ask what was promised to whom; list the three likeliest causes with how you would check each. Think aloud and name which check you would run first | Tests diagnosis over answer-guessing. Covers F3 |
| A3 | "Ten teams each tell you their request is urgent. You can support three. How do you choose?" | CASE | [generic] | State your criteria before applying them, say what you would ask each team, and say how the seven who lose hear it from you. Show one trade-off you would refuse to make | Tests prioritization and how you handle the people who lose. Covers F6 |
| A4 | "A product organization has no planning cadence. What do you build in the first 90 days, and what do you refuse to build?" | CASE | [generic] | Learn before you build: who you would talk to, what you would measure, one small mechanism first. The refusal half is where judgment shows; give a reason for each | Tests sequencing and restraint. Covers F3 and F2 |
| A5 | "What do you think is the biggest operational challenge for a company at this stage, and how would product operations help?" | CO | [generic] | This pack supplies no Stripe facts, so form your hypothesis from the company's own published material before the interview, and say where each point comes from. If you have not read it, say so plainly and ask what the interviewer sees | Gives the differentiator slot a place, left honestly generic until research is available |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Pick the one area from F1 to F6 where you are honestly thinnest, say it in a single plain sentence, then give a concrete first-30-days ramp. Do not name a strength disguised as a weakness. Hold through two follow-ups by returning to the ramp, never by adding claims | Every candidate is asked this in some form in a final round, and a rehearsed non-defensive answer changes the interview. JD because it scores honest fit |
| B2 | "Why this role, why this company, and why now?" | CO | [generic] | Give your own reasons in your own words, one real reason per part, and tie the company part to something you read in its own materials. If a part is unclear to you, say so plainly rather than making a reason up | Motivation consistency is the Skeptic's score. CO because it tests the homework, with EXP overtones |
| B3 | "Product operations owns few outcomes itself. What stops you being a coordinator nobody listens to?" | JD | [generic] | Name two mechanisms by which you would earn a hearing, and what you would do first. Selection scaffold for a story: pick a time you changed what a team did without being their manager, with a named stake. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The objection a role that sits between teams meets most. Covers F5 |
| B4 | "What would you want to learn in your first 30 days before you change anything?" | JD | [generic] | Three things you would learn, who you would learn them from, and what would make you act early anyway. It signals you will not arrive with a template | Tests humility and method together. Covers F3 and F4 |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship still intact afterward. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Values interviewer. A story where the hard truth landed is the bar, and none is assumed here |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two actually conflicted, name what it cost, and say how you knew it was right. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; tests whether you can describe a specific decision rather than a slogan |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam, and say what you would bring their team. Say how you would raise a disagreement, and when you would escalate | Peer lens: does the hire reduce or add to my load. Covers F5 |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick one piece of cross-team work where you can say who did what, including what was not yours. Say how credit was shared in practice. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Probes attribution honesty. Covers F1 |
| D3 | "A product manager tells you your process is slowing their launch. What do you do?" | CASE | [generic] | Ask what exactly is slow and what the process is for before defending or dropping it. Say what you would change, what you would hold, and how you would check it worked | Tests disagreement style with an equal. Covers F3 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate it. Give two reasons you can back with specifics in your own words, then hold through two follow-ups. Concede explicitly what an internal candidate knows that you do not, and say how you would close that gap | Persona stem. Hold-then-concede: composure is the score |
| E2 | "Pick a result you would put forward as yours. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result where you can separate your part from the team's. Say your part precisely and credit the rest by name or role. If no such result comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem aimed at attribution. Precise honesty beats a larger claim |
| E3 | "You have two minutes: what is product operations, and why does a company need it?" | JD | [generic] | A one-sentence definition in your own words, two problems it solves, one way you would know it is working. Stop at two minutes | Time-boxed role definition tests clarity under pressure. Covers F2 and F3 |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Pick a number you would put forward as yours. Walk me through how it was counted." | EXP | [generic] | Selection scaffold. Say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words. Say plainly if you do not know how part of it was counted. If no figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. The weakest-assumption move turns a gotcha into credibility. Covers F2 |
| F2 | "A weekly metric dropped 20 percent. Diagnose it." | CASE | [generic] | Check data and definitions first, then segment by time, user group and source, then look at what changed. Think aloud and name what you would rule out first and why | Persona stem. Covers F4 as a live problem |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you started, what moved you, why this role. Each beat is something you can say without checking your notes. If a beat has no real answer yet, find it before the interview | Casual and scored. Plan the arc in advance |
| G2 | "Which part of this job are you most excited about, and which are you least looking forward to?" | JD | [generic] | Name one of each in your own words. The second should be real and survivable, not a disguised strength | Rapport interviewers use this to test genuine interest and self-awareness |

## Requirement coverage

No job description was supplied, so the requirements are the role-family patterns from the fit snapshot.

| Requirement | Questions |
|---|---|
| F1 cross-functional launch | A1, D2 |
| F2 operating metrics | F1, E3, A4 |
| F3 process adoption | A2, A4, B4, D3, E3 |
| F4 data into recommendation | F2, B4 |
| F5 influence without authority | B3, D1, A1 |
| F6 prioritization | A3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make this role clearly successful at six months, in your words?" | Gets the success definition from the person who scores you and shows you plan around outcomes |
| R2 | "Where does product operations currently stop and product management start in practice?" | Shows you think about the seam and surfaces expectations before you accept the job |
| R3 | "What is the hardest part of the job that candidates tend not to ask about?" | Invites candor and signals you want the real job |
| R4 | "What have previous attempts to improve how product teams operate looked like, and what happened to them?" | Shows you want to learn from earlier attempts before you build |
| R5 | "How will I know in the first month whether I am pointed at the right problems?" | Ties to B4: you plan to learn before changing things |
| R6 | "If a peer is in the room: what could a new person do in the first month that would genuinely help your team?" | Reciprocity question for a peer interviewer, per the persona prior |

## Prohibited claims

Nothing is listed. No sentence of yours was supplied, so there is nothing for this pack to inflate, no stated negative to protect and no dossier to supply a prohibited claim. No cell in this pack says what you did, owned or decided. If you add a CV, this section is rebuilt against it before the banks are rewritten.

## Sources

Provided documents: none. No dossier, JD, CV, recruiter note or interviewer profile was supplied.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Query sent | Outcome |
|---|---|
| Stripe operating principles values | refused |
| Stripe interview process Product Operations Manager | refused |
| Stripe strategy news 2026 | refused |
| Product Operations Manager job description Stripe | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet if a values round were documented, and VAL themes. Neither was possible, so VAL questions use persona stems only |
| 2. Stripe interview process, product operations | unavailable | Would have established the loop and persona weights. Weights are a generic fallback, and the final-round structure is not asserted |
| 3. Stripe strategy and recent news | unavailable | Would have grounded the CO and CASE questions. A5 and B2 stay generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the generic requirements into inferred, quoted ones |

## Upgrade menu

- Search permission, or Stripe's own values and careers interview pages pasted → values cheat sheet if a values round is documented, the real loop, and company-grounded CO and CASE questions
- The job description text → the six generic requirement rows become `[grounded]` and quoted, and every question is checked against the posting's own list
- Your CV or a few lines on your product operations background → the worksheet becomes a real fit snapshot, selection scaffolds become story maps, and the prohibited list is rebuilt against what you actually said
- The interviewer names and roles → persona weights read from their public footprint and one tailored reverse question
- The recruiter's prep email → coverage of any announced deliverable or focus area; if your final is several sessions, send the schedule and I can split this into per-session mini-packs
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and the likeliest objection supplied rather than inferred
