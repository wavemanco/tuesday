I've read the playbook. Next I'm running the default research pass on Atlas Freight (values, loop structure, recent strategy), then I'll build the prep pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-2-denied-c78d0603/Atlas-Freight_operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles, a fit snapshot against each JD line, reverse questions, and a list of claims not to make.

- **No company research:** Web search was blocked this session, so nothing in the pack comes from outside research. Atlas's values, interview loop and strategy are all missing, and those questions are marked generic.
- **Assumed round:** Since you don't know who is interviewing you, I built it for a hiring-manager round with a generic loop (screen, hiring manager, panel). The persona weights rest on that pattern.
- **Your likeliest objection:** Question B1 is the one to rehearse most: you manage three supervisors today and the role is twelve across four sites. The pack gives you a concession line and a ladder of follow-ups for it.
- **Gaps to prepare for:**
  - Power BI: you said you've never used it, so the pack gives you a plain acknowledgment and a learning plan.
  - Multi-site and terminal work: your background reads warehouse and distribution, one site.
  - Years leading: your material shows seven years in operations but not how many of those were spent leading.
- **What's covered:** The mis-pick figure, the surge plan and the green belt each have defend-the-detail questions. Where your background doesn't show something, the pack gives you an "answer slot" instead of putting words in your mouth. Fill each slot from your own experience, or say plainly it wasn't yours.

I can play the Skeptic live on B1, the highest-ROI question, if you want to drill it. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Who are you meeting (your future manager, a peer, or someone senior or HR), and is it one conversation or a panel? The answer reweights every bank, and anything the recruiter said about focus areas or a take-home would help too. Do you also want me to retry the company research if you allow searches, up to 6 searches and 2 page fetches?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship: not stated, so this pack is built for a hiring-manager round. If that is wrong, the persona weights and banks change (see the upgrade menu).

## How to use this pack

- Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored.
- Type key: VAL = behavioral or values alignment. EXP = work-experience deep-dive. JD = role or JD-driven. CO = company and strategy knowledge. CASE = hypothetical or live problem.
- Provenance labels: `[grounded]` traces to something you wrote or the JD you pasted. `[inferred]` is this pack's derivation, named where it is used. `[generic]` is a role-family pattern with no claim about you or Atlas.
- Guidance is scaffolding, not a script. Where a row says "Answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours or never existed.
- The highest-ROI rehearsal in this pack is B1. This pack inferred it from F1 and F3 because no underwriting dossier was available.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution work and a surge plan the quote calls the site's. It does not show terminal operations or more than one site. The words stay at the quotes: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on multi-site ownership likely. If any of your work covered more than one site, or was terminal work, say which and how, in your own words; if none did, say so plainly and stay with the work the quotes carry |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is about the mis-pick rate and the pick path, not on-time performance or cost per shipment, and the bridge does not stretch it: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's on-time and cost line makes a probe on whether you tracked either likely. If you tracked either, say which and how it was counted, in your own words; if you did not, say so plainly, and say what you would measure first |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote carries three supervisors and the role is twelve. The pack states that difference and does not close it: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than three supervisors at any point, say when and how many, in your own words; if not, say so plainly and stay with the three you lead now |
| F4 | "build reporting in Excel/Power BI" — JD (Excel side) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill level and does not show reporting was built; the derivation is the pack's. The words stay at "my Excel is solid". Answer slot: the JD's reporting line makes a probe on what you have built likely. If you built reports or trackers in Excel that others used, say what they showed and for whom; if you did not build reporting, say so plainly and return to "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI side) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller. Your material does not show whether the JD's slash means either tool or both; R2 asks |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material shows seven years in operations and a current leadership role. It does not show how many of those years were spent leading. Words: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's "required" makes a probe on the leadership years likely. Say how many years you held leadership roles, and in which roles, in your own words; if the count is below five, say so plainly and stay with the roles you hold |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it (the certificate would raise this), so expect a probe. Lead with it in its own terms: "I'm green belt certified." Answer slot: if a project went with the certification, say what it was and what was yours; if none did, say so plainly and stay with the certification |

## Persona table

Reasoning for the weights, shown so you can recalibrate. Relationship prior: a hiring-manager round, assumed because you did not say who you are meeting. Interviewer signals: none, since you know nothing about them. Loop: no loop source was available (the JD names no rounds and research did not run), so the fallback archetype is Generic (screen, hiring manager, panel) with flat-ish weights, and these weights rest on that pattern and not on Atlas's documented process. Values-style round: not detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Case/Strategist | Live problems drawn from the job: diagnose on-time slippage, cost per shipment, peak planning | High: hiring-manager prior, and the JD's duties are operating problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of scale, terminal versus warehouse, years of leadership, tooling | High: hiring-manager prior, and F1, F3, F5 and F6 are where the JD and the material differ | Rehearse B1 until it is boring; bridges only from what you stated; calibrated candor over bluffing |
| C. Data-Driven Prober | Reads your numbers line by line; asks how they were counted | Medium: the JD stresses measures and reporting | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| D. Conversational | Friendly opener, casual questions on the JD's plus-skill | Medium: a loop that begins or ends with a chat is common in the Generic pattern | A 90-second arc built only from your own sentences; treat casual questions as scored |
| E. Pressure | Interrupts, time-boxes, asks how much was actually you | Low: no signal of a stress style | Pause, restate, hold through two follow-ups, concede specifically |
| F. Values/Behavioral | Scenario probes on judgment and customer focus | Low: no values-style round detected and no published values in hand | Pick stories that carry a named stake; where none comes to mind, say so plainly |
| G. Peer Evaluator | Seam and collaboration questions | Low: relationship assumed to be a manager, not a peer | Reciprocity framing; propose seam principles, not pretend knowledge of the seam |

## Question banks

### Bank A: Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance across the four sites has slipped over the last month. Where do you start, and what do you need to know first?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: what counts as on-time here, measured against which promise, and slipped by how much and where. Then state an objective, split the problem by site, shift and customer, name how you would test the likeliest causes, say which metric you would watch, and name the risk of fixing one site at another's expense. Think aloud and challenge one premise respectfully | Live problem from the JD's on-time line (F2's requirement); CASE because it scores structure. `[generic]` because it is a pattern for the problem |
| A2 | "Cost per shipment is up and you have no new budget. What do you look at, and in what order?" | CASE | [generic] | No claim about your past. Define the numerator and denominator before diagnosing. Break the cost into its parts, find the largest part you control, separate quick moves from structural ones, and name the one metric you would protect so cost does not come at the expense of on-time | The JD's cost-per-shipment line (F2's requirement) as a decision rather than a record |
| A3 | "You have twelve supervisors across four sites and no two run a shift the same way. What do you standardise first, and how do you get buy-in?" | CASE | [generic] | No claim about your past. Ask what is driving the variation before deciding it is a problem. Pick the one or two routines that matter most, involve the supervisors in setting them, pilot at one site, and say how you would know it worked. Hold the structure rather than inventing a past example | F3's requirement at its real scale; the pack cannot know what Atlas's supervisors do today, so the answer is structure, not content |
| A4 | "Peak season is six weeks out and volume is forecast well above normal. How do you plan across four sites?" | CASE | [generic] | No claim about your past. Clarify the forecast and its confidence, then objective, capacity by site, the constraints that bind first, trigger points for adding capacity, and risks. State the premise you would challenge | A planning problem in the shape the JD's daily-operations line implies; B-bank and C-bank rows cover your own experience, so this row stays generic |
| A5 | "You inherit four sites, twelve supervisors and a reporting pack you did not build. What do your first thirty days look like?" | CASE | [generic] | No claim about your past. Listen before changing: see each site, meet each supervisor, find out what is measured today and by whom, choose two or three measures to track, and defer large changes until you have seen a full cycle. Say what you would report back and when | Covers the ramp question that F1 and F3 invite, asked as a plan and not a history |

### Bank B: Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role is four sites and twelve supervisors. You currently have three supervisors. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "7 years in warehouse and distribution ops" | The highest-ROI rehearsal in this pack. Name the limit before it is asked: the quotes carry three supervisors, a surge plan the quote calls the site's, and seven years in operations; they do not carry twelve supervisors or more than one site. Concession, in these words: "Today I manage three supervisors; this role is twelve across four sites, so the scale is a step up from what I hold now." Then hold what you do have: "I'm currently a senior shift manager over 3 supervisors; I ran the site's peak-season surge plan two years running; I have 7 years in warehouse and distribution ops." Follow-up 1, "three is not twelve": agree plainly, then say your first step in the role, in your own words. Follow-up 2, "why would it scale": return to the quotes and add nothing; say how you would find out in the first weeks. Follow-up 3, "why not hire someone who has done it": state what you hold, the limit, and your ramp. Answer slot: the JD's twelve supervisors and four sites make a probe on leading at that scale likely. If you have led more than three supervisors or worked across more than one site, say when and how many; if not, say so plainly and stay with the quotes. Do not describe what these items prove; let the interviewer draw it | This objection arrives in some form, and F3 and F1 are where the role presses hardest on the material. JD because it scores the stated requirement; it is asked in this shape because the premise is only the JD's numbers and your own quote |
| B2 | "Your background reads warehouse and distribution. Where does a freight terminal differ, and what would you need to learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I have 7 years in warehouse and distribution ops." Do not claim terminal knowledge you have not stated. Say what you would ask first in the opening weeks, in your own words. Answer slot: the JD's "terminal operations" makes a probe likely. If any of your seven years touched terminal or freight-handling work, say what and where; if none did, say so plainly and stay with warehouse and distribution | F1 is the evidence for the terminal requirement and the likeliest place for a Skeptic to press; JD because it scores the listed duty |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | An open prompt, so choose the answer that is true. Your stated "never used Power BI" is one honest candidate: "I've never used Power BI." Then a concrete first step to learn it, as a plan in your own words. Your material also shows scale (F3) as a limit, so decide which you would name first and why. If no weakness comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Never name a weakness you do not have in order to sound modest | F5 is a gap you stated and F3 a visible limit, so this stem is likely; JD because it asks about the listed requirements |
| B4 | "Why this role, why now, and why Atlas?" | CO | [generic] | No claim about your past. The reason for wanting the role and the timing are yours: say them in your own words and keep them consistent with what you told the recruiter. The "why Atlas" part needs something you found in Atlas's own materials, and this pack could not research any, so find one fact yourself before the interview. If you cannot yet say why Atlas, say so plainly to yourself now and fix that gap before next week | The Skeptic's motivation probe; tagged CO because it tests homework and `[generic]` because research did not run |
| B5 | "The role asks for five or more years of operations leadership. Walk me through the leadership part of your seven years." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start from the quotes: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: say how many of the years you held leadership roles, and in which roles, in your own words; if the count is below five, say so plainly and stay with the roles you hold | F6 is where the JD's required tier meets a material that does not state leadership years |

### Bank C: Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate by 40%. Walk me through how that was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number, all in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before the interviewer does. Where you do not know how it was counted, "I don't know how that was counted" is an honest answer. The quote states the redesign and the 40%; add nothing about baseline, period or method unless you can repeat it under a second question | A headline metric on the material, so F2's evidence is the likeliest target of a Prober; EXP because it tests attribution and counting |
| C2 | "Tell me about the peak-season surge plan. What was in it?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped only to the quote's beats: the plan, the site's, two years running; tell them in your own words. Answer slot: the JD's on-time and cost lines make a probe on how the surges went against either likely. If you tracked either across the surge, say what and how it was counted; if you did not, say so plainly and describe how you ran the plan | F1's evidence is the closest thing to operational scale in the material; EXP because it tests what was actually done |
| C3 | "You will build reporting in Excel or Power BI. Show me what you have built." | JD | [grounded] "solid Excel"; "never used Power BI" | The question's premise is the JD's, and the quotes do not carry it. Say "my Excel is solid" and "I've never used Power BI". Answer slot: if you built reports or trackers in Excel that others used, say what they showed and for whom; if you did not build reporting, say so plainly and return to "solid Excel". Then a concrete first step to learn Power BI, as a plan in your own words | F4 and F5; JD because it scores a listed tool requirement, and the slot lets the premise be false |

### Bank D: Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc from those four beats, in an order you choose, because your material gives no dates or sequence. Close on why this role, in your own words. Add no title, employer or year that you have not stated | A friendly opener that is scored; F1, F2 and F3 are the beats it draws on |
| D2 | "Lean and Six Sigma are listed as a plus. What does that mean to you in terminal operations?" | JD | [grounded] "green belt certified" | Say "I'm green belt certified" and what you take it to mean in your own words. Answer slot: if a project went with the certification, say what it was and what was yours; if none did, or you have not applied it since, say so plainly and stay with the certification | F7 is the one row the JD marks as a plus and the material answers; JD because it scores the listed plus |
| D3 | "Tell me about the team you lead today." | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Say what the quote says: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's "lead a team of 12 supervisors" makes a probe on how you lead supervisors likely. If you have a way you lead yours, say what it is in your own words; if there is no set way, or it was not yours to set, say so plainly and return to the three supervisors you lead now | F3's evidence in a relaxed register |

### Bank E: Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold the sentence at its scope: "I cut the mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to it, never by adding to it. Concede specifically and only what is true. Answer slot: if anyone else shaped the result, say who and what; if it was all yours, say so plainly; if you do not know how much other changes contributed, say so | Attribution probe aimed at F2's evidence; EXP because it tests what was yours |
| E2 | "Sixty seconds: why you over a candidate who has already run four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 60-second structure: one thing you hold in your own quoted words, the limit named plainly (you do not claim to have run four sites), and one first step in the role. Say what you did and let the interviewer draw the inference. Do not claim multi-site experience | F1 and F3 are the limits this question presses; JD because it scores the stated role |

### Bank F: Values/Behavioral (low weight)

No published values were available, so these two questions use open prompts and are `[generic]`.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, what you said, how it landed, and an intact relationship afterward. Your material carries no such story, so none is supplied here. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard behavioral stem, kept low because no values round was detected |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a named customer, the metric at stake, what you decided, and what it cost. Your material carries no such story, so none is supplied. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem; fits a freight business whose output is a customer promise |

### Bank G: Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | No claim about your past. Propose seam principles, not a pretended knowledge of Atlas's seam: who owns the decision, what gets escalated and when, and which shared measure settles a dispute. Offer what you bring their team, not only what you need | Peer weight is low because the round is assumed to be a manager's; kept in case the interviewer is a peer |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: a joint result, what was yours and what was others', and how you said so. Your material carries no such story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing probe from the Peer persona |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, A5, B1, B2 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, A4, C2 |
| "lead a team of 12 supervisors" | A3, B1, D3, E2 |
| "build reporting in Excel/Power BI" | B3, C3 |
| "5+ years operations leadership required" | B1, B5 |
| "Lean/Six Sigma a plus" | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured today, and where does it vary most across the four sites?" | Shows you think in definitions and variation, and tells you what you would inherit (A1, F2) |
| R2 | "What do the supervisors and site leads report from today, and how are Excel and Power BI split between them?" | Settles whether Power BI is a day-one skill or something you would build into, which F5 leaves open |
| R3 | "How are the twelve supervisors spread across the four sites, and what support do they get?" | Sizes the scale step honestly before you accept it (F3) |
| R4 | "What would a good first thirty days and a good first ninety look like to you?" | Turns the interview into concrete expectations and pairs with A5 |
| R5 | "How do new managers get ramped across the sites in their first month?" | Shows a ramp mindset on the scale and terminal questions without conceding them (F1) |
| R6 | "What is the hardest part of this role that the job description does not say?" | Invites candor, and the answer tells you what the interview is really screening for |

If the interviewer turns out to be a peer, add a reciprocity question, such as what a new person could do in their first month to help their team.

## Prohibited claims

Built locally from the fit snapshot, before the banks. Each is a claim a candidate reaches for under pressure and this pack does not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution work and the site's surge plan. B1 and B2 stay inside that scope |
| Led a team of twelve supervisors, or a larger supervisory team than three | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors" |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope: the mis-pick rate and the pick path. C2's slot asks only what was tracked |
| Built reporting in Power BI, or used it | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Held five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: seven years in operations, and a current leadership role. B5's slot asks for your own count |

## Sources

Provided documents: the job description and your background, both pasted in your message. No dossier was present.

Searches sent (all refused, so nothing in this pack comes from outside research):
- "Atlas Freight regional logistics company values": refused
- "Atlas Freight operations manager interview process": refused
- "Atlas Freight regional logistics strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and values-mapped questions; none is built, and F-bank questions are `[generic]` |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have established the loop and set persona weights; the weights here rest on the Generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO question and the grounding brief; B4 is `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so no query could be formed; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to run web searches, or the text of Atlas's values page or careers page → a values cheat sheet if a values round is documented, and grounded values questions in place of the `[generic]` ones
- The recruiter's description of the loop (how many rounds, who runs each, any case or presentation) → real persona weights in place of the Generic pattern, and per-round mini-packs if there is a schedule
- The interviewer's name or even just their title → a reading of the interviewer, persona weights adjusted to them, and a reverse question tied to their path
- Your own answers to the slots in F1, F2, F4, F6 and F7 (multi-site or terminal work, on-time or cost tracking, Excel reports built, years spent leading, the project behind the green belt) → those rows upgrade from `[inferred]` or gap rows to `[grounded]` stories
- The green belt certificate, or a sample of an Excel report you built → raises F7 and F4 from the evidence you have now to something inspectable
- How many hours you have to prepare → a prioritized prep schedule
- A `tuesday-dossier.md` from earlier work, if you have one → verified evidence and a named top objection in place of the pack's inferences
