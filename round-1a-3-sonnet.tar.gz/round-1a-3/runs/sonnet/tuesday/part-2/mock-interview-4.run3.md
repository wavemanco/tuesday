Let me read these with the Read tool instead.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-4-denied-6596c787/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round, one 45-minute conversation, as you described, and used your dossier for the requirements, your confirmed evidence, the strategy limits and the prohibited claims.

My web searches were refused, so the pack says nothing about Quartzline's values, interview loop or strategy. The case questions are generic role-family problems, not Quartzline's own, and the pack says so. If you grant search permission, I can fill those in.

The pack has 18 questions. A1 is the one to rehearse first: "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" Your dossier named it. The pack coaches it as: concede both negatives plainly, bridge only with the integration work you quoted and name its limit, then give a ramp plan.

Two things you should know before you rehearse:
- **Roadmap and prioritization:** the pack coaches only an acknowledgment and a ramp plan, never a bridge, because the dossier found nothing to bridge with. The quarterly roadmap-input sessions stay at "fed client evidence to product", not roadmap ownership.
- **Requirements the dossier left ungraded:** it didn't grade R2, R3 or R4, so I graded them from your verified evidence. Treat those grades as suggestions for the underwriter to review.

Say the word and I'll play the Skeptic on A1, with follow-ups that react to what you actually say.
I can also save an updated `tuesday-dossier.md` with this prep's gaps and leads, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: one 45-minute conversation with the hiring manager (interviewer's name not given). Session mode. Built from tuesday-dossier.md (job-underwriter, dated 2026-08-14) and the role-family patterns the round type implies. No web research was available, so nothing here describes Quartzline's values, loop or strategy.

Highest-ROI prep in this pack: A1. The underwriter named that objection, and the pack rehearses it deepest.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior demonstrates the company's published values (none detected for this round, so no VAL questions) |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none here: no research ran) |
| CASE | A live problem from the role, scored on structure and reasoning |

Proposed wording in this pack is pending your approval: nothing is final until you have said it aloud and it is true in your own words.

## Fit snapshot

Requirements are the dossier's role_profile lines, quoted. Evidence is the dossier's verified candidate evidence, quoted without its confidence notes. Rows F3 to F5 are graded by this pack, because the dossier grades only R1 and R5 in its weak-areas list. Treat those grades as suggestions for the underwriter to review.

Gap and bridge language below is proposed wording, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [grounded] | transferability | The dossier grades this a bridge, with its limit named: the work is integration work, positioned as adjacent and never as PM experience. Plain acknowledgment first, sourced from `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title." Then the quotes at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live, and I wrote the internal integration playbook my team uses." Answer slot: the 3+ years line makes a probe on the span of your integration work likely. Give that span in your own words, since this pack holds no figure for it; if it is shorter than the interviewer expects, say so plainly |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities; "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier handoff uncertain_or_weak_areas | none given | none | [grounded] | capability | A gap wording cannot close, and the dossier records it as `acknowledge_gap`, so no bridge is coached. Words, sourced from `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past: in the first weeks, learn how roadmap decisions are made and which of them would be yours. No answer slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | high | [inferred] | transferability | Derived by this pack: the dossier lists R2 as high priority but grades it nowhere. The quotes show integration work and a playbook; they do not show an API or platform product delivered, and the words stay at the quotes: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: R2's wording makes a probe on what you delivered likely, and go-live is the stage the quote names. Say what your part in go-live was, in your own words; if it was not yours, say so plainly and stay with the stages you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | high | [inferred] | discovery | Derived by this pack: the quotes touch the requirement (REST APIs, architecture, a playbook) without showing whether the work reached API docs or schemas. The high band grades the quoted claims, not that question. Answer slot: R3's wording makes a probe on docs and schemas likely. If you read, wrote or reviewed either, say which and how, in your own words; if you did not, say so plainly and stay with the architecture work in the quote |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | medium | [inferred] | discovery | Derived by this pack. Confirmed, limited inspectable proof, so expect a probe on the sessions and volunteer their limit first: they fed client evidence to product, and `prohibited_claims: "Having owned a product roadmap"` stands. The quotes show clients and product; they do not show engineering or sales. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: R4 names engineering, sales and customers. If you worked with engineering or sales in these sessions or in the integrations, say who and what you did with them; if not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier grades this `clarify`: the evidence may exist and was not established, and no verified entry speaks to it. Answer slot: R5's wording makes a probe likely. If you worked in an agile delivery team, say what the team was and what your part was; if you did not work that way, say so plainly. You may also confirm the definition first: "Before I answer, I'd like to confirm how you define agile delivery on these squads" |

## Persona table

Reasoning is shown so you can recalibrate. The only round facts are yours: one 45-minute conversation with the hiring manager. That fixes the relationship; it names no company-specific loop, so weights rest on relationship priors and on the dossier.

| Persona | How it shows up | Weight and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the PM-title gap and the missing roadmap | Top, 5 questions. The hiring-manager prior puts it first, and the dossier names the objection it will press | Rehearse A1 until it is boring: concede the two negatives plainly, hold the quoted bridge through two follow-ups, never add to it |
| Case / Strategist | Live problems from the role: adoption, docs, a priority conflict | Top, 5 questions. The hiring-manager prior puts it first, and the role's responsibilities are written as live problems | Clarify first, state the objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads the quoted claims line by line and asks how each was counted | Mid, 3 questions. The 30+ figure is a headline number, and the playbook is the inspectable proof | Know what you can say about how the count was made; say plainly what you do not know; name your weakest assumption first |
| Conversational | Opens with the journey; casual questions are still scored | Mid, 3 questions. A 45-minute manager conversation usually has an opener | A 90-second arc built only from your own sentences |
| Peer Evaluator | Where the seam sits between you and the two squads, and what happens in a disagreement | Low, 2 questions. The interviewer is your future manager, but the squad-authority question makes the seam likely | Offer seam principles; do not pretend to know the seam; ask for the real one |
| Pressure | Interrupts and time-boxes | Not banked. No signal for it; its hold-then-concede skill is built into A1's follow-ups | See A1 |
| Values / Behavioral | Scenarios mapped to published values | Not banked. No values-style round is established by your words, and no published values are in hand. A4 and D3 are the nearest rehearsal if one arrives | See A4, D3 |

## Question banks

Answer guidance below is proposed wording, pending your approval. Each row's Provenance carries the sentences its claims about your past rest on.

Requirement coverage:

| Requirement | Covered by |
|---|---|
| R1 3+ years product management experience | A1, A2, A4, D1 |
| R2 Shipped API or platform products | A5, C1 |
| R3 Technical fluency: API docs, schemas | B3, C2, D2 |
| R4 Stakeholder management across engineering, sales, customers | C3, D3, E1, E2 |
| R5 Agile delivery experience | A3 |
| Responsibilities: roadmap, spec and delivery with two squads, adoption metrics | A2, B1, B2, B4, B5, E1 |

### A. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The highest-ROI rehearsal, named by the underwriter. Order: concede, bridge with its limit, plan. Concede both negatives first, sourced from `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"`: "I haven't held the title, and I haven't owned a roadmap." Bridge, at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live, and I wrote the internal integration playbook my team uses." Name the limit before it is asked: this is integration work, not product management, and you are not claiming it as PM experience. Then the plan: how you would learn which decisions are yours and how adoption is measured today. Follow-up 1, what in that is product work: return to the quotes; do not add to them. Follow-up 2, why not the PM with three years: concede specifically, "I don't have three years in a PM role", then hold the quoted work and the plan. Answer slot: if asked how long you did the integration work, give your own dates; this pack holds no figure | F1 and F2 are where the role presses hardest, and the dossier says this question will arrive in some form; JD because it scores the stated R1 |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas` acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it plainly, sourced from the dossier's acknowledge_gap area and `prohibited_claims: "Having owned a product roadmap"`: "Owning the roadmap and setting priorities is where I'm weakest on day one; I haven't done it." Then the plan, as a plan: you would learn first how roadmap decisions are made and which would be yours. Do not offer a bridge here; the underwriter looked and found none | F2 is the dossier's one capability gap, so the Skeptic goes there when asked for a weakness; JD because it scores the responsibilities line |
| A3 | "Tell me about a time you worked in an agile delivery team." | JD | [grounded] | Clarify before answering, in your own words: "How do you define agile delivery on these squads?" No verified entry speaks to this requirement, so the guidance cannot supply a story. Answer slot: R5's wording is the interviewer's likely probe. If you worked in such a team, say what the team was and what your part was; if you did not work that way, say so plainly and say what you would want to confirm about how they define it | F6 is a `clarify` area; the open prompt asks you to choose an instance and supplies none. JD because R5 is the stated line |
| A4 | "Why move from the integration work you've done into product management, and why this role, why now?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Your reason is yours; this pack supplies none. If the move grew out of the quarterly sessions, say so, using the sentence the quote supports: "I ran quarterly roadmap-input sessions feeding client evidence to product." Then your own reason for wanting the product work itself. If it did not grow from there, give the actual reason. Volunteer the limit first: confirmed, limited inspectable proof, and the sessions were not roadmap ownership, per `prohibited_claims: "Having owned a product roadmap"` | Motivation consistency is what the Skeptic scores; F5 holds the only quoted work near product. EXP because it tests whether your story survives cross-examination |
| A5 | "The role asks for shipped API or platform products. Where does your experience sit against that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: go-live is the stage the quote names, and the probe will go there. Say what your part in go-live was, in your own words; if it was not yours, say so plainly and stay with the stages you led. Hold by returning to the quote, never by widening it | F3 is the likeliest place for a second must-have probe; JD because it scores R2 directly |

### B. Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner adoption of the API has stalled. How do you start?" | CASE | [generic] | Clarify first: stalled against what baseline, and who counts as a partner. Then objective, segmentation of partners by how far they have got, approach, the metric you would trust and what it would miss, and risks. Say you would want the current adoption baseline before committing to a diagnosis. The question needs no claim about your past, so the guidance makes none | Adoption metrics are a named responsibility with no baseline stated; a pattern for the problem, not a fact about Quartzline |
| B2 | "Two squad leads each want your single next-quarter slot for their own work. How would you decide?" | CASE | [generic] | Frame it as what you would do, never what you have done. Clarify who holds the final call; state criteria you would apply and what evidence you would ask each lead for; say how you would keep both informed; name the escalation path. Ask who owns the decision, because the dossier lists squad authority as unresolved | F2 is the gap the Skeptic presses; this tests it as a decision. `[generic]` because it is a pattern for the problem |
| B3 | "A partner says the API docs are why they can't go live. How do you diagnose it?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify first: which partner, which stage, what failed. Segment by where they are in the stages the quote names, then separate documentation from schema from behavior, and say what evidence you would collect. The quote supports that you led integrations through those stages; it does not say how you used docs or schemas | F4's requirement as a live problem; the stages come from the quote and the diagnosis structure is generic |
| B4 | "Sketch your first 90 days on the partner API platform. What do you need to know first?" | CASE | [generic] | Open with what you need to learn: which decisions are yours, how adoption is measured today and the baseline, how the two squads work. Then a sequence: listen, baseline, a first small bet. It is a plan; claim no past. The same two unknowns are your reverse questions V1 and V2 | Plan-this stem for a hiring manager; it also lets the ramp plan from A1 and A2 carry the weight |
| B5 | "Partner API calls fell 20% last week. Diagnose it." | CASE | [generic] | Clarify scope and time first, then split into the usual causes: measurement, a few partners versus all, a release, a seasonal change. Say what data you would pull in which order and which premise you would challenge. Name no specific cause as known | Metric-drop stem; it tests structure, not the right answer |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations figure was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts integrations, not clients or partners; keep it on that noun. Tell it in the quote's own terms. Answer slot, the four a figure raises, in your own words: how it was counted; what it is sensitive to; the assumption you would defend least, named before they ask; and which part was yours. If you do not know how a part was counted, say so plainly | F1's headline number; probers go two levels deeper than the answer |
| C2 | "Tell me about the integration playbook you wrote. What is in it and how does your team use it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say what the quote says: you wrote it, and your team uses it. Answer slot: R3 asks about API docs and schemas, so expect a probe on whether the playbook touches them. If it does, say how; if it does not, say so plainly and stay with what you wrote. Name only contents you can walk through end to end | The playbook is the dossier's inspectable proof, so it is where a prober starts |
| C3 | "Walk me through the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell it at the quote's scope: quarterly, client evidence, fed to product. Volunteer the limit before it is extracted: confirmed, limited inspectable proof, and `prohibited_claims: "Having owned a product roadmap"` stands. Answer slot: R4 names engineering, sales and customers, so expect a probe on who else was involved. If engineering or sales were, say who and what you did with them; if not, say so plainly and stay with clients and product | F5 is the one medium-confidence entry; the dossier says to expect a probe |

### D. Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, one per quote, at their own scope. Open with the integrations, then the playbook, then the sessions, then your own reason for the move into product. Roles, employers and dates are slots: say them in your own words, since this pack holds none. State the adjacent framing yourself, once: integration work, not a PM seat | A friendly opener is still scored; F1 is where it lands |
| D2 | "What are you actually working with in API docs and schemas these days?" | JD | [grounded] | Name one tool or spec you have actually used, if one comes to mind; if none does, say so plainly, then say what you would learn first. The pack names no tool, since none is in your material | R3 asked casually; a casual question on a JD topic is still scored |
| D3 | "Tell me about a time you took customer feedback to engineers or sales." | JD | [grounded] | Pick an instance with a named piece of customer evidence, who you took it to, and what you asked of them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The quote about the quarterly sessions goes to product, not to engineers or sales, so do not stretch it | R4's three audiences as an open prompt; F5 shows only one of them |

### E. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between you and the two squad leads, and what happens when you disagree?" | JD | [generic] | Offer seam principles, not a seam: you decide what and why, they decide how and who; evidence settles disagreements before authority does. Say you do not yet know where the real seam sits, and ask. Never describe prioritization you have set for a squad | The unknown the dossier names; the Peer stem in a hiring-manager round |
| E2 | "How do you handle credit when work spans teams?" | JD | [generic] | Pick a time credit was shared across teams: what you said, what each team did, and how the relationship ended. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then say how you would handle it | R4 in collegial packaging; no quote carries a story for it, so this is a scaffold |

## Reverse questions

Proposed wording, pending your approval. Written from the dossier's unresolved risks and employer questions.

| # | Question | Why it lands |
|---|---|---|
| V1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's risk is that decision authority is asserted in the JD and not evidenced. It reads as diligence, and the answer settles the condition the underwriter set |
| V2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no baseline stated. The answer shows what you would inherit and sets up B1 and B5 |
| V3 | "When the two squad leads want different things in a quarter, who settles it, and how?" | It puts the seam question E1 in the interviewer's hands, so you do not have to guess it |
| V4 | "What would a strong first 90 days look like for someone coming from integration work rather than a PM seat?" | It turns A1 into a joint ramp plan, and lets the interviewer define what closes the gap |
| V5 | "What would you want the person in this seat to have changed by the end of their first two quarters?" | It asks for outcomes, not activities, and calibrates A2 against what they actually need |
| V6 | "How do the two squads and the PM split discovery with integration partners, and who talks to partners first?" | It tests the discovery responsibility from their side, and draws on your integration background without claiming discovery |

## Prohibited claims

Built from the dossier's prohibited_claims and this pack's own fit snapshot, before the banks were written. No guidance, slot, hold, bridge or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims: "Having held a product manager title or role"` | "I haven't held a product manager title." Then F1's quotes at their own scope. No slot |
| Having owned a product roadmap | `prohibited_claims: "Having owned a product roadmap"`; `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | "I haven't owned a product roadmap." The quarterly sessions stay at F5's scope: client evidence fed to product. No bridge, no slot |
| Having set prioritization for an engineering squad | `prohibited_claims: "Having set prioritization for an engineering squad"` | "I haven't set prioritization for an engineering squad." No bridge, no slot |
| Shipped an API or platform product | Inflated form of F3: R2's wording against a quote about integrations | F3's quote at its own scope. The limit is the pack's observation: the material says integrations led, not a product delivered. A5's slot stays inside go-live |
| Ran product discovery with integration partners | Inflated form of F5: the role's discovery line against a quote about roadmap-input sessions | F5's quote at its own scope. The limit is the pack's observation: the material says sessions feeding client evidence to product |
| Worked with 30+ clients or partners | Inflated form of F1: the figure in the quote counts integrations | F1's quote, with the figure on its own noun. C1's slots ask how the count was made |

## Sources

Provided documents: tuesday-dossier.md, dossier_version 1.1 (major version supported), generated 2026-08-14 by job-underwriter. Sections consumed: role_profile (requirements and responsibilities, the JD equivalent), handoff_to_mock_interview (verified candidate evidence, weak areas with their allowed strategies, the interviewer objection, risks, employer questions, prohibited claims). Sections not present in the file: evidence_map, evidence_state, risk_register. The dossier decision (conditional_go) was treated as context only.

Searches sent, all refused (web search permission was not granted in this session):

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline API platform strategy news" — refused

Loop: your own words establish one session, a 45-minute conversation with the hiring manager. No archetype fallback applies, and no values-style round is established.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have fed a values cheat sheet if a values-style round had been established, and themed VAL questions. Nothing is in this pack from it |
| 2. Quartzline interview process, product management | unavailable | Would have named the round's format and any other rounds, and reweighted personas. Weights rest on the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded a CO question and made B1 to B5 specific to Quartzline. They are generic |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative product manager, platform APIs JD | skipped | The dossier's role_profile requirements fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission → rows 1 to 3 run: Quartzline's published values, the documented loop, and current strategy. That adds CO questions and makes B1 to B5 specific, and shows whether a values-style round exists
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, once search is permitted → the strategy brief behind CO and CASE, the hiring manager's public footprint if named, and recruiter-loop reports
- The hiring manager's name → an interviewer read, persona weights read from their public footprint, and a reverse question tied to their own path
- Recruiter guidance on the 45 minutes (focus areas, any exercise to bring) → coverage assumed from round-type priors becomes stated, and any announced deliverable gets its own build section
- Your own answers to the slots in F1, F3, F4, F5 and F6, stated here rather than in a drill, including the span of your integration work and whether any API or platform product was delivered by you → those rows are regenerated with your words quoted in
- A session agenda or the written summary sent to product from one of the quarterly sessions → F5's medium confidence has a specific artifact that could raise it
- The days and hours you have before Thursday → a prep triage sized to them
