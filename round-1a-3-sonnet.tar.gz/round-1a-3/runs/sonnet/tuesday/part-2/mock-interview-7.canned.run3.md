Running the company research now: values, interview process, strategy, and Tobias Wrenfield's public footprint.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-7-canned-1ca40ea0/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for the Outage Hour, the single 60-minute hiring-manager interview that Saltmarsh's careers page describes: a live-incident tabletop on a simulated outage, then a values conversation, with no take-home. The pack names the C1 question ("You haven't led a team…") as your highest-ROI prep.

Say the word and I'll play the Skeptic on C1, the "you haven't led a team" question, and give feedback against its guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and has the recruiter said anything about the outage scenario? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations — treated as the hiring manager, an assumption built from Saltmarsh's careers page (see Sources), not something you told me
**Round:** the 60-minute interview the careers page calls the Outage Hour: a live-incident tabletop on a simulated outage during a live event, then a values conversation. The page says there is no take-home, so there is no graded-deliverable section

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior demonstrates Saltmarsh's published values |
| EXP | Whether a claim about your experience survives scrutiny |
| JD | A stated responsibility or requirement in the posting, including its gaps |
| CO | Knowledge of the company and its current strategy |
| CASE | Structure and reasoning on a live problem from the role |

Your own sentences appear in quotation marks in the Provenance column. Anything not in quotes is the pack's analysis or a generic pattern, and the label says which. An answer slot is an instruction for the interview, not a question for you now: answer it from your own experience, or say plainly the practice was not yours.

**Highest-ROI prep: C1**, the "you haven't led a team" question. It will arrive in some form, and a rehearsed, non-defensive answer changes the interview.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one main title's weekly content-drop calendar, not a live-events calendar across two titles, with nothing inspected behind it. The words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on the second title likely. If you planned around any other title, say how, in your own words; if you did not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which of these teams you worked with. Answer slot: expect a probe on each of the four. If you coordinated with any of them on content drops, say which and how, in your own words; if you did not, or it was not yours to do, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting the numbers, not owning a review or the KPIs it reports, with nothing inspected behind it. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's word "own" makes a probe likely. If you built those numbers or wrote up a review after a drop, say what, in your own words; if someone else produced them, or no review existed, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: you wrote the checklist, and QA still uses it. Lead with both facts in the quote's own terms: "I wrote the release checklist our QA team still uses." Nothing is added to it; whether you also ran release-day sign-off is not in your material and is not claimed |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Four years is past the three-year mark, and this is a length-of-experience line, not a gate. Your sentence does not say whether the title was live-service. Answer slot: if the main title had ongoing live updates, say what kind, in your own words; if it was not run as a live service, say so plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line of your own with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, content drops, your main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap on the requirement as worded, but a line with nothing inspected behind it. Lead with the monthly presentation to the studio head. Your material does not say how the numbers were counted, which D1 rehearses |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written document QA still uses touches this requirement, but a checklist is not shown to be clear writing, and nothing was inspected. Answer slot: if you have a written piece you can point to, such as a release note, a drop announcement or a review write-up, name which; if you do not, say so plainly |

## Reading the interviewer

Public professional footprint only. The one source found is a conference listing for his GDC 2026 talk, "Patch Notes Are a Promise" (read as a search summary, not the full talk).

| Public fact | Source | What it means for you |
|---|---|---|
| Head of Live Operations at Saltmarsh Games | GDC 2026 talk listing | He heads the function this role sits in. The post-event review and its KPIs are his territory, so do not bluff F3 |
| Previously a QA lead at a console studio | GDC 2026 talk listing | The release checklist is the part of your material nearest his own path. The quote to lead with from F4: "Wrote the release checklist our QA team still uses". Expect the probe to go to what the checklist checked, and answer only from what you wrote |
| His argument: a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk listing | Expect "announced versus shipped" to recur (A2, B2, D2). Mention the talk only if you have actually read or watched it, and then say what you took from it, in your own words |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop on a simulated outage during a live event, then calendar and retention problems | High. The careers page documents the tabletop, and a hiring-manager round weights Case up. Bank A, 5 questions | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values / Behavioral | The values conversation that follows the tabletop, built on three published values | High. The careers page documents a values conversation, and the values page gives three named values. Bank B, 4 questions | Story where one of your quoted sentences carries one, a selection scaffold where none does; "we" for context, "I" for contribution |
| Skeptic | The stated limits and the thin rows F2 and F3 | High. A hiring manager is derisking gaps, and you named two limits yourself. Bank C, 4 questions | Rehearse C1 until it is boring; bridge only from what you stated; give a ramp plan as a plan, never as a past |
| Data-Driven Prober | Retention numbers, the post-event review, announced versus shipped | Medium. The JD names retention and KPIs; the talk summary suggests his interest in what was announced versus what shipped. Bank D, 3 questions | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Pressure | Time-boxing inside the outage scenario | Medium. A simulated outage invites interruption, but time-boxing is not documented. Bank E, 3 questions | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational | The opening of a conversation about values | Low. Bank G, 2 questions | A 90-second arc from your own sentences; treat casual questions as scored |
| Peer Evaluator | Not weighted: the careers page documents this round as with the hiring manager | Low. No bank. If Tobias would not be your manager, the weights change | — |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the first hour of a weekend event. Players say they can't log in, and the event tab still shows last week's rewards. You're the producer on call — what do you do?" | CASE | [generic] | Think aloud in order. Clarify first: how many players, one title or both, what changed since the last release, who is on call in engineering. State the objective: protect players and get an accurate status out. Then act: page engineering, hold the event banner, put one honest line in front of players. Decide whether to pause, extend or leave it running, and who signs that off. Record it for the post-event review. Say aloud that when the calendar and the players disagree, Saltmarsh's published value is that the players win. The question needs no claim about your past, so the guidance makes none | The careers page documents a live-incident tabletop, and a hiring-manager round weights Case up; CASE because it scores structure, with the values page as vocabulary |
| A2 | "Engineering says the fix is two hours away, and the store page promises the event ends tonight. What do you recommend?" | CASE | [generic] | Clarify what is broken, what players lost and what was promised in the store and in the patch notes. Lay out the options (extend, compensate, end on time, roll back) with a cost for each, recommend one and name the one you would reject. Say what you would tell players: only what is built, not what is hoped, which is Saltmarsh's published wording. Challenge one premise politely by asking how firm the two-hour estimate is, and name who you would need agreement from | A second tabletop beat that tests the calendar-versus-players trade and the announced-versus-built line; CASE because it scores the trade-off reasoning |
| A3 | "Project Larkspur puts Tidepool Tactics and Lantern Row on a season pass with one shared events calendar from February 2027. How would you plan the first season's calendar — what do you need to know first?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: season length, what the pass promises players, which events are shared across the two titles and which stay title-specific, team capacity under one live-ops group, what retention and event data exists. Then structure it: objective, shared versus per-title segmentation, approach, metrics, risks such as collisions between the two titles and promises the calendar cannot keep. Your one quoted beat is a single title's weekly cadence, at that scope. Answer slot: the shared two-title calendar is the new part. If you ever had to fit one title's drops around another's, say how, in your own words; if you did not, say so plainly and stay with the weekly calendar you ran | F1 is the evidence for the calendar requirement and the second title is its gap; CO because it uses the Larkspur announcement, CASE in delivery |
| A4 | "Event-day retention is down 20 percent against the last event. Diagnose it." | CASE | [generic] | Clarify the definition first: which retention measure, which cohort, compared with which event. Segment: new versus returning players, platform, build version, region. Check what shipped against what was announced before anything else, then content and difficulty. Say what you would do before the next event and what the post-event review should report. Name the assumption in your diagnosis you would defend least, before the interviewer does | The JD's retention and post-event-review lines tested as a live problem; F7 is the requirement, and the question needs no claim about your past |
| A5 | "The build goes to QA on Thursday for a Saturday event. On Friday at noon QA finds a blocker. Walk me through your call." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Your quote carries the checklist you wrote and that QA still uses it, at that scope. The scenario is a call, so structure it: what exactly QA found and who is affected, the options (fix and slip, ship with a disclosed limitation, pull the feature), who decides, what players are told and when. Say the published value points to protecting players over the calendar. Answer slot: the JD asks you to manage the release checklist with QA. If you ran release-day sign-off with QA, say how, in your own words; if QA ran sign-off and you wrote the checklist, say so plainly and stay with the checklist | F4 is the evidence for the release-checklist requirement; CASE because the decision is delivered live |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the schedule and the players pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold for Players Before Plans: pick an instance with a named stake (what players would have lost or gained), what you changed or did not, who you told, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly calendar you ran, at its own scope, or how you would handle it | The first published value; VAL because it scores behavior against that value, and F1 is the nearest evidence |
| B2 | "Tell me about a time you had to correct or walk back something that had already been announced." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold for Ship the Patch Not the Promise: pick an instance with what was announced, what was actually built, and how you said so. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the checklist you wrote, at its own scope, or how you would handle it | The second published value and the thread of the interviewer's talk; F4 is the nearest evidence |
| B3 | "Tell me about a time you improved a process or a checklist after a release." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote the checklist, and QA still uses it, at that scope. Answer slot: Saltmarsh's value says each release leaves the checklist better than it found it, so expect a probe on changes made after releases. If you changed it after a release, say what changed and why, in your own words; if it stayed as written, or others changed it, say so plainly and stay with writing it | Leave the Build Greener, the third published value; F4 is the only row that carries a checklist |
| B4 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] "Presented the monthly retention numbers to the studio head" | Selection scaffold: it needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the monthly presentations to the studio head, at their own scope (your material does not say whether any were unwelcome), or how you would handle it | A standard values-round question; F3 holds the nearest sentence, and generic because the theme is a pattern, not a published value |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. How do you make that work?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Say the limit first, plainly, in your own words: "I haven't led a team." Then hold on what the JD asks, which is to coordinate, and describe your approach as a plan, not a past: what you would learn from each of the four disciplines in the first weeks and how you would find out who owns which call. Answer slot: if you coordinated with any of the four on content drops, say which and how, in your own words; if you did not, or it was not yours to do, say so plainly. Hold through two follow-ups (what happens when engineering says no; who decides when design and community disagree) by returning to the plan and the limit, never by adding to your past. Concede specifically: what you have not done yet and how you would find out | F2 is the thinnest row and the limit is yours; a hiring manager will ask this in some form. JD because it scores the stated requirement. This is the pack's highest-ROI prep |
| C2 | "You haven't worked on a game with in-app purchases, and both titles are moving to a season pass. What's your plan?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say the limit plainly first: "I haven't worked on a game with in-app purchases." Offer the calendar you ran as adjacent work, at its own scope, and do not present it as pass experience. Then give a plan: what you would learn first (what the pass promises, which numbers the post-event review reports, how events relate to the pass) and who you would ask | The stated limit meets the Larkspur change; F1 is the adjacent evidence. CO because the question rests on company strategy |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] "Presented the monthly retention numbers to the studio head" | Choose from your own material, not from this pack. The snapshot's thinnest rows are F2 (which teams you coordinated with is not in your material) and F3 (your material says presenting the numbers, not owning a review). Answer slot: name the one you would be weakest at, in your own words, then how you would close it in your first weeks, said as a plan. He heads the function that owns what the review reports, so be candid rather than bluff it | The standard Skeptic stem; inferred because the thin rows are this pack's reading of the snapshot |
| C4 | "Why this role, and why now?" | JD | [generic] | Answer slot: give your actual reasons, in your own words. Tie them to something Saltmarsh has published (the values page, the talk, the Larkspur announcement) only if it is true for you. If you cannot name a reason tied to this role, say so to yourself before Friday, not in the room | Motivation consistency is what a Skeptic scores; generic because no claim about your past is needed |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7: monthly, retention numbers, the studio head, at that scope. Answer slot: the JD asks for comfort with player-retention metrics, so expect a probe on which measures were in them and how they were counted. Say which measures, how they were counted and which assumption you would defend least, in your own words; if you do not know how a measure was counted, or someone else produced the numbers and you presented them, say so plainly | F7 is the evidence for the retention requirement and the likeliest place to be probed; EXP because it tests what was actually yours |
| D2 | "When you write the player-facing note for an update, how would you confirm that what you announce is what shipped?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Describe the check as a method: confirm with QA what passed, write only what is verified, list known issues, correct afterwards if needed. Your quote carries the checklist you wrote and that QA uses. Answer slot: if a step on that checklist compared announced against shipped, say which, in your own words; if there was no such step, say so plainly and describe how you would add one, as a plan | The interviewer's published argument is that patch notes should describe what shipped; F4 is the nearest row; JD because it scores the release-checklist and written-communication lines (F8) |
| D3 | "How would you run the post-event review, and which KPIs would it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure it: what we said would happen, what happened, what shipped, the KPIs and their definitions, decisions and owners, what changes next time. Your sentence carries presenting the monthly numbers, and the limit is the pack's observation: your material says presenting, not owning a review. Answer slot: if you wrote up or ran any review after a drop, say what, in your own words; if not, say so plainly and describe how you would run one, as a plan | F3 is the evidence for the review requirement and the thinnest of the JD's owned lines |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has led a team and shipped a season pass?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate. Hold only what your quotes carry: the weekly calendar you ran for your main title for two years, and the release checklist you wrote that QA still uses. Concede the two limits plainly: "I haven't led a team" and "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the two quoted facts, never by adding to them | Skeptic C1 and C2 delivered under time pressure; F1 and F4 are what you hold, JD because it scores the fit for the listed job |
| E2 | "That retention presentation — how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with what the sentence carries: "I presented the monthly retention numbers to the studio head." Answer slot: say which part was yours, in your own words, whether you built the numbers, chose what went in, or presented what someone else produced; if the numbers were someone else's, say so plainly and stay with the presenting. Hold the presenting, concede specifically what you did not do | Attribution honesty, the stem from the Pressure persona; F7 is the row it tests |
| E3 | "You've got ninety seconds, an outage is live, and the community team is asking what to tell players. What do you say?" | CASE | [generic] | Restate the question, then give three things: what you know, what you do not know, and when the next update comes. Announce only what is built, not what is hoped. Name who confirms the status. Say "I don't know yet" when it is true, rather than filling the silence. The question needs no claim about your past, so the guidance makes none | The tabletop under time pressure; community is one of the four teams in the JD (F2's requirement), and generic because it is a pattern for the problem |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc whose beats are your own four sentences, in your own words and at their own scope: the four years, the weekly calendar for your main title, the checklist QA still uses, the monthly retention presentations. Answer slot: end with your actual reason for wanting this role, in your own words; if you cannot give one yet, say so to yourself before Friday | The standard opener; F1, F3, F4 and F5 are the rows it draws on |
| G2 | "What are you actually playing with in live ops these days?" | CO | [generic] | Answer slot: name a live game you actually follow and say what you notice about how it runs its events, in your own words; if you are not following one, say so plainly and name what you would study first, Saltmarsh's own two titles, Tidepool Tactics and Lantern Row | A casual question about a hot JD topic that is still scored; generic because it needs no claim about your past |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A3, G1 |
| Coordinate design, art, engineering and community on each update | C1, A1, E3 |
| Own the post-event review and the KPIs | D3, A4, E2 |
| Manage the release checklist with QA | A5, D2, B3 |
| 3+ years producing live-service games or apps | G1, C3 |
| Experience running a content calendar | A3, B1 |
| Comfortable with player-retention metrics | D1, A4, E2 |
| Clear written communication | D2, B2 |
| Published value: Players Before Plans | B1, A1 |
| Published value: Ship the Patch Not the Promise | B2, A2 |
| Published value: Leave the Build Greener | B3 |

## Values / principles cheat sheet

Values are from Saltmarsh's own values page (fetched); the careers page documents a values conversation.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold: pick a time a scheduled drop and players' interests pulled apart, with a named stake, what you decided and who you told. If none comes to mind, say so plainly, then give the nearest thing: F1, "I ran the weekly content-drop calendar for our main title for the last two years", at its own scope, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold: pick a time something announced and something built differed, and how you said so. If none comes to mind, say so plainly, then give the nearest thing: F4, "Wrote the release checklist our QA team still uses", at its own scope, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses". The quote carries the checklist and that QA uses it; whether it improved release by release is not in your material, so say what you changed after a release if anything, or say it stayed as written |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued that a live team is judged by how often its patch notes describe what actually shipped. How does the team measure that today?" | Tied to his own published argument and his QA background; it shows you read what he put out and moves the conversation to how the team works |
| R2 | "Project Larkspur moves to one live-ops group and one shared events calendar from February 2027. Where does this role sit in that group, and does it still cover two titles?" | Shows you read the current strategy, and the answer tells you what the JD's two-title scope becomes |
| R3 | "Which KPIs does the post-event review report today, and who has owned them so far?" | The JD makes you the owner of the review and its KPIs; the answer tells you what you inherit |
| R4 | "Which checks on the release checklist have changed in the last year, and what prompted each change?" | Connects to Leave the Build Greener and to your own checklist without claiming anything about it |
| R5 | "When the calendar and the players disagreed, can you give me an example of a call the team made?" | Tests Players Before Plans against practice and signals that you take the value seriously |
| R6 | "What would you want a new producer to have changed in the first 90 days?" | A clear, forward-looking question that gets a direct answer on what success looks like |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed the design, art, engineering and community teams | Negative you stated: "Never led a team" | The plain acknowledgment: "I haven't led a team." Nothing added; what you did coordinate is an answer slot in C1 |
| Worked on monetised events or a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan to learn it, said as a plan |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: your material says one main title. A3's slot stays inside the calendar you ran |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head." The limit is the pack's observation: your material says presenting, not owning a review |
| Managed the release checklist with QA, including release-day sign-off | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." A5's slot asks only whether sign-off was yours |

## Sources

**Provided documents:** the job description and your background, both in your message. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, three principles by official name; bank B |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one 60-minute hiring-manager interview, tabletop then values conversation, no take-home. It establishes the loop, so no archetype fallback applies; it fixed the persona weights, banks A and E, and removed any graded-deliverable section |
| 3. `Saltmarsh Games strategy news mobile` | yes | A3, C2, G2 and R2, built from the Project Larkspur announcement (September 2026). Only the search summary was read; the fetch budget went to targets 1 and 2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read and R1. Only the listing summary was read, not the talk itself |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent:

- `Saltmarsh Games values` returned https://saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games strategy news mobile` returned https://saltmarshgames.com/news/project-larkspur
- `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full.

## Upgrade menu

- The recruiter's prep email or any note on the outage scenario → coverage of any announced focus, and a check on whether Tobias is the hiring manager the pack assumes
- The release checklist itself, or a content calendar you ran → F4 and F6 move from `medium` toward `high`, because an inspectable artifact is what raises the band
- A retention deck or a release note, a drop announcement or a review write-up you wrote → F3, F7 and F8 move up, and F8 names a real written sample
- Your answers to the answer slots (which of the four teams you coordinated with, whether the retention numbers and any review were yours, whether the main title was run as a live service, whether you ever planned around a second title) → F1, F2, F3 and F5 become `grounded` with your own words, and banks A, C and D regenerate
- The talk itself, as slides or video → the interviewer read from the full argument instead of a summary
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief on Project Larkspur, reports on this company's loop, and recent organisational context
- The hours you have before Friday → a prep triage sized to them
- A `tuesday-dossier.md` from an earlier session → verified evidence, a named objection to rehearse deepest, and absolute prohibited claims, in place of the ones this pack inferred
