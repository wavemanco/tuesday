Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-1-denied-8dde37a6/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 21 questions across seven personas, each with a type tag, provenance, answer guidance and rationale. It also has a fit snapshot, requirement coverage, an interviewer read, reverse questions, a prohibited-claims list and sources.

I built it for a single peer conversation with Dan and assumed no recruiter-declared deliverable. Persona depth is Data-Driven Prober 5, Peer Evaluator 4, Case 3, Skeptic 3, Conversational 2, Pressure 2, Values 2. The Prober is on top because Dan describes himself as "relentlessly data-driven".

The highest-ROI prep is **D1**, the "no classic sales-ops or quota-setting" objection. It's built on the plain acknowledgment from your notes plus the volume-targets work at its own scope, and it deliberately doesn't call those targets quotas. A1 and G1, the ~$400M ARR figure, are next.

My web searches were refused, so Northwind's values, its interview loop and Dan's public footprint were not researched. The pack leans on your research note and profile summary, and I haven't checked either against a source. Because no published values were read, the two Values questions are generic scaffolds with no mapped stories, and there is no values cheat sheet.

Say the word and I'll play the Skeptic on D1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter name any focus areas, or announce a deliverable such as a POV or presentation, for Dan's conversation? A deliverable would add a build section and reweight the banks.
Can you paste the full JD text and Priya's CV lines? Her own sentences would replace the paraphrases in the evidence column. If you'd rather not, the pack stands as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP)
**Format:** one 60-minute conversation
**Built on this assumption:** a peer conversation in a single session, with no recruiter-declared deliverable and no stated prep-time limit. If any of that is wrong, the persona weights and the banks change.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words and only as far as your own material goes.

Lines marked "Answer slot" are instructions for the interview. They are not questions for anyone now. Answer from your own experience, or say plainly that the practice was not yours, then return to what your own words do carry.

Bank letters skip F so they do not clash with the fit-snapshot rows F1 to F7.

| Type tag | Name | What it is really scoring |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether the CV's claims survive scrutiny and attribution is honest |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role, live |

## Fit snapshot

Requirements come from the JD highlights you supplied. Evidence is quoted from your notes on Priya and nothing else. No row is a gate: the material names no location, pay, schedule or credential term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market, and the words stay there: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's line on owning GTM for two new product lines makes a probe on go-to-market work likely. If any of that work was go-to-market, say which part and what was yours, in your own words; if there was none, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote is a proposal that was credited with an uplift, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's land, adopt, expand and renew line makes a probe on lifecycle stage likely. If the change worked on any of those stages, say which, in your own words; if it did not, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | A skill statement is not an analysis, and the material shows none, so nothing is asserted from it yet. Answer slot: if an analysis was yours end to end in SQL or Tableau, name it and what it changed, in your own words; if the queries or dashboards were built by others, or no such analysis comes to mind, say so plainly and say what you would build first |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a model, not a motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: a probe on partner-motion design is near-certain because the JD marks it required. If any part of how partners are approached, paid or enabled was yours to design, say which and how you decided, in your own words; if there was no such design, or it was not yours, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, so the bridge only rewords it: "I set annual volume targets with cross-org consensus." Lead with the targets and the consensus in the quote's own terms. It is a CV-style line with nothing inspected behind it, so expect a probe on it |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, so the bridge only rewords it: "I use AI tools daily." It says use, not building or launching, and the words stay there |
| F7 | Working fluency with sales-strategy mechanics such as quota-setting and sales operations — plain prose, role-family, not a JD line | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap that wording cannot close, and the material states it. Words: "I have no classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| own GTM strategy for two new product lines | C1, C2, C3, A4 |
| identify whitespace across land/adopt/expand/renew | C1, A4 |
| run independent analysis in SQL and Tableau | A3, A2 |
| partner-motion design experience required | D2, C3 |
| strong cross-functional influence | B1, B2, B3, B4 |
| AI experience a plus | E2 |
| Sales-strategy mechanics (F7, role-family, not a JD line) | D1, D3, G2 |

No requirement is left without a question.

## Reading the interviewer

Everything here is what you supplied about Dan. A search for his public footprint was refused, so nothing is added from the web.

| Signal (as you gave it) | Practical implication | Provenance |
|---|---|---|
| Profile self-describes as "relentlessly data-driven" | Expect every figure to be taken to its inputs and assumptions. Know how each number was counted, or say plainly that you do not | [grounded] |
| Career spine is pricing and monetization roles | Case questions will lean toward pricing, packaging and unit economics. Bring a pricing or packaging angle to every case, as a hypothesis and not as a claim about Northwind | [grounded] |
| One early-stage-startup chapter | Expect some interest in pace and scrappiness. No quoted sentence of Priya's carries a startup side, so this is not offered as a shared path | [grounded] |
| Peer, same VP | He is pricing what your hire costs and contributes to his own work. Reciprocity beats a list of needs | [grounded] |

Mirror opportunities:

| Dan's path | Fit row and exact quote | How to use it |
|---|---|---|
| Pricing and monetization | F2: "proposed a store-surface change credited with a ~$400M ARR uplift" | Use revenue and ARR language only where the quote already does. Ask for his read on how pricing is decided for new lines (reverse question 1) |
| Data-driven | F4: "built a partner-level revenue model used in carrier negotiations" | Offer to walk through the model in the terms of the quote. Claim no more about it than the quote does |

## Persona weights

The loop is one 60-minute conversation with a peer, established by your message, so no archetype fallback is used. Weights start from the peer prior (Peer Evaluator and Data-Driven Prober), then adjust for what you gave about Dan.

| Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) | Bank and depth |
|---|---|---|---|---|
| Data-Driven Prober | Reads each claim to its inputs, denominators and assumptions | High. Peer prior, adjusted up because his profile says "relentlessly data-driven" | Know what you can and cannot say about how each number was counted. Name the weakest assumption before he does. Offer to walk through an analysis end to end if you have one | A, 5 questions |
| Peer Evaluator | Seam-splitting between GTM strategy and Sales Strategy, "what would you need from me", credit and disagreement | High. Peer prior, and you report to the same VP | Reciprocity framing. Propose seam principles instead of pretending to know the seam. Disagreement stories that show spine and tact together | B, 4 questions |
| Case / Strategist | Live problems on pricing, packaging, expansion and the partner motion | Medium. A peer is less likely than a manager to run cases, but his pricing spine tilts toward them | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully | C, 3 questions |
| Skeptic | The gaps return in collegial packaging: sales-ops and quota mechanics, partner-motion design | Medium. The peer persona carries the objections of the other banks; F7 and F4 are where the material is thinnest | Rehearse the single most predictable objection until it is boring. Bridge only from adjacent evidence you actually stated, with a ramp plan | D, 3 questions |
| Conversational / Rapport | The opener ("walk me through the journey") and a casual question on AI | Low. It is short in a 60-minute peer talk, but it opens the session and the AI plus is easy to miss | A pre-scripted 90-second arc. Treat casual questions on hot JD topics as scored | E, 2 questions |
| Pressure / Stress | Time-boxed or devil's-advocate versions of the attribution and "why you" questions | Low. The peer prior does not carry it; two questions so no style is met for the first time live | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real | G, 2 questions |
| Values / Behavioral | Scenario probes on unpopular truths and customer-over-metric choices | Low. No loop source names a values round and no published values were read | Where a quoted sentence carries a story, map it; where none does, use the scaffold and its honest branch | H, 2 questions |

## Question banks

Highest-ROI prep in the pack: **D1**, the sales-ops and quota-setting objection. It will be asked in some form. After it, **A1**, the ARR figure.

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the sentence says and no more: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Keep "proposed" and "credited with"; do not upgrade them. Four answer slots, each in your own words: how the figure was counted, if you know; what it is sensitive to; the assumption behind it you would defend least, named before he asks; and which part was yours. If you do not know how it was counted, say so plainly and say what you do know | F2 holds the only figure in the material, and a data-driven peer probes figures first. EXP because it tests counting and attribution; this is the defend-the-number rehearsal |
| A2 | "Walk me through the revenue model you built. What was in it?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: a revenue model, at partner level, used in carrier negotiations. Those are the beats the quote states; tell them in your own words. Answer slot: the JD raises independent analysis in SQL and Tableau, so a probe on whether you built the analysis yourself is likely. If you wrote queries or built views for it, say which part; if the data work was someone else's, or done in another tool, say so plainly and stay with the model you built | F4 is the only analytic artifact in the material and F3 raises the independence probe. EXP because it tests what was actually yours |
| A3 | "Tell me about an analysis you ran in SQL or Tableau where the result changed what a team did." | JD | [inferred] "skilled in SQL/Tableau" | Selection scaffold, because F3 is low confidence and the pack asserts nothing from it. Pick an analysis where you wrote the query or built the view yourself. Name the question, the data, what you found and the decision it informed, and offer to walk through it end to end. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries or say how you would approach one | The JD names SQL and Tableau as independent work, and a data-driven peer will test it directly. JD because it scores the stated requirement; the provenance is `[inferred]` because F3 is a lead and not a story |
| A4 | "Pick one new product. Of land, adopt, expand and renew, which stage would you instrument first, and which metric would you trust least?" | CASE | [generic] | Clarify first: what the product is, who buys it and how value shows up. Define each stage by an event, not a label. Pick one stage and say why. Name the metric you would trust least and the assumption under it before he does, and say how you would test it. The question needs no claim about your past, so the guidance makes none | The JD's land, adopt, expand and renew line (F2's requirement) in the form a data-driven peer would ask it. CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about Northwind |
| A5 | "You set annual volume targets with cross-org consensus. Walk me through it." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: annual volume targets, cross-org consensus. Say "volume targets", not "quotas". Answer slot: a probe on what the targets were built from is the likeliest first follow-up from a data-driven peer. If you built or chose the basis, say what, in your own words; if the basis came from elsewhere, or there was no formal basis, say so plainly and stay with the targets you set | F5 is the nearest thing in the material to the sales-strategy territory F7 leaves open, and he will go there. EXP because it tests how the claim was actually produced |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between GTM strategy and Sales Strategy, and what happens when we disagree?" | JD | [generic] | Propose principles and say you do not yet know where the seam sits; ask where he draws it. Principles to offer: one owner per decision and per metric; disagreements start from data both sides trust; anything unresolved goes to the shared VP with both views written down, not through a back channel; no surprises in either direction. Then ask what he needs from you. Claim no past conflict, because the guidance has no quote for one | The peer row's core question, and F5's requirement in the form a peer asks it. JD because it scores strong cross-functional influence |
| B2 | "What would you need from me, and what would I get from you?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Needs: his view of where Sales Strategy's boundary sits, access to the data he trusts, and context on how pricing is decided for new lines. What he gets, at the quotes' own scope: "I built a partner-level revenue model that was used in carrier negotiations" and "I set annual volume targets with cross-org consensus." Answer slot: if either would transfer to his team's work, say what and why, in your own words; if neither would, say so plainly and ask where he would point you | A reciprocity question from a peer who is pricing what the hire adds to his work. JD because it scores cross-functional fit (F5); the quotes are the only supply the pack can offer |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F2: you proposed the change and credit for the uplift was attached to it. Those are the beats; use "we" for context and "I" for your contribution. Answer slot: a probe on who else contributed and how credit was shared is likely. Say who and what, in your own words; if you did it alone, or credit was not shared, say so plainly and stay with the change you proposed | The word "credited" in F2 invites exactly this probe from a peer. EXP because it tests attribution honesty |
| B4 | "Tell me about a time you disagreed with a peer." | JD | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a time with a named stake, your position and theirs, what moved it and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I set annual volume targets with cross-org consensus", at its scope, or say how you would handle a disagreement | Disagreement with equals is the peer persona's stem, and F5 is the requirement it scores. The quote is the nearest material but does not state a disagreement, so the scaffold holds |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You'd own GTM for two new lines. What do you need to know first, and where would you put effort across land, adopt, expand and renew?" | JD | [grounded] JD highlights: "own GTM strategy for two new product lines"; "identify whitespace across land/adopt/expand/renew" | Say the structure aloud: clarify, objective, segmentation, approach, metrics, risks. Clarify which two lines, how far along each is, whether there is an installed base, and what the profitability priority in your research note implies for how much each stage may cost. Add a pricing and packaging angle, since that is his native ground. Challenge one premise respectfully, such as whether all four stages deserve equal effort for a line with no installed base. State your hypothesis early. No claim about your past | The JD's core mandate (F1, F2) as a live problem. JD content with CASE delivery; tagged JD so the headline requirement has a JD-tagged question |
| C2 | "Our main competitive pressure is bundling by a much larger platform vendor. How does that change your GTM for a new line?" | CO | [grounded] your research note: bundling by a much larger platform vendor is the main competitive threat | Clarify which line, who buys and what the bundle includes; ask, do not assert. Form a hypothesis about where you would compete with the bundle and where you would go around it. Cover the pricing and packaging angle (standalone, attach or partner), the one metric that would tell you it is working, and the main risk. State no fact about Northwind's products or the vendor's | Bundling is the competitive threat in your research note, and his pricing spine makes the packaging angle likely. CO because it scores strategy fluency; CASE delivery |
| C3 | "Design the partner motion for one of these lines. Who are the partners, and what do you test first?" | CASE | [generic] | Clarify which line and what partners are for (reach, delivery or resale; say you are asking). Segment partner types, say what each must gain to take part, then pick one first test with its metric and a stopping condition. Name the main risk. The question asks about no past, so the guidance links this to none | The JD marks partner-motion design required (F4). CASE because it tests the design live; D2 covers the experience question separately |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How do you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **The deepest rehearsal in the pack.** Structure: (1) the plain acknowledgment: "I have no classic sales-ops or quota-setting experience." (2) the adjacent work at its own scope: "I set annual volume targets with cross-org consensus." Do not call them quotas. (3) a plan, said as a plan: what you would learn first and whom you would ask, starting with where his team draws its line. Follow-up ladder: if asked whether it is the same thing, hold the quote's scope and say you would not claim it is; if asked what you would get wrong first, answer slot: name, in your own words, what you expect to be slowest at, with no invented example; if asked "then why you", return to the two things you bring (G2). Exact concession: "That's a real gap, and I'd rather name it than talk around it." The limit, named before he asks: your material shows volume targets, not quotas | F7 is the biggest gap against a Sales Strategy peer and the most predictable objection. JD because it scores the role's sales-strategy fluency; Skeptic because it arrives as a quiet "help me understand" |
| D2 | "The role requires partner-motion design experience. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Start from the quote: "I built a partner-level revenue model that was used in carrier negotiations." Do not call the model a motion. Answer slot: if any part of how partners are approached, paid or enabled was yours to design, say which and how you decided, in your own words; if there was no such design, or it was not yours, say so plainly and stay with the model you built | F4 is a transferability gap against a requirement the JD marks required. JD because it scores that requirement directly; the second branch allows that no such design ever existed |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Calibrated candor over bluffing. The stated gap is sales-ops and quota mechanics: "I have no classic sales-ops or quota-setting experience." Follow it with a ramp plan: what you would learn first and from whom. Answer slot: if a different part of the JD is truly your weakest, say that instead, in your own words, with its ramp | The persona stem for the Skeptic, and a question that tests honest self-assessment. F7 is the only gap the material states, so the pack does not guess another |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: consulting, then consumer tech, and now here." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quote states: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: your actual reason for this move and for choosing this company, in your own words; the material gives none, so the pack supplies none. Claim no B2B or data-infrastructure background | The opener is likely and is scored despite its casual register. EXP because it tests whether the story hangs together (F1) |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start from the quote: "I use AI tools daily." Answer slot: which tools and for what, in your own words; if it is day-to-day use and not building or launching, say so plainly. Claim no AI product experience. A short, honest, specific answer beats a long one | The JD lists AI as a plus (F6), and the persona stem asks it casually. JD because it scores the plus; the answer is scored even though it feels like small talk |

### G. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That ARR figure. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold the quote: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Hold through two follow-ups. Answer slot: name which parts were not yours, in your own words; if all of it was, say so plainly. Concede specifically and never fold on the quote itself | The persona stem for attribution, aimed at F2's figure. EXP because it tests whether the claim survives cross-examination; it is the same fact as A1 in a harder delivery |
| G2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Three beats in under a minute: the model at its scope, the targets at their scope, and the plain acknowledgment "I have no classic sales-ops or quota-setting experience" followed by what you would do first. Do not claim to be better than anyone. If pushed on what an internal candidate knows, concede that advantage and return to the two things you bring | The persona stem for composure, and a compressed D1. JD because it scores fit for the role (F4, F5, F7) |

### H. Values / Behavioral (no published values were read)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would handle it | The Values persona stem. No quoted sentence carries this story, so it is a scaffold; low weight because no values round is detected |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's interest and an internal number pulled apart, say what you chose and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries or say how you would decide | The Values persona stem, kept so no style is met for the first time live. No quote carries it, so the guidance is a scaffold |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You've worked in pricing and monetization and had an early-stage chapter. How does pricing get decided for a brand-new line here, and where does GTM strategy sit in that decision?" | Ties to his own path and signals you researched him, not just the company. It moves the conversation from interrogation to peer exchange |
| 2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It shows you are pricing what you add to his work |
| 3 | "Where do you expect our work to overlap, and what is the cleanest way to settle it when we disagree?" | Turns B1's seam question around, and shows you want the seam principle before the first dispute |
| 4 | "What is the data you most wish you had for the two new lines?" | Speaks to a data-driven peer in his own terms and gives you something concrete to ask about later |
| 5 | "How is the bundling threat showing up in deals today, and what is your team doing about it?" | Uses the competitive frame from your research note and invites his view of it. Ask rather than assert |
| 6 | "How are you thinking about where Compass sits in the enterprise expansion story?" | Shows you read two of the three priorities in your research note, and asks for his view of how they connect |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having quota-setting or sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I have no classic sales-ops or quota-setting experience." No slot |
| Treating annual volume targets as quotas | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation, not words for the candidate: the material says volume targets, not quotas |
| Driving, generating or owning the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says proposed and credited with, not delivered or owned |
| Designing a partner motion, or running the carrier negotiations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a model that was used in negotiations, not a motion or the negotiating |
| Having owned GTM or launched products to market | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not go-to-market |
| Having run independent analyses end to end in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says skilled in, not an analysis she ran; A3 stays a scaffold |
| Having built or launched AI products | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says daily use of AI tools, not building |

## Sources

**Provided documents:** your message (role and company, JD highlights, Priya's summary, Dan's profile summary, and your research note on Northwind's three stated priorities and its main competitive threat). The JD is highlights only, and your research note is used as given and was not checked against any source. No `tuesday-dossier.md` was present.

**Searches sent (all refused, none returned a result):**

- "Northwind Data company values" — refused
- "Northwind Data interview process strategy GTM" — refused
- "Dan Kovac Director Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The one search sent was refused. Would have moved the VAL bank (H) and a values cheat sheet; none is built |
| 2. `Northwind Data interview process` | unavailable | The one search sent was refused. Would have moved persona weights; the weights rest on your message instead |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note supplies the priorities and competitive frame that feed the CO and CASE bank (C), so a search could not have moved it |
| 4. `Dan Kovac Northwind Data` | unavailable | The one search sent was refused. Would have moved the interviewer read and a path-specific reverse question; both rest on your profile summary instead |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the requirement rows of the fit snapshot |

## Upgrade menu

- Full JD text → the requirement rows now quote your highlights; the full text would add the mid-list requirements and any gate terms, and could turn rows into direct quotes of the posting
- Priya's CV lines in her own words → the evidence column now quotes your notes on her; her sentences would replace them and could turn F1, F2 and F4 from transferability into grounded story maps
- Her own words on the answer slots (rows A1, A2, A3, A5, B3, D2, E1, E2, G1) → each slot would become a story map; she can send them as input at any time
- The recruiter's stated focus areas, or any announced deliverable → coverage for graded deliverables, and a reweighting of the banks
- Web search access → Northwind's published values, its documented interview loop and Dan's public footprint, which would enable a values cheat sheet (if a values round is documented), a loop-based reweighting and a sharper reverse question. A deeper research pass would add up to 6 more searches and 2 more fetches and take several more minutes
- Prep time available → a prioritized prep schedule sized to it
- A `tuesday-dossier.md` → verified evidence and a standing list of prohibited claims, which would tighten the guidance cells; the pack is complete without one
