Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/tuesday/part-2/rooms/case-7-canned-453a20d1/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it assuming Tobias is your hiring manager, because Saltmarsh's interviewing page says its one 60-minute session is run by the hiring manager.

- **The hour:** Saltmarsh calls it the Outage Hour. It is a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home, so the Case bank is the biggest part of the pack.
- **Highest-ROI prep:** B1, the "you've never led a team, and this role coordinates four disciplines" question. The pack infers this objection, because it comes from your own stated gap and the JD's coordination line.
- **Strategy hook:** Saltmarsh announced in September 2026 that two titles move to a season-pass model with one shared events calendar from February 2027. That is why B2 (in-app purchases) and A5 are in the pack.
- **Tobias:** His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by whether its notes match what shipped. Keep every claim at the scope of what you told me. I only saw the talk's summary, so read the page before Friday.

Say the word and I'll run a drill. The default is the Skeptic on B1, or the Outage Hour tabletop on A1 if you'd rather.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the person you'd report to, and does anyone else join the hour? A different answer reweights every bank.
2. Did the recruiter say anything about how the hour will run? Any announced focus would retune the Case bank.
3. Do you want a deeper research pass on Saltmarsh's strategy? It's up to 6 more searches and 2 more fetches and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. Saltmarsh's interviewing page says its one 60-minute session is run by the hiring manager; your note did not say whether Tobias is the person you would report to
- **Format (from Saltmarsh's interviewing page):** a recruiter call, then the Outage Hour: one 60-minute interview, a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home
- **Candidate:** Femi

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: where a row says "answer slot", the instruction is for the interview, and the honest answer is whichever branch is true for you.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's published values |
| EXP | Whether what you said about your work survives scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Saltmarsh's current direction |
| CASE | Structure and reasoning on a live problem, delivered aloud |

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, with nothing inspected behind it, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-titles wording makes a probe on what differs likely. If any drops were timed events, say how you scheduled them; if the calendar held content drops only, or you ran no second title's calendar, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | Your material does not show which teams fed the calendar you ran; the quote says you have not led a team, which is a different thing from coordinating. Answer slot: if you worked with any of design, art, engineering or community on a drop, say which and what each needed from you; if you worked with none of them, or it was not yours to coordinate, say so plainly and return to the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your sentence says you presented the numbers, monthly, to the studio head; it does not say a review followed any event or that the numbers were yours to define. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you also wrote up what happened after a drop, say what, in your own words; if there was no such review, or someone else produced the numbers, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your sentence says you wrote the checklist and that QA still uses it, with nothing inspected behind it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's word is manage, so expect a probe on running releases through it. If you ran releases through it with QA, say how, in your own words; if you wrote it and did not run it, or it was not yours to run, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your sentence gives the years and the title, associate producer, and does not say whether the puzzle title is live-service. Words: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: if the main title was live-service, say so in your own terms; if it was not, or you would not call it that, say so plainly and describe how it was run |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a CV-style line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in terms, but a presented number is the likeliest thing to be probed to its inputs. Lead with it as quoted: monthly, to the studio head. D1 rehearses the probe |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist in use is one written artifact; the derivation from it to this requirement is the pack's, and it does not show the other writing the job asks for, such as reviews. Answer slot: if other writing of yours was read by other teams or leadership, say which, in your own words; if none was, say so plainly and stay with the checklist |
| F9 | Not a JD line: Saltmarsh's September 2026 announcement moves two titles to a season-pass model (Saltmarsh news, via search result) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The JD does not ask for it, so this is a likely question, not a stated requirement. Words: "I haven't worked on a game with in-app purchases." Then what you would want to learn first, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## 3. Reading the interviewer

Public professional footprint only. One source was found, a GDC 2026 talk page, and only its summary was read.

| What is published | Provenance | What it means for Friday |
|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] | He knows release checklists and QA hand-offs from the inside. Details of F4 will be heard by someone who can test them, so keep every claim at the quote's scope |
| His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped | [grounded] | Expect claims to be checked against what was actually done, which is why every guidance cell here stays at your own words. The same idea sits in Saltmarsh's published value "Ship the Patch Not the Promise". Read the talk page before Friday; only its summary was available to me |
| Shared vocabulary, not shared identity: QA and the release checklist | [grounded] | Pairs his path with F4: "Wrote the release checklist our QA team still uses". Offer it as a fact about your work, not as common ground to lean on |

## 4. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | The Outage Hour tabletop, and live planning problems | Highest. Hiring-manager prior, and Saltmarsh's interviewing page documents a live-incident tabletop | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of what the material does not show | High. Hiring-manager prior, plus the two negatives you stated (F2, F9) | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| Values/Behavioral (C) | The values conversation after the tabletop | High. A loop source documents a values conversation, so it is guaranteed in this hour | Map a story to each published value where your sentences carry one; a selection scaffold where they do not; we for context, I for contribution |
| Data-Driven Prober (D) | Walk-throughs of a number, and checks against what shipped | Medium. Tobias's published argument is about notes matching what shipped; F7 is a presented number | Know what you can and cannot say about how a number was counted; say plainly when you do not know |
| Pressure (E) | Time-boxed answers during the tabletop | Low to medium. A simulated outage may carry time pressure; no source says Tobias interviews that way (inferred) | Pause, restate, hold the position through two follow-ups, concede only what is true |
| Conversational (F) | The opener and casual questions | Low. Usually the first minutes; still scored | A short arc built only from your quoted sentences |
| Peer Evaluator (G) | Collegial seam-splitting on coordination | Low. Tobias is not a peer, but the JD's coordination line can arrive in that register | Propose seam principles, not a pretended seam; reciprocity framing |

## 5. Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Ten minutes into a live event, the event stops loading for players. What do you ask first, and what do you do in the first fifteen minutes?" | CASE | [generic] | Clarify before acting: what is broken, for whom, since when, whether it is the event or the whole game. Name the objective, then who you pull in (the JD names design, art, engineering and community), what players are told and when, and what gets recorded for the review. Think aloud and challenge one premise politely. The question needs no claim about your past, so the guidance makes none | The opening move of the documented tabletop; a pattern for the problem, not a fact about Saltmarsh. CASE because it asks about no past |
| A2 | "Engineering says a fix is probably two hours out. Community wants to announce it now. What do you do?" | CASE | [generic] | Separate what is known from what is hoped: ask engineering how sure they are and when they will next know, give community wording that states only what is known, and set the time of the next update. Saltmarsh's published value is "we announce what is built, not what is hoped"; echo its sense without quoting it at them. No claim about your past | Tests the tension between speed and accuracy that the published value and Tobias's talk both turn on. CASE; the pressure comes from the two teams disagreeing |
| A3 | "The outage left half the players with the event's rewards and half without. What happens to the calendar?" | CASE | [generic] | Clarify the size and shape of the split first, then options and who decides, then what players hear and when, then what the next events must now account for. Published value: "when the calendar and the players disagree, the players win". No claim about your past | Applies the calendar skill in F1 to a live problem, so the rehearsal is a decision, not a record. CASE because it presupposes nothing about you |
| A4 | "The outage is over and you own the review. What does it say, and what does its first paragraph tell someone who wasn't there?" | JD | [generic] | Structure: what happened, who was affected, what the numbers show, what changes and who owns each change. The first paragraph should stand alone in plain sentences. No claim about your past; if you reach for a parallel, F3's quote is the only one: "I presented the monthly retention numbers to the studio head" | Covers the JD's post-event review and clear written communication lines (F3, F8) through a live task. JD primary, CASE delivery |
| A5 | "Saltmarsh has announced one shared events calendar for two titles from February 2027. What do you need to know first, and what would you build into the first month?" | CO | [grounded] | Clarify first: which titles, what the season-pass cadence is, who owns the calendar once per-title event teams retire in favour of one live-ops group (the announcement says they do), and what each discipline needs by when. Challenge one premise: whether every title's events need the same beats. If you bring your own calendar, bring it at its scope, one main title: "For the last two years I ran the weekly content-drop calendar for our main title." Never claim to have run a shared calendar | The strategy question most candidates cannot touch; it rests on Saltmarsh's September 2026 announcement. F1 is the evidence you would reach for, and its scope is one title |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've said you've never led a team, and this role coordinates design, art, engineering and community on each update. Where does that leave you?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment, in your words: "I haven't led a team." Name the limit before it is asked for, then return to what you did: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's coordination line makes a probe on which of the four teams you worked with likely. If you worked with any, say which and what each needed from you; if you worked with none of them, or it was not yours to coordinate, say so plainly and return to the calendar. Follow-up one, a tie between two teams: answer as a plan, in your own words. Follow-up two, your first month: also a plan. Hold the calendar, concede the leading, and never fold into claiming more than the two quotes | The JD's coordination line meets your stated negative at F2, so this objection will arrive in some form; no dossier named it, so the pack infers it. JD because it scores a stated requirement |
| B2 | "Saltmarsh is moving two titles to a season-pass model, and you've said you've never worked on a game with in-app purchases. What would you want to understand first about running events in a season-pass game?" | CO | [grounded] "never worked on a game with in-app purchases" | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say, as a plan and never as a past, the questions you would ask first, in your own words: what the pass changes about each week's calendar, and which numbers the team watches. Do not describe knowledge of the model you do not have | F9 is the one gap you stated outright, and the announcement makes it likelier to be probed. CO because the premise is Saltmarsh's published move |
| B3 | "You've run the calendar for one title. This role runs it for two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F1 at its scope: the weekly calendar, one main title, the last two years. Answer slot: the JD's two-title wording makes a probe on what changes likely. If you ever scheduled around another title's or team's releases, say how; if you ran only the one title's calendar, say so plainly and say what you would ask first about the second | Targets the scope step in F1. JD because it scores the stated two-title requirement |
| B4 | "You've presented the monthly retention numbers to the studio head. This role also owns the post-event review and the KPIs it reports. What part of that have you done?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you also wrote up what happened after a drop, say what, in your own words; if there was no such review, or the numbers were produced by someone else, say so plainly and stay with the monthly presentation. Hold the quote; do not describe owning a review | The step between presenting and owning in F3. JD because the requirement is the JD's |

### C. Values/Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold for the value "Players Before Plans": pick a time a planned drop met a reason to change it for players. It needs a named stake, what you changed, and what it cost the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the weekly calendar you ran, at its scope, or how you would decide | Maps to the first published value; no quoted sentence of yours carries a disagreement, so this is a scaffold, not a story. VAL because it scores behaviour against a published value |
| C2 | "Tell me about a time you had to decide what to say about something that wasn't finished yet." | VAL | [grounded] | Selection scaffold for "Ship the Patch Not the Promise": pick a time you described unfinished work to others. It needs what you said, what you left out, and what happened to the promise. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would decide. Your material carries no sentence about announcing work, so no story is supplied | Maps to the second published value and to Tobias's public argument. No sentence of yours carries it, hence the scaffold |
| C3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4 for "Leave the Build Greener": you wrote the checklist, and QA still uses it, which are the beats the quote states. Answer slot: the value says each release leaves the checklist better, so expect a probe on whether it changed after releases. If you changed it after a release, say what changed and why; if it stayed as first written, or someone else changed it, say so plainly and stay with the checklist you wrote and QA still uses | Your strongest value story is F4. VAL because the question scores the published value |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented to the studio head were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say in your own words: how the numbers were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch; say it plainly. Never name a method you did not use. Words stay at: "I presented the monthly retention numbers to the studio head." | F7 is your headline metric and the likeliest probe. EXP because it tests attribution and the defend-the-number slots |
| D2 | "After a new event ships, which retention number do you look at first, and what does a change in it make you ask?" | JD | [generic] | Name the number as your studio called it, then say what a rise or fall would make you ask next. Use only terms you actually used; if you did not use a term, say so. The question makes no claim about your past, so the guidance makes none | Covers the JD's retention-metrics line (F7) as a way of thinking, not a record. JD because it is the stated requirement |
| D3 | "A patch note says an event fix shipped. How do you check it did what the note says?" | CASE | [grounded] | Ask for evidence before the note goes out: what was built, what the checklist shows, what the numbers show afterwards, and who confirms. Say how a mismatch gets recorded in the review. No claim about your past | Tobias's published argument is about notes describing what shipped; it also ties to the checklist in F4. CASE because it is a live problem |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over a producer who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "never worked on a game with in-app purchases" | Pause, restate, answer once, hold through two follow-ups. Hold only what you said: "For the last two years I ran the weekly content-drop calendar for our main title," and "I wrote the release checklist our QA team still uses." Concede only what is true and stated: if pressed, "I haven't worked on a game with in-app purchases." Do not argue about the other producer | The two-title comparison presses on F1 and F9 together. JD because it scores the stated requirements |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Words: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else wrote or changed parts of it, say who and what; if all of it was yours, say so, and say what QA added, if anything. Hold by returning to the quote, never by adding to it | Attribution probe on F4, the claim Tobias is best placed to test. EXP because it tests what was yours |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc whose beats are the four quoted sentences, each at its own scope: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Why live operations, and why Saltmarsh, is your own motivation, in your own words | The opener is scored. EXP because it checks the story hangs together; F5 is the row it rests on |
| F2 | "What live-service game are you following closely right now, and what do they do with their calendar that you'd copy?" | JD | [generic] | Name a game you actually follow, in your own words; if there is none, say so plainly and name the nearest thing you do follow. Do not invent a game or a calendar detail | A casual question about the JD's live-service wording (F5), still scored. JD because the requirement is the JD's |

### G. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When one of the teams you coordinate says the date can't hold, what happens next?" | JD | [generic] | Principles, not a pretended seam: get the reason and the new earliest date, find what the other teams lose, and take the choice to whoever owns it. Answer slot: if a team ever told you a drop's date could not hold, say what you did, in your own words; if that never happened or was not yours, say so plainly and answer as a plan | Collegial packaging of the coordination probe in F2. JD because it scores the coordination line |
| G2 | "How do you handle credit when an update spans several teams?" | JD | [generic] | We for context, I for contribution. Describe the principle you hold, in your own words, not an event you did not have. The question makes no claim about your past, so the guidance makes none | Credit-sharing probe from the same coordination line (F2). JD because it scores coordination |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A5, B3, E1 |
| Coordinate design, art, engineering and community teams on each update | A1, B1, G1, G2 |
| Own the post-event review and the KPIs it reports | A4, B4, D3 |
| Manage the release checklist with QA | C3, E2, D3 |
| 3+ years producing live-service games or apps | F1, F2, E1 |
| Experience running a content calendar | A5, B3, C1, F1 |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | A4 |

## 6. Values cheat sheet

Values are quoted by name from Saltmarsh's own page.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold (C1) ending in its honest branch; nearest material is F1: "I ran the weekly content-drop calendar for our main title for the last two years" |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (C2) ending in its honest branch; no quoted sentence of yours carries an announcement |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses", with the answer slot in C3 on whether the checklist changed after releases |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. What does that look like in the weekly rhythm here, and who checks a note against the build?" | Tied to his own published argument, so it signals you read him as well as the company. Read the talk page first; I saw only its summary |
| R2 | "You came to live operations from QA. What did that background change about how you run a release?" | Tied to his own path; it invites him to talk about it, and it leads naturally to the checklist |
| R3 | "The September announcement describes one shared events calendar and a single live-ops group from February 2027. Where does this role sit in that, and for which titles?" | The JD says two titles; this finds out what the job becomes after the change, which you need to know before accepting |
| R4 | "Once a post-event review is written, who reads it, and what has one changed?" | Shows you care what the review is for; the JD makes it yours |
| R5 | "Which KPIs does a post-event review report here, and which would I own in the first quarter?" | Tells you whether the KPI set reaches past the retention numbers in F3, before you accept |
| R6 | "What would you want me to have shipped or learned by the end of the first month?" | Gives you the ramp expectation that B1 and B2 ask you to answer as a plan |

## 8. Prohibited claims

Built before the banks. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or led the design, art, engineering or community teams | Negative you stated, F2 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers, not that you owned a review. B4's slot stays inside the monthly presentation |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope. Your material says you wrote it and QA still uses it, not that you ran releases through it. E2's slot stays inside the checklist |
| Planned and ran live events for two titles | Inflated form of F1 | F1's quote at its own scope: the weekly content-drop calendar for your main title. B3's slot stays inside that calendar |
| Produced a live-service game | Inflated form of F5 | F5's quote at its own scope: associate producer at a puzzle-game studio. Your material does not say the title was live-service |
| Defined or analysed the retention metrics | Inflated form of F7 | F7's quote at its own scope: you presented the numbers. D1's slot asks only how they were counted and which part was yours |

## 9. Sources

Provided documents: the job description you pasted, and your background as you wrote it in your message. No dossier was present.

Searches sent and what came back:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy mobile news" returned https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The three values by name: the values cheat sheet and C1 to C3 |
| 2. Saltmarsh Games interview process, live operations | yes | The Outage Hour, one 60-minute session of tabletop then values conversation: persona weights, A bank, no take-home so no graded deliverable |
| 3. Saltmarsh Games strategy, recent news | yes | The September 2026 announcement of a season-pass model and one shared calendar: A5, B2, R3. Only the result's own wording was used; the page was not fetched |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | One talk page: the interviewer read, D3, R1, R2. Only its summary was read |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- Whether Tobias is the person you would report to, and whether anyone else joins the hour → confirms or reweights every bank
- The recruiter's notes on how the Outage Hour will run → any announced focus, tuned into the Case bank
- Your CV, or the artifacts themselves (your release checklist, a sample weekly calendar, a retention deck) → medium rows F1, F3, F4, F7 can reach high, and the discovery rows F2, F5, F8 may become grounded
- Your answers to the answer slots, said outside a drill (F1, F2, F3, F4, F5, F8) → those rows regenerate with your own words
- How many hours you have before Friday → a prioritized prep schedule
- A strategy brief, or a deeper research pass → a grounding brief section on Saltmarsh's current direction
- Tobias's talk or slides pasted in → his recurring themes become likely questions and sharper reverse questions
- A `tuesday-dossier.md` from an earlier fit analysis, if you have one → verified evidence and a named top objection in place of this pack's inference; the pack stands without it
