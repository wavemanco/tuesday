Web search was refused, so the pack is built from your dossier alone (L0). Anything about Quartzline that I'd have had to research is labelled `[generic]` or left out. Writing the pack now.
Your prep pack is saved as `quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the 45-minute hiring-manager round and used your dossier for the requirements and your confirmed evidence. Web search was refused, so nothing in it is researched. The Quartzline-specific questions are generic, and the company-knowledge question (D3) leaves the Quartzline research to you.

The pack has 20 questions across six interviewer styles, tied to the dossier's requirements R1 to R5. The part to rehearse first is A1 to A3.

- **A1:** the objection the underwriter named ("never held the PM title or owned a roadmap"). Concede the gap first, then give your integration work at its stated scope, name the limit on the roadmap-input sessions yourself, and end on a plan to learn who decides what.
- **A2 and A3:** the follow-ups to A1. They rest on your plain acknowledgment plus a ramp plan, with no bridge to roadmap ownership.

- **R2 gap:** the dossier lists "shipped API or platform products" as high priority but gives it no weak-area entry, and your integration work doesn't show whether you shipped one. I treated it as a gap to clarify (B1). Tell me if you shipped any part of an API or platform product, because that changes B1.
- **Dossier age:** the dossier is dated 2026-08-14, so its confirmed claims are about three months old.

Say the word and I'll play the Skeptic on A1, the question the pack names as your highest-ROI prep.
I can also save an updated `tuesday-dossier.md` recording what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given.
**Built on:** your `tuesday-dossier.md` (decision: conditional_go). Search was unavailable in this session, so nothing here is researched; every Quartzline-specific line is `[generic]` or absent.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: the only claims about your past are your own quoted sentences at their own scope, and anything else is an answer slot, an instruction for the interview that you answer from your real experience or answer by saying plainly it was not yours.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in hand, so no VAL bank) |
| EXP | Whether your claims survive scrutiny; what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in this pack: A1, then A2 and A3 as its follow-ups.** The underwriter named this objection from evidence you confirmed, so it is used here rather than inferred.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | transferability | The underwriter's strategy is `bridge`, positioned as adjacent and never as product management experience. The bridge is derived from that strategy and stays at your quotes' scope: you led the integrations, and you ran the sessions that fed client evidence to product. The limit, as the pack's own observation: your material shows integration leadership, not a product manager title or role. The first quote is graded high confidence with an inspectable playbook; the second is medium, confirmed with limited inspectable proof, so expect a probe on it. Words: "I haven't held a product manager title or role" (dossier `prohibited_claims`), then the first quote as written |
| F2 | "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas; "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | Dossier strategy is `acknowledge_gap`, so no bridge and no answer slot. Words, sourced to dossier `prohibited_claims` ("Having owned a product roadmap", "Having set prioritization for an engineering squad"): "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past: learn which decisions the PM makes alone and which belong to the squad leads before proposing anything |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | discovery | The quotes touch API work and do not show whether you shipped an API or platform product. The dossier lists R2 as high priority but gives it no weak-area entry, so the pack treats it as discovery. Answer slot: the requirement's own wording makes a probe on what you shipped likely. If any part of an API or platform product was yours, say which and what you did, in your own words; if there was no such product, or it was not yours, say so plainly and stay with the integrations you led and the playbook you wrote |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | medium | [inferred] | discovery | The quotes name REST APIs and architecture and do not name API docs or schemas. Answer slot: expect a probe on docs and schemas. If you worked with them in those integrations, say how, in your own words; if you did not, say so plainly and stay with the REST APIs of the integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | discovery | The quotes name clients and product as the parties; engineering and sales are not named in them. Answer slot: expect a probe on each of the three groups the requirement lists. If you worked with engineering or sales in that work, say how, in your own words; if you did not, say so plainly and stay with the clients and the product sessions |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | Dossier strategy is `clarify`. No verified entry speaks to this requirement itself, so the pack maps nothing to it. Answer slot in A5: the requirement's wording is the interviewer's probe; if you worked that way, say how in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how they define it |

## Persona table

Weights rest on the hiring-manager relationship prior, adjusted by the dossier. No Quartzline loop source is in hand beyond your own words, which establish one session with the hiring manager; no archetype tilt is applied. No values-style round is detected, so there is no values bank or cheat sheet.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap | Top, 5 questions. Hiring-manager prior, and the dossier names an objection and carries a `bridge` and an `acknowledge_gap` area | Rehearse the named objection until it is boring: concession first, adjacent case at its scope, plan not claim (A1 to A5) |
| Case/Strategist | Live problems on the partner API role: conflicting partner asks, stalled adoption, two squads | Top, 5 questions. Hiring-manager prior. CASE rows are `[generic]` because strategy research was unavailable | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise (B1 to B5) |
| Data-Driven Prober | Reads the number and the playbook line by line | Mid, 3 questions. The integration count is a headline number and the playbook is inspectable | Know what you can and cannot say about how the number was counted; say plainly where you do not know (C1 to C3) |
| Conversational | A friendly opener in a 45-minute conversation | Mid, 3 questions. Casual questions are still scored | A short arc built only from your quoted sentences, then the real reason for this move (D1 to D3) |
| Pressure | Time-boxed challenge on attribution and on a squad lead pushing back | Low, 2 questions. No signal from the dossier; kept for attribution and decision-rights composure | Hold through two follow-ups, then concede specifically (E1, E2) |
| Peer Evaluator | The seam between the PM and the two squad leads | Low, 2 questions. The interviewer is the hiring manager, not a peer, but the role sits beside the squad leads | Offer seam principles instead of pretending to know the seam (F1, F2) |
| Values/Behavioral | Scenario probes mapped to published values | None. No published values in hand and no values round detected | No bank |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier `prohibited_claims`: "Having held a product manager title or role"; "Having owned a product roadmap" | The deepest rehearsal here, worded as the underwriter wrote it. Order: (1) concede first, before the comparison is pressed: "I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) The adjacent case at the quotes' scope and no wider: you led the client integrations, scoping, requirements, architecture, UAT, go-live, and you ran quarterly roadmap-input sessions feeding client evidence to product. (3) Name the limit before it is extracted: the second is confirmed with limited inspectable proof. Answer slot: if there are notes or outputs from those sessions you can point to, name them; if there are none, say so plainly and stay with the sessions as the quote states them. (4) End on a plan: before proposing anything, learn which roadmap decisions the PM makes and which belong to the squad leads. Do not call the integration work product management, and do not compare yourself favourably with a PM who has the years. Then rehearse A2 and A3 straight after | The underwriter named this as the likeliest objection to F1 and F2, so it is this pack's highest-ROI prep. JD because it scores the 3+ years requirement; the Skeptic delivery is why it sits here |
| A2 | "This role owns the roadmap for the partner-facing API platform. What makes you think you can make those calls?" | JD | [grounded] dossier `uncertain_or_weak_areas` `acknowledge_gap`: "Owning a roadmap and prioritization authority (R1 sub-claim)"; dossier `prohibited_claims`: "Having set prioritization for an engineering squad" | First follow-up to A1. Strategy is `acknowledge_gap`: a plain acknowledgment plus a ramp plan and no bridge. "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Ramp plan, said as a plan: learn which decisions are the PM's alone and which belong to the squad leads, and how partner demand reaches each squad, before proposing anything. Hold that plan through a second push. Concede specifically what you do not yet know, which is the decision rights, and never fill the gap with a precedent | F2 is a gap the underwriter found no evidence for, so the honest answer is the acknowledgment and a plan. JD because it scores the roadmap responsibility |
| A3 | "Why not hire someone who has already done this job for three years?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Second follow-up. Hold-then-concede: concede the comparison plainly, since someone with the years has held the title and role you have not (dossier `prohibited_claims`). Hold by returning to the quote at its own scope: what you led, from scoping to go-live as the quote lists it. Do not tell them what it proves; let them draw the inference. Hold through two further pushes by returning to the quote and never by adding to it | F1 is where the comparison to a titled PM lands. JD because it re-tests the 3+ years requirement from a different angle |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier `uncertain_or_weak_areas` `acknowledge_gap`: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Choose the gap the underwriter already established rather than discovering one live: roadmap ownership. Say it in the plain acknowledgment from A2, then the ramp plan. Delivered calmly, the question becomes a plan | F2 is the established weakest area; this stem tests whether the candidate names it honestly. JD because it is aimed at the listed responsibilities |
| A5 | "The JD asks for agile delivery experience. What's yours?" | JD | [grounded] JD requirement "Agile delivery experience" (dossier role_profile R5) | Strategy is `clarify`; no quote speaks to this requirement itself, so nothing is mapped to it. Answer slot: if you have worked that way, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines agile delivery. Do not stretch UAT or go-live into agile delivery; the quote does not say they were | F6 is a discovery gap; the pack cannot say which branch is true. JD because it scores a stated preference |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about the API or platform work you've done that's closest to what this team ships." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Start with what the quotes carry: the integrations you led and the playbook you wrote. Answer slot: the requirement is shipped API or platform products, so expect a probe on whether any of what you shipped was the API or platform itself. If it was, say what and which part was yours; if there was no such product, or it was not yours, say so plainly and stay with the integrations and the playbook | F3 is a must-have requirement with a discovery gap. JD because it scores R2 directly |
| B2 | "Two integration partners ask for conflicting changes to the same API. What do you need to know first, and how do you decide?" | CASE | [generic] | No claim about your past. Structure: clarify what each change unblocks and for whom; the objective; the cost to each squad and to existing integrations; the options, including a third way; how you would decide and communicate it; what you would measure after. Challenge one premise, for example whether the two asks are truly mutually exclusive. Say your assumption about who decides, and ask | A live problem from the partner-discovery responsibility. `[generic]` because Quartzline research was unavailable |
| B3 | "Adoption of a partner API has stalled. How do you find out why, and what do you measure?" | CASE | [generic] | No claim about your past. Clarify what adoption means here: first call, live in production, sustained use. Ask what baseline exists, since how adoption is measured today is an unknown in the dossier. Then segment partners, form hypotheses, say what data you would need, and name the metric and its limits | The role names adoption metrics as a responsibility with no baseline stated. `[generic]` for the same reason as B2 |
| B4 | "You have two squads and more asks than capacity. How do you sequence the work, and what do you say no to?" | CASE | [generic] | No claim about your past. State the assumption about decision rights first and ask whether it holds, since the dossier marks that authority as unevidenced. Then criteria, trade-offs, who you consult, how a no is explained. Keep it a method, not a precedent | Tests the roadmap and two-squad responsibilities without presupposing any past. `[generic]` |
| B5 | "Tell me about a time you had to hold together engineering, sales and a customer who wanted different things." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | An open prompt; choose the instance yourself. The quotes carry clients and the product sessions only, so tell those at their own scope. Answer slot: the requirement names engineering, sales and customers, so expect a probe on each. If engineering or sales were part of that work, say how, in your own words; if not, say so plainly and stay with the clients and the sessions. The second quote is medium confidence, so say what someone could check about it | F5 is a discovery gap. JD because it scores R4; the open prompt lets you choose |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say you led 30+ client integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number, in your own words. Answer slot: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part of the work was yours. "Led" is the quote's own attribution; keep it. If you do not know how it was counted, say so plainly; do not reconstruct a method | The headline number on the evidence list; probers go straight to it. EXP because it tests attribution honesty |
| C2 | "Walk me through the internal integration playbook you wrote. What's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Describe the contents from the document itself, not from how such documents usually look. The dossier marks this entry high confidence and inspectable, so it is the artifact to name if asked to show something. Stay with what the quote says: you wrote it, and your team uses it | An inspectable artifact is the strongest thing in the evidence list. EXP because it tests what you actually wrote |
| C3 | "Walk me through one of the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell the sessions as the quote states them: quarterly, client evidence, to product. The dossier marks this confirmed with limited inspectable proof, so volunteer the limit before it is probed. If pressed beyond the sessions themselves, say only what you can stand behind, and say plainly where your knowledge stops | The medium-confidence entry is where a prober finds the seam (F1, F5). EXP because it tests what was actually yours |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each only what its quote states: the integrations you led, the playbook you wrote, the sessions you ran. Say early that you are coming from integration delivery and not from a product manager seat, which keeps the positioning honest. The reason for this move is not in your material; say your actual reason in your own words, or say you are still forming it | A friendly opener is still scored, and the adjacency should be set by you first. EXP because it is a biography walk-through |
| D2 | "What are you actually working with these days on the API docs and schema side?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The casual register is still scored. Answer slot: the requirement names API docs and schemas. If you work with them now, or did in those integrations, say what, in your own words; if you do not, say so plainly and stay with the REST APIs of the integrations you led | F4 is a discovery gap on an important requirement. JD because it scores R3 |
| D3 | "What do you know about Quartzline and where its API platform is headed?" | CO | [generic] | No claim about your past, and no claim about Quartzline: research was unavailable, so nothing here is sourced. Before Thursday, read the posting, the company's own site, and any public API documentation, and prepare what you actually found, in your own words. If you found nothing current, say plainly what you read and what you would ask | A company-knowledge question is likely in a hiring-manager conversation. `[generic]` is the honest cost of no research |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty-plus integrations led — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate, anchor in the quote's own verb: you led them. Hold that through two follow-ups. Answer slot: the quote lists scoping, requirements, architecture, UAT and go-live; if some stages were done by others, say which and by whom; if all were yours, say so. Concede specifically what you do not know; do not fold on "led" to restore harmony | The attribution probe tests F1's strongest quote. EXP because it tests what was actually yours |
| E2 | "A squad lead pushes back hard on your priority call in front of the team. You have ten seconds. What do you do?" | CASE | [generic] | No claim about your past. Hold-then-concede: restate the objection, hold the reasoning rather than the title, concede what the lead may know that you do not, and name the next step. Because decision rights are unknown, say you would confirm where the call sits | Pressure on composure and on the decision-authority unknown. `[generic]` |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where's the seam between the PM and the squad leads, and what happens when you disagree?" | JD | [generic] | No claim about your past. Offer seam principles, not a map you do not have: who owns the why, who owns the how, how a disagreement escalates. Say you would want to confirm how Quartzline draws the line | The dossier marks decision authority versus the squad leads as unevidenced. JD because it tests the two-squad delivery responsibility |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a time where the credit was shared and the shares were clear; it needs a named stake and a result both sides could see. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A collaboration probe; the guidance is a selection scaffold because no quoted sentence carries this story. EXP because it tests attribution style |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, A3, A4, D1 |
| R2: Shipped API or platform products | B1 |
| R3: Technical fluency: API docs, schemas | D2 |
| R4: Stakeholder management across engineering, sales, customers | B5 |
| R5: Agile delivery experience | A5 |
| Responsibility: roadmap | A2, B4 |
| Responsibility: discovery with integration partners | B2 |
| Responsibility: specs and delivery with two squads | A5, B4, F1 |
| Responsibility: adoption metrics | B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier's risk: decision authority is asserted in the JD but not evidenced. It reads as diligence and tells you whether the role carries the authority its title implies |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier's risk: adoption metrics are a named responsibility with no baseline stated. The answer tells you whether the first job is defining the metric or inheriting one |
| 3 | "What would a strong first 90 days look like in this role, and what would you want the new PM to learn before proposing anything?" | It turns the ramp plan from A2 into a shared plan and shows you plan to learn before deciding |
| 4 | "How do the two squads split the partner API surface today, and how do their leads prefer to receive priorities?" | Probes the seam from F1 and shows you are thinking about the people who will work with you |
| 5 | "What does delivery cadence look like here, and how do the squads plan and release?" | The cleanest way to find out what agile delivery means at Quartzline, which is the move A5 asks for |
| 6 | "When partner feedback conflicts with what a squad lead thinks is feasible, how has that usually been resolved?" | Surfaces how decision rights work in practice; a vague answer is itself information about the authority question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier `prohibited_claims` | The plain acknowledgment the field supports: "I haven't held a product manager title or role." Then the integration quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" |
| "Having owned a product roadmap" | Dossier `prohibited_claims`; dossier `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | "I haven't owned a product roadmap." Plan only; no bridge |
| "Having set prioritization for an engineering squad" | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." Plan only; no bridge |
| Shaped or decided what product built | Inflated form of F1's third quote | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product". The limit is the pack's observation, not words for you: your material says the sessions fed client evidence to product, not what product did with it. Confirmed with limited inspectable proof |

## Sources

**Provided documents:** your `tuesday-dossier.md`, dossier version 1.1, generated 2026-08-14. Sections consumed: `handoff_to_mock_interview` (verified evidence, weak areas and their strategies, the named objection, risks, employer questions, prohibited claims) and `role_profile` (supplied the requirement text and responsibilities, standing as the JD). `decision` was read as context only. The dossier carries no `evidence_map`, `evidence_state` or `risk_register`. It is about three months old, so its confirmed claims are as of its date.

**Searches sent, all refused (permission not granted):**
- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline platform API strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have fed a values cheat sheet and VAL questions; none built, no values-style round detected |
| 2. Quartzline interview process, product manager | unavailable | Would have documented the loop and tuned persona weights; weights rest on your description and the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded D3 and the CASE bank; they are `[generic]` |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions |

## Upgrade menu

- Search permission → Quartzline's published values, documented loop and current strategy, turning D3 and the CASE rows from `[generic]` into grounded questions; a deeper pass, up to 6 more searches and 2 more fetches and several more minutes, can be added once on request
- The hiring manager's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- The recruiter's prep note, any stated focus areas or an announced exercise → coverage of anything pre-declared
- Your own words, outside rehearsal, on whether any part of an API or platform product was yours (F3, B1), whether you worked with API docs, schemas, engineering or sales in that work (F4, F5, D2, B5), and any agile delivery (F6, A5) → each answer becomes quoted evidence and regenerates those rows
- The span of years behind the integration work (the dossier's summary line mentions a duration, but no verified entry carries one) → a quoted span for F1, A1 and D1
- Any notes or outputs from the quarterly roadmap-input sessions, if they exist → could raise F1's second quote above medium confidence and ground C3
- Hours available before Thursday → a prep schedule sized to them, ordered A1, A2, A3 first
