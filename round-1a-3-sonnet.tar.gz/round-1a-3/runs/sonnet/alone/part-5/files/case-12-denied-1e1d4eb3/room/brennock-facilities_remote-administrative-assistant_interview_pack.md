# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

- Candidate: Aoife
- Round: 30-minute video call with the office manager (name not given). Built as a hiring-manager-style round, since the office manager is the person you would work alongside day to day. If the office manager turns out to be a peer instead, the persona weights below change.
- Built from: your message only. The ad's duties come as you described them, not from the full ad text.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. The guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. None in this pack: no published values were in hand |
| EXP | Whether the claims about your experience survive follow-up questions |
| JD | Whether you can do the listed duties, gaps included |
| CO | Knowledge of the company and its strategy. None in this pack: no company research was run |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. It says what to say if something is true and what to say if it is not.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message, the ad's duties as you described them | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The ad says calendars and your sentence says appointment book. Say your sentence as it stands, "I ran the appointment book for four physios", and let the interviewer draw the link. Nothing inspected sits behind it, so expect a probe on it |
| F2 | "booking travel" — your message, the ad's duties as you described them | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad names it, so expect a probe. If you have arranged travel for anyone, work or not, say for whom and what you booked, in your own words; if you have not, say so plainly and say how you would go about it as a plan |
| F3 | "preparing documents in Word and Excel" — your message, the Word half | "I'm good with Word" — your message | low | [inferred] | discovery | Derived from one self-rating in your message, which says how you rate your Word skills and does not say which documents you prepare. Keep the words at "I'm good with Word". Answer slot: if you have prepared particular kinds of document in Word, name them; if you have not, or only lightly, say so plainly and stay with how you rate yourself |
| F4 | "preparing documents in Word and Excel" — your message, the Excel half | "okay with Excel" — your message | low | [inferred] | discovery | Derived from one self-rating in your message. "Okay" is a level and the words stay at that level. Answer slot: if you have used Excel for particular tasks, name them; if only basic use, say so plainly. Then say, as a plan, how you would build the skill |
| F5 | "processing supplier invoices" — your message, the ad's duties as you described them | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and the words stay there: "I chased unpaid invoices." Answer slot: if any invoice handling you did involved invoices the clinic had to pay, say what you did and which part was yours; if none did, say so plainly and stay with the chasing |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live scenarios from the listed duties: a diary clash, a travel change, an invoice that looks wrong | High. The ad lists tasks, and a hiring-manager-style round on a task-based role usually tests how you would handle them. 5 questions | Clarify first, state the aim, give options, say how you would confirm. Think aloud |
| Skeptic (B) | Quiet probing of the gap between the ad's list and your material: F2, F4, F5 | High. Three of the five rows are thin, so the probing has somewhere to land. 4 questions | Rehearse B1 until it is boring. Hold what your quotes carry, name limits plainly, give a plan for the rest |
| Conversational (C) | Friendly "walk me through it" openers in a 30-minute call | Medium. A short video call usually opens this way, and the register is still scored. 3 questions | A 90-second arc built only from your own sentences |
| Data-Driven Prober (D) | Line-by-line questions on what you did at the clinic | Medium. The office manager will have little else to go on than your background. 3 questions | Know what you can and cannot say about each thing you did. Say plainly where you do not know |
| Pressure (E) | A short, time-boxed challenge on why you or how much was you | Low. Nothing says the call is adversarial. 2 questions | Pause, restate, hold what you stated, concede only what is real |
| Peer Evaluator (F) | "What would you need from me" and disagreement scenarios | Low. It rises if the office manager is a colleague rather than your manager. 2 questions | Offer what you bring as well as what you need |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers both need the same Thursday slot for a call, and one of them is travelling that day. What do you do?" | CASE | [generic] | Think aloud in this order: what you would ask first (whose meeting is fixed, what can move, by when), the aim (both calls happen with least disruption), the options (move the more flexible one, offer two alternative times), and how you would confirm it in writing to both. The question needs no claim about your past, so the guidance makes none | A live problem from the calendars duty (F1), asked as a decision. CASE because it scores structure rather than history; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "A director needs to reach a city for a 10am meeting, the budget is tight, and the train is cancelled the night before. Talk me through it." | CASE | [generic] | Same shape: ask what is fixed (arrival time, budget, who approves a change), list the options, rebook, tell the traveller and anyone waiting for them, keep one up-to-date itinerary. Say it as a plan, in the first person future: "I would". The question needs no claim about your past, so the guidance makes none | F2 is the row with no evidence, so a scenario lets the answer be a plan. CASE; generic for the same reason as A1 |
| A3 | "A supplier invoice arrives for more than the order was worth. What do you do with it?" | CASE | [generic] | Structure it: what you would check first, who you would ask, what you would hold off doing until it is resolved, and what you would record. If you do not know how the business handles invoices, say that you would ask the office manager how it is done here. The question needs no claim about your past, so the guidance makes none | The invoices duty (F5) as a decision rather than a record. CASE; generic because it presupposes nothing about how this employer works |
| A4 | "You are handed a spreadsheet of supplier invoices with duplicates and blank cells, and need a clean list by tomorrow. How do you start?" | CASE | [generic] | Clarify what the list is for, make a copy before changing anything, say what you would check for duplicates and gaps, and say what you would ask about. Describe only steps you could do today and say you would look up the rest. The question needs no claim about your past, so the guidance makes none | The Excel half of the documents duty (F4) tested by doing. CASE; generic because it is a pattern for the problem |
| A5 | "Working remotely, you get three requests from three people and cannot do all of them today. How do you decide, and who do you tell?" | CASE | [generic] | Clarify deadlines, ask the requesters or the office manager what matters most, agree an order, and confirm it in writing so nobody is surprised. The question needs no claim about your past, so the guidance makes none | The job title says remote, which makes working without anyone beside you likely to come up. CASE; generic because no row carries it |

### B. Skeptic

B1 is the highest-ROI prep in this pack. It will be asked in some form, and a rehearsed answer that is calm and specific changes the interview.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "chased unpaid invoices"; "okay with Excel" | Pick the one part you honestly feel least ready for and say it in your own words, without waiting to be pushed. Then say what your material carries for it at its own scope: for invoices, "I chased unpaid invoices"; for Excel, "I'm okay with Excel". Then give a plan for the first weeks, said as a plan and not as a past. Answer slot: travel booking is the ad's duty your material says least about; if you have arranged travel, say what, and if you have not, say so plainly. Hold through two follow-ups by returning to what you said, never by adding to it, and concede the specific limit rather than folding on the rest | F2, F4 and F5 are the rows where this question presses hardest. JD because it scores the listed duties, Skeptic because it asks you to rank your own gaps |
| B2 | "You have been a receptionist. What makes you think you can handle supplier invoices?" | EXP | [grounded] "chased unpaid invoices" | Say what the sentence says: "I chased unpaid invoices." Answer slot: supplier invoices are ones the business pays, so if any of your invoice handling involved invoices the clinic had to pay, say what you did and which part was yours; if none did, say so plainly and stay with the chasing. Then say how you would learn this employer's process, as a plan | F5 is a transferability row: adjacent work, with the limit stated. EXP because it tests what you actually did |
| B3 | "Tell me about any travel you have arranged for someone else, for work or not." | EXP | [grounded] "I ran the appointment book for four physios" | Pick an occasion where you arranged travel for another person. Say who it was for, what you booked and one thing you checked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or how you would go about booking travel | F2 has no evidence, so this is a selection scaffold ending in its honest branch rather than a story. EXP because it asks for a real instance |
| B4 | "How comfortable are you in Excel, honestly, and what would you need to get up to speed?" | JD | [inferred] "okay with Excel" | Say your level as it is, "I'm okay with Excel", and do not upgrade it. Answer slot: if you have used Excel for particular tasks, name them; if only basic use, say so plainly. Then name one concrete thing you would learn first and how, as a plan | F4 is low confidence and derived from one self-rating, so the honest level is the whole answer. JD because the ad names Excel |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. Tell me about yourself." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" | A 90-second arc with three beats, each in your own words: the clinic and the two years, the appointment book for four physios, the unpaid invoices you chased. Answer slot: why you want this admin role is yours to say, in your own reasons; if you are unsure, say what draws you and what you want to find out | The biography question is scored even when it feels casual. F1 and F5 are the rows this arc carries. EXP because it tests the story against the facts |
| C2 | "How would you describe your Word skills?" | JD | [inferred] "I'm good with Word" | Say "I'm good with Word" as it stands. Answer slot: if you have prepared particular kinds of document in Word, name them; if you have not, or only lightly, say so plainly and stay with how you rate yourself | F3 is low confidence, so the answer stays at your own rating. JD because Word is in the ad's duties |
| C3 | "What would you like to get out of a remote admin role?" | JD | [generic] | Choose one real reason you want an admin role and one real thing about working remotely that suits you. If remote working is new to you, say what you would put in place to make it work. Do not invent a reason because it sounds good | Motivation questions come up in a short call and the title says remote. JD because it tests fit with the listed role; generic because no row carries it |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Beats the sentence states: you ran the appointment book, and it was for four physios. Tell them in your own words. Answer slot: the ad's calendars duty makes a probe on how the book was organised likely; if any of how it was set up was yours to decide, say what and why; if not, say so plainly and describe how you ran it | F1 is the evidence for the calendars duty and the likeliest place to be probed. EXP because it tests what was actually yours |
| D2 | "What did chasing unpaid invoices involve?" | EXP | [grounded] "chased unpaid invoices" | Say what you did in your own words, at the scope of the sentence: you chased unpaid invoices. Answer slot: the ad's invoices duty makes a probe on method likely; if you kept a record of which invoices were chased, or chose when to follow up, say what; if not, or if it was not yours, say so plainly and describe what you did | F5 is where the invoices duty is thinnest. EXP because it asks for the detail behind one line |
| D3 | "How do you check your own work before you send a document on?" | JD | [generic] | Pick one habit you really use and say it. If none comes to mind, say so plainly, then say what you would start doing and why | Accuracy in prepared documents is part of the documents duty (F3, F4), and a prober tests it. JD; generic because it is a pattern for the question |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over another candidate?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios" | Pause, restate the question, then hold what your sentences carry, in those words. If challenged twice, concede the specific limit, not the whole case. Answer slot: why you is yours to say in your own reasons; if the honest answer is that you are early in admin, say so plainly and say what you bring | F1 is the strongest row and the one to hold. JD because it scores fit with the role; this is the pressure form of the question |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the sentence: "I ran the appointment book for four physios." Answer slot: if anyone else shared the book or set parts of it, say what was theirs; if not, say plainly it was yours to run. Hold through two follow-ups by returning to the sentence, never by adding to it | F1 again, under attribution pressure. EXP because it is the attribution probe |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "In your first month, what would you need from me to get up to speed?" | JD | [generic] | Name two or three real needs (how things are done here, which tools, who to ask) and pair each with what you will do for yourself first. Offer one thing you can take off the office manager's plate once you are settled | A peer or near-peer prices what a new hire costs them. JD; generic because it presupposes nothing about you |
| F2 | "If I gave you an instruction and you thought a different way was better, what would you do?" | CASE | [generic] | Say you would follow the instruction, raise the alternative once, briefly and with a reason, and accept the decision. The question needs no claim about your past, so the guidance makes none | Disagreement style with an equal. CASE because it is a small live scenario; generic because it is a pattern |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" (F1) | A1, A5, D1, E1, E2 |
| "booking travel" (F2) | A2, B1, B3 |
| "preparing documents in Word and Excel", Word half (F3) | C2, D3 |
| "preparing documents in Word and Excel", Excel half (F4) | A4, B1, B4 |
| "processing supplier invoices" (F5) | A3, B1, B2, D2 |
| Remote, from the role title | A5, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which tools do you use day to day for calendars, travel and invoices, and what would you expect me to handle on my own in the first weeks?" | It shows you are thinking about the practice of the job, and the answer tells you how much Excel the role really needs |
| 2 | "What would a good first month look like, and what would you want me to have learned by the end of it?" | It turns the call from judging you into planning with you, and it gives you a target to prepare against |
| 3 | "Whose calendars would I look after, and which suppliers would I deal with?" | It sizes the work behind the ad's duties, and the answer tells you which rows of your preparation matter most |
| 4 | "How do you like to hand work over and check in when someone works remotely?" | It shows you have thought about the remote part, which the title makes central |
| 5 | "What could I do in my first month that would genuinely help you most?" | A reciprocity question: it signals you think about what you bring as well as what you need |
| 6 | "What does the rest of the hiring process look like after this call, and is there anything I should prepare for it?" | It is a normal process question and gives you something concrete to prepare for |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Manages calendars for an office or for managers | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says the appointment book for four physios, not calendars for an office |
| Processes supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: your material says chasing unpaid invoices, not processing supplier invoices. B2's slot stays inside the chasing |
| Strong or advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". The limit is the pack's observation: your material gives a self-rating of okay, with nothing that shows more |
| Prepares documents in Word as a regular part of the job | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word". The limit is the pack's observation: your material gives a self-rating, not the documents prepared |

## Sources

Provided documents: your message, which contained the invite's wording, the ad's duties as you described them, and your background. No `tuesday-dossier.md` was present.

Searches and fetches sent: none.

Research tier: L0 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | L0 was chosen for this build, so no search was sent. It would have fed a values cheat sheet if a values-style round exists |
| 2. `{company} interview process {role family}` | unavailable | No search was sent. It would have set the loop structure and the persona weights |
| 3. `{company} strategy` / recent news | unavailable | No search was sent. It would have fed CO questions, of which this pack has none |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your description of the ad's duties fixes the five requirement rows; the full ad would fix more |

## Upgrade menu

- The full ad text: the requirement cells of F1 to F5 become exact quotes, and any requirement your summary left out (software, hours, reporting line) gets a row and a question
- The office manager's name: an interviewer read, tailored persona weights and a reverse question tied to their own path
- Your answers to the answer slots in F2 and F5, and to F3 and F4 if you use Word or Excel for particular tasks: those rows and the questions that draw on them become story-mapped answers instead of slots
- A reference from the clinic, or a Word or Excel file of yours with anything confidential removed: with something inspectable behind it, F1 and F5 can rise from medium and F3 and F4 from low
- Whether the office manager will be your manager or a colleague: the weights of A, B and F change
- Permission to run company research: a values and strategy section and CO questions
- A `tuesday-dossier.md` from an earlier session: verified evidence would replace the derived rows with grounded ones
