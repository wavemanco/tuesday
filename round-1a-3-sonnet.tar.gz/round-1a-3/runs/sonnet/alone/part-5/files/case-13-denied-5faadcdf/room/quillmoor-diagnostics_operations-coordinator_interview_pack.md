# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Round: recruiter screen, 30-minute phone call, Thursday 2pm, with Hannah Lowther (Talent Partner). Her stated agenda, from her LinkedIn message: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script, and every claim about your past in it comes from a sentence you wrote.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your experience survives scrutiny; what was actually you |
| JD | Whether you fit the stated requirements and terms of the role |
| CO | How well you know the company and its work |
| CASE | How you structure a live problem from the role |

Highest-ROI prep: B2, the question about moving from delivery scheduling to production-schedule coordination. It will arrive in some form, and the pack's guidance for it stays inside what you told me. Next: the four logistics questions, A2 to A5, which Hannah has said she will ask.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: the four years, the role, the type of employer |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says scheduling deliveries for three depots, and nothing about production schedules, planning or QA. The words stay at the depots: "I schedule deliveries for our three depots." Answer slot: the advert's line on planning, the warehouse and QA makes a probe on cross-team coordination likely. If any of your scheduling involved coordinating with other teams, say with whom and what you did, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | discovery | The quote shows chasing suppliers when orders slip. It does not show how deliveries are tracked. Lead with the quote's own words on chasing. Answer slot: if you track supplier deliveries, say how, in your own words; if you do not, or it is not your task, say so plainly and stay with the chasing |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, with nothing inspected behind the figure, so expect a probe on it. Say the sentence at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The figure's slots are in C1 |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on delivery performance. Answer slot: the advert's weekly-reporting line makes a probe likely. If you report on any delivery or dispatch measure, say what and how often, in your own words; if you do not, say so plainly and say what you would want to see first |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | Derived from the quote: it says spreadsheet, not Excel. Answer slot: say which tool it was and what the spreadsheet did, in your own words; if it was not Excel, say so plainly and say what it was |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | discovery | Your message states the SAP absence, so the plain words are "I've never used SAP." The in-house system is stated at the company's scope, "we run our own in-house stock system", and the quote does not say what you do in it. Answer slot: if you work in that system yourself, say what for; if you do not, say so plainly and stay with the SAP statement. This is a plus in the advert, not a requirement |
| F8 | "£38,000–£44,000" — advert; "your salary expectations" — recruiter's message | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure is inside the advert's range. Say it in your own words as you stated it. Nothing is added to it |
| F9 | "two days a week at our Avonmouth site in Bristol" — advert; "how the hybrid pattern would work for you" — recruiter's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Both halves of your sentence carry weight: two days is fine, and more than three is not what you want. Keep both, in that form |
| F10 | "your notice period" — recruiter's message | none given | none | [grounded] | hard_gate | Your material does not establish it |
| F11 | "what's prompting a move" — recruiter's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | Your reason is stated and specific. Say it as stated and add nothing to it |

## Persona table

| Persona | How it shows up on this call | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly phone register; the four logistics topics, the journey question, why Quillmoor | Highest. Hannah's own message sets a recruiter screen with a fixed agenda; the relationship prior for a recruiter screen is Conversational first. The risk is treating a friendly call as unscored | Short arc for the biography question (A1); logistics answers in your own words (A2 to A5); treat casual company questions as scored (A6) |
| Skeptic (light) | Knockout checks on the gaps: SAP, production scheduling, supplier tracking | Medium. Recruiters check requirements against the advert before passing you on, and the advert lists SAP or similar as a plus and production coordination as a duty. Her agenda names no probing round | Rehearse B2 until it is boring; state the SAP limit plainly (B1); never stretch the depots into production |
| Data-Driven Prober | Probes your figure and your Excel claim | Low to medium. Recruiters rarely go two levels deep, but the advert says "confident with Excel" and your message gives a figure | Know what you can and cannot say about how the figure was counted, and say plainly where you do not know (C1) |
| Case / Strategist | A short live problem from the role | Low. Hannah's agenda lists no problem-solving item and a recruiter screen rarely runs one; the cases are cheap rehearsal for the later rounds | Clarify, then structure, then answer; say your assumptions aloud (D1 to D3) |
| Pressure / Stress | A time-boxed "why you" | Low. Nothing in her message suggests it; it is rehearsal insurance for the "why you" line | Pause, restate, hold what your sentences say, concede the stated limit (E1, E2) |

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey. Where are you now?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats, each a sentence you wrote: the four years and the employer type, what you schedule and chase, the spreadsheet rebuild and the fall in discrepancies. Tell it in your own words in about ninety seconds, and end on why you are looking, using the words from A2 | F1, F3 and F4 are the strongest evidence in your material, so the opener should carry them; EXP because it tests what was actually yours |
| A2 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it as stated: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Add nothing to it. If she asks about it again, your own words were the same sentence. Answer slot: if she asks what draws you to this role, say what in the advert draws you, in your own words; if nothing beyond the location does, say so plainly | F11 is the reason Hannah named in her message; EXP because it tests consistency of your motive |
| A3 | "What salary are you hoping for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot: say your figure in your own words: "I'm hoping for £42,000." If she asks about your current pay, prepare a polite redirect to this role's range, with no figure | F8 holds your figure inside the advert's range; JD because pay is a term of the listed job |
| A4 | "What's your notice period?" | JD | [grounded] Hannah's message: "your notice period" | Logistics slot: give your actual notice period, in your own words. The pack holds no figure for it | F10 is a gate your material does not establish, and Hannah named it; JD because notice is a term of the listed job |
| A5 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot: say it as you stated it, both halves: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the journey or the days, your own words were the same sentence | F9 is the advert's hybrid term and Hannah's named topic; JD because location is a term of the listed job |
| A6 | "What do you know about Quillmoor, and why this role?" | CO | [grounded] advert: "diagnostic-test manufacturer, about 400 staff" | Selection scaffold, with research unavailable this turn: say what you have read about Quillmoor, from its own site or the advert, and what in the advert's duties interests you, using only what you actually read. If you have read little beyond the advert, say so plainly, then give what the advert states: a diagnostic-test manufacturer of about 400 staff | Casual company questions are scored in a recruiter screen; CO because it tests homework depth |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert mentions SAP or similar. Have you used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain words: "I've never used SAP." Then the in-house system at the scope you stated: "we run our own in-house stock system." Answer slot: if you work in that system yourself, say what for; if you do not, say so plainly and stop at the SAP statement. Close with how you would learn the ERP, said as a plan and never as past experience | F7 is stated by you and is a plus in the advert; JD because it scores a listed requirement |
| B2 | "Your background is delivery scheduling at a wholesaler. This role coordinates production schedules between planning, the warehouse and QA. What's the overlap?" | JD | [grounded] "I schedule deliveries for our three depots" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling involved coordinating with other teams, say with whom and what you did; if it did not, or it was not yours, say so plainly and stay with the depots. Hold through two follow-ups by returning to the depots, never by adding to them. Then concede the limit as the pack observes it: your material says deliveries, not production schedules. Last, a plan for the manufacturing side in your own words: what you would ask to see first | F2 is where the advert's headline duty presses hardest on your material, so this objection arrives in some form; JD because it scores the stated requirement |
| B3 | "The role tracks supplier deliveries and chases late orders. How do you do that today?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Lead with the sentence as you wrote it. Answer slot: the advert's tracking line makes a probe on how you follow deliveries likely. If you track them, say how, in your own words; if you do not, or it is not your task, say so plainly and stay with the chasing | F3 shows chasing and not tracking; JD because it scores a listed duty |
| B4 | "Tell me about a time you had to get people from different teams to agree on a schedule." | EXP | [grounded] "I schedule deliveries for our three depots" | Selection scaffold: the advert's planning, warehouse and QA line raises the theme. Pick a time with a named stake, the people involved and where you landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I schedule deliveries for our three depots." | F2 again, as an open prompt, because a recruiter often tests the cross-team line with a story; EXP because it checks what you actually did |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence at its scope. Four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no baseline or method | F4's figure is the headline number in your material and a magnet for probes; EXP because it tests attribution and honesty about the figure |
| C2 | "How confident are you with Excel? What did that spreadsheet do?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: say which tool it was and what the spreadsheet did, in your own words; if it was not Excel, say so plainly and say what it was. Name only what you built, nothing from the advert's wording | F6 is derived: the quote says spreadsheet, not Excel; JD because the advert states "confident with Excel" |
| C3 | "The role reports weekly on on-time dispatch. What do you report on today?" | JD | [grounded] advert: "report weekly on on-time dispatch" | Answer slot: if you report on any delivery or dispatch measure, say what and how often, in your own words; if you do not, say so plainly and say what you would want to see first. The pack names no report for you | F5 has no evidence in your material; JD because it scores a listed duty |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery that next week's production depends on will be five days late. What do you do?" | CASE | [generic] | Structure it: ask first what depends on it and what slack exists; decide what to tell planning, the warehouse and QA today; weigh expediting against re-sequencing; set a check-in time. Say your assumptions aloud. The question needs no claim about your past | A live problem from the advert's supplier-chasing and scheduling lines |
| D2 | "QA puts a batch on hold the morning it was due to ship, and the warehouse has dispatch booked. What do you do?" | CASE | [generic] | Structure it: find out the hold's scope and expected duration from QA; tell the warehouse what can still ship; flag the dispatch impact; log it for the weekly on-time report. Say your assumptions aloud. No claim about your past | A problem from the planning, warehouse and QA seam in the advert |
| D3 | "Stock records say 120 units and the shelf holds 112. How do you find out why?" | CASE | [generic] | Structure it: recount first, then check recent movements, then check for timing gaps in receipts and issues, then fix the record and note the cause. Say your assumptions aloud. No claim about your past | A problem from the advert's stock-records line |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we shortlist you over someone who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "Never used SAP — we run our own in-house stock system." | Pause and restate. Hold: the four years, the depots, the chasing, in the quotes' own words. Concede the stated limit plainly: "I've never used SAP." Then stop; do not argue that you are better | F7 is the stated gap and F1 and F3 the evidence to hold; JD because it scores fit against the advert |
| E2 | "That drop of about a third: how much of that was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the sentence says: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot: if other changes contributed, say what, in your own words; if none that you know of, say so plainly; if you do not know, say that. Hold through two follow-ups, concede only what you actually do not know | F4's figure invites an attribution probe; EXP because it rehearses honesty about what was yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1, E1 |
| Coordinate production schedules between planning, the warehouse and QA | B2, B4, D1, D2 |
| Track supplier deliveries and chase late orders | B3, D1 |
| Keep stock records accurate | C1, D3, E2 |
| Report weekly on on-time dispatch | C3, D2 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, E1 |
| £38,000–£44,000 and your salary expectations | A3 |
| Two days a week at Avonmouth | A5 |
| Notice period (recruiter's agenda) | A4 |
| What is prompting a move (recruiter's agenda) | A2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What are the next stages after this call, and who would I meet?" | Hannah has said she will cover next steps; this makes them concrete and tells you what to prepare next |
| R2 | "Is this a new role or a replacement, and what does the team need most from it in the first few months?" | It shows you are thinking about the work and surfaces what the hiring manager will weight |
| R3 | "How does the team report on on-time dispatch today, and who reads it?" | The advert names the weekly report as a duty; asking about it shows you read the duties |
| R4 | "Which ERP does the site run, and how does the team bring a new starter up on it?" | The advert lists SAP or similar as a plus; the question is about the site's onboarding, not your gap |
| R5 | "How do the two Avonmouth days usually work: fixed days, or agreed with the team?" | It asks about the employer's pattern, which the advert states only as two days a week |
| R6 | "What would you tell me about the team that isn't in the advert?" | An open invitation that keeps the call conversational and often draws out the most useful detail |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries, not production schedules. B2's slot stays inside the depots |
| Has used SAP, or has ERP experience | Negative you stated, F7 | The plain acknowledgment: "I've never used SAP." The in-house system only at the scope you stated. B1's slot asks only what you do in it |
| Cut stock discrepancies by a precise percentage, or by a method you named | Inflated form of F4 | F4's quote at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The limit is the pack's observation: your material gives the figure, not how it was counted |
| Your role is being made redundant | Inflated form of F11 | F11's quote at its own scope: the Bristol office is closing next year, and the only offer is relocating to Reading |

## Sources

Provided documents: your message, which held the advert, your background summary and Hannah Lowther's LinkedIn message.

Searches sent, all refused (the search permission was not granted):

- Quillmoor Diagnostics values — refused
- Quillmoor Diagnostics Avonmouth news strategy — refused
- Hannah Lowther Talent Partner Quillmoor Diagnostics — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search refused. Would have grounded A6 in published material and told us whether any value themes the questions |
| 2. Quillmoor Diagnostics interview process, operations | skipped | Hannah's message already fixes this session: who runs it, how long, and what it covers; persona weights follow it |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Search refused. Would have made A6 specific to Quillmoor's current work |
| 4. Hannah Lowther Quillmoor Diagnostics | unavailable | Search refused. Would have supplied an interviewer read and a reverse question tied to her path, both absent from this pack |
| 5. Representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your notice period → fills A4 in your own words and settles F10, the only gate row your material does not establish
- Your CV → replaces the message-sourced evidence in F1 to F4, F6, F7 and F11 with CV lines, and the stock-count spreadsheet itself or its before-and-after discrepancy counts would lift F4 from medium
- Your answers to the answer slots (whether your scheduling involved other teams, whether you track supplier deliveries, which tool the spreadsheet was, whether you report on delivery performance) → each becomes quoted evidence and regenerates B2 to B4, C2 and C3
- Hannah's public professional profile → an interviewer read, tuned persona weights and a reverse question tied to her career path
- Search permission → a research pass (up to 6 searches and 2 fetches) would ground A6 in Quillmoor's own published material; a deeper pass (6 further searches and 2 further fetches, several more minutes) would add a grounding brief for company-specific CO and CASE questions
- A tuesday-dossier.md from an earlier evaluation of this job → verified evidence and constraints on each weak area, in place of the pack's own inference from your message
