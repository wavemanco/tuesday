# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (the invite gives no name). Relationship assumed hiring-manager style. Format: a text chat, per the invite. Built at L0 in effect: no company research was available, so everything about Lumenvale is either absent or labeled.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the way of working the employer cares about |
| EXP | Whether your background survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Homework on the company: what it makes and where it is heading |
| CASE | Structure and judgment on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. It names a practice only as the interviewer's likely probe, and it always allows that the practice never existed.

The highest-ROI rehearsal in this pack is A1: the one gap you stated yourself is the objection most likely to arrive in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length, but a line from your message with nothing inspected behind it, so expect a probe. Lead with it in its own terms: three years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [inferred] | presentation | Your material names Freshdesk, not Zendesk. Whether Freshdesk counts as similar is the interviewer's call, and this pack derives only that the ad's "or a similar ticketing tool" leaves room for it. Words: "I use Freshdesk every day." Say the tool by name and how often, and never say Zendesk |
| F3 | "clear written communication" — job ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written, but the figure counts calls and emails together and shows nothing about how clear the writing was. Answer slot: the ad's line makes a probe on your writing likely, and this interview is itself a text chat. If a good share of those 60 was written, say so in your own words; if most were calls, say so plainly and describe how you write a reply. Keep the figure as you gave it, calls and emails together |
| F4 | "confidence handling escalations" — job ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show whether you have handled escalations; that is silence, not an absence. Answer slot: the ad's escalation line makes a probe likely. If you handled escalations, say what the situation was and which part was yours, in your own words; if you did not, or it was not yours, say so plainly and say how you would handle one |
| F5 | Software-company background: not a line in the ad as you relayed it, raised here because of the employer's name | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would get up to speed, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Not asked for in the ad as you relayed it; no requirement is claimed | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Extra material that earns space only when a question opens it (D2). Say it at its own scope: you trained four new starters on the refunds process, last year. The quote does not say you designed the process or ran a programme, or how it went, and nothing here supplies either |

## Persona table

Weights rest on the relationship prior for a hiring-manager-style round and on F5, your own stated gap. They do not rest on a documented Lumenvale process or an interviewer profile; neither was available. Recalibrate if you know more.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5 questions) | Quiet probing of the software-company gap, the tool match and the escalation line | High: the hiring-manager prior includes it, and F5 is a gap you stated yourself | Rehearse A1 until it is boring: the plain acknowledgment, then a plan, then back to your own quoted sentences |
| B. Case / Strategist (5 questions) | Live support scenarios you answer in the chat | High: the hiring-manager prior includes it, and the ad's escalation and writing lines can be tested live | Clarify first, structure the reply, think aloud, and promise only what you could deliver |
| C. Conversational (3 questions) | Friendly opener, then casual questions on hot ad topics | Medium: a text chat with a team lead suits a relaxed register, and casual questions are still scored | A short arc built only from your own sentences; read their site before the chat |
| D. Data-Driven Prober (2 questions) | Asks how the 60 a day and the four new starters were counted and what was yours | Low to medium: it depends on how closely the lead reads your CV, which nothing here shows | Know what you can and cannot say about each figure, and say plainly what you do not know |
| E. Pressure (2 questions) | Time-boxed challenge: why you, and how much was you | Low: no interviewer signal points to it; escalation composure is the only pull | Pause, restate, hold through two follow-ups, then concede specifically |
| F. Values / Behavioral (2 questions) | Scenario prompts in the customer's corner | Low: your message names a single chat with the support team lead and no round that assesses values | Choose stories where the hard truth landed; where none comes to mind, say so |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see experience at a software company in your background. How would you handle that in this role?" | EXP | [grounded] "I've never worked for a software company"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | The deepest rehearsal in the pack. Level 1: say it plainly, "I haven't worked for a software company", then, as a plan in your own words, how you would get up to speed, using only steps you would really take. Level 2, if told it is a big gap: hold, do not argue it away, and return to two sentences at their own scope: "I use Freshdesk every day" and "I trained four new starters on our refunds process last year". Level 3, if told someone from software would ramp faster: concede what you cannot know, that they may well be faster on the product, then return to the same two sentences. Never claim familiarity with the product or with software support | F5 is the one gap you stated yourself, so this objection arrives in some form; F2 and F6 are the only evidence it can be answered with. EXP because it tests what your background shows |
| A2 | "The ad says Zendesk or a similar tool. Which ticketing tool have you used?" | JD | [grounded] "I use Freshdesk every day" | Say the tool and the cadence in the quote's words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how, in your own words; if you have not, or have only used Freshdesk, say so plainly and stay with Freshdesk. If asked what you do in the tool, describe your own use and do not list features you have not used | F2 is the evidence for the tool line and the likeliest place a literal reading of the ad bites; JD because it scores a stated requirement |
| A3 | "Tell me about an escalation you handled." | JD | [generic] | Selection scaffold: pick a time a customer's issue went beyond what you could resolve yourself, or they asked for someone more senior. It needs the situation, your decision, what you handed over and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F4 is silence in your material, so the pack coaches selection and supplies no story; the prompt's theme comes from the ad's escalation line. JD because it scores that line |
| A4 | "Why this move, from an energy supplier to a software company, and why this role?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Start from the quote, in its own terms. The reason is yours and the pack has none on file. Answer slot: give what draws you to this role and anything you have actually read about Lumenvale; if you have read nothing yet, say so plainly and say what you would want to learn | F1 anchors the story, and motivation consistency is what a Skeptic scores. EXP because it tests whether your move hangs together |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name a weakness you honestly believe in; the pack does not choose it for you. If it is software-company background, it is your stated gap: "I haven't worked for a software company", followed by the same plan as A1. Calibrated candor beats bluffing | F5 is the gap you stated, so it is the natural answer, and the question forces a choice. JD because it scores the listed job including its gaps |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in capitals that this is the third time they have contacted us about the same problem. Reply to them now, in this chat." | CASE | [generic] | Ask the lead one clarifying question first: what the problem is and what has been tried. Then write: acknowledge the repeat contact, restate the problem in one line, say what happens next and who does it, and promise only what you could deliver. Short sentences, answer first | F3's requirement tested live: this chat is itself a writing sample |
| B2 | "A customer's issue is beyond what first-line support can fix, and they demand a manager. Walk me through what you do." | CASE | [generic] | Say what you would ask first, what you would try yourself, when you hand over and to whom, and what the handover note holds so the customer need not repeat themselves. Tell the customer what happens next without promising a manager's decision. Think aloud | F4's requirement as a decision rather than a story; CASE because it asks about no past |
| B3 | "A customer asks for a refund the policy does not allow, and says they will post a public review. What do you do?" | CASE | [generic] | Say what you would check, what you can and cannot say, and who decides exceptions; do not promise one. Acknowledge the review threat without bargaining over it, and say what you would record | Escalation judgment under pressure; the case claims nothing about your past, so the guidance makes none |
| B4 | "A customer asks a question about our product and you do not know the answer. What do you do?" | CASE | [generic] | Say what you do know, what you would check and where, and when the customer will hear back. Do not present a guess as an answer; set an honest expectation and follow up | F5 as a live problem: it lets you show how you work without a product background |
| B5 | "A customer reports something that looks like a bug, and you cannot reproduce it. What do you ask them for?" | CASE | [generic] | Clarify before diagnosing: what they did, what they expected, what happened, when, and on what device or browser, and whether they can send a screenshot. Say you would pass it on written up clearly, and promise no fix | A software-support pattern, labeled generic because no source describes Lumenvale's product |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A short arc, four beats, each a quoted sentence in your own words: the three years as a customer service advisor at an energy supplier; "around 60 calls and emails a day", calls and emails together; Freshdesk every day; training four new starters on the refunds process last year. Answer slot: why this role now, in your own words; if you have no settled reason yet, say what you are looking for | F1 to F6 in one pass; JD because the biography is where the ad's two-years line is scored |
| C2 | "The ad asks for clear written communication. What does that mean to you?" | JD | [grounded] "answering around 60 calls and emails a day" | Define it in your own words, briefly. Answer slot: if a good share of those 60 was written, say so; if most were calls, say so plainly and say how you write a reply. The chat itself is the sample, so write the answer the way you would answer a customer | F3 is thin evidence and the interview is a text chat, so the answer is scored twice. JD because it scores a stated requirement |
| C3 | "What do you know about Lumenvale and what we make?" | CO | [generic] | The pack could not research Lumenvale, so it supplies no facts. Before the chat, read their own site and note two things you actually read; say them as things you read. If you have not had time, say so plainly and ask what the product does | CO homework scored casually; generic because no company research ran |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty calls and emails a day. Walk me through how that number was counted." | EXP | [grounded] "answering around 60 calls and emails a day" | Keep your own word "around" and keep calls and emails together; do not turn it into emails alone. Answer slot: if a system or report gave you the figure, say what it was; if it is your own estimate, say so plainly. Say how it could vary and which assumption behind it you would defend least; if you do not know how it was counted, say that | F3's figure is the headline number on your background and a magnet for this probe |
| D2 | "Four new starters. Which part of training them was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say it at its own scope: "I trained four new starters on our refunds process last year." Answer slot: if you shared the training, say who did what; if you did it alone, say so plainly; if you do not know how it was set up, say so. Say how the four was counted and the assumption behind it you would defend least. Do not describe how it went unless you can say what happened | F6 is a headline figure with an attribution question attached; the quote carries who and what, not how it went |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause, restate the question, then hold with your sentences at their own scope: three years as a customer service advisor at an energy supplier, and "I use Freshdesk every day". Hold through two follow-ups. Concede specifically: "I haven't worked for a software company." Close with your own reason for wanting the role | F5 is the pressure point and F1 and F2 are what holds; JD because it scores fit against the listed job |
| E2 | "Sixty a day sounds like volume, not quality. Convince me." | EXP | [grounded] "answering around 60 calls and emails a day" | Hold on what the quote says: "around 60 calls and emails a day". Answer slot: if any measure of quality existed, such as a score, feedback or a review of your replies, name it; if none did, say so plainly and stay with the volume. Do not defend the figure as proof of quality | F3's figure says volume only; EXP because it tests what the number can and cannot carry |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time doing right by a customer cost you something on a target or a process. It needs what you decided, what it cost and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem, so no claim about your past is made |
| F2 | "Tell me about a time you delivered an unpopular truth." | VAL | [generic] | Selection scaffold: pick a time you told a customer or colleague something they did not want to hear. It needs what you said, how they reacted and how it ended, and the hard truth must have landed. If none comes to mind, say so plainly and do not supply an ending | A persona stem; generic because it makes no claim about you |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| "2+ years in customer support" | C1, A5, E1 |
| "experience with Zendesk or a similar ticketing tool" | A2 |
| "clear written communication" | C2, B1 |
| "confidence handling escalations" | A3, B2 |
| Software-company background (not in the ad as relayed) | A1, A5, B4, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a new support specialist's first month look like, especially learning the product?" | It meets F5 openly and turns your gap into a conversation about ramping up |
| R2 | "Which ticketing tool does the team use, and how are tickets routed?" | It is concrete about F2, and the answer tells you how far your Freshdesk use carries |
| R3 | "How does the team handle escalations, and what does a good handover look like?" | It is concrete about F4 and shows you think about the next person's job |
| R4 | "What do customers write in about most, and what would you want a new person to get good at first?" | It shows you are planning your first weeks, not just the interview |
| R5 | "How is success measured for this role in the first six months?" | It asks for the yardstick, which also tells you what to emphasise later |
| R6 | "What are the next steps after this chat? For example, is there a call or video conversation with the wider team?" | It tells you what else to prepare for and shows you are planning ahead |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material says Freshdesk, not Zendesk. A2's slot stays on your own use |
| Software-company background | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Sixty emails a day, or sixty tickets a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day", calls and emails together. D1's slots stay inside it |
| Owning or designing the refunds process, or running a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". The limit is the pack's observation: the quote says you trained four people on the process, not who set it up. D2's slot stays inside the training |

## Sources

Provided documents: your message, which holds the invite text, the ad's four requirements as you relayed them, and your background. No dossier was consumed.

Searches sent, all refused (permission was not granted):

- `Lumenvale Software company values`: refused
- `Lumenvale Software interview process customer support specialist`: refused
- `Lumenvale Software news strategy`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software company values` | unavailable | Would have fed VAL themes and a values cheat sheet; none exists, so F1 and F2 rest on persona stems |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Would have named the loop; persona weights rest on the relationship prior and your invite's wording instead |
| 3. `Lumenvale Software news strategy` | unavailable | Would have grounded the CO bank; C3 is generic and A4 asks for your own reading |
| 4. interviewer name and company | n/a | The invite gives no name for the support team lead, so there was no query to form; the interviewer read is absent |
| 5. representative JD for the title | skipped | The ad's four requirements, as you relayed them, fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → the four relayed lines become full quoted rows, and any term the ad states (hours, location, tools) is surfaced as its own row
- Your answer on escalations, whether a situation you handled and your part in it or that you have not handled any → F4, A3 and B2 move from selection scaffolds to a mapped story or an honest limit
- Your answer on how much of the 60 a day was written → F3, C2 and D1 move from discovery to a grounded row
- The support team lead's name and whether the chat runs live → an interviewer read, reweighted personas and a tailored reverse question
- Web search access, or the company's own values and careers pages pasted in → grounded values themes, a grounded C3 and A4, and a named loop; a deeper pass of up to 6 more searches and 2 more fetches would add a strategy brief, and takes several more minutes
- How much prep time you have → a prioritized schedule instead of the full pack
- A `tuesday-dossier.md` from an earlier session → verified evidence and a prohibited-claims list to hold the banks against
