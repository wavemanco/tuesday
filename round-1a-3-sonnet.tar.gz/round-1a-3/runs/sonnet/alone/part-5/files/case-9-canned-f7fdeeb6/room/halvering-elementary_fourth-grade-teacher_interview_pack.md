# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Halvering Elementary School, Orrinsford Community School District
**Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren plus two members of the fourth-grade team (the invite names no individuals for the two teachers)
**Relationship:** hiring manager (the principal) plus two grade-level peers
**Built on:** the invite, your résumé text, and an L1 research pass (see Sources). No posting text was supplied, so job-requirement rows beyond the invite and the district's own pages are role-family prose labeled `[generic]`.

## 1. How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your résumé claims survive scrutiny: what was actually you |
| JD | The listed job and its terms, including its gaps |
| CO | Homework: the district's plan and priorities |
| CASE | A live classroom problem, reasoned aloud |

An **answer slot** in a cell is an instruction for the interview, not a question for you now: say it in your own words if it is true, and if it is not, say so plainly and return to the quoted fact.

**Highest-ROI prep in this pack: B1.** "You haven't taught fourth grade" will be asked in some form, because your own material says so. A rehearsed, non-defensive answer changes the interview.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate, and your CV states it met: kind, endorsement, status and expiry. Say it as written. Checking the registration against the issuer's own record is yours to do, and I did not. Your license number stays out of this pack and out of every search I ran |
| F2 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | Classroom teaching experience at the elementary level — role-family requirement, no source quoted | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [generic] | none | Lead with it as written: six years, third grade, a public elementary school in Joliet. A named record beats an adjective. Its limit, third grade and not fourth, is carried by F2 |
| F4 | "reading instruction" — the district's hiring page: "Panels ask about reading instruction, classroom routines and how you work with families" | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Words stay at each quote's scope: you led the grade level's move, and you run the club. Answer slot: the district names reading instruction as a panel topic, so expect a probe on what happens inside a reading block itself. If the move changed what you did in your own reading block, say what, in your own words; if it did not, or that part was not yours, say so plainly and stay with the move you led and the club you run |
| F5 | "classroom routines" — the district's hiring page, same sentence as F4 | none given | none | [grounded] | discovery | Your material does not show routines either way. Answer slot: if you set routines in your own classroom, name one or two and say how you taught them, in your own words; if you did not set them, or none stand out, say so plainly, then say as a plan which you would set first in a fourth-grade room |
| F6 | "how you work with families" — the district's hiring page, same sentence as F4 | "I write a weekly email to families" — your CV | medium | [grounded] | none | Lead with the email in the quote's own terms: weekly, written, to families. A named cadence beats an adjective. Keep it at that scope; F7 is where the district's wording presses wider |
| F7 | "each teacher speaks with every family each term" — the district's beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Words: "I write a weekly email to families." Answer slot: the district's belief is stated in terms of speaking with families, so expect a probe past the email. If families replied to the emails or conversations followed, say what happened and what part was yours, in your own words; if none did, or it was not part of your practice, say so plainly and stay with the weekly email |
| F8 | Works as part of a grade-level team — role-family requirement, no source quoted | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [generic] | none | Say it at its own scope: you led the grade level's move. That is a different thing from a team-lead role; your message says "I've never been a team lead", and section 13 carries that |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan" — the district's beliefs page | "I've run the after-school reading club for the last two years" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | The club and the curriculum move are adjacent to a belief stated in terms of reading plans, and the words stay at their scope. Answer slot: if any student had a reading plan you wrote or followed, say what it was and what part was yours, in your own words; if there was none, or plans were not yours to write, say so plainly and stay with the club and the move |
| F10 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — the district's beliefs page | none given | none | [grounded] | discovery | Your material does not show assessment work either way. Answer slot: if assessment results ever changed what you taught, give one case in your own words; if they did not, or assessment was handled by others, say so plainly, then say as a plan how you would use results to adjust a lesson |

## 3. Persona table

Weights are shown as the number of questions each bank carries. Reasoning is shown so you can recalibrate if you know something I do not.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist (5) | Live classroom problems on reading, routines and family events, most likely from the principal | **High.** Relationship prior for a hiring manager is Case plus Skeptic. The district's hiring page names reading instruction and classroom routines as panel topics, and the principal's public footprint is reading-centered (section 6) | Clarify, then objective, approach, how you would know it worked, risks. Think aloud. Challenge one premise politely. Questions A1 to A5 |
| B. Skeptic (4) | The fourth-grade gap, probed quietly and persistently | **High.** Hiring-manager prior, and your own material states the gap (F2). The objection is certain; only its wording varies | Rehearse B1 until it is boring. Bridge only from what your quotes carry, and say the limit plainly. Questions B1 to B4 |
| C. Peer Evaluator (3) | The two fourth-grade teachers: seams, planning, what they would need from you | **Medium-high.** The panel includes two grade-level teachers, and the peer prior is Peer Evaluator plus Prober. Their individual styles are unknown | Reciprocity: what you bring their team as well as what you need. Offer seam principles rather than pretending to know their seam. Questions C1 to C3 |
| D. Values / Behavioral (3) | Scenario probes themed on the district's three published beliefs | **Medium.** The beliefs page says three beliefs guide every hire, but it is not a loop source and the hiring page names topics, not a values round, so no values-style round is detected and there is no values cheat sheet. The beliefs still raise questions, and each gets one | Map a story only where a quoted sentence carries one; otherwise a selection scaffold ending in its honest branch. Questions D1 to D3 |
| E. Conversational / Rapport (2) | The opening biography question and a casual reading question | **Medium-low.** Panels often open conversationally; the casual register is still scored. No signal about these panelists' style | A 90-second arc built only from your own quoted sentences. Questions E1, E2 |
| F. Data-Driven Prober (2) | A grade-level peer pressing on the curriculum move and the club | **Medium-low.** The peer prior includes Prober, and the district's third belief is about assessment, but nothing says these panelists are analytic | Know what you can and cannot say about how the move was going, and say plainly when you do not know. Questions F1, F2 |
| Pressure / Stress (no bank) | — | **Low.** The hiring page describes a topic-based building panel and gives no signal of time-boxing or interruption, so no bank is spent on it | — |

**Loop:** the district's hiring page, read in full, establishes this loop: one 45-minute building panel of the principal and two grade-level teachers, with references taken up after the panel. No archetype fallback is used.

## 4. Reading the interviewer

Public professional footprint only, read from a search excerpt (the full page was not fetched).

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois Principals Forum speaker page, search excerpt | [grounded] | Expect depth on reading instruction. She will hear imprecision on reading quickly, so stay at your quotes' scope |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | Illinois Principals Forum speaker page, search excerpt | [grounded] | A5 rehearses the likeliest version. Do not claim practices you did not run; asking how her building does it is a stronger move than guessing |

Mirror opportunity, shared vocabulary only: her talk is about reading in grades 3 to 5, and your F4 evidence carries "I've run the after-school reading club for the last two years" and "I led our grade level's move to a new reading curriculum in 2024". Offer those at their own scope and let her draw the link. Nothing in your material says you ran reading conferences, so none is offered as a shared practice. The two team members are unnamed, so no read is offered for them.

## 5. Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two weeks into the year, you find a fourth grader reading well below grade level. Walk us through what you do first." | CASE | [grounded] | Structure it aloud. Clarify first: what the student's earlier teacher knows, whether a reading plan came with the student, and what assessment results exist. Then the objective, one or two things you would try in the classroom, how you would know it is working, and who you would bring in, including the family. The question needs no claim about your past, so the guidance makes none | F4 and F9 are where reading instruction presses hardest, and the district's belief about reading plans makes this a likely live problem. CASE because it scores structure and clarifying, not a record |
| A2 | "Every school in the district runs a family reading night each term. How would you plan one for a fourth-grade class?" | CASE | [grounded] "I write a weekly email to families" | Objective first: what families should walk away with. Then who does what on the night, how families hear about it (the weekly email you write is a channel your quote carries; say if you would use it), and what you would look at afterwards to judge it. Stay with that one quoted channel and do not describe events you have not run | The family reading night comes from the board's plan (excerpt in Sources) and the beliefs page ties it to families, so F6 and F7 are the rows it draws on. CASE with a CO flavor, because it tests whether you know what the district is doing |
| A3 | "It's the first day with a new class. Which routines do you teach first, and how?" | CASE | [generic] | Pick two or three routines and say why those first, how you teach and practice them, and how you would tell they have stuck. Make no claim about your past here; if a follow-up asks about your own classroom, F5's answer slot applies | The hiring page names classroom routines as a panel topic and F5 has no evidence behind it, so this is the likeliest place a thin answer shows. CASE because it asks for a decision, not a record |
| A4 | "The board adopted a literacy plan in August with a new grades 3 to 5 reading curriculum from fall 2027. What would you want to know about that if you joined the fourth-grade team?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan, then clarify rather than opine: when pilots start, who chooses, what changes in fourth grade, how teachers are supported, how families hear about it. Then one sentence connecting your own experience, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Stop there and ask what theirs looks like. Do not add what the move taught you unless it is something you actually took from it | The plan is current district strategy, read from a search excerpt, and F4 is your nearest evidence. CO because it tests homework at the district's altitude, CASE in delivery |
| A5 | "In grades 3 to 5, how would you fit small-group reading and individual conferences into a week?" | CASE | [inferred] "I've run the after-school reading club for the last two years" | Structure the week aloud: how groups form, how often each is met, how you would keep track, and what the rest of the class does meanwhile. Then, if asked whether you have done this: answer from your own classroom, and if you have not, say so plainly and say what you have run, "I've run the after-school reading club for the last two years." Ask what her building does | Inferred from the principal's public talk, so it is a likely theme rather than a documented question. F4 is the evidence row, and the guidance makes no claim that it carries conferences |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've taught third grade for six years and haven't taught fourth. What would be hardest for you on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | **The deepest rehearsal in this pack.** Move 1, acknowledge plainly: "I haven't taught fourth grade." Move 2, hold only what your material carries: "Six years teaching third grade at a public elementary school in Joliet", said at that scope, with the link to fourth left for them to draw. Move 3, concede specifically. Answer slot: name the part of fourth grade you know least, in your own words; the pack does not choose it for you; if you cannot name one, say so plainly and say what you would ask the team first. Then give your ramp as a plan, never a past, using only steps you would really take. Limit, named before it is asked for: the pack's observation is that your material shows third grade and no fourth-grade content, so the hold is the quoted sentence, not a claim of readiness. If pressed on why not someone who has taught the grade, hold: repeat the acknowledgment, return to the six years, add nothing. If pressed on what happens if the ramp is slow, concede it is real, name your plan's first checkpoint in your own words, and promise no timeline you would not keep | F2 is the pack's biggest gap and the one your own material states, so this arrives in some form. JD because it scores the role as listed; it is the Skeptic's stem about day-one weakness, aimed at the stated gap |
| B2 | "Why Halvering, and why fourth grade now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Give your actual reasons in one or two sentences; the pack does not supply them. A reason that points at something you can name from what you have read of the district, such as the beliefs page or the board's literacy plan, lands better than a general one, but only if it is true for you. If the real reason is something else, say that. Answer slot: if the move is mainly about the grade rather than the school, say so plainly | The Skeptic's motivation stem, scored for consistency; F2 is why "fourth grade now" will be asked. JD because it scores fit with this listed role |
| B3 | "A parent asks why their child's teacher is new to fourth grade. What do you say?" | JD | [grounded] "I've never taught fourth grade"; "I write a weekly email to families" | Acknowledge first, in plain words: "I haven't taught fourth grade." Then what the parent can expect: how you will learn the grade, what you will share with the team, and how the family will hear from you. If you would keep writing the weekly email, say so, because your quote carries it: "I write a weekly email to families." Promise only what you would deliver | B1's objection, moved into the family-facing register that F6 and F7 make likely. JD because it scores how you handle the gap with someone outside the building |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Choose something true and say it plainly, then pair it with a plan and what you would ask of the team. The pack's observation is that F2 and F5 are the two rows your material leaves thinnest; choose from your own sense, not from this list. Do not name a weakness that is really a strength in disguise. Reuse B1's acknowledgment if the weakness is the grade | The Skeptic's standard stem, a second angle on B1's objection. JD because it scores honest self-assessment against the listed role |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our fourth-grade team plans together. Where would you expect the seam to be between your room and ours, and what happens when we disagree?" | VAL | [generic] | Propose seam principles instead of pretending to know their seam: what you would keep consistent with the team and what you would ask about before changing. For disagreement, pick a real time you disagreed with a colleague over how to teach something; it needs a named stake, what you said, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer prior puts seam and disagreement questions first, and F8 is the row they test. VAL because it scores partnership behavior, not a skill |
| C2 | "How do you handle credit when work spans a team?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell it with the beats the sentence states: you led, the grade level's move, a new reading curriculum, 2024. Use "we" for the context and "I" for your contribution, which the quote makes "led". If asked who did which part, say plainly what you can separate and what you cannot; add no detail the sentence does not carry | F8 is the only row about working across a grade level, and the peers will probe credit on it. VAL because it scores how you describe shared work |
| C3 | "What would you need from this team in your first month?" | JD | [grounded] "I've never taught fourth grade"; "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity framing. What you need: concrete things about the grade, tied to your plain acknowledgment, "I haven't taught fourth grade". What you offer: the sentence your quote carries, "I led our grade level's move to a new reading curriculum in 2024", given as something you are glad to talk through given the district's plan, not as a claim about what it taught you | Peers price what a hire costs their work, so lead with what you bring as well as need. F2 and F8 are the rows it draws on. JD because it scores the terms of joining this team |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader: tell us about a time you made sure a student was not left behind as a reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | A selection scaffold, because your sentence names a club and not a student. Pick a time a particular student's reading moved because of something you did; it needs a named stake, what you changed, and what you saw afterwards. The club is a place to look for it, not a story the pack can tell. If any student had a reading plan you wrote or followed, say what it was and what part was yours, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the club you run, or how you would handle it | The first of the district's three published beliefs, F9's requirement. VAL because it scores behavior against a named value, and the open prompt supplies no event |
| D2 | "Families Are Partners: you write a weekly email to families. Tell us about it." | VAL | [grounded] "I write a weekly email to families" | Tell it with the beats the sentence states: weekly, an email, to families, written by you, in your own words. If families replied to the emails or conversations followed, say what happened and what part was yours; if none did, or it was not part of your practice, say so plainly and stay with the weekly email. Do not describe conversations with every family unless that is what you did | The second belief, F6 and F7. VAL because it tests a published value, with the premise limited to what your sentence says |
| D3 | "Teach for Tomorrow, Not for the Test: tell us about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: pick a time results led you to reteach, regroup or change a plan; it needs the result you saw, what you changed, and what happened next. Answer slot: if assessment results ever changed what you taught, say one case in your own words; if they did not, or assessment was handled by others, say so plainly, then say how you would use results as a plan. If no such time comes to mind, say so plainly and say how you would handle it | The third belief, F10, which has no evidence behind it. VAL because the open prompt asks you to choose an instance |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your journey. How did you get here?" | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc, one beat per quoted sentence, in order: the license and endorsement, the six years of third grade in Joliet, leading the grade level's move to the new reading curriculum, the reading club, the weekly email. End on why Halvering and why fourth grade; that reason is yours to give, as B2 says. Add no beat the quotes do not carry | The biography question opens most panels and is scored. F1 and F3 to F8 are the rows it draws on. EXP because it tests whether the arc matches your documented claims |
| E2 | "What's a book you'd put in a fourth grader's hands?" | JD | [generic] | Name a real title you actually know and say why it suits that age, in one or two sentences. If no title comes to mind, say so plainly and say how you would choose one. The pack does not supply a title | The Conversational persona asks casual questions on the topics the role flags, and reading is the district's headline. JD because it scores interest in the listed work |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You led your grade level's move to a new reading curriculum in 2024. How did you know it was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start with the sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if any assessment or student information showed how it was going, say what it was and how you read it, in your own words; if nothing was measured, or you did not see the data, say so plainly and stay with the fact that you led the move. Say plainly where you do not know how something was counted | The district's third belief makes assessment a topic (F10), and the move is the only claim in your material a prober can press (F4). EXP because it tests attribution and whether you know your own evidence |
| F2 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Tell it with the beats the sentence states: after school, a reading club, run by you, for two years, in your own words. If probed for more, answer from what you know and say plainly what you do not | F4 and F9 both lean on the club, so a prober will test it. EXP because it tests your own claim |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 license | E1; no interviewer probe is expected, a gate shown met |
| F2 fourth grade | B1, B3, B4, C3 |
| F3 elementary experience | E1, B1 |
| F4 reading instruction | A1, A4, A5, D1, E2, F1, F2 |
| F5 classroom routines | A3 |
| F6 families | A2, B3, D2 |
| F7 speaking with families | D2, A2 |
| F8 grade-level team | C1, C2, C3 |
| F9 Every Child a Reader | A1, D1 |
| F10 Teach for Tomorrow | D3, F1 |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What from that shapes what you look for in a fourth-grade reading block?" | Ties to the principal's own public path, so it reads as research on her and not only on the district. It also tells you what the reading block is scored against |
| R2 | "In Small Groups, Big Readers you described weekly reading conferences in grades 3 to 5. What does that look like in fourth grade at Halvering, and where would a new teacher start?" | Ties to her published talk and turns A5's likeliest theme into information you can use. It shows preparation for her, not only for the district |
| R3 | "What could a new fourth-grade teacher do in their first month that would genuinely help your team?" | The reciprocity question for the two peers on the panel; it signals you are thinking about their load |
| R4 | "The board's plan has a new grades 3 to 5 reading curriculum from fall 2027. How will the fourth-grade team be involved before then?" | Shows you read the plan and asks where you would fit; the answer tells you whether your F4 and F8 experience will be used |
| R5 | "What does support look like for a teacher who is new to the grade: a mentor, observations, shared planning time?" | Puts the ramp from B1 in their hands, and the answer tells you what your plan can rely on |
| R6 | "What does the family reading night look like at Halvering today, and what do fourth-grade teachers do for it?" | Connects to Families Are Partners, and shows the same homework A2 rehearses |
| R7 | "What would you want to see from me by the end of the first term?" | A plain, specific close that lets you hear their priorities in their words |

## 7. Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative you stated: "I've never been a team lead" — your message | The plain acknowledgment: "I haven't been a team lead." The quote that limits it: "I led our grade level's move to a new reading curriculum in 2024", at its own scope |
| Led the school's or the district's reading curriculum change | Inflated form of F4 and F8 | F4's quote at its own scope. The limit is the pack's observation, not words for you: your material says the grade level's move, not the school's |
| Speaks with every family each term | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says a weekly email, not conversations with every family. D2's slot stays inside the email |

## 8. Sources

**Provided:** the invite text; your résumé text and the two statements in your message ("I've never taught fourth grade", "I've never been a team lead"). Your message also contained a government ID number; it is not needed, was not used, and appears nowhere in this pack or any search.

**Searches sent (5):**

1. "Orrinsford Community School District mission values" — returned https://orrinsfordschools.example/about/mission-and-beliefs
2. "Halvering Elementary School Orrinsford fourth grade teacher interview process" — returned https://orrinsfordschools.example/careers/how-we-hire-teachers
3. "Orrinsford Community School District news strategic plan" — returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. "Dolores Vantongeren principal Halvering Elementary" — returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. "fourth grade teacher job posting Illinois elementary school responsibilities qualifications" — returned https://k12jobsboard.example/listings/fourth-grade-teacher

**Pages fetched (2):** the mission-and-beliefs page and the how-we-hire-teachers page, both read in full. The literacy plan news item and the principal's speaker page were read only as search excerpts; the job-board listing's excerpt was cut off mid-sentence, so nothing from it is quoted in the pack.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Three beliefs by name; F7, F9, F10 and the whole of bank D |
| 2. Interview process | yes | Loop established: one 45-minute building panel, principal plus two grade-level teachers; persona weights, section 3 |
| 3. Strategy / recent news | yes | One search; excerpt only: the August board literacy plan with a new grades 3 to 5 reading curriculum from fall 2027 and a family reading night each term. Moved A2, A4, R4, R6 |
| 4. Interviewer footprint | yes | Name given, one search; excerpt only. Moved section 4, A5, R1, R2 |
| 5. Representative JD | yes | One search; the excerpt was truncated and was not fetched, so it moved only the wording of the two unquoted role-family rows F3 and F8, both labeled `[generic]` |

## 9. Upgrade menu

- The full posting text → F3 and F8 become quoted `[grounded]` rows, any duty the posting names, a team-lead role included, gets its own row and question, and the `[generic]` coverage in section 5 tightens
- Anything HR said about the panel, such as a sample lesson or writing sample → a graded-deliverable build section
- The names of the two team members → an interviewer read and persona weights per panelist
- Your answers to the slots in F4, F5, F7, F9 and F10 → those rows move from `discovery` or `transferability` toward quoted stories, and bank rows A3, D1, D2, D3 and F1 regenerate from them
- The issuer's own record of your license → F1's confidence moves from `medium` to `high`
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the literacy plan read from the full page, and a fuller read of the principal's public talks and writing
- A `tuesday-dossier.md` from an earlier engagement → verified evidence and a prohibited-claims list for the pack to be built against
