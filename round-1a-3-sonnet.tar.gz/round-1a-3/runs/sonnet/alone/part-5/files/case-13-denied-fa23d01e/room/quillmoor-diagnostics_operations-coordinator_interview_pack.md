# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner. Relationship: recruiter screen, a 30-minute phone call on Thursday at 2pm, Hannah ringing the mobile number on your application. Her stated agenda, in her words: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and the next steps.

Assumption this pack was built on: Hannah's own words establish this one call and nothing about later rounds, so nothing here assumes a later loop. Search was refused in this session, so everything about Quillmoor comes from the advert you pasted.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None here: no values-style round is detected for this call |
| EXP | Whether your claims survive scrutiny and what was actually you |
| JD | Whether you meet the listed job and its terms, gaps included |
| CO | Knowledge of the company and its strategy. None here: it needs research, which was refused |
| CASE | Structure and reasoning on a live problem from the role |

A recruiter screen is scored even when it sounds like a chat. The four things Hannah named are questions A1 to A4.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material shows scheduling deliveries, not scheduling production, and the words stay at the quote: "I schedule deliveries for our three depots." Answer slot: if any of that scheduling meant agreeing dates with other teams, say which teams and what you agreed, in your own words; if it did not, or it was not yours, say so plainly and stay with the three depots |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote reaches the chasing in role-relevant terms. Lead with it as you said it: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Say it as you said it. A figure invites a probe; the slots for it are in C1 and E2 |
| F5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says a spreadsheet, and does not show which tool it was built in or what you did in it. Answer slot: say which tool and what you did in it, in your own words; if the work was not in that tool, or was not yours, say so plainly and stay with the rebuild |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and return to the stock-count rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | The SAP half is a gap you stated, and the advert marks ERP as a plus. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | The quote says your employer runs an in-house stock system, not whether you work in it or whether it counts as similar. Answer slot: if you work in that system yourself, say what you do in it, in your own words; if you do not, or it is not yours to describe, say so plainly and stay with the quote |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Say it as you said it, a hope, with nothing added. The figure is inside the advert's band |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Say it in your own words at that scope. The advert's pattern is two days, and your sentence already covers it |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Your material gives no notice period. Answer slot: give your actual notice period, in your own words |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it in those terms: the office closing next year, the only offer being relocation to Reading, and that you don't want it. Nothing is added about your employer |

## Persona table

Weights start from the relationship prior for a recruiter screen (conversational, with a light Skeptic) and are adjusted only by Hannah's quoted agenda. The loop beyond this call is not established, so no later-round weighting is assumed.

| Persona | How it shows up | Likelihood and reasoning | Provenance | Counter-strategy |
|---|---|---|---|---|
| A. Conversational / Rapport | Friendly, unstructured; her four named topics arrive as chat | Highest. Her agenda is logistics plus motivation, which is what the recruiter prior predicts, and a friendly register is still scored | [generic] | Settle your own wording for each logistics answer beforehand (A1 to A4), and a 90-second arc built only from your quoted sentences (A5) |
| B. Skeptic | Quiet knockout checks against the advert's list: the production-scheduling duty, SAP, why this employer | High enough to need the deepest rehearsal: the advert lists duties and tools and a screen checks them | [generic] | Rehearse B1 until it is boring; hold what your quotes carry and let the gap be said plainly (B1 to B5) |
| C. Data-Driven Prober | Asks how your one figure was counted | Medium-low. One figure is in your material and a recruiter may ask about it once, lightly | [generic] | Know what you can and cannot say about how it was counted, and say plainly when you do not know (C1 to C3) |
| D. Case / Strategist | A short live problem from the role | Low. Recruiters seldom run cases, but the advert's tasks suit them and the style should not be met first live | [generic] | Clarify, then structure, then answer; think aloud (D1 to D3) |
| E. Pressure | Time-boxed challenge: why you, how much was you | Low in a friendly call, with a brief appearance possible when she tests motive | [generic] | Pause, restate, hold through two follow-ups, concede only what is true and specific (E1, E2) |

## Question banks

Highest-ROI prep in this pack: B1. It is the question your material is thinnest on, and the one an advert-led screen reaches first.

### A. Conversational / Rapport (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations for this role?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled in your own words: "I'm hoping for £42,000." Say it plainly and stop. If current or past pay comes up, you can decline or redirect to the advert's band, with no figure | F9 is the first topic on Hannah's list. JD because pay is the listed job's term |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. The pack supplies no figure | F11 is on her list and your message does not give one. JD because it concerns the job's start terms |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled in your own words at its scope: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If the commute or the day count is probed, your own words were that sentence, with nothing added | F10 is a term of the listed job and the one Hannah named second. JD because the advert sets the pattern |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, filled in your own words at its scope: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say the beats the sentence states and add nothing about how your employer handled it. If Reading is probed, your own words were: "the only offer is relocating to Reading, which I don't want" | F12 is the reason-for-leaving question every screen asks. EXP because it tests what is actually your situation |
| A5 | "So, walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F1 and F3: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for the three depots; chasing suppliers when orders slip. Tell those beats in your own words in about 90 seconds, then hand to your reason for looking (A4) | The conversational opener is where an unscripted answer rambles. EXP because it tests what you did, and the arc stays inside F1 and F3 |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules between planning, the warehouse and QA. Your work is scheduling deliveries. How do the two compare?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal. Hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation, not words for you: your material shows delivery scheduling, not production scheduling. Answer slot: if any of that scheduling meant agreeing dates with other teams, say which teams and what you agreed; if it did not, or it was not yours, say so plainly and stay with the three depots. Follow-up one, whether you have worked in a manufacturer: the same slot, answered from your own work or by saying it was not yours. Follow-up two, what you would need to learn: say it as a plan, never as a past. Follow-up three, why you over someone from that background: return to the quote's beats and add nothing | F2 is the widest gap between the advert's headline duty and your quoted work, so this objection arrives in some form. JD because it scores the first listed duty, Skeptic because it probes the gap |
| B2 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment, from your own sentence: "I've never used SAP." Then the other half at its scope: "we run our own in-house stock system." Answer slot: if you work in that system yourself, say what you do in it, in your own words; if you do not, or it is not yours to describe, say so plainly. Do not call it an ERP unless you would say so yourself. The advert marks ERP as a plus | F7 and F8 are the advert's one named tool. JD because it is a listed plus; the stated negative makes the honest answer short |
| B3 | "Why Quillmoor, and why this role?" | JD | [grounded] | Selection scaffold. Name the part of the advert that draws you and why, in your own words. The advert's own lines include "track supplier deliveries and chase late orders" and "keep stock records accurate", which your quotes touch in F3 and F4. If no particular reason comes to mind, say so plainly, then say what in the advert made you apply | F12 covers why you are looking, not why this employer, so a screen asks it separately. JD because it ties to the advert; Skeptic because it tests motive |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Choose a gap you can name truthfully. The SAP one has your own words: "I've never used SAP." Say how you would learn it as a plan, never a past. For any other gap, the answer slots in B1, C2 and C3 apply: answer from your own work, or say plainly it was not yours | F7 is the gap you have stated. JD because it scores the listed requirements |
| B5 | "Would three days a week at Avonmouth ever work?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words were "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Say that, with nothing added in either direction | F10 is a term of the listed job, and a screen tests a stated limit once. JD because it concerns the job's terms |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold at the quote's scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Answer slots, each in your own words: how it was counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. Where you do not know how it was counted, say so plainly | F4 holds your only figure, and a figure is the likeliest thing probed. EXP because it tests attribution and method |
| C2 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say which tool the spreadsheet was built in and what you did in it, in your own words; if the work was not in that tool, or was not yours, say so plainly and stay with the rebuild | F5 is the advert's tool requirement and the quote does not name one. JD because it scores a listed requirement |
| C3 | "Tell me about any reporting you've done on deliveries or dispatch." | JD | [grounded] | Answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and return to "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | F6 is the advert's weekly reporting duty, with no quote behind it. JD because it scores a listed duty |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that a key delivery will be a week late, and production is due to start on Wednesday. What do you do?" | CASE | [generic] | Structure it: what you would ask first (what is late, by how much, what depends on it, whether part can arrive sooner or an alternative exists); the objective; the options; who you tell and when (planning, the warehouse, QA); what you record and report. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing and scheduling lines. CASE because it asks for reasoning, not history |
| D2 | "The system says there are 120 units of an item and the count shows 112. What do you do first?" | CASE | [generic] | Structure it: record the discrepancy before correcting it; clarify what could explain it (unbooked movements, a pending delivery or pick); check; correct with a note; look for a pattern. No claim about your past | A live problem from the advert's stock-records line. CASE because it is a decision, not a record |
| D3 | "Three orders are late at once and you can chase only one first. How do you choose?" | CASE | [generic] | Say your criteria aloud: what each delay stops, how much time is left, whether alternatives exist, who is waiting. Name the one you would chase first and why, and say how you would tell the people affected by the others. No claim about your past | A prioritisation problem from the advert's chasing duty. CASE because it scores structure |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I put you forward?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler", "I schedule deliveries for our three depots and chase suppliers when orders slip." and "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Lead with those three beats in your own words: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; the stock-count rebuild and the fall in discrepancies. Hold through two follow-ups by returning to them, never by adding to them. Concede the one gap you have stated: "I've never used SAP." | F1, F3 and F4 are the quoted material a short pitch can rest on. EXP because it tests what you can say you did |
| E2 | "How much of that stock-count result was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the quote carries: "I rebuilt our stock-count spreadsheet." Answer slot: say which part of the fall you attribute to the rebuild and which to anything else, in your own words; if you do not know, say so plainly and stay with the rebuild | F4's figure invites an attribution probe, and a Pressure interviewer asks it bluntly. EXP because it tests attribution under pressure |

### Requirement coverage

| Advert or recruiter requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A5, E1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, D1, D3 |
| Track supplier deliveries and chase late orders | A5, D1, D3 |
| Keep stock records accurate | C1, E2, D2 |
| Report weekly on on-time dispatch | C3 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2, B4 |
| £38,000–£44,000 | A1 |
| Hybrid: two days a week at Avonmouth | A3, B5 |
| Notice period (Hannah's topic) | A2 |
| What's prompting a move (Hannah's topic) | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "After this call, what does the process look like, and who would I meet in what format?" | Hannah said she would cover next steps, so ask only for what she leaves out; it lets you prepare for the right kind of round |
| R2 | "Where does this role sit between planning, the warehouse and QA, and who would I work with most day to day?" | It follows the advert's own duty line and shows you are thinking about the role's seams |
| R3 | "How are the two Avonmouth days usually set: fixed days for the team, or agreed with each person?" | It is a practical question about the advert's hybrid pattern, and it is one you can ask without moving off your own stated position |
| R4 | "Which systems does the team use for stock and scheduling, and how does training work for them?" | The advert says "SAP or similar" is a plus; this lets the system question be answered on your terms |
| R5 | "How is on-time dispatch reported today, in what format, and who reads it?" | It ties to the advert's weekly reporting duty and tells you what you would be handed |
| R6 | "What would a good first three months look like in this role?" | It is a standard close that shows you thinking about delivery, and the answer shapes your next round |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP or another ERP | Negative you stated, F7 | The plain acknowledgment: "I've never used SAP." The pack's own observation: your material does not say whether you work in the in-house system or whether it counts as similar, so B2's slot stays inside that quote |
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: the material says delivery scheduling, not production scheduling |
| Confident or advanced with Excel | Inflated form of F5 | The quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The material says a spreadsheet, not which tool |
| My rebuild cut discrepancies by a third | Inflated form of F4 | The quote as you said it, at its own scope. C1 and E2 ask only how it was counted and which part was yours |
| I was made redundant | Inflated form of F12 | The quote at its own scope: the office closing next year, the only offer being relocation to Reading. The material says nothing of redundancy |
| Open to more than three days a week at Avonmouth | Claim your quote contradicts, F10 | The contradicting quote alone: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |

## Sources

Provided documents: the advert text you pasted; your message describing your background and what you would tell Hannah; Hannah's LinkedIn message as you quoted it. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused:

- "Quillmoor Diagnostics company values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth Bristol news" — refused
- "Hannah Lowther Quillmoor Diagnostics Talent Partner" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The call was refused. It would have supplied official value names; no values-style round is detected for this call, so no values sheet is built |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | The call was refused. It would have named later rounds and moved persona weights beyond this call |
| 3. `Quillmoor Diagnostics Avonmouth Bristol news` | unavailable | The call was refused. It would have fed a CO question grounded in current strategy; D1 to D3 are `[generic]` instead |
| 4. `Hannah Lowther Quillmoor Diagnostics Talent Partner` | unavailable | The call was refused. It would have supported an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or Quillmoor's values page or careers page pasted → official value names, any documented later rounds, and a CO question grounded in current strategy
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, if search is allowed → a grounding brief and a fuller interviewer read
- Your notice period, in your own words → fills A2's slot and quotes into F11
- Which tool the stock-count spreadsheet was built in, and whether you work in the in-house stock system yourself → F5 and F8 move from `discovery` toward grounded rows
- Whether any of your scheduling involves agreeing dates with other teams, and whether you report on deliveries or dispatch → F2 and F6 move off their answer slots
- Your CV, or the stock-count spreadsheet or a discrepancy log → F4 moves from `medium` toward `high`, and the evidence cells quote your CV instead of your message
- Hannah's LinkedIn profile text, pasted → an interviewer read and a reverse question tied to her path
- A `tuesday-dossier.md`, if you have one → verified evidence and any claims to avoid carried into the banks
