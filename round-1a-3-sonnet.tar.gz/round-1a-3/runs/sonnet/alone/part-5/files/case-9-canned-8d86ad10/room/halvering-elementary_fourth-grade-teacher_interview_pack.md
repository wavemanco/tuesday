# Interview pack — Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Round:** one 45-minute panel on Thursday — Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built on this assumption:** a single panel, as the invite and the district's hiring page both describe it; no posting text and no HR guidance on format were supplied.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your own claims survive a follow-up; what was actually you |
| JD | The listed job: can you do it, including where you are thin |
| CO | Homework: what you know about this district and how it talks |
| CASE | A live problem from the role, reasoned aloud |

Answer slots in the guidance are instructions for the interview, not questions for you now: each gives two honest branches, and either is a good answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The material shows the gate met: the kind, the state, the endorsement and the expiry are all stated, and the stated grades 1–6 include fourth. Nothing was inspected here; looking up your license record is yours to do before Thursday, and the license number is not needed or used in this pack. Say it in the quote's own terms: you hold the Illinois PEL with the Elementary Education endorsement, registered and active through June 30, 2029 |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then the adjacent sentence at its own scope: "I have six years teaching third grade at a public elementary school in Joliet." Then how you would get ready, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a curriculum move and a club, not day-to-day reading teaching, with nothing inspected behind either. Words stay at that scope: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Answer slot: the page lists reading instruction, so expect a probe on how you teach reading day to day. If that is where your reading work sits, say how in your own words; if the move and the club are where it sits, say so plainly and stay with them |
| F4 | "no student leaves third grade without a reading plan" — district mission page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | discovery | The belief is about the grade you teach, and your material does not show whether reading plans were part of it. Answer slot: expect a probe on reading plans for third graders. If you wrote or used them, say how, in your own words; if there was no such plan, or it was not yours, say so plainly and return to the six years |
| F5 | "how you work with families" — district hiring page | "I write a weekly email to families." — your CV | medium | [grounded] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with the email in the quote's own terms: you write it, weekly, to families |
| F6 | "each teacher speaks with every family each term" — district mission page | "I write a weekly email to families." — your CV | low | [grounded] | transferability | An email is not a conversation, and the quote says the email. Words: "I write a weekly email to families." Answer slot: expect a probe on speaking with families. If you speak with families in conferences, calls or meetings, say how and how often, in your own words; if you do not, or not with every family, say so plainly and say what you would set up |
| F7 | "classroom routines" — district hiring page | none given | none | [grounded] | discovery | Your material is silent on routines. Answer slot: expect a probe. If you have routines you use, describe them in your own words; if routines were set by the school, or you do not use any, say so plainly and say what you would set up in a fourth-grade room |
| F8 | "assessments inform teaching and never replace it" — district mission page | none given | none | [grounded] | discovery | Your material is silent on assessment. Answer slot: expect a probe on how assessment shapes what you teach. If any assessment result has changed what you taught, say what and how, in your own words; if none has, say so plainly and say how you would want results to inform teaching |
| F9 | Work as a member of a grade-level team — representative fourth-grade posting found by search, not this employer's, so unquoted | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | low | [inferred] | transferability | The move is adjacent work at the grade-level, at its own scope, and you have said you have not been a team lead. Words: "I led our grade level's move to a new reading curriculum in 2024." If team leadership comes up: "I haven't been a team lead." Nothing here supplies how the move was run |

## Reading the interviewer

Public professional footprint only. The panel's two team members are unnamed, so this covers Principal Vantongeren.

| Observation | Source | Provenance | Practical implication (this pack's reading) |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | ilprincipalsforum.example listing, from a search result; the page itself was not opened | [grounded] | Reading instruction is her home ground, so questions on it are likely to go a level deeper than the first answer. Keep every reading answer at what you actually did |
| 2025 forum talk "Small Groups, Big Readers", which covered weekly reading conferences in grades 3 to 5 | same listing | [grounded] | Her topic spans the grade you teach and the grade you want; B2 and R2 are built around it. Mention conferences only if it is how you actually work |
| Mirror: her talk covers grades 3 to 5 | same listing, paired with F2's evidence | [grounded] | Your side of the overlap is "Six years teaching third grade at a public elementary school in Joliet", said at that scope and no wider |
| Mirror: shared subject of reading | same listing, paired with F3's evidence | [grounded] | Your side is "I've run the after-school reading club for the last two years", said at that scope |

## Persona table

The district's hiring page names one panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and family work. Weights come from that panel mix and your material, shown so you can recalibrate.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | The principal or a teammate probing the fourth-grade gap and the move | High: F2 is a stated gap, and a panel hiring for fourth grade will reach it | Rehearse the plain acknowledgment until it is boring; hold the two sentences; give the plan as a plan |
| Case/Strategist (bank B) | Live classroom problems from the principal, plus district-vocabulary questions | High: the hiring page lists reading instruction, routines and families, which are problems more than biography | Clarify first, then objective, approach, how you would check, risks; use the district's own phrases |
| Peer Evaluator (bank C) | The two fourth-grade teachers asking about working beside them | High: two of three panelists are teammates, and F9 is thin | Reciprocity framing: what you would ask of them and what you carry; no pretending to know their seams |
| Values/Behavioral (bank D) | Stories tied to the three published beliefs | Medium: the page names beliefs that guide hiring, but names no values round, so none is detected | Pick stories only where a sentence of yours carries them; otherwise the scaffold and its honest branch |
| Conversational (bank E) | Warm openers: the journey, what you are reading | Medium: the opening minutes of any panel; still scored | A 90-second arc built only from your sentences |
| Data-Driven Prober (bank F) | A teammate asking how you know the move or the club worked | Low: your material gives no figures to probe, so the probe lands on method | Say what you looked at, or say plainly you did not measure it |
| Pressure | Time-boxing or devil's advocacy | Low: nothing in the district's description suggests it; no bank | Pause, restate, hold the sentence |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What makes you ready for it?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | **Highest-ROI prep in this pack.** Open with the plain acknowledgment: "I haven't taught fourth grade." Then the adjacent sentence at its own scope: "I have six years teaching third grade at a public elementary school in Joliet." Then a plan, said as a plan: what you would ask the fourth-grade team first and what you would learn in the first weeks, in your own words. Follow-up one, "third grade isn't fourth grade": agree, and return to the two sentences. Follow-up two, "what don't you know yet": name one thing about fourth grade you would need to learn, in your own words, and stop. Hold the acknowledgment and the six years through both; add no fourth-grade experience to ease the moment | F2 is the stated gap and the objection most certain to arrive in some form; JD because the position is the fourth-grade job; Skeptic because it probes the gap |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Name the limit the position makes live: "I haven't taught fourth grade." Then what you would do about it, as a plan. Do not volunteer a second weakness. If leadership is raised, the sentence is "I haven't been a team lead", followed by "I led our grade level's move to a new reading curriculum in 2024" at its own scope | F2 and F9 hold your two stated limits; JD because it scores honest self-assessment against the job, Skeptic stem |
| A3 | "You led your grade level's move to a new reading curriculum. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence: "I led our grade level's move to a new reading curriculum in 2024." Note its own words call it the grade level's move. Answer slot: say which part was yours, in your own words; if the move was shared throughout, or someone else made a decision you would otherwise be credited with, say so plainly and return to the sentence. Hold through two follow-ups by returning to it, never by adding to it | F3 and F9 both rest on this sentence, so it is where an attribution probe lands; EXP because it tests what was yours |
| A4 | "Why fourth grade, and why now?" | EXP | [generic] | Answer slot: give your own reason for the move, in your own words; the material carries none and this pack supplies none. Choose one reason you would repeat unchanged at a second follow-up; if the honest reason is mixed, say so plainly | The Skeptic's motivation stem; F2 shows the move is a change of grade, and the material is silent on why. EXP because it tests consistency of your story |
| A5 | "Our first belief says no student leaves third grade without a reading plan. What did reading plans look like for your third graders?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: if you wrote or used reading plans for third graders, say how, in your own words; if there was no such plan, or it was not yours, say so plainly and return to "I have six years teaching third grade at a public elementary school in Joliet." The honest branch is a limit, not a confession | F4: the belief is about your current grade, so a probe is likely; VAL because the premise is a published belief |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A fourth grader reads well below the rest of the class and goes quiet in group work. It is October. What do you do in the first two weeks?" | CASE | [generic] | Clarify first: what do you already know about the student, and what do the family and the previous teacher see. Then the objective, one or two things you would try, how you would check whether they help, and who you would bring in. Use the district's phrase, "assessments inform teaching and never replace it", as a frame for how results would shape the plan. Think aloud; challenge one premise politely. The question asks about no past of yours, so the guidance makes none | F7 and F8 are silent in your material, and a live problem lets you show reasoning where there is no quote; CASE because it is live, JD content |
| B2 | "Plan a week of reading instruction for a class with a wide range of reading levels. What do you need to know first?" | CASE | [generic] | Ask what you need first: the range, what data exists, the block length. State the aim of the week, then a structure, then how you would tell it is working, then the risk you would watch. If your plan includes meeting with individual readers, say so only if that is how you would work; the principal's public talk was on weekly reading conferences, and an echo you do not mean will not survive a follow-up | F3 is the thinnest reading evidence and the principal's background is reading; CASE with JD content |
| B3 | "Walk me through how the day starts in your room." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: if you have a routine for the start of the day, describe it in your own words; if routines were set by the school, or you do not use one, say so plainly and say what you would set up in a fourth-grade room. Name one routine and why it matters, not a list | F7: the hiring page lists classroom routines and the material is silent; JD because routines are a stated panel topic |
| B4 | "What do you know about how Orrinsford approaches reading and families?" | CO | [grounded] "I write a weekly email to families." | Bring the three beliefs by their published names: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Give each the page's own gloss: "no student leaves third grade without a reading plan", "each teacher speaks with every family each term", "assessments inform teaching and never replace it". Then one tie to your sentences, at its own scope: "I write a weekly email to families." Do not say it is speaking with every family each term | F5 and F6 are the evidence; CO grounded in the district's own page, which a candidate can be quizzed on by name |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you and a teammate disagreed about how to teach something." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: pick a time with a named disagreement, your position, how it ended and an intact working relationship. "We" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I led our grade level's move to a new reading curriculum in 2024", at that scope, without adding that anyone disagreed | F9: the team is two of the three panelists; EXP with a Peer stem on disagreement style |
| C2 | "What would you want from our team in your first month, and what would you bring us?" | EXP | [grounded] "I've never taught fourth grade"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | Two halves. What you would ask of them: the ramp, said as a plan, since you have not taught fourth grade. What you bring, at the quotes' own scope: "I've run the after-school reading club for the last two years" and "I write a weekly email to families." Offer nothing the sentences do not carry | F2 and F9 are the thin rows; the reciprocity framing turns the gap into a shared plan; EXP because it tests partnership fit |
| C3 | "How do you handle credit when work spans teachers?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what was yours and say it was the grade level's move: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say what others did, in your own words; if you do not know how the work divided, say so plainly and return to the sentence | F3 and F9 share this sentence; the Peer stem on credit probes the same attribution as A3 in collegial dress |
| C4 | "A family has not heard from you and their child is struggling. How do you reach out?" | CASE | [grounded] "I write a weekly email to families." | Structure it: what you would find out first, how you would contact them, what you would say, how you would follow up. Then your sentence at its own scope: "I write a weekly email to families." Answer slot: if you speak with families in conferences, calls or meetings, say how, in your own words; if you do not, or not with every family, say so plainly and say what you would set up | F6: the belief is speaking with families, the quote is an email; CASE, JD content |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader: tell me about a time a student who was not reading well made progress with you." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick a student, what you tried, what changed, and what you would do again; each of those is yours to name. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years", at that scope, adding no result | F3: the belief is the district's first; VAL because it asks for a specific decision, not the slogan |
| D2 | "Families Are Partners: tell me about a time you worked with a family to help a student." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: pick a student, the concern, what the family did, and how it ended; "we" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing, "I write a weekly email to families", at that scope | F5 and F6; VAL tied to the second belief |
| D3 | "Teach for Tomorrow, Not for the Test: tell me about a time assessment data changed what you taught." | VAL | [generic] | Selection scaffold: pick a time you changed a lesson, a group or a plan after seeing results, naming what you saw and what you changed. If no such time comes to mind, say so plainly, then say how you would want results to inform your teaching, as a plan rather than a past | F8: no sentence of yours carries a story here, so the scaffold and its honest branch are the whole answer; VAL tied to the third belief |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey. How did you get here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc built only from three sentences, in order: "Six years teaching third grade at a public elementary school in Joliet", the move, the club. Add your own reason for moving to fourth grade in your own words. If you want a beginning before the six years, it is yours to supply; the material carries none | F2 and F3; the biography question is where a prepared arc replaces a ramble; EXP because it tests whether the story is consistent |
| E2 | "What are you reading with your club these days?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: name a real book or approach you actually use; this pack supplies none. If the club is between books, or you would rather talk about what you read with students more widely, say so plainly. Keep it to one title and why | F3; JD because a casual question on a hot topic is still scored |
| E3 | "What goes into your weekly email to families?" | JD | [grounded] "I write a weekly email to families." | Answer slot: say what you actually put in it, in your own words; if the contents vary, say so plainly. Do not describe it as more than the quote: you write it, weekly, to families | F5; the email is your most concrete family-facing sentence, so it is the likeliest to be unpacked |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How would you know whether the move to the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: say what you looked at, in your own words; if nothing was measured, or it was not yours to measure, say so plainly and say what you would look at. Never state a result the quote does not carry | F3; the sentence has no figure, so the probe lands on method; EXP |
| F2 | "How many students come to the reading club, and what do they do there?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: say the number and what happens if you know them, in your own words; if you do not know the number, say so plainly and describe the club as you ran it. Only a figure you can repeat unchanged at a second follow-up | F3; asked for a denominator the sentence does not give; EXP |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| Illinois PEL with an elementary endorsement (invite) | — none, and why: the material shows it met and no panel topic names it; the check is the look-up of your license record |
| Fourth Grade Teacher position | A1, A2, A4 |
| reading instruction | A3, A5, B2, D1, F1, F2, E2 |
| no student leaves third grade without a reading plan | A5, D1 |
| how you work with families | B4, C4, D2, E3 |
| each teacher speaks with every family each term | B4, C4 |
| classroom routines | B3 |
| assessments inform teaching and never replace it | B1, D3 |
| Work as a member of a grade-level team | C1, C2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal here. What do you look for in a fourth-grade reading block?" | Ties to her own public path and hands her the floor on her home ground |
| R2 | "I came across your talk, Small Groups, Big Readers. What do weekly reading conferences look like in a fourth-grade classroom here?" | Shows you read her public work and links your gap to a concrete practice you could learn |
| R3 | "What would you like a new fourth-grade teacher to have learned by the end of the first month?" | Turns the stated gap into a ramp the panel defines, and shows you plan to close it |
| R4 | "What could a new teammate do in their first month that would genuinely help your team?" | Reciprocity question for the two fourth-grade teachers: asks what you can give, not only what you need |
| R5 | "The district says each teacher speaks with every family each term. How does that show up at Halvering?" | Uses the district's own words and asks how the belief is practised |
| R6 | "How do your grade-level meetings use assessment results?" | Picks up the third belief and asks about the team's real habit |
| R7 | "I read that references are taken up after the panel. What comes next, and when?" | Process clarity, grounded in the district's hiring page |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has equivalent fourth-grade experience | Negative you stated, F2 | "I haven't taught fourth grade." with "I have six years teaching third grade at a public elementary school in Joliet." at its own scope. No slot |
| Has been a team lead, or led the grade-level team | Negative you stated, F9 | "I haven't been a team lead." The move quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Chose, designed or wrote the new reading curriculum | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says the move, not the choice or the design. A3's slot stays inside the move |
| The curriculum move or the reading club improved student reading | Inflated form of F3 | F3's quotes at their own scope. The limit is the pack's observation: the material states a move and a club, with no result. F1's slot asks only what you looked at |
| Speaks with every family each term | Inflated form of F6 | "I write a weekly email to families." The limit is the pack's observation: the quote is an email, not a conversation |

## Sources

Provided documents: the invite as pasted, and the resume as pasted. No dossier was in hand. A government ID number in the pasted material was not used.

Searches and fetches sent, by query:

- Search: "Orrinsford Community School District values mission" — returned https://orrinsfordschools.example/about/mission-and-beliefs
- Search: "Orrinsford Community School District Halvering Elementary School" — no results
- Search: "Dolores Vantongeren principal Halvering Elementary" — returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- Search: "fourth grade teacher interview panel questions Illinois elementary" — returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- Search: "fourth grade teacher job description Illinois elementary school responsibilities qualifications" — returned https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch: https://orrinsfordschools.example/about/mission-and-beliefs — read
- Fetch: https://orrinsfordschools.example/careers/how-we-hire-teachers — read

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three beliefs by name, F4, F6 and F8, banks A5, B4 and D |
| 2. `Orrinsford interview process fourth grade teacher` | yes | The loop: one 45-minute building panel of the principal and two grade-level teachers; persona weights follow it. No values-style round is documented, so no values cheat sheet is built |
| 3. `Orrinsford strategy` / recent news | yes | The search sent for district and school context returned no results; recent context is not established and nothing from it is used |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | The interviewer read and R1 and R2; the listing was read as a search result only, as the fetch budget went to the two district pages |
| 5. representative `fourth grade teacher` JD | yes | F9 only, as unquoted prose labeled inferred; the result was a search snippet and raises no answer slots |

## Upgrade menu

- The posting text → F9 and the other prose-only requirement become grounded rows, and the JD-tagged questions are rechecked against its own list
- Anything HR said about format, such as a sample lesson, a presentation or named topics → a build section for each declared deliverable, and persona weights retuned
- Your own answers to the answer slots, stated outside a drill → F3, F4, F6, F7 and F8 move from discovery toward real evidence, and the rows that draw on them regenerate
- A past weekly family email with names removed, or the reading curriculum adoption document → F3, F5 and F6 can move from medium toward high by giving something inspectable behind the claim
- Your license record, which only you can look up → F1 can move from medium toward high
- Names of the two fourth-grade team members → an interviewer read for each and persona weights per seat
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → the principal's talks and writing, recent district context and role-family loop reports
- A `tuesday-dossier.md` from an earlier evidence review → verified claims and a prohibited-claims list that would constrain the guidance
