# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager (no name given); relationship to the role not stated. Format: 30-minute video call, one session, in your invite's words. Built as a hiring-manager-style round with a conversational tilt, because the relationship was not stated.

## How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the employer's published values. No values round is detected here, so no VAL questions appear |
| EXP | Whether what you said about your experience survives follow-up; what was actually you |
| JD | Whether you can do the listed duties, gaps included |
| CO | What you know about the company and its strategy. None appear: company research could not run |
| CASE | A live problem set in the role, answered by structuring it aloud |

An answer slot is an instruction for the interview, not a question for you now. Where a slot gives two branches, either honest branch is a good answer.

## Fit snapshot

Requirements are quoted from the ad as you described it in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: "I ran the appointment book for four physios." Nothing is inspectable behind it, so expect a probe. Your material gives an appointment book for four physios and no wider scope, so stay at that scope |
| F2 | "booking travel" — the ad, in your message | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the ad's booking-travel line makes a probe likely. If you have booked travel or similar arrangements for anyone, say what and for whom, in your own words; if you never did, or it was not yours, say so plainly and say how you would learn it |
| F3 | "preparing documents in Word and Excel" — the ad, in your message | "I'm good with Word" — your message | medium | [grounded] | none | Lead with the quote: "I'm good with Word." It is a self-rating with nothing inspected behind it, so expect a request for an example. Answer slot: if asked for one, name a document you prepared in Word, in your own words; if none comes to mind, say so plainly and say what you are comfortable doing in it |
| F4 | "preparing documents in Word and Excel" — the ad, in your message | "okay with Excel" — your message | medium | [grounded] | discovery | The quote touches the requirement without showing how far it reaches, and the words stay at "okay". Answer slot: expect a probe on what you actually do in Excel. Say what you have used it for, in your own words; if it is only basic, say so plainly and say what you would learn first |
| F5 | "processing supplier invoices" — the ad, in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, and the words stay there: "I chased unpaid invoices." Answer slot: if you handled other invoice tasks at the clinic, say which and what part was yours, in your own words; if the invoice work was the chasing and nothing else, say so plainly and stay with the chasing |
| F6 | "Remote Administrative Assistant" — the invite, in your message | none given | none | [grounded] | discovery | Your material does not show whether any of your work was done remotely or without someone beside you. Answer slot: if it was, say how you organised it, in your own words; if not, say so plainly and say how you would organise a working day |

## Persona table

The loop is one 30-minute video call with the office manager, per your invite's words, so no archetype fallback is needed. Whether this person would be your day-to-day manager is not stated, so the weights below are a hiring-manager prior with a conversational tilt, and flat where the evidence is silent.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Small live problems from the duties: a diary clash, a travel booking, an invoice that does not match | High. The ad lists four practical duties and a 30-minute call has room for a few quick scenarios; hiring-manager prior | Clarify first, then structure, then answer; think aloud; say what you would record |
| B. Skeptic | Quiet probing of the gaps: invoices, Excel, travel, remote working, why move | High. F2, F4, F5 and F6 are where the material is thin, and a hiring-manager prior puts the gaps first | Rehearse the single most likely objection (B2) until it is boring; return to what your quotes carry; give a plan for the rest |
| C. Conversational | Friendly biography and "what do you like" questions | Medium-high. An admin call from an office manager often opens casually, and casual questions are still scored | A 90-second arc from your own sentences; treat Excel and Word chat as scored |
| D. Data-Driven Prober | Reads your lines closely: what exactly "ran the appointment book" involved | Medium. The call is short, but any specific claim you make can be followed two levels down | Know what was yours and what was shared; say plainly what you do not know |
| E. Pressure | A time-boxed "why you" or "how much was you" | Low-medium. Possible in a short call, less likely for this level of role | Pause, restate, hold the position through two follow-ups, concede specifically |
| P. Peer Evaluator | "What do you need from us" and "who goes first" collaboration questions | Low. It applies only if the interviewer is a colleague, which was not stated | Reciprocity framing: what you bring, not just what you need |

## Highest-ROI prep

B2 is the objection this candidate meets most predictably: the ad's duty is processing supplier invoices and the quote you gave is chasing unpaid invoices. Rehearse it first, out loud, until the honest answer feels ordinary.

## Question banks

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A manager has three meetings booked at the same time on Thursday. How do you sort it out?" | CASE | [generic] | Structure it aloud: what you would ask first (which meetings can move, who decides priority), what you would propose, who you would tell, and what you would record. The question needs no claim about your past, so the guidance makes none | The calendar duty in F1's requirement, set as a live decision. CASE because it scores structure, with JD content |
| A2 | "You need to book a two-day trip for a colleague: travel, a hotel and a taxi, on a tight budget with a fixed meeting time. What do you ask before you book anything?" | CASE | [generic] | Clarify before structuring: dates and times, the budget, refundable or fixed fares, who approves, any preferences. Then give the order you would book in. Answer slot: the ad's booking-travel line makes a probe on whether you have done this likely. If you have booked travel or similar arrangements, say what, in your own words; if you have not, say so plainly and say how you would learn it | F2 is the row with no evidence, so this rehearses a clean structure and an honest answer. CASE with JD content |
| A3 | "A supplier's invoice arrives with an amount that does not match the order. What do you do?" | CASE | [generic] | Structure it: do not pay or pass it on yet, check it against the order, contact the supplier, tell whoever approves payment, record what happened. The guidance makes no claim about your past | The invoice duty behind F5, asked as a decision. CASE because it scores reasoning and caution, not a past event |
| A4 | "I'd like a monthly spreadsheet of supplier invoices with totals by supplier. How would you set it up, and how would you check it is right?" | CASE | [grounded] "okay with Excel" | Think aloud: what columns you would want, what you would ask me first, how you would check the totals. Keep your own words on your level: "I'm okay with Excel." If there is something you would need to look up, say so plainly and say how you would find out | F4 is the Excel row, and this tests it with a task rather than a self-rating. CASE with JD content, since Excel is a named duty |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Pick the part you would honestly be weakest at, and say it in your own words. If it is Excel, your words were "I'm okay with Excel", and the scope stays there. If it is travel booking, answer slot: if you have booked travel, say what, in your own words; if you have not, say so plainly. Then a ramp plan, said as a plan: what you would practise first, and how soon | F2 and F4 are the thinnest rows against the duties. JD because it scores the listed job, gaps included |
| B2 | "Chasing unpaid invoices is not the same as processing supplier invoices. How does your experience fit?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe on the rest of your invoice work likely. If you handled other invoice tasks at the clinic, say which and what part was yours, in your own words; if the invoice work was the chasing and nothing else, or the rest was not yours, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it. Then a ramp plan, said as a plan | F5 is the likeliest place to be probed, since the ad's duty and the quote sit on different sides of an invoice. JD because it scores a stated requirement; hold-then-concede because it is the pack's deepest objection |
| B3 | "Your background is a clinic reception desk. Why move to a remote admin role, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your own reason in your own words; this pack does not supply one. Keep it about the work the ad names rather than about leaving. If a follow-up asks what you would miss, answer from your own experience | Motivation consistency is what a Skeptic scores. EXP because it tests whether your story holds together |
| B4 | "Tell me about a time you managed your own workload with nobody checking over your shoulder." | JD | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick a time with a named task, how you kept track of it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I ran the appointment book for four physios." If remote working is the follow-up, F6's slot applies | The role title says remote, and F6 has no evidence either way. JD because the requirement is the role's working pattern |

### C. Conversational (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you end up here?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc from your own sentences: the two years as a receptionist at a physiotherapy clinic, the appointment book you ran for four physios, the unpaid invoices you chased. Then your own reason for this role, which this pack does not supply. Tell it in your own words, with nothing added | The biography question is nearly certain and sets the frame for every follow-up. EXP because it checks the story against F1 and F5 |
| C2 | "What do you enjoy most about day-to-day admin work?" | JD | [generic] | Pick one duty from the ad and say honestly why it suits you. The question needs no claim about your past, so the guidance makes none | A casual question that still scores genuine interest in the duties. JD because it points at the listed work |
| C3 | "What are you actually doing in Excel these days?" | JD | [grounded] "okay with Excel" | Say plainly what you use it for, keeping your own words on the level: "I'm okay with Excel." Answer slot: if you have used it for something recent, say what, in your own words; if not, say so plainly and say what you would learn first | F4's probe in casual packaging. JD because Excel is a named duty |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Walk me through how that worked day to day." | EXP | [grounded] "I ran the appointment book for four physios" | The beats the quote states: the appointment book, the four physios. Answer slot: the ad's calendar line makes a probe on the details likely. Say which part was yours and whether anyone else shared it, in your own words; if you do not remember a detail, say so plainly rather than filling it in | F1 is the calendar evidence and a prober will read it closely. EXP because it tests what was actually yours |
| D2 | "How did you keep track of the unpaid invoices you chased?" | EXP | [grounded] "chased unpaid invoices" | Say what you chased and from whom, in those words: "I chased unpaid invoices." Answer slot: if you had a way of tracking them, say how, in your own words; if you had none, or it was not yours, say so plainly. Do not offer a count you cannot stand behind | F5's detail probe. EXP because it tests method and attribution |
| D3 | "How do you check a document you have prepared before it goes out?" | JD | [generic] | Describe a checking routine as a method: who it is for, what it should say, formatting, a second read. If you already have a habit, say it in your own words. The guidance makes no claim about your past | F3's requirement, asked about habits. JD because it scores how documents are prepared |

### E. Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with more admin experience?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "okay with Excel" | Pause and restate the question. Anchor in what you said: two years as a receptionist at a physiotherapy clinic, and "I ran the appointment book for four physios." Hold through two follow-ups, then concede specifically where your own words set a limit: "I'm okay with Excel." | A time-boxed challenge to F1 and F4 together. JD because it scores fit to the listed job, with a pressure delivery |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the sentence you said: "I ran the appointment book for four physios." Answer slot: if any part was shared or someone else's, say which part and what was yours; if all of it was yours, say so plainly. Hold through two follow-ups, and concede only what is true | A direct attribution probe on F1. EXP because it tests ownership claims |

### P. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You would be dealing with whoever sends you diaries, invoices and documents. What do you need from us to do this well, and what could you take off our plate?" | JD | [generic] | Reciprocity framing: lead with what you would take off their plate, then what you need, such as clear deadlines and who approves what. The guidance makes no claim about your past | Applies if the interviewer is a colleague. JD because the duties are requests from others |
| P2 | "Two people ask you for something urgent at the same time. How do you decide who goes first, and what do you do about the other?" | CASE | [generic] | Structure it: ask each what the deadline is, check what depends on it, decide and tell both openly, escalate if you cannot decide. The guidance makes no claim about your past | Tests partnership and priority-setting without a past event. CASE because it is a live scenario |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| "managing calendars" | A1, D1, E2, P2 | |
| "booking travel" | A2, B1 | No evidence, so the guidance is an answer slot |
| "preparing documents in Word and Excel" | A4, B1, C3, D3 | |
| "processing supplier invoices" | A3, B2, D2 | |
| "Remote Administrative Assistant" | B3, B4 | |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week look like in this role: how much is calendars and travel, and how much is documents and invoices?" | Shows you have read the duties and want to know where the weight sits |
| R2 | "Which tools do you use for diaries, travel and invoices?" | Lets you place your Word and Excel level against real tools and plan your ramp |
| R3 | "What would a strong first month look like?" | Turns your ramp plan into a shared target |
| R4 | "How does the working day run for someone remote: who do I check in with, and how do requests reach me?" | Speaks to F6 and shows you are thinking about working independently |
| R5 | "What happens after this call: is there another step, and who would I speak to?" | A prep reason: you can plan for the next step instead of guessing |
| R6 | "What could a new person do in their first month that would genuinely help you?" | The reciprocity question; it fits if the interviewer is a colleague and costs nothing if they are not |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: your material says chasing unpaid invoices, not processing. B2's slot stays inside the clinic's invoice work |
| Is advanced or confident in Excel | Inflated form of F4 | F4's quote at its own scope: "I'm okay with Excel." A4, B1, C3 and E1 keep that wording |
| Has managed calendars beyond the appointment book | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." D1 and E2 stay inside it |

## Sources

Provided documents: your message (the invite text, the ad as you described it, and your background).

Searches sent, each by query:

- `Brennock Facilities Ltd values` — refused
- `Brennock Facilities Ltd interview process administrative assistant` — refused
- `Brennock Facilities Ltd strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Every call was refused. It would have supplied published values for VAL themes; none appear in this pack |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Every call was refused. It would have checked loop structure beyond the one call your invite describes |
| 3. `Brennock Facilities Ltd strategy news` | unavailable | Every call was refused. It would have fed CO questions, so the pack has none |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | Your description of the ad's duties fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → F1 to F6 get requirements quoted from the ad itself, and any duty your description left out gets a row and a question
- Whether the office manager would be your day-to-day manager or a colleague → persona weights are recomputed and banks A, B and P are rebalanced
- Any guidance the recruiter gave on focus areas or on what to prepare → coverage is built to it instead of assumed
- Your own answers to the slots on F2, F4, F5 and F6 → those rows become quoted evidence, and the guidance that draws on them is regenerated
- Permission for web searches (refused in this session) → published values and loop details for targets 1 and 2; a deeper pass would be up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from an earlier session → verified evidence and a sourced list of prohibited claims in place of the locally built one
