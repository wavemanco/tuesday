# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead (name not given). Format: a live text chat. Relationship assumed: hiring-manager style, since the lead will presumably run the team you would join. If that is wrong, the persona weights below change.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

Because this interview is a text chat, your writing is being scored on every answer, not only the ones about writing.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None in this pack: no published values were in hand |
| EXP | Whether your own claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge. None in this pack: no research ran, so these would be generic |
| CASE | A live problem from the role, reasoned through on the spot |

Provenance labels: grounded = traced to your message or the ad as you described it; inferred = derived from that, with the derivation named; generic = a role-family pattern with no claim about you or Lumenvale.

Highest-ROI prep: B1, the question about never having worked for a software company. It will be asked in some form, and a calm, honest answer changes the interview.

## Fit snapshot

The ad's requirements are as you listed them in your message, not the full ad text. Evidence is quoted from your message only; no CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap on the years, but stated rather than inspected, so expect a probe on what the role covered. Lead in the quote's terms: three years as a customer service advisor at an energy supplier. The training line is a separate strength and stays at its own scope: four new starters, the refunds process, last year |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is the tool you named, so name it: "I use Freshdesk every day." Your material says Freshdesk, not Zendesk, and the words stay with Freshdesk. Answer slot: if asked what you do in it, say which parts you use, in your own words; if your use is basic, say so plainly and say what you would learn first |
| F3 | "clear written communication" — job ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote puts calls and emails together, so it shows neither how much was written nor how clear it was. Keep the words at "answering around 60 calls and emails a day". Answer slot: the ad's line makes a probe on your writing likely. If you know roughly how many of those were emails, or have had feedback on your writing, say so in your own words; if not, say so plainly and say how you keep a reply clear |
| F4 | "confidence handling escalations" — job ad, as you described it | none given | none | [grounded] | discovery | Your material does not show an escalation either way. Answer slot: expect a probe on an escalated contact. If one comes to mind, say what it was and which part was yours, in your own words; if none does, or it was not yours to handle, say so plainly and say how you would handle one |
| F5 | Working for a software company (not in the ad as you described it; you raised it) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

Weights start from hiring-manager-style priors, adjusted by the format and by what your message shows. Your own message establishes the loop as one text chat with the support team lead, followed by an offer if it goes well. No published values or other loop source was in hand, so no values round is assumed and there is no values bank.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live customer scenarios you answer in writing, on the spot | High (6 questions). A team lead hiring for a support role scores by scenarios, and a text chat makes writing a reply live the natural test. This also scores F3 directly | Clarify before replying, then structure: acknowledge, own the next step, say what happens next. Keep replies short |
| B. Skeptic | Quiet probing of the gaps: no software background, no escalation example | High (4 questions). F5 is a negative you stated, and F4 has no evidence in your material, so these two are where a skeptic starts | Rehearse the B1 answer until it is boring. Bridge only from what you have said you did; where nothing exists, say so plainly and give a plan |
| C. Conversational | Friendly opener, casual questions about writing and background | Medium (3 questions). A chat-format interview opens conversationally, and casual questions are still scored | A 90-second arc built only from your own sentences; treat casual questions about writing as scored |
| D. Data-Driven Prober | Reads your numbers and asks how they were counted | Medium (3 questions). Two figures of yours are quotable: the daily volume and the four starters | Say how each figure was counted, or say plainly you do not know; name the part you would defend least before they do |
| E. Pressure | Time-boxed or demanding customer role-play; "why you" in sixty seconds | Lower (3 questions). Nothing in your material signals a stress style, but support leads often test composure with a difficult-customer scenario | Pause, restate, anchor in what you actually said, hold through two follow-ups before conceding anything real |

Not included: Values (no published values in hand, no values round documented) and Peer (nothing says a peer interviews you).

## Question banks

IDs are letter-by-persona. Question text is the interviewer's line. An answer slot is an instruction for the interview, not a question for you now.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem, says they're fed up and will cancel. Write me your first reply, here." | CASE | [generic] | Write it as you would to the customer: one plain sentence acknowledging it is the third time, then what you will do and by when, ask only for what you genuinely need, and end with what happens next. Short enough to read on a phone. The question needs no claim about your past, so none is made | A live reply scores written communication (F3) while it tests the scenario. CASE because it is a live problem; JD because it also scores the ad's writing line |
| A2 | "A customer says the app lost their work and you can't reproduce it. What do you ask them first, and what do you tell them meanwhile?" | CASE | [generic] | Clarify before concluding: what happened, when, on what device or version, and whether they can send a screenshot. Tell them what you are doing and when you will update them, and promise nothing you cannot control. If you would need a colleague's help with something about the product, say so. The question needs no claim about your past, so none is made | A software-product problem, the area your material is thinnest on (F5). CASE because it scores clarify-then-structure |
| A3 | "Two tickets arrive together: one customer is locked out of their account, another wants a feature added. How do you decide what to answer first?" | CASE | [generic] | Give your criteria aloud: how many people are blocked, how urgent, and what the customer can do meanwhile. Say what you would tell the second customer so they are not left waiting in silence. No claim about your past is made | Tests judgement with a queue, which is the ticketing-tool requirement's practical side (F2). CASE because it is a live prioritisation problem |
| A4 | "When would you pass a ticket to a senior colleague or another team, and what would you write in the handoff?" | JD | [grounded] | A structure for a decision, with no past in it: the signs a ticket is beyond your remit or carries risk, then what the handoff must hold so nobody re-asks the customer (the issue, what has been tried, what the customer has been told, what you need back), then telling the customer what happens next. Nothing here claims you have done a handoff | Scores the ad's escalation line (F4) as a decision rather than a story, so it is safe whatever your history is. JD with CASE delivery |
| A5 | "Tell me about a time you dealt with an escalated customer." | JD | [grounded] | Selection scaffold: pick a contact where the customer was already unhappy or the first answer had not settled it. It needs what they wanted, what you did, which part was yours, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F4 is the row with no evidence, so this probe is likely. JD because the ad names escalations; the guidance supplies no story because none of your sentences carries one |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. How would you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never worked for a software company." Then the nearest thing your material carries, at its own scope: "I use Freshdesk every day." Then the plan, said as a plan and never as a past: what you would learn first, where you would look, who you would ask, how you would check you had understood, all in your own words. Hold through two follow-ups by returning to those three beats; never add product experience you have not had. The limit is not a confession | F5 is the biggest gap in your material and a skeptic's first target. JD because it scores whether you can do the job as listed, gap included |
| B2 | "Which part of this role would you find hardest in your first month?" | JD | [grounded] "I've never worked for a software company" | Pick the part you genuinely expect to be hardest, and say what you would do about it in a sentence. Your own message names product familiarity as a gap, so that is a defensible choice. Answer slot: if handling escalations has not been part of your work, say so plainly and say how you would learn it; if it has, say which part was yours, in your own words | Candour about a real weak spot is what this question scores. The slot keeps F4 honest in either direction. JD because it is the standard stem for the listed requirements |
| B3 | "Why are you moving from an energy supplier into software support?" | EXP | [generic] | Give your actual reason in your own words; your material states none, so the pack supplies none. Keep it about the work you want to do, not about an employer. If part of the honest answer is that you have not worked in software, say so plainly | The why-leave, why-here, why-now probe, aimed at the sector change. EXP because it tests whether your story is consistent |
| B4 | "The ad asks for Zendesk or a similar tool. What have you used?" | JD | [grounded] "I use Freshdesk every day" | Name the tool you use: "I use Freshdesk every day." Do not say you have used Zendesk. Answer slot: if asked what you do in Freshdesk, say which parts you use, in your own words; if your use is basic, say so plainly and say what you would learn first | F2 is the ad's tool requirement, and a skeptic checks whether "similar" is real. JD because it scores a stated requirement |

### C. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A 90-second arc using only those beats, in order: the role and its three years, the daily volume at its own scope (calls and emails together), the tool you use every day, and training four new starters on the refunds process last year. Close with what you want next, in your own words. Describe what you did and let them draw the conclusions | The unstructured opener is scored for economy. EXP because it tests whether your own account holds together (F1, F2, F3) |
| C2 | "Do you find you prefer helping people by phone or in writing?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer honestly and say what you like about it. Your quote covers calls and emails together, so claim no split you have not stated. Answer slot: if you know roughly how your day divided, say so; if you do not, say so plainly | A casual question on the ad's writing requirement (F3). JD because the ad raises it |
| C3 | "How do you keep a reply clear and kind when the customer is upset?" | JD | [generic] | Pick the two habits that are genuinely yours and say them plainly: for example, what you lead with and how you check a message before sending. Answer slot: if a habit comes from your own work, say so in your own words; if you have not built one, say so plainly and say how you would start. No claim about your past is made here | Scores the ad's clear-writing line (F3) as an approach, with the slot letting the real answer through |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 calls and emails a day. How was that counted, and how many of those were emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep "around" and keep calls and emails together unless you know the split. Say how the figure was counted, or say plainly you do not know how it was counted. Say what it would be sensitive to, name the assumption behind it you would defend least before they do, and say which part was yours | F3 holds the figure. EXP because headline numbers are where probers dig, and the split is exactly what F3 lacks |
| D2 | "You trained four new starters on the refunds process last year. What was your part in that?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say it as stated: "I trained four new starters on our refunds process last year." Answer slot: say which part was yours, in your own words; if someone else set or shared any of it, say so plainly. Do not add what the sessions held or how they turned out unless you remember it first-hand | F1's training line is the most checkable claim about what you did for others. EXP because it tests attribution |
| D3 | "The ad wants two years in customer support. What do your three years add up to?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Say it at its scope: three years as a customer service advisor at an energy supplier, and leave the interpretation to them. Answer slot: if asked what the role covered, say in your own words; if some part was not yours, say so plainly | F1 meets the requirement; this makes you state it without puffing it up. JD because it scores the ad's years line |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year"; "I've never worked for a software company" | Hold, then concede. Hold: three years as a customer service advisor at an energy supplier, Freshdesk every day, and training four new starters on the refunds process last year, at those scopes and no wider. Concede plainly when pressed: "I've never worked for a software company." Hold through two follow-ups; do not claim to be better, only say what you bring | The sharpest version of F5. EXP because it tests whether you stay level when the gap is named |
| E2 | "A customer wants a refund outside the policy window and is demanding a manager. You have thirty seconds." | CASE | [generic] | Pause, restate the request, and acknowledge it in a sentence. Say what you can do, what you cannot, and what you would pass on and how. Promise nothing the policy does not allow; if you do not know the policy, say you would check it. No claim about your past is made | Composure under a time box; CASE because it is a live problem, and it touches the escalation line (F4) without needing a story |
| E3 | "Imagine a customer who knows our product better than you do on day one. What do you do?" | CASE | [generic] | Be straightforward about what you do not know yet, and do not guess at product facts. Say what you can do for them now, what you would check and with whom, and when you will come back to them. No claim about your past is made | Tests how you handle the product gap (F5) in a live moment rather than in the abstract. CASE because it is a live problem |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support (F1) | D3, C1, E1 |
| Zendesk or a similar ticketing tool (F2) | B4, A3, C1 |
| Clear written communication (F3) | A1, C2, C3, D1 |
| Confidence handling escalations (F4) | A4, A5, B2, E2 |
| Working for a software company (F5, raised by you) | B1, B2, E1, E3 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new to the product?" | It shows you are planning to learn the product, which answers the software gap without you having to raise it |
| R2 | "When a ticket needs escalating, who picks it up and what do you want in the handoff?" | It shows you are thinking about the handoff before you are asked to do one |
| R3 | "What does great written support look like on this team? Is there an example you would point a new person to?" | Gives you the team's own standard for the ad's writing line, and shows you care about quality as well as speed |
| R4 | "How is the day split between chat, email and any calls, and which tools does the team live in?" | Lets you tie your own experience to their real mix, and signals interest in the job as it is |
| R5 | "What do people coming from outside software usually find hardest in their first few weeks?" | Invites the lead to tell you the honest ramp, and shows you expect to have one |
| R6 | "After this chat, is there a call or video step before any offer, and how long does the whole process usually take?" | Tells you what else to prepare for and when |

## Prohibited claims

What this pack will not coach, and why. Each limit below is the pack's observation about your material, not words for you to say.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." Your material says Freshdesk, not Zendesk |
| Handles 60 emails a day, or that volume as written work | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day." Calls and emails are counted together |
| Designed, led or ran the refunds training, or its results | Inflated form of F1 | F1's quote at its own scope: "I trained four new starters on our refunds process last year." Your material says four starters and the refunds process, nothing about content or outcomes |
| Software or SaaS support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |

## Sources

Provided: your message, including the invite text you pasted (which establishes the loop as one text chat with the support team lead, with any offer to follow in the same chat), the four ad requirements as you listed them, and your background as you described it. No CV, full ad text or interviewer profile was provided.

Searches sent:

- "Lumenvale Software values" — refused
- "Lumenvale Software interview process Customer Support Specialist" — refused

Nothing in this pack comes from outside research.

Research tier: L1 — searches 2 of 6 sent, both refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | The search was refused. It would have fed a values cheat sheet and VAL questions; none is in this pack |
| 2. Lumenvale Software interview process, support roles | unavailable | The search was refused. The loop here rests on your own description of one text chat, not on any source about their process |
| 3. Lumenvale Software strategy and recent news | unavailable | No search was run, because search permission was not granted. It would have fed CO questions; none is in this pack |
| 4. Interviewer name and company | n/a | The interviewer is described only as the support team lead, so there is no name to query. The interviewer read is absent |
| 5. Representative Customer Support Specialist JD | skipped | The ad requirements you listed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full ad text → F1 to F4 requirements move from your summary to the ad's own wording, and any requirement you did not mention gets a row and a question
- Your CV → F1 to F3 evidence moves from your message to your CV's own sentences, and the training and Freshdesk rows can carry more of your actual work
- Your answers to the slots in F2, F3 and F4 (what you do in Freshdesk, how many contacts were emails, whether you have handled an escalation) → those rows firm up, and A5 and B2 become story-mapped rather than scaffolds
- The support team lead's name → an interviewer read and a reverse question tied to their own path
- Search permission, or Lumenvale Software's published values and loop pasted from its own site → a values cheat sheet if a values round is documented, and grounded CO and CASE questions
- Time available before the chat → a prep triage ordered by what matters most
- A tuesday-dossier.md → verified evidence and any claims to keep out, applied to every guidance cell
