# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

- **Candidate:** Aoife
- **Interviewer:** the office manager (no name given). Whether this person would be your manager or a colleague is not stated, so the pack is weighted as a hiring-manager-style round.
- **Format:** the invite's own sentence is "The interview is a 30-minute video call with our office manager."
- **Built from:** your message only: the invite text, the ad's duties as you described them, and your background. Company research did not run (see Sources).

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding for your own words, not a script: where a cell says "answer slot", it is an instruction for the interview, and you answer from what actually happened or say plainly that it did not.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none were available to this pack, so no VAL questions) |
| EXP | Whether what you say about your work survives follow-up; what was actually you |
| JD | The stated duties of the role, gaps included |
| CO | What you know about the company and how you think at its level |
| CASE | A live problem from the real job, scored on structure and reasoning |

## Fit snapshot

Requirements are quoted from the ad as you described it in your message. Evidence is your own words, nothing added.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as described in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it as you said it: "I ran the appointment book for four physios." The material gives the book and the four physios; it does not say what the book was kept in or whose appointments moved. Answer slot: the ad's calendar line makes a probe on how the book worked likely. Say what it was kept in and what you did with it, in your own words; if you do not know, or that part was not yours to set, say so plainly and stay with the book you ran |
| F2 | "booking travel" — the ad, as described in your message | none given | none | [grounded] | discovery | Your material does not show any travel booking, and the pack does not assume there was none. Answer slot: if you have booked travel for anyone, in or outside the clinic, say what and for whom in your own words; if you have not, say so plainly and say how you would start on a first booking |
| F3 | "preparing documents in Word and Excel" — the ad, as described in your message | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | presentation | Say it exactly as you said it: "I'm good with Word, okay with Excel." Excel is where the probe lands. Answer slot: name what you have actually made or done in Excel, in your own words; if it is little, say so plainly, then say which Excel task from the ad you would practise first |
| F4 | "processing supplier invoices" — the ad, as described in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your words are "chased unpaid invoices", and they stay at that scope. The material does not say whose invoices they were, and the ad's line is supplier invoices. Answer slot: if any of the invoices you handled came from suppliers, say what you did with them in your own words; if they were invoices the clinic issued, or you did not handle supplier invoices, say so plainly and stay with chasing unpaid invoices |

Also in your message: "two years as a receptionist at a physiotherapy clinic" — your message. It frames F1 and F4 and is not claimed beyond that.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank depth |
|---|---|---|---|---|
| Case / Strategist | Live mini-problems from the four duties: a diary clash, a trip, a spreadsheet request, an odd invoice | high: the relationship prior for a hiring-manager-style round, and the ad's four duties are all practical tasks | Clarify, structure, decide, confirm in writing; think aloud | A, 5 questions |
| Skeptic | Quiet probing of F2, F3 and F4, and why this move | high: F2 has no evidence, F3 is your own hedge, F4 differs from the ad's line | Rehearse the most predictable objection (B2) until it is boring; bridge only from your own words | B, 5 questions |
| Conversational / Rapport | "Walk me through your journey", casual tool questions | medium: a 30-minute video call invites a chatty register, and chatty questions are still scored | A 90-second arc built only from your own sentences | C, 4 questions |
| Data-Driven Prober | "Four physios, how was that counted?", "walk me through how you chased them" | low: a short call leaves little room, but your CV-style figures and steps are easy to probe | Know what you can say about each figure and say plainly when you do not know | D, 2 questions |
| Pressure | "How much of that was actually you?" | low: nothing in the invite suggests a stress style | Hold, then concede specifically | E, 2 questions |
| Peer Evaluator | "Where is the seam between us?" | low: the office manager may or may not be a peer | Offer principles, not a pretended seam | F, 2 questions |
| Values / Behavioral | Stories mapped to company values | none expected: no published values were available and no values round is described | Not rehearsed | no bank |

Weights rest on the relationship prior, not on this company's documented process: the invite's one sentence about the interview is the only loop information.

## Question banks

### A. Case / Strategist (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people you support each ask for the same one-hour slot with an outside client on the same morning, and neither will move. What do you do?" | CASE | [generic] | Clarify first: whose meeting has a hard deadline, whether the client can move, who decides priority. Then name your options, decide, tell both people in an order you can explain, and confirm the outcome in writing. The question asks about no past, so the guidance makes no claim about yours | The ad's calendar line (F1's requirement) turned into a live decision; CASE because it scores reasoning, not history |
| A2 | "Someone flies out Monday and back Thursday. The cheapest flight lands after their first meeting starts. How do you decide what to book?" | CASE | [generic] | Clarify: budget limit, who approves, the meeting's importance, the traveller's preferences. Offer two options with the trade-off stated, recommend one, and get the approval in writing before booking. No claim about your past is made | F2 has no evidence behind it, so a structured method is the strongest honest answer; CASE because it is a live problem |
| A3 | "A supplier invoice arrives for more than the quote you were given. What do you do before it goes any further?" | CASE | [generic] | Compare it with the quote or order, ask who approved the work, hold it, query the difference with the supplier in writing, and record the outcome. Say where you would ask for the company's own process rather than guess it | F4's requirement as a live problem; the method is available even where the experience is thin |
| A4 | "I need a one-page summary of this month's supplier spend in Excel by Friday. What do you ask me, and what do you hand back?" | CASE | [grounded] "I'm good with Word, okay with Excel" | Ask what the columns and categories are, where the source figures come from, who reads it, and in what format. Say what you would do yourself in Excel and what you would check or ask about: your own words were "I'm good with Word, okay with Excel", and that is the level to speak at. Answer slot: if a step is beyond what you can do today, say so plainly and say how you would learn it | F3 is the likeliest place a task is set; CASE because it tests clarifying before building |
| A5 | "You are supporting three people from home and nobody sits near you. How do you organise your week?" | CASE | [generic] | A structure: a fixed time to agree priorities, one shared view of everyone's calendar, written confirmation of requests, and a running list of open items you review daily. It is a plan for the job, not a claim about what you have done | The invite calls the role remote, and remote working is where an admin's method is most visible; CASE and JD in flavour |

### B. Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" | Pick the real one and say it first, before they do. Your own words on Excel were "I'm good with Word, okay with Excel", so Excel is a candid answer at that scope. Answer slot: travel booking is the other open row; if you have booked travel say what, and if you have not, say so plainly and name your first step. End on a ramp plan, spoken as a plan and not a past | F2 and F3 are the open rows; JD because it scores honest self-assessment against the listed duties |
| B2 | "The role is processing supplier invoices. What you have is chasing unpaid ones. What is the difference, and why should I be comfortable?" | JD | [grounded] "chased unpaid invoices" | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries: "I chased unpaid invoices." Follow-up 1, which invoices they were: answer slot as in F4: if any came from suppliers, say what you did with them; if they were the clinic's own or you did not handle supplier invoices, say so plainly. Follow-up 2, what you did when one stayed unpaid: say what you actually did in your own words, and if it was only the chasing, say that. Follow-up 3, what you would check on a supplier invoice first: this is a plan, so say what you would ask the office manager about the company's process. Never describe processing you did not do | F4 is the objection aimed where the material is thinnest and the ad's line is firmest; JD because it scores the stated duty |
| B3 | "Why move from reception to a remote admin role?" | EXP | [generic] | Give your real reason in one or two sentences, in your own words, and tie it to the work the ad lists: calendars, travel, documents, invoices. The pack does not supply a reason for you. If part of the reason is the remote setup, say that plainly too | Motivation consistency is the Skeptic's standing question; EXP because it is about your own path (F1 and F4 frame it) |
| B4 | "How good are you with Excel, honestly?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say it as it stands: "I'm good with Word, okay with Excel." Answer slot: name what you have actually done in Excel in your own words; if it is little, say so plainly, then say which task from the ad you would practise first and how | F3 is your own hedge, so the question will arrive; JD because Excel is a named duty |
| B5 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: if you have, say what and for whom in your own words; if you have not, say so plainly, then give how you would handle a first booking. Either branch is fine and a bluff is the only failure | F2 is silent in your material, so the honest branch must be ready; JD because travel is a named duty |

### C. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc with only these beats: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, chasing unpaid invoices. Tell them in your own words and end on why this role, in your own words | The biography question is always asked; EXP because it tests whether the story matches the CV-style claims (F1, F4) |
| C2 | "Tell me about the appointment book you ran for the four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Tell what the book was and who it served, in your own words. The quote carries the book and the four physios and nothing further. Answer slot: where an interviewer asks about a part you did not set or do not remember, say so plainly and return to the book you ran | F1 is the evidence for the calendar duty; EXP because it checks what was actually yours |
| C3 | "What do you know about us?" | CO | [generic] | Say only what you have actually read, and name where you read it. This pack could not establish anything about the company, so it supplies no facts. If you have read little, say what you have and ask what the office manager would most like you to understand | Homework depth is a standard opener; CO because it tests preparation, and generic because no research ran |
| C4 | "What do you use to keep yourself organised day to day?" | JD | [generic] | Name the tools and habits you actually use, in your own words. If a tool the ad's duties imply is one you have not used, say so plainly and say how you would pick it up | A casual tool question that is scored against the calendar and document duties; JD because it checks the listed work |

### D. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say four physios. What did running their appointment book involve, and which part was yours?" | EXP | [grounded] "I ran the appointment book for four physios" | The figure raises four slots, each in your own words: how "four" was counted, what it depends on (for example whether it was the same four throughout your time there), the assumption behind it you would defend least, and which part was yours. If you do not know how something was counted, say "I don't know how that was counted". Do not add numbers you were never given | A figure in your own words is the Prober's first target (F1); EXP because it tests attribution |
| D2 | "Walk me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | Tell the steps you actually took, in order, in your own words. Answer slot: if the clinic had a routine someone else set, say so plainly; if there was no set routine, say that. Do not supply counts or amounts you do not know; "I don't know" is a complete answer | F4 is the row a Prober presses; EXP because it tests what you did |

### E. Pressure (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The appointment book: how much of that was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Pause and restate the question. Hold at your own sentence, "I ran the appointment book for four physios", through two follow-ups. Concede specifically: answer slot: say which parts were set by someone else or are not yours to claim; if all of it was yours, say so plainly. Never fold on the core claim just to settle the room | F1 is the attribution a pressure style tests; EXP because it is about what was yours |
| E2 | "Sixty seconds: why you, over someone who has done this exact job before?" | JD | [grounded] "I ran the appointment book for four physios", "chased unpaid invoices" | State only what you said: you ran the appointment book for four physios, and you chased unpaid invoices. Say it in your own words, then stop. The pack's observation is that your material shows reception work and invoice chasing, not remote admin, so concede plainly that someone may have done this exact job and give the reason you are still worth a call from what you can honestly state | The Pressure persona's standing stem; JD because it weighs you against the listed duties (F1, F4) |

### F. Peer Evaluator (weight 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If you and I disagreed over who should handle an invoice query, how would we sort it out?" | CASE | [generic] | Propose principles, not a pretended seam: agree who owns what in writing, bring facts not opinions, escalate only after trying to settle it between you. The question asks about no past, so the guidance makes none | If the office manager is a colleague rather than a manager, this is how the seam gets tested; CASE because it is a live scenario from F4's duty |
| F2 | "Tell me about a time work was shared between you and someone else, and how you handled credit." | EXP | [generic] | Pick a time where credit was shared and the sharing was clear; "we" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | A standard collegial probe; EXP because it tests attribution honesty |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "managing calendars" | A1, A5, C2, D1, E1 |
| "booking travel" | A2, B1, B5 |
| "preparing documents in Word and Excel" | A4, B1, B4, C4 |
| "processing supplier invoices" | A3, B2, D2, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role, and what could a new person do in it that would genuinely help you?" | It shows you are already thinking about contribution, and it gives a colleague-style interviewer a way to answer as a peer |
| R2 | "Which of calendars, travel, documents and invoices takes most of the week?" | It uses the ad's own four duties and tells you where to spend practice time |
| R3 | "Who would I be supporting, and how many people?" | It sizes the load behind the calendar and invoice duties and shows you are thinking about priorities |
| R4 | "What tools and systems would I use for calendars, documents and invoices?" | It surfaces the Excel level the role needs before you commit to it |
| R5 | "How do you like work handed over and updates given when we are not in the same room?" | The role is remote, and this shows you have thought about how remote working actually runs |
| R6 | "What happens after this call, and who else would I speak to?" | It tells you what to prepare for next and is a normal closing question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars or diaries across a team | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: the material says the book and the four physios, not calendars beyond it. The F1 slot stays inside the book |
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: the material says chasing, and does not say whose invoices. The F4 slot stays inside what you handled |
| Advanced or expert Excel | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word, okay with Excel." The limit is the pack's observation: the material gives Excel as "okay". The F3 slot stays inside what you have actually done |

## Sources

Provided documents: your message (the invite text as pasted, the ad's four duties as you described them, and your background).

Searches sent, all refused, none returned anything:

- `Brennock Facilities Ltd values` — refused
- `Brennock Facilities Ltd interview process administrative assistant` — refused
- `Brennock Facilities Ltd strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have fed a values cheat sheet; none is included and no VAL questions are written |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have checked the loop; the one session comes from the invite's own sentence, and persona weights follow the relationship prior |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO or CASE question in current strategy; C3 stays generic |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The four duties in your message fix the fit snapshot and the JD-tagged questions; a full ad would tighten the wording, not the structure |

## Upgrade menu

- The ad's full text, pasted → F1 to F4 take their requirement wording from the ad itself instead of your summary, and any further duties get questions
- Your answers to the slots in F1, F2, F3 and F4, said outside a drill → those rows gain quoted evidence and the slots in A, B, C, D and E tighten into story-mapped guidance
- The interviewer's name and role → an interviewer read, persona weights reset from their public footprint, and a reverse question tied to their path
- Anything stated about what the call covers, such as focus areas or a task to prepare → coverage built to it, and a build section if a deliverable is announced
- Company values and any documented interview structure → a values cheat sheet and VAL questions, and persona weights set from the company's own process
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), once searching is permitted in this session → a company strategy brief and sharper CO questions
- A `tuesday-dossier.md` from an earlier evidence check → its verified evidence and per-gap strategy replace the evidence and prohibited claims this pack built locally
