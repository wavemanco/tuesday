# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Round: one 30-minute video call with the office manager (your words). Interviewer name: not given. Relationship: not stated, so this pack assumes the office manager is a hiring-manager-style interviewer who would work closely with the role.

Highest-ROI prep: question B1, on supplier invoices. It is the likeliest probe and sits exactly where your material is thinnest.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the employer's values |
| EXP | Whether what you say about your experience holds up under follow-ups |
| JD | Whether you can do the listed duties, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the job |

An answer slot is an instruction for the interview, not a question for you now. Meet it with either branch, from your own experience.

## Fit snapshot

The requirements are the four duties as you described the ad in your message. The full ad text would let these cells quote the ad itself.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message, describing the ad | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your words stay at the quote: "I ran the appointment book for four physios." Your material says an appointment book, and nothing inspected sits behind it. Answer slot: the ad's calendar line makes a probe on how bookings were arranged across the four physios likely. If any of that was yours to decide, say how, in your own words; if it was not yours, or there was no such arrangement, say so plainly and stay with the book you ran |
| F2 | "booking travel" — your message, describing the ad | none given | none | [grounded] | discovery | Your material is silent on travel. Answer slot: the ad lists booking travel, so expect a probe. If you have arranged travel for anyone, say what, in your own words; if you have not, say so plainly and stay with the appointment book you ran |
| F3 | "preparing documents in Word and Excel" (Word half) — your message, describing the ad | "I'm good with Word" — your message | medium | [grounded] | discovery | The quote is a self-rating, and the material does not show what was prepared in Word. Words: "I'm good with Word." Answer slot: expect a probe on which documents. If you prepared documents in Word, say what kinds, in your own words; if it was little or none, say so plainly and stay with your own rating |
| F4 | "preparing documents in Word and Excel" (Excel half) — your message, describing the ad | "okay with Excel" — your message | medium | [grounded] | discovery | Say it at your own rating: "okay with Excel." The material does not show what was done in it. Answer slot: if you have built or edited spreadsheets, say what for, in your own words; if you have not used it for work like the ad's, say so plainly and say what you would learn first |
| F5 | "processing supplier invoices" — your message, describing the ad | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Words at the quote's scope: "I chased unpaid invoices." Your material does not say which side of the payment those invoices sat on, and chasing is a different activity from processing. Answer slot: if you can say which side your invoices were on, say it plainly; if any of your work was entering, checking or routing invoices for payment, say what, in your own words; if none was, say so plainly and stay with chasing |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, A3 |
| "booking travel" | A1, A2 |
| "preparing documents in Word and Excel" | D2 (Word); A5, C2, E2 (Excel) |
| "processing supplier invoices" | A4, B1, D3 |

## Persona table

The loop rests on your own words: one 30-minute video call with the office manager. No loop source documents a values round, so values weight is low.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Short practical scenarios: a clashing diary, a missing purchase order, a messy document | High. The relationship prior for a hiring-manager style round is Case plus Skeptic, and all four duties are easy to turn into a scenario | Clarify first, then order your steps, then say how you would confirm and record. Think aloud |
| Skeptic | Quiet probing of what the clinic did and did not cover | High. F2 and F5 are where the material is thinnest, and a clinic-to-office move invites "why" | Rehearse B1 until it is boring: hold what you said, concede the limit plainly, give your plan to learn |
| Conversational | Friendly opener, "walk me through your journey" | Medium. A 30-minute video call to a small team is likely to open this way, and the archetype for an unknown loop is generic | A 90-second arc from your own sentences. Treat casual questions as scored |
| Data-Driven Prober | Wants the detail behind "four physios", invoices and Excel | Medium-low. Short call, but two of the duties are numbers-and-documents work | Know what you can say about each claim and say plainly where you do not know |
| Pressure | Time-boxed "why you" | Low. Nothing in the material points to a stress style | Pause, restate, hold through two follow-ups, concede one specific thing |
| Values / Behavioral | Open "tell me about a time" prompts | Low. No published values were found and no values round is documented | A selection scaffold and the honest branch if nothing comes to mind |

## Question banks

Quotes in Provenance are exactly as in the fit snapshot.

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your manager has a Tuesday call that clashes with a supplier visit, and someone has to be in Cork by Wednesday morning. Walk me through what you do." | CASE | [generic] | Structure it aloud: what you would ask first (which commitment can move, and who needs telling), the options you would weigh, how you would confirm the change in writing, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the calendar and travel duties (F1, F2), asked as a decision; CASE because it scores structure, not history |
| A2 | "Tell me about a time you booked travel for someone." | JD | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick a booking where several people's availability had to line up. If no travel booking comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or say how you would go about booking travel | F2 is the row with no evidence, so this is where it is probed; JD because the ad lists the duty, and an open prompt because it supplies no event |
| A3 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the book and the four physios are the beats the quote states; tell them in your own words. Answer slot: expect a probe on how bookings were arranged across four people. If any of that was yours to decide, say how; if it was not yours, or there was no such arrangement, say so plainly and describe the book as you ran it | F1 is the evidence for the calendar duty and the likeliest follow-up; EXP because it tests what was actually yours |
| A4 | "A supplier emails to say an invoice from last month is unpaid, and you cannot find a purchase order for it. What do you do?" | CASE | [generic] | Structure it: what you would check first and where, who has to approve before anything is paid, what you would tell the supplier and when, and what you would record. Where you do not know how this company approves invoices, say that is the first thing you would ask. No claim about your past is needed | The supplier-invoice duty (F5) as a live problem, so a gap in experience can still show reasoning; CASE because it scores order of steps |
| A5 | "Here is a spreadsheet of forty invoices with due dates. How would you show me which are overdue?" | CASE | [grounded] "okay with Excel" | Think aloud and keep it at your own rating, "okay with Excel". Say what you would try and where you would check your result. Where you do not know the function or feature, say so plainly and say how you would find out. Answer slot: if you have done something like this, say what, in your own words; if you have not, say so plainly | Tests F4 under a live task rather than a self-rating; CASE with JD content |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role involves processing supplier invoices. What part of that have you done yourself?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if you can say which side of the payment those invoices were on, say it plainly; if any of your work was entering, checking or routing invoices for payment, say what, in your own words; if none was, say so plainly and stay with chasing. Hold through two follow-ups by returning to what you said, never by adding to it. Concede the limit in one specific sentence, then give your plan to learn how this company processes invoices | F5 is where the role's invoice duty presses hardest against a thin quote, so this objection arrives in some form; JD because it scores the stated duty |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Pick the part you actually believe is weakest and say why, in your own words. Your material does not show travel booking (F2) or invoice processing (F5), and your own rating of Excel is "okay with Excel". Name your first-week plan for the one you pick. An honest, specific answer scores better than a vague one | The standard Skeptic stem; it forces a self-assessment across F2 to F5; JD because it scores fit against the duties |
| B3 | "You have two years as a receptionist. Why an administrative role, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Answer slot for motive: give your real reasons in your own words; nothing is supplied here. Pick a reason that is true and about the work. If the main reason is practical, say so plainly, then say what draws you to the duties. Start from the quote only for the fact of the job | A motivation-consistency probe that any clinic-to-office move gets; EXP because it tests the story behind the CV line |
| B4 | "This is a remote role. How would you keep your work on track without anyone nearby?" | JD | [generic] | Structure it: how you would agree priorities, how you would show progress without being asked, and how you would flag a problem early. The question asks about your method, so say what you would do, and if you have worked this way before, say so in your own words | The role title says remote; JD because it scores a condition of the role; no claim about your past is needed |
| B5 | "Your experience is in a clinic. What from there would carry into this office?" | EXP | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices" | Keep to the two sentences at their own scope and let the interviewer draw the link: "I ran the appointment book for four physios", "I chased unpaid invoices". Answer slot: if you can name one thing from either that carried over, say it in your own words; if you cannot, say so plainly and say what you would bring to learn | The transferability question behind F1 and F5; EXP because it tests whether the bridge survives |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios" | A 90-second arc with only what the sentences carry: the two years as a receptionist at a physiotherapy clinic, and the appointment book for four physios. Add why you are here in your own words. Nothing else about your past is supplied | The likeliest opener in a short call; EXP because it sets up every later follow-up on F1 |
| C2 | "What are you playing with in Excel these days?" | JD | [grounded] "okay with Excel" | Casual, but scored. Answer slot: if you have used Excel recently, say what for, in your own words; if you have not, say so plainly and say what you would like to learn first. Your rating stays "okay with Excel" | Persona stem for a plus-skill; F4 is the row it presses |
| C3 | "What did you enjoy most about running the appointment book?" | EXP | [grounded] "I ran the appointment book for four physios" | Your own answer, with nothing supplied. Pick one true thing specific to the work. If nothing stands out, say so plainly and say what you would like more of | Tests genuine interest in the work behind F1; EXP because it is a deep-dive in a friendly register |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of running the appointment book for four physios was yours?" | EXP | [grounded] "I ran the appointment book for four physios" | Say the sentence in your own words first. Then the four slots a figure raises: what "four" covered when you were there, whether it changed, the part of that you would defend least, and which parts were yours. If someone else handled some of it, say so plainly. If you do not know how something was counted, say that | The defend-the-number question for the one figure in your material; EXP |
| D2 | "You get a twelve-page document back from three people, each with their own edits in Word. How do you turn it into one clean version?" | CASE | [grounded] "I'm good with Word" | Think aloud and keep to your own rating, "I'm good with Word". Say what you would do and what you would check at the end. Where you do not know a feature by name, describe what you would want it to do and say you would look it up. Answer slot: if you have merged edits like this, say how, in your own words; if you have not, say so plainly | The only question aimed at the Word half of F3; CASE with JD content |
| D3 | "Walk me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | Story-mapped on F5 with only the beat the quote states: "I chased unpaid invoices." Answer slot: expect a probe on how you kept track of which were unpaid. If you used a list, a system or notes, say which, in your own words; if someone or something else kept track, or there was no such record, say so plainly and stay with the chasing | Probers ask for the denominator behind a CV line; EXP because it tests F5 at its own scope |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has worked in an office?" | EXP | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices" | Pause and restate the question. Hold what the sentences carry: "I ran the appointment book for four physios", "I chased unpaid invoices". Hold through two follow-ups, then concede one specific thing in your own words. Your material does not show an office-based role; answer slot: if you have worked in an office, say where, in your own words; if not, say so plainly and say what you would bring | Persona stem for time-boxed comparison; EXP because it scores whether the story holds under pressure |
| E2 | "You said okay with Excel. Is okay good enough for this job?" | JD | [grounded] "okay with Excel" | Hold what you said, "okay with Excel", without upgrading it. Concede one specific thing you would need to learn, named in your own words, and say how you would learn it. Answer slot: name one thing you have done in Excel and one you have not; if you have not used it for work like the ad's, say so plainly | Pressure on F4's modest self-rating; JD because it scores the stated tool |

### Bank F: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | Persona stem; low weight because no values round is documented; VAL because it scores behaviour |
| F2 | "When did you put a customer ahead of an internal target?" | VAL | [generic] | Selection scaffold: pick a time a patient, client or supplier's need and an internal rule pulled apart, with what you did and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | Persona stem; VAL because it scores behaviour, generic because no published values were found |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like in this role?" | It shows you are planning to deliver, and the answer tells you which duty matters most first |
| R2 | "Of calendars, travel, documents and invoices, which takes most of the week?" | It lets you weight your preparation and shows you read the duties as a working week |
| R3 | "How is work handed over and checked when the team works remotely: messages, calls, shared folders?" | It shows you are thinking about how remote work stays visible, which is the practical side of B4 |
| R4 | "Who would I work with day to day, and who approves the supplier invoices I would process?" | It maps the seam between you and the approver, and signals care about getting invoices right |
| R5 | "Which tools do you use for diaries, travel booking and invoices?" | It turns F2 to F5 gaps into a learning plan you can start before day one |
| R6 | "What are the next steps after this call, and when should I expect to hear?" | It is a plain process question that closes the call professionally |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for staff or managers | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios". The limit is the pack's observation: the material says an appointment book. A3's slot stays inside the book |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: the material says chasing, not processing. B1's slot asks only which side of the payment the invoices sat on |
| Proficient or advanced in Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". E2's slot stays inside what you have done |
| Expert in Word | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word". D2's slot stays inside what you have done |

## Sources

Provided documents: your message (the interview email's wording, your description of the ad, and your background).

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Queries sent:

- "Brennock Facilities Ltd values about us": refused
- "Brennock Facilities Ltd strategy recent news": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | The search was refused. It would have supplied published values to theme the Values bank; no values section is built, since no values round is documented |
| 2. interview process, role family | skipped | Your words already fix the loop: one 30-minute video call with the office manager. Persona weights follow it |
| 3. company strategy, recent news | unavailable | The search was refused. It would have supplied a company-specific question for Bank A; none is written |
| 4. interviewer name | n/a | No name was given, only "office manager", so there is no query to form; no interviewer read is built |
| 5. representative role JD | skipped | The four duties you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F5 quote the ad itself instead of your summary, and any further requirement gets a row and a question
- Your CV, or a reference or role description from the clinic → F1 to F5 evidence cells move from single sentences to documented lines, and confidence can rise where something inspectable backs them
- Your answers to the slots on booking travel, which side of the payment your invoices sat on, and what you have done in Word and Excel → F2 to F5 move from discovery or transferability, and A2, B1, D2 and D3 become story-mapped
- Search access for company values and news → a Values bank themed on published values, and a company-specific Case question
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent company context, if any can be attributed to this employer
- The office manager's name and public professional profile → an interviewer read, persona weights adjusted to it, and a reverse question tied to their path
- A tuesday-dossier.md from an earlier session → verified evidence and strategy limits per weak area, so the objection to rehearse is drawn from evidence rather than inferred
