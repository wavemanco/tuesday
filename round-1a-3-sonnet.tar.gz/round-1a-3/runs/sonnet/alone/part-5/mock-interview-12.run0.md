I've read the skill's rules, and I'm now running the default research pass on the company and role before I write the pack.
Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview". It also says "you deposit the cheque and send the balance on to the vendor". A fee before an interview, passport and bank details before any offer, and a cheque you deposit and then send money on from are a known scam pattern, and these requests, and this job as described, are very likely a scam. Hold all three (paying, depositing the cheque, sending the passport or bank details) until you've checked the invite with the employer. Use contact details you find yourself on its own website or careers page, not the email address, numbers or replies in the invite. If you've already paid or sent anything, call your bank now. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-5/rooms/case-12-denied-927fa24b/brennock-facilities_remote-administrative-assistant_interview_pack.md`. It has 18 questions in five styles, built for the one 30-minute video call the invite describes. The interviewer's relationship to the role isn't stated, so I weighted the styles from the four duties in the ad.

- **Highest-ROI prep (B1):** expect to be pressed on the gap between your "chased unpaid invoices" and the ad's "processing supplier invoices".
- **Other thin spots:** booking travel (F2) and how far your Excel goes (F3) are the next likeliest probes.
- **What I couldn't do:** web search wasn't permitted, so nothing in the pack is sourced from outside your message. The company-knowledge question (C2) is generic, and the Sources section shows each target as unavailable.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager the person you'd report to day to day, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: "our office manager" (no name given), one 30-minute video call. Their relationship to the role is not stated, so persona weights are built from the one session the invite describes and are not tuned to a manager or a peer.

## How to use this pack

Personas are how a question arrives; types are what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background survives scrutiny; what was actually you |
| JD | The advertised duties, including where you are thinner |
| CO | What you know about the company |
| CASE | A live problem from the real job, reasoned aloud |

Every question carries a Provenance cell: `[grounded]` rests on your own words or a supplied document, `[inferred]` on a derivation named in the row, `[generic]` is a pattern with no claim about you or the employer. Where guidance makes a claim about you, the sentence it rests on is quoted beside the label. An answer slot is an instruction for the interview, not a question for you now.

The highest-ROI prep in this pack is B1: the interviewer will very likely press on the difference between chasing unpaid invoices and processing supplier invoices.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios, and the words stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendars line makes a probe on how that differs from managing calendars likely. Say which parts of keeping the book were yours to decide, in your own words; if none were, or it was a fixed routine, say so plainly and describe how you kept the book |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show any travel booking. Answer slot: if you have booked travel for anyone, say what and for whom, in your own words; if you have not, or it was not yours, say so plainly and say how you would learn the booking tools |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | discovery | The quote gives a level for each program and says nothing about which documents you prepared. Keep the words at that level: "I'm good with Word, okay with Excel." Answer slot: say which documents or spreadsheets you have actually produced, in your own words; if none at work, say so plainly and stay with the level you gave |
| F4 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and the words stay at chasing: "At the clinic, I chased unpaid invoices." Answer slot: the ad's supplier-invoices line makes a probe on invoices you handled likely. If you handled any invoices that were to be paid, say how, in your own words; if you did not, say so plainly and return to the chasing |

## Persona table

The loop rests on your message: the invite names one session, a 30-minute video call, with the office manager. No other source for the loop was available, so the weights come from that and from the role's four duties.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Small live admin problems: a clash in a diary, a trip to arrange, a mismatched invoice | Highest: five questions. The ad lists four hands-on duties, and a 30-minute call has little room for anything else | Clarify first, then options, then confirm and record; think aloud |
| B. Skeptic | Probes the gaps between your background and the four duties | Highest: five questions. F2 and F4 are where your material is thinnest | Rehearse B1 until it is boring; stay inside what your own words carry |
| C. Conversational | "Walk me through your journey", "why us" | Medium: three questions. An office manager is likely to open this way, and casual questions are still scored | A 90-second arc from your own sentence |
| D. Data-Driven Prober | Reads your background line by line and asks what was yours | Medium: three questions. Your background is short, so each line gets pressed | Know which part of each line was yours and say so plainly |
| E. Peer Evaluator | Collaboration scenarios | Low: two questions. The invite does not say the interviewer is a peer | Say what you would do for the other person, not only what you need |

Not given a bank: Pressure, since nothing in the invite suggests a stress format, and Values, since no values round is documented.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers ask for the same hour on the same day, and one of them is travelling that morning. How do you sort the diary?" | CASE | [generic] | Structure it aloud: ask who decides priority between them and whether either meeting can move; look for options such as moving one, a shorter slot, or a delegate; confirm the outcome with both in writing; note the rule so it is not asked again. The question needs no claim about your past, so the guidance makes none | F1's requirement, asked as a decision rather than a record; a live problem, so CASE |
| A2 | "A manager asks you to book a trip to Frankfurt from Tuesday to Thursday, back before Friday's team meeting. What do you need to know first?" | CASE | [generic] | Clarify before answering: dates and flexibility, budget or approved-supplier rules, seat and hotel preferences, who approves. Then options, confirm before booking, send the itinerary, say what you would do if a flight changed. No claim about your past | F2's requirement; with no booking evidence in the material, a structured approach is the honest answer; CASE |
| A3 | "A supplier invoice arrives for an amount that does not match the order. What do you do?" | CASE | [generic] | Ask who approves payments, hold the invoice, check it against the order and delivery, query the supplier, record the outcome. Think aloud and name what you would not do: pay first and sort it later. No claim about your past | F4's requirement; a live problem on the invoice duty, so CASE |
| A4 | "A manager wants a one-page monthly summary of supplier invoices in Excel and a covering note in Word. How would you build it?" | JD | [grounded] "I'm good with Word, okay with Excel" | Open with your level in your own words, then structure: ask what the manager wants to see, lay out the columns, check the totals, then the note. Answer slot: the ad's Excel line makes a probe on what you have done in it likely. Say which tasks you have actually done, in your own words; if none at work, say so plainly and stay with the level you gave | F3 is the evidence for the documents duty; JD because it scores the listed requirement, delivered as a case |
| A5 | "It is 4pm, a Word report is due out at 5, and the figures from an Excel sheet have just changed. Talk me through the next hour." | CASE | [generic] | Order the hour aloud: confirm the new figures and who signed them off, update the sheet, carry the changes into the report, check every figure that moves, send, and tell the manager what changed. Ask one clarifying question first. No claim about your past | F3 and F1 under time pressure; a live problem, so CASE |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You chased unpaid invoices at the clinic. This job processes supplier invoices, which is the other direction. Where does your experience stop?" | EXP | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "At the clinic, I chased unpaid invoices." Answer slot: if you handled any invoices that were to be paid, say how, in your own words; if you did not, say so plainly and return to the chasing. Follow-up one, "What would you want to learn first?": answer as a plan, never as a past. Follow-up two, "Have you dealt with invoices coming in?": the slot again, same two branches. Follow-up three, "Why should I believe you would pick it up?": return to the quote and the plan. If the slot's second branch is yours, concede it in one sentence, then move to how you would learn it | F4 is where the ad's supplier-invoices line presses hardest against your material, so this objection will be asked in some form; EXP because it tests what was actually yours |
| B2 | "Booking travel is part of this job. What travel have you booked?" | JD | [grounded] "I ran the appointment book for four physios" | Answer slot: if you have booked travel, say what and for whom; if you have not, or it was not yours, say so plainly. Then give the nearest thing your material carries, in its own words: "I ran the appointment book for four physios", and say how you would learn the booking tools. Do not call the appointment book travel experience | F2 has no evidence behind it, so this probe is likely; JD because it scores a stated duty |
| B3 | "How would you rate your Excel?" | JD | [grounded] "I'm good with Word, okay with Excel" | Hold your own level: "okay with Excel". Hold it through two follow-ups, such as "What would you not be comfortable doing?" and "What would you do when you got stuck?". Concede where it ends, specifically and in your own words, and say how you would close it. Do not move "okay" upward to calm the room | F3's quote is a self-rating with nothing inspected behind it, so a probe on the level is likely; JD because it scores a listed tool |
| B4 | "Why move from physiotherapy reception into office administration?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Selection scaffold: pick your real reasons, one pull toward the ad's duties and one thing you took from the clinic job that carries over, in your own words; avoid running down the clinic. If no single reason comes to mind, say so plainly, then give the nearest true one | Motivation consistency; EXP because it tests whether your story holds together |
| B5 | "This role is fully remote. What helps you work well without an office around you?" | JD | [generic] | Selection scaffold: pick one or two real habits, such as how you keep work visible to others and how you ask for what you need. If you have not worked remotely, say so plainly and describe how you would set up your week. No claim about your past | The title says remote, so this is likely; `[generic]` because it is a pattern, not a fact about this employer |

### C. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc on the beats the sentence states: the clinic, the two years, the appointment book for four physios, chasing unpaid invoices. Tell them in your own words, then say which of the ad's four duties you most want to do and why, in your own words | F1 and F4 are the evidence for the duties; EXP because it is your own story, asked casually and still scored |
| C2 | "What made you apply to us?" | CO | [generic] | Say what in the ad drew you, in your own words. This pack holds no facts about the company because research did not run, so claim only what you have read yourself; if you know little about them, say so plainly and ask what they would like you to know | Likely in any friendly opener; CO because it tests homework, kept generic for the stated reason |
| C3 | "What sort of documents do you put together in Word?" | JD | [grounded] "I'm good with Word" | Name documents you have actually made, in your own words, at the level "I'm good with Word". Answer slot: if what you have made is simple, say so plainly rather than reaching for a bigger example | F3 covers the documents duty; JD because it scores the listed requirement, asked casually |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Which part of that was yours day to day?" | EXP | [grounded] "I ran the appointment book for four physios" | Say what you did with the book, in your own words, at the scope of the quote. Answer slot: say which parts were yours and which were shared or someone else's; if you do not know how any figure was counted, say so plainly | F1; EXP because it tests attribution |
| D2 | "Tell me about a time something went wrong with the appointment book and how it was sorted." | EXP | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick one real moment, what happened, what you did, what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in its own words | The ad's calendars line raises a probe on how the book went wrong; F1; EXP because it asks for a specific instance |
| D3 | "Tell me how you chased unpaid invoices at the clinic." | EXP | [grounded] "chased unpaid invoices" | The beats are only what the quote states: you chased unpaid invoices. Tell it in your own words and say which part was yours; if part of it was someone else's, say so plainly | F4; EXP because it tests what the line actually covered |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Two colleagues each ask you to do their work first. How do you decide?" | CASE | [generic] | Say what you would ask first, how you would find out whose deadline is real, and how you would tell the one who waits. Offer them both a time. No claim about your past | F1's requirement, from the collaboration side; a live problem, so CASE |
| E2 | "Tell me about a time you needed something from a colleague who was slow to answer." | EXP | [grounded] "chased unpaid invoices" | Selection scaffold: pick one real time, what you needed, what you did, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "chased unpaid invoices", at that scope | A standard peer probe; EXP because it asks for a real instance |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, A5, D1, D2, E1 |
| "booking travel" | A2, B2 |
| "preparing documents in Word and Excel" | A4, A5, B3, C3 |
| "processing supplier invoices" | A3, B1, D3 |
| remote (from the role title) | B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | Shows you are thinking about delivery, and tells you what the first weeks really involve |
| R2 | "Of calendars, travel, documents and invoices, which takes most of the week?" | Tells you where to put your prep, and shows you read the duties as a working list |
| R3 | "Which tools does the team use for calendars, travel booking and invoices?" | Lets you say how you would close any tool gap, honestly, rather than guess |
| R4 | "How does the team stay in touch day to day with someone working remotely?" | Shows you have thought about working remotely and gives you something concrete to judge |
| R5 | "What could a new person do in the first month that would genuinely help you?" | A reciprocity question: it turns the call from an examination into a conversation |
| R6 | "What are the next steps after this call, and when should I expect to hear?" | Shows readiness and gives you a timeline to plan around |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars in the sense the ad uses | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says an appointment book for four physios, not calendars. D1's slot stays inside the book |
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says chasing unpaid invoices, not processing supplier invoices. B1's slot asks only what invoices you handled |
| Advanced or expert Excel | Inflated form of F3 | F3's quote at its own scope: "okay with Excel". A4 and B3 stay at that level |

## Sources

Provided documents: your message, which holds the invite's text, the ad's duties as you described them, and your background. No tuesday-dossier.md was consumed.

Searches sent, all refused because search permission was not granted: `Brennock Facilities Ltd values`; `Brennock Facilities Ltd interview process remote administrative assistant`; `remote administrative assistant job description calendar management travel booking Excel supplier invoices`. No page was fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Refused. Would have supplied value names for VAL themes; nothing in the pack rests on company values |
| 2. `Brennock Facilities Ltd interview process remote administrative assistant` | unavailable | Refused. The loop stands on your message alone: one 30-minute video call with the office manager |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | No call sent after the refusals above. Would have fed grounded CO and CASE questions; C2 stays generic |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | The invite names only "our office manager", so there was no query to form |
| 5. representative Remote Administrative Assistant JD | unavailable | Refused. Would have added requirements beyond the four you described; the fit snapshot rests on your description of the ad |

## Upgrade menu

- The ad's full text → the four requirements quoted from the ad itself, and any further duty added to the coverage table with its own questions
- Detail on your clinic work, such as any travel or invoices you handled and what you have made in Word or Excel, stated in your own words → F2, F3 and F4 move from answer slots to quoted evidence, and the matching bank rows get story maps
- Whether the office manager would be your day-to-day manager or a peer → persona weights recomputed and the banks reordered
- Search permission → company values, loop and strategy read from sources, and C2 becomes grounded
- A tuesday-dossier.md → an evidence-derived top objection and constraints on what each weak area may claim
