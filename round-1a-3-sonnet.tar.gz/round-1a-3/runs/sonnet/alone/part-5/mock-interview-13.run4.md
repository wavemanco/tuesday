Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It has 19 questions, built around Hannah's four topics: pay, notice period, hybrid and what's prompting the move. It assumes this is a recruiter screen and prepares only for Thursday's call, since later rounds aren't known.

Web search was refused, so nothing in the pack comes from outside what you gave me. The "what do you know about us" question and the live-problem questions are labeled generic. Before Thursday, read Quillmoor's website and recent news yourself.

The pack names three areas to prepare first:
- **Production scheduling (B1):** the advert asks for scheduling between planning, the warehouse and QA. Your material says delivery scheduling across three depots, so the pack has you say that and nothing wider.
- **SAP (B2):** the pack has you say "I've never used SAP" plainly, then mention your in-house stock system.
- **The stock-count figure (C1 and D2):** be ready to say how "about a third" was counted and which part of the result was yours. "I don't know how it was counted" is an honest answer.

Pay and hybrid are given in your own words. £42,000 sits inside the advert's £38,000 to £44,000 band, and your two-days-fine, no-more-than-three position needs no extra wording. The reason for leaving is in your own words too: the Bristol office closing and the Reading offer you don't want. Expect Hannah to ask what draws you to this role, so the pack leaves that as a blank for you to answer.

Say the word and I'll play Hannah on B1, the question the pack names as highest-ROI. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, I'll convert it.

What notice period do you owe your current employer? The pack can't cover that topic until I know, and Hannah has said she'll ask.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner. Relationship: recruiter screen, a 30-minute phone call on Thursday at 2pm. She will ring the mobile number on your application.

Built on this assumption: Hannah's own message sets the agenda (salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move), and she says she will then describe the team and the next steps. Later rounds are not known, so this pack prepares only this call.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. The guidance is scaffolding for your own words, not a script, and each cell is meant to be speakable in 90 to 120 seconds.

Type key:

- VAL: whether past behavior shows the company's published values. No values-style round is detected for this call, so there are no VAL questions.
- EXP: whether the claims in your background hold up, and what was actually yours.
- JD: whether you can do the listed job, gaps included, and the job's own terms.
- CO: what you know about the company.
- CASE: a live problem from the role, answered aloud.

The highest-ROI prep in this pack is B1, the question on coordinating production schedules between planning, the warehouse and QA. It is where your material reaches the role least directly and where a screener's attention goes first. B2 (SAP) and A2 (what is prompting the move) come next.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and names no work with planning or QA. Words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on which of those you have worked with. If any of your scheduling involved one of them, say which and what you did, in your own words; if none did, say so plainly and stay with the three depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but the figure is a magnet for probes. Say what you rebuilt and what happened, in the sentence's own terms, and prepare the four defend-the-number points in C1 |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | The material does not show whether you reported on delivery performance. Answer slot: the advert's weekly dispatch line makes a probe likely. If you reported on deliveries in any regular way, say what and how often, in your own words; if you did not, say so plainly and stay with the scheduling |
| F5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, so the link to Excel is this pack's derivation. Answer slot: if the spreadsheet was in Excel, say so; if it was another program, say so plainly and name it |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap on length. Experience length is not a gate. Say it as you wrote it |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | A stated negative plus adjacent work. Words: "I've never used SAP", then "we run our own in-house stock system", and nothing more about what that system is: your material does not say whether it is an ERP. Then how you would learn SAP, said as a plan and never as a past |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The schedule term is met in your own words. Give them as you stated them and add nothing. If the commute comes up, repeat them |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | The figure sits inside the advert's band, which is the pack's observation. Say your figure in your own words and add no range, floor or flexibility |
| F10 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term you meet or do not, so no wording bridges it, and the pack says nothing about it until you give it |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, agenda-led call covering pay, notice, hybrid, motivation, then the team | Highest. A recruiter screen's prior is conversational plus light Skeptic, and Hannah's message lists her topics, which makes it logistics-heavy in a friendly register | Short arc from F6, F2 and F3: "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." Treat the casual questions as scored |
| Skeptic (light) | Quiet probing of the gaps and the motivation | High. The advert's production, QA and SAP language sits against F1 and F7, and "what's prompting a move" is the classic consistency check | Rehearse B1 until it is boring: hold F1's quote at its scope, concede what the material does not show |
| Data-Driven Prober | Pulls on the stock-count figure | Medium-low. A 30-minute screen rarely goes deep, but a figure on your background invites one follow-up | C1: say plainly how much you know about how the figure was counted |
| Pressure | A time-boxed "why you" or a probe on your share of a result | Low. Recruiters seldom stress-test, but a "sixty seconds" version is common | Pause, restate, hold the position through two follow-ups, concede only what the quotes support |
| Case / Strategist | A short live problem on the role | Low for a screen, likely in a later round. Included so you do not meet the style cold | Clarify, objective, options, who to tell, what to record |

## Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey so far." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats, each one a clause the quotes state: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet and the fall in discrepancies. Tell them in your own words. Answer slot: end on what draws you to this role specifically; say it as you would, and if nothing beyond the role fit comes to mind, say that plainly | The opener is nearly certain on a screen, and F6, F2 and F3 are the evidence it draws on. EXP because it tests whether the background is told straight |
| A2 | "What's prompting the move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hannah lists this in her own message, so it is asked. Your reason is stated in your own words above: say it as you wrote it, at that scope. Answer slot: recruiters often listen for what you are moving toward as well. If something about this role draws you, say it in your own words; if the office closing is the whole reason, say that plainly | The reason for leaving is one of the four logistics topics a recruiter screen covers. EXP because it tests consistency of the story |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Your own words: "I'm hoping for £42,000." Say it once and stop talking. If asked what you earn now, you can decline to give a figure and return to the role's band, which the advert gives as £38,000 to £44,000 | A logistics topic in Hannah's own message, asked first or second on most screens. JD because it tests the job's terms |
| A4 | "What's your notice period?" | JD | [grounded] | Give your actual notice period in your own words, and any constraint on the start date as it really is | A logistics topic in Hannah's own message. F10 shows the pack does not know it yet |
| A5 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If a commute follow-up comes, repeat those words and add nothing | A logistics topic in Hannah's message, tied to the advert's hybrid line (F8). JD because it tests a job term |
| A6 | "What do you know about us?" | CO | [generic] | No research reached the pack, so it has no company facts to give. What the advert states: a diagnostic-test manufacturer of about 400 staff, with a site at Avonmouth. Read Quillmoor's own website and recent news before Thursday and say, in your own words, one thing you found and why it matters to the role | Homework depth is checked casually on most screens. CO because it scores company knowledge; the label is generic because the research search was refused |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. Which part of that have you done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Hold what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if any of your scheduling involved planning, the warehouse or QA, say which and what you did, in your own words; if none did, say so plainly, and stay with the three depots. Hold through two follow-ups by returning to what you do, never by adding to it | F1 is where the role's scheduling mandate presses hardest on your material, so the question arrives in some form. JD because it scores a stated requirement |
| B2 | "ERP experience, SAP or similar, is a plus. Where are you with that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it plainly: "I've never used SAP", then "we run our own in-house stock system." Answer slot: if asked what that system does, describe what you actually use it for; if you touch only part of it, say which part. Close with how you would learn SAP, as a plan | F7 is a stated gap the advert marks as a plus, not a requirement. JD because it scores the advert's ERP line |
| B3 | "The role reports weekly on on-time dispatch. What have you reported on?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you reported on deliveries in any regular way, say what and how often, in your own words; if you did not, say so plainly and stay with the scheduling: "I schedule deliveries for our three depots." | F4 is silence in your material, and the advert states the requirement. JD because it scores that line |
| B4 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Selection scaffold: pick the gap your own material shows most clearly, say it plainly, then give the nearest thing your material does carry and how you would close it. The quote above is one candidate. If no gap comes to mind, say that plainly | The standard Skeptic stem on any recruiter screen. JD because it tests honest self-assessment against the advert |

### C. Data-Driven Prober (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Four slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. "I don't know how it was counted" is an honest branch. The pack supplies no method, baseline or assumption | F3's figure is the one number in your material. EXP because it tests whether the claim survives scrutiny |
| C2 | "Which spreadsheet program was the stock-count sheet in, and what did you do in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Answer slot: say which program it was; if it was not Excel, say so plainly and name it. Then describe what you did in it, in your own words, at the scope of "rebuilt" | F5's link to Excel is this pack's derivation. JD because it scores the advert's Excel line |
| C3 | "Talk me through how you chase a supplier when an order slips." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F2: the quote states two beats, scheduling for three depots and chasing when orders slip. Tell them in your own words. Answer slot: if a particular order comes to mind, describe it as it happened; if the chasing is routine, say so | F2 is the evidence for the advert's chasing line. JD because it scores that requirement |

### D. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Hold: the four years and the scheduling and chasing, in those words. Concede, if pushed: "I've never used SAP." Never fold on the core claim to restore harmony | Time-boxed "why you" is the standard Pressure stem. JD because it scores fit against the advert. F6 and F7 are the evidence |
| D2 | "That stock-count result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the sentence says: you rebuilt the spreadsheet. Answer slot: if others contributed to the fall in discrepancies, say who and what; if it was all yours, say so; if you cannot separate the rebuild from other changes, say that plainly | The stem probes attribution, and F3 is the result in your material. EXP because it tests what was yours |
| D3 | "Is this a move to us, or just a move away from Reading?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your reason is stated: say it at that scope. Answer slot: what draws you to this role, in your own words; if the role fit and the location are the whole of it, say that plainly | A motivation-consistency probe from A2, in pressured form. EXP because it tests the story |

### E. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier says a delivery production depends on will be three days late. What do you do first?" | CASE | [generic] | Structure it: what you would ask first (what is affected, what is already in stock), what you want to protect, the options, who you tell and when, and what you record. The question needs no claim about your past | A live problem from the advert's chasing line. Generic because it is a role-family pattern |
| E2 | "The stock system and the warehouse count disagree on a part. How do you work out what happened?" | JD | [generic] | Structure it: confirm the count, check recent movements, find where the two diverge, correct the record, note the cause. No claim about your past | JD content from the advert's stock-records line, CASE delivery; typed JD so the requirement has a JD-tagged question |
| E3 | "Planning wants a batch scheduled for Tuesday, QA has not released the previous batch and the warehouse is full. How do you coordinate?" | CASE | [generic] | Structure it: clarify what is blocking, set the objective, list the options with their cost, say who needs to hear what, and name what you would check afterwards. No claim about your past | The advert's three-way coordination line as a live problem. Generic because it is a pattern |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, E3, D1 |
| Track supplier deliveries and chase late orders | C3, E1 |
| Keep stock records accurate | C1, E2, D2 |
| Report weekly on on-time dispatch | B3 |
| Confident with Excel | C2 |
| 2+ years in operations or logistics coordination | A1, D1 |
| ERP experience (SAP or similar) | B2, B4 |
| Hybrid, two days at Avonmouth | A5 |
| Pay band | A3 |
| Notice period | A4 |
| What is prompting the move | A2, D3 |

## Reverse questions

1. "Who would I work alongside day to day across planning, the warehouse and QA?" Why it lands: it shows you understand the role sits between three teams.
2. "What system does the team use for stock and orders, and how is a new starter trained on it?" Why it lands: it raises the SAP topic on your terms and signals you are thinking about ramp-up.
3. "How is on-time dispatch reported today, and what does the weekly report look like?" Why it lands: it shows you read the advert's reporting line and want to know the standard.
4. "Which two days does the team tend to be at Avonmouth, and is that fixed?" Why it lands: it is a practical question about the pattern Hannah said she would discuss.
5. "What is the timeline from here, and when would you hope someone starts?" Why it lands: it opens the next-steps conversation Hannah has said she will cover and ties to the notice period.
6. "What does a good first three months look like in this role?" Why it lands: it invites a description of the outcome the team wants, and gives you something to prepare against.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has SAP or ERP experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." Then "we run our own in-house stock system", at its own scope. No slot on SAP itself |
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says delivery scheduling, not production scheduling. B1's slot stays inside the three depots |
| My rebuild cut discrepancies by a third | Inflated form of F3 | F3's quote at its own scope: you rebuilt the spreadsheet and discrepancies fell by about a third over a year. The sentence does not say the rebuild alone caused it, and C1 and D2 slots ask only how it was counted and which part was yours |

## Sources

Provided documents: Hannah Lowther's LinkedIn message; the Operations Coordinator advert; your notes on your background and what you would tell her.

Research tier: L1 attempted — searches 3 of 6 sent, all refused; fetches 0 of 2. Nothing from outside your documents is in this pack.

Searches sent: "Quillmoor Diagnostics values" (refused); "Quillmoor Diagnostics interview process Operations Coordinator" (refused); "Quillmoor Diagnostics Avonmouth news" (refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search was refused. Would have fed a values sheet; none is built because no loop source documents a values round |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Search was refused. Would have shown later rounds; Hannah's own message fixes this call only |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Search was refused. Would have grounded A6 and a CO question; both are labeled generic instead |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | No search was sent after the first three were refused. Would have fed an interviewer read; that section is dropped |
| 5. Representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A4 and F10 become your own words
- What the stock-count discrepancy figure measured, and whether the spreadsheet was Excel → C1, C2 and D2 move from answer slots to your own words, and F3 and F5 can rise a band
- Whether any of your scheduling involved planning, warehouse or QA teams, and whether you ever reported on delivery performance → B1 and B3, and F1 and F4
- What draws you to this role, apart from the office closing → A1, A2 and D3
- Permission to run web searches → the company's values, strategy and interview process become real research, and A6 becomes a grounded CO question. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent organisation context
- Anything Hannah says about later rounds → a per-round pack in place of this single-call one
- A tuesday-dossier.md → verified evidence and any objection already worked out, in place of the objection this pack inferred
