I'm reading the rest of the prep-pack rules now, and then I'll build your pack. The invite has one thing I need to flag at the top.
Search access was refused in this session, so I'll build the pack from what you've given me and label company facts as not researched.
Before the prep, one thing in the invite: it says the process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who you're dealing with, and the invite may not come from who it names. Until you know who sent it, hold off on paying anything, depositing a cheque, or sending documents or bank details. Check the invite with Lumenvale itself, using contact details you find on its own website or careers page, never through this chat. If you want the invite weighed, job-underwriter can check it as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. I built it as a hiring-manager round, assuming the support team lead would manage the hire. My web searches were refused in this session, so the pack has no researched company facts. The company questions are generic and labelled that way.

The highest-ROI prep is B1, "You have not worked for a software company. What makes you think you will pick up our product quickly?" The pack coaches a plain acknowledgment ("I've never worked for a software company"), then what your own words support (you use Freshdesk every day), then a learning plan said as a plan.

Say the word and I'll play the Skeptic on B1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job ad text and your CV wording? That would turn the four requirement rows into direct quotes.
Has Lumenvale said anything else about what the chat will cover, and how long do you have before it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Role: Customer Support Specialist (remote). Company: Lumenvale Software. Interviewer: the support team lead, not named in your material. Format: a text chat, from your message. Relationship: built as a hiring-manager round, on the assumption that the support team lead would manage the hire; your material does not say so.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and in a text chat cut each answer to a few sentences you could type in under two minutes.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values a company publishes, or sound judgment where none are known |
| EXP | Whether the claims on your CV survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | How you structure a live problem from the role |

A line marked answer slot is an instruction for the interview. It asks nothing of you here. Meet it with whichever branch is true, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length, but a line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms: for three years you were a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap in what you said, but your material names Freshdesk, not Zendesk, and whether Freshdesk counts as similar is the interviewer's call. Say: "I use Freshdesk every day." Expect a probe on what you do in it |
| F3 | "clear written communication" — the job ad, as you described it | "answering around 60 calls and emails a day" — your message | medium | [grounded] | discovery | The figure counts calls and emails together, so your material does not show how much of it was written. Answer slot: the ad's written-communication line makes a probe on the written share likely. If you know roughly how many were emails, say so in your own words; if you do not know the split, say so plainly and say what you do know |
| F4 | "confidence handling escalations" — the job ad, as you described it | none given | none | [grounded] | discovery | Your material does not say whether escalated contacts reached you. Answer slot: if they did, say what kind and what you did, in your own words; if escalations went to someone else or were not part of your job, say so plainly and describe how you would handle one |
| F5 | Helping teammates learn the process (role-family expectation, not in the ad as you described it) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Say it at its own scope: "I trained four new starters on our refunds process last year." Your material says you trained four new starters on a process, not that you designed the process or ran a programme |
| F6 | Familiarity with the software the team supports (role-family expectation, not in the ad as you described it) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past |

## Persona table

Loop: one session, a text chat with the support team lead, from your message. No other rounds are established, so weights rest on the hiring-manager relationship prior. No values-style round is detected, so there is no values sheet.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live support scenarios: an angry customer, a product problem, an escalation | High. The hiring-manager prior favours live problems from the real job, and the ad's escalation line invites one | Clarify, then structure, then answer; think aloud |
| Skeptic (B) | Quiet probing of F6, F4 and the move from energy to software | High. F6 is a stated gap and F4 is a silent one; the hiring-manager prior includes Skeptic | Rehearse the F6 question until it is boring; plain acknowledgment, then plan |
| Conversational (C) | Friendly opener, journey question, casual tool talk | Medium. A text chat from a team lead tends to open informally, but your material does not say how formal it will be | Prepare a short arc from your own quoted lines; treat casual questions as scored |
| Data-Driven Prober (D) | Reads your lines closely: the 60 a day, the four new starters, the three years | Medium. Every figure in your message is a magnet for a probe | Know what you can and cannot say about how each figure was counted |
| Pressure (E) | Short, challenging prompts: why you, how much was you | Low. The hiring-manager prior does not favour it, and nothing in the invite suggests it | Pause, hold on your quoted facts, concede only what is true |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry for the third time about the same problem and says they will cancel. What do you do before you reply?" | CASE | [generic] | Structure it: read the history first, acknowledge what has already gone wrong, say what you will do and by when, and note who else you may need. The question needs no claim about your past, so the guidance makes none | A live problem of the kind this role handles; CASE because it scores structure; generic because it is a pattern, not a fact about this employer |
| A2 | "A customer says a feature has stopped working and you do not know the product well yet. How do you handle the first ten minutes?" | CASE | [generic] | Structure it: ask what they see and what changed, check whether it is already known, tell them honestly what you do and do not know yet, and hand over with a clear summary if you need help. No claim about your past | F6 is the pack's biggest gap, and this is the live form of it; CASE because it is a decision, not a history |
| A3 | "The ad mentions Zendesk or a similar tool. Which ticketing tool have you used?" | JD | [grounded] "I use Freshdesk every day" | Hold what the quote carries: "I use Freshdesk every day." Answer slot: say what you do in it day to day, in your own words; if asked about a feature or tool beyond that, say plainly which you have used and which you have not | F2 is the evidence for the tool requirement; JD because it scores the stated requirement |
| A4 | "A customer refuses to give details and demands a manager. Walk me through what you do." | JD | [generic] | Structure it: stay calm, find out what outcome they want, say what you can and cannot do, offer the next step, and record it. No claim about your past | The ad's escalation line, tested as a decision because F4 gives no past to probe; JD content, CASE delivery |
| A5 | "Here is a reply: 'Unfortunately we cannot do that.' Rewrite it for a customer who is already upset." | JD | [generic] | Say what is wrong with it first, then rewrite: lead with what you can do, give the reason in one plain line, end with a next step. No claim about your past | The ad's written-communication line, tested live, which also suits a text-chat interview; JD content, CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company. What makes you think you will pick up our product quickly?" | JD | [grounded] "I've never worked for a software company" and "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment in your own words: "I've never worked for a software company." Stay with the one other fact the quotes carry: "I use Freshdesk every day." Then your plan for learning the product, said as a plan in your own words and never as something already done. Follow-up 1 is likely to be how you would learn it: plan only. Follow-up 2, what you would do when a customer asks something you cannot answer: say what you would do, not what you have done. Follow-up 3, whether that is enough: concede that it is a real ramp-up and hold on the two quoted facts | F6 is the likeliest objection in any version of this interview; JD because it scores fit to the job, with Skeptic delivery |
| B2 | "Your background is in energy. Why software support, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Say the background in the quote's terms, then give your actual reason for the move, in your own words. Answer slot: if the reason is partly practical, such as the remote format, say so plainly and say what draws you to the work itself | Motivation consistency is what a Skeptic scores; F1 is the background being asked about; EXP because it tests a story against the CV |
| B3 | "The role needs confidence handling escalations. What have you handled?" | JD | [grounded] | Answer slot: if escalated contacts reached you, say what kind and what you did, in your own words; if escalations went to someone else or were not part of your job, say so plainly and describe how you would handle one, using your A4 structure | F4 is the row where the ad presses and your material is silent; JD because it scores the stated requirement |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name one real weakness, in your own words. Your material points at software familiarity; if you choose it, say "I've never worked for a software company", then your plan to close it, as a plan. Do not offer a weakness you do not have in order to sound modest | F6; a standard Skeptic stem, JD because it scores honest self-assessment against the listed job |
| B5 | "This is a written role. How comfortable are you without the phone?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the line as it stands: "answering around 60 calls and emails a day." Answer slot: what share was email, in your own words; if you do not know the split, say so plainly. Name the assumption in the figure you would defend least, before the interviewer does | F3; EXP because it tests what part of the figure was written, with the weakest-assumption move for a metric |

### C. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. What brought you to apply?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | A short arc built only from the three quoted lines, in that order. Then your actual reason for applying, in your own words | The biography question arrives in every loop; F1, F2 and F5 are the lines it can draw on |
| C2 | "I would love to hear about training new starters. How did that come about?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say the quote at its own scope: "I trained four new starters on our refunds process last year." Answer slot: how it came about, in your own words; if it was assigned to you, or you followed material that already existed, say so plainly | F5; EXP because it tests what was yours, asked in a friendly register |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer situation, a moment you chose the customer, and an outcome you can describe honestly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no values source for this company was read, so VAL is a pattern here, not a mapped value |
| C4 | "What do you like and not like about the ticketing tool you use every day?" | JD | [grounded] "I use Freshdesk every day" | Give your own opinion of the tool you use, in your own words. Do not name features you do not use | F2; JD because casual tool talk is still scored against the tool requirement |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: say how the figure was counted, what it is sensitive to, and which assumption in it you would defend least, in your own words; if you do not know how it was counted, say so plainly. Keep "around" in your wording | F3; EXP because it defends a number |
| D2 | "In the training you mentioned, what was yours and what was the team's?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold at the quote: "I trained four new starters on our refunds process last year." Answer slot: which part was yours, in your own words; if part of it was someone else's, say so plainly | F5; EXP because it tests attribution on a number you gave |
| D3 | "The ad asks for 2+ years in support. What did your three years cover?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Say the quote in its own terms, then describe the role in your own words. Add nothing the line does not carry | F1; JD because it scores the stated requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | Pause, then hold on the three quoted lines. If pushed twice, concede the one real limit in your own words: "I've never worked for a software company." Do not fold on the quoted facts to ease the pressure | F6 against F1, F2 and F5; JD because it scores fit, with Pressure delivery |
| E2 | "That training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold at "I trained". Answer slot: say which part was yours; if part was someone else's, say so plainly and return to the quote | F5; a standard Pressure stem on attribution |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | D3, C1, B2 |
| "experience with Zendesk or a similar ticketing tool" | A3, C4 |
| "clear written communication" | A5, B5, D1 |
| "confidence handling escalations" | A4, B3 |
| Software familiarity (F6, not in the ad as described) | A2, B1, B4, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for someone in this role?" | It shows you are thinking about the ramp-up F6 raises, and gives you the team's own yardstick |
| R2 | "Which ticketing tool does the team use, and what product training does a new person get?" | It ties to F2 and F6 and shows you expect to learn the product |
| R3 | "How are escalations routed, and how much authority does an agent have before one is needed?" | It ties to F4 and shows you take escalations seriously |
| R4 | "How does the team review the quality of written replies?" | It ties to F3 and shows you care about writing quality |
| R5 | "Is there a later step after this chat, such as a call or video, and is there anything I should prepare for it?" | It is a prep question: it tells you whether to rehearse spoken answers as well as written ones |
| R6 | "What does the schedule look like for a remote team, and how is cover shared across time zones?" | A concrete working-pattern question; the ad as you described it says nothing on hours |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk |
| Experience working for or supporting a software company | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never worked for a software company." No slot |
| Designed or ran the refunds process or a training programme | Inflated form of F5 | F5's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says you trained four new starters, not that you designed the process or ran a programme |
| Answered around 60 emails a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day." The limit is the pack's observation: your material gives one figure for calls and emails together |

## Sources

Provided: your message, containing the invite text, the job ad's requirements as you described them, and your background. No full job ad text, CV, interviewer profile or company document was provided.

Searches sent, all refused, so nothing from them is used:

- "Lumenvale Software company values": refused
- "Lumenvale Software interview process customer support specialist": refused
- "Lumenvale Software news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Search was refused. It would have moved a values sheet and the VAL bank; none exists, and C3 is generic |
| 2. `Lumenvale Software interview process customer support` | unavailable | Search was refused. It would have moved the loop structure and persona weights; weights rest on the relationship prior and your own description of the chat |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Search was refused. It would have moved CO questions; the pack has none and A1 to A5 are generic |
| 4. Interviewer name and company | n/a | No interviewer is named, so there is no query to form. The interviewer read is absent |
| 5. Representative Customer Support Specialist JD | skipped | The requirements you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text → the four requirement rows quoted from the ad itself, and any mid-list item such as a named tool or a hours requirement turned into a question
- Your CV text → F1 to F6 quoted from the CV, and a check of the guidance against each line
- The support team lead's name and public profile → an interviewer read, tuned persona weights and a reverse question tied to their path
- Anything the company has said about what the chat will cover → a replacement for the relationship-prior weights
- Search access, or a values page and role description you paste → a values sheet and company questions in place of generic ones; a deeper research pass would add up to 6 more searches and 2 more fetches, several more minutes
- A tuesday-dossier.md → verified evidence and a named most-likely objection, in place of the inferred one
