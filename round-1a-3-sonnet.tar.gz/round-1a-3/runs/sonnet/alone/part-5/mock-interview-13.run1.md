I'll read the reference files the skill requires before building the pack.
Your prep pack is built and saved, and I'm presenting it now. I built it as a recruiter-screen pack from Hannah's own message and your advert. My web searches were refused, so nothing about Quillmoor or Hannah beyond what you pasted is in it, and the company-knowledge questions rest on the advert alone.

The file is `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-5/rooms/case-13-denied-d7c74609/quillmoor-diagnostics_operations-coordinator_interview_pack.md`.

Say the word and I'll play Hannah on B3, the question the pack names as your highest-ROI prep. It asks how far scheduling deliveries carries over to scheduling production between planning, the warehouse and QA.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What's your notice period? Hannah has it on her agenda and your material doesn't say, so A4 and F11 stay open until you tell me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Operations Coordinator, Quillmoor Diagnostics: recruiter screen pack

Interviewer: Hannah Lowther, Talent Partner (recruiter). Thursday 2pm, a 30-minute phone call; she rings the mobile number on your application. Candidate: Sam.

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding, not a script: say it in your own words. An answer slot is an instruction for the call, not a question for you now: it tells you what to say if a branch is true and what to say plainly if it is not. Question IDs run by persona (A to E, then G; F is kept for the fit snapshot's rows).

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience claims survive a follow-up; what was actually you |
| JD | Whether you can do the listed job, gaps included, and whether its terms suit you |
| CO | How much you know about the company and why you want it |
| CASE | How you structure a live problem from the role |

## Fit snapshot

Requirements are quoted from the advert you pasted, or from Hannah's own message. Evidence is your own words from your message to me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries across three depots, and nothing in it names production, planning or QA. The words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on production scheduling likely. If any of your scheduling involved those functions, say which and what was yours, in your own words; if it did not, or it was not yours, say so plainly and stay with the three depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you chase suppliers when orders slip |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it. Say it as you said it, and expect the four questions a figure raises: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours (C1, C2) |
| F4 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says a spreadsheet, and does not say which tool. The bridge is the sentence at its own scope: "I rebuilt our stock-count spreadsheet." Answer slot: the advert's Excel line makes a probe on the tool likely. If the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or Excel was a small part of it, say so plainly and stay with the rebuild |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: the advert asks for weekly reporting on on-time dispatch. If you already report a dispatch or delivery measure regularly, say what and how often, in your own words; if you do not, or it is not yours, say so plainly, then say how you would set one up, as a plan and not as a past |
| F6 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | You stated it, and the advert lists it as a plus, not a requirement. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Whether "or similar" reaches your in-house system is the interviewer's call, and the sentence does not say you work in it yourself. Words: "We run our own in-house stock system." Answer slot: if you use it yourself, say what for, in your own words; if you do not, or it is not an ERP, say so plainly and stay with what the sentence says |
| F8 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Lead with the sentence in its own terms; a line from your message alone, so expect it to be probed |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your own words show this term met. Say them as given, with nothing added; if the journey comes up, your own words again |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advert's stated band. Say it as you said it and stop |
| F11 | "your notice period" — Hannah's message to you | none given | none | [grounded] | hard_gate | Your material does not establish it. Nothing in the pack can fill it for you; A4 holds the slot |
| F12 | "what's prompting a move" — Hannah's message to you | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | This answers her question as asked. Say it in your own words, no longer than the sentence carries |

## Reading the interviewer

Hannah's own message is the only source here: no public footprint was established (see Sources), so nothing about her career is used.

- She set her agenda in advance: salary expectations, notice period, how the hybrid pattern would work, and what's prompting the move. A3, A4, A5 and A2 are therefore near-certain, and are the four to have ready in your own words.
- She said she would tell you about the team and next steps after those four, so questions about the team fit best at the end, in the reverse-question slot.
- There is no shared professional path to offer, because none was established, so no mirror opportunity is claimed.

## Persona table

The relationship is a recruiter screen, so the priors are Conversational plus a light Skeptic. Hannah's message names one session, 30 minutes, run by her, which fixes the session count; it says nothing about later rounds, so no hiring-manager weighting is assumed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (A, 5 questions) | Friendly walk-through of your background, then her four logistics topics in a chatty register | Highest. She listed pay, notice, hybrid and the reason for moving herself, and recruiter screens open with a biography question as a prior | Have each logistics answer ready in your own words, from the quotes in A2 to A5; treat the casual register as scored |
| Skeptic, light (B, 4 questions) | A quiet probe on the gaps: production scheduling, SAP, why this role | Medium-high. The advert lists planning, warehouse and QA coordination and SAP, and F1 and F6 are where your material is thinnest | Rehearse B3 until it is boring: say only what the quotes carry, and state the limit plainly |
| Data-Driven Prober (C, 3 questions) | Asks how the stock-discrepancy figure was counted and what tool you used | Medium-low. She may not dig, but the figure is the most checkable line you have | Know what you can and cannot say about the figure; "I don't know how that was counted" is an honest branch |
| Case / Strategist (D, 4 questions) | Short live scenario or "what would you put in the report" | Medium-low for a recruiter; high for the next round if one exists, so worth meeting once now | Clarify, structure, then answer; claim nothing about your past in a case |
| Pressure (E, 2 questions) | "Why you over someone with SAP?" or "Is this a fallback?" | Low-medium. A recruiter may test composure lightly | Pause, restate, hold on your own words, concede specifically |
| Peer Evaluator (G, 2 questions) | Seam and credit questions | Low in a recruiter screen; likelier from the team later | Offer seam principles, not made-up specifics |

## Question banks

Highest-ROI prep in this pack: B3, the production-scheduling objection. It is the headline duty, it is where your material says the least, and it will be asked in some form.

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far and what you're doing now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F8, F2 and F3, three beats the quotes state: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down about a third over a year. Tell each in your own words in about 90 seconds, saying "about a third" as you said it, and close on your reason for looking, from A2 | The biography opener decides what the rest of the call returns to; F8, F2 and F3 are the lines she will pick up. EXP because it tests what you will claim about your own work |
| A2 | "What's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Reason-for-leaving slot, filled with your own words: the office closing next year, the only offer being Reading, which you don't want. Say that and no more than it carries; add no detail about how the closure was handled. If she follows up on Reading, your own words again, quoted | She named it as an agenda item and F12 carries it. EXP because it tests whether your story is consistent and honest |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Pay slot, filled with your own words: "I'm hoping for £42,000." Say it plainly and stop. If she asks what you earn now, you may decline politely and bring it back to this role's band, without giving a figure | F10 is your figure and sits inside the advert's band; JD because the band is the listed job's term |
| A4 | "What's your notice period?" | JD | [grounded] | Notice slot: give your actual notice period, as it is. Your material has no figure, so the pack supplies none | F11 is an open gate the material does not establish, so this row asks and assumes nothing; JD because it is a term of the listed job |
| A5 | "How would the hybrid pattern work for you, two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Location slot, filled with your own words: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. Say it as given; if the journey comes up, repeat your own words | F9 shows the term met. JD because the pattern is stated in the advert |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Choose a weakness your material itself shows, and name it plainly first. The advert lists ERP as a plus and you have never used SAP: "I've never used SAP." Then how you would learn it, as a plan. Production scheduling is the other candidate; if you choose it, use B3's slot. Never name a weakness you do not have to look modest, and do not hide one | F6 and F1 are where your material is thinnest, so this question lands there. JD because it scores the listed job; Skeptic in delivery |
| B2 | "SAP is a plus for this role and you haven't used it. How much does that matter?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold-then-concede. Concede at once and plainly: "I've never used SAP." Hold only the sentence's other half: "We run our own in-house stock system." Answer slot: if you use that system yourself, say what for, in your own words; if you do not, or it is not an ERP, say so plainly and stay with what the sentence says. Then your plan to learn the system they use | F6 and F7 are the exact gap the advert names. JD because the question scores a listed plus |
| B3 | "Your experience is scheduling deliveries. This role schedules production between planning, the warehouse and QA. How far does one carry to the other?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling involved production, planning or QA teams, say which and what was yours, in your own words; if it did not, or it was not yours, say so plainly and stay with the three depots and the suppliers you chase when orders slip. Follow-up one, "what would you need to learn?": say what you would ask first about how planning, the warehouse and QA's schedules fit together, as a plan. Follow-up two, "could you do this from day one?": concede specifically that your material is the delivery side, and hold it there; add nothing to it. Follow-up three, "have you scheduled production?": answer from your own experience, either branch, then return to the quote | F1 is the thinnest transfer on the headline duty. JD because it scores a stated responsibility; Skeptic in delivery |
| B4 | "What draws you to Quillmoor, beyond the office closing?" | CO | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Answer slot: if something specific in the advert or about Quillmoor appeals to you, say what, in your own words. The advert's own lines you may quote: "diagnostic-test manufacturer", "about 400 staff", "our Avonmouth site in Bristol". If the move is mainly the office closing, say so plainly and say what in the role matches your current work, using only your own sentences. Do not manufacture an interest | F12 says why you are leaving, and leaves the why-here half open. CO because it tests homework and genuine interest |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend-the-number slots, in your own words: how it was counted, and what the figure is sensitive to. Say "about a third over a year" exactly as you said it. If you do not know how it was counted, say so plainly. Supply no baseline you were not given | F3's figure is the most checkable line in your material. EXP because it tests whether the claim survives scrutiny |
| C2 | "How much of that was actually you, and which part would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what was yours, from the sentence: you rebuilt the spreadsheet. Then name, in your own words, the assumption behind "about a third" you would defend least, before she does. Answer slot: if anyone else's work contributed to the fall, say what; if nothing else did, say so plainly | The attribution and weakest-assumption slots a figure raises (F3). EXP because it scores precise attribution |
| C3 | "How confident are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot, as in F4: say which tool the spreadsheet was in. If Excel, say what you did in it, in your own words; if it was another tool, or Excel was a small part, say so plainly and stay with the rebuild | F4 is a discovery gap: the advert's Excel line is a likely probe. JD because it scores a listed requirement |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier tells you on Monday that an order QA needs for Thursday's production run will be a week late. What do you do?" | CASE | [generic] | Structure: clarify first (what the order feeds, the current stock position, what planning can move); state the objective; set out options with planning, the warehouse and QA; say how you would communicate and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing and scheduling lines (F1, F2). `[generic]` because it is a pattern, not a fact about Quillmoor |
| D2 | "This role reports weekly on on-time dispatch. What would you put in that report?" | JD | [generic] | Ask how Quillmoor defines on-time dispatch before proposing anything. Then a short structure: the measure, the late items and the reason for each, and what changed since last week. Answer slot from F5: if you already report such a measure, say what; if not, say so plainly | F5 has no evidence, so this is where the requirement is tested. JD because it scores a stated duty |
| D3 | "The warehouse count says 120 and the stock record says 112. Where do you start?" | CASE | [generic] | Structure: confirm both numbers are for the same item, location and time; check movements since the count; recount; find the cause before adjusting the record; note what you would change to stop it recurring. No claim about your past | A live problem from the advert's stock-records line (F3). `[generic]` because the numbers and steps are a pattern |
| D4 | "What do you know about Quillmoor?" | CO | [grounded] | Search was unavailable, so this rests on the advert alone: "diagnostic-test manufacturer", "about 400 staff", the Avonmouth site in Bristol. Say what you have actually read yourself, and say plainly that you have read the advert and would like her account of the team, which she offered. Do not use anything about Quillmoor from outside the advert | Homework check; the pack could not establish more. CO because it scores company knowledge |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone who already has SAP and production scheduling experience?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause and restate. Hold only what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers when orders slip. Concede specifically: "I've never used SAP." Hold through two follow-ups by returning to those words, never by adding to them | F8, F2 and F6 are what you can stand behind and where the limit is. JD because it scores fit against the listed job; Pressure in delivery |
| E2 | "You don't want to go to Reading, so is this just a fallback?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Pause and restate. The position you hold is your own stated words: the office closing, Reading the only offer, and you don't want it. Concede what is true, that the closure prompted the search, and say it plainly. If something about this role appeals, use B4's slot; if nothing yet does, do not manufacture it | F12 is exactly what this question presses. EXP because it tests consistency under pressure |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Planning and the warehouse disagree about a schedule. Where do you come in, and what happens when we disagree?" | CASE | [generic] | Offer principles, not made-up specifics: get both constraints on the table, find what each side cannot move, propose options, escalate with a recommendation when they cannot agree. No claim about your past | The advert's planning, warehouse and QA coordination line (F1) as a collegial seam question. `[generic]` because it is a pattern |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams where you can say what was yours and what was theirs, in your own words; use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme comes from the advert's three-function coordination line. EXP because it tests attribution honesty |

## Requirement coverage

| Advert or recruiter requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B3, D1, G1 |
| Track supplier deliveries and chase late orders | D1, E1 |
| Keep stock records accurate | C1, C2, D3 |
| Report weekly on on-time dispatch | D2 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B1, B2 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Hybrid, two days a week at Avonmouth | A5 |
| £38,000–£44,000 | A3 |
| Notice period (Hannah) | A4 |
| What's prompting a move (Hannah) | A2, B4, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work most closely with across planning, the warehouse and QA?" | Picks up the advert's own three functions, so it shows you read it |
| R2 | "How is on-time dispatch measured at the moment, and who sees the weekly report?" | Ties to the advert's weekly reporting line (F5) and tells you what the job is judged on |
| R3 | "Which ERP does the Avonmouth site run, and how is a new starter trained on it?" | Turns the SAP gap into a practical question about the system you would actually use (F6, F7) |
| R4 | "What would a good first three months look like in this role?" | Shows you are thinking about delivering, and gives you the criteria |
| R5 | "After this call, who would I speak to next, and what would that conversation focus on?" | You do not know the later rounds; this lets you prepare for them |
| R6 | "Is this a new post or a replacement, and what would you like the next person to change?" | Surfaces what the role is for, with no assumption about the answer |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says deliveries across three depots, not production. B3's slot stays inside the deliveries |
| Confident or proficient in Excel | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet." The material says a spreadsheet, not the tool. C3's slot asks only which tool |
| Has ERP experience through the in-house system | Inflated form of F7 | F7's quote at its own scope: "We run our own in-house stock system." The sentence does not say you work in it |
| Has used SAP | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used SAP." No slot |
| Was made redundant, or was pushed out | Inflated form of F12 | F12's quote at its own scope. The material says the office is closing and the only offer is Reading, which you don't want |
| Fully flexible on office days | Contradicted by F9's quote | "I wouldn't want more than three." Nothing more |
| £42,000 as a minimum, or as something that can move | Inflated form of F10 | "I'm hoping for £42,000." No cell adds a floor, a range or flexibility you did not give |

## Sources

Provided documents: the advert you pasted; your message about your background and what you would say; Hannah Lowther's LinkedIn message as you quoted it. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search refused (query: "Quillmoor Diagnostics values"). Would have fed a values cheat sheet; none is built, as no values-style round is detected for a recruiter screen |
| 2. Quillmoor Diagnostics interview process operations coordinator | unavailable | Search refused. Persona weights rest on your own message and the recruiter-screen prior, not on a documented loop |
| 3. Quillmoor Diagnostics Avonmouth news strategy | unavailable | Search refused. D4 and B4 stay at the advert's own lines; CO questions are not strategy-grounded |
| 4. Hannah Lowther Quillmoor Diagnostics | unavailable | Search refused. The interviewer read uses only her own message |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A4 and F11 would carry it in your own words in place of an open slot
- Your CV → fit snapshot rows built from your message alone gain further quoted evidence, and some `low` rows may rise
- Which tool your stock-count spreadsheet was in, whether you use the in-house stock system yourself, whether any of your scheduling involved production, planning or QA, and whether you report any dispatch measure → F1, F4, F5 and F7 become quoted stories in place of answer slots, and B3, C3 and D2 sharpen
- Search access, or the company's values, careers page or any strategy material pasted in → CO questions become strategy-grounded, loop structure and the interviewer read get real sources, and a values cheat sheet is built if a values round is documented
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → strategy brief, interviewer talks and writing, role-family loop reports, recent organisation context
- The date and format of any later round (for example a hiring-manager interview) → persona weights recomputed, and a per-round mini-pack
- A tuesday-dossier.md from earlier work → verified evidence and constraints would sharpen the bank, but the pack stands without one
