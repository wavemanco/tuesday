I'll read the skill's reference files before building the pack.
I've finished the pack and am writing up the hand-off now.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-5/rooms/case-13-denied-6193f822/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for the recruiter phone screen with Hannah. I used your message as your background, since there's no CV. Your advert and Hannah's four agenda items set the questions.

My web searches for company values, interview process, news and Hannah's public profile were all refused, so nothing in the pack comes from outside research. The company-knowledge question (A6) rests on the advert alone. The pack lists exactly what was affected.

- **Most important to rehearse:** B1, the "is this about Quillmoor, or just needing a Bristol job after the closure?" question. Your reason for moving is the office closing, not something about this role, so expect it in some form. The pack covers how to hold your honest reason and what to say about what draws you to the role.
- **Biggest gaps against the advert:** production scheduling across planning, the warehouse and QA (your material covers delivery scheduling for depots), SAP, and the weekly on-time dispatch report. The pack gives you wording that stays within what you told me, plus slots for you to answer truthfully either way.
- **Pay, hybrid and your reason for leaving:** your figure of £42,000 sits inside the advertised band. Your hybrid limit and your Reading reason are in your own words in A2, A4 and A5, and the pack adds nothing to them.
- **Notice period:** you didn't give one, so A3 tells you to state your actual notice, as it stands in your contract. It's the one thing Hannah will ask that I couldn't prepare for you.

Say the word and I'll play Hannah and run B1 or the pay and notice questions as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to a Word document if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter phone screen with Hannah Lowther (Talent Partner), Thursday at 2pm, 30 minutes. She will ring the mobile number on your application. Her stated agenda, in her words: "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps."

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for your own words, not a script: where a row says "answer slot", it is an instruction for the call, and the honest answer is whichever branch is true for you.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background claims hold up; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its work |
| CASE | A live problem from the role, answered with structure |

Highest-ROI prep in this pack: B1, the "is this about Quillmoor, or about needing a Bristol job" question. Hannah's own agenda includes "what's prompting a move", and your reason for moving is a reason to leave rather than a reason to join. Rehearse B1 until it is boring.

## Fit snapshot

Sources: the advert you pasted, Hannah's message and your message. There is no CV in hand, so every evidence quote is from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe. Lead with the role and the years in the quote's own terms |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who your scheduling touches likely. If any of it meant working with other teams, say which and how, in your own words; if it did not, or none of it was yours, say so plainly and stay with the depots |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote already speaks to this in the advert's terms: you chase suppliers when orders slip. Say it at that scope |
| F4 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote touches supplier deliveries without showing how they are tracked. Answer slot: if you keep track of what suppliers have promised, say how, in your own words; if there was no such tracking, or it was not yours, say so plainly and stay with chasing suppliers when orders slip |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote reaches stock accuracy in role terms. It carries a figure, so expect the defend-the-number probe in C1: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show reporting of this kind. Answer slot: if you report on deliveries or dispatch regularly, say what and how often, in your own words; if you do not, say so plainly and stay with what the stock-count spreadsheet quote carries |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet and does not name the tool. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, or you used little of it, say so plainly and stay with the rebuild |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | A plus, not a requirement. The words: "I've never used SAP", which is your stated negative. The in-house system stays at the quote's scope: "we run our own in-house stock system." Answer slot: if you work in that system day to day, say what you do in it, in your own words; if you do not, or it is not that kind of system, say so plainly. Then a plan for how you would learn the system here, said as a plan and never as a past |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your stated figure sits inside the advertised band. Say it in your own words; nothing about it needs defending |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your pattern and the advert's match. If asked about it again, your own words are the answer |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Your material does not state it. Logistics slot: give your actual notice period, in your own words |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Your reason is already stated. Say it in those terms; the pull toward this role is a separate answer, in B1 |

## Persona table

Weights start from the recruiter-screen prior, which is a conversational register with a light Skeptic. Hannah's own message then fixes this call's agenda. No source I could read establishes the later rounds, so beyond this call the weights are flat and rest on a generic pattern, not on Quillmoor's process. No values-style round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly questions about your background, pay, notice, hybrid and why you are moving | High: all four of Hannah's stated items are logistics and motivation, asked in a friendly register, and they are still scored | Say each answer in your own words, once, and stop; the quotes in A1 to A5 are your material |
| B. Skeptic | Quiet probing of why Quillmoor, the production-scheduling step and the SAP gap | Medium: the prior says "light", but "what's prompting a move" invites the push-versus-pull question, and F2 and F8 are the thinnest rows | Rehearse B1 until it is boring; state limits plainly where F2 and F8 stop |
| C. Data-Driven Prober | Asks how the stock-count figure was counted | Low on a recruiter call, higher with a later hiring manager; the figure in F5 is the likely target in any case | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| D. Pressure / Stress | Time-boxed "why you" and attribution probes | Low: a friendly screen rarely pushes, but a short "why you" is common | Hold your quoted position through two follow-ups; concede specifically what you do not know |
| E. Case / Strategist | A live problem from the role | Low on this call; the advert's duty to chase late orders is where a later hiring manager would naturally set one | Clarify, structure, then answer; think aloud |

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background and what you're doing at the moment." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc in three beats, each a clause those quotes state: the role and the years, the scheduling for three depots and chasing suppliers when orders slip, the stock-count spreadsheet rebuild and the fall in discrepancies. Order them as the advert does. Tell them in your own words and add no detail the quotes do not carry | The first question on almost every screen, and F1, F3 and F5 are the rows it draws on; EXP because it tests what you say you did |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot: say your figure in your own words, the one you have given, and stop. If asked about your current pay, you can say you would rather talk about what this role pays; give no figure for that | Hannah named salary expectations as her first item; F9 is the row. JD because pay is a term of the listed job |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, as it stands in your contract, in your own words. If asked whether it can change, say what is actually true for you and nothing more | Hannah's second item; F11 is the row. JD because it is a term of the listed job |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot: say it in those words, including the limit. If she asks about the commute or whether three is firm, your own words are the answer again: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hannah's third item; F10 is the row. JD because the advert states the pattern |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the facts those words carry: the office closes next year, the only offer is Reading, and you do not want it. If she asks about Reading again, your own words again: "the only offer is relocating to Reading, which I don't want." Pair it with the pull in B1 | Hannah's fourth item; F12 is the row. EXP because it is a question about your own history and motives |
| A6 | "What do you know about us so far?" | CO | [grounded] "diagnostic-test manufacturer, about 400 staff" — the advert | Start from what the advert says about Quillmoor. Answer slot: if you have read anything beyond the advert, say what and where, in your own words; if you have not, say so plainly and work from the advert's own duties | Homework depth is scored even when asked casually. Company research could not run for this pack, so this question rests on the advert alone |
| A7 | "Where else are you in process?" | EXP | [generic] | Answer truthfully and briefly: say plainly where you actually are, and say nothing about other employers or offers that is not so. If there is nothing to report, say that | Recruiters ask it to gauge timing; generic because it needs no claim from your material |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Is this move about Quillmoor, or mainly about needing a Bristol job after the closure?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want."; "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | The highest-ROI rehearsal in this pack. Hold what you said: the office is closing and you do not want Reading. Do not pretend the closure is not the trigger. Answer slot: if something in the advert appeals to you, say what, in your own words; if the move is mainly the closure, say so plainly and say what in the advert you would want to do. Follow-up 1, "would you be looking if the office weren't closing": answer from your own situation, and if you would not be, say so plainly. Follow-up 2, "what if the Reading offer is still open": your own words again, quoted above, and nothing added. Hold through both by returning to those words, never by adding to them | The objection arrives in some form because F12 is a reason to leave, not a reason to join, and this is the question a screen exists to ask; F10 shows the pattern is workable. EXP because it tests motive consistency |
| B2 | "Which part of this role would be the biggest step up for you?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say it at the quote's scope: "I schedule deliveries for our three depots." The advert's planning, warehouse and QA line is the likely target. Answer slot: if any of that scheduling meant working with other teams, say which and how, in your own words; if it did not, or none of it was yours, say so plainly and stay with the depots. Then a plan, said as a plan: how you would learn how production schedules are set here | F2 is where the advert presses hardest and the quote is thinnest. JD because it scores the stated duty |
| B3 | "The advert says ERP experience such as SAP is a plus. Where are you on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain words from your stated negative: "I've never used SAP." Then the in-house system at its own scope: "we run our own in-house stock system." Answer slot: if you work in that system day to day, say what you do in it, in your own words; if you do not, or it is not that kind of system, say so plainly. Close with how you would learn the system here, as a plan | F8 is a plus rather than a requirement, so a plain answer costs little and a stretched one costs a lot. JD because it scores the stated plus |
| B4 | "Are you confident with Excel? What would you say you do in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from the quote at its scope: you rebuilt the stock-count spreadsheet. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, or you used little of it, say so plainly and stay with the rebuild. Name no functions you did not use | F7 is the requirement the quote touches without naming the tool. JD because it scores a stated requirement |
| B5 | "The role includes a weekly report on on-time dispatch. What's your experience of that kind of reporting?" | JD | [grounded] "report weekly on on-time dispatch" — the advert | Answer slot: if you report on deliveries or dispatch regularly, say what and how often, in your own words; if you do not, say so plainly and stay with the stock-count spreadsheet quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | F6 is the one requirement your material is silent on, and it is a mid-list item that goes missing. JD because it scores a stated duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the quote's own terms: "about a third", "over a year". Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Where you do not know how it was counted, say so plainly. Name no method or baseline you cannot repeat under a second question | The one headline figure; F5 is the row, so it is a magnet for probers. EXP because it tests attribution and precision |
| C2 | "What did you rebuild in the spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you rebuilt, at the quote's scope: the stock-count spreadsheet. Answer slot: if others contributed or the rebuild was partial, say so plainly; if it was wholly yours, say that, in your own words | A follow-up to C1 that probes the verb "rebuilt"; F5 is the row. EXP because it tests what was actually yours |
| C3 | "How do you keep stock records accurate day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The quote carries the spreadsheet rebuild and the fall in discrepancies. Answer slot: if there is a routine you follow beyond it, say what, in your own words; if there is not, say so plainly and stay with the rebuild | The advert's stock-records duty, F5. JD because it scores a stated duty |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Thirty seconds: why you over someone who's worked in manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold the quoted position through two follow-ups: the years, the role, the scheduling and the chasing, at those scopes. Concede specifically where the advert's duties go beyond them. Answer slot: if you have worked in a manufacturing setting, say what; if you have not, say so plainly | The advert names planning, the warehouse and QA, and F1, F2 and F3 are where this lands. JD because it scores fit to the listed job |
| D2 | "That stock-count result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold on the quote: you rebuilt it. Answer slot: if others contributed to the rebuild or to the fall in discrepancies, say who and what; if it was all yours, say so plainly, in your own words. Concede explicitly what you do not know about why the number moved | An attribution probe on F5. EXP because it tests what was actually yours |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Three suppliers are late on the same morning and production is due to start. What do you do first?" | CASE | [generic] | Structure it: what you would ask first, which orders are most urgent and why, who you would tell, and what you would record. The question needs no claim about your past, so the guidance makes none | The advert's chase-late-orders duty set as a live decision; generic because it is a pattern for the problem, not a fact about this employer |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1, D1 |
| Coordinate production schedules between planning, the warehouse and QA | B2, D1, E1 |
| Track supplier deliveries and chase late orders | A1, E1 |
| Keep stock records accurate | C1, C2, C3, D2 |
| Report weekly on on-time dispatch | B5 |
| Confident with Excel | B4 |
| ERP experience (SAP or similar) a plus | B3 |
| £38,000 to £44,000 | A2 |
| Hybrid, two days a week at Avonmouth | A4 |
| Notice period (Hannah's agenda) | A3 |
| What's prompting a move (Hannah's agenda) | A5, B1 |
| About the company | A6 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I be coordinating with day to day across planning, the warehouse and QA?" | The advert names all three, and it signals you are thinking about the seams between them |
| R2 | "Which system do planning and the warehouse use for stock and orders, and how is training handled?" | It turns the SAP gap into a ramp-up conversation instead of a deficit |
| R3 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It shows you have read the reporting duty and want to know what good looks like |
| R4 | "Who would I meet after this call, and what would that conversation focus on?" | It lets you aim your next round, and it is a process question Hannah can answer |
| R5 | "How is the two-day pattern at Avonmouth set: fixed days, or agreed within the team?" | It confirms the advert's pattern in practice, which is a term you will be living with |
| R6 | "What would good look like in the first three months?" | A standard question that signals intent to deliver; generic, so ask it in your own words |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says delivery scheduling, not production scheduling. B2's slot stays inside the depots |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The pack's observation is that the material does not call it an ERP |
| Has the SAP experience the advert calls a plus | Negative you stated, F8 | The plain acknowledgment from your words: "I've never used SAP." No slot |
| Confident Excel user | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The pack's observation is that it says spreadsheet, not Excel |
| Cut errors by exactly a third, or entirely through the rebuild | Inflated form of F5 | F5's quote at its own scope: "about a third over a year." The pack's observation is that the quote does not say why the figure moved |
| Open to more than three office days | Contradicted by your quote, F10 | "I wouldn't want more than three." Nothing more |
| Willing to relocate to Reading | Contradicted by your quote, F12 | "the only offer is relocating to Reading, which I don't want." Nothing more |

## Sources

Provided documents: the advert for Operations Coordinator at Quillmoor Diagnostics; Hannah Lowther's LinkedIn message; your message. No tuesday-dossier.md was present.

Searches sent, all refused (permission was not granted), so nothing came back:

- "Quillmoor Diagnostics company values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth Bristol news" — refused
- "Hannah Lowther Quillmoor Diagnostics Talent Partner" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have supplied published values; the question bank has no VAL questions because no values-style round is detected, so it would have moved A6 only |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have named later rounds; persona weights beyond this call stay flat and generic |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Would have fed a strategy-grounded CO question; A6 rests on the advert alone |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have supported an interviewer read; that section is absent and R-questions are role-generic |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → F1 to F8 are quoted from your message; a CV would let the evidence cells quote its lines, and could upgrade F6 and F7 if it names reporting or Excel
- Your answers to the slots in F2, F4, F6, F7 and F8 → those rows move from discovery or transferability toward grounded evidence, and the matching bank guidance sharpens
- Your actual notice period → F11 moves from none given to a quoted row, and A3's slot fills in your own words
- Search permission for company research → the four unavailable rows above could return; values, loop structure, recent news and Hannah's public footprint would sharpen A6, the persona weights and the reverse questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for strategy-grounded CO questions; offered once, on your say-so
- Hannah's prep email, or anything she says about later rounds → coverage of any pre-declared deliverable, and per-round mini-packs if there is a schedule
- A tuesday-dossier.md from an earlier evaluation of this role → an evidence-derived top objection and absolute guardrails in place of the locally built list above
