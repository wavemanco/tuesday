Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-5/rooms/case-9-canned-9cd27c55/halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for the one 45-minute panel in your invite, with the principal and two fourth-grade team members. It's built from your invite, your résumé, and a representative fourth-grade posting, because I don't have the school's own. The posting-based rows are labelled as inferred for that reason.

Your SSN isn't needed for interview prep. I haven't used or saved it, so there's no need to send it again. I also left your license number out of the pack and out of every search.

Say the word and I'll play the principal on B1, the question about you never having taught fourth grade, which the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the school's own job posting you can paste in? It would turn six inferred rows into grounded ones.
2. Did HR or the school say anything about what the panel will cover, or ask you to bring something such as a sample lesson?
3. Do you want a deeper research pass, with up to 6 more searches and 2 more page fetches and several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Session:** one 45-minute panel on Thursday — Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Relationship:** panel — the principal as the hiring-manager seat, two grade-level teachers as peer seats

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Every question carries both, plus a provenance label, answer guidance and a rationale.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether the claims in your material survive scrutiny, and what was actually yours |
| JD | The stated responsibilities and qualifications, gaps included |
| CO | How well you know the district's current direction |
| CASE | A live problem from the actual job, answered with structure |

Provenance labels: `[grounded]` traces to your material or to a cited source; `[inferred]` is derived from a representative posting or an adjacent source; `[generic]` is a pattern with no claim about you or this district.

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview: it names a likely probe and gives two honest branches, and it asks nothing of you here. Either branch is a good answer; the practice it names is never required to have happened. Question IDs skip the letter F so they never collide with fit-snapshot rows F1 to F11.

The invite describes one session, so this is a session-mode pack, not a loop.

## Fit snapshot

The posting for this role was not supplied. Rows quoting a posting use a representative fourth-grade posting (named in Sources), so they are `[inferred]` and typical of the role, not this school's own list.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Met on your own words, so there is no bridge to build. Say it in the quote's own terms, plainly. Grade 4 sits inside the grades 1–6 your quote states. The pack has not inspected the state registry, so checking your registration shows as active before Thursday is yours to do |
| F2 | "plan and teach reading, writing, math, science and social studies" — representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your material says six years of third grade, not which subjects you taught or planned. Answer slot: the posting lists five subjects, so expect a probe on which you taught. Say which, in your own words; if some were taught by someone else, or you taught fewer, say so plainly and stay with "Six years teaching third grade at a public elementary school in Joliet" |
| F3 | "differentiate instruction using assessment data" — representative posting | none given | none | [inferred] | discovery | Your material is silent on this. Answer slot: expect a probe on using assessment data. If you adjusted your teaching using assessment results, say what you looked at and what changed, in your own words; if you did not, or it was not yours to do, say so plainly and say how you would start |
| F4 | "keep clear classroom routines" — representative posting | none given | none | [inferred] | discovery | Your material is silent on this. Answer slot: expect a probe on routines, a topic the district's hiring page names for panels. If you set routines in your own room, say which and why, in your own words; if there were none, or they were set for you, say so plainly and say how you would set them up |
| F5 | "communicate regularly with families" — representative posting | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you write it, weekly, to families |
| F6 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your material says an email, not a conversation, and the words stay there: "I write a weekly email to families." Answer slot: the published belief is about speaking with families, so expect a probe on direct contact. If you speak with families directly, say how, in your own words; if you do not, or there was no such step, say so plainly and stay with the email |
| F7 | "work with the grade-level team" — representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | presentation | The first quote already reaches working with the grade-level team in other terms. Words: "In 2024 I led our grade level's move to a new reading curriculum." Nothing is added to it. Your stated limit stands beside it, and the words for it are yours: "I haven't been a team lead." |
| F8 | "experience in grades 3 to 5 preferred" — representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | The quote is third grade, inside the posting's range, so no bridge is needed. Lead with it as written: six years, third grade, a public elementary school in Joliet |
| F9 | "Fourth Grade Teacher" — HR invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan in your own words and never as a past. The nearest thing your material carries stays at its own scope: third grade (F8) |
| F10 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | "I've run the after-school reading club for the last two years" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Your material says a reading club and a curriculum move, not a reading plan for any child, and the words stay at those two sentences. Answer slot: the published belief is about a reading plan for every student, so expect a probe. If any child you taught had a reading plan, say what it was and whose it was, in your own words; if none did, or it was not yours, say so plainly and stay with the club and the move |
| F11 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: expect a probe on how a result shaped your teaching. If a result changed what you taught next, say so in your own words; if no such time comes to mind, say so plainly and say how you would use a result |

## Reading the interviewer

Public professional footprint only: Principal Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist, per an Illinois principals' forum speaker page. That page says her 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. Nothing is known about the two fourth-grade team members, so no read is offered for them.

- Expect reading instruction to be asked about in reading terms, so rehearse A1, D2 and E1 aloud.
- Her public path is reading in the upper elementary grades. Ask about her work (reverse question 1) rather than quoting her talk back to her.
- Mirror opportunity: a shared professional domain, not a shared jump. Your material that sits in that domain is "I led our grade level's move to a new reading curriculum in 2024" (F7) and "I've run the after-school reading club for the last two years" (F10). Say them as written and let her draw the connection.

## Persona table

The weighting is shown so you can recalibrate. Panels take each member's top two personas. The principal's seat is hiring-manager (Case/Strategist and Skeptic); the two team seats are peer (Peer Evaluator and Data-Driven Prober). The loop is established by the invite (one 45-minute panel, the principal and two grade-level teachers) and the district's how-we-hire page, which lists panel topics as reading instruction, classroom routines and how you work with families. No values-style round is documented, so the three published beliefs theme the E bank without a dedicated values round.

| Bank | Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|---|
| A | Case/Strategist | 5 questions | Live problems in reading, routines and the week's plan | High: the principal's seat prior, the hiring page's named panel topics, and a reading-specialist path | Clarify, then objective, approach, check on progress; think aloud; challenge one premise politely |
| B | Skeptic | 4 questions | Quiet, persistent probing of the stated gaps (F9, F7) | High: the same seat's second prior, and your own stated gaps are exactly what this persona probes | Rehearse B1 until it is boring: plain acknowledgment, the nearest sentence at its scope, a ramp plan in your words |
| C | Peer Evaluator | 4 questions | Two team members asking about the seam, disagreement and what you add to their load | High: two of three seats are peers; the posting line on working with the grade-level team | Reciprocity first: what you would offer; propose principles for the seam instead of claiming to know it |
| D | Data-Driven Prober | 3 questions | Line-by-line probes of what was actually yours | Medium: a peer-seat second prior, but your material holds few figures, so probes land on attribution, not numbers | Say what you know, say plainly what you do not, and never add a detail you could not repeat under a second question |
| E | Values/Behavioral | 3 questions | Stories themed on the three published beliefs | Medium: the beliefs page says three beliefs guide every hire and panels ask about families; no dedicated values round is documented | A selection scaffold per belief; "we" for context, "I" for contribution; the honest branch when nothing comes to mind |
| G | Conversational | 2 questions | A warm biography opener and the licensure check | Medium-low: a panel usually opens easily, and the invite makes licensure a stated requirement | A 90-second arc built only from your quoted sentences; treat casual questions as scored |
| H | Pressure | 2 questions | A time-boxed challenge on the fourth-grade gap or attribution | Low: no signal for it, but the stated gaps are what a challenge would use | Pause, restate, concede specifically, hold the core through two follow-ups |

## Question banks

### Bank A: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's October. Five of your fourth graders read well below grade level and the rest are on track. How do you plan a week of reading?" | CASE | [generic] | Structure it aloud: what you would want to know first and what data you hold on each child, the objective for the five, how you would group them and what the rest do meanwhile, how you would check progress, and what you would tell families. Challenge one premise politely, such as how "well below" was measured. The question needs no claim about your past, so the guidance makes none | Reading is the likeliest case topic for this panel, on the reasoning shown in the persona table. CASE because it is a live problem, and `[generic]` because it is a pattern, not a fact about this district |
| A2 | "The board adopted a three-year literacy plan in August. What would you want to know about it before your first day?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The cited news item says the plan brings a new grades 3–5 reading curriculum from fall 2027. Name that one item to show you read it, then ask one question about how fourth grade is expected to prepare, instead of reciting the plan. One tie only, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if asked which parts of that move were yours, say which, in your own words; if a part was not yours, or there was no such part, say so plainly and stay with the sentence | This is the strategy question the research supports; the plan is public, so a shared answer is the consensus one and a good question is the divergence. F7 is the one honest connection your material offers. CO because it tests current context |
| A3 | "Walk us through how you would plan a week across reading, writing, math, science and social studies for a fourth-grade class." | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Open with one sentence at its scope: "I spent six years teaching third grade at a public elementary school in Joliet." Then structure the week in your own words. The five-subject list comes from a representative posting, so treat it as typical for the role, not as this school's practice. Answer slot: expect a probe on which of the five subjects you taught. Say which, in your own words; if some were taught by someone else, or you taught fewer, say so plainly and stay with the six years | F2 is the posting's headline duty and the one your material covers only at its own scope. JD content with a CASE delivery |
| A4 | "How would you set up the first ten minutes of the day with a new fourth-grade class?" | CASE | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Describe what children do on arrival, how a transition works and what you say, in your own words. Answer slot: the posting names clear routines, so expect a probe on your own room. If you set routines in your third-grade room, say which and why; if there were none, or they were set for you, say so plainly and answer as how you would set them up | F4 is a posting duty and a topic the district's hiring page names for panels. CASE with JD content, `[inferred]` because the duty comes from a representative posting |
| A5 | "Our third belief is that assessments inform teaching and never replace it. Tell me about a time you saw that play out." | JD | [grounded] | An open prompt themed on the published belief and the posting's assessment-data line. Selection criteria: pick a time a result you had in hand changed what you taught next; it needs the result, what you changed, and what followed, all in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 and F11 both press here and your material is silent on both, so the answer must come from you, not the pack. JD because it scores a stated duty |

### Bank B: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've taught third grade and not fourth. What will be hardest about the move on day one?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack, because it will be asked in some form. Hold-then-concede. Concede first and plainly: "I haven't taught fourth grade." Then hold on the nearest sentence at its scope: "I spent six years teaching third grade at a public elementary school in Joliet." Then name the hardest part in your own words and what you would do about it, said as a plan and not a past; the pack supplies neither. Follow-up 1 is likely to ask what you know about how fourth grade differs: say what you actually know, and where you do not, say so plainly. Follow-up 2 is likely to ask why they should take the risk: return to the two sentences and add nothing | F9 is the stated gap and F8 the nearest evidence; the objection is aimed exactly where the material is thinnest. JD because it scores the role's own grade level |
| B2 | "Have you been a grade-level team lead?" | EXP | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment first: "I haven't been a team lead." Then the sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." Stop there; the two sentences are different and the panel may test the difference. Answer slot: if asked what leading the move involved, say what you did yourself, in your own words; if a part was others', or there was no such part, say so plainly and stay with the sentence | F7 holds both your limit and your strongest team sentence, and the question sits between them. EXP because it tests what was actually yours |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Calibrated candor, not a rehearsed weakness. The one gap you have stated yourself is in the quote. If it is truly your weakest part, say "I haven't taught fourth grade" and then what you would do first, as a plan in your own words. If a different part is truly your weakest, say that part and what you would do about it | F9 is the stated gap, and this is the standard Skeptic stem. JD because it scores fit against the listed job |
| B4 | "Six years at one school is a long time. What's prompting the move?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Reason-for-leaving slot: give your actual reason, in your own words. The pack has none from you and supplies none. If something specific draws you to Halvering, say what you actually know of it | F8 supplies the six years the question rests on. EXP because it tests the consistency of your own story |

### Bank C: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you work with the fourth-grade team week to week, and what would you do when you disagree with us?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity framing: say what you would offer the team before what you would need, and propose principles for handling disagreement in your own words instead of claiming to know their seam. The one sentence of yours that touches grade-level work, at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if asked how your grade level made decisions during the move, say what you saw and did, in your own words; if there was no such process, or it was not yours, say so plainly and stay with the sentence | F7 is the posting's team line and your best team sentence. JD because the posting lists working with the grade-level team |
| C2 | "Tell us about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | An open prompt from the peer persona's stem. Selection criteria: pick a time with a named stake, your position, how you handled it, and the working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers weigh disagreement style with equals. EXP because it asks for a past instance, `[generic]` because it is a stem and no sentence of yours carries it |
| C3 | "Tell us about the after-school reading club you've run." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Story-map only what the sentence states: a reading club, after school, run by you, for the last two years. Tell it in your own words and add only what you actually did; the pack supplies no further beats and no results | F10 holds the club sentence. EXP because peers will ask about it from the CV |
| C4 | "What would you need from the team in your first month, and what would you bring?" | JD | [generic] | Reciprocity framing. Ask for what you genuinely need to get started, in your own words, and name what you would bring only from work you can back. The question needs no claim about your past, so the guidance makes none | F7 is the team requirement; peers price what a hire adds to their own load. JD because it scores working with the team |

### Bank D: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led your grade level's move to a new reading curriculum in 2024. What was your part, specifically?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Expect follow-ups two levels deep. State the sentence at its scope, then answer slot: say which parts were yours, in your own words; if a part was someone else's, or there was no such part, say so plainly and stay with the sentence. Hold through two follow-ups by returning to the sentence, never by adding to it | F7 and F10 both rest on this sentence, so it is the next-deepest rehearsal after B1. EXP because it tests attribution |
| D2 | "What would you look at to know whether a new reading curriculum is working?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer as a method in your own words, and name the assumption you would defend least before they do. The published belief is that assessments inform teaching and never replace it, so show a result informing a decision, not replacing it. Answer slot: if asked whether you looked at anything to judge how the 2024 move went, say what, in your own words; if nothing was, or it was not yours to judge, say so plainly and answer as how you would do it | F11 is the published belief and F7 the sentence it would be tied to. CASE because it is a live problem, with an EXP follow-up likely |
| D3 | "You write a weekly email to families. Walk us through one." | EXP | [grounded] "I write a weekly email to families" | Tell it in your own words: who it goes to and how often are in the sentence, and what it contains is yours to say. The pack supplies no content. Answer slot: the published belief is that each teacher speaks with every family each term, so expect a probe on direct contact. If you also speak with families directly, say how; if not, or there was no such step, say so plainly and stay with the email | F5 and F6 rest on this sentence. EXP because a prober checks the CV line against the detail |

### Bank E: Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our first belief is Every Child a Reader. Tell me about a time you helped a child who struggled to read." | VAL | [grounded] "I've run the after-school reading club for the last two years" | An open prompt themed on the published belief. Selection criteria: pick a time with a child (no names), what you tried, and what changed, all in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, at its scope: "I've run the after-school reading club for the last two years." Answer slot: the belief is about a reading plan for every student, so expect a probe. If any child you taught had a reading plan, say what it was and whose it was; if none did, or it was not yours, say so plainly and stay with the club | F10 is the row this belief presses on. VAL because it scores a published belief by name |
| E2 | "Our second belief is Families Are Partners. Tell me about a time you worked through a hard conversation with a family." | VAL | [grounded] "I write a weekly email to families" | An open prompt themed on the published belief. Selection criteria: a named stake, what you said, how the relationship stood afterwards, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, at its scope: "I write a weekly email to families." Or say how you would handle it | F6 is where an email and a conversation come apart. VAL because the belief is published |
| E3 | "Our third belief is Teach for Tomorrow, Not for the Test. Tell me about a time you kept a test result in its place." | VAL | [grounded] | An open prompt themed on the published belief, which the page states as assessments informing teaching and never replacing it. Selection criteria: a result you held, what it told you, what you did with it, and what you chose not to let it decide. If no such time comes to mind, say so plainly, then say how you would handle it | F11 is the belief and your material is silent on it, so only your own story can answer. VAL because it scores a published belief |

### Bank G: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Before we begin, can you confirm your licensure for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms, plainly and in one breath. Confirm on the state registry before Thursday so what you say matches what it shows; that check is yours | F1 is the invite's one stated requirement. JD because it scores a stated qualification |
| G2 | "So, walk us through the journey: how did you get to teaching, and why us?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc built from the four sentences, each at its own scope, in the order you choose. How you came to teaching is yours to say; the pack has no material on it. Answer slot for why Halvering: say what actually draws you, in your own words; if any of the district's three published beliefs does, name which | F8, F7, F10 and F5 carry the sentences. EXP because it opens a scored conversation in a casual register |

### Bank H: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | EXP | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Pause and restate the question. Concede specifically: "I haven't taught fourth grade." Then hold on the sentences as stated and add nothing; the pack knows nothing about the other teacher, so do not compare. Hold through two follow-ups by returning to the sentences, never by adding to them | F9 is the gap a pressure challenge would use. EXP because it tests composure and attribution together |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pause. Anchor on the sentence at its scope, hold it, and concede specifically anything that was not yours. Answer slot: say which parts were yours, in your own words; if a part was others', or there was no such part, say so plainly and stay with the sentence | F7 again under pressure; D1 is the calm version of this question. EXP because it is an attribution probe |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence | G1 |
| F2 plan and teach five subjects | A3 |
| F3 differentiate using assessment data | A5, D2 |
| F4 classroom routines | A4 |
| F5 communicate regularly with families | D3, E2 |
| F6 speaks with every family each term | D3, E2 |
| F7 work with the grade-level team | B2, C1, C4, D1, H2 |
| F8 grades 3 to 5 preferred | A3, B4, G2 |
| F9 Fourth Grade Teacher | B1, B3, H1 |
| F10 Every Child a Reader | E1, C3 |
| F11 assessments inform teaching | A5, E3, D2 |
| Current district direction (CO) | A2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How does that shape how reading time is run in fourth grade here?" | Tied to the principal's own public path; it moves the conversation from interrogation to peer talk and shows you researched her |
| R2 | "The board's literacy plan brings a new grades 3–5 reading curriculum in fall 2027. What would you like a fourth-grade teacher to be doing this year to get ready?" | Shows you read the plan and asks for an expectation instead of assuming one |
| R3 | "What could a new fourth-grade teacher do in their first month that would genuinely help the team?" | The reciprocity question for the peer seats; it prices their load, not just your needs |
| R4 | "How does the fourth-grade team plan together, and what is shared versus each teacher's own?" | Surfaces the seam the peer persona probes, and gives you a fact for your own principles |
| R5 | "The second belief is that each teacher speaks with every family each term. What does that look like in practice at Halvering?" | F6 is where your material is thinnest, so hearing the expected form helps you prepare, and it shows you read the beliefs |
| R6 | "What happens after the panel, and when do you expect to decide?" | The district's hiring page says references are taken up after the panel; this confirms the next steps and the timeline |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F9 | The plain acknowledgment: "I haven't taught fourth grade." The nearest sentence stays at its scope: third grade, six years |
| Has been a team lead | A negative you stated, F7 | The plain acknowledgment: "I haven't been a team lead." The move sentence stays at its scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Chose, designed or wrote the new reading curriculum | Inflated form of F7 and F10 | The quote at its own scope. The limit is the pack's observation: your material says the move, not who chose or wrote the curriculum |
| Spoke with every family each term | Inflated form of F6 | "I write a weekly email to families" at its own scope. The limit is the pack's observation: your material says an email, not conversations |

## Sources

**Provided:** the HR invite (Orrinsford Community School District) and your résumé text. Identifier numbers in your message were not used and are not in this pack.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three published beliefs by name: F6, F10, F11 and the E bank. Fetched in full |
| 2. `{company} interview process {role family}` | yes | Loop structure: one 45-minute building panel, panel topics named; persona weights follow it, so no archetype fallback was needed |
| 3. `{company} strategy` / recent news | yes | The 2026–2029 literacy plan: question A2 and reverse question R2 |
| 4. `{interviewer name} {company}` | yes | Reading the interviewer, reverse question R1 |
| 5. representative `{role title}` JD | yes | F2 to F5, F7 and F8, all `[inferred]`; no posting was supplied |

**Searches sent (5):**

1. "Orrinsford Community School District values mission" — https://orrinsfordschools.example/about/mission-and-beliefs
2. "Orrinsford Community School District teacher interview process panel" — https://orrinsfordschools.example/careers/how-we-hire-teachers (search result text only; page not fetched)
3. "Orrinsford Community School District strategic plan news" — https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. "Dolores Vantongeren principal Halvering Elementary School" — https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. "fourth grade teacher job description Illinois elementary school district posting" — https://k12jobsboard.example/listings/fourth-grade-teacher

**Fetches sent (2):** https://orrinsfordschools.example/about/mission-and-beliefs and https://k12jobsboard.example/listings/fourth-grade-teacher.

The posting is a representative job-board listing, not this school's own, which is why its rows are `[inferred]`. The how-we-hire page is undated in the result, so its age is not established. No `tuesday-dossier.md` was present.

## Upgrade menu

- The school's own posting → F2, F3, F4, F5, F7 and F8 move from `[inferred]` to `[grounded]`, and any requirement the representative posting missed gets a row and a question
- Anything HR or the school said about what the panel covers, or something to bring such as a sample lesson → coverage tuned to it, and a build section if a deliverable was declared
- The two fourth-grade team members' names, if HR shares them → an interviewer read for each seat and tuned persona weights
- Your registry entry for your licence, seen on the state site → F1 moves from medium to high; the number itself is never needed
- Your answers to the slots in F2, F3, F4, F6, F10 and F11, in your own words → those rows move out of discovery or transferability and the matching bank guidance becomes story-mapped
- A `tuesday-dossier.md`, if you have one → verified evidence, absolute prohibited claims and the evidence-derived top objection, instead of the ones inferred here
