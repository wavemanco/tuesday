I'm running the company research for the pack: three searches on Lumenvale Software's values, hiring process and recent news.
Before the prep, one thing in the invite: it says the hiring process "is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who you're dealing with, and nothing in it asks you for money so far. Until you've checked who sent it, don't pay anything, deposit a cheque, or send documents or bank details. Check with Lumenvale Software using a phone number or address from the careers page you applied through, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-5/rooms/case-10-denied-366dee5b/lumenvale-software_customer-support-specialist_interview_pack.md`. I built it for one text-chat round with the support team lead, treating them as a likely future manager since the invite doesn't say. The three web searches on Lumenvale were refused, so nothing in it is specific to the company. The company-knowledge and values questions are generic and the Sources section says so.

The question to rehearse most is B1, "You've never worked for a software company. Why should we think you'd cope?". The pack also flags that your material is silent on escalations, and the ad asks for confidence handling them, so B3 is the next one to prepare.

Say the word and I'll play the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter say anything about the chat's format, such as a time limit or a written exercise, and is the team lead the person you'd report to? Either answer would reweight the banks.
Can you paste the full ad text and your CV? I built the pack without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

- **Interviewer:** the support team lead, not named in the invite. Treated as a likely future manager, because the invite does not say.
- **Round:** one session, a text chat. The invite's own words: "your interview will be a text chat here with our support team lead".
- **Built from:** your message only: the ad's four requirements as you relayed them, and five sentences about your background. No CV and no full ad text were supplied, and the research searches were refused (see Sources), so nothing here is specific to Lumenvale.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values: whether your past behaviour shows what the company says it values |
| EXP | Work-experience deep-dive: whether what you've said survives follow-up questions, and what was actually you |
| JD | Role-driven: can you do the listed job, including the parts you are weaker on |
| CO | Company knowledge: homework depth |
| CASE | A live problem from the role, set in the chat |

Question IDs are letters by persona, and the letter F is skipped so a question ID is never mistaken for a fit-snapshot row (F1 to F6). Guidance cells are sized for a 90 to 120 second spoken answer. In a typed chat, send the same material as two or three short messages.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as relayed in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length, but a line from your message with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: "3 years as a customer service advisor at an energy supplier". The ad says support and your sentence says customer service advisor, so say your own title and do not relabel it |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as relayed in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap on the ad's "or a similar" wording, but a sentence with nothing inspected behind it, so expect a probe. Lead with it as it stands: "I use Freshdesk every day". Whether the team counts Freshdesk as similar is theirs to say |
| F3 | "clear written communication" — the ad, as relayed in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The sentence touches written work, but gives one figure for calls and emails together and shows nothing about how clear the replies were. Answer slot: the ad asks for clear written communication, so expect a probe on your writing. If anything showed your written replies worked, say what it was, in your own words; if nothing of the kind exists, say so plainly and say what you aim for when you write a reply. The interview is itself a written chat, so how you write in it is the sample |
| F4 | "confidence handling escalations" — the ad, as relayed in your message | none given | none | [grounded] | discovery | Your material does not say whether escalations were part of your work. Answer slot: the ad asks for confidence handling escalations, so expect a probe. If you dealt with escalated customers, say what the situation was and which part was yours, in your own words; if escalations were not part of the job, or none reached you, say so plainly and say how you would approach one |
| F5 | Support work on a software product: a role-family expectation, not a line of the ad as you relayed it | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software support work, and nothing added to make the gap feel smaller |
| F6 | No line of the ad as you relayed it asks for this | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Not an ad requirement, but a sentence you can tell as a story at its own scope. It holds a figure, so expect the defend-the-number probes in D3. What the training consisted of and how it went are not in your material, and they stay yours to say in your own words |

## Persona table

The loop is established by the invite's own words: one text chat with the support team lead. No values-style round is detected, so Values/Behavioral carries a modest weight rather than a guaranteed one. Weights start from the hiring-manager prior (Case/Strategist plus Skeptic) and are adjusted below; if the lead turns out to be a peer rather than your future manager, the Peer bank moves up.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A, weight 5) | Live tickets set in the chat: an angry customer, a triage call, a rewrite of a bad reply | High. A team lead is the person most likely to test the job as a live problem, and the ad names escalations (F4) and written communication (F3) | Clarify, then say your structure, then answer, then name the risk. In chat, send the structure first, in one short message |
| Skeptic (bank B, weight 5) | Quiet probing of the two gaps: software (F5) and escalations (F4), plus why this move and why now | High. F5 is a gap you stated and F4 is a requirement your material is silent on | Rehearse B1 until it is boring. Build bridges only from the F1 and F2 sentences, and say the limit plainly |
| Conversational (bank C, weight 3) | A relaxed opener such as "walk me through your journey", and casual questions about writing | Medium. Chat is a casual register, and casual questions are still scored | Have a 90-second arc ready from your quoted sentences, and treat each casual question as scored |
| Data-Driven Prober (bank D, weight 3) | Follow-ups on the two figures in your message: around 60 a day, and four starters | Medium. Both figures are the kind a careful reader presses on | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Values/Behavioral (bank E, weight 2) | "Tell me about a time" stories | Low to medium. No values round is documented, and the company's values were not retrievable here | Choose stories where you can say what you chose and how it ended; where none comes to mind, say so plainly |
| Pressure (bank G, weight 2) | A short, challenging line such as "how much of that was you" | Low. A text chat gives little room for interruption, but the challenge itself travels well in text | Pause, restate, hold the position through two follow-ups, then concede only what is true |
| Peer Evaluator (bank H, weight 2) | Handover and disagreement questions | Low. The invite names a team lead, not a peer | State your own approach as a principle, and tell a story only if you have one |

## Question banks

The highest-ROI rehearsal in this pack is **B1**, the software-company question: it is the one gap you named yourself, and it is the most likely objection to arrive in some form. It has the most follow-up levels, below.

### Bank A: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: the product has lost a week of their work, and they want a refund and a manager. Talk me through your first three replies." | CASE | [generic] | Say your structure first: what you would ask before promising anything (what was lost, when, how much it matters to them); what the first reply does (acknowledge it, say what you are doing and when you will update them); whether this is yours to resolve or goes to someone else; and what the handover note contains so the customer does not repeat themselves. The question needs no claim about your past, so the guidance makes none | The ad's "confidence handling escalations" (F4's requirement) asked as a live decision rather than a record. CASE because it is a problem set in the role |
| A2 | "You have 40 tickets open and three more arrive at once: a locked-out customer, a billing dispute, and a bug report from someone writing in for the third time. What do you do first, and why?" | CASE | [generic] | Ask what priority guide or time targets the team uses. Then say how you would rank (who is blocked, who is at risk, what is time-bound), what you would tell each customer, and the trade-off you accept. Think aloud; the ranking matters less than the reasoning | Tests triage in a ticketing queue, the working context behind F2's requirement. CASE because it is a live problem |
| A3 | "A colleague drafted this reply: 'As I said before, this isn't supported. Please read the guide.' Rewrite it for the customer." | JD | [generic] | Build the rewrite in four moves: acknowledge what they asked, say plainly what is and is not possible, give one next step, and say what you will do if that does not help. Drop "as I said before". Keep it short and free of jargon the customer did not use. The question needs no claim about your past | The ad's "clear written communication" (F3's requirement) tested in the medium the interview itself uses. JD content, CASE delivery |
| A4 | "A customer describes what looks like a bug in a feature you don't know well, and you can't reproduce it. What do you do?" | CASE | [generic] | Structure it: gather what you need from the customer (what they did, what they saw, anything that shows it); check what the team already knows; try to reproduce it; hand it to whoever owns the product with a complete write-up, and ask how that handover works on this team; tell the customer what is happening and when you will update them. The question needs no claim about your past | The role-terms version of F5: it shows how you would work on a product you do not yet know. CASE because it is a live problem |
| A5 | "What do you know about what we make and who uses it?" | CO | [generic] | This pack could not look the company up, so nothing company-specific is in it. Before the chat, read the company's own website, product pages and careers page, and in the chat say what you found in your own words. If you found little, say so plainly and ask the lead to tell you. Do not recite guesses | Company knowledge is the differentiator question, and it is generic here because the research searches were refused. CO because it tests homework depth |

### Bank B: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we think you'd cope with supporting a software product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry. Open with the plain acknowledgment: "I've never worked for a software company." Then the work you stated, at its own scope: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day." Say the limit yourself before it is pressed: your material shows no software support work, so do not stretch the energy work into technical support. Follow-up 1, "that is a different kind of customer": concede that you do not yet know their customers or product, and return to the three years and the daily tool. Follow-up 2, "how long until you are useful": say plainly you cannot promise a date; give the first things you would learn, in your own words, naming only what you would really do (the product, the commonest ticket types, how escalation works on this team), and give a number of weeks only if you actually hold one. Follow-up 3, "what if a customer asks something technical you can't answer": use the A4 structure and say you would tell the customer what you are checking and when you will come back. Hold through all three by returning to the quotes, never by adding to them | F5 is the gap you stated, so this objection arrives in some form; F1 and F2 are what you hold it with. JD because it scores a requirement the role implies; it sits in the Skeptic bank because the interviewer is probing a gap |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the weakness that is true. If it is software, your own sentence carries it: "I've never worked for a software company", then what you would do first to close it. For any other weakness, name it in your own words and what you would do about it. Do not pick a fake weakness | The stock Skeptic question; F5 is where your material names a gap, and F4 is where it is silent. JD because it scores fit against the listed job |
| B3 | "Tell me about a time you handled an escalated customer." | JD | [generic] | An open prompt, so choose an instance. Pick a time with a named stake, your own part in it, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. In chat, send it as four short messages: situation, your part, what you did, outcome | F4 is the ad's requirement your material is silent on, so this probe is likely; the pack supplies no story because none is in your material. JD because it scores the stated requirement |
| B4 | "The ad says Zendesk or a similar tool. What do you do in Freshdesk in a normal day?" | JD | [grounded] "I use Freshdesk every day" | Start with the sentence as it stands: "I use Freshdesk every day." Answer slot: say in your own words which parts of it you use in a day; nothing here names features for you. If they then ask about Zendesk by name, answer from your own experience of it if you have any; if you have none, say so plainly and stay with Freshdesk | F2 is the evidence for the tool requirement and the likeliest place to be probed. JD because it scores a stated requirement |
| B5 | "What draws you to support at a software company, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Give your actual reasons in your own words; this pack does not know them and will not supply them. Keep it about what draws you to the work, not what is wrong with where you have been. Join it to the three years only at the quote's own scope. If part of the honest answer is practical, say so plainly | The standard why-this-move probe, aimed at a candidate changing sector (F1 and F5). EXP because it tests your actual path, not a requirement |

### Bank C: Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A 90-second arc with only the beats the quotes state: three years as a customer service advisor at an energy supplier; around 60 calls and emails a day, said as one combined figure; Freshdesk every day; four new starters trained on your refunds process last year. Close on what draws you to this role, in your own words. Add no titles, teams or outcomes. In chat, send it as three short messages | The opener sets how every later answer is read, and F1, F2, F3 and F6 are the sentences it can rest on. EXP because it is your own history |
| C2 | "I hear you trained some new starters. Tell me about that." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence states: four new starters, the refunds process, last year. What the training consisted of and how it went are yours to say only if you have them; do not make it bigger than the sentence supports | F6 is a sentence the ad does not ask about but a friendly interviewer will pick up. EXP because it tests what you actually did |
| C3 | "What does a good reply to an unhappy customer look like to you?" | JD | [generic] | Give your own view in your own words, in the register of the chat, because the answer is itself a writing sample. A frame to build from: it says what happens next, uses short sentences, avoids jargon the customer did not use, and asks for no more than one thing. The question needs no claim about your past | A casual question on the ad's "clear written communication" (F3's requirement), which is scored even when it sounds relaxed. JD because it scores a stated requirement |

### Bank D: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say what the sentence says: around 60 calls and emails a day, together. Answer slots, each in your own words: how the figure was counted, and if you do not know, say so plainly; the assumption behind it you would defend least, named before they do, or say plainly if you know of none; what it varies with; which part was yours, and if it was a team figure, say so plainly | The figure in F3 is the likeliest thing a prober presses. EXP because it tests attribution and honest sizing |
| D2 | "How many of those were emails and how many were calls?" | EXP | [grounded] "answering around 60 calls and emails a day" | If you know the split, give it as you know it. If you do not, say so plainly and return to the combined figure: "around 60 calls and emails a day". Do not estimate a split to fill the gap | F3's evidence is one combined figure, and the ad asks about written work, so the split is the natural next question. EXP because it tests precision |
| D3 | "Four new starters on the refunds process: which part of the training was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence at its scope: "I trained four new starters on our refunds process last year." Answer slot: which part was yours, in your own words; if the process or its materials were set by others, or you trained them alongside someone, say so plainly and return to the sentence. If asked how the figure four was counted or what it varies with, answer in your own words, or say plainly you do not know | F6 holds a figure, so the four defend-the-number probes apply. EXP because it tests attribution |

### Bank E: Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | An open prompt, so choose an instance. Pick a time with a named stake, the choice you made, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. It is not mapped to Lumenvale's own values, which could not be looked up here | A standard values probe for support work. VAL because it asks for past behaviour; generic because no published value could be retrieved |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | An open prompt, so choose an instance. Pick a time where the hard message actually landed, say what you said and how it was received, and choose one where you can speak only to your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A second values probe that also tests the ad's escalation theme (F4). VAL because it asks for past behaviour |

### Bank G: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold-then-concede. Hold the sentence: "I trained four new starters on our refunds process last year." Answer slot: which part was yours, in your own words; if it was shared, or the process or materials were others', say so plainly and return to the sentence. Hold through two follow-ups by returning to the sentence, never by adding to it; concede only what is true | F6 is the only sentence where you stand as trainer, so it is where an attribution challenge lands. EXP because it tests what was yours |
| G2 | "Sixty seconds: why you over someone who has worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause and restate the question first. Hold what the quotes carry: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day." Concede the gap in one plain sentence: "I've never worked for a software company." Do not claim your energy-sector work equals software support. Hold through two follow-ups by returning to the quotes | F1, F2 and F5 together are the whole of this answer. JD because it scores fit against the listed job |

### Bank H: Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "When a ticket passes between two people, what does a good handover look like?" | CASE | [generic] | Name the principles in your own words: the next person should not have to ask the customer anything twice, the note says what has been tried and what is promised, and the customer is told who has it now. Ask how handovers work on this team. The question needs no claim about your past | Handover is where a peer feels the cost of a new hire, and it connects to the ad's escalations theme (F4). CASE because it is a live problem |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your own approach as a principle first. Then, if you have an instance, tell it with your own part and the others' parts kept separate; if no instance comes to mind, say so plainly and say how you would handle it | A peer-style probe on collaboration. VAL because it asks about your behaviour with equals |

### Requirement coverage

| Requirement (source) | Questions that cover it |
|---|---|
| "2+ years in customer support" | C1, B5, G2 |
| "experience with Zendesk or a similar ticketing tool" | B4, A2, G2 |
| "clear written communication" | A3, C3, D2 |
| "confidence handling escalations" | A1, B3, H1 |
| Support work on a software product (role-family, not in the ad as relayed) | B1, B2, A4, G2 |
| Your trained-four-starters sentence (no ad line) | C2, D3, G1 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like in this role, and what would you want me to have learned by the end of it?" | Lets the lead define success themselves, and answers what B1's ramp plan has to cover |
| R2 | "How do escalations work on this team: what counts as one, who takes them, and what does a good handover look like?" | Shows you have thought about the escalation path before being asked, and tells you the standard you will be held to |
| R3 | "Which ticketing tool does the team use, and how are new starters trained on the product?" | Tells you how much product training to expect, which bears directly on F5 |
| R4 | "What do customers most often write in about, and what do they most often get stuck on?" | Gives you the shape of the work and something specific to read up on |
| R5 | "How is the team's work measured: response time, customer satisfaction, something else?" | Shows you the scoring frame for the job, and tells you what to emphasise in your later answers |
| R6 | "Is there a call or video step after this chat, and what happens after it?" | Tells you what else to prepare for and how the rest of the process runs |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in software support | Negative you stated, F5 | The quote: "I've never worked for a software company." The plain acknowledgment rests on that sentence. No slot |
| Three years as a customer support specialist | Inflated form of F1: the ad's vocabulary in place of your own title | F1's quote at its own scope: "3 years as a customer service advisor at an energy supplier". The pack's observation is that your material gives the title customer service advisor |
| Answered around 60 emails a day | Inflated form of F3: the combined figure moved onto one noun | F3's quote at its own scope: calls and emails together. The pack's observation is that your material gives the combined figure, not a split. D2's slot stays inside the combined figure |
| Owned or designed the refunds process or a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". The pack's observation is that your material says you trained four starters, not who set the process. D3 and G1 ask only which part was yours |

## Sources

Provided documents: the invite as you pasted it; your summary of the ad's four requirements; five sentences about your background. No CV and no full ad text were supplied. The loop (one text chat with the support team lead) rests on the invite's own words.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused (the host denied permission to use search):

- `Lumenvale Software company values` — refused
- `Lumenvale Software interview process customer support specialist` — refused
- `Lumenvale Software news strategy` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have named the company's published values, moved the VAL bank (E) from generic to mapped, and shown whether a values-style round exists |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The search was refused. It would have shown any documented loop; persona weights here rest on the invite's own words and the hiring-manager prior instead |
| 3. `Lumenvale Software news strategy` | unavailable | The search was refused. It would have fed a strategy-grounded CO or CASE question; A5 is generic instead |
| 4. interviewer name plus company | n/a | The invite names a talent-team sender and an unnamed support team lead; no interviewer name was given, so there was no query to form. There is no interviewer read |
| 5. representative `Customer Support Specialist` JD | skipped | The four ad requirements you relayed already fix the fit snapshot and the JD-tagged questions; the full ad text is in the upgrade menu |

## Upgrade menu

- The full ad text → any mid-list requirements the four lines you relayed leave out become fit-snapshot rows and get questions in the coverage table
- Your CV → the F1, F2, F3 and F6 rows now rest on single sentences from your message with nothing inspected behind them; a CV line, or a customer-satisfaction report or manager review from your current job, would be what lifts them from medium
- An example from your own work of dealing with an escalated customer, or a plain statement that none reached you → F4 becomes a story-mapped row, and B3, A1 and E2 get a mapped answer in place of a scaffold
- The company's published values, loop and recent news (pasted, or fetched if search is permitted) → E1 and E2 are mapped to named values, A5 becomes specific, and a values cheat sheet is added if a values round is documented
- The support team lead's name → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to their own career path
- Anything the recruiter told you about format, such as a time limit, a written test or a role-play → coverage for it, and a build section if a deliverable was announced
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it needs search to be permitted here) → a grounding brief and strategy-specific CO and CASE questions
- A `tuesday-dossier.md` from an earlier evidence-check → verified evidence for each row, the objection worth the deepest rehearsal, and a limit on what each answer may claim
