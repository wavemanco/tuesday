I'll read the skill's reference files before building the pack.
Before the prep, one thing in the invite: it says the process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with, so the invite may not come from who it names. Until you've checked it, don't pay anything or send documents or bank details. To check, use contact details from Lumenvale's own website or careers page, not the chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite checked more fully, job-underwriter can do that as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. It has 20 questions across six interviewer styles, a fit table against the four ad requirements, and reverse questions to ask them.

- **Assumption:** I treated the support team lead as a hiring-manager-style interviewer, since your note doesn't say whether they'd manage you.
- **Research:** my web searches on Lumenvale were refused, so nothing in the pack comes from company research. That means no company values or strategy questions.
- **Biggest gap:** "I've never worked for a software company". Question B1 is the one to rehearse most. The pack coaches you to say that plainly, then point to your three years and daily Freshdesk use, and describe how you'd learn the product.
- **Two thin spots:** your material says nothing about escalations, and names Freshdesk but not Zendesk. The pack gives you slots to answer honestly either way.

Say the word and I'll play the Skeptic on B1 as a live text drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Will the support team lead be your future manager?
Can you paste the full job ad, or tell me to carry on without it?
Has anyone told you what the chat will cover?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Candidate: Imani. Role: Customer Support Specialist (remote). Interviewer: the support team lead, name not given. Format: a text chat. Built on this assumption: the lead is treated as a hiring-manager-style interviewer, because your note does not say whether they would manage you.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims about your experience survive follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned through aloud |

Answer slots in the guidance are instructions for the interview, not questions for you now. Provenance labels: `[grounded]` rests on what you sent, `[inferred]` is derived from it, `[generic]` is a role pattern with no claim about you or the employer.

## Fit snapshot

The requirements are your description of the ad, not the ad's full text. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a self-stated line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: three years, customer service advisor, energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say it in the quote's own words: "I use Freshdesk every day." The pack's observation is that your material names Freshdesk and no other tool. Answer slot: if the interviewer asks about a tool other than Freshdesk, say plainly which tools you have used and stay with what that sentence carries |
| F3 | "clear written communication" — the ad as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Answering emails is not the same as showing the writing was clear, and the bridge should not stretch it. Answer slot: the ad's clear-writing line makes a probe on evidence likely. If anything backs up how clear your writing is, such as feedback, a score or a reply you are proud of, say what it was; if nothing does, say so plainly and stay with the quote. The chat itself is also a writing sample |
| F4 | "confidence handling escalations" — the ad as you described it | none given | none | [grounded] | discovery | Your material says nothing about escalations either way. Answer slot: if you have handled escalated calls or emails, say what happened and which part was yours, in your own words; if none came to you, or it was not yours to handle, say so plainly and say how you would handle one |
| F5 | Familiarity with software products — not in the ad as you described it, plain prose, `[generic]` | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Not an ad requirement. A line for conversational questions and the likeliest figures to be probed | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Say it in the quote's own words, with "four", "new starters", "refunds process" and "last year" kept exactly where they are. Expect "what did that involve" and "how much was you" |

## Persona table

Relationship prior: a hiring-manager-style round favours Case/Strategist and Skeptic. No interviewer profile exists, so there are no signal adjustments. The invite describes one text chat with the support team lead, which is the loop source; no values-style round is documented, so the Values persona is kept light.

| Persona | Bank | Likelihood and reasoning | How it shows up here | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | A (5) | High. Hiring-manager prior, and the ad's escalation and writing lines are testable live in a chat | A ticket scenario you answer in writing | Clarify first, then structure, then answer; think aloud in short lines |
| Skeptic | B (5) | High. Hiring-manager prior, and F5 is the biggest gap in your material | Quiet probing of the software gap and of which tools you have used | Rehearse the single likeliest objection (B1) until it is boring |
| Data-Driven Prober | C (3) | Medium. Your material has three figures a reader can pull on | Questions on how each number was counted | Know what you can say about each number and say plainly when you do not know |
| Conversational | D (3) | Medium. Team leads often open casually, and casual questions are still scored | Journey, tools and remote working | A short arc built from your own sentences; treat casual questions as scored |
| Pressure | E (2) | Low to medium. A text chat can still be time-boxed, and escalation work attracts composure tests | Short, challenging follow-ups | Hold the position through two follow-ups, then concede only what is true |
| Values/Behavioral | F (2) | Low. No loop source documents a values round and no company values were available to me | Two open behavioural prompts | Pick a real instance or say plainly that none comes to mind |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and says they are cancelling today. Walk me through your next ten minutes." | CASE | [generic] | Think aloud in short written steps: look at what has already been said and tried before replying; apologise for the specific problem, not a generic one; say what you will do and by when; decide whether it needs someone with more access or product knowledge; set a follow-up you will keep. The question needs no claim about your past, so the guidance makes none | F4's requirement tested as a decision rather than a story; CASE because it scores structure and priorities. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "A bad release goes out overnight and the queue has doubled by morning. What do you do first, and what do you need to know?" | CASE | [generic] | Clarify before structuring: what is broken, who is affected, how many tickets look alike. Then group tickets by cause instead of answering one by one, agree one customer-facing message with whoever owns the product, flag it upward, and say what you would tell customers meanwhile. Say what you do not know and who you would ask. No claim about your past | F4's requirement again, at team level rather than single-ticket level. CASE because it scores clarifying and prioritising |
| A3 | "A customer says the product lost their data and wants a refund and a call from a manager. Write me your first reply, here, now." | CASE | [generic] | The chat is the test. Keep it short: acknowledge the specific harm, avoid guessing at the cause, say exactly what you will do next and when they will hear back, ask only for what you need. Where a refund or a call is not yours to promise, say who decides rather than promising it | F3's requirement turned into a live writing sample, which is how a text-chat interview scores it. CASE in delivery, JD in content |
| A4 | "How do you decide whether to handle a ticket yourself or escalate it?" | JD | [generic] | Give your criteria in your own words, for example how widely it affects customers, whether you lack access or product knowledge, and how long the customer has waited. Say what a handover note needs so the next person does not re-ask. Answer slot: the ad's escalation line makes a probe on your own record likely. If you have made that call in your current role, say what you did and which part was yours; if it was not yours to make, or there was nothing to escalate, say so plainly and answer with how you would decide | F4 is the row with no evidence, so this is where the ad's escalation line presses hardest. JD because it scores a stated requirement directly |
| A5 | "How would you get up to speed on our product in your first weeks?" | JD | [generic] | Say it as a plan, in your own words: what you would ask for, what you would try yourself, who you would ask when stuck. It is a plan and never a claim about the past. The pack has no facts about Lumenvale's product, so do not describe it as though you do | F5's gap, asked forward rather than as a challenge. JD because the role needs product learning, and it is the easy half of B1 |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company before. What makes you think you can support a software product?" | JD | [grounded] "I've never worked for a software company" "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" | **The highest-ROI prep in this pack.** Open with the plain acknowledgment: "I haven't worked for a software company." Then give your two sentences at their own scope: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Name the limit once, specifically, and say how you would learn the product as a plan. Hold through two follow-ups by returning to those sentences, never by adding to them. If asked which parts of the job carry over, answer slot: say which parts you think carry over and why, in your own words; if you cannot name any, say so plainly and say what you would do to close the difference. Concede the difference once and do not keep apologising | F5 is the biggest gap and this question is aimed at it, so it will arrive in some form. JD because it scores a stated fit gap. Deepest rehearsal because the limit is named before it is asked for |
| B2 | "The role asks for Zendesk or a similar ticketing tool. What have you used?" | JD | [grounded] "I use Freshdesk every day" | Say: "I use Freshdesk every day." Then, in your own words, what you do in it. Answer slot: if the interviewer presses on a different tool, say plainly which tools you have used; if the answer is only Freshdesk, say so and stay with that sentence. Do not describe features you have not used | F2 is a presentation row: the evidence is there in other terms. JD because it scores the ad's tool line directly |
| B3 | "Which part of this job would you be weakest at on day one?" | EXP | [grounded] "I've never worked for a software company" | Choose the answer you believe, not the safest one. Your material points at product knowledge: "I haven't worked for a software company." Say that, then your plan to close it. Answer slot: if another part of the ad is truer for you, such as escalations, say plainly which and how you would close it | F5 and F4 are the two thin spots, and this stem invites you to pick one. EXP because it scores honest self-assessment rather than a stated requirement |
| B4 | "Tell me about a time you had to escalate something." | EXP | [generic] | Selection scaffold: pick an instance with a named stake, what you handed over and why, what the customer was told meanwhile, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 has no evidence behind it, so an open prompt is the honest way to ask. The theme comes from the ad's escalation line; EXP because it asks for a real instance |
| B5 | "Why customer support at a software company, and why now?" | JD | [generic] | Your reasons are yours; the pack will not supply them. Say what actually draws you to support work and to this role, in plain words. If you have not looked at the company's product yet, do so before the chat and say only what you really saw | Motivation consistency is what a Skeptic scores beside the gap. JD because it tests fit for the role you applied for |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say it as it is: "around 60 calls and emails a day", and keep "around" and "answering". Defend-the-number slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F3's figure is the line a prober pulls first. EXP because it tests whether the number survives |
| C2 | "You trained four new starters on your refunds process. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Open with the sentence as you wrote it. Answer slot: say what you actually did, in your own words, and which part was yours if anyone else was involved; if some of it was informal or someone else's, say so plainly and stay with the sentence. Defend "four" the same way as C1: how it was counted and what it covers | F6 is a spare strength that a prober turns into a number to defend. EXP because it tests attribution |
| C3 | "Take me through your three years at the energy supplier." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Tell it in order, using only what you can say plainly. Start: "I was a customer service advisor at an energy supplier for 3 years." Answer slot: if your role changed over the three years, say how, in your own words; if it stayed much the same, say so plainly and describe what the job was | F1 is the headline of the CV line and will be walked through. EXP because it tests whether the line survives follow-up |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you end up in customer service, and why this role?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" | A short arc: where you are now, using those two sentences, then why this role, in your own words. Answer slot: the why is yours; say what actually draws you, and if you have not yet looked at the company's product, say what you do know and what you would want to learn | F1 and F2 are the two facts a casual biography question is built on. EXP because it checks the story is consistent |
| D2 | "Do you like writing to customers, or are you more of a calls person?" | JD | [grounded] "answering around 60 calls and emails a day" | Casual, but scored against the ad's writing line. Say which you prefer and why, in your own words; the sentence shows you answer both calls and emails, no more. Answer slot: if anything backs up how clear your writing is, such as feedback or a reply you are proud of, say what it was; if nothing does, say so plainly | F3's requirement asked in a friendly register. JD because it scores the ad's writing line |
| D3 | "What would you need in place to do this job well remotely?" | JD | [generic] | Be concrete and honest about your own set-up and routine. The question asks about the future, so the guidance makes no claim about your past. The pack has no facts about Lumenvale's remote arrangements, so ask rather than assume | The role is remote, so working practicalities are a normal casual probe. JD because remote working is part of the role as you described it |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I've never worked for a software company" | Pause, restate the question, then hold on what the sentences carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Concede specifically: "I haven't worked for a software company." Hold through two follow-ups by returning to those sentences. Answer slot: say in your own words what you think you bring; keep it to what you have actually done | F5 under time pressure. JD because it scores the same fit gap as B1 in a different delivery |
| E2 | "That training of the four new starters. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold: "I trained four new starters on our refunds process last year." If any part was shared, or someone else led any part, say which part, specifically. Answer slot: if nothing was shared, say that plainly and add nothing to the sentence. Do not defend more than you did | F6 repackaged as an attribution challenge. EXP because it tests precise attribution under pressure |

### F. Values/Behavioral

No published Lumenvale values were available, so these rest on persona stems and are `[generic]`.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you put a customer ahead of an internal target." | VAL | [generic] | Selection scaffold: pick an instance with a named stake, a moment you chose the customer, and what happened to the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem, kept because support roles score customer-first judgment. VAL because it scores behaviour against a value, not a stated requirement |
| F2 | "Tell me about a time you had to tell someone something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a case where the message was hard and the truth landed; say what you said and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-facing roles deliver bad news routinely. VAL because it scores candour |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "2+ years in customer support" | C3, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" | B2, D1 |
| "clear written communication" | A3, D2 |
| "confidence handling escalations" | A1, A2, A4, B3, B4 |
| Software product familiarity (not in the ad) | A5, B1, B3, B5, E1 |
| Remote working (the role as you described it) | D3 |
| Company values | F1, F2 (persona stems only; no published values were available) |
| Company strategy (CO) | none: no research ran, so a CO question would be generic and has no place here |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new to the product?" | Pairs with your answer to B1 and A5: it shows you are planning the ramp, and it tells you what the team expects |
| R2 | "What kinds of tickets get escalated here, and who do they go to?" | The ad lists escalations, so this shows you think about handover, and the answer tells you the real bar |
| R3 | "Which ticketing tool does the team use, and how are replies shared or reviewed?" | Settles the tool question from F2 and shows you care about how work is checked |
| R4 | "How is cover organised across hours and time zones when everyone is remote?" | A practical remote-working question that signals you have thought about the day-to-day |
| R5 | "What would the next stage look like: is there a call or video step, or does the rest stay in writing?" | Lets you plan what to rehearse next, since voice and written answers need different preparation |
| R6 | "What is the support team working hardest to improve this year?" | Open and low-risk; it asks about priorities without assuming any |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material names Freshdesk and no other tool |
| Worked in software or software-company support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Resolved or closed 60 tickets a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day". The limit is the pack's observation: the quote says answering, not outcomes |
| Proven or strong written communicator | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the quote shows volume of answering, not how clear the writing was. A3 and D2 stay inside it |
| Led or ran a training programme | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the quote says you trained four new starters on one process, nothing wider |

## Sources

Provided documents: your message, which contains the invite text, your description of the ad's four requirements, and your background. The invite's description of a single text chat with the support team lead is the loop source for the persona weights. No dossier was present.

Searches sent, all refused by the host with a permissions error and so returning nothing: "Lumenvale Software values"; "Lumenvale Software interview process customer support specialist"; "Lumenvale Software strategy recent news". No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The one search sent was refused. It would have fed a values cheat sheet and mapped VAL questions to published values by name |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The one search sent was refused. It would have documented any rounds beyond the chat the invite describes, and could have reweighted the personas |
| 3. `Lumenvale Software strategy recent news` | unavailable | The one search sent was refused. It would have fed CO questions on current priorities and a grounding brief |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there is no query to form; there is no interviewer read |
| 5. Representative Customer Support Specialist JD | skipped | The four requirements you listed fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad: the four requirements are your summary, so the full text would catch any requirement missed, such as shifts, languages or named tools, and add JD-tagged questions
- Web research on Lumenvale's published values, product and support approach (it was refused here): would add CO and VAL questions grounded in the company, and any documented interview stages. A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, would add a strategy grounding brief
- The support team lead's name and role: personalised persona weights and a reverse question tied to their path
- Anything the recruiter or lead has said about what the chat covers: replaces assumed coverage with stated coverage
- A sentence on whether you have handled escalations, and what happened: upgrades F4 from `none given` and rewrites A4 and B4 as story-mapped answers
- A QA score, customer-satisfaction result or sample reply with details removed: raises F1 and F3 from `medium` and `low`, because those are the artifacts a support role keeps as proof
- A sentence on whether you have used any ticketing tool other than Freshdesk: tightens F2 and B2
- A `tuesday-dossier.md` from an earlier session: would supply verified evidence rows and prohibited claims, replacing the ones this pack built locally
