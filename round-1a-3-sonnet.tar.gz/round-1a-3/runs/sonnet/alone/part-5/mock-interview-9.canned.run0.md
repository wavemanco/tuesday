I'll read the reference files the skill requires before writing the pack.
Research is done: 5 searches and 2 fetches, all attributable to the district. I'm writing the pack file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-5/rooms/case-9-canned-6067bede/halvering-elementary_fourth-grade-teacher_interview_pack.md`.

Your résumé text included a Social Security number. I don't need it, and I haven't used it or put it in the pack. I also left your license number out, and you may want to strip both from anything you send onward.

I built the pack for the panel as the district describes it: the principal plus two fourth-grade teachers, asking about reading instruction, classroom routines and families. It has no full job posting behind it, so some requirement rows rest on a representative posting and are labeled `[inferred]`.

Your license requirement checks out against your résumé as written. The pack has not verified it, so confirm your own license record before Thursday. The question to rehearse first is A1: what's new for you in fourth grade. Hold the license and your third-grade years, say "I've never taught fourth grade" early, then give your plan. G1 is the 60-second version of the same question.

Say the word and I'll play the panel on A1, with follow-ups, and give you feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job posting, along with anything HR told you about what the panel will cover?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. A 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team. Built from your invite, your résumé text, and the district's published pages. No full job posting was supplied, so rows built on a representative posting are labeled `[inferred]`.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your résumé claims survive scrutiny and attribution |
| JD | The role's stated requirements, gaps included |
| CO | Homework on the district and school |
| CASE | A live classroom problem, reasoned aloud |

An answer slot is an instruction for the interview, not a question for you now. Meet it with whichever branch is true: say how you did it, or say plainly it was not yours or did not exist.

The highest-ROI rehearsal in this pack is **A1** (fourth grade, and the limit you have already named), with **G1** as its time-boxed version. Rehearse those two together first.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate, and your CV states it met. It is a CV line with nothing inspected behind it, so expect to be asked to confirm it. Say it in the quote's own terms: "My Illinois Professional Educator License has an Elementary Education endorsement for grades 1 through 6, registered and active through June 30, 2029." Whether your record shows it that way is yours to check against the license record itself; this pack has not verified it |
| F2 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then the other sentence at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then how you would learn fourth grade, said as a plan and never as a past; A1 holds the slot for it |
| F3 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board representative listing, not this school's posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Your material says third grade, not which subjects. Answer slot: if you planned and taught any of those subjects yourself, say which, in your own words; if some were taught by others or were not part of your job, say so plainly and stay with the six years. D2 rehearses it |
| F4 | "reading instruction" — district hiring page: "Panels ask about reading instruction, classroom routines and how you work with families." | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | No gap in wording, but two CV lines with nothing inspected behind them, so expect a probe on each. Lead in the quotes' own terms: you led your grade level's move to a new reading curriculum in 2024, and you have run the after-school reading club for the last two years. What "led" covered is an answer slot in D1; what happens in a club session is one in B4 |
| F5 | "classroom routines" — district hiring page | none given | none | [grounded] | discovery | Your material does not show routines either way. Answer slot: the district names routines as a panel topic, so expect a probe. If you set or ran routines in your own classroom, say what they were and why, in your own words; if that was not yours, or you cannot name any, say so plainly and say how you would set them up in a new grade |
| F6 | "differentiate instruction using assessment data" — K12 Jobs Board representative listing | none given | none | [inferred] | discovery | Your material does not show this either way. Answer slot: if you have used assessment results to adjust what you taught, say what you looked at and what you changed, in your own words; if you have not, or cannot name an example, say so plainly and say what you would look at first |
| F7 | "communicate regularly with families" — K12 Jobs Board representative listing | "I write a weekly email to families" — your CV | medium | [inferred] | none | The quote already reaches the requirement in role-relevant terms: a named, weekly record beats an adjective. Lead with it as written: "I write a weekly email to families." It is a CV line with nothing inspected behind it, so expect a probe on what the emails contain |
| F8 | "Families Are Partners: each teacher speaks with every family each term." — district mission and beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your material says a weekly email; the district's belief is about speaking with families, and the words stay at the email: "I write a weekly email to families." Answer slot: what a typical weekly email covers, in your own words; if you do not know how families respond to it, say so plainly |
| F9 | "work with the grade-level team" — K12 Jobs Board representative listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | Both sentences at their own scope: "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." Answer slot: which parts of the move were yours to carry and which were your colleagues' or the school's, in your own words; if the move did not work out that way, say so plainly and stay with the first sentence |

## Reading the interviewer

Only Principal Vantongeren has a public footprint in the material found. The two fourth-grade team members are unnamed, so nothing is read about them.

| Public fact | Source | What it means for you | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page, via search | Reading instruction is her professional home ground, so expect follow-ups on reading answers to go two levels deep (D1, B4, E1) | [grounded] |
| 2025 forum talk, Small Groups, Big Readers, on weekly reading conferences in grades 3 to 5 | Same page | A likely theme for her questions, and the best material for reverse question R1. Use her vocabulary only for things you actually do; the pack puts no reading-conference practice in your mouth (see section 13) | [grounded] |
| Shared vocabulary: reading instruction, reading curriculum, reading club | Her page beside F4's two quotes | The shared ground is reading. Your side of it is exactly two sentences: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" (F4) | [grounded] |

## Persona table

The district's hiring page establishes this loop: one 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and how you work with families. Your invite says the same. Persona weights below rest on that, plus the relationship priors for a panel (blend each member's top two personas). The hiring page names no values or behavioral round, so none is assumed; the district's published beliefs still theme the VAL questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the fourth-grade gap and of "how much of that was you" | High. F2 is a gap you stated yourself, and two panelists teach the grade; the principal's role resembles a hiring manager, whose prior is Skeptic plus Case | Rehearse A1 until it is boring: hold the license and third-grade years, concede "I've never taught fourth grade", then the plan |
| Peer Evaluator | The two fourth-grade teachers asking what you would bring to their team and need from it | High. Two of three panelists are team members; the peer prior is Peer Evaluator plus Prober | Reciprocity first; propose principles for how a team splits work rather than pretending to know the seam |
| Case / Strategist | Live classroom problems on routines, reading, families | Medium. The panel topics are practical, but no source says scenarios are used | Clarify, objective, approach, how you would know it is working; think aloud |
| Data-Driven Prober | Line-by-line questions on the curriculum move and the club | Medium. The principal's reading-specialist background makes reading follow-ups likely to go deep | Know what you can say about each CV line and say plainly what you do not know |
| Values / Behavioral | Stories mapped to the district's three published beliefs | Medium. The mission page says the beliefs guide every hire, but the hiring page names no values round | Use the selection scaffolds; a belief named without a real story scores as a slogan |
| Conversational | Friendly opener, license confirmation, "walk me through your journey" | Medium-low as a style, but certain as an opener, and still scored | A 90-second arc built only from your own sentences (F1 in the bank) |
| Pressure | Time-boxed or devil's-advocate challenges | Low. Nothing in the sources suggests a stress format | Pause, restate, hold through two follow-ups, concede specifically (G1, G2) |

## Question banks

### Bank A: Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your experience is in third grade. What would be new for you in fourth?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | The highest-ROI rehearsal in this pack. Hold, concede, plan. Hold with two sentences you wrote: "My license is Elementary Education, grades 1 through 6" and "I've taught third grade for six years." Concede early and specifically: "I've never taught fourth grade." Then the plan, said as a plan and never as a past. Answer slot: name the first two things you would want to learn about fourth grade and who on this panel you would ask, in your own words; if you do not yet know, say so plainly and say how you would find out. Hold through two follow-ups by returning to those sentences, never by adding to them | F2 is the gap you named yourself, and a panel with two fourth-grade teachers will find it early; JD because it scores the role's grade level. Rehearsed so the limit is stated before it is asked for |
| A2 | "Which part of this job would be hardest for you in your first month?" | JD | [grounded] | Choose from the three areas the district says panels ask about: reading instruction, classroom routines, how you work with families. The pack's observation is that your material shows nothing on routines (F5) or on using assessment data (F6) either way. Answer slot: name the area you honestly have least to say about and what you would do about it in the first month, in your own words; if you cannot pick one, say so plainly and say which you would ask a teammate about first | Skeptic stem asking for honest self-assessment; F5 and F6 are the rows with nothing behind them; JD because it scores stated responsibilities |
| A3 | "You led your grade level's move to a new reading curriculum. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Concede its limit in your own words: "I've never been a team lead." Answer slot: which parts of the move were yours and which were your colleagues' or the school's, in your own words; if you cannot separate them, or the move did not work that way, say so plainly and return to the first sentence. Hold through two follow-ups | The attribution probe on the line most likely to be pushed (F4, F9); EXP because it tests what was actually yours, in a pressure register |
| A4 | "Why fourth grade, and why Halvering?" | CO | [grounded] | The reason has to be yours, in your own words, because the panel will test it against your résumé. Give your actual reason for the grade and a separate, specific reason for this school or district. The district's published page gives you real things to point at: its three beliefs by name are Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. Name one only if it is genuinely part of why. If part of your real reason is practical, say that plainly beside the specific one | Skeptic motivation stem; CO because it scores homework on the district; it makes no claim about your past |
| A5 | "How do you set up classroom routines?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the district names classroom routines as a panel topic, so expect a probe. If you set routines in your own classroom, say what they were and why, in your own words; if that was not yours, or you cannot name any, say so plainly, return to "Six years teaching third grade at a public elementary school in Joliet", and say how you would set routines up in a new grade | F5 is a row with nothing behind it and a named panel topic; JD because it scores a stated responsibility; the premise is allowed to be false |

### Bank B: Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be joining the fourth-grade team. What would you bring to it, and what would you want from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity first. What you bring rests on one sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: what that move asked of your colleagues and how you worked with them, in your own words; if it was not carried with colleagues, say so plainly. What you want from them: propose a principle rather than a seam you cannot know yet, such as asking the team how it splits planning before suggesting changes | F9 and the peer prior; JD because the listing names working with the grade-level team |
| B2 | "Tell me about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | Selection scaffold: pick a time with a named stake, where you raised the disagreement directly with the colleague, and where the working relationship was intact at the end. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem on disagreement with equals; no row carries a story for it, so this is a scaffold, not a story map |
| B3 | "How do you handle credit when work spans the team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | "We" for context, "I" for contribution. Say what you led in the sentence's own terms and name colleagues' parts as theirs. Do not describe yourself as a team lead: "I've never been a team lead." Answer slot: which pieces of the move were your colleagues', in your own words; if you cannot say, or it had no such pieces, say so plainly | Peer credit-sharing probe; the stated negative in F9 keeps the answer at its true size |
| B4 | "Tell us about the reading club. What do you do there that we might borrow?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Beats the sentence states: after school, a reading club, you have run it, for the last two years. Answer slot: what happens in a club session, in your own words; if the club has no fixed shape, or part of it is run by others, say so plainly and stay with the sentence. "Borrow" is the interviewer's word; offer only what you actually do | F4; reciprocity framing, what you add to their team; EXP because it tests what you actually do |

### Bank C: Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's the second week of school, and your class takes too long to get from reading to math. Where do you start?" | CASE | [generic] | Clarify first: what "too long" looks like and where the time goes. Then the objective, one routine to teach and practice, and how you would know it is working. Think aloud and challenge one premise respectfully. It needs no claim about your past | The district names classroom routines as a panel topic; CASE because it is a live problem |
| C2 | "A fourth grader is reading well below the rest of the class. What do you do in the first two weeks?" | CASE | [generic] | Clarify what the evidence for "well below" is and who else already knows. State the objective, your approach, and what you would check after two weeks. Think aloud. It needs no claim about your past | Reading instruction is a named panel topic and the principal's background is reading (see interviewer read); CASE |
| C3 | "The board adopted a literacy plan in August 2026, including a new grades 3 to 5 reading curriculum from fall 2027. How would you get ready to teach it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you have read it: the plan has structured phonics from kindergarten to second grade, a new grades 3 to 5 reading curriculum from fall 2027, and a family reading night at every school each term. Structure the answer: what you would want to know first, what you would learn, who you would work with. Your own sentence is the one place your past meets the plan: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: what that earlier move would teach you for this one, in your own words; if nothing carries over, say so plainly and reason from principle | The strategy-grounded CO question; F4 supplies the one sentence it may touch |

### Bank D: Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the move your grade level made to a new reading curriculum in 2024. What was your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Beats the sentence states: 2024, your grade level, a new reading curriculum, you led the move. Tell them in your own words. Answer slot: what leading the move involved for you, concretely; if someone else made key choices or it was shared, say so plainly and return to "I led our grade level's move to a new reading curriculum in 2024". Expect follow-ups two levels deep; know what you can say and say plainly what you do not know | F4 and F9; the line a reading-focused panelist is most likely to examine |
| D2 | "Which subjects do you teach in your own classroom, and where do you feel least secure?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the representative listing for this role names reading, writing, math, science and social studies, so expect a probe on which were yours. Say which, in your own words; if some were taught by others or were not yours, say so plainly and stay with "Six years teaching third grade at a public elementary school in Joliet". For "least secure", name one honestly or say plainly why none comes to mind | F3; JD, and `[inferred]` because the listing is typical for the role, not this school's |
| D3 | "How do you use assessment data to shape your teaching?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the district's third belief says assessments inform teaching and never replace it, so expect a probe. If you have used assessment results to adjust what you taught, say what you looked at and what you changed, in your own words; if not, or you cannot name an example, say so plainly, return to "Six years teaching third grade at a public elementary school in Joliet", and say what you would look at first | F6; the published belief raises the probe |

### Bank E: Values / Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader is one of our beliefs. Tell me about a time a child's reading wasn't moving and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick a time with a named stake, what you tried, what changed and what you would do differently, with no identifying detail about the child. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years", or how you would handle it | VAL on the first published belief; your material carries no story for it, so this is a scaffold |
| E2 | "Families Are Partners. Tell me about a time you worked with a family to help a child." | VAL | [grounded] "I write a weekly email to families" | The sentence carries these beats: weekly, an email, families. For a story beyond that, pick a time with a named stake, what you told or asked the family, and what changed; if none comes to mind, say so plainly and give the sentence as written. Answer slot: what a typical weekly email covers, in your own words; if you do not know how families respond, say so plainly | VAL on the second belief; F7 and F8 |
| E3 | "Teach for Tomorrow, Not for the Test. When have you taught toward more than a test?" | VAL | [grounded] | Selection scaffold: pick a time where a test or score could have set the lesson and you chose a different aim, say what the aim was, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | VAL on the third belief; no row carries a story for it |

### Bank F: Conversational (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through your journey and what brought you to apply." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc, in order, each beat at its sentence's own scope: the license, six years of third grade in Joliet, the 2024 curriculum move you led, the club you have run for two years, the weekly family email. Close with your real reason for this role, which A4 rehearses. Your path before these sentences is yours to tell in your own words; the pack has nothing to say about it | The opener is scored even when friendly; a pre-built arc stops you wandering |
| F2 | "Just to confirm before we start: your Illinois license is current, with the elementary endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Short and exact: "My Illinois Professional Educator License has an Elementary Education endorsement for grades 1 through 6, registered and active through June 30, 2029." Nothing added. Know where your own license record sits so you can confirm if asked | F1, the gate requirement; JD because the invite states it as a requirement |

### Bank G: Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you, over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | Pause and restate the question. Hold with the sentences: "I've taught third grade for six years" and "I've run the after-school reading club for the last two years." Concede plainly: "I've never taught fourth grade." Say nothing about the other candidate. Answer slot: the first thing you would do to learn fourth grade, as in A1, in your own words; if you do not know yet, say so plainly | The time-boxed version of A1; rehearse the two together |
| G2 | "You send weekly emails. Do families actually read them?" | EXP | [grounded] "I write a weekly email to families" | Hold the sentence as written: "I write a weekly email to families." Answer slot: if you know how families respond, say what you know, in your own words; if you do not know, say so plainly, which is a complete answer. Do not supply a rate | Devil's-advocate challenge on F7; EXP because it tests what you actually know |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 license with elementary endorsement | F2, A1 |
| F2 Fourth Grade Teacher position | A1, A2, A4, G1 |
| F3 plan and teach reading, writing, math, science and social studies | D2 |
| F4 reading instruction | D1, B4, C2, C3, E1 |
| F5 classroom routines | A5, C1 |
| F6 differentiate instruction using assessment data | D3, E3 |
| F7 communicate regularly with families | E2, G2 |
| F8 Families Are Partners | E2 |
| F9 work with the grade-level team | B1, B2, B3, A3 |
| Every Child a Reader; Families Are Partners; Teach for Tomorrow, Not for the Test | E1; E2; E3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. How does that look in a fourth-grade classroom at Halvering?" | Tied to the principal's own public path; it asks her to describe the practice and claims nothing about yours |
| R2 | "What would help your team most from a new fourth-grade teacher in the first month?" | Reciprocity with the two team members: it asks what you can do for them, not only what you need |
| R3 | "The board's August 2026 literacy plan brings a new grades 3 to 5 reading curriculum in fall 2027. Where is the fourth-grade team in getting ready for it?" | Shows you read the plan and asks about the team's load rather than reciting it |
| R4 | "What support does a teacher new to fourth grade usually get in the first term?" | Fits the gap you have named without apologising for it; it signals you plan the ramp |
| R5 | "What would you want to be true of the person in this seat a year from now?" | Lets the panel describe the job's success measure in their words |
| R6 | "I understand references follow the panel. What are the next steps and timeline?" | Process question drawn from the district's hiring page; it shows interest without asking for anything |

## Prohibited claims

Built from the fit snapshot before the banks were written. These are the claims this pack will not coach, with the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | "I've never taught fourth grade." Then "Six years teaching third grade at a public elementary school in Joliet" at its own scope. No slot attaches to the denial |
| Has been a team lead, or led the grade-level team | Negative you stated, F9 | "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." |
| Chose or designed the new reading curriculum | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says the grade level's move, not who chose the curriculum. D1's slot stays inside the move |
| Speaks with every family each term | Inflated form of F8, using the district's own wording | F8's quote at its own scope. The limit is the pack's observation: your material says a weekly email, not conversations with families. E2's slot stays inside the email |
| Runs small-group reading conferences | Inflated form of F4's club line, tempting because of the principal's talk | The club quote at its own scope. The limit is the pack's observation: your material says the club, not its format. B4's slot asks only what happens in a session |

## Sources

Provided documents: your invite text and the résumé text you pasted into the conversation. Identifying numbers in the pasted text were not used, in searches or in this pack.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The district's three published beliefs by official name; E1 to E3, A4 and the F8 requirement. No values-style round is detected, so there is no values cheat sheet |
| 2. `{company} interview process {role family}` | yes | Loop structure: one 45-minute panel of principal plus two grade-level teachers and its three topics; persona weights and bank depth |
| 3. `{company} strategy` / recent news | yes | The August 2026 literacy plan; C3 and R3. A snippet only; the full plan page was not read |
| 4. `{interviewer name} {company}` | yes | The principal's public career and 2025 talk; interviewer read, R1, and the shared-vocabulary row. A snippet only |
| 5. representative `{role title}` JD | yes | A representative listing used for F3, F6, F7 and F9, labeled `[inferred]`; its qualifications line was cut off in the result and was not used |

Searches sent, and what came back:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel elementary" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Fourth Grade Teacher job description Illinois public elementary school responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: the mission and beliefs page and the how-we-hire-teachers page above; both returned the same text as their search snippets.

## Upgrade menu

- The full job posting text → F3, F5, F6, F7 and F9 move from `[inferred]` requirements to quoted ones, and D2, D3 and A5 get re-aimed at the posting's own wording
- Anything HR sent about what the panel will cover → coverage tuned to the stated topics instead of the district page's general ones
- Your license record as the state shows it → F1 confidence can rise above medium once it has been inspected
- Whether you have used assessment results, set classroom routines, or spoken with families directly rather than by email, stated outside a drill → F5, F6 and F8 become story maps instead of answer slots
- The names of the two fourth-grade teachers → per-member persona weights and a tailored reverse question
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the literacy plan and the district's recent context, and sharper CO and CASE questions
- A `tuesday-dossier.md`, if you ever build one → verified evidence and a named worst objection, which would replace this pack's inferred one
