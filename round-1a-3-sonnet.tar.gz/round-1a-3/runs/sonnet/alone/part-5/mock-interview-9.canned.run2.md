I'll read the reference files this skill points to before building the pack.
Pack is written. I'm doing a quick check that no SSN, license number or stray brackets made it into the file, then I'll hand it over.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-5/rooms/case-9-canned-5a075dfc/halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for the panel your invite describes: Principal Vantongeren plus two fourth-grade teachers. It has 19 practice questions, a fit table, reverse questions and a list of claims not to make.

- **Your top prep is question A1.** You've never taught fourth grade, so expect "what will be hardest in your first month?" The pack coaches you to say plainly "I haven't taught fourth grade," hold on your six years of third grade, and then give a plan rather than a past.
- **Your license matches the invite's requirement.** I used your license details without the number.
- **I didn't use your Social Security number.** It isn't needed for interview prep, and I'd leave it off anything you send ahead.
- **Several rows are marked "inferred".** The invite wasn't a full job description, so I used one representative fourth-grade posting from a jobs board. Halvering's real posting could change them.
- **Some research is thin.** The district's three published beliefs, the board's 2026–2029 literacy plan and the principal's background came from a few web search results. For the hiring page, the literacy plan and her background I saw only a short snippet, not the full page.

Say the word and I'll play the skeptical panelist on A1 so you can rehearse it live. I can also save a `tuesday-dossier.md` noting the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, I'll convert it.

1. Do you have the full text of Halvering's posting, or anything HR sent beyond the invite, such as a demo lesson or focus areas? Pasting it would firm up the "inferred" rows. No problem if you don't.
2. Want a deeper research pass on the district and the principal's talks? It's up to 6 more searches and 2 more fetches, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Employer:** Orrinsford Community School District
- **Round:** 45-minute panel on Thursday, with Principal Dolores Vantongeren and two members of the fourth-grade team (the two team members are not named)
- **Candidate:** Grace

## How to use this pack

- **Personas** describe how a question arrives (who is asking, in what style). **Types** describe what is being scored. Rehearse both.
- **Type key:** VAL = behavioral or values alignment (does past behavior show the district's published beliefs). EXP = work-experience deep-dive (does your CV survive scrutiny). JD = role and posting-driven (can you do the listed job, gaps included). CO = company and strategy knowledge. CASE = a live problem set in the role.
- **Provenance key:** `[grounded]` traces to your material or to research cited in Sources. `[inferred]` is derived from a representative posting or an adjacent source. `[generic]` is a role-family pattern with no claim about this employer or about you.
- Answer guidance is scaffolding, not a script. Say it in your own words. An **answer slot** is an instruction for the interview, not a question for you now: it has two honest branches, and either one is a good answer.
- Bank letters skip F so question IDs never collide with fit-snapshot rows (F1, F2 and so on).
- **Highest-ROI prep in this pack: A1.** The objection that you have not taught fourth grade will arrive in some form. A calm, short, rehearsed answer changes the interview.

## Fit snapshot

No posting from Halvering was supplied. Requirements come from three places, each named in its row: the invite, the district's published beliefs (fetched), and one representative fourth-grade posting from a jobs board (fetched; typical for the role, not this school's own words).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your words reach the gate in its own terms, so no gap. It is a CV line with nothing inspected behind it, so expect the panel or HR to check it against the state's license record; arranging that check is yours. The pack's observation: the quote's grades 1–6 range contains fourth grade. Say it once in the quote's terms and stop |
| F2 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your material says six years of third grade and does not say which subjects. Answer slot: the posting's five-subject line makes a probe on subjects likely. If you taught several of them, say which, in your own words; if you taught only some, or a subject was taught by someone else, say so plainly and stay with third grade |
| F3 | "experience in grades 3 to 5 preferred" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | Third grade sits inside the posting's range, so no gap on its own terms. Lead with the quote: six years teaching third grade at a public elementary school in Joliet. The limit: this is a typical-role line, not Halvering's own wording |
| F4 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |
| F5 | "work with the grade-level team" — representative posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV, "I've never been a team lead" — your message | medium | [inferred] | presentation | Reword only the first quote: "In 2024 I led our grade level's move to a new reading curriculum." It names the move and its year, no process, team makeup or result, and the pack adds none. The second quote stays true beside it: if asked about a title, "I haven't been a team lead" |
| F6 | "differentiate instruction using assessment data" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material does not show how assessment data entered your teaching. Answer slot: expect a probe. If you used assessment results to change what or how you taught, say what the results were and what you changed, in your own words; if you did not, or that was set by others, say so plainly and say what you would look at first |
| F7 | "communicate regularly with families" — representative posting, K12 Jobs Board | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap in the quote's own terms. Lead with it: a weekly email to families is a named routine, which beats an adjective. Expect a probe on it, and tell only what the email actually is |
| F8 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your words are an email, and the belief says speaking. Hold the quote at its own scope. Answer slot: the belief raises whether you also speak with families directly. If you do, say how and when, in your own words; if you do not, or it has not been part of your practice, say so plainly and stay with the weekly email |
| F9 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | A curriculum move and a club are adjacent to this belief, and neither quote mentions plans for individual students. Words: the two quotes at their own scope. Answer slot: a probe on individual reading plans is likely, since the belief is about the grade you taught. If you kept or contributed to individual plans, say how, in your own words; if there were none, or they were set elsewhere, say so plainly and stay with the curriculum move and the club |
| F10 | "assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | The material is silent on how assessments shaped your teaching. Answer slot: if a result changed what you did, say what it was and what changed, in your own words; if none did, say so plainly and say how you would keep assessment informing rather than replacing |
| F11 | "keep clear classroom routines" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | The material is silent on routines, and this is a typical-role line. Answer slot: if you set or kept routines, name one and say why, in your own words; if they were set by the school or others, say so plainly and say what you would set up first in a new room |

## Reading the interviewer

Only the principal is named. The two fourth-grade team members are unknown, so nothing is read about them.

| Public fact | Source | What it means for you | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page, read as a search snippet only | Reading instruction is her home ground, so expect depth on reading. Keep every reading answer to what you did (B1, D1, E1) | [grounded] |
| 2025 forum talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 | Same page and snippet | The pack's reading: her recurring theme is individual readers. Expect interest in how you see individual readers, and do not claim a conference practice your material does not show (F9 slot) | [grounded] |
| Mirror: her talk spans grades 3 to 5 | Same page and snippet | Pair it with your own sentence at its own scope: "Six years teaching third grade at a public elementary school in Joliet" (F3). Use shared vocabulary only. Her path from specialist to principal is not offered as a shared jump, because no row carries your side of it | [inferred] |

## Persona table

The loop is established by your invite: one 45-minute panel, the principal and two fourth-grade team members. The district's careers page, seen as a search snippet only, matches that and adds that panels ask about reading instruction, classroom routines and working with families. No values-style round is documented, so there is no values cheat sheet. The published beliefs still theme the D bank.

| Persona (bank) | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probes on the move from third grade, the team seat, and the license | Highest. Your message names two absences (F4 and the lead title in F5), and a panel built around a fourth-grade seat will reach for the first. Five questions | Rehearse A1 until it is boring. Bridges only from the quoted third-grade sentence, a plan said as a plan, and the plain acknowledgment F4 gives |
| Peer Evaluator (B) | The two team members asking what it is like to work beside you | High. The relationship prior for peers, and the invite puts two of them on the panel. Four questions | Reciprocity framing: what you bring, said at the quotes' scope, and principles rather than pretending to know their seam |
| Case/Strategist (C) | The principal setting live classroom problems | Medium. The principal is the hiring-manager seat, and the careers snippet says panels ask about reading, routines and families, which are scenario-shaped. Three questions | Clarify first, then structure, then think aloud; challenge one premise respectfully |
| Values/Behavioral (D) | Prompts keyed to the three published beliefs | Medium. The beliefs page says they guide every hire, but no round assessing them is documented. Three questions | One honest story per belief where a quote carries one, and a selection scaffold with its honest branch where none does |
| Data-Driven Prober (E) | Close reading of the CV lines | Low to medium. Your CV has few figures, so there is little to defend numerically, but peers read closely. Two questions | Say what each line says and no more; say plainly when you did not track something |
| Conversational (G) | A warm opener such as the journey question | Low to medium. It is a panel opener in most formats, and the risk is treating it as unscored. Two questions | A 90-second arc built only from your own sentences |
| Pressure | No bank | Low. Nothing in the sources points to a stress style. The pressure stem sits inside A3, and a drill can turn it up on request | Hold-then-concede, as in A1 and A3 |

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What will be hardest for you in your first month?" | JD | [grounded] "I've never taught fourth grade", "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal. Say it plainly: "I haven't taught fourth grade." Then hold what the second quote carries: six years teaching third grade at a public elementary school in Joliet. Hold through two follow-ups by returning to that sentence, never by adding to it, and concede specifically that the gap is real. Then give a plan as a plan: say, in your own words, what you would ask the fourth-grade team in your first weeks and what you would watch for, choosing only things you would really do. Never describe fourth-grade work as something you have done | F4 is the likeliest objection in this loop, and F3 is the only evidence that bears on it. JD because the posting is for a fourth-grade seat; the hold-then-concede shape is the Skeptic's bar |
| A2 | "Which part of this job would you be weakest at on day one: the subjects, routines, families, the team?" | JD | [inferred] | Pick one item from the posting's list where you are least practiced and name it plainly, then the first concrete step you would take, in your own plan. If no one part stands out, say so plainly, then say how you would find out. Do not pick a gap you would not be willing to discuss for two follow-ups | F2, F6 and F11 are the rows where the material shows nothing, so this stem lands there. JD because it scores the listed responsibilities; `[inferred]` because the list is from a representative posting |
| A3 | "You led a move to a new reading curriculum. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024", "I've never been a team lead" | Hold the sentence as it stands: "In 2024 I led our grade level's move to a new reading curriculum." Answer slot: which parts were yours, in your own words. If some of it was decided or set by others, or no part was distinct, say so plainly and stay with the sentence. Hold through two follow-ups. If the follow-up turns to title, "I haven't been a team lead" said plainly, without a hedge | F5 is the strongest evidence in the pack and so the one most probed for attribution. EXP because it tests what was actually yours; the Pressure stem is carried here |
| A4 | "Why leave third grade: why this move, why Halvering, why now?" | JD | [generic] | Your own reasons, in your own words; the pack supplies none. For why here, pick one published fact you genuinely care about, such as one of the district's three beliefs or its 2026–2029 literacy plan (see Sources), and say why it matters to you. If no reason beyond the job itself comes to mind, say so plainly rather than inventing one | The Skeptic's motivation-consistency stem. `[generic]` because the guidance makes no claim about your past |
| A5 | "Tell us about your licensure: what do you hold, and through when?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms once: the license, the elementary endorsement for grades 1–6, registered and active through June 30, 2029. Then stop; do not pad. Have your license record available in case they ask to see it | F1 is the invite's stated condition, so a confirming question is near-certain. JD because it scores a stated qualification |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about working with your grade-level team." | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story map on F5, beats limited to what the sentence states: the grade level, the new reading curriculum, the move, 2024. Say it in your own words. Answer slot: the posting's team line makes a probe on how colleagues responded likely. If views differed and you did something about it, say what happened and what part was yours; if they did not differ, or none of it was yours, say so plainly and stay with the sentence | F5 is the only team evidence; the question is an open prompt themed by the posting's team line. JD because it scores that requirement |
| B2 | "How do you handle it when you and a teammate disagree about how to teach something?" | EXP | [generic] | Selection scaffold: pick a time you disagreed with a colleague about instruction. It needs the disagreement, your position, and how it ended, whether or not you prevailed. If no such time comes to mind, say so plainly, then give how you would handle it | The Peer persona's disagreement-with-equals stem. `[generic]` because it supplies no event |
| B3 | "You would join a team that has taught fourth grade. What would you ask of us, and what would you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years", "I write a weekly email to families" | Two halves. The ask: say what you would ask the team first, in your own plan. The bring: name the three quoted things at their own scope and no wider. Offer working principles rather than pretending to know their seam | Reciprocity framing; F4 makes the ask half the honest one and F5, F8 and F9 carry the bring half. JD because it scores fit with the team requirement |
| B4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use the sentence as it stands for your part: "I led our grade level's move." For the rest, speak of the team in "we" terms about what is not yours. If asked who did what beyond the sentence, say plainly what you do not know or did not do | A credit probe is the Peer persona's standard; F5 is the only claim that invites it |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new fourth grader joins in October, reading well below grade level, with no reading plan from the previous school. What do you do in the first two weeks?" | CASE | [inferred] | Clarify before structuring: what is known about the child's reading, what data exists, what the family wants. Then objective, a first-two-weeks plan, how you would check it is working, how you would bring the family in, and the risks. Think aloud; challenge one premise respectfully. It needs no claim about your past, so the guidance makes none | Derived from the published belief Every Child a Reader and the posting's differentiation line (F6, F9). CASE because it is a live problem in the role; `[inferred]` because the scenario is this pack's construction |
| C2 | "It is the second week. Transitions eat the first twenty minutes of your reading block. Diagnose it and tell me what you would change." | CASE | [inferred] | Clarify first: which transitions, what the class is doing, what routines exist. Then hypotheses, one small change, how you would see whether it worked, and what you would tell the team. Makes no claim about your past | The posting's routines line (F11) as a live problem; `[inferred]` because the line is from a representative posting |
| C3 | "The board has adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027. How would you get a fourth-grade classroom ready for that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you have read it: name what the plan says (see Sources). Then structure the answer as questions you would ask the principal and team, and the preparation you would do. If you use your own experience, use the sentence at its scope and no wider. Do not claim to know which curriculum the district will choose | The CO differentiator: most candidates will not have seen the plan. CO because it tests strategy fluency; F5 is the only link to your own history |

### D. Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you helped a student who was struggling to read." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Theme: Every Child a Reader. Selection scaffold: pick one student or moment from your class or the club, with a stake, what you did, and what the student then did; keep it to what you can answer two follow-ups on. The quote carries only that you run the club, after school, for two years. If no such moment comes to mind, say so plainly, then give the club as the quote states it, or how you would handle it | F9 is the nearest evidence and does not carry a student story. VAL because the prompt is themed by a published belief |
| D2 | "How do you keep families partners in their child's learning?" | VAL | [grounded] "I write a weekly email to families" | Theme: Families Are Partners. Start with the quote as it stands: "I write a weekly email to families." Tell only what the email actually is. Answer slot: the belief raises whether you also speak with families directly. If you do, say how and when; if you do not, or it has not been part of your practice, say so plainly and stay with the email. Never describe it as conversations with every family | F8 is the row; it is adjacent to the belief and does not reach it. VAL because it is themed by a published belief |
| D3 | "Tell me about a time an assessment result changed what you taught." | VAL | [grounded] | Theme: Teach for Tomorrow, Not for the Test, whose published meaning is that assessments inform teaching and never replace it. Selection scaffold: pick a time a result changed your plan, with what it showed, what you changed, and what happened. If no such time comes to mind, say so plainly, then say how you would keep assessment informing your teaching | F6 and F10 are silent, so the guidance claims nothing about your past. VAL because it is themed by a published belief |

### E. Data-Driven Prober (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me how the reading club runs." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say what the quote states: you have run it, after school, for two years. Then say, in your own words, how it actually runs. Where a follow-up asks something you did not track, say so plainly | F9 raises the club and nothing in the material goes further. EXP because it tests the claim |
| E2 | "Walk me through a typical week in your third-grade classroom." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | The week is yours; the pack supplies none of it. Answer slot: the posting's five-subject line makes a probe on subjects likely. If you taught several of them, say which and how the week ran; if you taught only some, or another teacher had a subject, say so plainly and describe the week you did have | F2 is discovery; this surfaces the answer. EXP because it checks the CV line |

### G. Conversational (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey: how did you come to this chair?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet", "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years", "I write a weekly email to families" | A 90-second arc in this order, each beat a quote at its own scope: six years teaching third grade at a public elementary school in Joliet; in 2024 leading your grade level's move to a new reading curriculum; running the after-school reading club for two years; writing a weekly email to families. Then your own reason for fourth grade, in your own words | A casual opener that is still scored. F3, F5, F7 and F9 supply the beats |
| G2 | "What are you trying with your readers these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick one thing happening now in the club or your class that you can describe in a minute, with what it is and what you have seen. The quote carries only that you run the club. If nothing comes to mind, say so plainly, then give the club as the quote states it | The Conversational persona's hot-topic stem, aimed at reading, the one topic the sources agree on. F9 is the only link |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license and endorsement | A5 |
| F2 plan and teach five subjects | A2, E2 |
| F3 grades 3 to 5 | A1, G1 |
| F4 fourth-grade seat | A1, A4 |
| F5 work with the grade-level team | A3, B1, B3, B4, C3 |
| F6 differentiate using assessment data | C1, D3 |
| F7 communicate regularly with families | D2, G1 |
| F8 speak with every family each term | D2 |
| F9 every child a reader, reading plan | C1, D1, E1, G2 |
| F10 assessments inform teaching | D3 |
| F11 clear classroom routines | A2, C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Principal Vantongeren, you spent nine years as a reading specialist before becoming principal. How does that shape what you want a fourth-grade reading block to look like?" | Tied to her own public path. It invites her to talk about reading, her home subject, and shows you looked at her rather than only the school |
| R2 | "What would help your team most from a new teammate in the first month?" | Reciprocity for the two peers on the panel: it asks what you can do for their load, not only what you need |
| R3 | "The board's plan includes a new grades 3–5 reading curriculum from fall 2027. What does a fourth-grade teacher joining now do to prepare, and what is the team's role?" | Shows you read the district's own plan and turns a CO answer into a conversation. It presumes nothing about how they work |
| R4 | "How does the school support a teacher who is new to a grade?" | Addresses the F4 gap openly and turns the objection into a plan the panel can describe |
| R5 | "What does a strong first semester look like for the person in this seat?" | Lets the panel state what they are scoring, which sharpens your last impression |
| R6 | "What happens after the panel, and what is the timeline?" | Practical, and leaves you knowing what to prepare next |

## Prohibited claims

Claims this pack will not coach, with their basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Any wording that says you have taught fourth grade | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't taught fourth grade." Then the third-grade quote at its own scope. No slot |
| Any wording that says you have been a team lead | Negative you stated, F5 | The plain acknowledgment: "I haven't been a team lead." Beside it, F5's first quote at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." No slot |
| Led the curriculum choice or rollout for a school or district | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says a grade level's move, not a wider one. A3's slot stays inside the sentence |
| Runs the school's reading program | Inflated form of F9 | The club quote at its own scope. The limit is the pack's observation: the material says an after-school club, run for two years |
| Speaks with every family each term | Inflated form of F8 | F8's quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: the material says an email, not a conversation. D2's slot stays inside the email |

## Sources

**Provided documents:** the invite from Human Resources, Orrinsford Community School District; your CV text and statements in your message. No `tuesday-dossier.md` was in hand.

**Searches sent (5):**

- `Orrinsford Community School District mission values` returned https://orrinsfordschools.example/about/mission-and-beliefs
- `Orrinsford Community School District teacher interview process panel` returned https://orrinsfordschools.example/careers/how-we-hire-teachers (snippet only; not fetched)
- `Orrinsford Community School District news strategic plan` returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet only; not fetched)
- `Dolores Vantongeren Halvering Elementary School principal` returned https://ilprincipalsforum.example/speakers/dolores-vantongeren (snippet only; not fetched)
- `Fourth Grade Teacher Illinois elementary job description responsibilities qualifications` returned https://k12jobsboard.example/listings/fourth-grade-teacher

**Fetches sent (2):** https://orrinsfordschools.example/about/mission-and-beliefs (returned the three beliefs and their meanings), https://k12jobsboard.example/listings/fourth-grade-teacher (returned the representative posting, responsibilities and qualifications).

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three beliefs by name: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Fit rows F8 to F10 and the D bank |
| 2. `{company} interview process {role family}` | yes | Returned a careers-page snippet that matches your invite's one 45-minute panel. Persona weights and the note that no values-style round is documented, so no values cheat sheet |
| 3. `{company} strategy` / recent news | yes | The board's 2026–2029 literacy plan, from a snippet. Question C3 and reverse question R3 |
| 4. `{interviewer name} {company}` | yes | Section Reading the interviewer, from a snippet, and reverse question R1. The two team members are unnamed, so nothing was searched for them |
| 5. representative `{role title}` JD | yes | Fit rows F2, F3, F5, F6, F7 and F11, labeled `[inferred]`, and the JD-tagged questions |

## Upgrade menu

- Halvering's own posting, or any text HR sent beyond the invite → rows F2, F3, F5, F6, F7 and F11 move from `[inferred]` to `[grounded]`, and the JD-tagged questions get re-sourced
- Any recruiter or HR guidance (focus areas, or a demonstration lesson or writing task if one was announced; usually one email to HR) → coverage tuned to the panel's stated focus, and a build section for any announced deliverable
- The names and roles of the two fourth-grade team members → an interviewer read for each, persona weights adjusted, and reverse questions tailored to them
- Your own answers to the answer slots (which subjects you taught in F2; whether you spoke with families directly in F8; any assessment-driven change in F6 and F10; individual reading plans in F9) → those rows and the bank cells that draw on them move from slots to quoted stories
- A copy or printout of your license record from the state's licensing system → F1 moves from `medium` to `high`
- A `tuesday-dossier.md` from an earlier evidence review → verified evidence per requirement and an agreed positioning for each weak area, without which the pack infers its top objection
