I'm still reading the skill's reference files so the assessment follows its required shape. Next up are the worked report and the risk and decision rules.
Pivoting into PM is not a waste of your time. This particular role is a stretch, because its one explicitly labeled must-have is 3+ years of product management and you have no PM title. I'd apply, as a conditional go, and not by sending a cold resume to the portal. The conditions are below.

My two search calls were refused, so nothing here is checked against the web. Everything about Quartzline comes from the JD you pasted.

## Decision snapshot

**No, you are not wasting your time. This is a stretch role that is worth a targeted application. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1 (3+ years PM experience), R2 (shipped API or platform products) · unclear: R4b (launches with sales and support), R5 (agile delivery)
- `important` — direct: R7 · adjacent: R6 (roadmap, specs, two squads) · unclear: R8 (adoption metrics)

R1 — adjacent work only, zero titled PM years. R2 and R8 — one unconfirmed lead (the triage tool) could bear on both. R3 (`medium`) — your strongest row, with no artifact inspected yet.

**Opportunity ledger.** The role reads as clearly scoped, with an explicit mandate to own the roadmap (RR3). The employer is unverified (RR1), the JD may be screened literally on titled years (RR2), and both decision rights (RR4) and pay (RR5) are unstated.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting is confirmed live and the employer matches the description (RR1).
  2. You can substantiate at least one real product-style outcome, such as a shipped tool or an adoption result (G1 → R2, R8).
  3. You get a read on whether implementation-led product work is accepted in place of titled years (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently verified |
| Mandate | Own the roadmap of the partner-facing API platform; run partner discovery; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Seniority | Mid-level, set by "3+ years product management experience (must-have)" | `[inferred]` from the stated years floor |
| Scope read | One product area with two squads is a bounded remit for a company this size | `[inferred]` from the squad count and company size in the JD |
| First-90-days outcomes | Not stated in the JD | `[grounded]` JD silence |
| Market calibration | Not run, because search was refused; no band for title or pay | `[generic]` none available |
| Unknowns | Decision rights over the roadmap; compensation; level and title; the team you would sit in | `[grounded]` JD silence |
| Contradictions | None found within the JD; the company's careers page was not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | low | transferability | You have held no PM title, so titled tenure is zero. Credible adjacent work: roadmap-input sessions, requirements docs, and coordinating with PMs. Limit: none of it shows you deciding priorities or owning outcomes. | `[grounded]` your statement; `[generic]` that titled years are often screened literally | G2; RR2 |
| R2 | Shipped API or platform products | must_have | adjacent | low | discovery | You delivered 30+ client integrations of your vendor's REST APIs, which is implementation and not shipping the product. Limit: nothing you stated shows you building or releasing an API product. | `[grounded]` your statement; `[inferred]` limit from the absence of any product-build claim | G1 |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Seven years on REST integrations, plus Postman, SQL, and OpenAPI reading. Stated and specific; nothing inspectable yet. | `[grounded]` your statement | Optional: the playbook, sanitized, would raise this to `high` |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers, and PMs across 30+ integrations. | `[grounded]` your statement | none |
| R4b | Coordination with sales and support on launches | must_have | unclear | none | discovery | Nothing stated about sales or support. Go-lives with clients are a nearby activity, not the same thing. | `[grounded]` silence in your resume | G4 |
| R5 | Experience with agile delivery | must_have | unclear | none | discovery | Nothing stated about sprints, backlogs, or squad rituals. | `[grounded]` silence in your resume | G3 |
| R6 | Roadmap ownership, specs, driving two squads | important | adjacent | medium | discovery | Written requirements docs and engineer coordination are real. It is not established whether you made prioritization calls or owned delivery. | `[grounded]` your statement; `[inferred]` limit | G3 |
| R7 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops across 30+ clients and quarterly roadmap-input sessions are partner discovery in substance. The resume frames it as implementation and feedback collection. | `[grounded]` your statement | E1 |
| R8 | Define and track adoption metrics | important | unclear | none | discovery | Nothing stated. An unconfirmed memory lead (a triage tool that support agents adopted) could bear on this. It is not evidence until you confirm it. | `[grounded]` silence; `[inferred]` from the lead | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption (R2, R8) | discovery | Integration delivery is established; building or releasing a product, and measuring use, is not. | Two rows hinge on it, one a must-have, and it is the most direct counter to the titled-years objection. | An internal tool or integration kit others adopted; a feature you specified that shipped; a usage or adoption figure you tracked | A short write-up, usage numbers, a screenshot, or a README | `[grounded]` CV silence; `[generic]` that this row is likeliest to be probed |
| G2 | Titled years (R1) | transferability | Adjacent evidence only. | Cannot be closed by wording; only the employer's reading of equivalence can narrow it. | Product decisions you drove inside client builds; input you gave that changed what product built | Roadmap-input session notes or outcomes | `[grounded]` your statement; `[generic]` on how it is read |
| G3 | Decisions owned and agile practice (R5, R6) | discovery | Coordination is shown; decision rights and delivery method are not. | Separates "coordinated" from "owned", which is the gap the role's first line probes. | Choosing scope or sequence on a custom build; running work in sprints with a squad | A spec you wrote, a backlog, or a sprint artifact | `[grounded]` CV silence |
| G4 | Sales and support launches (R4b) | discovery | Not mentioned. | A named duty in the JD. | Go-live handoffs to support; enablement for a sales team; a launch checklist | A handoff doc or the integration playbook | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Search was refused, so this stays open and is not a finding. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I'd interview with? | unresolved |
| RR2 | Titled-years must-have against no PM title | risk_signal | medium | "3+ years product management experience (must-have)" | The requirement may be applied as written, filtering on titles before anyone reads the bridge. | `[generic]` hiring pattern; not a claim about this employer | Would you consider product-adjacent work, such as partner-facing API implementation and roadmap input, as meeting this requirement? | unresolved |
| RR3 | Mandate and responsibilities stated concretely | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Scope looks genuinely defined, and your integration background maps onto the platform's users. | `[grounded]` JD states it | Who owns roadmap prioritization today, and what has changed? | noted |
| RR4 | Roadmap ownership against decision rights | unknown | — | "Own the roadmap ... drive delivery with two engineering squads" | The title language may outrun real authority over priorities and squad capacity. | `[inferred]` from the JD's silence on decision rights | Which roadmap decisions does this role make alone, and which go to a VP or CEO? | unresolved |
| RR5 | Compensation withheld | unknown | — | "Product Manager, Platform APIs" (no figure) | Pay and level are unknown, and a first PM title may carry a different band than your current role. The band was not researched. | `[inferred]` from silence in the posting | What is the budgeted range and level for this role? | unresolved |

## Application plan

All of the proposed wording and actions below are pending your approval, advice included. Nothing is finalized until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reword your roadmap-input bullet in the role's terms, for example "Ran quarterly sessions collecting client roadmap input and fed it to product". It keeps "fed to product" and does not say you set priorities. Do not use a PM title or "owned roadmap". | R7, R6 | `[grounded]` your own account, with wording audited against inflation | pending your approval |
| E2 | Lead with the 30+ integrations and the playbook as evidence of platform and developer-experience fluency, with your own scope stated plainly. | R3, R4a | `[grounded]` your statement | pending your approval |
| W1 | A one-page work sample, such as an adoption-metrics proposal for a partner API's onboarding, labeled as a proposal and not as shipped work. | R8, R2 | `[inferred]` as a way to narrow the limit named in the map | pending your approval |
| A1 | Before investing in an application, ask a recruiter or a contact whether implementation-led product work is accepted in place of titled years (RR2). | R1 | `[grounded]` RR2 | pending your approval |
| A2 | Say the gap in one plain sentence in your cover note (no PM title yet, with the adjacent work named) and let the specifics carry the case. | R1 | `[grounded]` R1 row | pending your approval |
| A3 | Seek an introduction through a mutual contact before applying cold. | How hiring often works at companies of this size, not a fact about this employer | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a prior-conversation mention that you once built an internal request-triage tool that support agents adopted. Details are unconfirmed, so it only drives G1 and is not counted as evidence anywhere above.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Quartzline logistics technology Series B partner API platform careers" was refused. Would have moved RR1 (employer exists, posting live) and role reality's contradictions row. |
| 2. Role-family sweep | unavailable | Search "Product Manager platform API B2B salary range Series B 2026 solutions engineer to product manager transition" was refused. Would have moved the market calibration line and RR5. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I offer to save this as `tuesday-dossier.md` for later turns if you'd like it.

## Upgrade menu

- Permission to run web search, or a link to the live posting or the company's careers page → RR1 resolves, the market band fills role reality, and RR5 can be set against your floor. A deeper company pass (up to 5 more searches and 2 more fetches) is available once search works.
- Any artifact for the triage tool or the integration playbook (a write-up, usage numbers, a sanitized excerpt) → R2, R8 move from `none` or `low` toward `medium`, and R3 can reach `high`.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- Your pay floor, location, and title requirements → the hard-gates line stops reading "checks unknown".

## Questions

1. **G1 (R2, R8):** Did you build an internal request-triage tool for support agents, and if so, did it reach real users beyond a prototype, what did you personally own, and how did you know people were using it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G3 (R5, R6):** On any custom build, did you personally decide scope or sequencing, or run work with a squad in sprints? Name one example and what was actually yours.
3. **C1 (constraints):** What is your pay floor, your location or remote requirement, and would you take a PM title at a lower level than your current role?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.