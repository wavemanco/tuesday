I've read the skill's reference files and am now loading the web tools. I'll use them to check that the Pellucid posting is still live and matches what you pasted. Then I'll write the assessment.
## Decision snapshot

**Yes, this looks worth applying to. Your must-have rows R3, R4, R5, R6, R8 and R9 are all `direct`, and what stands between you and `go` is two unconfirmed gates, R1 and R2. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery as the warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R7 is a credible bridge with its limit named; R10 and R11 are rows where your background says nothing yet.

**Opportunity ledger.** The posting is transparent on pay and sits at or above the market band you were sent (RR1), and the company reports recent funding (RR5). Equity terms, team structure and on-call load, and whether pay varies by location are all unstated (RR2, RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm that R1 and R2 work for you.
  2. BigQuery (R7) is framed as adjacent to your Snowflake work, never as experience.
  3. RR3 (team shape, on-call) gets answered in an early conversation.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about page text you pasted (not independently fetched); the careers page I fetched is on the same domain |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | Ownership of a defined pipeline-to-contract domain; no direct reports and no team size or manager stated | `[inferred]` from the JD's mandate against its silence on reports |
| Market calibration | The Datawright 2026 report puts Senior Data Engineer at Series B–D companies at a $151,000 median and a $139,000–$163,500 interquartile range, with "Senior" typically 5–8 years and ownership of one domain with no reports. The posting's low end ($148,000) is just under that median and its top ($166,000) is above the 75th percentile. Your 6 years sits inside the 5–8 range | `[generic]` the report you sent (n=2,310, a pattern, not this employer's offer); `[grounded]` the posting's figures |
| Unknowns | Equity terms; team and manager; on-call; location-adjusted pay; hiring manager (not named) | `[grounded]` JD silence |
| Contradictions | None between your pasted JD and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you are based or whether you can work from the US. Nothing stated to grade | `[grounded]` JD; no candidate constraint given | Question R1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor from you. The posted range itself is plausible against the report you sent | `[grounded]` JD; no candidate constraint given | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Years-of-experience is graded as a requirement, not a gate. Medium because this is intake prose with no artifact inspected | `[grounded]` your background message | Optional: CV or LinkedIn raises it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily". Specific but unprobed | `[grounded]` your background message | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Specific and plausible; no repo or docs inspected | `[grounded]` your background message | A sanitized model lineage or project overview would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as worded is met. The BigQuery part is R7 | `[grounded]` your background message | none |
| R7 | BigQuery as this role's warehouse | important | adjacent | medium | transferability | Credible bridge: the same dbt-on-a-cloud-warehouse work. Limit: you have never used BigQuery. Interviewers at BigQuery shops may probe it; whether they treat it as a gap or a ramp-up depends on the team | `[inferred]` adjacency from your Snowflake and dbt work; `[generic]` that stack-specific probes are common | See G1 |
| R8 | Airflow or similar orchestration | must_have | direct | medium | none | You used Airflow for orchestration at the payroll company. Scope and ownership level unstated | `[grounded]` your background message | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is a specific owned claim. No artifact inspected | `[grounded]` your background message | A sanitized suite excerpt would raise it |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your message does not say what your ingestion sources were. Payroll pipelines likely ingested something, but not established | `[grounded]` background silence; `[inferred]` from the JD's mandate that this is a core duty | See G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your message does not mention contracts or schema agreements with analysts. Great Expectations and dbt tests may be adjacent | `[grounded]` background silence | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Snowflake plus dbt at scale; no BigQuery use | The posting names BigQuery as the warehouse, so this is the most likely probe | A side project running dbt on BigQuery; migrating or comparing warehouses at work; BigQuery used even briefly in another job | A small public dbt-on-BigQuery repo | `[inferred]` bridge from your stated work; `[generic]` that this is the likeliest stack question |
| G2 | App and CRM ingestion (R10, important) | discovery | No source systems named | The JD lists ingestion first among its duties | Loading data from a SaaS tool or product database; building or running a connector or CDC job; handling CRM-style exports | Pipeline diagram, DAG list, or README | `[grounded]` background silence on sources |
| G3 | Data contracts (R11, important) | discovery | Testing is shown; agreements with consumers are not | The JD names analyst-facing contracts as a duty | Agreeing schema or freshness expectations with analysts; versioned model contracts; breaking-change processes | A contract doc, dbt contract config, or SLA note | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent, and sits at or above the median in the report you sent | `[grounded]` JD; `[generic]` the Datawright band | Is the range the same for Denver and remote hires? | noted |
| RR2 | Equity unspecified | unknown | — | "plus equity" | Equity may be options or RSUs with an unstated amount, vesting or strike | `[generic]` pattern: postings often give no equity terms | What is the equity grant structure, size range and vesting schedule for this level? | unresolved |
| RR3 | Team structure and on-call unstated | unknown | — | "Build and run the pipelines" | "Run" may include on-call or incident duty, and the role may be the only data engineer or one of several | `[inferred]` from the JD's wording against its silence on team and rota | How big is the data team, who does this role report to, and is there an on-call rota? | unresolved |
| RR4 | Pay by location unstated | unknown | — | "Remote (US) or our Denver office" | Pay may be adjusted by location for remote hires | `[generic]` pattern: some employers adjust pay by location | Does the range vary by where the hire lives? | unresolved |
| RR5 | Recent funding and size | positive_signal | — | "Series C ($52M, February 2026)" | A funded company of this size is hiring into a mature stage | `[grounded]` the about page text you pasted, not independently checked | What is the data team's roadmap for the next year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with "Built our dbt project on Snowflake, about 180 models" | see R5 | `[grounded]` your own sentence | resume_edits_pending_approval |
| E2 | Put "Set up our Great Expectations test suite" as its own bullet | see R9 | `[grounded]` your own sentence | resume_edits_pending_approval |
| A1 | State in the cover note that your warehouse experience is Snowflake and that you have not used BigQuery | see R7: say it plainly before an interviewer asks | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small public dbt-on-BigQuery project | see G1 | `[inferred]` closure path for the transferability gap | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim with the recruiter or hiring manager | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), a quick check of your pasted JD. The posting is live ("Accepting applications") and its text matches; this moved role reality's contradictions row, and no failed-attribution entry is needed |
| 2. Role-family sweep | skipped | Your recruiter's Datawright report is in hand and already fixes the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Dossier offer

I can write all of this into a `tuesday-dossier.md` file if you want to keep it.

## Upgrade menu

- A CV or LinkedIn profile raises R3, R4, R8 from `medium` toward `high` and shows whether the CV buries anything.
- A sanitized dbt lineage or project overview raises R5; a Great Expectations suite excerpt raises R9.
- Your answer on ingestion sources closes G2 and R10; your answer on contracts closes G3 and R11.
- Your pay floor and location close R1 and R2, which decides `go` versus a hold.
- A hiring manager's name would let role reality's scope read and the plan's positioning use their published professional footprint.
- A deeper company pass (funding history, leadership changes, public employee reports; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

R1 — Are you based in the US (or able to work there), and is remote or Denver both fine for you?

R2 — What is your minimum base salary, and does equity matter to you?

R10 — Which source systems did your pipelines ingest from (product database, SaaS tools, CRM exports), and what part did you build yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.