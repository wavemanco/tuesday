I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, worth applying to, on conditions. Your background lands directly on R1, R2, R3, R4 and R5, and R6 (BigQuery) is the one adjacent row. R7 and R8 are unconfirmed, and I can't check the gates R9 and R10 without your constraints. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (dbt-modelled warehouse in BigQuery) · unclear: R7 (ingestion from app and CRM), R8 (data contracts)

R6 — a credible bridge from Snowflake, its limit named; R7 and R8 — unconfirmed, waiting on your answers; R9 and R10 — waiting on your constraints.

**Opportunity ledger.** Sound on what is on the page: the pay is stated and sits inside the market band (RR5), and the funding is recent (RR6). Still open are the employer check, which could not run from here (RR1), the unnamed team and reporting line (RR2), the breadth of scope (RR3), and the equity terms (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location, US work authorization and pay floor are checked against R9 and R10; (2) the posting is confirmed live on Pellucid's own careers page (RR1); (3) BigQuery is presented as adjacent to your Snowflake work, never as experience (R6); (4) your answers on R7 and R8 don't turn either into a real gap.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not compared with the live site (see Evidence status) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and the CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Stack wording | The requirements say "a cloud warehouse", while only the mandate names BigQuery. I read BigQuery as a responsibility, not a stated requirement, so R6 is tiered `important` | `[inferred]` from the JD's two phrasings |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Outcomes | No first-90-days or first-year outcomes stated | `[grounded]` JD silence |
| Scope read | Ingestion, modelling and contracts sit under one title, with no stated team size or direct reports (RR2, RR3) | `[inferred]` from the JD's three areas against its silence on team |
| Market calibration | The Datawright 2026 report (n=2,310, Senior Data Engineer, Series B–D) gives a base median of $151,000 and an IQR of $139,000–$163,500. "Senior" typically means 5–8 years, with ownership of one domain's pipelines and no direct reports. The posting's range starts $3,000 below that median and ends $2,500 above the IQR's top; its midpoint, $157,000, is $6,000 above the median. Your 6 years sits inside the 5–8 range, and Series C sits inside B–D. This is the band to expect, never Pellucid's offer | `[grounded]` the report figures you provided and the JD figures; `[generic]` as a role-family pattern; I could not check the report's currency |
| Hiring manager | None named | `[grounded]` your note on the posting |
| Unknowns | Team size, reporting line, equity terms, support or on-call expectations, how success is defined | `[inferred]` from JD silence |
| Contradictions | None visible between the JD and the about text as pasted; neither was compared with the live site | `[grounded]` pasted text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. That exceeds the stated minimum, but it is self-reported and I have not seen your CV. A years requirement is graded on fit, not treated as a gate | `[grounded]` your prose background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is a judgment with nothing inspectable behind it. Hiring loops for this role family often include a live SQL or Python exercise | `[grounded]` your prose; `[generic]` loop pattern | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models" meets both halves. The 180 counts models in the company's project. Your personal share of them is not stated, so the caveat travels with any use of the claim | `[grounded]` your prose | offer: dbt docs or a lineage view, sanitized, would raise to `high` |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. What you personally did (authoring DAGs, running the deployment, monitoring) is not stated, so I take `medium`, not more | `[grounded]` your prose | say which part was yours when you write the line (E3) |
| R5 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite" is a specific claim with stated ownership. There is no inspectable artifact yet | `[grounded]` your prose | offer: a sanitized expectations file would raise to `high` |
| R6 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Bridge: dbt modelling on a cloud warehouse (Snowflake). Limit: you have never used BigQuery, so its specifics, such as partitioning, clustering and its pricing model, are not exercised by your Snowflake work. Strengthener: a small dbt-on-BigQuery project (W1) | `[grounded]` your prose, including "never used BigQuery"; `[generic]` that BigQuery has those specifics | see G4 |
| R7 | Ingestion from the app and the CRM | important | unclear | none | discovery | You said nothing about ingestion sources, so no claim exists to grade | `[grounded]` your prose silence | G2 |
| R8 | Data contracts analysts depend on | important | unclear | none | discovery | The Great Expectations suite may be adjacent, but you haven't said whether any expectations were agreed with producers or consumers. I won't map it to "contracts" until you say | `[grounded]` your prose silence | G3 |
| R9 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | Your location and US work authorization were not given, and the remote option is US-only. The gate can be met or failed, and I can't tell which. Confidence is `none` because no constraint of yours was stated | `[grounded]` JD; your constraints not given | G1 |
| R10 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so the range can't be checked against it. The range itself sits inside the market band (RR5) | `[grounded]` JD; your floor not given | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Your constraints against location and pay (R9, R10; hard_gate) | hard_gate | The posting states location and pay. None of your constraints are on the table yet | A failed gate caps the decision at `no_go` whatever the fit elsewhere, and an unconfirmed one keeps the status at `conditional_go` | — | None needed; your own statement is the evidence | `[grounded]` JD terms; `[grounded]` constraints not given |
| G2 | Ingestion from an app and a CRM (R7; important) | discovery | Your background covers modelling, orchestration and testing. It doesn't mention where data came from | It is one of three areas the mandate names; an answer can move R7 off `unclear` | Loading data from a product database or event stream; pulling from a CRM, billing or HR system through an API or export; handling a source whose schema changed | A sanitized DAG or ingestion script, or an architecture diagram | `[grounded]` your prose silence; `[inferred]` that an answer moves R7 |
| G3 | Data contracts (R8; important) | discovery | A Great Expectations suite is confirmed. Whether any expectations were agreed with data producers or consumers is not | The JD names contracts as something analysts depend on, so an answer decides whether R8 is `adjacent` or still open | Agreeing schema, freshness or quality expectations with an upstream owner or analysts; expectations that alerted or blocked a load when a source changed; documented ownership of key tables | A sanitized expectations file, a data-quality README, or an alert example | `[grounded]` your prose; `[inferred]` from the JD's wording |
| G4 | BigQuery (R6; important) | transferability | dbt on Snowflake, no BigQuery use | The row stays `adjacent` until something narrows the limit | A small dbt project run on BigQuery; any BigQuery exposure inside your payroll work, if there was some | A repository link to a small sample project | `[grounded]` your prose; `[generic]` that a work sample narrows a tool-specific gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources. The check was refused, so it did not run | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Team and reporting line unknown | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the only data engineer, or one of several; the posting says nothing on either | `[inferred]` from the JD's silence on team and reporting | Who does this role report to, and who else is on the data team: data engineers, analysts, analytics engineers? | unresolved |
| RR3 | Scope breadth and run duties | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Three areas may be wider than the one-domain scope the report calls typical, and "build and run" may bring support or on-call duties. Low, not medium, because the posting is a short summary | `[inferred]` the JD's areas against the `[grounded]` report's typical scope | Which of ingestion, modelling and contracts would I own end to end, and what support or on-call duties come with running them? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Type, size, vesting and valuation basis are unknown, so total pay can't be compared with a base-pay report | `[grounded]` JD wording; `[inferred]` that it can't be valued | What is the equity grant for this level: type, size, vesting, and valuation basis? | unresolved |
| RR5 | Pay stated and inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is stated up front and overlaps the report's IQR, assuming the posting's "salary" means base pay | `[grounded]` JD against the report you provided; `[inferred]` that "salary" is base | Where in that range would an offer for my experience land? | noted |
| RR6 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | The company raised in February 2026, so the role may be funded. This is unchecked against the live site | `[grounded]` about-page text as pasted; `[inferred]` from the funding date | Is this a new position or a backfill, and what is the hiring plan behind it? | noted |

## Application plan

All of this is proposed and nothing is final until you approve it. That covers the resume lines, the positioning advice and the cover-note sentence, and no CV was provided, so I'm working from your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Built our dbt project on Snowflake — about 180 models." | R3; your own sentence | `[grounded]` your prose | resume_edits_pending_approval |
| E2 | Resume line: "Set up our Great Expectations test suite." | R5; your own sentence | `[grounded]` your prose | resume_edits_pending_approval |
| E3 | Skills line: "Airflow (orchestration); Python and SQL (daily use)." Add your own part in Airflow once you confirm it | R2, R4; your own words | `[grounded]` your prose | resume_edits_pending_approval |
| E4 | Cover-note sentence: "I haven't used BigQuery; my dbt warehouse work is on Snowflake." | R6; states the limit before the reader finds it | `[grounded]` your prose | pending your approval |
| P1 | Lead with the dbt project and the Great Expectations suite (R3, R5), since both are specific and confirmed. Don't write "data contracts", "ingestion" or "BigQuery" lines until G2, G3 and G4 are answered | The map's rows; unconfirmed rows can't carry claims | `[grounded]` R3, R5, R6, R7, R8 | pending your approval |
| W1 | A small dbt project on BigQuery, public repository, to narrow the R6 limit. It is your call whether the time is worth it | R6 | `[generic]` work samples narrow tool-specific gaps | pending your approval |
| A1 | Before investing in the loop, open the careers page you copied the posting from and confirm the role is still listed | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | In the loop, ask the verification questions of RR2, RR3, RR4 and RR5 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Each clause in E1–E4 comes from your own sentences, and none borrows the JD's wording for your history.

## Evidence status

Verified: none yet. Every claim on the map is your prose background, which counts as self-report. I assumed the stage is evaluating.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both calls were refused by the host's permissions, so nothing was read: a search for "Pellucid Learning online tutoring K-12 Denver Series C $52M", and a fetch of pellucidlearning.com/careers/senior-data-engineer, run to check your pasted text is current. It would have moved the contradictions row in role reality and RR1 (is the posting live and consistent with the pasted text) |
| 2. Role-family sweep | skipped | The Datawright 2026 figures you pasted already fix market calibration and the pay check in RR5 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can offer a quick dossier of all this: say the word and I'll save it as `tuesday-dossier.md`.

## Upgrade menu

- **Your CV** lets me replace E1–E3 with line-by-line edits and look for evidence it buries.
- **Inspectable artifacts** raise specific rows. A dbt docs or lineage view (sanitized) raises R3. A sanitized Airflow DAG raises R4. A sanitized Great Expectations suite raises R5 and informs R8. An ingestion script or diagram informs R7.
- **Answers to G1, G2 and G3** close R9 and R10 or turn them into a `no_go`, and settle R7 and R8.
- **A named hiring manager** would let me read their public professional footprint (target 3) and sharpen the scope read.
- **Search and fetch permission** would let me redo target 1, confirm the posting is live and close RR1.
- **A deeper pass on Pellucid Learning** (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) needs the same permission. Say the word and it runs.

**G1** — What are your non-negotiables for this move: where you can work from (US remote, Denver, or neither), whether you're authorized to work in the US, and the lowest base salary you'd accept?

**G2** — Have you built ingestion from a product database or application, or from a CRM or other SaaS tool, into your warehouse? Which parts were yours, and what happened when a source changed?

**G3** — Did you agree schema, freshness or quality expectations with the teams that produce or consume your data, and what did your Great Expectations suite do when an expectation failed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.