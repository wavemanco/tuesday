**Yes, apply, on conditions. Status: `conditional_go`.** Your gaps are R6 (forecast ownership), R7 (finance and revenue data) and R8 (billing data). These are experience gaps you can address openly, not hard gates. The two hard gates, R1 and R2, are unconfirmed because you haven't told me your location or pay floor.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, hybrid, two office days a week), R2 (Salary £61,500–£67,000 plus share options)
- `must_have` — direct: R3a, R4 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R3b (at a B2B software company), R7 (Working with finance on billing or revenue data)
- `important` — direct: R9 · absent: R8 (Owning billing data)

R6 — closest bridge is the monthly pipeline review, its limit named; R7 (`low`) — unclear until you give a finance example; R8 — billing data, which you say you haven't worked on.

**Opportunity ledger.** The pay is stated and sits near the market middle (RR2). Four things are unverified: whether the posting is live on Quillfield's own site (RR1), the option terms (RR3), and the support and authority behind a "Lead" title (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two office days a week), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the salary range fit your own terms (R1, R2). (2) The role is confirmed live on Quillfield's own careers page (RR1). (3) Interviews show who owns billing data and the forecast number, and what ramp support exists (RR4, R6, R7, R8). (4) You describe the forecast and billing gaps as they are, not as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` "About Quillfield" page (quillfield.co.uk/about) |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting text |
| Working pattern and pay | Bristol, hybrid, two office days a week. £61,500–£67,000 plus share options | `[grounded]` posting text |
| Requirements stated | 4+ years in revenue ops, sales ops or similar analytics at a B2B software company; HubSpot or Salesforce admin; strong SQL and spreadsheet modelling; experience owning a forecast; finance work on billing or revenue data | `[grounded]` posting text |
| Scope read | CRM, billing data, cross-team reporting and the forecast sit in one title with no team size, tooling or decision rights stated. That is a wide remit for one person, so the support behind it is the question | `[inferred]` from the posting's mandate list against its silence on team and authority |
| Market calibration | A UK B2B software revenue operations lead has a median base of £64,200, with an interquartile range of £57,800 to £70,400. The posted range straddles that median. The guide is UK-wide, not Bristol-specific, and is a pattern, not Quillfield's offer | `[generic]` Ledgerline 2026 UK pay guide (n=438), snippet only; `[grounded]` posting for the range |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously a sales operations manager for four years at a payments company. This is her public title and career pattern, with no inference about preferences | `[grounded]` profile snippet; the recruiter named her as hiring manager. I haven't confirmed that the reporting line runs to her |
| Unknowns | Team size and reporting line; who owns the forecast number; which billing system and who owns data quality; share option terms; first-year outcomes (the posting gives none) | `[grounded]` posting silence |
| Contradictions | None found between the posting and Quillfield's About page on city, product or sector. Posting liveness on Quillfield's own site is not established (RR1) | `[grounded]` About page against the posting |

## Evidence map

Your background is self-reported and no CV was shared, so `medium` is the ceiling for any claim below.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't stated where you live or any commute limit, so the gate is not established. Confidence is `none` because there is no statement of yours to grade | `[grounded]` posting; no constraint given | Question 1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given, so I can't say whether the range meets it | `[grounded]` posting; no constraint given | Question 1 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team. That is above four years on your stated titles, and it is a length requirement, not a gate. Dates and titles are uninspected | `[grounded]` your background message | Share a CV or profile so dates can be checked |
| R3b | ...at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether its product is software sold to businesses isn't stated | `[grounded]` your background message | Upgrade menu: one line on what it sells and who buys it |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, stated and specific. The certificate hasn't been inspected | `[grounded]` your background message | A Trailhead credential link would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show regular use, not depth. Spreadsheet modelling is not mentioned | `[grounded]` your background message; `[inferred]` that frequency isn't strength | Question 3 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You haven't owned the company forecast, as finance did. The adjacent work is the monthly pipeline review with your sales director and rebuilding pipeline dashboards. The limit is no ownership of the forecast number and no CFO-level accountability | `[grounded]` your statement; `[inferred]` the bridge | G1: bridge case and optional work sample (W1) |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | Renewal dashboards touch revenue data, but you haven't said whether finance used or helped define them. You've said you haven't worked on billing data | `[grounded]` your background message; `[inferred]` that renewal data is revenue data | Question 2 |
| R8 | Owning billing data | important | absent | none | capability | You've said you haven't worked on billing data, so there is no direct or adjacent evidence. It is an `important` tier row, not a gate | `[grounded]` your statement | Carry as a risk. Ask in interviews which billing system the role uses, who owns its data quality, and what ramp-up support exists |
| R9 | Build the pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is unconfirmed, which is R7's question | `[grounded]` your background message | None |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Adjacent: the monthly pipeline review and the dashboards you rebuilt. Limit: no ownership of the forecast number | Running the quarterly forecast with the CFO is one of the posting's main duties, so this is the most visible gap | Preparing the pipeline numbers finance used in its forecast; a coverage or conversion model; renewal projections you produced | A sanitized dashboard screenshot or a pipeline review deck | `[grounded]` your statement and the posting; `[generic]` that forecasts normally draw on pipeline and renewal data |
| G2 | Finance collaboration on revenue or billing data (R7, must_have) | discovery | Renewal dashboards imply revenue data, but no stated finance collaboration | A must-have that could move R7 from `unclear` to `direct` or confirm a gap | Reconciling pipeline or renewal figures with finance; agreeing definitions such as bookings, ARR or churn; supporting finance's forecast inputs | A metric definitions doc, a reconciliation sheet, or a review deck | `[grounded]` your message is silent on finance collaboration; `[inferred]` that this could move the status |
| G3 | SQL and spreadsheet modelling depth (R5, must_have) | discovery | Usage frequency is stated, with no description of models | The posting says "strong" and names modelling | A pipeline or renewal model in Excel; SQL that fed a dashboard or report others relied on | A sanitized query or a model screenshot | `[grounded]` your message |
| G4 | B2B software employer (R3b, must_have) | discovery | Your employer is described as a B2B payments company | Whether it counts as B2B software is a must-have detail | The company's product and who buys it | A company product page | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not seen on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield." | My search returned Quillfield's About page but no careers page or this role. The listing may simply not be indexed, or may sit only on the job board | `[inferred]` from what the search returned | Can you confirm the role is open on your own careers page, and who the interviewers would be? | unresolved |
| RR2 | Salary stated, near the market middle | positive_signal | — | "Salary £61,500–£67,000 plus share options." | Range is transparent and straddles the median of a UK-wide guide | `[grounded]` posting; `[generic]` UK-wide band, not a claim about Quillfield | Where in the range does an offer usually land for this level? | noted |
| RR3 | Share option terms not given | unknown | — | "plus share options" | Value depends on grant size, vesting and strike price, none of which the posting states | `[inferred]` from the posting's silence | What size grant, vesting schedule and strike price come with this role? | unresolved |
| RR4 | Wide remit, no team or authority stated | unknown | — | "own our CRM and billing data ... run the quarterly revenue forecast with the CFO" | The role may carry the forecast and billing data without stated headcount, tooling or decision rights | `[inferred]` from the mandate list against its silence; `[generic]` that titles with "Lead" may or may not manage people | Who reports to this role, who owns the forecast number between this role and the CFO, and who owns billing data today? | unresolved |

## Application plan

Everything in this plan, including the positioning wording in E1, is proposed and pending your approval. Nothing is final, and nothing should be sent, until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Positioning line for the top of your CV: "Ran revenue operations for a UK sales team for two years; rebuilt the pipeline and renewal dashboards; run the monthly pipeline review with the sales director; Salesforce admin certified." Every clause traces to your message | R9, R4, R3a. These are the direct rows | `[grounded]` your background message | pending your approval |
| E2 | Say plainly that finance owned the forecast and that you haven't worked on billing data, then describe the adjacent work. Do not describe the pipeline review as forecasting | R6, R8 | `[grounded]` your statements | pending your approval |
| W1 | Optional one-page example showing how pipeline and renewal data could feed a quarterly forecast, labeled as a worked example and not as experience | G1 | `[inferred]` from the R6 limit | pending your approval |
| Q1 | Ask the verification questions of RR1, RR3 and RR4 in the loop; ask RR2's question once an offer is near | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Ask the recruiter to confirm the role is live on Quillfield's own careers page, before investing in the loop | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported, and nothing else was supplied.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about). Confirms the company exists as described: city, product and size. It returned no careers page or this role, so RR1 stays open. I read the snippet only |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR2. The guide is UK-wide, not Bristol-specific, and I read the snippet only |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager row in role reality; I read the snippet only |

I can run a deeper pass on Quillfield (funding and leadership changes, hiring patterns, recent news) with up to 5 more searches and 2 more fetches. Say the word and it runs.

I can write this up as `tuesday-dossier.md` if you want to keep or extend it later.

**Upgrade menu**

- A CV or profile with dates → R3a to a checked reading.
- A Trailhead credential link → R4 to `high`.
- One line on what your employer sells and who buys it → R3b resolves.
- A sanitized dashboard, query or model → R5, R9 and G1 strengthen.
- Your location and pay floor → R1 and R2 resolve, and the hard-gates line becomes a firm answer.
- The recruiter's answers on RR1, RR3 and RR4 → the conditions close and the decision likely firms to `go`.

**Questions**

1. (R1, R2) Can you be in Bristol two days a week, and does £61,500–£67,000 meet your pay floor?
2. (G2, R7) Have you worked with finance on revenue or renewal numbers, for example agreeing metric definitions, reconciling figures, or supplying inputs to their forecast? What was yours to do, and what changed as a result?
3. (G3, R5) Have you built a pipeline, renewal or similar model in Excel or SQL that others relied on? Describe what it did and who used it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.