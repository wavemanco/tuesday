I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, apply, and you're a fit on the core of the role: R1, R2, R3, R4 and R5 are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R9a · adjacent: R9b (Partner with clinicians) · unclear: R7 (Define and maintain the metrics layer), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R6 (Healthcare data experience, HIPAA)

R6 (`medium`) — a credible bridge, its limit named; R7 and R8 — your background is silent on the specifics, so each needs a question.

**Opportunity ledger.** The scope is concrete: a named team size and named stakeholders (RR5). Three things are unestablished: the employer (RR1), the pay (RR2) and the work arrangement (RR3). Ownership of the data foundation is also open (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) pay and work arrangement are checked against your own floor and location needs (RR2, RR3, and your answer to C1 below); (3) the healthcare bridge is framed as adjacent, never as HIPAA experience (R6); (4) your answers to G1 and G2 don't surface a mismatch on R7 or R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own product analytics for the app: the metrics layer, A/B test design and analysis, self-serve Looker dashboards, and analysis turned into roadmap decisions | `[grounded]` JD |
| Team | Mentor two junior analysts | `[grounded]` JD |
| Stakeholders | Product managers and clinicians | `[grounded]` JD |
| Scope read | The title, the mentoring and the stakeholder list fit one analytics owner with a small team. How much of the metrics layer already exists is not stated | `[inferred]` from the JD's verbs (define, design, build, partner, mentor) against its silence on current state |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` JD silent |
| Market calibration | Not run: both searches were refused, so there is no pay or scope band to compare against | `[grounded]` search permission refused |
| Unknowns | Pay; location or remote policy; whether a metrics layer and experimentation tooling already exist; who owns data engineering | `[grounded]` absent from the JD as pasted |
| Contradictions | None found in the pasted JD, which I could not check against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. Specific, but self-reported with nothing inspectable yet | `[grounded]` your background, stated in prose | none |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on a Snowflake warehouse. "Expert" is a self-grade, so expect a live SQL exercise | `[grounded]` your background; `[generic]` that senior analyst loops commonly include a SQL screen | offer: a sanitized query or a model you wrote would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD doesn't define "scale"; the 2M-subscriber base is your context | `[grounded]` your background | offer: an anonymized experiment readout of the pricing test would raise it to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. That is the named tool, at build level | `[grounded]` your background | offer: dashboard screenshots with figures blurred would raise it to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | offer: a redacted memo would raise it to `high` |
| R6 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | Adjacent: you have handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: you have not worked with health data and haven't stated HIPAA-specific practice, so this is a bridge and not equivalence. HIPAA is also a US regime, with different rules from GDPR/CCPA | `[grounded]` your background; `[generic]` that regimes differ in scope | see G3 |
| R7 | Define and maintain the metrics layer | important | unclear | low | discovery | Your "40+ governed dashboards" and consent-state model are leads that you may have owned metric definitions. Nothing you've said states it | `[grounded]` your background is silent on metric definitions | see G1 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing | `[grounded]` your background silent | see G2 |
| R9a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | presentation | You present to the VP Product monthly and write the exec metrics memo. Presenting is not the same as owning roadmap calls, so the framing should say what you actually did | `[grounded]` your background | E3 below |
| R9b | Partner with clinicians to turn analysis into roadmap decisions | important | adjacent | low | transferability | Adjacent: you have partnered with non-technical stakeholders. Limit: you haven't mentioned working with clinicians | `[inferred]` from your stakeholder work against the JD's clinician requirement | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R7, important) | discovery | A Looker build and governed dashboards, but nothing says who defined the metrics or how they were maintained | It is the first responsibility the JD lists, and your answer decides whether R7 reads `direct` or stays `unclear` | Writing LookML or a semantic layer; owning definitions for retention or churn; running a metric-change or deprecation process; setting up the consent-state model's definitions | A metrics dictionary, a LookML excerpt, a definitions doc | `[grounded]` your background silent on definitions; `[inferred]` that this is the likeliest open question on the role |
| G2 | Mentoring junior analysts (R8, important) | discovery | No mention of mentoring or managing anyone | The JD names it as part of the job, and a blank here reads as no experience | Onboarding analysts; reviewing others' SQL or experiment designs; running office hours; coaching an analyst through a first test | Any written review, onboarding doc or feedback note | `[grounded]` your background silent |
| G3 | Healthcare and clinician context (R6, R9b) | transferability | Consumer-PII governance and consent modeling; no health data and no clinician partnership mentioned | R6 is only preferred, but R9b is an important responsibility that involves clinicians | Working with any domain expert whose judgment shaped a metric; privacy or compliance reviews of your data models; consent flows with legal sign-off | A consent-model doc or compliance review summary | `[grounded]` your background; `[generic]` that domain-expert partnership is the usual bridge into regulated fields |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. I could not check, because my searches were refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | no figure appears in the JD as pasted | The posting may withhold pay, or the pasted text may have dropped it | `[grounded]` JD as pasted contains no figure | What is the budgeted salary range for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | no location in the JD as pasted | The role may be remote, hybrid or on-site; I can't tell from the text | `[grounded]` JD as pasted | Where is this role based, and what is the in-office expectation? | unresolved |
| RR4 | Current state of the data foundation not stated | unknown | — | "define and maintain the metrics layer" | The role may inherit an existing layer or build one from nothing, and the JD doesn't say which | `[inferred]` from "define and maintain" against the JD's silence on current state | Does a metrics layer exist today, who owns the data engineering behind it, and what experimentation tooling is in place? | unresolved |
| RR5 | Concrete scope: named team size and named stakeholders | positive_signal | — | "mentor two junior analysts"; "partner with product managers and clinicians" | The scope is specific enough to be tested in interviews | `[grounded]` JD | Who are the two analysts today, and how long have they been on the team? | noted |

## Application plan

All of the following are proposed only. The `resume_edits_pending_approval` block and the prose rows below each need your approval before I treat them as final.

`resume_edits_pending_approval`

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the summary with: "Product analytics, 6 years at a consumer-subscription company. Built the Looker instance from scratch (40+ governed dashboards) and designed and ran the experimentation program (30+ A/B tests a year)." | R1, R3, R4 | `[grounded]` each clause traces to your own sentences | pending your approval |
| E2 | Keep the pricing test as its own bullet: "Designed the pricing test behind an 11% retention lift." The lift stays attached to the test, and I've said nothing about who made the pricing decision | R3 | `[grounded]` your words | pending your approval |
| E3 | Reword the stakeholder bullet to what you stated: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." Don't add roadmap-ownership language unless you confirm it | R5, R9a | `[grounded]` your words | pending your approval |
| E4 | Surface the consent-state model with its scope: "Built the consent-state model for the warehouse; handled GDPR/CCPA consumer PII." Don't write HIPAA anywhere | R6 | `[grounded]` your words | pending your approval |

Positioning advice, proposed:

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | In any cover note, say plainly: "I haven't worked in healthcare. I have handled consumer PII under GDPR and CCPA and built our warehouse's consent-state model." Then move on | R6 stays adjacent; stating the limit lets you lead with R1–R5 | `[grounded]` your words | pending your approval |
| A1 | Before investing in an application, find the role on Harborlight's own careers site | RR1 | `[grounded]` register | pending your approval |
| A2 | Ask RR2, RR3 and RR4 verbatim with the recruiter or hiring manager | RR2, RR3, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported at intake, so every claim above is a lead and not yet confirmed evidence.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for Harborlight Health's careers page was refused (permission not granted). It would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | A search for pay and scope norms for this title was refused. It would have moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I have not retried the searches, and everything company-specific above rests on the JD as you pasted it.

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Permission for web search → RR1 resolves or stays open on real evidence, and RR2 gets a market band to compare against.
- A redacted experiment readout, dashboard screenshots, a sanitized SQL sample or the metrics memo → R2, R3, R4 and R5 move toward `high`.
- A metrics dictionary or LookML excerpt → R7 resolves.
- Any written mentoring artifact → R8 gets a basis.
- The hiring manager's name → role reality's scope read and which story the plan leads with.

## Questions

G1 — Did you personally define or maintain the metric definitions behind your Looker dashboards (for example retention or churn)? What did you own, and how were changes handled?

G2 — Have you mentored, onboarded or reviewed the work of other analysts? What did you do, and for whom?

C1 — What are your non-negotiables for a move: a pay floor, location or remote needs, work authorization, or anything else? I can't check the hard gates until I know them.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.