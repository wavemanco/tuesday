I'll read the skill's reference files before building the assessment.
**Decision snapshot**

**No, you're not wasting your time, but there is one real stretch: R1a, the 3+ years of titled PM experience, is absent, and no rewording creates titled years. Apply with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1b (PM-type work without the title), R2 (Shipped API or platform products) · unclear: R4b (Sales and support coordination, launches), R5 (Experience with agile delivery) · absent: R1a (3+ years PM experience, titled)
- `important`: adjacent: R6 (Discovery with integration partners), R7 (Own the roadmap, specs, two squads) · unclear: R8 (Define and track adoption metrics)

R1a: the titled years are not there; R1b, R2: credible bridges, limits named; R4b, R5, R8: unconfirmed, and askable.

**Opportunity ledger.** The scope is concrete (RR3). The employer is not established from here (RR1), pay and location are unstated (RR2), and decision rights and year-one outcomes are unstated (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Quartzline's own careers page and the employer checks out (RR1); (2) you accept R1a as a known gap and find out early whether the team treats it as a screen or a preference (A1); (3) the open must-haves R4b and R5 get a truthful answer (G3, G4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own the roadmap for a partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years PM experience (marked must-have); shipped API or platform products; technical fluency (API docs, schemas); stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| Hard gates | None stated. Location, pay, schedule and authorization terms are absent from the posting as provided. The 3+ years line is an experience requirement, so it is graded as a must-have and not as a gate | `[grounded]` JD silence |
| First 90 days and first year | Not stated | `[grounded]` JD silence |
| Scope read | The JD puts the most weight on API and schema fluency, which is where your evidence is strongest. It puts the most on owning roadmap and delivery, where your evidence is thinnest | `[inferred]` from the JD's requirement list set against your resume |
| Market calibration | Not calibrated. The role-family sweep did not run, so no pay or title band is stated and none should be assumed | `[grounded]` research status below |
| Unknowns | Salary, level, location or remote policy; who the role reports to; decision rights over the roadmap; year-one outcomes | `[grounded]` JD silence |
| Contradictions | None visible inside the posting. The posting could not be checked against Quartzline's own careers page | `[grounded]` JD; check not run |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as titled | must_have | absent | none | transferability | You state you have never held a PM title, so the titled-years line cannot be met as written. The adjacent work is graded on R1b, not here. Hiring teams often read a years-of-PM line literally. | `[grounded]` your own statement; `[generic]` literal-screen pattern | Don't claim PM years anywhere. See R1b and A1 |
| R1b | PM-type work done without the PM title | must_have | adjacent | medium | transferability | CV-level claims are specific: scoping workshops, requirements documents, quarterly roadmap-input sessions collecting client feedback for product. The limit is that none shows you deciding what got built or prioritised. | `[grounded]` your resume summary, unconfirmed beyond it | G1 question |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your company's REST APIs end to end and wrote the integration playbook. That is delivering integrations onto an API, not shipping the API product. A shipped release of your own is not evidenced. | `[grounded]` resume summary; limit `[inferred]` from the verbs used | G1 question; a sanitized artifact would help |
| R3 | Strong technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture are stated and specific. They are CV-level only, so expect a hands-on probe. | `[grounded]` resume summary | Offer: a sanitized integration architecture diagram or playbook excerpt would raise to high |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and product managers across 30+ client engagements. The limit is that you stood on the vendor's implementation side. | `[grounded]` resume summary | none |
| R4b | Stakeholder management with sales, and launches with sales and support | must_have | unclear | low | discovery | The resume is silent on sales and support. Client go-lives are not product launches. | `[grounded]` resume silence | G4, carried with no question this turn |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | UAT and go-live are delivery steps, but no sprint, backlog or squad cadence is stated. | `[grounded]` resume silence | G3 question |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions are close in form. The limit is that you scoped client implementations and relayed feedback, with no evidence the discovery drove a product bet. | `[grounded]` resume summary; limit `[inferred]` | G1 question |
| R7 | Own the roadmap, write specs, drive delivery with two squads | important | adjacent | low | transferability | Requirements documents for custom builds and input to product are adjacent. Roadmap ownership, prioritisation and squad delivery are not evidenced, so this takes the lower band. | `[grounded]` resume summary | G1 question; W1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent. A memory lead from an earlier conversation (an internal request-triage tool that support agents adopted) is unconfirmed, so it is only the basis for a question. | `[grounded]` resume silence; `[inferred]` lead, unconfirmed | G2 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM-type decisions without the title (R1b, must_have) | transferability | Bridge: roadmap-input sessions, requirements documents and scoping workshops carry over. Limit: none of it shows you deciding scope or priority. Strengthener: one concrete decision you owned, or a sanitized work sample. | R1a cannot be closed, so R1b is what a reader will weigh against it | Deciding what a custom build would and would not include; re-scoping or declining a client request; turning repeated client asks into a requirement product accepted; any acting product-owner stretch | A sanitized requirements document, a playbook excerpt, a roadmap-input summary product used | `[grounded]` resume summary; `[generic]` that R1b is the row a reader weighs against a titled-years gap |
| G2 | Adoption metrics (R8, important) | discovery | The resume is silent on measuring adoption; one unconfirmed lead exists | A confirmed shipped, adopted tool would support R8, and could strengthen R1b and R2 | An internal tool or process others adopted; usage or ticket counts you tracked; a SQL query behind a dashboard; before and after numbers | A dashboard screenshot, a short write-up, a README | `[grounded]` resume silence; `[inferred]` that a confirmed answer would lift R8 |
| G3 | Agile delivery (R5, must_have) | discovery | No cadence or method is stated | It is a stated must-have with no evidence either way | Sprint planning or standups with the engineering team on a custom build; a backlog you fed; UAT cycles inside a client's agile team | A sanitized board screenshot or a role description | `[grounded]` resume silence |
| G4 | Sales and support coordination, launches (R4b, must_have) | discovery | Nothing on launch work with sales or support | It is a must-have and a named responsibility | Handoffs to support at go-live; enablement sessions; runbooks; input to sales on what integrations could do | A handoff document or an enablement deck | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; none is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, level, location and working pattern unstated | unknown | — | "Product Manager, Platform APIs — Quartzline" | The posting may be an excerpt, or the employer may withhold these; there is no band to set against your needs | `[grounded]` JD silence | What are the salary range, level, and location or remote policy for this role? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | Squads and a metric type are named, which suggests a defined mandate | `[grounded]` JD states both | Which adoption numbers are the squads measured on today? | noted |
| RR4 | Decision rights and success measures unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may own the roadmap while sales or partner requests drive priority, and no year-one outcome is given | `[inferred]` from "own the roadmap" set against the JD's silence on authority and targets | What would this PM have shipped, and which adoption metric moved, a year in, and who decides when a sales or partner request conflicts with the roadmap? | unresolved |

## Application plan

Every row below is proposed and pending your approval, as are the resume edits and the positioning advice. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reorder the experience section so three bullets lead, in your own words and verbs: "Led 30+ client integrations of our REST APIs end to end"; "Wrote the integration playbook the whole team uses"; "Ran quarterly roadmap-input sessions collecting client feedback for product". Add no outcome or ownership claim. | See R2, R6, R3. This surfaces what you have, which is the strongest evidence for this role | `[grounded]` your resume summary | `resume_edits_pending_approval` |
| E2 | Cover-note opening: "For seven years I've worked on the integration side of my company's REST APIs, leading 30+ client integrations end to end. I haven't held a PM title; alongside that work I ran quarterly roadmap-input sessions collecting client feedback for product and wrote the integration playbook the whole team uses." | See R1a, R1b. It says the no-title fact plainly and leaves the reader to weigh the bridge. | `[grounded]` each clause traces to your resume summary | `resume_edits_pending_approval` |
| A1 | Before investing effort, find someone on the product or platform side and ask whether the 3+ years line is a hard screen for candidates with an integration-lead background. | See R1a. A years line can be a hard screen or a preference, and only the team knows which. | `[generic]` how hiring often works, not a fact about this employer | pending your approval |
| A2 | Confirm the posting is live on Quartzline's own careers page and find who the hiring contact is. | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR2, RR3 and RR4 questions verbatim in the process. | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | A one-page sanitized product-style sample: a spec and adoption-metric proposal for one integration pain point from your playbook, with no client-confidential detail. | See R7, R8. It narrows a limit; it is a work sample and never presented as shipped work. | `[inferred]` from the R7 and R8 limits | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation note that you may have built an internal request-triage tool that support agents adopted (`memory_lead`; it prompts G2 and is not evidence). Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search on Quartzline's site and platform was refused. It would have confirmed the entity and the live posting, feeding role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | The search on PM platform-API pay and requirements was refused. It would have supplied the market calibration and the pay check in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

If you'd like, I can write this up as `tuesday-dossier.md` to carry between sessions.

**Upgrade menu**

- A full resume, or an earlier version → may show PM-type work the summary omits; it moves R1b, R7 and R8.
- A sanitized playbook excerpt or integration architecture diagram → R3 to `high`; strengthens R2 and R7.
- Your answer on the triage tool (G2) → R8, and possibly R1b and R2.
- Search permission → the official-site check and the market band, which close RR1 and inform RR2.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- Your pay floor, location and schedule limits → hard-gate rows would exist, and the check against the posting would run.

**Questions**

G1 — Is there a build or client where you decided what went in or out of scope, or turned repeated client requests into something product accepted? What was yours, who else was involved, and what happened?

G2 — An earlier conversation suggested you built an internal request-triage tool that support agents adopted. Is that right, and if so what did you own, how many people used it, and how did you know it worked?

G3 — On the custom builds, did you work in sprints or a backlog alongside the engineers, and what was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.