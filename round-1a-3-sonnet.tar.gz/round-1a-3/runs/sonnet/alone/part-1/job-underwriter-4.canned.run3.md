I'll read the skill's reference files before building the assessment.
# Job Underwriting Assessment — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, apply, provided R1 (the working pattern) is settled first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · adjacent: R10 (Pet-insurance domain knowledge) · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9

R1 — the JD's remote term is contradicted by the employer's own careers page; R10 — a credible bridge, its limit named; R6 (`medium`) — "built and maintained" is confirmed, monitoring itself is not yet.

**Opportunity ledger.** The role is clearly scoped and the Director's published work matches it (RR5). Four things are open: the working pattern conflicts between sources (RR1), pay is withheld (RR2), direct reports are unstated (RR3), and the employer's stage and size are not independently corroborated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed and acceptable to you (R1, RR1); (2) the budgeted salary clears your floor (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The role is live on brindlemoor.co.uk. Stage and size are not independently established | `[grounded]` JD and fetched careers page |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing. The hiring manager is Odile Varga | `[grounded]` JD and careers page |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" (see R1, RR1) | `[grounded]` JD against fetched careers page |
| Scope read | An individual owner of one product's pricing analytics. The JD lists no direct reports or line-management duties, so your lack of management experience is not tested by anything stated | `[inferred]` from the JD's "own pricing analytics" wording and its silence on team |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Hiring manager's public footprint | Director of Pricing. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result, snippet only |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. The posting withholds pay, so this is what to expect and not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 pay survey, n=612, snippet only |
| Unknowns | Salary, direct reports, which working pattern is current, first-year outcomes, company stage and size | `[grounded]` JD and careers page silent |
| Contradictions | Working pattern: JD against careers page | `[grounded]` both sources quoted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a working-pattern constraint, so there is nothing to grade. Fit is unclear because the JD and the careers page disagree on the term | `[grounded]` JD and fetched careers page; no candidate statement | Q1; employer check RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific and confirmed, but nothing inspected. A length-of-experience requirement is not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is specific on frequency. It says nothing yet about what you built, so "strong" is untested | `[grounded]` your background | Offer: a sanitised query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book, on motor, not pet (see R10) | `[grounded]` your background | Offer: a sanitised model spec would raise to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which is the audience the JD names. An actuarial audience isn't stated | `[grounded]` your background | Offer: a redacted review deck would raise to `high` |
| R6 | Build and monitor rating models | must_have | direct | medium | discovery | "Built and maintained" is stated and "monitored" is not, so I take the lower reading. Monitoring is likely to matter to this hiring manager | `[grounded]` your wording; `[inferred]` monitoring matters, derived from the Director's talk topic | G2 / Q2 |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Which parts you designed and which you read isn't split out, so expect a probe | `[grounded]` your background | none |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | The tests were run with underwriting, and the quarterly review goes to the head of underwriting | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | none | discovery | Nothing in your message touches product-team work. That is silence, not absence | `[grounded]` your message silent | G4 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (inferred from "our pet-insurance product") | important | adjacent | medium | transferability | The rating-model craft carries over. The limit is your own statement that you've never worked on pet insurance. Pet-specific rating factors and claims patterns usually differ from motor | `[grounded]` your statement; `[generic]` that factors differ by line | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working-pattern term (R1, hard_gate) | hard_gate | The JD and the careers page disagree, and you haven't said whether either pattern works for you | A gate. If office attendance is a deal-breaker for you, everything else is moot | Not applicable: a term, not experience | The link or message where you found the JD, plus the employer's own answer (RR1) | `[grounded]` both sources quoted |
| G2 | Monitoring rating models (R6, must_have) | discovery | The GLM build and maintenance are stated. Post-launch monitoring isn't described | A must-have, and the hiring manager's published talk is about monitoring | Tracking actual against expected on the young-driver model; checking for drift in factors; deciding when to refit; a regular report others read | A redacted monitoring pack, a dashboard screenshot, a refit note | `[grounded]` gap in your description; `[inferred]` weight, from the talk topic |
| G3 | Pet-insurance domain (R10, important) | transferability | Adjacent: you built and maintained a GLM on a motor book. Limit: no pet exposure, so pet rating factors and claims behaviour haven't been exercised. Strengthener: a short note mapping your model's structure to a pet book | The likeliest objection to your application | Any non-motor exposure; claims-inflation or severity trend work; reading public pet-pricing material you can discuss | A one-page bridge note, proposed and pending your approval | `[grounded]` your statement; `[generic]` that factors differ by line |
| G4 | Recommendations to product (R8b, important) | discovery | Nothing stated | The JD names product as one of two audiences for your recommendations | A pricing change you took to a product or proposition team; a test readout that changed a feature or add-on | A readout, email or deck | `[grounded]` silence; `[inferred]` weight, from the JD naming product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern conflicts between sources (see R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | One source may be out of date, or the terms may differ by version of the posting. Which is current isn't established | `[grounded]` both quoted; which is current is unknown | Is this role fully remote, or Leeds-based four days a week? | unresolved |
| RR2 | Pay withheld | unknown | — | The JD states no salary | The figure may sit anywhere in the expected band, or the employer may not publish pay. Your floor isn't given, so there is no comparison yet | `[generic]` Pricewell band for the title; `[grounded]` JD silent | What base salary range is budgeted for this post? | unresolved |
| RR3 | Direct reports unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Senior" may or may not carry line management here. The JD lists none, which bears on your never having managed | `[inferred]` from the JD's scope wording and its silence on team | Does this role have direct reports now, or is one planned? | unresolved |
| RR4 | Stage and size not independently corroborated | unknown | — | "Brindlemoor (insurtech)" | One search for the company returned nothing. The role is live on the employer's own site, so the posting is attributable. Small employers often have thin footprints | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` careers page fetched | What is the company's size and stage, and who is on the pricing team? | unresolved |
| RR5 | Director's published work matches the role | positive_signal | — | Talk: "Small Books, Loud Errors" on monitoring rating models; JD: "build and monitor rating models" | The mandate reflects what the Director talks about publicly, so the scope is probably real | `[grounded]` search result, snippet only | How do you monitor the pet rating model today, and what would I own in the first 90 days? | noted |

## Application plan

I'm proposing all of this language, and none of it is final until you approve it. The approval covers the edits table and the positioning and framing lines below. Each clause traces to your own sentences, and I've deliberately not written "monitored" anywhere until G2 is answered.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the experience section with "Built and maintained the GLM rating model for the young-driver book" | R4, R6 | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | Add "Ran 14 price tests last year with the underwriting team" as its own line | R7, R8a | `[grounded]` your background | `resume_edits_pending_approval` |
| E3 | Add "Present the quarterly pricing review to the head of underwriting" | R5, R8a | `[grounded]` your background | `resume_edits_pending_approval` |
| A1 | Before investing effort, confirm the working pattern through a contact on brindlemoor.co.uk, not the source you found the JD on | RR1, R1 | `[grounded]` RR1 | pending your approval |
| P1 | Be ready to say exactly what you did to keep the GLM performing after launch, and only that. Hold the monitoring wording until you've answered G2 | The Director's talk centres on monitoring | `[grounded]` talk topic; `[inferred]` it makes monitoring a likely probe | pending your approval |
| P2 | If asked about management: "I haven't line-managed anyone. I worked with the underwriting team on price tests and present the quarterly review to the head of underwriting" | RR3; the JD lists no management duties | `[grounded]` your background | pending your approval |
| P3 | If asked about pet: "I haven't worked on pet insurance. I built and maintained a GLM rating model on a motor book" | R10, stating the limit up front | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Your background is prose self-report, so it sits at `medium` until you share an inspectable artifact or confirm specifics. Memory leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned nothing, and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved role reality's organization, working-pattern and contradictions rows, R1, RR1 and RR4 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. Moved market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Moved role reality's footprint row, R6, RR5 and P1 |

I can write this up as a saved `tuesday-dossier.md` for reuse, if you'd like.

## Upgrade menu

- **A redacted model spec, monitoring pack or test readout.** These can raise R3, R4, R5 and R6 from `medium` toward `high`, and would close G2.
- **Your working-pattern requirement and salary floor.** These turn R1 into a met or failed gate, and set RR2 against your floor.
- **Where you found the JD, as a link or message.** It can show which working pattern is current and close RR1.
- **Any product-team work you've done.** It closes G4 and moves R8b.
- **The employer's answers to RR1 to RR4,** asked through contacts on brindlemoor.co.uk.
- **Deeper research on Brindlemoor** (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1 — Is fully remote a firm requirement for you, or is some office attendance workable, and if so how many days a week?

G2 — On the young-driver GLM model, what did you personally do to monitor how it performed after launch (for example actual-versus-expected tracking, drift checks, or deciding when to refit), and is there anything you could share in redacted form?

RR2 — Do you have a minimum base salary you'd need for a move, so I can set it against the band?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.