I'm reading the skill's remaining reference files (risk register and evidence-map rules) before writing your assessment.
# Job Underwriting Assessment — Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, apply, but confirm the working pattern first: R1 (Fully remote (UK)) is unsettled, because the JD and Brindlemoor's own careers page disagree. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (monitor rating models)
- `important` — direct: R8a · unclear: R8b (recommendations for product)
- `preferred` — direct: R9

R6b — monitoring not yet stated; R8b — product-side work not yet stated; R2–R7 (`medium`) — your own account, nothing inspected yet.

**Opportunity ledger.** The posting is live on the employer's own site and names a hiring manager, but its terms disagree on where the work happens (RR1) and pay is withheld (RR2). Ownership and resources are unspecified (RR3). A named Director of Pricing as the reporting line is a positive (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed against what you can accept — R1, RR1; (2) pay is acceptable once the band is known — RR2; (3) you can supply one product-side and one monitoring example, or accept those rows stay open — R6b, R8b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the posting is live and accepting applications | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for pet insurance: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both quoted |
| People management | The JD lists no line-management requirement and names no direct reports | `[grounded]` JD silent |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | Three strands (models, tests, recommendations) under one "own" mandate, with no team, budget or decision rights named | `[inferred]` from the JD's wording against its silence |
| Market calibration | A pay survey snippet gives senior pricing analyst, UK insurers and insurtechs (n=612): median £58,400, interquartile range £52,100 to £64,900. This is a market band, never Brindlemoor's offer, and the JD withholds pay (RR2) | `[generic]` survey snippet only, page not fetched; `[grounded]` JD for the withheld pay |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint: a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books; previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result, professional footprint only |
| Unknowns | Where the work happens; salary; decision rights; size of the pricing team | — |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says remote and the careers page says Leeds four days a week, so the role's terms are unsettled. You have stated no constraint, so there is no candidate claim to grade | `[grounded]` JD and careers page; you stated no constraint | Confirm the pattern with the employer (RR1); tell me whether remote is a must |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer, 2 as senior analyst. Specific, but self-reported with nothing inspected. Years of experience are not a gate | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Specific, but no artifact inspected | `[grounded]` your stated background | A sanitized query or notebook sample would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, no artifact | `[grounded]` your stated background | A sanitized model spec or methodology note would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. This is underwriting, not actuarial leads, which matches the JD's "or" | `[grounded]` your stated background | none |
| R6a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM. The limit is that it is one segment of one motor book | `[grounded]` your stated background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You say "maintained", which may include monitoring (tracking, drift, refit triggers). Your account doesn't say what you did | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | Gap queue G2 |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Specific and recent, but the design-versus-read split and your ownership are not stated | `[grounded]` your stated background | Offer: a sanitized test design or readout would raise to high |
| R8a | Recommendations for underwriting | important | direct | medium | none | You worked with underwriting on the tests and present the quarterly review to their head | `[grounded]` your stated background | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing you've described touches product or proposition decisions | `[grounded]` silence in your account | Gap queue G1 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years in motor insurance. Pet-insurance experience is not listed in the JD and you have none, so the limit is named: no pet-specific work | `[grounded]` JD and your stated background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R8b, important) | discovery | Underwriting-facing work is clear; nothing yet shows a test result shaping a product or proposition decision | The JD names product as a second audience for your recommendations | A test result that changed a product feature, add-on, cover level or renewal rule; a pricing input to a product launch or review | A sanitized readout, a deck, a review paper | `[grounded]` your account; `[inferred]` that this is the open half of the JD's recommendations duty |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" is stated; monitoring practice is not | A must-have responsibility, and the area of the hiring manager's published talk | Actual-versus-expected tracking, drift or segment checks, refit triggers, an alert or dashboard you built or ran | A monitoring pack, dashboard screenshot, model-governance note | `[grounded]` your wording; `[inferred]` from the JD's "build and monitor" |
| G3 | Fully remote (UK) (R1, hard_gate) | hard_gate | JD and careers page disagree on working pattern | A term you either can accept or can't; wording can't fix it | A statement of whether remote is required and where you are based | The employer's written answer on the working pattern | `[grounded]` both sources |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between JD and careers page (see R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be out of date, or the role's terms may have changed. I can't tell which | `[inferred]` from two sources that disagree | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pay not stated | unknown | — | The JD gives no figure | The offer may sit inside or outside the market band in role reality, or the employer may simply not publish pay | `[inferred]` from the withheld figure, against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Ownership asserted, resources and decision rights unspecified | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may carry accountability without a named team, budget or sign-off authority | `[inferred]` from the JD's "own" against its silence | Which pricing decisions does this role make, and who signs off rate changes? | unresolved |
| RR4 | Named, senior reporting line | positive_signal | — | "reports to the Director of Pricing" | The role sits directly under the pricing head, who has spoken publicly on rating-model monitoring | `[grounded]` careers page; `[grounded]` search result on the talk | What would success look like in this role after 12 months? | noted |

## Application plan

Every row is proposed, and so is all the advice in this plan. Nothing is finalized without your explicit approval, and no CV or letter wording is drafted until you approve a direction.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with Brindlemoor before investing in the application, using contact details from its own careers page | see R1, RR1 | `[grounded]` the two sources | pending your approval |
| E1 | CV: put the young-driver GLM build and the 14 price tests with underwriting at the top, reordered only, with no new facts | see R4, R6a, R7 | `[grounded]` your stated background | pending your approval |
| E2 | CV: make the quarterly pricing review to the head of underwriting visible as its own line | see R5 | `[grounded]` your stated background | pending your approval |
| A2 | If G2 confirms a monitoring example, lead with it. The hiring manager's published talk is on monitoring rating models in small books, so it is a verified story on the same subject | see R6b | `[grounded]` the talk title; `[inferred]` the match to your example, which isn't confirmed yet | pending your approval |
| A3 | State plainly that your pricing work is motor, not pet, and that pet isn't a stated requirement | see R9 | `[grounded]` JD and your background | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is stated in the conversation, which makes it leads, not proof. Rejected inferences: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live and surfaced the working-pattern contradiction (R1, RR1). The page text was short and said nothing on company stage, size or pay |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration `[generic]`, from the snippet only. It said nothing on pet insurance or remote pay |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It supplied the talk and prior role in role reality and A2 |

## Dossier offer

I can write all this up as `tuesday-dossier.md` to carry forward, if you want it.

## Upgrade menu

- Your answer on remote versus Leeds, plus any pay floor → R1 settles (the status may become `go` or `no_go`) and RR2 can be set against your floor.
- A sanitized query or notebook sample → R3 to `high`.
- A sanitized GLM spec or methodology note → R4, R6a to `high`.
- A sanitized price-test design or readout → R7 to `high`.
- An example for G1 or G2 → R8b or R6b moves from `unclear`.
- The employer's answer on pay → RR2 closes against the band.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. **R1** — Is working remotely a must for you, or would four days a week in Leeds be workable?
2. **G2** — In your GLM role, did you personally monitor the model once it was live (actual versus expected, drift, refit triggers)? What did you do, and what happened?
3. **G1** — Have you taken a price-test result into a product or proposition decision, not just an underwriting one? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.