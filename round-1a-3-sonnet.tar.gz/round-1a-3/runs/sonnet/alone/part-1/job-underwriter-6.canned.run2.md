I've fetched the posting and I'm reading the underwriting rules for the decision format. Next I'll build the assessment.
# Job Underwriting — Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, apply, but as a stretch rather than a match. The forecast (R6) and billing data (R8) are real gaps on must-haves. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Pay £61,500–£67,000 plus share options)
- `must_have` — direct: R3, R4, R5 · adjacent: R6 (Experience owning a forecast) · unclear: R7 (Working with finance on billing or revenue data) · absent: R8 (Own billing data)
- `important` — direct: R9

R6 — a credible bridge through the pipeline review, its limit named; R7 — open until your renewal work is probed; R8 — a gap you stated yourself, with no bridge.

**Opportunity ledger.** Sound so far: the employer is attributable and the pay is disclosed within market (RR1, RR2, RR3). Four things are open: the share options (RR4), whether the role owns the forecast or supports finance (RR5), what "Lead" means for reporting (RR6), and whether the posting is live on Quillfield's own site (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Pay £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the recruiter or Tamsin Achebe confirms what the Lead owns in the forecast and how that is expected to be learned — R6, RR5; (2) you confirm location and pay are workable — R1, R2; (3) the forecast and billing gaps are framed honestly as adjacent and absent, never as ownership — R6, R8; (4) the posting is confirmed live on Quillfield's own site — RR7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` Quillfield "About" page fetched |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, per the recruiter. Her public headline reads Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. Only a search snippet was seen, no talks or writing | `[grounded]` your recruiter's statement; `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" |
| Scope read | The post spans three jobs: sales-ops reporting, finance-facing billing data, and a CFO-level forecast. Her title sits above this one, so the Lead probably reports to her | `[inferred]` from the posting's three responsibilities and her public title |
| Market calibration | £61,500–£67,000 sits inside the survey's interquartile range (£57,800–£70,400) and brackets its median (£64,200) for UK B2B software revenue operations leads, n=438. The survey is national, not Bristol-specific, and only its search snippet was seen. It is the market's band, not this employer's offer | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting for the figure |
| Unknowns | Option terms; reporting line and direct reports; who signs off the forecast; whether the role is new or a replacement | — |
| Contradictions | None between the posting and Quillfield's About page. The role itself was not found on the company's own site (RR7). The posting asks for experience at a "B2B software company" and your background is a B2B payments company (R3) | `[grounded]` About page fetched; `[grounded]` your stated background |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days | hard_gate | unclear | none | hard_gate | Your location and willingness were not stated, so the gate is unestablished | `[grounded]` posting; `[grounded]` no constraint given | G3 |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your floor was not stated. The posting's figure is clear, so only your side is open | `[grounded]` posting; `[grounded]` no floor given | G3 |
| R3 | 4+ years in revenue operations, sales operations or similar at a B2B software company | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team, covers the years and the function. Your employer is a B2B payments company, and nothing says whether it counts as software, so the sector reads at its lower end. This is a length-of-experience requirement, not a gate | `[grounded]` your prose background, self-report | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You stated Salesforce admin certification, which matches one of two named options. The certification is checkable but has not been inspected | `[grounded]` your prose background, self-report | none |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | discovery | SQL weekly and Excel daily show use. "Strong" and "modelling" are not evidenced by frequency, so the depth of any model you built is open | `[grounded]` your prose background; `[inferred]` that frequency is not depth | a sanitized model or query example would raise it |
| R6 | Experience owning a forecast, including the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is adjacent to forecasting. Limit: finance owned the company forecast at your employer, you have not owned one, and nothing shows CFO-level exposure | `[grounded]` your statement that finance owned it; `[inferred]` adjacency from the pipeline review | see G1 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue", so renewal reporting could count as revenue data. Whether finance used or reconciled those dashboards is not stated | `[grounded]` your rebuilt renewal dashboards; `[inferred]` that they may count | see G2 |
| R8 | Own the company's billing data | must_have | absent | none | capability | You said you have never worked on billing data. No bridge is offered here because none is evidenced | `[grounded]` your statement | closure path in G2 |
| R9 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance ran on them is unstated, so the claim stops at the dashboards | `[grounded]` your prose background, self-report | a sanitized dashboard screenshot would raise it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | A monthly pipeline review with your sales director; the company forecast sat with finance | The role runs the quarterly forecast with the CFO, so this is the largest gap in the posting's own scope | Pipeline commit or coverage numbers you supplied to finance's forecast; a variance or accuracy review; a forecast model you built for the UK team | A sanitized pipeline-review deck, a forecast-input sheet, a variance note | `[grounded]` your statements; `[generic]` that forecast ownership is the likeliest probe for this title |
| G2 | Billing and revenue data with finance (R7 discovery, R8 capability) | discovery for R7, capability for R8 | Renewal dashboards, with no stated finance link and no billing data | R7 can still resolve, but R8 is stated absent and stays a material risk | Renewal figures reconciled with finance's revenue numbers; finance requests for pipeline or renewal cuts; an invoice or ARR figure you validated. For R8 a realistic closure path is a small project joining renewals to invoice exports | A reconciliation sheet, a finance request email, a renewals-to-revenue query | `[grounded]` your statements; `[generic]` the closure path is a pattern, not a promise |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established as described | positive_signal | — | "Quillfield, the invoicing software company" | The entity exists, is in Bristol, and is a funded, mid-sized company | `[grounded]` About page: 96 employees, Series A £11M April 2025 | What is the team's size and where does it sit in the business? | noted |
| RR2 | Pay disclosed and in line with the market band | positive_signal | — | "£61,500–£67,000" | A disclosed range suggests a defined budget, and the range brackets the survey median | `[grounded]` posting; `[generic]` survey band, UK-wide | Where in the range would an offer sit for someone who has not owned a forecast? | noted |
| RR3 | Scope stated concretely | positive_signal | — | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast with the CFO" | The role has defined outputs and finance-facing authority | `[grounded]` posting | Which of those three is the first priority in the first six months? | noted |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | Value depends on number, strike price, vesting and dilution since the Series A | `[generic]` option terms vary widely | How many options, at what strike price and vesting schedule? | unresolved |
| RR5 | Forecast ownership versus support unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | "With the CFO" may mean owning the forecast or preparing it for sign-off | `[inferred]` from the posting's wording | Does this role own the forecast, or does the CFO, and who signs it off? | unresolved |
| RR6 | "Lead" with no stated team | unknown | — | "Revenue Operations Lead" | The role may be an individual contributor under a Head of Revenue Operations, or may manage people | `[inferred]` from the title and the hiring manager's public title | Does this role have direct reports, and who does it report to? | unresolved |
| RR7 | Posting not found on the company's own site | unknown | — | Posting hosted at jobs.tallyboard.example | The role may be listed only on the board, or the careers page may not have surfaced in this search | `[inferred]` from one fetched page, About only | Is this role listed on Quillfield's own careers page, and is it still open? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Positioning: lead with the pipeline and renewal dashboards you rebuilt and the monthly pipeline review you run with your sales director, then Salesforce admin certification and weekly SQL | R9, R4, R5, R6 | `[grounded]` your own statements | pending your approval |
| E2 | Gap framing for the interview: "I haven't owned the company forecast, because finance did, and I haven't worked on billing data. Here is the pipeline and renewal work I have done." | R6, R8 | `[grounded]` your own statements | pending your approval |
| A1 | Before investing in the loop, ask the recruiter the RR5, RR6 and RR7 questions, and RR4 later | RR4–RR7 | `[grounded]` register | pending your approval |
| A2 | Prepare one example showing how pipeline numbers reached finance's forecast, only if G1 confirms it happened | R6 | `[grounded]` G1 | pending your approval |
| W1 | A sanitized dashboard screenshot or query as a work sample | R5, R9 | `[grounded]` R5, R9 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers"; fetched "About Quillfield" (quillfield.co.uk/about). It confirmed the employer and fed role reality and RR1. No careers page or posting surfaced, so RR7 stands |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide), a snippet only. It fed the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), a snippet only. It fed the hiring manager and scope rows and RR6. No talks or writing were found |

I can save this analysis as `tuesday-dossier.md` to carry into later steps, if you want it.

## Upgrade menu

- Your CV → confirms or raises R3, R4 and R9 and lets me propose edits against it.
- An answer on G1 → resolves or narrows R6.
- An answer on G2 → settles R7 and shows whether R8 has any bridge.
- A sanitized dashboard or model example → raises R5 and R9.
- Your location and pay floor → closes R1 and R2.
- The recruiter's answers on forecast ownership, reporting line and options → close RR4, RR5 and RR6.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → adds to the risk register. Say the word and it runs.

G1 — Is there a time your pipeline-review numbers fed finance's forecast, and what did you supply, to whom, and what happened to the forecast?
G2 — Have you ever reconciled renewal or revenue figures with finance, or answered a finance request for pipeline or renewal data, and what did you own in it?
G3 — Are Bristol two days a week and a base of £61,500–£67,000 both workable for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.