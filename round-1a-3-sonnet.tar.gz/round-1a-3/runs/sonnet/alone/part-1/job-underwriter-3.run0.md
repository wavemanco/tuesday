I'll read the reference files the skill names before building the assessment.
**No, not as posted: R1 and R2, both hard gates, fail · Status: `no_go`.** You're a strong match on paper, and the mismatch is in the terms, so the feeling that something is off is well founded.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 (Base pay of $70–85k)
- `must_have` — direct: R3, R5, R6 · adjacent: R4 (Own all revenue growth end to end) · unclear: R7 (SEO/content)
- `important` — unclear: R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops), R11 (Team of one to start)

R1 and R2 — failed on terms no CV wording can change; R3, R5, R6 (`medium`) — confirmed by your own account, no artifact yet; R4 — a credible bridge, limit named; R7 to R11 — nothing in your background addresses them yet.

**Opportunity ledger.** The posting states pay and office terms plainly (RR7). The pay sits against a wide mandate and your floor (RR1, R2), and the mandate bundles several functions with no team, stated resources or fixed metrics (RR2, RR3, RR4). It also signals always-on hours (RR5). The employer is not independently established (RR8), and the office terms conflict with your remote-only constraint (RR6, R1).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 (Base pay of $70–85k).
- **Severe red flags:** none found.
- **What would change this:** Novaline would have to allow fully remote work from Portland (R1) and offer a base of at least $150k (R2). Both would have to change, and the posting says "no exceptions" on location.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; not independently confirmed (target 1) |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | "A team of one to start"; reports to the CEO, "dotted line to the board" | `[grounded]` posting |
| Location and schedule | On-site Austin, 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms given | `[grounded]` posting |
| Success metrics and first-90-days | "Success metrics will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` posting |
| Scope read | A head-of-function title carrying an individual operator's workload across seven named functions | `[inferred]` from the title and CEO/board reporting line against "team of one" and the function list |
| Sales motion | "Sales ops" and "e-commerce enablement" suggest a sales-assisted, possibly merchant-facing motion, which would differ from your B2C subscription background | `[inferred]` from those two phrases only; the posting does not name the customer |
| Market calibration | Not established. The role-family sweep did not run (target 2), so no band is stated | — |
| Unknowns | Budget, customer type (consumer or merchant), equity terms, who "sales ops" supports, what "success" will mean | — |
| Contradictions | No second source to compare against. Within the posting, a "Head of" title and board access sit beside a team of one | `[grounded]` posting text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" (your constraint: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit, which is specific and confirmed. The fit fails because the posting rules out remote work | `[grounded]` your statement and posting | Surface in the snapshot; only you or the employer changing terms resolves it |
| R2 | Base pay of $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor. The posted top of range is below it, so the fit fails | `[grounded]` your statement and posting | Surface in the snapshot; the equity is unquantified in the posting and cannot be weighed against a base floor |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You state 9 years in growth, including Growth lead then Head of Growth at two B2C subscription companies. It is your own account, with no document inspected, so `medium`; the posting gives no definition of what counts as "growth leadership" | `[grounded]` your background as stated | none |
| R4 | "Own all revenue growth end to end" | must_have | adjacent | medium | transferability | You scaled one company from $8M to $40M ARR over three years with a budget you controlled, and owned paid, lifecycle and experimentation. Limit: that is three of the posting's seven functions. SEO/content, brand, PR, partnerships and sales ops are not in your account, so full-funnel ownership is not shown | `[grounded]` your stated claim; `[inferred]` the limit from the seven-function list | If terms ever change: a revenue-attribution view or board deck would raise it |
| R5 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both companies; confirmed in prose, no artifact | `[grounded]` your background as stated | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, SQL and GA4. Confirmed in prose, no artifact | `[grounded]` your background as stated | none |
| R7 | SEO/content | must_have | unclear | low | discovery | Your account does not mention SEO or content. Low, not none, because a growth lead in subscription businesses may have touched it, which you can confirm or deny | `[grounded]` silence in your account; `[generic]` that growth leads sometimes touch SEO | Ask only if terms change (G1) |
| R8 | Brand and PR | important | unclear | low | discovery | Not in your account | `[grounded]` silence in your account | Ask only if terms change (G2) |
| R9 | Partnerships | important | unclear | low | discovery | Not in your account | `[grounded]` silence in your account | Ask only if terms change (G2) |
| R10 | Sales ops | important | unclear | low | discovery | Not in your account, and the posting does not say what sales motion it supports | `[grounded]` silence in your account | Ask only if terms change (G3) |
| R11 | Operate as a team of one to start | important | unclear | low | discovery | You built and managed teams of 3–7. Whether you have run a function alone is not stated | `[grounded]` your account | Ask only if terms change (G4) |

## Gap recovery queue

All four rows are conditional. The decision rests on R1 and R2, so none of them moves the status unless the terms change.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | Nothing on SEO or content in your account | It is the one `must_have` row below `direct` and `adjacent` | Owning organic landing pages or a content calendar; working with an SEO agency or writers on conversion goals; setting up organic tracking in GA4 | A traffic or conversion report, a content brief | `[grounded]` silence in your account |
| G2 | Brand, PR and partnerships (R8, R9, important) | discovery | Nothing on these in your account | The posting lists them as part of one mandate | A launch with press coverage; affiliate or co-marketing deals you negotiated | A deal summary, a press link | `[grounded]` silence in your account |
| G3 | Sales ops (R10, important) | discovery | Nothing on sales operations | The posting does not say what sales motion it supports, so it is hard to tell what counts | CRM or pipeline reporting for a sales team; lead routing or attribution between marketing and sales | A pipeline dashboard screenshot | `[grounded]` silence in your account; `[inferred]` the sales motion |
| G4 | Team of one (R11, important) | discovery | You managed teams of 3–7; solo operation is unstated | It decides whether the workload in the posting is feasible for you | A period when you ran paid and lifecycle alone, or before a team was hired | A role description or org chart for that period | `[grounded]` your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay against scope and seniority (R2) | risk_signal | medium | "8+ years growth leadership required … $70–85k base plus meaningful equity upside" | The base may be priced below what a seven-function mandate at this seniority usually commands. The market band is unavailable because the sweep did not run, so this is a reading and not a measured gap | `[inferred]` from the posting's pairing of years and scope with that base | What is the equity, in percentage and vesting terms, and is the base range fixed? | unresolved |
| RR2 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles may be folded into one title and one person | `[inferred]` from the seven named functions under one hire | Which of these functions would you expect this person to execute, and which to hire or contract for? | unresolved |
| RR3 | Responsibility without stated resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench" | The role may carry company-wide revenue accountability with no committed budget or headcount | `[inferred]` from the posting's silence on budget against its scope | What budget and headcount are committed for the first year? | unresolved |
| RR4 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for revenue growth may come with no agreed definition of success | `[inferred]` from the quote against the demanding mandate | What results would make the first year a success, and who decides? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours beyond a normal week may be routine rather than exceptional | `[inferred]` from the quote | How many evenings or weekends a month does the current team work, and is any of it compensated? | unresolved |
| RR6 | On-site five days against your remote-only constraint (R1) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions" | The terms are incompatible with a constraint you stated. Medium because this is a conflict of terms and says nothing about the posting's honesty; R1 and the decision carry it at full weight | `[grounded]` posting and your statement | Is any part of this role open to remote work from Portland, or is five days in Austin firm? | confirmed |
| RR7 | Pay and office terms stated plainly | positive_signal | — | "$70–85k base" and "On-site … 5 days a week" | You can rule the role in or out without a recruiter call | `[grounded]` posting | Is the $70–85k base the full cash compensation, or are there bonuses on top? | noted |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Novaline may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting as written | R1 and R2 both fail and no wording closes them | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If you want to test whether terms move, ask the employer directly about remote work and the base range, using the RR6 and RR1 questions, before investing in an application. The posting says "no exceptions", so expect a no | Cheapest check before any application effort | `[inferred]` from the posting's "no exceptions" wording | pending your approval |
| A3 | If terms ever change, lead with R3, R5, R6 and the R4 revenue-scale claim, stated as you gave them, with the caveat that no artifact has been inspected. Do not claim SEO, brand, PR, partnerships or sales ops (R7 to R10) | These are the rows your own account supports | `[grounded]` R3 to R6 rows | pending your approval |
| A4 | Don't draft CV edits for this role | Nothing to optimize while the gates fail | `[grounded]` R1, R2 rows | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin careers Head of Growth"; the call was refused. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth startup Series A salary base range 2026"; the call was refused. It would have moved role reality's market calibration and the RR1 comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can write this up as `tuesday-dossier.md` if you want a kept copy.

**Upgrade menu**

- Search permission, so targets 1 and 2 can run → RR8 closes or sharpens, role reality's organization row is checked against the company's own site, and a market band is set against RR1. This would not change the `no_go`.
- Novaline's answer on remote work and the base range → R1 and R2 would be re-read, and the status could move.
- A named hiring manager → role reality's scope read and the application plan's positioning.
- Answers to G1 to G4, or artifacts such as a traffic report or pipeline dashboard → R7 to R11 would move off `unclear`. This matters only if terms change.
- A deeper research pass on Novaline (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → this would only refine the register, and it needs search permission first.

**Questions**

None. Nothing the gap queue could recover changes a status that rests on R1 and R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.