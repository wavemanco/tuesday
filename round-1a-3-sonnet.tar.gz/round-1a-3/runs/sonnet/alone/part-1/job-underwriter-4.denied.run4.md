I'll read the skill's reference files first.
**Yes, apply, on conditions. Status: `conditional_go`.** Your two worries don't block it. R10 (pet-insurance domain) is a credible bridge with a named limit. The posting as pasted lists no people-management requirement (see Role reality).

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based working)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Design price tests)
- `important`: unclear: R8 (Recommendations to product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R5b: design ownership isn't stated; R8: the product audience isn't evidenced; R10 (`low`): a credible bridge, its limit named.

**Opportunity ledger.** The role is concrete but has unevidenced edges. The employer is not verified from here (RR1), the pasted posting carries no salary (RR2), and sign-off authority and team shape are unstated (RR3). One entry runs the other way: the responsibilities are concrete (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based working); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) UK-remote working is confirmed as workable for you (R1). (2) Brindlemoor and the live posting are verified (RR1). (3) The salary range is acceptable once learned (RR2). (4) The pet bridge is framed as adjacent, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product. Existence and stage were not checked (see Evidence status). | `[grounded]` JD as pasted; unverified |
| Role | Senior Pricing Analyst, fully remote (UK). Own pricing analytics for the pet product. | `[grounded]` JD |
| Mandate | Build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product. | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. | `[grounded]` your message |
| People management | The JD lists no line-management requirement. Whether the seat has direct reports is not stated. | `[grounded]` JD silent |
| First-90-days / first-year outcomes | Not stated in the JD. | `[grounded]` JD silent |
| Scope read | A single-product analytics seat that owns models, tests and recommendations. The JD names no team, budget or decision rights. | `[inferred]` from "own pricing analytics for our pet-insurance product" against the JD's silence on authority |
| Market calibration | Not established. The role-family sweep did not run, so no salary band or title norm is offered. | `[grounded]` target 2 unavailable, below |
| Unknowns | Salary; who signs off rate changes; team size; whether there are direct reports. | `[grounded]` JD silent on each |
| Contradictions | None between the JD and your background as given. There was no second source to check the JD against. | `[grounded]` inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based working | hard_gate | unclear | low | hard_gate | The JD says "Fully remote (UK)". You described no residence, right to work or constraints. A UK employer is a hint, not a statement. | `[grounded]` JD; `[inferred]` UK base from your UK employer | Confirm via the closing question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. It's self-reported with no inspectable artifact yet. | `[grounded]` your background | Offer: a dated role record would help |
| R3 | Build and monitor rating models | must_have | direct | medium | none | You stated you "built and maintained" the GLM rating model for the young-driver book. That is one book. Monitoring practices aren't described separately. | `[grounded]` your background | Offer: a sanitized monitoring pack would raise it |
| R4 | GLM experience | must_have | direct | medium | none | The same GLM rating model for the young-driver book, built and maintained by you. | `[grounded]` your background | Offer: a sanitized model summary would raise it |
| R5a | Run and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. | `[grounded]` your background | Offer: a sanitized test readout |
| R5b | Design price tests | must_have | unclear | low | discovery | "Ran" doesn't say whether you designed them (hypothesis, segmentation, control, duration). Ambiguity resolves downward. | `[grounded]` your wording; `[inferred]` the open reading | G1 |
| R6 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use of both. "Strong" is unverified. | `[grounded]` your background | Offer: a sanitized query or notebook sample |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` your background | None |
| R8 | Recommendations for product, as well as underwriting | important | unclear | low | discovery | Your underwriting-facing work is stated. Nothing in what you gave touches a product audience. | `[grounded]` your background silent on product | G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. | `[grounded]` your background | None |
| R10 | Pet-insurance domain knowledge (implied by "our pet-insurance product") | preferred | adjacent | low | transferability | You said you've never worked on pet insurance. Motor rating, price testing and underwriting-facing reviews carry over as method. The motor work is `medium`, but its applicability to pet is my inference, so I took the lower band. Motor and pet books differ in what drives claims and in the rating factors available. | `[grounded]` your statement; `[inferred]` the bridge; `[generic]` the motor and pet differences | G3 |

No CV was provided, so gap `none` means nothing is missing from what you wrote. A CV could surface presentation gaps.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design price tests (R5b, must_have) | discovery | "Ran 14 price tests with the underwriting team", with no statement of who designed them | A must-have that the JD names directly. A clear answer likely moves R5b to `direct`. | Choosing the segment and the control; sizing and duration; setting the read-out criteria; deciding whether to roll out | A sanitized test readout or design note | `[grounded]` your wording; `[inferred]` that it moves the row |
| G2 | Recommendations to product (R8, important) | discovery | The audience in your work is underwriting; product isn't mentioned | The JD pairs underwriting with product, and an interviewer may ask about it | A pricing paper that reached a product owner, marketing or finance; a rate-change proposal beyond underwriting | A sanitized slide or paper | `[grounded]` JD pairing; `[generic]` that interviewers probe the second audience |
| G3 | Pet-insurance domain (R10, preferred) | transferability | Adjacent evidence: a GLM rating model, price tests and a quarterly pricing review, all on motor. Limit: nothing in your account touches pet-specific factors or claims patterns. Strengthener: a short note of how you'd approach pet rating from public material, written by you. | The biggest gap you named. It is preferred-tier, and a bridge with its limit stated reads stronger than a claim. | Any non-motor product, or health- or breed-like rating factors you've handled | A short note, pending your approval | `[grounded]` your statement; `[inferred]` the bridge |
| G4 | UK-remote working and constraints (R1, hard_gate) | hard_gate | The JD states a UK-remote gate; your location and constraints weren't given | A gate that wording can't fix. Whether it is met decides everything else. | n/a | Your own confirmation | `[grounded]` JD; inputs silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check did not run. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | No salary in the posting as pasted | unknown | — | "Senior Pricing Analyst … Fully remote (UK)" (no figure) | The posting may withhold pay, or the figure may have been left out of what you pasted. | `[inferred]` from the pasted text | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership asserted, authority and team unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The seat may own the analytics while rate-change sign-off sits with underwriting or product, and with unknown analyst support. | `[inferred]` from the JD's ownership wording against its silence on authority | Who signs off rate changes, and what team supports this role? | unresolved |
| RR4 | Responsibilities are concrete | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | Scope is defined as deliverables, which makes success measurable. | `[grounded]` JD | What would success look like in the first 90 days and the first year? | noted |

## Application plan

Every row below is proposed, and nothing is finalized until you approve it. That covers the edits table and the advice text beside it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put this line first: "Built and maintained the GLM rating model for the young-driver book" (`resume_edits_pending_approval`) | See R3, R4 | `[grounded]` your sentence | pending your approval |
| E2 | Add: "Ran 14 price tests last year with the underwriting team" (`resume_edits_pending_approval`). Don't write "designed" until G1 is answered. | See R5a, R5b | `[grounded]` your sentence | pending your approval |
| E3 | Add: "Present the quarterly pricing review to the head of underwriting" (`resume_edits_pending_approval`) | See R7 | `[grounded]` your sentence | pending your approval |
| P1 | In any cover note, say plainly that you haven't worked on pet insurance and that your rating, testing and review work was on motor. Don't claim pet experience. | See R10, G3 | `[grounded]` your statement | pending your approval |
| Q1 | Ask RR1 to RR4's verification questions in the loop, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the salary range before investing in the full loop | See RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Brindlemoor pet insurance insurtech careers" was refused (permission not granted). It would have moved role reality's organization and contradictions rows, and let RR1 close or stay open on evidence. |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst pet insurance UK salary" was refused. It would have moved the market-calibration row and a salary comparison against RR2. |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. A name was given, so this isn't `n/a`. It would have moved the scope read and which story to lead with. |

I can produce a `tuesday-dossier.md` of this assessment if you'd like one.

## Upgrade menu

- Granting search permission, or pasting the company's careers-page listing, lets RR1 resolve. It also adds a market band to role reality and Odile Varga's public professional footprint to the application plan. A deeper pass would add up to 5 more searches and 2 more fetches, on your say-so.
- The salary range closes RR2.
- Answers to G1 and G2 move R5b and R8.
- A sanitized model-monitoring pack, test readout, or quarterly-review deck would raise R3, R4, R5a, R7 and R6 toward `high`.
- Pasting your CV shows whether presentation gaps exist, since only prose was given.

## Questions

1. **R1** — Beyond UK-remote working, which non-negotiables apply to you (right to work, a pay floor, hours)?
2. **G1** — On the 14 price tests, which parts did you personally own: the segment and control choice, sizing, the read-out, or the roll-out call?
3. **G2** — Have you taken pricing results to anyone beyond underwriting, such as product, marketing or finance? What did you recommend, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.