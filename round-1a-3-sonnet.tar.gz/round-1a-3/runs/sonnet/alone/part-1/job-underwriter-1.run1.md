I'll read the reference files the workflow requires before building the assessment.
## Decision snapshot

**Yes, apply once the employer checks out. You are a fit on R1, R2, R3, R4 and R5, all `must_have` rows at `direct`. R6 is `adjacent` and waits on one answer from you, and healthcare (R9) is new to you. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 (`low`) — inferred from "governed dashboards", one answer from direct; R9 — a credible bridge, its limit named; R7b, R8 — your background is silent.

**Opportunity ledger.** The employer could not be checked from here (RR1), pay and work location are unstated in the posting as you pasted it (RR2, RR3), and the role's authority over metric definitions is unspecified (RR4). One entry runs the other way: the duties and stakeholders are concrete (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Harborlight's own careers site, RR1; (2) pay and location are acceptable to you, RR2, RR3; (3) the metrics-layer question R6 resolves, or you are comfortable carrying it as adjacent; (4) healthcare is framed honestly as new, R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own product analytics for the app: metrics layer, A/B test design and analysis, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Requirements | 5+ years product analytics; expert SQL; experiment design at scale; Looker or similar BI; written communication with non-technical stakeholders. HIPAA healthcare data is a plus | `[grounded]` JD |
| Hard gates | None stated in the posting as pasted: no work location, authorization, schedule or pay term | `[grounded]` JD as provided |
| First-year outcomes | Not stated; no success measures are given for the mandate | `[grounded]` JD silence |
| Scope read | Four functions plus mentoring of two juniors under one "own" verb reads as a lead-flavored senior individual-contributor post | `[inferred]` from the responsibilities list |
| Market calibration | Not available: the role-family search was refused, so no band is given rather than recalled from memory | `[grounded]` the refused search, see Evidence status |
| Unknowns | Pay; location or remote policy; whether the metrics layer exists or must be built; who sets metric definitions; what the clinicians' role in decisions is | `[grounded]` JD silence |
| Contradictions | None found between your background and the JD; no second source for the JD was available to compare | `[grounded]` inputs provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber meal-kit company. Self-reported, so `medium` at intake | `[grounded]` your background as stated | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" for 6 years. That shows sustained use, and you didn't claim "expert" yourself, so that word stays your call. Hiring loops for this title often include a live SQL exercise | `[grounded]` your statement; `[generic]` on SQL exercises | none; a sample query or model you can share would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | "Designed and ran the experimentation program: 30+ A/B tests a year", including the pricing test behind an 11% retention lift, across ~2M subscribers. Limit: "11%" has no stated baseline or unit | `[grounded]` your statement | one answer on what the 11% measures (see Application plan, A2); a test write-up would raise it |
| R4 | Looker or similar BI | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your statement | a dashboard screenshot or LookML sample would raise it |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your statement | a sanitized memo would raise it |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" and a warehouse consent-state model are near this work. Nothing you said states that you defined or owned metric definitions, so ownership stays unconfirmed | `[inferred]` from "governed" and the consent-state model | see G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product, and a pricing test that changed outcomes | `[grounded]` your statement | none |
| R7b | Partner with clinicians | important | unclear | low | discovery | No clinician or domain-expert partnership appears in your background. Analogous work, such as culinary or operations teams, may exist but is unstated | `[grounded]` background silent | see G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background is silent on managing or mentoring analysts | `[grounded]` background silent | see G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Limit: that is not healthcare data and not HIPAA work, and you have no healthcare-domain experience | `[grounded]` your statement; limit `[grounded]` your own "never worked in healthcare" | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | Governed dashboards and a consent-state model, with no statement of who defined the metrics behind them | A `must_have` and the first-listed responsibility. Resolving it could move R6 to `direct` | Writing the canonical definition of a core metric (retention, activation, churn); LookML models or dbt-style definitions you maintained; resolving a dispute over how a number was calculated; deprecating conflicting dashboards | A metric dictionary, a LookML excerpt, a definitions doc | `[grounded]` your statement; `[inferred]` that the answer moves R6 |
| G2 | Mentoring (R8, important) | discovery | Nothing on mentoring or reviewing others' analysis | The JD names two juniors; a yes or no changes how R8 is positioned | Onboarding an analyst; reviewing others' SQL or experiment designs; a formal or informal mentee; training PMs on self-serve dashboards | A mentoring plan, review checklist or onboarding doc | `[grounded]` background silent |
| G3 | Clinician partnership (R7b, important) | discovery | No work with clinical or other domain-expert stakeholders | The JD pairs clinicians with PMs in the roadmap loop | Working with dietitians, nutritionists, medical or compliance advisors, or any domain expert whose judgment shaped a test or metric | A brief or memo that included their input | `[grounded]` background silent |
| G4 | HIPAA and healthcare data (R9, preferred) | transferability | Consumer-privacy handling and a consent-state model, outside healthcare | A `preferred` row. The bridge helps, and its limit has to be stated, not hidden | Any health-adjacent data (dietary or allergy preferences, wellness programs); privacy reviews, DPAs, or de-identification; access-control design | A consent-model design doc or data-handling policy you wrote | `[inferred]` bridge from GDPR/CCPA work; limit `[grounded]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. My searches were refused, so none of these is ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated in the posting as pasted | unknown | — | No pay figure appears in the pasted posting | The range may be withheld, sit in a separate section you didn't copy, or fall below the role-family norm for the title and scope | `[inferred]` from the pasted posting's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Work location and arrangement unstated | unknown | — | No location or remote policy appears in the posting as pasted | A location or on-site requirement may exist that conflicts with a constraint you haven't yet given me | `[inferred]` from the pasted posting's silence | Where is this role based, and what is the on-site or remote expectation? | unresolved |
| RR4 | Authority and starting state of the metrics layer unspecified | unknown | — | "define and maintain the metrics layer" and "Own product analytics" | The role may be accountable for definitions without decision rights, or may be a from-scratch build with no stated success measures | `[inferred]` from the responsibilities against the JD's silence on authority and outcomes | Does this role set metric definitions itself, and what exists today in the metrics layer? | unresolved |
| RR5 | Concrete duties and named stakeholders | positive_signal | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | The role's deliverables and partners are specified, which reads as a defined scope | `[grounded]` JD | What roadmap decision did the last analysis in this role change? | noted |

## Application plan

Every row below is a proposal and nothing is applied. Each row, whether wording or strategy, is `pending your approval`, and none goes into your CV or any message until you approve it. Each line of wording traces to your own sentences. I am deliberately not using the JD's phrase "metrics layer" for your work until you answer G1.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume edit: lead the summary with "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift", then "Built the company's Looker instance from scratch — 40+ governed dashboards" | See R3, R4. Both are your own sentences, in your order of strength | `[grounded]` your statement | resume_edits_pending_approval |
| E2 | Resume edit: add "Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII" | See R9. It states the bridge without claiming healthcare or HIPAA | `[grounded]` your statement | resume_edits_pending_approval |
| W1 | Positioning: in one sentence in your cover note or intro call, say healthcare is new to you and that you have handled consumer PII under GDPR/CCPA. Do not describe it as healthcare or HIPAA experience | See R9. A hiring team can check whether it is stated plainly | `[grounded]` your "never worked in healthcare" | pending your approval |
| A1 | Confirm the posting is live on the company's own careers site before spending effort on the application | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Prepare to say what the 11% measures (baseline, unit, time window) and which parts of the pricing test were yours | See R3. Interviewers for this title often probe attribution | `[grounded]` R3; `[generic]` on probing | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in early conversations | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused. It would have moved role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "Senior Product Analyst digital health salary range Looker experimentation"; the call was refused. It would have moved role reality's market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you want to keep it or reuse it later.

## Upgrade menu

- Granting web search so I can retry targets 1 and 2 (3 searches and 2 fetches remain) → RR1 closes or stays open on real evidence, and role reality gets a market band for RR2.
- A deeper research pass on Harborlight (funding, leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches) → feeds RR1 and the opportunity ledger.
- Your answer on G1, with a metric dictionary, LookML excerpt or definitions doc → R6 moves toward `direct`.
- Your answer on G2 → R8 closes or is carried as a minor risk.
- Your answer on G3 → R7b closes or is carried as a minor risk.
- A sanitized experiment write-up, dashboard screenshot or monthly memo → R3, R4 and R5 move toward `high`.
- Your pay floor, location or remote preference, and work authorization → hard-gate rows for each, checked against RR2 and RR3.
- The hiring manager's name → role reality's scope read, and which of your verified stories to lead with for that reader.

## Questions

G1 — Did you personally write or own the definitions of core metrics (retention, churn, activation) behind your governed dashboards, such as LookML models or a metric dictionary? What did you own, and who signed off?

G2 — Have you mentored, onboarded or reviewed the work of other analysts? What did you do, and for whom?

RR2, RR3 — What are your non-negotiables for this role on pay floor, location or remote arrangement, and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.