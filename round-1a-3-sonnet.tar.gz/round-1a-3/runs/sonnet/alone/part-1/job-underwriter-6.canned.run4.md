Status: I've read the posting and the underwriting method. Next I'm running the company, salary-band and hiring-manager lookups.
## Decision snapshot

**Yes, worth applying to, as a stretch rather than a safe fit. R6a and R7a, both absent, are the gaps you would carry in. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5a · adjacent: R5b (Spreadsheet modelling), R6b (Quarterly forecast with the CFO) · unclear: R7b (Working with finance on revenue data) · absent: R6a (Experience owning a forecast), R7a (Billing data)
- `important` — direct: R8

R6a, R7a — absent, carried as capability gaps; R6b — a credible bridge, its limit named; R7b — one answer could resolve it.

**Opportunity ledger.** The role is clearly described and pays at a stated, mid-range figure (RR4). Two things are unresolved: the posting is not confirmed on Quillfield's own careers page (RR1), and the split of forecast ownership with the CFO is unclear (RR2). The scope bundles several jobs into one title (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 are both workable for you; (2) the forecast and billing gaps (R6a, R7a) are acceptable to the employer, which you test with the RR2 question; (3) RR1 resolves, meaning the role is live and open; (4) you describe R6a and R7a plainly and never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting text |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting text |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at a payments company for four years | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), a snippet only |
| Scope read | A lead role under a Head of Revenue Operations, with CRM, billing data, reporting and forecasting combined | `[inferred]` from the posting's four responsibilities and the manager's title |
| Market calibration | UK B2B software revenue operations leads: median base £64,200, interquartile range £57,800–£70,400. The posted range sits inside that interquartile range, around the median. Share options are outside the band, and this is a market pattern, not Quillfield's offer | `[generic]` "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example), snippet only; `[grounded]` posting for the range |
| Unknowns | Reporting line; team size; who signs off the forecast number; which billing system; first-90-day and first-year outcomes (the posting states none); option terms | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the About page. The role was not found at quillfield.co.uk/careers (see RR1) | `[grounded]` one fetch returned no page |

## Evidence map

Your background is self-report at intake, so `medium` is the ceiling on any row built from it.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You have not stated your location or what you will commute, so the gate is not established | `[grounded]` posting; no candidate statement | Ask G1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated. The range is mid-band for the title (see role reality) | `[grounded]` posting; `[generic]` band | Ask G1 |
| R3 | 4+ years in revenue ops, sales ops or similar analytics at a B2B software company | must_have | direct | medium | discovery | You report 5 years in sales operations, the last 2 running revenue operations for the UK team. The years and function match. Whether a B2B payments company counts as "software" is unconfirmed | `[grounded]` your stated background; sector fit unconfirmed | G6: confirm what your employer sells |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, and you rebuilt the pipeline and renewal dashboards. Nothing inspected yet | `[grounded]` your stated background | Offer: certification record |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly is real use, and "strong" has no artifact behind it | `[grounded]` your stated background | Offer: a sanitized query |
| R5b | Spreadsheet modelling | must_have | adjacent | medium | transferability | Excel daily is confirmed. Building models, such as a forecast or revenue model, is not stated. Limit: daily use is not modelling | `[grounded]` your stated background | G7: say which models you have built |
| R6a | Experience owning a forecast | must_have | absent | none | capability | You said you have never owned the company forecast and that finance did | `[grounded]` your statement | Closure path in G2; carried as a material risk |
| R6b | Run the quarterly revenue forecast with the CFO (a responsibility) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is forecast-adjacent. Limit: you did not own the number, and the CFO is a different counterpart | `[grounded]` your stated background; `[inferred]` adjacency | G3 |
| R7a | Billing data (own CRM and billing data) | must_have | absent | none | capability | You said you have never worked on billing data | `[grounded]` your statement | G4 |
| R7b | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Your pipeline and renewal dashboards may have been used by finance. That is unconfirmed, and finance owned the forecast | `[inferred]` from the renewal dashboards; nothing confirmed | Ask G5 |
| R8 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | presentation | You rebuilt your pipeline and renewal dashboards, which is the closest match to the role. Whether finance used them is R7b | `[grounded]` your stated background | E1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Bristol hybrid and the pay range (R1, R2, hard_gate) | hard_gate | Neither your location nor your pay floor is stated | A gate you cannot meet ends the application | Not applicable; only your own answer settles it | None needed | `[grounded]` the inputs are silent |
| G2 | Owning a forecast (R6a, must_have) | capability | You have not owned one | The posting lists it as a requirement, and the role's forecast is shared with the CFO | Closure path: submit or maintain a forecast figure for your sales director's review, shadow finance's forecast cycle, or build a forecast model from your own pipeline data | A sanitized forecast model from your pipeline data | `[grounded]` your statement; `[inferred]` the closure path |
| G3 | The forecast bridge (R6b, must_have) | transferability | You run the monthly pipeline review | It is your strongest answer to the forecast requirement | Commit calls or a forecast category you set or defended in that review, a weighted-pipeline number you produced, forecast accuracy you tracked | A sanitized pipeline review pack | `[grounded]` your stated background |
| G4 | Billing data (R7a, must_have) | capability | No billing data work | The role owns billing data, and the posting's requirement is finance on billing | Closure path: renewal or invoice data you have reconciled to the CRM, revenue recognition or billing system exports you have queried | A query on renewal or invoicing tables | `[grounded]` your statement; `[inferred]` the closure path |
| G5 | Finance collaboration (R7b, must_have) | discovery | The CV signal is renewal dashboards, with no named finance work | It could move R7b from `unclear` and soften R7a | Finance using your renewal dashboard, reconciling bookings to billed revenue, supplying finance with churn or renewal figures | The dashboard, or an email thread with finance | `[grounded]` background silent on finance; `[inferred]` it could soften R7a |
| G6 | B2B software employer (R3, must_have) | discovery | Your employer is described as a B2B payments company | The posting asks for a B2B software company | Your employer selling a platform, an API or software subscription | A company description or product page | `[grounded]` your stated background |
| G7 | Spreadsheet modelling (R5b, must_have) | transferability | Daily Excel use | The posting says "spreadsheet modelling" | A territory, quota, commission or renewal model you built | A sanitized workbook | `[grounded]` your stated background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not confirmed on the employer's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed at a different path, listed only on the jobs board, or already closed | `[grounded]` one fetch of quillfield.co.uk/careers returned no page; one path is a thin check | Can you point me to this role on Quillfield's own careers page, and is it still open? | unresolved |
| RR2 | Forecast authority split with the CFO | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the model while the CFO signs off the number, or the reverse | `[inferred]` from the posting's wording against its silence on sign-off | Who owns the forecast model and who signs off the number, this role or the CFO? | unresolved |
| RR3 | Four responsibilities in one lead title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast" | CRM, billing data, reporting and forecasting may be combined in one lead role | `[inferred]` from the posting's four responsibilities; the Head above it is from the hiring manager's public title | What team and tooling support this role, and who else works in revenue operations at Quillfield? | unresolved |
| RR4 | Stated pay, mid-band | positive_signal | — | "£61,500–£67,000 plus share options" | The range is stated and sits inside the typical band for the title | `[grounded]` posting; `[generic]` band | How are the share options structured and when do they vest? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: lead with "Rebuilt our pipeline and renewal dashboards; run the monthly pipeline review with the sales director" (your own words, no added scope) | R8, R6b | `[grounded]` your stated background | pending your approval |
| E2 | Cover note line: "I haven't owned a company forecast (finance did at my current company) or worked on billing data; here is the adjacent work." The adjacent work is only what G3 and G5 confirm | R6a, R7a: naming the gap yourself is the honest framing | `[grounded]` your statements | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim with the recruiter or Tamsin Achebe | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Settle G1 (location and pay) before putting in effort | R1, R2 | `[grounded]` map | pending your approval |
| A2 | Lead with the pipeline and renewal reporting story for the hiring manager, because it is your closest-to-role evidence | R8; her public title is Head of Revenue Operations | `[grounded]` hiring-manager profile snippet | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report from this conversation, and nothing from agent memory was used.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved the organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager row and A2 |

I can write this up as `tuesday-dossier.md` if you want a copy you can keep and update.

## Upgrade menu

- Your location and pay floor → R1 and R2 close.
- An answer on finance collaboration → R7b resolves, and R7a may soften.
- A sanitized pipeline review pack or any forecast figure you submitted → R6b's bridge strengthens.
- A sanitized dashboard, query or certification record → R4, R5a and R8 can reach `high`.
- Confirmation of what your employer sells → R3 closes.
- The recruiter's answers on forecast sign-off and reporting line → RR2 and RR3 close.
- A deeper research pass on Quillfield (funding, leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.
- Extra, not built: a 30-day plan for closing the forecast and billing-data gaps before interviews. It earns its place because R6a and R7a are what decide this stretch. Say yes and I'll build it.

## Questions

G1 — Are the Bristol hybrid pattern and the £61,500–£67,000 range both workable for you?

G5 — Did finance use your pipeline or renewal dashboards, or rely on figures you supplied? What did you own, and what happened?

G3 — In your monthly pipeline review, did you set or defend a forecast number or commit category, or only report pipeline?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.