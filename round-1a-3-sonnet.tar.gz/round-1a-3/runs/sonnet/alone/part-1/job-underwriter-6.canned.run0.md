I'm reading the skill's remaining rules (decision snapshot, evidence bands, row shape), then I'll write up the assessment.
Yes, worth applying, but as a stretch: forecast ownership and billing data are real gaps against what the posting lists. I couldn't confirm the posting on Quillfield's own site (RR1), and I don't know whether the Bristol terms and pay suit you. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3a, R4, R5a · adjacent: R6 (Owning a forecast) · unclear: R3b (At a B2B software company), R5b (Spreadsheet modelling), R7 (Finance on billing or revenue data) · absent: R8 (Owning billing data)
- `important` — direct: R9

R6 — a credible bridge, its limit named; R8 — absent, to be named as absent and never reframed; R3b, R5b, R7 — open until you answer.

**Opportunity ledger.** The employer and the hiring manager both check out publicly, and the posted pay sits inside the market band (RR3). Open items: the posting isn't confirmed on Quillfield's own careers page (RR1), it isn't clear who owns the forecast today (RR2), and the share options have no stated terms (RR4).

- **Hard gates:** none failed (R1 and R2 are `unclear`, neither is `hard_gate_fail`); unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 work for you; (2) the posting verifies on Quillfield's own channels, per RR1; (3) R6 and R8 go in as adjacent and absent, with the recruiter or Tamsin Achebe confirming a learning curve is acceptable (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` About Quillfield page, from search |
| Role | Revenue Operations Lead: own CRM and billing data, build pipeline and renewal reporting for sales and finance, run the quarterly revenue forecast with the CFO | `[grounded]` posting, read from your link |
| Working pattern and pay | Bristol, hybrid, two office days a week. £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is listed publicly as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches the name the recruiter gave you | `[grounded]` public professional profile snippet, from search |
| First-year outcomes | Not stated. The first quarterly forecast cycle with the CFO is the likeliest early test | `[inferred]` from "run the quarterly revenue forecast with the CFO" |
| Scope read | One post covering CRM, billing data, reporting and the forecast is broad. The posting doesn't say whether the post has reports | `[inferred]` from the posting's responsibility list and its silence on team size |
| Market calibration | A 2026 UK pay survey puts revenue operations lead at B2B software firms (n=438) at a median base of £64,200, interquartile range £57,800–£70,400. The posted range sits inside that band, near the median. This is a pattern, not this employer's offer | `[generic]` survey found by role-family search; `[grounded]` posting for the posted range |
| Unknowns | Who owns the forecast today; what "billing data" means (Quillfield's subscription billing or customer invoice data); option terms; whether the post manages people | — |
| Contradictions | None between the posting and the About page. The posting wasn't found on Quillfield's careers address I tried (RR1) | `[grounded]` About page; careers address returned no page |

## Evidence map

I worked from your description only. No CV or artifacts were provided, so no row is at `high`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol office, hybrid, two days a week | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what office days you'll accept, so I can't say whether the term is met | `[grounded]` posting term; no candidate constraint given | Q1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the pay. Your floor wasn't given | `[grounded]` posting figure; no floor given | Q1 |
| R3a | 4+ years in revenue operations, sales operations or similar analytics role | must_have | direct | medium | none | You have 5 years in sales operations, the last 2 running revenue operations for the UK team. No document inspected | `[grounded]` your stated background | Share a CV to raise it |
| R3b | That experience at a B2B software company | must_have | unclear | medium | discovery | Your employer is a B2B payments company. Whether the posting would count it as software is not established | `[grounded]` your stated employer type; `[generic]` that employers differ on this reading | Say so plainly in the application and let the reader judge |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified and rebuilt the pipeline and renewal dashboards. The certification is stated, not checked | `[grounded]` your stated certification | Certification record would raise it to high |
| R5a | Strong SQL | must_have | direct | medium | none | You use SQL weekly. That shows use, not depth, and "strong" is the posting's own word | `[grounded]` your stated use | A sanitized query sample would raise it |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily. You haven't said you build models | `[grounded]` your stated Excel use; model-building not stated | G5 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | Finance owned the forecast where you worked. You run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards. Limit: you have not owned the forecast | `[grounded]` your stated background and limit | Q2 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You built renewal dashboards, which may be revenue data. You haven't said finance used them or that you worked with finance on them. You have not worked on billing data | `[grounded]` your stated background; whether finance was involved is not established | Q3 |
| R8 | Owning billing data (responsibility) | must_have | absent | none | capability | You said you've never worked on billing data. Closure path in G4 | `[grounded]` your own statement | Carried as a named risk; no workaround wording |
| R9 | Pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance was a user isn't stated | `[grounded]` your stated work | A sanitized dashboard screenshot would raise it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Bristol terms and pay fit (R1, R2, hard_gate) | hard_gate | No location or pay floor from you | Either could fail the role regardless of fit elsewhere | — | Your own statement | `[grounded]` constraints not given |
| G2 | Forecast ownership (R6, must_have) | transferability | Pipeline reviews and dashboards, with finance owning the forecast | The posting has you running the forecast with the CFO. The bridge is credible with its limit named | Pipeline numbers you supplied that fed finance's forecast; commit or best-case calls you made; a forecast-vs-actual review you took part in | A sanitized pipeline review deck or forecast-accuracy view | `[grounded]` your statements; `[inferred]` that the pipeline review feeds a forecast |
| G3 | Finance and revenue data (R7, must_have) | discovery | Renewal dashboards, but no stated finance contact | A must-have that may close from work you already did | Renewal dashboards finance reviewed; reconciling CRM renewals to finance's revenue figures; monthly numbers agreed with finance | A dashboard screenshot or reconciliation note | `[grounded]` your statements; `[inferred]` renewal data counts as revenue data |
| G4 | Billing data (R8, must_have) | capability | You have not worked on billing data | No direct or adjacent evidence. It's a named responsibility, not a gate | Closure path: learn the billing system's data model before the interview, and ask what billing data means at Quillfield | A short billing-data primer you work through | `[grounded]` your statement; `[generic]` that billing data work varies by company |
| G5 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use, no model-building stated | "Modelling" is the posting's word, and daily use alone doesn't show it | Models you built for budgets, renewals or pipeline scenarios; reusable templates others relied on | A sanitized workbook | `[grounded]` your statement |
| G6 | B2B software employer (R3b, must_have) | discovery | A B2B payments company | Might be read as software or not | Product or platform work, subscription sales motion | Employer one-liner | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the company's own careers page | risk_signal | low | "Revenue Operations Lead, Quillfield" | The careers address I tried may not be where Quillfield lists roles, or the role is listed only on the job board. Quillfield exists as described and the hiring manager is publicly listed there, so severity stays low | `[inferred]` from one unanswered careers address against a confirmed About page | Can you point me at this role on your own careers page? | unresolved |
| RR2 | Forecast ownership versus the hiring manager's own title | unknown | — | "run the quarterly revenue forecast with the CFO" | The CFO and a Head of Revenue Operations may already share the forecast, which would change what "own" means for this role | `[inferred]` from the posting's wording against the manager's listed title | Who owns the forecast today, and what would this role own versus support? | unresolved |
| RR3 | Posted pay inside market band | positive_signal | — | "£61,500–£67,000" | The range sits within the interquartile range, near the median, so no seniority-pay mismatch is indicated | `[grounded]` posting figure; `[generic]` survey band | Where in the range would this post be offered? | noted |
| RR4 | Share options without terms | unknown | — | "plus share options" | Options are unquantified, so their value can't be weighed | `[grounded]` posting silent on terms | What is the option grant, vesting and strike basis? | unresolved |
| RR5 | "Billing data" undefined | unknown | — | "own our CRM and billing data" | It may mean subscription billing for Quillfield's own customers or invoice data from its product | `[inferred]` from the company's invoicing product against the posting's silence | Which billing system, and which data, does this role own? | unresolved |

## Application plan

Everything in this section is pending your approval, including the edit table and the advice below it. Nothing is final until you approve it.

`resume_edits_pending_approval`:

| # | Proposed line | Traces to your words | Status |
|---|---|---|---|
| E1 | "Revenue operations for the UK team (last 2 of 5 years in sales operations at a B2B payments company). Salesforce admin certified. Rebuilt the pipeline and renewal dashboards. Run the monthly pipeline review with the sales director." | "5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team"; "Salesforce admin certified"; "I rebuilt our pipeline and renewal dashboards"; "I run the monthly pipeline review with our sales director" | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Positioning advice: name finance's forecast ownership and the absence of billing-data work plainly, with the monthly pipeline review as your closest evidence. Lead with the payments sales-operations background | Tamsin Achebe's listed prior role was sales operations at a payments firm, so that background may read quickly to her | `[grounded]` her listed role; `[inferred]` that it reads quickly | pending your approval |
| A1 | Ask the recruiter for the role on Quillfield's own careers page before investing in the loop | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2 and RR5 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring manager row, RR2 and P1 |

I can also turn this into a `tuesday-dossier.md` you can keep or carry forward, if you'd like it.

## Upgrade menu

- Your CV, or confirmed dates and titles → R3a and R3b rows firm up, and E1 can be written against a baseline.
- A Salesforce certification record → R4 to `high`.
- A sanitized dashboard screenshot or pipeline review deck → R9 and G2 strengthen.
- A sanitized SQL sample or workbook → R5a to `high`, and R5b resolves.
- The recruiter's answers on the careers page, forecast ownership and billing data → RR1, RR2 and RR5 close.
- The option terms → RR4 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, public employee and candidate reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Questions:

1. G1 — Is Bristol with two office days a week workable for you, and does £61,500–£67,000 clear your floor?
2. G2 — Did finance's forecast take numbers from your pipeline review or dashboards? What did you supply and how often?
3. G3 — Did finance use or check your renewal dashboards? What data did they come from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.