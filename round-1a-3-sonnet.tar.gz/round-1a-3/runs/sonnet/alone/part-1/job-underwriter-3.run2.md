I'll read the reference files the skill requires before building the assessment.
**No. R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

Your instinct is borne out too: the role has problems of its own, apart from your two constraints. Those are in the opportunity ledger below.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin office 5 days a week), R2 (Compensation $70–85k base)
- `must_have` — direct: R4, R5 · unclear: R3 (8+ years growth leadership), R6 (SEO/content)
- `important` — unclear: R7 (Brand, PR, partnerships, sales ops), R8 (Team of one to start)

R1 — location conflict, no wording fixes it; R2 — pay conflict, same; R3 — your 9 years are in growth, with leadership years unstated; R6, R7 — your stated background is silent.

**Opportunity ledger.** Apart from fit, the posting is weakly specified. It folds several functions into one title with no stated team or budget (RR4). It sets the pay figure against that mandate (RR3). It signals always-on expectations (RR5), undefined success metrics (RR6) and unquantified equity (RR7). The employer is unverified (RR8). The CEO reporting line is the one positive (RR9).

- **Hard gates:** failed: R1 (On-site Austin office 5 days a week), R2 (Compensation $70–85k base).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the role's actual terms would have to include remote work and a base at or above $150k. The posting offers neither and says "no exceptions" on location. Wording cannot close either gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one", Austin office. Not verified from any source beyond the posting | `[grounded]` JD header; research did not run |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting line | CEO, "dotted line to the board" | `[grounded]` JD |
| Team and resources | "A team of one to start"; no budget, headcount plan or decision rights stated | `[grounded]` JD, for the team and the silence |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside", with no equity terms stated | `[grounded]` JD |
| Success measures | "Success metrics will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD |
| Scope read | Seven functions under one title, with the only staffing stated being yourself, reads as several roles bundled together | `[inferred]` from the JD's function list against "team of one" and its silence on budget |
| Market calibration | Not calibrated. The role-family search did not run, so no market band is given and none is implied | `[grounded]` search not run (see Evidence status) |
| Unknowns | Budget; equity terms; planned hires; what the board line means in practice; the metrics; whether the employer exists as described | `[grounded]` JD silence |
| Contradictions | A head-level title with an 8+ year bar and a board line sits beside a team of one and $70–85k base | `[inferred]` from the JD's own terms side by side |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin office 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the limit ("remote-only… I live in Portland and I'm not relocating"), which is specific and your own. The fit is a failed gate because the JD requires full on-site presence and rules out exceptions | `[grounded]` JD quote and your statement | Surface only; the employer changing terms is the one path (RR1) |
| R2 | Compensation: $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor ("at least $150k base"). The fit is a failed gate because the top of the posted range is $65k below it | `[grounded]` JD quote and your statement | Surface only (RR2) |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You state 9 years in growth, with growth lead then Head of Growth titles. How many of those years were in a lead or head role is not stated. Reading downward, the leadership years are not established. This is graded as experience, not as a gate | `[grounded]` your stated background | See G2 |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you "owned paid" and "controlled" a budget while scaling one company from $8M to $40M ARR over three years. Confirmed and specific, with no inspectable artifact yet, so expect a probe | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Same standing as R4: specific, with no artifact yet | `[grounded]` your stated background | none |
| R6 | SEO/content | must_have | unclear | none | discovery | Your stated background names paid, lifecycle, experimentation, SQL, GA4 and Braze, and says nothing of SEO or content. That is silence, not a confirmed absence | `[grounded]` absence in stated background | See G3 |
| R7 | Brand, PR, partnerships and sales ops | important | unclear | none | discovery | Nothing in your stated background touches these. Silence only | `[grounded]` absence in stated background | See G3 |
| R8 | Operating as a team of one to start | important | unclear | low | discovery | You built and managed teams of 3–7 and owned several channels. Hands-on solo execution of all of them is not stated | `[grounded]` your team sizes; `[inferred]` that ownership implied some hands-on work | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | On-site 5 days and $70–85k against remote-only and a $150k floor (R1, R2, hard_gate) | hard_gate | The posting states both terms flatly, "no exceptions" on location; your constraints are the opposite on both | Either one alone fails the gate, so the status is `no_go` whatever else fits | Nothing in your experience bears on this; only the employer's terms changing would | A written statement of the role's actual terms from the employer | `[grounded]` JD and your statements |
| G2 | When you first held a lead or head title (R3, must_have) | discovery | 9 years in growth are stated; the split between individual-contributor and lead or head years is not | The posting's bar is leadership years, and the prose establishes growth years | Dates of your growth lead role, then Head of Growth role, at each company | A CV with month-and-year dates for each title | `[grounded]` your stated 9 years and titles |
| G3 | SEO/content, and brand, PR, partnerships, sales ops (R6, R7) | discovery | Your stated background does not mention these | Only worth recovering if you pursue this or a similar bundled role | Owning an organic or content channel's targets; running a partner or affiliate program; managing a PR or agency relationship; owning a sales-ops or CRM-to-revenue handoff | Channel reports, a partner-program brief, an agency scope document | `[grounded]` background silence |
| G4 | Solo hands-on execution (R8, important) | discovery | Team leadership is stated; running every channel yourself is not | A team of one to start means doing the work, not directing it | Periods before or between hires when you ran channels yourself; launching a channel alone | A dated channel report from a period you ran solo | `[grounded]` your team sizes; `[inferred]` that this period may exist |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The role cannot be done from Portland on its stated terms | `[grounded]` JD quote against your stated constraint | Is five days on-site a fixed condition of this role? | confirmed |
| RR2 | Posted pay is below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted base ends $65k below your floor | `[grounded]` JD figure against your stated floor | What is the full base range budgeted for this role, and is it fixed? | confirmed |
| RR3 | Pay set against the seniority and mandate | risk_signal | medium | "8+ years growth leadership required… $70–85k base" | The figure may be low for the title and years asked; not calibrated because the market sweep did not run, so this stays a risk signal and not a finding | `[inferred]` from the JD's mandate and years bar against its pay figure | What do you see as the comparable market range for this level, and how was this range set? | unresolved |
| RR4 | Seven functions, no stated team, budget or decision rights | risk_signal | medium | "Own all revenue growth end to end… You will be a team of one to start" | Responsibility for outcomes without the resources or authority to produce them | `[inferred]` from the JD's function list against its silence on budget and headcount | What budget does this role control, and when and how does the team grow? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than occasional | `[inferred]` from the phrasing, which defines no limit on "when it matters" | How often did the last person in this function work evenings or weekends? | unresolved |
| RR6 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability to the CEO and board may rest on targets not yet defined | `[inferred]` from the JD's silence on first-year outcomes | What would success look like at 90 days and at 12 months? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | Equity may be real, but its size, vesting and strike price are not stated | `[inferred]` from the JD's wording with no terms attached | What percentage, vesting schedule and strike price come with this role? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | CEO reporting line with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board." | The role may carry real access and standing | `[grounded]` JD states the line | What does the board line involve in practice? | noted |

## Application plan

Every row is a proposal. None changes anything until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort unless the employer states different terms on location and base | see R1, R2, RR1, RR2 | `[grounded]` R1, R2 rows | pending your approval |
| Q1 | If you want to test it, put RR1 and RR2's questions to the employer through contact details on its own site, not through where you found this posting | A reply either closes the gates or confirms them | `[grounded]` register | pending your approval |
| A2 | If you proceed anyway, ask RR3 to RR7's questions verbatim in the first conversation; the register travels with you | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Search for head-level growth roles whose postings state remote work and a base at your floor; your background of teams of 3–7 and a controlled budget matches what such roles tend to ask | Filters on your two stated constraints | `[inferred]` from R1, R2 and your stated background | pending your approval |

`resume_edits_pending_approval`: none proposed in this pass.

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth careers"; the call was refused because search permission was not granted. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary Series A startup base salary range 2026"; refused for the same reason. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no one beyond "the CEO", so there was no query to form |

I'd be glad to put this in a `tuesday-dossier.md` if you want a record of it.

**Upgrade menu**

- Search permission → the two unrun L1 targets: whether Novaline's own site shows this role and matches the posting (RR8, role reality), and a role-family pay band for RR3. Neither can change the status, which the two failed gates fix.
- A deeper research pass on Novaline (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) → firms up RR8 and the opportunity ledger.
- A CV with month-and-year dates per title → R3 resolves.
- Channel reports or a dated solo-period summary → R8 and R6/R7 move off `unclear`.
- The employer's written terms (location, base, equity) → R1, R2, RR1, RR2 and RR7 close.

**Questions**

R1/R2 — Did this posting come with a recruiter or a hiring contact, and have you been quoted any terms that differ from it on location or base?
R3 — In which month and year did you first hold a growth lead title, and at which company?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.