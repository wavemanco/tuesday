I'll read the skill's reference files before building the assessment.
**Yes, apply, on three conditions. Status: `conditional_go`.** Your motor-insurance record lands `direct` on R2, R3, R4, R5, R6a and R7a. The pet-insurance gap sits at R10, a preferred row, and it is `adjacent`.

My web searches were refused, so nothing about Brindlemoor or the market has been checked from here. Only what you pasted is grounded.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6a, R7a · adjacent: R6b (Monitor rating models) · unclear: R7b (Design price tests)
- `important` — adjacent: R8 (Recommendations to underwriting and product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R6b — "maintained" is not yet "monitored"; R7b — "ran" is not yet "designed"; R10 (`medium`) — adjacency through motor rating, its limit named.

**Opportunity ledger.** The posting is concrete about the work (RR4), but it is silent on pay (RR1) and on team shape and decision rights (RR2). The employer is unverified from here (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and a live posting verify, see RR3; (2) UK location and work eligibility are confirmed, see R1; (3) pay and scope are acceptable to you, see RR1 and RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; not independently checked | `[grounded]` JD header |
| Mandate | "Own pricing analytics for our pet-insurance product: build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | `[grounded]` JD |
| Stated requirements | 4+ years pricing or actuarial analytics; strong SQL and Python; GLM experience; experience presenting to underwriting or actuarial leads; insurance experience a plus | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; public footprint not looked up | `[grounded]` your message |
| Line management | The JD asks for none and mentions no direct reports, so your never having managed anyone meets no stated requirement | `[grounded]` JD silence |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | An owner-level individual-contributor role, judging by "Own" and the absence of any team language. Team size and decision rights are unknown | `[inferred]` from "Own pricing analytics" against the JD's silence |
| Compensation | No figure in the posting. No market band was calibrated, and your floor wasn't given | `[grounded]` JD silence |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD fixes UK remote. You haven't stated your location or work eligibility. Working at a UK insurer suggests a UK base but doesn't establish eligibility | `[grounded]` JD quote; `[inferred]` UK base from your UK employer | Constraints question, closing block |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics at a UK motor insurer. That is self-report with no artifact seen, so `medium` | `[grounded]` your background statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use of both. Nothing inspectable yet | `[grounded]` your background statement | Upgrade menu: a sanitized notebook or query sample would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. Specific, but no artifact yet. Expect a probe on factors, validation and fit | `[grounded]` your background statement | Upgrade menu: a sanitized factor or relativity summary would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. That is underwriting, not actuarial, which the JD's "or" allows | `[grounded]` your background statement; `[grounded]` JD "or" | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM evidence as R4 | `[grounded]` your background statement | none |
| R6b | Monitor rating models | must_have | adjacent | medium | discovery | You said "maintained". Monitoring (tracking performance after launch) is not stated. Resolved downward, so adjacent | `[grounded]` your wording; the downward reading is a reasoning choice | G1 |
| R7a | Run price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Plainly stated and specific | `[grounded]` your background statement | none |
| R7b | Design price tests | must_have | unclear | low | discovery | "Ran" doesn't say who designed them. Nothing is claimed about design | `[grounded]` your wording | G2 |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | Underwriting side is evidenced (tests run with them, the quarterly review). The product side is not mentioned | `[grounded]` your background statement | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background statement | none |
| R10 | Pet-insurance product knowledge | preferred | adjacent | medium | transferability | The JD doesn't ask for it, but the role is for the pet product, so I carried it as an implied row. You have never worked on pet. The adjacency is motor GLM rating and price tests. The limit is that none of it touched pet-specific risk or claims behavior | `[inferred]` from the role's product against the JD's "insurance experience a plus" | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, must_have) | discovery | "Built and maintained" the GLM. No post-launch tracking is described | The JD pairs "build and monitor", so this decides whether the row is `direct` | Tracking actual-vs-expected loss ratios or claim frequency by segment; a recurring performance report; triggering a refit when the model drifted | A sanitized monitoring pack or dashboard screenshot | `[grounded]` your wording; `[inferred]` that this moves R6b |
| G2 | Designing price tests (R7b, must_have) | discovery | 14 tests run with underwriting. Who set the hypotheses, splits and success measures is not stated | Test design is named in the mandate | Choosing test and control cells; setting sample size or run length; deciding the success metric; writing the readout | A sanitized test plan or readout | `[grounded]` your wording; `[generic]` that design is often split from execution |
| G3 | Recommendations to product (R8, important) | discovery | The underwriting audience is evidenced and the product audience is not | JD names both audiences | A test result that changed a product feature or rating rule; presenting to a product owner | A review-deck excerpt | `[grounded]` your background; may close with G2's answer |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM and price tests carry over as method. Nothing touches pet | Preferred-tier, but the product is the whole role | Bridge: rating factors, tests and reviews are the same discipline. Limit: no pet claims or pricing behavior exercised. Strengthener: show how you'd approach the pet rating factors (age, breed, region and the like) in a short note | A short sanitized approach note | `[inferred]` bridge from your motor work; the limit is `[grounded]` in your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (posting as provided states no pay) | The figure may be below or above your floor, or the employer may not publish it | `[grounded]` posting silence | What salary range is budgeted for this post? | unresolved |
| RR2 | Team shape and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | Sole owner of pricing analytics, with unclear authority over rating changes and unclear plans for direct reports | `[inferred]` from "Own" against silence on team and authority | Who else is on the pricing team, does this role have or plan direct reports, and which rating changes does it decide itself versus recommend? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer. It is unchecked here because my searches did not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I'd interview with? | unresolved |
| RR4 | Responsibilities are concrete | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The scope is defined, though first-year success measures are not stated | `[grounded]` JD | What would a strong first year look like in this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV summary or first bullet with: "Built and maintained the GLM rating model for our young-driver book at a UK motor insurer" | R4, R6a; I haven't seen your CV, so there's no baseline line to compare | `[grounded]` your background statement | `resume_edits_pending_approval` |
| E2 | Bullet: "Ran 14 price tests with the underwriting team last year". Don't write "designed" until G2 is answered | R7a, R7b | `[grounded]` your background statement | `resume_edits_pending_approval` |
| E3 | Bullet: "Present the quarterly pricing review to the head of underwriting" | R5 | `[grounded]` your background statement | `resume_edits_pending_approval` |
| E4 | Cover-note line: "My pricing experience is in UK motor insurance, not pet: I built and maintained the GLM rating model for our young-driver book and ran 14 price tests with the underwriting team last year." | Names the pet gap up front and puts your two strongest matches first (R10, R4, R7a) | `[grounded]` your background statement | `resume_edits_pending_approval` |
| E5 | If line management comes up, say plainly that you haven't managed anyone. Don't suggest otherwise | No JD requirement; honesty is the defence if it's probed | `[grounded]` your statement and JD silence | pending your approval |
| A1 | Before investing effort, find the role on Brindlemoor's own careers page and confirm it is live | RR3 | `[grounded]` RR3 | pending your approval |
| Q1 | Ask the RR1, RR2 and RR4 verification questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row above is a proposal, covering the edits table and the cover-note, interview-framing and action rows. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; the call was refused. It would have moved role reality's organization row and RR3 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; the call was refused. It would have moved the market calibration, RR1 and the scope read |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have informed the scope read and which story the plan leads with |

## Closing

If you'd like, I can write all of this to `tuesday-dossier.md` for you to keep.

**Upgrade menu**

- Your CV, or sanitized artifacts (a GLM factor summary, a monitoring pack, a price-test readout or plan, a notebook or query sample, a review-deck excerpt). These move R2 to R7a toward `high` and may settle R6b and R7b.
- Allowing web search. I'd rerun the three declared targets: RR3, a pay band against RR1, and Odile Varga's public professional footprint.
- Deeper diligence (up to 5 more searches and 2 more fetches). Say the word and it runs.
- A link to the live posting or Brindlemoor's careers page. That settles RR3 without searching.
- Your pay floor and other non-negotiables. These settle R1, and let RR1 be checked against them.

**Questions**

1. R1 — What are your non-negotiables for this move (UK location and work eligibility, a pay floor, hours), so I can check them against the gate?
2. G1 — After your young-driver GLM went live, what did you do to monitor it: which measures, how often, who saw them, and what did you change as a result?
3. G2 — Of your 14 price tests, which parts did you design yourself, and what did you recommend to underwriting or product afterward?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.