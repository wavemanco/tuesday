Status: I've read the skill's rules and worked example. Next I'll read the remaining evidence rules, then run the research searches (company, pay band, hiring manager) before writing the assessment.
**Yes, apply, once you've confirmed the work pattern. `conditional_go`.** R2, R3, R4, R5a, R6, R7a and R8 are `direct`. R1 is a hard gate and unconfirmed: the posting says fully remote, but the company's own careers page says Leeds office four days a week.

# Job Underwriting Assessment: Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models), R7b (Recommendations for product)
- `preferred`: direct: R9

R5b: "maintained" is not yet monitoring; R7b: the product audience is not evidenced.

**Opportunity ledger.** The posting is live on the company's own site and its scope is clear. It contradicts itself on work pattern (RR1) and withholds pay (RR2). It is silent on direct reports (RR3). The reporting line is stated and the hiring manager has a public footprint in the role's area (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the work pattern is confirmed in writing as remote or hybrid on terms you accept (R1, RR1); (2) the monitoring and product-recommendation gaps are answered truthfully rather than papered over (R5b, R7b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The careers page confirms the product and that the posting is live. Size, funding and stage were not established | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing, Odile Varga | `[grounded]` JD; careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both read; contradiction, see RR1 |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Not asked for | The JD asks for neither people-management experience nor pet-insurance experience. Its only insurance line is "insurance experience a plus" | `[grounded]` JD |
| Scope read | A senior individual-contributor post. No reports or budget are named | `[inferred]` from the JD's silence |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books). She was previously head of pricing analytics at Calloway Re for six years. This is public professional footprint only, from a profile snippet I did not fetch | `[grounded]` search result |
| Monitoring emphasis | Her talk topic suggests model monitoring may weigh heavily with her | `[inferred]` from one talk title |
| Market calibration | A pay survey of UK insurers and insurtechs (n=612) puts senior pricing analysts at a median base of £58,400 (interquartile range £52,100 to £64,900). The posting withholds pay, so this is the band to expect, never Brindlemoor's offer | `[generic]` Pricewell 2026 survey result; `[grounded]` JD for the withheld pay |
| Unknowns | Pay; work pattern; direct reports; first-year outcomes; company size and stage | `[grounded]` JD and careers page silent |
| Contradictions | JD against the careers page on work pattern (RR1) | `[grounded]` both read |

## Evidence map

Your background was typed in prose, which counts as self-report. That is why the confidence bands top out at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have stated no constraint, so confidence is `none`. Fit is `unclear` because the JD and the careers page disagree. Your UK motor-insurer history suggests UK location is met | `[grounded]` JD and careers page; `[inferred]` UK base from your employer | Question R1 below; RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics, the last 2 as senior analyst. Self-report, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; no artifact yet | `[grounded]` your background | A code sample or description of a pipeline would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | A sanitized model summary would raise it |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM build as R4. Limit: a motor young-driver book, not pet | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" suggests, but does not establish, performance monitoring such as actual versus expected, drift and segment checks | `[inferred]` from "built and maintained" | Question G1 |
| R6 | Design and read price tests | must_have | direct | medium | presentation | You ran 14 price tests last year with the underwriting team. The count is strong evidence that may be buried in a CV, which I haven't seen | `[grounded]` your background | Edit E1; sanitized test write-up W1 |
| R7a | Recommendations for underwriting | must_have | direct | medium | none | Tests were run with underwriting, and you present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7b | Recommendations for product | must_have | unclear | low | discovery | Nothing you've said involves a product owner | `[grounded]` silence in your background | Question G2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer. Pet is a different line, and that limit is named wherever the point is used | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R5b, must_have) | discovery | "Maintained" the GLM; no mention of how performance was tracked or what happened when it slipped | The role names monitoring and the hiring manager has a public talk on it, so the gap is worth closing | Actual-versus-expected tracking by segment; drift or stability checks; a recalibration after a poor result; a periodic model-health report | A sanitized monitoring dashboard, a review slide, or a recalibration note | `[grounded]` CV-equivalent silence; `[inferred]` weight from the talk |
| G2 | Recommendations for product (R7b, must_have) | discovery | Underwriting audience evidenced; product audience not | The JD names both audiences | A price-test result taken to a product or proposition owner; a test that changed an offer, feature or cover level | A recommendation memo or a decision note | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Work pattern differs between JD and careers page (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the role's terms may have changed, or the JD may be a different variant of the post | `[inferred]` from two sources that disagree; no reason ranked as likely | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pay withheld | unknown | — | JD gives no figure | The figure may sit anywhere in the survey band or outside it | `[generic]` survey band against `[grounded]` JD silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Direct reports unstated | unknown | — | "Own pricing analytics" | The post may be an individual-contributor role or may carry reports now or later | `[inferred]` from the JD's silence | Does this role have direct reports, now or planned? | unresolved |
| RR4 | Reporting line and scope stated | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | Scope and reporting line are concrete, and the manager's public work overlaps the role | `[grounded]` careers page; `[inferred]` overlap from one talk title | What would success look like in the first year, and what does model monitoring look like today? | noted |

## Application plan

All items are proposed and pending your approval. I haven't seen your CV, so the language below is direction, not final wording.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing in interviews, ask through the application channel on brindlemoor.co.uk whether the role is remote or Leeds four days a week | See RR1, R1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with three facts as you stated them: you built and maintained the young-driver GLM rating model; you ran 14 price tests last year with underwriting; you present the quarterly pricing review to the head of underwriting. No new claims | See R4, R6, R8 | `[grounded]` your background | pending your approval |
| E2 | Claim monitoring and product-recommendation experience only after G1 and G2 are answered | See R5b, R7b | `[grounded]` map rows | pending your approval |
| W1 | A one-page sanitized write-up of one price test: design, read-out, recommendation | Raises R6 and may help R7b | `[grounded]` R6 | pending your approval |
| P1 | Be plain that you haven't worked on pet insurance, and frame your motor GLM work as adjacent, not as pet pricing. Pet pricing likely uses factors motor does not, such as breed and age, so name that as something to learn | See R9; the JD asks only for "insurance experience a plus" | `[grounded]` your background; `[generic]` pet rating factors | pending your approval |
| P2 | Don't volunteer "never managed anyone". The JD doesn't ask for it, so ask RR3 first | See RR3 | `[grounded]` JD | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4's questions in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned no results, and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live and the product, and exposed the work-pattern contradiction (R1, RR1). Company size and funding are not established |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It supplied the market calibration band in role reality and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It supplied the hiring-manager row and the monitoring emphasis in role reality, and RR4. I did not fetch it |

I can save this as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Your CV → rows move from self-report toward `high` where artifacts exist, and E1 becomes concrete wording.
- A sanitized price-test write-up or model summary → R6, R3 and R4 can reach `high`.
- Your pay floor → RR2 gets set against the survey band.
- Your answer on remote → R1 resolves to `direct` or `hard_gate_fail`.
- A deeper research pass on Brindlemoor (funding, leadership changes, public reports, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

1. **R1:** Is working fully remote a requirement for you, or would four days a week in Leeds be workable?
2. **G1 (R5b):** Beyond maintaining the young-driver GLM, did you monitor it after release (for example actual-versus-expected by segment, or drift)? What did you do when it slipped?
3. **G2 (R7b):** Have you taken a price-test result to a product or proposition owner rather than underwriting? What did you recommend, and what was decided?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.