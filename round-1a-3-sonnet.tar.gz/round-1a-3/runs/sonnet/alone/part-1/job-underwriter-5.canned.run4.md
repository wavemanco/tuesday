I'm reading the skill's remaining rules, on the decision snapshot, output format and research tiers. Then I'll write the assessment.
**Yes, it's worth applying, on conditions: R3, R4, R5, R6, R7 and R8 are `direct`, and R1 and R2 (location and pay) are yours to confirm · `conditional_go`**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery); unclear: R10 (ingestion from app and CRM), R11 (data contracts)

R9 — a credible bridge, its limit named; R10, R11 — your background as given is silent on them.

**Opportunity ledger.** Pay is stated and the stack is named (RR1, RR6). Open items are team shape and on-call (RR2), first-year outcomes (RR3), equity terms (RR4), and funding and headcount that only the company's own pages support (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 — you're in the US, or willing to be in Denver; (2) R2 — the range clears your own floor; (3) R9 — BigQuery is framed honestly as adjacent, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, matching the text you pasted |
| Posting status | Live on the company's careers page, "Accepting applications", with text identical to what you pasted | `[grounded]` careers page fetched |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Requirements as listed | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Implied by the description | BigQuery specifically, ingestion from app and CRM, and data contracts are in the description, not the requirements list. I tiered them `important` | `[inferred]` from the role description against the requirements list |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | One end-to-end domain (ingest, model, contract) with no direct reports stated. This matches the typical scope in the pay report | `[inferred]` from the JD's mandate against the report's typical-scope line |
| Market calibration | Series B–D senior data engineers: base median $151,000, interquartile range $139,000–$163,500, "senior" typically 5–8 years. Your 6 years sits inside that. This is a pattern, not Pellucid's offer. The comparison with the posted range is in RR1 | `[generic]` Datawright 2026 Pay Report, n=2,310, as sent by your recruiter |
| Unknowns | Hiring manager (not named), team size, on-call, equity terms, first-year outcomes | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and the live page | `[grounded]` careers page fetched |

## Evidence map

I haven't seen your CV, only the prose background you gave. That is self-report, so `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Confidence grades your statement of the constraint, and none was given. Fit is `unclear` because I don't know where you are or what you want | `[grounded]` JD term, no candidate constraint supplied | G1's question |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Same logic: no floor was given, so I can't say whether the range clears it. The range itself is market-normal (RR1) | `[grounded]` JD figure, no candidate floor supplied | G1's question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company, which is above the 5+ bar | `[grounded]` your background prose | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is the JD's word and your evidence is daily use, so I took the lower band | `[grounded]` your background prose | a code sample would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models | `[grounded]` your background prose | sanitized dbt docs or a lineage screenshot would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the JD asks for "a cloud warehouse", not BigQuery specifically | `[grounded]` your background prose and the JD wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration | `[grounded]` your background prose | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your background prose | a sanitized suite config or a check summary would raise it |
| R9 | BigQuery (named in the role description) | important | adjacent | medium | transferability | Carries over: dbt and warehouse SQL on Snowflake. Limit: you have never used BigQuery, and nothing you've described exercised its specifics. `[generic]` Cloud warehouses differ in how they are administered and billed | `[grounded]` your stated gap; `[inferred]` requirement from the role description; `[generic]` warehouse differences | G4's bridge and work sample |
| R10 | Ingestion from the app and a CRM | important | unclear | low | discovery | Your background doesn't say which sources your pipelines ingested | `[grounded]` background silence | G2's question |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't mention contracts. The Great Expectations suite is adjacent, but I won't call it contracts without your word | `[grounded]` background silence; `[inferred]` adjacency from the test suite | G3's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | The posting allows Remote (US) or Denver and states $148,000–$166,000; I have neither your location nor a floor | Either term could end this regardless of fit, and the answer is a fact, not a recall | Not a recall gap: the terms fit or they don't | none needed | `[grounded]` JD terms; no candidate constraints supplied |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Nothing on what fed your pipelines | The description names this as core work, and a real example would turn the row direct | Event or API data from a product; a CRM sync (Salesforce, HubSpot or similar); webhook or batch loads you built or maintained | A pipeline diagram, a DAG screenshot, a design note | `[grounded]` background silence; `[inferred]` importance from the role description |
| G3 | Data contracts (R11, important) | discovery | Nothing on explicit producer–consumer agreements | The JD names "the data contracts our analysts depend on" as part of the mandate | Agreed schemas or freshness expectations with an upstream team; ownership and SLA notes on key tables; schema-change processes with analysts | A contract doc, a schema-change policy, a dbt model contract config | `[grounded]` background silence; `[inferred]` importance from the role description |
| G4 | BigQuery (R9, important) | transferability | Snowflake plus dbt, no BigQuery use | The bridge is credible but unproven in this specific warehouse | Any exposure to BigQuery through a side project, a vendor dataset, or an analyst workflow | A small public repo running dbt on BigQuery | `[grounded]` your stated gap; `[inferred]` bridge from Snowflake and dbt |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range's midpoint is $157,000. Its low end is $3,000 under the $151,000 median and its high end is $2,500 over the $163,500 upper quartile, so there is no seniority–pay mismatch at 5+ years. The report's figures are a pattern, not Pellucid's offer | `[grounded]` JD figure; `[generic]` Datawright band | Where in the range would my experience land? | noted |
| RR2 | Team shape and on-call unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | "Build and run" may carry support and on-call duty, and the JD gives no team size or reporting lines. The report's typical scope is one domain with no direct reports | `[inferred]` from JD silence; `[generic]` report's typical scope | How many data engineers are there, and what is the on-call expectation? | unresolved |
| RR3 | No first-year outcomes or hiring manager named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Success may be defined only in the interview | `[inferred]` from JD silence | What would success look like at 90 days and at 12 months, and who would I report to? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The JD gives no type, amount or vesting, so its value can't be compared | `[inferred]` from JD silence | What is the equity grant (type, amount, vesting)? | unresolved |
| RR5 | Funding and headcount rest on the company's own pages | unknown | — | "264 employees. Series C ($52M, February 2026)" | My one search returned only the company's own about page. That is a thin check and says little either way | `[grounded]` search result list | What does the data team's roadmap look like, given the Series C? | unresolved |
| RR6 | Stack and responsibilities named concretely | positive_signal | — | "a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The posting says what the work is, and the live page matches it | `[grounded]` JD and fetched page | Which parts of that stack exist today and which would I build? | noted |

## Application plan

All of these are proposals. I haven't seen your CV, so the edits work from your background prose.

`resume_edits_pending_approval`

| # | Current framing (your words) | Proposed | Why | Provenance | Status |
|---|---|---|---|---|---|
| E1 | "Built our dbt project on Snowflake — about 180 models" | Make it a lead bullet: "Built the dbt project on Snowflake — about 180 models" | R5 and R6 | `[grounded]` your background prose | pending your approval |
| E2 | "Set up our Great Expectations test suite" | Make it its own bullet, in your words | R8 | `[grounded]` your background prose | pending your approval |

Both lines trace clause by clause to your sentences and add no scope, outcome, or verb beyond "built" and "set up".

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the application with dbt, Airflow and the Great Expectations suite, then say plainly that your warehouse is Snowflake and you haven't used BigQuery | Matches R5, R7, R8, R9 | `[grounded]` your background prose | pending your approval |
| W1 | Build a small dbt-on-BigQuery project on a public dataset, only if the application is a go | Turns G4's bridge into something inspectable | `[inferred]` from R9's limit | pending your approval |
| A1 | Confirm your location and floor before spending effort | R1, R2 | `[grounded]` map rows | pending your approval |
| Q1 | Ask RR2, RR3, RR4 and RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), which showed the posting live with identical text. Searched "Pellucid Learning Series C $52M online tutoring K-12 Denver", which returned only "About Pellucid Learning" (pellucidlearning.com/about), matching your pasted text. Both calls checked your pasted material. They moved role reality's posting-status and contradictions rows and RR5 |
| 2. Role-family sweep | skipped | The Datawright report you pasted has the figures in hand, and it fixes the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

If you'd like it, I can write this up as `tuesday-dossier.md`.

## Upgrade menu

- Your CV, or a sanitized dbt docs page or lineage screenshot → R5, R8 and the other `must_have` rows could reach `high`.
- Your location and pay floor → R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- The employer's answers on team shape, outcomes and equity → RR2, RR3 and RR4 close.
- The hiring manager's name → the scope read, and which of your stories to lead with.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches) → RR5 and the risk register. Say the word and it runs.

**G1 (R1, R2)** — Are you based in the US (or happy to be in Denver), and is there a base-salary floor below which this isn't worth pursuing?

**G2 (R10)** — Which source systems fed your pipelines at the payroll company (app events, a CRM, third-party APIs), and what did you personally build to ingest them?

**G3 (R11)** — Did you ever set an explicit agreement (schema, freshness, ownership) between the producers of a table and the analysts who used it, and what was yours to define?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.