Running the two L1 searches the skill calls for: Quartzline's own site and careers page, then a market sweep for API product manager roles.
Search permission was denied, so I couldn't check Quartzline's site or the market. I ran this on your resume and the JD alone, and the Evidence status table shows what that cost.

# Job underwriting: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, Nadia, this isn't a waste of time, but a cold application starts at a disadvantage. R1 (3+ years PM experience) is absent as a titled term, while R3 and R7a land `direct` and R2, R4 and R5 are credible bridges. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R7a · adjacent: R2 (Shipped API or platform products), R4 (Roadmap ownership and partner discovery), R5 (Specs and delivery with squads) · absent: R1 (3+ years PM experience)
- `important` — unclear: R6 (Adoption metrics), R7b (Sales and launch coordination), R8 (Agile delivery)

R1 — a literal miss on a years term, not a gate; R2, R4, R5 — credible bridges, each limit named; R3 (`medium`) — confirmed, waiting on an artifact.

**Opportunity ledger.** The mandate is concrete (RR5), but the employer and posting are unchecked (RR1), the years term may be screened literally (RR2), pay and location are unstated (RR3), and decision rights are unspecified (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, RR1; (2) a recruiter or referrer confirms a no-PM-title profile with adjacent work is considered, R1 and RR2; (3) the bridges in R2, R4 and R5 are framed as adjacent, never as owned PM work.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not checked against any outside source | `[grounded]` JD header only |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | One product area with two squads, so a single-platform PM post rather than a portfolio role | `[inferred]` from the squad count and the single named platform |
| First-year outcomes | Not stated. Defining adoption metrics looks like an early deliverable | `[inferred]` from the responsibility "define and track adoption metrics" |
| Market calibration | Not available. The role-family sweep did not run and the JD states no pay, so there is no band to set against | `[generic]` nothing asserted |
| Unknowns | Pay, location or remote policy, reporting line, decision rights over the roadmap, what "shipped" means, whether 3+ years is screened by title | `[grounded]` JD silence |
| Contradictions | None between your resume and the JD. The JD against Quartzline's own careers page is unchecked | `[grounded]` inputs compared; careers page not reached |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | absent | none | capability | You say you have never held a PM title, so titled years are absent. The adjacent work sits in R2, R4 and R5. Postings that mark years as must-have are often filtered by title before anyone weighs adjacent work | `[grounded]` your statement; `[generic]` screening pattern | Claim no PM years. Test with RR2's question and a referral |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | CV: "Led 30+ client integrations of our REST APIs end to end". That is the implementer side of an API product. Nothing says you owned or shipped one. Limit: integrations of the vendor's APIs are not products you owned | `[grounded]` CV and JD quotes | G1 may surface a shipped internal tool; G2 holds the bridge |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | CV: Postman, SQL, reading OpenAPI specs, plus 30+ client integrations with integration architecture. Confirmed and specific, no inspectable artifact yet, so expect a probe | `[grounded]` CV | Offer: a sanitized architecture diagram would raise to `high` |
| R4 | Roadmap ownership and discovery with integration partners | must_have | adjacent | medium | transferability | CV: "Ran quarterly roadmap-input sessions collecting client feedback for product", plus scoping workshops with clients. Input to a roadmap, not ownership of one. The workshops are the closer match to partner discovery | `[grounded]` CV | G3 |
| R5 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | CV: requirements documents, integration architecture, and coordinating "our engineers, the client's engineers, and product managers on custom builds". Those were client build specs and coordination. No claim of driving squads or owning a delivery plan | `[grounded]` CV | G3 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | CV is silent on metrics. An unconfirmed note from an earlier conversation mentions an internal request-triage tool that support agents adopted. It is a lead only, with no ownership, scope or numbers confirmed | `[grounded]` CV silence; `memory_lead` unconfirmed | G1 |
| R7a | Stakeholder management across engineering and customers | must_have | direct | medium | none | CV: coordinated your engineers, client engineers and product managers, with 30+ client integrations through UAT and go-live. Specific and confirmed, no artifact | `[grounded]` CV | none |
| R7b | Stakeholder management with sales; launch coordination with sales and support | important | unclear | low | discovery | CV does not mention sales or support partners. Solutions roles commonly touch sales, but your CV does not say you did | `[grounded]` CV silence; `[generic]` role-family pattern | G4 |
| R8 | Agile delivery | important | unclear | low | discovery | CV names no sprint, backlog or squad rhythm. Coordinating custom builds with engineers may have run on one, but nothing confirms it | `[grounded]` CV silence | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics and a possible shipped tool (R6, important; also bears on R2) | discovery | The CV is silent on metrics. The triage-tool lead is unconfirmed | It could turn R2 and R6 from thin to concrete, the two PM-shaped gaps you can still affect | Owning a tool's backlog or intake; tracking who used it and how often; deciding what to build next from agent feedback; a before/after number | A one-page brief, a usage chart, a launch note, a spec | `[grounded]` CV silence; `[inferred]` it could move R2 and R6 |
| G2 | Shipped API or platform products (R2, must_have) | transferability | Adjacent: 30+ client integrations of your employer's REST APIs and a team playbook. Limit: you implemented against APIs and did not own one | The JD's phrase is "shipped API or platform products". An unframed bridge reads as a miss | Feedback you sent back that changed an API or its docs; a recurring integration problem you got fixed | A sanitized playbook excerpt, a ticket that led to an API change | `[grounded]` CV; `[generic]` how this phrase is usually read |
| G3 | Roadmap and spec work (R4 and R5, must_have) | transferability | Adjacent: roadmap-input sessions, requirements documents. Limit: input and client-build specs, not roadmap ownership or squad delivery | These are the core duties of the post | A requirement you wrote that engineering built into the product; a client request you argued for in a roadmap discussion | A requirements document, a roadmap-session summary | `[grounded]` CV; `[generic]` that these are the core duties |
| G4 | Sales and launch coordination (R7b, important) | discovery | The CV is silent on sales and support | The JD names sales and support for launches | Joining sales calls to scope an integration; handing a finished integration to support | A handoff doc, a pre-sales scoping note | `[grounded]` CV silence |
| G5 | Agile delivery (R8, important) | discovery | No delivery rhythm is stated | A listed requirement with nothing behind it | Sprint ceremonies on custom builds; backlog grooming with engineers | A board export, a sprint plan | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | No search ran, so the company and posting are unchecked. It may be new or small, the posting may be stale, or it may not represent a real hiring employer, none ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | A years requirement that may be screened literally | risk_signal | medium | "3+ years product management experience (must-have)" | A resume screen may filter on PM titles before adjacent work is read | `[inferred]` from the "(must-have)" label against your titles | Would you consider someone with seven years in solutions engineering and no PM title, if their work matched the responsibilities? | unresolved |
| RR3 | Pay and location unstated | unknown | — | JD lists no pay or location | The band or the work arrangement may not fit what you need | `[grounded]` JD silence | What is the pay range, and is the role remote, hybrid or office-based, and where? | unresolved |
| RR4 | Roadmap ownership without stated decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Roadmap calls may sit with product leadership or an engineering lead | `[inferred]` from the JD's silence on reporting line and decision rights | Who does the role report to, and which roadmap decisions does it make alone? | unresolved |
| RR5 | Concrete mandate | positive_signal | — | "run discovery with integration partners; … define and track adoption metrics" | Duties and the partner audience are specific. Partner-facing integrations are the work you have done | `[grounded]` JD; `[inferred]` overlap with your integration work | Which adoption metrics are tracked today? | noted |

## Application plan

Everything below is proposed. Nothing is final until you approve it.

**Resume edits: `resume_edits_pending_approval`.** These only reorder and re-word your own sentences.

| # | Current | Proposed | Audit |
|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product." | "Ran quarterly sessions collecting client feedback as input to the product roadmap." | Stays input, not ownership |
| E2 | Playbook line near the bottom | Same sentence, moved to the top: "Wrote the internal integration playbook the whole team uses." | Wording unchanged |

**Positioning advice, pending your approval.** In the cover note, say only what is yours: "For seven years I've worked on the implementation side of our REST APIs, taking 30+ client integrations from scoping to go-live, and I'm now looking to move into product management." Do not call the integration work product ownership.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask a contact at Quartzline for a referral or a short conversation before applying cold | See RR2 | `[generic]` how hiring often works at companies of this size | pending your approval |
| A2 | Ask the recruiter RR2's and RR3's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | A one-page sample: adoption metrics for a hypothetical partner API, labeled as a sample, never as experience | Narrows the limit in G2 and R6 | `[inferred]` strengthener for the gap | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: the request-triage tool from earlier conversation, a lead for G1 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company careers Product Manager Platform APIs"; refused, no permission. Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "platform API product manager B2B Series B requirements salary solutions engineer transition"; refused, no permission. Would have moved the market-calibration row and RR2 and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this as `tuesday-dossier.md` if you'd like to carry it forward.

## Upgrade menu

- Permission to search → RR1, the contradictions row and the market-calibration row. A deeper pass on Quartzline (up to 5 more searches and 2 more fetches) is available after that.
- A product spec, roadmap doc, launch plan or adoption dashboard from the triage tool → R6 and R2 can rise from thin to `medium` or `high`.
- A sanitized playbook excerpt or an integration architecture diagram → R3, R4 and R5 rise.
- Your constraints (pay floor, location, remote needs) → hard-gate rows appear and the Hard gates line stops saying "not given".
- The hiring manager's name → role reality's scope read and which story to lead with.

## Questions

G1 — Did you build or run the request-triage tool support agents used? What did you own, how did you know agents adopted it, and is there a spec, chart or note I could look at?

G4 — On custom builds, did you work with sales or support, for example in scoping calls or handoffs at go-live, and what was your part?

Constraints — What are your must-haves on pay floor, location or remote, and anything else non-negotiable?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.