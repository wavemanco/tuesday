Output is being truncated; I'll read the essential files individually.
**Yes, worth applying to, as a stretch you should price in. Status: `conditional_go`.**

I read the posting, checked Quillfield, and benchmarked the pay. The stretch is R6 (forecast ownership), R7 (finance revenue data) and R10 (billing data).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3a, R4 · adjacent: R5 (strong SQL and spreadsheet modelling), R6 (experience owning a forecast), R7 (working with finance on billing or revenue data) · unclear: R3b (at a B2B software company)
- `important` — direct: R8 · adjacent: R9 (own CRM data), R11 (run quarterly forecast with the CFO) · absent: R10 (own billing data)

R6 and R7 are real bridges with their limits named; R10 has no billing-data work behind it.

**Opportunity ledger.** The posting is open about pay and place (RR2) and the employer was found (see role reality, Organization). Open items are breadth of scope (RR1), the option terms (RR3) and the listing's presence on Quillfield's own site (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 meet your own limits; (2) RR1 verifies in interviews: how much forecast and billing-data ownership is expected from week one, and who owns them today; (3) R6, R7 and R10 are presented as the gaps they are, never as experience (see the application plan).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about, from search |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` JD |
| Reporting line | Hiring manager per the recruiter is Tamsin Achebe. Her public profile lists her as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The JD names no reporting line or team size | `[grounded]` your recruiter's statement and her profile page, as a search snippet |
| First-year outcomes | None stated in the posting | `[grounded]` JD silence |
| Scope read | Five duties span sales operations and finance data (CRM, billing, pipeline reporting, renewal reporting, forecast). The post sits under a Head of RevOps, so forecast ownership may be shared rather than sole | `[inferred]` from the duty list and the manager's title |
| Market calibration | The posted band is near the median for a UK B2B software revenue operations lead, £64,200 (IQR £57,800–£70,400, n=438). The guide is UK-wide, not Bristol-specific, and the posting's own band is the only figure that is Quillfield's | `[generic]` Ledgerline 2026 pay guide; `[grounded]` JD for the posted band |
| Unknowns | Team size; who owns the forecast and billing data today; billing system; option terms; first-year outcomes | — |
| Contradictions | None found. The JD wording is consistent with the company's about page | `[grounded]` JD against about page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You gave no location or commute limits, so whether this term is met is unestablished | `[grounded]` no constraint stated | Question R1/R2 below |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | No pay floor given. The band is stated, but whether it clears your floor is unknown | `[grounded]` JD figure; no floor stated | Question R1/R2 below |
| R3a | 4+ years in revenue operations, sales operations or similar analytics role | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. Confirmed in your message, no CV yet | `[grounded]` your statement | CV would raise to `high` |
| R3b | At a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether its product is software is not stated | `[grounded]` your statement; the JD wording on sector | Add a line on what your employer sells, if software |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. Day-to-day admin tasks not described. A certificate is an inspectable artifact: an ID or link would raise it | `[grounded]` your statement | Share the certification record |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly, Excel daily is frequency of use. "Modelling" and its strength are not stated | `[grounded]` your statement; `[generic]` that "strong" is usually probed by a task | Describe one model you built, if any |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | Adjacent: you run the monthly pipeline review with your sales director. Limit: finance owned the company forecast, so you have not owned one. Name that limit wherever this is used | `[grounded]` your statement | See G1 |
| R7 | Working with finance on billing or revenue data | must_have | adjacent | low | discovery | You rebuilt pipeline and renewal dashboards, which is revenue-side reporting. Working with finance on it is not stated, and you have never worked on billing data | `[grounded]` your statement | See G2 |
| R8 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. The finance audience is not stated | `[grounded]` your statement | A sanitized screenshot would raise to `high` |
| R9 | Own the CRM data | important | adjacent | low | discovery | Certified and ran RevOps for the UK team, but ownership of CRM data and its scope are not stated | `[grounded]` your statement | See upgrade menu |
| R10 | Own billing data | important | absent | none | capability | You have never worked on billing data. No direct or adjacent evidence is in hand | `[grounded]` your statement | See G3 |
| R11 | Run the quarterly revenue forecast with the CFO | important | adjacent | medium | transferability | Adjacent: a monthly pipeline review with a sales director. Limit: different counterpart, cadence and purpose, and not a forecast | `[grounded]` your statement | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, `must_have`; R11) | transferability | A monthly pipeline review with your sales director. Finance owned the forecast | The most senior duty in the posting and a named requirement, so the bridge and its limit decide how the application reads | Pipeline or renewal numbers you supplied that finance used; a coverage or commit view you maintained; tracking how far past pipeline landed against plan | A pipeline-review deck or a renewal-forecast sheet, sanitized | `[grounded]` your statement; `[generic]` that forecast ownership is usually probed |
| G2 | Finance-side revenue data (R7, `must_have`) | discovery | Renewal dashboards, with no stated finance counterpart or data source | Moves R7 from `low` and decides whether R10 has any adjacent bridge | Reconciling renewal values with finance; sourcing contract or invoice values for dashboards; a month-end or quarter-end data request from finance | A dashboard data-source note or a reconciliation sheet, sanitized | `[grounded]` your statement; `[inferred]` that the renewal data may touch finance sources |
| G3 | Billing data ownership (R10, `important`) | capability | No billing-data work | The product is invoicing software, so billing data is central to the post | None to name yet. G2's answer may change this | Closure path: learn the billing data model in interviews and early onboarding. Carry it as a material risk | `[grounded]` your statement; `[generic]` that billing-heavy roles lean on it |
| G4 | B2B software employer (R3b, `must_have`) | discovery | Employer described as a B2B payments company | A literal screen on sector could catch it | Whether your employer's product is a software platform | A one-line description of your employer's product | `[grounded]` your statement; `[generic]` that sector wording is sometimes screened literally |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Breadth of mandate, support not stated | unknown | — | "You will own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO." | Wide scope, with finance-system depth possibly expected from the first quarter; team size and tools unstated | `[inferred]` from the duty list against the JD's silence on team size | What does the team around this role look like, and who owns the forecast and the billing data today? | unresolved |
| RR2 | Pay and place stated, inside the benchmark range | positive_signal | — | "Bristol, hybrid: two days a week in the office. Salary £61,500–£67,000 plus share options." | Open terms on pay and place; the figure sits inside the benchmark range | `[grounded]` JD; `[generic]` Ledgerline 2026 range | Where in the band does this role sit for the experience you are seeking? | noted |
| RR3 | Share option terms unstated | unknown | — | "plus share options" | The options may be material or nominal | `[generic]` pattern for early-stage equity, not a claim about this employer | What is the option grant for this role, and what are the vesting terms and strike price? | unresolved |
| RR4 | Posting not located on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield" | One guessed careers address returned no page; the role may be listed elsewhere on the site or only on the job board | `[inferred]` from one failed fetch at a guessed address | Is this role listed on Quillfield's own site, and who is the contact for it? | unresolved |

## Application plan

Nothing in this plan, the table below or the positioning lines, is final until you approve it; this covers the prose advice and the table alike.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm for yourself that the pay and the two Bristol office days fit your own limits before investing in the application | see R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | In the application and the loop, say plainly that finance owned the forecast at your employer and you ran the pipeline review with your sales director. Say you have not worked on billing data. Do not call either "forecast ownership" or "billing experience" | see R6, R10 | `[grounded]` your statements | pending your approval |
| A3 | Ask RR1, RR3 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Lead with the rebuilt pipeline and renewal dashboards, the story closest to the posting's own "pipeline and renewal reporting". Her public profile shows a sales-operations path into revenue operations | see R8 | `[grounded]` your statement and her profile; `[inferred]` that this is the nearest story | pending your approval |

`resume_edits_pending_approval` — each line below traces to your own sentence:

| # | Your words | Proposed line | Status |
|---|---|---|---|
| E1 | "I rebuilt our pipeline and renewal dashboards" | Rebuilt our pipeline and renewal dashboards | `resume_edits_pending_approval` |
| E2 | "I run the monthly pipeline review with our sales director" | Run the monthly pipeline review with our sales director | `resume_edits_pending_approval` |
| E3 | "the last 2 running revenue operations for the UK team" | Ran revenue operations for the UK team for the last 2 years | `resume_edits_pending_approval` |

## Evidence status

Verified: none yet. Your background is self-reported and no CV, link or certificate has been inspected, so it sits at `medium` or below.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: Organization row (employer exists as described) and RR4 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), seen only as a search snippet, no page fetched. Moved: reporting-line row and A4 |

## Upgrade menu

- A CV or the Salesforce certification record → R3a, R4 toward `high`.
- A sanitized dashboard screenshot or a pipeline-review pack → R8 and R6 gain an inspectable artifact.
- A one-line description of what your employer sells → R3b resolves.
- A model you built in Excel or SQL → R5 firms up.
- Your pay floor and location limits → R1 and R2 resolve, and the decision becomes `go` or `no_go` on the gates.
- The recruiter's answers on team and billing system (RR1), option terms (RR3) and the live listing (RR4) → those entries close.
- A Bristol-specific pay band → the market calibration narrows.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → the register strengthens; say the word and it runs.

I can also write this up as `tuesday-dossier.md` if you want to keep it or carry it into later steps.

**Questions**

R1/R2 — Do £61,500–£67,000 and two days a week in Bristol both meet your own limits on pay and commute?

G1 — Did any of your pipeline-review output feed finance's forecast? If so, what did you personally own, who relied on it, and how did you know how close it was?

G2 — Have you worked with finance on revenue-side figures such as renewals, contract values or invoicing data? If so, which systems or tables, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.