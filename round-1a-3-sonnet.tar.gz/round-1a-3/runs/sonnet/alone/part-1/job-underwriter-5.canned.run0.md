I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, this looks worth applying to. R3, R4, R5, R6 and R7, the five `must_have` rows, are all `direct`. Status: `conditional_go`.** The condition is that the two location and pay gates, which you haven't stated terms for, check out.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (warehouse in BigQuery) · unclear: R9 (ingestion from our app and CRM), R10 (data contracts our analysts depend on)

R8 — a credible bridge from Snowflake, its limit named; R9, R10 — unestablished, waiting on your answer to G2.

**Opportunity ledger.** The pay is posted and the scope is concrete (RR1). Equity terms and the team around the role are not stated (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm that R1 and R2 fit your own terms (G1).
  2. The BigQuery bridge in R8 is presented as adjacent, never as BigQuery experience.
  3. The team and scope in RR3 check out in the interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the pellucidlearning.com/about page, seen as a search result; the funding is not corroborated outside the company's own site |
| Posting status | Live, marked "Accepting applications", and word-for-word the text you pasted | `[grounded]` careers page fetched |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | The posting covers ingestion, warehouse modelling and contracts end to end, and mentions no reports and no team. The pay report's typical scope is one domain's pipelines with no direct reports, so this may be somewhat broader than typical | `[inferred]` from the JD's three-part mandate set against the pay report's typical scope |
| Market calibration | The posted $148,000–$166,000 starts just under the $151,000 median and ends above the $163,500 top of the interquartile range (IQR) for Senior Data Engineers at Series B–D companies. Your 6 years sits inside the typical 5–8 for "Senior". The band is a pattern, not this employer's offer | `[generic]` Datawright 2026 report (US, n=2,310) from your recruiter, with no search run; `[grounded]` the JD's posted range |
| Unknowns | Hiring manager (none named), team size and reporting line, equity terms, whether pay varies by location | `[grounded]` JD silence |
| Contradictions | None between the pasted text and the careers page | `[grounded]` page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based, whether you're authorized to work in the US, or whether you'd go to Denver. Nothing is stated, so the confidence of your own statement is `none` | `[grounded]` JD; no constraint given | G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is posted, but your floor isn't known. Against the market, the range is at or above the median across its span (see Market calibration). Equity terms are unstated | `[grounded]` JD; `[generic]` pay report | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It is a self-report with no artifact, so `medium`; expect it to be probed | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily". It is stated but carries no depth or artifact, so `medium` | `[grounded]` your background | A sanitized query, or a code sample you can share, would raise it to `high` |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. "Built" is your word and the model count is yours; team size and ownership are not stated | `[grounded]` your background | A dbt docs lineage screenshot or a sanitized model list would raise it to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named directly, but your role in it isn't specified (writing DAGs, running the platform, or both) | `[grounded]` your background | Say which part you owned; a DAG listing would raise it to `high` |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, a direct match. Coverage and who relied on it aren't stated | `[grounded]` your background | A sanitized suite listing or data docs screenshot would raise it to `high` |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The JD's requirements list says only "a cloud warehouse", but the mandate names BigQuery. Your Snowflake dbt work is real adjacent evidence. The limit is that you've never used BigQuery, and warehouse-specific choices such as partitioning, clustering and cost controls are untested | `[grounded]` your background and the JD; `[generic]` that these choices are warehouse-specific | G3 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Airflow work at a payroll company suggests you ingested data, but the sources aren't stated. A CRM or app source is not established | `[inferred]` from the Airflow experience | G2 |
| R10 | Data contracts our analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is near this work, but formal contracts with analyst consumers aren't mentioned | `[inferred]` from the Great Expectations work | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, US work eligibility and pay floor (R1, R2; hard_gate) | hard_gate | Neither your location and authorization nor your pay floor is stated | Both are terms you either meet or don't, and one failure would make this a `no_go` | Anywhere in the US counts for the remote option; Denver is the other; a base floor you'd walk away below | Your own statement is enough | `[grounded]` no constraints given |
| G2 | Ingestion sources and data contracts (R9, R10; important) | discovery | Sources and analyst-facing agreements aren't stated | These are two of the role's three headline duties; resolving them could lift the rows to `adjacent` or `direct` | Pipelines pulling from a product database, a CRM or third-party APIs; schema or freshness checks agreed with analysts; versioned model contracts | A pipeline diagram, a README, a sanitized schema or checks file | `[grounded]` your background is silent on them |
| G3 | BigQuery experience (R8; important) | transferability | Snowflake plus dbt; BigQuery never used | It is the most likely objection to your application | Adjacent: Snowflake warehouse design, dbt materialization and cost tuning. Limit: no BigQuery partitioning, clustering or cost-control work | A small dbt-on-BigQuery project, if you choose to build one | `[inferred]` bridge from your Snowflake work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay posted and consistent with the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent and at or above the market median across its span | `[grounded]` JD range against the report's median and IQR | Where in this range would someone with my profile land, and what sets it? | noted |
| RR2 | Equity unspecified | unknown | — | "plus equity" | The grant type, size and vesting may be thin or vary by person | `[inferred]` from the JD's silence on terms | What is the equity grant for this level, and how does it vest? | unresolved |
| RR3 | Team and scope unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the main or only data engineer, covering ingestion through contracts | `[inferred]` from the JD's three-part mandate and its silence on team and reporting line, against the report's typical scope | Who does this role report to, and how many other data engineers and analysts are on the team? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with dbt on Snowflake (about 180 models), Airflow orchestration and the Great Expectations suite, in your own wording of what you built | R5, R6, R7. This adds no claim beyond what you've stated | `[grounded]` your background | pending your approval |
| E2 | Name Snowflake plainly and state no BigQuery experience; the cover note says "no BigQuery yet, same dbt-and-warehouse practice on Snowflake" | R8. It is truthful and it answers the objection first | `[grounded]` R8 | pending your approval |
| W1 | Optional small dbt project on BigQuery, to claim only what you actually build | R8, G3 | `[inferred]` closure path from the transferability gap | pending your approval |
| A1 | Ask your recruiter for the hiring manager's name, the equity terms and the location rules before investing in the loop | RR2, RR3, R1, R2 | `[grounded]` register | pending your approval |
| Q1 | Put RR1, RR2 and RR3's questions verbatim to interviewers | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything about you comes from the prose you pasted, which counts as self-report and carries a `medium` ceiling. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), and fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). This confirmed the posting is live and identical to your paste, and that the employer matches its own description. Role reality's organization, posting-status and contradictions rows moved; the funding is not corroborated outside the company's own site |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration and the pay comparison, so a search could not change them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

If you want, I can emit this as `tuesday-dossier.md`.

## Upgrade menu

- Your CV, so I can find presentation gaps and draft bullets for your approval.
- A dbt lineage screenshot, a sanitized Great Expectations suite listing, or a DAG listing, which would lift R5, R6 and R7 to `high`.
- Your location, authorization and pay floor, which settles R1 and R2 and decides whether this stays `conditional_go`.
- The recruiter's answers on equity, team and reporting line, which close RR2 and RR3.
- The hiring manager's name, which unlocks target 3 and positioning for that reader.
- A deeper research pass on Pellucid Learning (funding corroboration, leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Where are you based and are you authorized to work in the US (R1)? What is the lowest base salary you'd accept (R2), and would you take Denver or only remote? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Where did your payroll pipelines' data come from (an app database, third-party APIs, a CRM)? Did you ever formalize what analysts could rely on, such as schema checks, freshness expectations or model contracts, and which part was yours? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.