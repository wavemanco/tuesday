I'll read the reference files the skill requires before building the assessment.
**Yes, apply. You are a direct fit on R1, R2, R3, R4 and R7, and the one real question is R5, the metrics layer. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R7 · unclear: R5 (define and maintain the metrics layer)
- `important` — direct: R6a · unclear: R6b (partner with clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data experience, HIPAA)

R5 — your evidence is silent on shared metric definitions; R6b and R8 — no evidence either way yet; R9 (`medium`) — a bridge, its limit named.

**Opportunity ledger.** The employer is unverified because research did not run (RR1). Pay and work arrangement are unstated (RR2, RR3), and the scope of metrics-layer ownership is unclear (RR4). RR5 runs the other way: the posting names a concrete stack and two junior analysts to mentor.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) your metrics-layer experience is confirmed with specifics (R5, G1); (3) pay and work arrangement are checked against your constraints once you state them (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C, with a care-navigation app | `[grounded]` JD header, not independently verified |
| Mandate | Own product analytics: the metrics layer, A/B test design and analysis, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority signal | Two named direct mentees and ownership of a whole analytics domain point to a senior individual contributor with informal lead duties | `[inferred]` from the mentoring line and the "own" verb |
| First 90 days | Likely: inventory existing metric definitions, take over experiment and dashboard backlogs, and meet PMs and clinicians | `[inferred]` from "define and maintain the metrics layer", which suggests the layer is not yet settled; the JD states no outcomes |
| Market calibration | Not available. The role-family search was refused, so no pay or scope band is stated | `[generic]` none stated; see Evidence status |
| Unknowns | Pay, location or remote policy, reporting line, warehouse and metrics-layer tooling, success measures, how clinicians are involved | `[grounded]` the pasted JD is silent on each |
| Contradictions | None inside the JD or between the JD and your background | `[grounded]` JD and your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company, about 2M subscribers. The domain differs from healthcare, but the JD does not require healthcare experience. Self-report only, so expect a probe | `[grounded]` your background | Offer a role-history line or LinkedIn to raise to `high` |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" is specific, but "expert" is a level only a work sample or a technical screen can show | `[grounded]` your background | Be ready for a live SQL exercise; a sanitized query sample would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | You describe designing and running "30+ A/B tests a year", including the pricing test behind an 11% retention lift. `[generic]` Care-navigation outcomes such as bookings and referrals often have lower volume than subscription events, so expect power and sample-size questions | `[grounded]` your claims; `[generic]` the volume contrast | A sanitized write-up of the pricing test would raise to `high` |
| R4 | Build self-serve dashboards in Looker or a similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards. "Governed" is stated; self-serve exploration for non-analysts is not, so keep your wording to what you said | `[grounded]` your background | Dashboard inventory or sanitized screenshots would raise to `high` |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | The governed dashboards and the warehouse consent-state model hint at definitional work, but nothing you wrote says you owned shared metric definitions. I will not assume that practice, so the row stays low | `[grounded]` the gap in your inputs; `[inferred]` weak adjacency from the governed dashboards | Gap G1 |
| R6a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | You present monthly to the VP Product and write the monthly metrics memo the exec team reads. That shows regular partnership at senior level; PM-level working partnership is not itself stated | `[grounded]` your background | none |
| R6b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background mentions working with clinical or other domain-expert stakeholders | `[grounded]` no evidence in your inputs | Gap G2 |
| R7 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | The monthly exec metrics memo is a direct, recurring example. The memo itself is the inspectable artifact | `[grounded]` your background | A sanitized memo excerpt would raise to `high` |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing analysts. It may exist and just be unrecorded | `[grounded]` no evidence in your inputs | Gap G3 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You have handled GDPR/CCPA consumer PII and built the warehouse consent-state model. That carries over as privacy-regulated data work, but you have not worked with HIPAA, PHI or healthcare data, and it should never be presented as if you had | `[grounded]` your consent-state and PII claims; `[inferred]` the adjacency to HIPAA-type handling | Bridge in Application plan E3; no work sample needed |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards and a consent-state model, but no statement that you defined shared metrics, owned a metrics dictionary or modeled metrics once for reuse | It is the only `must_have` row not at `direct`, and it names the role's first responsibility, so it could move the decision from `conditional_go` to `go` | Defining "active subscriber" or "retention" once and having every dashboard use it; LookML or dbt models; a metrics dictionary or change process; settling disputes over conflicting numbers | A metrics dictionary, a sanitized LookML or model snippet, or a data-governance doc | `[grounded]` silence in your inputs; `[generic]` that this role family usually probes it |
| G2 | Clinician partnership (R6b, important) | discovery | No domain-expert stakeholders other than PMs and execs are mentioned | The JD names clinicians as partners, and healthcare analytics usually means translating between them and product | Working with ops, culinary, nutrition, medical or regulatory advisors on a test or metric; any case where a domain expert changed an analysis | A project brief or decision note | `[grounded]` silence in your inputs; `[generic]` the clinician-partner pattern in this domain |
| G3 | Mentoring (R8, important) | discovery | No mentoring or management evidence | The JD names two direct mentees, so it affects how the application reads at senior level | Onboarding analysts, reviewing their SQL or analyses, running office hours, training stakeholders on Looker | A mentee's promotion note or an onboarding doc you wrote | `[grounded]` silence in your inputs |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | (no pay figure appears in the pasted JD) | The figure may be withheld, or it may have been cut from what you pasted | `[grounded]` the pasted JD is silent; no band was found because the role-family search was refused | What is the budgeted salary range for this role? | unresolved |
| RR3 | Location and work arrangement unstated | unknown | — | (no location or remote policy appears in the pasted JD) | The role may be remote, hybrid or office-based; if it conflicts with your constraints it becomes a gate | `[grounded]` the pasted JD is silent | Is this role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Metrics-layer ownership scope unclear | unknown | — | "define and maintain the metrics layer" | The role may own the metrics layer end to end, including modeling work an analytics-engineering team would normally do, or only the definitions | `[inferred]` from "define", which implies no settled layer, against the JD's silence on tooling and data-team structure | Who builds and maintains the underlying models today, and which tools does the metrics layer live in? | unresolved |
| RR5 | Concrete stack and named mentees | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | A named tool you already know, and two existing reports, suggest a defined analytics team with budget behind it | `[inferred]` from the specific tool and headcount language | How is the analytics team organized and who does it report to? | noted |

## Application plan

Everything in this section is proposed language or action and is pending your approval, advice prose included. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the summary with your own claims, in your own words: "6 years of product analytics", "30+ A/B tests a year", "built the Looker instance from scratch with 40+ governed dashboards", and the pricing test behind an 11% retention lift. Keep each number attached to what it counted | R1, R3, R4 | `[grounded]` your background | pending your approval |
| E2 | Hold any metrics-layer or mentoring bullet until G1 and G3 are answered; the only phrasing so far that traces to your words is "governed dashboards" | R5, R8 | `[grounded]` R5 and R8 rows | pending your approval |
| E3 | Frame the HIPAA gap honestly: "handled GDPR/CCPA consumer PII; built the consent-state model for our warehouse; no HIPAA or PHI experience yet". Do not use "healthcare data experience" for your own history | R9 | `[grounded]` your claims; `[inferred]` the bridge's limit | pending your approval |
| A1 | Verify the employer and posting first: the live posting on the company's own careers page, and the recruiter's email domain | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims so far are prose self-report, so the intake ceiling is `medium`. Unverified leads from memory: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused because search permission was not granted. It would have settled whether the company and live posting exist as described, which sets RR1 and the role reality Organization row |
| 2. Role-family sweep | unavailable | Searched "Senior Product Analyst digital health salary range 2026"; the call was refused for the same reason. It would have given the market calibration line and a pay band to check against RR2 |
| 3. Hiring manager's public footprint | n/a | No hiring manager name was given, so there was no query to form |

## Upgrade menu

- Search permission → targets 1 and 2 run. RR1 and RR2 can resolve, and a market calibration row gets added. A deeper pass on Harborlight (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) is available on your word.
- A metrics dictionary, a sanitized LookML or model snippet, or a governance doc → R5 can move from `unclear` toward `direct`.
- A sanitized write-up of the pricing test → R3 to `high`. A sanitized exec memo excerpt → R7 to `high`. Dashboard inventory or screenshots → R4 to `high`.
- An example of working with a domain expert, or of mentoring → R6b and R8 resolve.
- Your non-negotiables (pay floor, location, authorization, schedule) → the hard-gates line gets real checks instead of "not given".
- The hiring manager's name → role reality's scope read and which story to lead with.

If it would help, I can save all of this as a `tuesday-dossier.md` you can reuse or carry into later steps.

**Questions**

1. **G1** — Did you define and own shared metric definitions (for example "active subscriber" or "retention") in one governed place that other dashboards and analysts reused, and what did that look like (LookML, dbt, a metrics doc)? What was yours and what was someone else's?
2. **G3** — Have you mentored or managed analysts, formally or informally? How many, for how long, and what did you do for them?
3. **Constraints** — What are your non-negotiables for a role like this: pay floor, location or remote, work authorization, schedule?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.