I'll read the reference files the skill requires before building the assessment.
**Yes, apply, with conditions. R1 (a hard gate) is unconfirmed, and I couldn't check the employer from here (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitoring rating models)
- `important` — unclear: R7b (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R4 (`medium`) — your GLM build is the closest match to the JD's core ask; R6 (`medium`) — which parts of the test design were yours is still open; R10 — a credible bridge, its limit named.

**Opportunity ledger.** The employer could not be attributed from here (RR1), the pay is withheld (RR2), and team size and decision rights are unstated (RR3). One entry runs the other way: the hiring manager is named and holds a function-owner title (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify on Brindlemoor's own site (RR1); (2) UK residence and right to work confirmed (R1); (3) pay, team and authority answers are acceptable (RR2, RR3); (4) pet insurance is framed as adjacent, never as direct experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product. Stage, size and funding are not stated, and the entity has not been checked. | `[grounded]` JD header; research did not run |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Scope read | The JD lists no people management among its requirements, so your not having managed anyone is not a stated gap. Whether the role leads a team is unknown (RR3). | `[inferred]` from the JD's requirement list against its silence on reports |
| First-90-days and first-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Market calibration | Not established. The role-family sweep did not run, so there is no band for title, scope or pay. | — |
| Compensation | Not stated. No band is available and your pay floor was not given, so no comparison is possible. The withholding is worth a question (RR2). | `[grounded]` JD silence |
| Unknowns | Employer's existence and live posting; pay; team size; authority over rating changes; who owns the product side of recommendations | — |
| Contradictions | None visible within the pasted JD. It was not checked against Brindlemoor's careers page. | `[grounded]` JD text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You stated no residence or right-to-work term. A UK motor-insurer job points to UK-based but doesn't settle it, so this stays a gate question and not an assumed pass. | `[grounded]` JD; `[inferred]` UK base from your UK employer | One gate question (see closing block) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Confirmed and specific, with no inspectable artifact yet. | `[grounded]` your background, prose | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. The claim is specific about frequency but not about what you built, so expect a probe. | `[grounded]` your background, prose | Offer: a sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your employer's young-driver book. Limit: one book at one motor insurer. | `[grounded]` your background, prose | Offer: a sanitized model summary or documentation page would raise it to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM. | `[grounded]` your background, prose | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which is not the same as stating monitoring. Ambiguity resolves downward, so this is a lead and not a claim. | `[grounded]` your wording; `[generic]` that monitoring usually means tracking performance against actuals | Closing-block question G1 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" does not say whether you designed them, so the design half needs confirming. | `[grounded]` your background, prose | Closing-block question G2 |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You ran the tests with underwriting and present the quarterly pricing review to the head of underwriting. | `[grounded]` your background, prose | none |
| R7b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing you gave touches a product team. The JD pairs product with underwriting. | `[grounded]` your background silent; JD quote | Ask in the interview if skipped here (see RR3) |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The audience is underwriting, not actuarial. | `[grounded]` your background, prose | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. | `[grounded]` your background, prose | none |
| R10 | Pet-insurance product knowledge | preferred | adjacent | medium | transferability | The JD only says insurance is a plus, so this requirement is inferred from the role's product. The bridge is a GLM rating model in a different line. The limit is that you have not worked on pet insurance, and its own rating factors and claims patterns are unexercised. | `[inferred]` requirement from the JD's role description; `[grounded]` your statement that you have not worked on pet insurance | Frame as adjacent, never as direct (see plan P1) |

The CV was not seen, only your summary, so every `none` gap above means your described evidence is relevant, not that a document was checked. Any presentation gap is unknowable until the CV is shared.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | "Built and maintained" the young-driver GLM, but nothing on how performance was tracked | The JD names monitoring as half of its first duty, so this is a `must_have` row at `unclear` | Actual-versus-expected tracking; drift or lift checks; a refit trigger; a recurring model-performance pack | A sanitized monitoring report, a dashboard screenshot, a refit note | `[grounded]` background wording; `[generic]` what monitoring commonly covers |
| G2 | Price-test design ownership (R6, must_have) | discovery | You "ran" 14 tests with underwriting. Who set the hypothesis, split and readout is not stated | Design is the first verb in the JD's test duty, and what you say about it will be probed | Choosing test and control splits; setting the success measure; deciding the test's length; writing the readout | A test brief, a readout deck, an analysis notebook, all sanitized | `[grounded]` your wording; `[generic]` that interviews probe design versus execution |
| G3 | Working with a product team (R7b, important) | discovery | Nothing in your background touches product | An `important` row at `unclear`, and it also feeds RR3's unknown team shape | A pricing change shaped with a product owner; a recommendation that went into a product decision | A pricing-review slide or recommendation memo | `[grounded]` your background silent |
| G4 | Pet-insurance bridge (R10, preferred) | transferability | Adjacent: a GLM rating build in motor. Limit: no pet-specific work | A `preferred` row, so a limit to name, not a blocker | Any work on a non-motor line; any pricing project touching vet-cost or health-claims data | A short note on how you'd adapt your young-driver model to a new line | `[inferred]` bridge from your motor GLM; `[generic]` that pet rating uses different risk factors |
| G5 | UK-based remote gate (R1, hard_gate) | hard_gate | Gate not established | Only you can answer whether the gate is met, and no wording changes it | Not applicable | Not applicable | `[grounded]` JD term; your background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | no figure in the JD | The posting may simply not publish pay, or the figure may sit below what the title usually pays. Neither can be judged without a band. | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Team size and authority unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the sole pricing analyst, or one of a team. Whether it decides rating changes or only recommends them is also open. | `[inferred]` from "own" against the JD's silence on team and decision rights | Who else works on pricing analytics today, and which pricing decisions does this role make versus recommend? | unresolved |
| RR4 | Hiring manager named at director level | positive_signal | — | "Odile Varga, Director of Pricing" | The role has a named owner in the pricing function. Her footprint was not researched. | `[grounded]` as given in your message | What would success look like in this role's first year? | noted |

RR1 keeps the decision at `conditional_go` until it is resolved.

## Application plan

All of this is proposed, and none of it is final until you approve it. The audit of every proposed line against your own sentences is below.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting and Brindlemoor on the company's own careers site before spending effort | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV line: "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer" | see R4, R5a; traces to your sentence about the young-driver book | `[grounded]` your background | resume_edits_pending_approval |
| E2 | CV line: "Ran 14 price tests last year with the underwriting team" | see R6. It keeps "ran" and does not claim design until G2 is answered | `[grounded]` your background | resume_edits_pending_approval |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting" | see R7a, R8 | `[grounded]` your background | resume_edits_pending_approval |
| P1 | Positioning: lead with the GLM build and the price tests. Say plainly that you have not worked on pet insurance. Add nothing about product work, team leadership or pet-specific modelling. | see R10, R7b | `[grounded]` your own statements about what you have not done | pending your approval |
| Q1 | Ask the verification questions of RR2, RR3 and RR4 verbatim in the interview loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches on "Brindlemoor" and its careers page were refused by the host, so every call errored. It would have settled RR1 and the contradictions row in role reality. |
| 2. Role-family sweep | unavailable | One search on UK pet-insurance pricing-analyst pay and scope was refused. It would have given the market calibration row a `[generic]` band and let RR2 be set against one. |
| 3. Hiring manager's public footprint | unavailable | One search on Odile Varga's public professional footprint was refused. It would have fed the scope read and which story the plan leads with. |

## Dossier offer and upgrade menu

I can write all of this up as `tuesday-dossier.md` if you want it saved, say the word.

- Search permission, so targets 1–3 can run → RR1 resolves or stays open, the market calibration row fills with a `[generic]` band, and RR2 is set against it. A deeper pass on the company (leadership changes, funding, candidate reports; up to 5 more searches and 2 more fetches) can run once search works.
- Your pay floor and any other non-negotiables (location, schedule, contract type) → the hard-gates line stops being unchecked, and any conflicts with the role surface.
- Your actual CV → presentation gaps on R2–R9 become visible, and E1–E3 are checked against its real wording.
- A sanitized model summary, query or notebook → R3 and R4 move to `high`.
- A sanitized monitoring report → G1 and R5b close.
- A test brief or readout → G2 and R6's design half close.
- Any work with a product team → R7b becomes a row you can speak to.
- Odile Varga's public talks or writing, once search works → the plan's positioning is set for that reader.

**G1** — Once the young-driver GLM was live, how did you track whether it was still performing, and who did that?

**G2** — For the 14 price tests, which parts were yours: the hypothesis, the control split, the success measure, the length, the readout?

**G3** — Are you UK-resident, with the right to work for a UK employer while working from home?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.