Web search was refused, so I'm working from your message alone. I'm reading the reframing-audit reference before I write any positioning advice.
## Decision snapshot

**Should you go for this one? Yes, apply, but with conditions. R1 (a hard gate) is unconfirmed, and I couldn't check the employer (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7a, R8 · unclear: R7b (recommendations to product)
- `important` — adjacent: R9 (Own pricing analytics for the pet product)
- `preferred` — direct: R10 · adjacent: R11 (Pet-insurance pricing knowledge)

R7b — product-facing recommendations not yet evidenced; R9 — segment-level model ownership against a product-level mandate; R11 — a motor-to-pet bridge, its limit named.

**Opportunity ledger.** The role's outputs are clearly specified (RR5). The employer is unchecked (RR1), the pay is not stated (RR2), and reporting and decision rights are not stated (RR3). The JD names no direct reports (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed, which G1 asks; (2) the employer and live posting verified, RR1; (3) a product-facing recommendation example surfaced, or the gap carried honestly, R7b and G2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; existence and live posting not checked (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD names no direct reports and no management requirement | `[grounded]` JD silence |
| First-90-days read | Learn the existing rating model and its monitoring; run or read a first price test; present a recommendation to underwriting | `[inferred]` from "build and monitor rating models", "design and read price tests" and "recommendations for underwriting" |
| Scope read | A senior individual-contributor post under a Director, spanning model, testing and recommendations for one product | `[inferred]` from the JD's three duties and the reporting line, with no team named |
| Market calibration | Not available: the salary search was refused, so no band is offered and none is claimed | `[grounded]` research status below |
| Unknowns | Pay; decision rights versus underwriting and product; team size; whether reports are planned | `[grounded]` JD silence |
| Contradictions | None found within the JD; the careers page was not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You stated no location or right to work. A UK motor insurer is a pointer, not a statement. | `[grounded]` JD; `[inferred]` from your UK employer | G1 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You wrote "5 years pricing analytics at a UK motor insurer". Specific, but your CV has not been read. | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You wrote "SQL and Python daily". Confirmed and specific, but nothing inspectable. | `[grounded]` your message | A sanitized query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You wrote "built and maintained the GLM rating model for our young-driver book". The claim covers one segment, and the cell keeps that limit. | `[grounded]` your message | A sanitized model spec or factor summary would raise to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | You wrote "built and maintained". What was tracked, and how often, is not stated, so monitoring is read at that level only. | `[grounded]` your message | E1 keeps the wording at what you stated |
| R6 | Design and read price tests | must_have | direct | medium | none | You wrote "ran 14 price tests last year with the underwriting team". "Ran" does not separate design from reading. | `[grounded]` your message | E1; a sanitized test readout would raise to `high` |
| R7a | Recommendations for underwriting | must_have | direct | medium | none | Tests were run with the underwriting team, and you present the quarterly review to its head. | `[grounded]` your message | none |
| R7b | Recommendations for product | must_have | unclear | low | discovery | Nothing in your background mentions a product team. | `[grounded]` your message's silence | G2 question |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You wrote "I present the quarterly pricing review to the head of underwriting". Underwriting side only; no actuarial audience is stated. | `[grounded]` your message | A sanitized review deck would raise to `high` |
| R9 | Own pricing analytics for the pet product | important | adjacent | medium | discovery | You owned the model for one book segment, and the JD asks for ownership of a whole product. Whether you owned more is not stated. | `[grounded]` your message; `[inferred]` from the JD's "own" | G3 question |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. | `[grounded]` your message | none |
| R11 | Pet-insurance pricing knowledge (the JD does not require it) | preferred | adjacent | medium | transferability | You have no pet-insurance work. The bridge is GLM pricing in a rated insurance book. Its limit is that you have not exercised pet-specific rating. | `[grounded]` your message; `[generic]` pet rating usually leans on factors such as breed, age and pre-existing conditions, which motor work does not touch; requirement `[inferred]` from the product named in the JD | G4 bridge case |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-remote eligibility (R1, hard_gate) | hard_gate | No location or right-to-work statement | A gate that is unconfirmed holds the decision below `go` | None needed, only a yes or no on whether the gate is met | None | `[grounded]` JD term; your message is silent |
| G2 | Recommendations to product (R7b, must_have) | discovery | Underwriting-facing work is clear; product-facing work is not mentioned | The JD names product as an audience alongside underwriting | A test result that changed a product or proposition decision; a pricing view given to a product or commercial lead; a rating-factor change that shipped | A readout, a paper or a slide | `[grounded]` JD names product; `[inferred]` that resolving it moves R7b |
| G3 | Whole-product ownership (R9, important) | discovery | One segment's GLM is stated; the scope of the 14 tests is not | "Own pricing analytics" is the headline duty | Tests or model changes outside young drivers; deciding which tests to run; being the named owner of a book-level metric | A model inventory, a test log or an org chart line | `[grounded]` your message; `[generic]` that "own" in a senior post usually implies accountability beyond one segment |
| G4 | Pet-specific pricing (R11, preferred) | transferability | Motor GLM work, no pet exposure | Likely the first probe on a pet-insurance team | Any rating or claims-cost work on non-motor lines; any reading you can truthfully describe | A short written note on how you would adapt your factors to pet (a work sample, only if you want one) | `[grounded]` your message; `[generic]` that domain probes are common for this role family |

G4's bridge, stated with its limit: the method carries over (GLM rating, price tests, the underwriting conversation). The limit is that you have not exercised pet-specific factors or claims behaviour.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is ranked as likely. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | The JD as provided gives no figure | The range is unknown; the posting may simply not publish it | `[grounded]` JD silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership asserted, decision rights and team unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may own analysis while model or price changes are decided by others | `[inferred]` from the JD's "own" against its silence on authority and team | Which pricing changes does this role decide, and what team and tools are in place today? | unresolved |
| RR4 | Line management unstated | unknown | — | "Senior Pricing Analyst" | The JD names no direct reports, so a management element may or may not exist now or later | `[grounded]` JD silence on reports | Does the role have direct reports now, or is that planned? | unresolved |
| RR5 | Outputs are concretely stated | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | Success looks measurable | `[grounded]` JD | What would a strong first year look like for this role? | noted |

## Application plan

Each block below is proposed, not final.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: put your own two facts first and word them as you did: the GLM rating model you built and maintained for the young-driver book, and the 14 price tests you ran last year with the underwriting team. Add no outcome, uplift, team size or "led" unless you confirm it. | R4, R5, R6 | `[grounded]` your message | pending your approval |
| E2 | Keep the quarterly pricing review to the head of underwriting visible as your presenting evidence. Don't describe the audience as actuarial. | R8 | `[grounded]` your message | pending your approval |
| E3 | On management, describe yourself as the senior analyst you are. Use no leadership verbs. | RR4 | `[grounded]` your message | pending your approval |
| E4 | On pet, name it as a bridge with its limit: motor pricing work, no pet-insurance pricing yet. | R11, G4 | `[grounded]` your message | pending your approval |
| A1 | Before applying, find the live role on Brindlemoor's own careers page. | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the loop, including whether the role has reports. | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. No unverified leads from prior context; no rejected inferences.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst"; both were refused. It would have moved role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst UK insurance salary remote 2026"; refused. It would have moved the market calibration row and RR2. |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have moved the scope read and which story the plan leads with. |

I'm offering no deeper research pass, because the base tier hasn't run.

I can write this up as `tuesday-dossier.md` for you to carry into later sessions if you want it.

## Upgrade menu

- The live posting or Brindlemoor's careers-page link, or permission to search (one search and two fetches remain in the base budget) → RR1 and the contradictions row close or sharpen.
- A salary range from the posting or the recruiter → RR2 closes and can be set against your own floor.
- Your pay floor, notice period and any other non-negotiables → the hard-gates line stops saying "candidate constraints not given".
- Your CV as a document → R2 to R8 can be checked against it.
- A sanitized price-test readout, model spec or quarterly review deck → R4, R6 and R8 to `high`.

## Questions

G1 — Are you UK-based with the right to work in the UK without sponsorship, and is fully remote working fine for you?

G2 — Have you taken a pricing result to a product or commercial team rather than underwriting, and what changed as a result?

G3 — Do the GLM and the 14 tests cover only young drivers, or other segments or the wider motor book too? Who decided which tests ran?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.