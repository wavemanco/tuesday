I'll read the reference files the skill requires before building the assessment.
**Yes, apply: you're a credible fit on the core of this role.** R1, R2, R3, R4, R5 and R7a are all `direct`. Status: `conditional_go`. The condition is that the employer and posting verify (RR2), because the web checks were refused in this session.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5, R7a · unclear: R6 (define and maintain the metrics layer)
- `important` — unclear: R7b (partner with clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9b (privacy-regulated data handling) · absent: R9a (healthcare data experience)

R6 — governed dashboards are not yet a stated metrics layer; R8 — mentoring is unevidenced; R9a — a real gap, preferred only.

**Opportunity ledger.** The scope is clearly stated and names real tooling (RR4), but pay, location and success measures are absent (RR1, RR5). The employer is unverified from here (RR2), and the bundle of responsibilities may run wider than one analyst role (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for `conditional_go` are (1) the posting and employer verify (RR2); (2) you confirm you've owned metric definitions, or R6 gets framed as adjacent (R6, G1); (3) you can evidence mentoring before it appears anywhere on your CV (R8, G2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, with a care-navigation app | `[grounded]` JD header; not independently checked |
| Title and seniority | Senior Product Analyst, 5+ years required | `[grounded]` JD |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Must-have terms | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders | `[grounded]` JD |
| Preferred | Healthcare data experience (HIPAA) | `[grounded]` JD, "a plus" |
| Hard gates | None stated in the posting as provided | `[grounded]` JD |
| First 90 days / first year | Not stated | `[grounded]` JD silence |
| Scope read | A senior individual-contributor post with a mentoring duty. "Mentor" does not say whether the two juniors report to this role | `[inferred]` from the verb "mentor" against the JD's silence on reporting lines |
| Compensation and location | Neither appears in the posting as provided | `[grounded]` JD silence |
| Market calibration | Not run: the role-family sweep was refused, so no band is offered | `[grounded]` Research tier line below |
| Unknowns | Pay, location or hybrid terms, success measures, reporting line for the juniors, data-engineering support, who owns instrumentation | `[grounded]` JD silence |
| Contradictions | None between the JD and your background. The JD was not checked against the company's own careers page | `[grounded]` inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a meal-kit company; typed self-report with nothing inspectable yet | `[grounded]` your background, prose | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake; "expert" is your level to confirm, and an interview will probe it | `[grounded]` your background, prose | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, 30+ A/B tests a year, at about 2M subscribers, including the pricing test behind an 11% retention lift. No readout inspected yet | `[grounded]` your background, prose | offer: a sanitized experiment readout would raise to high |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background, prose | offer: dashboard screenshots or a governance doc would raise to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads. Quality is not inspectable until a sample is shared | `[grounded]` your background, prose | offer: a sanitized memo excerpt would raise to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests metric-definition work, but you don't say who defined the metrics or whether they lived in a modeled layer. `[inferred]` that governance usually involves some shared definitions; that is a lead, not a claim | `[grounded]` CV silence; `[inferred]` from "governed" | see G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | must_have | direct | medium | presentation | You present monthly to the VP Product, and the pricing test led to an 11% retention lift. The link from analysis to a named decision is implied and not stated, so it is worth making explicit | `[grounded]` your background, prose | see plan E4 |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing stated about working with subject-matter experts such as clinicians | `[grounded]` background silence | see G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing stated about mentoring or reviewing others' work | `[grounded]` background silence | see G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | You told me you have never worked in healthcare | `[grounded]` your statement | closure path in G5; minor risk, since the posting says "a plus" |
| R9b | HIPAA-relevant data handling | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Limit: that does not exercise HIPAA-specific obligations around protected health information. `[generic]` GDPR/CCPA and HIPAA are distinct regimes | `[grounded]` your background; `[generic]` regime difference | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | 40+ governed dashboards, but no statement of who defined or maintained the underlying metrics | A named responsibility and a must-have; the one must-have row below `direct` | Writing LookML or a semantic layer that others queried; keeping a metric dictionary; resolving two teams' conflicting definitions of churn or retention; deprecating a metric | A metric glossary, a LookML excerpt, a governance doc (all sanitized) | `[grounded]` CV silence; `[inferred]` that resolving it moves the status |
| G2 | Mentoring (R8, important) | discovery | No mention of mentoring | The JD names two junior analysts, so this is a stated duty of the role | Reviewing a junior's SQL or experiment designs; onboarding a new analyst; running an analytics office hour; informally coaching a PM on reading A/B results | A teaching doc, an onboarding checklist, a peer review template | `[grounded]` background silence; `[generic]` that senior analyst roles commonly carry this duty |
| G3 | Clinician partnership (R7b, important) | discovery | No subject-matter-expert partnership stated | Clinicians are named stakeholders; a close analogue would help | Working with nutritionists, dietitians or culinary leads on a test or metric; translating domain-expert input into a metric or experiment | An experiment brief co-written with a domain expert | `[grounded]` background silence |
| G4 | HIPAA-adjacent handling (R9b, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | Differentiates you from other non-healthcare applicants | The bridge: privacy-regulated data work, with consent state modeled. The limit: no protected-health-information experience. The strengthener: a short, honest line on the consent model and a stated plan to learn HIPAA basics | A consent-model diagram (sanitized) | `[grounded]` your background; `[inferred]` the strengthener |
| G5 | Healthcare domain (R9a, preferred) | capability | No healthcare experience, as you stated | Preferred only | A realistic closure path is health-data fundamentals training plus a side analysis of public health data | A small public-data analysis | `[grounded]` your statement; `[generic]` closure path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay, location and work arrangement absent | unknown | — | none; absent from the posting as provided | The figure may sit below your target, or the posting may simply omit it | `[inferred]` from the posting's silence | What is the budgeted salary range, and is the role remote, hybrid or on-site? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the checks were refused, so this is untested and not a negative finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Several specializations in one title | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | One analyst may carry analytics engineering, experimentation and BI that other organizations split | `[inferred]` from the scope list against the JD's silence on supporting roles | What data-engineering and instrumentation support does this role have, and who else works on the metrics layer? | unresolved |
| RR4 | Scope and tooling stated concretely | positive_signal | — | "design and analyze A/B tests, build self-serve dashboards in Looker" | The mandate is specific and the tooling is named | `[grounded]` JD | Which product decisions did the last three analyses from this team change? | noted |
| RR5 | No success measures or reporting line for the juniors | unknown | — | "mentor two junior analysts" | The mandate may carry accountability with no stated definition of success, and "mentor" may or may not mean line management | `[inferred]` from the JD's silence on outcomes and reporting | What does success look like at 90 days and at one year, and do the two juniors report to this role? | unresolved |

## Application plan

Everything below is proposed and pending your approval. That covers the resume edits and the positioning and action rows alike, and nothing is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Summary line: "Product analyst, 6 years, consumer-subscription company (about 2M subscribers); SQL on Snowflake, Looker, experimentation." | Surfaces R1 to R4 in the JD's terms; every clause is from your own sentences | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Bullet: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | R3; kept in your own words | `[grounded]` your background | resume_edits_pending_approval |
| E3 | Bullet: "Built the company's Looker instance from scratch: 40+ governed dashboards." | R4 | `[grounded]` your background | resume_edits_pending_approval |
| E4 | Bullet: "Write the monthly metrics memo the exec team reads; present monthly to the VP Product." Add the decision it informed once you tell me one, such as the pricing test | R5, R7a; I will not add a decision you haven't confirmed | `[grounded]` your background | resume_edits_pending_approval |
| E5 | Bullet: "Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII." | R9b. It must not read as HIPAA or healthcare experience | `[grounded]` your background | resume_edits_pending_approval |
| P1 | Positioning: lead with experimentation and the exec-memo writing, state plainly that you haven't worked in healthcare, and present GDPR/CCPA work as privacy work only | R9a, R9b; claiming more would not survive a follow-up question | `[grounded]` R9a, R9b rows | pending your approval |
| P2 | Hold off writing any mentoring or metrics-layer line until G1 and G2 are answered | R6, R8 | `[grounded]` R6, R8 rows | pending your approval |
| A1 | Before investing heavily, confirm the role is live on the company's own careers page | RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Ask RR1, RR3 and RR5's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused, so none of them returned results. It would have confirmed whether Harborlight Health exists as described and whether the posting is live, which feeds role reality's contradictions row and RR2 |
| 2. Role-family sweep | unavailable | The search was refused. It would have supplied a market band for the seniority and scope, feeding the market calibration row and the pay mismatch check in RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you'd like, I can save all of this as `tuesday-dossier.md` for you to keep or reuse.

## Upgrade menu

- Pay floor, location and schedule limits → hard-gate rows against the role, currently unknown.
- A sanitized metric glossary, LookML excerpt or governance doc → R6 resolves.
- A sanitized pricing-test readout → R3 rises to `high`; also strengthens E2.
- A sample of the exec memo → R5 rises to `high`.
- A link to the live posting, or allowing web search → RR2 closes, and the market band lands in role reality.
- The hiring manager's name → target 3 runs, and the plan's positioning is tuned to that reader.

## Questions

1. Constraints — which pay floor, location or schedule limits are non-negotiable for you?
2. G1 — have you personally defined and maintained the shared metric definitions behind those dashboards (LookML, a metric dictionary, a semantic layer), and who relied on them?
3. G2 — have you mentored or reviewed other analysts' work, formally or informally, and what did that involve?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.