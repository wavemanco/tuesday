I'll read the skill's reference files before building the assessment.
**Yes, apply. You're a fit on the core of the role: R1, R2, R3 and R4 (`must_have`) are `direct`, and R5 is `adjacent`. Status: `conditional_go`.** The conditions are below. The main one is that I couldn't verify the employer, because both searches were refused.

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4 · adjacent: R5 (metrics layer)
- `important`: direct: R6a, R7 · adjacent: R6b (clinicians) · unclear: R8 (mentor two junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R5 (`low`) — you built governed dashboards, but owning the metric definitions is unconfirmed; R8 — the background is silent on mentoring; R9 — GDPR/CCPA and consent-state work is a real bridge, with its limit named.

**Opportunity ledger.** The role reads as clearly scoped, with a named stack and a concrete mentoring remit (RR5). Pay is unstated (RR2), the employer couldn't be checked (RR1), and no first-year outcomes are given (RR4). The mentoring seat's reporting line is also unclear (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) you confirm you owned metric definitions, not only dashboards (R5, G1); (3) the healthcare gap is framed honestly as adjacent (R9, G5); (4) your pay and location constraints fit what the role offers (G3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header, not checked against the company's own site |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, Looker self-serve dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Stack | Looker or a similar BI tool; SQL; the warehouse is not named | `[grounded]` JD |
| First-90-days and first-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | A senior individual-contributor post with a mentoring remit over two juniors. The JD doesn't say whether it carries line management | `[inferred]` from "mentor two junior analysts" against the absence of a team-lead title or reports language |
| Compensation | Not stated. No market band is given, because the role-family sweep couldn't run and your pay floor isn't known. The withheld figure is itself worth a question (RR2) | `[grounded]` JD silence |
| Unknowns | Pay, location or remote terms, reporting line, which clinicians you'd partner with, what the metrics layer is built in | `[grounded]` JD silence |
| Contradictions | None between the JD and your background. The JD hasn't been checked against a careers page | `[grounded]` the pasted JD and your summary |

## Evidence map

All your claims are self-reported, so they sit at the `medium` intake ceiling. I've assumed you're at the evaluating stage.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber consumer-subscription company. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake. "Expert" is your own grade, so expect a live SQL exercise | `[grounded]` your background; `[generic]` that roles like this often include a SQL screen | offer: a sanitized query or model you wrote would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Strong and specific; no readout inspected | `[grounded]` your background | offer: a sanitized test readout or experiment-design doc would raise it to `high` |
| R4 | Looker or similar BI tool; self-serve dashboards | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. Confirmed and specific | `[grounded]` your background | offer: screenshots or a governance description of the instance would raise it to `high` |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards and the monthly metrics memo sit near this. Whether you owned the shared metric definitions, rather than the dashboards, isn't stated. `low`, not higher, because the central claim is unconfirmed | `[grounded]` your background; `[inferred]` adjacency from "governed dashboards" | see G1 |
| R6a | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | presentation | You present monthly to the VP Product and write the monthly metrics memo the exec team reads. That is direct partnership with product leadership. The "roadmap decisions" outcome isn't stated | `[grounded]` your background | resume edit E2, pending your approval |
| R6b | Partner with clinicians | important | adjacent | medium | transferability | Your partners were product and exec, not domain clinicians. The bridge is explaining analysis to non-analyst decision-makers. Limit: no clinician partnership is stated | `[grounded]` your background; `[generic]` that clinician stakeholders usually bring domain-specific questions | see G4 |
| R7 | Written communication with non-technical stakeholders | important | direct | medium | presentation | Your monthly metrics memo to the exec team is direct evidence. The CV may bury it | `[grounded]` your background | offer: a sanitized memo excerpt would raise it to `high`; resume edit E2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or reviewing others' work. That is a gap in what I've seen, not a finding that it never happened | `[grounded]` background silence | see G2 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Limit: you've never worked in healthcare, and you haven't stated any HIPAA or health-data work | `[grounded]` your background; `[generic]` that HIPAA work brings its own obligations beyond consumer-privacy law | see G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics-layer ownership (R5, must_have) | discovery | Governed dashboards and an exec metrics memo, but nothing on who wrote and versioned the metric definitions | A `must_have` row at `adjacent` and `low`. Confirming it is the biggest single upgrade to the fit side | Defining "active subscriber" or "retained" once and having every dashboard use it; a metrics dictionary or model layer others queried; resolving a definition dispute between teams | A metric-definitions doc, a semantic-model excerpt, or a before/after of a conflicting-definition cleanup | `[grounded]` background silence on definition ownership; `[inferred]` that confirming it would move R5 up |
| G2 | Mentoring juniors (R8, important) | discovery | Silence on mentoring | The JD names it as a responsibility, and it's the one `important` row with no evidence | Onboarding an analyst; reviewing others' queries or test designs; a standing office hour or analytics guild | Nothing needs attaching; a specific example is enough | `[grounded]` background silence |
| G3 | Candidate constraints not given (no map row; the JD states no gate terms) | discovery | You haven't said anything about pay floor, location or remote, or work authorization, and the JD states none of these terms | Until I know them, the gate checks can't run, and any of them could change the status | Pay floor, remote or hybrid needs, authorization for the role's country | None | `[grounded]` neither source states them |
| G4 | Clinician partnership (R6b, important) | transferability | Partnership with product and exec stakeholders, no clinical partners | A real limit, named here so it isn't glossed over | Working with ops, customer-support, or other domain-expert teams (not product) to scope an analysis | A stakeholder-facing readout | `[inferred]` bridge from exec and product partnership |
| G5 | Healthcare / HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model; no health-data work | A `preferred` row, so a minor risk, not a blocker | Any data-protection, access-control or de-identification work you did on the consent model | A description of the consent-state model's design | `[inferred]` from the consent model; `[generic]` that HIPAA experience is typically a plus, not a gate, when a JD marks it so |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the check never ran, because the searches were refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | JD gives no pay figure | The figure may sit anywhere against the role-family band. Many postings simply don't publish pay | `[inferred]` from the JD's silence | What salary range is budgeted for this role and level? | unresolved |
| RR3 | Mentoring seat with unclear reporting line | unknown | — | "mentor two junior analysts" | The role may carry informal mentoring, or may carry accountability for the juniors' output without line-management authority | `[inferred]` from the JD's wording against its silence on reports or title | Do the two junior analysts report to this role, and who sets their goals and reviews? | unresolved |
| RR4 | No stated success outcomes | risk_signal | low | "Own product analytics for our care-navigation app" | A broad ownership mandate with no first-year definition of success can mean unclear priorities | `[inferred]` from the JD's silence on outcomes | What would success look like at six and twelve months in this role? | unresolved |
| RR5 | Clear scope, named stack, concrete team | positive_signal | — | "build self-serve dashboards in Looker" and "mentor two junior analysts" | Responsibilities are specific, and the tool and team are named | `[grounded]` JD | Which warehouse and modeling layer sit under Looker today? | noted |

## Application plan

Every row below is proposed language or an action and is pending your approval. Nothing here is final until you say so. I checked each line against your own words.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the experimentation program: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Don't add scope or revenue claims you haven't stated | R3, the strongest direct row | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | Put the monthly metrics memo and the monthly VP Product presentation in one bullet, in your own terms: "Write the monthly metrics memo the exec team reads; present monthly to the VP Product." Don't add that analysis "drove roadmap decisions" unless you confirm it | R6a, R7 | `[grounded]` your background | `resume_edits_pending_approval` |
| E3 | State the Looker work as you described it: "Built the company's Looker instance from scratch — 40+ governed dashboards." Don't name LookML, dbt or a semantic layer unless you confirm them | R4, R5 | `[grounded]` your background | `resume_edits_pending_approval` |
| E4 | Describe the privacy work as "handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse" and say plainly that you haven't worked in healthcare. Don't write or imply HIPAA experience | R9, G5 | `[grounded]` your background | `resume_edits_pending_approval` |
| Q1 | Ask the questions in RR1 to RR4 verbatim in the screening loop. They also double as interview preparation | The register | `[grounded]` the register | pending your approval |
| A1 | Check the posting on the company's own careers page, and confirm who sent it, before investing in a tailored application | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. The claims in R1 through R9 come from your summary, so they're self-reported and unconfirmed.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app careers Senior Product Analyst" was refused by the host. It would have confirmed the company exists as described and the posting is live. Without it, RR1 stands and caps the decision at `conditional_go` |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary range Looker A/B testing experimentation" was refused by the host. It would have given a market calibration and a pay band to set against RR2 |
| 3. Hiring manager's public footprint | n/a | No hiring manager's name was given, so there was no query to form |

I can offer one more thing if it helps: a sanitized walkthrough of your pricing test, written to show your exact role. That would be extra to the assessment, so I'll only build it if you want it.

If you want, I can write all of this into `tuesday-dossier.md` for you to keep.

**Upgrade menu**
- Permission to run web search → I can check that the company and posting exist, which could clear RR1 and lift the cap on `go`, and I can calibrate pay against a market band (RR2).
- A sanitized metric-definitions doc or semantic-model excerpt → R5 moves toward `direct` and `medium`.
- A sanitized test readout and a memo excerpt → R3 and R7 to `high`.
- Your pay floor, location or remote needs, and work authorization → the gate checks can run, and G3 closes.
- The hiring manager's name → the scope read and which story to lead with get sharper.

**Questions**

G1 — Did you personally write and version the shared metric definitions (what counts as an active subscriber, retention, and so on) that your Looker dashboards used? What did you own, and who else relied on them?

G2 — Have you ever mentored, onboarded or reviewed the work of other analysts? What did you do, and roughly how long?

G3 — Do you have any non-negotiables on pay floor, location or remote work, or work authorization for this role's country?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.