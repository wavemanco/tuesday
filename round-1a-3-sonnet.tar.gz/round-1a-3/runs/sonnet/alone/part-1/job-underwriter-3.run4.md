I'll read the skill's reference files before building the assessment.
# Job Underwriting Assessment: Head of Growth at Novaline

## Decision snapshot

**No, not as posted. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R3 (Evenings and weekends when it matters) · hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 (Base pay $70–85k)
- `must_have` — direct: R4, R5, R6, R7 · unclear: R8 (SEO and content)
- `important` — unclear: R9 (Brand and PR), R10 (Partnerships and sales ops), R11 (Team of one)

R1 — location conflict, no wording fixes it; R2 — pay conflict, same; R4, R5, R6, R7 — your strongest evidence, all from your own account; R8 — undiscovered, not absent.

**Opportunity ledger.** The mandate covers seven functions with a team of one and no stated budget or success metrics (RR4, RR5, RR7), an always-on expectation (RR6), and pay set against the seniority asked for (RR3). The employer could not be established from here (RR8). The posting is plain about its pay, location and reporting line (RR9), which is why the conflicts with your constraints show up so quickly (RR1, RR2).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 (Base pay $70–85k against a $150k floor); unconfirmed: R3 (Evenings and weekends when it matters).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the employer would have to confirm in writing a remote arrangement for this role (R1) and a base of at least $150k (R2). The posting says "no exceptions" on location and gives a band whose top is $65k under your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one"; none of this verified (see Evidence status) | `[grounded]` JD header |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` JD |
| Team | "A team of one to start" | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; no equity terms given | `[grounded]` JD |
| First-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Seven functions with no staff reads as a department's remit given to one person, which is wider than a single role | `[inferred]` from the function count against "team of one" |
| Market calibration | Not calibrated: the role-family sweep did not run, so no band is offered. The pay conflict (R2) rests on your floor and the posted band, not on a market figure | `[grounded]` JD band and your stated floor |
| Unknowns | Budget, headcount plan, equity terms, who the customers are (merchants or consumers), what "no exceptions" covers | `[grounded]` JD silence |
| Contradictions | "Head of" and 8+ years of leadership sit beside a team of one and a $70–85k base | `[inferred]` from the JD's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin office 5 days a week — "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement (remote-only, Portland, not relocating), which is specific and your own. The fit fails because the posting rules out any remote arrangement | `[grounded]` JD quote and your stated constraint | Surface only; resolved only if the employer changes terms (RR1) |
| R2 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k base floor, which is specific and your own. The top of the posted band is $65k below it. Equity is not base | `[grounded]` JD band and your stated floor | Surface only; resolved only if the employer changes terms (RR2) |
| R3 | Evenings and weekends "when it matters" | hard_gate | unclear | none | hard_gate | The term is open-ended and you stated no constraint on hours, so nothing settles whether it is acceptable | `[grounded]` JD quote; your input silent | None while R1 and R2 stand; confirm your tolerance only if they change |
| R4 | 8+ years growth leadership | must_have | direct | medium | none | You report 9 years in growth, as growth lead then Head of Growth at two B2C subscription companies. Self-reported, no artifact inspected. A years requirement is graded on evidence, not treated as a gate | `[grounded]` your account | none |
| R5 | Own revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. Limit: both employers were B2C subscription, and the posting's "enablement" wording suggests a different customer | `[grounded]` your account; `[inferred]` customer difference from the JD's wording | A revenue bridge or investor update would raise it to `high` |
| R6 | Paid acquisition | must_have | direct | medium | none | You owned paid at both companies; no channel report seen | `[grounded]` your account | A channel performance report would raise it to `high` |
| R7 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and are deep in Braze; no artifact seen | `[grounded]` your account | A Braze canvas export or retention report would raise it to `high` |
| R8 | SEO/content | must_have | unclear | low | discovery | Your account names paid, lifecycle and experimentation and is silent on SEO or content. Low rather than none, since a growth lead may have touched it. Tiered `must_have` because the posting lists it beside paid and lifecycle | `[grounded]` your account's silence; `[inferred]` tier | See G1 |
| R9 | Brand and PR | important | unclear | low | discovery | Not in your account. Tiered `important` because the posting does not rank its list | `[grounded]` your account's silence; `[inferred]` tier | See G2 |
| R10 | Partnerships and sales ops | important | unclear | low | discovery | Not in your account. Sales ops usually belongs to a B2B motion, and your background is B2C | `[grounded]` your account's silence; `[generic]` where sales ops sits | See G2 |
| R11 | Working as a team of one, "players who don't need a bench" | important | unclear | low | discovery | You built and managed teams of 3–7. Whether you executed hands-on alone is not stated | `[grounded]` your account | See G3 |

## Gap recovery queue

These gaps would matter only if R1 and R2 changed. The hard gates themselves are not recoverable by evidence.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R8, must_have) | discovery | Your account is silent on SEO or content | A `must_have` row at `unclear`; it is the only must-have row not covered by your own account | Owning organic landing pages or a content calendar; directing an SEO agency; owning an organic acquisition target | A traffic or rankings dashboard export, a content brief | `[grounded]` account silent; `[generic]` that growth leads at your level often oversee organic |
| G2 | Brand, PR, partnerships, sales ops (R9, R10, important) | discovery | Nothing in your account on these | Two `important` rows; a seven-function mandate leaves little room to leave any uncovered | Affiliate or referral partnerships; managing a PR agency; a launch with press coverage; CRM-to-sales handoff design | A partner agreement, a launch recap, a coverage report | `[grounded]` account silent; `[inferred]` that B2C subscription work may have touched partnerships |
| G3 | Solo execution (R11, important) | discovery | Teams of 3–7 are stated; hands-on solo work is not | The posting starts you with no bench | Periods you ran paid or lifecycle yourself before hiring; a function you ran with no direct reports | A before-and-after org chart or channel ownership list | `[grounded]` account; `[generic]` that "team of one" roles lean toward hands-on execution |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The posting rules out the one arrangement you can accept | `[grounded]` JD quote against your stated constraint | Is a remote arrangement possible for this role under any terms? | confirmed |
| RR2 | Base pay below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted band sits below your $150k floor at its top | `[grounded]` JD band against your stated floor | Is the base flexible above the posted band, and what are the equity terms? | confirmed |
| RR3 | Seniority-pay mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The pay may sit below what this seniority and scope usually carry. Not verified, since the sweep did not run, so it stays at medium | `[inferred]` from the JD's own seniority against its pay | What total compensation do you budget for this level, and how is equity structured? | unresolved |
| RR4 | Bundled specializations, team of one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one to start" | Several full roles may be folded into one title | `[inferred]` from the JD's function list against its staffing | What headcount and first hires are committed for year one? | unresolved |
| RR5 | Authority and resources unstated | unknown | — | "Own all revenue growth end to end" | The posting names no budget or decision rights | `[grounded]` JD silence | What budget and decision rights does this role hold? | unresolved |
| RR6 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The extra hours may be routine rather than occasional | `[generic]` pattern for this kind of wording, not a claim about this employer | What did the last quarter's evenings and weekends look like in practice? | unresolved |
| RR7 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue growth with no stated definition of success | `[inferred]` from the JD's mandate against its silence on outcomes | What outcome would count as success at six and twelve months? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Terms stated plainly | positive_signal | — | "$70–85k base… On-site… 5 days a week — no exceptions" | Pay, location and reporting line are all in the posting, so the conflict costs you no interview time | `[grounded]` JD | What does the dotted line to the board involve in practice? | noted |

If you proceed against this status, RR3 through RR8's questions become essential to ask first.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on this posting as written | see R1, R2, RR1, RR2 | `[grounded]` the two failed gate rows | pending your approval |
| P2 | Optional: one short note to Novaline through contacts on its own site, asking whether remote work and a base of at least $150k are possible for this role | see RR1, RR2; the posting says "no exceptions", so low odds | `[inferred]` from the JD's wording | pending your approval |
| P3 | No resume edits proposed; nothing in the map is worth repositioning while the gates stand | see R4, R5, R6, R7 | `[grounded]` map rows | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating. Your constraints and background were taken as stated.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth"; the call was refused (search permission not granted). It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary Series A startup base compensation 2026"; the call was refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I did not retry the searches. The decision rests on your two stated constraints and the posting's own words, so a search could not change it.

I can save this as `tuesday-dossier.md` if you want a record to carry into other postings.

## Upgrade menu

- Link to the live role on Novaline's own careers page → RR8 closes and the organization row can be grounded.
- Search permission, for the role-family sweep → market calibration and RR3 move from inference to a stated band.
- Novaline's answers on budget, headcount and equity terms → RR2, RR4 and RR5 close.
- A traffic dashboard export or content brief → R8 moves from `unclear`; a partner agreement or launch recap → R9 and R10.
- A revenue bridge or investor update for the $8M to $40M ARR period → R5 moves from `medium` to `high`; a channel report → R6; a Braze canvas export → R7.
- The hiring manager's name → role reality's scope read.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.