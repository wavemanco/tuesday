I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, this is worth applying to: R3, R4, R5, R6, R7 and R8, every must-have, land `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9: a credible bridge from Snowflake, its limit named; R10, R11: waiting on your answer about source-system and schema ownership.

**Opportunity ledger.** Pay is posted and sits inside the report's band (RR3). The open items are the role's scope and ownership (RR2), its success measures (RR5), the equity terms (RR4), and a posting I could not check as live (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the location and pay terms in R1 and R2 work against your own constraints; (2) the posting and employer verify, see RR1; (3) the BigQuery gap is framed honestly as adjacent, see R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; the live page was not checked, see Evidence status |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` pasted JD |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` pasted JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` pasted JD |
| First-90-days / first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | The mandate spans three layers (ingestion, modelling, contracts) with no team size, reporting line or named hiring manager. That is broader than the report's typical single-domain ownership, but whether it means a sole-engineer remit is unknown | `[inferred]` JD's three layers set against the report's typical scope, which is `[grounded]` in the Datawright report you supplied |
| Market calibration | The report puts Senior Data Engineer base at a $151,000 median (IQR $139,000–$163,500) for Series B–D companies, and "Senior" at 5–8 years. The posted range starts $3,000 below that median and ends $2,500 above its upper quartile. Your 6 years fall inside the 5–8 band. This is the band, never this employer's offer | `[grounded]` Datawright 2026 Data Engineering Pay Report (n=2,310) and JD; `[inferred]` the comparison |
| Unknowns | Team size and ownership split; success measures; equity form and vesting; hiring manager; posting age | `[grounded]` JD silence |
| Contradictions | None between the two pasted texts. Neither could be checked against the live pages | `[grounded]` pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You gave no location or authorization terms, so neither the gate nor your constraint is established. Confidence is `none` because there is no statement to grade | `[grounded]` JD terms; your constraints not given | Ask whether the terms work (G1) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor was not given, so I cannot say whether it clears. The band comparison is in role reality and RR3 | `[grounded]` JD pay; your floor not given | Ask whether the range works against your floor (G2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. That is confirmed and specific, but intake prose is the ceiling at `medium`: no inspectable artifact yet. Expect a probe on scope | `[grounded]` your background as pasted | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is your claim. "Strong" is a self-assessment, and the evidence is limited to your own statement | `[grounded]` your background | Offer: a sanitized model or script excerpt would raise to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models, specific and confirmed. No artifact inspected | `[grounded]` your background | Offer: dbt docs or lineage graph excerpt raises to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the stated requirement is met. The BigQuery-specific part is R9 | `[grounded]` your background; JD wording "a cloud warehouse" | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named by both you and the JD. Confirmed but unprobed | `[grounded]` your background | Offer: a sanitized DAG file raises to `high` |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Confirmed and specific, with no artifact inspected | `[grounded]` your background | Offer: suite config or data-docs excerpt raises to `high` |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The bridge is dbt modelling on a cloud warehouse (Snowflake). The limit is that you have never used BigQuery, so its cost model, partitioning and tooling are unexercised. I tiered this `important` because the JD's requirements list says "a cloud warehouse" and names BigQuery only in the mandate. Whether warehouse skills transfer between these platforms is not something I can source here | `[grounded]` your background and JD mandate; `[inferred]` the tiering | See G3 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background says nothing about source systems or ingestion, so there is a gap to recover, not an absence | `[grounded]` your background silent | See G4 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your background is silent on written agreements with analysts about schemas or freshness. Your dbt and test-suite work may count, but that is unconfirmed | `[grounded]` your background silent | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location terms (R1, hard_gate) | hard_gate | Terms are Remote (US) or Denver. Your constraints were not given | A failed gate would make this `no_go` whatever the fit | Being US-based or Denver-able | None needed; your word | `[grounded]` JD terms and your silence |
| G2 | Pay floor (R2, hard_gate) | hard_gate | Posted $148,000–$166,000 plus equity. Your floor was not given | Same gate effect; the posted range is also `[grounded]` against the supplied report in RR3 | Your base-salary floor | None needed; your word | `[grounded]` JD and your silence |
| G3 | BigQuery (R9, important) | transferability | Snowflake and dbt, with no BigQuery use | This is the one named tool of the stack you have not touched | A BigQuery sandbox, side project, course project, or a Snowflake-to-BigQuery comparison you ran | A repo, a project README or a course certificate | `[grounded]` your statement; `[inferred]` that any exposure narrows the limit |
| G4 | Ingestion from app and CRM (R10, important) | discovery | Nothing about the systems feeding your warehouse | The mandate opens with ingestion | Loading product-database or SaaS-tool data (a CRM, billing or support system) into the warehouse; owning connectors or incremental loads | A pipeline diagram, a DAG file or an architecture note | `[grounded]` your background silent |
| G5 | Data contracts (R11, important) | discovery | Nothing about agreements with analysts | The JD names analysts as dependants of the contracts | Agreed schema or freshness expectations; tests that blocked a bad load; a model-ownership doc | A contract doc, a schema.yml with tests, a data-docs excerpt | `[grounded]` your background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | I could not open the live pages, so the posting's age and the company's details are unchecked. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope and ownership unstated | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The three layers could be one person's remit, against the report's typical single domain with no direct reports | `[inferred]` from the JD's three layers against the supplied report's scope norm | How many data engineers and analysts are on the team, and which of ingestion, modelling and contracts does this role own alone? | unresolved |
| RR3 | Pay posted and in line with the supplied market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | A published range with a midpoint $6,000 above the report's median, at a Series C company, is consistent with a role priced for its seniority | `[grounded]` JD and the supplied report; `[inferred]` the reading | Where in that range would a hire with six years of experience start? | noted |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Form, size and vesting are all unknown, so total pay cannot be compared | `[inferred]` from the JD's silence | What form does the equity take, and what is the vesting schedule? | unresolved |
| RR5 | Success measures unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The JD states no first-90-day or first-year outcomes, so what "good" looks like is undefined | `[grounded]` JD silent | What would a successful first year look like for this role? | unresolved |

## Application plan

All language and actions below are proposed and pending your approval; none is final until you say so. Each CV line traces to your own sentence: "Built our dbt project on Snowflake — about 180 models", "Airflow for orchestration", "I set up our Great Expectations test suite". The audit added no scope, no verbs and no numbers beyond yours.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Built our dbt project on Snowflake, about 180 models" | R5 | `[grounded]` your sentence | resume_edits_pending_approval |
| E2 | CV line: "Set up our Great Expectations test suite" | R8 | `[grounded]` your sentence | resume_edits_pending_approval |
| E3 | CV line: "Used Airflow for orchestration" | R7 | `[grounded]` your sentence | resume_edits_pending_approval |
| P1 | Positioning: lead with the dbt project and the test suite, since the JD names data quality testing and dbt among its requirements. Say plainly that you have worked on Snowflake and have not used BigQuery | R5, R8, R9 | `[grounded]` rows R5, R8, R9 | pending your approval |
| Q1 | In the loop, ask RR1, RR2, RR4 and RR5's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Before any salary conversation, ask where in the posted range the role starts (RR3's question) | R2 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried to check your pasted material for currency and genuineness. A fetch of pellucidlearning.com/careers/senior-data-engineer and a search ("Pellucid Learning online tutoring K-12 Series C Denver") were both refused (web permission not granted), so nothing came back. It would have moved role reality's contradictions row and RR1; RR1 stands, and it caps the decision at `conditional_go` until the posting verifies |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market band, the seniority range and the scope norm, which are the outputs this target feeds: the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Dossier offer

If you'd like a record of this assessment, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Web access granted for my search and fetch tools, with the URL sent again → RR1 and role reality's contradictions row get checked against the live pages, and the cap on `conditional_go` may lift.
- Your location and salary floor → R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- Any BigQuery exposure → R9's limit narrows.
- A sanitized dbt lineage graph, Airflow DAG file or Great Expectations suite excerpt → R5, R7 and R8 go from `medium` to `high`.
- A pipeline diagram or contract doc → R10 and R11 move off `unclear`.
- The hiring manager's name, if the recruiter shares it → role reality's scope read, and which story the plan leads with.
- A deeper pass on the company's funding, leadership and public employee reports (up to 5 more searches and 2 more fetches) → RR1 and the register. It needs web access too, and runs only on your say-so.

## Questions

- **G1 and G2** — Do this posting's terms (US-remote or Denver, $148,000–$166,000) work against your own location and salary floor?
- **G3** — Have you touched BigQuery in any form, such as a side project, a course or a sandbox?
- **G4 and G5** — At the payroll company, which source systems did you personally bring into the warehouse, and did you agree any written schema or freshness expectations with analysts?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.