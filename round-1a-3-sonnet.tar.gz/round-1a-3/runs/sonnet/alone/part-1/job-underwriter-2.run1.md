I'll read the reference files the skill requires before building the assessment.
Running two research searches now: one to check that Quartzline exists as described, and one for the market band for this role.
Research was denied: the web search permission wasn't granted, so nothing below rests on outside sources.

# Job Underwriting Assessment: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, you're not wasting your time, but this is a stretch application and not a natural fit. R1 and R2, both must-haves, are only adjacent for you. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1 (3+ years PM experience), R2 (Shipped API or platform products) · unclear: R4b (Sales and support coordination), R5 (Agile delivery)
- `important` — direct: R7 · adjacent: R6 (Roadmap ownership), R8 (Specs for engineering squads) · unclear: R9 (Define and track adoption metrics)

R1 — the title gap, the likeliest screen-out; R2 — adjacent evidence, no shipped product yet; R3 (`medium`) — the strongest row, waiting on an inspectable artifact.

**Opportunity ledger.** The scope reads as concrete, with roadmap ownership, two squads and named adoption metrics (RR3). The employer is not established, because research did not run (RR1). Compensation is withheld (RR2) and success targets are unstated (RR4). The "must-have" wording on the title-years requirement is a screening risk (RR5).

- **Hard gates:** none failed; the posting states no gate terms (location, authorization, pay and schedule are all unstated), and candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verified (RR1); (2) the recruiter or hiring manager confirms adjacent experience is considered in place of a PM title (R1, RR5); (3) any product-ownership evidence you have is confirmed, so R2 and R9 can move (G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not verified: research did not run | `[grounded]` JD header, unverified |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years PM experience (must-have); shipped API or platform products; technical fluency (API docs, schemas); stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| Hard gates | None stated. "3+ years" is a length-of-experience term, so it is graded as a requirement (R1) and not as a gate | `[grounded]` JD |
| First-90-day and first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A single-product, mid-level platform PM post: one product area, two squads, partner-facing users. The JD gives no seniority title beyond "Product Manager" | `[inferred]` from the 3+ years floor and the two-squad scope |
| Market calibration | Not obtained. Pay band and title norms need the role-family search, which was denied | `[generic]` nothing run |
| Unknowns | Compensation; location or remote policy; reporting line; who sets the adoption targets; whether the 3+ years is flexible | — |
| Contradictions | None visible within the JD alone. It could not be checked against the company's own careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | You have 7 years of PM-adjacent work: roadmap-input sessions, requirements documents, coordinating engineers and product managers. You have never held a PM title. Roadmap-input sessions collected client feedback for product, which is not the same as owning priorities. The posting calls this a must-have, and a literal screen would catch it | `[grounded]` your resume; `[inferred]` that the term may be screened literally | G2; RR5's question |
| R2 | Shipped API or platform products | must_have | adjacent | low | discovery | You led 30+ client integrations of your employer's REST APIs and wrote the team's integration playbook. That is deep use and delivery on a platform, not shipping one. A possible internal-tool lead is unconfirmed | `[grounded]` your resume; `[grounded]` memory lead, unconfirmed | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture across 30+ API integrations, is specific and directly on point. `medium` because it is CV-only; the playbook or a sanitized integration design would raise it to `high` | `[grounded]` your resume | offer: a sanitized playbook excerpt |
| R4a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and product managers on custom builds, and ran client scoping workshops and UAT | `[grounded]` your resume | none |
| R4b | Coordinating launches with sales and support | must_have | unclear | low | discovery | The resume is silent on sales or support. Go-lives involve them in many firms, but that is a pattern, not your history | `[grounded]` CV silence; `[generic]` pattern | not asked this turn; carried as a minor risk |
| R5 | Agile delivery | must_have | unclear | low | discovery | The resume names no sprint, backlog or cadence. UAT and go-live show delivery discipline, not agile practice | `[grounded]` CV silence | not asked this turn; carried as a minor risk |
| R6 | Own the roadmap | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product. That is the input side. The resume does not say you decided priorities | `[grounded]` your resume | G2 |
| R7 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly feedback sessions with clients are discovery conversations. The resume does not frame them that way | `[grounded]` your resume | E2 pending approval |
| R8 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | You wrote requirements documents for client integrations and coordinated engineers on custom builds. Specs for a product squad's backlog are a related but different artifact | `[grounded]` your resume | G2 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | SQL is a relevant tool, but the resume names no metric you defined or tracked | `[grounded]` CV silence | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption metrics (R2, R9) | discovery | Resume silent. An earlier conversation hinted you built an internal request-triage tool that support agents adopted. That is unconfirmed | R2 is a must-have at `adjacent` and R9 is unclear. Real ownership of something people adopted would be the strongest bridge in your file | An internal tool you built, a process or template others adopted, any usage you tracked | A screenshot, usage numbers, a short description, anything inspectable | `[grounded]` memory lead, unconfirmed; `[inferred]` the likely relevance |
| G2 | Ownership of what product built (R1, R6, R8) | transferability | Roadmap-input sessions feed product. Nothing shows what you recommended or what happened next | R1 is the likeliest objection. Evidence you influenced priorities narrows it | A feature client feedback led to, a requirement you wrote that became a backlog item, a recommendation product acted on | A sanitized requirements document or a product follow-up note | `[inferred]` from your roadmap-input description |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Research did not run, so nothing is established. The employer may simply be small, the posting may be stale, or the posting may not reflect a live hiring need | `[generic]` pattern, not a claim about this company | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | No pay figure in the JD | The pay may sit above or below the band for this scope. The band was not obtained, so it cannot be set against your floor, which you have not given | `[generic]` nothing run; `[grounded]` JD silent | What salary range is budgeted for this role? | unresolved |
| RR3 | Scope and decision rights stated concretely | positive_signal | — | "Own the roadmap for our partner-facing API platform ... drive delivery with two engineering squads" | Ownership of the roadmap with two squads suggests real scope, though the real decision rights are still untested | `[grounded]` JD | What decisions on the roadmap does this role make alone, and which go to a VP or CEO? | noted |
| RR4 | Success targets unstated | unknown | — | "define and track adoption metrics" | The role may be asked to set its own targets with no baseline | `[inferred]` from the JD asking the role to define metrics, with no numbers given | What would success look like at 90 days and at 12 months? | unresolved |
| RR5 | Title-years requirement marked must-have | risk_signal | low | "3+ years product management experience (must-have)" | The requirement may be screened literally by a recruiter or tracking system. It may be flexible for strong adjacent profiles; I have no evidence either way, so this stays `low` | `[generic]` how title-years requirements are often screened | Would you consider a candidate with seven years of API integration delivery and client roadmap input in place of a PM title? | unresolved |

## Application plan

`resume_edits_pending_approval` — each line below traces to your own sentences, and nothing is applied until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Proposed summary line: "Solutions and implementation lead with seven years taking enterprise-software REST API integrations from scoping workshops through UAT and go-live for 30+ clients, working alongside client engineers, our engineers and product managers." | Front-loads the API delivery evidence for R2, R3 and R4a without claiming a PM title. Every clause traces to your resume | `[grounded]` your resume | pending your approval |
| E2 | Proposed bullet: "Ran quarterly roadmap-input sessions collecting client feedback for product." Keep that scope and verb; do not upgrade it to "shaped" or "owned" the roadmap | Surfaces R7 and R6 at their true level | `[grounded]` your resume | pending your approval |
| E3 | Proposed bullet: "Wrote the internal integration playbook the whole team uses." | Evidence of documented, adopted practice (R2, R3). It also leaves room for G1 if the triage tool is confirmed | `[grounded]` your resume | pending your approval |
| A1 | Positioning, for the first line of any cover note: say plainly that you have not held a PM title and that you have 7 years delivering API integrations and bringing client feedback to product. Don't present it as PM experience | Naming R1 yourself is more credible than letting a reader discover it | `[inferred]` from R1 and RR5 | pending your approval |
| A2 | Before investing in a full application, ask the recruiter RR5's question | If the 3+ years is firm, you learn it early | `[grounded]` RR5 | pending your approval |
| A3 | Look for a referral or a conversation with someone at Quartzline before applying cold | Moves from solutions or implementation roles into API platform PM roles are often helped by an internal sponsor. This is how such moves commonly work, not a fact about this employer | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a request-triage tool that support agents adopted, from earlier agent memory and unconfirmed. It prompts question 1 and does not appear in any proposed resume line until you confirm it. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Quartzline's company and careers page was refused, so nothing was used. It would have moved role reality's organization row and contradictions row, and RR1 |
| 2. Role-family sweep | unavailable | The search for market scope and pay for this title was refused. It would have moved role reality's market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want to keep this, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Allow web search → targets 1 and 2 run (up to 3 more searches and 2 fetches remain at this tier). They would settle RR1 and fill the market calibration and RR2's band.
- The hiring manager's name → role reality's scope read and which story to lead with.
- A sanitized playbook excerpt or integration design → R3 to `high`.
- Any inspectable artifact from the triage tool, if confirmed → R2 and R9 move off their current reads.
- A sanitized requirements document that product acted on → R1, R6 and R8 bridges strengthen.
- Your non-negotiables (pay floor, location, sponsorship) → the hard-gates line can run real checks.

## Questions

1. **(G1, R2/R9)** An earlier conversation suggested you once built an internal request-triage tool that support agents adopted. Is that right, and if so what did it do, how many people used it, and did you track usage?
2. **(G2, R1/R6/R8)** After your roadmap-input sessions, what happened to the feedback? Did you make recommendations or write requirements that product acted on, or did product take it from there?
3. **(Hard gates)** Do you have non-negotiables for a move like this, such as a pay floor, location or remote requirement, or visa needs?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.