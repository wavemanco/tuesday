I'm reading the skill's remaining reference files (evidence-row shape and question rules), then I'll run the company and market research.
# Job Underwriting — Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Yes, this is worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Remote US or Denver office), R11 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R1, R2, R3, R4, R5, R6
- `important` — adjacent: R7 (dbt-modelled warehouse in BigQuery); unclear: R8 (ingestion from app and CRM), R9 (data contracts for analysts)

R7 — a credible bridge from Snowflake, its limit named; R8, R9 — your summary says nothing either way.

**Opportunity ledger.** The pay is stated and sits on the market band (RR2), and the stack and deliverables are explicit (RR5). Team size and reporting line are unstated (RR3), equity terms are unstated (RR4), and the stage claims rest on the company's own pages (RR1).

- **Hard gates:** none failed; unconfirmed: R10 (Remote US or Denver office), R11 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R10 and R11 clear your own constraints (where you live, your pay floor).
  2. RR3 verifies that the scope is workable, because the posting doesn't say whether you'd be the only data engineer.
  3. The BigQuery bridge (R7) is framed honestly as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched in search; the company's own statement |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity (type and size unstated) | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Hiring manager | None named | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | The three areas (ingestion, warehouse, contracts) may be broader than the usual one-domain remit, and the JD gives no team size, so this could be a sole or near-sole owner post. Unconfirmed (RR3) | `[inferred]` the JD's three areas against the pay report's typical scope, with the JD silent on team |
| Market calibration | Base median for Senior Data Engineer at Series B–D companies is $151,000 (IQR $139,000–$163,500; n=2,310; "senior" typically 5–8 years). The posted range runs $3,000 under the median to $2,500 above the upper quartile, and your 6 years sits in the typical band. This is a market band, never this employer's offer | `[grounded]` the Datawright 2026 report you supplied; `[grounded]` JD for the posted range |
| Unknowns | Team size, reporting line, equity terms, on-call expectations for "run", first-year outcomes | — |
| Contradictions | None between the pasted JD and the live careers page | `[grounded]` careers page fetched; text matches |

## Evidence map

Your background is typed prose, so it counts as self-report: `medium` is the ceiling on a first pass. Rows R10 and R11 rest on constraints you haven't stated yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. Years of experience is a requirement, not a gate. Unprobed prose, so `medium` | `[grounded]` your background summary | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily"; no artifact yet, so expect a probe on depth | `[grounded]` your background summary | none |
| R3 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. The claim is specific; nothing inspectable yet | `[grounded]` your background summary | A sanitized model-lineage screenshot or project README would raise it to `high` |
| R4 | A cloud warehouse | must_have | direct | medium | none | The JD says "a cloud warehouse"; Snowflake is one. R7 carries the BigQuery-specific point | `[grounded]` JD wording and your summary | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration; scale and ownership not stated | `[grounded]` your background summary | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is direct and specific. Hedge: how it was wired into pipelines and who acted on failures is not stated | `[grounded]` your background summary | none |
| R7 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: dbt modelling and warehouse design on Snowflake. Limit: you have not used BigQuery, so its cost model, partitioning and clustering are unexercised. The JD lists "a cloud warehouse", not BigQuery, as the requirement | `[grounded]` your summary ("never used BigQuery") and JD; `[inferred]` that the bridge is credible | See G1 |
| R8 | Ingestion from the app and CRM | important | unclear | none | discovery | Your summary says nothing about ingestion sources or connectors | `[grounded]` your summary silent | See G2 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in your summary either way; schema agreements with analysts or downstream teams could count | `[grounded]` your summary silent | See G3 |
| R10 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | The JD's terms are stated; your location and work authorization are not | `[grounded]` JD; your constraints not given | Ask whether the term clears your constraints |
| R11 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The JD's terms are stated; your pay floor is not | `[grounded]` JD; your constraints not given | Ask whether the term clears your floor |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Warehouse and dbt depth on Snowflake; no BigQuery exposure | It is the named platform in the role description, and the likeliest probe | A small dbt project on BigQuery using a public dataset, or a BigQuery-specific cost or partitioning comparison with your Snowflake work | A public repo or short write-up | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that a named platform is the likeliest probe |
| G2 | App and CRM ingestion (R8, important) | discovery | Ingestion sources are not mentioned | It is the first-named duty in the role | Loading product events or a CRM (Salesforce, HubSpot) into the warehouse; connector tools or custom extraction; handling schema drift | A pipeline diagram or DAG listing, sanitized | `[grounded]` your summary silent; `[inferred]` that it is the first-named duty |
| G3 | Data contracts (R9, important) | discovery | Not mentioned; nothing establishes schema agreements with consumers | The posting says analysts depend on contracts | Agreeing column definitions or freshness expectations with analysts; dbt contract or schema-test enforcement; breaking-change processes | A sanitized contract, schema doc, or dbt YAML | `[grounded]` your summary silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Funding, size and stage rest on the company's own pages | unknown | — | "Series C ($52M, February 2026)" | The facts may be accurate; the one source reached is the company's own About page, with no independent corroboration yet | `[inferred]` from the single source reached | How large is the data team today, and what is the round expected to fund on the data side? | unresolved |
| RR2 | Pay stated and in line with the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay, spanning the report's median and upper quartile | `[grounded]` JD and the pay report you supplied | Where in the range would this role land for my experience? | noted |
| RR3 | Team size, reporting line and manager are unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be a sole or near-sole owner of ingestion, warehouse and contracts, wider than the report's one-domain norm; or it may sit inside a team | `[inferred]` JD's three areas against its silence on team; `[grounded]` report's typical scope | Who is on the data team, who would I report to, and who else owns ingestion and modelling? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Type, size and vesting are open, so the equity may not be comparable across offers | `[inferred]` from the JD's silence | What is the equity grant for this level, its type, and its vesting? | unresolved |
| RR5 | Stack and deliverables are explicit | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Scope is defined by tools and outputs | `[grounded]` JD | What does a successful first year look like, especially for the contracts? | noted |

## Application plan

All rows are proposed. Nothing here is final until you approve it, and that covers both the table and any wording in the Why column.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with: built the dbt project on Snowflake (about 180 models); set up the Great Expectations test suite; Airflow orchestration; Python and SQL daily | Maps R3, R5, R6 and R2 to the JD's wording. Uses only your stated claims, and says nothing about ownership beyond "built" and "set up" | `[grounded]` your summary | pending your approval |
| E2 | Say plainly that BigQuery is new to you and give the Snowflake work as the transferable base | Keeps R7 adjacent, never claimed as experience | `[grounded]` your summary | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery project with a public dataset, finished before interviews, if you want to narrow R7's limit | See G1; only counts once it exists | `[inferred]` from G1's strengthener | pending your approval |
| Q1 | Ask RR1, RR3 and RR4's questions in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check R10 and R11 against your own constraints before investing time | See R10, R11 | `[grounded]` rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live ("Accepting applications") and matches your paste. It moved the contradictions row (none), and RR1, because both pages are the company's own, so its stage and size are not independently corroborated |
| 2. Role-family sweep | skipped | The Datawright report you supplied fixes market calibration and RR2, so a search could change neither |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A sanitized dbt lineage or project README → R3 to `high`.
- A BigQuery side project (W1) → R7's limit narrows.
- Answers to G2 and G3, or a sanitized pipeline diagram or contract → R8 and R9 resolve.
- Your location, work authorization and pay floor → R10 and R11 resolve, and the decision likely becomes `go` or `no_go`.
- The hiring manager's name → role reality's scope read, and which story the plan leads with for that reader.
- A deeper research pass on Pellucid Learning (independent funding and leadership coverage, hiring pattern, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you'd like, I can write this up as `tuesday-dossier.md` to keep or carry forward.

Questions:

- R10, R11 — Do you live in the US (or would you work from Denver), and is $148,000 at or above your pay floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- G2 — Have you built ingestion from a product app or a CRM into your warehouse, and what did you personally own? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- G3 — Have you agreed schema, definitions or freshness expectations with analysts or other consumers of your models, formally or informally? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.