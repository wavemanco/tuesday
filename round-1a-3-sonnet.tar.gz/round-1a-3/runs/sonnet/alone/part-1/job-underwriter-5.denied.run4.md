Output is being truncated; I'll read the files directly in chunks.
**Yes, it's worth applying. Status: `conditional_go`.** The conditions are below. Two things drive the "conditional": nothing here could confirm the posting or the company is current, and I don't know your location or pay terms.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8 · unclear: R9 (Ingestion from app and CRM)
- `important` — adjacent: R11 (BigQuery warehouse) · unclear: R10 (Data contracts for analysts)

R11 — a credible bridge, its limit named; R9 and R10 — areas your background is silent on, not ones it contradicts.

**Opportunity ledger.** Sound on its face but unverified. The employer and posting are unchecked (RR1), team structure and scope are unstated (RR2, RR3), and the equity terms are unstated (RR5). One entry runs the other way: pay is stated and sits inside the market band (RR4).

- **Hard gates:** none failed (R1, R2); unconfirmed: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and company verify as live and as described (RR1); (2) your location, US work eligibility and pay floor meet the role's terms (R1, R2); (3) R9 and R10 come out acceptably in your answers or in screening, and BigQuery is presented as adjacent, never as experience (R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026). Taken from the page text you pasted and not independently checked (RR1) | `[grounded]` pasted about page |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts analysts depend on | `[grounded]` JD |
| Location and pay | Remote (US) or Denver office; $148,000–$166,000 plus equity. The posting doesn't say whether the figure is base | `[grounded]` JD |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | Three areas (ingestion, warehouse modelling, contracts) under one title, with no team size, manager or reporting line stated. The pay report's typical scope is one domain's pipelines with no direct reports, so this may be wider, or may be one reporting domain end to end | `[inferred]` JD against the `[grounded]` pay report's stated typical scope |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years. The posted range starts $3,000 below that median and ends $2,500 above the upper quartile, so it sits in the upper half of the band. Your 6 years falls inside the typical 5–8 years. This is one report from your recruiter, n=2,310, and it is a band for the market, not a promise about this employer | `[generic]` role-family band from the provided report; `[grounded]` posting figures |
| Unknowns | Hiring manager; team size and structure; on-call expectations behind "run"; equity form and terms; whether the range is base; first-year outcomes | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and about page. No live-page check ran | `[grounded]` pasted texts |

## Evidence map

Your background was typed into the conversation. That counts as CV-equivalent self-report, so `medium` is the ceiling until something inspectable is attached.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you're eligible to work for a US employer. Confidence grades your statement of the constraint, and there is none yet | `[grounded]` JD; no constraint stated | Closing question R1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor isn't given, so whether the range meets it is unknown. The range itself is in band (RR4) | `[grounded]` JD; no constraint stated | Your floor would close it (upgrade menu) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. This is a length-of-experience requirement, not a gate | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Daily use is stated; depth is not inspectable yet | `[grounded]` your stated background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models, as you described it. No artifact inspected | `[grounded]` your stated background | A sanitized model or lineage screenshot would raise to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The posting's BigQuery is carried separately in R11 | `[grounded]` your stated background; JD "dbt and a cloud warehouse" | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. How much of the DAG authoring was yours isn't stated, and the row claims no more | `[grounded]` your stated background | A sanitized DAG excerpt would raise to `high` |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your stated background | A sanitized suite config or run summary would raise to `high` |
| R9 | Ingestion from the app and CRM | must_have | unclear | low | discovery | Your background says Airflow for orchestration but names no source systems. Nothing says which sources fed your pipelines, so the row stays open rather than assumed | `[grounded]` background silence | Closing question R9 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is the nearest thing in your background. It isn't contract work unless you say it involved agreements with producers or analysts | `[grounded]` background silence; `[inferred]` that the suite is the nearest evidence | Closing question R10 |
| R11 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | What carries over: dbt modelling at scale on a different cloud warehouse. Limit: you've never used BigQuery, so its warehouse-specific mechanics are unexercised. Warehouses generally differ in cost model, partitioning and adapter behaviour | `[grounded]` your stated gap; `[generic]` that warehouses differ in those ways | Gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, must_have) | discovery | Airflow orchestration is stated; the source systems feeding it are not | The posting leads with ingestion from these two source types, so which sources you handled decides how direct this row is | Pulling data from a product database, event stream or API; syncing a CRM or similar business system into the warehouse; handling schema changes from an upstream source | A sanitized DAG excerpt, an ingestion diagram, or a source-system list | `[grounded]` background silence; `[inferred]` that the posting leads with ingestion because it is first in the mandate |
| G2 | Data contracts (R10, important) | discovery | A Great Expectations suite, with no stated agreement with upstream producers or downstream analysts | The posting names contracts analysts depend on as one of three deliverables | Agreeing schema or freshness guarantees with a producing team; testing a source against an agreed expectation; notifying or coordinating with analysts when a model's output changed | A contract doc, a schema-change policy, or an expectations file with its owners | `[grounded]` background silence; `[inferred]` that the posting treats contracts as a deliverable |
| G3 | BigQuery (R11, important) | transferability | dbt on Snowflake, about 180 models; no BigQuery use | The posting names BigQuery. The bridge is credible, and its limit decides how you phrase it | Any exposure to BigQuery even outside work, such as a side project or a read-only query | A small dbt-on-BigQuery project, if you choose to build one (W1) | `[inferred]` bridge from your Snowflake dbt work; `[grounded]` your stated limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not yet verified | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | Unchecked rather than contradicted: the pasted pages agree with each other, but the one search and one fetch sent were refused, so whether the posting is live and the funding claim holds is unconfirmed here | `[grounded]` the research calls refused; pasted texts consistent | Can you confirm this role is still open and who I'd be interviewing with? | unresolved |
| RR2 | Team structure and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | This may be the sole data engineer or one of a team; "run" may carry on-call duty | `[inferred]` from the posting's silence on team, manager and on-call | Who does this role report to, how many data engineers and analysts are on the team today, and is there an on-call rotation? | unresolved |
| RR3 | Scope may be wider than one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Three areas may fall to one person, against a typical scope of one domain's pipelines; it may equally be a single reporting domain end to end. Severity stays low because the posting doesn't say either way | `[inferred]` JD mandate against the `[grounded]` pay report's typical scope | Which of these areas would I own first, who owns the rest today, and what does a successful first year look like? | unresolved |
| RR4 | Pay stated and in band | positive_signal | — | "$148,000–$166,000 plus equity" | The range straddles the report's $151,000 median and reaches just past its upper quartile, so there is no mismatch with a 5+ year Senior title | `[grounded]` posting and pay report | Is the range base salary, and does it differ for Denver versus remote? | noted |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | Form, quantity, vesting and strike aren't stated, so its value can't be compared | `[inferred]` from the posting's silence | What form is the equity, how much is offered, and what are the vesting and strike terms? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with two statements in your own words: "built our dbt project on Snowflake, about 180 models" and "set up our Great Expectations test suite", and name Airflow as the orchestration you used | see R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| P2 | Put the BigQuery limit in plain words: "I haven't used BigQuery; my dbt work has been on Snowflake" | see R11 | `[grounded]` your stated gap | pending your approval |
| A1 | Before investing effort, check the role is live on pellucidlearning.com's own careers page yourself | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the questions of RR2, RR3, RR4 and RR5 verbatim in a screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Optional: a small dbt project on BigQuery using public data, to narrow R11's limit | see R11, G3 | `[inferred]` from R11's stated limit | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating, since you didn't give one.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring K-12 Denver Series C" and fetched pellucidlearning.com/careers/senior-data-engineer. Both were refused, so nothing came back. It would have confirmed the posting is live and that the company matches the pasted description (role reality's organization and contradictions rows, and RR1) |
| 2. Role-family sweep | skipped | The pay report you supplied is in hand and fixes the market calibration, the typical-scope comparison and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, and the posting names none |

I did not retry the refused calls.

If you want, I can write this up as `tuesday-dossier.md` to carry forward.

## Upgrade menu

- Permission to run the page check (one fetch of the careers page, one search), or the live posting text pasted in → RR1 closes and role reality's contradictions row is checked against the live page.
- Your base-pay floor → R2 closes.
- Your CV, or a sanitized dbt lineage screenshot, DAG excerpt or Great Expectations suite summary → R5, R7 and R8 can reach `high`, and a CV would show whether it already presents these well.
- A hiring manager's name → role reality's scope read and which of your stories P1 should lead with for that reader.

## Questions

1. **R1** — Are you based in the US (or willing to work from the Denver office), and eligible to work for a US employer without sponsorship?
2. **R9** — Which source systems did your Airflow pipelines ingest from, and what did you personally own in getting them into Snowflake?
3. **R10** — Did you ever agree schema, freshness or quality guarantees with an upstream team or with analysts, and did your Great Expectations suite enforce them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.