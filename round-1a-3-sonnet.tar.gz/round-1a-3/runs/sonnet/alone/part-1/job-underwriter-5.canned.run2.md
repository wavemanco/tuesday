I've read the underwriting rules, and I'm now checking pellucidlearning.com's careers page and funding claim against what you pasted, before I write the assessment.
# Job Underwriting Assessment: Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Yes, this is worth applying to, on conditions. R1 and R2 are hard gates I can't check because I don't have your location or pay floor. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (Data contracts), R11 (Ingestion from app and CRM)

R9: a credible bridge from Snowflake, its limit named; R10 and R11: your account is silent on them, so they are worth a recall.

**Opportunity ledger.** The stated terms are sound. The pay band is published and sits at or above the report's median (RR4), and the employer's own pages match the posting (RR5). The team shape (RR1), the equity terms (RR2) and the on-call expectations (RR3) are unstated.

- **Hard gates:** none failed (R1 `unclear`, R2 `unclear`); unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based and authorized to work there, or willing to be in Denver (R1); (2) the range clears your pay floor (R2); (3) BigQuery is framed as adjacent and never as experience (R9); (4) the team shape and on-call questions answer cleanly in the interviews (RR1, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company's own about page, via search snippet; single-source (RR5) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, careers page fetched |
| Requirements stated | 5+ years, SQL and Python, dbt and a cloud warehouse, Airflow or similar, data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | Ingestion, warehouse modelling and contracts span one domain's whole lifecycle (reporting). Whether that is one engineer's remit or a team's is unstated | `[inferred]` from the mandate wording against the posting's silence on team size (RR1) |
| Market calibration | The report puts Senior Data Engineers at Series B–D companies at a $151,000 base median, interquartile range $139,000–$163,500. "Senior" typically means 5–8 years, with ownership of one domain's pipelines and no direct reports. The posting's low end is $3,000 below that median and its high end $2,500 above the range's top. It asks for 5+ years and mentions no direct reports | `[grounded]` pasted Datawright report (n=2,310) and JD for the figures; `[generic]` that the report's norms describe the title, never this employer's offer |
| Unknowns | Hiring manager and team size; equity terms; on-call; whether pay is banded by location; the CRM | `[grounded]` posting silent; no manager named |
| Contradictions | None. The careers page text matches the pasted JD and shows "Accepting applications" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or your work authorization, so there is no claim to grade. The JD's term is clear | `[grounded]` JD; no candidate statement | Q-R1 below |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor stated. The range itself is explicit | `[grounded]` JD; no candidate statement | Q-R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported with no inspectable artifact yet, so expect a probe on scope | `[grounded]` your background, intake prose | optional: a CV or LinkedIn history would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" is a level nothing here yet inspects | `[grounded]` your background | optional: a code sample or repo |
| R5 | dbt | must_have | direct | medium | none | You built the project, about 180 models, on Snowflake. Ownership and the figure are your own and unprobed | `[grounded]` your background | optional: a sanitized project structure or docs |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The JD's named warehouse is BigQuery, handled in R9 | `[grounded]` your background and JD | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as your orchestrator, with no scope detail yet | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is a testing framework, and own that setup | `[grounded]` your background | optional: a sanitized suite layout |
| R9 | BigQuery (named in the role description) | important | adjacent | medium | transferability | The same dbt and warehouse work carries over. Limit: you have never used BigQuery, so its cost model, partitioning and tooling are untested for you. Warehouses of this kind usually share concepts, though the details differ | `[grounded]` your background; `[generic]` that concepts transfer between warehouses | see G1 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing stated about agreements with downstream analysts, though Great Expectations and 180 dbt models may touch it | `[grounded]` background silent | see G2, Q-R10 below |
| R11 | Ingestion from the app and a CRM | important | unclear | none | discovery | Your sources at the payroll company aren't stated | `[grounded]` background silent | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt work that maps across, and no BigQuery use | The JD names BigQuery, so this is the likeliest probe | A side project or sandbox on BigQuery's free tier; a Snowflake-to-BigQuery comparison you wrote | A small public repo or a note on a migration you studied | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that the named warehouse is the likeliest probe |
| G2 | Data contracts (R10, important) | discovery | A dbt project and a test suite, with nothing on agreements with consumers | The JD names contracts as something analysts depend on | Agreed column definitions or SLAs with analysts; schema-change reviews; failing tests that blocked a release | A contract doc, a schema-change policy, a dbt `contract` config | `[grounded]` background silent |
| G3 | App and CRM ingestion (R11, important) | discovery | Pipelines are described, but not their upstream sources | The JD's first listed job is ingestion from the app and CRM | Pulling from a product database or event stream; a CRM sync such as Salesforce or HubSpot; an API loader you built | A sanitized DAG or architecture diagram | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team shape and manager unknown | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" (no hiring manager named) | The role may be a sole data engineer owning everything, or one of several on an established team | `[inferred]` from the posting's silence on team size and manager | Who does this role report to, and how many data engineers are on the team today? | unresolved |
| RR2 | Equity terms unspecified | unknown | — | "Salary $148,000–$166,000 plus equity" | Equity could be material or nominal, and the posting doesn't say | `[inferred]` from "plus equity" with no figure or structure | What form does the equity take, how much, and what is the vesting schedule? | unresolved |
| RR3 | On-call and "run" expectations unstated | unknown | — | "Build and run the pipelines" | "Run" may mean production support outside business hours, or may not | `[inferred]` from "run" alone, so held as a question and not a risk | Is there an on-call rotation for the pipelines, and how often do incidents page the team? | unresolved |
| RR4 | Pay band published and at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range runs from $3,000 below the report's $151,000 median to $2,500 above its interquartile top ($163,500), so it reads as market-rate or better, with no seniority-pay mismatch. It may be banded by location | `[grounded]` JD range against the pasted Datawright report | Does this range apply to remote US hires, or does it vary by location? | noted |
| RR5 | Funding and headcount are single-source | unknown | — | "Series C ($52M, February 2026)" | Both figures come from the company's own about page, and one search found no independent report of the round. The posting is live and consistent | `[grounded]` about and careers pages; `[generic]` that a first search often turns up only the company's own page | Is the Series C round announced publicly, and what is the current runway? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with dbt at scale (about 180 models) and the Great Expectations suite you set up, since these map to R5 and R8 | Both sit directly under the JD's named stack | `[grounded]` R5, R8 | pending your approval |
| A2 | Frame BigQuery as new and Snowflake as the nearest equivalent. Don't claim BigQuery experience, and consider a small sandbox project to close G1 | See R9; wording can't turn adjacent into direct | `[grounded]` R9 row | pending your approval |
| A3 | Ask the RR1, RR2, RR3 and RR4 questions in the loop, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Check R1 and R2 against your own location and pay floor before spending effort on the loop | Hard gates; nothing else offsets them | `[grounded]` R1, R2 rows | pending your approval |

Every row above is a proposal, and the prose around the table is covered too. Nothing becomes CV language or outreach text until you approve it.

## Evidence status

Verified: none yet. Your background is intake prose, so it counts as a lead and not as proof. No prior-context memory leads were used.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C $52M tutoring Denver", which returned only "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live and matches your paste. That settled role reality's contradictions row, and it left the funding and headcount single-source (RR5) |
| 2. Role-family sweep | skipped | The pasted Datawright report fixes market calibration and the pay check (role reality, RR4), so a search would not have changed either |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form. A name would unlock role reality's scope read and which story the application plan leads with |

I can write `tuesday-dossier.md` from this assessment whenever you want it.

## Upgrade menu

- A CV, LinkedIn history or code sample → R3, R4 and R5 can reach `high`, and A1 can be drafted from inspectable material.
- A sanitized DAG or architecture diagram → R11 (G3) and R7 move.
- A sanitized contract doc or dbt `contract` config → R10 (G2) resolves.
- A small BigQuery sandbox project → R9's limit narrows (G1).
- The hiring manager's name → role reality's scope read, and the plan's lead story.
- A deeper research pass on Pellucid Learning (funding corroboration, leadership churn, public employee reports, recent news; up to 5 more searches and 2 more fetches) → RR5 closes or sharpens. Say the word and it runs.

## Questions

R1 — Are you based in the US and authorized to work there without sponsorship, or would you take the Denver office?
R2 — Does $148,000–$166,000 clear your pay floor, and is equity something you'd weigh against base?
R10 — Have you agreed column definitions, SLAs or schema-change rules with the analysts who use your models? If so, what did you own, and what happened when a contract broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.