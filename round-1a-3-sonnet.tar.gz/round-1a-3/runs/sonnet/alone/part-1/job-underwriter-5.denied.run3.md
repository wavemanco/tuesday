I'll read the reference files the skill requires before building the assessment.
**Yes, it's worth applying to, with conditions. Status: `conditional_go`.** R1 and R2 (hard gates) are unconfirmed against your own constraints, because you haven't given me your location or pay floor. RR1 (the employer) is unverified because my research was refused.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — unclear: R9 (ingestion from app and CRM), R10 (data contracts)
- `preferred` — adjacent: R11 (BigQuery)

R5 (`medium`) — the dbt build, with a stated scale; R8 (`medium`) — the Great Expectations suite, waiting on an artifact; R9 and R10 — your background is silent, so ask; R11 — a Snowflake bridge with its limit named.

**Opportunity ledger.** The posted pay sits inside the market band (RR2). The employer could not be verified from here (RR1). Team shape, on-call and authority (RR3) and equity terms (RR4) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) the location and pay terms meet your own requirements, see R1 and R2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently checked, because research was refused |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts analysts depend on | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity (terms unstated) | `[grounded]` JD |
| Seniority | "5+ years" sits inside the 5–8 years the report says "Senior" typically means | `[grounded]` JD and the pasted Datawright report |
| Scope read | Ingestion, warehouse modelling and contracts are three layers under one title. That may be wider than the single-domain pipeline ownership, with no reports, that the report calls typical | `[inferred]` from the JD's three named layers against the report's typical scope |
| Market calibration | Posted floor is $3,000 under the report's base median ($151,000). Posted ceiling is $2,500 over its 75th percentile ($163,500). Equity is on top. This is the report's Series B–D band (n=2,310), not this employer's offer | `[generic]` band from the recruiter's report; `[grounded]` JD figures |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Hiring manager (unnamed), team size, who owns contracts today, on-call expectations, equity terms, whether BigQuery experience is expected on day one, posting date | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the about text you pasted. Whether the posting is live was not checked | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you'd work from. The role offers two options, so whether either meets your constraint is unknown | `[grounded]` JD; no candidate constraint given | G4 question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so the range can't be tested against it. The range sits at the market median or above (RR2) | `[grounded]` JD; `[generic]` band | G4 question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. That meets the ask, and a length-of-experience ask is graded, not gated. Self-report, no CV inspected, so `medium` | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both is stated. How strong is untested; interviews for this title commonly test it live | `[grounded]` your statement; `[generic]` on interview practice | none |
| R5 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models." Specific and plausible; nothing inspectable yet | `[grounded]` your statement | A dbt docs lineage graph or sanitized repo excerpt would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, which meets the stated requirement. The posting's actual platform is BigQuery (R11) | `[grounded]` your statement and JD | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You name Airflow, which is the JD's own example | `[grounded]` your statement and JD | A sanitized DAG excerpt would raise it to `high` |
| R8 | Data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite." Specific; no artifact yet | `[grounded]` your statement | A sanitized suite config or checkpoint list would raise it to `high` |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background doesn't mention what fed your warehouse. Payroll companies typically ingest from product databases and third-party systems, so evidence may exist | `[grounded]` silence; `[generic]` on the industry pattern | G1 question |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The GE suite is indirect context. Nothing says whether you agreed schemas, freshness or tests with analysts or upstream teams | `[grounded]` GE claim and silence | G2 question |
| R11 | BigQuery specifically (inferred requirement) | preferred | adjacent | medium | transferability | The JD's requirements say "a cloud warehouse", but its role description names BigQuery. You confirmed you've never used it; the Snowflake and dbt work is the bridge | `[inferred]` from the role description against the requirements list; `[grounded]` your statement | G3 bridge below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Your background covers modelling, orchestration and testing but not what fed the warehouse or how | It's half of the first thing the JD says you'll build, and a direct answer would move R9 to `direct` | Loading from a product database or event stream; pulling from a CRM or a third-party payroll or benefits system by API or file drop; replicating or snapshotting source tables | A sanitized DAG, a source-system diagram, or an ingestion README | `[grounded]` silence; `[inferred]` that this closes the row |
| G2 | Data contracts (R10, important) | discovery | The GE suite is a quality control; it isn't shown to be an agreement with consumers | The JD names contracts as the thing analysts depend on, so this is the likeliest probe | Agreeing schema, freshness or null-rate rules with analysts or source owners; dbt tests or documented model guarantees that consumers relied on; handling a breaking upstream change | A sanitized dbt schema file with tests, a freshness SLA note, or the GE expectation list | `[grounded]` GE claim; `[generic]` that contracts are probed in roles like this |
| G3 | BigQuery (R11, preferred) | transferability | Snowflake and dbt carry over. Never used BigQuery | A bridge is only credible with its limit stated | Adjacent: warehouse SQL and dbt modelling. Limit: no BigQuery use, so its platform specifics are untested. Strengthener: a small dbt project of yours run against BigQuery | A short repo or a one-page note on what you ran | `[grounded]` your statement; `[generic]` that warehouse-specific behaviour differs between platforms |
| G4 | Location and pay terms (R1 and R2, hard_gate) | hard_gate | Your constraints weren't given | A gate the inputs don't settle stays open until you answer | Not applicable; this is a yes or no on your own terms | None | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The entity may be too new or small to show up in checks, the posting may be stale or aggregated, or it may not represent a real hiring employer. No reason is ranked as likelier | `[generic]` pattern for any employer a search can't confirm, not a claim about this one | Can you point me at this role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Posted pay is inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is stated up front and spans the report's median to just above its 75th percentile | `[grounded]` JD figures against the pasted report | Where in the range would you expect to place someone with 6 years of experience? | noted |
| RR3 | Team shape, authority and on-call unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | "Build and run" may mean on-call ownership. The posting also doesn't say whether this is a first data-engineering hire or a team seat | `[inferred]` from the JD's wording against its silence on team and rotation | Who is on the data team, who does this role report to, and is there an on-call rotation? | unresolved |
| RR4 | Equity unquantified | unknown | — | "Salary $148,000–$166,000 plus equity" | The grant size, vesting and strike terms are absent, so total compensation can't be compared with other offers | `[grounded]` JD silent on terms | What is the equity grant range for this level, and what are the vesting and strike terms? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put your dbt project (about 180 models, on Snowflake) and the Great Expectations suite you set up where a first screen reads them. Use only your own verbs — "built", "set up" — and no scale or ownership beyond your sentences | R5, R8 | `[grounded]` your statements | pending your approval |
| E2 | Name Snowflake as the warehouse you used, and don't list BigQuery as a skill | R6, R11 | `[grounded]` your statement | pending your approval |
| W1 | An optional small dbt project run against BigQuery, only if you actually build it | G3 | `[grounded]` your statement | pending your approval |
| A1 | Confirm the posting is live on the company's own careers page, and check the recruiter's email domain, before investing in the loop | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1, RR3 and RR4's questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

`resume_edits_pending_approval`: E1 and E2 are proposals. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring K-12 Denver Series C" and "Pellucid Learning careers Senior Data Engineer"; both were refused for permission and returned nothing. It would have moved RR1, the Organization row and the Contradictions row in role reality |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration line and RR2, so a search would not have changed them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Upgrade menu

- Search permission granted → RR1 can be checked, and the Organization and Contradictions rows move off pasted-text-only.
- A link to the live posting, or the recruiter's email domain → RR1 resolves either way.
- Your CV (not yet seen; the background you typed is treated as CV-equivalent) → R3 to R8 can be checked against its wording, and E1 and E2 can be written against the real text.
- A dbt docs lineage graph, a sanitized Airflow DAG, or a Great Expectations suite config → R5, R7 or R8 to `high`.
- A hiring manager's name → role reality's scope read and which story the plan leads with.

Say the word and I'll write this up as `tuesday-dossier.md`.

G4 — Which of the two locations (Remote (US) or Denver) would you work from, and is a $148,000 base at or above your floor?
G2 — Have you agreed schemas, freshness or test rules with analysts or source owners, what did you personally own, and what happened when something upstream broke the agreement?
G1 — What fed your warehouse, and did you personally build or run any of those ingestions? Say which systems, and whether any was a customer-facing app database or a CRM.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.