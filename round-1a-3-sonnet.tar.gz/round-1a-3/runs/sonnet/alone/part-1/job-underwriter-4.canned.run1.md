I'm reading the skill's reference files so the assessment follows its required format. The only one left is the research-tier rules.
**Yes, apply — `conditional_go`.** R9 (insurance experience, preferred) is `direct` through your motor work, and it is the nearest the map comes to your two worries. Pet insurance is the product here, not a stated requirement. The JD asks for no management experience, so no map row exists for it. The condition is R1: the posting says fully remote, but the company's careers page says otherwise.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7, R8a
- `important` — unclear: R8b (Recommendations to product)
- `preferred` — direct: R9

R8b — your history shows underwriting recommendations, not product ones; R5 (`medium`) — monitoring is read from "maintained", not stated.

**Opportunity ledger.** The role is well defined, but the JD and the careers page disagree on the working pattern (RR1), the salary is not in your pasted JD (RR2), and the size of the pet book and team is not established (RR4). One entry runs the other way: the hiring manager has spoken publicly on monitoring models in small books (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern confirmed as one you can accept (R1, RR1); (2) the pet-insurance gap framed honestly as unfamiliar product, never as domain expertise (R9); (3) a salary range obtained before the loop deepens (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, with a live careers page for this role; stage, size and pet-book scale not established | `[grounded]` careers page fetched; first company search returned nothing |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD and careers page agree on the mandate |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | JD says fully remote (UK); the careers page says "Leeds office four days a week" | `[grounded]` both sources, in conflict (RR1) |
| Scope read | Reads as a single-owner analytics post for one product, with no direct reports mentioned | `[inferred]` from "Own pricing analytics" and no team language in the JD |
| Market calibration | Median base £58,400, interquartile range £52,100 to £64,900 for senior pricing analysts at UK insurers and insurtechs. This is the market band, never Brindlemoor's offer; the pasted JD states no salary | `[generic]` Pricewell 2026 pay survey (search snippet); `[grounded]` JD silent on salary |
| Hiring manager | Odile Varga, Director of Pricing, presented "Small Books, Loud Errors" on monitoring rating models in small books at the 2025 Insurance Pricing Forum; previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile snippet |
| Unknowns | Working pattern; salary; pet-book size; team size; how models are monitored today | — |
| Contradictions | JD "fully remote" against careers page "Leeds office four days a week" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD and the careers page conflict, and your location and working-pattern needs were not given, so neither side can be checked | `[grounded]` JD against careers page; candidate constraints not given | RR1's question to the employer; G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. This is your own account, with no artifact yet | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Strength is not evidenced beyond that | `[grounded]` your statement | a sanitized code sample would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but no artifact yet | `[grounded]` your statement | a sanitized model summary would raise to high |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Building is stated. Monitoring is inferred from "maintained", with no cadence, metrics or triggers given, so expect a probe | `[grounded]` build and maintain; `[inferred]` monitoring | G3 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team | `[grounded]` your statement | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R8a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Price tests run with underwriting and a quarterly review to its head are consistent with this; recommendations as such are not stated | `[inferred]` from R6 and R7 | confirm in G3's answer |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your history touches a product team | `[grounded]` silence in your account | G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer meets the wording. Pet insurance is not in your history, and the JD does not ask for it. Expect a question on it | `[grounded]` your statement and JD wording | frame as adjacent product knowledge, never pet expertise |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | Two employer sources disagree; your own constraint is not known | Hybrid in Leeds could rule the role in or out for you | Your location and what you can accept | The employer's written answer on the pattern | `[grounded]` the two sources; `[inferred]` that it could decide the role for you |
| G2 | Recommendations to product (R8b, important) | discovery | Underwriting audience only | A named gap on the JD's second audience | A price-test result that changed a product feature, a pricing-to-product handover, or a product-team review you contributed to | A sanitized test-readout deck or decision note | `[grounded]` your account; `[generic]` that this role family reads recommendations to both audiences |
| G3 | Monitoring of rating models (R5, must_have) | discovery | "Maintained" is stated; what you watched and when is not | The hiring manager has spoken publicly on monitoring, so it is likely to be probed | Drift or loss-ratio dashboards, A/E checks, re-fit triggers, a model-performance review | A sanitized monitoring pack or dashboard screenshot | `[grounded]` your account and the talk title; `[inferred]` that it will be probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between JD and careers page | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The posting copies may differ in age, or the role may be office-based with the JD text outdated. Held at medium because both could be a copy slip | `[inferred]` from two sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated in the JD you pasted | unknown | — | No figure in the pasted JD | The offer may sit inside the market band or outside it; the band is not this employer's offer | `[generic]` Pricewell band; `[grounded]` no figure in the JD | What is the salary range for this post? | unresolved |
| RR3 | Hiring manager's public work centres on model monitoring | positive_signal | — | "Small Books, Loud Errors" (2025 Insurance Pricing Forum) | Monitoring may be a priority for the team, which fits R4 and R5 | `[grounded]` the public talk title; `[inferred]` that it reflects the team's priorities | How are rating models monitored today, and what triggers a re-fit? | noted |
| RR4 | Company stage, team size and pet-book scale not established | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be a sole owner on a small book; this is a pattern, not a finding about Brindlemoor | `[generic]` small-company pattern; `[grounded]` first company search returned nothing | How large is the pet book, and who else is on the pricing team? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the young-driver GLM you built and maintained, written in your own stated facts and no wider | see R4, R5 | `[grounded]` your statement | pending your approval |
| E2 | A bullet pairing the 14 price tests with the quarterly review to the head of underwriting | see R6, R7, R8a | `[grounded]` your statement | pending your approval |
| E3 | Add a monitoring bullet only after G3 is answered and confirmed | see R5 | `[grounded]` R5 row | pending your approval |
| P1 | In the interview, lead the model story with monitoring and small-book realities, since that is the hiring manager's public topic | see RR3 | `[grounded]` the public talk title | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4's questions verbatim, RR1 first | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Settle the working pattern with the employer before investing in a full application | see R1, RR1 | `[grounded]` RR1 | pending your approval |

Every row above, and the prose advice with it, is a proposal. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned nothing, so stage, size and product are not established. Searched "Brindlemoor careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality: the contradictions and working-pattern rows, and RR1 |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration `[generic]`, and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Role reality's hiring-manager row, RR3 and P1 |

I can write the full findings up as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Your location and whether hybrid in Leeds is acceptable → R1 and RR1 resolve against your constraints, and the decision likely becomes `go` or `no_go`.
- Your salary floor → RR2 can be set against the £52,100 to £64,900 band and the pay question prioritized.
- A sanitized model summary, monitoring pack or code sample → R3, R4 and R5 rise toward `high`.
- A test-readout deck or decision note involving a product team → R8b closes or is confirmed absent.
- A deeper research pass on Brindlemoor (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. G1 — Where are you based, and could you do hybrid in Leeds four days a week, or do you need fully remote?
2. G3 — For the young-driver GLM, what did you personally monitor after launch, how often, and what would trigger a re-fit?
3. G2 — Have you ever taken a price-test result to a product team, or to anyone beyond underwriting, and what changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.