**Not worth pursuing. R1 and R2, both hard gates, fail, so the status is `no_go`.** Your instinct that something is off is right on two counts: the posting breaks both of your non-negotiables, and it also carries risks of its own.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin, five days a week), R2 (Base $70–85k against your $150k floor)
- `must_have` — direct: R3, R4, R5
- `important` — unclear: R6 (SEO and content), R7 (Brand, PR, partnerships, sales ops), R8 (Team of one, no bench)

R1, R2 — a failed pair that no wording closes; R3 — nine years against the eight asked; R4, R5 — your own account, no artifact yet; R6, R7, R8 — nothing stated, so nothing to read.

**Opportunity ledger.** Apart from your constraints, the posting puts seven functions on one person (RR3), expects evenings and weekends (RR4), and leaves success undefined (RR5). The employer is also not checked (RR6). The CEO reporting line is the one positive entry (RR7).

- **Hard gates:** failed: R1 (On-site Austin, five days a week), R2 (Base $70–85k against your $150k floor).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the employer would have to confirm in writing that the role can be done remotely from Portland (R1) and that base pay is at least $150k (R2). The pay gap alone is at least $65k, from $85k to $150k.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup. The posting says Series A and "profitable since day one" | `[grounded]` JD header; not checked against any outside source |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Schedule | "Evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Location | On-site in Austin five days a week, "no exceptions" | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside", with no equity figure | `[grounded]` JD |
| First-90-days outcomes | None stated; the posting says success metrics "will evolve as we learn" | `[grounded]` JD silence |
| Scope read | A department-sized mandate with no stated team, budget or decision rights, not a single-discipline growth post | `[inferred]` from seven named functions against "team of one" and no stated budget |
| Market calibration | Not established. The sweep did not run, so no band is stated and the posting's pay is not compared to a market figure | `[grounded]` search permission was not granted |
| Unknowns | Budget, revenue target, equity size, who is on the board, whether the posting is live on the company's own site | `[grounded]` JD silence on each |
| Contradictions | None checked; the JD was not compared with a careers page | `[grounded]` no fetch ran |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, five days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the limit ("remote-only … I live in Portland and I'm not relocating"), which is specific and your own. The fit fails because the posting rules out remote work | `[grounded]` JD quote and your stated constraint | Surface only; the employer changing terms or you revising the constraint are the only resolutions |
| R2 | Base $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor, which is specific and your own. The fit fails because the top of the posted range is $65k under that floor | `[grounded]` JD figure and your stated floor | Surface only; same two resolutions as R1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You report nine years, Growth lead then Head of Growth. This is a length-of-experience requirement, so it is not a gate. The claim is from your message, so it sits at `medium` | `[grounded]` your stated background, no document inspected | A CV or LinkedIn history would confirm the dates |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid at two B2C subscription companies, with a controlled budget while scaling one from $8M to $40M ARR over three years. Specific, but no inspectable proof yet. The budget amount is not stated | `[grounded]` your stated background | A channel-level spend and results summary would raise it to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and have deep Braze experience. Specific, with no artifact yet | `[grounded]` your stated background | A Braze program or retention report, sanitized, would raise it to `high` |
| R6 | SEO/content | important | unclear | none | discovery | Your background does not mention SEO or content ownership. Silence is not absence, so this is not marked `absent` | `[grounded]` silence in your message | G3 |
| R7 | Brand, PR, partnerships and sales ops | important | unclear | none | discovery | Nothing stated for any of the four. This is one row because all four are equally silent. Sales ops and partnerships are the furthest from a B2C subscription background | `[grounded]` silence in your message; `[inferred]` distance from your described roles | G4 |
| R8 | Hands-on execution as a team of one | important | unclear | low | discovery | You managed teams of 3–7, which shows leadership but not solo execution. Your SQL, GA4 and Braze skills suggest hands-on ability, but that is a reading and not a stated claim | `[grounded]` team sizes you gave; `[inferred]` hands-on ability from the tools named | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | On-site five days (R1) | hard_gate | The posting says "no exceptions"; you are remote-only in Portland | It fails alone, whatever your fit elsewhere | Nothing counts as a substitute; only changed terms resolve it | A written statement from the employer on remote or hybrid work | `[grounded]` JD and your constraint |
| G2 | Base pay (R2) | hard_gate | $70–85k posted against your $150k floor | It fails alone, with no wording that narrows $65k | Nothing counts as a substitute | A written statement of the budgeted base | `[grounded]` JD and your constraint |
| G3 | SEO and content (R6, important) | discovery | No SEO or content ownership appears in your background | Without evidence, one of seven mandate areas is uncovered | Owning organic landing pages for subscription acquisition; commissioning or editing content tied to signups; working with an SEO agency on a roadmap | A traffic or conversion report, a content calendar, an SEO audit | `[grounded]` silence in your message |
| G4 | Brand, PR, partnerships, sales ops (R7, important) | discovery | Nothing stated for any of the four | The mandate names all four, and no evidence means no coverage | A launch campaign with PR; an affiliate or partner channel you managed; a sales or CRM handoff you designed | A partner program brief, a launch plan, a press hit list | `[grounded]` silence in your message |
| G5 | Solo execution (R8, important) | discovery | Teams of 3–7 led, with no evidence of working without a bench | The posting says "a team of one to start" | Periods when you personally built campaigns, dashboards or tests | A dashboard or campaign you built yourself | `[grounded]` team sizes you gave |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site requirement conflicts with remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role is incompatible with your stated constraint as written | `[grounded]` JD and your constraint | Is any part of this role open to remote work from outside Austin? | confirmed |
| RR2 | Posted pay conflicts with your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base sits at least $65k under your floor; equity is unquantified and cannot be weighed | `[grounded]` JD figure and your floor | Is $70–85k the full base range, and is there any room above it? | confirmed |
| RR3 | Seven functions bundled on one person | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops … a team of one to start" | A department's worth of work may be priced as one mid-level post, which is a seniority-compensation mismatch until a market sweep confirms or clears it | `[inferred]` from the named functions against the stated pay and team; `[generic]` that bundled-role postings often work this way | What budget and headcount are committed for this function in the first twelve months? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine and not exceptional | `[inferred]` from the phrase "just who we are" | In the last quarter, how many evenings or weekends did the growth function work? | unresolved |
| RR5 | Success undefined on a broad mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be accountable for outcomes with no agreed target | `[inferred]` from the JD's silence on targets | What revenue or growth target will this role be measured against in the first year? | unresolved |
| RR6 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a live hiring employer; none of these is more likely than the others | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who I would be interviewing with? | unresolved |
| RR7 | Reporting line to the CEO with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | Senior access and visibility, though the posting gives no detail on how it works | `[grounded]` JD states it; not verified | Who sits on the board, and how often would this role present to it? | noted |

## Application plan

Every row is a proposal. Nothing is finalized without your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not spend application effort on this posting while R1 and R2 stand | see R1, R2 | `[grounded]` the two failed gates | pending your approval |
| A2 | If you want to test whether the terms flex, ask the employer RR1 and RR2's questions verbatim before doing anything else | see RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | No CV edits are proposed. R3, R4 and R5 are already stated in terms the posting uses, and R6 to R8 have no evidence to surface | see R3, R4, R5 | `[grounded]` the evidence map | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A Head of Growth"; the call was refused, so no results came back. It would have moved role reality's organization and contradictions rows and RR6 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary Series A startup base salary range 2026"; the call was refused, so no results came back. It would have moved role reality's market calibration and the RR3 hypothesis |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd offer to build `tuesday-dossier.md` from this assessment if you want a saved copy.

**Upgrade menu**

- Search permission → runs the company and pay checks, filling role reality's organization and calibration rows and settling RR6.
- The employer's written answer on remote work and base pay → the only input that could move the status (R1, R2, RR1, RR2).
- A growth summary behind the $8M to $40M scale-up, or a channel report, or a Braze retention report, sanitized → R4 and R5 to `high`.
- Any SEO, content, partnership or sales-ops history → R6 and R7.
- A hiring manager's name → role reality's scope read.
- Your stage isn't stated, so I assumed you are evaluating.

No questions this turn: nothing you could answer would change the status unless the employer moves on R1 and R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.