I've read the skill's rules. Next I'm checking that Pellucid Learning and the posting exist as pasted (one search, then possibly one page fetch), and then I'll write the assessment.
## Decision snapshot

**Yes, worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9: a credible bridge from Snowflake, its limit named; R10, R11: nothing in your payroll work shown against them yet, recoverable by recall.

**Opportunity ledger.** Sound on the facts supplied, though the posting itself is unchecked. The stated pay sits inside the market band (RR3), team shape and scope are unspecified (RR1), liveness is unchecked (RR2), and equity is unsized (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on the company's own careers page (RR2); (2) location and pay clear your own non-negotiables (R1, R2); (3) BigQuery is framed as adjacent, never as experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, Denver, founded 2016, 264 employees, Series C ($52M, February 2026). It sits inside the survey's Series B–D bracket. | `[grounded]` the about-page text you pasted; not checked against the live site (see Evidence status) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Ingestion, modelling and contracts together reach past the one-domain, no-reports scope the survey calls typical. It may be a broad single-owner role, or a team may split it. | `[inferred]` from the JD's three-part mandate against its silence on team size; `[generic]` survey scope |
| Market calibration | Posted low end is $3,000 below the survey's base median of $151,000. Posted top is $2,500 above the upper quartile of $163,500. Your 6 years sits inside the survey's usual 5–8 for "Senior". I assume the posted figure is base, since the JD says "salary". | `[generic]` Datawright 2026 report you supplied (n=2,310), one recruiter-sent source I haven't verified; `[inferred]` base reading |
| Unknowns | Team size and who you'd report to; first-90-day and first-year outcomes; equity terms; whether pay differs by location | `[grounded]` JD silent on each |
| Contradictions | None between your pasted JD and about text | `[grounded]` pasted material only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | low | hard_gate | You haven't said where you are or what your location constraints are, so I can't mark it met | `[grounded]` JD; your constraints not given | Answer the R1, R2 question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | low | hard_gate | The range is stated, but your floor isn't known. The band comparison is in Role reality. | `[grounded]` JD; floor not given | Answer the R1, R2 question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, stated by you; no inspectable artifact yet | `[grounded]` your message | Share your CV |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated by you; depth and scale not described | `[grounded]` your message | A sanitized code or model sample would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the project, about 180 models, on Snowflake. That is specific ownership. | `[grounded]` your message | A sanitized dbt docs or lineage view would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets the stated requirement. BigQuery specifically is R9. | `[grounded]` your message | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named. Whether you authored or maintained the DAGs isn't stated, so expect that probe. | `[grounded]` your message | Say what you owned |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is direct and specific | `[grounded]` your message | A sanitized suite config would raise it |
| R9 | BigQuery (the warehouse named in the role description) | important | adjacent | medium | transferability | Snowflake plus dbt carries over: same modelling discipline and SQL. Limit: you've never used BigQuery, so its cost and tuning model is untried. Billing and partitioning details differ across warehouses. | `[inferred]` adjacency from your Snowflake/dbt work; `[generic]` that warehouse specifics differ | See G1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your message doesn't say whether your payroll pipelines ingested from product or CRM sources | `[grounded]` your message silent | See G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite may bear on this, but no contract-style agreement is described | `[grounded]` your message silent; `[inferred]` that the suite may relate | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Strong Snowflake and dbt evidence; no BigQuery use | The JD names BigQuery, so the likeliest interview probe is whether you've used it. A stated limit reads better than a stretched claim. | A dbt project run against BigQuery, even a personal one; any migration or evaluation you took part in | A small repo or README, if you choose to build one | `[inferred]` from the JD naming BigQuery; `[generic]` that this is the likeliest probe |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Warehouse, dbt, orchestration and testing are shown; source ingestion isn't | Ingestion is the first named duty; evidence here shows whether the role is a close match | Loading product events or a CRM export into the warehouse; connector or custom extract work; handling source schema changes | A pipeline diagram, DAG screenshot or design note, sanitized | `[grounded]` your message silent; `[inferred]` duty weight from JD order |
| G3 | Data contracts (R11, important) | discovery | A test suite is shown; a written agreement with upstream teams or analysts isn't | The JD names contracts as something analysts depend on | Agreed schema, freshness or quality expectations with a source team; a checked, versioned expectation analysts relied on | A sanitized contract doc, or a suite config tied to a named consumer | `[grounded]` your message silent; `[generic]` that "contract" language usually means enforced expectations |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope and team unspecified | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | One engineer may hold the whole stack; or a team may split it | `[inferred]` from the three-part mandate against silence on team size; `[generic]` survey scope | How many data engineers are on the team, and who owns ingestion, modelling and contracts today? | unresolved |
| RR2 | Posting and company text unchecked against the live site | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | I couldn't run the check, so the pasted text may differ from the live pages or the posting may have changed; this is a gap in my checking, not a finding about the employer | `[grounded]` my search was refused | Can you point me to this role on your careers page, and who would I interview with? | unresolved |
| RR3 | Pay stated and in line with the survey | positive_signal | — | "Salary $148,000–$166,000 plus equity" | A stated range suggests transparent terms; it is near the supplied band | `[grounded]` JD; `[generic]` the supplied Datawright band | Is the range base salary, and is it the same for remote and Denver hires? | noted |
| RR4 | Equity unsized | unknown | — | "plus equity" | The value is unknown without grant size, vesting and valuation basis | `[grounded]` JD silent on terms | What is the equity grant range, vesting schedule and latest valuation basis for this level? | unresolved |

## Application plan

Every row is proposed and pending your approval. None of the wording is final until you approve it, and that includes the positioning advice as well as the resume lines.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume lines, drafted from your message, not a CV: "Built the company's dbt project on Snowflake, about 180 models"; "Set up the Great Expectations data-quality test suite"; "Orchestrated pipelines with Airflow" | see R5, R7, R8 | `[grounded]` your message | pending your approval |
| E2 | Lead with the dbt build and the test suite, and say plainly "Snowflake, not yet BigQuery" | see R9, G1 | `[inferred]` from the JD's emphasis; `[grounded]` your message | pending your approval |
| W1 | A small dbt project run against BigQuery, to narrow the R9 limit | see G1 | `[generic]` common way to close a platform gap | pending your approval |
| A1 | Confirm the posting is live on the company's careers page, and ask about team shape before investing in the loop | see RR1, RR2 | `[grounded]` register | pending your approval |
| Q1 | Ask the RR1, RR3 and RR4 questions verbatim at the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning senior data engineer careers Denver tutoring"; the call was refused by permission, so no result came back and no fetch was sent. It would have moved Role reality's contradictions row and closed RR2. Your pasted JD and about text stand unchecked. |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes market calibration and the pay comparison, so a further search would change nothing |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Upgrade menu

- Your location and your base-pay floor: R1 and R2 resolve, and the status can move to `go` or fall to `no_go`.
- A line on your ingestion work, and on any written data expectations you set with upstream teams or analysts: R10 and R11 move off `unclear`.
- Your CV: E1 gets drafted from your actual text instead of your summary.
- Any inspectable, sanitized artifact (dbt docs or lineage, a test-suite config, a DAG screenshot): R3 to R8 can rise from `medium`.
- Search permission: the live-posting and company-page check runs and RR2 closes. A deeper pass on Pellucid (funding, leadership churn, public employee reports; up to 5 more searches and 2 more fetches) is also available once search works.
- The hiring manager's name, if your recruiter has it: Role reality's scope read sharpens, and so does which story to lead with.

If you'd like, I can write all of this up as `tuesday-dossier.md` for you to keep or pass on.

Questions:

- R1, R2: Does Remote (US) or Denver, at $148,000–$166,000 plus equity, clear your own non-negotiables on location and pay?
- G2: At your payroll company, did you build or run ingestion from a product app or a CRM, and what did you own?
- G3: Did you ever agree schema, freshness or quality expectations with an upstream team or analysts, and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.