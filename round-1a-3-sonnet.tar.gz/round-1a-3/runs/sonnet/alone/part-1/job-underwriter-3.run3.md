Running two searches now: one to check that Novaline exists as the posting describes, and one for market pay and scope for a solo Head of Growth role.
**Not worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.** On paper you match the experience (R3, R4, R5, R6). What feels off is the role itself: the mandate and the pay (RR3, RR4) don't fit the seniority being asked for, and the posting rules out both of your constraints.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin 5 days), R2 (Base at least $150k)
- `must_have` — direct: R3, R4, R5, R6
- `important` — unclear: R7 (SEO and content), R8 (Brand and PR), R9 (Partnerships and sales ops), R10 (Team of one)
- `preferred` — unclear: R11 (Thrive on ambiguity)

R1, R2 — failed on the posting's own words; R3, R4, R5, R6 — match on paper, resting on your own account of your work.

**Opportunity ledger.** Beyond the two terms that clash with your constraints (RR1, RR2), the role reads as overloaded and thinly resourced (RR3, RR4, RR5, RR6), and the employer is not yet established (RR7). The stated profitability and CEO reporting line run the other way (RR8).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 (Base pay of at least $150k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting would have to allow remote work from Portland (it says "no exceptions") and offer a base of $150k or more (it states $70–85k). The posting gives no sign of either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; not checked against any outside source |
| Mandate | Own all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Resources and reporting | Team of one "to start"; reports to the CEO, dotted line to the board; no budget or headcount stated | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus equity "upside", with no stated amount or terms for the equity | `[grounded]` posting |
| Success measures | None stated: "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | Seven functions under a "Head of" title with no team: a senior title and mandate, resourced as an individual contributor | `[inferred]` from the function list against "team of one" |
| First 90 days / first year | Not stated | `[grounded]` posting silence |
| Market calibration | Not established: no pay or scope band was obtained (see evidence status) | `[grounded]` search refused |
| Unknowns | Headcount and budget; equity terms; what the board line involves; what success means | — |
| Contradictions | The "Head of" title beside "team of one" is in tension | `[inferred]` from the posting's own wording |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, no exceptions (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your constraint, which you stated. The posting excludes remote work in its own words | `[grounded]` posting and your stated constraint | none; wording can't resolve it |
| R2 | Base pay of $70–85k (your constraint: $150k minimum base) | hard_gate | hard_gate_fail | high | hard_gate | The top of the stated band is $65k below your floor. Equity is unquantified and doesn't change the base | `[grounded]` posting and your stated constraint | none; wording can't resolve it |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You have 9 years, with Growth Lead then Head of Growth roles at two companies. The claim is yours and specific, with no inspectable artifact yet | `[grounded]` your account | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You said you owned paid at both companies | `[grounded]` your account | none |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | You said you owned lifecycle and have deep Braze experience | `[grounded]` your account | none |
| R6 | Owning revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled, and built teams of 3–7 | `[grounded]` your account | none |
| R7 | SEO and content | important | unclear | low | discovery | Nothing you've said covers SEO or content | `[grounded]` your account is silent | see G1 |
| R8 | Brand and PR | important | unclear | low | discovery | Nothing you've said covers brand or PR | `[grounded]` your account is silent | see G2 |
| R9 | Partnerships and sales ops | important | unclear | low | discovery | Nothing you've said covers partnerships or sales ops | `[grounded]` your account is silent | see G3 |
| R10 | Working as a team of one, with no bench | important | unclear | low | discovery | You've led teams of 3–7. Hands-on solo execution across all functions isn't described | `[grounded]` your account; `[inferred]` that the role is mostly hands-on | see G4 |
| R11 | Thriving on ambiguity | preferred | unclear | low | discovery | Scaling a company from $8M to $40M suggests you can handle it, but you haven't described it | `[inferred]` from your scaling result | none; preferred and low value |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R7, important) | discovery | Nothing in what you described | Only matters if you pursue this despite the gates | Owning organic channel targets, working with a content team, a content-led acquisition test | A channel report or experiment log | `[grounded]` your account is silent |
| G2 | Brand and PR (R8, important) | discovery | Nothing in what you described | Same | Brand-awareness campaigns you ran, press or launch work | A campaign brief or results deck | `[grounded]` your account is silent |
| G3 | Partnerships and sales ops (R9, important) | discovery | Nothing in what you described | Same | Affiliate or referral programs, CRM-to-sales handoffs | A program summary | `[grounded]` your account is silent |
| G4 | Solo, hands-on operation (R10, important) | discovery | Your experience is leading teams | Same | Early-stage periods with no team, or channels you ran yourself | A role timeline | `[grounded]` your account; `[generic]` that "Head of" roles at lean companies are often hands-on |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site rule conflicts with remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The term leaves no room for remote work, so it can't be reconciled with your constraint | `[grounded]` posting against your stated constraint | Is any remote arrangement possible for this role, or is five days in Austin firm? | confirmed |
| RR2 | Base pay below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The base is $65k under your minimum at the top of the band, and the equity has no stated terms | `[grounded]` posting against your stated constraint | Is the base negotiable, and what are the equity terms? | confirmed |
| RR3 | Seniority-pay mismatch | risk_signal | medium | "8+ years growth leadership required" with "Own all revenue growth end to end" | The pay may be low for the mandate; no market band was obtained, so this stays a risk signal | `[inferred]` from the posting; band not checked | How was this pay range benchmarked, and is there flexibility? | unresolved |
| RR4 | Seven functions, no team or budget | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" and "a team of one to start" | You may be accountable for several full roles with no resources or decision rights | `[inferred]` from the posting's scope against its silence on budget and headcount | What headcount and budget are committed in year one? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be a routine expectation | `[inferred]` from the posting's wording | What does a normal week look like, and how often were evenings or weekends needed last quarter? | unresolved |
| RR6 | No success definition | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue growth with no fixed target to be judged against | `[inferred]` from the posting | What would success look like at 90 days and at 12 months? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer; no search ran, so none of these is ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and say who I would interview with? | unresolved |
| RR8 | Reporting line and profitability stated | positive_signal | — | "Report to the CEO with a dotted line to the board" and "profitable since day one" | If true, the role has senior access and a funded business | `[grounded]` posting states both; unverified | Who is on the board, and what does the dotted line involve? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1 and R2 both fail on the posting's explicit terms | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If you proceed anyway, ask RR1 and RR2 first, before any other step | The answers decide whether anything else matters | `[grounded]` register | pending your approval |
| A3 | If you proceed anyway, carry the other register questions (RR3–RR8) into any conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

I haven't proposed any resume language, since there is no case for applying yet.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A careers Head of Growth"; the call was refused (search permission not granted). It would have moved RR7 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup salary base range 2026 solo growth hire"; the call was refused. It would have moved role reality's market calibration and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` file you can keep, if you want it.

## Upgrade menu

- Search permission granted → the employer check (RR7) and a market pay and scope band for role reality and RR3, which would run the two refused searches again.
- A line from the employer on remote work and base pay → R1, R2, RR1 and RR2 could change, and the decision with them.
- The hiring manager's name → role reality's scope read.
- Evidence on SEO, brand/PR, partnerships and solo operation → G1 to G4 and R7 to R10, only relevant if the gates move.

No questions this turn. The decision rests on the posting's own terms and your stated constraints, so no answer from you would change it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.