I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Duinvaart is worth your time. Kroonhaven isn't.**

### Duinvaart Cold Chain, Operations Analyst: `conditional_go`

**Fit ledger.**

- `hard_gate` — unclear: D1 (Hybrid, three days in the Rotterdam office)
- `must_have` — direct: D2, D3, D4, D5
- `important` — adjacent: D7 (Work with depot managers on route changes) · unclear: D6 (Temperature compliance across the refrigerated fleet)
- `preferred` — adjacent: D8 (Dutch a plus)

D6 — the cold-chain piece your background doesn't mention; D7 — adjacent until we know whether your reviews led to route changes.

**Opportunity ledger.** The scope is concrete (DR3). The employer is not yet established from here (DR1), the salary is withheld (DR2), and whether the role recommends or decides route changes is unstated (DR4).

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) three Rotterdam days work for you, D1/GD1; (2) the posting is confirmed live on Duinvaart's own careers page, DR1; (3) no temperature-compliance claim goes on your CV until you've answered GD2, D6.

### Kroonhaven Foods, Supply Planner: `no_go`

**Fit ledger.**

- `hard_gate` — unclear: K1 (On-site in Utrecht)
- `must_have` — adjacent: K6 (Fluent Dutch) · unclear: K3 (Own the 13-week supply plan), K4 (Advanced Excel) · absent: K2 (3+ years of supply or demand planning in FMCG), K5 (SAP IBP or a similar planning system)
- `important` — adjacent: K7 (Run the weekly S&OP meeting)

K2, K5 — no planning work in your background; K6 (`medium`) — conversational against the fluent level asked.

**Opportunity ledger.** The scope is clear (KR3). The employer is not yet established from here (KR1) and the salary is withheld (KR2).

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** K2 and K5 would need real planning-role experience and a planning system behind them, and K6 would need Dutch at working fluency. None of that can be closed by rewording an application.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| D · Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet operator | `[grounded]` pasted posting; not checked against the company's own pages |
| D · Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| D · Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| D · Scope read | A standard analyst remit: metrics, dashboards, partnering with depot managers. No team, budget or decision rights mentioned | `[inferred]` from the posting's responsibilities against its silence on authority |
| K · Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` pasted posting; not checked against the company's own pages |
| K · Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| K · Working pattern | On-site in Utrecht | `[grounded]` posting |
| K · Scope read | A planning-owner post: the plan and the meeting are the job, and the posting asks for 3+ years of titled planning | `[inferred]` from the responsibilities and the stated experience requirement |
| Market calibration (both) | Not established: the role-family searches did not run, so there is no salary band for either title. Neither posting states pay | `[grounded]` posting silence; search refused |
| Unknowns | D: pay, commute fit, who owns the temperature data, whether the analyst recommends or decides route changes. K: pay, the meeting's working language | `[grounded]` posting silence |
| Contradictions | None inside either pasted posting. I couldn't compare them with the employers' own pages | `[grounded]` pasted postings |

## Evidence map

Your background came in as prose, so it counts as CV-equivalent self-report. That caps rows at `medium` until you give me something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You've said you worked in Amsterdam but not where you live or any limits, so there's no statement to grade and the gate isn't settled | `[grounded]` posting; your message silent | GD1 |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier, your own account. Limit: parcel, not refrigerated | `[grounded]` your background message | none |
| D3 | Strong SQL | must_have | direct | medium | none | "SQL daily" is specific, but "strong" has no inspectable proof yet | `[grounded]` your background message | a sanitized query sample would raise to `high` |
| D4 | Power BI or Tableau; weekly dashboards | must_have | direct | medium | none | Power BI daily, "including the on-time delivery dashboard our depot managers use". You haven't said whether you built it or maintain it, so I read it at the lower reading | `[grounded]` your background message | a sanitized screenshot, plus say which parts you built |
| D5 | Track on-time delivery | must_have | direct | medium | none | The on-time delivery dashboard depot managers use is this work | `[grounded]` your background message | same screenshot |
| D6 | Track temperature compliance across the refrigerated fleet | important | unclear | none | discovery | Your background doesn't mention temperature or cold-chain data. That is silence, not a confirmed absence | `[grounded]` your message silent | GD2 |
| D7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether the review led to route changes isn't stated | `[grounded]` your background message | GD3 |
| D8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but below fluent; the posting only calls Dutch a plus. Limit: state the level as conversational | `[grounded]` your message and posting | a CEFR level or certificate, if you have one |
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Same as D1: no location or limits stated | `[grounded]` posting; your message silent | GK1 (not asked; see queue) |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning, and the parcel carrier isn't FMCG. Years of experience is graded as a requirement, not a gate | `[grounded]` your message | closure path in GK2 |
| K3 | Own the 13-week supply plan; balance capacity against forecast | must_have | unclear | none | discovery | Nothing in your background says you've balanced capacity against a forecast. Your route reviews may touch volume, but that's unconfirmed | `[grounded]` your message silent | GK3, not asked while K stays `no_go` |
| K4 | Advanced Excel | must_have | unclear | none | discovery | You named SQL and Power BI; Excel is not mentioned | `[grounded]` your message silent | GK4, not asked |
| K5 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system in your background, consistent with having never worked in planning | `[grounded]` your message | closure path in GK5 |
| K6 | Fluent Dutch | must_have | adjacent | medium | transferability | You have conversational Dutch. It sits below "fluent", and a post that runs a weekly meeting is likely to lean on spoken Dutch | `[grounded]` your message and posting; `[inferred]` the meeting's language from the meeting-leading duty | GK6 |
| K7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: S&OP brings supply, production and commercial sides to one plan, and your review was operational | `[grounded]` your message; `[generic]` what an S&OP meeting involves | GK7 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GD1 | Rotterdam three days (D1, hard_gate) | hard_gate | The posting sets the schedule; your message gives no home location or limit | A failed commute ends this role regardless of fit | A term, not experience: only whether it works | None | `[grounded]` posting and your message |
| GD2 | Temperature compliance (D6, important) | discovery | Silence on temperature or cold-chain tracking | The most role-specific item in the posting and one you haven't addressed | Temperature-controlled or time-critical parcels; breach or exception reports; any compliance measure you tracked | A sanitized exception report or metric definition | `[grounded]` your message silent; `[generic]` that cold-chain postings weigh this item |
| GD3 | Route changes with depot managers (D7, important) | discovery | The review is confirmed; its outcomes aren't | Turns "adjacent" into "direct" if reviews changed routes | A review finding that led a depot manager to adjust a route or schedule | A sanitized review summary | `[grounded]` your message |
| GD4 | Dutch level (D8, preferred) | transferability | Conversational, stated by you | Preferred, so a minor item; the level must be stated honestly | Working in Dutch with depot staff | A CEFR level or course certificate | `[grounded]` your message |
| GK1 | Utrecht on-site (K1, hard_gate) | hard_gate | Same as GD1 | Moot while the role stays `no_go` | A term, not experience | None | `[grounded]` posting |
| GK2 | 3+ years of planning (K2, must_have) | capability | No planning role; no FMCG | A must-have with no direct or adjacent evidence | Planning, forecasting or capacity work not yet mentioned, which you've said doesn't exist | None | `[grounded]` your message |
| GK3 | 13-week plan (K3, must_have) | discovery | Silent on capacity-versus-forecast work | Would not rescue K2 | Volume forecasts or capacity checks in your route reviews | A sanitized forecast sheet | `[grounded]` your message silent |
| GK4 | Advanced Excel (K4, must_have) | discovery | Silent | Would not rescue K2 | Models, pivots, forecasting sheets | A sanitized workbook | `[grounded]` your message silent |
| GK5 | Planning system (K5, must_have) | capability | None | A must-have, closable only through a planning role or a course plus a role | None in your history | None | `[grounded]` your message |
| GK6 | Fluent Dutch (K6, must_have) | transferability | Conversational, stated by you | Fluency can't be closed in an application window | Dutch-language work meetings | A CEFR level | `[grounded]` your message |
| GK7 | S&OP meeting (K7, important) | transferability | A weekly route-performance review | A credible bridge, but S&OP is broader | Who attended, what was decided | A sanitized agenda | `[grounded]` your message; `[generic]` S&OP scope |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The search for it did not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| DR2 | Salary withheld | unknown | — | (the posting states no salary) | The figure may sit anywhere against a market band I couldn't establish | `[grounded]` posting silent | What salary range is budgeted for this post? | unresolved |
| DR3 | Concrete scope | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet, build weekly dashboards in Power BI" | The role's work is defined in measurable terms | `[grounded]` posting | Who owns the temperature data feeds today, and which systems hold them? | noted |
| DR4 | Route-change authority unstated | unknown | — | "work with depot managers on route changes" | The analyst may recommend changes or own them; the posting doesn't say | `[inferred]` from the posting's silence on decision rights | Does the analyst recommend route changes, or decide them? | unresolved |
| KR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The search for it did not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| KR2 | Salary withheld | unknown | — | (the posting states no salary) | The figure may sit anywhere against a market band I couldn't establish | `[grounded]` posting silent | What salary range is budgeted for this post? | unresolved |
| KR3 | Concrete scope | positive_signal | — | "Own the 13-week supply plan ... run the weekly S&OP meeting" | The role's duties are defined | `[grounded]` posting | Which production lines does the plan cover, and who signs off on it? | noted |

## Application plan

Everything here is proposed and finalized only on your approval. That covers the edits table and the advice rows. The resume-edit row is `resume_edits_pending_approval`, and each advice row is `pending your approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| DE1 | Resume summary: "Operations analyst, 4 years at a parcel carrier in Amsterdam. SQL and Power BI daily, including the on-time delivery dashboard our depot managers use. Ran the weekly route-performance review." | D2–D5, D7; every clause traces to your own sentences, and I've left out "built", which you didn't say | `[grounded]` your background message | `resume_edits_pending_approval` |
| DP1 | Write your Dutch as "conversational" in any note | D8; the posting only calls Dutch a plus | `[grounded]` your message and posting | pending your approval |
| DP2 | Write no line about temperature or cold-chain tracking until you've answered GD2 | D6 is unclear, and I can't assert it | `[grounded]` D6 row | pending your approval |
| DP3 | Confirm the posting on Duinvaart's own careers page before spending time on the application | DR1 | `[grounded]` DR1 | pending your approval |
| DP4 | In the loop, ask DR2, DR3 and DR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| KP1 | Don't tailor an application to Kroonhaven | K2 and K5 are absent, K6 is below fluent | `[grounded]` K2, K5, K6 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht" were both refused (search permission not granted). They would have moved role reality's Organization and Contradictions rows and the entries DR1 and KR1 |
| 2. Role-family sweep | unavailable | Searches "operations analyst logistics Netherlands salary Power BI SQL" and "supply planner FMCG Netherlands salary requirements SAP IBP" were both refused. They would have moved the market calibration row and the pay checks in DR2 and KR2 |
| 3. Hiring manager's public footprint | n/a | No names were given, so there was no query to form |

I can save this as a `tuesday-dossier.md` if you'd like to carry it forward.

## Upgrade menu

- The link to each posting on the employer's own careers page → DR1 and KR1 can be checked. Reading a link you give me isn't charged to the search budget.
- Where you live and any commute limit or pay floor → D1 and K1 resolve, and the hard-gates line stops flagging unchecked constraints.
- A sanitized dashboard screenshot or query sample, and which parts you built → D3, D4 and D5 can move to `high`.
- Any temperature-sensitive or time-critical shipment tracking you did → D6 resolves.
- A CEFR level or Dutch certificate → D8 and K6 firm up.
- A hiring manager's name for either role → the footprint target can run.
- Search permission → targets 1 and 2 could run, within what's left of the L1 budget (1 search, 2 fetches).

## Questions

GD1 — Would three office days a week in Rotterdam work for you from where you live?

GD2 — At the parcel carrier, did you ever track temperature-controlled or time-critical shipments, or any compliance measure like it? If so, what was it and what did you own?

GD3 — In the weekly route-performance review, did a finding of yours lead to a route or schedule change with a depot manager? What did you own and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.