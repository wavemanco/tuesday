I'll read the reference files the skill requires before building the assessment.
**Operations Analyst at Duinvaart: worth your time. A2, A3 and A4 land `direct`. Status: `conditional_go`.**
**Supply Planner at Kroonhaven: not worth tailored effort. B2, B3 and B4 have nothing behind them in what you've told me. Status: `no_go`.**

Row IDs: A-rows belong to Duinvaart, B-rows to Kroonhaven.

## Decision snapshot

**Fit ledger, Duinvaart (A)**

- `hard_gate` — unclear: A1 (Hybrid, three days a week in the Rotterdam office)
- `must_have` — direct: A2, A3, A4
- `important` — direct: A5a · adjacent: A6 (Work with depot managers on route changes) · unclear: A5b (Temperature compliance)
- `preferred` — adjacent: A7 (Dutch a plus)

A5b — cold-chain content untested; A6 — your route-performance review sits next to route changes; A1 — turns on where you live.

**Opportunity ledger, Duinvaart.** The posting could not be checked against the employer's own site (RA1), pay is not stated (RA2), and the responsibilities are concrete (RA3).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the commute works, A1; (2) the employer and live posting verify, RA1; (3) temperature compliance is framed as untested unless you have the experience, A5b.

**Fit ledger, Kroonhaven (B)**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B5 (Fluent Dutch), B6 (Run the weekly S&OP meeting) · unclear: B7 (Advanced Excel) · absent: B2 (3+ years of FMCG supply or demand planning), B3 (Own the 13-week supply plan), B4 (SAP IBP or similar planning system)

B2, B3, B4 — no planning work in the background you gave; B5 — conversational against a fluent requirement.

**Opportunity ledger, Kroonhaven.** The employer could not be checked (RB1), pay is not stated (RB2), and the scope is clearly defined (RB3).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** B2, B3 and B4 would need real planning experience and a planning-system track record, which is a change in your background and not a wording fix. The call is yours.

## Role reality

**Duinvaart Cold Chain, Operations Analyst**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, a refrigerated-fleet operator based in Rotterdam | `[grounded]` posting as you pasted it; could not be checked elsewhere |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A single-analyst reporting and analysis role with depot-manager contact; no team or budget is mentioned | `[inferred]` from the posting's list of duties and its silence on reports or budget |
| First outcomes | Not stated; the weekly dashboard is the visible recurring deliverable | `[inferred]` from "build weekly dashboards" |
| Market calibration | Not established. The role-family sweep could not run, so no pay band or scope norm is stated | `[grounded]` search permission was not granted |
| Unknowns | Pay; who the role reports to; whether "route changes" means recommending or deciding | `[grounded]` posting silent |
| Contradictions | None within the posting. It could not be compared with the careers page | `[grounded]` target 1 unavailable |

**Kroonhaven Foods, Supply Planner**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, a chilled ready-meals producer in Utrecht | `[grounded]` posting as you pasted it; could not be checked elsewhere |
| Mandate | Own the 13-week supply plan for the chilled ready-meals range, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A full ownership role over one product range, not an analyst-support role | `[inferred]` from "Own", "balance" and "run" in the posting |
| First outcomes | Not stated | `[grounded]` posting silent |
| Market calibration | Not established, for the same reason as above | `[grounded]` search permission was not granted |
| Unknowns | Pay; planning system actually in use; language of the S&OP meeting | `[grounded]` posting silent |
| Contradictions | None within the posting | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no home location or commute limit, so there is no constraint of yours to grade. Your last employer was in Amsterdam, which says nothing about where you live | `[grounded]` background gives no location | Question 1 |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; confirmed and specific, no artifact yet. A parcel carrier counts as logistics | `[grounded]` your background; `[inferred]` that a parcel carrier is logistics | none |
| A3 | Strong SQL | must_have | direct | medium | none | "SQL daily" over four years is confirmed use; "strong" has no inspectable sample behind it, so `medium` and expect a probe | `[grounded]` your background | Offer: a sanitized query would raise it to `high` |
| A4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use. Whether you built it or maintained it is not stated, so it is carried at the lower reading | `[grounded]` your background | Offer: a sanitized dashboard screenshot would raise it to `high` |
| A5a | Track on-time delivery | important | direct | medium | none | The dashboard depot managers use is an on-time delivery dashboard | `[grounded]` your background | none |
| A5b | Track temperature compliance (cold chain) | important | unclear | low | discovery | Nothing in your background mentions temperature-controlled freight; there may be a thread if your carrier handled chilled parcels | `[grounded]` background silent | Question 2 |
| A6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran a weekly route-performance review and depot managers use your dashboard. Whether those reviews led to route changes you drove is not stated | `[grounded]` your background | Question 3 |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is a real asset for a "plus". The limit is that it is below professional fluency | `[grounded]` your background | State it plainly as conversational |
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Same as A1: no location or commute limit given | `[grounded]` background gives no location | Question 1 |
| B2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning. A years requirement is not a gate, but there is no adjacent planning work to count | `[grounded]` your own statement | closure path in GB1 |
| B3 | Own the 13-week supply plan, balancing capacity and forecast | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your own statement | closure path in GB1 |
| B4 | SAP IBP or a similar planning system | must_have | absent | none | capability | Your tools are SQL and Power BI; no planning system is mentioned | `[grounded]` your background | closure path in GB1 |
| B5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational against a required "fluent". A weekly meeting run in Dutch is the likely stress point | `[grounded]` your background; `[inferred]` that the S&OP meeting runs in Dutch | bridge in GB2 |
| B6 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. It is a different kind of meeting: S&OP reconciles supply, demand and finance, and the review did not | `[grounded]` your background; `[generic]` what S&OP meetings cover | bridge in GB3 |
| B7 | Advanced Excel | must_have | unclear | low | discovery | Your background doesn't say what you use Excel for. SQL and Power BI daily suggests data fluency, which is not the same claim | `[grounded]` background silent | not asked this turn; low weight given B2 to B4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Location and commute (A1, hard_gate) | hard_gate | No location given | If the commute doesn't work, the role fails on a term and wording can't fix it | Not applicable; this is a fact, not an experience | None | `[grounded]` background silent |
| GA2 | Temperature compliance (A5b, important) | discovery | No cold-chain content in your background | The posting names it as one of two things to track | Chilled or temperature-sensitive parcel handling; excursion or compliance reports; a service tier with temperature requirements | A sanitized report, a dashboard tab, an SLA excerpt | `[grounded]` background silent |
| GA3 | Route changes with depot managers (A6, important) | discovery | A weekly review and a depot-manager dashboard, but no stated outcome | It is the posting's collaboration duty; a concrete example moves A6 toward `direct` | A route a depot changed after your review; a recurring delay you flagged that was fixed | A review deck, a change log, an email thread | `[grounded]` your background |
| GB1 | Planning ownership, planning system, planning years (B2, B3, B4; must_have) | capability | No credible direct or adjacent planning evidence | Three must-haves are open at once | None found in what you've told me | Not applicable | `[grounded]` your own statement. `[generic]` Closure paths such as planning-system training or an entry planning or planning-analyst role exist, but they are months of work and not a wording fix |
| GB2 | Fluent Dutch (B5, must_have) | transferability | Conversational Dutch | A required skill, not a plus here | Adjacent evidence: daily Dutch-language work at the carrier, if any. Limit: conversational is below fluent. Strengthener: a language certificate level | A certificate or a Dutch-language work sample | `[grounded]` your background |
| GB3 | S&OP meeting (B6, must_have) | transferability | A weekly route-performance review you ran | The bridge is real but the meeting type differs | Adjacent: running a recurring cross-team review. Limit: it never reconciled supply against demand. Strengthener: a review agenda or deck | An agenda or deck from the weekly review | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The search was not permitted, so this is not a finding about the employer. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RA2 | Pay not stated | unknown | — | no figure appears in the posting | The figure may sit anywhere relative to the market, or the employer may simply not publish it | `[grounded]` posting silent | What salary range is budgeted for this role? | unresolved |
| RA3 | Responsibilities are concrete | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet, build weekly dashboards in Power BI" | The scope reads as specific and checkable | `[grounded]` posting | What does a good first six months look like for this role? | noted |
| RB1 | Employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | Same reasoning as RA1: not searched, so no finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RB2 | Pay not stated | unknown | — | no figure appears in the posting | Same as RA2 | `[grounded]` posting silent | What salary range is budgeted for this role? | unresolved |
| RB3 | Scope is clearly defined | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The mandate is specific | `[grounded]` posting | Which planning system and which sites does the plan cover today? | noted |

## Application plan

`resume_edits_pending_approval`: everything in this section is proposed. Nothing is final until you approve it, and that covers the prose advice as well as the rows.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| EA1 | Duinvaart: open your CV with the on-time delivery dashboard depot managers use and the weekly route-performance review you ran, in your own words. Don't write "built" or "owned" the dashboard until you confirm which it was | see A4, A5a, A6 | `[grounded]` your background | pending your approval |
| EA2 | Duinvaart: state Dutch as "conversational", not "fluent" or "professional" | see A7 | `[grounded]` your background | pending your approval |
| AA1 | Duinvaart: confirm the commute before investing in a tailored application | see A1 | `[grounded]` A1 row | pending your approval |
| QA1 | Duinvaart: ask RA1, RA2 and RA3's questions verbatim at screening | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| PB1 | Kroonhaven: if you apply anyway, say plainly that you have no planning experience, claim none of B2, B3 or B4, and describe the weekly review as a review, not as S&OP | see B2, B3, B4, B6 | `[grounded]` B rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam refrigerated transport" and "Kroonhaven Foods Utrecht chilled ready meals"; both calls were refused for lack of permission. It would have fed role reality's organization and contradictions rows, and RA1 and RB1 |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Netherlands Rotterdam" and "supply planner FMCG salary Netherlands Utrecht"; both calls were refused for lack of permission. It would have fed the market calibration rows and pay comparisons for RA2 and RB2 |
| 3. Hiring manager's public footprint | n/a | No name was given in either posting, so no query could be formed |

## Closing

I can save this as `tuesday-dossier.md` if you want to carry it forward.

**Upgrade menu**

- Where you live and whether three days a week in Rotterdam works → A1 and B1 close.
- Your pay floor and work-authorization status for the Netherlands → the hard-gates lines can check against them; today they are unchecked.
- Your CV, plus a sanitized SQL query or dashboard screenshot, and a note on whether you built or maintained the dashboard → A3 and A4 can reach `high`, and EA1's wording can be firmed up.
- Links to the live postings or each employer's careers page → RA1 and RB1 can close.
- Permission for web search → target 1 and target 2 would run. A deeper company pass (up to 5 more searches and 2 more fetches) is also available once search works; say the word.

**Questions**

1. A1, B1 — Where are you based, and is three days a week in Rotterdam realistic for you? Would an on-site role in Utrecht be workable too?
2. A5b — Did your carrier handle temperature-sensitive or chilled parcels, and did you track or report on that?
3. A6 — Did your weekly route-performance review ever lead to a route change with a depot manager? What did you own, and who made the call?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.