I'll read the reference files this skill points to before building the assessment.
**Does it sound worth applying for? Yes, on conditions (`conditional_go`). Is it legit? I can't establish Fernquay from here, because my web searches were refused. Nothing in the posting or the WhatsApp message asks you for money, documents or personal details, and the open verification point is RR1.** I've assumed you're at the interviewing stage, since a call has been proposed.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6
- `important` — adjacent: R7 (Own the booking flow end to end), R8 (our first designer), R9 (research calls with school owners)

R7 — checkout is a credible bridge to the whole flow, its limit named; R8 — adjacent, never solo; R4 (`medium`) — confirmed, waiting on an artifact.

**Opportunity ledger.** The posting is concrete on pay, hours and duties (RR5). The employer is unestablished from here (RR1), decision rights are unstated (RR2), and equity terms and runway are unstated (RR3, RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and the live posting verify (RR1); (2) the salary band meets your floor (R2); (3) decision rights and support for a first designer are made concrete (RR2, R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not verified outside the posting | `[grounded]` JD text you pasted |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Who you'd work with | Co-founder Ronan Kehoe most closely; the CTO is Saoirse | `[grounded]` JD and WhatsApp message |
| Working pattern | Hybrid, two days a week in the Galway office, the rest flexible | `[grounded]` JD |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Scope read | Design and research are both yours, and no design lead or peer is named | `[inferred]` from the JD's "first designer" and its silence on any design lead |
| First 90 days / first year | Not stated | `[grounded]` JD silent |
| Market calibration | None. The role-family sweep did not run, so I'm not saying whether this band is typical | `[grounded]` search refused |
| Unknowns | Decision rights, equity terms, funding and runway, first-year outcomes | `[grounded]` JD silent on each |
| Contradictions | None visible between the posting and the message: both name Ronan, the "co-founder", and the call includes Saoirse, the "CTO" | `[grounded]` comparing the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway. Whether two fixed office days suit you is not stated, so the band is `medium` | `[grounded]` your prose background and the JD | confirm the two days suit you |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states pay. Your floor was not given, so the term can't be marked met | `[grounded]` JD, no constraint from you | G4: say your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer is your stated claim. Nothing was inspected | `[grounded]` your prose background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated. "Strong" is a judgement that a Figma file or case study carries better than prose | `[grounded]` your prose background | offer: a link to the case study or Figma file raises it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. These are evaluative sessions, so open-ended discovery interviews are not evidenced here (see R9) | `[grounded]` your prose background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. "Happy" is a preference and nothing contradicts it | `[grounded]` your prose background | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned the checkout flow at a travel-booking company. Limit: checkout is one stage, and ownership of the whole journey is not stated | `[grounded]` your prose background | G1 |
| R8 | You would be our first designer | important | adjacent | medium | transferability | You own checkout work and ran your own research cadence. Limit: you have never been the only designer, so working without design peers or review is untested | `[grounded]` your statement; `[generic]` that a first-designer role usually adds process-setting and advocacy duties | G2 |
| R9 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions carry over. Limits: the participants were consumer customers rather than small-business owners, and the sessions were not open-ended discovery | `[grounded]` your prose background and the JD | G3 |

Everything on the map is a lead from your prose and not yet proof. None of it has been inspected, so nothing here reaches `high`.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership (R7, important) | transferability | Checkout redesign, with no stated span before or after it | R7 is the role's headline duty and sits at `adjacent` | Seat or date selection, basket or add-ons, confirmation emails, changes and cancellations, owner-side admin screens | The case study file, flow diagrams, a before/after | `[grounded]` your prose scope; `[generic]` that "end to end" claims are probed for span |
| G2 | Working as the only designer (R8, important) | transferability | Squad work with four engineers and your own research cadence, but never solo | The role has no design peer or lead named | Setting up a research routine, writing design decisions down, building a component library, deciding priorities alone | A sanitized artifact showing you ran something yourself | `[grounded]` your statement; `[inferred]` from the JD that no design peer exists |
| G3 | Discovery calls with small-business owners (R9, important) | transferability | Customer usability sessions only | The role's research is with school owners | Supplier or partner interviews, calls with small hotel or tour operators, support-call analysis | Sanitized interview guide or synthesis | `[grounded]` your prose; `[generic]` that B2B owner calls differ from consumer sessions |
| G4 | Pay floor (R2, hard_gate) | hard_gate | The band is stated, your floor is not | A gate the inputs do not settle stays open | n/a | n/a | `[grounded]` JD states the band; no floor given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search could run, so none of these is ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Decision rights and priorities unstated for a sole designer | unknown | — | "own the booking flow end to end ... work most closely with our co-founder, Ronan Kehoe" | Ownership may be shared with the co-founder, with no stated authority over priorities | `[inferred]` from the JD's ownership wording against its silence on decision rights | Which product decisions does design make alone, and which go through you, Ronan? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, share class and strike price are not given, so the value can't be read | `[inferred]` from the posting's figure with no terms attached | What are the vesting schedule, share class and any strike price, and how much has the company been diluted so far? | unresolved |
| RR4 | Funding and runway unstated | unknown | — | "We are six people" | Payroll security for a six-person team is not visible from the posting | `[inferred]` from the JD's silence on funding | How is Fernquay funded, and how many months of runway does the current plan give? | unresolved |
| RR5 | Concrete pay, hours and duties | positive_signal | — | "Salary €52,000–€60,000 ... two days a week at our Galway office" | The posting states its terms openly and the duties are specific | `[grounded]` JD | Is the band fixed or does it flex with experience? | noted |

## Application plan

Everything in this plan, the rows and the notes beneath them, is proposed and stays pending until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Scheduling a video call by WhatsApp is routine. Before the call, confirm the invite came by email, that its sender address matches the address on Fernquay's own site, and that the video link comes from the invite itself | Ordinary diligence before any first call | `[generic]` how interview scheduling usually works | pending your approval |
| A2 | Ask the RR1 to RR4 verification questions verbatim, split between Ronan and Saoirse | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | On R8, say plainly that you have not been the only designer, then name only what you ran alone: your research cadence and the checkout redesign | Candour reads stronger than a stretched claim, and your own statement is the evidence | `[grounded]` your statement | pending your approval |
| A4 | Be ready to walk through the checkout case study, separating what you owned from what the squad did. They said they liked it, and the posting prefers "one messy real project" | Both are in the texts you pasted | `[grounded]` JD and WhatsApp message | pending your approval |
| A5 | Fix your pay floor before the call, and ask about equity terms (RR3) | R2 is open until you do | `[grounded]` R2, RR3 | pending your approval |

## Evidence status

Verified: none yet. Your background is prose and counts as leads until you confirm specifics or share artifacts.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers product designer Galway"; both were refused. It would have moved RR1 and the Organization row |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 first designer startup mid-level"; refused. It would have moved the Market calibration row and any pay-mismatch check on R2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have moved the scope read and which of your stories A3 and A4 lead with |

If you'd like, I can save all of this as `tuesday-dossier.md` to carry forward.

**Upgrade menu**
- Permission to run web search (up to 5 searches and 2 fetches) → RR1 can be confirmed or left open, the Market calibration row fills in, and Ronan's public professional footprint informs A3 and A4.
- A link to the posting or Fernquay's own careers page → RR1.
- Your pay floor → R2 closes.
- The case study or Figma file (the artifact a designer's evidence rests on) → R4 and R7 can reach `high`.
- A sanitized usability-session guide or synthesis → R5 and R9 firm up.
- Equity and funding answers from the call → RR3 and RR4 close.

**Questions**

G4 (R2) — What is the lowest base salary you would accept, and does €52,000–€60,000 plus equity clear it?

G1 (R7) — In the checkout redesign, which stages of the journey did you personally own, and did your remit reach anything before or after checkout?

RR1 — Where did you find the posting (their own site, a job board, a referral), and can you share the link?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.