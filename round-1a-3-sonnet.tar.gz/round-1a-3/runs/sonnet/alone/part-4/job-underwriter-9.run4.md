Yes, this is normal. The order of events is also what a genuine employer would do.

**Why it's routine**
- **Bank details:** they need these to pay your salary.
- **PPS number:** Irish employers need it to register you with Revenue and run your PAYE, PRSI and USC. You'll know this from payroll work. You can't be put on a payroll properly without it.
- **Passport:** employers commonly check identity and right to work at hiring. A scan is common, and so is asking to see the original on day one, as they've said.
- **Timing:** they ask for these after a written offer and your acceptance, not before. You've also had two in-person interviews at their office. The advice never to hand these over applies to strangers who ask before there's any real job, by chat, or alongside a request for money. This is the opposite situation.

**Cheap checks before you upload anything**
1. **Confirm the offer.** Find Marrowgate's phone number or the People Team's contact on their own website, not from the email. Ask them to confirm they sent the offer and that the portal link is theirs. Declan Garvagh, whom you met, is a good person to ask.
2. **Check the link.** When it arrives, make sure it opens on a marrowgatehousing.ie address or a payroll or HR system they've named. If it's a different domain, ask them before you enter anything.
3. **Use the portal only.** Don't send these documents by reply email. If they ask you to, say you'd prefer the portal.
4. **Get the contract in writing.** Ask for the full contract and terms, including salary, hours, notice and probation, before or when you accept. You can accept without sending any of these details, because those only come after you accept.

**Things that would change my view**
- A request to pay for equipment, training or checks.
- Pressure to hand over the details before you accept.
- Payment details being sent to a different person than the one who interviewed you.

None of these appear in what you've shown me.

**The job itself**
- The pay of €40,000 sits inside the advertised band.
- The role is a step up in scale, from 90 staff to 240 and from fortnightly to monthly.
- Pension changes are the one gap. You haven't done them yourself, so ask Declan about onboarding or training on those. It shouldn't stop you accepting.

I didn't search the web for Marrowgate, so I haven't independently confirmed that the company or the email address is genuine. The checks above are how to do that.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.