I've finished reading the underwriting rules. Next I'm loading the web search tools to check whether Fernquay exists and the posting is live.
## Decision snapshot

**Yes, worth taking the call. Fernquay's own pages match the posting and the people named in it (RR1), and a WhatsApp scheduling message is ordinary, not a warning sign. Status: `conditional_go`.** I'm assuming you've applied and the video call is the next step.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 against your floor)
- `must_have` — direct: R3, R4, R5, R6
- `important` — adjacent: R7 (Own the booking flow end to end), R8 (Research calls with school owners), R9 (First designer, no design peers)

R9 — the real stretch, since you have never been the only designer; R7 — checkout is part of a booking flow, not all of it; R2 — your floor wasn't given, so the pay can't be checked against it.

**Opportunity ledger.** The employer and posting check out against Fernquay's own pages (RR1), and the stated pay sits inside the market band (RR4). The open items are the equity terms (RR2), decision rights and design review for a first design hire (RR3), and revenue stability for a customer-funded firm (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your salary floor sits at or below the range (R2); (2) the equity structure is explained in writing before you weigh it (RR2); (3) you are comfortable being the sole designer, and the call shows who reviews design decisions (R9, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About Fernquay page |
| Posting | Live on Fernquay's careers page as "our first design hire", hybrid two days a week in Galway, €52,000–€60,000 plus equity. The apply route there is jobs@fernquay.example | `[grounded]` careers page |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, and previously spent five years as a product lead at a Galway travel-software company | `[grounded]` search-result snippet for his profile, which agrees with the About page on the name and role |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Scope read | A first-designer role in a six-person company is broad. Design decisions, process and tooling are likely to be yours to set, with no design peer to review them | `[inferred]` from "first designer" and "own the booking flow end to end" |
| Market calibration | Product designers in Ireland with 3–5 years' experience have a median base of €57,000, interquartile range €51,500–€62,000. The posted range sits within that, around the median. This is a survey pattern, not Fernquay's offer | `[generic]` Tillerby 2026 Ireland survey (n=520) snippet; `[grounded]` posting for the range |
| Unknowns | First-year outcomes, equity structure, decision rights, who reviews design, your salary floor | `[grounded]` none of these appear in the posting or on the pages read |
| Contradictions | None found. The careers page is shorter than the posting: it says "equity" without the 0.5–1% figure | `[grounded]` both texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week in the Galway office | hard_gate | direct | high | none | You moved back to Galway last year, so the location term is met on your own account | `[grounded]` your background, posting | none |
| R2 | Salary €52,000–€60,000 against your pay floor | hard_gate | unclear | none | hard_gate | The posting states a range, but you haven't given a floor, so I can't say whether it is met | `[grounded]` posting; floor not given | G1 asks for it |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at one Dublin travel-booking company exceeds the stated minimum. Medium because I haven't inspected a portfolio, though the sender says they have seen your checkout case study | `[grounded]` your background; WhatsApp message | a link to the case study would raise to high |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. Medium because no file has been inspected | `[grounded]` your background | a shareable Figma file would raise to high |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers, which is the stated requirement. Its limit: usability sessions are not necessarily owner-level discovery calls (see R8) | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; the role has two | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | discovery | You redesigned a checkout flow at a travel-booking company, which is close to the domain. What you owned beyond checkout is not stated | `[grounded]` your background; `[inferred]` that this is a task of this role's kind from the posting | G2 |
| R8 | Run research calls with school owners | important | adjacent | low | transferability | Customer usability sessions carry over. The limit: nothing says the participants were business owners or that the sessions were discovery-style calls. A strengthener would be one concrete session you ran, described plainly | `[grounded]` your background; `[inferred]` that the role's calls are owner-level from "school owners" | G3 |
| R9 | First designer: set your own process with no design peers | important | adjacent | low | transferability | You have never been the only designer. What carries over is that you ran the monthly sessions and a redesign yourself, but whether you set process alone is unknown, and the limit is the missing peer review | `[grounded]` you've never been the only designer; `[inferred]` requirement from "first designer" | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against the range (R2, hard_gate) | hard_gate | A stated range, but no floor from you | A hard gate stays unresolved until it is checked against your figure | Your minimum base salary, and whether equity changes it | Your own figure | `[grounded]` posting; floor not given |
| G2 | Scope of the checkout redesign (R7, important) | discovery | A checkout redesign is stated, with no scope or ownership detail | Owning the booking flow end to end is the headline responsibility | Deciding the flow's steps yourself; shipping it with engineers; measuring the result; touching search, availability or payment steps | A before/after screen, a case-study page, a metric | `[grounded]` your background; `[generic]` that owning the whole flow is the first thing a founder will probe |
| G3 | Owner-level research (R8, important) | transferability | Usability sessions with customers; participant type unknown | The role's research calls are with business owners, not end users | Sessions with the people who buy or run the product; recurring sessions that changed a design decision | A session guide, a findings summary | `[grounded]` your background; `[inferred]` that owner-level calls matter from the posting |
| G4 | No design peers (R9, important) | transferability | Always in a squad; never the only designer | The posting says you would be the first designer. The bridge is your self-run research and redesign. The limit is that you've had no one reviewing a decision you alone owned. A strengthener is one example of a decision you made without a design lead | An occasion you made a design call on your own; a process you set up, such as the session cadence | A short written example | `[grounded]` your background; `[inferred]` that solo process-setting is the stretch |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting match their own pages | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company exists as the posting describes, with a live listing | `[grounded]` About and careers pages | How long has Kelproster been live with paying schools? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value depends on structure (options or shares, vesting, strike price, share count), none of which is given | `[inferred]` from the posting's silence; `[generic]` that equity in a small private firm has uncertain value | Is the equity options or shares, and what are the vesting schedule, any cliff and the number of shares outstanding? | unresolved |
| RR3 | Sole designer with no stated review or decision rights | risk_signal | low | "own the booking flow end to end" | You may carry the outcomes with design decisions shared among founders and engineers. Low, because the posting says you would work most closely with Ronan Kehoe | `[inferred]` from the posting's scope against its silence on authority | Which product decisions would the designer make alone, and which sit with you and the CTO? | unresolved |
| RR4 | Salary stated and within the market band | positive_signal | — | "Salary €52,000–€60,000" | The pay is in line with the 3–5 year median. Stating a range openly is itself a transparent sign | `[grounded]` posting; `[generic]` survey band | Is the range fixed for this role, and when is pay reviewed? | noted |
| RR5 | Revenue-funded, no outside investment named | unknown | — | "funded by its customers" | Runway depends on customer revenue. For seasonal outdoor schools that may rise and fall through the year | `[grounded]` About page; `[generic]` seasonal-business pattern, not a finding about this firm | Roughly how many schools pay today, and how does the winter season affect hiring plans? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the story with your checkout redesign and the monthly usability sessions, saying what you personally owned and that you have worked in a squad, never as the only designer | see R3, R5, R7, R9; Ronan Kehoe's own background in travel software suggests the booking-flow work will resonate | `[grounded]` your background and the sender's message; `[inferred]` resonance | pending your approval |
| P2 | Ask the RR2, RR3, RR4 and RR5 questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P3 | Treat the WhatsApp as ordinary scheduling. As housekeeping, check that the calendar invite came from a fernquay.example address, the domain on the careers page, and that the call itself happens on the video link | Scheduling by chat for a video interview is routine, and checking the sender is a sensible habit | `[grounded]` careers page domain; `[generic]` that chat scheduling is routine | pending your approval |
| P4 | Treat the one real project the careers page asks for as the centre of your pitch: the posting says they would rather see a messy real project than a polished deck | The posting asks for it | `[grounded]` posting | pending your approval |

Rehearsing the call is mock-interview's job, not this skill's.

## Evidence status

Verified: none yet. Your background claims are CV-level leads until an artifact is inspected.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved the organization and contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland first designer startup Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), read as a snippet. Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), read as a snippet. Moved the hiring-manager row and P1 |

## Dossier offer and upgrade menu

I can save all of this as `tuesday-dossier.md` if you want a copy to carry into later steps.

- Your salary floor → R2 and the hard-gates line resolve.
- A link to your checkout case study or a Figma file → R3 and R4 move to `high`.
- Answers to G2 and G3 → R7 and R8 firm up or stay adjacent.
- The equity structure in writing → RR2 closes.
- A deeper research pass on Fernquay (customer reviews, news, hiring history; up to 5 more searches and 2 more fetches) → feeds RR5 and the risk register. Say the word and it runs.

## Questions

1. G1 — What is the lowest base salary you would accept, and would equity change it?
2. G2 — In the checkout redesign, which decisions did you make yourself, which steps did you cover beyond checkout, and what changed afterwards?
3. G3 — In your monthly usability sessions, who took part (end customers or the businesses buying the product), and did any session change a design decision?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.