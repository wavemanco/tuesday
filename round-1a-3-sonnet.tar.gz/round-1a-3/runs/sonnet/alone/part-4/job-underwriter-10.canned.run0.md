Reading the underwriting rules is done. Next I'm checking whether Fernquay exists, using up to 5 searches and 2 page fetches. I'll write the assessment after that.
**Yes, this is worth pursuing, and the WhatsApp message is a routine scheduling step. Status: `conditional_go`.** R2 (pay) can't be settled until you tell me your floor.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R9 (First designer, no design peers) · unclear: R8 (Research calls with school owners)
- `preferred` — direct: R10

R7 — your checkout redesign is a credible bridge, with its limit named; R9 — the real stretch, since you have never been the only designer.

**Opportunity ledger.** The employer and posting check out against its own pages (RR1) and the pay sits inside the market band (RR2). The open items are unstated equity terms (RR3), the support around a first designer (RR4) and runway (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the salary band meets your floor — R2; (2) the equity terms are explained in writing — RR3; (3) you are comfortable being the sole designer, with the support question answered — R9, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023, funded by its customers | `[grounded]` About page (seen as a search result) |
| Posting | Live on Fernquay's own careers page. Same terms as your copy: first design hire, hybrid, two days a week in Galway, €52,000–€60,000 plus equity | `[grounded]` careers page fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship with two engineers, work closest with Ronan Kehoe | `[grounded]` JD |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, and was previously product lead at a Galway travel-software company for five years | `[grounded]` public professional profile |
| Scope read | One designer owning one product surface, with a small team around them. The scope reads as coherent, not bundled | `[inferred]` from the JD's one-product scope against its team size |
| Market calibration | A survey of product designers with 3–5 years in Ireland gives median base €57,000 and interquartile range €51,500–€62,000. The posting's €52,000–€60,000 sits inside that range. The band is not Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report, n=520; `[grounded]` the posting's own figure |
| Contact route | Scheduling a video call by WhatsApp, with the invite sent by email, is a routine step. It gets no register entry | `[generic]` scheduling by chat for an interview held elsewhere is normal |
| Unknowns | Equity form and terms; who reviews design work; runway; how many schools use the product | — |
| Contradictions | None found. The About page names Saoirse Doyle as co-founder; "CTO" in the message isn't stated in what I read | `[grounded]` About page and your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, which meets the term. `medium` because it is your own statement, not a stated constraint | `[grounded]` your background and the JD | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You gave no pay floor, so whether the band clears it is not established. Confidence is `none` because there is no stated constraint to grade | `[grounded]` JD; no floor given | G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Self-reported, nothing inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" over four years. The checkout case study Ronan praised is the proof, but I haven't seen it | `[grounded]` your background | send me the case study link |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Self-reported | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. Limit: checkout is one stage, and what you did upstream of it is not stated | `[grounded]` the checkout claim; `[inferred]` that "end to end" is wider than checkout | G1 |
| R8 | Run research calls with school owners | important | unclear | low | discovery | You ran sessions with customers, but whether they were business users like school owners is not stated | `[grounded]` your background; silent on who the customers were | G2 |
| R9 | First and only designer: no design peer to review or mentor | important | adjacent | low | transferability | You owned a redesign inside a squad, but you have never been the only designer. Taking the lower band: ownership is evidenced, sole ownership is not | `[grounded]` your own statement; `[inferred]` that this is implied by "first designer" | G4 |
| R10 | Booking-software domain | preferred | direct | medium | none | Four years in travel booking, which is the same product category | `[inferred]` from "booking software" in the JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | How much of the booking flow you've touched (R7, must_have) | transferability | Checkout redesign confirmed; nothing about the stages around it | The role owns the whole flow, so the bridge's limit decides how you frame the call | Availability or date selection, basket or confirmation emails, payment failures, post-booking changes | The checkout case study, flow diagrams | `[grounded]` claim and silence; `[generic]` that "end to end" is probed |
| G2 | Who your research participants were (R8, important) | discovery | Sessions with customers, with no detail on who they were | The role's research is with school owners, a business audience | Sessions with partner businesses or operators, supplier-side or admin users, interviews rather than usability tests | A research summary or session guide | `[grounded]` your wording; `[generic]` that owner-led research differs from consumer testing |
| G3 | Your pay floor (R2, hard_gate) | hard_gate | Band stated; your floor not | The one thing that could change the decision | Your minimum base, and how you value equity | None needed | `[grounded]` the posting states the band and you stated no floor |
| G4 | Working with no design peer (R9, important) | transferability | Never the only designer | The main stretch in the role, and the support around it is unknown | Making design calls alone on a feature, a design-system decision you drove, mentoring a junior | Your case study, with decisions you made alone marked | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting match what you were told | positive_signal | — | "Six people, based in Galway" | The company is a real, small hiring employer with the role live on its own site | `[grounded]` About page and careers page | Who would be on the video call, and who would I report to? | noted |
| RR2 | Pay stated and inside the market band | positive_signal | — | "€52,000–€60,000 plus equity" | The pay is open and realistic for the seniority | `[grounded]` posting; `[generic]` survey band | Is the band fixed, or does it move with experience? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The instrument, vesting and dilution are unknown, so the equity's value can't be judged | `[generic]` terms vary widely at small companies | Is the equity options or shares, with what vesting, strike price and total share count? | unresolved |
| RR4 | Responsibility for the whole flow with no design support described | unknown | — | "You would be our first designer: own the booking flow end to end" | There may be no design review or mentoring, and decision rights between you, Ronan and the engineers are unstated (R9) | `[inferred]` from the JD's silence on support and authority | Who reviews design decisions, and what do you decide without sign-off? | unresolved |
| RR5 | Runway and customer base not stated | unknown | — | "funded by its customers" | Funding from customers means revenue matters; how many schools pay and for how long is unknown | `[grounded]` About page; `[generic]` small firms' stability varies | How many schools use the product, and how many months of runway do you have? | unresolved |

## Application plan

Every block below is `pending your approval`, and so is the advice in the final paragraph. Nothing here is finalized until you say so.

`resume_edits_pending_approval`: none proposed. Your CV evidence already maps to R3–R6 and I haven't seen the CV itself.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the call with the checkout redesign and the monthly usability sessions, saying what was yours | see R5, R7 | `[grounded]` your background | pending your approval |
| P2 | Say plainly that you have never been the only designer, then ask the RR4 question | see R9, RR4 | `[grounded]` your statement | pending your approval |
| P3 | Ask the RR3 and RR5 questions verbatim | The register doubles as call preparation | `[grounded]` register | pending your approval |
| P4 | Check that the calendar invite came from an address on `fernquay.example`, the domain on the careers page. Entering anything sensitive is not part of this step | Routine hygiene for any invite | `[generic]` | pending your approval |
| P5 | Bring one real project, as the careers page asks | the posting's own ask | `[grounded]` careers page | pending your approval |

Ronan Kehoe's own background is in travel software, so your travel-booking years may land with him (`[inferred]` from his public profile and your background). Rehearsing the call is mock-interview's job.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (About Fernquay, fernquay.example/about) and "Fernquay product designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). It confirmed the company and the live posting, so no failed-attribution entry is needed |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup Galway 3+ years", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). It moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). It moved role reality's hiring-manager row and one plan note |

I can write all of this into `tuesday-dossier.md` if you want a copy to keep.

**Upgrade menu**

- The checkout case study link → R4 and R7 can move toward `high`, because a portfolio is the artifact a design reviewer inspects.
- Your pay floor → R2 closes and the snapshot's gate line settles.
- Who your research participants were → R8 resolves.
- The equity terms in writing → RR3 closes.
- A deeper research pass on Fernquay (customer count, press, leadership history; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Beyond checkout, which other parts of a booking flow have you designed or changed, and what was yours versus the squad's?
G2 — Were the customers in your monthly usability sessions individual travellers or business users, and did you run the sessions yourself?
G3 — What is the lowest base salary you would accept, and how much do you value the equity?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.