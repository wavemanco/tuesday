Web search wasn't permitted, so everything below rests on what you pasted, and anything about the wider world is labelled.

## Decision snapshot

**Yes, asking for bank details, PPS number and passport after you accept a written offer is routine. I'd accept, but check the written terms first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Hybrid, two days in Limerick), R11 (Pay €38,000–€42,000)
- `must_have` — direct: R1, R3, R4 · unclear: R2 (Irish PAYE, PRSI, USC)
- `important` — direct: R6, R7 · adjacent: R5 (Monthly payroll, 240 staff) · unclear: R9 (Staff payroll queries) · absent: R8 (Pension changes)

R8 is a real gap but a learnable one. R2 and R9 are probably fine and only need your confirmation.

**Opportunity ledger.** The role is clearly scoped and the offer is in the advertised band (RR3). The employer can't be checked from here (RR1), the offer email leaves out the terms that matter (RR2), and who covers pension changes while you learn them is unknown (RR4). I found nothing in the offer that warrants alarm.

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two days in Limerick), R11 (Pay €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) written contract terms received and acceptable before you accept — RR2; (2) a clear answer on who handles pension changes and how you'll be supported — R8, RR4; (3) the commute and salary suit you — R10, R11.

## On your actual question

What the offer describes is the standard order of things, and it's the safe one. They asked for the details after the offer and after your acceptance, not before. You'd had two in-person interviews, and the email came from an address on their own domain. Bank details are needed to pay you. The PPS number is needed to register you with Revenue. Employers also routinely check right to work and ID. Asking for the original passport on day one is normal too `[generic]`.

Your instinct is still sound, so apply it to *where* the details go. Enter them only in the employer's own portal, at an address that matches their website. Don't email a passport scan to anyone. See A3 below.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` JD; you've met them in person twice |
| Mandate | Monthly payroll, starters/leavers/pension changes, monthly payroll-to-ledger reconciliation, staff queries | `[grounded]` JD |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Terms offered | €40,000 permanent, hybrid with two days a week in Limerick, start after your notice, reply within five working days | `[grounded]` offer email |
| Scope read | A one-person payroll seat for 240 staff, a step up from 90 staff. The JD names no team or backup | `[inferred]` from the JD naming one post against the headcount |
| Market calibration | Not done: no search was available, and I won't quote market pay from memory | `[generic]` none available |
| Unknowns | Probation, notice terms, pension scheme, leave, start date, who covers pension changes, payroll software | — |
| Contradictions | None between JD and offer. Both say hybrid with two office days, and €40,000 sits inside the band | `[grounded]` JD against offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff. Your own account, nothing inspectable yet | `[grounded]` your statement | none |
| R2 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You didn't say the hotel payroll was Irish-run or that you did the statutory calculations. Likely, but not stated | `[grounded]` silence in your background | G2 question |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables, XLOOKUP | `[grounded]` your statement | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your statement | none |
| R5 | Monthly payroll for 240 staff | important | adjacent | medium | transferability | Same discipline at 90 staff, fortnightly. Limit: bigger headcount and a monthly cycle that you haven't run | `[inferred]` from 90-staff experience against 240 | G3 |
| R6 | Process starters and leavers | important | direct | medium | none | Stated directly | `[grounded]` your statement | none |
| R7 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Stated directly | `[grounded]` your statement | none |
| R8 | Process pension changes | important | absent | none | capability | "Never done pension changes myself" and your manager handled them. No claim should be made beyond that | `[grounded]` your statement | G1 |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Not stated. Running payroll for 90 staff probably involved queries, but that's a guess | `[inferred]` | G4 question |
| R10 | Hybrid, two days a week in Limerick office | hard_gate | unclear | low | hard_gate | The role's terms are clear. Your commute and constraints weren't given | `[grounded]` offer email; constraints not given | question 3 |
| R11 | Salary €38,000–€42,000 | hard_gate | unclear | low | hard_gate | Offer of €40,000 is mid-band. Your minimum wasn't given | `[grounded]` offer email; floor not given | question 3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R8, important) | capability | You've never processed them | It's a named duty, and one person owns payroll here | Preparing pension data for your manager, enrolment forms, deduction checks in payroll runs. Only if you really did them | Your honest account, plus a plan for how you'd learn | `[grounded]` your statement; `[generic]` that employers usually train for scheme-specific steps |
| G2 | Irish statutory knowledge (R2, must_have) | discovery | Not stated | It's a must-have, and the likeliest thing to be probed | Running PAYE/PRSI/USC in Revenue-compliant payroll, year-end returns | A payslip layout or process note with figures removed | `[grounded]` CV silence |
| G3 | 240 staff, monthly (R5, important) | transferability | 90 staff, fortnightly | Scale is a step up | Any month-end close you ran; reconciling larger totals | A description of your month-end checklist | `[inferred]` bridge from your reconciliation work |
| G4 | Staff queries (R9, important) | discovery | Not stated | Part of the daily job | Handling queries from staff or managers about pay, tax credits, deductions | One example | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked from here | unknown | — | "Marrowgate Housing, a housing association in Limerick" | Web search wasn't permitted, so the entity wasn't checked. You've met them in person twice and the email came from their own domain, which counts in their favour | `[grounded]` search unavailable; `[inferred]` from the two in-person interviews | Which housing-association regulator registration does Marrowgate hold? (This is public for housing bodies.) | unresolved |
| RR2 | Offer email omits key terms | unknown | — | "reply to accept within five working days" | The email gives pay, hours pattern and reporting line but not probation, notice, pension scheme, leave or start date. A short reply window is ordinary, and the contract may just come later | `[generic]` offers often follow up with a contract | Can you send the full contract and staff handbook before the five days end? | unresolved |
| RR3 | Clear scope and stated salary | positive_signal | — | "€40,000 a year, reporting to Declan Garvagh, Finance Manager" | Pay, title, manager and responsibilities are all stated | `[grounded]` JD and offer | Who covers payroll when you're on leave? | noted |
| RR4 | Pension changes with no named support | unknown | — | "process starters, leavers and pension changes" | The employer may know you haven't done pension changes, or may not | `[inferred]` from the JD's single-post wording | How are pension changes handled today, and who'd show me the scheme rules? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before accepting, ask People Team/Declan for the full contract and handbook. Ask RR2 and RR4's questions | see RR2, RR4 | `[grounded]` register | pending your approval |
| A2 | Tell Declan plainly: "I haven't processed pension changes myself; my manager did them. I'm confident learning scheme rules quickly." Don't imply hands-on experience | Honest framing of R8 | `[grounded]` R8 | pending your approval |
| A3 | When the portal link comes: check its address is on the same domain as the email and their website. Don't email passport scans. Or ring the People Team on the number from marrowgatehousing.ie if unsure. Don't send details by any other route | Routine step, so this is advice and not a condition | `[generic]` common safe practice | pending your approval |
| A4 | Reply within the window to accept in writing, confirming start date after your notice | see R10, R11 | `[grounded]` offer email | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Marrowgate Housing Limerick housing association" was refused. Would have fed role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Search "payroll administrator salary Ireland Limerick 2026" was refused. Would have fed the market calibration line |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh was named, but no search was permitted. Would have fed the scope read |

## Dossier offer and upgrade menu

I can save all this as `tuesday-dossier.md` if you'd like to keep it.

- Search permission → role reality, RR1 and the market calibration line get grounded.
- A deeper research pass (up to 5 more searches and 2 more fetches) → employer diligence and recent news.
- Your payroll duties in detail → R2, R9 and G1 move.
- Your salary floor and commute limits → R10 and R11 resolve.

## Questions

1. **(R2, G2)** Was the hotel group's payroll Irish, and did you do the PAYE, PRSI and USC yourself?
2. **(R8, R9, G1, G4)** Did you touch pensions in any way, such as preparing data for your manager? Did you answer staff pay queries?
3. **(R10, R11)** Is €40,000 acceptable to you, and is two days a week in Limerick workable?

Answer, say "skip", or say "not sure" to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.