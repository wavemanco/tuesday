I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, this is worth applying for. R1 and R2 (both gates) are met on your own statements, and R4, the one-year experience requirement, is `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2 · unclear: R3 (Salary £31,050–£37,800)
- `must_have`: direct: R4 · unclear: R5 (clear, timely written records)
- `important`: direct: R8a · adjacent: R6 (wound and leg-ulcer care), R7 (catheter and continence care), R10 (visiting housebound adults at home), R11 (own small caseload) · unclear: R8b (care planning), R9 (end-of-life visits)
- `preferred`: absent: R12 (Doppler assessment)

R6, R7 and R10 — adjacent, limits named; R11 — your stated gap, bridged only by your home-visiting work; R12 (preferred) — absent, named plainly.

**Opportunity ledger.** The role is clearly scoped, with senior support built in (RR2) and pool cars provided (RR4). Three things are unconfirmed: the posting on the employer's own site (RR1), the pay point within the range (RR3), and Doppler and community-induction training (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); unconfirmed: R3 (Salary £31,050–£37,800); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you check your own NMC register entry and driving record, since R1 and R2 are stated and not checked; (2) the posting is confirmed open on Calderbrook's own site (RR1); (3) the pay point you would be offered meets your floor (R3, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health: a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Working pattern | Pool cars provided, mileage paid; hours, shifts and weekend or on-call work not stated | `[grounded]` advert |
| Scope read | A Band 5 post asking for one year's post-registration experience is an entry route into community nursing, not a senior post | `[inferred]` from the essential list against the band |
| Market calibration | Posting range £31,050–£37,800 `[grounded]`. The 2026 Wardround survey for community staff nurse, Band 5, England (n=1,240) gives a median basic pay of £34,300 and an interquartile range of £32,400–£36,600, and the posting's range brackets that interquartile range. This is the market band, never this employer's offer; I saw the survey as a search snippet only | `[generic]` role-family sweep (Wardround 2026 UK Community Nursing Pay Guide) |
| Hiring lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` Community Nursing Forum speaker page |
| Lead's likely interests | Leg-ulcer care and Doppler training are topics she teaches on, so they probably matter in this team | `[inferred]` from the talk titles alone |
| First-90-days and first-year outcomes | Not stated | `[grounded]` advert silent |
| Unknowns | Pay point within the range; hours and rota; induction and Doppler training; how a new caseload is built up; whether the post is permanent | `[grounded]` advert silent |
| Contradictions | None between the advert and the About page; the advert itself was not found on Calderbrook's site (RR1) | `[grounded]` About page read; careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration as a Registered Nurse (Adult), revalidation due March 2028. Stated, not checked: your NMC register entry is the public record to check | `[grounded]` CV | You check your own register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated, not checked: your driving record is yours to check | `[grounded]` CV | You check your driving record |
| R3 | Pay £31,050–£37,800 a year plus mileage (against your pay floor) | hard_gate | unclear | none | hard_gate | No floor was given, so whether the range meets it is not established. Confidence is `none` because no constraint was stated to grade | `[grounded]` advert; no candidate constraint given | Ask G1 |
| R4 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical ward staff nurse; a length-of-experience requirement, not a gate. The register entry would show your registration date | `[grounded]` CV | none |
| R5 | Clear, timely written records | must_have | unclear | none | discovery | The CV makes no claim about records or any electronic patient record, so none is asserted | `[grounded]` CV silence | Ask G5 later if useful; otherwise add a line only if true |
| R6 | Wound and leg-ulcer care | important | adjacent | medium | discovery | Wound care including pressure ulcers and surgical wounds is stated. Leg ulcers and compression are not mentioned. Limit: leg-ulcer care is not evidenced | `[grounded]` CV | Ask G2 |
| R7 | Catheter and continence care | important | adjacent | medium | discovery | Catheter care is stated; continence care is not. Lower band taken | `[grounded]` CV | Confirm any continence work; add only if true |
| R8a | Insulin administration | important | direct | medium | none | Stated plainly on the CV; no inspectable artifact yet | `[grounded]` CV | none |
| R8b | Care planning | important | unclear | none | discovery | Not mentioned on the CV | `[grounded]` CV silence | Confirm whether you wrote or contributed to care plans |
| R9 | End-of-life visits | important | unclear | none | discovery | CV silent; no claim made | `[grounded]` CV silence | Ask G3 |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | presentation | 18 months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: short-term post-discharge visits, not ongoing care of housebound adults | `[grounded]` CV | Lead with it (E1) |
| R11 | A small caseload of your own | important | adjacent | low | transferability | You say you have never held your own caseload. The adjacent evidence is home visiting only; whether you planned your own visits is unknown, hence `low` | `[grounded]` your statement and CV | Ask G4 |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have never done one. Preferred tier, so a minor risk, not a blocker | `[grounded]` your statement | Ask the employer about training (RR5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R3, hard_gate) | hard_gate | The range is stated but your floor is not | A gate your floor could fail would end the decision, and I can't check it without the floor | Your lowest acceptable salary; any other fixed limits on hours or travel | Your own statement | `[grounded]` no constraints given |
| G2 | Leg-ulcer care (R6, important) | discovery | Wound care is stated; leg ulcers and compression are not | The advert names leg-ulcer care, and the lead has spoken on it | Applying compression bandaging; assessing a leg wound's cause; dressing venous ulcers on the ward or on visits | A training record or competency sign-off | `[grounded]` CV silence on leg ulcers; `[inferred]` from the lead's talks that it matters here |
| G3 | End-of-life care (R9, important) | discovery | The CV is silent | Named in the advert as a core duty | Symptom review for dying patients; anticipatory medicines; family conversations; care after death, on the ward or at home | A sanitized care plan or competency record | `[grounded]` CV silence |
| G4 | Own caseload (R11, important) | transferability | Home-visiting evidence; you hold no caseload | The role makes it a defined duty, though it is supported by a senior nurse | Planning your own visit lists on the discharge team; prioritising patients; deciding when to escalate | A rota or visit list, if sanitized | `[grounded]` your statement; limit: ownership never held |
| G5 | Written records (R5, must_have) | discovery | The CV is silent on records and any electronic patient record | A must-have row with no evidence yet | Which electronic record you use on the ward or discharge team; audits of your documentation | An audit result or the system name | `[grounded]` CV silence |
| G6 | Doppler assessment (R12, preferred) | capability | None; stated by you | A preferred criterion, so a minor risk | A closure path is training; whether Calderbrook offers it is unknown | The employer's answer (RR5) | `[grounded]` your statement; `[inferred]` that training may exist, from the lead's Doppler-training talk |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not seen on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The advert may sit at an address I didn't find, on a jobs board, or be closed; the employer itself is established | `[grounded]` fetch of the guessed careers address returned no page; the About page says vacancies are listed on a careers page | Is this post still open, and where is it listed on your own site? | unresolved |
| RR2 | Senior support for a new caseload | positive_signal | — | "supported by a senior community nurse" | The post is built for a nurse new to caseload-holding | `[grounded]` advert | How is a caseload built up for someone new to community work, and what does the senior nurse's support involve? | noted |
| RR3 | Pay point within a wide range unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | The offer may sit anywhere in the range, and the lower part is below the market's interquartile range | `[grounded]` advert; `[generic]` survey band | Where in the range would an offer sit for someone with five years' post-registration experience? | unresolved |
| RR4 | Pool cars and mileage provided | positive_signal | — | "pool cars are provided" | Removes the need for your own vehicle for visits | `[grounded]` advert | Are pool cars available at every shift start, and how is mileage claimed? | noted |
| RR5 | Doppler and community induction unstated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The team may train staff new to community work in Doppler | `[inferred]` from the lead's published talk on Doppler training for staff new to community work | What induction and Doppler training do new community nurses receive, and what competency sign-off follows? | unresolved |

## Application plan

Everything in this section is proposed and `pending your approval`, the CV edit and the positioning advice alike. I have used nothing you haven't stated.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with the Team Lead before applying, and ask RR1, RR3 and RR5's questions verbatim | The advert invites it, and the register doubles as interview preparation | `[grounded]` advert | pending your approval |
| E1 | CV edit: lead with the discharge-to-assess secondment, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | Your strongest adjacent evidence for R10 currently sits after the ward role | `[grounded]` CV | `resume_edits_pending_approval` |
| A2 | Positioning: lead with the home-visiting work and say plainly that you have not held a caseload or done Doppler assessment; do not describe either as experience | A claim you can't support is the one an interviewer will test | `[grounded]` CV and your statements | pending your approval |
| A3 | Check your own NMC register entry and your driving record before applying | R1 and R2 are stated and not yet checked | `[grounded]` the map | pending your approval |

E1 above is a proposed CV edit and nothing more: every clause traces to a sentence you wrote, and I added no title, number or duty.

## Evidence status

Verified: none yet.

Your National Insurance number isn't needed for this assessment, so I haven't used or repeated it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse district nursing vacancy", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Role reality's organization and contradictions rows: the employer is established. A fetch of calderbrookhealth.example/careers returned no page, so the posting is unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nursing role requirements salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration, RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's hiring-lead rows, A1, RR5 |

If you want this kept, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your lowest acceptable salary and any other fixed limits → R3 resolves and the hard-gates line stops flagging unknown constraints.
- A look at your own NMC register entry → R1 to `high`; your driving record → R2 to `high`.
- A leg-ulcer or compression training record or competency sign-off → R6.
- A sanitized end-of-life care plan or competency record → R9.
- The name of your electronic patient record system and any documentation audit → R5.
- A link to the advert on Calderbrook's own site → RR1 closes.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches: hiring patterns, public staff and candidate reports, recent news) — say the word and it runs.

G1 — What is the lowest salary you would accept, and are there any other limits the role would have to meet (hours, shifts, weekends, on-call, travel)?

G2 — Have you personally dressed leg ulcers or applied compression bandaging, in the ward or on your home visits, and what training or sign-off did you have?

G3 — Have you personally cared for patients at the end of life, on the ward or in their homes, and what was yours to do versus the team's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.