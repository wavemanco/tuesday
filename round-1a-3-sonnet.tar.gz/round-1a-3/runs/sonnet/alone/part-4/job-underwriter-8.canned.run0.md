Checking whether Velloway Logistics shows up as an employer, then I'll write up the assessment.
**Is this job legit, and should you go ahead?** I can't establish the firm from here. The requests made of you (RR1 to RR3 below) are very likely a scam, so don't go ahead and send nothing yet. Status: `no_go`.

# Job Underwriting: Remote Order Processing Coordinator (as posted by Velloway Logistics)

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3 · adjacent: R4 (Good written English)
- `important` — unclear: R5 (A quiet place to work)

R1 — the posting gives only a ceiling, so the floor can't be checked; R2, R3 — your own account, no artifact yet; R5 — only you can confirm.

**Opportunity ledger.** The requests in RR1, RR2, RR3 and RR4 are confirmed from the messages you pasted. The employer isn't established (RR6), the contact address doesn't match the firm's name (RR5), and the pay terms are open (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer, verified through contact details you find yourself on the employer's own site. It would have to come with no payment, no cheque and no ID or bank details before it. Even then R1 would still need a guaranteed rate and hours.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics, as named in the posting. One search for the name returned no results, so the entity is not established | `[grounded]` posting; search returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission on every order" | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Pay arithmetic | At €26 an hour, 15 hours a week is €20,280 a year and 30 hours is €40,560. Reaching €30,000 needs about 22 hours a week at the top rate, every week, before commission. "Up to" means €26 is a ceiling | `[inferred]` arithmetic on the posting's figures |
| Market calibration | Salaried order processing and customer operations coordinators in Ireland: median base €31,200, interquartile range €28,400 to €34,100. This is a salaried-only survey, not this employer's offer | `[generic]` Pennoral 2026 Ireland pay guide |
| Contradictions | The posting never mentions buying equipment. The messages ask for €349, then a cheque of €2,850 from which €350 is kept and the rest (€2,500) goes to the "equipment partner". That is not €349 | `[grounded]` posting and messages |
| Unknowns | Guaranteed hourly rate, commission formula, contract type, who the employer is | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your floor) | hard_gate | unclear | high | hard_gate | Confidence grades your constraint, which you stated. Fit is `unclear` because "up to €26" and a 15–30 hour range guarantee nothing. €30,000 needs about 22 hours a week at the maximum rate | `[grounded]` your floor and the posting; `[inferred]` arithmetic | Ask for the guaranteed rate and hours in writing (RR7) |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and a weekly team tracker are specific, but there is no inspectable artifact | `[grounded]` your account | A sanitized tracker sample would raise it to high |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. Stated, not inspected | `[grounded]` your account | Same sample as R2 |
| R4 | Good written English | must_have | adjacent | low | discovery | Ticket handling is written work, but volume and quality aren't shown | `[inferred]` from Zendesk ticket work | A short writing sample would close it |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` silence | Yours to confirm |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | A ceiling of €26 an hour with commission undefined | Your €30,000 floor can't be tested without a guaranteed rate and hours | — | Rate, weekly hours and commission terms in a written offer from a verified employer | `[grounded]` posting |
| G2 | Quiet workspace (R5, important) | discovery | Nothing stated | A stated requirement | Your current home setup | Your own confirmation | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A job that charges you to start is a known scam pattern. This request is very likely a scam. The sender's identity is unresolved, and these messages may not come from who they name | `[generic]` known pattern | Using contact details you find yourself on the employer's own site, not Telegram or the address in the messages: "Do you ask applicants to buy equipment, deposit cheques or send ID before a written offer, and did you send this?" | confirmed |
| RR2 | Asked to lodge a cheque and send most of it on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can show as credited before it clears. If it is later returned, the money you sent out is yours to cover. Don't deposit this cheque | `[generic]` known pattern | As RR1; the route and the hold are the same | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | The request comes before an interview or any written offer, so it is not routine onboarding | `[generic]` pre-offer disclosure | As RR1 | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | You can't place anyone you've spoken to, so you can't tell who is behind the process. The sign shows an unverifiable process; it doesn't show who is behind it | `[inferred]` from the posting's own statement | As RR1 | confirmed |
| RR5 | Contact address doesn't match the firm's name | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | An address on a general mail domain can't be tied to the firm named in the posting | `[inferred]` from the address against the firm's name | Which email domain does your hiring team use? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this firm | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR7 | Pay is a ceiling with commission undefined | unknown | — | "Earn up to €26 an hour plus commission on every order you process." | The guaranteed rate and hours may fall well below your €30,000 floor (R1) | `[inferred]` from "up to" and the 15–30 hour range | What is the guaranteed hourly rate, the weekly hours, and how is commission calculated? | unresolved |

**Hold on RR1 to RR4:** don't pay anything, don't lodge the cheque, and don't send the IBAN you have ready, your PPS number or a passport photo. The sender's identity is unresolved. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing and pay nothing while the sender is unverified | see RR1–RR4 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it, and tell your bank if you're unsure | see RR2 | `[generic]` known pattern | pending your approval |
| A3 | Look for the firm independently (its own website, a business register) and use only contacts found there | see RR6 | `[grounded]` register | pending your approval |
| E1 | CV line from your own facts: "Handled about 60 Zendesk tickets a day at a parcel courier; trained two new starters; kept the team's weekly tracker in Excel" | Your courier ticket work and tracker are the kind of experience genuine customer-operations roles ask for | `[grounded]` your account | pending your approval |
| A4 | Aim a search at genuine customer-operations or order-processing roles, where the survey median of €31,200 sits above your €30,000 floor | see R1 | `[generic]` Pennoral guide | pending your approval |

Offer beyond this assessment: I can check any genuine role you find against your €30,000 floor and your Zendesk and Excel evidence, since you now have a working checklist for spotting this pattern.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator"; no results, so the employer is not established. This produced RR6 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This moved the market calibration and R1's context |
| 3. Hiring manager's public footprint | n/a | No name was given, only the handle @VellowayHiring, so there was no query to form |

I can save this as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- The jobs site and a link to the original listing → RR6 may close or firm up.
- Any company page, named person or website the listing pointed to → R-level research on role reality.
- A guaranteed rate and hours in writing, from a verified source → R1 and RR7 close.
- A sanitized tracker sample or short writing sample → R2, R3 to `high` and R4 to `direct`.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) → RR6 firms up. Say the word and it runs.

**Questions**

1. (RR6) Which jobs site was the posting on, and did the listing link to a company page or name a person?
2. (R5) Do you have a quiet place to work, for any genuine remote role you pursue?

Answer in text, paste a screenshot of the listing, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.