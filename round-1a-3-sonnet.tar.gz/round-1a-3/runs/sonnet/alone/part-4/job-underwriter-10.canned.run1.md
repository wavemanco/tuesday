I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, worth taking forward. The register holds no red flag, and the WhatsApp message is routine scheduling for a video call (role reality, Contact route). Status: `conditional_go`.**

Your message says Ronan thanked you for applying, so the live question is whether to take the call, not whether to apply.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (First designer, no design peers)

R6: checkout is evidenced and the wider flow is not; R8: usability sessions bridge to owner interviews, limit named; R9: the bridge is real and the limit is stated by you; R4 (`medium`): daily Figma use stated, no artifact inspected yet.

**Opportunity ledger.** The employer matches the posting on every page found (RR1) and the pay is disclosed and in band (RR4). The open items are equity terms (RR2), design decision rights for a first designer (RR3) and runway (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the salary clears your own floor, which I don't know (R2); (2) the equity terms turn out to be concrete (RR2); (3) design decision rights and support for a first designer verify in the call (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, "funded by its customers". They make Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` search result "About Fernquay" (fernquay.example/about) |
| Mandate | First design hire: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with the co-founder | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting; `[grounded]` search result "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) |
| Scope read | A broad but ordinary first-designer remit: one product, one flow, two engineers, direct access to a founder | `[inferred]` from the posting's mandate against the team size on the about page |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting; the careers page says "plus equity" without a percentage |
| Market calibration | Product designers with 3–5 years in Ireland: median base €57,000, interquartile range €51,500–€62,000 (n=520). The posting's band sits inside that range. It is a base-pay survey for all of Ireland, not Galway, and not this employer's offer | `[generic]` role-family search, "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report) |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO of Fernquay, and before that was product lead at a Galway travel-software company for five years. That is relevant to your travel-booking background | `[grounded]` search result "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe) |
| Contact route | Scheduling a video call by WhatsApp, with the invite emailed, is ordinary for a small team and is not a sign of a problem. The one useful check is that the invite comes from Fernquay's own domain (A1) | `[generic]` small-company practice; `[grounded]` the message you pasted |
| Unknowns | Equity terms; runway; who currently owns design decisions; first-90-day outcomes (not stated); Saoirse Doyle's CTO title (the about page names her as co-founder, but I didn't see the title) | `[grounded]` posting silence |
| Contradictions | None found between the posting and the careers page: both say hybrid, two days a week in Galway, €52,000–€60,000. Both ask for one real project rather than a polished deck | `[grounded]` search results only; I did not fetch the full pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. Whether the commute to the office works is yours to confirm | `[grounded]` your message and the posting | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | medium | hard_gate | I have no pay floor from you, so I can't tell whether the band clears it. Confidence grades the posted figure, which is stated in two places | `[grounded]` posting and careers page; constraints not given | Pay-floor question below |
| R3 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer at a Dublin travel-booking company. This is a CV-level claim and I haven't seen an artifact | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | You state daily Figma use. The checkout case study Ronan mentions is not in front of me, so nothing is inspected | `[grounded]` your message | Share the case study to raise it |
| R5 | You have run your own user research | must_have | direct | medium | none | You state monthly usability sessions with customers that you ran | `[grounded]` your message | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow. Whether you owned the stages around it (availability, amends, confirmation), or only checkout, is unstated, so the reading that claims less is used | `[grounded]` your message | See G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R8 | Run research calls with school owners | important | adjacent | low | transferability | Usability sessions with customers carry over. The limit: they test a design, while owner calls are open discovery with small-business operators, and your message doesn't say whether your customers were consumers or businesses | `[grounded]` your message; `[inferred]` the usability-versus-discovery distinction | See G2 |
| R9 | First designer, no design peers (implied by "our first designer") | important | adjacent | low | transferability | You have shipped and run research in a squad but have never been the only designer, which is a limit you stated. The adjacent evidence is real and the gap is stated | `[grounded]` posting and your message | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow end to end (R6, must_have) | discovery | A checkout redesign. Nothing on availability or slot picking, amends and cancellations, or confirmations | The role's headline duty is the whole flow, so whether you owned more than checkout decides how to position you | Date or slot selection; changes and cancellations; confirmation emails; conversion measures you tracked | The checkout case study, before and after flows, an analytics screenshot | `[grounded]` your message's silence beyond checkout; `[generic]` that booking flows span more than checkout |
| G2 | Research calls with school owners (R8, important) | transferability | Monthly usability sessions with customers | Owner calls are discovery interviews with operators, and the bridge is stronger if any of your sessions were with business customers | Calls with operators or partners; sessions with support or sales staff; discovery interviews rather than usability tests | A discussion guide, a research plan, a synthesis note | `[inferred]` bridge from usability sessions; `[generic]` that discovery and usability research differ |
| G3 | First designer, no peers (R9, important) | transferability | Four years in a squad; no sole-designer role | Not a decision-changer: you've said it and it's carried as a named limit | Setting up component libraries or guidelines; critique without a design lead; setting your own research cadence | None needed | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle, and funded by its customers." | The company is a real, small, revenue-funded business hiring its first designer | `[grounded]` the about page, the careers page and Ronan Kehoe's profile agree with the posting | How many schools use the product today? | noted |
| RR2 | Equity percentage with no terms | unknown | — | "0.5–1% equity" | The share is hard to value without vesting, strike price, share class and the basis for the percentage | `[generic]` pattern for equity offers at small firms; not a claim about this company | What is the vesting schedule and cliff, what class of share is it, and what is the 0.5–1% measured against? | unresolved |
| RR3 | Design decision rights for a first designer | unknown | — | "You would be our first designer: own the booking flow end to end" | Ownership may be real, or it may sit beside founder-led product decisions | `[inferred]` from the posting naming ownership while saying you work most closely with the co-founder | When you and the engineers disagree on a design call, who decides? | unresolved |
| RR4 | Pay disclosed and within band | positive_signal | — | "€52,000–€60,000" | The posted band is transparent and falls inside the survey range | `[grounded]` posting; `[generic]` the survey band in role reality | Is the equity on top of this band, or part of how it is set? | noted |
| RR5 | Runway of a customer-funded company | unknown | — | "funded by its customers" | A revenue-funded firm's runway tracks its revenue, which makes the salary and the equity depend on it | `[inferred]` from "funded by its customers" | What is the current runway at this headcount? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the calendar invite comes from an address at Fernquay's own domain, and that the video link is the one in that email. If in doubt, write to the jobs address on the careers page | Routine due diligence for any call set up through a chat message | `[generic]` standard practice; `[grounded]` careers page lists the jobs address | pending your approval |
| A2 | Decide your pay floor, and any other deal-breakers, before the call | See R2; I have none from you | `[grounded]` R2 | pending your approval |
| A3 | Lead with the two things you've told me, in your own words: you redesigned the checkout flow at the Dublin travel-booking company, and you ran monthly usability sessions with customers. Say plainly that you have worked in a squad with engineers and have not been the only designer | Traces to your sentences, with R9's limit stated up front | `[grounded]` your message | pending your approval |
| A4 | Ask RR2, RR3 and RR5 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Bring one messy real project, as the posting asks | The posting says it would rather see one real project than a polished deck | `[grounded]` posting | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (returned "About Fernquay", fernquay.example/about) and "Fernquay careers Product Designer Galway" (returned "Product Designer — Fernquay careers", fernquay.example/careers/product-designer). Role reality: organization and contradictions rows; RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration; RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality: hiring manager row; A3 |

## Upgrade menu

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it.

- The checkout case study or a link to it → R4 and R6 could rise to `high`, and G1 could close.
- Your pay floor → R2 becomes met or failed.
- The full careers and about pages, not just their search snippets → I'd confirm the contradictions row and Saoirse Doyle's CTO title.
- A deeper research pass on Fernquay (customers, funding, hiring history, news; up to 5 more searches and 2 more fetches) → it could sharpen RR1 and RR5. Say the word and it runs.

## Questions

1. **R2:** What's the lowest salary you'd accept, and is there any other term (commute, hours, equity) you wouldn't trade?
2. **G1:** Beyond the checkout flow, which other parts of the booking journey did you personally own, and what happened to conversion or completion after your redesign?
3. **G2:** Were any of your monthly usability sessions with business customers, and did you ever run open discovery interviews rather than testing a design?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.