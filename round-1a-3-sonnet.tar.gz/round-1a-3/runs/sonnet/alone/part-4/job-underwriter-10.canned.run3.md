Running the L1 research now: checking whether Fernquay exists as described, then a salary sweep for the role.
**Yes, worth taking the call, and Fernquay checks out as the company the posting describes. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R6 (Research calls with school owners) · absent: R9 (First or only designer)

R7 — checkout is one part of a booking flow, its limit named; R9 — never the only designer, by your own account; R2 — waiting on your pay floor.

**Opportunity ledger.** The employer is established and the posting matches its own pages (RR1), and the pay sits inside the market band (RR2). Equity terms, decision rights and runway are unstated (RR3, RR4, RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the first-designer step-up is one you want, with decision rights and support clear (R9, RR4); (2) equity terms are written down (RR3); (3) the company's runway is explained (RR5).

On the WhatsApp message: a founder arranging an interview by chat is routine, and nothing in it asks you for money or personal details. The plan row A1 has a quick check on the emailed invite.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, customer-funded. It makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` About Fernquay page (search result) |
| Role | First design hire: own the booking flow, run research calls with school owners, ship alongside two engineers, work most closely with Ronan | `[grounded]` posting; careers page fetched, same role |
| Working pattern and pay | Hybrid, two days a week in Galway; €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting and careers page agree |
| Hiring contact | Ronan Kehoe appears as co-founder and CEO, previously five years as product lead at a Galway travel-software company. The about page names Saoirse Doyle as co-founder; I did not see "CTO" on any page I read | `[grounded]` LinkedIn profile snippet and About page |
| First-year outcomes | None stated; "own the booking flow" has no success measure | `[grounded]` posting silent |
| Scope read | One designer owning one product surface, close to the CEO, with two engineers. This is a broad, high-autonomy remit with no design leadership above you | `[inferred]` from "first designer", "end to end", and the team size |
| Market calibration | €52,000–€60,000 sits inside the range for 3–5 years of experience in Ireland (median €57,000, interquartile range €51,500–€62,000). It is the market norm and tells you nothing about Fernquay's own offer beyond the posted figure | `[generic]` Tillerby 2026 Ireland Design Salary Report, one search |
| Unknowns | Equity terms, decision rights against the founders, runway, who the research contacts are | — |
| Contradictions | None between the posting and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the location is met. Your willingness to commute two days is not stated | `[grounded]` your intake message | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states a band, but you gave no floor, so I can't say whether it meets your terms | `[grounded]` posting; your floor not given | Ask whether the band works (Q1) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company | `[grounded]` your intake message, self-reported | Share the case study to raise it |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily"; nothing inspected yet | `[grounded]` your intake message | Link the checkout case study |
| R5 | You have run your own user research | must_have | direct | medium | none | Ran monthly usability sessions with customers | `[grounded]` your intake message | none |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were usability sessions with customers. Not exercised: interviewing business owners about how they run their operation. Posting-wise, this role is mostly discovery conversation with operators, so the limit matters | `[grounded]` your intake message; `[inferred]` that owner calls are discovery work | Say plainly that you have run usability sessions, not owner interviews |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. Not established: the steps before checkout or ownership across the whole flow | `[grounded]` your intake message | Q3 |
| R8 | Work directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your intake message | none |
| R9 | First or only designer (implied by "our first designer") | important | absent | none | capability | You have never been the only designer. Inferred requirement: the posting states the role is first design hire but does not list it as a requirement | `[grounded]` your statement; `[inferred]` requirement from the posting's wording | Q2; frame honestly as a step up |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | Band stated; your terms not given | A gate I can't mark met or failed | n/a, a term, not experience | Your floor and your view of equity | `[grounded]` posting; your floor not given |
| G2 | Working without design leadership (R9, important) | capability | Never the only designer; a squad with four engineers | The posting makes you the first designer, so it matters how much direction you set yourself | Setting priorities when no design lead was present; deciding scope or trade-offs with the PM and engineers | A project brief, roadmap note, or case study showing decisions that were yours | `[grounded]` your statement; `[inferred]` that this is the likeliest probe |
| G3 | Booking flow beyond checkout (R7, must_have) | transferability | Checkout redesign confirmed | A must-have at `adjacent`; scope decides whether "end to end" is a stretch or a leap | Redesigning search, selection, availability or confirmation steps; owning the flow across several releases | The checkout case study, with scope noted | `[grounded]` your intake message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer exists and matches the posting | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | A young, small company can have a thin footprint beyond its own site; here the own-site pages match | `[grounded]` About and careers pages; `[generic]` that small firms have thin footprints | Which schools use Kelproster today, and could I speak to one? | noted |
| RR2 | Pay inside the market band | positive_signal | — | "Salary €52,000–€60,000" | The band is in line with the market median, so it is not a mismatch | `[grounded]` posting; `[generic]` survey band | Is there room within the band for experience? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage means little without the instrument, vesting, and what it is a share of | `[inferred]` from the posting giving a range and no terms | Is it options or shares, what is the vesting schedule, and is the percentage fully diluted? | unresolved |
| RR4 | Decision rights unstated for a sole designer | unknown | — | "own the booking flow end to end ... work most closely with our co-founder" | End-to-end ownership may sit beside founder-led product decisions | `[inferred]` from the posting's scope against its silence on decision rights | Which product decisions does this role make alone, and which go to Ronan? | unresolved |
| RR5 | Runway and revenue unstated | unknown | — | "funded by its customers" (About page) | Customer-funded means no investor round, but nothing shows how stable revenue is | `[inferred]` from the About page's funding line | What is your current revenue trend, and how many months of runway do you have? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the checkout redesign and the monthly usability sessions, in your own words and scope: "redesigned the checkout flow at a Dublin travel-booking company; ran monthly usability sessions with customers". Don't describe it as owning a booking flow or as owner research | Every clause traces to your sentences; R6 and R7 limits stay visible | `[grounded]` your intake message | `resume_edits_pending_approval` |
| A1 | Reply on WhatsApp to confirm the slot. Open the emailed invite and check the sender's address ends @fernquay.example, matching the careers page's jobs address | Founder-led scheduling by chat is common at six-person firms; this is a quick habit, not a concern | `[generic]` hiring pattern; `[grounded]` careers page address | pending your approval |
| A2 | Ask RR3, RR4 and RR5 aloud on the call, and ask to speak to a school owner | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | Say plainly that you have never been the only designer, then describe where you set direction | A first-designer role will test this; candor rehearses better than spin | `[generic]` role-family pattern; `[grounded]` R9 | pending your approval |

Rehearsing the call itself is the mock-interview skill's job.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (About Fernquay, fernquay.example/about) and "Fernquay careers product designer Galway"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality's organization and contradictions rows: the company exists and the posting is live and consistent |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup 3-5 years experience", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]` and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality's hiring-contact row; moved the framing in E1 toward travel-booking work |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` if you want it kept, just say so.

- Your pay floor and any other non-negotiables → R2 closes and the hard-gates line stops reading "unknown".
- The checkout case study link → R3, R4 and R7 can move toward `high`, and G3 narrows.
- A brief or case study showing decisions you made without a design lead → G2 and R9.
- Equity terms, decision rights and runway from the call → RR3, RR4 and RR5 close.
- Deeper research (customer reports, funding and recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- G1 — Is the €52,000–€60,000 band, with 0.5–1% equity, at or above your floor, and is two days a week in the Galway office fine for you?
- G2 — In Dublin, was there a design lead above you, and what product or design decisions were yours alone?
- G3 — Did your checkout redesign touch steps before checkout (search, availability, selection), or was it checkout only?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.