**Worth applying, and worth taking the call, on the conditions below. The firm is the part I couldn't check. Status: `conditional_go`.** The fit rows R1, R2, R3a and R4 are `direct`. I couldn't establish Fernquay from here because my web searches were refused, so that is a gap in my checking and says nothing about Fernquay. The WhatsApp message asks only for a 45-minute video call and nothing else from you. Scheduling by chat for a call held elsewhere is routine.

**Fit ledger.**

- `hard_gate` — unclear: R7 (Hybrid, two days in Galway office), R8 (Salary €52,000–€60,000)
- `must_have` — direct: R1, R2, R3a, R4 · adjacent: R5 (Own the booking flow end to end)
- `important` — adjacent: R3b (Research calls with school owners), R6 (First designer, no peer designer)

R5 — a credible bridge, scope beyond checkout unconfirmed; R6 — never the sole designer, named as the limit; R7 and R8 — unconfirmed because your constraints weren't given.

**Opportunity ledger.** The employer could not be checked (RR1). Equity terms, the work-sample ask and design decision rights are unstated (RR2, RR3, RR5). The posting does state pay and a concrete scope (RR4).

- **Hard gates:** none failed; unconfirmed: R7 (Hybrid, two days in Galway office), R8 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 verifies: the live posting, the company's own site, and Ronan and Saoirse's roles line up; (2) R7 and R8 meet your own limits; (3) R5 and R6 are framed as adjacent, never as having owned a whole product's design.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A six-person Galway company making booking software for sea-kayak and surf schools; not independently checked | `[grounded]` posting text as pasted |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two office days a week in Galway | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity; vesting and share terms not stated | `[grounded]` posting |
| Scope read | Real breadth for one person: flow design, research and delivery. The posting is clear about outcomes and silent on who has final say on design | `[inferred]` from the posting's three duties against its silence on decision rights |
| Market calibration | Not established. The role-family sweep did not run, so I have no band to set the €52–60k against and won't quote one from memory | `[grounded]` the sweep was refused |
| Contact and process | The message asks for a video call with the co-founder and the CTO and nothing else. It asks for no payment, bank or ID details. The invite is said to be by email | `[grounded]` your pasted message |
| Consistency | The co-founder named in the posting is the sender named in the message, and the message says it saw your checkout case study. These agree with each other, but only within what you pasted | `[grounded]` pasted posting and message |
| Unknowns | Design decision rights; equity vesting terms; what the "messy real project" ask involves; the first-90-days outcomes | `[grounded]` posting silent |

## Evidence map

Your background is self-report from your message. I haven't read the case study or any other artifact, so `medium` is the ceiling on every candidate row.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, confirmed in your words, no artifact inspected | `[grounded]` your background statement | Link the checkout case study to raise it to `high` |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily" for four years; strength is self-described and not inspected | `[grounded]` your background statement | The case study's Figma files would raise it to `high` |
| R3a | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Their format and depth aren't described | `[grounded]` your background statement | A short write-up of one session round would raise it to `high` |
| R3b | Research calls with school owners | important | adjacent | medium | transferability | Usability sessions with travel customers carry over to calls with business owners. Limit: nothing shows discovery interviews with owner-operators rather than testing a flow already built | `[grounded]` your statement; `[inferred]` the adjacency | See G2 |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | A squad with four engineers is first-hand, close working | `[grounded]` your background statement | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a travel-booking checkout, which is close in domain. Whether you owned steps beyond checkout is unstated | `[grounded]` your statement; `[inferred]` the adjacency | See G1 |
| R6 | Work as the company's first designer | important | adjacent | medium | transferability | You own a flow inside a squad but have never been the only designer. Limit: no evidence of setting design direction or working without peer review | `[grounded]` your statement | See G1 |
| R7 | Hybrid, two days a week in the Galway office | hard_gate | unclear | low | hard_gate | You live in Galway, but you haven't said whether two fixed office days meet your limits | `[grounded]` your move to Galway; no constraint given | See G3 |
| R8 | Salary €52,000–€60,000 | hard_gate | unclear | low | hard_gate | The posting states the range; your floor wasn't given, so I can't say if it meets it | `[grounded]` posting; no constraint given | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership and first-designer practice (R5, R6) | transferability | Checkout redesign plus squad work. Nothing on steps before or after checkout, or on setting direction without a design lead | The posting makes one person's ownership of the flow the job, and the call is likely to test it | Search or selection, pricing or add-ons, confirmation and cancellation emails, a design-system or component library you started, choosing what to research or ship next | The checkout case study, a flow map, a before/after | `[grounded]` your statement; `[generic]` that a sole-designer role leans on direction-setting |
| G2 | Discovery research with owner-operators (R3b) | transferability | Usability sessions with customers | Research calls with school owners are listed as a core duty | Interviews with partner or supplier businesses, support or sales calls you mined for insights, a research plan you wrote | A research plan, a synthesis board, a findings deck (sanitised) | `[grounded]` your statement |
| G3 | Your own limits on office days and pay (R7, R8) | hard_gate | Not given | If the terms fail either one, it settles the decision however strong the fit | Your pay floor; days you can or can't be in Galway | none needed beyond your answer | `[grounded]` no constraint stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may simply be too new or small for a footprint, the posting may be stale, or it may not be a live hiring employer. My searches didn't run, so this reflects my gap and not a finding about Fernquay | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | A percentage can't be valued without the vesting schedule, share type and total share count | `[inferred]` from the posting giving a percentage and nothing else | What is the vesting schedule and cliff, what type of shares or options are these, and what is the current fully diluted share count? | unresolved |
| RR3 | Work-sample ask unscoped | unknown | — | "we would rather see one messy real project than a polished deck" | It may mean walking through past work, or it may mean producing new work for them | `[inferred]` from the phrase's two readings | Is the messy project something I walk you through from my past work, or something you want me to produce, and how much time is it expected to take? | unresolved |
| RR4 | Pay and scope stated, named co-founder, CTO on the first call | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Terms are stated up front and the first call includes a technical decision-maker | `[grounded]` posting and your message | What would you want shipped in my first ninety days? | noted |
| RR5 | Design authority unstated | unknown | — | "You would be our first designer: own the booking flow end to end" | Ownership of the flow may sit beside final say with the co-founder | `[inferred]` from "work most closely with our co-founder" against silence on decision rights | Which design decisions would I make myself, and which would go to Ronan or the engineers? | unresolved |

## Application plan

Every row is a proposal. Nothing becomes CV text or outreach wording until you approve it, and that covers the advice below as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, open the invite in your email and check it came from a Fernquay domain. Find Ronan and Saoirse on the company's own site, and use contact details from there if anything needs checking | See RR1. This is a check you can do and I can't | `[grounded]` RR1 | pending your approval |
| A2 | Lead the call with the checkout case study they said they liked, and name its edges as the bridge: a travel checkout, with ownership beyond checkout still to confirm | See R5, R6 | `[grounded]` your message and statement | pending your approval |
| A3 | Be ready to say plainly that you haven't been the only designer, and describe how you set direction inside a squad | See R6 | `[grounded]` your statement | pending your approval |
| A4 | Ask RR2, RR3 and RR5 verbatim, and ask for the salary and office-day terms in writing if you want them confirmed | The register doubles as call preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Fernquay booking software sea kayak surf schools Galway", "Fernquay careers Product Designer Galway") were both refused for lack of permission. It would have settled whether the company and a live posting exist (RR1) and whether the posting matches what you were sent (role reality's consistency row) |
| 2. Role-family sweep | unavailable | One search (product designer salary, Ireland) was refused. It would have given the market calibration line and a check of €52–60k against the role (R8) |
| 3. Hiring manager's public footprint | unavailable | One search on Ronan Kehoe and Fernquay was refused. The name was given, so this is a refusal and not an `n/a`. It would have fed the scope read and which story to lead with (A2) |

## Dossier offer and upgrade menu

I can write this up as a `tuesday-dossier.md` you can keep, if you'd like one.

- Permission to run web searches → rows 1–3 run: RR1 can close, a market band appears for R8, and Ronan's public professional background informs A2.
- A link to the live posting or Fernquay's own careers page → RR1 resolves without searching.
- The checkout case study link and a Figma file → R1, R2, R3a to `high`; R5 firmed up.
- A research plan or synthesis write-up → R3b firmed up.
- Their answers on vesting, design authority and the work-sample ask → RR2, RR3, RR5 close.

## Questions

1. G3 (R7, R8) — Do you have a pay floor or an office-days limit that this role's terms would have to meet? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G1 (R5, R6) — At the travel-booking company, which steps of the booking journey beyond checkout did you personally own, and where did you decide design direction yourself? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. G2 (R3b) — Have you run discovery interviews, as distinct from usability tests, with business owners or partners, and what did the findings change? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.