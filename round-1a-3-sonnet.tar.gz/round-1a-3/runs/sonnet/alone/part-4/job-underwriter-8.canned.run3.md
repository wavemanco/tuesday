**Should you go ahead? No. Send nothing and pay nothing, and don't lodge the cheque. I can't confirm Velloway Logistics exists from here. The messages ask you to pay €349 (RR1), to deposit a cheque and forward money (RR2), and to hand over bank, tax and ID details before any offer (RR3). This job is very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — adjacent: R6 (Order-processing work); unclear: R5 (A quiet place to work)

R1 — the pay can't be confirmed from the posting; R6 — a bridge, its limit named.

**Opportunity ledger.** Four confirmed requests in the messages are severe: RR1 (paying for equipment), RR2 (cheque deposit and forwarding), RR3 (bank, tax and ID details before an offer) and RR4 (a hiring process run wholly on Telegram). The employer can't be established from sources outside the chat (RR6), and the pay is a ceiling, not a rate (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** (1) the employer is established from its own website, with the posting live there; (2) no payment, cheque or ID details are requested before a written offer naming the role and pay; (3) interviews are held live, by call or video, not only in chat; (4) a guaranteed rate and hours come in writing, to settle R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". A search on the name returned nothing, so what it is, and whether the sender represents it, is not established (RR6) | `[grounded]` JD header; `[grounded]` search returned no results |
| Mandate | "Remote Order Processing Coordinator": process orders from home, "set your own hours" | `[grounded]` JD |
| Hours and pay | "15–30 a week", "up to €26 an hour plus commission on every order". The commission rate and the guaranteed hourly rate are not stated | `[grounded]` JD |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` JD |
| Scope read | Entry-level order handling. No first-90-day or first-year outcomes are stated | `[inferred]` from "No experience needed" and the posting's silence on outcomes |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200 a year, interquartile range €28,400 to €34,100. The survey leaves out commission-only and freelance work. The band is what to expect for a salaried post, never this employer's offer. The posting's ceiling is €26 an hour (RR5) | `[generic]` a pay survey found by one search; `[grounded]` JD for the €26 ceiling |
| Unknowns | Who the employer is; guaranteed hourly rate; commission rate; contract type; first-year outcomes | — |
| Contradictions | The posting mentions no equipment cost. The messages then add a €349 transfer and a cheque to forward, so the terms differ between the posting and the messages | `[grounded]` posting set against the messages you pasted |

## Evidence map

Your claims below come from your own message and are unverified. I haven't seen a CV or any artifact, so none reaches `high`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades the constraint, which is your own and stated. Fit is unclear because "up to €26" at "15–30 a week" spans about €20,280 to €40,560 a year at 52 weeks. €30,000 needs roughly 22 hours a week even at the ceiling rate, and commission is unquantified | `[inferred]` arithmetic on the JD's figures; `[grounded]` your stated floor | G1 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day in Zendesk is a stated volume of careful, repeated work. Self-reported, nothing inspectable yet | `[grounded]` your message | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-reported; the formulas, size and use are unspecified | `[grounded]` your message | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket replies are your daily work. No writing sample has been seen | `[grounded]` your message | none |
| R5 | A quiet place to work | important | unclear | none | discovery | The posting lists it and you haven't said. Costless to confirm, and it moves nothing while the status is `no_go` | `[grounded]` JD; your message is silent | G3 |
| R6 | Order-processing work (implied by the title) | important | adjacent | medium | transferability | Parcel-courier ticket handling carries over: order and delivery status, customer details, volume. Limit: you haven't said you entered or processed orders. Companies running this kind of role often value logistics-systems familiarity | `[inferred]` from your courier tickets; `[generic]` on what such roles value | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay meets your floor (R1, hard_gate) | hard_gate | A ceiling of €26 an hour with hours from 15 to 30; no guaranteed rate or hours | It decides R1, and any real offer must settle it in writing | None applies: this needs the employer's terms | A written offer from a verified employer stating hourly rate, weekly hours and commission terms | `[grounded]` JD; `[inferred]` that the posting can't settle it |
| G2 | Order processing (R6, important) | transferability | Courier ticket handling; nothing stated on order entry | Matters only if a verified role of this kind turns up | Redirecting, re-booking or correcting parcel records; returns or refund handling; any system where you changed order details | A sanitized Zendesk macro list or a tracker extract with names removed | `[inferred]` bridge from your courier work |
| G3 | Quiet place to work (R5, important) | discovery | The posting asks and the evidence is silent | Remote roles often ask for it as a practical condition | A home office or a quiet room | None needed | `[grounded]` JD; `[generic]` that remote posts commonly ask this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment demanded, after being told you passed | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A new starter being asked to pay for the work kit is a known pattern in job scams. This request is very likely a scam. The sender's identity is unresolved | `[generic]` known pattern; `[grounded]` the quoted message | Do you ask new starters to pay for equipment before they start? Put this to the employer through contact details you find yourself on its own website, never through the chat | confirmed |
| RR2 | Cheque to deposit, with most of it forwarded | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can be returned unpaid after the funds appear in your account, and a transfer you made in the meantime stays your loss. Being asked to forward most of the money is a known pattern in job scams. This request is very likely a scam | `[generic]` how cheques and known patterns work; `[grounded]` the quoted message | Why would a new employer send you a cheque and ask you to transfer part of it onward? Same route as RR1 | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | The request comes before an interview or a written offer. Handing these over can enable fraud in your name. This request is very likely a scam | `[generic]` known pattern; `[grounded]` the quoted message | Will you send me a written offer naming the role and pay before asking for any of these details? Same route as RR1 | confirmed |
| RR4 | Hiring and offer conducted wholly by chat; contact by a free-mail address | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." and "the job is yours!" | You were told you'd passed screening and then the interview, and were offered the job, all in chat. The sign shows that nobody can be checked live. You can check it by asking for a live call or video meeting arranged through the employer's own website | `[grounded]` the posting and your messages | Can we hold a live interview with a named person from your company? Same route as RR1 | confirmed |
| RR5 | Pay is a ceiling, against your €30,000 floor (R1) | risk_signal | medium | "Earn up to €26 an hour plus commission" | At the lower hours the posting names, even the ceiling lands below your floor; the guaranteed rate and commission are unstated. Posts like this one usually state a base rate | `[inferred]` JD figures against your floor; `[generic]` salaried median €31,200 | What is the guaranteed hourly rate and the guaranteed weekly hours, in writing? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. These stay side by side. The search returned nothing | `[generic]` pattern, not a claim about this firm | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

Hold on all of it: pay nothing, deposit nothing and share nothing while you check. This covers RR1, RR2, RR3 and RR4. I couldn't identify an employer independently of the chat, so the sender's identity is unresolved. Any check must go through contact details you find yourself on an employer's own website, never the chat or the address in these messages.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

I'm proposing no CV or outreach wording, so nothing here needs approval before use. The rows are advice, and the choices are yours.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or €349. I've not repeated or used your IBAN | see RR1, RR3; these details aren't needed to assess the job | `[grounded]` RR1, RR3 | proposed |
| A2 | If a cheque arrives, don't lodge it. If you ever lodged one and sent money, call your bank straight away | see RR2 | `[generic]` how returned cheques work | proposed |
| A3 | Report the posting to the jobs site, and the chat to Telegram. Then stop replying | see RR4 | `[generic]` how these sites handle reports | proposed |
| A4 | Aim at salaried customer-operations coordinator roles you can verify. The survey median is €31,200 against your floor of €30,000; its lower quartile of €28,400 would fall short | see R1, R6 | `[generic]` survey band; `[grounded]` your floor | proposed |

Offer beyond this assessment: I can search for verifiable Irish customer-operations roles near your €30,000 floor. That would give you a shortlist worth a real application, which this posting can't. Say yes and I'll build it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics"; it returned no results, so the firm is not established. It moved role reality's organization row and RR6 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary per hour"; it returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It moved the market calibration, RR5 and A4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

If you'd like to keep this, I can write it up as `tuesday-dossier.md`.

Upgrade menu:
- A link to the posting and the jobs site it appeared on → RR6 and the contradictions row.
- The firm's own website or careers page, if you can find one → RR6 resolves or hardens.
- A written offer from a verified employer with hourly rate and hours → R1 and RR5 close.
- A sanitized Zendesk macro list or tracker extract → R2, R3, R4 and R6 can rise to `high`.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) — say the word and it runs.

Question:
RR6 — Which jobs site was the posting on, and can you send me its link?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.