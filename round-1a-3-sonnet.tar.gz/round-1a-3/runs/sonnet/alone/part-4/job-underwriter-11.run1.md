I'll read the skill's reference files before building the assessment.
## Decision snapshots

**Duinvaart Cold Chain, Operations Analyst: yes, worth your time, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, three days Rotterdam)
- `must_have`: direct: R2, R3, R4
- `important`: direct: R5a · adjacent: R6 (Work with depot managers on route changes) · unclear: R5b (Temperature compliance, refrigerated fleet)
- `preferred`: adjacent: R7 (Dutch a plus)

R5b: temperature compliance isn't evidenced yet; R6 (`medium`): near the route-change work, your ownership unconfirmed; R1: the commute fact is unknown.

**Opportunity ledger.** The scope is clearly stated (RR3), but I couldn't verify the employer from here (RR1) and the pay is unstated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days Rotterdam); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Duinvaart's own careers page (RR1); (2) three days a week in Rotterdam works for you (R1); (3) temperature compliance is framed as not yet evidenced, never as experience you have (R5b).

**Kroonhaven Foods, Supply Planner: no, I wouldn't spend time on it as posted. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: K1 (On-site in Utrecht)
- `must_have`: adjacent: K6 (Fluent Dutch) · unclear: K4 (Advanced Excel) · absent: K2 (3+ years supply or demand planning in FMCG), K3 (Own the 13-week supply plan), K5 (SAP IBP or similar)
- `important`: adjacent: K7 (Run the weekly S&OP meeting)

K2, K3, K5: you told me you've never worked in planning; K4: Excel isn't mentioned either way.

**Opportunity ledger.** The role is clearly defined (KRR3). The employer couldn't be verified from here (KRR1) and the pay is unstated (KRR2).

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** documented planning work in an FMCG or similar setting (K2, K3), hands-on planning-system experience (K5), and Dutch at working fluency (K6). The role's terms would also have to move.

## Role reality

**Duinvaart Cold Chain, Operations Analyst**

| Element | What it is | Provenance |
|---|---|---|
| Organization | A refrigerated-fleet operator in Rotterdam. Size, stage and whether the posting is live are unverified. | `[grounded]` JD header; `[grounded]` search refused, so nothing further is established |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An ordinary analyst remit: two named metrics, a named tool, a named stakeholder group. No team-lead or budget language. | `[inferred]` from the JD's responsibility list |
| Unknowns | Salary, team size, who sets route changes (analyst or depot managers), how temperature data is captured | `[grounded]` JD silence |
| Market calibration | Not done. The salary sweep was refused, so no band is offered. | `[grounded]` research unavailable |

**Kroonhaven Foods, Supply Planner**

| Element | What it is | Provenance |
|---|---|---|
| Organization | A chilled ready-meals food business in Utrecht. Size, stage and whether the posting is live are unverified. | `[grounded]` JD header; `[grounded]` search refused |
| Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A full ownership role, not an analyst-support one. "Own" and "run" put the plan and the meeting on this person. | `[inferred]` from the JD's verbs |
| Unknowns | Salary, team size, which planning system is actually used, how much on-site time the role needs in practice | `[grounded]` JD silence |
| Market calibration | Not done, for the same reason as above. | `[grounded]` research unavailable |

## Evidence map

Your own words are the only source for you, and they count at the intake ceiling of `medium`. I haven't seen a CV or any artifact.

**Duinvaart Cold Chain**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You stated no constraints and no home location. You worked in Amsterdam; whether the commute works is yours to say. | `[grounded]` JD; `[grounded]` your message is silent on location | Ask the gate question (Q1) |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. A parcel carrier is logistics work. Self-reported, nothing inspectable yet. | `[grounded]` your stated background | none |
| R3 | Strong SQL | must_have | direct | medium | none | "SQL daily" over four years. "Strong" is the JD's word; daily use is what you stated. | `[grounded]` your stated background | A sanitized query sample would raise to `high` |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use | `[grounded]` your stated background | A dashboard screenshot with figures removed would raise to `high` |
| R5a | Track on-time delivery | important | direct | medium | none | The dashboard depot managers use is an on-time delivery dashboard. Whether you built or maintained it is not stated; I read it downward. | `[grounded]` your stated background | Q3 settles ownership |
| R5b | Track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | No temperature or cold-chain work was mentioned. Some parcel networks carry temperature-sensitive items, so it may exist. | `[grounded]` silence in your message; `[generic]` that parcel networks sometimes carry chilled goods | Q2 |
| R6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Route performance is close to route changes. Limit: you haven't said the reviews produced route changes or who decided them. | `[grounded]` your stated background; `[inferred]` adjacency from the review work | Q3 |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is a real partial match for a "plus". Limit: not fluent, and that stays true wherever it's used. | `[grounded]` your stated Dutch level | none, state it as conversational |

**Kroonhaven Foods**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Same as R1: no location or schedule constraint given | `[grounded]` JD; `[grounded]` your message is silent on location | Ask the gate question (Q1) |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said directly that you've never worked in planning, so this is a confirmed absence and not a first-pass guess | `[grounded]` your statement | Closure path in KG1 |
| K3 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning work stated. Your route-performance review is operational reporting, not capacity-against-forecast planning. | `[grounded]` your statement; `[inferred]` that the review work is a different kind of activity | KG1 |
| K4 | Advanced Excel | must_have | unclear | none | discovery | Excel isn't mentioned. Daily SQL and Power BI don't establish it, and I'm not inferring it. | `[grounded]` silence in your message | Not asked: the other gaps decide this role |
| K5 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analytics tools, not planning systems | `[grounded]` your stated tools; `[generic]` that IBP-type systems are a separate category | KG1 |
| K6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is near the requirement but below it. Postings of this kind often screen language literally. | `[grounded]` your stated Dutch level; `[generic]` screening pattern | KG2 |
| K7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: a cross-functional demand-and-supply meeting is a different forum, and you haven't said who attended or decided. | `[grounded]` your stated background; `[inferred]` the adjacency | KG1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b, important) | discovery | Nothing on temperature or cold-chain tracking | It's the domain-specific half of the role's first responsibility | Tracking temperature-sensitive or time-critical parcels; exception reports for late or damaged consignments; any SLA breach analysis | A sanitized exception report or SLA dashboard view | `[grounded]` silence; `[inferred]` that resolving it firms up the conditional |
| G2 | Route changes with depot managers (R6, important) | discovery | A weekly review and a dashboard, but not whether reviews led to route changes you proposed | It decides whether R6 reads as "worked with" or "influenced" | A review that ended in a changed route, a depot cut-off time, or a reassigned round | A review pack or action log | `[grounded]` your stated background; `[generic]` that interviewers probe ownership |
| G3 | Rotterdam hybrid (R1, hard_gate) | hard_gate | No location or schedule constraint on file | A gate the inputs don't settle stays open until answered | n/a, this is a fact about your situation | none | `[grounded]` silence |
| KG1 | Planning experience, plan ownership, planning system (K2, K3, K5, must_have; K7, important) | capability | No planning work, confirmed by you | Three must-haves are absent, and the role's core is owning the plan | A realistic route is a scoped-down target: supply-chain analytics or planning-support roles in food or FMCG, where SQL and Power BI are the asked-for skills | n/a | `[grounded]` your statement; `[generic]` that such roles exist as a stepping path |
| KG2 | Dutch fluency (K6, must_have) | transferability | Conversational Dutch against a fluent requirement | The gap is the stated limit of an adjacent match | A test certificate or documented work in Dutch would narrow the limit | A language certificate level | `[grounded]` your stated Dutch level |

## Opportunity risk register

Both employers share the same standing entry: neither could be attributed from here. The reasons below are possibilities, none ranked as likely.

**Duinvaart Cold Chain**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | "Operations Analyst ... Hybrid, three days a week" | The figure may sit below what you'd accept; the posting may simply omit it. | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Outputs and tools named | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers" | Scope is concrete: named metrics, tool and stakeholders. | `[grounded]` JD | Who defines the temperature-compliance thresholds today? | noted |

**Kroonhaven Foods**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| KRR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| KRR2 | Pay not stated | unknown | — | "Own the 13-week supply plan" | The figure may sit below what a plan-owning role pays, or the posting may omit it. | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| KRR3 | Responsibilities and tools named | positive_signal | — | "run the weekly S&OP meeting ... SAP IBP or a similar planning system" | Scope is concrete, so the fit read is reliable. | `[grounded]` JD | Which planning system does the team use today? | noted |

## Application plan

Every row below is proposed. All of it, including the wording inside the rows and the prose in the plan, is `resume_edits_pending_approval`; nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart only: lead the summary with "Operations analyst, four years at a parcel carrier in Amsterdam; SQL and Power BI daily, including the on-time delivery dashboard depot managers use; ran the weekly route-performance review." Each clause comes from your own sentences. I didn't write "built" because you didn't. Add "conversational Dutch" and never "fluent". | R2, R3, R4, R5a, R6, R7 | `[grounded]` your stated background | pending your approval |
| A1 | Check the Duinvaart posting on its own careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the register's verification questions at Duinvaart verbatim: pay, who defines temperature thresholds | RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Don't apply to Kroonhaven as posted. If you apply anyway, the KRR1 and KRR2 questions become essential, and K2, K3 and K5 would be the first things probed. | `no_go` basis | `[grounded]` K2, K3, K5 rows | pending your approval |
| A3 | Look for supply-chain analytics or planning-support roles in food or FMCG as a stepping path | KG1 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Every claim about you is self-reported prose, so nothing is above `medium`.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both calls were refused for lack of search permission, so nothing returned. It would have moved role reality's organization and contradictions rows and RR1 and KRR1. |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Rotterdam salary Netherlands" and "supply planner FMCG Netherlands salary SAP IBP Dutch required"; both refused. It would have moved the market-calibration lines and RR2 and KRR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

One more thing I can do: emit all of this as a `tuesday-dossier.md` you can keep or hand on, if you'd like it.

**Upgrade menu**

- Web search permission → both employers verified or left not-established, RR1 and KRR1 resolve, and the market-calibration lines become possible.
- The live posting link on each employer's own careers page → the same verification without a search.
- Your home location or commute limit → R1 closes.
- A sanitized dashboard screenshot or query sample → R3, R4 and R5a rise toward `high`.
- Any chilled or time-critical parcel tracking you've done → R5b moves from `unclear`.
- A review pack or action log showing a route change → R6 firms up.
- The posted salary → RR2 and KRR2 close.
- The hiring manager's name → role reality's scope read and which story the plan leads with.

**Questions**

Q1 (R1, K1): Can you commit to three days a week in Rotterdam, and is five days on-site in Utrecht something you'd consider? Where do you live?

Q2 (G1): At the parcel carrier, did you ever track temperature-sensitive or time-critical shipments, or report on breaches of a delivery condition? If so, what was your part?

Q3 (G2): Which parts did you personally own: did you build the on-time delivery dashboard or maintain it, and did your weekly route reviews lead to route changes you proposed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.