I'm reading the rest of the skill's rules, then I'll look Fernquay up on the web to check the company is real.
## Decision snapshot

**Yes, worth taking the call, and I can't yet say whether the company is legit. Status: `conditional_go`.** Nothing in the posting or the WhatsApp message asks you for money, bank details or ID. I couldn't establish Fernquay itself from here (RR1). I'm treating this as the interview stage: you applied and have been invited to a first call.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R8 (Own the booking flow end to end)
- `important` — adjacent: R6 (Research calls with school owners), R9 (First and only designer)

R8 — checkout is one segment of a booking flow, so full ownership is unconfirmed; R9 (`medium`) — the real stretch, since you've always had design peers.

**Opportunity ledger.** The employer is not established from here (RR1), and equity terms (RR3), runway (RR5) and design support in a one-designer post (RR4) are all unknown. The stated pay band (RR2) runs the other way. The WhatsApp contact only schedules a video call and takes no register entry.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company and posting verify independently — RR1; (2) the pay clears your floor — R2; (3) equity terms and runway get concrete answers — RR3, RR5; (4) the support for a first designer is real — RR4, R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting as you pasted it, not checked against the company's own pages |
| Mandate | First product designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reporting line | Works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Scope read | Three jobs in one post: flow design, user research and being the sole design voice, for a team of six | `[inferred]` from the mandate list against the team size |
| Market calibration | Not done: the role-family sweep did not run, so I can't say where this band or scope sits | `[generic]` none available |
| Unknowns | Contract basis; equity terms; runway; success measures; who reviews your work | — |
| Contradictions | None between the posting and the WhatsApp message; not compared with the company's own pages | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the location is met. Which two days, and whether you want them, isn't stated | `[grounded]` your statement; posting | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | low | hard_gate | The posting states the pay, but I don't have your floor or current salary. The equity can't be valued without its terms (RR3) | `[grounded]` posting figures; your floor not given | G4 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. This is your own account, with no artifact in hand | `[grounded]` your statement | none |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily across those four years. "Strong" can only be judged from the work itself | `[grounded]` your statement | share the checkout case study to raise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your statement | none |
| R6 | Research calls with school owners (small-business discovery) | important | adjacent | medium | transferability | Your sessions were usability testing. Discovery interviews with business owners is a different skill. Nothing says yours included any | `[grounded]` your statement; `[inferred]` the limit | G3 |
| R7 | Work directly with engineers | must_have | direct | medium | none | Squad with four engineers; this post has two | `[grounded]` your statement | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a booking product's checkout. Whether you owned the rest of the flow (search, selection, post-booking) isn't stated | `[grounded]` your statement; `[inferred]` the limit | G1 |
| R9 | Be the first and only designer (implied by "first designer") | important | adjacent | medium | transferability | Carries over: owning a flow and running your own research. Limit: you've always had design peers, and nothing shows you building design foundations from nothing | `[grounded]` posting and your statement; `[inferred]` the bridge | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Full flow ownership (R8, must_have) | discovery | A checkout redesign; the rest of the flow isn't mentioned | The post's headline duty is the whole booking flow, so which parts you owned decides how direct this is | Search or availability screens, pricing or add-on steps, confirmation emails, post-booking changes and cancellations | The case study, a before/after flow map | `[grounded]` your summary covers checkout only |
| G2 | Working as the sole designer (R9, important) | transferability | Squad work with engineers, but always alongside other designers | The posting makes this the job's shape, and the interviewers will probe it | A component library or style guide you started or maintained, setting up a research routine, making design calls without review | Screenshots of a library or process doc you created | `[inferred]` bridge from your account; `[generic]` that a first-designer role gets probed on this |
| G3 | Discovery research with business owners (R6, important) | transferability | Monthly usability sessions; unclear whether they were exploratory, or with business customers | Owner calls are a named duty | Customer interviews before a redesign, calls with partners or suppliers, sales-call shadowing | A research plan or findings summary | `[grounded]` your statement says "usability sessions" only |
| G4 | Pay against your floor (R2, hard_gate) | hard_gate | Band stated; your floor not given | A pay gap would be a hard-gate failure | n/a | n/a | `[grounded]` posting; your floor unknown |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` you couldn't find much online | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay band stated openly | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The employer is willing to be concrete on pay | `[grounded]` posting | Is the band fixed, or does it move with experience? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | A percentage means little without share class, vesting, the total shares outstanding and any dilution plan | `[generic]` how equity offers work; `[inferred]` from the posting's silence on terms | What are the vesting schedule, cliff and share class, and what is the total share count today? | unresolved |
| RR4 | One designer, three jobs, no stated support or success measures | unknown | — | "own the booking flow end to end, run research calls … ship alongside our two engineers" | You may be accountable for design quality with no review, no design system and no defined first-year goals | `[inferred]` from the mandate list against the posting's silence on outcomes | What would success look like in my first year, and who reviews my design work? | unresolved |
| RR5 | Runway and funding unknown | unknown | — | "We are six people" | A six-person team's stability may rest on funding the posting doesn't mention | `[inferred]` from the posting's silence | How is the company funded, and how many months of runway does it have? | unresolved |

The WhatsApp message is routine scheduling: it asks only for a video call, with the invite sent by email. It asks for no money, bank details or ID, so it takes no register entry. A cheap check is that the invite email comes from the same domain as the company's own website, found by your own search rather than from a link in the message.

## Application plan

All rows are proposals pending your approval, including the framing advice; nothing here is final wording. Interview rehearsal is mock-interview's job, not this assessment's.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own site and a live copy of this posting through your own search, and check the invite domain against it | Closes RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions. State plainly that you've been in a squad with design peers and not the only designer | R3, R4, R5 and R7 are `direct`; R9 is `adjacent`, and claiming otherwise would be inflation | `[grounded]` map rows R3, R4, R5, R7, R9 | pending your approval |
| A3 | Ask RR3, RR4 and RR5 verbatim, and ask for the equity terms in writing if you get to an offer | Register questions double as interview preparation | `[grounded]` register | pending your approval |
| A4 | Ask in the call whether the checkout case study is the project they liked, and offer the full flow if you owned more of it | Tests R8 and makes use of the posting's stated preference for messy real work | `[grounded]` posting and the message | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Sent "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer careers Galway"; both refused. Would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Sent "product designer salary Ireland startup first designer 2026"; refused. Would have given the market calibration line and checked the band in R2 |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe's name was given, but no query was sent after the other searches were refused. Would have informed the scope read and which story to lead with |

I can write up this assessment as `tuesday-dossier.md` if you'd like to carry it forward.

## Upgrade menu

- Permission to run web searches, so targets 1–3 can run → RR1 resolves or stays open, the pay band gets calibrated, and the scope read firms up.
- The live posting link on Fernquay's own site, or the invite's sender domain → RR1 closes without any search.
- Your pay floor → R2 and the decision firm up.
- The checkout case study → R4 and R8 can reach `high`.
- A deeper research pass (up to 5 more searches and 2 more fetches) is available once the first tier has run.

## Questions

1. G4 — What is the lowest salary you'd accept, and does equity count for anything in that figure?
2. G1 — Beyond checkout, which parts of the booking flow did you personally own, and how did you know your changes worked?
3. G3 — Have you run exploratory interviews with business customers or partners, as opposed to usability tests? What did you learn?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.