I've read the skill's rules and I'm now running its employer check on Velloway Logistics: does the company exist, and does the posting match what it publishes. After that I'll write the assessment.
**No. Don't go ahead with this one.** This job is very likely a scam. The messages ask you to pay out money, lodge a cheque, and hand over bank and ID details, and the interview was all in chat (RR1, RR2, RR3 and RR4, all `severity: high`). I also can't find Velloway Logistics from here (RR5). Status: `no_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay at least €30,000 a year)
- `must_have` — direct: R2 · adjacent: R4 (Strong attention to detail) · unclear: R3 (Good written English)

R1 (`high`) — your floor is confirmed, but the posting only gives a maximum rate; R2 (`medium`) — self-reported, no artifact.

**Opportunity ledger.** Three money requests plus the chat-only hiring are severe (RR1, RR2, RR3, RR4). The employer can't be established (RR5) and the pay terms are only a ceiling (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** an employer I can confirm independently on its own website. It would also need a live interview, a written offer from its own domain, no payment or cheque asked of you, and pay terms that clear R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: a search for the name returned no results, so existence and size are not established | `[grounded]` search "Velloway Logistics", no results |
| Mandate | Remote order processing coordinator, 15–30 hours a week, own hours, "No experience needed, full training provided" | `[grounded]` posting |
| Pay as posted | "Up to €26 an hour plus commission". Commission terms and employment type are not stated. At the maximum rate, 15–30 hours a week is €20,280–€40,560 a year, and your €30,000 floor needs about 22 hours a week at that maximum | `[grounded]` posting; `[inferred]` arithmetic from its figures |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200, interquartile range €28,400–€34,100. The guide excludes commission-only and freelance work, so it is not like-for-like with variable hours | `[generic]` Pennoral 2026 Ireland pay guide, found by one search |
| Unknowns | Who the employer is, employee or contractor, commission terms, who interviewed you | `[grounded]` posting and messages are silent |
| Contradictions | The posting offers pay for work, while the messages ask you to pay €349 first and to move most of a cheque onward | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay at least €30,000 a year (your constraint; posting says "up to €26 an hour", 15–30 hours) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because the posting gives a maximum rate and a wide hours range, so the floor is not established | `[grounded]` your message and posting; `[inferred]` arithmetic | Pay terms in writing from a verifiable employer, or drop it |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. This is self-report with no artifact, so `medium` is the ceiling | `[grounded]` your background | A sanitised tracker would raise it to `high` |
| R3 | Good written English | must_have | unclear | low | discovery | Zendesk tickets may have been written replies, but your background doesn't say so and there is no sample | `[grounded]` your background; `[inferred]` that ticket work is written | Check what a writing sample could be |
| R4 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 tickets a day and a weekly tracker are adjacent to this. The limit is that no accuracy outcome is stated | `[grounded]` your background | Name an accuracy or error-rate outcome if you have one |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor not established (R1, hard_gate) | hard_gate | A maximum hourly rate, undefined commission, and 15–30 hours | It decides whether this could meet your €30,000 floor at all | A written salary or guaranteed-hours term from a named employer | A written offer from the employer's own domain | `[grounded]` posting wording; `[inferred]` shortfall at low hours |
| G2 | Written English evidence (R3, must_have) | discovery | Zendesk volume is stated, but not the writing involved | Matters for any genuine coordinator role, not this one | Ticket replies, macros or guides you wrote, or starter training notes | A sanitised reply sample or training guide | `[grounded]` background silent; `[generic]` that such roles screen writing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. It asks you to pay before any work or wages. The sender's identity is unresolved | `[generic]` requests like this are a known scam pattern | To the employer, via contact details you find yourself on its own site, not this chat: "Do you ask new hires to buy equipment, and did you send these messages?" | confirmed |
| RR2 | Asked to deposit a cheque and move money on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. Don't deposit the cheque. A cheque can be returned after the money has gone, and you would owe it back | `[generic]` known scam pattern | See RR1 | confirmed |
| RR3 | Bank and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details were asked for at the first screening, before an offer, and you don't need to give them | `[grounded]` the messages' order | See RR1 | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No live interview meant no way to see who you were dealing with. This sign alone takes no verdict; it can be checked | `[grounded]` posting | See RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | It may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is ranked as likely. The HR address is on a mail-provider domain, not one I can tie to the employer | `[generic]` pattern, not a claim about this employer | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR6 | Pay is a ceiling, not an offer | risk_signal | medium | "Earn up to €26 an hour plus commission" | At 15–30 hours the posted ceiling may fall below the €30,000 floor (R1). The salaried market median in role reality is €31,200 | `[inferred]` from the posting against the `[generic]` band | What is the guaranteed hourly rate, and how is commission calculated? | unresolved |

Hold for RR1–RR4: pay nothing, deposit nothing, and send no details until you've checked who sent these messages. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

Nothing here is final until you approve it. I'm proposing no CV wording.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't lodge or forward any of the cheque | RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| P2 | Report the posting to the jobs site where you found it | Others may see the same posting | `[generic]` | pending your approval |
| P3 | Look for roles that name the employer, state a salary, and interview by call or video. Your parcel-courier ticket work and Excel tracker map to R2 and R4 | Your €30,000 floor sits inside the salaried band in role reality | `[grounded]` your background; `[generic]` band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and got no results, so it is not established. Moved RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration row, R1 and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given; the Telegram handle is not a person's name |

I can turn this into a `tuesday-dossier.md` if you want a record of it, with no pressure to.

**Upgrade menu**

- The jobs site's name or a link to the live posting → RR5 and the posting-consistency check.
- Any written offer or contract, and the employer's own website → RR5 resolves either way.
- The guaranteed hourly rate and commission terms → R1 and RR6 close.
- A sanitised tracker or reply sample → R2 to `high`, R3 firmed.
- A deeper research pass on Velloway Logistics (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. RR1 — Have you sent or paid anything so far (details, photo, a transfer)? If yes, say what and when.
2. RR5 — Which jobs site was it on? Drop a link if you have one.
3. G1 — For a replacement search, what are your other must-haves beyond €30,000 (remote only, minimum hours, location)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.