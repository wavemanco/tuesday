I'm reading the skill's reference rules for the assessment format, then I'll run a few searches on Fernquay.
## Decision snapshot

**Yes, worth taking the call, with conditions: nothing in Ronan's message asks you for money, documents or personal details, but I couldn't check Fernquay's own pages from here, so the employer isn't verified yet (RR1). Status: `conditional_go`.** You've already applied, so the live question is whether to do the call.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 against your floor)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (First designer, no design peers)
- `preferred`: direct: R10

R7 (`medium`): checkout is part of a booking flow, ownership scope to confirm; R9 (`medium`): sole-designer work you haven't done, bridge named; R2: your floor decides it.

**Opportunity ledger.** The employer is unverified from here (RR1), equity terms are unstated (RR2), and the designer's decision rights are unknown (RR3). On the positive side, the posting states a pay band (RR4), and the message refers to your case study by name and puts a technical interviewer on the call (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 against your floor); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay's own site shows the company and this role, and you've done that check yourself (RR1); (2) the pay band clears your floor and the equity terms are explained (R2, RR2); (3) the sole-designer bridge is framed as adjacent, never as having been the only designer (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` JD |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Working pattern | Hybrid: two days a week in the Galway office, the rest from wherever suits you | `[grounded]` JD |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; vesting, strike price and share class unstated | `[grounded]` JD |
| Contact | Ronan Kehoe, co-founder, messaged you on WhatsApp for a 45-minute video call with him and Saoirse, the CTO, with a calendar invite emailed | `[grounded]` your message |
| Scope read | A coherent small-team remit: one product surface, direct work with the engineers, research by the designer | `[inferred]` from the JD's three duties against its stated team size |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not established: the role-family sweep couldn't run, so I give no salary band and no norm for this title | `[grounded]` see Evidence status |
| Unknowns | Equity terms; which product decisions the designer owns; who else shapes the roadmap | `[inferred]` from JD silence |
| Contradictions | None between the JD and the message (company, Ronan's role, Saoirse's role, your application). The JD can't be checked against a careers page from here | `[grounded]` JD and message compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You told me you moved back to Galway last year, so the office days are met. The band is `medium` because this is your own statement, not something I could inspect | `[grounded]` your stated location | none |
| R2 | Salary €52,000–€60,000 (against your floor) | hard_gate | unclear | none | hard_gate | The JD states the band. You haven't given a floor, so I can't say whether the band meets it | `[grounded]` JD; your floor not given | the question tagged R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, as you stated it | `[grounded]` your stated background | a LinkedIn or CV link would raise to high |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" shows use. "Strong" is a judgement an interviewer will test, so a file or portfolio would carry it | `[grounded]` your stated background | share a Figma file or prototype link |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your stated background | a sanitized research note would raise to high |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your stated background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout for a travel-booking product. Checkout is one stage of a booking flow, and the scope of your ownership beyond it isn't established | `[inferred]` adjacency from the checkout redesign | see G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers. Owners of small activity businesses are operators, a different audience | `[inferred]` from the JD's audience against your sessions | see G2 |
| R9 | Be the first designer, with no design peers | important | adjacent | medium | transferability | You've never been the only designer. You did own a checkout redesign and a monthly research cadence inside a squad | `[inferred]` requirement from the JD line "You would be our first designer" | see G3 |
| R10 | A messy real project over a polished deck | preferred | direct | medium | none | The checkout case study you submitted is the kind of real project the posting asks for, and Ronan's message praised it | `[grounded]` JD quote and your message | bring the working files and the rough edges to the call |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R7, must_have) | transferability | You redesigned checkout. Your role in the stages before and after it isn't established. Bridge: checkout is part of the same journey. Limit: you haven't said you owned search, selection or post-booking. | A must-have at `adjacent`; the duty is the job's centre | Owning a checkout redesign from research to launch; improving search, availability or confirmation screens; setting metrics for the flow | A before-and-after flow, a launch note, a metrics summary | `[inferred]` bridge from the checkout redesign |
| G2 | Research with business owners (R8, important) | transferability | Your sessions were with consumers. Bridge: the method is the same. Limit: operators have different goals and time. | Half the first-year work is research calls with school owners | Calls with a business customer, a supplier or a partner; a B2B or admin-side study | A discussion guide or a research summary | `[inferred]` bridge from your usability sessions |
| G3 | Working as the only designer (R9, important) | transferability | You've never been the only designer. Bridge: you owned a redesign and a research cadence. Limit: you haven't set design process with no peer review. | The team has no design lead to catch gaps | Setting up a component library; making a design decision with no review; handing off to engineers without a design lead | A process note, a component set, a handoff example | `[grounded]` your statement; `[inferred]` bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. You also report finding little online | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` your report | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may be before dilution, with vesting and strike price unstated | `[inferred]` from the JD's silence | What is the vesting schedule, the strike price, and the share class? | unresolved |
| RR3 | Designer's decision rights unknown | unknown | — | "You will work most closely with our co-founder, Ronan Kehoe" | Product direction may sit with the co-founder, with the designer owning execution | `[inferred]` from the JD's single named working partner | Which product decisions does the designer make alone, and which go to you? | unresolved |
| RR4 | Pay band stated in the posting | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The employer is transparent on pay | `[grounded]` JD states both | What would move someone from the bottom to the top of the band? | noted |
| RR5 | Message refers to your application and brings in the CTO | positive_signal | — | "we loved the checkout case study" and "me and Saoirse, our CTO" | The contact connects to your application, and you meet an engineering lead | `[grounded]` your message | What did the team take from the checkout case study that shaped this role? | noted |

## Application plan

Everything in this section is proposed. Nothing here is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, open Fernquay's own website yourself, not through the chat. Check that the calendar invite came from an address on that site's domain and that the video link is a mainstream platform. Scheduling a call over WhatsApp is routine for a small team | See RR1; the message asks only for a time | `[generic]` small-team scheduling pattern; `[grounded]` your message | pending your approval |
| A2 | Ask the verification questions of RR1, RR2 and RR3 in the call, verbatim | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | Describe your work as you stated it: you redesigned checkout and ran monthly usability sessions. Say plainly you've never been the only designer, and name what you'd carry over from your squad | Keeps R7 and R9 honest as adjacent | `[grounded]` R7, R9 rows | pending your approval |
| A4 | Bring one real project with its working files and rough edges, from the checkout redesign | The posting says they prefer a messy real project to a polished deck | `[grounded]` JD quote | pending your approval |
| A5 | Ask for the salary floor question and equity terms before a second round | See R2, RR2 | `[grounded]` R2, RR2 | pending your approval |

Rehearsal for the call with Ronan and Saoirse is mock-interview's job.

## Evidence status

Verified: none yet. Unverified leads: none from earlier conversation.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers Product Designer Galway"; both were refused, since search permission wasn't granted. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 first designer startup 3+ years"; refused. It would have moved the market calibration row and the pay check against the €52,000–€60,000 band |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe co-founder Fernquay"; refused. It would have moved the scope read and which story A3 leads with for Ronan |

## Upgrade menu

I can offer a dossier of this assessment: `tuesday-dossier.md`, saved only if you want it.

- A link to Fernquay's own website or careers page, or its text pasted here → RR1 may close without any search, and the contradictions row gets checked against the live posting.
- Search permission for the one remaining L1 search → the market calibration row, or the check on Ronan's professional footprint, would run.
- Your salary floor → R2 resolves, and the decision likely settles.
- A Figma file or portfolio link → R4 rises toward `high`.
- A sanitized research note or checkout before-and-after → R5, R7 and R8 strengthen.
- Answers to G1 and G3 → the R7 and R9 bridges either narrow or stay as named limits.

## Questions

1. **R2** — What's the minimum salary you'd accept, and are there other non-negotiables (equity, days in the office, anything else)?
2. **G1** — At the travel company, did you own more of the booking journey than checkout, such as search, availability or confirmation? What did you personally own, and what happened after launch?
3. **G3** — Have you ever made a design decision, or set up a process, with no other designer to review it? What was it, and how did it turn out?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.