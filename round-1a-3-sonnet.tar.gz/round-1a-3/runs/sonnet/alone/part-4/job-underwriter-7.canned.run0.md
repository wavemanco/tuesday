I'll read the reference files the skill points to before building the assessment.
Checking the employer and the pay band online, then I'll write up the assessment.
**Yes, this one is worth applying for. Status: `conditional_go`.**

I used your CV and advert, plus four searches and two page fetches (listed under Evidence status). I haven't repeated your National Insurance number anywhere, and nothing here needs it.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5, R7, R9, R11 · adjacent: R12 (Own small caseload and care planning) · unclear: R6 (Leg-ulcer care), R8 (Continence care), R10 (End-of-life visits)
- `preferred`: absent: R13 (Doppler assessment)

R12 is a credible bridge with its limit named. R6, R8 and R10 are CV silence, not a known lack. R13 is confirmed absent, but it is only desirable in the advert.

**Opportunity ledger.** Clear scope and a supported caseload (RR5, RR6). Open items are the working pattern (RR1), whether the post is live (RR2), how mileage works with pool cars (RR3) and the terms beyond salary (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`). Both rest on your word and are not checked by me. Candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The post is confirmed open (RR2).
  2. R6 and R10 are either confirmed from your experience or stated plainly as not yet held.
  3. You check your own NMC register entry and driving record (R1, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` employer's About page, fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Support and scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team and has spoken at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, found by search |
| Scope read | Leg-ulcer care and Doppler assessment are live topics for this team, so the Doppler gap may be trainable on the job. This is a question for the chat, not a promise. | `[inferred]` from the speaker page against the advert making Doppler desirable only |
| Market calibration | The posted £31,050–£37,800 spans a survey median of £34,300 (interquartile range £32,400–£36,600) for England Band 5 community staff nurses. The bottom of the range sits below that interquartile range. In that survey 61% were paid mileage and 24% had a pool or lease car. This is a market pattern, not this employer's offer. | `[generic]` search result "Wardround 2026 UK Community Nursing Pay Guide", self-reported, n=1,240, snippet only; `[grounded]` advert for the posted figures |
| First-90-days and first-year outcomes | Not stated | `[grounded]` advert silent |
| Unknowns | Hours and any weekend or on-call rota; where in the range you would start; pension and leave terms; how mileage applies with pool cars; closing date | `[grounded]` advert silent |
| Contradictions | None found. The advert is not confirmed on the employer's careers page (RR2). | `[grounded]` About page says vacancies are listed on a careers page; the address I tried returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Registered Nurse (Adult), registration active, revalidation due March 2028. Stated, not checked by me. | `[grounded]` CV | You look up your own entry on the NMC register and confirm it shows Adult nursing |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Pool cars are provided. Stated, not checked by me. | `[grounded]` CV; advert | You check your licence and driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. The CV gives no registration date, so this rests on the staff nurse title. | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about record-keeping or any electronic record system you have used. Ward and discharge-to-assess work involve records, but that is not evidence of yours. | `[grounded]` CV silence | Carried as a minor risk; add a record-keeping line only if you can supply a true one |
| R5 | Wound care (excluding leg ulcers) | important | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | unclear | low | discovery | The CV names pressure ulcers and surgical wounds, not leg ulcers. Evidence may exist. | `[grounded]` CV silence | See G1 |
| R7 | Catheter care | important | direct | medium | none | CV: catheter care | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | The CV names catheter care only. | `[grounded]` CV silence | See G3 |
| R9 | Insulin administration | important | direct | medium | none | CV: insulin administration, in an acute ward setting rather than at home | `[grounded]` CV | none |
| R10 | End-of-life visits | important | unclear | low | discovery | The CV does not mention end-of-life care. | `[grounded]` CV silence | See G2 |
| R11 | Visiting patients in their own homes | important | direct | medium | none | 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge | `[grounded]` CV | none |
| R12 | Holding a small caseload of your own, with care planning, supported by a senior nurse | important | adjacent | medium | transferability | You have never held your own caseload. Carries over: home visits to patients in their first post-discharge week. Limit: you have not carried an ongoing caseload or planned care over time. Roles built with senior support for newer caseload-holders are common. | `[grounded]` CV and your statement; `[generic]` on supported caseloads | Name the limit plainly; see G4 |
| R13 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have not done one. | `[grounded]` your statement | Closure path: ask in the chat whether training is offered (G5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R6, important) | discovery | The CV lists pressure ulcers and surgical wounds only | Leg-ulcer care is named in the advert, and the team lead has spoken on it | Applying or reviewing compression bandaging; dressing venous leg ulcers on the ward or on home visits; tissue-viability referrals for a leg wound | A competency sign-off or a tissue-viability training record | `[grounded]` CV silence; `[inferred]` that it matters to this team from the speaker page |
| G2 | End-of-life visits (R10, important) | discovery | The CV is silent on end-of-life care | Listed among the advert's core duties, so a confirmed answer changes how you frame the fit | End-of-life care on the medical ward; anticipatory medication or comfort-care plans; family conversations at the end of life; discharge of a dying patient home | A training certificate or a reflective entry, anonymised | `[grounded]` CV silence |
| G3 | Continence care (R8, important) | discovery | Catheter care is stated; other continence care is not | Part of the advert's duty list | Bladder or bowel care plans; continence assessments; catheter trials without catheter | A care-plan template or training record | `[grounded]` CV silence |
| G4 | Caseload (R12, important) | transferability | You have home-visit experience but no caseload of your own | The role is built around a small caseload with senior support | Following the same patients across several visits in the discharge-to-assess team; planning visit order; escalating to a senior | A team role description or a reference describing your visit load | `[grounded]` your statement; `[inferred]` bridge from the discharge-to-assess work |
| G5 | Doppler assessment (R13, preferred) | capability | No experience, stated by you | Desirable only, but it is a topic the team lead has spoken on | None to recover | none | `[grounded]` your statement; the speaker page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern unstated | unknown | — | "caring for housebound adults in their own homes ... end-of-life visits" | Community nursing posts may include evening, weekend or on-call work | `[generic]` role-family pattern, not a claim about this employer | What are the working hours, and is there a weekend, evening or on-call rota? | unresolved |
| RR2 | Posting not confirmed on the employer's own careers page | unknown | — | "Join our district nursing team" | The employer exists as described; the advert may simply not have been reached by my one careers-page attempt | `[grounded]` About page says vacancies are on a careers page; `[inferred]` that my one attempt proves nothing | Is this post open, and what is the closing date? | unresolved |
| RR3 | Mileage payable alongside pool cars is unexplained | unknown | — | "pool cars are provided" ... "plus mileage" | Mileage may apply to own-car use or to travel to a base, not to pool-car miles | `[inferred]` from the two phrases | When is mileage paid if a pool car is used? | unresolved |
| RR4 | Terms beyond salary unstated | unknown | — | "Band 5 ... £31,050–£37,800 a year plus mileage" | A community interest company's pension and leave terms may differ from an NHS employer's | `[generic]` pattern, not a claim about this employer | What are the pension, leave and sick-pay terms, and where would my five years place me in the range? | unresolved |
| RR5 | Supported caseload stated | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse." | Scope is defined and entry to caseload holding is supported | `[grounded]` advert | How is the senior support structured: accompanied visits, protected time? | noted |
| RR6 | Named lead offers an informal chat, and their public profile matches the team | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | The named contact leads the Halifax team the advert describes | `[grounded]` forum speaker page | What does the first month look like for a nurse new to community work? | noted |

## Application plan

Every row is proposed and pending your approval, including the wording in E1 and E2.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge." Every clause is your own sentence. | R11, R12 | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | Near the top, list your own skills in the advert's order using your own words: wound care including pressure ulcers and surgical wounds; catheter care; insulin administration. Add leg-ulcer, continence or end-of-life only after you confirm them. | R5, R7, R9 | `[grounded]` CV | `resume_edits_pending_approval` |
| A1 | Take up the informal chat. Ask RR1, RR2, RR3 and RR4 verbatim, and ask whether Doppler training is offered to staff new to community work. | RR1–RR4, R13 | `[grounded]` advert invites the chat | pending your approval |
| A2 | Say plainly that you have not held a caseload or done a Doppler assessment, and describe the discharge-to-assess home visits as what you have done. | R12, R13 | `[grounded]` your statements | pending your approval |
| A3 | Leave your National Insurance number off the application. It is usually only needed for payroll after an offer. | You offered it with the CV; it is not needed for this assessment | `[generic]` hiring practice | pending your approval |

## Evidence status

Verified: none yet. Everything about you comes from your CV and your message.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 district nursing Calderbrook Community Health CIC Halifax vacancy". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). A guessed careers address (calderbrookhealth.example/careers) returned no page. Moved: Organization row; the live posting is not confirmed (RR2). |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale 2026/27 community district nurse Band 5 role scope", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), a search snippet only. Moved: market calibration. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: scope read and A1. |

If you'd like, I can write all of this up as `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- Your answers on leg-ulcer, continence and end-of-life care → R6, R8 and R10 move off `unclear`.
- A wound-care competency sign-off, or a revalidation portfolio entry → R5, R7, R9 and R11 could move to `high`.
- Your own check of your NMC register entry and driving record → R1 and R2 confirmed.
- Your pay floor and any hours you won't work → hard-gate checks against your constraints.
- A link to the live posting on the employer's careers page → RR2 closes.
- A deeper research pass on Calderbrook (staffing and service news, public staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — Have you dressed or bandaged venous leg ulcers, on the ward or on home visits? What was your part, and was there a competency sign-off?

G2 — Have you cared for patients at the end of life, such as comfort-care plans, anticipatory medication or family conversations? What did you do yourself?

RR1 — Are there hours or pay terms, such as a weekend or evening rota or a pay floor, that you would not accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.