Checking whether Velloway Logistics shows up as a real employer, then I'll write up the assessment.
Short answer: don't go ahead. Send nothing and pay nothing. The work you described does fit your background, but what they are asking you to do is the problem.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

## Decision snapshot

**No, don't go ahead: RR1, RR2, RR3 and RR4 are severe red flags, and these requests are very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay floor of €30,000 a year)
- `must_have` — direct: R2, R3, R4 · adjacent: R5 (Order-processing duties)
- `important` — unclear: R6 (A quiet place to work)

R5 — a credible bridge from parcel-courier tickets; R2 (`medium`), R3 (`medium`), R4 (`medium`) — CV-level evidence, no artifact yet.

**Opportunity ledger.** The messages ask for payment for equipment (RR1), a cheque deposit (RR2), bank, tax and ID details before any written offer (RR3), and a hiring process run wholly on Telegram (RR4). The reply address is not on any employer domain (RR5), the employer is not established (RR6), and pay is given only as a ceiling (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay floor of €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the payment, cheque and details requests would have to be absent, and the employer would have to be confirmed through contacts you find yourself on its own site (RR1–RR4, RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics"; a search for the name returned no results, so the employer is not established | `[grounded]` posting header; search "Velloway Logistics" returned nothing |
| Role | Remote Order Processing Coordinator, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Duties and outcomes | The posting names no duties beyond the title and no first-year outcomes | `[grounded]` posting silent |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Scope read | An entry-level data-entry or order-handling post, going by "no experience needed" and the stated requirements | `[inferred]` from the requirements list |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland have a median base of €31,200 a year (interquartile range €28,400 to €34,100). The guide excludes commission-only and freelance work, so it is only a rough comparison for an hourly, part-time post | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide |
| Unknowns | Who the employer is, employment status, base pay floor, commission terms, who pays the "equipment partner" | `[grounded]` posting and messages silent |
| Contradictions | The posting mentions no equipment purchase or cheque. The first message asks you to pay €349 yourself. The later message has you forward the balance of a cheque to the same "partner" | `[grounded]` posting against the messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Your floor of €30,000 a year | hard_gate | unclear | high | hard_gate | Confidence grades your own constraint. Fit is `unclear` because pay is a ceiling only. At the full €26 an hour you would need about 22 hours a week to reach €30,000, and "up to" gives no floor. The commission is undefined | `[grounded]` your constraint and the posting; `[inferred]` arithmetic | RR7's question, if the employer is ever confirmed |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and training two new starters point to accuracy under volume. It is your own account with no artifact yet | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. Your own account only | `[grounded]` your background | an example tracker, sanitized, would raise to high |
| R4 | Good written English | must_have | direct | medium | none | Daily written customer replies. No sample seen | `[grounded]` your background | none |
| R5 | Processing orders (the implied duties) | must_have | adjacent | medium | transferability | Parcel-courier tickets are close to order handling. You have not described entering or processing orders. The limit is named wherever the bridge is used | `[inferred]` from the title; your background | see gap G1 |
| R6 | A quiet place to work | important | unclear | low | discovery | You have not said | `[grounded]` not stated | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Order processing (R5, must_have) | transferability | Ticket handling at a courier, with no order entry described | It would be the bridge for real order-processing roles | Any order, dispatch or returns handling alongside tickets | A short description of those tasks | `[inferred]` from your background |
| G2 | Pay floor (R1, hard_gate) | hard_gate | A ceiling and an undefined commission | The €30,000 floor can't be tested without base pay and hours | Not applicable | Written pay terms from a confirmed employer | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. A real employer would not ask you to pay for equipment in order to start | `[generic]` known pattern for requests of this kind | If you can find the employer independently on its own site: do you ever ask new hires to pay for equipment, and who is your equipment partner? | confirmed |
| RR2 | Cheque deposit, then forwarding money | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. The rest is €2,500 sent out of your own account, and a lodged cheque can later be returned unpaid, leaving you out of pocket | `[generic]` known pattern; `[inferred]` arithmetic | See RR1; same route and hold | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details were requested before any written offer naming the role and pay, so this is not routine onboarding | `[grounded]` messages order; `[generic]` onboarding norm | See RR1; same route and hold | confirmed |
| RR4 | Process run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No interview happened outside chat and the "offer" arrived in chat | `[grounded]` posting and messages | Can I speak to someone on your own published phone number or email? | confirmed |
| RR5 | Reply address off any employer domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | The address may not belong to the employer. I rate it medium rather than high because an address alone proves little | `[inferred]` from the address against the firm's name | Can you confirm this address from your own careers page? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for entities with no footprint | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Pay stated as a ceiling; commission undefined | unknown | — | "Earn up to €26 an hour plus commission on every order you process." | Base pay may sit well below €26. The ceiling can't be tested against your €30,000 floor (R1) | `[inferred]` from "up to"; `[generic]` salaried band above | What is the guaranteed hourly rate, the guaranteed weekly hours, and the commission formula? | unresolved |

Hold: pay nothing, deposit nothing and send no personal or bank details while the sender's identity is unresolved. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not send the IBAN, the PPS number or the passport photo, and do not pay the €349 | see RR1, RR3 | `[grounded]` RR1, RR3 | pending your approval |
| A2 | If a cheque arrives, do not lodge it, and do not forward any money | see RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Find any employer contact yourself on its own published site. If none can be found, report the posting to the jobs site | see RR4, RR6 | `[grounded]` RR4, RR6 | pending your approval |
| A4 | If you have already sent anything or paid, tell your bank straight away | Banks can act faster the sooner they hear | `[generic]` general advice | pending your approval |
| A5 | Redirect the search to customer-operations roles, where your ticket volume, onboarding and tracker work are your strongest evidence | see R2, R3, R5 | `[grounded]` your background; `[generic]` pay band above | pending your approval |

## Evidence status

Verified: none yet.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics", which returned no results, so the employer is not established. It fed RR6 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary work from home", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It fed the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only the handle @VellowayHiring, so there was no query to form |

Your IBAN is not needed for this assessment, and I have not used or repeated it. Keep it out of any chat.

## Dossier offer

If you'd like it, I can write all of this up as a `tuesday-dossier.md` for you to keep.

## Upgrade menu

- The employer's own website or careers page, found independently → RR6 and RR5 could resolve.
- Written pay terms (base rate, weekly hours, commission formula) from a confirmed employer → R1 and RR7 close.
- A sanitized sample of your Excel tracker → R3 rises to `high`.
- A short description of any order, dispatch or returns tasks you've done → G1 narrows R5.
- A deeper research pass on Velloway Logistics (recent news, public reports from other applicants; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. (RR3) Have you already sent or paid anything, including a reply with personal details, a copy of an ID, or money?
2. (R1) Is your €30,000 a gross annual figure, and how many hours a week could you work?
3. (G1) Have you handled any order, dispatch or returns work alongside your tickets?

Answer in text, paste a screenshot, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.