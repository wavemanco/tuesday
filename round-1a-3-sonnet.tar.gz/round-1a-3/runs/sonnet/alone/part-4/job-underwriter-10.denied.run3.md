I'll read the skill's reference files before building the assessment.
Worth taking the call, on conditions, though I can't establish Fernquay from here. The web search I tried was refused, so everything below rests on the posting, the message and your background.

## Decision snapshot

**Yes, worth taking the call. Status: `conditional_go`.** The firm can't be established from here (RR1), and your pay floor and office-day limits aren't known (R1, R2).

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days at Galway office), R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6
- `important`: adjacent: R7 (Own the booking flow end to end), R8 (Research calls with school owners), R9 (First designer on the team)

R1, R2 — terms not yet checked against your own limits; R7 — a credible bridge, its limit named (checkout versus the whole flow); R8 — customer sessions versus school owners, unconfirmed; R9 — no sole-designer history, so a stretch to be named honestly.

**Opportunity ledger.** The employer can't be established from here (RR1). The equity terms and runway are unstated (RR2, RR3), and a first-designer seat names no design reviewer (RR4). The posting is concrete on pay, equity range, scope and collaborators (RR5). The WhatsApp message asks only for a 45-minute video call. It asks for no money, documents or personal details, so it takes no register entry (see A2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days at Galway office), R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and the live posting verify through its own site, and the invite comes from its own domain, per RR1 and A1; (2) the pay band and two office days work against your own limits, per R1 and R2; (3) the call answers who reviews design work and what the equity is, per RR2, RR3 and RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, "six people in Galway making booking software for sea-kayak and surf schools"; no outside source read | `[grounded]` posting text only |
| Mandate | First designer: "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | `[grounded]` posting |
| Reporting line | Works "most closely with our co-founder, Ronan Kehoe" | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; vesting and strike terms not stated | `[grounded]` posting |
| Working pattern | Hybrid: two days a week at the Galway office, the rest "from wherever suits you" | `[grounded]` posting |
| Culture signals | "Small and informal", a dog in the office, "one messy real project" preferred over "a polished deck" | `[grounded]` posting |
| Scope read | Broad but coherent: one product, one flow, research plus shipping. The breadth is typical of a sole designer at a six-person firm | `[inferred]` from the posting's responsibilities against its stated team size |
| First-90-days outcomes | Not stated | `[grounded]` posting silent |
| Market calibration | Not established: the role-family sweep was refused, so no pay band is offered for this title. Model memory is not used for market values | `[grounded]` search refused this run |
| Unknowns | Equity terms; runway and funding; who reviews design work; customer base and product stage; success measures | `[inferred]` from the posting's silence |
| Contradictions | None between the posting and the WhatsApp message: both name Ronan Kehoe as co-founder and the same role. Nothing outside the two was checked | `[grounded]` posting and message compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at Galway office | hard_gate | unclear | low | hard_gate | Confidence grades your own statement, and you've only said you moved back to Galway. That is residence, not a stated limit on office days | `[grounded]` your message and the posting | Question G1 |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | No pay floor from you yet, so nothing to compare the band against | `[grounded]` posting figure, no floor given | Question G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, self-reported and not yet inspected. Experience length is not a gate | `[grounded]` your background | Link the portfolio case study to raise it |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily", confirmed but with nothing inspectable yet | `[grounded]` your background | Share a Figma file or prototype link |
| R5 | You have run your own user research | must_have | direct | medium | none | "Ran monthly usability sessions with customers": specific, with no artifact yet | `[grounded]` your background | Share a sanitized session plan or findings note |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | "Worked in a squad with four engineers"; whether it made you happy is yours to speak to | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | discovery | You redesigned the checkout flow at a travel-booking company, which is one stage of a booking journey. Whether you owned stages beyond checkout is unstated | `[grounded]` your background; `[inferred]` that checkout is one part of a wider flow | Question G2 |
| R8 | Run research calls with school owners | important | adjacent | medium | discovery | You ran sessions with "customers". Whether they were consumers or business owners isn't stated, and school owners are business customers | `[grounded]` your background; `[generic]` that owner interviews differ from consumer testing | Question G3 |
| R9 | First designer: no design peer in the team | important | adjacent | low | transferability | The role is "our first designer" and you've "never been the only designer anywhere". The carry-over is self-directed ownership of the checkout redesign and the monthly sessions. The limit is no sole-designer seat | `[grounded]` posting and your statement | Bridge case in G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay and office-day terms (R1, R2) | hard_gate | The posting states both, and your limits aren't given | A failed gate would end the process whatever the fit; unknown gates are what hold the status at `conditional_go` | A salary floor, a commute or caring constraint, a preference for remote days | None needed; your own statement | `[grounded]` posting terms, no constraints supplied |
| G2 | Ownership beyond checkout (R7) | discovery | One flow, checkout, is the evidence | The posting says "end to end", and the stages you owned beyond checkout would show how far your ownership reached | Booking search or availability screens, confirmation and email flows, post-booking changes, or a cancellation or refund flow | Before/after screens, a flow diagram, a case-study page | `[grounded]` background names only checkout; `[inferred]` the posting's scope implies more stages |
| G3 | Research with business owners (R8) | discovery | "Customers" with no segment named | Owner interviews are the posting's named research activity | Calls with a hotel, tour operator, or agency partner, or a supplier-side interview | A sanitized discussion guide or findings note | `[grounded]` background silent on segment |
| G4 | Sole-designer seat (R9) | transferability | Strong ownership inside a squad, no seat without design peers | A sole designer works without design review, which the posting makes explicit | Design systems or patterns you started yourself, a project where you made the design calls alone, a side or freelance project | The "messy real project" the posting asks for, with the decision log | `[grounded]` your statement; `[generic]` that sole-designer seats lack peer review |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Nothing could be checked this run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers page, and who besides you and Saoirse will I meet? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The equity's value depends on vesting, strike price and share class, none of which the posting gives | `[inferred]` from the posting's silence | What are the vesting schedule, strike price and share class for the equity? | unresolved |
| RR3 | Runway and funding unstated | unknown | — | "We are six people in Galway" | Whether a first-designer hire is funded for a stated period isn't shown | `[inferred]` from the posting's silence | How long is the current runway, and is this hire budgeted within it? | unresolved |
| RR4 | First designer with no named design reviewer | risk_signal | low | "You would be our first designer" | Craft feedback may come only from the co-founder and engineers; severity stays `low` because a first-designer hire is stated openly | `[inferred]` from "first designer" against the team size | Who reviews design work today, and what does success look like for this role after six months? | unresolved |
| RR5 | Concrete terms and a practical hiring signal | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" and "we would rather see one messy real project than a polished deck" | Pay, equity range, scope and a named collaborator are stated, and the process sounds hands-on | `[grounded]` posting | What would a good first booking-flow outcome look like in your first 90 days? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Fernquay yourself before the call: its own website and careers page (the role listed there), and that the calendar invite came from an address on its own domain. Use contact details from its site, not from the chat | RR1 | `[generic]` advice | pending your approval |
| A2 | Treat the WhatsApp message as scheduling. Reply in the thread or by email, and share no ID, bank or tax details at this stage. Those belong after a written offer, in the employer's own portal | WhatsApp is a common channel for small teams; the message asks only for a call | `[generic]` common small-company practice | pending your approval |
| A3 | Lead with the checkout redesign and the monthly usability sessions in your own words. Say plainly that you have worked in a squad and not as a sole designer | R5, R7, R9 | `[grounded]` your background | pending your approval |
| A4 | Ask RR1, RR2, RR3, RR4 and RR5 verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Bring one messy real project, not a polished deck, as the posting invites | R9, G4 | `[grounded]` posting | pending your approval |

Every row above is proposed. Nothing becomes part of your application or outreach until you approve it. Rehearsing the call itself is mock-interview's job, not this one's.

## Evidence status

Verified: none yet. No unverified leads from prior context.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches, "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers product designer Galway", were refused. It would have moved RR1, role reality's contradictions row, and whether the posting is live |
| 2. Role-family sweep | unavailable | One search, "product designer salary Ireland 2026 startup first designer", was refused. It would have moved the market calibration row and the R2 comparison |
| 3. Hiring manager's public footprint | unavailable | One search, "Ronan Kehoe Fernquay co-founder", was refused. It would have moved role reality's scope read and which story A3 leads with |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` if you'd like to keep or reuse it.

- Search permission → one L1 search remains (and two page fetches), and Fernquay's site and careers page come first, closing or confirming RR1. The salary band and Ronan's public professional footprint would then need a deeper pass of up to 5 more searches and 2 more fetches; say the word.
- Your pay floor and any limit on office days → R1 and R2 resolve, and the decision moves toward `go`.
- A link to the live posting and the invite's sender domain → RR1.
- Your portfolio or the checkout case study they mentioned, or a Figma file → R3, R4, R5 and R7 can rise toward `high`.
- Any answer on equity or runway from the call → RR2 and RR3.

## Questions

G1 — Are €52,000–€60,000 and two set office days a week in Galway each workable for you, and what's your pay floor?
G2 — Beyond checkout, which parts of the booking journey did you personally own, and what changed?
G3 — Were your monthly usability sessions with consumers or with business partners such as hotels or operators, and who ran them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.