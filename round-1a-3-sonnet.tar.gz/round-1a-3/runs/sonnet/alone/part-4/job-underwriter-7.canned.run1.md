I'll read the skill's reference files before building the assessment.
I've read the skill's reference files. Now I'm running the three L1 research targets: the employer's own site, a pay and scope check for the role, and the team lead's public professional footprint.
**Yes, it's worth applying for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R10 · adjacent: R5 (wound and leg-ulcer care), R9 (own caseload) · unclear: R4 (clear, timely written records)
- `important` — direct: R6a, R7 · unclear: R6b (continence care), R8 (end-of-life visits)
- `preferred` — absent: R11 (Doppler assessment for leg ulcers)

R5, R9 — credible bridges, limits named; R11 — absent, at the preferred tier.

**Opportunity ledger.** The role looks transparent. Pay, pool cars, a named contact and supervision are stated (RR2). The listing itself is not located on the employer's site (RR1). Caseload size, training and contract terms are unstated (RR3, RR4, RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Your records experience is confirmed (R4).
  2. The posting is confirmed live on the employer's own careers page (RR1).
  3. The caseload and leg-ulcer work are framed as adjacent, never as experience you haven't had (R5, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` employer's About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Support | A small caseload of your own, with a senior community nurse supporting | `[grounded]` JD |
| Travel | Pool cars provided, and mileage is also listed. Which one applies when is not stated | `[grounded]` JD |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` JD |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (search result) |
| Scope read | Leg-ulcer care looks like a real emphasis of this team, so expect Doppler and compression to come up | `[inferred]` from the lead's talks against the JD's leg-ulcer wording |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England puts median basic pay at £34,300 and the middle half at £32,400–£36,600. The posting's range brackets that median. The survey is a market pattern, not this employer's offer | `[generic]` survey; `[grounded]` JD for the posting's figure |
| Unknowns | Posting's live status, caseload size and visit rota, training and induction, contract basis and hours, mileage versus pool-car terms | — |
| Contradictions | None between the JD and the About page on service type or area. The posting itself was not found on the careers page | `[grounded]` About page fetched; careers address tried returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration as a Registered Nurse (Adult), with revalidation due March 2028. It's stated, not checked, and `medium` is the ceiling for unprobed intake. I haven't repeated the PIN | `[grounded]` your message | You check your own entry on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. It's stated, not checked | `[grounded]` your message | You check your licence record on the DVLA's online service |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical ward staff nurse is well past one year. This is a length requirement, not a gate. No document was inspected | `[grounded]` your message | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | Your message is silent on documentation and on any electronic record system. Ward nursing makes it likely you did this, but likely isn't evidence | `[grounded]` silence in your message; `[inferred]` that ward work implies record-keeping | G1 |
| R5 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Confirmed wound care covers pressure ulcers and surgical wounds. Leg ulcers and compression aren't mentioned. Community leg-ulcer care usually adds compression therapy and vascular assessment | `[grounded]` your message; `[generic]` for community leg-ulcer practice | G2 |
| R6a | Catheter care | important | direct | medium | none | Stated plainly in your message. No inspectable artifact | `[grounded]` your message | none |
| R6b | Continence care | important | unclear | low | discovery | Only catheter care is stated. Wider continence work isn't mentioned either way | `[grounded]` silence in your message | G6 |
| R7 | Insulin administration | important | direct | medium | none | Stated plainly. The JD pairs it with care planning at home, which this row doesn't claim | `[grounded]` your message, JD | none |
| R8 | End-of-life visits | important | unclear | low | discovery | Nothing stated. An acute medical ward may well have given you palliative care, but that isn't established | `[grounded]` silence in your message; `[inferred]` from the ward setting | G3 |
| R9 | A small caseload of your own, supported by a senior nurse | must_have | adjacent | medium | transferability | The adjacent work is 18 months of discharge-to-assess home visits in the first week after discharge. The limit is that you have never held your own caseload, and that's stated by you. The JD's senior support narrows the gap | `[grounded]` your message, JD | G4 |
| R10 | Visiting housebound adults in their own homes | must_have | direct | medium | none | The discharge-to-assess secondment is home-based work. It was 18 months and recent. No document was inspected | `[grounded]` your message | none |
| R11 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You say you have never done one. This is a preferred item, so a minor risk, not a blocker | `[grounded]` your message | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and electronic patient record (R4, must_have) | discovery | Silence on documentation and on any record system | A `must_have` at `unclear` is the one thing that holds the status at `conditional_go` | Discharge-to-assess records, ward notes, an electronic prescribing or patient system, audit of your documentation | A competency record, an audit result, or a system named on a reference | `[grounded]` silence in your message; `[inferred]` that this moves the status |
| G2 | Leg-ulcer care (R5, must_have) | transferability | Pressure-ulcer and surgical wound care. Leg ulcers and compression aren't mentioned | Leg-ulcer care is named in the JD, and the hiring lead has spoken on it | Applying compression bandaging, leg-ulcer reviews on the ward or on discharge visits, tissue-viability link work | A competency sign-off or tissue-viability training record | `[grounded]` your message, JD; `[inferred]` the lead's emphasis |
| G3 | End-of-life care (R8, important) | discovery | Nothing stated | A named duty in the JD, and acute wards often carry this | Last-days care on the ward, anticipatory medicines, family conversations, a syringe driver | A training record or reflective account | `[grounded]` silence in your message; `[generic]` that acute wards carry this |
| G4 | Own caseload (R9, must_have) | transferability | Home visits during discharge-to-assess, but you've never held a caseload | The limit to name honestly. Bridge: home visits. Limit: no own caseload. Strengthener: describe how you planned and prioritised a day of visits | Planning your own visit list, reassessing patients at home, escalating to GPs or therapists | A rota excerpt or a service description | `[grounded]` your message |
| G5 | Doppler assessment (R11, preferred) | capability | Never done, and no adjacent evidence. Closure path: ask whether training is provided; the lead has spoken on Doppler training for people new to community work | A preferred item, so a risk rather than a blocker | none claimed | A training booking, if you pursue one | `[grounded]` your message, forum page |
| G6 | Continence care (R6b, important) | discovery | Catheter care only | Part of the same JD line as R6a | Bladder scanning, continence assessments, bowel care | A competency record | `[grounded]` silence in your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not located on the employer's own careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The listing may be live at an address I didn't reach, may have closed, or may be listed elsewhere only | `[grounded]` About page points to a careers page; the address I tried returned no page | Can you point me to this post on your careers page, and what is its closing date? | unresolved |
| RR2 | Pay, pool cars, named contact and senior support are all stated | positive_signal | — | "pool cars are provided" … "supported by a senior community nurse" | The role is transparently scoped. Pool cars are provided at a minority of surveyed employers | `[grounded]` JD; `[generic]` survey (24% had a pool or lease car) | What does senior support look like in the first months: shadowing, joint visits? | noted |
| RR3 | Caseload size, visit rota and lone-working terms unstated | unknown | — | "a small caseload of your own" | "Small" may be modest or may grow quickly. Evening and weekend visits aren't mentioned | `[inferred]` from the JD's silence | How many patients and visits does a nurse carry in a day, and is there a weekend or on-call rota? | unresolved |
| RR4 | Training and induction not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The team may train new starters in Doppler, given the lead's talk on that topic | `[inferred]` from the JD and the forum page | Is Doppler training provided to nurses who haven't done it, and what induction does someone new to community work get? | unresolved |
| RR5 | Contract basis, hours, and mileage versus pool car unstated | unknown | — | "pool cars are provided" … "plus mileage" | The post may be full-time or part-time. Mileage may apply to personal-car use only | `[inferred]` from the JD's silence | Is this permanent, full-time, and when does mileage apply alongside pool cars? | unresolved |

## Application plan

Every row below, and any CV wording or message that follows, is proposed. Nothing changes your CV or goes to Rhiannon until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the 18-month discharge-to-assess secondment, in your own words: seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. No new facts added | see R9, R10 | `[grounded]` your message | pending your approval |
| E2 | Add a records line only once you've answered G1 | see R4 | `[grounded]` R4 row | pending your approval |
| A1 | Use the informal chat Rhiannon offers to ask RR3, RR4 and RR5 | The register doubles as interview preparation | `[grounded]` JD, register | pending your approval |
| A2 | Name Doppler as a gap and ask about training, rather than leaving it unspoken | see R11, RR4 | `[grounded]` R11 row | pending your approval |
| A3 | Check your own NMC register entry and DVLA licence record before applying | see R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A4 | Frame caseload and leg-ulcer work as adjacent: home visits yes, own caseload no | see R5, R9 | `[grounded]` R5, R9 rows | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment, so I've set it aside. The NMC PIN and licence class are treated as stated, not checked.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about); one fetch of a careers address I tried returned no page. Role reality's organization and contradictions rows; RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nursing salary scope Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Scope read, RR4, A1 |

I can save this as `tuesday-dossier.md` if you'd like to keep it or revisit it later.

## Upgrade menu

- An answer to G1 → R4 moves from `unclear`, and the status likely simplifies to `go`.
- The employer's careers listing or a live link to the post → RR1 closes.
- A competency record, training record or reference describing your home visits → R9, R10 and R5 can reach `high`.
- An answer to G3 and G6 → R8 and R6b improve.
- Your NMC register entry and licence record, once you've checked them → R1 and R2 reach `high`.
- Your pay floor, hours and any other non-negotiables → the hard-gates line stops reading "constraints not given", and the pay comparison becomes a real check.
- A deeper research pass on Calderbrook (leadership churn, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Three questions:

- **G1 (R4)** — What record system did you use on the ward or in discharge-to-assess, and what did you personally document: assessments, care plans, discharge notes? Any audit of your notes?
- **G2 (R5)** — Have you applied compression bandaging, reviewed leg ulcers or worked with tissue viability, even on the ward or on a discharge visit? What did you own?
- **G3 (R8)** — Have you cared for patients at the end of life, such as last-days care, anticipatory medicines or a syringe driver? What did you do yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.