I've read the underwriting rules. Next I'm running a few public searches on the firm and on typical pay for this kind of role, and then I'll write up the assessment.
## Decision snapshot

**No, don't go ahead: this job is very likely a scam, because these messages ask for payment, a cheque deposit and bank, tax and ID details before any written offer (RR1, RR2, RR3, RR4). Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

R1 — the posting gives a ceiling and no floor; R2 (`medium`), R3 (`medium`), R4 (`medium`) — match your background as self-report; R5 — nothing either way.

**Opportunity ledger.** RR1, RR2, RR3 and RR4 are each a confirmed demand quoted from the messages, and RR4 is the chat-only process. RR5 (the firm can't be established) and RR6 (a pay ceiling with no floor) are unresolved. No entry runs the other way.

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer would have to confirm the role and the sender through contact details you find on its own website, and the requests in RR1, RR2 and RR3 would have to be withdrawn. R1 would also need a guaranteed pay floor in writing.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics, named in the posting. I can't establish the firm from here: two searches returned no results | `[grounded]` searches returned nothing; not established |
| Mandate | Remote order processing, 15–30 hours a week, "set your own hours" | `[grounded]` posting |
| Pay | "up to €26 an hour plus commission on every order you process"; no floor and no commission rule given | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Scope read | An entry-level admin role. The posting names no systems, no reporting line and no manager | `[inferred]` from the posting's silence on all three |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200 a year, interquartile range €28,400 to €34,100 (n=1,140). The guide leaves out commission-only and freelance work, so it is a band to expect, never this employer's offer | `[generic]` one salary search, a 2026 pay guide |
| Unknowns | Who runs the Telegram handle; whether the post is employment or contract work; the guaranteed hourly rate; how commission works | `[inferred]` from what the posting and messages leave out |
| Contradictions | The posting mentions no equipment cost and says "full training provided". The messages then ask for €349 for equipment and ask for IBAN, PPS number and passport photo before any offer | `[grounded]` posting set against the messages; neither resolved |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint; posting says "up to €26 an hour", 15–30 hours a week) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because the posting gives a ceiling and no floor. At the full €26 you would need about 22 hours a week to reach €30,000, and at 15 hours a week the same rate gives about €20,280 | `[grounded]` your floor and the posting's figures; `[inferred]` arithmetic from them | Ask for the guaranteed hourly rate in writing, only after the employer is verified (RR6) |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and a weekly tracker you keep are relevant work. Self-report only, nothing inspected | `[grounded]` your message | A sanitized tracker screenshot would raise it to high |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. No file inspected | `[grounded]` your message | A sanitized tracker screenshot would raise it to high |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling at about 60 tickets a day. No writing sample inspected | `[grounded]` your message | None |
| R5 | A quiet place to work | important | unclear | none | discovery | No claim from you either way | `[grounded]` your message is silent | None while the status is `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Guaranteed pay against your floor (R1, hard_gate) | hard_gate | A ceiling of €26 an hour, 15–30 hours, commission undefined | It decides whether the role could meet your €30,000 floor even if the employer verified | Whether your floor counts guaranteed pay only, or commission too | The guaranteed hourly rate and commission rules in a written contract from a verified employer | `[grounded]` posting wording; `[inferred]` that the answer would settle R1 |
| G2 | Quiet place to work (R5, important) | discovery | Nothing stated | Low impact while the status is `no_go` | A room or hours where calls and typing are undisturbed | None needed | `[grounded]` no claim in your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" (asked before the interview and before any offer) | Payroll details after a credible written offer naming the role and pay are ordinary. Here they come first, in chat. This request is very likely a scam. | `[grounded]` the quote and its timing; `[generic]` what ordinary onboarding looks like | To the employer, through contacts on its own website: did you ask me for these details, and is this request from your payroll team? | confirmed |
| RR2 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A fee to start work, with a promised refund, is a known scam pattern. This request is very likely a scam. | `[grounded]` the quote; `[generic]` the pattern | To the employer, through contacts on its own website: do new starters pay for equipment, and who is this equipment partner? | confirmed |
| RR3 | Cheque to deposit, part forwarded | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can be credited and later returned unpaid, leaving the transfer you sent as your own money. This request is very likely a scam. Don't deposit the cheque. | `[grounded]` the quote; `[generic]` how returned cheques work | To the employer, through contacts on its own website: did you send me a cheque, and why does the process have me forward part of it? | confirmed |
| RR4 | Hiring and offer wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the offer all happened in the chat, which leaves no way to check who is on the other end. The sign shows the process; who sent it is unproven. | `[grounded]` the quote and your account of the chat | To the employer, through contacts on its own website: can I have a call or video interview and a written offer sent from an address on your own domain? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The firm may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The contact address given can't be matched to a website, since none turned up | `[generic]` pattern for firms of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay ceiling with no floor, commission undefined | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process" | The real rate may be well below €26 (see R1). The ceiling sits far above the band's median, which is a yearly figure for salaried work: €31,200 over a 40-hour week is roughly €15 an hour | `[grounded]` the posting's figure; `[generic]` the band; `[inferred]` the hourly conversion | What is the guaranteed hourly rate, and how is commission calculated, in writing? | unresolved |

**Hold.** Send nothing while RR1, RR2, RR3 and RR4 are open: no IBAN, no PPS number, no passport photo, no €349, and don't lodge the cheque or move any of its money. The sender's identity is unresolved for all four. Keep your IBAN to yourself too; I don't need it and I haven't repeated it. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

Nothing here is final until you approve it. That covers the advice in A1 to A5 as well as E1's wording.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send none of the details, no payment, and no cheque deposit or onward transfer | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Look for the employer's own website yourself and use only contact details found there; my searches found none | see RR4, RR5 | `[grounded]` register; searches | pending your approval |
| A3 | If the cheque arrives, don't lodge it, and tell your bank | see RR3 | `[generic]` ordinary caution with a cheque you can't place | pending your approval |
| A4 | Report the posting to the jobs site where you found it | see RR4, RR5 | `[generic]` jobs sites usually have a report option | pending your approval |
| A5 | Put your effort into roles listed on the employer's own site, at €30,000 or more, which is within the band's range | see R1, RR6 | `[generic]` 2026 pay guide | pending your approval |
| E1 | CV line for roles like this: "Handled about 60 Zendesk tickets a day at a parcel courier; trained two new starters; maintained the team's weekly Excel tracker." | see R2, R3, R4 | `[grounded]` your own figures, nothing added | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator"; both returned no results, so the firm is not established. This moved role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary per hour", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This moved the market calibration, R1 and RR6 |
| 3. Hiring manager's public footprint | n/a | No person was named, only a chat handle, so there was no name to search |

I can also save this as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- A link to the live posting on the jobs site would let me check it is live and matches what you pasted, which moves RR5.
- The employer's own website or careers page, found independently, would give a route for the verification questions in RR1 to RR4.
- The guaranteed hourly rate and commission rules in writing would settle R1 and RR6.
- A sanitized tracker screenshot would raise R2 and R3 to `high`.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) would check public reports and recent news. Say the word and it runs.

**Questions**

- G1 — Is €30,000 a floor on guaranteed pay, or could commission count toward it?
- RR5 — Which jobs site was the posting on, and can you paste its link?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.