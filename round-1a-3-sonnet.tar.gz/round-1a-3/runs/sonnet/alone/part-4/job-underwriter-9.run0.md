Yes, this is normal, and the way they've done it is the right way round. Your rule about never handing these over is still a good one. It's aimed at requests that come before an offer, or from someone you can't identify.

**Why this looks routine**
- **Order:** you had two in-person interviews at their office, then a written offer, and the details are requested only after you accept. A request for bank, tax or ID details before any offer is the pattern to worry about, and that isn't what happened here.
- **Bank details:** they're needed to pay you.
- **PPS number:** an Irish employer needs it to report your pay to Revenue.
- **Passport:** employers have to confirm you're entitled to work in Ireland. Many do that for every hire, and asking for the original on day one is common practice.
- **Role:** the job ad and the offer match (title, hybrid, Limerick, manager named, salary inside the advertised band).

I haven't searched the web, so I haven't independently checked Marrowgate. This is based only on what you've pasted.

**Light checks before you use the portal**
1. Check that the `marrowgatehousing.ie` domain matches the one on the company's own website and on the emails you got when arranging the interviews.
2. Before you click the portal link, check that it sits on that domain or on a payroll/HR provider they name. If you're unsure, email or phone Declan or someone you met, using contact details from their website, and ask them to confirm the link.
3. Upload documents through the portal only, not by email attachment.

**Before you accept**
- Ask for the written contract or terms. The offer doesn't mention notice period, probation, holiday or pension, and you'd be accepting within five working days. A reasonable employer will send these.
- The five-day deadline is also normal. If you need a few more days to review the contract, ask.

**Fit, briefly**
- You meet the requirements well:
  - three years of payroll (fortnightly, 90 staff);
  - starters and leavers;
  - the monthly payroll-to-ledger reconciliation;
  - the Payroll Technician certificate;
  - strong Excel.
- Two things to be upfront about:
  - **Staff size:** 240 staff is bigger than the 90 you've run.
  - **Pension changes:** you haven't done these yourself. Tell them now rather than after you start, and ask what pension scheme they use and whether there's handover or training. Don't describe it as something you've done.
- €40,000 is mid-band for the advertised €38,000–€42,000. You were never asked about salary beyond that, so negotiation is your call. It's a reasonable moment to ask for €42,000, given your certificate and reconciliation experience.

If you'd like, I can draft a short, polite reply that accepts conditionally on receiving the contract, and asks about pension handover.