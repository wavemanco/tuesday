I'll read the reference files the skill points to before building the assessment.
Update on what I did: I searched for the employer, a pay band and the team lead, and tried the employer's careers page. The assessment follows.

# Job Underwriting Assessment: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC

## Decision snapshot

**Yes, this one is worth applying for, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5, R7, R8 · adjacent: R6 (Leg-ulcer care) · unclear: R4 (Clear, timely written records on the electronic patient record), R9 (End-of-life visits), R10 (Care planning)
- `important` — direct: R11 · adjacent: R12 (Own caseload)
- `preferred` — absent: R13 (Doppler assessment)

R6, R12 — credible bridges, limits named; R4, R9, R10 — CV silent, which is a question and not a gap; R13 — preferred, not essential.

**Opportunity ledger.** The employer is established on its own About page, and pay, support and mileage are stated (RR2, RR3). Open items are whether the post is live (RR1), what induction and Doppler training exist (RR4), the rota and caseload size (RR5), and the terms (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`; both are your own statements, not yet checked); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post confirmed live, which clears RR1; (2) you check your own NMC register entry and driving record, R1 and R2; (3) R6, R12 and R13 are framed honestly as adjacent or absent, never as caseload or Doppler experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` About page, calderbrookhealth.example/about |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence, end-of-life, insulin, care planning, on the electronic patient record | `[grounded]` JD |
| Support and caseload | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Pay and travel | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England puts the median basic pay at £34,300 (interquartile range £32,400–£36,600; n=1,240). The posting's range brackets that range, so there is no mismatch. This is the market, not this employer's offer | `[generic]` survey page found by search; `[grounded]` JD for the posting's figures |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page, communitynursingforum.example/speakers/rhiannon-mabbott |
| Scope read | An ordinary community staff nurse post with supervision, not a bundled or unsupported one. Leg-ulcer work is a team interest, which makes the Doppler gap more visible and also more likely to be trained | `[inferred]` from the JD's support line and the speaker page |
| Unknowns | Whether the post is live; rota, weekends and on-call; caseload size; induction and competency training; terms and pension | — |
| Contradictions | None between the JD and the About page or speaker page. The careers page was not found at the address tried, so the posting itself is unconfirmed | `[grounded]` About page, speaker page and the failed careers fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states an active registration with a revalidation date. Stated, not checked; nothing has been inspected | `[grounded]` CV | You check your own NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full category B licence. Stated, not checked | `[grounded]` CV | You check your own driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement, so not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records on the electronic patient record | must_have | unclear | low | discovery | CV is silent on records and on any electronic system | `[grounded]` CV silence | G3 |
| R5 | Wound care, including leg-ulcer care in general terms | must_have | direct | medium | none | Pressure ulcers and surgical wounds stated; leg ulcers are split out at R6 | `[grounded]` CV | none |
| R6 | Leg-ulcer care | must_have | adjacent | low | transferability | Credible adjacency: pressure-ulcer and surgical wound care. Limit: no leg-ulcer, compression or Doppler work stated | `[inferred]` adjacency from the wound care stated | G2 |
| R7 | Catheter and continence care | must_have | direct | medium | none | Catheter care stated. Continence care beyond catheters is not stated, so say "catheter care" and nothing wider | `[grounded]` CV | none |
| R8 | Insulin administration | must_have | direct | medium | none | Stated plainly | `[grounded]` CV | none |
| R9 | End-of-life visits | must_have | unclear | low | discovery | CV is silent on end-of-life care | `[grounded]` CV silence | G1 |
| R10 | Care planning | must_have | unclear | low | discovery | CV is silent on care planning | `[grounded]` CV silence | G3 |
| R11 | Visiting patients at home | important | direct | medium | none | 18 months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge | `[grounded]` CV | E1 |
| R12 | A small caseload of your own | important | adjacent | low | transferability | Credible bridge: home visits on discharge-to-assess. Limit: you have never held your own caseload, and the CV must not imply otherwise. The JD names senior support, which is where the post's own risk mitigation sits | `[grounded]` your statement and the JD; `[inferred]` the bridge | E2 |
| R13 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have not done one. Preferred only; closure is training on the job or a short course | `[grounded]` your statement | RR4's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R9, must_have) | discovery | The CV establishes acute medical ward work but nothing about end-of-life care | Explicitly listed in the advert; an answer could move R9 to direct | Caring for dying patients on the ward; anticipatory prescribing or symptom-control charts; rapid discharge home to die; family conversations | A reflective note or a practice-feedback entry, sanitised | `[grounded]` CV silence; `[generic]` that wards on acute medical settings often include end-of-life patients |
| G2 | Leg-ulcer care (R6, must_have) | transferability | Wound care is stated, but no leg-ulcer, compression bandaging or Doppler work | The only clinical gap between the advert and the CV, and the team lead has a public interest in it | Applying compression bandaging; leg-ulcer assessment on the ward; a leg-ulcer or tissue-viability study day | A training certificate or competency sign-off | `[grounded]` CV and speaker page |
| G3 | Records and care planning (R4, R10, must_have) | discovery | The CV does not say which records system you used, or whether you wrote care plans | Both are in the advert and both can be recovered from ordinary ward work | Writing or updating care plans; discharge planning paperwork; electronic observation or patient record systems; audit of documentation | Nothing needed; a sentence in your own words is enough | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page may sit at a different address from the one tried, the vacancy may be advertised elsewhere, or the post may have closed | `[grounded]` fetch of /careers returned no page; `[generic]` reasons side by side, none ranked as likely | Is this post still open, and what is the closing date? | unresolved |
| RR2 | A senior nurse supports a small caseload | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | Support is named and the caseload is bounded, which suits someone moving from a ward | `[grounded]` JD | How does that support work in the first months: joint visits, shadowing, or case review? | noted |
| RR3 | Pay range, mileage and pool cars are stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" and "pool cars are provided" | Compensation is transparent and matches the survey's range | `[grounded]` JD; `[generic]` survey band | Is a pool car available to every visiting nurse at the Halifax base? | noted |
| RR4 | Induction and Doppler training not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The post may offer training: the team lead has spoken publicly about Doppler training for staff new to community work. Training for this post is not stated | `[grounded]` speaker page; `[inferred]` that it may extend to this post | What induction and competency sign-off would a new community nurse get, including Doppler, and over what timescale? | unresolved |
| RR5 | Rota, weekends, on-call and caseload size unstated | unknown | — | "district nursing team caring for housebound adults in their own homes" | Visiting services are often run seven days a week; whether this post covers weekends is not stated | `[generic]` role-family pattern; `[inferred]` from the JD's silence | What are the working pattern, weekend and on-call expectations, and the expected caseload? | unresolved |
| RR6 | Terms and conditions unstated | unknown | — | "Community Health CIC" | The company runs services under an NHS contract; whether staff terms, pension and leave match NHS terms is not stated | `[grounded]` About page; `[inferred]` from the JD's silence | Are terms and conditions, including pension and annual leave, the same as NHS Agenda for Change terms? | unresolved |

The standing employer-not-established entry does not apply: the employer is established on its own About page, and RR1 is about the posting, not the employer.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the 18-month discharge-to-assess secondment and home visiting, then list wound care, catheter care and insulin administration against it, using only what your CV states | R11, R5, R7, R8 | `[grounded]` CV | pending your approval |
| E2 | Say plainly in the supporting statement that you have not held your own caseload or done Doppler assessment, and that your closest experience is discharge-to-assess home visiting. Do not describe the secondment as a caseload | R12, R13 | `[grounded]` your statement | pending your approval |
| A1 | Take up the advert's offer of an informal chat with Rhiannon Mabbott before applying, and use the RR1, RR4, RR5 and RR6 questions | The advert invites it; her public talks cover Doppler training | `[grounded]` JD and speaker page | pending your approval |
| A2 | Check your own NMC register entry and your driving record yourself. Payroll and National Insurance details are an offer-stage step, given only on the employer's own portal | R1, R2 | `[generic]` | pending your approval |

All CV wording and positioning above is proposed, not final, and goes in only on your explicit approval.

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for an application and I haven't used or repeated it. The NMC and driving-licence claims are stated, not checked.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing" and "Calderbrook Community Health CIC Community Staff Nurse Band 5 vacancy", both returning "About Calderbrook Community Health" (calderbrookhealth.example/about); fetched calderbrookhealth.example/careers, which returned no page. Established the employer and its service. Posting liveness stayed unconfirmed, which created RR1 |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026/27 community staff nurse district nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Supplied the market calibration; no pay mismatch |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Fed the scope read, RR4 and A1 |

## Dossier offer

I can save all of this as `tuesday-dossier.md` if you'd like to keep it or use it later.

## Upgrade menu

- Your answers to G1, G2 and G3 → R9, R6, R4 and R10 firm up and E1 gets concrete wording.
- A training certificate or competency record for compression or leg-ulcer work → R6 rises from low towards medium.
- Your NMC register entry and driving record checked → R1 and R2 move from stated to checked.
- A link to the live vacancy or the careers page → RR1 closes.
- Rhiannon Mabbott's answers on induction, rota and terms → RR4, RR5 and RR6 close.
- A deeper research pass on Calderbrook (inspection reports, leadership changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **G1** — Have you cared for patients at the end of life on the ward or on discharge-to-assess, and what did you personally do (symptom control, family conversations, planning a discharge home)?
2. **G2** — Have you applied compression bandaging or assessed leg ulcers, or done any leg-ulcer or tissue-viability training?
3. **G3** — Did you write or update care plans, and which records system did you use on the ward and on discharge-to-assess?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.