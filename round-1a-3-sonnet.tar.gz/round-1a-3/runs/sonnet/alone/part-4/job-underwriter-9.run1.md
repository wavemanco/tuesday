Yes, this is normal. What they're asking for, in the order they're asking for it, is how a legitimate Irish employer onboards someone.

**Why each item is routine**
- **Bank details:** they can't pay you without them.
- **PPS number:** the employer needs it to register you with Revenue and run your PAYE, PRSI and USC. You'll know this from your own payroll work.
- **Passport scan and original on day one:** this is a standard identity and right-to-work check. For an Irish or EU/EEA citizen the legal requirement is lighter than for non-EEA staff, but many employers still take a copy. Asking for the original on your first day is a good sign, because it means someone will check you in person.

The advice never to hand these over is aimed at unsolicited contact before any real hiring process. That isn't your situation.

**Why this looks like a genuine offer**
- You had two in-person interviews at their office.
- The offer names your manager, the salary, the hybrid arrangement and the notice-period start.
- Their sequence is accept first, then portal, which is the right way round. They haven't asked for anything before an offer.
- The role matches the ad.

**Checks before you upload anything**
1. **The portal link.** It should sit on Marrowgate's own domain or a recognisable HR or payroll platform they name. If the link is vague, ask Declan or the People Team what platform it is.
2. **The sender.** Check that the offer's sender matches the contact details on Marrowgate's own website, not just the address that emailed you. A quick call to the number on their site, or a message to Declan, confirms it in a minute.
3. **Never send these details by email reply.** Use the portal only. If anyone asks for the passport scan or bank details over email or chat, stop and call them first.
4. **Privacy notice.** Ask for their employee privacy notice, which should say how long they keep your passport copy and who can see it. Irish employers are required to explain this under GDPR.
5. **Written terms.** The email offer is thin. Before you accept, ask for the contract or a written summary covering probation, notice period, pension scheme, leave and the start-date mechanism. Irish law requires a written statement of core terms within five days of starting.

**One extra point:** you've never done pension changes yourself. This is your one gap against the ad. It's worth asking in your reply who handles pension administration and what handover or training you'd get, so you're not learning it alone in your first month.

You don't need to refuse any of it. Do the sender check, then accept and use the portal.