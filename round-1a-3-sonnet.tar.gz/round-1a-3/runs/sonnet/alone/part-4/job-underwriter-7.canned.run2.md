Still reading the skill's reference files (research tiers, evidence-map rules) before I write the assessment. Next I'll pull the remaining sections I need.
# Job Underwriting — Community Staff Nurse, Band 5, Calderbrook Community Health CIC (Halifax)

## Decision snapshot

**Yes, this one is worth applying for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R6a, R7a, R9a · adjacent: R5 (Home visiting for housebound adults) · unclear: R4 (Clear, timely records on an electronic patient record), R6b (Leg-ulcer care), R7b (Continence care), R8 (End-of-life visits)
- `important` — adjacent: R10 (Own caseload and care planning)
- `preferred` — absent: R11 (Doppler assessment)

R5 — a credible bridge, its limit named; R4, R6b, R7b, R8 — the CV is silent and recall may close them; R10 (`low`) — the bridge is thin; R11 — a closure path is named.

**Opportunity ledger.** The employer is established and the pay is stated openly (RR5). One entry runs the other way: the hiring manager's public talks suggest Doppler skills are taught to new community staff (RR6). Open items are whether the posting is live (RR1), how big the caseload is and how it is supervised (RR2), how the pool car and mileage work together (RR3), and the working pattern (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed open, see RR1; (2) R4, R6b and R8 are recovered from your history, or carried honestly as gaps; (3) R10 and R11 are framed as what they are: no caseload of your own yet, no Doppler yet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff on four locality hubs | `[grounded]` About page, from the search result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, on an electronic patient record | `[grounded]` JD |
| Supervision | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Working pattern | Pool cars provided plus mileage; hours, weekends and on-call not stated | `[grounded]` JD, silent on hours |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | Six clinical areas under a Band 5 title, with supervision named, reads as a defined generalist post rather than several roles folded into one. The soft spot is that "small caseload" is undefined (RR2) | `[inferred]` from the JD's list and its supervision clause |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. Leg ulcers therefore look like a service priority, so R6b matters more than the JD's "desirable" suggests | `[grounded]` speaker page; `[inferred]` the priority reading |
| Market calibration | Stated pay £31,050–£37,800 `[grounded]` JD. A 2026 survey of Band 5 community staff nurses in England (n=1,240) gives a median basic of £34,300 and an interquartile range of £32,400–£36,600, with 61% paid mileage and 24% on a pool or lease car. The posted range brackets that interquartile range, so there is no pay mismatch. This is the market band, never this employer's offer. The sweep returned pay only, so scope is not calibrated against role-family norms | `[generic]` Wardround 2026 pay guide |
| Contradictions | The posting could not be found on the employer's careers page (RR1). Nothing in the JD contradicts the About page | `[grounded]` failed fetch; About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Adult registration, active, revalidation due March 2028. This is stated and not checked: the register entry is yours to look at | `[grounded]` CV | You check your own NMC register entry shows active, Adult |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated and not checked | `[grounded]` CV | You check your driving record; pool cars are provided per the JD |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward at a district general hospital. This is a length of experience, so it is a must-have and not a gate, though screening may apply it literally | `[grounded]` CV; `[generic]` literal screening of titled years | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV is silent on documentation and on any electronic record system. Ward documentation is routine for nurses, but that is a pattern and not your evidence | `[grounded]` CV silence; `[generic]` ward documentation norm | Gap G1 |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | Eighteen months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: that is a short post-discharge window, not a continuing housebound caseload | `[grounded]` CV; `[inferred]` the limit from the one-week window | Gap G5 |
| R6a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds, both stated | `[grounded]` CV | none |
| R6b | Leg-ulcer care | must_have | unclear | low | discovery | The CV names pressure ulcers and surgical wounds and does not mention leg ulcers or compression. It may be unrecorded experience or none | `[grounded]` CV silence | Gap G2 |
| R7a | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R7b | Continence care | must_have | unclear | low | discovery | The CV does not mention continence care beyond catheters | `[grounded]` CV silence | Gap G4 |
| R8 | End-of-life visits | must_have | unclear | low | discovery | The CV is silent. Acute medical wards see dying patients, but that is a pattern and not your evidence, and a home visit differs from a ward | `[grounded]` CV silence; `[generic]` ward exposure pattern | Gap G3 |
| R9a | Insulin administration | must_have | direct | medium | none | Stated. The JD pairs insulin with care planning, which sits in R10 | `[grounded]` CV | none |
| R10 | Holding a small caseload of your own and care planning | important | adjacent | low | transferability | You have said you have never held your own caseload. The nearest evidence is home visiting in the discharge team, whose planning content is unstated. The JD says a senior nurse supports the post | `[grounded]` your statement, CV, JD | Gap G6 |
| R11 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have said you have never done one. Preferred tier, so a minor risk. Closure path: training on appointment (RR6) | `[grounded]` your statement | Say so plainly; ask about training (RR6) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records on an electronic record (R4, must_have) | discovery | The CV says nothing about documentation or record systems | The JD asks for clear, timely records, and a must-have left silent leaves the posting's one stated written-skills requirement unmet on paper | Discharge-team notes or care plans you wrote; the electronic system your trust uses; audit feedback on your documentation | A redacted note format, an audit result, a line from a reference | `[grounded]` CV silence; `[inferred]` that this is the cheapest gap to close |
| G2 | Leg-ulcer care (R6b, must_have) | discovery | Pressure and surgical wounds only | The hiring manager has spoken publicly on leg-ulcer clinics, so a probe here is likely | Applying compression bandaging; assessing a venous leg ulcer; working alongside a tissue viability nurse or leg-ulcer clinic | A competency record, a training certificate | `[inferred]` the likelihood of a probe from the hiring manager's talks |
| G3 | End-of-life visits (R8, must_have) | discovery | Silent | Home end-of-life care is one of six named duties | Caring for dying patients on the ward; anticipatory medicines; fast-track discharges home to die in the discharge team | A reference, a training record in end-of-life care | `[grounded]` CV silence; `[grounded]` JD lists it |
| G4 | Continence care (R7b, must_have) | discovery | Catheter care only | Paired with catheter care in the JD | Bladder and bowel care plans; continence assessment | A training record | `[grounded]` CV silence |
| G5 | Housebound home care (R5, must_have) | transferability | Discharge-team home visits, first week after discharge | The bridge is strong but short-window | Visits beyond week one; patients you saw more than once; handovers to district nursing | A discharge-team service description | `[inferred]` the bridge from the CV |
| G6 | Own caseload and care planning (R10, important) | transferability | Never held a caseload; the JD offers senior support | The limit should be stated plainly, not stretched | Planning a patient's visits; managing a ward bay or patient group on a shift; any written care plans you authored | A redacted care plan | `[grounded]` your statement, JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the careers page | unknown | — | "Current vacancies are listed on our careers page." (About page) | The vacancy may sit at a different address, be closed, or be advertised through another channel | `[inferred]` from a failed fetch of one guessed address | Is this vacancy still open, and where on your site is it listed? | unresolved |
| RR2 | "Small caseload" and "supported by a senior community nurse" undefined | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse" | The support may be well defined or informal; the caseload may grow with vacancies | `[generic]` caseload and support often vary between teams | How many patients, what visit load, and how often does the senior nurse review your work? | unresolved |
| RR3 | Pool cars provided and mileage paid, relationship unstated | unknown | — | "pool cars are provided" and "plus mileage" | Mileage may apply to your own car where no pool car is free | `[inferred]` from two terms stated side by side | When is mileage paid, and how are pool cars booked? | unresolved |
| RR4 | Hours, weekends and on-call not stated | unknown | — | "end-of-life visits" | End-of-life care may need evening or weekend visits | `[inferred]` from the visit types listed against silence on hours | What are the working hours, and what weekend or on-call rota applies? | unresolved |
| RR5 | Pay stated openly | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent pay, with a range that brackets the survey's middle spread | `[grounded]` JD; `[generic]` survey band | Where in the range do new starters from the acute sector usually sit? | noted |
| RR6 | Hiring manager has spoken on Doppler training for staff new to community work | positive_signal | — | "Doppler training for staff new to community work" (speaker page) | Training may be on offer, which would make your missing Doppler skill a normal starting point | `[grounded]` speaker page; `[inferred]` that this means training here | Is Doppler training provided on appointment, and how soon? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the JD's offer of an informal chat with Rhiannon Mabbott, and ask RR1–RR4 and RR6 verbatim | Closes the open items before you spend time on the application | `[grounded]` JD offer | pending your approval |
| E1 | Move the discharge-to-assess secondment up and state it as it is: "Seconded 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | Surfaces R5, which the CV currently states as a secondment without leading with it. It claims no caseload and no district nursing | `[grounded]` CV | pending your approval |
| E2 | Keep wound care (pressure ulcers, surgical wounds), catheter care and insulin as named items | R6a, R7a and R9a are `direct`; leave them as you have them | `[grounded]` CV | pending your approval |
| W1 | In the supporting statement, say plainly that you have not held your own caseload and have not done Doppler assessment, and that you would want training | Honest and checkable; the gap is closed by training, not by wording | `[grounded]` R10, R11; `[inferred]` that candour reads well to this hiring manager | pending your approval |
| A2 | Add leg-ulcer, end-of-life and records experience only if your answers to G1–G3 support it | Wording cannot create it | `[grounded]` gap queue | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the NMC registration, the licence and every CV claim, stated and not checked. The first two are for you to check against your NMC register entry and your driving record. Stage: evaluating, assumed. Your National Insurance number is not needed for this and I have not used it; an application form should not need it before an offer.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page at that address. Moved: the employer is established as described; the posting itself is unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "community staff nurse district nurse Band 5 Band 6 role scope salary Calderdale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the pay calibration; scope was not covered |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the scope read, RR6 and the positioning in W1 |

I can write up the evidence and plan as a `tuesday-dossier.md` if you want one.

## Upgrade menu

- Answers to G2, G3 and G1 → R6b, R8 and R4 move toward `direct`, and the decision likely simplifies to `go`.
- A competency record, training certificate or redacted care plan → raises the matching rows toward `high`.
- The recruiter's answers on RR1–RR4 → the open register entries close.
- A deeper research pass on Calderbrook (leadership changes, staff and patient reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G2 — Have you applied compression bandaging, assessed a venous leg ulcer, or worked in or alongside a leg-ulcer clinic? What did you personally do, and is there a training record?

G3 — Have you cared for dying patients, or arranged a fast-track discharge home to die? What was your part, and who else was involved?

G1 — Which electronic record system did you use on the ward and in the discharge team, and what did you write into it (assessments, care plans, discharge notes)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.