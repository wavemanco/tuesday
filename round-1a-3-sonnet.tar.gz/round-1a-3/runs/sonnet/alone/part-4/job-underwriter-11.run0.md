I'll read the skill's reference files before building the assessment.
Checking whether both employers exist and what these roles typically pay, then I'll write up the assessment.
## Decision snapshot

**Role 1, Duinvaart Cold Chain: yes, it's worth your time. Status: `conditional_go`.**

**Role 2, Kroonhaven Foods: no, it isn't. R8, R9 and R12, all `must_have` rows, are `absent`, and R13 is only `adjacent`. Status: `no_go`.**

**Role 1 fit ledger.**

- `hard_gate` — unclear: R7 (Hybrid, three days in Rotterdam)
- `must_have` — direct: R1, R2, R3, R4a · unclear: R4b (Temperature compliance)
- `important` — adjacent: R5 (Route changes with depot managers)
- `preferred` — adjacent: R6 (Dutch)

R4b — no stated exposure to temperature compliance; R5 — your route-performance review is close, its limit named.

- **Opportunity ledger.** Concrete deliverables are named (RR3), but the employer could not be checked (RR1) and the pay is withheld (RR2).
- **Hard gates:** none failed; unconfirmed: R7 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies on its own careers site (RR1); (2) the three-day Rotterdam commute works for you (R7); (3) temperature compliance is described as work you haven't done yet, never implied (R4b).

**Role 2 fit ledger.**

- `hard_gate` — unclear: R14 (On-site in Utrecht)
- `must_have` — adjacent: R13 (Fluent Dutch) · unclear: R11 (Advanced Excel) · absent: R8 (3+ years planning in FMCG), R9 (Own the 13-week supply plan), R12 (SAP IBP or similar)
- `important` — adjacent: R10 (Run weekly S&OP meeting)

R8, R9, R12 — no planning work to point to, in your own words; R10 — a different kind of meeting from the one you ran.

- **Opportunity ledger.** The scope is specific (RR6). The employer could not be checked (RR4) and the pay is withheld (RR5).
- **Hard gates:** none failed; unconfirmed: R14 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** planning work you haven't mentioned that covers R8, R9 and R12, or Dutch you'd call fluent. Wording can't close these.

## Role reality

| Element | Role 1 | Role 2 | Provenance |
|---|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, refrigerated fleet | Kroonhaven Foods, Utrecht, chilled ready-meals | `[grounded]` JD headers; existence not checked |
| Mandate | Track on-time delivery and temperature compliance, weekly Power BI dashboards, route changes with depot managers | Own the 13-week supply plan, balance capacity against forecast, run weekly S&OP | `[grounded]` JDs |
| Working pattern | Hybrid, three days in Rotterdam | On-site in Utrecht | `[grounded]` JDs |
| Pay | Withheld; your floor not given | Withheld; your floor not given | `[grounded]` JDs; no band, because the sweep did not run |
| First-year outcomes | Not stated | Not stated | `[grounded]` JDs silent |
| Scope read | An analyst post that serves the depots | A planning post that owns the plan end to end | `[inferred]` from the verbs "track, build, work with" against "own, balance, run" |
| Market calibration | Not established | Not established | `[grounded]` sweep unavailable (see Evidence status) |
| Unknowns | Team size, reporting line, who owns route decisions | Team size, planning-system licence, forecast ownership | `[grounded]` JDs silent |
| Contradictions | None between the two texts you pasted | None | `[grounded]` pasted JDs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Role 1: 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; stated, nothing inspected yet | `[grounded]` your background | none |
| R2 | Role 1: Strong SQL | must_have | direct | medium | none | "SQL ... daily"; no artifact seen | `[grounded]` your background | none |
| R3 | Role 1: Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use. Whether you built it is not stated | `[grounded]` your background | a sanitized screenshot would raise it to `high` |
| R4a | Role 1: Track on-time delivery | must_have | direct | medium | none | The on-time dashboard and the weekly review cover this | `[grounded]` your background | none |
| R4b | Role 1: Track temperature compliance on a refrigerated fleet | must_have | unclear | low | discovery | Nothing you've told me touches temperature or cold-chain compliance. It may exist unmentioned | `[grounded]` your background silent | see G1 |
| R5 | Role 1: Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and the depot managers use your dashboard. Limit: you haven't said the review produced route changes | `[grounded]` your background; `[inferred]` adjacency | see G2 |
| R6 | Role 1: Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, which is real but not fluent | `[grounded]` your background | state it as conversational |
| R7 | Role 1: Hybrid, three days a week in Rotterdam (term) | hard_gate | unclear | none | hard_gate | The JD fixes the term. Your location constraints were not given, and you worked in Amsterdam | `[grounded]` JD; your constraints unknown | the R7 question below |
| R8 | Role 2: 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning. Years of experience is not a gate, but it's the requirement most likely to be screened literally | `[grounded]` your statement; `[generic]` screening pattern | see G3 |
| R9 | Role 2: Own the 13-week supply plan against forecast | must_have | absent | none | capability | No planning ownership to point to | `[grounded]` your statement | see G3 |
| R10 | Role 2: Run the weekly S&OP meeting | important | adjacent | low | transferability | You ran a weekly route-performance review. Limit: that reviews past performance, while S&OP sets forward supply against demand, so it's a different kind of meeting | `[grounded]` your background; `[generic]` what S&OP is | see G4 |
| R11 | Role 2: Advanced Excel | must_have | unclear | low | discovery | Excel isn't mentioned; you named SQL and Power BI | `[grounded]` your background silent | see G5 |
| R12 | Role 2: SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system use, per your statement | `[grounded]` your statement | see G3 |
| R13 | Role 2: Fluent Dutch | must_have | adjacent | medium | transferability | Conversational against fluent is a gap of degree that wording can't close | `[grounded]` your background | see G4 |
| R14 | Role 2: On-site in Utrecht (term) | hard_gate | unclear | none | hard_gate | The JD fixes the term; your constraints were not given | `[grounded]` JD; your constraints unknown | none while the role is `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R4b, must_have) | discovery | Nothing on temperature or cold-chain monitoring | A `must_have` and the one place Role 1 is specific to refrigeration | Tracking cold-chain or temperature-controlled parcels, or other service-level compliance you reported on; alerts or exception reports tied to a threshold | A sanitized compliance report or an exception-report screenshot | `[grounded]` your background silent; `[inferred]` that this is Role 1's distinguishing requirement |
| G2 | Route changes with depot managers (R5, important) | discovery | A weekly route-performance review, with no stated outcome | Separates "reported on routes" from "changed routes", and the JD names route changes | A review that led to a rerouted run, a changed depot cut-off, or a depot manager acting on your numbers | A review agenda or action log, sanitized | `[grounded]` your background |
| G3 | Planning ownership and tools (R8, R9, R12, must_have) | capability | No credible direct or adjacent planning evidence, as you've said | Three `must_have` rows, which is why Role 2 is `no_go` | Closure takes time, for example a planning role or a SAP IBP course, so it doesn't make this application stronger | None applicable now | `[grounded]` your statement; `[inferred]` closure path |
| G4 | S&OP meeting and Dutch fluency (R10, R13, R6, transferability) | transferability | A weekly review, and conversational Dutch | R10 and R13 count against Role 2; R6 is a small plus for Role 1 | Dutch-language work meetings; the route review as an input to someone else's planning | A dated example of a Dutch-language meeting you ran or presented in | `[grounded]` your background; `[generic]` that these roles probe both |
| G5 | Advanced Excel (R11, must_have) | discovery | Not mentioned | Can't move Role 2's status given R8, R9 and R12 | Models, pivot-driven reporting, forecasting sheets | A sanitized workbook | `[grounded]` your background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (Role 1) | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this firm | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld (Role 1) | unknown | — | no figure given | The pay may sit above or below your floor, which I don't have | `[inferred]` from silence against an unknown floor | What salary range is budgeted for this post? | unresolved |
| RR3 | Concrete deliverables named: on-time and temperature tracking, weekly Power BI dashboards (Role 1) | positive_signal | — | "build weekly dashboards in Power BI" | The work is defined and measurable | `[grounded]` JD | Who owns the temperature-compliance data today, and how does it reach you? | noted |
| RR4 | Employer not established from attributable sources (Role 2) | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The same three reasons as RR1, none ranked as likely | `[generic]` pattern, not a claim about this firm | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Salary withheld (Role 2) | unknown | — | no figure given | As RR2 | `[inferred]` from silence | What salary range is budgeted for this post? | unresolved |
| RR6 | Specific scope named: 13-week plan, weekly S&OP (Role 2) | positive_signal | — | "Own the 13-week supply plan" | The mandate is defined | `[grounded]` JD | What decision rights does the planner hold over production capacity? | noted |

RR1 and RR4 cap a `go` at `conditional_go` until the posting is verified. Clearing them means the role appears on the employer's own careers site, or the recruiter writes from the employer's own domain.

## Application plan

**Role 1 only. Role 2 has no plan, because the decision is `no_go`.** Every row is proposed, none applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: "Operations analyst, parcel carrier, Amsterdam, 4 years: SQL and Power BI daily, including the on-time delivery dashboard used by depot managers." | R1, R2, R3 — every clause is your wording, and "used by" is kept because authorship isn't stated | `[grounded]` your background | pending your approval |
| E2 | `resume_edits_pending_approval`: "Ran the weekly route-performance review." | R5 — your words, with no claim that routes changed | `[grounded]` your background | pending your approval |
| E3 | `resume_edits_pending_approval`: "Dutch: conversational." | R6 — it's a "plus", so the honest level costs little | `[grounded]` your background | pending your approval |
| A1 | Confirm the posting on Duinvaart's own careers site before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | In the application's opening lines, lead with the on-time dashboard and the weekly review. Say nothing about temperature compliance unless G1 produces something | R3, R4a, R4b | `[inferred]` from the map | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is stated and nothing has been inspected.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | The searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht" were both refused. It would have moved RR1 and RR4 and the organization row of role reality |
| 2. Role-family sweep | unavailable | The searches "operations analyst logistics Rotterdam salary Netherlands" and "supply planner FMCG Utrecht salary Netherlands SAP IBP" were both refused. It would have moved the market-calibration row and RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given in either posting |

## Dossier offer

I can write this up as `tuesday-dossier.md` if you want a file to carry forward. Say so and I will.

## Upgrade menu

- Search permission, which I can use for company checks: closes RR1 and RR4, and sets pay against a market band for RR2 and RR5.
- A sanitized dashboard screenshot: R3 to `high`.
- A sanitized compliance or exception report: R4b moves from `unclear`.
- A review agenda or action log showing route changes: R5 moves toward `direct`.
- Your salary floor and commute limits: R7 and R14 resolve, and RR2 and RR5 get a threshold.
- The hiring manager's name for either role: scope read and positioning.

## Questions

1. **R7:** Is three days a week in Rotterdam workable for you from where you live, and is there any commute or schedule limit I should treat as a dealbreaker?
2. **G1:** Have you tracked or reported on anything with a temperature, cold-chain or similar threshold, even as a small part of your job?
3. **G2:** Did your weekly route-performance review ever lead to a route or depot change, and what was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.