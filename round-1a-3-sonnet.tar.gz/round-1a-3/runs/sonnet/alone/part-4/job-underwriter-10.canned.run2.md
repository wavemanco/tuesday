Reading the underwriting method is done. Next I'm checking whether Fernquay shows up on the public web, then I'll write the assessment.
# Job Underwriting Assessment: Product Designer at Fernquay

## Decision snapshot

**Yes, worth going on with, and the employer's own pages match the posting (RR1): `conditional_go`. The condition that matters most is whether the salary meets your floor (R2).**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7 · adjacent: R8 (Own the booking flow as the first designer)
- `important` — direct: R10 · adjacent: R9 (Research calls with school owners)

R8 — a credible bridge, its limit named: you have never been the only designer; R9 — usability sessions carry over, the school-owner setting is untested; R2 — waiting on your pay floor.

**Opportunity ledger.** Consistent and transparent: the posting, the careers page and the about page agree, and the pay is stated (RR1). Open: equity terms (RR2), runway at a six-person company (RR3) and what design practice exists today (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the base salary meets your floor, R2; (2) equity terms are clarified, RR2; (3) the role's funding and runway are confirmed, RR3; (4) R8 is framed as adjacent, never as sole-designer experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, "funded by its customers" | `[grounded]` About page fetched |
| Product | Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` About page |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD; careers page also says "our first design hire" |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` JD and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity in the JD; the careers page says "plus equity" with no range | `[grounded]` JD and careers page |
| Hiring-side people | Ronan Kehoe is listed as co-founder and CEO, previously a product lead for five years at a Galway travel-software company. Saoirse is named as co-founder on the About page, and your message calls her CTO | `[grounded]` About page, public profile snippet |
| Scope read | An ordinary-sized remit for a first designer in a small product team: one flow, research and engineer pairing. Your checkout work sits in the same domain as Ronan's earlier travel-software work | `[inferred]` from the mandate list and his stated career |
| Market calibration | The posted band sits inside the range reported for product designers with 3–5 years in Ireland (median €57,000, interquartile €51,500–€62,000). This is a market band, not this employer's offer, and I found no market figure for equity at this size | `[generic]` Tillerby 2026 Ireland Design Salary Report snippet; `[grounded]` JD for the posted figure |
| Unknowns | Equity terms; runway; existing design system or research backlog; who reviews design work | — |
| Contradictions | None between the JD and the careers page. Both give the same hybrid pattern and pay, and the careers page asks for "one real project" | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year, so the location term is met. You haven't said whether two office days suit you, and that is why confidence is `medium` | `[grounded]` your message | Confirm two office days suit you |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posted terms are known but your floor is not, so whether they meet it can't be settled. The band is a normal one for 3–5 years (see Market calibration) | `[grounded]` JD; `[generic]` band | Give your minimum base (question G3) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. This is self-report, so `medium` | `[grounded]` your background | A portfolio link or CV would raise it |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. No Figma file or portfolio has been inspected | `[grounded]` your background | A shareable file or case study would raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. This is a direct match to "run your own user research" | `[grounded]` your background | Same artifact as R4 |
| R6 | Design the booking flow | must_have | direct | medium | none | You redesigned the checkout flow at a travel-booking company, in the same domain | `[grounded]` your background | Same artifact as R4 |
| R7 | Work directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. This role has two | `[grounded]` your background; `[grounded]` JD | None |
| R8 | Own the booking flow end to end as the first designer | must_have | adjacent | medium | transferability | Carries over: you owned checkout design inside a squad. Limit: you have never been the only designer, so you haven't set direction without design peers or review. Strengthener: examples where you made design calls without design review | `[grounded]` your statement that you've never been the only designer; `[generic]` that first-designer roles carry decision-making without peers | See G1 |
| R9 | Research calls with school owners | important | adjacent | medium | transferability | Carries over: running recurring usability sessions. Limit: I don't know who your participants were, and the JD's participants are small-business owners. Strengthener: examples of customer or business-user interviews | `[grounded]` your background; `[grounded]` JD | See G2 |
| R10 | One real project to show, messy welcome | important | direct | medium | none | Ronan's message says they liked your checkout case study. I haven't seen it, so this rests on your message and theirs | `[grounded]` the WhatsApp message and the careers page | Check the case study doesn't expose your employer's confidential material |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer ownership (R8, must_have) | transferability | Checkout design inside a squad; no stretch without design peers | This is the likeliest probe for a first-designer post | Design decisions you made without a lead's sign-off; setting a pattern or small design system others adopted; critique you sought from engineers or product; any freelance or side project run alone | A case-study excerpt, a decision log, a design-system page | `[grounded]` your statement; `[generic]` that this is the usual probe for a first designer |
| G2 | Owner-style research calls (R9, important) | transferability | Monthly usability sessions; participants unknown | The JD's calls are with business owners, not consumers | Interviews with agents, suppliers or other business users; sessions that changed a roadmap | A research summary, a discussion guide | `[grounded]` your background and JD |
| G3 | Pay floor (R2, hard_gate) | hard_gate | The band is posted; your minimum is not known | A gate can't be marked met without it | A figure you'd need, and your view on equity versus salary | None needed | `[grounded]` JD; your floor not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting, careers page and about page agree; pay is stated | positive_signal | — | "€52,000–€60,000 plus equity" | The role is real and openly described | `[grounded]` three pages fetched | Is this the post's full pay package, and does the equity range in the JD apply? | noted |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, strike price, share class and dilution terms may differ from what a range suggests | `[generic]` equity terms vary at small companies | What are the vesting schedule, any cliff, the strike price and the share class? | unresolved |
| RR3 | Runway not stated at a customer-funded company | unknown | — | "funded by its customers" | A six-person firm funded by revenue ties a new salary to customer income | `[generic]` pattern for self-funded small companies | How long is the runway at current revenue, and is this role in the funded plan? | unresolved |
| RR4 | First designer with no stated design practice | unknown | — | "You would be our first designer" | No design system, research backlog or design reviewer may exist yet | `[inferred]` from "first designer" and the JD's silence on existing design assets | What design assets and research exist today, and who reviews your work? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the calendar invite arrived by email from a Fernquay address (the careers page uses jobs@fernquay.example) and names Ronan and Saoirse. Scheduling by WhatsApp for a video call is routine | The invite matches the company's own site | `[generic]` routine scheduling; `[grounded]` careers page address | pending your approval |
| E1 | Lead with the checkout redesign and say plainly it was done inside a squad of four engineers. Add no metrics or titles beyond what you've told me | See R6, R7, R10 | `[grounded]` your background | pending your approval |
| E2 | Name the first-designer step up in your own words: "I've always had design peers and have not been the only designer", then say how you'd work without them | See R8 | `[grounded]` your statement | pending your approval |
| Q1 | Ask the register's verification questions (RR2, RR3, RR4) verbatim on the call, and ask Ronan RR1's pay question | The register doubles as call preparation | `[grounded]` register | pending your approval |

Every row is proposed, and none is applied until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers Product Designer Galway"; fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality: organization and contradictions rows; the employer-not-established entry is not triggered |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), a professional-role snippet only. Moved the hiring-side people and scope read rows |

## Closing

I can write this up as `tuesday-dossier.md` if you want a file to keep, and say the word and I'll do that.

**Upgrade menu**

- Your minimum base salary and any other must-haves (office days, start date) → R2 moves to met or failed, and the decision likely simplifies to `go` or `no_go`.
- A portfolio link or Figma file → R3 to R6 can rise to `high`, and the confidentiality check on R10 is done.
- An answer to G1 or G2 → R8 or R9 bridges narrow.
- The call's answers on equity, runway and design assets → RR2, RR3 and RR4 close.
- A deeper company check (funding, hiring history, public reports; up to 5 more searches and 2 more fetches) → the register's runway and risk rows get sourced. Say the word and it runs.
- Rehearsing for the video call is the mock-interview skill's job, not this one's.

**Questions**

G3 — What is the minimum base salary you'd accept, and is there anything else (office days, start date) I should check this against?

G1 — In your four years, when did you make a significant design call without a design lead or peer reviewing it? What did you own, and what happened?

G2 — Who took part in your monthly usability sessions (consumers, travel agents, business users), and did the findings change anything?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.