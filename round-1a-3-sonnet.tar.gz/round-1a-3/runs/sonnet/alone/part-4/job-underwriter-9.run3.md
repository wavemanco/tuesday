**Yes, this is normal.** The rule you were taught is about handing these over *before* a job exists, or to someone you haven't verified. Your case is different on both counts.

**Why it looks routine**
- You've had two in-person interviews at their office and a written offer with a named manager, salary and terms.
- The details are requested **after you accept**, through a portal, not up front.
- Each item has an ordinary purpose:
  - **Bank details:** to pay your salary.
  - **PPS number:** the employer needs it to register you with Revenue and run PAYE, PRSI and USC. You'll know this from your own payroll work.
  - **Passport:** a right-to-work check. They ask to see the original on day one, which is standard.
- Nothing in the offer asks you to pay anything, buy equipment or deposit a cheque, which are the real warning signs.

**Checks before you click the portal link**
1. **Confirm the link's source.** When it arrives, check that it comes from a `marrowgatehousing.ie` address and that the portal URL is on, or clearly tied to, their domain. If you're unsure, phone or email the person you interviewed with, using contact details from the company's own website. Don't use a number or address from the link email itself.
2. **Check that the offer email's domain matches** the one used to arrange your interviews.
3. **Ask how they store the passport scan.** A scan is common. As far as I know, for an Irish or EU/EEA citizen the employer isn't obliged to keep a copy. Asking how it's stored and who can see it is a reasonable data-protection question, and a good employer will answer easily.
4. **Don't send any of this by plain email.** Use the portal, or hand the passport over in person.

**Other points before you accept**
- Ask for a written contract or statement of terms, including probation, notice period and pension scheme.
- You said you've never done pension changes yourself. That's a gap against their ad, but not a hard requirement. It's worth asking Declan what the pension setup is and what support you'd get, rather than assuming.
- €40,000 sits inside their stated €38–42k band. You have the 2+ years of payroll and the qualification, so you meet the stated requirements.

You can accept within the five working days without giving anything sensitive first. If something about the portal link or sender feels off when it arrives, stop and verify through the company's own website contacts before entering anything.

I can also do a fuller review of the role against your background, including the pension gap and what to ask before signing, if that would help.