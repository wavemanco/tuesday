I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Your question — are either worth your time? First (Duinvaart, Operations Analyst): yes, apply, on conditions. Status: `conditional_go`. Second (Kroonhaven, Supply Planner): no, not as written. R10 and R12, both `must_have`, are `absent`. Status: `no_go`.**

**First: Duinvaart Cold Chain, Operations Analyst**

*Fit ledger.*

- `hard_gate` — unclear: R1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5 · adjacent: R7 (Work with depot managers on route changes) · unclear: R6 (Temperature compliance across the refrigerated fleet)
- `preferred` — adjacent: R8 (Dutch a plus)

R6 — cold-chain temperature work not evidenced yet; R7 — your involvement in route changes unconfirmed.

*Opportunity ledger.* The posting's tasks are specific and match its title (RR3). The employer could not be checked because research was unavailable (RR1), and the pay is not stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting appears on Duinvaart's own careers page, so RR1 clears; (2) the commute to Rotterdam three days a week works for you, so R1 clears; (3) you can say truthfully what temperature-sensitive or time-critical work you tracked at the carrier, so R6 is evidenced. If R6 has no basis, it is carried as a named gap and the application still stands.

**Second: Kroonhaven Foods, Supply Planner**

*Fit ledger.*

- `hard_gate` — unclear: R9 (On-site in Utrecht)
- `must_have` — adjacent: R13 (Fluent Dutch) · unclear: R11 (Advanced Excel) · absent: R10 (3+ years of supply or demand planning in FMCG), R12 (SAP IBP or a similar planning system)
- `important` — adjacent: R14 (Run the weekly S&OP meeting)

R10, R12 — no planning experience, by your own statement; R13 — conversational Dutch against a fluent bar.

*Opportunity ledger.* The scope is concrete (RR6). The employer could not be checked (RR4), and the pay is not stated (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** R10 and R12 would have to be `direct` or `adjacent`. That would need planning-system and planning-ownership experience you have told me you don't have. A reduced-requirements version of this role, or a planning-analyst role at the same employer, is a different posting that I'd assess separately.

## Role reality

**First: Duinvaart Cold Chain**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, operating a refrigerated fleet | `[grounded]` JD header; existence not verified (RR1) |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| First-90-days or first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | An individual analytics post: no reports, team or budget are mentioned | `[inferred]` from the JD naming none |
| Unknowns | Pay; how many depots; who sets route changes; whether temperature data is already collected cleanly | `[grounded]` JD silent on each |
| Contradictions | None inside the pasted text; no second source was available to compare | `[grounded]` one source only |

**Second: Kroonhaven Foods**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, with a chilled ready-meals range | `[grounded]` JD header; existence not verified (RR4) |
| Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| First-90-days or first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A single-owner planning post for one range; no team is mentioned | `[inferred]` from the JD naming none |
| Unknowns | Pay; whether S&OP is conducted in Dutch; planning-system rollout state | `[grounded]` JD silent; no Dutch-language statement for meetings |
| Contradictions | None inside the pasted text | `[grounded]` one source only |

No market-calibration line is given for either role: the role-family sweeps did not run (see Evidence status).

## Evidence map

Your background is typed prose, so it carries CV standing. That caps your claims at `medium` until something inspectable exists.

**First: Duinvaart Cold Chain**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no location or commute constraint, so the term is not settled either way. Confidence is `none` because there is no stated constraint to grade | `[grounded]` JD term; your constraints not given | Ask whether three Rotterdam days work for you (question below) |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier in Amsterdam; stated by you, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | "SQL daily" over 4 years; "strong" is not measured by that statement | `[grounded]` your background | A sanitized query sample would raise to `high` |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use | `[grounded]` your background | A sanitized dashboard screenshot would raise to `high` |
| R5 | Track on-time delivery | important | direct | medium | none | The dashboard you work on is an on-time delivery dashboard. Whether you built it or maintained it is not stated, so it is carried at the lower reading (worked on it) | `[grounded]` your background | Confirm your role on it (see E1) |
| R6 | Track temperature compliance across the refrigerated fleet | important | unclear | low | discovery | A parcel carrier may or may not handle temperature-sensitive shipments, and you did not mention any. The only link is indirect context | `[grounded]` your background silent on temperature | Question G2 below |
| R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether the review led to route changes you worked on is unstated, so the lower reading is taken | `[grounded]` your background; limit: route changes themselves unconfirmed | Question G3 below |
| R8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, stated by you. It supports "a plus" but not working fluency, and must be described that way | `[grounded]` your statement | State it as "conversational" wherever it appears |

**Second: Kroonhaven Foods**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R9 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or commute constraint was given | `[grounded]` JD term; your constraints not given | Same commute question as R1 |
| R10 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, and a parcel carrier is not FMCG. Per the gap rules this is classed by your own confirmed statement, not by a CV gap. Years of experience are not a gate, so this is a must-have fit problem | `[grounded]` your statement | Closure path in G4 |
| R11 | Advanced Excel | must_have | unclear | low | discovery | Excel was not mentioned; SQL and Power BI daily is only indirect context | `[grounded]` your background silent on Excel | Would not move the status; no question spent on it |
| R12 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system appears in your background; Power BI is a reporting tool, not a planning tool | `[grounded]` your background | Closure path in G4 |
| R13 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch, stated by you, against a bar of fluent. A language bar is a skill requirement, not a legal or credential gate, so it sits in the fit tiers. Likely to be screened literally | `[grounded]` your statement; `[generic]` that stated language bars are usually screened as written | State it as "conversational" wherever it appears |
| R14 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. That is a performance review, a different kind of meeting from one balancing supply, capacity and forecast, so only the meeting discipline carries over | `[grounded]` your statement; limit named | Strengthener: none available without planning evidence |

## Gap recovery queue

No questions sit here; each implied question is asked in the closing block under its row id.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Commute and office days (R1, R9) | hard_gate | Both posts require office days (three in Rotterdam; on-site in Utrecht) and your constraints were not given | A term, not a skill; unsettled, it could make either post unworkable for you | Not applicable; this is a term | Your own statement | `[grounded]` both JDs; your constraints not given |
| G2 | Temperature compliance (R6, important) | discovery | A parcel carrier background with no temperature or time-critical work mentioned | The role's second stated task; an honest bridge changes how R6 reads and how the application leads | Tracking chilled or temperature-sensitive parcels, pharma or food shipments, delivery-window breaches, or any compliance threshold you monitored on a dashboard | A sanitized report or dashboard screenshot | `[grounded]` background silent; `[inferred]` that a bridge, if it exists, would be through time-critical or sensitive shipments |
| G3 | Route changes with depot managers (R7, important) | discovery | A weekly route-performance review you ran, and a dashboard depot managers use | Whether your review drove decisions about routes decides if this is `direct` or stays `adjacent` | Recommendations from the review that depots adopted; a route you flagged as underperforming; a change a depot manager made from your numbers | Meeting notes, a review pack or a sanitized slide | `[grounded]` your statement; `[inferred]` that the review fed route decisions |
| G4 | Planning experience and systems (R10, R12, must_have) | capability | No planning ownership, no planning system | The role's core; there is no credible direct or adjacent evidence | None qualifies on current evidence | An S&OP pack you contributed to, a forecast model you built or audited, a planning-tool course | `[grounded]` your statement; `[generic]` that supply-chain analyst or planning-analyst posts commonly sit between analytics and planning |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart Cold Chain not established from attributable sources, because research did not run | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for employers of this kind, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated for the Duinvaart post | unknown | — | "(no salary stated in the pasted posting)" | The figure may sit in the full listing, or be withheld; I have no market band to compare it with because the sweep did not run | `[inferred]` from the pasted text's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Duinvaart tasks and requirements are specific and consistent with the title | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet, build weekly dashboards in Power BI" | The scope reads as a defined analyst remit | `[grounded]` JD | Which depots would this role cover first? | noted |
| RR4 | Kroonhaven Foods not established from attributable sources, because research did not run | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for employers of this kind, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Pay not stated for the Kroonhaven post | unknown | — | "(no salary stated in the pasted posting)" | The figure may sit in the full listing, or be withheld; no market band compared | `[inferred]` from the pasted text's silence | What salary range is budgeted for this post? | unresolved |
| RR6 | Kroonhaven scope is concrete: a 13-week plan and a weekly S&OP | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The post has a defined remit and clear accountability | `[grounded]` JD | Who owns forecast accuracy: this role or a separate demand planner? | noted |

## Application plan

Everything in this table is proposed, nothing applied. The resume line and the Dutch wording are `resume_edits_pending_approval`; every other row waits on your approval too.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Proposed resume line for Duinvaart: "Operations analyst, parcel carrier, Amsterdam (4 years): SQL and Power BI daily, including the on-time delivery dashboard used by depot managers; ran the weekly route-performance review." Each clause traces to your own sentences; "worked on" is not upgraded to "built" because you did not say you built it | R2, R3, R4, R5, R7 | `[grounded]` your background | pending your approval |
| E2 | Wherever Dutch appears, say "conversational Dutch" and nothing stronger | R8, R13 | `[grounded]` your statement | pending your approval |
| A1 | Before investing in the Duinvaart application, find the role on the company's own careers page | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | If G2 has a true answer, add one sentence about it; if not, apply on R2–R5 and let R6 stand as a named gap | R6 | `[grounded]` R6 row | pending your approval |
| A3 | Ask RR2 verbatim at the first call | RR2 | `[grounded]` register | pending your approval |
| B1 | Skip Kroonhaven as written and look instead for analyst posts that sit next to planning, such as supply-chain or planning analyst roles at food employers | R10, R12 | `[generic]` role-family pattern, not a claim about Kroonhaven | pending your approval |
| B2 | If you apply to Kroonhaven anyway, ask RR4, RR5 and RR6 verbatim and describe the S&OP-adjacent work only as a weekly performance review | R14, register | `[grounded]` rows named | pending your approval |

Offer beyond this assessment: a short list of target role titles that reuse your analyst evidence, built only if you want it, because both postings show how far your analyst background reaches before it meets planning.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam refrigerated transport" and "Kroonhaven Foods Utrecht chilled ready meals"; both calls were refused for lack of permission. Would have moved RR1 and RR4 and the contradictions rows |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Netherlands salary Rotterdam" and "supply planner FMCG Netherlands salary SAP IBP"; both refused. Would have moved the market calibration and the pay entries RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission for web search → targets 1 and 2 run: it checks whether Duinvaart and Kroonhaven exist as described and whether the postings are live (RR1, RR4), and sets a pay band against both roles.
- Your location or commute limit, plus any pay floor → R1 and R9 settle, and RR2 and RR5 can be set against the floor.
- A sanitized dashboard screenshot or query sample → R3 and R4 from `medium` toward `high`.
- Answers to G2 and G3 → R6 and R7 move from `unclear` or `adjacent` toward `direct`, or stay as named gaps.
- A hiring manager's name for either post → scope read and which story the application leads with.

I can write all of this as `tuesday-dossier.md` if you'd like to keep it.

Questions:

1. **G1 (R1, R9)** — Is three office days a week in Rotterdam workable from where you live, and is there a pay floor or any other limit I should check these roles against?
2. **G2 (R6)** — At the parcel carrier, did you track any temperature-sensitive or time-critical shipments, and what part of that was yours?
3. **G3 (R7)** — Did your weekly route-performance review lead to route changes, and what did you own versus the depot managers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.