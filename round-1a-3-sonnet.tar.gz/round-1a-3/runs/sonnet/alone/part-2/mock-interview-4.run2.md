I'll read the reference files the skill requires before building the pack.
Your prep pack is saved and the full message follows. Quick status: the pack is finished and I'm giving you the hand-off now.

Your prep pack is saved as `quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the 45-minute hiring-manager conversation, using your dossier as the evidence base. It has 23 questions across seven interviewer styles, a fit snapshot, reverse questions drawn from the dossier's open risks, and a list of claims the pack won't coach.

- **Start with A1.** It is the dossier's own objection, "never held the PM title or owned a roadmap," and it gets the deepest rehearsal. The structure is concede, then bridge with its limit named, then a ramp plan.
- **Research was refused.** All three Quartzline searches were denied, so the pack has no values, strategy or loop facts beyond the dossier. The two Quartzline-specific questions (A4, E3) are labeled generic as a result. The Sources section records this.
- **R2 isn't classified in the dossier.** R2 ("Shipped API or platform products") is a must-have but has no weak-area entry. I graded it myself as a discovery gap (F3, A3) and labeled it inferred, so treat it as a lead to check.
- **The dossier is dated 2026-08-14.** If the posting or your evidence has changed since, tell me and I'll regenerate the affected rows.

Say the word and I'll play the Skeptic live on A1, with follow-ups that react to what you actually say.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

- **Role:** Product Manager, Platform APIs, Quartzline
- **Interviewer:** not named. **Relationship and format:** the hiring manager, one 45-minute conversation on Thursday (your words)
- **Built on:** that round type, the dossier you carried (`tuesday-dossier.md`, version 1.1) and relationship priors. Quartzline research was refused in this run, so every Quartzline fact below comes from the dossier's role profile and nothing is claimed about its strategy, values or process.
- **Highest-ROI prep:** A1. The dossier named that objection from evidence you confirmed, and the pack gives it the deepest rehearsal.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The role's stated requirements and responsibilities, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem from the role, solved aloud |

An **answer slot** is an instruction for the interview, not a question for you now. It says what an interviewer is likely to probe, then gives two honest branches: say how it went, in your own words, or say plainly it did not happen that way or was not yours, and return to what your own sentences carry.

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence cells hold your confirmed sentences from the dossier's `verified_candidate_evidence` and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's strategy is `bridge`: positioned as adjacent work, never as product-management experience. Your material shows integration delivery and a playbook, not a product-management role, and carries no tenure, so no number of years is claimed. Words: lead with the integrations at their own scope, then stop and let the interviewer draw the inference. Plain acknowledgment, sourced to `prohibited_claims` ("Having held a product manager title or role"): "I haven't held a product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area ("Owning a roadmap and prioritization authority (R1 sub-claim)") and lists `prohibited_claims` ("Having owned a product roadmap"). Words: "I haven't owned a roadmap." Then a ramp plan said as a plan and never as a past: how roadmap decisions split with the two squad leads, and how adoption is measured and its baseline. No bridge and no slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The dossier lists R2 as a high-priority requirement but has no weak-area entry for it, so this grading is the pack's own and a lead to verify. The quote says client integrations, and does not show whether any API or platform product was one you shipped. Answer slot: R2's wording makes a probe on what you shipped likely. If you shipped an API or platform product, say which and what part was yours; if the APIs were the vendor's and your work was the client integrations, or there was no such product, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes name an architecture stage and a playbook; they do not show API docs or schemas. Answer slot: R3's wording makes a probe on the docs and schemas themselves likely. If you wrote, reviewed or worked from either, say which and what part was yours; if the work was elsewhere or there was none, say so plainly and stay with the architecture stage of the integrations you led and the playbook you wrote |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes reach clients and product; they do not show engineering or sales. The sessions line is confirmed with limited inspectable proof, so expect a probe and say plainly what you can show of it. Answer slot: R4 names engineering and sales. If you worked with either on these integrations, say how and what was yours; if not, say so plainly and stay with the clients and product the quotes name |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy is `clarify`, and none of your verified entries speaks to this requirement itself. Answer slot: R5's wording makes a probe on how you define agile delivery likely. If you have delivered inside an agile process, say how and what your part was; if you have not worked that way, say so plainly, and say what you would want to confirm about how Quartzline's two squads run |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quote is sessions feeding client evidence to product, at its own scope, with limited inspectable proof. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: the JD's partner line makes a probe on how the sessions were run likely. If you decided how they were run, say how and what you decided; if the format was set by someone else, or there was no set format, say so plainly and stay with the sessions as quoted |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote lists requirements and go-live as stages of the integrations; it does not show specs written for engineering squads. Answer slot: if any requirements or architecture you wrote were handed to engineering teams, say what you wrote and how delivery ran; if not, say so plainly and stay with the stages as quoted. The slot stays on what was written and handed over, never on who set priority |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | low | [grounded] | discovery | Nothing in your material speaks to measures. Answer slot: if you defined or tracked adoption or usage measures for any integration, say which and what was counted; if you did not, say so plainly and say what you would measure first |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the PM title and roadmap gaps | High. The hiring-manager prior is Case/Strategist plus Skeptic, and the dossier names a likely objection from evidence you confirmed (A1) and three weak areas (F1, F2, F6) | Rehearse A1 until it is boring; concede first, bridge only from your three quoted sentences, then a ramp plan |
| Case/Strategist | Live problems from the real role: roadmap, adoption, two squads | High. Same prior, and the JD's responsibilities (roadmap, partner discovery, specs with two squads, adoption metrics) are all cases | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud; fold the dossier's two unknowns into your clarifying questions |
| Pressure | A time-boxed or interrupted version of the same objection | Medium. No interviewer signal, and the prior does not list it for a hiring manager; raised because A1's objection is easy to deliver under pressure | Hold the facts your quotes carry through two follow-ups, concede specifically, never fold on the core |
| Data-Driven Prober | Line-by-line on "30+" and on adoption metrics | Medium. The JD names adoption metrics as a responsibility and your material holds one figure | Say plainly what you can and cannot say about how the figure was counted |
| Conversational / Rapport Builder | Opening "walk me through the journey", motivation | Medium. A 45-minute conversation opens this way, though no signal says this interviewer is chatty | A 90-second arc built only from your three sentences; treat casual questions as scored |
| Peer Evaluator | The seam between your calls and the squad leads' | Low. The stated relationship is hiring manager; the seam question still arrives in managerial form (B3) | Offer seam principles and ask where the seam is, rather than pretending to know it |
| Values/Behavioral | Stories mapped to published values | Low. Your words describe one conversation, so no values-style round is detected, and no published values were read | Selection scaffolds only (G1, G2) |

Weights rest on your stated round type and relationship priors. With no interviewer profile and no research, nothing adjusts them further.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap" | The highest-ROI rehearsal, and the dossier's own named objection. Order: concede, bridge with its limit, ramp. Concede first in your own plain words: "I haven't held a product manager title and I haven't owned a roadmap." Bridge at the quotes' scope: you led 30+ end-to-end client integrations of the vendor's REST APIs through scoping, requirements, architecture, UAT and go-live, and wrote the internal integration playbook your team uses. Say it as adjacent work and stop; do not say what it proves. If the sessions come up, say you ran quarterly roadmap-input sessions feeding client evidence to product, name that you can show limited proof of them before they probe, and keep it to what reached product, not any roadmap decision. Ramp, as a plan: ask which roadmap decisions are yours and which the squad leads', and how adoption is measured and its baseline. Follow-up one, "a PM has done this for three years": hold the same facts and concede they have done what you have not. Follow-up two, "then why you?": concede you cannot match the years, return to the quotes, stop. Never say the integration work was effectively product management | F1 and F2 are the widest gaps and the dossier named this objection, so some form of it arrives. JD because it scores the stated requirement, and the Question is the dossier's wording, whose negatives each have a `prohibited_claims` source |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `prohibited_claims`: "Having owned a product roadmap" | Name it before they do. The weakest part your material shows is the roadmap itself, and the dossier allows only a plain acknowledgment there: "I haven't owned a roadmap." Then the ramp, said as a plan: in the first weeks you would learn how roadmap decisions split with the two squad leads and how adoption is measured today. No bridge on this one. If asked for a second weakness, F6 is the next: say plainly what you would want to confirm about how the squads work | F2 is a gap the dossier closed to bridging, and a candidate who names it first converts a probe into candor. JD because the stem asks about the listed role |
| A3 | "Tell me about the API or platform work you've done that is closest to shipping a product." | EXP | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-map the quote: the integrations, the 30+, and the stages it names, told in your own words. Answer slot: R2's wording makes a probe on whether any of it was a product you shipped likely. If you shipped an API or platform product, say which and what was yours; if the APIs were the vendor's and your work was the client integrations, or there was no such product, say so plainly and stay with the integrations you led. Say what you did and let them draw the inference | F3 is a must-have the dossier did not classify, so the pack grades it low and labels it `[inferred]`. EXP because it tests what was actually yours; JD secondary |
| A4 | "Why product management, and why this platform?" | CO | [generic] | A motivation answer in your own words, built on two selection criteria: a specific moment in your work that pulled you toward deciding what gets built, and one thing in the JD you can name, such as "Own the roadmap for the partner-facing API platform". If no such moment comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach the role. Nothing about Quartzline beyond the JD's own lines goes in, because research was refused | The skeptic's motivation probe: why change lanes, why here. `[generic]` because it makes no claim about you or about Quartzline; CO because it scores homework, which is thin by necessity this run |
| A5 | "How would you describe your experience with agile delivery?" | JD | [grounded] | Slot-shaped, per the dossier's `clarify` strategy: no verified entry speaks to this itself. R5's wording makes a probe on how you define agile delivery likely. If you have delivered inside an agile process, say how and what your part was; if you have not worked that way, say so plainly, then say what you would want to confirm about how Quartzline's two squads run. It is a preferred requirement; do not let it become the story of the conversation | F6 is a discovery gap and the cheapest to close by answering honestly. JD because R5 is a stated requirement |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd decide what the partner API roadmap should hold in your first quarter. What do you need to know first?" | CASE | [generic] | The scored beat is the clarifying questions. Ask which decisions are yours versus the squad leads', how adoption is measured and its baseline, and what partners are asking for now. Then the objective, how you would segment partners, the approach, metrics and risks, thinking aloud. Challenge one premise politely. It is a plan; claim no roadmap you have run | F2's requirement, asked as a live problem so the answer is a method and not a past. CASE because it asks for structure on the role's own mandate |
| B2 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify first: what counts as adoption, and against what baseline. Segment partners, list hypotheses (onboarding, docs, missing capability, partner priorities) and the evidence that would separate them. You may use the quote's stages (scoping, requirements, architecture, UAT, go-live) as the places you would look, as a map and not as a claim about what went wrong anywhere | F9's requirement made live, using the dossier's open unknown on how adoption is measured. CASE because it asks for diagnosis from a metric |
| B3 | "Two squads, and one partner request that needs both. How do you sequence it?" | CASE | [generic] | Clarify who decides sequencing and who owns each squad's capacity; the dossier shows that authority is unknown, so ask rather than assume. Then impact, dependencies, partner urgency, options and a recommendation with what would change it. Offer seam principles, not a claim about how Quartzline's squads work | F8's responsibility and the unresolved squad-authority risk, in a case form. CASE |
| B4 | "A large partner insists on an endpoint that doesn't fit the platform's direction. What do you do?" | CASE | [generic] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Separate what the partner needs from what they asked for, gather evidence, lay out options, and rehearse a clear no with an alternative: a platform PM's job includes saying no. If you mention your sessions, keep them at the quote's scope: sessions feeding client evidence to product, with limited inspectable proof | The strategist's stem on the platform-versus-partner tension. CASE; the quote is cited only so the allowed mention is exact |
| B5 | "What would your first ninety days look like?" | CASE | [generic] | A plan, in order: learn the decision split with the squad leads and how adoption is measured, listen to partners, then propose a small first set of priorities for discussion. The ramp plan is also the dossier's required companion to the roadmap acknowledgment, so keep it consistent with A2. Claim no delivery you have not done | F2 and F6 close with a ramp plan, and this is where it gets rehearsed. CASE |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having held a product manager title or role" | A1 in sixty seconds. Pause and restate. Concede plainly: "I haven't held a product manager title, and a PM with three years has done what I haven't." Then one adjacent fact at the quote's scope: you led 30+ end-to-end client integrations of the vendor's REST APIs. Then a one-line ramp, and stop. Hold through two follow-ups by returning to the quote, never by adding to it | A1's objection with a clock. JD; the pressure is in the delivery, not the content |
| C2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Your sentence says you led them, through the stages it names. Answer slot: which of those stages you ran directly and which were shared or done by others, in your own words; if some were not yours, say so plainly. Do not widen "led" into more | F1 and F5 rest on this sentence, so attribution is probed here first. EXP because it tests what was yours |
| C3 | "You haven't owned a roadmap, and this job is the roadmap. Convince me this isn't a mistake." | JD | [grounded] `prohibited_claims`: "Having owned a product roadmap" | The position you hold is the honest one: "I haven't owned a roadmap." Hold it through two follow-ups without adding a claim to it, then give the ramp plan: how decisions split with the squad leads, how adoption is measured and its baseline, what you would ask partners first. Concede specifically what you do not yet know, such as how Quartzline's squads work. Do not offer a bridge here; the dossier closed that door | F2 under pressure. JD; the question's negative is sourced to the dossier's `prohibited_claims` item and `acknowledge_gap` area |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You'd own adoption metrics for the platform. How would you define adoption, and how would you know it moved?" | JD | [generic] | A plan: candidate definitions, the baseline you would ask for, and the assumption behind your favorite metric that you would defend least, named before they do. Answer slot: if you defined or tracked adoption or usage measures for any integration, say which and what was counted; if you did not, say so plainly and say what you would measure first | F9's responsibility, plus the dossier's open question on today's baseline. JD |
| D2 | "Your 30+ client integrations — walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words, four parts: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. The "30+" counts client integrations; keep it attached to that noun. If you do not know how something was counted, say so plainly | The only figure in your material, and a prober's first target. EXP |
| D3 | "Tell me about the evidence those roadmap-input sessions fed to product, and what product did with it." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what the quote says: you ran quarterly sessions feeding client evidence to product. Name the limit first: confirmed, with limited inspectable proof, so say plainly what you can show of it. Answer slot: if product acted on any of it, say what, and what part was yours; if not, or you never learned what happened, say so plainly and stay with the sessions as quoted | F7's medium-confidence line, where the dossier says to expect a probe. EXP |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A ninety-second arc of three beats, each at its quote's scope: the integrations you led, the playbook you wrote, the roadmap-input sessions. Then why product, in your own words (see A4). Dates and tenure come from your CV, not from this pack, because none of the quotes carries them | F1 and F7 in narrative form; the opener sets the frame for A1. EXP |
| E2 | "What are you actually playing with in API docs and schemas these days?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | A casual question on R3 that is still scored. Answer slot: if you work with API docs or schemas, say which and what your part is; if you do not, say so plainly and stay with the architecture stage of the integrations you led and the playbook you wrote | F4 is low-confidence and unclassified by the dossier, so the pack hedges it. JD in a conversational register |
| E3 | "Why Quartzline, and why the partner API platform?" | CO | [generic] | Say what draws you in your own words, anchored to what the JD states: a partner-facing API platform, partner discovery, adoption. Before Thursday, read Quartzline's public developer material, if it has any, so you can name one real thing; the pack could not research it | A rapport interviewer's easy question that scores homework. `[generic]` because research was refused. CO |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You'd work across two squads with their own leads. Where is the seam between your calls and theirs, and what happens when we disagree?" | JD | [generic] | Propose seam principles and ask where the seam is, since the dossier shows the JD asserts authority it does not evidence. For the disagreement, pick a time you and an engineering or delivery lead disagreed on scope or sequence: it needs a named stake, what you held, and an intact working relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The unresolved squad-authority risk in a collegial register. JD |
| F2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the internal integration playbook her team uses" | "We" for context, "I" for contribution. The one contribution your sentence carries is the playbook: you wrote it, and your team uses it. Add a credit story only from your own experience; if none comes to mind, say so plainly and describe how you would handle it | F1's playbook line as the one place credit is cleanly yours. VAL as a collaboration behavior; this is a persona stem |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Low-weight stem; no values-style round is detected and no published values were read. VAL |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, what the metric was, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Same reasoning as G1. VAL |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| "3+ years product management experience" (R1) | A1, A2, C1, C3 |
| "Shipped API or platform products" (R2) | A3 |
| "Technical fluency: API docs, schemas" (R3) | E2, B2 |
| "Stakeholder management across engineering, sales, customers" (R4) | D3, F1, F2, B3 |
| "Agile delivery experience" (R5) | A5 |
| "Own the roadmap for the partner-facing API platform" | A2, B1, B5, C3 |
| "Run discovery with integration partners" | D3, B4 |
| "Write specs and drive delivery with two engineering squads" | B3, F1 |
| "Define and track adoption metrics" | D1, B2 |

## Reverse questions

| # | Question | Why it lands | Basis |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | It reads as diligence, and it answers the dossier's open risk: decision authority is asserted in the JD but not evidenced | dossier questions_for_employer; dossier opportunity_risks_to_validate |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier notes adoption metrics are a named responsibility with no stated baseline; the answer tells you what you would be judged against | dossier questions_for_employer; dossier opportunity_risks_to_validate |
| 3 | "What would a strong first quarter look like for the person in this seat?" | It asks the manager to define success, which hands you the criteria to aim at and opens the ramp conversation from B5 | [generic] |
| 4 | "How does feedback from integration partners reach the roadmap today, and where does it get stuck?" | It ties to your own quoted sessions (F7) without claiming more than they say, and signals interest in discovery | [generic] |
| 5 | "For someone coming to product from client integration delivery, what would you want to see in the first ninety days to be confident?" | It turns A1 into a joint plan and surfaces a concern while you can still answer it | [generic] |
| 6 | "What happens after this conversation, and who else would I meet?" | Your words describe one conversation and no loop source says more, so this is the fastest way to learn what the next prep is | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The integrations quote at its own scope, positioned as adjacent: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Plain acknowledgment, sourced to the field: "I haven't held a product manager title." No slot |
| Having owned a product roadmap | Dossier `prohibited_claims` and its `acknowledge_gap` area | "I haven't owned a roadmap," then a ramp plan said as a plan. No bridge and no slot, as the dossier's strategy requires |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad," then how you would learn the decision split with the squad leads. F8's slot stays off priority entirely |
| Integration leadership as product-management experience | Inflated form of F1; the dossier's condition is that the bridge is positioned as adjacent | F1's quotes at their own scope. The limit is the pack's observation: your material shows integration delivery and a playbook, not a product-management role |
| Ran product discovery with integration partners | Inflated form of F7 | F7's quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product". The pack's observation: it says sessions feeding evidence to product, and nothing about how they were run |

## Sources

- **Provided:** `tuesday-dossier.md`, version 1.1, generated 2026-08-14; your note that this is a 45-minute conversation with the hiring manager on Thursday.
- **Dossier sections consumed:** `role_profile` (requirements and responsibilities, standing as the JD); `handoff_to_mock_interview` (`verified_candidate_evidence` for the fit snapshot and story-mapping, `uncertain_or_weak_areas` for the allowed strategies, `likely_interviewer_objections` for A1, `opportunity_risks_to_validate` and `questions_for_employer` for the reverse questions, `prohibited_claims` for the prohibited list). The `decision` was read as context only. The file has no `evidence_map`, `evidence_state` or `risk_register`, so F3, F4 and F8 are graded by this pack. The dossier is dated 2026-08-14; if the posting or your evidence changed since, the affected rows should be regenerated. Its decision prose mentions a tenure and a team size that no verified entry carries, so the pack uses neither.
- **Searches sent, all refused:** "Quartzline company values" (refused); "Quartzline interview process product manager" (refused); "Quartzline API platform strategy news" (refused). No pages were fetched.
- **Loop:** your words establish one session, a 45-minute conversation with the hiring manager, so no archetype fallback applies. No values-style round is detected, so there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every search was refused. It would have fed a values cheat sheet if a values-style round were detected, and the theme of G1 and G2 |
| 2. `Quartzline interview process product manager` | unavailable | Refused. It would have documented the loop and reweighted personas; your own words fix the loop for this session, so the weights rest on them |
| 3. `Quartzline API platform strategy news` | unavailable | Refused. It would have grounded a CO question in current strategy; A4 and E3 are `[generic]` instead |
| 4. interviewer name | n/a | No name was given, so there was no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already supplies the requirements and responsibilities |

## Upgrade menu

- Permission to research (the three searches this run were refused): Quartzline's published values, loop and current strategy → a grounded CO question, a values map if a values-style round turns up, and persona weights checked against a documented loop. A deeper pass is also available once, up to 6 more searches and 2 more fetches and several more minutes, which would add the strategy brief and recent org context
- The interviewer's name → a reading of their public path, weights adjusted to it, and a reverse question tied to their own career
- The recruiter's prep email → any stated focus areas or pre-declared deliverable, which this pack currently assumes absent
- Your CV, or answers to the slots in F3, F4, F5, F6, F7, F8 and F9 → each row you answer moves out of discovery, and the tenure and team size the dossier's prose mentions can enter F1 once your own sentence carries them
- An agenda or write-up from one of the roadmap-input sessions, or the integration playbook itself → F5 and F7 move from medium toward high
- An `evidence_map` section in `tuesday-dossier.md` → F3, F4 and F8 graded from your confirmed evidence rather than by this pack
