I'll read the skill's reference files before building the pack.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-3-denied-65583df1/stripe_product-operations-manager_interview_pack.md`. I built it for a final round with unknown interviewers and blended persona weights, since your note didn't say who you're meeting.

The pack has no Stripe-specific content and nothing about your background. All four web searches I sent were refused, and I didn't use memory for Stripe's values, loop or strategy. I also had no JD or CV. So the fit snapshot is a worksheet and every question is labeled generic. It has 21 questions across seven personas, 7 reverse questions, and an upgrade menu listing what each missing input would unlock.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in the final round, in what order (one session or several), and did the recruiter mention focus areas or a deliverable like a presentation or case? The answer reweights the personas and could add a build section.

Can you paste the JD and your CV, or a few lines on your background? Either one turns the generic rows into grounded ones; say "skip" and I'll leave the pack as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack — Product Operations Manager, Stripe

**Round:** final round. Interviewers, their relationships to the role and the session schedule were not given, so the persona weights are blended and flat. No JD and no CV were supplied, and web research was refused in this session, so the pack holds nothing specific to Stripe and nothing about your background. Every row is labeled to say so.

## 2. How to use this pack

- **Personas** describe how a question arrives (who is asking, in what style). **Types** describe what is being scored.
- Type key: **VAL** values and behavior alignment; **EXP** work-experience deep-dive; **JD** role-driven, can you do the job including its gaps; **CO** company and strategy knowledge; **CASE** a live problem from the role.
- Guidance is scaffolding, not a script. Where it says "answer slot" or "selection scaffold", the content has to come from your own experience, in your own words. Where nothing comes to mind, say so plainly: that is a legitimate answer and every scaffold below ends with it.
- Question IDs run by persona (A1, A2, B1 and so on) so a drill can name them.
- **Highest-ROI prep: B1.** Without a CV the pack cannot name your single most likely objection. B1 is the question that surfaces whichever gap you carry, so rehearsing it until it is boring is the best use of your time.

## 4. Fit snapshot (worksheet variant)

No JD, recruiter wording or background was supplied. The requirements below are role-family prose, written without a source and labeled `[generic]`; they are not quotations from Stripe. Every evidence cell is `none given` because there is no CV, so each bridge says what strong evidence looks like and gives a selection scaffold ending in its honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or programs across product, engineering and go-to-market teams (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is one launch or program you coordinated, with the teams it spanned and what was yours to decide. Selection scaffold: pick one instance where you can separate your part from the team's; if no instance comes to mind, say so plainly, then give the nearest work your material carries, or how you would approach it |
| F2 | Design and run planning or operating cadences for product teams (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a recurring planning, review or reporting rhythm you set up or ran, and who used it. Selection scaffold: pick one such rhythm and say what was yours; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would set one up |
| F3 | Use data to track product health and launch outcomes (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a measure you tracked or reported, with how it was counted and what it was sensitive to. Selection scaffold: pick a measure you can explain end to end; if none comes to mind, say so plainly, then say what you would measure first in this role |
| F4 | Improve processes and tooling so product teams scale (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process or tool change, what prompted it and what changed after. Selection scaffold: pick one change where you can say what you did versus what others did; if none comes to mind, say so plainly, then say where you would look first for friction |
| F5 | Influence and communicate with stakeholders, senior ones included, without direct authority (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a moment you changed a decision or a plan without holding the decision. Selection scaffold: pick one with a named stake and an intact relationship afterwards; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| F6 | Structure ambiguous problems and move them forward (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a problem with no clear owner or answer that you broke down. Selection scaffold: pick one where you can state the first question you asked; if none comes to mind, say so plainly, then walk through how you would structure one live, which the CASE questions rehearse |

No row is a gate: nothing supplied states a term such as location, authorization or pay, so none is invented.

## 8. Persona table

Archetype fallback: Generic, flat weights. No loop source was read, and "final round" alone does not establish how many sessions there are or who runs them, so the weights rest on a pattern and not on Stripe's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | A live problem set in the role: plan this, diagnose that | Equal: a final round of unknown shape could include one, and the role is process and program work | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of gaps, motivation, why here and why now | Equal: finals commonly test the thinnest area, but your thinnest area is unknown without a CV | Rehearse the likeliest objection until it is boring; calibrated candor over bluffing; a ramp plan stated as a plan |
| Values/Behavioral (C) | Scenario probes, story-shaped answers | Equal, and lower depth: Stripe's published values could not be retrieved, so these questions are not tied to named values | Choose stories where the hard truth landed; "we" for context, "I" for contribution; where no story comes to mind, say so |
| Pressure (D) | Interrupts, time-boxes, questions motives | Equal: possible in any senior round, nothing read says otherwise | Pause, restate, anchor in what you actually did, hold through two follow-ups, then concede specifically |
| Data-Driven Prober (E) | Asks how numbers were counted and what they assume | Equal: the role works with metrics, and any figure you cite invites this | Know what you can and cannot say about how a number was counted; name the weakest assumption first |
| Conversational (F) | Friendly, unstructured, still scored | Equal: some round in a loop usually opens this way | A 90-second arc for the biography question; treat casual questions as scored |
| Peer Evaluator (G) | Seam-splitting, collaboration, credit | Equal: a product operations role sits between teams, so peers may be in the loop | Reciprocity framing; propose seam principles instead of pretending to know the seam |

## 9. Question banks

All 21 rows are `[generic]`: with no JD, CV, values page or strategy brief, nothing here rests on your material or on Stripe. Each row is an open prompt or a live problem and presupposes nothing about your past.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and engineering, sales and support each say they are not ready. You are the product operations manager. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify first: what "ready" means to each team, what is fixed versus movable, who makes the go or no-go call. Then objective, split the blockers by owner, approach, the signals you would watch, the risks. Challenge one premise aloud, for instance whether all three must be ready at once. The question needs no claim about your past, so the guidance makes none | Live problem in the territory of F1 and F6. CASE because it scores structure and clarifying before answering |
| A2 | "A metric the product team watches dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Ask how the metric is defined and whether anything about its measurement changed before assuming a real drop. Then segments, timing, recent changes, a ranked list of hypotheses, the first two checks, and who you would tell and when | Covers F3 and F6. Persona stem for the Case/Strategist; CASE because the answer is scored on reasoning, not on a right diagnosis |
| A3 | "Several product teams each plan in a different way. Sketch how you would bring them onto a shared planning rhythm. What do you need to know first?" | CASE | [generic] | Clarify what is broken today and for whom, and what the teams would lose by changing. Then objective, which teams first, how you would earn adoption without authority, how you would know it worked, and what could go wrong | Covers F2, F4 and F5 as a live problem. The no-authority angle is where the role-family risk sits |
| A4 | "In your own words, what does Stripe do, and where does product operations fit in it?" | CO | [generic] | No research on Stripe ran, so the pack supplies no facts. Say two or three plain sentences from what you have read yourself on Stripe's own pages, name where you read it, and mark your view of product operations as a view. If you have not read them yet, do that before the interview and not in the room | Company-altitude check. CO because it scores homework; it stays generic until Stripe's own material is in hand |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Look at your lowest-evidenced row in the fit snapshot and say it in one plain sentence. Then give a ramp plan as a plan, not as a past: what you would learn in the first weeks and from whom. Hold through two follow-ups; concede the limit specifically and do not fold on what you can genuinely do. If no clear weakness comes to mind, say so plainly, then name the area where you have the least direct experience, or how you would find out | Likeliest in some form in any final round, and it is aimed at wherever your material is thinnest. JD because it scores the role including its gaps; no JD was supplied, so the role is the role-family in F1 to F6 |
| B2 | "Why product operations, why Stripe, and why now?" | CO | [generic] | Three short parts in your own reasons. The Stripe part must come from what you have read on Stripe's own pages, since the pack holds nothing on Stripe. If you cannot yet give a Stripe-specific reason, find one before the interview, and say plainly in the room that you are still forming it if that is true | Motivation consistency. CO because the Stripe-specific part scores homework |
| B3 | "What would you want to learn in your first 30 days, and what would you want to have changed by day 90?" | CASE | [generic] | A plan, in the future tense, built from your answer to B1: who you would meet, what you would read, what you would ask. Put a limit on the 90-day part, since a plan with no limit reads as unexamined. Make no claim about a past you have not stated | Skeptics test whether the candidate knows what they do not yet know. Draws on F6 and F4 |

### C. Values/Behavioral

Stripe's published values were not retrieved, so no VAL question below is tied to a named value, and no values cheat sheet is included.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact afterwards. Use "I" for what you said and did, "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem; covers F5. VAL because it scores behavior, not the job |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an instance where the trade-off was real and you can say what the metric cost. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem; it tests judgment under a competing incentive |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, give three short points from your own material in your own words (the slots are your answers to B1 and B2), and stop. Hold the position through two follow-ups; concede a specific limit, never the core of what you can do | Persona stem. JD because it scores whether you can make the fit case under time pressure |
| D2 | "Tell me about a result you are proud of, and how much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result where you can separate your part from the team's and say each in a sentence. "We" for context, "I" for contribution. Hold through two follow-ups; concede what was not yours without folding on what was. If nothing comes to mind where you can separate them, say so plainly, then give the nearest thing your material carries | Attribution probe; EXP because it tests what was actually yours |
| D3 | "Ninety seconds: convince me product operations is a real function and not overhead." | JD | [generic] | Define the function in your own words, then give your view of the cost of not having it. Expect a push such as "that is just project management". Hold, then concede one specific limit of the function | Tests composure and whether you understand the role's reason to exist. Touches F4 |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Choose a number from your own work that you would be happy to defend. Walk me through how it was counted." | EXP | [generic] | Defend-the-number slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. "I don't know how it was counted" is an honest branch. If you have no figure to choose, say so plainly and say what you would measure first in this role | Covers F3. The weakest-assumption move converts a gotcha into credibility |
| E2 | "A dashboard shows adoption of a new feature rising. What would you check before telling leadership it is working?" | CASE | [generic] | Definition of adoption, who is counted, the baseline period, whether anything else changed, and what result would change your mind. Say which assumption you would defend least | Live metric skepticism; covers F3. No claim about your past |
| E3 | "How would you decide which metrics a product operations function reports to leadership every week?" | CASE | [generic] | Start from the decisions leadership has to make, then candidate measures, what each could mislead about, and how you would retire one. Ask who the audience is before answering | Covers F3 and F2 at design altitude |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the turns, why this role. Every beat is a sentence you can stand behind from your own material; the pack holds none, so write it from your CV and rehearse it aloud | The casual biography question is scored. EXP because it checks consistency with whatever your CV claims |
| F2 | "What have you been learning lately that bears on this kind of work?" | EXP | [generic] | One specific thing you really are learning, said in your own words and kept to what you can discuss for two more minutes. If nothing comes to mind, say so plainly and name the nearest thing you are curious about | A casual-register question that scores genuine interest. No claim about your past is supplied |
| F3 | "Is there anything you would like to tell us that we haven't asked?" | EXP | [generic] | Have a 30-second close ready, drawn from your own material: one thing you want remembered. Never answer that you think they have covered everything | The open slot is scored and is where preparation shows |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam between product operations and the product team, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know the seam, for instance who owns the decision and who owns the process around it. Name how you would disagree: raise it early, with the evidence, and agree the tie-break before the case arises | Covers F1 and F5 as a live scenario; no claim about your past |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an instance where credit was shared or contested and say what you did. If none comes to mind, say so plainly, then say how you would handle it | Persona stem; VAL because it scores partnership behavior. Covers F5 |
| G3 | "What would you need from the product managers you would support, and what would you give them back?" | CASE | [generic] | Reciprocity framing: lead with what you would take off their plate, then what you would need to do it. Do not pretend to know their current pain; ask | Peers price what a hire adds to or takes from their load. Covers F1 and F5 |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 launch and program coordination | A1, G1, G3 |
| F2 planning and operating cadences | A3, E3 |
| F3 metrics and data | A2, E1, E2, E3 |
| F4 process and tooling | A3, D3 |
| F5 influence without authority | A3, C1, G1, G2, G3 |
| F6 structuring ambiguity | A1, A2, B3 |
| No requirement row, by design: motivation, company knowledge, attribution, biography and close | A4, B1, B2, C2, D1, D2, F1, F2, F3 |

No defend-the-number question is tied to a CV figure, since no figure was supplied; E1 stands in.

## 11. Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "How does the team decide what product operations owns versus what stays with the product teams, and how has that boundary moved?" | It opens the seam question G1 rehearses and shows you are thinking about scope, not only tasks |
| 2 | "What would a strong first 90 days look like, and what would tell you in month six that the hire was right?" | It gets the success criteria said aloud and gives you something concrete to respond to |
| 3 | "Which of the teams this role supports is under the most strain right now, and what would you want different for them?" | It points your attention at the real problem and invites a conversation about priorities |
| 4 | "How is this function's own work measured, and who sees those measures?" | It follows from E3 and shows you hold the function to the standard you would hold others to |
| 5 | "What is a recent trade-off the team made between process and speed, and how did you decide?" | It invites a story and tells you how decisions are made in practice |
| 6 | "Is there anything about my background you would like me to address before we finish?" | It gives you the chance to handle an objection you rehearsed in B1 instead of leaving it unspoken |
| 7 | If the person is a peer: "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question; it shifts from what you need to what you bring |

## 13. Prohibited claims

Built locally from the fit snapshot, before the banks. With no CV there is no sentence of yours to inflate, so nothing here widens a stated claim.

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past, scope, results or figures that your own words do not carry | No background was supplied, so the pack holds no sentence to build on | Your own words, answering the scaffolds above. Where nothing comes to mind, the honest branch each scaffold ends with |
| Stripe-specific facts (values, strategy, loop structure, product details) stated as established | Web research was refused in this session, so none were researched | Say only what you have read yourself on Stripe's own pages, and where you read it |

## 14. Sources

**Provided documents:** your message (company, role, round). No JD, CV, interviewer profile, recruiter guidance or `tuesday-dossier.md` was provided.

**Searches sent (all refused, none returned):**

- `Stripe operating principles values` — refused
- `Stripe interview process Product Operations Manager` — refused
- `Stripe strategy news 2026` — refused
- `Stripe Product Operations Manager job description` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe operating principles values` | unavailable | Would have supplied official value names for VAL questions and a values cheat sheet where a values-style round is documented. Nothing moved |
| 2. `Stripe interview process Product Operations Manager` | unavailable | Would have established the loop and set persona weights from named rounds; the generic archetype with flat weights stands in |
| 3. `Stripe strategy news 2026` | unavailable | Would have grounded A4 and B2 in current priorities; they stay generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned F1 to F6 into quoted `[inferred]` rows and added JD-tagged questions; they remain role-family prose |

## 15. Upgrade menu

- Job description text → F1 to F6 become quoted `[grounded]` rows, JD-tagged questions are added per requirement, and the coverage table is rewritten against the JD's own list
- CV, or a few sentences about your background → the evidence column fills, selection scaffolds become story-mapped guidance, B1 is rewritten against your real thinnest row, and any headline figure gets its own defend-the-number question
- The final-round schedule and who runs each session (if your final is several sessions) → per-session mini-packs with their own persona weights
- The recruiter's prep email, including any focus areas or a pre-declared presentation or case → coverage by what is actually assessed, and a build section for any declared deliverable
- Interviewer names → an interviewer read, persona weights from public footprint, and a reverse question tied to their path
- Web search permission, or Stripe's own values and strategy pages pasted → a values cheat sheet if a values round is documented, CO questions grounded in current strategy, and a deeper research pass offered once (up to 6 more searches and 2 more fetches, several more minutes)
- How much prep time you have → a prioritized schedule sized to it
