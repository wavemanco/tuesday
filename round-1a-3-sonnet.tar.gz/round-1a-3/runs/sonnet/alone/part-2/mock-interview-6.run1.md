I'll read the reference files the skill requires before writing anything.
Writing's done; I'm now running a quick check that the pack's tables are well-formed before I present it.
Your prep pack for all three rounds is saved as `larkfield-systems_engineering-manager_interview_pack.md`. I built it as one loop: a shared fit snapshot, then a bank, persona weights and reverse questions for each round. I couldn't check its tables after writing it: the check I tried needed approval and I didn't pursue it. If a table looks off when you open the pack, tell me and I'll fix it.

- **Search was refused:** web search wasn't permitted, so I have no Larkfield research. There's no company-values sheet and no strategy questions, and the case questions are generic. All three queries are logged in Sources as refused.
- **Source material:** the pack rests on your own words and the recruiter's "values and leadership philosophy" description. You gave me four sentences of background, and those are the only evidence I quote.
- **Highest-ROI prep:** A2, the hardware-roadmap question. It's the likeliest objection in all three rounds because the role description names hardware, and you've said you haven't owned that kind of roadmap. A2 has you say that plainly first, then give a plan, with exact wording for conceding under follow-ups.
- **Managing managers:** you said you've never managed managers. The role description I have doesn't mention managers, so I treated that as a lighter second objection, covered in A3 and I2.
- **Your two figures:** the 60% on-call drop and the "about 40 interviews" each get a defend-the-number question (C1, C2, and C1 again in I1). They're framed so you don't claim more than your sentence says, for example that you personally caused the drop.
- **Prep order:** Tuesday first (A2, A1, A3, the two figure questions, then the delivery case B1), then the panel, then the VP round. The full schedule is in "Prep triage".

Say the word and I'll run a live drill as the Director on A2, the question the pack names as highest-ROI. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for you to carry into later sessions. If you want the pack as a Word document, say so and I'll convert it.

1. Can you paste the full job description and your CV? I've worked from your summary and four sentences, and more would turn the thin rows into real evidence. If not, I'll stay with what I have.
2. Has the recruiter said anything about the panel's focus, or asked you to prepare something, such as a presentation or a take-home? That would change Thursday's structure.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Mode: loop, three scheduled rounds. Interviewers are unnamed in the material, so there is no interviewer read.

| Round | When | Who and length | Relationship |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager, 60 min | Panel |
| 3 | The following Monday | VP Engineering, 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows values or leadership principles, not generic virtue |
| EXP | Whether a claim about your experience survives scrutiny, including how much was you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge. No CO questions appear in this pack: no company facts were available (see Sources) |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. It tells you what to say if something was true, and what to say plainly if it was not. Anything you tell me that fills a slot is new material: I quote it into the fit snapshot and regenerate the rows that draw on it.

## Prep triage

Three rounds in two weeks. Do these in order, aloud, with a timer:

1. Before Tuesday: A2 first (the highest-ROI prep in this pack), then A1 and A3, then C1 and C2 (your two figures), then B1.
2. Before Thursday: E2, F1, F3 and G1, then E3.
3. Before Monday: I2 and I1, then H1 and H4, then J1.

Everything else is insurance.

## Fit snapshot (shared by all three rounds)

The requirements are quoted from the role description you gave me, which is a summary and not the full posting. Your evidence is four sentences of your own, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six, at a payments company. It does not show two squads or device-management services, and the words stay at that scope: "I've spent three years as a team lead of six." Answer slot: the role description's two-squads line makes a probe on the step up likely. If any of your lead work spanned more than one team, say what and how, in your own words; if none did, say so plainly and stay with the team of six |
| F2 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | discovery | The sentence says you pushed a reliability quarter through against roadmap pressure and that the burden dropped 60% after. It does not show whether delivery dates or commitments were yours to hold. Answer slot: if they were, say how you held them; if they were not, or there were none, say so plainly and stay with the sentence |
| F3 | "hiring" in "own delivery, hiring and growth for 11 engineers" — role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The sentence already speaks to hiring in role-relevant terms: you run the loop for backend roles. Expect a probe on the figure, because "about 40 interviews" does not say how many you sat in. Where the sentence allows two readings, claim the smaller. The figure raises four slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F4 | "growth for 11 engineers" in "own delivery, hiring and growth for 11 engineers" — role description | none given | none | [grounded] | discovery | Your material is silent on growing engineers. Answer slot: the role description names growth, so expect a probe on it. If you have supported an engineer's growth, say what you did and what part was yours, in your own words; if you have not, or it was not yours, say so plainly and say how you would start |
| F5 | "partner with hardware and product on roadmap" (the hardware side) — role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." The role description's word is partner, and your sentence says owned. Whether you have worked alongside hardware teams is something your material does not show; that is the pack's observation, not words for you. After the plain acknowledgment, how you would learn it, said as a plan and never as a past |
| F6 | "partner with hardware and product on roadmap" (the product side) — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your sentence carries adjacent work: a reliability quarter pushed through against roadmap pressure. It does not show partnership with product, and the words stay at its scope. Answer slot: if you took that quarter to product or others, say with whom and what you said, in your own words; if it was settled another way, or was not yours to take, say so plainly and stay with the sentence |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | A1, A3, A4, B1, B2, J1 |
| Own delivery | B1, B2, F1, F2, G2 |
| Hiring | C2, E3, H3 |
| Growth for 11 engineers | H4 (the role description lists growth once, so one question) |
| Partner with hardware on roadmap | A2, B1, D2, E2, J2 |
| Partner with product on roadmap | B3, E2, F1, G1 |
| Your figure: 60% | C1, I1 |
| Your figure: about 40 interviews | C2 |

## Prohibited claims (shared)

Built before the banks. No guidance, slot, hold or reverse question in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F5 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |
| Has led two squads or an organisation of eleven | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of six |
| Cut on-call burden by 60% on your own | Inflated form of F2 | F2's quote at its own scope: the burden dropped after you pushed the reliability quarter through. C1 and I1 only ask which part was yours |
| Ran or conducted 40 interviews yourself, or hired 40 people | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop, and the quarter's count is about 40 interviews. C2 only asks which part was yours |

---

# Round 1: Tuesday, Director of Engineering (hiring manager, 45 min)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the gaps: scale, hardware, motivation | Highest. A hiring manager prior is Case plus Skeptic, and you have named two gaps yourself (F5). It is your would-be boss, who is pricing the risk of hiring you | Rehearse A2 until it is boring: plain acknowledgment first, then a plan, with no claim you cannot back |
| Case / Strategist (B) | Live problems from this team's own roadmap | High. The hiring-manager prior, and the role description is about delivery and roadmap partnership | Clarify, objective, options, risks. Think aloud, and challenge one premise respectfully per case |
| Prober (C) | Walks your numbers back to their assumptions | Medium. You have two figures on your message (F2, F3), and a Director reads them line by line | Know what you can and cannot say about how each was counted, and say plainly when you do not know |
| Conversational (D) | The opener and a curiosity question | Medium-low. Almost certain as an opener, but low-risk if rehearsed | A 90-second arc built only from your own sentence; treat the casual questions as scored |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led a team of six. This role is two squads and eleven engineers. What changes about the job?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start with what the sentence carries: three years as a team lead of six. Then answer as a plan, not a past: what you would find out about each squad in the first weeks, and what you would stop doing yourself as the number of people grows. Answer slot: the two-squads line makes a probe on the step up likely. If any of your lead work spanned more than one team, say what and how, in your own words; if none did, say so plainly and stay with the team of six | F1 is the transferability row and the first place a hiring manager tests scale. JD because it scores the stated role, not a past event |
| A2 | "This role partners with hardware on the roadmap, and you're coming from payments. How would you handle the hardware side?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company", "I've never managed managers and never owned a hardware-adjacent roadmap." | **The highest-ROI prep in this pack.** Say the limit first, in your words: "I've never owned a hardware-adjacent roadmap." The role description says partner, and you can point to that word without claiming you have done it. Then a plan: which hardware dates your services would depend on, which of your releases hardware would depend on, who in hardware you would meet regularly, and a question back to the Director on how conflicts are settled today. If asked what you have that is adjacent, say what you did and stop: "I pushed a reliability quarter through against roadmap pressure." Let them draw the link. Follow-up 1, "What do you do in the first 30 days?": the plan again, with nothing added from a past. Follow-up 2, "Hardware slips a revision and your squad is blocked": use the B1 structure. Follow-up 3, "So you want us to teach you?": hold, and concede exactly: "That's fair. I haven't done this, and I'd expect to learn it from the hardware team and from you." Do not fold into any claim of hardware experience | F5 is the biggest gap against a named requirement and the likeliest objection in all three rounds. The role description names hardware, and it does not name managing managers. JD because it scores a stated responsibility; the guidance holds only what the quote carries |
| A3 | "Have you led through other leads before?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I've never managed managers." Then a question back, which is a legitimate move: how are the two squads structured today, and who leads day to day? If they have leads, your plan for working with them is yours to say in your own words; do not describe a practice you have not run | F5 carries your stated negative, and it is the second most likely probe at this altitude. EXP because it tests whether you can state your limit precisely |
| A4 | "Why this role, at an industrial IoT company, coming from payments?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Nothing in your material states your motive, so the words are yours. Selection scaffold: name the one specific thing about two squads building device-management services that draws you, and one thing from your current role you want to build on. If no real reason comes to mind, say so plainly, then say what you would want to find out first | F1 is where "why here, why now" attaches for a Skeptic. JD because it scores fit to the stated role |
| B1 | "Hardware changes the firmware interface your services depend on, three weeks before a planned release. Walk me through the next week." | CASE | [generic] | Structure it aloud: clarify first (what changed, which devices, who in hardware owns the decision), then the objective (protect customers, then the release), then options (hold, re-sequence, ship behind a flag, split), who you tell and when, what you ask of hardware, and the risk in each option. Challenge one premise: whether the date is the real constraint. Claims about your past: none | F5 and F2 turn into a live problem here. CASE because the Director's own roadmap is the likeliest source of the scenario; `[generic]` because it is a pattern, not a fact about Larkfield |
| B2 | "Eleven engineers, a full roadmap, and the squads say reliability is hurting them. How do you decide what gets the next quarter?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure: what you need to see first (incident and on-call data, what the squads feel, what the roadmap commits to), the options for the quarter, who decides, what you trade. If you tell your own story, keep it at the sentence's scope and in one line: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if the quarter involved a trade you made, say what, in your own words; if it did not, say so plainly and stay with the sentence | F2 is the only evidence of delivery and roadmap judgment. CASE because it is a live decision, asked in the role's own terms |
| B3 | "Product wants a new device-provisioning feature in six weeks. One squad says it needs ten. What do you do?" | CASE | [generic] | Clarify what the six weeks is anchored to, split the feature into a first usable slice and the rest, put the options and their risks in front of product in one conversation, and say what you would protect. Think aloud; claims about your past: none | F6 is the product side of the roadmap partnership. CASE because the answer is scored on reasoning; `[generic]` because the feature is invented |
| C1 | "That 60% drop in on-call burden: how was it counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The defend-the-number slots, each in your own words. How the 60% was counted. What it is sensitive to. The assumption behind it you would defend least; name it before they do. Which part was yours. If you do not know how it was counted, say so plainly. Keep the sentence's attribution: you pushed the quarter through, and the burden dropped after. Do not say you cut it. Hold through the follow-up "what else changed in that period?" by returning to the sentence | F2 holds your only headline metric, and a Prober's first target. EXP because it tests attribution and counting |
| C2 | "About 40 interviews last year: how many were you in the room for, and what does the count include?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the sentence carries: you run the hiring loop for backend roles. Then the four slots, in your own words: how the 40 was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If the figure counts the loop's interviews and not only yours, say so plainly; where the sentence allows two readings, claim the smaller | F3 is solid evidence with a figure attached, so a probe lands on the count. EXP because it tests what was actually yours |
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the three beats the sentence states: nine years in engineering, three as a team lead of six, currently at a payments company. Then why this role, in your own words (A4). Nothing else about the past is on the page, so add nothing | The biography question is nearly certain as an opener, and it is scored. F1 supplies the beats. EXP because it checks the story holds together |
| D2 | "What would you want to understand first about how hardware and software work together here?" | JD | [generic] | A curiosity answer: how a hardware change reaches the squads, who arbitrates when dates conflict, and what the squads wish hardware knew. Present it as what you would learn, not what you know. Claims about your past: none | F5 gets a gentle form here, and the answer shows how you learn. JD because it scores the stated hardware partnership |

## Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would make the next two quarters a success for these two squads, in your eyes?" | It gets the scoreboard your would-be boss will use, and it is something you can only learn from them |
| R1.2 | "Where do the squads' schedules and hardware's schedule collide most often right now?" | It treats the hardware dependency (F5) as a live problem, which shows where you are putting your learning |
| R1.3 | "How are the two squads structured today, and who leads day to day?" | It resolves what the material does not show about leads (F1), and the answer reshapes A3 |
| R1.4 | "What has been hardest about hiring for this role?" | It tells you what the Director is worried about, and it reads as a manager's question |
| R1.5 | "How do you and your VP split roadmap decisions that touch hardware?" | It shows where the real decisions sit before you take the seat |
| R1.6 | "What would you want me to have learned by day sixty?" | It lets you plan against their expectation, not your guess |

---

# Round 2: the Thursday after, panel (two staff engineers and a product manager, 60 min)

## Persona weights

The panel's names are unknown, so no persona is assigned to a member. The weights blend the top two personas of each seat, with the staff engineers read as technical peers and the product manager as cross-functional.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (E) | Seam-splitting, "what would you need from me", disagreement with equals | Highest. Staff engineers are pricing what a new manager costs their work, and the PM's seam with engineering is the same lens | Reciprocity framing: what you would bring them. Propose seam principles, not a pretended seam. Show spine and tact together |
| Prober (F) | Depth checks on your stories, your technical judgment, your on-call thinking | High. Technical specialists prior is Prober plus Pressure, and F2 holds the only metric that touches their world | State what the sentence says and no more. Where you do not know, say so |
| Values / Behavioral (G) | Scenario probes on stakeholder conflict and unwelcome news | Medium-low. The PM prior is values plus conversational. The recruiter flagged the values conversation for the VP round, not this one | Map a story only where a sentence of yours carries one; otherwise a scaffold with its honest branch |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Staff engineers on your squads will often know the systems better than you. How do you work through a technical disagreement with them?" | JD | [generic] | Principles, in your words: who owns the call, what is decided on technical merit and what on delivery trade-offs, how you disagree in the room and where you do not, and when you defer. Claims about your past: none | The staff engineers' first concern is whether a manager will override or defer. JD because it scores the working relationship the role implies |
| E2 | "Our teams sit beside hardware and product. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a pretended seam: what each side owns, what is shared, who decides when two owners conflict, how fast a disagreement escalates. Then ask the panel where they see the seam today. Claims about your past: none | The stated hardware and product partnership (F5, F6) is the seam. JD because it scores the responsibility; peer weighting moves it to the panel |
| E3 | "You run a hiring loop today. What would you want from the staff engineers here in ours?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Reciprocity: say what the sentence carries, that you run the hiring loop for backend roles, then what you would want from staff engineers and what you would give them. If you changed anything about your loop that staff engineers would care about, say what, in your own words; if you did not, say so plainly and answer as a plan | F3 is strong, and staff engineers are the interviewers who will sit in the loop. JD because hiring is a stated duty |
| E4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Principles in your words: name the people and teams, use "we" for context and "I" for your own contribution. Claims about your past: none | The Peer Evaluator's credit probe, in its stock form. VAL because it scores behavior, not a fact |
| F1 | "You pushed a reliability quarter through against roadmap pressure. Walk us through how." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Tell the beats the sentence states: a reliability quarter, roadmap pressure, you pushed it through, the burden dropped after. Answer slot: if you took it to anyone or traded anything, say who and what, in your own words; if it was settled another way, or the push was not only yours, say so plainly and stay with the sentence. Keep to the sentence's attribution, and do not say you caused the drop | F2 and F6 are your only evidence on delivery and roadmap partnership. EXP because it tests what was actually yours |
| F2 | "A squad's on-call load is high and the roadmap is full. How do you find out what is actually wrong?" | CASE | [generic] | Structure: what you would look at first (the incident history and who is on call), what you would ask the engineers, how you separate a few big causes from many small ones, what you would propose and how you would measure it. Claims about your past: none | The staff engineers will want to see technical judgment on reliability. CASE because it is a live diagnosis |
| F3 | "As a manager of eleven engineers, where do you stay technical and where do you stop?" | JD | [generic] | Your position, in your words, with the trade-off said aloud: what you keep (reading designs, joining incident reviews) against what you hand off. Claims about your past: none | Technical specialists test whether a manager is credible with them. JD because the role is a management one |
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The sentence carries a reliability quarter and roadmap pressure. It does not say the pressure came from leadership or that you delivered a hard message. Answer slot: if that story involved telling leadership something unwelcome, say what, to whom and how it landed, in your own words; if it did not, say so plainly and pick another time, or say none comes to mind and describe how you would do it | F6 is the closest evidence. VAL because it is a persona-stem behavioral question |
| G2 | "A date is going to slip. When and how do we hear about it from you?" | JD | [generic] | Structure: tell early, say what is known and what is not, give the options and the ask, use one channel. Claims about your past: none | The product manager is scoring how partnership would feel. JD because delivery is a stated duty (F2) |

## Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | To a staff engineer: "What is one thing about these services you would change if you could?" | It invites a candid view, and staff engineers tend to answer a genuine question at length |
| R2.2 | Reciprocity: "What could a new engineering manager do in their first month that would genuinely help your work?" | It frames you as reducing their load, which is the peer lens |
| R2.3 | To the product manager: "Where does the roadmap conversation between product and engineering get hardest today?" | It covers the product side of F6 and shows you are looking for the seam |
| R2.4 | "How do hardware changes reach the squads today, and how would you want them to?" | It keeps the hardware gap (F5) in learning mode |
| R2.5 | "What is the on-call experience like on these services right now?" | It connects to F2 without a claim, and the answer tells you what the first quarter looks like |
| R2.6 | "What do you most want from a manager that you have not had?" | It lets the staff engineers describe your job to you |

---

# Round 3: the following Monday, VP Engineering (30 min, "values and leadership philosophy")

## Persona weights

The recruiter's description is the loop source for this round's type. The company's published values were not available (see Sources), so the questions are themed on the recruiter's words and the role description, not on named values.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (H) | Leadership philosophy and behavioral probes | Highest. The recruiter named values and leadership philosophy | Map a story to each principle only where one of your quoted sentences carries it; otherwise a scaffold ending in its honest branch |
| Pressure (I) | Time-boxed challenge on your results and on why you | Medium. A skip-level prior is Strategist plus Pressure, and thirty minutes forces short answers | Pause, restate, hold through two follow-ups, concede specifically, never fold on the core |
| Case / Strategist (J) | Altitude questions on how you would run this | Medium. The skip-level prior, though with 30 minutes it is likely one question | Clarify before structuring, then name a priority and a risk |

Thirty minutes allows perhaps five or six questions, so rehearse H1, I1, I2 and H4 first.

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure.", "I run our hiring loop for backend roles — about 40 interviews last year." | Choose two or three principles you actually run your team by, each backed by something you did. Two of your sentences can carry a story at their own scope: "I pushed a reliability quarter through against roadmap pressure" and "I run our hiring loop for backend roles." Say what you did and let the VP draw the inference; do not say what the work proves. Answer slot: what principle each reflects is your own wording. If neither reflects how you lead, say so plainly and use a different example | The recruiter's own words raise this question. F2 and F3 are the sentences that can carry it. VAL because it scores leadership principles, not skills |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a metric or target that pointed the other way, what you chose, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem, for a values conversation. Nothing in your material speaks to it, so the scaffold is honest about that. VAL because it scores behavior |
| H3 | "What do you look for in an engineer you hire?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the sentence carries: you run the hiring loop for backend roles. What you look for is your own wording; nothing in your material supplies it. Answer slot: if you set any part of how your loop works, say what and why; if you did not, say so plainly and answer from what you look for | F3 is solid, and hiring is a stated duty. VAL because for a VP it is a statement of principle |
| H4 | "Tell me about an engineer whose growth you invested in." | VAL | [generic] | Selection scaffold: pick someone where you can name the stake, what you did and what happened to them. Be exact about which part was yours. If no such person comes to mind, say so plainly, then say how you would start with the engineers in these squads | The role description names growth, and nothing in your material speaks to it (F4). The scaffold keeps the honest branch open. VAL because it scores how you treat people |
| I1 | "That result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold at the sentence's scope: you pushed the quarter through, and the burden dropped after. Do not say you caused it alone. Answer slot: if you can separate your part from the team's, say how, in your own words; if you cannot, say so plainly. Hold through two follow-ups, then concede exactly what you cannot attribute, and no more | F2 is the figure a skip-level will push on. EXP with a Pressure delivery |
| I2 | "Sixty seconds: why you, rather than someone who has already led managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap.", "I run our hiring loop for backend roles — about 40 interviews last year.", "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Concede first, in your words: "I've never managed managers." Then what you have, at its scope: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Say it and stop. Hold through a second push; do not add scope | F5 carries the stated negative and F2 and F3 the positives. JD because it scores the fit to the stated role; the delivery is the Pressure persona's |
| J1 | "Eleven engineers, a roadmap and an incident history: what does a good first ninety days look like?" | CASE | [generic] | Clarify first: what the VP wants most, what is known about each squad. Then listen (squads, hardware, product), a first set of priorities, one thing you would deliberately leave alone, and a risk. Claims about your past: none | A skip-level asks about altitude and sequence. CASE because it is a live plan; `[generic]` because it carries no fact about Larkfield |
| J2 | "How do you think about the relationship between engineering and hardware at an industrial IoT company?" | CASE | [generic] | Think aloud and ask the VP where they stand: what each owns, where interfaces break, how roadmap conflicts are settled. Do not recite company facts, because none were available to this pack. Claims about your past: none | F5 is the gap, and a VP may probe the altitude of your thinking on it. CASE because it scores reasoning; no CO claim was possible |

## Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does good leadership look like in your organisation, and how would you know I was growing into it?" | It asks the VP to describe the standard you will be scored against |
| R3.2 | "Which of your engineering principles is hardest to hold under delivery pressure?" | It converts a values conversation into a real one and invites a story |
| R3.3 | "How do you develop managers who come in from outside?" | It addresses F1 and F5 head-on without stating a claim, and it is a question a manager would ask |
| R3.4 | "What do you want true about the hardware and software partnership in eighteen months?" | It shows you are thinking about the partnership (F5) as an outcome |
| R3.5 | "What is the biggest open bet in engineering this year?" | It gets the VP's altitude, and the answer is a safe starting point for your own questions |
| R3.6 | "What would make you doubt a hire in this seat at six months?" | It asks for the bar up front, and you can hear it before it applies |

---

## Sources

Provided documents: your message (the role description, the three round descriptions including the recruiter's "values and leadership philosophy", and the four sentences of your background quoted above). The loop is established by your own words: three sessions, each with who runs it.

Dossier: none was in context. No interviewer names were given.

Search queries sent, all refused (permission to search was not granted):

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The values cheat sheet (section 10) is dropped. VAL questions are themed on the recruiter's words and the role description, and value names would have come from the company's own page |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The loop rests on your own words, which establish all three sessions. A source on the loop could have added case formats and how the panel is scored |
| 3. `Larkfield Systems strategy` / recent news | unavailable | No CO question is in the pack, and the CASE questions are `[generic]`. Strategy facts would have grounded J2 and B1 |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form. The interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | Searches were refused, so no further call was sent. The role description is a summary, and a posting could have added requirements it does not state |

This is an L1 run. L2 did not run.

## Upgrade menu

- The full job description text → the six fit rows are checked against the posting's own list, and any mid-list requirement it holds (a methodology, a tool, travel or on-site terms, whether the squads have leads) becomes its own row and question
- Your CV, or a few more lines on your current role → the evidence column holds four sentences of yours; F4 is `none given`, and more of your own sentences could move rows from `discovery` to a grounded story, with the caveat that a CV alone leaves them `medium` until something inspectable backs them
- Your answers to the slots on F1, F2, F4 and F6 → each answered slot becomes quoted evidence and the rows and questions that draw on it regenerate
- Any work you have done alongside hardware teams, in your own words → F5 could change from the stated negative to a grounded row for the partnership half of the requirement, and A2 would gain a real adjacent story
- The recruiter's prep notes for each round → the panel's format and focus, any pre-declared deliverable, and whether the VP round uses published values; usually one email
- Search access for the research pass, or the company's values page pasted in → the values cheat sheet (section 10), named values mapped to your stories, and grounded CO and CASE questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief, and is offered once here
- The names of the Director, the staff engineers, the product manager and the VP → an interviewer read, persona weights read from their public footprint, and a reverse question tied to each person's path
- A `tuesday-dossier.md` from job-underwriter → verified evidence, an objection list and `prohibited_claims` from an evidence review, in place of the ones built here from your message
