I'll read the skill's reference files first.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-3-denied-113ea920/stripe_product-operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles, a requirement-coverage table and six reverse questions. I built it for a final round whose schedule and interviewers I don't know, so the persona weights lean flat.

- **Research didn't run.** Web search wasn't permitted, and all four searches were refused. Nothing in the pack comes from Stripe's own materials. That means no Stripe values, no interview-loop details and no recent strategy.
- **Nothing is based on your background.** The pack has no CV or job description to work from, so every answer note is a method or a story-selection prompt, not your own experience. The fit snapshot is a worksheet.
- **Biggest rehearsal item.** B1, "Which part of this role would you be weakest at on day one?", is marked as the highest-value one to practise. A CV would let me replace that guess with the objection your own background most invites.

Say the word and I'll play the hiring manager on B1, with live follow-ups and feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in this final round (hiring manager, a peer, a skip-level, or several sessions back to back), and did the recruiter name any focus areas or a deliverable such as a presentation or take-home? The answer reweights the banks.
2. Can you paste the job description and your CV, or just the lines you'd lean on? I'll carry on without them if you'd rather not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer and relationship: not given. Schedule (one conversation or several back-to-back sessions): not given. Built as a blended pack with flat-leaning persona weights.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

Type key:

- VAL: behavioral and values alignment. Does past behavior show the behavior the question names.
- EXP: work-experience deep-dive. Whether your claims survive scrutiny and what was actually yours.
- JD: role and job-description driven. Can you do the listed job, gaps included.
- CO: company and strategy knowledge. Homework depth and thinking at the company's altitude.
- CASE: a live problem from the role. Structure and reasoning on the spot.

Everything in this pack is labeled `[generic]`, because no job description, CV or working web research was available. That means every row is rehearsal for a pattern, not a fact about Stripe or about you. The upgrade menu at the end says what each missing input would change.

Highest-ROI prep: question B1, "Which part of this role would you be weakest at on day one?" It is asked in nearly every manager-style final, and a rehearsed, non-defensive answer changes the room. This pick is a role-family inference; a CV would replace it with the objection your own material most invites.

## Fit snapshot (worksheet)

You gave no CV and no job description, so this is the worksheet variant: every evidence cell reads `none given`, and each row says what strong evidence would look like and how to choose a story. The requirements are role-family patterns written as plain prose, not quotes from a posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a repeating operating rhythm across product teams, such as planning cycles and business reviews (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a recurring forum you ran or helped run, with a named audience and a decision it fed. Selection scaffold: pick a recurring meeting, review or planning cycle where you can say who attended, what it was for and what you personally did in it; if no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Coordinate launches across product, engineering, go-to-market and support (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is one launch where you can name the teams, the date pressure and your specific part. Selection scaffold: pick a launch or release with several teams involved where your role was clear to you; if no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define and track metrics that tell product teams whether something is working (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a figure you reported where you can say how it was counted and which part was yours. Selection scaffold: pick a number you reported to others and be ready for how it was counted, what it is sensitive to and the assumption you would defend least; if no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Improve or build processes and tooling that teams actually adopt (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process change with a named before, a named after and an honest account of who resisted. Selection scaffold: pick a process you changed or proposed and be exact about whether you designed it, ran it or supported it; if no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence without authority, including disagreeing with peers and saying no (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a disagreement with someone who did not report to you, with a stake and an outcome. Selection scaffold: pick a moment you held a position with an equal or a senior person and the relationship survived; if no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Bring customer and field feedback into product priorities (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is one case where customer input changed a decision and you can say how. Selection scaffold: pick an occasion where customer or user input and an internal target pulled apart; if no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

Requirement coverage: which question IDs cover which row.

| Requirement | Questions |
|---|---|
| F1 operating rhythm | A3, A5, C1 |
| F2 launch coordination | A1, B4 |
| F3 metrics | A2, D1, D2, D3 |
| F4 process and tooling | A3, A5, B3 |
| F5 influence without authority | B2, C1, C2, C3, E1, F2 |
| F6 customer and field feedback | E2 |
| Motivation and fit, not a JD row | A4, B2, G1, G2, F1 |

## Persona table

No loop source was available (see Sources), so these weights rest on relationship priors and are flat-leaning. They are the pack's best guess for a final round whose sessions are unknown; recalibrate if you know the schedule.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on launches, metrics, planning | High. The hiring-manager prior is Case/Strategist plus Skeptic, and a final round of a manager-level role most likely includes that session | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of day-one gaps, motivation and what "product operations" means | High, for the same hiring-manager prior | Rehearse B1 until it is boring; adjacent evidence only, with a concrete ramp plan; never bluff a competency |
| Peer Evaluator | Seam questions between product ops and neighbouring teams, credit and disagreement | Medium. A peer or cross-functional session is plausible in a multi-session final | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Asks how a number was counted and which assumption is weakest | Medium. Metric work is central to the role family, so probing is plausible in any session | Know what you can and cannot say about each figure; name the weakest assumption before they do |
| Values/Behavioral | Scenario probes, STAR-shaped stories | Low-to-medium. No loop source says there is a dedicated values round, so none is assumed, but behavioral probes ride inside many sessions | "We" for context, "I" for contribution; pick stories where the hard truth landed |
| Pressure | Time-boxed challenges, devil's advocate | Low-to-medium. More likely if a skip-level or executive session exists | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational | Friendly, unstructured, still scored | Low-to-medium. Present in any session as the opener or closer | A pre-scripted 90-second arc; never answer "I think you've covered everything" |

## Question banks

### A. Case/Strategist (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A cross-team launch is two weeks out. Engineering says it will land on time; support and sales say they have not seen what is shipping. What do you do in your first two days?" | CASE | [generic] | Clarify first: what "ready" means here, who signs off, what is known versus assumed. State the objective, split the problem by team and by risk, then the approach: one shared view of what ships, agreed readiness criteria with each owner, a go or no-go checkpoint. Name the metrics that tell you it is working and the main risk. Challenge one premise, such as whether the date or the scope is the fixed thing. This makes no claim about your past | Tests F2 as a live problem. CASE because it scores structure on a decision, not recall |
| A2 | "Pick one metric that tells you whether launches are landing well. What would you track, and what would make you distrust the number?" | CASE | [generic] | Name the decision the metric informs first, then one leading and one lagging measure. Say how it would be counted, what it is most sensitive to, and the assumption you would defend least, before they ask. If you do not know how a figure would be counted, say that plainly rather than inventing a method | Tests F3 and the weakest-assumption move. CASE because the metric is chosen live, not taken from a CV |
| A3 | "A product's weekly business review has grown to forty slides and no decision changes because of it. Redesign it." | CASE | [generic] | Clarify who attends and what decisions they own. Cut to the few questions the forum must answer, assign an owner to each, decide what moves to a written pre-read, and set how you would know the new format is working. Say what you would keep, not only what you would remove. This makes no claim about your past | Tests F1 and F4 on a familiar product-ops artifact. CASE because it is a redesign problem |
| A4 | "Why Stripe, and why product operations rather than product management?" | CO | [generic] | Give your own reasons in two or three sentences. Anchor the Stripe part in something you have personally used or read, and say which one; if you have not, say so and name what you have read. Keep the product-operations half about the work you want to do, not about what you are leaving. I have no verified facts about Stripe's strategy to offer, so none are supplied here | Motivation consistency is scored in nearly every final; links to no fit row. CO because it tests homework depth, with VAL overtones |
| A5 | "You can add one process to how product teams plan their quarter. What is it, and what do you remove to make room?" | CASE | [generic] | Pick one process and say the problem it solves. The removal answer carries the credibility: name what you would stop and who would feel it. Say how you would pilot it before asking everyone to adopt it. This makes no claim about your past | Tests F1 and F4. CASE because it forces a tradeoff rather than a wish list |

### B. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Choose a real gap from your own honest view of the role; do not choose a fake weakness. Name it in one sentence, then give a concrete ramp plan: who you would learn from, what you would read or shadow, what you would have done by day thirty. Hold through two follow-ups: first, "What if your manager does not think that is a gap?" then, "What would that cost us in the meantime?" Concede the cost specifically and return to the plan. If no gap comes to mind, say how you would find out in your first two weeks | Asked in some form in most manager finals, and the likeliest place a candidate sounds defensive. JD because it scores fit against the stated job, with Skeptic delivery |
| B2 | "Why are you looking to leave your current role, and why now?" | EXP | [generic] | Give your actual reason, in your own words, framed around what you are moving toward. If part of the honest reason is about what you are leaving, say it plainly without blaming people. Keep it consistent with your answer to A4 | A Skeptic probe on motivation consistency. EXP because the answer is your own reason, not a claim to verify |
| B3 | "Product operations is sometimes seen as project management with a better title. Convince me it is not, in sixty seconds." | JD | [generic] | Define the work in your own terms: what problem it solves for product teams, which decisions it improves, how you would know it is working. Concede the true part, that coordination is part of the work, then say what separates it. This makes no claim about your past | Tests whether you can define the role, which F4 depends on. JD because it scores role understanding, delivered as an objection |
| B4 | "You would join a team with habits that already work. What would you leave alone for the first month?" | CASE | [generic] | Say that you would learn the current rhythm before changing it, then name how: whom you would talk to, what you would observe, what would justify a change. Pick one thing you would leave alone and say why. This makes no claim about your past | Tests humility against change-agent instinct, relevant to F2 and F4. CASE because it is a judgment call on a live situation |

### C. Peer Evaluator (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product ops and product, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know this team's seam: ask what the current split is, say that you would write down who decides what, and say how you would handle a disagreement: restate their view, separate data from preference, agree who decides and by when, escalate rarely. This makes no claim about your past | Covers F1 and F5. JD because it scores how the role fits next to the peer's |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Give your principle first, in a sentence. If you have a real example where credit was shared in a way others would recognize, use it; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F5. VAL because the peer is scoring partnership behavior |
| C3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Use reciprocity: one or two things you would need, such as context and access to decision-makers, and one specific, modest thing you would offer in month one, stated as a proposal. This makes no claim about your past | The reciprocity question for a peer session. JD because it scores how the hire adds to the peer's work |

### D. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number from your past work that you reported to others. Walk me through how it was counted." | EXP | [generic] | Choose a figure you can speak to. Be ready for four follow-ups, answered in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say that plainly. Do not offer a method you cannot repeat under a second question | Covers F3; the pack's defend-the-number rehearsal. EXP because it tests attribution and honesty about the figure |
| D2 | "A dashboard shows adoption of a new feature up thirty percent week on week. Before you tell anyone, what do you check?" | CASE | [generic] | Check the definition and the denominator, whether the period is comparable, whether instrumentation or a population shift changed, and whether the move is concentrated in one segment. Then say what decision the number would change. This makes no claim about your past | Covers F3 as a live diagnostic. CASE because the interviewer supplies the figure |
| D3 | "Walk me through an analysis you ran yourself, from the question to the decision it fed." | EXP | [generic] | Pick one you can walk end to end: the question, the data, the choices, the result, the decision. If part of it was not yours alone, say which part was; if none was truly yours, say so plainly and describe the nearest work you did carry | Covers F3. EXP because it tests whether the work was yours |

### E. Values/Behavioral (weight: low-to-medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften the message, and a relationship that was intact afterward. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F5. VAL because the answer must show a behavior, not state a virtue |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick an occasion where the customer need and an internal target pulled apart, say what you did and what it cost, and be exact about your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F6. VAL because it separates a real decision from a slogan |

### F. Pressure (weight: low-to-medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate the question. Anchor the answer in what you actually have done and can discuss, in your own words. Hold the position through two follow-ups, then concede specifically what an internal candidate would know that you would have to learn. Do not fold on the core claim to restore harmony | Pressure-persona prior; tests composure more than content. JD because it scores fit for the role |
| F2 | "That result you just described: how much of it was actually you?" | EXP | [generic] | Hold-then-concede. Separate the team's work from yours, name exactly what was yours, concede the parts others did, and if the honest share is modest, say so. A precise small claim beats a large one that breaks under the next question | The attribution probe that follows any story. EXP because it tests what was the candidate's |

### G. Conversational (weight: low-to-medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc: where you started, the two or three moves and what each moved you toward, and why this role now. Every beat should come from your own CV and be something you can expand on. Send the CV and I will map the beats to its lines | Casual openers are still scored. EXP because it previews every claim that follows |
| G2 | "Is there anything about your background we have not touched on that you would want us to know?" | EXP | [generic] | Prepare one thing in advance: the strongest piece of your real experience that the conversation has not surfaced. If nothing comes to mind, say you would rather use the time for your questions, and ask your best one | Answering "I think we covered everything" wastes a scored slot. EXP because it invites an unprompted claim |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a great first ninety days look like in this role, and what would disappoint you?" | Shows you are thinking about outcomes, and gives you the interviewer's own bar to prepare against |
| R2 | "What does product operations own here, and what stays with product management and engineering?" | Surfaces the seam the peer questions probe, and shows you want it explicit |
| R3 | "Which of the team's recurring forums or processes are working well, and which would you change first?" | Signals you plan to learn before changing, and tells you where the real problems are |
| R4 | "How does the team decide whether its own work is succeeding?" | A product-ops candidate who asks about measurement signals the metric mindset the role needs |
| R5 | "What is the hardest tradeoff the team has faced recently, and how was it settled?" | Invites a real story instead of a pitch, and shows how decisions get made |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer session; converts evaluation into collaboration |

## Prohibited claims

None built. There are no sentences from you in the material, so there is no wording to stretch and no negative you stated. When you share a CV or answer an answer slot, entries arrive here with their honest forms. Until then, nothing in this pack asserts what you did: every guidance cell is a method, a structure or a selection scaffold ending in an honest branch.

## Sources

Provided documents: none. Your message gave the company, the role and the round only.

Searches sent, each refused (the host did not grant search permission, so nothing came back):

- Stripe operating principles values: refused
- Stripe interview process product operations manager final round: refused
- Stripe strategy news 2026 annual letter: refused
- Stripe Product Operations Manager job description: refused

Fetches: none. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have given the official principle names and a values cheat sheet; no section 10 is built and no value is named in this pack |
| 2. `Stripe interview process product operations` | unavailable | Would have fixed the loop structure and persona weights; weights rest on relationship priors, and no archetype is asserted for Stripe |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current priorities; A4 is the only CO question and it is generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned the fit snapshot's requirements into quoted, `[inferred]` rows; they are role-family prose instead |

## Upgrade menu

- The job description text → the six `[generic]` requirement rows become `[grounded]` quotes, and each JD-tagged question gains a raising source for its guidance
- Your CV, or the lines you would lean on → the fit snapshot's evidence column fills with your own sentences, the worksheet guidance becomes story-mapped answers, and the prohibited list gains real entries
- Who you are meeting and in what relationship → persona weights recompute and whole banks are added or dropped
- If your final is several sessions, the schedule → per-session mini-packs with their own weights and reverse questions
- The recruiter's prep email, including any declared presentation or take-home → a graded-deliverable build section, which this pack does not have because none was declared to me
- Web search permission → Stripe's published values, documented interview loop, recent strategy and a representative JD, which would add a values cheat sheet if a values round is documented and ground the CO bank; a deeper pass of up to 6 further searches and 2 further fetches, taking several more minutes, would add a strategy brief and interviewer and loop reports
- An interviewer name, if you have one → an interviewer read and a reverse question tied to their own path
- A `tuesday-dossier.md` from an earlier evidence-recovery session → verified claims, an evidence-derived top objection and absolute prohibited claims, in place of this pack's inferred ones
