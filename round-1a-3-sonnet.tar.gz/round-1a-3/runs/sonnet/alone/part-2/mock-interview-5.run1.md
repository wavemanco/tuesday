Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-5-denied-3015bba7/Kelverton-Rail_senior-partnerships-manager_interview_pack.md`. It has 18 questions across five panel styles, a build guide for the 15-minute POV, reverse questions, and a four-hour schedule.

I built it from your message alone, for a two-person panel. Deepa is treated as hiring manager (strategy and skeptic questions) and Ross as commercial (number-probing and pressure). Three things are missing, and the pack says so:
- **Market report:** it didn't arrive in this conversation, so nothing in the pack is drawn from it. The POV guide tells you to bring one of its shortlist items as proof you've read it, then diverge from the rest.
- **Web research:** the search permission was refused, so all six searches failed. There is no read on Deepa or Ross, and no check of Kelverton's strategy or interview process.
- **JD:** none was supplied, so the requirements are quoted from the recruiter's email.

The highest-value prep is C1: "You've never sold into rail and never carried a direct quota. What makes you the right person?" Both panelists can see those two gaps from your own words. The pack has you acknowledge them plainly, then use your consulting and ISV channel sentences only at the scope you gave them. The "Prohibited claims" section lists what the pack won't coach, such as implying you've sold into rail or closed the £4M yourself.

Say the word and I'll play Ross on C1, then B1 (the £4M defence). I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the JD text, or tell me to carry on without it? With it, the quoted requirements replace the recruiter-derived ones and any gate such as location or travel gets its own row.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday, 60 minutes, panel of two.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Source: the recruiter's email, as you quoted it.
**Format, per the recruiter:** first 15 minutes, you present a short POV on where you would take Kelverton's operator partnerships over the next 18 months, no slides. The rest is Q&A, and "Ross will push on commercials."
**Built on:** your message only. There was no JD, the market report did not arrive in this conversation, and web research was not permitted, so nothing here is drawn from Kelverton's own materials.

## How to use this pack

Personas say how a question will be asked. Types say what it is scoring. Every question carries one persona (its bank) and one type tag.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Say it in your own words. Where a cell says answer slot, it is an instruction for the interview: answer from what you actually did, or say plainly it was not yours or did not exist.

## Prep triage (about four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 60 min | Build and speak the POV aloud three times, timed to 12 minutes with three spare. Record once and listen for the concession in each thesis | Section: Graded deliverable |
| 2 | 45 min | Say the answer to C1 aloud until the plain acknowledgment in it sounds boring. Then D1 | C1, D1 |
| 3 | 40 min | Write down, in your own words, how the £4M and the 6 to 40 were counted and what you do not know about either. Then say B1, B2 and D2 aloud | B1, B2, D2 |
| 4 | 30 min | Structure-only run of A1, A3 and B3: clarify, objective, approach, measure, what you would give up | A1, A3, B3 |
| 5 | 25 min | Time your E1 arc to 90 seconds. Pick three reverse questions | E1, Reverse questions |
| 6 | 40 min | Live drill with me, C1 first, then B1 | Drill offer |

Everything else in this pack is insurance.

## Fit snapshot

No JD was supplied, so requirements are quoted from the recruiter's email. F4 is a role-family requirement with no source, written as plain prose. There was no JD, so the pack has not checked for a gate such as location or travel; if the JD names one, it becomes its own row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, 6 partners to 40, and nothing about operators or rail partnerships, with nothing inspected behind it. Words at the sentence's scope: "For the last four years I ran the ISV channel at a payments company, and I took it from 6 partners to 40." Answer slot: the recruiter's "operator partnerships" makes a probe on how that channel compares likely. If any part of your ISV work resembled what operator partnerships will involve, say which part and what you did, in your own words; if none did, or it was not yours, say so plainly and stay with the channel |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning in consulting. It does not say which operators, or what "the other side" covers, and nothing is inspected behind it. Words at the sentence's scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter's ask makes a probe on what you know of operators' own priorities likely. If your consulting work was with operators directly, say who and what part was yours, in your own words; if it was not, or none of it was yours, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials." — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Your material says roughly £4M of influenced revenue and a stated absence of a direct quota, nothing inspected behind the figure. Words at both: "My figure is roughly £4M of influenced revenue, and I haven't carried a direct quota." Answer slots for the figure, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and what part was yours. If you do not know how it was counted, say so plainly |
| F4 | Credibility with rail operators from outside the sector (role-family requirement, no source supplied) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past: whom you would talk to first and what you would find out. Never a claim to rail sales, and nothing added to make the gap feel smaller |

## Graded deliverable: the 15-minute POV

The recruiter's brief, quoted: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." and "Please land on what it means for the operators themselves."

**Facts you can build on.** Each is a fit-snapshot row and its quoted sentence.

- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- F4: "Never sold into rail specifically and never carried a direct quota, only influenced revenue."

**One assumption to state aloud in the first minute.** Your material does not say whether "operator partnerships" means operators as customers, as co-development partners, or both. Say which you are assuming, and that you would confirm it. This is a pack observation, not a fact about Kelverton.

**Differentiation from the market report.** The report is shared with every candidate and with the panel, so reciting it scores as homework. The pack has not seen it. Do this: bring one item from the report's own shortlist, named as the report's, to show you have read it; then diverge with one thesis below and say why. Do not spend more than two minutes on the report's items.

**Timing.**

| Minutes | Content |
|---|---|
| 0:00 to 1:00 | Frame, and the stated assumption about operator partnerships |
| 1:00 to 3:30 | One report item, then where you depart from it |
| 3:30 to 9:30 | Two theses from the table, each with its concession |
| 9:30 to 11:30 | The anti-pick |
| 11:30 to 14:00 | Land on the operators: what changes for an operator, how soon, how they would know |
| 14:00 to 15:00 | Spare. Stop early rather than run over |

**Theses.** Choose two. Each is a position for the next 18 months, offered as a hypothesis, not a finding about Kelverton or about operators.

| Thesis | What it means for the operator (your close) | Mandatory concession | Provenance |
|---|---|---|---|
| T1: Judge each partnership by what changes in the operator's own operation, on the operator's own measure, not by partner count | An operator can name one thing that is better in their own operation, measured their way | It is a hypothesis. You would test it with operators and Kelverton's own data before committing to it | [generic] |
| T2: Fewer, deeper operator partnerships before wider ones | Operators with a real say in priorities, rather than being one of many | Depth costs reach, and F1's quoted sentence is about growing a count, 6 partners to 40. Expect Ross to ask why depth is right here, and say so before being asked | [generic] |
| T3: Open the operator partnerships to ecosystem partners that make the software more useful to operators, derived from F1's ISV channel | Operators get more from the software without Kelverton building all of it | It adds partner-management load and may not fit how operators buy. "I haven't sold into rail specifically" belongs in this concession | [inferred] |

**The anti-pick.** Do not make partner count, or partner-sourced revenue, the headline 18-month goal. Concession: Ross will want a number. Offer the commercial measure you would report, and say plainly that your figure is influenced revenue and that you have not carried a direct quota.

**The close.** Last 90 seconds: one sentence per chosen thesis naming what an operator sees, how soon, and how they would know. The recruiter asked for exactly this.

## Persona table

The loop is set by the recruiter's email: one 60-minute panel session, a POV and then Q&A. No archetype fallback is used. Weights rest on the recruiter's description of the two panelists, not on any public footprint, since research was not available.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (Deepa) | Pushes on the POV, asks you to choose, sequence and measure | High. The recruiter calls Deepa your future manager, which tilts toward Case plus Skeptic, and the first 15 minutes are a strategy talk | Clarify, objective, approach, measure, risk. Challenge one premise respectfully. Bank A, 5 questions |
| Data-Driven Prober (Ross) | Takes each number to how it was counted | High. The recruiter says Ross will push on commercials, and F3's figure is a number | Know what you can and cannot say about how each figure was counted, and name the weakest assumption before Ross does. Bank B, 4 questions |
| Skeptic (Deepa and Ross) | Quiet, persistent probing of the gaps | High. F4 is a stated negative both panelists can see | Rehearse C1 until it is boring. Bridges from F1 and F2 only, at their scope. Bank C, 4 questions |
| Pressure (Ross) | Time-boxes, interrupts, "how much was actually you" | Medium. Commercial Director plus "push" suggests it; the recruiter did not say stress | Pause, restate, hold through two follow-ups, concede specifically. Bank D, 3 questions |
| Conversational | A friendly opener or a casual question that is still scored | Low. The recruiter's format starts straight into the POV, but the biography question is common enough to prepare. Bank E, 2 questions | A 90-second arc built only from your two background sentences |

No Peer bank, since no peer is on the panel. No Values bank, since nothing documents a values round for this loop.

## Question banks

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've got eighteen months. If you could only run one operator partnership motion, which would you run and why?" | CASE | [grounded] | Pick the thesis from the POV section you can defend longest. Structure: the motion; what changes for the operator and how soon; the measure you would report; what you would give up by choosing it. Say it as your position for the next 18 months, not as something you have done. The question needs no claim about your past, so the guidance makes none | The natural follow-on from the POV the recruiter asked for. CASE because it forces a choice, and the recruiter's own words are its source |
| A2 | "Two operators want opposite things from the same partnership. Who do you build around?" | CASE | [generic] | Clarify first: what each wants and what the partnership is for. Then the criteria you would use, what you would say to the operator who does not get their way, and what you would watch afterwards. Structure only | A live-problem form of the operator focus. Generic because it is a pattern for the role, not a fact about Kelverton |
| A3 | "In eighteen months, how would the operators themselves know they were better off?" | JD | [grounded] | Name the operator-side signal you would look for, said as a plan. Then say the one thing you would need to learn from operators before you could set it. Say that the measure is a hypothesis you would test with them. No claim about your past | The recruiter asked the POV to land on the operators, and this is the interviewer's version of that ask |
| A4 | "What do you think operators weigh when they choose a scheduling supplier, and where does a partnership change that?" | CO | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Offer a hypothesis and label it as one. If pressed on how you know, use the words the sentence gives: "I haven't sold into rail specifically." Then say how you would test the hypothesis with operators. Do not describe how operators buy from experience; your material does not carry that | CO, generic in content because no strategy source was in hand. F4's stated negative is the limit on the answer |
| A5 | "Sketch your first ninety days. What would you need to find out before committing to anything?" | CASE | [generic] | Clarify, then the objective, then whom you would talk to first, then what you would decide at day thirty and at day ninety. A plan only | Deepa, as your future manager, is pricing the ramp. CASE because it asks for structure |

### Bank B: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "That £4M of influenced revenue. Walk me through how it was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say what the figure is in the sentence's own terms: roughly £4M, influenced revenue. Answer slots, each in your own words: how it was counted; what it is most sensitive to; which assumption behind it you would defend least; which part of it was yours. If you do not know how it was counted, say so plainly and say what you would check. Name the weakest assumption before Ross does | The headline figure, in front of the Commercial Director. F3. EXP because it tests attribution |
| B2 | "Six partners to forty. How was a partner counted, and what was your part in the move?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slots, each in your own words: what counted as a partner; what the count is sensitive to; the assumption you would defend least; what part was yours. If part of it was not yours, say so plainly and return to the sentence: you took the channel from 6 partners to 40 | The second headline number. F1. EXP because it tests attribution |
| B3 | "How should we think about the economics of a partnership here: who gains what, and how do we measure it?" | CASE | [generic] | Ask first what the partnership is, customer, co-development or both, because the economics differ. Then the value to each side, how each side's gain is measured, and what you would not count as success. Say you would need Kelverton's own commercial model before settling numbers. Structure only | The recruiter's "Ross will push on commercials", which sources F3. CASE because it asks for structure on a live problem |
| B4 | "You've said your figure is influenced revenue. What would change for you carrying a direct number here?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Start with the plain acknowledgment: "I haven't carried a direct quota; my figure is influenced revenue." Then, as a plan, what you would want to understand about how a number is set here before accepting one. Do not present the influenced figure as the same thing | F3's second half. The premise is your own stated negative, so it is asked as stated |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail and never carried a direct quota. What makes you the right person to take our operator partnerships forward?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The highest-ROI prep in this pack. Three moves, in order. One, the plain acknowledgment, first and unhurried: "I haven't sold into rail specifically, and I haven't carried a direct quota." Two, what you have, at the quotes' own scope: "I spent five years in transport consulting, in bus and light rail network planning," and "For the last four years I ran the ISV channel at a payments company, and I took it from 6 partners to 40." Three, the plan: whom you would talk to first and what you would learn. Answer slot: if any of the consulting work was with operators directly, say who and what part was yours, in your own words; if not, say so plainly and stay with the planning work. Likely follow-ups, held then conceded. If bus and light rail is set against train operating companies, concede plainly that your planning work was bus and light rail. If consulting is set against selling, concede, and return to the channel sentence. If influenced revenue is set against a direct quota, concede, and return to B1. Never argue that the gaps do not matter | Built from F4 and F3's stated negatives, which both panelists can see, so it will arrive in some form. JD because it scores whether you can do the job as listed. Deepest rehearsal because it is aimed where the material is thinnest |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose the weakness you have already said plainly rather than a smaller invented one: "I haven't sold into rail specifically." Then the ramp, as a plan: the first conversations and what you would want to understand before proposing anything. If a different gap is truer for you, name that one in your own words | The Skeptic's standing probe, and an honest answer is the only safe one. F4 |
| C3 | "Why leave payments for rail?" | EXP | [generic] | Give your own reason in two or three sentences. A strong reason names something about this role, not only something you are leaving. If your reason is mixed, say it is mixed. No reason is supplied here, because your material does not state one | Motivation consistency, the Skeptic's why-leave probe. EXP because it tests your own account of your path |
| C4 | "Tell me about the transport consulting years. What was your part?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The beats are the ones the sentence states: five years, transport consulting, bus and light rail network planning. Tell them in your own words and in that order. The last clause is yours to explain: say what "the operator world from the other side" means in practice for you, keeping to what you did. Answer slot: which part of the planning was yours; if it was a team's work or not yours, say so plainly and stay with the planning work | The panel will test the "other side" clause. F2. EXP because it tests attribution |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Restate the question, pause, then hold only what the quote carries: "For the last four years I ran the ISV channel at a payments company, and I took it from 6 partners to 40." Concede the rest plainly: "I haven't sold into rail specifically." Hold through two follow-ups by returning to the channel sentence, never by adding to it. Make no comparison with other candidates | Time-boxed pressure from the Commercial Director. F1 and F4. JD because it tests fit to the listed role |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold: the figure in its own terms, roughly £4M of influenced revenue. Concede specifically where the sentence stops: it is influenced revenue, and "I haven't carried a direct quota." Then the four slots from B1, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, what part was yours. If you do not know how it was counted, say so. At the second follow-up, repeat rather than elaborate | The pressure form of B1. F3 |
| D3 | "I'd push back on your lead thesis. Defend it in a minute." | CASE | [generic] | Restate the objection in one sentence. Hold your thesis through two follow-ups by giving the reason you chose it, not by adding evidence you do not have. Concede the specific point you cannot yet answer, and say how you would test it. No claim about your past | Tests composure on the POV itself, the part Deepa and Ross both heard |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc made only of the two sentences' beats, in this order: five years in transport consulting, bus and light rail network planning; then nine years in partnerships, the last four running the ISV channel at a payments company, 6 partners to 40. Close with why this role, in your own reason, kept to a sentence. Your material does not state a reason | The biography opener is common and is scored. F1 and F2. EXP because it is the CV account |
| E2 | "What are you actually thinking about in operator partnerships these days?" | CO | [generic] | Pick one live question you are genuinely curious about and tie it to your POV. Say it as a question you are working on, not as a finding. Treat it as scored | A casual question on the role's own topic. No claim about your past |

### Requirement coverage

No JD was supplied, so this maps the recruiter's stated asks. The JD's own list has not been checked.

| Requirement (source) | Questions |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | A1, A2, A5, D3, E2, and the POV section |
| "Please land on what it means for the operators themselves." — recruiter's email | A3, A4, and the POV section's close |
| "Ross will push on commercials." — recruiter's email | B1, B2, B3, B4, D2 |
| Credibility with rail operators from outside the sector (role-family, no source supplied) | C1, C2, C3, C4, D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When you say operator partnerships, which relationships do you mean: operators as customers, as co-development partners, or both?" | It tests your assumption from the first minute of the POV, and shows you would not presume |
| R2 | "What does a good first six months look like for whoever holds this role, and how will you judge it?" | Deepa is your future manager, and the answer tells you the real measure of success |
| R3 | "How do you want partnership revenue counted here: attributed, influenced, or something else?" | It meets Ross's commercial lens directly and shows you take measurement seriously |
| R4 | "Which operator relationship would you most want this role to change, and what is in the way today?" | It turns the conversation to the work and shows you are thinking at the level the recruiter asked for |
| R5 | "Which finding in the strategy team's report are you least sure of?" | It shows you read it as a document to test, not a source to recite |
| R6 | "What would make you regret this hire a year from now?" | It surfaces the concern behind the gaps in F4 before it goes unspoken |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | The plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Has carried a quota | Negative you stated, F3 and F4 | "I haven't carried a direct quota; my figure is influenced revenue." No slot |
| Closed or personally held the £4M | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: your material says influenced revenue, not closed revenue |
| Advised train operating companies | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning, not train operators or rail scheduling |
| Personally built every one of the 40 partnerships | Inflated form of F1 | F1's quote at its own scope: the channel went from 6 partners to 40. B2's slot stays on what your part was |

## Sources

**Provided documents:** your message, which includes the recruiter's email as you quoted it. The market report was mentioned as attached; it did not arrive in this conversation, so nothing from it is used. No tuesday-dossier.md was present.

**Searches sent, all refused:**

- "Kelverton Rail values" — refused
- "Kelverton Rail interview process partnerships manager" — refused
- "Kelverton Rail strategy news train operating companies scheduling software" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Ross Commercial Director Kelverton Rail" — refused
- "Senior Partnerships Manager rail technology job description train operating companies" — refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have fed a values cheat sheet, but only if a loop source documented a values round; none does, so it might have moved nothing |
| 2. Interview process, partnerships | unavailable | Would have tested the persona weights against any documented loop; the weights rest on the recruiter's email alone |
| 3. Strategy and recent news | unavailable | Would have grounded the CO questions and the POV in current priorities; A4 and E2 are generic instead |
| 4. Interviewer names with the company | unavailable | Two queries, both refused. Would have supplied an interviewer read and a reverse question tied to each panelist's path; both are absent |
| 5. Representative JD | unavailable | Would have supplied quoted requirements for the fit snapshot; rows rest on the recruiter's words instead |

## Upgrade menu

- The market report's shortlist and headline findings, pasted → a grounding brief in the report's own vocabulary, a POV differentiation built against its actual items, and the generic CO questions (A4, E2) become grounded
- The JD text → the quoted requirements replace the recruiter-derived ones, the coverage table closes against the JD's own list, and any gate such as location or travel gets its own row
- Web search permission in this session → an interviewer read for Deepa and Ross from their public footprint, a reverse question tied to each path, and a documented loop to test the persona weights against; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and is yours to ask for
- The report or dashboard the £4M and the 6 to 40 were counted in, or a note on how they were counted → F1 and F3 confidence can rise from medium to high, and the slots in B1, B2 and D2 can be answered from your own record
- Your CV or LinkedIn text → more quoted sentences, and F1 to F3 may move from transferability to presentation where a line already reaches the requirement
- Your typed answers to the answer slots in F1, F2, C1 and C4 → those rows and banks regenerate from your own words
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a prohibited-claims list that would replace the locally built one
