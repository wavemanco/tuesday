I'll start by reading the skill's reference files.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-3-denied-d494cb3b/Stripe_product-operations-manager_interview_pack.md`.

I built it for a final round with an unknown format and interviewer, so the persona weights are blended. I had no JD or CV, and web search was refused (permission not granted). The pack therefore has no Stripe-specific facts. Its requirements are generic role-family patterns, and all 22 questions are labeled generic. The guidance coaches structure and honest selection of your own stories, not stories for you. The pack's Sources section lists each refused search and what it would have added.

Say the word and I'll play the Skeptic on B2, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in the final round and in what format, and has the recruiter given you any focus areas or asked you to prepare anything in advance?

Can you paste the job description and your CV, or tell me to go ahead without them?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not known. Relationship: not known. Built as a blended final-round pack from your message alone. No JD, no CV and no research were available, so every row below is labeled for what it rests on, and your own experience appears nowhere in it except as a slot for you to fill.

## How to use this pack

Personas describe how a question is asked: who is asking and in what style. Types describe what is being scored. Every question carries both, so you can rehearse the delivery as well as the content.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The stated role: can you do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. With no CV supplied, the guidance cells coach structure and selection, never a story about your past. Anything about what you did has to come from you, in your own words, from what really happened.

## Fit snapshot

No JD was supplied, so these requirements are role-family patterns written as plain prose, not quotes from a posting. With no background supplied, this is the worksheet variant: every evidence cell reads none given.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or programs across product, engineering and go-to-market teams (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be one of your own sentences naming a cross-team launch or program, the teams it spanned and which part was yours. Selection scaffold: pick one cross-team effort where you can separate what you were responsible for from what the group did; if no such effort comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing or improving operating processes and cadences such as planning, reviews or launch checklists (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a sentence of yours describing a process you set up or changed and what changed after it. Selection scaffold: pick a process where you can say what it was before, what you did to it, and what you saw change; if no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using data and metrics to run and inspect product work (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a sentence of yours naming a metric you tracked, how it was counted and what you did with it. Selection scaffold: pick a number you can explain end to end, including the assumption you would defend least; if no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing partners such as product managers, engineers and leaders without direct authority (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a sentence of yours about a disagreement or a request you moved without authority, and how the relationship stood afterwards. Selection scaffold: pick a case where you can say what you wanted, what the other side wanted and what happened; if no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizing and structuring ambiguous problems (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a sentence of yours about a problem you were handed without a clear shape and how you framed it. Selection scaffold: pick a problem where you can name the choice you made and what you gave up; if no such problem comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Understanding the company's products, customers and current priorities (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be homework you have done yourself and can speak to from your own reading. This pack could not research the company, so it supplies no facts about it. Selection scaffold: pick two or three things you have actually read or used and what each made you think; if nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

The relationship to your interviewers is unknown and no loop source was read, so the weights rest on a pattern, not on Stripe's documented process: a final round can arrive as one conversation or several, and this pack does not assert which. Weights are blended from the relationship priors in the persona model; send the schedule and they will be recomputed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A, 5 questions) | A live problem from the role: plan this, diagnose that | Highest. A hiring manager is the most likely final-round owner of this role, and that prior favors Case/Strategist | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic (bank B, 4 questions) | Quiet probing of motivation and of the biggest stretch | High. The same hiring-manager prior pairs it with Case, and a final round is where gaps get tested | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Peer Evaluator (bank C, 3 questions) | Seam-splitting with adjacent teams, credit, what you would need from them | Medium. Product operations sits between teams, so a peer or cross-functional interviewer is plausible in a multi-session final | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Conversational (bank E, 3 questions) | A friendly opener and an open slot at the end | Medium. Opening and closing conversation is likely in any format and is still scored | A prepared 90-second arc; never answer the reverse-question slot with "I think you've covered everything" |
| Pressure (bank G, 3 questions) | Time-boxed challenges, devil's advocate | Medium. A skip-level or executive interviewer tilts toward it, and the schedule is not known | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (bank D, 2 questions) | Scenario probes mapped to published values | Lower here. No loop source was read, so no values round is assumed, and no published values were read to map against | Choose stories where the hard truth actually landed; where none comes to mind, say so |
| Data-Driven Prober (bank H, 2 questions) | Line-by-line questions on numbers and assumptions | Lower. It rises sharply once a CV exists with figures on it | Know how each figure was counted and say plainly when you do not |

## Question banks

IDs run by persona. There is no bank F, so question IDs never collide with the fit-snapshot rows F1 to F6. No CV or JD was supplied, so every row below is labeled generic and no guidance makes a claim about your past.

Highest-ROI prep in this pack: B2. It is chosen from the round-type prior, not from a gap in your material, because no material was supplied. A CV would replace it with the objection your own background most invites.

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 cross-team launches and programs | A1, A4, C2 |
| F2 operating processes and cadences | A2, H2 |
| F3 data and metrics | A3, H1, H2 |
| F4 influence without authority | A4, C1, C2, D1, G3 |
| F5 ambiguity and prioritization | A4, B2, B3, D2 |
| F6 company and products | A5, B1, D2 |

These requirements are role-family patterns, not a JD, so this table is re-keyed when a JD arrives.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch has slipped twice in a quarter, and three teams each say the dependency sits with someone else. What do you want to know first, and what do you do in the first week?" | CASE | [generic] | Clarify before structuring: what slipped, against which date, who signs off on done, what has already been tried. Then objective, who is involved, approach for week one, a metric that shows the slip is closing, and the main risk. Think aloud and name one premise you would test. The question asks about no past, so the guidance makes no claim about yours | A live coordination problem of the kind F1 describes, delivered as a decision. CASE because it scores structure, not history |
| A2 | "Sketch how you would set up a launch process for a product line that has none. What do you need to know first?" | CASE | [generic] | Open with what you would ask: who launches, how often, what has gone wrong, who is affected. Then the minimum process that would help, how you would get the teams to use it, and how you would tell it was working. Say the framework aloud before using it. No claim about your past is needed or made | F2's requirement, asked as a design problem. Using the persona's own stem keeps the question premise-free |
| A3 | "A key metric for a product you support drops 20 percent week over week. Diagnose it." | CASE | [generic] | Clarify the metric's definition and the window first, then split into data problem, real change in behavior, and a change you caused. Name the cuts you would look at and the order, and say what would make you stop and escalate. State which assumption you would check first | F3's requirement as a live diagnosis. The persona stem gives the theme, so nothing about your past is presupposed |
| A4 | "Two product teams each ask for the same limited operations capacity this quarter. How do you decide, and who do you tell?" | CASE | [generic] | Ask what each request is for and what happens if it waits. Then a stated rule for deciding, who owns the final call, and how you tell the team that loses so the relationship holds. Challenge one premise, for example whether the capacity is really fixed | F4 and F5 together, set in the role's own seam between teams. CASE because the answer is a method |
| A5 | "What do you see as the biggest challenge Stripe's product organization has to operate against right now, and where would product operations help?" | CO | [generic] | This pack could not research the company and will not supply facts about it. Prepare two or three points from material you have actually read, say where each came from, and tie one to what product operations does. If you have not formed a view, say what you would want to learn first and how you would learn it | F6's requirement. The honest cost of no research is that this question stays generic, and the guidance is your own homework, not a script |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why product operations rather than product management, why Stripe, and why now?" | JD | [generic] | Motivation consistency is scored: three short answers that point the same direction. Give the real reason for the function, the real reason for the company, and the real reason for the timing, each in your own words. If a reason is partly about what you are moving away from, say so plainly and put the pull toward this role first. Do not use company facts you have not read yourself | The standard motivation probe at a final round, covering F6. JD because it tests fit with the stated role, not a past event |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Pick a real weakness you can name specifically, say why it is a gap, and give a concrete ramp in the first two weeks and the first month. Prepare three follow-ups: what would you do in your first two weeks about it, how would I see that it is improving, and what if that is exactly what the team most needs. If no clear weakness comes to mind, say what you would verify first and who you would ask. Calibrated candor beats bluffing | The most predictable objection in some form, chosen from the persona stem because no CV exists to aim it. Deepest rehearsal: three follow-up levels and a limit named before it is asked for. JD because it tests the role's requirements including gaps |
| B3 | "Walk me through how your background gets you to this role. Where is the biggest stretch?" | EXP | [generic] | Name the stretch yourself before the interviewer does, then say what you would do about it. Use only what really happened, in your own words. If you cannot name a clear stretch, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 to F5 are all unevidenced here, so a probe on fit is likely. EXP because the answer must survive cross-examination |
| B4 | "What would make you decide, six months in, that this role is not right for you?" | JD | [generic] | Be specific about what you need from the work and the team, and honest about it. An answer that is too perfect reads as unexamined. Say what you would do before deciding, such as raising it with your manager. The question asks about no past | A motivation-consistency probe from the Skeptic's usual territory. JD because it tests whether the real job matches your expectations |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: who owns the decision, who owns the follow-through, how you escalate. Show spine and tact together by saying how you would disagree and how you would keep the relationship afterwards. Ask what the seam looks like today before proposing anything | F4's requirement in the persona's own stem. The question asks about no past |
| C2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick cross-team work where you can separate what the group did from what you did, using we for context and I for your contribution. Say how credit was shared in practice. If no such work comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F1 and F4, and probes attribution honesty. Peers ask it because credit disputes land on them |
| C3 | "What would you need from me in your first month, and what would I get from you?" | JD | [generic] | Reciprocity first: what a peer team gets from a product operations manager, in terms of their load, then what you would need to learn from them. Keep both concrete and modest. Do not promise outcomes before you know the team | The reciprocity question the persona model asks for when the interviewer may be a peer. JD because it scores the role's working relationships |

### D. Values/Behavioral

No published values were read, so these questions use the persona's own stems and no values are mapped.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where there was a named stake, a moment you did not soften it, and a relationship still intact afterwards, and choose one where the hard truth actually landed. Use I for what you said and we for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's requirement, scored as behavior. VAL is the persona's own type; without published values the question tests the habit, not a named value |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a specific decision where the two pulled apart, what you chose and what it cost. Say what you knew at the time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Touches F5 and F6 through a decision under tension. VAL because it scores behavior, not familiarity |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in three beats: the thread that connects your roles, the point that turned you toward product operations, and why this role now. Each beat must come from your own account, in your own words. If no thread comes to mind, say so plainly and start from what you are doing now | The casual opener is scored. It will be rebuilt around your own sentences when a CV arrives |
| E2 | "What have you been reading or trying lately that has changed how you think about running product work?" | JD | [generic] | A casual question about a hot topic for the role. Name one real thing, what it was, and what it changed in how you think. If nothing specific comes to mind, say so plainly and say what you plan to look at next | Covers F5 loosely. Rapport-style interviewers score this as genuine interest |
| E3 | "Do you have any questions for me?" | CO | [generic] | Use the reverse questions below. Choose three, ordered by how much the answer would change your decision. Never answer that you think they have covered everything | This slot is weighted heavily by rapport-style interviewers. CO because good questions show homework |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate the question. Hold the position through two follow-ups: say what you would bring in terms of how you would work, anchored in what you can state from your own account. Concede specifically that you do not know the internal slate or the team's history, and do not fold on the core claim to restore harmony | Tests composure, not content. The hold is only what your own account can carry, and none was supplied |
| G2 | "Pick the result you are proudest of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede: say plainly what was yours, with we for context and I for your contribution. Hold that position through two follow-ups, then concede exactly what others did. If you cannot separate your part from the group's, say so plainly, then give the nearest thing your material does carry | Attribution honesty is what this probe scores, and it is the likeliest Pressure question for any candidate with a results-led background |
| G3 | "Product operations is overhead. Why does a product org need you?" | JD | [generic] | Pause, then hold: concede what is true, that badly designed process is overhead, and say what would make it not be. Define value by what you would measure and what you would stop doing. Hold through two follow-ups without turning defensive | F2 and F4 as a position to defend. JD because it scores the case for the role |

### H. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Pick one figure you would put on your résumé. Walk me through how that number was counted." | EXP | [generic] | Pick a figure you can explain end to end. Four things to be ready to say in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how a figure was counted, say that plainly. Name the weakest assumption before the interviewer does | F3's requirement and the standard defend-the-number probe. Once a CV with figures exists, this becomes one question per headline figure |
| H2 | "What metrics would you put on a product operations function in its first six months, and which would you refuse to be measured on?" | JD | [generic] | Pick two or three measures, say what each is meant to show and how it could be gamed, and name the one you would refuse and why. State the assumption you would defend least. The question asks about no past | Covers F2 and F3 and tests whether you know your own assumptions |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first ninety days look like for this role, and what would make you say it was off track by day sixty?" | Shows you are thinking about the work and the bar, and the answer tells you what the team really needs |
| R2 | "Where does product operations end and product management begin here, and who decides when the line moves?" | Surfaces the seam directly, and a good answer shows how the team handles disagreement |
| R3 | "What did the last person to hold this kind of responsibility, or the team before this role existed, find hardest?" | Invites an honest account of the real problem, and rapport-style interviewers weight a considered question here |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer. It shows you are thinking about what you bring, not only what you need |
| R5 | "How does product operations get measured here, and has that changed recently?" | Ties to the metrics bank (A3, H2) and tells you what you would be accountable for |
| R6 | "What is the one thing about this role that is not in the posting?" | Gives the interviewer room to say the real thing, and it is the question most likely to change your decision |

## Prohibited claims

No entries. No material about your past was supplied, so there is nothing for this pack to inflate or contradict. Every statement about your own experience stays an instruction for you to fill from what really happened, and nothing in this pack states one for you.

## Sources

Provided documents: your message only (the company, the role and the stage).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, each refused because search permission was not granted:

- Stripe operating principles values: refused
- Stripe interview process Product Operations Manager: refused
- Stripe strategy news 2026: refused
- Stripe Product Operations Manager job description: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet and the names a candidate may be quizzed on. Not available; nothing about Stripe's values appears in this pack |
| 2. Stripe interview process, product operations | unavailable | Would have set the loop structure and the persona weights. Weights rest on a relationship prior instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A5 and a grounding brief. A5 stays generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned F1 to F6 into inferred quoted requirements. They are role-family prose instead |

## Upgrade menu

- Your CV, or a few lines on your recent roles → the evidence cells quoted, guidance story-mapped to your own sentences, a defend-the-number question per headline figure, and the most likely objection derived from your actual gaps in place of B2's placeholder
- The JD text → F1 to F6 become quoted requirements, and the coverage table is re-keyed to the posting
- Who you are meeting and in what format → an interviewer read, persona weights recomputed, and a reverse question tied to their path
- The recruiter's guidance, or any pre-declared deliverable such as a presentation or take-home → a build section for the deliverable and weights shifted toward what they flagged
- If your final is several sessions, the schedule → a mini-pack per session with its own weights
- Search permission, or Stripe's values page and loop description pasted in → a values cheat sheet if a values round is documented, a grounded CO bank, and weights from the real loop
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief with current strategy and recent moves
- How much prep time you have → a prioritized schedule sized to it
- A tuesday-dossier.md from an earlier evaluation of this role, if you have one → verified evidence and constraints carried straight into the pack
