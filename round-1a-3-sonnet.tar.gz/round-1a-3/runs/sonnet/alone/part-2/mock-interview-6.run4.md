I'll read the skill's reference files before building the pack.
I've finished the pack and saved it. This is the message that presents it.

Your prep pack is saved as `larkfield-systems_engineering-manager_interview_pack.md`. I built it in loop mode: one fit snapshot shared across all three rounds, then a bank of eight questions, a persona weighting and five reverse questions for each round.

I assumed the panel's two staff engineers and the product manager would ask in the styles their roles suggest, since no names were given. The web searches I tried on Larkfield were refused. That means no company research went in, there's no values cheat sheet for Monday, and there are no strategy questions. The Sources section lists each search and what it would have changed.

The pack names A1 as the highest-ROI prep: "You haven't owned a hardware-adjacent roadmap before. How would you handle that part of this job?" You told me you haven't owned one, so it's the objection most likely to come up on Tuesday.

Say the word and I'll play the Skeptic on A1 and push back on your answer.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three rounds, one shared fit snapshot, one mini-pack per round.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1. Tuesday | Director of Engineering, the hiring manager | 45 min | Would-be manager |
| 2. The Thursday after | Panel: two staff engineers and a product manager | 60 min | Peers-in-practice and a cross-functional partner |
| 3. The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level, values-style |

No interviewer names were given, so there is no interviewer read. The loop itself (three sessions, who runs each) comes from your own message, so persona weights rest on that and not on an archetype.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership philosophy, not generic virtue |
| EXP | Whether the claims in your background survive scrutiny and attribution probes |
| JD | A stated responsibility in the role description, including its gaps |
| CO | Knowledge of the company and its strategy (none in this pack: see Sources) |
| CASE | A live problem set in the role, scored on structure and reasoning |

Provenance labels: `[grounded]` rests on your quoted words or a supplied document, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or Larkfield. An answer slot is an instruction for the interview, not a question for you now.

## Prep triage

You have two weeks and three rounds, so the order matters more than the volume.

1. Before Tuesday: A1 out loud until the acknowledgment sounds boring, then C1 and C2 (the 60% figure), then the I1 arc.
2. Before Tuesday, once through: B1 and B2 aloud with the case structure.
3. Between Tuesday and the panel: D1, E1 and E3, then D2.
4. Between the panel and Monday: G1 to G3, then H1 and H2.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message. Rows F4 and F7 hold no quote from you, because your material is silent there.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "3 as a team lead of 6". Your material shows one team of six, not two squads, and the role's eleven engineers is a wider span than the quote carries. Answer slot: the role's two squads make a probe on coordinating more than one team likely; if you have coordinated across teams, say how and which part was yours, in your own words; if you have not, say so plainly and stay with the team you led. Plain acknowledgment from your message: "I've never managed managers." |
| F2 | "own delivery" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote carries a reliability quarter pushed through against roadmap pressure; the material does not show delivery ownership beyond that. Words at that scope: "I pushed a reliability quarter through against roadmap pressure." The 60% raises four slots, each answered in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch (C1, C2) |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in the terms of the hiring part, but a line with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run it, for backend roles. The 40 raises the same four slots, including what the 40 counts and which of those interviews were yours (E3) |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description in your message | none given | none | [grounded] | discovery | Your material says nothing on growing engineers. Answer slot: the role's growth line makes a probe likely; if you have helped an engineer grow, say what changed and what you did, in your own words; if not, say so plainly and say how you would approach it (G2) |
| F5 | "partner with hardware and product on roadmap" (the hardware half) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past (A1, B2) |
| F6 | "partner with hardware and product on roadmap" (the product half) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | Derivation: the quote touches a roadmap without naming who applied the pressure, so it does not show product partnership. Answer slot: if the roadmap pressure involved product and you worked it through with them, say how, in your own words; if it came from elsewhere or there was no such conversation, say so plainly and stay with the reliability quarter as quoted (D1, F2) |
| F7 | "building device-management services" — role description in your message | none given | none | [grounded] | discovery | Your material names a payments company and nothing about devices or industrial settings, and the pack's bridge does not go past that. Answer slot: if you have worked on services that manage devices or hardware-connected systems, say what and which part was yours; if not, say so plainly and stay with the work your material does carry (A3, E2) |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads" (F1) | A2, B1, H1, H2 |
| "own delivery" (F2) | B1, B3, C1, C2 |
| Hiring, for 11 engineers (F3) | E3, I1 |
| Growth, for 11 engineers (F4) | G2, G3 |
| Hardware partnership (F5) | A1, A2, B2 |
| Product partnership (F6) | B2, D1, F2 |
| "building device-management services" (F7) | A3, E2 |
| Monday's "values and leadership philosophy" (recruiter's words) | G1, G2, G3, G4, F1 |

No requirement is left uncovered. No CO question exists because no research ran.

## Round 1: Tuesday, hiring manager (45 min)

### Persona weights

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet probing of the gaps and the motivation | Highest, tied | The hiring-manager prior favors it, and F5 and F1 carry limits you stated yourself | Rehearse A1 until it is boring; bridge only from what your quotes carry; give a ramp plan as a plan |
| Case/Strategist | Live problems on the squads and the hardware and product seams | Highest, tied | The hiring-manager prior; the role description's squads and partnering lines supply the material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Asks how the 60% was counted | Medium | F2 holds a figure, and a figure is a standard probe target | Know what you can and cannot say about the count, and say plainly where you do not know |

### Bank A: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't owned a hardware-adjacent roadmap before. How would you handle that part of this job?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The highest-ROI rehearsal in this pack. Hold-then-concede. Open with the plain acknowledgment, before they press: "I've never owned a hardware-adjacent roadmap." Then give a plan, never a past: in your own words, name the first two things you would want to learn from the hardware side and how you would learn them. Hold that plan through two follow-ups by returning to it. If pushed for the nearest experience, use only "I pushed a reliability quarter through against roadmap pressure" at its own scope, and say plainly it was not a hardware roadmap. Concede specifically what you cannot yet judge | F5 is the one requirement where you stated the limit yourself, so it is the objection most likely to arrive in some form from the person who would manage you. JD because it scores the partnering line; Skeptic because of the quiet, persistent delivery |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Choose the limit that is true and name it first, in your own words. Your material states two. If one is your real answer, say it plainly and follow it with how you would close it, said as a plan. If the weakest part is something else, say that, and say plainly that it is not one of the two. Do not pick a gap you do not hold to sound candid | F1 and F5 are where the material is thinnest, so this stem tends to land there. JD because it scores the role as listed; the Skeptic's calibrated-candor test is the point |
| A3 | "You're at a payments company now. Why this role, and why industrial IoT?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: say in your own words what pulls you toward this role and what pulls you toward this domain; if the domain is not the pull, say so plainly and do not invent one. Keep to the facts the quote carries: nine years in engineering, three as a team lead of six, currently at a payments company. Claim no familiarity with Larkfield's products or strategy, because this pack could not research them | F7 shows nothing on devices, so the motivation probe and the domain probe arrive together. EXP because it tests whether the story holds up; Skeptic because of the why-leave, why-here, why-now shape |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit two squads on a device-management service. One has a release date tied to a hardware milestone; the other carries a heavy on-call load. What do you want to know first, and where do you start?" | CASE | [generic] | Structure it aloud: clarify what each squad has committed to and to whom, and what depends on each; state the objective; segment by squad, dependency and risk; choose an approach and say what you would deliberately defer; name the metrics you would watch; name the main risk. Challenge one premise respectfully, for instance whether the two squads should be treated as one problem. The question asks for no claim about your past, so the guidance makes none | F1 and F2 set up a live problem on the squads, which is the hiring-manager prior's native format. CASE because it scores structure; `[generic]` because the scenario is a pattern, not a fact about Larkfield |
| B2 | "Product wants a feature next quarter. Hardware says the device firmware can't support it until later. How do you run that conversation?" | CASE | [generic] | Clarify what is actually blocked and why, and what product has committed to and to whom; lay out options (reduce scope, sequence the work, an interim path) with the trade-off of each; say who decides and how both sides stay in the same conversation; name what you would measure. Challenge the premise: is it "can't" or "not yet"? Say the structure aloud before filling it. No claim about your past | F5 and F6 make the hardware and product seam the likeliest live problem. CASE with JD content, because it tests the partnering line as a decision |
| B3 | "Reliability work competes with feature work on devices already in the field. How do you decide what gets the quarter?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure first: what is at stake for each option, what you would need to know, how you would decide and who else must agree. Then, if it helps, say your own experience at the quote's scope and no wider: a reliability quarter, roadmap pressure, you pushed it through, and the on-call burden dropped 60%. Tell those beats in your own words and add nothing the sentence does not state | F2 is the nearest evidence to this decision, and a CASE question invites the candidate to reach for it. CASE because it scores the decision structure; the quote carries only the beats stated |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words: how the 60% was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly, then say what you do know. Name the weakest assumption before they do. Do not offer a method or baseline you cannot repeat under a second question | F2 holds a headline figure and figures are the standard defend-the-number target. EXP because it tests attribution and honesty about the count |
| C2 | "How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence at its own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if others carried parts of it, say whose and which parts; if most of it was yours, say that plainly and add nothing. Hold through two follow-ups by returning to the sentence, and concede specifically what you cannot claim about the 60% | F2's verb is "pushed", and an attribution probe tests exactly that verb. EXP with a Pressure delivery, because the question is the stem "how much of that was actually you" |

## Round 2: The Thursday after, panel (60 min)

Assumption: the names of the two staff engineers and the product manager are unknown, so personas are assigned by relationship, as the panel rule requires: the top two of each member's relationship, blended.

### Persona weights

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | Seam-splitting, disagreement and credit probes, from staff engineers and the product manager | Highest | All three members sit beside the squads, and the peer prior is seam-heavy; F6 is the open row | Offer seam principles, not a pretended seam; frame what you bring them as well as what you need; disagreement stories that show spine and tact |
| Data-Driven Prober | Technical depth and how the figures were counted, from the staff engineers | High | Staff engineers are the likeliest to press F2's work and F7's domain gap | Say plainly what you do and do not know; offer to walk through anything you did end to end |
| Values/Behavioral | Scenario stories, from the product manager | Medium | The cross-functional prior; it also warms up Monday's round | Pick stories where you can say what you did; "we" for context, "I" for contribution; where none exists, say so |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Engineering and product sit side by side here. Where's the seam, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Offer principles, not a map you cannot know: who decides what, how a disagreement gets surfaced, what each side owes the other. Add what you bring product, not only what you need. Answer slot: if the roadmap pressure in your quote came from product and you worked it through with them, say how, in your own words; if it came from elsewhere or there was no such conversation, say so plainly and stay with the quarter as quoted | F6 is open, and the product manager is the one person who can test it directly. JD because it scores the partnering line; Peer because of the seam framing |
| D2 | "One of the staff engineers on your squad disagrees with the technical direction you've set. What do you do?" | CASE | [generic] | Ask what the disagreement is actually about and what evidence each side has; separate who decides from who is heard; say how you would test the disagreement cheaply; say what you would do if it stays unresolved and how the relationship survives either outcome. The scenario carries no claim about your past, and the guidance makes none | Two of the three panelists are staff engineers, and this is the live version of the credit and disagreement probes. CASE because it asks for a decision, not a story |
| D3 | "How do you handle credit when work spans teams, say hardware and software?" | VAL | [generic] | Selection scaffold: pick a time work crossed team boundaries, where you can say who did what, what you said about credit and how the relationship stood afterward. "We" for context, "I" for your own contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem is a standard Peer probe; nothing in your material carries a cross-team credit story, so this is the scaffold case. VAL because it scores behavior, not a skill |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You mention a reliability quarter. What was the technical work in it?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: the sentence names a reliability quarter and not what it contained. Say what the work was in your own words and which parts you did and which others did; if you do not remember a detail, say so plainly. Do not name tools or techniques that you cannot walk through a second question deep | A staff engineer will want the content behind F2's sentence. EXP because it tests whether you can describe your own work at the level of the person asking |
| E2 | "What technical depth would you bring to reviewing a design for a service that talks to devices in the field?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the limit as your own observation first: your work so far has been at a payments company. Answer slot: if you have reviewed or made design decisions on services you worked on, say which and what your part was; if not, say so plainly, then say how you would involve the staff engineers and what you would want to learn. Do not claim device or industrial experience | F7 is a discovery gap and staff engineers are the likeliest to test it. JD because the role is device-management services; Prober delivery |
| E3 | "How does the hiring loop you run for backend roles work, and what would you change about it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Describe the loop in your own words, at the scope of the quote: you run it, for backend roles. Answer slot: if there is something you would change, say what and why; if not, say so plainly. The 40 raises four slots: what it counts, which interviews were yours, what it is sensitive to, and the assumption behind it you would defend least. "I don't know exactly how that was counted" is an honest branch | F3 is the strongest hiring evidence but has nothing inspected behind it. EXP because it tests whether the number and the loop are both yours to describe |

### Bank F: Values/Behavioral and cross-functional

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a user ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named stake, a moment you held the line, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. If you use your reliability quarter, say only what the quote says and do not describe its users or stakes unless you can | The stem is a standard cross-functional values probe and no quote carries a user-versus-metric story. VAL because it scores behavior against a value |
| F2 | "What do you need from product to run two squads well?" | JD | [generic] | Reciprocity framing: what you would offer product (clear sequencing, early warning, honest estimates in the terms you actually use), then what you need back. Offer principles, not claims about how Larkfield's product team works. No claim about your past | The role's partnering line makes the product manager's own question likely, and F6 shows the evidence for it is thin. JD with a Peer flavor, since the seam is the point |

## Round 3: The following Monday, VP Engineering (30 min)

Weighting note: the executive prior (Case/Strategist and Pressure) gives way to the recruiter's own description, "values and leadership philosophy". A values-style round is detected on that basis. No published Larkfield values are in hand, so there is no values cheat sheet; the VAL questions below take their themes from the recruiter's words and the role's growth line.

### Persona weights

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Scenario probes on leadership and values | Highest | The recruiter's description of the round | A story where one of your quoted sentences carries it, a scaffold where none does; the hard truth must actually land in the story you choose |
| Skeptic | Span-of-leadership probes | Medium | F1 shows a team of six against eleven engineers, and you stated that you have not managed managers | State the limit in your own words first, then the plan |
| Conversational | A short biography opener; time-boxed answers | Medium | A 30-minute slot rewards a prepared arc, and casual questions are still scored | A 90-second arc built only from your quoted sentences |

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The quote carries these beats: a reliability quarter, roadmap pressure, you pushed it through, the on-call burden dropped 60%. Tell them in your own words. Answer slot: if the pressure came from leadership and you had to tell them something unwelcome, say what and how it landed; if it did not, or you did not, say so plainly and stay with the quarter as quoted. If another story is truer, use it and say why | F2 is the only quoted sentence that touches pushing back, so it is the first candidate story. VAL because the stem scores whether the hard truth actually landed |
| G2 | "Tell me about an engineer you helped grow." | VAL | [generic] | Selection scaffold: pick one person where you can say what changed and what you did, and keep to what you can stand behind. If no such time comes to mind, say so plainly, then give how you would approach growing engineers on a team of the size the role describes | The role's growth line and the recruiter's "leadership philosophy" make this likely, and F4 shows nothing on it. VAL because it scores what you actually did for another person |
| G3 | "What's your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The recruiter's own words raise this. State two or three principles you actually hold, each backed by one specific thing you did; if you cannot back a principle, drop it. If either quoted sentence backs a principle, use it at its own scope and add nothing. The pack does not write your philosophy for you | The recruiter described the round in these words, so some form of this is near-certain. VAL because it scores principles against behavior |
| G4 | "Tell me about a time you got something wrong as a lead." | VAL | [generic] | Selection scaffold: pick a mistake that was yours, what it cost, what you changed afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not pick a mistake only because it sounds small | Leadership philosophy rounds commonly test self-assessment, and no quote carries a mistake. VAL because it scores honest self-assessment |

### Bank H: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've led a team of six. This role has eleven engineers across two squads. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the quote at its scope: "3 as a team lead of 6". Then say, in your own words, what you expect to change with eleven engineers and two squads; this part is a plan, not a past. Answer slot: if you have coordinated across more than one team, say how and what part was yours; if you have not, say so plainly and stay with the team you led | F1 sets the span against the role's own numbers. JD because it scores the stated scope; Skeptic because it targets the one place the quote stops |
| H2 | "You've never managed managers. How do you see your path to leading leaders?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment first, in your words from the quote: "I've never managed managers." Then a forward plan only: what you would want to learn, who you would learn it from, how you would know you were ready. Nothing in the past tense about leading leaders | You stated this limit (F1) and a leadership-philosophy conversation is the natural place for it to surface. JD because it tests honest self-assessment against the role |

### Bank I: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc whose beats are the quotes: nine years in engineering, three as a team lead of six, currently at a payments company; you run a hiring loop for backend roles; a reliability quarter pushed through against roadmap pressure. Answer slot: add in your own words why you are here now; the pack does not write that part. Do not add a turning point or a reason that you cannot name | A casual opener is still scored, and a prepared arc is the counter. EXP because it tests whether the story hangs together; Conversational delivery |
| I2 | "Sixty seconds: why you for this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Time-box it: one fact from your material at its own scope, one reason in your own words, one sentence on what you would do first, said as a plan. Say plainly that you are new to the domain if it comes up. Claim nothing about Larkfield's strategy, since this pack has none | A time-boxed question is the executive format and the Pressure persona's stem. JD because it scores fit to the role as a whole |

## Reverse questions

### Round 1 (hiring manager)

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does success look like for these two squads at six months, and who decides?" | It asks for the Director's own definition of delivery, which is what the role's first line asks you to own (F2) |
| 2 | "Where do the hardware and software roadmaps meet today, and where do they collide?" | It turns the gap you stated (F5) into a learning conversation instead of a defense |
| 3 | "How is on-call shared across the two squads today?" | It signals you read the role as an operational one and shows interest in the area F2 touches |
| 4 | "What would you want me to have done by day 30, 60 and 90?" | It makes the ramp plan from A1 concrete and shows you expect to be measured |
| 5 | "Is there anything in my background you'd want me to address?" | It brings the objection into the room where you have already rehearsed it (A1, A2) |

### Round 2 (panel)

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new manager do in their first month that would genuinely help your work?" | It is the reciprocity question for the staff engineers: what you offer, not only what you need |
| 2 | "Where are design decisions made today, and what role do you want the manager to play in them?" | It addresses the staff engineers' likeliest worry about the hire and sets up D2 |
| 3 | "How does product planning work with hardware release schedules here, and where does it hurt?" | It goes to the product manager's seam and shows you are looking at the interface (F6) |
| 4 | "Can you describe a technical disagreement here that was resolved well, and what made it work?" | It invites a real story and tells you how disagreements are handled in practice |
| 5 | "What does reliability look like from each of your sides right now?" | It lets each panelist answer from their own function, and it touches the area F2 does |

### Round 3 (VP Engineering)

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which of the company's values do you see tested most right now, and how?" | It shows you take values as something that gets tested, not recited, and suits a values-style round |
| 2 | "How are engineering managers developed here, and what does the path to leading leaders look like?" | It raises H2's topic on your terms and shows you are planning to grow |
| 3 | "Where do you see industrial device management heading over the next couple of years, and what does that mean for these squads?" | It asks for the VP's strategy in the VP's words, which this pack could not research |
| 4 | "What is the biggest unresolved tension between engineering, hardware and product that you'd want this role to help with?" | It points the conversation at the seams in F5 and F6 |
| 5 | "What would you most want this hire to have changed a year from now?" | It gives you the VP's own success measure to hold yourself to |

## Prohibited claims

Built from the fit snapshot before the banks. The pack does not coach these, and no answer slot, hold, bridge or rationale asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment: "I've never managed managers." Then a forward plan only |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then a plan, never a past |
| Has led more than one team, or two squads | Inflated form of F1 | The quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: the material shows one team. H1's slot stays inside the team you led |
| Owned delivery | Inflated form of F2 | The quote at its own scope: "I pushed a reliability quarter through against roadmap pressure". C2's slot asks only which parts were yours |
| Owned hiring for the team | Inflated form of F3 | The quote at its own scope: "I run our hiring loop for backend roles". E3's slot asks only what the 40 counts and which interviews were yours |

## Sources

Provided documents: your message (the role description, the three rounds and your background). No dossier was provided.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have fed a values cheat sheet for Monday; with no published values in hand, there is none |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. Loop structure comes from your own words, so the weights stand; the search could have added documented round formats |
| 3. `Larkfield Systems strategy` and recent news | unavailable | The search was refused. It would have supplied the CO questions and strategy-grounded cases; none are in the banks, and the reverse questions ask for the strategy instead |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, all refused: "Larkfield Systems industrial IoT values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems industrial IoT device management strategy news".

## Upgrade menu

- Web search access, or the text of Larkfield's published values page pasted in → a values cheat sheet for Monday with the company's own value names, and strategy-grounded CO questions in all three banks
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief, recent org context and role-family loop reports; run only if you say yes and search is available
- The interviewers' names → an interviewer read, per-member persona weights for the panel, and a reverse question tied to each person's own path
- The full job description → F1 to F7 requirements quoted from the posting itself, and any gate (location, travel, on-site pattern) surfaced as its own row
- The recruiter's prep email or notes for each round → any pre-declared deliverable and stated focus areas, especially for Monday's "values and leadership philosophy"
- Your answers to the answer slots in F1, F4, F6 and F7 → those rows can become story-mapped answers with quoted evidence instead of scaffolds
- The on-call dashboard or quarterly review behind the 60% → F2 could rise from medium to high; the written hiring rubric or loop pipeline report → the same for F3
- A `tuesday-dossier.md` from an earlier evidence check, if you have one → verified evidence and constraints on what each weak area may claim
