I'll read the reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-7-denied-c5e7e1dd/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions across six interviewer styles, a fit table of the JD against your own words, reverse questions, and the claims it won't coach.

- **Assumption:** I built it for a hiring-manager round with Tobias, since Head of Live Operations is probably your future boss. That puts the live-problem and skeptic questions first.
- **No web research:** the four searches I tried (company values, interview process, strategy, Tobias's background) were not permitted, so the pack uses only the JD and your background. There are no company-specific questions and no read on Tobias. The pack says this and lists the searches.
- **Biggest risk:** "You haven't worked on a game with in-app purchases." Question B2 is the one to rehearse first. It opens with a plain acknowledgment from your own words, then a plan to learn it, and holds through three follow-ups without arguing the gap is small. "Never led a team" is covered in B3 and E1.
- **Where your wording stops:** the pack keeps you to what you wrote.
  - You presented the retention numbers; it doesn't say you owned the KPIs or the post-event reviews.
  - You wrote the release checklist; it doesn't say you managed releases with QA.
  - You ran one title's weekly content drops; it doesn't say two titles or live events.
  - Where a probe will push past that, the pack leaves a slot for you to answer in your own words, or to say it wasn't yours.

I can play Tobias on B2 now, or any other question, and give feedback against the pack's own guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Is Tobias the person you'd report to, or a peer or skip-level? If the recruiter gave you any focus areas, tell me those too. Either would reweight the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. Your note gave his title and not how he sits to the role, so every persona weight below rests on that assumption and says so.
**Round:** one 60-minute interview, Friday.
**Built from:** the JD text and background you pasted. No web research ran (see Sources), so there is no company-values sheet, no grounding brief and no interviewer read.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no research ran) |
| CASE | A live problem from the role, scored on structure and reasoning |

Answer slots are instructions for the interview, not questions for this conversation. Each one has two honest branches: if you did it, say how; if you did not, or it was not yours, say so plainly.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Your material gives the four years and does not say whether the game was live-service, so that half is open. Words: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: expect a probe on what live service meant there. If the game ran on an ongoing schedule of updates, say so in your own words; if it did not, say so plainly and return to the four years as an associate producer |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly cadence, the main title, two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | The quote is one title and weekly content drops; the JD says two titles and live events. Words stay at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If any of your calendar overlapped a second title, or held events as well as content drops, say how, in your own words; if not, say so plainly and stay with the one calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with on a drop. The pack's observation: the JD's verb is coordinate. Answer slot: expect a probe on each of the four teams. Name the ones you worked with and what you did with each, in your own words; if you did not work with one, say so plainly |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | Presenting numbers touches this requirement without showing whether the reviews or the numbers were yours. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or produced any of what was reported, say which, in your own words; if the numbers came from someone else, or there was no review of an event, say so plainly and stay with presenting them |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The quote is writing the checklist and your QA team's continued use of it; the JD's verb is manage. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran releases against it, say how, in your own words; if you did not, or that was not yours, say so plainly and stay with the checklist you wrote |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but nothing inspected behind it. Lead with it in the quote's own terms. The quote does not say how the numbers were counted, and the pack supplies no method; see C1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already shows a written document in use by another team. Reword only that: "I wrote the release checklist our QA team still uses." Nothing added; the checklist itself, or another writing sample, is what would lift the band |
| F9 | Leading a team: role-family expectation, not in the JD (JD says coordinate) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't led a team." Then how you would work with the teams, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Experience with in-app purchases: role-family expectation, not in the JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Then what you would learn first and from whom, as a plan and never as a past. Never a claim to purchase or monetization work |

No requirement here is a gate: "3+ years" is an experience requirement, graded like any other row.

## Persona table

The loop rests on your own words: one 60-minute session with Tobias. Nothing documents how Saltmarsh structures interviews, and no values round is detected, so there is no values bank. Weights follow the hiring-manager prior, adjusted by your stated gaps. No interviewer signals were available to adjust them.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the calendar and release process | High. A hiring manager buys capability and tests it on the role's real work; the JD is operational (calendar, coordination, review, checklist) | Clarify, structure, then answer; think aloud; challenge one premise politely |
| B. Skeptic | Quiet, persistent probing of the two gaps you stated, and of why this move | High. A hiring manager derisks gaps, and F9 and F10 are stated and obvious | Rehearse the objection until it is boring; plain acknowledgment, then a ramp plan; no bluffing |
| C. Data-Driven Prober | Goes line by line through retention and KPI claims | Medium. The JD asks you to own KPIs and be comfortable with retention metrics, and F5 and F7 are your quoted evidence | Know what you can and cannot say about how the numbers were counted; say plainly where you do not know |
| D. Conversational | Friendly opener, casual questions that are still scored | Medium. Almost every interview opens this way; the register is the risk | A 90-second arc built only from your quoted lines; treat casual questions as scored |
| E. Pressure | Time-boxed challenges to attribution and motive | Low. Nothing in the material signals a stress style; kept because two gaps invite a hard push | Pause, restate, hold through two follow-ups, concede only what is true |
| F. Peer Evaluator | Seam-splitting between disciplines, credit-sharing | Low. Tobias is assumed to be your manager, but the JD is built on cross-team work, so the style may surface | Offer seam principles rather than pretending to know the seam; reciprocity framing |

## Question banks

### A. Case/Strategist (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A seasonal event is three weeks out. Art says its assets will land two days late and engineering has a hard release freeze. What do you do first?" | CASE | [generic] | Ask before answering: what is fixed (the date, the freeze) and what can move (scope, sequence, the date). Then who owns each call, the options with their costs, how you tell each team the same thing at the same time, and what you would write down afterwards. The question needs no claim about your past, so the guidance makes none | F4's requirement, asked as a decision rather than a line on a CV; CASE because it scores structure; `[generic]` because the scenario is a pattern, not a fact about Saltmarsh |
| A2 | "You're planning next quarter's live-events calendar for two titles that share a small engineering team. How do you build it?" | CASE | [generic] | Clarify first: what each title needs, what capacity is shared, what is already committed. Then sequence so the two titles do not collide, name the review points, and say what you would drop first if capacity falls short. Make no claim about having done this | F3's two-titles line, asked live; CASE because it scores the planning approach, JD because the scenario is the job description's |
| A3 | "An event ended last week and the players who took part retained worse than hoped. Walk me through the post-event review." | CASE | [generic] | Clarify what the event was meant to do and how success was defined. Then segment the players, compare against a baseline, form a hypothesis, say what you would change next time and how you would write it up. Think aloud and say which data you would want to see | F5 and F7's requirement, asked live; the question makes no claim about your history, and the guidance follows |
| A4 | "Design, art and community each want a different thing in the same week. How do you decide what goes on the calendar?" | CASE | [generic] | State your criteria out loud before choosing: what the update has to achieve, what each team's dependency is, what is cheapest to move. Then say who you would involve in the decision and how it is recorded. Concede the case where the answer depends on facts you would ask for | F4's coordination line; CASE because the answer is a decision rule, not a story |
| A5 | "What do you need to know about our calendar before you would change anything in it?" | CASE | [generic] | Ask rather than assert: the last quarter's calendar, how its events were reviewed, what slipped and why, how the release checklist is used today, who signs off a drop. Do not claim knowledge of Saltmarsh's practice; this is a question set, not a diagnosis | Strategist stem "what do you need to know first"; JD because it scores whether you scope before you act |

### B. Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick the weakest from your own list rather than the safest. If it is the two-titles line, say what the quote says and that two is new: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you picked the four-teams line, say which of the teams you have worked with on a drop and which you have not, in your own words; if you have worked with none, say so plainly. Then give one concrete ramp step | F3 and F4 are the rows where your material is thinnest against the JD; JD because it scores honest self-assessment |
| B2 | "I understand you haven't worked on a game with in-app purchases. How do you expect to get up to speed on that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." "I ran the weekly content-drop calendar for our main title for the last two years." | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment and do not pad it: "I haven't worked on a game with in-app purchases." Then say, as a plan and not a past, what you would learn first and from whom, in your own words. What you can say of your own work stays at its scope: "I presented the monthly retention numbers to the studio head." Follow-up 1, retention is not revenue: agree it is a different number, and say plainly you do not know from experience how purchases shape an event. Follow-up 2, can you own KPIs that include revenue: say you haven't worked with purchase data, and ask which KPIs the post-event review reports. Follow-up 3, why take the risk: return to "I ran the weekly content-drop calendar for our main title for the last two years." and concede the limit; do not argue the gap is small | F10 is the stated gap most likely to be pressed, and the one place the pack is most tempted to thicken thin evidence, so it gets the most follow-up levels and the limit named before it is asked for; JD because it scores honest self-assessment |
| B3 | "You've never led a team. This role coordinates four disciplines on every update. Why would they listen to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Then the JD's own verb is coordinate, which is not the same job as leading, and you can say so without arguing it. Hold on what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you worked with design, art, engineering or community on a drop, say which and what you did with them; if you did not, say so plainly. Concede that earning the teams' trust is the part you have not yet done in this role | F9 is the stated gap; the question's premise comes from your message, and the "four disciplines" premise is the JD's, so the slot allows that you did not work with them |
| B4 | "You've spent four years at a puzzle-game studio. Why move, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | The reasons are yours; the pack has none from your material and will not supply any. Give your actual reasons in your own words, ground them in what the role asks, and do not criticise your current studio. Keep to a minute | The Skeptic's motivation-consistency probe; EXP because it scores whether your story holds up under cross-examination |
| B5 | "What would your first thirty days look like?" | JD | [generic] | A plan, not a past. Listen and map before changing anything: the existing calendar, the review process, the release checklist and who uses it, each team's constraints. Name the two gaps you stated as things you would learn first, and who you would ask. Do not promise outcomes in the first thirty days | The ramp plan the Skeptic counter-strategy calls for; JD because it scores whether the gaps have a closure path |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented retention numbers monthly. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say how they were counted, in your own words; if you do not know how they were counted, say so plainly, and say who did know. Then name the assumption behind them you would defend least before the interviewer does; if you do not know of one, say that. Then what was yours: "I presented the monthly retention numbers to the studio head." The pack supplies no method, baseline or assumption | F7 and F5 are your evidence for the retention requirement and the likeliest place to be probed; EXP because it tests what was actually yours |
| C2 | "In a post-event review, which KPIs would you report, and which would you distrust?" | JD | [generic] | A decision rule, not a story. Start from what the event was for, pick the few measures that answer that, say what each cannot tell you, and name the one you would distrust and why. Say which data you would want checked and who you would ask. Make no claim about your history | F5's KPI line asked as a judgment; JD because it scores the stated requirement; `[generic]` because the pattern is not a fact about this employer |
| C3 | "How much of the monthly retention numbers you presented were your own work?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you produced or chose any of what was reported, say which, in your own words; if the numbers came from someone else, say so plainly and stay with presenting them: "I presented the monthly retention numbers to the studio head." Never claim analysis you did not do | F5 is where the JD's "own" presses hardest against the quote's "presented"; EXP because the probe exists to catch inflation |

### D. Conversational / Rapport Builder (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your four years as an associate producer." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc told in the quotes' own terms: the four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title, two years; the release checklist your QA team still uses; the monthly retention numbers presented to the studio head. Answer slot: what drew you to each, if anything, in your own words; if nothing in particular did, leave it out. End by pointing at why this role | The opener is scored even when it feels casual; F1 to F7 are the beats, and EXP because it tests whether the story is yours |
| D2 | "What are you actually playing these days, and what do you notice about how those games run their events?" | JD | [generic] | Name only games you actually play and what you have really noticed, from the player's side, and say it is the player's side. If you do not play live-service mobile games, say so plainly and say what you would study first. Do not present player-side observations as producer experience | Conversational stem built on the JD's live-events theme; JD because a casual question on a hot topic is still scored |
| D3 | "How do you keep the teams informed when the plan changes?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Describe your approach, then what you have actually written: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote anything else to keep teams informed of changes, say what, in your own words; if the checklist is the main example, say so plainly. Be economical; the answer is itself a sample of your writing | F8 is the JD's written-communication line; JD because it scores the requirement, delivered casually |

### E. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold on what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Concede in one clause: "I haven't worked on a game with in-app purchases." Hold the position through two follow-ups; do not claim equivalence, and do not fold on the calendar just to restore harmony | F10 returned in a time-boxed form; JD because it scores the fit, delivered as pressure |
| E2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: if others contributed, say who and what, in your own words; if all of it was yours, say so plainly. Hold: "I wrote the release checklist our QA team still uses." Concede exactly what you do not know, such as how QA changed it since. Never add practices around the checklist you did not describe | F6 and the attribution probe the Pressure persona favors; EXP because it tests what was yours |

### F. Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Producers sit between design, engineering and community. Where is the seam between you and engineering, and what happens when you disagree?" | JD | [generic] | Offer seam principles rather than pretending to know Saltmarsh's seam: who owns the date, who owns the scope, what is escalated and when. For disagreement, say how you would state your position and what you would concede. Reciprocity framing: what you bring engineering, such as an accurate calendar, as well as what you need | F4's coordination line in a collegial register; JD because it scores partnership fit |
| F2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | "We" for context, "I" for contribution: "I wrote the release checklist our QA team still uses." Answer slot: if QA or anyone else shaped it, say who and how, in your own words; if not, say so plainly. Credit the team's use of it as a fact and not as modesty | F6 is the only cross-team artifact in your material; VAL because it scores how you share credit, a behavior, not a requirement |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | D1, B4, E1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A2, A5, B1 |
| "experience running a content calendar" | A2, D1, E1 |
| "coordinate design, art, engineering and community teams on each update" | A1, A4, B3, F1 |
| "own the post-event review and the KPIs it reports" | A3, C1, C2, C3 |
| "manage the release checklist with QA" | E2, F2, D3, A5 |
| "comfortable with player-retention metrics" | A3, C1, C2, C3 |
| "clear written communication" | D3 |
| In-app purchases and team leadership (your stated gaps, not in the JD) | B2, B3, E1 |
| Company strategy (CO) | none: no research ran, so no question rests on Saltmarsh's strategy |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and which KPIs does it report?" | The JD makes you the owner of both, so asking for the standard now shows you already think of the review as yours to run; the answer also tells you whether revenue is among the KPIs |
| R2 | "Which of the two titles' calendars is harder to run today, and why?" | Shows you have read the two-titles line as real work, and gets the live problem you would inherit |
| R3 | "I haven't worked on a game with in-app purchases. What would you want me to learn first, and how would the team help?" | Turns the objection into a ramp conversation on your terms; the acknowledgment is the one your message states |
| R4 | "As Head of Live Operations, how do you decide when an event should be cut or moved?" | Asks about his own decision rule, which is the thing he owns; it signals you are thinking at his altitude |
| R5 | "How do design, art, engineering and community hand work into a release today, and where does it tend to get stuck?" | Finds the seam you would be coordinating, and is a better preparation signal than a generic process question |
| R6 | "What would a successful first ninety days look like for this role?" | Lets you hear his success criteria and set your own ramp against them |

No interviewer profile was available, so none of these is tied to his career path; R4 is tied to his role.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed teams | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or on monetization | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar across two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says one title's weekly content drops. B1's slot stays inside the one calendar |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says presented, not owned. C1 and C3 slots ask only what was counted and which part was yours |
| Managed the release process with QA | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says wrote the checklist, not managed the release. E2's slot stays inside the checklist |

## Sources

Provided documents: the JD text and your background, both pasted in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused (the host did not grant search permission):
- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio news strategy": refused
- "Tobias Wrenfield Saltmarsh Games": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. Would have fed a values cheat sheet if a values round were documented; none is detected, so no values bank is built |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Every call was refused. Would have fixed loop structure and persona weights; they rest on your own words (one 60-minute session) and the hiring-manager prior |
| 3. `Saltmarsh Games` strategy / recent news | unavailable | Every call was refused. Would have grounded a CO or CASE question in current strategy; the case bank is generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The call was refused. Would have produced the interviewer read and a reverse question tied to his path |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search access → company values, how Saltmarsh interviews, current strategy and Tobias's public footprint: a values sheet if a values round exists, CO questions, an interviewer read, and a reverse question tied to his path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for the CASE bank and role-family loop reports; offered once, on your say-so
- Tobias's place in the loop, and anything the recruiter told you about focus areas or a take-home → persona weights recomputed, and a build section for any declared deliverable
- Your own answers to the slots in F1, F3, F4, F5 and F6 → those rows regenerate from your words and the slots close
- The release checklist itself, a calendar export or the retention deck you presented → F2, F5, F6, F7 and F8 move from medium toward high, because each is an artifact an interviewer could be shown
- How much prep time you have → a prioritized schedule sized to it
- A job-underwriter dossier → verified evidence and sharper constraints on what the pack may coach; the pack never requires one
