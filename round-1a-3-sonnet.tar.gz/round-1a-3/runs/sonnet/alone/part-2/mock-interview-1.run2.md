I'll read the reference files before building the pack.
The pack is built and saved. This is the closing message that presents it.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-1-denied-21b85b86/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 24 questions across seven personas, weighted for a single 60-minute conversation with a peer. Web search was refused in this session. So the values, the loop structure and Dan's public footprint are not established. The company priorities come from your research note, and every claim about Priya comes from your message. The deepest rehearsal is D1, the no-sales-ops, no-quota-setting objection from a peer in Sales Strategy.

Say the word and I'll play Dan on D1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Three things would restructure the pack:
1. Did the recruiter name any focus areas, or ask Priya to prepare anything for the conversation?
2. Can you paste the full JD and Priya's CV text, so the quotes come from her own lines rather than your summary?
3. Do you want a deeper research pass, with up to 6 more searches and 2 more fetches taking several more minutes? You'd need to allow web search first, since it was refused this time.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, Northwind Data. **Relationship:** peer, both reporting to the same VP. **Round:** a single 60-minute conversation.

Built on these assumptions: the JD highlights and the candidate summary are your message's own words, not full documents, so every quote below comes from your message ("the coach's notes"). Web research was refused in this session, so company values, loop structure and Dan's public footprint are not established. The company priorities come from your research note.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say the candidate's own sentences in her own words, and treat every answer slot as an instruction for the interview. If the slot's practice was not hers, the honest branch is to say so plainly.

| Type tag | Meaning |
|---|---|
| VAL | Behavioral and values: does past behavior show the behavior asked about |
| EXP | Work-experience deep-dive: do the CV claims survive scrutiny, and what was actually hers |
| JD | Role and JD-driven: can she do the listed job, gaps included |
| CO | Company and strategy knowledge: can she think at Northwind's altitude |
| CASE | Live problem from the actual role: structure and reasoning |

Highest-ROI prep in this pack: **D1**, the no-sales-ops, no-quota-setting objection from a peer who works in Sales Strategy. It is the objection most likely to be asked in some form. It gets the most follow-up levels and the exact concession wording. **A1**, the ~$400M figure, is second.

## 2. Fit snapshot

Requirements F1 to F6 are the JD highlights as you gave them. F7 is not in the highlights: it comes from the interviewer's function, which is why it is `[inferred]`. Full JD text would confirm the wording.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not bringing a new line to market, and the words stay at that scope: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-product-lines line makes a probe on launches likely. If any of that work was bringing a new offer to market, say which and what part was yours, in your own words; if none was, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The quote carries a proposal and a credited figure, and does not show how the opportunity was found. Words at its scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's lifecycle line makes a probe on how the opportunity was found likely. If you found it by analysing your own data, say how, in your own words; if the idea came another way, or someone else found it, say so plainly and stay with the proposal. The figure raises its own slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names the tools and does not show analysis run independently. Words: "I'm skilled in SQL and Tableau." Answer slot: Dan describes himself as relentlessly data-driven, so a probe on one analysis you ran is likely. If there is one you ran yourself, be ready to walk it end to end in your own words; if there is not, or it was not yours, say so plainly and stay with the sentence |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a partner-level revenue model used in negotiations, not a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any of your work shaped how a partner relationship was set up, say what and how you decided; if there was no such step, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with it as it stands: "I set annual volume targets with cross-org consensus." Add nothing about how the consensus was reached unless you say it, in your own words, as in A4 and B5 |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [grounded] | transferability | The quote is daily use of AI tools, which is not building or selling an AI product, and the words stay there: "I use AI tools daily." Answer slot: if asked what for, say what you actually use them for, in your own words; if the use is lighter than daily or narrower, say so plainly |
| F7 | Sales-ops and quota-setting fluency, the peer's home territory (not in the JD highlights; derived from Dan's title) | "No classic sales-ops or quota-setting experience." — the coach's notes; "set annual volume targets with cross-org consensus" — the coach's notes | none | [inferred] | capability | A gap wording cannot close, and you have stated it. Words: "I don't have classic sales-ops or quota-setting experience." Then the nearest thing your material carries, at its own scope: "I set annual volume targets with cross-org consensus." Your material does not call those targets quotas, so the sentence stays at "volume targets". Then how you would learn it, said as a plan and never as a past |

## 3. Interviewer read: Dan Kovac

Source: your description of his profile only. Nothing about him was searched, because web search was refused.

| Signal | What it says | Practical implication |
|---|---|---|
| Self-description: "relentlessly data-driven" | His own words | Every figure gets probed to its assumptions; see A1, A3, A4, F1 |
| Career spine: pricing and monetization | Per your profile summary | Cases land in packaging, pricing and unit-economics language; see C3, C4 |
| One early-stage-startup chapter | Per your profile summary | Expect a pace and ambiguity probe against nine years at a large company; see D3, D4 |
| Peer, same VP | Your message | He is pricing what you cost him and add to his work; see B1 to B5 and the reciprocity question in the reverse bank |

Mirror opportunity, shared vocabulary only: his pricing and monetization spine sits next to "built a partner-level revenue model used in carrier negotiations" (F4). Use that sentence at its own scope. Do not call it pricing work, because your material does not say that. No shared career jump is established by your material, so none is offered.

## 4. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Inputs, denominators and assumptions, two levels deep | Highest. Peer prior, plus "relentlessly data-driven", plus a ~$400M figure on F2 | Know what you can say about how the number was counted, say plainly what you do not know, and name the weakest assumption first |
| Peer Evaluator | Seam-splitting with Sales Strategy, credit, "what do you need from me" | Highest. The relationship prior for a peer, and both of you report to one VP | Reciprocity framing; propose seam principles and do not pretend to know the seam |
| Case/Strategist | Live GTM, whitespace and bundling problems | Medium. A peer is not the hiring manager, but pricing is his home ground and your research note names bundling as the main threat | Clarify, objective, segmentation, approach, metrics, risks; say the structure aloud |
| Skeptic | The sales-ops and quota gap, partner-motion experience, nine years at one company | Medium. F7 is a stated gap and F4 is adjacent only; his startup chapter adds a pace probe | Rehearse D1 until it is boring; calibrated candor, no bluffing a competency he owns |
| Conversational | The journey, and what she is playing with in AI | Low. No signal of a rapport-led style, but openers are scored | A 90-second arc; treat the AI question as scored |
| Pressure | "How much of that was actually you", "why you" | Low. Nothing in his profile points to stress style; a peer rarely uses it | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral | Unpopular-truth and customer-first stems | Low. No values round was documented and none is assumed for a single peer conversation | Selection scaffolds with an honest branch |

Loop: one 60-minute conversation with one peer, as you described it. Weights rest on your description and not on a Northwind source.

## 5. Question banks

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The store-surface change you proposed was credited with a ~$400M ARR uplift. Walk me through how that figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open at the sentence's scope: "I proposed the change, and it was credited with a ~$400M ARR uplift." Then the four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name that weakest assumption before Dan does. If you do not know how it was counted, say so plainly; do not reconstruct a method you cannot repeat under a second question | F2 carries the one headline figure, and Dan describes himself as relentlessly data-driven, so this is the likeliest deep probe. EXP because it scores counting and attribution; Prober because the register is inputs and denominators |
| A2 | "You'd run your own analysis in SQL and Tableau here. Walk me through one analysis you ran end to end." | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Say "I'm skilled in SQL and Tableau." Then choose one analysis that was yours alone, one where you can survive a second and third follow-up on inputs: the question it answered, where the data came from, what you did, and what changed because of it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, the partner-level revenue model, at its own scope, or how you would approach one | F3 is a tool claim with nothing inspected behind it, and the JD names independent analysis. JD because it scores a stated requirement; the open-prompt form lets the honest branch exist |
| A3 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the sentence at its scope. Answer slot: say, in your own words, what the model took in and what it was used for in the negotiations; if you do not remember the mechanics, or part of it was not yours, say so plainly and stay with the sentence. Never describe a method, input or negotiation outcome you did not state | F4 is the closest your material comes to Dan's pricing and monetization spine, so he is likely to open it. EXP because it tests what was actually yours |
| A4 | "Walk me through how those annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Say "I set annual volume targets with cross-org consensus." Answer slot: say how, in your own words; if there was no formal method, or others set it, say so plainly and stay with the sentence. If Dan asks whether that is quota-setting, your own words are: "I don't have classic sales-ops or quota-setting experience; I set annual volume targets with cross-org consensus." Do not call the targets quotas | F5 and F7 meet here: the JD's cross-functional line draws the question, and the stated gap sits next to it in Dan's territory. EXP because it scores method and attribution |
| A5 | "How would you pressure-test an AI-generated analysis before leadership acts on it?" | JD | [grounded] "uses AI tools daily" | Say "I use AI tools daily." Then a method for the hypothetical, which claims nothing about your past: state the question first, reproduce the key figures from source data yourself, check them against a sanity bound, and say what you are still unsure of. Answer slot: if you have done this on a real analysis, say what you checked; if not, say so plainly and say how you would | F6 is the weakest-evidenced row and the JD marks AI as a plus, so a data-driven peer is likely to ask it as a method question. JD because it scores the plus; the Prober register is the rationale for asking how, not whether |

### B. Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Ask Dan where he draws it first. Then propose principles: one named owner per decision with the other consulted, shared definitions for stages and metrics before targets are set, and disagreements settled on the data and not on the person. Reciprocity: say what you would hand his team, and keep it to the sentence: "I built a partner-level revenue model that was used in carrier negotiations." Do not claim to know where the seam sits today | The persona stem for a peer, and the first-month risk is turf. JD because it scores the role's cross-functional line; the guidance claims only the quoted sentence |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Describe the practice as a principle: say what each team did and use the verb that is true. Use your sentence as the example of precision: "I proposed the change" and not "I delivered it". Answer slot: say whose work the uplift also depended on, if you know; if you do not know, say so plainly and stay with "proposed" | F2's wording is the test case for attribution, and a peer asks about credit to find out whose results he would be sharing. VAL because it scores collaborative behaviour; EXP-adjacent but the stem is behavioural |
| B3 | "What would you need from my team in your first ninety days, and what would we get from you?" | JD | [generic] | Ask for what a new GTM lead can reasonably need: the stage definitions, the data access, and the targets Dan's team already set. Then offer a plan, not a record: share your hypotheses for each new line with his team before any target is proposed. The question needs no claim about your past, and the guidance makes none | The reciprocity question a peer asks, and the candidate's answer shows whether she reduces or adds to his load. JD because it scores the cross-functional requirement; generic because it is a pattern |
| B4 | "Enterprise expansion is a stated priority. Where do the two product lines fit, and where might they pull against it?" | CO | [grounded] | Clarify first: which two lines, whether they are sold into existing enterprise accounts or to new buyers, and who sells them. Then a hypothesis to test and not a fact: lines that sell into existing enterprise accounts support expansion, while lines needing new buyers compete for the same sales capacity. Say the hypothesis aloud and ask Dan which he sees | Your research note names enterprise expansion as a priority, and a Sales Strategy peer lives in capacity trade-offs. CO because it tests strategy fluency at Northwind's altitude |
| B5 | "Tell me about a time you pushed back on a number a partner team owned." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Pick a moment where you disagreed with a counterpart on the data and kept the relationship: the number, why you disagreed, what changed, and how you stood with them afterwards. Answer slot: if a disagreement happened while setting annual volume targets with cross-org consensus, say what it was and what part was yours; if none happened, or it was not yours, say so plainly, then give the nearest thing your material carries, or how you would handle it | The persona stem for a peer, with the seam made personal. VAL because it scores disagreement style; the slot lets the premise be false |

### C. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the go-to-market plan for one of the two new lines. What do you need to know first?" | CASE | [grounded] | Clarify before structuring: which line, the target buyer, who sells it (direct, partners or bundled), and what year-one success means given a profitability priority. Then objective, segments, the motion across land, adopt, expand and renew, metrics, and risks. Challenge one premise respectfully. This is a live problem and asks about no past | The JD's headline requirement is the two lines, so this is the plan a peer would want to hear. CASE because it is a live problem from the role |
| C2 | "Where would you look for whitespace across land, adopt, expand and renew, and what would you pull from the data first?" | JD | [grounded] | Define each stage for the product, then count accounts at each stage. Look at where accounts stall between stages, how far existing accounts have adopted, and how renewal cohorts differ. State each as a hypothesis you would check in SQL, and say which number you would trust least. No claim about your past | The JD's lifecycle requirement is not otherwise rehearsed. JD because it scores that requirement, with CASE delivery |
| C3 | "A much larger platform vendor starts bundling a competing product into its suite. How does your go-to-market respond?" | CO | [grounded] | Clarify which segments overlap and where the bundle is likely to win and where it is not. Then respond on three fronts: positioning for the buyers a bundle does not serve, the partner motion, and packaging and pricing, which is Dan's territory, so invite his view. Hold it as a hypothesis, since you do not have Northwind's win and loss data | Your research note names bundling as the main competitive threat, and pricing is Dan's native language. CO because it tests competitive fluency; the case form is the delivery |
| C4 | "Profitability is a stated priority and both lines are investments. How do you decide where go-to-market effort goes first?" | CASE | [grounded] | Ask what profitability means for the lines in year one. Then a unit-economics lens: payback on the effort per segment, a stage gate per line, and what you would stop. State the assumption you would defend least. No claim about your past | A pricing and monetization peer is likely to press the profitability priority from the research note. CASE because it asks for a prioritisation under a constraint |

### D. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting. How would you do this job alongside me?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **The highest-ROI rehearsal.** Pause, then concede first and specifically: "I don't have classic sales-ops or quota-setting experience." Then what your material carries, at its own scope: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model that was used in carrier negotiations." Then a plan, never a past: in the first weeks, learn how his team sets and allocates quota before proposing anything, and rely on his team for those mechanics. Follow-up 1, "volume targets are basically quota": hold at the sentence, concede that you cannot speak to quota mechanics, and do not agree they are the same. Follow-up 2, "what would you get wrong first": give one specific concession, tied to the mechanics you would be learning from his team. Follow-up 3, "why not hire someone from sales ops": hold on the two sentences and do not add to them | A peer in Sales Strategy is the person most likely to feel this gap. F7 is a stated negative, so the plain acknowledgment is sourced. JD because it scores a competency adjacent to the role; Skeptic because it is the gap probed |
| D2 | "Partner-motion design is a requirement. What partner motion have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the sentence at its scope. Answer slot: say which decisions the model informed in the negotiations and which of those were yours; if the model informed no decision you can name, or the decisions were not yours, say so plainly and stay with the sentence. Hold through two follow-ups by returning to the model, never by adding to it | F4 is adjacent and not direct, and the JD marks the requirement. JD because it scores the stated requirement; the slot lets the premise be false |
| D3 | "You've spent nine years at one large consumer-tech company. Why leave, why here, why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Give your actual reason for leaving in your own words, and keep it about what you want next. Then why this role, tied to the two new lines. No figure or reason is supplied here, because only yours will hold. Do not turn the nine years into a claim about pace | Dan's startup chapter makes a pace probe likely, and the motivation question is the standard Skeptic stem. EXP for the reason for leaving; F1 holds the nine years |
| D4 | "Tell me about a time you built something with no playbook." | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pick an instance where you started with a blank page: what was missing, what you chose first, and what you would do differently. Answer slot: if the store-surface change was one, say how it started, in your own words; if it was not, or it was not yours, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's two new lines are an ambiguous remit, and Dan's startup chapter makes this a likely probe of scrappiness. VAL because it scores behaviour; the slot lets the premise be false |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc with beats the sentences state: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops, the revenue model, the proposed change and its credited figure. End on why this role, in your own words | It is the safest-feeling question and it is scored. EXP because it is a CV walk-through; the arc is pre-scripted so the opening is not improvised |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say "I use AI tools daily", then say what for, in your own words. If the use is narrow, say so plainly. Then link it to the role as interest only: your research note names the Compass launch, so ask what Dan sees as the sales motion for it | The JD marks AI as a plus, and the question arrives in a casual register. JD because it scores the plus |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold at the sentence: "I proposed the change, and it was credited with a ~$400M ARR uplift." Hold through two follow-ups. Concede specifically that the sentence does not say more than "proposed" and "credited". Answer slot: if you know how credit was apportioned, say so in your own words; if you do not, say so plainly | The persona stem for pressure, aimed at the figure on F2. EXP because it scores attribution; hold-then-concede is the structure the type requires |
| F2 | "Sixty seconds: why you over someone who has run sales strategy at a B2B company?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause. Concede first, briefly: "I don't have classic sales-ops or quota-setting experience." Then two sentences at their own scope: "I built a partner-level revenue model that was used in carrier negotiations" and "I set annual volume targets with cross-org consensus." Stop there; do not fill the remaining time | The pressure variant of D1. JD because it scores the fit; the time-box tests whether the concession stays specific |

### G. Values/Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time where the truth was a number or a decision, with a named stake, a moment you did not soften it, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem for values. No quote carries it, so this is a selection scaffold. VAL because it scores behaviour; generic because it is a pattern |
| G2 | "Tell me about a time you put a partner's interest ahead of an internal metric." | VAL | [generic] | Pick a time with a named partner, a named metric you gave ground on, and what happened to the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The other persona stem for values, and it fits a role that includes partner-motion design. VAL for the same reason; generic because no quote carries it |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "own GTM strategy for two new product lines" | C1, C4, B4, D3, D4 |
| "identify whitespace across land/adopt/expand/renew" | C2, C1 |
| "run independent analysis in SQL and Tableau" | A2, A5, C2 |
| "partner-motion design experience required" | D2, A3, C3, G2 |
| "strong cross-functional influence" | A4, B1, B2, B5 |
| "AI experience a plus" | A5, E2 |
| Sales-ops and quota-setting fluency (derived from Dan's title) | D1, F2, A4 |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has been in pricing and monetization. Where do you see pricing and packaging decisions meeting go-to-market for the new lines, and where should my remit stop?" | Ties to his own path and asks about the seam in his native language |
| R2 | "You've had an early-stage startup chapter. What did you carry from it into a company this size?" | Ties to his path and turns the pace probe into a peer conversation |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer |
| R4 | "You describe yourself as data-driven. Which metric do you most wish you could trust more, and why?" | Shows you listened to how he describes himself, and surfaces the data's weak points |
| R5 | "How is the bundling threat showing up in the deals your team sees?" | Uses your research note's competitive frame and invites his direct view |
| R6 | "How are you thinking about Compass in the sales motion?" | Uses the Compass launch from your research note and the JD's AI line |
| R7 | "How will the profitability priority change how the two lines are judged in year one?" | Connects the third stated priority to what you would be measured on |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led go-to-market for a new product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not a new-line launch. The slot stays inside that work |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope: a model used in negotiations. The slot asks only which decisions the model informed |
| Led or ran the carrier negotiations | Inflated form of F4 | The sentence says the model was used in carrier negotiations, and nothing about who ran them |
| Set or owned pricing for carrier deals | Inflated form of F4, and tempting with a pricing-spine interviewer | The model sentence at its own scope, with no word about pricing |
| Drove, delivered or generated the ~$400M ARR uplift | Inflated form of F2 | "I proposed the change, and it was credited with a ~$400M ARR uplift" |
| Has sales-ops or quota-setting experience | Negative you stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| The annual volume targets were quotas | A claim your own quote contradicts, F7 | "I set annual volume targets with cross-org consensus", at that scope |
| Has built or launched an AI product | Inflated form of F6 | "I use AI tools daily", and nothing wider |

## 8. Sources

Provided documents: your message (the JD highlights, the candidate summary, the interviewer description) and your research note (three priorities, one competitive threat).

Searches sent, all refused:

- "Northwind Data company values" — refused
- "Northwind Data interview process strategy lead" — refused
- "Dan Kovac Northwind Data Director of Sales Strategy" — refused

No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every search was refused. It would have fixed published value names for VAL questions and section 10; the VAL bank uses persona stems instead |
| 2. `Northwind Data interview process Senior GTM strategy` | unavailable | Every search was refused. It would have documented the loop; persona weights rest on your description of one peer conversation |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note supplies the priorities and the competitive threat, which fix the CO and CASE banks. Its date is not known to me, so check it is still current |
| 4. `Dan Kovac Northwind Data` | unavailable | Every search was refused. It would have added talks and writing to section 3 and sharpened R1, R2 and R4 |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 9. Upgrade menu

- Full JD text → F1 to F6 requirement quotes are confirmed against the posting and any mid-list requirement gets a question
- Priya's CV text → the evidence column moves from your summary to her own lines, and confidence can rise where an artifact backs a claim
- Her answers to the slots in F1, F2, F3, F4 and F6, given outside a drill → those rows are regenerated with her words, and the matching banks become story-mapped
- The recruiter's prep email, or any stated focus areas or deliverable → coverage beyond the round-type priors, and a build section for any announced deliverable
- Web research allowed, including a deeper pass of up to 6 more searches and 2 more fetches, several more minutes → published values, the loop, and Dan's talks and writing, a grounding brief, and persona weights read from his public footprint
- The prep time available → a prioritised schedule sized to it
- A `tuesday-dossier.md` → verified evidence, a named strongest objection, and prohibited claims that replace the ones built locally here
