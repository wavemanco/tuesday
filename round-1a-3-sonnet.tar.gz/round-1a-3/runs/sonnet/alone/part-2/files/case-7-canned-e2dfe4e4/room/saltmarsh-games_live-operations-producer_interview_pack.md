# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Prepared for:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The pack assumes he is the hiring manager running the round.
**Round:** built for the Outage Hour, which Saltmarsh's careers page describes as a single 60-minute interview with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation. The page says there is no take-home.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Question IDs run by persona (A, B, C…), so a drill can name one.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The stated responsibilities and requirements, including the gaps |
| CO | Whether you can think at the company's altitude: strategy, recent moves |
| CASE | A live problem from the actual role, structure over the "right" answer |

Guidance is scaffolding, not a script. Say it in your own words. Wherever a cell says "answer slot", it is an instruction for the interview: answer from your own experience, and if the thing did not happen or was not yours, say so plainly.

**Highest-ROI prep in this pack: C1**, the in-app-purchase question. It is the gap you stated yourself, and the studio's published direction makes it the most predictable objection. Rehearse it until it is boring.

## 2. Fit snapshot

No requirement below is a gate: "3+ years" is an experience length, not a term you meet or do not.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not an events calendar across two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on how events differ from drops likely. If any of your drops were time-limited events, say how you planned them; if they were all ongoing content, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | Your material says you have not led a team and shows nothing either way on coordinating across disciplines; leading and coordinating are different things, and the stated negative covers only leading. Your words for the stated part: "I haven't led a team." Answer slot: the JD's four disciplines make a probe on how you worked with them likely. If you worked with any of them on a drop, say which and what you needed from them, in your own words; if you did not, or it was someone else's job, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers, and shows nothing on owning a review or choosing the KPIs; the words stay at presenting: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went into the monthly set, or ran a review after a drop, say how, in your own words; if the set was handed to you, or no such review existed, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you wrote it, and QA still uses it. A named artifact beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | presentation | The quote already reaches the years in other terms. Say it as it stands: "4 years as an associate producer at a puzzle-game studio." The title is associate producer, so expect a probe on scope. "Live-service" is the JD's phrase; use your own words for the work, as in F6 |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it. Lead with it in its own terms: weekly, one main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on how those numbers were counted, and see D1 for the honest ways to answer it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | transferability | A checklist is one kind of written work and your material shows no more. The bridge stays at the checklist: you wrote it, QA still uses it. Answer slot: if you wrote other things your team relied on, say which, in your own words; if not, say so plainly and stay with the checklist |
| F9 | The direction of the titles the role covers: a season-pass model with one shared events calendar from February 2027, per the Project Larkspur announcement. A season pass usually involves purchases, so expect your in-app-purchase absence to be probed. Whether the JD's "two of our mobile titles" are the two Larkspur names is not established | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase-related work, and nothing added to make the gap feel smaller |

## 3. Reading the interviewer

Public professional footprint only. Sources are in section 11.

| Item | What the source says | Provenance | Implication for you |
|---|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | [grounded] | He owns the function the JD describes; expect him to score the JD's responsibilities directly |
| Earlier path | Previously a QA lead at a console studio, per the talk listing | [grounded] | Your F4 line, "Wrote the release checklist our QA team still uses", is shared professional ground with that path. Use it by describing the checklist in those words, never by implying QA experience you have not stated |
| Published talk | "Patch Notes Are a Promise", GDC 2026. His argument, per the listing: a live team is judged by how often its patch notes describe what actually shipped | [grounded] | Expect questions where what you say to players must match what is built: A1, A5, B2. Use "what shipped" and "what is confirmed" as your own working vocabulary |
| Overlap with Saltmarsh's values | The second published value, "Ship the Patch Not the Promise", covers the same ground as the talk's title and argument | [inferred] | Treat B2 and B4 as likely in some form. This is the pack's reading of the overlap, not something he has said |

Reverse question R1 is tied to his path.

## 4. Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a simulated outage during a live event, then follow-up injects | Highest. The careers page names the tabletop as the first half of the hour; the hiring-manager prior is Case plus Skeptic | Clarify, objective, who does what, approach, metrics, risks. Think aloud and challenge one premise respectfully. Bank A: five questions |
| B. Values / Behavioral | A values conversation on Saltmarsh's three published values | High, and guaranteed: the careers page documents a values conversation as the second half | Map a story to each value where one of your quoted sentences carries one; where none does, use the selection scaffold and its honest branch. Bank B: four questions |
| C. Skeptic | Quiet probing of the gaps you stated | Mid. Hiring-manager prior, and F2 and F9 are stated gaps | Rehearse C1 until it is boring. Concede plainly, hold what the quotes carry, give a ramp plan. Bank C: three questions |
| D. Data-Driven Prober | Line-by-line on the retention numbers and the checklist | Mid. The JD asks you to own post-event KPIs, and F3 and F7 give a number trail to probe | Say what you know about how the numbers were counted, say plainly what you do not. Bank D: three questions |
| E. Pressure | Interrupts inside the tabletop, time-boxes the answer | Low. A simulated outage may carry time pressure; this is the pack's inference, not something the page says | Pause, restate, anchor in what you stated, hold through two follow-ups. Bank E: two questions |
| F. Conversational | Opening biography and "what have you played" | Low. A pattern for a 60-minute hiring-manager session, not a documented Saltmarsh step | A 90-second arc built from your own quoted lines. Bank F: two questions |
| Peer Evaluator | Not included | The careers page puts the hiring manager in the room, so a peer round is not plausible here | None needed |

## 5. Question banks

### Bank A: Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Simulated outage: partway through a live event, players report that a reward is granting far more than it should, and the number is climbing. You have the room on a call. What do you want to know first, and what happens in the first fifteen minutes?" | CASE | [inferred] | Clarify before you structure: how many players, since when, whether it can be stopped without a new build, who can confirm. Then state the objective (stop the damage, keep players informed), then who does what, naming design, art, engineering, community and QA by what you would ask of each. Then what players are told, limited to what is confirmed. Say your framework aloud and challenge one premise, for example whether the event keeps running while it is investigated. The question needs no claim about your past, so the guidance makes none | Derived from the careers page's description of the tabletop; the scenario itself is invented. CASE because it scores structure under a live problem, and it exercises the JD's four-discipline coordination line (F2) as a decision, not a record |
| A2 | "A fix exists. Engineering wants to push it now. QA has not finished the checklist. Community is already answering players, and design wants to extend the event to make up for it. Who decides what?" | CASE | [inferred] "Wrote the release checklist our QA team still uses" | Separate the decisions: ship or hold, what players are told, whether to extend. Say who holds each and what you would ask for before it is made. If you reach for the checklist, your words are the quote's: you wrote it, and QA still uses it. Answer slot: if a release was ever held or changed because of the checklist, say what happened and what part was yours, in your own words; if there was no such occasion, or it was not yours, say so plainly and describe how you would use it | Second inject in the same incident, built from the JD's release-checklist line (F4). CASE because the decision map is what is scored |
| A3 | "The event ended Sunday. Monday you owe the post-event review. What goes in it, in what order, and what would you refuse to claim?" | CASE | [generic] | State the objective the event was for, then the few numbers you would report against it, then what you cannot attribute to the event. For the number you would defend least, name the assumption behind it before the interviewer does. The question needs no claim about your past, so the guidance makes none | The JD's post-event-review line (F3) asked as a decision. CASE because it is a live task, and the weakest-assumption move is the metric-question bar |
| A4 | "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027. You are building the first quarter of that calendar. What do you need to know before you place a single event?" | CO | [grounded] "never worked on a game with in-app purchases" | Clarify first: what the pass is meant to do for players across a season, what the shared calendar has to coordinate between the two titles, how success will be measured. If the purchase side comes up, say it once: "I haven't worked on a game with in-app purchases", then carry on with the plan. Structure the quarter from those answers, and name the part you would take to people who know the purchase side | Larkspur is the company's published direction (September 2026 announcement). CO because it needs current strategy; the JD's "two of our mobile titles" may or may not be these two, which F9 records. The quote is F9's stated absence |
| A5 | "An event shipped with one of its three promised features. Say the first two lines of the player-facing note out loud." | JD | [inferred] | Say what shipped. Say what did not. Give a next-update time only if it is real. Do not describe the missing feature as coming unless someone has committed to it. The question needs no claim about your past, so the guidance makes none | Scores the JD's written-communication line (F8). Built from the topic of the interviewer's published talk, which is the pack's derivation, not something he has said about this round. JD tag with CASE delivery |

### Bank B: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold for "Players Before Plans": pick a time a scheduled drop met something players were telling you. It needs a named stake, what you did with the date, and what players saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the calendar you ran, in the quote's own words, or how you would handle it | The first published value, whose definition is "when the calendar and the players disagree, the players win". VAL because it needs a specific decision; the scaffold is used because the quote carries the calendar and not a disagreement |
| B2 | "When did you hold back from announcing something that was not built yet?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold for "Ship the Patch Not the Promise": pick a time you kept something out of an announcement because it was not finished. It needs the pressure to announce it and what you said instead. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the checklist you wrote and QA still uses, at that scope, or how you would handle it | The second published value, defined as "we announce what is built, not what is hoped". VAL; the checklist is the nearest quoted sentence, not a story about announcing |
| B3 | "Tell me about a time a release left something better than you found it: a process, a checklist, a tool." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4, with the beats the quote states: you wrote the checklist, and QA still uses it. Tell them in your own words. Answer slot: if you changed it after releases, say what prompted each change; if it was written once and left, or others changed it, say so plainly and stay with what you wrote | The third published value says every release leaves "the codebase and the checklist" better than it found them. F4 is the one quoted sentence that carries a story for a value, so VAL with a mapped story |
| B4 | "Tell me about a time you had to tell someone a date or a promise would not hold." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not soften it, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, presenting the monthly numbers, at that scope, or how you would handle it. Answer slot: if any month's numbers were not what the studio head hoped, say what happened; if none were, say so plainly | The theme is the second published value's line between built and hoped. VAL; the quote is the nearest sentence and does not itself show a hard message landing |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and Project Larkspur moves our two titles to a season pass from February 2027. How would you plan a calendar for that?" | JD | [grounded] "never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years" | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment, once, without apology: "I haven't worked on a game with in-app purchases." Then state what you did in the quote's words, the weekly content-drop calendar for your main title for the last two years, and stop; let them draw the inference. Then a plan, said as a plan: what you would ask first (what the pass is meant to do for players, what the shared calendar has to coordinate, how success is measured) and whom you would learn from. Follow-up one, "How would that change where you place an event?": answer from the plan, and name what you cannot yet judge. Follow-up two, "What do you do in your first thirty days?": a learning plan, in order. Follow-up three, "What would you not decide alone?": name the decisions you would take to people who know the purchase side. Hold the quoted work through all three, and never shrink the gap or stretch the calendar | F9 is the most likely objection because the gap is stated and the published direction presses on it. JD because it scores the role's fit; the limit is named before it is asked for, which is what makes the answer non-defensive |
| C2 | "You haven't led a team. The role coordinates design, art, engineering and community on every update. How do you get four teams moving together?" | JD | [grounded] "Never led a team", "I ran the weekly content-drop calendar for our main title for the last two years" | Plain acknowledgment first: "I haven't led a team." Then the quote at its scope: you ran the weekly content-drop calendar for your main title. Answer slot: if you worked with design, art, engineering or community on a drop, say which and what you needed from them, in your own words; if you did not, or it was someone else's job, say so plainly and describe what you did own. Hold through one follow-up by returning to the calendar, never by adding to it | F2's requirement, asked at the line the JD draws. JD tag; the negative is sourced to your own statement |
| C3 | "Your calendar was weekly drops for one title. We run live events across two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | State the quote at its scope first. Answer slot: if events differ from drops in how you planned them, say how, in your own words; if you never ran time-limited events, say so plainly and stay with the calendar you ran. Do not describe a second title or an events process you did not run | F1's gap, asked directly. JD because it scores the first-listed responsibility; the premise is the quote's own scope |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you know about how they were counted, in your own words, and say plainly where you do not know. Name the assumption behind the figure you would defend least before they do. Say which part was yours: the quote says presenting. Answer slot: if you built or chose the figures, say so; if they were handed to you, say so plainly | F3 and F7 are the number trail the JD's KPI line invites a prober to follow. EXP because it tests what was actually yours |
| D2 | "Pick one KPI for a post-event review. How would you know the event caused it, and not the week around it?" | JD | [generic] | Pick one and say why. Say what else was happening that week that could explain it. Then name the assumption you would defend least, in your own words. The question needs no claim about your past, so the guidance makes none | Scores "own the post-event review and the KPIs it reports" (F3) as a reasoning task. JD tag with CASE delivery; the metric-question bar is the weakest-assumption move |
| D3 | "Walk me through the release checklist you wrote. How does it work in a release?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Describe the checklist in your own words, as you wrote it. Answer slot: if you and QA ran it together on release day, say how; if QA ran it and you wrote it, say so plainly, and stay with what you wrote. Do not describe release practices the quote does not state | F4 is the strongest line, so it will be tested hardest. JD because it scores "manage the release checklist with QA"; the content is EXP |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has already run a monetised events calendar?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "never worked on a game with in-app purchases" | Hold-then-concede. Pause and restate the question. Hold on what the quotes carry: four years as an associate producer at a puzzle-game studio, and the weekly calendar for your main title. Concede the purchase side in one sentence: "I haven't worked on a game with in-app purchases." Answer slot: your reason for wanting this role, in your own words; the pack does not supply one. Hold through two follow-ups without adding to the quotes | The stem "why you over…" aimed at F9. JD because it scores fit against the role |
| E2 | "Stop. You have talked for two minutes and I still do not know what you would do first. What is the first action?" | CASE | [generic] | Restate the question in a clause, then give one first action and the one fact it depends on. Do not restart the whole structure. If they push, hold the action and concede only what you do not yet know. The question needs no claim about your past, so the guidance makes none | An interruption inside the tabletop; the pressure bar is composure, not content. Included because a simulated outage invites it, which is the pack's inference |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc in your own words, in this order: the four years, the weekly calendar, the checklist, the monthly numbers. Each beat is exactly what its sentence says. Answer slot: why live operations and why Saltmarsh, in your own words; the pack does not supply a reason | The near-certain opener, and casual questions are still scored. EXP because it tests whether the CV lines hold up when told aloud |
| F2 | "Have you played Tidepool Tactics or Lantern Row?" | CO | [grounded] | Answer slot: if you have played either, say what you noticed about how its events ask players to show up; if you have not, say so plainly and say what you will do before the interview. Playing one before the interview and noting one event is a preparation step, not a claim | Both titles are named in the Larkspur announcement. CO because it tests homework depth; the question is a guess at how a hiring manager opens a rapport slot |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | C3, C1, A4, B1 |
| "coordinate design, art, engineering and community teams on each update" | C2, A1, A2 |
| "own the post-event review and the KPIs it reports" | D2, A3, D1 |
| "manage the release checklist with QA" | D3, A2, B3 |
| "3+ years producing live-service games or apps" | E1, F1 |
| "experience running a content calendar" | C3, B1, F1 |
| "comfortable with player-retention metrics" | D1, D2 |
| "clear written communication" | A5 |

## 6. Values cheat sheet

Included because the careers page documents a values conversation. Names and definitions are from Saltmarsh's published values page.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players disagree, the players' side takes priority | No quoted sentence of yours carries this one. Selection scaffold in B1, ending in its honest branch: if no such time comes to mind, say so plainly, then the nearest thing your material carries, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped for | No quoted sentence of yours carries this one. Selection scaffold in B2 and B4, each ending in its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses" — your message. The beats are the quote's own: you wrote it, and QA still uses it. See B3 for the answer slot |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background includes QA lead work at a console studio. How did that shape what you want from a producer working with QA?" | Tied to his published path. It connects to F4, the checklist line, and shows you read about him as well as the company |
| R2 | "With per-title event teams becoming one live-ops group from February 2027, where would this producer sit, and who would they work with day to day?" | The announcement changes what "two of our mobile titles" means in the JD. The answer also tells you whether the role is the one the JD describes |
| R3 | "What does the first quarter of the shared calendar need to prove?" | Asks for the measure of success before you are inside it, which links to F3's KPI line |
| R4 | "How is the post-event review used: who reads it, and what has changed because of one?" | The JD gives this to the producer to own. The answer tells you whether it drives decisions |
| R5 | "In the Outage Hour, what separates a strong tabletop from a weak one?" | Invites him to describe the format from the inside, and it is a question only a candidate who prepared for the tabletop would ask |
| R6 | "I haven't worked on a game with in-app purchases (your own words: "never worked on a game with in-app purchases"). What would you want me to learn first about the season-pass side?" | Turns the gap you have already conceded in C1 into a ramp plan, with him setting the priorities |

## 8. Prohibited claims

Built before the banks, from the fit snapshot. Nothing in the pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F2 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot; the ramp is a plan, never a past |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title. C3's slot stays inside the calendar |
| Owned the KPIs or the post-event review | Inflated form of F3 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: your material says presenting. D1's slot asks only what was counted and what was yours |
| Produced a live-service game | Inflated form of F5, in the JD's wording and not the quote's | F5's quote at its own scope: "4 years as an associate producer at a puzzle-game studio." Describe the work in F6's terms |

## 9. Sources

Provided: the JD text and your background summary, both in your message. No dossier was present.

| Query or fetch | Returned | Used for |
|---|---|---|
| Search: "Saltmarsh Games values" | https://saltmarshgames.com/values | Section 6; B1, B2, B3 |
| Search: "Saltmarsh Games interview process live operations producer" | https://saltmarshgames.com/careers/interviewing | Round format, persona weights; the Outage Hour assumption |
| Search: "Saltmarsh Games mobile studio news strategy" | https://saltmarshgames.com/news/project-larkspur (search snippet, dated September 2026; page not fetched) | A4, C1, F2, R2, F9 |
| Search: "Tobias Wrenfield Saltmarsh Games" | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet; page not fetched) | Section 3, A5, R1 |
| Fetch: https://saltmarshgames.com/values | The three values and their one-line definitions | Section 6 |
| Fetch: https://saltmarshgames.com/careers/interviewing | The recruiter call plus Outage Hour description; no take-home. The page carries no date | Section 4 and the title block |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Section 6, with the three values by official name; B1 to B4 |
| 2. `Saltmarsh Games interview process` for the role family | yes | The loop: one 60-minute session, tabletop then values; persona weights follow it |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur, from a search snippet only; moved A4, C1, F2, F9, R2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Section 3, from a search snippet only; moved A5 and R1 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- The recruiter's prep note on the Outage Hour (what the simulated outage involves, whether it touches either named title) → A1, A2, A3 and A5 stop being invented scenarios and match the real format
- Confirmation that Tobias Wrenfield is the hiring manager running the round → persona weights hold; if someone else runs it, Banks A to C reweight
- Your CV text → the same rows, quoted from the CV instead of from your summary, and possibly more story beats for B1, B2 and B4
- Anything you can say about the retention numbers (what was counted, who built the set) or about coordinating with design, art, engineering or community on a drop → F2, F3 and F7 upgrade, and D1 and C2 become story-mapped instead of answer slots
- The release checklist itself, or a redacted copy of one weekly calendar → F4 and F6 can move from medium to high confidence
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Project Larkspur, Tobias's talk read in full, and any reports of how the Outage Hour runs
- A `tuesday-dossier.md`, if you have one, → verified evidence and prohibited-claim guardrails from an earlier evidence check; the pack stands without it
