# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Role:** Product Manager, Platform APIs, Quartzline
- **Round:** one 45-minute conversation with the hiring manager, Thursday (from your message)
- **Interviewer:** hiring manager, name not given
- **Built from:** your dossier (`tuesday-dossier.md`, version 1.1). No web research ran in this build, see Sources

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

Rehearse in this order: **A1** first (the underwriter named it as the objection to expect, so it is the highest-ROI prep in the pack), then A2, D1 and D3, then the rest. Everything else is insurance.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows published company values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

No CO question appears because no company research ran. That is the honest cost, and the upgrade menu says what would add it.

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`, which stands in for the JD. Evidence is quoted from the dossier's `verified_candidate_evidence`. The dossier graded three areas itself: R1, the roadmap sub-claim, and R5. Rows F3, F4, F5, F7, F8 and F9 are graded by this pack, which is why they carry `[inferred]` or a stated source.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's strategy is bridge, and the bridge stays at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I wrote the internal integration playbook my team uses." The limit is the pack's observation: your material shows integration leadership, not product management, so it is positioned as adjacent and never as PM experience. Sourced plain acknowledgment, from prohibited_claims "Having held a product manager title or role": "I haven't held a product manager title." No years count |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area, "Owning a roadmap and prioritization authority (R1 sub-claim)", and prohibited_claims lists "Having owned a product roadmap". Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. No bridge and no answer slot, because the underwriter looked and found nothing |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | Words are the quote at its own scope. The limit is the pack's observation: your material says integrations led, not an API or platform product shipped. Answer slot: the requirement's wording makes a probe on what part of the product you touched likely. If anything you led or wrote shaped what the API product itself did, say what and how, in your own words; if nothing did, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | Neither quote says whether you worked with API docs or schemas, so the words are an answer slot. The requirement names docs and schemas, so expect a probe on which you have worked with. If you worked with docs or schemas in those integrations, say which and what you did with them, in your own words; if you did not, say so plainly and say what you would read first in this platform's docs and schemas |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes name clients and product, and do not show engineering or sales. The second quote is confirmed with limited inspectable proof, so expect a probe on it and volunteer its limit first. Answer slot: for each of engineering, sales and customers, if you worked with them directly, say what you did with them, in your own words; for any you did not, say so plainly and stay with the clients and product the quotes name |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's strategy is clarify, and no verified entry speaks to this requirement itself. Answer slot: the requirement's own wording makes a probe on what Agile delivery looks like where you have worked likely. If your delivery ran in sprints or a similar cadence, say how, in your own words; if it was not run that way, say so plainly. Then say what you would want to confirm about how this team defines it |
| F7 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: expect a probe on adoption measures. If you counted or tracked anything about how clients took up an integration, say what was counted, in your own words; if you did not, say so plainly and say what you would measure first. The dossier lists the current baseline as unknown, so asking about it is part of the answer |
| F8 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote is confirmed with limited inspectable proof and says the sessions fed client evidence to product, not that you ran discovery with partners. Answer slot: if you chose what to ask clients in those sessions, say how, in your own words; if the questions were set by someone else, or there were none, say so plainly and stay with the sessions as quoted |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | Words are the quote at its own scope. The limit is the pack's observation: your material says integrations led through UAT and go-live, not specs written or delivery driven with an engineering squad, and prohibited_claims lists "Having set prioritization for an engineering squad". Answer slot: if engineers worked with you on architecture or UAT in those integrations, say what you did with them, in your own words; if they did not, say so plainly |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic), then move on the dossier. Your message names a single 45-minute conversation, so no archetype loop is assumed. No interviewer information was given, so no interviewer signals are applied.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5, bank A) | Quiet probing of the PM-title and roadmap gaps, and why this move | High. A hiring manager is derisking gaps, and the underwriter named the objection (A1) from your confirmed evidence | Rehearse A1 until it is boring: concede plainly, offer the adjacent work at its own scope, name the limit, give a ramp plan |
| Case/Strategist (weight 4, bank B) | Live problems from the role: adoption, squad trade-offs, partner pain | High. The hiring-manager prior, and the role's responsibilities are decisions to make live | Clarify, objective, segmentation, approach, metrics, risks; think aloud; ask who decides before deciding |
| Conversational (weight 3, bank C) | "Walk me through the journey", casual probes on API work | Medium. A conversation format usually opens this way, and casual questions are still scored | A 90-second arc from your quoted sentences only; treat the casual API question as scored |
| Data-Driven Prober (weight 3, bank D) | Line-by-line on the three confirmed claims | Medium. Each claim is short and one carries a figure and one carries a stated limit | Know what you can and cannot say about how the figure was counted; volunteer the limit on the medium-confidence claim |
| Pressure (weight 2, bank E) | Time-boxed version of A1, attribution challenge | Low. Not the hiring-manager prior, but A1 is the likeliest place it appears | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator (weight 2, bank F) | Seam between you and the two squads | Low. The hiring manager is not a peer, but decision authority versus the squads is an open unknown in the dossier | Offer seam principles instead of pretending to know the seam; reciprocity framing |
| Values/Behavioral (no bank) | Stories mapped to published values | Low. No values-style round is detected: your message describes one conversation with the hiring manager and no published values were retrieved | None built. The upgrade menu says what would change this |

## Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The highest-ROI rehearsal in the pack, and the underwriter's own wording. Beat 1, concede first and plainly: "You're right: I haven't held a product manager title, and I haven't owned a product roadmap." Beat 2, offer the adjacent work at its own scope and name the limit: "What I can offer is the integration side. I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live — and I wrote the internal integration playbook my team uses. That is adjacent to this job, not the job itself." Beat 3, a ramp as a plan: "In the first weeks I'd learn which roadmap decisions are the PM's and which belong to the squads, and how adoption is measured today." Hold through two follow-ups by returning to the quoted work, never by adding to it. When pressed on why the other candidate is not better, concede the specific: a PM with three years in the seat has roadmap experience you do not. Do not tell the interviewer what the work proves, and add no years, title, team size or prioritization claim | F1 and F2 are where the objection presses hardest. The underwriter named it from evidence you confirmed, so it is not inferred. JD because it scores R1 | 
| A2 | "This role owns the roadmap for the partner-facing API platform. Which part of the job would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Name the roadmap before they do. Plain acknowledgment, sourced to the prohibited_claims item and the acknowledge_gap area: "Owning the roadmap is where I'd be weakest: I haven't owned a product roadmap." Then a ramp plan, said as a future: learn which roadmap decisions are the PM's alone and which belong to the squads, and learn how adoption is measured today, before proposing anything. Ask the interviewer those two questions (section 11, items 1 and 2). No bridge and no story: the underwriter found nothing to bridge with here | F2 is a capability gap the dossier records, so the strategy is acknowledge-and-ramp. JD because it scores the stated roadmap responsibility |
| A3 | "Tell me about an API or platform product you've shipped, or the nearest thing you've done." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3 at the quote's own scope: the integrations, 30+ of them, end to end from scoping to go-live. Say it as the nearest thing and leave the inference to them: "The nearest thing I have is the integration side: I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the requirement's wording makes a probe on what part of the product you touched likely. If anything you led or wrote shaped what the API product itself did, say what and how; if nothing did, or it was not yours, say so plainly and stay with the integrations you led | F3 is a must-have with only adjacent evidence, so this is probed in some form. JD because it scores R2, with EXP delivery |
| A4 | "The JD lists Agile delivery experience as preferred. Tell me how delivery was run on the work you've done." | JD | [grounded] | No quote in your material speaks to this, so there is no story to map, only a slot. Answer slot: the requirement's own wording, Agile delivery experience, is the probe. If your delivery ran in sprints or a similar cadence, say how, in your own words; if it was not run that way, say so plainly. Either way, close with what you would want to confirm about how this team defines it | F6 is a clarify area, and the evidence may exist without having been established. JD because it scores a stated requirement |
| A5 | "Why Product Manager, Platform APIs at Quartzline, and why now?" | JD | [generic] | Three parts, each your own: what you want to do next, why that points at this role, why here. The pack supplies no motive and none is in your material. Keep it consistent with A1: if your reason implies you already do product work, you have contradicted your own concession. Use the job's own responsibilities as the vocabulary: the partner-facing API platform, discovery with integration partners, adoption | Every Skeptic bank has a motivation probe, and it is where a bridge story either holds or leaks. JD because it scores fit to this role, with a motivation-consistency check |

### Bank B: Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose partners sign up for the API but few reach go-live. Sketch how you'd find out why — what do you need to know first?" | CASE | [generic] | Say the structure aloud: clarify, objective, segmentation, approach, metrics, risks. Your first clarifying question is the real one: how is adoption measured today, and what is the baseline. The dossier lists that as unknown, so asking it is not a stall. Segment by stage of the integration journey and by type of partner, form two or three hypotheses, and say which evidence would separate them. Challenge one premise: does "sign up" and "go live" mean the same event in their data. The guidance makes no claim about your past | Adoption metrics are a named responsibility with no stated baseline, so this is a live problem from the role. CASE because it scores structure, covering F7 |
| B2 | "The two squads each want the next sprint. One has a partner-requested endpoint, the other has reliability work. How do you decide?" | CASE | [generic] | Ask who decides before you decide: the PM, the squad leads or jointly. That is the dossier's unresolved authority question. Then state your criteria before the call, such as partner impact against the adoption goal, risk and cost, bring evidence to both leads, and say what you would escalate and to whom. Answer as how you would decide, never as how you have decided: a past claim about setting a squad's priorities is on the prohibited list | The JD names two squads, and decision authority over them is an open risk. CASE because it asks for a decision under constraint, with JD content from F9 |
| B3 | "A partner's lead engineer tells you your schema makes their integration painful. What do you do this week?" | CASE | [generic] | Clarify the pain first: which endpoint or field, what error, what they were trying to do. Reproduce it from the docs, check whether other partners hit the same thing, then sort it: a docs fix, a workaround or a schema change. A schema change goes to the squad that owns it with the evidence, and you close the loop with the partner. No claim about your past | Technical fluency is an important requirement and a live problem shows it without a story. CASE with JD content, covering F4 |
| B4 | "It's your first 90 days. What do you do, and what do you hold off on?" | CASE | [generic] | Learn before you change. Early: decision rights with the squads, the adoption baseline, conversations with integration partners, the roadmap as it stands. Hold off on committing to a roadmap of your own until you understand the constraints. Name a first written output, such as the hypotheses and open questions you would bring back. This is a plan, never a past | The hiring manager is buying a ramp for a candidate without the title, and F1 and F2 make the ramp the answer. CASE because it asks you to structure an open problem |

### Bank C: Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | A 90-second arc built from two beats only. First, the integrations: you led them, there were 30+, they ran end to end from scoping to go-live. Second, the playbook: you wrote it and your team uses it. Tell both in your own words. Close with one sentence on why this role, from A5. Include no title, years count or team size: none is in your material. Say early that this is integration work adjacent to product, so the interviewer does not have to be the one to say it | The biography question is where a bridge is first heard, and F1 is the bridge. EXP because it tests what was actually yours |
| C2 | "What are you actually playing with in APIs these days?" | JD | [grounded] | No quote speaks to recent hands-on work, so this is a slot. Answer slot: the requirement's wording, API docs and schemas, is the probe. Name what you have actually worked with lately, in your own words; if nothing recent comes to mind, say so plainly and say what you would look at first in this platform's docs and schemas | A casual question on a hot JD topic is still scored. JD because it scores R3, covering F4 |
| C3 | "Tell me about a time you worked across engineering, sales and customers." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick the one integration you would tell and say which stage it was, in your own words. The quote carries the beats: you led it, end to end, from scoping to go-live, with a client. Answer slot: the requirement names engineering, sales and customers, so expect a probe on each. For any of the three you worked with directly, say what you did with them; for any you did not, say so plainly and stay with the clients the quote names | R4 is a high-priority requirement and the quotes reach only part of it, per F5. JD because it scores a stated requirement; the open prompt takes its theme from the JD |

### Bank D: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led 30+ client integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words: how the 30+ was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly. The pack supplies no counting method, and any you did not use fails the second follow-up. The 30+ counts integrations, not clients or APIs | The only figure in your evidence is a magnet target. F1 holds it. EXP because it tests whether the number survives |
| D2 | "Walk me through the integration playbook your team uses." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The quote carries two beats: you wrote it, and your team uses it. What it covers and how the team uses it is yours to say, in your own words, because the pack does not know its contents. It is your strongest inspectable item, so be ready to offer to show it. Describe it as an internal playbook, not as API documentation or a product artifact | F1 and F4 both lean on this item, and a prober will go to what can be inspected. EXP because it tests what you actually produced |
| D3 | "Tell me about the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The quote carries three beats: the sessions ran quarterly, they were roadmap-input sessions, and they fed client evidence to product. This one is confirmed with limited inspectable proof, so expect a probe and volunteer the limit first: say what the sessions were, say what you know about what product did with the input, and say plainly what you do not know. If asked whether you owned the roadmap, hold on the sourced acknowledgment, from prohibited_claims "Having owned a product roadmap": "I haven't owned a product roadmap; the sessions fed client evidence to product." Then return to the sessions as quoted | F5 and F8 rest on this item, and its limit is where the seam is. EXP because it tests a claim with the thinnest proof behind it |

### Bank E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | A1 cut to four sentences. Pause and restate the question first. Concede, offer the quoted integration work at its own scope, name the limit, give the ramp. Hold through two follow-ups without adding to the quote; concede the specific, that the other candidate has roadmap experience you do not. Do not give a years number or a title | A1's time-boxed form; the same objection arrives faster. JD because it scores R1, with pressure delivery |
| E2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold at the quote's own verb, led, through two follow-ups. Answer slot: say in your own words which parts you did yourself and which were your team's; where you do not know the split, say so plainly and stay with what you led. Do not upgrade led to owned or decided | Attribution is the probe a quoted verb invites, so F1 gets it in a hard form. EXP because it scores what was actually yours |

### Bank F: Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You'd work with two engineering squads. Where's the seam between your job and theirs, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam: propose principles and ask where the line sits today. Principles such as decision rights agreed up front, evidence brought to the disagreement, and a named escalation path. Add reciprocity: what you would bring the squads, such as clear partner evidence on what to build and why. Everything is future tense. Never say you have set a squad's priorities | Decision authority over the squads is the dossier's open risk, so the seam question arrives in collegial form. CASE because it asks for a working rule, with JD content from F9 |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | No quote of yours speaks to this, so use selection criteria. Pick a time work crossed teams and credit could have gone to one person; it needs named teams, what you did against what others did, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | A standard peer-style probe on collaboration. EXP because it asks for a specific past instance, with a selection scaffold because the material does not carry one |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | A1, A5, C1, E1 |
| Own the roadmap for the partner-facing API platform | A2, D3 |
| R2 Shipped API or platform products | A3 |
| R3 Technical fluency: API docs, schemas | B3, C2, D2 |
| R4 Stakeholder management across engineering, sales, customers | C3, B2, F1 |
| R5 Agile delivery experience | A4 |
| Run discovery with integration partners | B4, D3 |
| Define and track adoption metrics | B1, B4 |
| Write specs and drive delivery with two engineering squads | B2, F1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority over the two squads but does not evidence it, and your answer to A2 depends on it. It reads as diligence and tells you what you would own |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are named as a responsibility with no baseline stated, so this resolves a real unknown. It also lets you use the language of B1 |
| 3 | "What would a strong first 90 days look like, and what would you want me to have learned by then?" | It turns the ramp plan from A1 and B4 into the interviewer's own success definition |
| 4 | "Where do you see the biggest gap between my background and what this role needs, and how would you want me to close it?" | It invites the objection from A1 into the open on your terms, and shows you can take a gap calmly |
| 5 | "How do the two squads take partner input today, and where does discovery with integration partners happen?" | It tests the discovery responsibility and shows where your quoted work would plug in without claiming it does |
| 6 | "How does this role work with sales and the customer-facing teams day to day?" | R4 names engineering, sales and customers, and this shows you are thinking about the working relationships |

## Prohibited claims

Items 1 to 3 come from the dossier's `prohibited_claims`. Items 4 to 6 are inflated forms built from the fit snapshot. No guidance cell, slot, reverse question or drill feedback asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims "Having held a product manager title or role" | F1's two quotes at their own scope, and the sourced acknowledgment: "I haven't held a product manager title." |
| Having owned a product roadmap | Sourced: dossier prohibited_claims "Having owned a product roadmap", and the acknowledge_gap area for the R1 sub-claim | The limiting quote, "Ran quarterly roadmap-input sessions feeding client evidence to product", and the sourced acknowledgment: "I haven't owned a product roadmap." No slot |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims "Having set prioritization for an engineering squad" | F9's quote at its own scope, and the sourced acknowledgment: "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says integrations led, not a product shipped. A3's slot stays inside the integrations |
| Wrote API documentation or schemas | Inflated form of F4, widened from the playbook | F4's quotes at their own scope. The limit is the pack's observation: the material says an internal playbook, not API docs or schemas. C2's slot asks only what you have worked with |
| Ran discovery with integration partners | Inflated form of F8, widened from the roadmap-input sessions | F8's quote at its own scope. The limit is the pack's observation: the sessions fed client evidence to product. D3 stays with the sessions as quoted |

## Sources

**Provided documents:** `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter. Sections consumed: `role_profile` (requirements and responsibilities, which stand as the JD's lines), `handoff_to_mock_interview` (verified_candidate_evidence, uncertain_or_weak_areas with allowed strategies, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims, high_priority_requirements) and `decision` (context only). Absent from the file: `evidence_map`, `evidence_state`, `risk_register`. The decision summary mentions seven years of integration leadership; no verified entry states a duration, so this pack states none.

**Searches sent:**

- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline API platform strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. Would have moved the values cheat sheet and the CO bank, which are absent |
| 2. Quartzline interview process, product manager | unavailable | Every call was refused. Would have moved loop structure and persona weights; weights rest on your message and the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. Would have moved a CO question and the strategy vocabulary |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission for web search: values, loop structure and strategy would run, adding a CO question and Quartzline's own vocabulary; a deeper pass, up to 6 more searches and 2 more fetches and several more minutes, would add recent organisation context and interviewer footprint once a name is known
- The interviewer's name: an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email: stated focus areas and any pre-declared deliverable, which would add a build section
- Your answers to the answer slots in F3, F4, F5, F6, F7, F8 and F9, said in your own words in a message: those rows regenerate from your own quoted sentences
- The raw CV behind the confirmed claims: the rows graded by this pack would move from `[inferred]` toward `[grounded]`
- Any agenda, notes or slides from the roadmap-input sessions: would raise the medium-confidence claim behind F5, F8 and D3
- How many hours you have before Thursday: a prioritized prep schedule sized to your time
