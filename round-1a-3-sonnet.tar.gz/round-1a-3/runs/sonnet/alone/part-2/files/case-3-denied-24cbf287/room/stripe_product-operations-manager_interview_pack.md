# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer name, relationship and number of sessions: not given. Built with flat persona weights. No CV and no job description were supplied, and no web research ran (see Sources), so nothing below is a fact about Stripe or about you.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive a follow-up; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework: company, strategy, how you think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Every row is labeled `[generic]` because nothing here comes from your material or from a source read for this pack. The upgrade menu says what turns rows into `[grounded]`.

## Fit snapshot

Worksheet variant: no CV and no JD were given, so there is no evidence to quote. The requirements are role-family prose, not quotes from a posting. Each bridge says what strong evidence would look like, then gives a selection scaffold.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or programs across product, engineering and go-to-market teams (role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is one named launch or program, what your part in it was, and what changed. Selection scaffold: pick one launch where you had a defined part, name the teams involved and your role in plain terms; if no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Defining and tracking metrics for products or processes (role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is one metric you helped define or track, how it was counted, and one decision it informed. Selection scaffold: pick one metric you can explain end to end; if no such metric comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Building or improving processes and tooling for product teams (role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is one process you changed, what it replaced, and how you knew it worked. Selection scaffold: pick one process change where you can separate your part from the team's; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing stakeholders without formal authority (role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is one disagreement with a more senior or a peer stakeholder, what you did, and the state of the relationship afterward. Selection scaffold: pick a case with a named stake; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Structured problem-solving on ambiguous operational problems (role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is one ambiguous problem, how you framed it before solving it, and what you decided. Selection scaffold: pick a problem where you set the frame; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Using data to find and size problems (role family, no posting read) | none given | none | [generic] | discovery | Strong evidence is one analysis you ran yourself, end to end, and one caveat you would put on it. Selection scaffold: pick an analysis you can walk through without notes; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 launches and programs | A1, A3, C3, E3, B4 |
| F2 metrics | A2, D1, D2 |
| F3 processes and tooling | A3, D2 |
| F4 stakeholder influence | C1, C2, E1, E2, F2, F3 |
| F5 structured problem-solving | A1, A2, B4, D3 |
| F6 data | A2, D1, D3 |
| Motivation and fit (not a requirement row) | B2, B3, G1, G2, G3 |
| Company knowledge | A4, G2, B3 |

## Persona table

No loop source was read, so the loop for this final round is not established and the weights are flat, on the generic screen, hiring manager, panel pattern. A final round may be several back-to-back sessions with different interviewers; if you know the schedule, the weights change.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems: plan this, diagnose that | Medium. Flat weight; a fourth question because the pack can rehearse it without your material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps; why leave, why here, why now | Medium. Flat weight; a fourth question because the gap it probes is yours to name | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| Values / Behavioral | Scenario probes, STAR-shaped stories | Medium. No published values were read, so themes come from the persona's standard stems | A scaffold per question; we for context, I for contribution |
| Data-Driven Prober | Inputs, denominators, assumptions | Medium. Flat weight | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Peer Evaluator | Seam between adjacent teams; what you would take off their plate | Medium. Flat weight | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Pressure | Interrupts, time-boxes, questions motive | Medium. Flat weight | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Friendly, unstructured; still scored | Medium. Flat weight | A 90-second arc for the biography question; never answer "I think you've covered everything" at the end |

Highest-ROI prep in this pack: B1. With no CV the pack cannot see your specific gap, and B1 asks you to name it yourself, which is the most predictable objection in any final round.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three product teams are each launching in the same month and each asks you for launch support. How do you decide what to do first, and what do you need to know before you decide?" | CASE | [generic] | Clarify first: what launch support means, what is at stake for each launch, which dates are fixed, who decides priority. State the objective, sort the launches by customer impact and readiness, propose one simple rule for ordering, name what you would measure, and name one risk and one premise you would check. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | Covers F1 and F5 as a live problem; CASE because it scores structure, not history |
| A2 | "A headline adoption metric for a recently launched product has dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Start with the definition and the instrumentation: did the metric or the data pipeline change. Then segment by customer type, region, channel and version, line the drop up against known changes and seasonality, rank hypotheses, say what you would pull first and whom you would call. Think aloud | Covers F2, F5 and F6; the stem is the Case persona's standard diagnostic |
| A3 | "Design the weekly operating rhythm for a product organisation of several teams: which meetings, documents and metrics, and what would you refuse to add?" | CASE | [generic] | Say what the rhythm is for (decisions, not status), then inputs and outputs, cadence tiers, owners, the few metrics, and the coordination cost of each ritual. Name one ritual you would cut, since the refusal shows judgment | Covers F1 and F3; the anti-pick is what separates this from a list of meetings |
| A4 | "What do you think a product operations function most needs to get right at a company like Stripe today?" | CO | [generic] | This pack could not fetch Stripe's current materials, so it supplies no facts. Before the interview, read Stripe's own current product and company pages, pick one or two facts you can cite by source, and tie your answer to them. Without that reading, answer on the function in general and say plainly that you are reasoning from general principles | A CO question grounded in strategy is a differentiator but needs research this pack lacks; it stays generic until you add sources |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in the pack. Pick a real gap against the role as you understand it, say it in one plain sentence, then give a concrete first step you would take in your first thirty days. Hold your composure through two follow-ups; concede the specific limit and do not fold on what you can do. If no such gap comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Skeptic's standard stem; JD because it scores the job as listed, gaps included |
| B2 | "Product operations means different things at different companies. What does it mean to you, and where does it stop?" | JD | [generic] | Give a one-sentence scope in your own words, say what it is not, and give a boundary example with product management and one with program management. The guidance makes no claim about your past | A scoping question from a skeptical interviewer; tests whether your picture of the role matches theirs |
| B3 | "Why are you looking to move now, and why this role in particular?" | JD | [generic] | Give your real reasons in three short parts: what you want more of, what draws you to this role, why now. For anything you say about Stripe, cite only what you have read in Stripe's own materials. If one part has no real answer, say so plainly instead of padding it | Motivation consistency is what the Skeptic scores; JD because it asks about fit with the role |
| B4 | "What would you do in your first 90 days, and what would you deliberately not touch?" | CASE | [generic] | Listen-first plan: learn how the teams work, map stakeholders, agree one small visible piece of work with your manager, decide how you would show it worked. Name what you would defer and why. Make no claim about what you have done before | Covers F1 and F5; the refusal half is the part most candidates skip |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment where you did not fold, and a relationship that was intact at the end. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values persona's standard stem; no published values were read, so the theme is the persona's, not Stripe's |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer cost and the metric cost were both real, say what you weighed and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard stem; VAL because it scores the behavior, not the outcome |
| C3 | "A team asks you to sign off a launch plan that you think is not ready, but the date is already public. What do you do?" | CASE | [generic] | Ask what the date's flexibility is and what readiness means here, separate what is truly blocking from what is merely uncomfortable, propose options with their costs, say who you would bring in, and say what you would record. The question asks about no past, so the guidance makes no claim | A live values problem from the role's launch-coordination work (F1); CASE delivery, VAL content |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a result you are proud of. How was its headline figure counted, and which assumption behind it would you defend least?" | EXP | [generic] | Cover the four slots in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how a figure was counted, say so plainly. If no result with a figure comes to mind, say so plainly, then describe the nearest result your material does carry in its own terms | Quantified claims are magnets for probers; this rehearses the defence without inventing a method |
| D2 | "You are asked to pick one metric that tells us whether a new internal process is working. What do you pick, and how could it mislead us?" | CASE | [generic] | State what the process is for, pick one metric that tracks that purpose, say how it could be gamed or misread, and name a second measure that would catch it. Say what you would need to know first | Covers F2 and F3 as a live problem |
| D3 | "Two dashboards show different weekly customer counts. How do you work out which one is right?" | CASE | [generic] | Compare definitions first (what counts as a customer, which time window, which source), then the pipelines, then sample reconciliation. Say who you would involve and what you would not conclude until checked | Covers F5 and F6; the definitions-first move is the credible one |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between us, and what happens when we disagree?" | VAL | [generic] | Propose seam principles rather than pretending to know the seam: who owns the decision, what each side needs from the other, how you surface disagreement early, and when you escalate. Frame it as what you bring their team as well as what you need | The Peer persona's standard stem; covers F4 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your principle in a sentence. If you give an example, pick a real case where credit was shared, use we for context and I for your part. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard stem; scores whether the hire reduces or adds to a peer's load |
| E3 | "What could you do in your first month that would actually take work off my plate?" | CASE | [generic] | Reciprocity framing: you would first learn what recurs and what hurts, then offer one small agreed piece of work, and ask what they would want taken first. Do not claim to know their pain before they tell you. The guidance makes no claim about your past | The collegial version of the capability probe; covers F1 |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give one true strength in your own words and one honest concession. Hold your position through two follow-ups; concede specifically and do not fold on the core point. Say nothing about the internal candidate | Standard stem; tests composure, not content |
| F2 | "Think of a result you describe on your résumé. How much of it was actually you?" | EXP | [generic] | Hold-then-concede: say exactly which part was yours in specific terms, say specifically what was others', and hold the first through two follow-ups. If you cannot separate your part from the team's, say so plainly | Attribution is where pressure interviewers press; EXP because it scores the claim, not the pressure |
| F3 | "You have told me what you would do, and I do not think it would work here. Convince me." | CASE | [generic] | Restate the objection, ask what specific constraint they see, hold the core of your approach through two follow-ups, then concede one specific limit and say how you would adapt. Do not abandon the approach to restore harmony | Tests holding a position without becoming defensive; covers F4 |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you are now, how you got here, why this role next. Each beat only what you can stand behind; no figure you cannot defend. Practise it aloud until it fits the time | The standard opener; casual in register, still scored |
| G2 | "What drew you to Stripe in the first place?" | CO | [generic] | Give your real reason. For anything about Stripe, cite only what you have read in its own materials and say where you read it. If your reason is general, say so plainly instead of dressing it up | Needs the research this pack lacks; stays generic until you add sources |
| G3 | "Where do you do your best work, and with what kind of manager?" | VAL | [generic] | Describe your working conditions truthfully and include one condition that is not ideal for you, with how you handle it. The guidance makes no claim about your past | A rapport question that scores self-awareness and fit |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success in this role look like at six months, and how would you know?" | It shows you think in outcomes and gives you the interviewer's own measure to refer back to |
| R2 | "What tends to make a launch or process hard to run well here?" | It signals you expect the hard parts and invites a candid answer rather than a pitch |
| R3 | "Where does this role sit relative to product, engineering and go-to-market teams, and where do those teams disagree about it?" | It surfaces the seam before you take the job and shows you plan for disagreement |
| R4 | "What would you want a new person here to have changed by the end of their first quarter?" | It turns an interrogation into a planning conversation and shows ownership |
| R5 | "How is this team's work measured, and who sees those measures?" | It shows you care about evidence and tells you how your work would be judged |
| R6 | "What are the next steps in the process and the timeline?" | A practical close that shows interest and sets expectations |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any fact about Stripe's values, strategy, loop or numbers | No search ran and no Stripe material was supplied; nothing was read for this pack | Say only what you have read yourself in Stripe's own current materials, and name where you read it |
| Any claim that you owned, led, built or measured something | No CV, quote or statement of yours was supplied; the pack has no sentence of yours to stand on | The selection scaffolds in the fit snapshot and banks, answered from your own record, each ending in the plain honest branch |

## Sources

Provided documents: your message only (company, role, final round). No JD, CV, dossier or interviewer information.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, each refused (permission to search was not granted in this session): "Stripe operating principles values"; "Stripe interview process Product Operations Manager"; "Stripe strategy news 2026 annual letter"; "Stripe Product Operations Manager job description responsibilities qualifications".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call was refused. Would have fed a values cheat sheet and named the principles for the VAL bank; neither could be built |
| 2. Stripe interview process, product operations | unavailable | Every call was refused. Would have established the loop and set persona weights; they are flat instead |
| 3. Stripe strategy and recent news | unavailable | Every call was refused. Would have grounded A4, B3 and G2; they stay generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Every call was refused. Would have supplied quoted requirements, so the fit snapshot uses unquoted role-family prose |

## Upgrade menu

- The job description text → the six role-family rows in the fit snapshot become `[grounded]` against the posting's own words, and JD-tagged questions re-point to its lines
- Your CV or a few lines on your background → the evidence column fills, scaffolds become story maps, and B1 becomes your specific objection instead of a general one
- The round format and who you meet → persona weights stop being flat; if your final is several sessions, send the schedule for per-session mini-packs
- Interviewer names → an interviewer read and a reverse question tied to their path
- Any recruiter guidance on focus areas or a pre-declared deliverable → coverage re-weighted, and a build section for any deliverable
- Search permission, or Stripe's own pages pasted in (values, careers or interview material, recent strategy) → A4, B3 and G2 gain specifics, and a values cheat sheet if a source names a values round; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is available once search is allowed
- A tuesday-dossier.md from an earlier evidence review, if you have one → verified evidence and absolute prohibited claims replace the inferred ones here; never required
