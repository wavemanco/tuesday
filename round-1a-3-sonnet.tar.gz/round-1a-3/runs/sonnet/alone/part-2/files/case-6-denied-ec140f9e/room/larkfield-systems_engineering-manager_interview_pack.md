# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Mode: loop, one shared fit snapshot and three round mini-packs.

| Round | Who | Format | Stated focus |
|---|---|---|---|
| 1, Tuesday | Director of Engineering (hiring manager, your would-be boss) | 45 min | Not stated |
| 2, the Thursday after | Two staff engineers and a product manager | 60 min panel | Not stated |
| 3, the following Monday | VP Engineering | 30 min | "values and leadership philosophy", per the recruiter |

Build status: no full JD and no CV were supplied, so the requirements are the one-sentence role description in your message and the evidence is the sentences in your message. Web research was refused by the host, so nothing here states a fact about Larkfield's values, strategy or interview process. No interviewer names were given, so there is no interviewer read. The loop itself, three sessions and who runs each, comes from your own words.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | The stated responsibilities, including the gaps |
| CO | Company and industry knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Answer guidance is scaffolding, not a script. Where a cell says answer slot, it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours. Neither branch is a failure. Question IDs run by persona across the loop: A to C are round 1, D, E and J are round 2, G to I are round 3. Fit-snapshot rows are F1 to F8, so no question ID starts with F.

## Prep triage

You have two weeks and three rounds. In order:

1. B1 and F6, before Tuesday. This is the highest-ROI prep in the pack: the hardware-roadmap objection will arrive in some form in every round, and D4 and J3 are it in a friendlier voice. Rehearse B1 aloud until the plain sentence stops costing you anything.
2. E1 and E2, before Thursday. Both are numbers from your own message, and a prober will walk each one down.
3. H1, I2 and G1, before Monday. Moving from leading six to leading eleven across two squads, and "never managed managers", are the Monday gap.
4. The answer slots in F1, F2, F4, F5 and F7: write your honest answer to each in a line or two. Anything you write and send me outside a drill becomes quoted evidence and the affected rows are regenerated.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team of six, not two squads, and the words stay at that size. Answer slot: the role names two squads, so expect a probe on whether you have had responsibility beyond one team. If you have, say what and how, in your own words; if not, say so plainly and stay with the team of six |
| F2 | "building device-management services" — role description in your message | none given | none | [grounded] | discovery | Your material is silent on device-management or IoT work, and silence is not an absence. Answer slot: if you have built or run services that manage fleets of devices, or close to it, say what and what part was yours, in your own words; if not, or it was not yours, say so plainly and give how you would get fluent, said as a plan |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the delivery clause) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote is one team's reliability quarter, not delivery across eleven engineers; no practice is added to it. Answer slot: if you ran a team's delivery beyond this quarter, say how, in your own words; if not, or it was shared, say so plainly and stay with the quarter. The 60% figure raises its own slots in E1 |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the hiring clause) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | The quote is a hiring loop you run and a count of interviews, not who decides or who owns headcount. Answer slot: if you shaped or made the hire decision, say how; if the decision sat with others, say so plainly and stay with running the loop. The figure raises its own slots in E2 |
| F5 | "own delivery, hiring and growth for 11 engineers" — role description in your message (the growth clause) | none given | none | [grounded] | discovery | Nothing in your material speaks to developing engineers. Answer slot: if you have helped an engineer grow, say who in general terms, what you did and what changed, in your own words; if you have not, say so plainly and say how you would start |
| F6 | "partner with hardware and product on roadmap" — role description in your message (the hardware clause) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Your sentence is about owning a roadmap and the role says partner, and your material is silent on working alongside a hardware team, so that part is B1's answer slot and not a claim. Then how you would learn it, said as a plan and never as a past |
| F7 | "partner with hardware and product on roadmap" — role description in your message (the product clause) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote touches roadmap pressure without showing whom it came from or whether you worked it through with product. Answer slot: if the pressure came from product and you worked it through with them, say how and what was yours; if it came from elsewhere, or it was not a product relationship, say so plainly and stay with the quarter |
| F8 | "values and leadership philosophy" — the recruiter's description of round 3, in your message | none given | none | [grounded] | discovery | Your material states no leadership principles. Answer slot (G1): name the principles you actually run a team by and one thing you did for each; if a principle has nothing behind it, say it is one you are working toward. "I've never managed managers" (F6's cell) is likely to surface in this round; its plain acknowledgment is in H1 |

No requirement in your material is a gate (authorization, licence, location, pay, schedule or travel), so no row is `hard_gate`.

---

# Round 1: Hiring manager, Director of Engineering (Tuesday, 45 min)

## Persona table, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on running two squads: priorities, first 90 days, headcount | High. The hiring-manager prior is Case/Strategist plus Skeptic, and the role description's delivery and roadmap clauses are easy to turn into live problems | Clarify, objective, options, call, risks; think aloud; challenge one premise respectfully. A story used inside a case rests on a quote or an answer slot |
| Skeptic | Quiet probing of hardware, scale from six to eleven, and why this domain | High. Same prior, and your own message names the hardware gap, so this is where the Director will derisk | Rehearse B1 until it is boring; bridges only from quoted adjacent evidence; concede specifically |
| Conversational | The opening "walk me through your background" and a hiring chat | Low. A Director meeting a future report opens friendly, but this round is a capability buy | Pre-script the 90-second arc from your quotes; treat casual questions as scored |

## Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have two squads, eleven engineers, a customer escalation on a device fleet and a hardware date that moves, all in the same week. Walk me through how you decide what the squads work on." | CASE | [generic] | Clarify first: how serious the escalation is, how firm the hardware date is, what each squad owns, who is already stretched. Then the objective, two or three options with their costs, the call, who you tell and when, and how you would know it worked. Think aloud, and challenge one premise politely. It needs no claim about your past, so the guidance makes none | A live problem from the role description's squads and roadmap-partnership clauses (F1, F6); CASE because this is the hiring-manager prior; `[generic]` because no company research ran |
| A2 | "It is your first month and you have inherited two squads you did not build. What do you do?" | CASE | [generic] | Structure it: what you ask each squad and each engineer before you decide anything, what you read to understand how delivery has gone, what you agree with the Director about the first ninety days, and one early change you could defend. Say what you would ask, not what you would announce | The role is a step in scope (F1, F3); CASE because it is a plan problem, asked at the altitude a Director uses |
| A3 | "Two open reqs, two squads, and you can fill one this quarter. How do you decide where it goes?" | CASE | [grounded] "I run our hiring loop for backend roles" | Decision structure: which squad's delivery risk is higher, what skills each lacks, what each squad's on-call load is, how long the hire takes to land. The quote stays at its own scope: you run the loop for backend roles. Answer slot: if you have had a say in where a hire goes, say how; if not, say so plainly and describe the criteria you would use | The hiring clause (F4) turned into a decision; CASE because the Director is testing judgment, not history |
| A4 | "A reliability investment is competing with feature commitments to product. How do you make the call, and who do you take it to?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Criteria first: what the reliability work protects, what slips if it goes ahead, who decides. Then the story in the quote's own terms: a reliability quarter, pushed through against roadmap pressure. The 60% is defended in E1, so say it only as you gave it. Answer slot: the role names partnering with product, so expect a probe on whom the pressure came from and how it was worked through. Say what you did and what was yours, in your own words; if the pressure was not from product, or the call was not yours alone, say so plainly and stay with the quarter | Your strongest quoted story meets the delivery and product clauses (F3, F7); CASE because it is asked as a decision |
| B1 | "Your background does not include owning a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. How do you handle that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "3 as a team lead of 6"; "I run our hiring loop for backend roles" | **The highest-ROI prep in the pack.** State the limit first, at its own scope: "I haven't owned a hardware-adjacent roadmap." Then the ramp, said as a plan: what you would ask hardware and the staff engineers in the first weeks, what you would learn about their lead times and constraints, and where you would lean on the Director. Follow-up 1, what do you know about working with hardware teams. Answer slot: if you have worked alongside a hardware team in any capacity, say how and what was yours; if not, say so plainly and return to the plan. Follow-up 2, so on day one you depend on others. Concede it specifically: the hardware side is where you ramp, and name how you would close it. Do not add a past. Follow-up 3, why not someone who already has. Hold on what your quotes carry: you are a team lead of six who runs the backend hiring loop, you have not owned a hardware-adjacent roadmap, and here is how you would close it | F6 is where the role's roadmap clause presses hardest and the one gap you named yourself, so this objection arrives in some form; JD because it scores a stated requirement, with the deepest follow-up ladder in the pack |
| B2 | "You have led a team of six. This is two squads and eleven engineers. What changes?" | EXP | [grounded] "3 as a team lead of 6" | Name the size plainly: the quote says a team lead of six. Then what you expect to change, as a plan: how you would divide attention between two squads, what you would ask each squad's leads, what you would stop doing yourself. Answer slot: if you have had responsibility beyond one team, say what; if not, say so plainly and stay with the team of six. Do not call the step small or large; let them draw it | The scale step in F1, probed at its quote | 
| B3 | "You are currently at a payments company. Why industrial IoT, and why now?" | EXP | [grounded] "currently at a payments company" | Give your actual reasons in your own words; the pack does not know them. Two beats: what draws you to this kind of problem, and what is true about the timing. One sentence each. Answer slot: if part of the reason is something you want to leave, say only what is true and keep it forward-looking | A reason-for-moving probe and the domain gap in F2; EXP because the Director is checking motivation consistency |
| B4 | "Tell me about a time you helped an engineer grow." | EXP | [generic] | Open prompt, theme from the role description's growth clause. Selection scaffold: pick one engineer and one change, with a named starting point, what you did and what changed for them. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would start | F5 has no quote behind it, so this is a scaffold; EXP because it asks what you actually did |
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering"; "3 as a team lead of 6"; "currently at a payments company" | A 90-second arc from these beats only: nine years in engineering, three of them as a team lead of six, now at a payments company. Add why this role is next, in your own words. Answer slot: give the one reason that is most true; if there are several, say so and lead with the strongest | The standard opener, and the first place your scope is stated (F1) |
| C2 | "Tell me about the hiring loop you run." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-map at the quote's scope: backend roles, the loop, about forty interviews last year. The figure's own slots are in E2. Answer slot: the role names hiring for eleven engineers, so expect a probe on who decides beyond the loop. If the decision or part of it was yours, say how; if it sat with others, say so plainly and stay with running the loop | F4 is the hiring evidence and the likeliest hiring probe; JD because it scores the hiring clause |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would you want the two squads to have delivered, and in what shape, by the end of my first six months?" | Lets you hear the Director's scoring sheet and tune A2, and shows you are planning against an outcome |
| R1.2 | "Where do hardware dependencies bite the squads hardest today?" | Lets you hear the real seam before proposing one, which is the honest answer to F6 |
| R1.3 | "How are tech leads or senior engineers spread across the two squads, and how are decisions made between them?" | Gets the structure behind B2 and H2 before you propose one |
| R1.4 | "What does growth look like for engineers here, and what support do managers get to help it happen?" | Addresses the growth clause (F5) from the receiving side |
| R1.5 | "What would make you hesitate about hiring me for this role, so I can address it now?" | Invites the objection in the open; a rehearsed, non-defensive answer to B1 pays off most right here |

---

# Round 2: Panel, two staff engineers and a product manager (the Thursday after, 60 min)

## Persona table, round 2

No names were given, so personas are assigned by role and not per person. Assumption: the staff engineers are technical senior people on or beside the squads, and the product manager is a cross-functional partner.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | The seam between product and engineering, disagreement with roadmap owners, "what would you need from us" | High. A product manager and staff engineers are pricing what you add to their work; the panel prior blends each member's relationship | Reciprocity framing; seam principles, not a pretended seam; disagreement stories with spine and tact |
| Data-Driven Prober | Your two numbers, walked down to inputs | High. Staff engineers read claims for assumptions, and both of your figures are in the evidence | Say how each figure was counted or that you do not know; name the weakest assumption before they do |
| Values/Behavioral | Scenario questions from the product manager | Medium. Cross-functional interviewers tend to ask behavioral questions; no published values are in hand, so these use the standard stems | Story from a quote where one carries it, a selection scaffold with an honest branch where none does |
| Case/Strategist, Pressure, Conversational | Not a main style in this room | Low. They get banks in rounds 1 and 3, so you meet each style once | None needed beyond rounds 1 and 3 |

## Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Product and engineering sit side by side here. Where is the seam on roadmap decisions, and what happens when we disagree?" | CASE | [generic] | Offer principles, not a pretended seam: what product owns, what engineering owns, what is decided jointly, how a disagreement is escalated and recorded. Ask what it looks like today before proposing. Close with what you would offer them going forward and what you need from them | The product-clause probe (F7) in the product manager's own words; CASE because it asks for a structure |
| D2 | "Tell me about a time you disagreed with someone who owned the roadmap, and how it ended." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Open prompt, theme from the role description's roadmap clause. Story-map at the quote's scope: the reliability quarter, the roadmap pressure, you pushed it through; the how is yours to tell. Answer slot: say who applied the pressure and how you worked it through with them; if they were not a roadmap owner or from product, say so plainly. Then what, if anything, you gave up; if nothing, say so | F7 is low confidence, so this is a story-map plus an honest branch; VAL because the panel scores disagreement style |
| D3 | "You choose a reliability fix over a feature the squad wanted, and one of your staff engineers thinks you are wrong. What do you do?" | CASE | [generic] | Structure: hear the technical case fully, state your criteria, say who has decision rights, say what would change your mind, record the disagreement and the decision. Concede one specific point where they have it. It makes no claim about your past | Staff engineers test whether a manager can be wrong in front of them (F1, F3); CASE because it is a live decision |
| D4 | "Hardware dates and software dates do not always line up. How would you plan with us when they do not?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Open with the plain sentence, at its own scope: "I haven't owned a hardware-adjacent roadmap." Then a planning structure as a plan: find out what the dependency is, split work so the software side delivers value on its own, agree an early-warning signal with hardware, say what you would not commit to until it is known | F6 returns in collegial packaging, as the persona model predicts; CASE because it asks how you would plan |
| E1 | "Your team's on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The four defend-the-number slots, in your own words: how the figure was counted, or say plainly that you do not know; what it is sensitive to; the assumption you would defend least, named before they do; and which part was yours. Your sentence says you pushed the quarter through and that it was your team's burden, and that is the scope to hold. Never name a measure or baseline you did not use | The headline metric in F3; EXP because a prober checks attribution and counting |
| E2 | "About 40 interviews last year. How was that counted, and how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Slots, in your own words: what the 40 counts, or say plainly you do not know; whether they were interviews you conducted, ones you scheduled or the loop's total; what the figure is sensitive to; the assumption you would defend least. Keep the word "about" | The second figure in your evidence (F4); EXP because the ambiguity in "interviews" is exactly what a prober tests |
| E3 | "Tell me about a hiring decision you were part of and how the group reached it." | EXP | [grounded] "I run our hiring loop for backend roles" | Open prompt, theme from the role description's hiring clause. Pick one decision. Tell it at the quote's scope: you run the loop, so describe how the group got to the decision. Answer slot: say what your part in the decision was; if the group reached it without disagreement, say so | Gives the hiring clause (F4) a story and tests whether you can describe the group's reasoning |
| E4 | "Device-management services are the core of these squads. How would you get fluent in the domain, and how do you judge a design proposal there?" | JD | [generic] | A plan and not a past: who you would learn from first, what you would read, and how you would test a proposal: failure modes, rollout and rollback, how it is operated. Answer slot: if you have worked with systems that manage fleets of devices, or close to it, say how and what was yours; if not, say so plainly and give the plan | The domain gap in F2, in a staff engineer's voice; JD because it scores the stated services |
| J1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact at the end. Answer slot: if the reliability quarter involved telling someone senior something unwelcome, say what and how it landed; if not, say so plainly and use another time. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values stem for a cross-functional interviewer (F7); VAL because it scores whether a hard truth landed |
| J2 | "How do you handle credit when work spans squads?" | VAL | [generic] | State principles, not a past: name the people, "we" for context and "I" for your contribution, and credit in the room where the decision is made. It makes no claim about your history | The standard credit probe from a cross-functional peer; VAL because it scores partnership |
| J3 | "A hardware dependency slips two sprints and I need something to tell a customer tomorrow. What do you tell me?" | CASE | [generic] | Structure: what is known and what is not, the options, what you can commit to and what you cannot, when you will update, and who else needs to know. Do not invent facts to sound certain | The seam from the product manager's side (F6, F7); CASE because it is a live problem |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What do staff engineers here most want a manager to protect, or fix?" | Shows you see staff engineers as people to serve and not only manage |
| R2.2 | "How does a roadmap disagreement between product and engineering actually get settled today?" | Gets the real seam before you propose one, for D1 |
| R2.3 | "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity question: asks what you can give the panel and not only what you need |
| R2.4 | "Where does hardware most often change your plans?" | Turns F6 into curiosity and gets the most useful answer you will hear all week |
| R2.5 | "How do you learn what customers are experiencing on deployed devices?" | Shows interest in the product and gives the product manager an easy, expansive answer |

---

# Round 3: VP Engineering, values and leadership philosophy (the following Monday, 30 min)

## Persona table, round 3

Assumption: the VP Engineering sits above the Director, so this is a skip-level conversation. If that is wrong, tell me and I will reweight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy, hard-truth and customer stories | High. The recruiter's own words name this round as values and leadership philosophy; the skip-level prior alone would put Case first, and the recruiter's description outweighs it. No published values are in hand, so stems are the standard ones | Stories from a quote where one carries it; selection scaffolds with an honest branch elsewhere; "we" for context, "I" for contribution |
| Skeptic | Moving from a team of six to eleven across two squads, and "never managed managers" | Medium. A VP reads a leadership gap as the central question of a values round | Plain sentence, then a plan; concede specifically |
| Pressure | "Sixty seconds, why you" | Low to medium. The skip-level prior includes Pressure, and 30 minutes invites time-boxing | Pause, restate, hold what your quotes carry, concede the gap |
| Case/Strategist (CO) | One strategy-flavored question | Low. The prior is Case/Strategist, but 30 minutes and a values brief leave little room | Say what you read and from where; do not assert Larkfield facts |

## Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Open prompt, theme from the recruiter's "values and leadership philosophy". Selection scaffold: pick two or three principles you actually run a team by, and attach one thing you did to each; an adjective without an instance is weak. Answer slot: if the reliability quarter shows one of your principles, say which and in your own words; if a principle has nothing behind it, say it is one you are working toward | F8 has no quote behind it, so this is a scaffold with a conditional use of the one story you have |
| G2 | "How do you decide when to hold the line against roadmap pressure and when to give way?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Story-map at the quote's scope: the quarter, the pressure, you pushed it through. Then your criteria in your own words. Answer slot: if there was a time you gave way, say what you weighed; if not, say so plainly and describe your criteria as the approach you would take | F3 is the delivery-judgment evidence; VAL because leadership philosophy is the round's brief |
| G3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Standard values stem. Selection scaffold: pick a time with a named customer need, an internal measure it cost you, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | No quote carries this, so it is a scaffold; the stem is the persona model's and not a Larkfield value |
| H1 | "You have led a team of six and have not managed managers. What does it take to lead leaders, and where are you today?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "3 as a team lead of 6" | The plain sentence first: "I haven't managed managers." Then what you would want to learn, as a plan: how you decide what to delegate, how you coach someone who coaches others, who you would ask. Concede specifically and do not describe the step as small. Do not borrow the question's phrase "leading leaders" as experience. Hold what the second quote carries: a team lead of six | The leadership gap you flagged, in the round where leadership is the brief (F1, F8); EXP because it checks self-assessment honesty |
| H2 | "Eleven engineers in two squads. How do you structure leadership inside them, and what do you hand off?" | CASE | [generic] | Ask what structure exists first. Then principles: what stays with you, what is delegated, how you would know delegation is working. It makes no claim about your past | The scale step (F1) as a structure problem; CASE because it is asked about the future |
| H3 | "Why leave where you are, and why us?" | EXP | [grounded] "currently at a payments company" | Your actual reasons, in your own words; the pack does not know them. Keep it forward-looking. The "why us" needs Larkfield-specific material this pack could not research, so read their careers page and product material yourself and say where it came from | A skip-level motivation probe (F2); EXP because it scores consistency with what you told the Director |
| I1 | "Where do you see industrial IoT device management heading, and what should an engineering organization like ours be strongest at?" | CO | [generic] | No research ran, so the substance is yours to build before Monday from Larkfield's own site, careers page and product material. Say what you read and where it came from, say plainly what you do not know about Larkfield, then ask the VP what they see | F2 plus an honest cost of declined research; CO because it tests the altitude of your homework |
| I2 | "Sixty seconds: why you over someone who has already managed managers?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "3 as a team lead of 6"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause and restate the question. Hold only what your quotes carry: you are a team lead of six, you run the backend hiring loop. Concede specifically: "I haven't managed managers." Do not argue you are better; say what you would bring from those quotes and stop. Hold through two follow-ups, concede the gap and do not fold on what you have done | The pressure form of F1, F4 and F6 together; EXP because it scores hold-then-concede and not the content |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does good leadership look like at Larkfield, in your own words?" | Hands the VP the values round's own topic and shows you are listening for their version |
| R3.2 | "Where does engineering management here most need to be stronger in the next year?" | Shows altitude and gives you something to refer back to |
| R3.3 | "How do you develop managers here, especially toward leading other leaders?" | Turns H1's gap into a question about their growth path |
| R3.4 | "What is a decision your leaders made recently that reflects how you want people here to lead?" | Gets a story you can map your own to |
| R3.5 | "How do hardware and software leadership work together at your level?" | Speaks to F6 from the top and signals you are thinking about the seam |

---

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" | A1, A2, B2, H2, and G2 for judgment |
| "building device-management services" (domain) | A1, B3, E4, H3, I1 |
| "own delivery" | A1, A4, D3, G2 |
| hiring (clause of "own delivery, hiring and growth for 11 engineers") | A3, C2, E2, E3 |
| growth (same clause) | B4, R1.4 |
| "partner with hardware and product on roadmap" | B1, A4, D1, D2, D4, J3 |
| "values and leadership philosophy" (round 3) | G1, G2, G3, J1, H1 |
| "11 engineers" (scale) | B2, H2, I2 |

## Prohibited claims

Built from the fit snapshot before the banks. None of these appears in any guidance cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | A negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." Nothing added to make it feel smaller |
| Managed managers | A negative you stated, F6 | "I haven't managed managers." Then the plan in H1 |
| Led or owned delivery across two squads or eleven engineers | Inflated form of F1 and F3 | The F1 quote at its own scope. The limit is the pack's observation: the material says a team lead of six and one reliability quarter, not two squads |
| Owned hiring for the team, or made the hire decisions | Inflated form of F4 | The F4 quote at its own scope. The limit is the pack's observation: the material says a loop you run, not headcount or decisions; C2 and E3 keep their slots inside the loop |
| Cut the on-call burden by 60% on your own, or designed the reliability work | Inflated form of F3 | The F3 quote at its own scope: "pushed a reliability quarter through". The pack observes that the sentence says pushed through, not built or designed; E1 asks only which part was yours |

## Sources

Provided: your message, containing the role description, the three rounds and their formats, the recruiter's description of round 3, and your background. No dossier, JD, CV or interviewer profile was supplied.

Searches sent, all refused by the host ("Claude requested permissions to use WebSearch, but you haven't granted it yet"):

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused
- "Engineering Manager device management IoT platform job description": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet and named the values for VAL questions; instead VAL banks use the standard stems and no value names appear |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have confirmed loop structure; the loop here rests only on your own words, and persona weights follow them |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded I1 and any strategy case; I1 is `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | unavailable | Would have given a fuller requirement list for the fit snapshot; it rests on the one-sentence role description |

## Upgrade menu

- The full JD text → F1 to F8 gain the posting's own requirements, and mid-list items the one-sentence description may omit get questions and coverage rows
- Your CV or current-role bullets → more of your own sentences in the evidence column, so more guidance cells can be story-mapped and fewer are scaffolds; for an engineering manager, the inspectable artifacts that would raise `medium` to `high` are the incident or on-call report behind the reliability quarter and the hiring loop's scorecard or interview record
- Your honest answers to the slots in F1, F2, F4, F5, F6 and F7 → those rows move off `discovery` and the affected banks regenerate
- The recruiter's note on each round, especially whether the Thursday panel includes an exercise or presentation → a graded-deliverable build section if one was declared
- The panel members' and VP's names, titles or public profiles → an interviewer read, persona weights per person and a reverse question tied to each one's career path
- Search access, or Larkfield's values and careers pages pasted → a values cheat sheet, current strategy for I1, and a check on the loop; a deeper research pass would be up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from earlier work → user-confirmed evidence and prohibited claims arrive ready-made and the pack's highest-ROI objection is read from evidence, not inferred
