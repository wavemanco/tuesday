# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations (the hiring manager). **Candidate:** Femi.

**Round:** a 60-minute session with Tobias. The careers page describes the loop as "a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." This pack assumes your Friday session is that Outage Hour. If it is not, the persona weights in section 6 are the part to redo.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Whether your claims survive scrutiny and you can say what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current strategy and can think at its level |
| CASE | A live problem from the real role, scored on structure and reasoning |

- **Answer slots.** An answer slot is an instruction for the interview, not a question for me. It names a likely probe and gives you two honest branches: say what you did, or say plainly there was no such step or it was not yours, and return to what you have stated.
- **IDs.** Fit-snapshot rows are F1 to F9. Question banks use letters A to E and G, skipping F, so an F-number always means a fit row.
- **Labels.** `[grounded]` is traceable to your message, the JD or a page I read. `[inferred]` is derived from a named source. `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not events and not two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's events line and its two titles make a probe on both likely. If any of your drops were time-limited events, say how they differed from the weekly drops; if none were, or you ran only the one title, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | Your material states no coordination with these teams, and the one thing it states is that you have not led a team; the plain words are "I've never led a team." Answer slot: the JD's four teams make a probe on which of them you worked with likely. If running the drop calendar meant working with any of them, say which and what you asked of each, in your own words; if it meant none of them, or you were not the one asking, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers to the studio head, not that you ran a review or chose the numbers, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who produced those numbers and what followed likely. If you also built the numbers or reviewed them with others, say which part, in your own words; if the numbers came from someone else and you presented them, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in terms: you wrote the checklist and QA still uses it, and a named artifact beats an adjective. It is a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms, "I wrote the release checklist our QA team still uses," and stop where it stops: the quote does not say you ran each release through it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and a calendar you ran, and does not show whether the title was live-service. Answer slot: the JD's live-service line makes a probe on that likely. If your main title was being updated while players were playing it, say how, in your own words; if it was not, say so plainly and stay with the four years and the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the requirement in close terms: a weekly content-drop calendar, run for two years. Lead with it as stated. Expect a probe on what was yours to decide inside it, which the quote does not say (D2) |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in role terms: retention numbers, presented every month. Lead with it as stated: "I presented the monthly retention numbers to the studio head." A requirement that names retention draws a "how was that counted" probe, which D1 holds as an answer slot |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | Your material shows one written document and does not show whether it was clear to the people who used it. Answer slot: the JD's written-communication line makes a probe on an example likely. If the checklist is your best example, say what makes it easy to follow, in your own words; if another piece of writing is better, use that and say what it was; if you have none to point to, say so plainly |
| F9 | Season-pass and in-app-purchase context behind the live calendar; not a JD line, derived from the Project Larkspur announcement (search result, September 2026) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past, in your own words. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## 3. Reading the interviewer

Public professional footprint only.

| Public fact | Source | Provenance |
|---|---|---|
| Head of Live Operations at Saltmarsh Games | GDC 2026 talk listing, search result | [grounded] |
| Previously a QA lead at a console studio | Same listing | [grounded] |
| Gave the talk "Patch Notes Are a Promise"; the argument as listed: a live team is judged by how often its patch notes describe what actually shipped | Same listing | [grounded] |

| What it means for Friday | Derived from | Provenance |
|---|---|---|
| Mirror opportunity, shared vocabulary rather than a shared jump: Tobias's QA background and your release checklist sit in the same territory. The sentence that carries your side is F4's: "Wrote the release checklist our QA team still uses." Say it at that scope | The QA-lead fact and F4 | [inferred] |
| The stated test is announced versus shipped, so expect attention to whether what you say matches what you did. This is the same discipline as the prohibited-claims list in section 4 | The talk's listed argument | [inferred] |
| Read or watch the talk before Friday. Refer to it only for what you actually took from it, in your own words; I saw only a listing, not the talk | The talk listing | [inferred] |

## 4. Prohibited claims

Built before the banks and binding on every guidance cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for one main title. D2's slot stays inside the calendar you ran |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope: you presented the numbers. A5's and D1's slots ask only who produced them and what followed |
| Managed releases, or ran each release through the checklist | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist and QA still uses it |
| Four years of live-service production | Inflated form of F5 | F5's quotes at their scope: four years as an associate producer, and a calendar you ran. Whether the title was live-service is an answer slot |
| Led or managed a team | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never led a team." No slot |
| Worked on in-app purchases or a season pass | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never worked on a game with in-app purchases." No slot |

## 5. Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| Plan and run the live-events calendar for two mobile titles | D2, A3, A4 |
| Coordinate design, art, engineering and community on each update | C3, A1 |
| Own the post-event review and the KPIs it reports | A5, E2 |
| Manage the release checklist with QA | D3, B3, A5 |
| 3+ years producing live-service games or apps | C4 |
| Experience running a content calendar | D2, G1 |
| Comfortable with player-retention metrics | D1, E2, A5 |
| Clear written communication | D3, A2 |
| Season-pass and in-app-purchase context (not a JD line) | C1, E1 |
| Value: Players Before Plans | B1, A3 |
| Value: Ship the Patch Not the Promise | B2, A2 |
| Value: Leave the Build Greener | B3, A5 |

## 6. Persona table

The loop source says the hour is a tabletop followed by a values conversation. The relationship prior for a hiring manager is Case plus Skeptic. Weights follow both, and you can recalibrate if you know something I do not.

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The Outage Hour tabletop: a simulated outage during a live event | Highest, 5 questions. The careers page makes the tabletop half the hour, and the hiring-manager prior agrees | Clarify, then objective, then who you pull in, then the first message to players, then what you would review afterwards. Think aloud and challenge one premise |
| B. Values / Behavioral | The second half of the hour: a values conversation on the three published values | High, 4 questions. The careers page documents the conversation, so it is guaranteed in this session | One story per value where a quoted sentence carries one; a selection scaffold with its honest branch where none does |
| C. Skeptic | Probing the gaps you stated: in-app purchases and leading a team | High, 4 questions. The hiring-manager prior, plus two gaps you stated yourself. Likelihood is a judgement: the JD does not mention monetization, but the Larkspur announcement describes a season-pass model | Rehearse C1 until it is boring. Name the limit before it is asked. Give a ramp plan as a plan, never a past |
| D. Data-Driven Prober | Line-by-line questions on your three claims | Medium, 3 questions. Tobias's public QA background and a talk about announced versus shipped suggest precision on what you did. The weighting is a reading, not a fact about Tobias | Know what you can and cannot say about how each number was counted. Say plainly what you do not know |
| E. Pressure | Time-boxed or devil's-advocate challenges | Low, 2 questions. No source says the tabletop is timed, so this stays a short drill | Pause, restate, hold on what you stated, concede what you have not done |
| G. Conversational | The opener and any casual question | Low, 2 questions. Casual questions in a 60-minute hour are still scored | A 90-second arc built only from your own sentences |

**Highest-ROI prep: C1.** It is the likeliest objection and the one aimed at a gap you stated, which makes it the one place a pack is most tempted to thicken your answer and an interviewer is most likely to test it. Rehearse it through all three follow-up levels.

## 7. Question banks

### A. Case / Strategist (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a limited-time event and players can't log in while the event timer keeps running. You're the producer in the room. What do you need to know first, and what do you do in the first fifteen minutes?" | CASE | [inferred] | Clarify aloud first: which title and platform, whether progress or anything players paid for is affected, whether engineering has a cause or only symptoms. Then the objective: an honest message to players quickly, and the right people in one room. Pull in engineering, community and QA, and ask design what the timer allows. Agree one owner for player-facing words. If purchases are in play, say plainly that you would find out who decides compensation here before proposing anything. The question needs no claim about your past, so the guidance makes none | Built from the careers page's described tabletop, which the scenario copies in shape only; the scenario itself is this pack's. CASE because it scores structure, and it touches the JD's four teams (F2's requirement) without asking you to have coordinated them |
| A2 | "Players have been locked out for an hour. Engineering won't commit to a fix time and community wants to post something now. Say out loud what the first player message says." | CASE | [inferred] | Three short sentences: what is confirmed, what is not known yet, when the next update comes. The published value reads "we announce what is built, not what is hoped"; an ETA nobody has committed to is hope, so commit to a time for the next update rather than a time for the fix. Then say what you would do if that time arrives with no news: post anyway. No claim about your past is needed | Scores the JD's written-communication line (F8) as a live task, and the value Ship the Patch Not the Promise, which the values page defines in the words quoted. CASE delivery, JD content |
| A3 | "The outage is fixed, but players lost the first six hours of a weekend event. Do you extend it, compensate players, or leave it, and how do you decide?" | CASE | [inferred] | Decision structure: what players actually lost, which you would ask before deciding; who owns compensation here; what an extension does to the next event on the calendar; how you would tell players. The published value reads "when the calendar and the players disagree, the players win", so lean toward the option that keeps faith with players and say what it costs the calendar. Name the assumption you would defend least before you are asked | Tests the calendar-versus-players trade at the heart of the first value and the calendar ownership in F1's requirement, as a decision rather than a record. Needs nothing about your past |
| A4 | "Project Larkspur puts both titles on one events calendar from February. What breaks first when two live games share a calendar, and what do you set up in your first month?" | CO | [inferred] | Think aloud and state a hypothesis early, for instance that the hardest part is two titles wanting the same slot. Ask what the single live-ops group arbitrates and who has the final call. Your honest base is one title: "I ran the weekly content-drop calendar for our main title for the last two years." Say that, then what two titles change. Answer slot: if your calendar ever clashed with another team's schedule, say what you did; if it never did, say so plainly and say what you would set up first | The differentiator question from current strategy; derived from the announcement snippet only, which is why it is `[inferred]`. CO because it asks for company-level thinking. F1 is the evidence and its limit: one title | 
| A5 | "The event is over, and the outage was in the middle of it. Walk me through the review you'd run and the handful of numbers you'd report out of it." | JD | [grounded] | Structure: a timeline of what happened, what players experienced, what caused it versus what made it worse, what changes, who owns each change, and a short written summary shared. Where the checklist belongs: "Wrote the release checklist our QA team still uses." is your one artifact, so say where a finding would change it. For the numbers, the evidence you hold is "Presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-KPIs line makes a probe on who chose numbers like these likely. If you chose which numbers went in the report, say how, in your own words; if the numbers were set by someone else, say so plainly and stay with presenting them | The JD's post-event-review line (F3) and checklist line (F4) in one live question; the value Leave the Build Greener is the second reason it is likely. JD content, CASE delivery |

### B. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time a scheduled drop and what players were experiencing pulled apart. It needs what players were seeing, the decision, who agreed, and what happened to the date. Your material carries a calendar but no such moment. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the calendar you ran, or how you would handle it | The first published value, Players Before Plans, defined on the values page as "when the calendar and the players disagree, the players win". F1 is the nearest evidence and carries no conflict, so this is a scaffold. VAL because it scores behavior against that value |
| B2 | "Tell me about a time something announced ahead of a release had to be narrowed or corrected before players saw it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: it needs what was said, what was built, who caught the difference, and what the correction cost. The nearest thing you hold is the checklist. Answer slot: if the checklist has a step about what gets announced, say what it is and why it is there; if it does not, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second value, Ship the Patch Not the Promise, defined as "we announce what is built, not what is hoped"; Tobias's published talk argument is on the same theme. F4 is the nearest evidence. VAL |
| B3 | "Tell me about a time a release taught you something that changed a checklist or a process." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: the beats the quote states are that you wrote the release checklist and that QA still uses it; tell those in your own words. Answer slot: the value says every release leaves "the checklist better than it found them", so expect a probe on whether yours has changed. If it changed after a release, say what changed and what prompted it; if it has not changed, or you cannot say, say so plainly and stay with the checklist as written | The third value, Leave the Build Greener, and your strongest quoted story, F4. VAL |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | Selection scaffold. It needs a named stake, what you said, and the relationship intact afterwards. The nearest thing you hold is presenting the numbers to the studio head. Answer slot: if any month's numbers were unwelcome, say what you said and how it landed; if none were, or you were presenting numbers others produced, say so plainly. Choose a story where the hard truth landed; where your material shows none, say so rather than supplying an ending | A standard values-round stem the loop's values conversation makes plausible; `[generic]` because no published value names it. F3 is the nearest evidence. VAL |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see in-app purchases anywhere in your background. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | **Highest-ROI rehearsal.** Say the limit first, before it is probed: "I've never worked on a game with in-app purchases." Hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head". Do not imply either involved purchases. Then your plan, as a plan: what you would learn first and from whom, in your own words. Follow-up level one, "So what would you look at first in a purchase metric?": say you have not worked with one and say how you would learn what it counts; do not offer a definition you could not repeat. Level two, "Does that worry you for a role that owns the post-event KPIs?": concede plainly that it is the steepest climb and name what you would ask for in the first month. Level three, "What would you need from me?": answer with one specific ask. Never fold on what you have stated, and never add to it | F9 is the gap and F7, F6 the adjacent evidence. It is the likeliest objection because the announcement describes a season-pass model and you have said you have no purchase experience; the likelihood is a judgement, shown in section 6. JD because it scores whether you can do the listed role including this gap |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick one and say it plainly before the follow-up. The words your own sentence gives you are "I've never worked on a game with in-app purchases" or "I've never led a team." Choose the one you can follow with how you would close it, said as a plan. Keep it consistent with C1, since the two will be put side by side | F2 and F9 are the two gaps you stated. JD because it scores honest self-assessment against the listed role |
| C3 | "You'd be coordinating design, art, engineering and community on every update. What have you coordinated across teams like that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with what is true: "I've never led a team." Answer slot: the JD's four teams make a probe on which of them you worked with likely. If running the drop calendar meant working with any of them, say which and what you asked of each, in your own words; if it meant none of them, or you were not the one asking, say so plainly and stay with the calendar you ran. Then your approach to coordinating without authority, as a plan | F2 is the row, and the JD's line is the raising source. The slot's second branch lets the premise be false. JD |
| C4 | "The JD asks for three-plus years producing live-service games or apps. Where does your experience sit against that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you hold, in those words: "4 years as an associate producer at a puzzle-game studio" and a weekly content-drop calendar for your main title for two years. Answer slot: if your main title was being updated while players were playing it, say how, in your own words; if it was not, say so plainly and stay with the four years and the calendar. Concede what is open, specifically, and do not describe the title as live-service unless it was | F5 is a discovery row: the material does not show whether the title was live-service. JD because it scores the headline requirement |

### D. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Three slots, each in your own words. Say which retention measure you presented and how it was counted. Name the assumption behind the numbers you would defend least, before you are asked. Say whether you produced the numbers or presented others'. If you do not know how they were counted, say that plainly; it survives a second question and an explanation you cannot repeat does not | F7 is the evidence and F3 the limit: presenting, not choosing. EXP because it tests whether the number survives scrutiny and what was yours |
| D2 | "What part of planning and running a live-events calendar have you owned yourself?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The hold is only what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you chose what went into a drop or when it went out, say how you decided, in your own words; if the contents or dates were set elsewhere, or there was no such decision, say so plainly and describe how you ran the calendar. Hold through two follow-ups by returning to the calendar you ran, never by adding to it | F1 and F6 meet here; the JD's plan-and-run line is the raising source. The honest branch is a limit, not a confession. JD |
| D3 | "Walk me through the release checklist you wrote and how QA uses it today." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: the beats the quote states are that you wrote it and that QA still uses it. Describe it so someone who has not seen it could follow: what is on it and when it is used, in your own words. Answer slot: if you remember what prompted it, say; if it began as something you were handed, or you do not know how often it is used, say so plainly and stay with what you wrote | F4 is the strongest evidence you hold and F8 asks whether it was clear. JD, covering the release-checklist and written-communication lines |

### E. Pressure (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has already run live events with in-app purchases?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold on the three things you stated: you ran the weekly content-drop calendar for your main title for two years, you wrote the release checklist QA still uses, and you presented the monthly retention numbers. Concede once and specifically: "I've never worked on a game with in-app purchases." Hold through two follow-ups by returning to those three things. Do not say anything about the other producer | F9 is the concession and F1, F4, F7 the hold. EXP because the interviewer is testing composure and attribution, not content |
| E2 | "That retention work — how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold at the quote's scope: you presented the numbers to the studio head. Answer slot: if you also built or analysed them, say which part, in your own words; if the numbers came from someone else, say so plainly and stay with the presenting. Concede nothing the quote does not require, and add nothing it does not carry | F3 and F7 are the rows. EXP because it is a direct attribution probe |

### G. Conversational (weight 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey. How did you get to live ops, and why Saltmarsh?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences, in that order: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title over the last two years, the release checklist QA still uses, the monthly retention numbers presented to the studio head. Answer slot: why Saltmarsh, in your own words. If you have read or watched Tobias's talk, say what you took from it; if you have not, do not mention it | The opener is scored. F1, F4 and F7 supply the arc; F6 is the calendar line. EXP because it tests whether your story matches your material |
| G2 | "Is there a live game you follow closely, and what does its team do well or badly with events?" | CO | [generic] | Selection scaffold: pick a game you actually play and one thing you have noticed about how it runs its event calendar, with what players see as the evidence. If you do not follow one, say so plainly and say what you would look at to judge an event calendar | A casual question on a hot JD topic, asked as conversation but scored. `[generic]` because it is a pattern, not a fact about Saltmarsh. CO because it tests current-market fluency |

## 8. Values cheat sheet

The careers page documents a values conversation, so this section applies. Value names are as published on the values page.

| Value (official name) | Working meaning, paraphrased | Your mapped story |
|---|---|---|
| Players Before Plans | When a schedule and the players' experience conflict, the players' experience decides | Selection scaffold (B1): pick a time a scheduled drop and what players were experiencing pulled apart. Nearest evidence, F1: "I ran the weekly content-drop calendar for our main title for the last two years." That quote carries a calendar and no conflict. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announce what has been built, not what is hoped for | Selection scaffold (B2): pick a time something announced had to be narrowed or corrected. Nearest evidence, F4: "Wrote the release checklist our QA team still uses." If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Each release should leave the codebase and the checklist in better shape than it found them | Story-mapped (B3) on F4: "Wrote the release checklist our QA team still uses." The beats the quote states are that you wrote it and that QA still uses it. Whether it changed after a release is an answer slot in B3 |

## 9. Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ1 | "You were a QA lead before heading Live Operations. What from QA do you still lean on most when a live event goes wrong?" | Tied to Tobias's own public path, and it opens the territory where F4 sits without you claiming more than the quote | [grounded] |
| RQ2 | "Your GDC talk argues a live team is judged by whether patch notes describe what shipped. What does the team do before a release to check that?" | Quotes the talk's listed argument at the scope I saw. Ask it only once you have watched or read the talk, and then it turns your checklist into a conversation | [grounded] |
| RQ3 | "With Project Larkspur putting the titles on one events calendar and one live-ops group from February, where does this role sit?" | Shows you read the announcement; it also tells you whether the JD's two titles are the Larkspur titles, which the JD does not say | [inferred] |
| RQ4 | "Which two or three numbers does the team look at first after an event, and who owns reporting them?" | Goes straight at the JD's own-the-KPIs line (F3) and tells you whether this role chooses the numbers or reports them | [grounded] |
| RQ5 | "What would you want a new producer to understand about how the titles earn from events in their first month?" | Faces the in-app-purchase gap (F9) forward, as a learning question, without you re-arguing it | [inferred] |
| RQ6 | "In the Outage Hour, what separates people who do well from people who don't?" | Invites Tobias to calibrate you live; the careers page names the format | [grounded] |

## 10. Sources

**Provided documents:** the JD and your background, both in your message. No dossier was present.

**Searches sent and what came back**

| Query | Returned |
|---|---|
| Saltmarsh Games values | https://saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Saltmarsh Games strategy news | https://saltmarshgames.com/news/project-larkspur |
| Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise |

**Fetches sent:** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned. The Project Larkspur announcement and the talk listing were read only as search-result snippets and were not fetched, so A4, RQ3 and section 3 rest on the snippet text.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Section 8 and bank B: three values by official name and their published definitions |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: the Outage Hour, tabletop then values conversation, no take-home; persona weights in section 6 and bank A |
| 3. `Saltmarsh Games strategy news` | yes | A4, RQ3 and the F9 row, from the Project Larkspur snippet |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Section 3, RQ1 and RQ2, and bank D's weight, from one talk listing |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief from the full Project Larkspur announcement and the talk itself, replacing the snippet-only reads behind A4, RQ3 and section 3
- The recruiter's email about Friday → confirms the session is the Outage Hour and may name the simulated title or format, sharpening bank A
- Your answers to the answer slots, in your own words (whether any drops were time-limited events, which teams the calendar involved, which retention measure you presented, whether the title was live-service) → F1, F2, F3, F5 and F8 become story-mapped rows and C3, C4, D1 and D2 lose their slots
- A redacted copy of the release checklist → F4 moves from medium to high and B3 and D3 become checkable
- Which two titles the JD covers → A4 and RQ3 sharpen
- How many hours you have before Friday → a prioritized prep triage
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and binding prohibited claims, replacing my inferred pick of C1 as the likeliest objection
