# Interview pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop, all on 29 November 2026 (pack built 20 November):** Round 1, 30 minutes with the recruiter. Round 2, 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural. Round 3, 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four published values. Interviewer names are not yet assigned, so there is no interviewer read.

Built in loop mode because the recruiter's email gives three scheduled rounds with who runs each.

## How to use this pack

- Personas are how a question arrives; types are what it scores. Each round has its own persona weights, bank and reverse questions. Question IDs run by round: A is Round 1, B is Round 2, C is Round 3.
- Type key: **VAL** — behaviour against Ashgrove's published values. **EXP** — your experience held up to scrutiny; what was actually you. **JD** — a requirement the job description states, gaps included. **CO** — company and strategy knowledge. **CASE** — a live problem from the real role.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer it from your own experience, in your own words, and where the honest answer is that the practice was not yours or never existed, say that plainly.
- Highest-ROI prep in the whole pack: **B4**, the contact-centre objection. It is the likeliest question for you in some form, and it appears in lighter form in A8, A9 and C6.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and an escalation script taught to tellers, with nothing inspected behind it, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's line on the process across branches makes a probe on what happened to a complaint beyond the log likely. If any step beyond the log was yours, say which and what you did, in your own words; if there was none, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence shows a monthly complaints spreadsheet that your regional manager uses; it does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect "what is in it". Say what it counted, in your own words; if it counted neither, say so plainly and say what you would add first |
| F3 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The sentence carries training new tellers on a script, not coaching supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on whether you have coached people at your own level likely. If any of that training was for supervisors, say how it went, in your own words; if it was all tellers, or none of it was coaching as such, say so plainly and stay with the tellers |
| F4 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with a digital team. Answer slot: if you have worked with one, say what the work was and what part was yours; if you have not, say so plainly and say what you would want to ask a digital team first about a complaint that starts in the app |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the years, but a self-reported line with nothing inspected behind it, so expect a probe on what the last three years held. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The sentence says formal complaints; it does not show whether they sat under outside rules. Answer slot: if the complaints in the log fell under external rules or time limits you worked to, say what, in your own words; if they did not, or you did not work to such rules, say so plainly and stay with the formal log you handled |
| F7 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then a plan, said as a plan and never as a past: what you would want to learn first and from whom. Nothing added to make the gap feel smaller |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan. The material does not say who counts as senior leaders at Ashgrove; that is a reverse question (A-R4) |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says spreadsheet, not Excel, and the reading that claims less is the one to use. Answer slot: if you built it in Excel, say what you built in it, in your own words; if it was another tool, say so plainly and stay with the spreadsheet you built |

## Grounding brief — Ashgrove's current direction

From the 2026 strategy brief Ashgrove published in July 2026 (sent by the recruiter) and the JD. Learn the vocabulary; do not recite it at them.

| Fact | Source | Provenance | An angle it may open (this pack's inference, not a fact about Ashgrove) |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | strategy brief | [grounded] | Where a complaint that starts digitally is held; B7, A-R3 |
| Consolidate eight branches into five hubs over 2027 | strategy brief | [grounded] | The panel are branch managers, so this plan may be personal to them; C8, and tread carefully |
| Launch a small-business lending product in Q1 2027 | strategy brief | [grounded] | A question to ask about which process new-product complaints fall under; B-R5 |
| Main competitive pressure is app-only banks | strategy brief | [grounded] | Why plain, fast complaint handling matters to retention; A3 |
| Member-owned, about 900 staff | JD | [grounded] | Why "Members First" is a governance idea as well as a slogan; A3 |

---

# ROUND 1 — Recruiter, 30 minutes

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through of your history, motivation, and logistics | High — a recruiter screen's prior is conversational with logistics, and the email gives no reason to depart from it | A tight 90-second arc; treat casual questions as scored (A1–A7) |
| Skeptic (light) | Knockout-style checks on the biggest JD gaps, politely | Medium — the JD names the contact centre and senior-leader presenting, and your message names both as limits | Say the limit first, plainly, then a plan (A8, A9) |

## Question bank

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc built from the beats the sentences state, in this order: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Tell each in your own words at that scope. Close on your own reason for moving toward complaints leadership; the material gives none, so state yours | Every later round starts from this arc, so it has to be tight and accurate. F5 is the years requirement it answers, and EXP because it tests that your account matches your material |
| A2 | "Tell me about the complaints side of your current role." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Two beats, held at their scope: you handled the branch's formal complaints log; you trained new tellers on the escalation script. Answer slot: the JD's regulated-complaints line makes a probe on the rules those complaints fell under likely. If you worked to external rules or time limits, say which, in your own words; if you did not, say so plainly and stay with the formal log you handled | F6 is the likeliest place a recruiter tests the regulated-complaints requirement, and F1 is the scope you must not stretch. EXP because it checks what was actually yours |
| A3 | "What draws you to Ashgrove?" | CO | [grounded] | Pick one or two reasons that are genuinely yours from what Ashgrove has published: it is member-owned, its first value is "Members First, Always", its brief moves 40% of member service to digital by 2028. Name their facts in their own words. If no reason beyond the job comes to mind, say so plainly and say what in complaints work holds your interest | A recruiter scores motivation consistency, and the strategy brief is what makes the answer specific. CO because it tests homework; the pack supplies the facts, not your reason |
| A4 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: give the figure that is truly yours, or ask for the role's band first. If asked what you earn now, you can decline politely and return to what you are looking for in this role | A recruiter screen always covers pay, and the only safe answer is your own. JD because it concerns the job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Covered in every recruiter screen; JD because it concerns the job's terms |
| A6 | "Where are you based, and how do you see working across branches and the contact centre?" | JD | [generic] | Logistics slot: give where you can work and how often, in your own words. The JD does not state the role's location or pattern, so ask the recruiter for it if it has not come up | The role spans branches and a contact centre, so location and travel are certain to be checked. JD because it concerns the job's terms |
| A7 | "Why are you looking to move?" | EXP | [generic] | Logistics slot: give your actual reason in one or two sentences, in your own words. Say what you are moving toward as well as what you are leaving, and use the JD's or the values' words only where they are truly your reasons | Reason for leaving is asked in every screen and is scored for consistency with A3. EXP because it tests whether your account hangs together |

### Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A8 | "The role covers the contact centre as well as branches. How do you see that part?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Acknowledgment first, in your words: "I haven't worked in a contact centre." Then a plan, said as a plan: what you would want to learn first and from whom. Do not claim the branch log works the same way a contact centre does; you have not said it does | The recruiter is the first person to screen for F7, and a limit named before it is asked reads as self-awareness. JD because it tests the stated requirement; B4 is the full rehearsal |
| A9 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose the one that is truly the weakest from the two you have stated: "I haven't worked in a contact centre" or "I've never presented to anyone above regional level". Say it in one sentence, then the plan. Answer slot: if working with digital teams on self-service is also new to you, say so plainly too; if you have done that, say what | F7 and F8 are your two stated limits, so this question is certain in some form. JD because it scores honest self-assessment |

## Reverse questions — Round 1

| # | Question | Why it lands |
|---|---|---|
| A-R1 | "Who is on the panel in round three, and what should I prepare for the complaint case?" | A scheduled case with unassigned interviewers is the one thing a recruiter can resolve in a line, and it shows you are preparing |
| A-R2 | "Is the 20-minute case a scenario I respond to cold, or is there anything to read first?" | The format changes how you rehearse C6 to C8 |
| A-R3 | "How does the move to 40% digital service by 2028 change what this role owns?" | Ties your question to their own brief, which a recruiter notices |
| A-R4 | "Who are the senior leaders this role reports to each month?" | It tells you the audience for F8 and shows you are thinking about the report's reader |
| A-R5 | "Who leads complaint handling in the contact centre today?" | It turns your F7 gap into curiosity about the people you would work with |

---

# ROUND 2 — Head of Member Services (your manager), 45 minutes, mostly behavioural

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" stems tied to Ashgrove's values | High — the recruiter calls this round mostly behavioural, which lifts it above the hiring-manager prior | A mapped story where a quote carries one, a selection scaffold where none does (B1–B3) |
| Skeptic | Quiet probing of the gaps by the person who owns the outcome | High — a manager is buying capability and derisking F7 and F8, which you have named yourself | Hold-then-concede on B4 and B5, with a plan each |
| Case / Strategist | A live problem from the actual role | Medium — the manager's prior is cases and the brief supplies the vocabulary, though the recruiter's email says mostly behavioural | Clarify, then structure, then answer (B7–B9) |

## Question bank

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | No quoted sentence carries a story of seeing a problem through, so this is a selection scaffold: choose one specific complaint from the log you saw through, with a named stake, what you personally did, who else it touched and how it ended; use "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — "I handled the branch's formal complaints log" — at that scope, or how you would hold a problem from first sight to solved | "Own the Fix" is a published value and this is its stem. F1 is the nearest evidence and it stops at the log. VAL because it scores the value, not the job |
| B2 | "Tell me about a time something had to be explained to a member or a colleague twice, and what you did about it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the sentence: you trained new tellers; the escalation script. Tell those two beats in your own words. Answer slot: the value says if a member needs it explained twice, we wrote it wrong, so expect a probe on whether the script's wording was ever changed after someone was confused. If it was, say what changed and whose call it was; if the script was fixed or not yours to change, say so plainly and stay with training the tellers on it | "Plain Words" is a published value and F3 is the only sentence near it. VAL because it scores the value |
| B3 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold the scope the sentence gives: you trained new tellers on the escalation script. Answer slot: the JD's supervisors line makes a probe on whether any of it was for supervisors likely. If it was, say how it went, in your own words; if it was tellers only, say so plainly and stay with that | F3 is the JD's coaching requirement and its evidence stops at tellers. JD because the stem comes from the stated responsibility |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "You'd own complaints across the contact centre, and you've said you've never worked in one. Why should we believe you can?" **Highest-ROI prep in the pack.** | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Deepest rehearsal, four levels. Open: "I haven't worked in a contact centre" — say it before they do. Hold what the sentences carry: six years in retail banking, the last three as a branch supervisor, and you handled the branch's formal complaints log. Follow-up 1, "What do you do in your first 30 days?": a plan, said as a plan, built on listening to the people who do the work. Follow-up 2, "What if that team doesn't accept a branch person's view?": concede that they know what you do not, and say what you would ask before proposing anything. Follow-up 3, "So you can't do the job today.": do not fold and do not stretch — "Not all of it, and I have said which part; what I bring is the branch side of complaints." Never claim a contact-centre parallel | This is the objection F7 creates, and the manager is the person who owns the result. JD because it scores a stated requirement; the rehearsal is the concession, not extra content |
| B5 | "You'd report to senior leaders each month, and you've told us you haven't presented above regional level. How would you handle that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I built the monthly complaints spreadsheet our regional manager uses." | Acknowledge in your words: "I've never presented to anyone above regional level." Then the plan, said as a plan: ask what senior leaders decide with the report, and rehearse it with your manager before the first one. What you carry is "I built the monthly complaints spreadsheet our regional manager uses" at that scope. Answer slot: if you have presented any of it at regional level, say what and how it went; if not, say so plainly | F8 is your second stated limit, and the manager is the likely audience for the first report. JD because it scores the stated presenting requirement |
| B6 | "The role needs experience handling regulated complaints. What have you handled that fits?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the sentence says: you handled the branch's formal complaints log. Answer slot: if those complaints fell under external rules or time limits you worked to, say what, in your own words; if they did not, or you did not work to such rules, say so plainly and stay with the formal log | F6 is a hard JD requirement that the evidence only touches. JD because it tests the stated requirement |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B7 | "We want 40% of member service on digital channels by 2028. A member starts a complaint in the app and it ends at a branch counter. Who keeps hold of it, and what do you want to know first?" | CASE | [grounded] | Clarify first: what the member did, what they want, what has been said to them already. Then the objective, who holds the complaint at each step ("Own the Fix": the finder keeps hold until it is solved), where the journey breaks, how you would measure it (volumes and resolution times, the JD's own measures), and the risks. Answer slot: if you have worked with a digital team, say what and what part was yours; if not, say so plainly and say what you would ask them first | CO and CASE: the 40% target is the brief's, and F4 is where the JD's self-service line meets a gap. The pack supplies the structure, never your experience |
| B8 | "What would you put in a monthly complaints report for senior leaders, and what would you leave out?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sentence says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: say what it counted; if it was in Excel, say what you built in it; if it counted neither volumes nor resolution times, or was another tool, say so plainly and stay with the spreadsheet. Then the JD's own two measures as where you would start, and what senior leaders would decide with them | F2 and F9 both land here. JD because it tests the reporting requirement; CASE in delivery |
| B9 | "You'd be coaching supervisors across all the branches. Where would you start?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Structure: start by asking supervisors what they find hardest to escalate, before bringing anything of your own. The one thing you can say about standing is "I was a branch supervisor for the last three years" at that scope; do not claim to know their branches. Close on how you would know it worked | F3 is the JD's coaching line; being a supervisor yourself is what gives you the standing question to answer. CASE because it asks you to plan a live piece of the role |

## Reverse questions — Round 2

| # | Question | Why it lands |
|---|---|---|
| B-R1 | "What would you want complaints to look like in six months?" | It asks your future manager for the success measure |
| B-R2 | "Where does a complaint most often get stuck between a branch and the contact centre?" | It shows you already think in terms of one owner |
| B-R3 | "Who is the audience for the first monthly report, and what do they decide with it?" | It turns your F8 limit into preparation |
| B-R4 | "How will complaints from the small-business lending product launching in Q1 2027 be handled?" | It uses their brief and tests whether they have thought it through |
| B-R5 | "What support would I have for the contact-centre side in my first months?" | It names your F7 gap openly, as a planning question, which your manager will respect |

---

# ROUND 3 — Panel of two branch managers, 60 minutes, values round with a 20-minute case

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stems scored against the four published values | High — the recruiter says the panel is also the values round | A mapped story or a scaffold for each value (cheat sheet below; C1–C5) |
| Case / Strategist | The 20-minute complaint-escalation case | High for those 20 minutes — it is scheduled | Clarify, structure, then answer; think aloud (C6–C8) |
| Peer Evaluator | Branch managers asking how this role lands on their supervisors' time | Medium — the role coaches their supervisors and reports on their branches | Reciprocity: what you bring them, not only what you need (C9, C10) |

## Values / principles cheat sheet

The four values are quoted as Ashgrove publishes them. The working meaning is paraphrased.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries this story, so it is a selection scaffold: pick a decision where the member's side and an internal convenience pulled apart, with a named stake and what you did yourself. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1) or how you would decide |
| Plain Words | If a member needs it explained twice, the writing was wrong | F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beats: you trained new tellers; the escalation script. Answer slot: if the script's wording was ever changed after someone was confused, say what changed; if not, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | F5: "6 years in retail banking, the last 3 as a branch supervisor." Beat: three years as a branch supervisor. Answer slot: if a decision of yours was shaped by the town your branch served, say which; if not, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beat: you handled the log. Answer slot: if you kept hold of a complaint past the log until it was solved, say what part was yours; if the log was where your part ended, say so plainly |

A tension the panel may press: the role reports numbers each month and the third value is "Neighbours, Not Numbers" (C2). The panel are branch managers; the hub plan may be personal to them, so do not speculate about which branches (C8).

## Question bank

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold, since no sentence carries this story: choose one decision with a named stake where the member's side and an internal convenience pulled apart, and say what you did yourself. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — "I handled the branch's formal complaints log" — or how you would decide | "Members First, Always" is the first value and the panel scores against it. F1 is the nearest evidence, and VAL because it scores the value |
| C2 | "You'll report numbers every month. How do you keep a branch's town visible in them?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sentence says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it carried anything about a branch or a member beyond counts, say what; if it was counts only, say so plainly and say what you would add so a branch is more than a number | It sets "Neighbours, Not Numbers" against the reporting duty, which is where this value and this role meet. F2 is the evidence and it does not show what the spreadsheet counted |
| C3 | "A supervisor finds a complaint problem that belongs to the contact centre. Who keeps hold of it, and what do you do?" | VAL | [grounded] | A live problem, so no claim about your past. The value says whoever finds the problem keeps hold of it until it is solved: say the finder stays involved while the owner fixes it. Then what you do in the first hour, who you tell, and how the member hears about it in plain words | "Own the Fix" in a live case, aimed at the seam between branches and the contact centre. VAL in content, CASE in delivery |
| C4 | "A member has just complained. Explain to us, in two sentences, what happens next." | VAL | [grounded] | A live exercise with no claim about your past. You do not know Ashgrove's process, so say what kind of complaint you would first want to know about, then speak to the member in words that need no second explanation. Keep it to what we heard, what happens next, and when they will hear from us | "Plain Words" tested live; the panel can hear whether it was written right. VAL because it scores the value |
| C5 | "Which of our four values would be hardest for you in this role, and why?" | VAL | [grounded] | Choose one honestly, say why in one sentence from your actual experience, concede it plainly, and say what you would do about it. Do not pick the safest value | A values round often ends on self-assessment, and a candid answer lands better than a polished one. VAL because it scores honesty against the published values |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C6 | "A member has complained at a branch twice and now rings the contact centre, where nobody has the history. Take us through what you do." | CASE | [generic] | Think aloud in this order: clarify (what the member wants, what has been said, any deadline that applies); the member's outcome first; who now holds it; a plain-words update to the member; what is recorded; what you would change so it does not repeat; how you would measure it. Spend about two minutes on structure and leave room to be challenged; these are branch managers and will push on what is practical | This is the case format the recruiter described, with the F7 seam built in. CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about Ashgrove |
| C7 | "Your report shows two branches handling the same kind of complaint very differently. What do you do?" | CASE | [generic] | Clarify first whether the two are counting the same thing. Then talk to both supervisors before drawing a conclusion, and do not assume which branch is right. Say what you would report and what you would leave to them to decide | It tests F2's reporting duty against a live conflict. CASE because the answer is reasoning, not recall |
| C8 | "One of the branches planned for consolidation has the highest complaint volume. What goes in your report, and what do you recommend?" | CO | [grounded] | The brief says eight branches into five hubs over 2027, and nothing about which. Do not speculate about branches. Separate what the numbers show from what members need; the decision is not yours; decide from the member's side. Ask what the volume is made of before you recommend anything | Strategy brief material in a live case, and the panel may be personally affected, so tone matters as much as content. CO because it needs the brief; CASE in delivery |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C9 | "What would you need from us, and what could we expect from you?" | JD | [generic] | Reciprocity: lead with what the branches get — a clear route for an escalation and a plain answer — then what you need, stated as principles rather than a claim to know their seam | F3's coaching duty lands on their supervisors' time, and a peer weighs what the hire adds to or takes from it. JD because it scores the stated working relationship |
| C10 | "Tell me about a time you disagreed with a manager over how to handle a complaint." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold: pick a real disagreement with a named stake, what you said, and how it ended with the relationship intact. If none comes to mind, say so plainly, then give the nearest thing your material carries — "I handled the branch's formal complaints log" — or how you would handle one | The Peer persona's disagreement probe. VAL because it scores spine and tact together |

## Reverse questions — Round 3

| # | Question | Why it lands |
|---|---|---|
| C-R1 | "Which kind of complaint is hardest for your supervisors to escalate?" | It asks them about their own work and gives you the coaching starting point |
| C-R2 | "What would make my coaching useful, rather than another demand on their time?" | The reciprocity question for a peer panel |
| C-R3 | "What do members in your branch most want to keep as the network changes?" | It speaks to "Neighbours, Not Numbers" without asking about closures |
| C-R4 | "What does a good monthly report look like from your branch's side?" | It collects the reader's view of F2 |
| C-R5 | "Which of the four values is hardest to hold on a busy day in a branch?" | It shows you listened to the values and invites a real answer |

---

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches (F1) | A2, B1, B3, B7, C3, C6 |
| Report monthly on volumes and resolution times (F2) | B5, B8, C2, C7, C8 |
| Coach branch supervisors on escalations (F3) | B2, B3, B9, C9 |
| Work with digital teams on self-service journeys (F4) | B7, A9 |
| 4+ years in financial-services customer operations (F5) | A1 |
| Experience handling regulated complaints (F6) | A2, B6 |
| The contact centre (F7) | A8, A9, B4, C3, C6 |
| Confident presenting to senior leaders (F8) | B5, B8 |
| Comfortable with Excel reporting (F9) | B8 |
| Four published values | Members First: C1; Plain Words: B2, C4; Neighbours, Not Numbers: C2; Own the Fix: B1, C3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log and a script taught to tellers. The slots stay inside the log |
| Coached branch supervisors on escalations | Inflated form of F3 | F3's quote at its own scope: new tellers, the escalation script |
| Reported on complaint volumes and resolution times | Inflated form of F2 | F2's quote at its own scope: a monthly complaints spreadsheet your regional manager uses. B8's slot asks only what it counted |
| Handled regulated complaints | Inflated form of F6 | F6's quote at its own scope: the branch's formal complaints log |
| Built the complaints reporting in Excel | Inflated form of F9 | F9's quote at its own scope: the spreadsheet. The slot asks only what tool it was in |
| Contact-centre experience | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description you pasted; Ashgrove's four values, copied by you on 20 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process; the 2026 strategy brief Ashgrove published in July 2026, sent by the recruiter; your own background message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values fix the cheat sheet, Round 3's VAL questions and B1–B2 |
| 2. `Ashgrove interview process member experience` | skipped | The recruiter's email already fixes the three sessions and who runs each, so it fixes the persona weights per round |
| 3. `Ashgrove strategy` / recent news | skipped | The July 2026 brief you were sent fixes the grounding brief, B7, C8 and A3 |
| 4. `{interviewer name} Ashgrove` | n/a | No interviewer name was given for Rounds 2 or 3, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- The names of the Head of Member Services and the two branch managers, once assigned → a public-footprint interviewer read, persona weights adjusted from it, and reverse questions tied to their own paths
- Your answers to the answer slots in F1, F2, F3, F6 and F9 (the log's steps, what the spreadsheet counted, whether any training was for supervisors, whether the complaints sat under outside rules, whether it was Excel) → those rows regenerate with your own words, and the matching slots in A2, B2, B3, B5, B6 and B8 become mapped answers
- Whether you have ever worked with a digital team (F4) → B7 becomes a mapped answer or a firmer scaffold
- An anonymised copy of the monthly complaints spreadsheet or the escalation script → F2, F3 and F9 can move from `medium` towards `high`
- The hours you have before 29 November → a prep triage that puts B4 and the two stated limits first
- One email to the recruiter: the format of the 20-minute case and anything to read first → the Round 3 case rehearsal built to the real format
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering Ashgrove's public material on its strategy, role-family loop reports and recent organisational context → a fuller grounding brief and sharper CO questions
- A `tuesday-dossier.md`, if you already have one → verified evidence and absolute prohibited claims in place of the ones this pack built from your message
