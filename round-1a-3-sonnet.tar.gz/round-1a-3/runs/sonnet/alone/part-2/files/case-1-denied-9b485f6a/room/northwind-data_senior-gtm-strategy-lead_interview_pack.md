# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP). **Format:** one 60-minute conversation, per your note. Built on that: a peer round, one session, no other rounds assumed.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding to speak from in your own words, not a script. An "answer slot" is an instruction for the interview: say which branch is true for you, and if neither is, say so plainly.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's published values. None is tagged here: no published Northwind values were obtained (see Sources), and your note describes no values round |
| EXP | Whether claims about your work survive scrutiny, and what was actually yours |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge, at the company's altitude |
| CASE | A live problem from the role: structure and reasoning |

## Fit snapshot

Sources for the left column: your JD highlights. Sources for the evidence column: your notes on Priya. None of the six requirements is a term such as location, authorization or schedule, so there is no gate row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "No classic sales-ops or quota-setting experience." — the coach's notes | low | [grounded] | transferability | Your material shows product strategy and ops work, not go-to-market ownership, and the words stay at that scope: "For nine years I was in product strategy and ops at a large consumer-tech company." The limit you stated is the plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." Answer slot: the JD's own-GTM line makes a probe on go-to-market work likely. If any of your strategy and ops work shaped how a product reached customers, say which piece and what was yours; if none did, or it was not yours, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [inferred] | discovery | The quote shows a proposal credited with an ARR uplift; it does not show which customer stage the change touched. Answer slot: the land/adopt/expand/renew line makes a probe on that likely. If the change moved one of those stages, say which and how you know, in your own words; if it did not map to those stages, say so plainly and stay with what you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in the tools, but a stated skill with nothing inspected behind it, so expect to be asked to walk through an analysis (A4). Lead in the quote's terms: skilled in SQL and Tableau |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the requirement makes a probe on which parts of the partner approach were yours likely. If any part was yours to shape, say which and how you decided; if there was no such step, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on the consensus. Lead with the quote's own terms: you set annual volume targets, with cross-org consensus |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | The quote shows use of AI tools; it does not show what for or how far it goes. Answer slot: if a casual question about AI comes, say which tools and what you use them for, in your own words; if the use goes no further than that, say so plainly |

## Grounding brief

Everything here is from your research note, taken as given. It was not independently checked, because web searches were not permitted this session.

| Item | What your note says | Provenance | Feeds |
|---|---|---|---|
| Priorities | Enterprise expansion; an AI copilot launch ("Compass"); reaching profitability | [grounded] | C2, C3, D3, R4, R6, R7 |
| Competitive threat | Bundling by a much larger platform vendor | [grounded] | C1, R3 |

Vocabulary to use accurately: "Compass" is the product name in your note. Your note does not say whether Compass is one of the two new lines, so the pack never assumes it (R7 asks).

## Reading the interviewer

Public footprint was not searched (refused), so this reads only the profile you supplied.

| Signal in your note | Implication | Used in |
|---|---|---|
| "relentlessly data-driven" (his self-description) | Every number you give gets probed to its assumptions; arrive knowing what you can and cannot say about how each was counted | A1 to A5 |
| Career spine of pricing and monetization roles | Cases tilt to pricing, packaging and unit economics, his native language | C1, C3 |
| One early-stage-startup chapter | A weak signal; at most a pace-of-big-company probe. Not weighted | D3 |
| Peer, same VP | He is pricing what you cost and contribute to his work; objections return in collegial packaging | B1 to B5, D1 |

Mirror opportunities. Shared vocabulary: his monetization economics and your sentence "built a partner-level revenue model used in carrier negotiations" (F4), used at its own scope. His ARR vocabulary and "proposed a store-surface change credited with a ~$400M ARR uplift" (F2), at its own scope. His startup chapter has no counterpart in your material, so it is not offered as a shared jump.

## Persona table

Loop: your note establishes one 60-minute session run by Dan, so no archetype fallback is used.

| Persona | How it shows up with Dan | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Line-by-line on the ~$400M figure, the revenue model, the volume targets | High, 5 questions. Peer prior is Peer Evaluator plus Prober; his "relentlessly data-driven" self-description moves the Prober up; the notes carry a headline figure | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know; name the weakest assumption before he does |
| Peer Evaluator (B) | Seam between your lines and his sales strategy; what you need from him; credit; disagreement | High, 5 questions. Same peer prior, plus the same-VP reporting line | Reciprocity framing; propose seam principles rather than pretending to know the seam; disagreement stories with spine and tact |
| Case/Strategist (C) | Short live problems in pricing, packaging, partner economics, whitespace | Medium, 3 questions. Not in the peer prior; raised by his pricing spine and by the bundling threat in your note | Clarify first, then structure, then metrics and risks; challenge one premise respectfully |
| Skeptic (D) | The sales-ops and quota gap, partner-motion design, why this move | Medium, 3 questions. Not in the peer prior; raised by the gap you stated and by a peer weighing what you add to his work | Rehearse the single likeliest objection (D1) until it is boring; bridges only from stated evidence; a ramp plan said as a plan |
| Conversational (E) | The biography question and a casual AI question | Low, 2 questions. Any 60-minute conversation opens somewhere friendly, and casual questions are still scored | A 90-second arc; treat the AI question as scored |

Not weighted: Pressure (no signal for it from a peer round) and Values/Behavioral (no values round is named by your note, and no published values were obtained).

## Question banks

Highest-ROI prep in the pack: **D1**, the sales-ops and quota objection. It is the one limit you stated yourself, and a peer in Sales Strategy sits closest to it.

### A. Data-Driven Prober (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The CV credits you with a roughly $400M ARR uplift on a store-surface change. Walk me through how that figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start at the sentence's own scope: you proposed the change, and the uplift was credited to it. Then four slots, each in your own words: how the figure was counted, if you know; what it is most sensitive to; the assumption behind it you would defend least; which part was yours. Name the weakest assumption before he does. If you do not know how it was counted, say so plainly and say who would. Do not offer a method you cannot repeat under a second question | F2 carries the pack's one headline figure, and a self-described data-driven interviewer goes to numbers first. EXP because it tests whether the CV line survives |
| A2 | "You say you proposed it. What was your part, and what was everyone else's?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold "proposed" through two follow-ups; it is your sentence's verb, so do not trade up to a bigger one. Concede specifically what you cannot attribute. Answer slot: if you also shaped the change beyond the proposal, say what; if the proposal was your part, say so plainly and say what you know of what happened after | The attribution follow-up to A1, the second place F2 gets pressed. EXP because it scores attribution honesty |
| A3 | "Walk me through that partner-level revenue model: what went in, and what would you change?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Open with the sentence at its scope: "I built a partner-level revenue model used in carrier negotiations." Slots in your own words: what it took in and what it produced; where it was used and what your part was in those negotiations, since the sentence says the model was used there; the assumption you would defend least. If you were not in the negotiations, say so plainly | F4 is your evidence on a required JD line, and a pricing-native interviewer will want the mechanics. EXP because the model is a CV claim to be inspected |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick an analysis where you wrote the query or built the view yourself, a decision depended on it, and you can state the question, the data and the limit of the answer. Offer to walk it end to end. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one | The JD names independent SQL and Tableau analysis; F3 is thin on inspectable proof. JD because it scores the stated requirement; the theme comes from the JD line |
| A5 | "You set annual volume targets. How is that different from setting quota?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | In order: first the plain acknowledgment, "I haven't had classic sales-ops or quota-setting experience." Then the sentence at its scope: "I set annual volume targets with cross-org consensus." Answer slot: say what the targets counted and what data they rested on; if the process was not data-led or was not yours to design, say so plainly and stay with the consensus. Do not describe quota mechanics you have not worked in | A peer in Sales Strategy will test the nearest thing to his own work. F1 and F5 meet here. EXP because it separates the adjacent claim from the missing one |

### B. Peer Evaluator (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between your GTM strategy for the new lines and my sales strategy, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam. Propose principles: who owns which decision, what data each side trusts, how a disagreement escalates to the shared VP. Ask what he would draw differently. The question needs no claim about your past, so the guidance makes none | The core peer question, since you share a VP. JD because cross-functional influence is a stated requirement (F5); the peer persona sets the delivery |
| B2 | "Tell me about a time you got teams with different incentives to agree." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on the sentence's own beats: annual volume targets, and consensus across organisations; tell them in your own words. Answer slot: the JD asks for cross-functional influence, so expect a probe on where the teams started apart. If they did, say on what and what moved them and what part was yours; if they did not, or the consensus came from someone else's work, say so plainly and stay with the targets | F5 is the evidence for the influence requirement. EXP because it tests what you actually did; the prompt's theme is the JD's |
| B3 | "Work that spans teams tends to get claimed by whoever presents it. How do you handle credit?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Describe your own part in the sentence's terms: you proposed it. Say how you would name other teams' parts as a principle, in the present tense, only if it is true for you. Answer slot: if you know who else contributed to that change and how credit was assigned, say; if credit was assigned by others, say so plainly | The credit-sharing probe from the peer persona, aimed at the one line where credit is explicit (F2). JD because it scores cross-functional influence |
| B4 | "What would you need from my team in your first ninety days, and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau" | Ask first for context, not access to everything: where the numbers live and which ones his team trusts. Offer what the sentence carries: analysis in SQL and Tableau. Reciprocity beats a shopping list | A peer is pricing what you cost and contribute. JD because it tests partnership fit on the stated cross-functional line |
| B5 | "Tell me about a time you disagreed with a peer team over a number, and how it resolved." | EXP | [generic] | Selection scaffold: pick a disagreement where the number itself was in dispute, you held a position, and the relationship was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's disagreement-with-equals probe, in his data-driven register. EXP because it scores what you did; no published values were obtained, so it is not VAL |

### C. Case/Strategist (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a capability that overlaps one of our new products at no extra cost. What do you need to know first, and what does it change about how we sell?" | CASE | [grounded] | Clarify first: which product, which accounts overlap, whether the bundle is a real substitute or only adjacent. Then segment (who is most exposed), then the packaging and pricing stance, since this is his native ground, then the metrics you would watch and the risks. Challenge one premise politely. No claim about your past | Bundling is the competitive threat in your research note, and his pricing spine makes packaging the natural frame. CASE with CO, because it needs company-level vocabulary |
| C2 | "Take a new product with thin customer data. How would you find whitespace across land, adopt, expand and renew?" | CASE | [grounded] | Say the structure aloud: what you would need to know, the hypotheses per stage, the first cuts you would run in SQL and what each would tell you, and what would change your mind. Tie to enterprise expansion, a stated priority in your note, only as framing. No claim about your past | The JD's whitespace line, run as a live problem. CASE because it scores structure; it also puts the SQL requirement in play |
| C3 | "A partner offers to push a new product if we improve their economics. How do you decide, given profitability is a stated priority?" | CASE | [grounded] | Clarify what the partner brings that direct sales does not; then the unit economics for both sides; then channel conflict with direct sales, which is his seat; then the walk-away point and how you would know the motion is working. Name your assumptions before he does. No claim about your past | Partner-motion design is a required line (F4), and partner economics is shared ground with a pricing background. CASE; the profitability link is from your note |

### D. Skeptic (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done sales-ops or quota-setting, and your last nine years were consumer tech. Why should I believe you can land go-to-market strategy here?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | Highest-ROI rehearsal in the pack. Name the limit first: "I haven't had classic sales-ops or quota-setting experience." Hold what the sentences carry: nine years in product strategy and ops at a large consumer-tech company, and "I set annual volume targets with cross-org consensus." Follow-up 1, "what is the nearest thing?": return to the targets, no further. Follow-up 2, "how do I trust you with my team's numbers?": give a ramp plan said as a plan, never a past: what you would learn first and from whom. Follow-up 3, "what if sales leaders reject your numbers?": give principles, not a past event. Answer slot: if any strategy and ops work shaped how a product reached customers, say which and what was yours; if none did, say so plainly. Concede specifically, never fold on the nine years | The gap you stated, put by the person closest to it. JD because it scores a stated requirement; Skeptic delivery. This is where the pack is most tempted to thicken the material, so it is held to your sentences |
| D2 | "The role requires partner-motion design. Which part of designing a partner motion have you owned yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the sentence carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of the partner approach was yours to shape, say which and how you decided; if there was no such step, or it was not yours, say so plainly and stay with the model. The honest branch is a limit, not a confession. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where a required line presses hardest, so this arrives in some form. JD because it scores the stated requirement |
| D3 | "Why this move, from consumer tech to B2B data infrastructure, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Give your actual reason in your own words; the pack supplies none. If any of Northwind's stated priorities in your note (enterprise expansion, Compass, profitability) genuinely draws you, name which and why. Keep it consistent with what you will say in E1 | The motivation-consistency probe. EXP because it tests the story against the CV; no claim beyond the sentence |

### E. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the sentence's own beats: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Then a slot for the move: your actual reason, in your own words, ending on why this role. Do not add a third chapter the sentence does not hold | Casual opener, still scored for economy. F1 is the row it draws on |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Answer slot: say which tools and what you use them for, in your own words. If the use goes no further than that, say so plainly. Treat it as scored: the JD lists AI as a plus and Compass is a stated priority in your note | A casual question on a JD plus (F6). JD because it scores that line, rapport register |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | D1, E1, C1, C2 |
| identify whitespace across land/adopt/expand/renew | C2 |
| run independent analysis in SQL and Tableau | A4, B4, C2 |
| partner-motion design experience required | D2, A3, C3 |
| strong cross-functional influence | B1, B2, B3, B4, B5 |
| AI experience a plus | E2 |
| headline figure on the CV | A1, A2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization roles, with an early-stage chapter. How does that shape what you want from GTM strategy on new lines?" | Tied to his own path, so it turns an interrogation into a peer conversation and shows you read him |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you are pricing what you add, not only what you need |
| R3 | "Where does the seam between our two functions bite today, and where would you like me to take work off you?" | Opens the seam conversation B1 rehearses, on his terms |
| R4 | "How is bundling by the larger platform vendor showing up in the deals you see, and what data would help you see it earlier?" | Uses the competitive threat in your note and asks for his data view, which a data-driven peer values |
| R5 | "Which decisions should whitespace analysis change in your planning, and which numbers do you not yet trust?" | Ties the whitespace requirement to his decisions and invites the assumptions conversation he likes |
| R6 | "With profitability among the stated priorities, how do you see the trade-off between landing and expanding on the new lines?" | Shows company-level thinking from your note and tests how he frames trade-offs |
| R7 | "Where does Compass sit relative to the two new product lines: one of them, or alongside?" | Settles a scope fact your note leaves open, so you do not assume it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Designed or owned a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a model used in negotiations, not the design of a motion. D2's slot stays inside the model |
| Owned go-to-market for a product | Inflated form of F1 | F1's quote at its own scope: strategy and ops work. The limit is the pack's observation, not words for you. D1's slot asks only whether any of that work shaped how a product reached customers |
| Set sales quotas or ran sales ops | Negative you stated, F1 | The plain acknowledgment F1 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Led, built or owned the store-surface change or its uplift | Inflated form of F2 | F2's quote at its own scope: you proposed it, and the uplift was credited to it. A2's slot stays inside the proposal |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: you use AI tools daily. E2's slot asks only what for |

## Sources

Provided documents: your message (role, JD highlights, notes on Priya, interviewer profile, research note). No dossier was consumed.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Searches sent: `Northwind Data company values principles` (refused); `Dan Kovac Director of Sales Strategy Northwind Data` (refused). Neither returned anything, so nothing from the web is in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have themed VAL-style questions and, if a values round had been documented, the values cheat sheet |
| 2. `Northwind Data interview process` | skipped | Your note already fixes one 60-minute session with Dan, so persona weights follow it |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note supplies the priorities and the competitive threat, which fix the CO and CASE questions; the note is used as given |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have added to the interviewer read and tied a reverse question to anything he has published |
| 5. representative role JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search, or pasting Northwind's values page and any talks or posts by Dan → VAL-themed questions on published values, and a reverse question tied to his own writing
- The full JD text → the six quoted requirements become verbatim JD lines, and the coverage table is rechecked
- Priya's CV text → the evidence column quotes her CV instead of your notes
- A document behind the revenue model or the ARR credit, such as the model file or the review that credited the change → F2 and F4 could rise from medium toward high
- Your own answers to the answer slots on F1, F2, F4 and F6, given outside a drill → those rows regenerate on what you say
- Recruiter or HR guidance on focus areas or a pre-declared deliverable → coverage beyond the peer-round priors
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a fuller strategy brief and role-family loop reports; say if you want it
- A `tuesday-dossier.md` from an earlier evidence check → verified evidence and a sourced no-claim list in place of the one built locally here
