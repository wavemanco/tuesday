# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Format:** 60 minutes, Friday.
**Built on this assumption:** a hiring-manager round on a loop nobody has documented, so weights lean on the hiring-manager prior and the loop falls back to a generic archetype. Company research did not run (see Sources), so nothing below claims a fact about Saltmarsh Games beyond your JD.
**Highest-ROI prep in this pack:** B1, the in-app-purchase question. It will arrive in some form, and your own message gives the interviewer the opening.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script. Where a cell says "answer slot", it is an instruction for the interview, and the honest answer is whichever branch is true for you.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. None used here: no published values were read |
| EXP | Whether your background claims survive scrutiny, and what was actually yours |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge. None used here: no strategy research ran |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

The evidence column holds your own words from your message, nothing else. Everything the pack says about your past rests on these sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, which is one title and drops, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two titles and its live-events wording make a probe on both likely. If you ran a calendar for any title besides the main one, or any of your drops were timed events, say which, in your own words; if not, say so plainly and stay with the main title's drops |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team" — your message | low | [inferred] | discovery | Your material does not show which teams your drops involved. Plain acknowledgment, from your own words: "I've never led a team." Answer slot: if any of your drops needed design, art, engineering or community, say which and how you agreed what shipped; if you did not work with some of them, or none of it was yours to coordinate, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran post-event reviews or owned KPIs. The words stay at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own the ... KPIs it reports" makes a probe on who chose what the numbers measured likely. If you chose which measures went in, say which and why; if they were set for you or someone else built them, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the checklist in the quote's own terms: you wrote it, and your QA team still uses it. The quote says written and in use, not who ran each release, so add nothing to it. The checklist itself is the inspectable artifact that would raise this row |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [inferred] | discovery | Your material gives four years as an associate producer at a puzzle-game studio and does not say whether that title ran as a live service. Answer slot: the JD says live-service, so expect the probe. If the title ran as a live service, say how it ran live, in your own words; if it did not, say so plainly and stay with the weekly drops you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, main title, last two years, because named scope beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but nothing inspected sits behind it, so expect a probe on how the numbers were counted (C1). Lead with what the quote states: monthly, retention, to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist your team still uses is something you wrote; your material does not show how it reads to others beyond that. Answer slot: if you have written anything else that others acted on, say what it was; if not, say so plainly and stay with the checklist |
| F9 | Familiarity with in-app purchases in a mobile title — role-family pattern, no JD line | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

The loop is not documented in anything I could read, so these weights rest on the hiring-manager prior and a generic archetype, not on Saltmarsh's process. If Tobias is a skip-level rather than your direct manager, Pressure rises.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: plan this calendar, diagnose this drop | High. The hiring-manager prior puts it first, and the JD is built on planning and running | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise per case |
| B. Skeptic | Quiet probing of the gaps: in-app purchases, team leadership, one title versus two | High. Hiring managers derisk gaps, and your message states two of them (F2, F9) | Rehearse B1 until it is boring; plain acknowledgment, then a plan; stay inside your own quotes |
| C. Data-Driven Prober | Line-by-line on the retention numbers and KPIs | Medium. The JD asks for retention-metric comfort and you present them monthly (F7, F3) | Say what you know of how each number was counted and say plainly what you do not; name the assumption you would defend least |
| D. Conversational | Opening biography, "what are you playing", a writing question | Medium. A 60-minute round almost always opens here, and casual questions are still scored | A 90-second arc; treat casual questions on JD topics as scored |
| E. Peer Evaluator | Seam and credit questions between disciplines | Low. The title suggests a manager, not a peer, but the JD's four-team coordination invites the form | Principles for the seam, not a claim to know it; credit stated as "we" for context, "I" for contribution |
| F. Pressure | Time-boxed, "how much was actually you" | Low. Rises if Tobias is a skip-level | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Plan the next eight weeks of live events for two titles that share an art team and an engineering team. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Think aloud: clarify first (what is already fixed, what the two titles share, what the eight weeks are meant to achieve), state one objective, split shared from title-specific work, sequence, name the metrics, name the risks, challenge one premise. If you illustrate from your own work, the sentence you can stand on is "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any of your drops needed more than one discipline, say which and what you did; if not, say so plainly and stay with the calendar | F1 and F6 are the evidence for the headline responsibility. CASE because it scores structure, with JD content |
| A2 | "An event's day-3 participation is half of what the team expected. It ends Sunday. What do you do in the next 24 hours?" | CASE | [generic] | Clarify before acting: is it a data problem, a content problem or a communication problem, and how would you tell which. Then who you would pull in (the JD's design, art, engineering and community teams), what you would change and what you would leave running, and what you would record for the post-event review. No claim about your past is needed, and the guidance makes none | Tests the JD's coordination line (F2) as a decision under time pressure. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A3 | "Retention for players who joined during last month's event is below the previous cohort. Diagnose it." | CASE | [generic] | Clarify (which retention measure, which cohorts, what else changed), segment, list hypotheses in the order you would test them, say which data would separate them, and name the assumption in your own diagnosis you would defend least. The question presupposes nothing about your past | F7 is the evidence for retention comfort and C1 probes it from the other side; here it is asked as a live problem |
| A4 | "You own the post-event review. What is in it, and which KPIs does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it: the question the review answers, the few KPIs you would report, how each is counted and what you would distrust about it, who reads it, what it changes. From your own work, the beat the quote carries is that you presented monthly retention numbers to the studio head. Answer slot: the JD's "own the post-event review and the KPIs it reports" makes a probe on who set the measures likely. If you chose which measures went in, say which and why; if they were set for you, say so plainly and describe how you would pick them | F3 is the thinnest of the JD's headline responsibilities and the likeliest to be pressed. JD because it scores the stated requirement, CASE in delivery |
| A5 | "Engineering says Thursday's update cannot ship. Art is done and community has already announced. Walk me through it." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify what is actually blocked and what is only at risk, who decides, what the options cost, what you tell design, art and community and when, and what the post-event review records. From your own work, say what the quote states: you wrote the release checklist your QA team still uses. Answer slot: the JD's "manage the release checklist with QA" makes a probe on how the checklist was used on a real release likely. If you ran it with QA on a release, say what that looked like; if others ran it, or it was used some other way, say so plainly and stay with having written it | F4 is where the JD's QA line is probed. CASE because it is a live problem, with JD content |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you get up to speed on that side of live events?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment in your own words: "I've never worked on a game with in-app purchases." Do not soften it and do not pad it. Then give a plan, never a past: the first thing you would ask to see in week one, who you would ask, and what you want to be able to explain by day 30. Choose these yourself, since the pack does not know this studio's setup. Hold through two follow-ups by returning to the plan. If asked for the nearest thing you carry, say "I presented the monthly retention numbers to the studio head." and stop | F9 is the objection most likely to be asked, and the one your own message hands over. Deepest rehearsal means a limit named before it is asked for, not more affirmative content than F7 carries. JD because it scores fit to the role, EXP in the follow-ups |
| B2 | "You've never led a team. This role coordinates design, art, engineering and community on every update. Where does your authority come from?" | JD | [grounded] "Never led a team" and "I ran the weekly content-drop calendar for our main title for the last two years." | Acknowledge plainly: "I've never led a team." Then say what the role asks as coordination, and what you would rely on in place of authority, as a method you would use and not a history. Answer slot: if any of your drops needed design, art, engineering or community, say which and how you agreed what shipped; if you did not work with some of them, say so plainly and stay with the calendar. Hold the calendar quote through two follow-ups | F2 is the objection's source. JD because the premise is the JD's coordination line, aimed at where the evidence is thin |
| B3 | "This role covers two titles. You've run one calendar. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Keep the quote at its scope: your main title, weekly drops, two years. Say what you would need to learn about a second title and how you would split your attention, as a plan. Answer slot: if you ran a calendar for any other title, say which; if not, say so plainly | F1 is where the one-title versus two-title gap is probed. JD because it scores the first responsibility on the list |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose one from your own material and name it before they do: your message states two limits, and the pack's reading is that the post-event review and KPIs row (F3) is also thin. State it, then give the first step you would take. Do not name a weakness you cannot back with a plan | The persona stem; it rewards calibrated candor. F2, F3 and F9 are the candidates |
| B5 | "Your background is a puzzle-game studio. What carries over to our titles, and what doesn't?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Say what carries in the quotes' terms: four years as an associate producer, and the weekly drops calendar for your main title. For what doesn't, name what you have not done, in your own words. Answer slot: the JD says "live-service"; if your puzzle title ran as a live service, say how it ran live; if it did not, say so plainly and stay with the weekly drops | F5 is the row where the "3+ years" requirement is probed. EXP because it tests what your background does and does not cover |

### C. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. What did they cover, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what the quote states: monthly, retention, to the studio head. Answer slot: say which retention measures were in them and how they were counted, in your own words; if you did not build them, or you do not know how they were counted, say so plainly and say what you did with them. Name the assumption behind them you would defend least, or say you do not know it | F7 and F3 are the evidence; the question tests attribution and whether you know your own numbers |
| C2 | "A retention number moved after an event. How do you tell the event did it?" | CASE | [generic] | Name what else changed in the same window, what you would compare against, and what you could not rule out. Say plainly what you would still not know. The question asks nothing about your past | Tests retention comfort (F7) as reasoning. `[generic]` because it is a pattern for the problem |
| C3 | "Which two or three KPIs would you put in a post-event review, and what would you distrust about each?" | JD | [generic] | Choose measures you can say how you would count. For each, name the weakest assumption before they do. The JD's "KPIs it reports" raises the topic and the guidance makes no claim about your past | F3's requirement asked as a judgment call. JD because it scores the stated requirement |

### D. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. Why live ops, why Saltmarsh, why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc that starts from what the quote states, four years as an associate producer at a puzzle-game studio, and carries it forward in your own words. Answer slot: give your own reasons for this company and this moment; the pack read nothing about Saltmarsh, so it supplies none | Motivation consistency is scored even when the register is casual. F5 is the background it starts from |
| D2 | "What are you actually playing in live ops these days?" | JD | [generic] | Name one or two live events you have actually seen in games you play and say what you noticed about how they were run. The pack names none, because it cannot know what you play | The persona stem for the casual question that is still scored |
| D3 | "Tell me about something you wrote that a team actually used." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Tell it with the beats the quote states: written by you, used by your QA team, still in use. Answer slot: add anything else only if you can stand behind it in your own words; if there is no more to it, say so and stop | F8 and F4 are the evidence for "clear written communication". JD because the requirement raises it |

### E. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design, art, engineering and community all want the same update slot. How do you decide when they disagree?" | CASE | [generic] | Offer principles rather than pretending to know the seam: what each team needs from you, what you would ask each to give up, how you decide who decides, how you tell the losing side early. The question asks nothing about your past | The JD's four-team coordination line (F2) as a live problem |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | "We" for context, "I" for contribution. The sentence you can stand on is that you wrote the checklist your QA team still uses; say what was yours and leave what was not to the team | F4 is the one row where authorship is clean enough to rehearse this on |

### F. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate, hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if parts of it were decided by someone else, say which parts and who; if none were, say so plainly. Concede only what is true, specifically, and do not fold on the quote | F1 and F6 carry the claim most likely to be tested for attribution |
| F2 | "Sixty seconds: why you over a producer who has run in-app-purchase events and led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | Concede first and plainly: "I've never led a team, and I've never worked on a game with in-app purchases." Then give the three things your own words carry: the weekly drops calendar, the release checklist your QA team still uses, the retention numbers you presented monthly. Stop there and do not add a fourth | F2 and F9 are conceded, F1, F3 and F4 are what is held. JD because it scores fit under comparison |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B3, F1 |
| "coordinate design, art, engineering and community teams on each update" | A2, B2, E1 |
| "own the post-event review and the KPIs it reports" | A4, C3 |
| "manage the release checklist with QA" | A5 |
| "3+ years producing live-service games or apps" | B5, D1 |
| "experience running a content calendar" | A1, B3, F1 |
| "comfortable with player-retention metrics" | A3, C1, C2 |
| "clear written communication" | D3, E2 |
| Stated limits, not JD lines (in-app purchases, team leadership) | B1, B2, B4, F2 |
| Published company values | — none, and why: no values page was read, so there are no published values to map |
| Company strategy | — none, and why: strategy research did not run, so a CO question would be generic |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this role across the two titles?" | It shows you are planning to deliver, and the answer tells you what the post-event review and calendar work are judged on |
| R2 | "How is the live-events calendar planned today, and how are conflicts between design, art, engineering and community settled?" | It shows you think about the seam as a process, and the answer fills in the coordination row you could not research |
| R3 | "Which KPIs does the post-event review report today, and which of them do you trust least?" | It is the weakest-assumption move turned on their own numbers, which reads as a metrics-literate peer |
| R4 | "How do the live events connect to each title's revenue, and where would a new producer need to get up to speed first?" | It lets you work on the in-app-purchase gap openly with the person who can size it, instead of waiting to be asked |
| R5 | "What does the release checklist with QA look like in practice today, and where does it creak?" | It ties to something you wrote and signals you want to improve it rather than defend it |
| R6 | "What would tell you in six months that this hire worked?" | It asks for the scorecard directly and the answer is your day-one prep list |

## Prohibited claims

What this pack will not coach, and why. Each entry is built from your own quotes in the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team or managed people | Negative you stated, F2 and F9 | The plain acknowledgment: "I've never led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." Then a plan, not a past |
| Planned and ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one main title and content drops. B3's slot stays inside that |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers. A4's slot asks only who chose what went in |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist your QA team still uses. A5's slot stays inside having written it |
| Drove or improved retention | Inflated form of F7 | F7's quote at its own scope: you presented the monthly retention numbers to the studio head |

## Sources

**Provided documents:** the JD text you pasted, and the background you described in your message. Nothing else was provided.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, every one refused (no results returned):

- "Saltmarsh Games mobile game studio values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy news mobile titles" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions; none were written |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Every call was refused. It would have documented the loop and set persona weights; the pack uses the generic archetype instead, and says so |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call was refused. It would have fed CO questions and a grounding brief; none were written |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have fed an interviewer read and a tailored reverse question; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or pasted pages from Saltmarsh's careers or values page → a values cheat sheet, CO questions tied to current strategy, and persona weights read from the documented loop in place of the generic archetype
- A deeper research pass, if search is allowed (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on current strategy and recent organization context
- Tobias's public bio or talks, pasted → an interviewer read, and a reverse question tied to his own career path
- The recruiter's note on format, focus areas or any task to prepare → a graded-deliverable build section and reweighted personas
- Your release checklist itself, with anything confidential removed → F4 can move from medium toward high
- A short piece of your own writing that others acted on → F8 moves from a discovery lead toward a grounded row
- Your answers to the answer slots in F1, F2, F3, F5 and F8, in your own words → those rows become your stated evidence and the questions that draw on them are regenerated
- Your prep time → a prioritized schedule sized to it
- A tuesday-dossier.md, if you have one → verified evidence and a lead objection recorded from evidence, in place of the one this pack inferred
