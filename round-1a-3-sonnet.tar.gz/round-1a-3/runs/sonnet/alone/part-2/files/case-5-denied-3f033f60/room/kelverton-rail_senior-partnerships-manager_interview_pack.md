# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday, 60 minutes, panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Shape, from the recruiter's email:** first 15 minutes, a short POV on where you would take Kelverton's operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and Ross will push on commercials.
**Built on:** your message (your background and the recruiter's email, quoted in it). No JD was supplied, so the requirements come from the recruiter's own words. The market report was not available to me, and no web research ran, so every Kelverton-specific fact is absent from this pack and anything about the company is labelled `[generic]`.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behaviour against published values (none in this pack: no values round is documented) |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem or hypothetical from the real role |

An answer slot is an instruction for the interview, not a question for you now. Where one asks for something only you know (how a figure was counted, what was yours), the honest answer can be a limit.

## 2. Prep triage (about four hours, over the weekend)

| Order | Time | Do this | Ties to |
|---|---|---|---|
| 1 | 75 min | Build and speak the POV aloud, twice, timed. Aim for 11 to 12 minutes so interruptions do not push you past 15. | Section 4, B1, B3, D3 |
| 2 | 60 min | Write out, in your own words, the four things about the £4M figure and the 6 to 40 count: how each was counted, what it is sensitive to, the assumption you would defend least, and what was yours. | C1, C2, D2, F3 |
| 3 | 45 min | Rehearse the no-rail, no-quota answer until it is boring: acknowledge, hold what your record carries, then the ramp. | A1, A2, D1 (A1 is the highest-ROI prep) |
| 4 | 30 min | A drill with me on A1 with follow-ups, then B3. | A1, B3 |
| 5 | 30 min | Re-read the market report once for the one item you will agree with and the one you will push back on. Pick three reverse questions. | Section 4, B4, section 9 |

Everything else in the pack is insurance.

## 3. Fit snapshot

No JD was supplied. Requirements are the recruiter's own words, quoted. Rows with no supplied source are plain prose, labelled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says nine years in partnerships and the last four running an ISV channel at a payments company, not operator partnerships, with nothing inspected behind it. Words at that scope: "I spent my last four years at a payments company running the ISV channel." Answer slot: expect a probe on how ISV partners compare with operators as partners. If parts of your channel work are relevant, say which and why in your own words; if none are, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning in consulting, not train operating companies and not an operator's seat. Words at that scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on how far that reaches to train operators. If any of it overlapped with what a train operator faces, say which part in your own words; if not much did, say so plainly and say what you would want to learn first |
| F3 | "Ross will push on commercials." — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | A specific figure with nothing inspected behind it, so expect it to be taken apart. Words at that scope: "roughly £4M of influenced revenue." Answer slot: say how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; "I don't know how it was counted" is an honest answer |
| F4 | Carrying a direct revenue target; a role-family requirement with no supplied source | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | A gap wording cannot close, and you stated it. Words: "I have never carried a direct quota, only influenced revenue." Then how you would want to be held accountable in this role, said as a proposal and never as a past. No slot |
| F5 | Having sold into rail; a role-family requirement with no supplied source | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | You stated this too. Words: "I've never sold into rail specifically." Then how you would learn the sector, said as a plan. Nothing added to make the gap feel smaller. No slot |

## 4. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. The brief: where you would take operator partnerships over 18 months, talked through without slides, landing on what it means for operators.

**Facts you can build on, from your own sentences.**
- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F3: "took it from 6 partners to 40, roughly £4M of influenced revenue"

**Differentiation strategy.** Deepa and Ross have the market report, and so does every prepared candidate, so reciting it scores as homework. Do three things in this order:
1. Bring one item from the report that you agree with, defended from the operator's side, to prove you read it.
2. Then give one thesis of your own that departs from it, with reasons.
3. Then give the anti-pick: one thing you would deliberately not do in 18 months, and why, in operator terms. The role's job includes saying no, and a POV with no anti-pick sounds like a wish list.

Before choosing, re-read the report and check which side of the table it is written from: Kelverton's or the operators'. That decides which thesis below is a real departure.

| Thesis | What you would say | Mandatory concession | Rests on | Provenance |
|---|---|---|---|---|
| T1: operator outcome first | Judge every partnership by what changes for the operator, and work backwards to Kelverton's revenue. | It will show up in revenue later than a supplier-first view, and you have not seen Kelverton's partner data, so the first 90 days are for testing it. | F2 quote above, at its own scope | [generic] |
| T2: fewer, deeper | Over 18 months, depth with a small number of operators beats a wider list. | Your own record is breadth: "took it from 6 partners to 40". Say that before they do. Answer slot: if you learned something from that growth that points the other way, say what in your own words; if you did not, say so plainly and argue it on the merits | F3 quote above, at its own scope | [generic] |
| T3: sequence and say no | Choose one or two operator-facing plays, sequence the rest behind them, and name what you would decline. | You have not seen the pipeline or the operator base, so the choice is a hypothesis with a checkpoint, and a wrong pick costs time. | F1 quote above, at its own scope | [generic] |

**Suggested shape, about 11 to 12 minutes:**
1. One minute framing.
2. Two minutes on the report item you agree with.
3. Five minutes on your thesis and two supporting moves.
4. Two minutes on the concession and the anti-pick.
5. Two minutes on the close: what it means for operators.

**The requested close.** End on the operator, in three sentences in your own words: what changes on their side, what you would ask of them, and how they would know it is working. Do not supply a number you cannot defend.

## 5. Persona table

The loop is one panel session as the recruiter described it, so no archetype fallback is used.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of no rail and no quota | High. Deepa is your future manager (hiring-manager prior: Case plus Skeptic), and Ross is a commercial director who will "push on commercials" while your own message states both gaps | Rehearse A1 until it is boring. Bridge only from the quoted sentences, and say limits plainly |
| Case/Strategist | The POV itself, then live follow-ups on it | High. A 15-minute POV is the first quarter of the session, and the hiring-manager prior is Case-led | Clarify, objective, segmentation, approach, metrics, risks. State your thesis in the first minute |
| Data-Driven Prober | Ross on the £4M and the 6 to 40 | Medium-high. The recruiter's note about commercials points at your one headline number | Know and say what you can and cannot say about how each figure was counted. Name the weakest assumption before he does |
| Pressure | Time-boxing the POV, "how much was actually you" | Medium. Ross's push and a 60-minute panel make interruption plausible, but nothing says the style is hostile | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Opening "walk me through the journey" | Low weight, still scored. It is the easiest place to ramble | A 90-second arc built only from your quoted sentences |

## 6. Question banks

### A. Skeptic (weight: highest; 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The highest-ROI rehearsal in this pack. Choose the true answer from your own limits, and the quote gives you both: "I've never sold into rail specifically, and I have never carried a direct quota, only influenced revenue." Then a ramp, said as a plan: what you would learn first and from whom in the first weeks. Hold through two follow-ups. Follow-up one: operators will want to know why they should take your commitments seriously without a quota behind you. Follow-up two: how long until you are credible with an operator's commercial team. Give your own timeline in your own words. Concede the limit specifically, and never fold on the record you do have | F4 and F5 are the biggest gaps and the ones both panelists can see, so this arrives in some form. JD because it scores the role's requirements, Skeptic because it probes your honesty about them |
| A2 | "You've never carried a direct quota. How would you be accountable for commercial outcomes here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Acknowledge first: "I have never carried a direct quota, only influenced revenue." Then your figure at its scope: "roughly £4M of influenced revenue." Then propose how you would want to be measured here, as a proposal and in operator terms. Answer slot: if asked to defend the £4M, say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; "I don't know how it was counted" is honest | F4 raises it and Ross's brief makes it his. Tagged JD because it scores accountability for commercial outcomes |
| A3 | "You ran an ISV channel. Operators aren't ISVs. What transfers and what doesn't?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Start with your own scope: "I spent my last four years at a payments company running the ISV channel." Answer slot: say in your own words which parts of that work you would carry across and which you would not; if you think little carries, say so plainly and say what you would do about it | F1 is the nearest evidence and an interviewer will test where it stops. EXP because it tests what your channel work actually was |
| A4 | "Your consulting years were bus and light rail. How much of that reaches train operators?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Keep to the quote's scope: five years in transport consulting, bus and light rail network planning. Do not say you know train operators from the inside. Answer slot: if any of that work overlapped with what a train operator faces, say which part in your own words; if little did, say so plainly and say what you would want to learn first | F2 is the claim most likely to be stretched in the room, so rehearse its honest limit. EXP because it tests what the experience was |
| A5 | "Why leave a payments company for rail-tech, and why now?" | EXP | [generic] | Your material gives no reason, so the words must be yours. Selection criteria: one real pull toward this role and this sector, specific enough that it could not be said of any employer, and no complaint about where you are. If you do not yet have a specific pull toward rail, say so plainly and say what you hope to find out in this conversation | The "why here, why now" probe is in every Skeptic's kit. EXP because it tests motivation consistency against your history |

### B. Case/Strategist (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [generic] | The graded POV: use section 4. Thesis in the first minute, report item, your departure, concession, anti-pick, operator close | The recruiter announced it. CASE because it is a live strategic problem |
| B2 | "What would you need to know first?" | CASE | [generic] | Clarify before you structure, aloud: which operators are partners today and what the relationship consists of, what the partnership is meant to achieve commercially, what has been tried, and what data exists. Then say how the answers would change your plan. Lead with the questions, not a recommendation | Case interviewers score clarifying before structuring. CASE because it is the interviewer's standard probe on a plan |
| B3 | "What does your plan mean for an operator, in their words and not ours?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The recruiter asked for this close. Speak it as a proposal: what changes for them, what you would ask of them, how they would know it is working. Answer slot: if your consulting years inform what you think operators care about, say which part in your own words; if they do not, say so plainly and say how you would find out from operators themselves | F2 is where the candidate's side of the story would come from, and the recruiter said to land here. CASE because it is a plan stated from the customer's side |
| B4 | "Is there anything in the report we circulated that you'd push back on?" | CO | [generic] | Pick one item you can defend from the operator's side and give your reason in operator terms. If you have no real disagreement, say so plainly and say which item you would test first. Do not recite the report back, and do not correct the room | A shared source is the consensus answer, so departing from it scores judgement. CO because it tests how you read the company's own thinking |
| B5 | "Partner count or partner depth: what do you optimise for over 18 months?" | CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Choose one and say why in operator terms. Your own record is the count, "took it from 6 partners to 40", so name that before they do. If the figure comes up, say how the count was reached and which part was yours, in your own words | Your headline figure is breadth, which makes T2 an easy trap. CASE because it forces a choice and a defence |

### C. Data-Driven Prober (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Your figure at its scope: "roughly £4M of influenced revenue." Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how part of it was counted, say so plainly. Naming the weakest assumption first reads as credibility | F3 is a specific figure with nothing inspected behind it. EXP because it tests whether the claim survives scrutiny |
| C2 | "How was a partner counted when you went from 6 to 40?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say what counted as a partner, in your own words, and what part of the growth was yours. Keep to "took it from 6 partners to 40" and add nothing to it. If you do not know exactly how the count was set, say so plainly | The count is the second number a prober will test. EXP because it tests attribution and definition |
| C3 | "How would you judge, before revenue shows, whether an operator partnership is working?" | CASE | [generic] | Pick two or three leading indicators in operator terms, and name the one you would trust least. This asks about no past, so the guidance makes no claim about yours | Ross's commercial push is likely to reach forward-looking measures. CASE because it is a live problem on the role |
| C4 | "Which of your numbers would you least want us to rely on?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Name the weakest assumption you know of in your figure, in your own words, before they do. If you do not know which is weakest, say so plainly and say how you would find out | Conceding the weak spot early converts a gotcha into credibility. EXP because it tests self-knowledge of the figure |

### D. Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause, restate. Hold what your quotes carry: nine years in partnerships, the last four running an ISV channel at a payments company. Concede plainly: "I've never sold into rail specifically." Hold through two follow-ups without adding a rail claim | F5 makes this comparison the natural pressure question. JD because it scores fit against the role |
| D2 | "That growth from 6 to 40: how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold your sentence: "took it from 6 partners to 40." Answer slot: say what part was yours, in your own words; if part of it was done by others or came from existing relationships, say so plainly and return to what you did. Do not widen "took it" into anything larger | The attribution probe is standard for a number this visible. EXP because it tests precise attribution |
| D3 | "Land your recommendation in thirty seconds." | CASE | [generic] | One sentence of recommendation, one of why, one of what it means for the operator. Practise it until it fits | A time-box tests whether the POV has a spine. CASE because it is a live structuring task |

### E. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with only the beats the quotes state: five years in transport consulting, bus and light rail network planning, then nine years in partnerships, the last four running the ISV channel at a payments company. Answer slot: say in your own words why you moved between them; if there was no single reason, say so plainly | The biography question is scored even in a friendly register. EXP because it tests whether the story is coherent |
| E2 | "What have you been thinking about on operator partnerships lately?" | CO | [generic] | Selection criteria: one idea from the report or your own reading that you find genuinely interesting, and the one question it leaves open. If nothing has caught you yet, say so plainly and say what you would want to read first | Casual questions on the role's hot topics are still scored. CO because it tests homework depth |

## 7. Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: POV on operator partnerships, 18 months | B1, B2, B5, A3, D3 |
| F2: land on what it means for operators | B3, A4, E1 |
| F3: commercials | C1, C2, C3, C4, A2, D2 |
| F4: direct revenue target | A1, A2 |
| F5: having sold into rail | A1, D1 |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "What would operators say, 18 months from now, if this had gone well?" | It reuses the recruiter's own brief and shows you think from the operator's side |
| R2 | To Deepa: "What has changed since the market report was circulated last quarter?" | It shows you read it and asks for the current picture without correcting anyone |
| R3 | To Ross: "How do you want partnership-influenced revenue counted and reported here?" | It turns your quota gap into a measurement conversation and tests how commercials are really judged |
| R4 | To both: "What would you want to see from me in the first 90 days?" | It signals you are planning the ramp the Skeptic questions probe |
| R5 | To Deepa: "How is it handled when an operator partnership isn't working?" | It shows you think about failure modes, which a partnerships lead has to own |
| R6 | To both: "Is there anything in my background you'd want me to address before we finish?" | It hands them the chance to name the doubt, so you can answer it live |

## 9. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | "I've never sold into rail specifically." No slot |
| Has carried a quota or owned a revenue number | Negative you stated, F4 | "I have never carried a direct quota, only influenced revenue." No slot |
| Closed, sourced or owned the £4M | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says influenced revenue |
| Knows train operating companies from the inside, or has operator-side experience | Inflated form of F2 | F2's quote at its own scope. Your material says bus and light rail network planning in consulting |
| Has built or run operator partnerships | Inflated form of F1 | F1's quote at its own scope. Your material says an ISV channel at a payments company |

## 10. Sources

Provided: your message, which quotes the recruiter's email. The market report attached to that email was not pasted or uploaded, so its content is not used anywhere in this pack.

Searches sent, all refused, none retried:
- `Kelverton Rail scheduling software train operating companies`: refused
- `Kelverton Rail values`: refused
- `Kelverton Rail strategy news partnerships`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Every call was refused. It would have named published values for VAL themes; no values round is documented, so it would not have added a values sheet |
| 2. `Kelverton Rail interview process partnerships` | skipped | The recruiter's email already fixes the loop: one panel, 60 minutes, a POV then Q&A. Persona weights follow it |
| 3. `Kelverton Rail strategy` or recent news | unavailable | Every call was refused. It would have grounded the CO and CASE questions in current facts, which are `[generic]` instead |
| 4. `Deepa Kelverton Rail` and `Ross Kelverton Rail` | unavailable | No call was sent after searches were refused. It would have supplied an interviewer read and a reverse question tied to their paths |
| 5. representative `Senior Partnerships Manager` JD | unavailable | No call was sent after searches were refused. It would have supplied `[inferred]` requirement rows and JD-tagged questions |
| Unnumbered: the first query above, a company-overview lookup | unavailable | Refused, so it moved nothing |

## 11. Upgrade menu

- Search permission for this session → values, loop reports, current strategy and the interviewers' public footprints become sourced rather than absent, and an interviewer read and a tailored reverse question appear
- The market report's text, pasted → a grounding brief on Kelverton's own vocabulary, B4 and the POV's differentiation rest on what it actually says, and B2, C3 and E2 stop being `[generic]`
- The JD text → the recruiter-word and `[generic]` requirement rows become `[grounded]` on the JD's lines, and any mid-list requirement gets its own question
- Your CV → more of your sentences to quote, so E1 and B3 can be mapped to stories beyond the four you gave
- The report or CRM export behind the £4M figure → F3 rises from medium to high, and C1 and C2 stop being answer slots
- Answers to the slots in A3, A4, B3 and D2 → the guidance there rests on your own words, not on an instruction
- A tuesday-dossier.md from an earlier job-underwriter run → verified evidence and prohibited claims arrive ready-made
- If the recruiter can say whether any other panelist joins, or whether a values conversation is planned → a values sheet and a changed persona mix
