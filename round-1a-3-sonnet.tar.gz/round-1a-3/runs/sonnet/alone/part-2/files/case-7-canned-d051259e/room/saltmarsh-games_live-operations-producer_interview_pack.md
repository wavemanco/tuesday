# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations, treated as the hiring manager. Round: the Outage Hour, a single 60-minute session, per Saltmarsh's interviewing page (see Sources). It opens with a live-incident tabletop on a simulated outage during a live event, then moves to a values conversation. There is no take-home.

Built on one assumption: Tobias is the hiring manager who runs the Outage Hour. If someone else sits in, the persona weights change.

## How to use this pack

Personas say how a question arrives. Types say what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | A stated requirement of the role, gaps included |
| CO | Knowledge of the company's strategy and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience, or say plainly the practice was not yours.

## Fit snapshot

The JD names no eligibility, location or pay term, so no row here is a `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material carries one main title and a weekly content-drop calendar, where the JD says live events across two titles. Keep your words at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on how far your calendar reached likely. If any of what you ran covered more than the main title, say which part and how, in your own words; if none did, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with on the weekly drops. Answer slot: the JD names four teams, so expect a probe on how updates got coordinated. If you worked with any of them on the drops, say which and how, in your own words; if you did not, or the coordination was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Presenting numbers monthly is the limit of what your material shows here, and the bridge should not be stretched past it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if any part of choosing what went into those monthly presentations was yours, say which, in your own words; if none was, say so plainly and stay with the presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it. Words at that scope: "I wrote the release checklist our QA team still uses." Answer slot: Tobias's public path includes QA lead, so expect depth on this row. Say how QA uses the checklist today, in your own words; if you know little about how it runs now, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years on the weekly calendar. It does not say whether the main title ran as a live service. Answer slot: if the main title ran as a live service, say how, in your own words; if it did not, say so plainly and stay with the weekly calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but nothing is inspected behind the line, so expect a probe on it. Lead with the quote's own terms: you ran it, weekly, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a probe on how those numbers were counted is likely. Answer slot: say what you know about how they were counted, in your own words; if you do not know, say so plainly and stay with having presented them monthly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is writing, and your material shows nothing else written for a wider audience. Answer slot: if other writing of yours reached a wider audience, say what, in your own words; if none did, say so plainly and point to the checklist you wrote |

Two stated negatives sit outside the JD's list but will be raised: "Never led a team, and never worked on a game with in-app purchases." — your message. They are handled in C1, C2 and the prohibited list below.

## Reading the interviewer

Public professional footprint only.

| Signal | What the source says | Provenance | What it means for you |
|---|---|---|---|
| Role | "Head of Live Operations at Saltmarsh Games" | [grounded] | Tobias owns the function you would join, so tabletop answers are scored by the person who would work with you |
| Prior path | "previously a QA lead at a console studio" | [grounded] | Release checklists and QA are native ground, so F4 will be probed closely |
| Talk | GDC 2026 talk "Patch Notes Are a Promise"; the listing says the argument is that "a live team is judged by how often its patch notes describe what actually shipped" (listing only, the talk itself was not read) | [grounded] | Expect attention to the gap between what is announced and what shipped. Do not say more than your material carries; it mirrors the value Ship the Patch Not the Promise |
| Mirror vocabulary | Shared ground is QA and release checklists. Your side, from F4: "Wrote the release checklist our QA team still uses." — your message | [inferred] | Use "release checklist" and "QA" in your own sentences. This is shared vocabulary, not a shared career jump |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The tabletop on a simulated outage during a live event | High. The careers page makes the tabletop the first half of the session, and a hiring-manager round leans to Case | Clarify, state the objective, name who you pull in, say what players are told and when, then say what you record. Think aloud and challenge one premise |
| B. Values/Behavioral | The second half of the session: a conversation on Saltmarsh's three published values | High. The careers page names a values conversation, so a values-style round is detected | Map a story to each value where one of your quoted sentences carries it; where none does, use the selection scaffold and its honest branch |
| C. Skeptic | Quiet probing of the gaps | Medium-high. A hiring manager derisks gaps, and you have stated two negatives (the sentence quoted under the fit snapshot) and carry one title against a JD that says two | Rehearse C1 until it is boring: concede the gap in one plain sentence, hold what your quotes carry, give a plan said as a plan |
| D. Data-Driven Prober | Checks what you announced against what you did, and how numbers were counted | Medium. Tobias's talk listing centres on announced versus shipped, and the retention numbers are the one metric on your side | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| E. Pressure | Time-boxed challenges inside the tabletop | Low-medium. A live incident is time-boxed by design, but the page names no stress interviewer | Pause, restate, hold a challenged position through two follow-ups before conceding anything real |
| F. Conversational | The opening biography question and a casual question on Larkspur | Low-medium. A session usually opens warm, and the Larkspur news is easy small talk that is still scored | A 90-second arc from your four quoted sentences; treat the casual question as scored |
| Peer Evaluator | Not included | The careers page describes one session with the hiring manager, so no peer is in the loop | None needed |

Highest-ROI prep in this pack: C1, the in-app purchases question. Saltmarsh's announcement moves its two titles to a season-pass model from February 2027, and your stated negative is exactly where that lands.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is the first hour of a limited-time event and players cannot log in. You are the producer on call. What do you want to know first, and what do you do in the first fifteen minutes?" | CASE | [generic] | Think aloud in order. What you need to know: who is affected, what changed recently, who is on call in engineering. Objective: players back in and told the truth about what is known. Who you pull in, and what each does. What players are told and when. What you write down for the review. Say what is known and what is not; give no fix time you were not given | The Outage Hour opens with this kind of tabletop. CASE because it scores structure over the right answer; it also exercises the JD's coordination line (F2) |
| A2 | "Engineering says the fix is about three hours away and the event has six hours left. Players are posting. Do you extend, compensate, or let it run?" | CASE | [generic] | Clarify first: is three hours an estimate or a commitment, who is affected, and what extending does to the calendar behind it. Lay out the options, then decide with players first, which is the published value Players Before Plans. Say the trade you are making out loud and what you tell players | The calendar-versus-players conflict is the first value on the published page. CASE with a VAL edge |
| A3 | "A reward is granting the wrong amount. Engineering wants to hotfix tonight and QA wants a full regression pass. How do you decide?" | CASE | [generic] | Ask what is affected and for whom, what the smallest change is, what QA must verify before it ships, and who decides. Say what players are told, keeping to what is built rather than what is hoped | Puts the JD's QA checklist line (F4) in a live problem without presupposing a past. CASE |
| A4 | "Say out loud the first three lines of the player-facing message about the outage." | CASE | [generic] | What is known, what is not, when the next update comes. Plain words, no promise of a fix time, nothing announced that is not built | JD asks for clear written communication (F8), and Tobias's listed talk is about patch notes. CASE because it is delivered live |
| A5 | "The event is over. Walk me through the review you would write and the KPIs you would report." | CASE | [generic] | Structure: what was planned against what happened, player impact, what you would measure and why, what changes next event, who reads it. Name the KPIs you would choose and say why, in your own words | JD line on the post-event review and its KPIs (F3). CASE because it asks for a design, not a past |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time with a named stake, a decision, and what players got. The quote carries the calendar, not a disagreement, so the middle of the story has to be your own. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the calendar you ran, or how you would handle it | Players Before Plans is the first published value; the theme comes from the value's own text. F1 is the nearest evidence |
| B2 | "Tell me about a time you were asked to announce something that was not built yet." | VAL | [grounded] | Selection scaffold: pick a time with a named announcement, what you said, and what you did. If no such time comes to mind, say so plainly, then say how you would handle the request | Ship the Patch Not the Promise is the second published value; no quoted sentence of yours carries this story |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the checklist, and QA still uses it. Tell those two beats in your own words. Answer slot: the value names the checklist, so expect a probe on what it improved. If you can say what it replaced or changed, say so in your own words; if nothing came before it, or it was not yours alone, say so plainly and stay with the quote | Leave the Build Greener is the third published value. The checklist is your one quoted sentence that carries it |
| B4 | "Tell me about a time you delivered a truth a team did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: a named truth, who it was for, and whether it landed. The quote carries the presenting only, not what the numbers showed or how they were received. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Stock values stem, tied to the published value that announcements follow what is built. F7 is the nearest evidence |
| B5 | "Which of our three values would be hardest for you, and why?" | VAL | [generic] | Choose the one that is truthfully hardest. Say why in one plain sentence and what you would do about it, as a plan | Tests honest self-assessment against published values; no past claim is needed |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "As I read your background, you have not worked on a game with in-app purchases, and from February 2027 our two titles move to a season pass. How would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Highest-ROI rehearsal in this pack. Concede in one plain sentence: "I haven't worked on a game with in-app purchases." Hold only what your quotes carry: you ran the weekly calendar for the main title, and you presented the retention numbers. Then a plan said as a plan: what you would learn first, from whom, and how you would check you had it right, in your own words. Follow-up one, "retention is not revenue": agree where it is true and do not claim the numbers covered spend. Follow-up two, "who would you ask": name roles, not people you have not met. Limit named before it is asked for: your material says no in-app purchases, so no sentence may imply it | The stated negative meets a documented monetisation change; F1 and F7 are what you can hold. JD because it scores a listed capability gap |
| C2 | "You have not led a team, and this role coordinates design, art, engineering and community. Why would they follow you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Concede plainly: "I haven't led a team." The JD says coordinate, not lead, and your material shows neither; do not blur the two. Answer slot: if you worked with any of those teams on the weekly drops, say who and how, in your own words; if you did not, say so plainly and say how you would earn their trust in the first month, as a plan | F2 is the unfilled row and the stated negative sharpens it. JD because it tests the coordination line |
| C3 | "The JD says two titles and you have run the calendar for one. What changes when it is two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold at scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any of what you ran covered more than the main title, say which part and how; if it did not, say so plainly and stay with the main title's calendar. Then what you would ask first about the second title, as a plan. The announcement describes one shared calendar and a single live-ops group from February 2027, so do not correct Tobias on the JD; ask about it in R3 | F1 is the transferability gap. JD because the two-title line is in the JD |
| C4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose honestly from F2, F3 and the stated negatives, and name it before Tobias does. Use "I haven't led a team" or "I haven't worked on a game with in-app purchases" if you pick those, then say how you would ramp, as a plan. Avoid choosing a strength dressed as a weakness | Standard Skeptic stem. JD because it maps to the stated requirements |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Walk me through how those were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say what you know about how they were counted, in your own words, and name the assumption behind them you would defend least. If you do not know how they were counted, say so plainly. Say which part was yours: the quote says you presented them | F7 is the only metric on your side, so it is the number a Prober goes to. EXP because it tests what was actually yours |
| D2 | "Ship the patch, not the promise: on a weekly drop you ran, how did you check that what you announced was what went out?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses." | Answer slot: if you checked, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the calendar you ran and the checklist you wrote | F1 and F4 are the quoted ground, and the published value raises the probe. EXP because it tests whether a practice was yours |
| D3 | "Tell me about the release checklist you wrote. How does QA use it today?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it. Answer slot: say how QA uses it today, in your own words; if you know little about how it runs now, say so plainly and stay with having written it | The most natural probe for a former QA lead (F4) |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has run live events with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate. Concede first: "I haven't worked on a game with in-app purchases." Hold what the quote carries: you ran the weekly calendar for two years. Answer slot: what else you offer, in your own words; if that is little, say so plainly and say how fast you would ramp. Hold through two follow-ups, concede only what is true | Compresses C1 into a time-box. JD because it presses the in-app purchases gap |
| E2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours alone and which were shared, in your own words; if you do not know where the line sits, say so plainly | Attribution probe on F1 and F6. EXP because it tests ownership |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc in your own words: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title over the last two years; the release checklist QA still uses; the monthly retention presentations. Answer slot: end with your own reason for wanting live operations here; the material does not supply one | Likely opener; F5, F6, F4 and F7 are its beats. EXP because it tests whether the story hangs together |
| F2 | "Project Larkspur moves our two titles to a season pass with one shared calendar from February. What do you make of that for a live-ops producer?" | CO | [grounded] | Say what the announcement says and no more: two titles to a season-pass model, one shared events calendar from February 2027, a single live-ops group in place of per-title event teams. Then what you would want to know before giving an opinion: what players get, how the calendar is built, what changes for the team. Opinions on internal details are not yours to have | The one strategy question from the announcement of September 2026. CO in a casual register, and it is scored |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A2, C3, E2, B1 |
| Coordinate design, art, engineering and community teams | A1, A3, C2 |
| Own the post-event review and its KPIs | A5, D1 |
| Manage the release checklist with QA | A3, B3, D2, D3 |
| 3+ years producing live-service games or apps | F1, C4, E1 |
| Experience running a content calendar | B1, D2, E2, F1 |
| Comfortable with player-retention metrics | D1, A5 |
| Clear written communication | A4, B2 |

## Values cheat sheet

A values-style round is detected: the careers page names a values conversation.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F1: "I ran the weekly content-drop calendar for our main title for the last two years." — your message. It carries the calendar only, so a disagreement story is a selection scaffold (B1) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No row's quote carries this story. Selection scaffold in B2, with its honest branch |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message. Story-mapped in B3, with its answer slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live operations from a QA lead role at a console studio. What did that change about how you run a live team?" | Ties to Tobias's own path and to the QA ground of this role (F4), and invites a story rather than a recital |
| R2 | "Your GDC talk is about patch notes as a promise. How does the team measure whether the notes match what shipped?" | Shows you looked at Tobias's published work and speaks to the value Ship the Patch Not the Promise. The talk itself was not read, only its listing, so ask rather than assert |
| R3 | "From February, Larkspur describes one shared calendar and a single live-ops group. How does the role map onto that?" | Surfaces any gap between the JD's two titles and the announcement without correcting anyone |
| R4 | "Coming from a game without in-app purchases, what would you want me to learn first about the season pass?" | Turns the stated gap into a plan and shows you intend to close it |
| R5 | "What does a good post-event review look like here, and which KPI has most changed how you run events?" | Speaks to the JD's review and KPI line (F3) and shows you think about reporting |
| R6 | "What separates strong tabletop answers from weak ones in the Outage Hour?" | Asks how the first half is scored, which only the interviewer can answer |

## Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or on monetisation or a season pass | Negative you stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Never imply the retention numbers covered spend |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope: the weekly content-drop calendar for the main title. The limit is the pack's observation: your material says one main title and drops |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. The material shows presenting, not owning a review |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope: you wrote it and QA still uses it |

## Sources

Provided: the JD and your background, both in your message. No dossier.

Searches and fetches sent:

- Search `Saltmarsh Games values` returned https://saltmarshgames.com/values
- Search `Saltmarsh Games interview process Live Operations Producer` returned https://saltmarshgames.com/careers/interviewing
- Search `Saltmarsh Games mobile studio strategy news` returned https://saltmarshgames.com/news/project-larkspur (search result text only; the page was not fetched)
- Search `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search result text only; the talk was not read)
- Fetch https://saltmarshgames.com/values returned the three values and their one-line meanings
- Fetch https://saltmarshgames.com/careers/interviewing returned the loop description

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Values cheat sheet, B1 to B3, three published value names |
| 2. `{company} interview process {role family}` | yes | Loop established: one 60-minute session with the hiring manager, tabletop then values. Persona weights and the banks follow it |
| 3. `{company} strategy` / recent news | yes | Project Larkspur (September 2026): the CO question in bank F, plus C1, C3, R3, R4. Result text only, so the announcement's detail is limited to what that text says |
| 4. `{interviewer name} {company}` | yes | Interviewer read, D2, R1, R2. Listing text only |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and JD questions |

## Upgrade menu

- Your answers to the answer slots in F1 to F5, F7 and F8 → those rows move from `discovery` or `transferability` toward `none`, and the matching guidance becomes story-mapped instead of slotted
- The release checklist itself, with any names removed → F4 from `medium` toward `high`, and a written sample for F8
- The recruiter's note on the Outage Hour, such as the scenario's domain or who scores it → the case bank tuned to the real tabletop
- How many hours you have before the session → a prioritised prep schedule, which this pack omits because the time is unknown
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → the full Larkspur announcement, Tobias's talk read in full, and a grounding brief on the studio's strategy
- A tuesday-dossier.md from job-underwriter → verified evidence rows and a sourced list of claims to avoid, replacing the ones this pack built locally
