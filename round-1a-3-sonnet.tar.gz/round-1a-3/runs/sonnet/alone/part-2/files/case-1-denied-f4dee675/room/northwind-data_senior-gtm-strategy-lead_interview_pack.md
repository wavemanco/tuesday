# Mock interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Format:** one 60-minute conversation.

## How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior demonstrates the company's published values. None in this pack: no published Northwind values were in hand and no values round is documented |
| EXP | Whether the CV's claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Northwind's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

An **answer slot** is an instruction for the interview, not a question for you now. It names what Dan is likely to probe and gives two honest branches: say what you did in your own words, or say plainly that the step was not yours or did not exist, and return to what your material does carry. Question IDs run by persona (A to E, then G). F is skipped so a question ID never collides with a fit-snapshot row ID (F1 to F7).

**Highest-ROI prep in this pack: C1.** The partner-motion requirement is the likeliest place Dan presses, and it sits where the material is thinnest. Rehearse it until it is boring.

## Fit snapshot

The requirements are quoted from the JD highlights you sent, which may not be the full posting. Evidence is quoted from your description of Priya, not from her CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market for new lines, and the words stay there: "For nine years I was in product strategy and ops at a large consumer-tech company." Answer slot: the JD's line on owning GTM for two new lines makes a probe on go-to-market work likely. If any of that work was go-to-market for something new, say what and which part was yours, in your own words; if none was, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Your material says you proposed a change and that the uplift was credited to it, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." It does not show how the opportunity was found or which lifecycle stage it sat in. Answer slot: the JD names land, adopt, expand and renew, so expect a probe on how the opportunity was found; if an analysis found it, say which, in your own words; if it came another way or from someone else, say so plainly and stay with the proposal. Four defend-the-number slots: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | Your material says skilled in the tools, not that you ran an analysis end to end. Answer slot: the JD asks for independent analysis, so expect a probe on one you ran yourself; if you wrote the queries and built the views for an analysis, name it and what it fed; if someone else ran them, or you used the tools for something other than analysis, say so plainly and stay with "I'm skilled in SQL and Tableau" |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a model used in carrier negotiations, not a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD requires partner-motion design, so expect a probe on what you shaped about how a partner relationship worked. If any of it was yours to set, say what and how you decided, in your own words; if the model priced the relationship and the structure was set elsewhere, or there was no such step, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Reword only the quote: "I set annual volume targets, with consensus across orgs." Keep "cross-org", the candidate-side term, rather than the JD's "cross-functional". The quote does not say who disagreed or how consensus was reached, so a probe on process gets the answer slot in B2 |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | none | No gap in the requirement as worded, but a line with nothing inspected behind it, so expect a probe on which tools and for what. Lead in the quote's terms: "I use AI tools daily." The slot for naming them is in E2 |
| F7 | Sales-ops and quota-setting experience — plain prose, not in the JD highlights you sent; you flagged it as a gap | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap wording cannot close, and it was stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Annual volume targets in F5 are not described as quotas anywhere in this pack |

## Reading the interviewer

Public footprint is limited to the profile description in your message. The search for talks and posts was refused (see Sources), so none were read.

| Signal | What it implies | Provenance |
|---|---|---|
| Self-described "relentlessly data-driven" (profile, via your message) | Every number gets probed to its assumptions. Say how a figure was counted, or that you do not know, before he asks | [grounded] |
| Career spine in pricing and monetization (profile, via your message) | Case questions tilt to pricing, packaging and unit economics. Ask a pricing-angle clarifier in every case | [grounded] |
| One early-stage-startup chapter (profile, via your message) | Builder stories tend to land with this background, and a scrappiness probe against nine years at a large company is plausible. No fit-snapshot row carries a builder story, so none is offered here | [inferred] |
| Peer under the same VP (your message) | He is weighing what you cost and contribute to his own work, so expect seam questions and a probe on sales-ops overlap, where F7 sits | [generic] |
| Mirror opportunity: his monetization path beside F4's evidence | Shared professional vocabulary is revenue economics. F4's sentence, quoted exactly: "built a partner-level revenue model used in carrier negotiations". Use it to talk about how partner revenue was modeled, not to claim a shared identity | [grounded] |

## Persona table

Weights rest on the peer relationship prior, the signals above, and the one-conversation format you described. No Northwind loop documentation was read, so no weight rests on a documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober (5 questions) | Probes the ~$400M figure, the revenue model and any SQL or Tableau claim to inputs and assumptions | Highest: his self-description, plus F2 being a headline figure | Say what you know about how each number was counted and what you do not; name your weakest assumption first |
| B. Peer Evaluator (4) | Seam between his team and yours, credit across teams, what you need from him | High: the relationship is peer, same VP | Reciprocity first; propose seam principles rather than pretending to know the seam |
| C. Skeptic (3) | Presses F4 and F7, and the move from consumer tech | Medium-high: those are the two thinnest rows against a required item | Rehearse C1 until boring; concede the limit specifically; add a ramp plan stated as a plan |
| D. Case / Strategist (3) | Live problems on new-line GTM, pricing and bundling | Medium: pricing spine tilts toward cases, one hour limits length | Clarify, structure, metrics, risks; ask a pricing clarifier |
| E. Conversational (2) | Biography opener, casual AI question | Medium-low: openers are near-certain but short; the AI question is the JD plus | Script the 90-second arc; treat the AI question as scored |
| G. Pressure (2) | Time-boxed challenge on fit and attribution | Low: no signal for it in a peer conversation, but F2 and F7 invite it | Pause, restate, hold through two follow-ups, then concede specifically |

## Question banks

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | G1, C2, D1, D2, D3 |
| identify whitespace across land/adopt/expand/renew | A5, D1 |
| run independent analysis in SQL and Tableau | A2, A3, A5 |
| partner-motion design experience required | C1, A2 |
| strong cross-functional influence | B1, B2, B3 |
| AI experience a plus | E2, D3 |

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You proposed a store-surface change that was credited with a ~$400M ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the quote's own scope: you proposed the change, and the uplift was credited to it. Then four slots, each in your own words. Answer slot: how the figure was counted. Answer slot: what it is sensitive to. Answer slot: the assumption you would defend least, named before he names it. Answer slot: which part was yours. If you do not know how it was counted, say so plainly. Do not offer a method you cannot repeat under a second question | F2 is the headline metric, and a data-driven peer will go to it first. EXP because it tests attribution and counting, not the role |
| A2 | "You built a partner-level revenue model used in carrier negotiations. What went into it, and where did the inputs come from?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold the quote: you built the model, and it was used in carrier negotiations. Answer slot: the JD asks for independent analysis in SQL and Tableau, so expect a probe on whether you built the model in those tools. If you did, say where; if the model lived elsewhere or the data came from someone else, say so plainly and return to the model. Answer slot: if you gathered the inputs yourself, say which and how; if they were handed to you, say so | F4 and F3 meet here: the model is the nearest evidence for both the partner and the analysis requirements. JD because it scores independent analysis; the EXP content is in the rationale of A1 |
| A3 | "Pick one analysis you ran end to end yourself, from the question to the decision it fed. Walk me through it." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: choose an analysis where you wrote the query yourself, can say what the data could not tell you, and can name the decision it fed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, or describe how you would run one. Never describe a query or a view you did not build | F3 is a discovery row, so this prompt turns the gap into a choice of story. JD because the requirement is independent analysis; open prompt because the JD supplies the theme |
| A4 | "How would you know that uplift wasn't coming anyway?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Return to the quote: the uplift was credited to the change you proposed. Answer slot: if the crediting accounted for what would have happened without the change, say how, in your own words; if it did not, or you do not know, say so plainly and name what you would want to check | F2's attribution is the Prober's second move after counting. EXP because it tests whether you know the limits of your own figure |
| A5 | "What would you put on a Tableau view for a new line's first quarter of land and expand, and what would you refuse to read into it early?" | JD | [generic] | Live structure, no claim about your past: clarify the product and the motion first, then pick two or three measures per stage of land, adopt, expand and renew, say what each could mislead you about, and name the one decision each would change. Ask a pricing or packaging clarifier, since that is his native ground | Covers the whitespace requirement (F2) and the Tableau line (F3) as a live problem. JD because it scores the stated requirements; CASE in delivery |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side under the same VP. Where's the seam between us, and what happens when we disagree?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Propose seam principles rather than a map you cannot know: who owns which decision, how a disagreement is put to the shared VP with the data on one page, and what each side promises the other. If the seam runs through sales-ops mechanics, your own words: "I don't have classic sales-ops or quota-setting experience." Then what you would ask him to teach you and what you would bring in return | F7 is where a peer in sales strategy is most likely to feel exposed on your behalf. JD because it scores partnership fit for the listed role |
| B2 | "Tell me about a time you got other teams to agree to a number they didn't want." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story map on F5, with only the quote's beats: annual volume targets, which you set, with cross-org consensus. Answer slot: the JD asks for cross-functional influence, so expect a probe on where the orgs disagreed. If they did, say what, and what part of resolving it was yours; if consensus came without disagreement, or was not yours to broker, say so plainly and stay with the targets | F5 is the evidence for the influence requirement. Open prompt, theme from the JD; EXP because it tests what you actually did |
| B3 | "How do you handle credit when the work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Selection scaffold: pick a time credit was shared, where you can name who contributed what and how it was recognized. Answer slot: if others' work fed into the change you proposed, say whose and what; if it was yours alone, or you do not know, say so plainly. If no such time comes to mind, say so, then say how you would handle it | Peer stem; F2's "credited with" makes it pointed rather than generic. EXP because credit-sharing is about attribution honesty |
| B4 | "What would you need from me in your first thirty days, and what could you do for my team?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first: ask what his team's most important unanswered analytical question is. What you offer is the quote at its scope: you are skilled in SQL and Tableau. Then your needs, as questions: who owns the data on adoption and renewal, and who owns the partner relationships | Peer prior calls for a reciprocity answer. JD because it scores how the hire adds to or reduces his load |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role requires partner-motion design. Which part of a partner motion have you owned yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The deepest rehearsal in this pack. The hold is only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any of it was yours to set, say what and how you decided; if the model priced the relationship and the structure was set elsewhere, or there was no such step, say so plainly and stay with the model. Three follow-up levels to rehearse. First: "Which partner, and who set the terms?" Say what the model did and who set the terms, in your own words. Second: "So you modeled it, but you didn't design it?" Return to the model; the honest limit is that your material says the model, not the motion. Third: "What would you do first here?" Answer as a plan: what you would ask his team and read in your first weeks. Hold through all three by returning to the model, never by adding to it | F4 is where the JD's required item meets the thinnest evidence, and it sits in a peer's area. JD because it scores the stated requirement; Skeptic because it probes the gap |
| C2 | "Your background has no classic sales-ops or quota-setting experience. This role sits next to mine, so how does that not become my problem?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | Plain acknowledgment first, in your own words: "I don't have classic sales-ops or quota-setting experience." Then the adjacent work at its own scope: you set annual volume targets with cross-org consensus. Answer slot: if he asks how those targets compare with a quota, say what they covered and who they applied to; if you cannot say, say so plainly. Close with a ramp plan stated as a plan: what you would learn from his team and by when | F7 is a stated gap, so the objection arrives in some form. JD because it scores whether the hire can work in the sales-strategy seam |
| C3 | "After nine years at a large consumer-tech company, why a B2B data-infrastructure company, and why now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | The reason is yours: give your actual reason for the move and for Northwind, in your own words; nothing in the material supplies one. Say what the nine years were in the quote's terms, product strategy and ops, and let him draw the line to the role. Answer slot: if any of that work touched enterprise or B2B customers, say what; if none did, say so plainly | Motivation consistency is the Skeptic's standard probe and F1 is the row it leans on. EXP because it tests whether your path survives cross-examination |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A new line is landing customers but few of them adopt beyond a pilot. Diagnose it. What do you need to know first?" | CASE | [generic] | Clarify first: which line, which segment, what counts as adopted, what the pilots were sold on. Then structure by land, adopt, expand, renew; name the two or three cuts of data you would pull and the pricing or packaging question you would ask. Close with the decision each cut would change. No claim about your past | JD vocabulary for the whitespace requirement (F2), as a live problem. CASE because it scores structure; pricing angle chosen for his spine |
| D2 | "Bundling by a much larger platform vendor is the main threat. How does that change your go-to-market for a new line?" | CO | [grounded] your research note: "main competitive threat is bundling by a much larger platform vendor" | Do not recite the note; any prepared candidate has it. Bring one consensus point to prove grounding, then one thesis of your own with its concession. Clarify which lines are exposed to the bundle first. Two thesis options: lead where the standalone product wins on its own merits, or lead with a partner-led motion; each needs the case against it stated. Name the metric that would tell you you were wrong | The research note names the threat, and a strategy-adjacent peer tends to test it. CO because it scores company-altitude thinking. The note's age is unknown, so check it before using it |
| D3 | "Enterprise expansion, the Compass launch and profitability are all priorities. Where would a new line's GTM plan have to trade one off?" | CO | [grounded] your research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Clarify first: is Compass one of the two lines, or a separate launch the lines must sit beside? Then name the tension you see, take a position on sequencing, concede what it costs, and name the one measure that would make you change your mind. Do not claim knowledge of Northwind's internal plans | Three stated priorities from your note give a natural trade-off question. CO because it tests prioritization at the company's level; also touches the AI plus |

### E. Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quotes state: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company, then this role. Answer slot: give your own reason for each move, and your reason for this one. Nothing in the material supplies them. End on what you want to work on next | A casual opener is still scored, and F1 is the row it summarizes. EXP because it is the biography question |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start with the quote at its scope: "I use AI tools daily." Answer slot: name the tools and one thing you actually use them for, in your own words; if it is mostly drafting or search, say so plainly. Then turn it back: ask what Compass is meant to do for the buyer | F6 is the JD plus, asked casually. JD because it scores the stated plus |

### G. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: you have no sales-ops or quota-setting background. Why you?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause and restate the question. Hold: you built a partner-level revenue model used in carrier negotiations, and you set annual volume targets with cross-org consensus. Concede specifically: "I don't have classic sales-ops or quota-setting experience." Hold the position through two follow-ups; give up nothing beyond what you have conceded | F7 plus F4 and F5 are the materials a time-boxed challenge would use. JD because it scores fit against the role |
| G2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Anchor in the quote: you proposed the change, and the uplift was credited to it. Answer slot: what part of the work after the proposal was yours; if others built or ran it, say so plainly. Answer slot: if you do not know how credit was assigned, say that. Concede the limit you actually have, in specific terms, and hold the rest | F2 under attribution pressure. EXP because the question tests what was actually yours |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent most of your career in pricing and monetization, with a startup chapter along the way. How does that shape how you'd want a sales-strategy director and a GTM lead to split a decision like packaging a new line?" | Ties to his own path, turns an interrogation into a peer conversation, and surfaces the seam from his side |
| R2 | "What's the one analysis you wish someone on a neighbouring team would just own?" | Reciprocity for a peer: it shows you are thinking about his load, and tells you where to be useful first |
| R3 | "Which two product lines are these, and is Compass one of them?" | Fixes what you would be owning; your note lists Compass as a separate priority, and the answer reshapes D2 and D3 |
| R4 | "Where does partner motion sit today, who owns it, and what isn't working?" | Shows you take the required item seriously and lets you learn what the JD's partner-motion line means in practice |
| R5 | "How are land, adopt, expand and renew measured today, and where is the data weakest?" | A data-driven peer will answer at length, and it tells you where SQL and Tableau work would help first |
| R6 | "With bundling named as the main threat, which new-line decision is most exposed?" | CO signal without reciting the note, and an honest look at where he sees risk |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Set quotas (calling annual volume targets quotas) | Inflated form of F5 | F5's quote at its own scope: annual volume targets, with cross-org consensus. The limit is the pack's observation: the material says volume targets, not quotas. C2's slot asks only what those targets covered |
| Designed the partner motion | Inflated form of F4 | F4's quote at its own scope. The material says the model, not the motion. C1's slot stays inside the model |
| Owned or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. The material says a proposal, not ownership of the outcome |
| Owned GTM strategy or launched new product lines | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The material does not show go-to-market for new lines |
| Ran independent analyses in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope: skilled in the tools. A3's slot asks only whether an analysis was run end to end by you |
| Built or led AI products or programs | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. The material says use, not building |

## Sources

**Provided documents:** your message (JD highlights, Priya's background summary, Dan's profile summary, your research note). No full JD, CV, or Northwind documents were provided. The research note's content and age were not independently checked.

**Searches sent (all four refused; no results came back):**

- `Northwind Data company values` — refused
- `Northwind Data interview process strategy GTM` — refused
- `Northwind Data strategy Compass AI copilot enterprise expansion profitability` — refused
- `Dan Kovac Northwind Data Director Sales Strategy` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. It would have fed a values cheat sheet; none was built, and no VAL questions exist |
| 2. `Northwind Data interview process GTM` | unavailable | Every call was refused. It would have documented the loop; persona weights rest on the relationship prior and your description of a single conversation |
| 3. `Northwind Data strategy` / recent news | unavailable | Every call was refused. It would have checked the freshness of your research note, which D2 and D3 use unverified |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call was refused. It would have added talks or posts to the interviewer read; that read rests on the profile summary only |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six JD quotes in F1 to F6 are re-checked against the whole posting, and any mid-list requirement the highlights left out gets a question
- Anything the recruiter said about Dan's 60 minutes (a case, a presentation, a take-home, stated focus areas) → a build section for any announced deliverable, and reweighted personas
- Your answers to the slots in A1, A2, A3, B2, C1 and C2, stated outside a drill → F2, F3 and F4 move from slots to story-mapped guidance with your own sentences quoted
- Priya's CV text, or the revenue-model write-up or the memo behind the ARR credit → the evidence column quotes her own sentences rather than your summary, and F2 and F4 can move from medium to high
- Search access, or a pasted Northwind strategy brief under about six months old → a grounding brief section, and D2 and D3 move from your note to checked sources; a deeper pass would be up to 6 more searches and 2 more fetches, several more minutes, run only on your yes
- Northwind's published values or a documented interview loop → a values cheat sheet if a values round is documented, and persona weights replaced by the loop's actual rounds
- Dan's public talks or posts → a sharper interviewer read and a reverse question drawn from his own themes
- Prep time available → a prep triage schedule sized to it
- A tuesday-dossier.md from an earlier evidence review, if you have one → verified evidence and any prohibited claims it lists would sharpen the fit snapshot and the prohibited list
